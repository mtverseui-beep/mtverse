# UPGRADE RULES — Mandatory for all new projects

These rules are derived from real issues encountered in previous projects (Meridian Terminal, Meridian Health). Every rule below MUST be followed. Violations cause production-blocking bugs.

---

## 1. HYDRATION — Zero mismatches allowed

**Root cause pattern:** Any code that calls `Date.now()`, `new Date()`, `Math.random()`, or `localStorage` during render or in a way that runs on both server and client will produce different values → hydration mismatch.

**Rules:**
- NEVER use `Date.now()` or `new Date()` in render path, useMemo, or mock-data builders.
- Create a FIXED `NOW` anchor in a formatters file: `export const NOW = new Date("2026-08-01T08:00:00Z").getTime();`
- All mock data must use `NOW` instead of `Date.now()`.
- All formatters (`fmtRelative`, `fmtLengthOfStay`, etc.) must use `NOW`.
- All chart cutoffs (`cutoff = NOW - hours * 3600000`) must use `NOW`.
- All `useState(new Date())` must become `useState(new Date(NOW))`.
- Store actions that run ONLY on client interaction (button clicks) MAY use `new Date()` — they never run during SSR.
- The TopBar clock is the ONE exception: use `useState<string | null>(null)` and set it in `useEffect` so server renders `null` and client renders the time.

---

## 2. LOGO / FAVICON — Use file-based icon convention

**Root cause pattern:** Manual `icons` config in metadata + external CDN URLs (e.g. z.ai scaffold logo) get aggressively cached by browsers. `?v=2` query params are NOT enough.

**Rules:**
- ALWAYS use Next.js App Router file-based icon convention: `src/app/icon.svg`, `src/app/icon.png`, `src/app/favicon.ico`, `src/app/apple-icon.png`.
- NEVER set a manual `icons` object in `metadata` — let the file convention auto-generate hash-busted URLs.
- NEVER reference external CDN URLs for icons.
- Generate PNG/ICO from the SVG using PIL (`scripts/generate-icons.py`).
- In-app `<img src="/icon.svg">` is fine for the sidebar/topbar logo (the file is served at a stable path).

---

## 3. NO NATIVE `<select>` — Use Radix Select everywhere

**Rules:**
- NEVER use `<select>` in any component.
- Build a `ModernSelect` wrapper around shadcn `Select` (Radix) for all dropdowns.
- Map size props: shadcn SelectTrigger only accepts `"sm" | "default"`, so map `"md"` → `"default"`.

---

## 4. NO PLACEHOLDER PAGES — Every route must be real

**Rules:**
- NEVER ship a page that says "coming soon" or "module not wired".
- Every nav item must route to a real page with real content, real data, and real interactions.
- If a page is referenced in the sidebar, it MUST exist and be functional.

---

## 5. NO DEAD BUTTONS — Every button must do something real

**Rules:**
- NEVER ship a button that only shows a generic `toast.info("Call")`.
- Buttons must open a real dialog, navigate to a real route, mutate real state, or perform a real action.
- "Call" → opens a CallDialog with dialing → connected → timer → end call.
- "Message" → opens a MessageDialog with textarea + send.
- "Inbox" → opens a real dropdown with task list + complete actions.
- "View details" → opens a drawer or navigates to a detail page.
- Audit EVERY button before shipping.

---

## 6. NO TABS FOR PRIMARY NAVIGATION — Use a real sidebar

**Rules:**
- NEVER use a row of tabs as the primary navigation for an enterprise app.
- Build a real collapsible sidebar (280px expanded, 72px collapsed) with grouped nav, nested items, active state, collapse persistence (localStorage).
- Tabs are OK for sub-sections within a page (e.g. patient panel tabs), never for app-level navigation.

---

## 7. HASH ROUTER — Real routes for every page

**Rules:**
- Use `useHashRoute` hook for all navigation.
- Every page gets a real route: `/#/dashboard`, `/#/fleet`, `/#/dispatch`, `/#/settings/profile`, etc.
- Sidebar items, profile dropdown items, and "view all" links must navigate via hash.
- The hook must default to a sensible landing route (e.g. "dashboard").

---

## 8. TYPESCRIPT STRICT — Zero tsc errors

**Rules:**
- `bunx tsc --noEmit` must exit 0 with ZERO errors before shipping.
- Common fixes:
  - lucide icon props: type as `React.ComponentType<{ size?: number; className?: string; style?: React.CSSProperties }>` (not just `{ size?: number }`).
  - nivo v0.99: use `seriesColor`/`seriesId` (not `serieColor`/`serieId`), no `LineDatum` export, no `outerRadius` on RadialBar, no `format` on xScale.
  - react-day-picker v10: classNames keys are `button_previous`/`button_next`/`day_button`/`weekday`/`week` (not `nav_button`/`head_row`/`cell`).
  - readonly arrays from `as const`: type explicitly as `T[]` not `readonly [...]`.
  - `<input indeterminate>`: React doesn't support it — use a ref-based IndeterminateCheckbox component.
- Exclude scaffold dirs from tsconfig: `examples`, `skills`, `mini-services`, `tests`.

---

## 9. ESLINT — Zero errors

**Rules:**
- `bun run lint` must exit 0 with ZERO errors (warnings are OK).
- `react-hooks/set-state-in-effect` rule: suppress with `// eslint-disable-next-line react-hooks/set-state-in-effect` on the FIRST setState call in the effect (not on lines that don't trigger it).
- `react-hooks/exhaustive-deps`: only suppress if truly intentional, and remove unused directives.
- TanStack Table `useReactTable` produces a known `react-hooks/incompatible-library` warning — acceptable, not an error.

---

## 10. CHARTS — Verify SVG actually renders

**Rules:**
- After building any chart, verify in the browser that SVG elements exist: `document.querySelectorAll('svg').length > 0`.
- ECharts: pass colors as resolved hex strings (not CSS variables) — ECharts canvas can't resolve `var(--x)`.
- nivo: can use CSS variables in SVG attributes, but for safety use a `useResolvedVar` hook with MutationObserver for theme changes.
- For ECharts theme-awareness: read computed CSS vars via `getComputedStyle` and re-render on theme change.

---

## 11. DIALOG A11Y — Add aria-describedby

**Rules:**
- Every `<DialogContent>` must have `aria-describedby={undefined}` to suppress the "Missing Description" React warning.
- Or include a `<DialogDescription>` element.

---

## 12. PRODUCTION AUDIT — Mandatory before shipping

Run ALL of these and confirm zero errors:
1. `bunx tsc --noEmit` → exit 0, 0 errors
2. `bun run lint` → exit 0, 0 errors (warnings OK)
3. Agent Browser fresh load → 0 hydration errors, 0 runtime errors
4. Test EVERY route (loop through all hash routes) → 0 errors each
5. Browser console → clean (no warnings beyond React DevTools)
6. Click test: inbox, call, message, notifications, theme toggle, every sidebar item, every dropdown, every modal

---

## 13. DESIGN SYSTEM — Must be distinct per project

**Rules:**
- Each project MUST have a completely different color palette, typography, radius scale, and visual identity.
- Project 01 (Trading): indigo accent, JetBrains Mono, 10px radius, glassmorphism, dark-only.
- Project 02 (Healthcare): teal primary, coral critical-only, Inter, 14px radius, calm/clinical, light default.
- Project 03 (FleetOps): amber primary on dark tactical bg, IBM Plex Sans/Mono, 6-8px radius max, industrial/dense.
- NEVER reuse the previous project's globals.css. Start fresh.

---

## 14. RESPONSIVE — Sidebar collapses, not tabs

**Rules:**
- Desktop: full sidebar + right utility rail.
- Tablet: sidebar becomes overlay drawer, utility rail hides.
- Mobile: stacked layout, hamburger menu, drawers replace side panels.
- NEVER collapse to a bottom tab bar for enterprise apps (that's consumer-app pattern).

---

## 15. CODE ORGANIZATION

**Rules:**
- `src/components/<domain>/` — all domain components
- `src/components/<domain>/pages/` — routed page components
- `src/components/<domain>/settings/` — settings sub-pages
- `src/components/<domain>/panel/` — drawer/tab sub-components
- `src/lib/<domain>/` — types, mock-data, format
- `src/store/` — Zustand store
- `src/hooks/` — shared hooks (use-hash-route, use-media-query)
- `src/components/ui/` — shadcn primitives (untouched)
- Scripts in `scripts/` (persisted, not inline)
