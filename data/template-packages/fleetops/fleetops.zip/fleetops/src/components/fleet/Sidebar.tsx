"use client";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, Truck, MapPin, ClipboardList, Route as RouteIcon, Navigation,
  Building2, Package, CalendarClock, Users, Trophy, ShieldCheck, BarChart3, Activity,
  Settings, UserCog, Plug, LifeBuoy, BookOpen, Server, ChevronLeft, Clock,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import type { Route } from "@/hooks/use-hash-route";

interface SidebarProps {
  route: Route;
  navigate: (path: string) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

interface NavItem {
  path: string;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
}
interface NavSection {
  label: string;
  items: NavItem[];
}

const NAV: NavSection[] = [
  {
    label: "Overview",
    items: [{ path: "dashboard", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    label: "Fleet Operations",
    items: [
      { path: "fleet", label: "Live Fleet", icon: Truck },
      { path: "tracking", label: "Vehicle Tracking", icon: MapPin },
      { path: "dispatch", label: "Dispatch Queue", icon: ClipboardList },
      { path: "deliveries", label: "Active Deliveries", icon: Navigation },
      { path: "route-planner", label: "Route Planner", icon: RouteIcon },
    ],
  },
  {
    label: "Routes",
    items: [
      { path: "routes/timeline", label: "Timeline", icon: Activity },
      { path: "routes/optimization", label: "Optimization", icon: BarChart3 },
      { path: "routes/exceptions", label: "Exceptions", icon: ShieldCheck },
    ],
  },
  {
    label: "Warehouses",
    items: [
      { path: "warehouses", label: "Inventory", icon: Package },
      { path: "dock-schedule", label: "Dock Schedule", icon: CalendarClock },
      { path: "loading-bays", label: "Loading Bays", icon: Building2 },
    ],
  },
  {
    label: "Drivers",
    items: [
      { path: "drivers", label: "Leaderboard", icon: Trophy },
      { path: "drivers/compliance", label: "Compliance", icon: ShieldCheck },
      { path: "drivers/safety", label: "Safety", icon: ShieldCheck },
      { path: "drivers/hos", label: "Hours of Service", icon: Clock },
    ],
  },
  {
    label: "Analytics",
    items: [
      { path: "analytics", label: "Performance", icon: BarChart3 },
      { path: "analytics/heatmaps", label: "Heatmaps", icon: Activity },
      { path: "analytics/fuel", label: "Fuel", icon: Activity },
      { path: "analytics/maintenance", label: "Maintenance", icon: Activity },
    ],
  },
  {
    label: "Administration",
    items: [
      { path: "admin/users", label: "Users", icon: UserCog },
      { path: "admin/teams", label: "Teams", icon: Users },
      { path: "admin/permissions", label: "Permissions", icon: ShieldCheck },
      { path: "admin/integrations", label: "Integrations", icon: Plug },
    ],
  },
  {
    label: "Support",
    items: [
      { path: "help", label: "Help Center", icon: LifeBuoy },
      { path: "documentation", label: "Documentation", icon: BookOpen },
      { path: "system-status", label: "System Status", icon: Server },
      { path: "settings", label: "Settings", icon: Settings },
    ],
  },
];

export function Sidebar({ route, navigate, collapsed, onToggleCollapse }: SidebarProps) {
  const currentTop = route.segments[0] ?? "dashboard";

  return (
    <TooltipProvider delayDuration={collapsed ? 200 : 99999}>
      <motion.aside
        initial={false}
        animate={{ width: collapsed ? 56 : 256 }}
        transition={{ duration: 0.2, ease: "easeOut" }}
        className="shrink-0 border-r flex flex-col h-full"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
        aria-label="Primary navigation"
      >
        {/* Brand */}
        <div className="h-16 flex items-center px-3 border-b shrink-0" style={{ borderColor: "var(--border)" }}>
          <button type="button" onClick={() => navigate("dashboard")} className="flex items-center gap-2.5 cursor-pointer focus-ring rounded-[6px] min-w-0 w-full" aria-label="FleetOps home">
            <img src="/icon.svg" alt="FleetOps" width={28} height={28} className="shrink-0" style={{ display: "block" }} />
            <AnimatePresence>
              {!collapsed && (
                <motion.div initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }} transition={{ duration: 0.15 }} className="flex flex-col leading-none min-w-0">
                  <span className="text-[14px] font-semibold tracking-tight text-[var(--foreground)]">FleetOps</span>
                  <span className="text-[10px] text-[var(--foreground-muted)] font-medium uppercase tracking-[0.08em]">Command Center</span>
                </motion.div>
              )}
            </AnimatePresence>
          </button>
        </div>

        {/* Nav — flat list, no expand/collapse */}
        <nav className="flex-1 overflow-y-auto overflow-x-hidden py-3 px-2" role="navigation">
          {NAV.map((section) => (
            <div key={section.label} className="mb-3">
              {!collapsed && (
                <p className="px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)]">
                  {section.label}
                </p>
              )}
              <div className="space-y-px mt-0.5">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const active = currentTop === item.path.split("/")[0] || route.path === item.path;
                  const button = (
                    <button
                      key={item.path}
                      type="button"
                      onClick={() => navigate(item.path)}
                      aria-current={active ? "page" : undefined}
                      className={cn(
                        "w-full flex items-center gap-2.5 px-3 py-1.5 rounded-[6px] text-[13px] font-medium transition-colors cursor-pointer focus-ring relative",
                        active
                          ? "text-[var(--primary)]"
                          : "text-[var(--foreground-secondary)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]",
                        collapsed && "justify-center px-0",
                      )}
                      style={active ? { background: "var(--primary-soft)" } : undefined}
                    >
                      <Icon size={16} className="shrink-0" />
                      <AnimatePresence>
                        {!collapsed && <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 text-left truncate">{item.label}</motion.span>}
                      </AnimatePresence>
                      {collapsed && active && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 rounded-r-full" style={{ background: "var(--primary)" }} />}
                    </button>
                  );
                  if (collapsed) {
                    return (
                      <Tooltip key={item.path}>
                        <TooltipTrigger asChild>{button}</TooltipTrigger>
                        <TooltipContent side="right" sideOffset={8} className="font-sans text-xs" style={{ background: "var(--surface-floating)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "6px" }}>{item.label}</TooltipContent>
                      </Tooltip>
                    );
                  }
                  return button;
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Collapse toggle + Env badge */}
        <div className="border-t shrink-0" style={{ borderColor: "var(--border)" }}>
          <button
            type="button"
            onClick={onToggleCollapse}
            className={cn("w-full flex items-center gap-2 px-3 py-2 text-[11px] font-medium text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring", collapsed && "justify-center")}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {collapsed ? <ChevronLeft size={14} className="rotate-180" /> : <><ChevronLeft size={14} /> <span>Collapse</span></>}
          </button>
          {!collapsed && (
            <div className="px-3 py-1.5 border-t" style={{ borderColor: "var(--border)" }}>
              <div className="flex items-center gap-2 text-[10px] font-mono">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-ontime)" }} />
                <span className="text-[var(--foreground-muted)]">Production</span>
                <span className="ml-auto text-[var(--foreground-muted)]">v4.2.1</span>
              </div>
            </div>
          )}
        </div>
      </motion.aside>
    </TooltipProvider>
  );
}
