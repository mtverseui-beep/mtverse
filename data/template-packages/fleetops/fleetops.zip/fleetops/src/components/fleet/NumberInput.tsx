"use client";
import { cn } from "@/lib/utils";

interface NumberInputProps {
  value: string | number;
  onChange: (value: string) => void;
  min?: number;
  max?: number;
  step?: number;
  disabled?: boolean;
  className?: string;
  ariaLabel?: string;
  suffix?: string;
}

export function NumberInput({ value, onChange, min, max, step, disabled, className, ariaLabel, suffix }: NumberInputProps) {
  return (
    <div className={cn("relative inline-flex items-center", className)}>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        min={min}
        max={max}
        step={step}
        disabled={disabled}
        aria-label={ariaLabel}
        className={cn(
          "w-full h-9 px-3 text-[12px] font-mono tabular-nums rounded-[6px] border bg-[var(--surface)] focus-ring outline-none transition-colors hover:border-[var(--border-strong)] text-[var(--foreground)] placeholder:text-[var(--foreground-muted)]",
          "disabled:opacity-50 disabled:cursor-not-allowed",
          suffix && "pr-10",
        )}
        style={{ borderColor: "var(--border)" }}
      />
      {suffix && (
        <span className="absolute right-3 text-[10px] font-mono text-[var(--foreground-muted)] pointer-events-none">{suffix}</span>
      )}
    </div>
  );
}
