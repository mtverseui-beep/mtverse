"use client";
import { useMemo, useState, useEffect, useRef } from "react";
import { flexRender, getCoreRowModel, getFilteredRowModel, getSortedRowModel, getPaginationRowModel, useReactTable, type ColumnDef, type SortingState, type RowSelectionState, type VisibilityState } from "@tanstack/react-table";
import { Search, ChevronUp, ChevronDown, ChevronsUpDown, ChevronLeft, ChevronRight, Settings2, Download, MoreHorizontal, Eye, MessageSquare, Phone, Wrench, AlertTriangle, MapPin, X } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuCheckboxItem } from "@/components/ui/dropdown-menu";
import { useFleetStore } from "@/store/fleet-store";
import { FleetMapWrapper as FleetMap } from "./FleetMapWrapper";
import { StatusBadge, PriorityBadge } from "./ui";
import { VehicleDrawer } from "./VehicleDrawer";
import { ModernSelect } from "./ModernSelect";
import { fmtETA, fmtRelative } from "@/lib/fleet/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Vehicle } from "@/lib/fleet/types";

export function FleetPage() {
  const vehicles = useFleetStore((s) => s.vehicles);
  const drivers = useFleetStore((s) => s.drivers);
  const routes = useFleetStore((s) => s.routes);
  const selectVehicle = useFleetStore((s) => s.selectVehicle);
  const selectedVehicleId = useFleetStore((s) => s.selectedVehicleId);

  const [sorting, setSorting] = useState<SortingState>([{ id: "status", desc: false }]);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [globalFilter, setGlobalFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [pageSize, setPageSize] = useState(20);

  const filtered = useMemo(() => {
    if (statusFilter === "all") return vehicles;
    return vehicles.filter(v => v.status === statusFilter);
  }, [vehicles, statusFilter]);

  const columns = useMemo<ColumnDef<Vehicle>[]>(() => [
    { id: "select", size: 36, header: ({ table }) => <input type="checkbox" checked={table.getIsAllPageRowsSelected()} ref={(el) => { if (el) el.indeterminate = !!table.getIsSomePageRowsSelected(); }} onChange={table.getToggleAllPageRowsSelectedHandler()} className="w-3.5 h-3.5 rounded cursor-pointer accent-[var(--primary)]" aria-label="Select all" />, cell: ({ row }) => <input type="checkbox" checked={row.getIsSelected()} onChange={row.getToggleSelectedHandler()} className="w-3.5 h-3.5 rounded cursor-pointer accent-[var(--primary)]" aria-label={`Select ${row.original.unit}`} />, enableSorting: false, enableHiding: false },
    { accessorKey: "unit", header: "Vehicle", size: 90, cell: ({ row }) => <span className="text-[12px] font-mono font-bold text-[var(--foreground)]">{row.original.unit}</span> },
    { id: "driver", accessorFn: (v) => drivers.find(d => d.id === v.driverId)?.name ?? "Unassigned", header: "Driver", size: 140, cell: ({ row }) => { const d = drivers.find(d => d.id === row.original.driverId); return d ? <span className="text-[12px] text-[var(--foreground-secondary)]">{d.name}</span> : <span className="text-[12px] text-[var(--foreground-muted)] italic">Unassigned</span>; } },
    { id: "route", accessorFn: (v) => routes.find(r => r.id === v.currentRouteId)?.destCity ?? "—", header: "Route", size: 120, cell: ({ row }) => { const r = routes.find(r => r.id === row.original.currentRouteId); return r ? <span className="text-[12px] font-mono text-[var(--foreground-secondary)]">{r.originCity} → {r.destCity}</span> : <span className="text-[12px] text-[var(--foreground-muted)]">—</span>; } },
    { accessorKey: "region", header: "Region", size: 120, cell: ({ row }) => <span className="text-[11px] text-[var(--foreground-muted)]">{row.original.region}</span> },
    { accessorKey: "speed", header: "Speed", size: 70, cell: ({ row }) => <span className="text-[12px] font-mono tabular-nums text-[var(--foreground)]">{row.original.speed}<span className="text-[var(--foreground-muted)] text-[10px]"> mph</span></span> },
    { id: "eta", header: "ETA", size: 90, cell: ({ row }) => <span className={cn("text-[12px] font-mono tabular-nums", row.original.status === "delayed" ? "text-[var(--status-delayed)]" : "text-[var(--foreground)]")}>{fmtETA(row.original.eta)}</span> },
    { accessorKey: "fuelPct", header: "Fuel", size: 70, cell: ({ row }) => { const pct = row.original.fuelPct; const color = pct < 25 ? "var(--status-delayed)" : pct < 50 ? "var(--status-atrisk)" : "var(--status-ontime)"; return <div className="flex items-center gap-1.5"><div className="w-10 h-1.5 rounded-full" style={{ background: "var(--surface-hover)" }}><div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} /></div><span className="text-[10px] font-mono text-[var(--foreground-muted)]">{pct}%</span></div>; } },
    { accessorKey: "capacityPct", header: "Load", size: 70, cell: ({ row }) => <span className="text-[12px] font-mono tabular-nums text-[var(--foreground-secondary)]">{row.original.capacityPct}%</span> },
    { accessorKey: "status", header: "Status", size: 110, cell: ({ row }) => <StatusBadge status={row.original.status} size="sm" /> },
    { id: "lastCheckIn", accessorFn: (v) => v.lastCheckIn, header: "Last Check-In", size: 90, cell: ({ row }) => <span className="text-[11px] font-mono text-[var(--foreground-muted)]">{fmtRelative(row.original.lastCheckIn)}</span> },
    { id: "actions", header: "", size: 44, enableSorting: false, enableHiding: false, cell: ({ row }) => (
      <DropdownMenu>
        <DropdownMenuTrigger asChild><button type="button" className="w-7 h-7 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label={`Actions for ${row.original.unit}`}><MoreHorizontal size={14} /></button></DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-44 font-sans" style={{ background: "var(--surface-floating)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "6px", boxShadow: "var(--shadow-lg)" }}>
          <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">{row.original.unit}</DropdownMenuLabel>
          <DropdownMenuSeparator style={{ background: "var(--border)" }} />
          <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => selectVehicle(row.original.id)}><Eye size={13} /> View details</DropdownMenuItem>
          <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => toast.success("Dispatch started", { description: row.original.unit })}><MapPin size={13} /> Dispatch</DropdownMenuItem>
          <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => toast.success("Message sent", { description: `Message to ${row.original.unit} driver` })}><MessageSquare size={13} /> Message driver</DropdownMenuItem>
          <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => toast.success("Reroute", { description: `${row.original.unit} rerouted` })}><MapPin size={13} /> Reroute</DropdownMenuItem>
          <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => toast.success("Maintenance flagged", { description: row.original.unit })}><Wrench size={13} /> Maintenance</DropdownMenuItem>
          <DropdownMenuSeparator style={{ background: "var(--border)" }} />
          <DropdownMenuItem className="cursor-pointer focus:bg-[var(--status-delayed-soft)] rounded-[4px] mx-1 text-[12px] gap-2 text-[var(--status-delayed)]" onClick={() => toast.success("Incident reported", { description: row.original.unit })}><AlertTriangle size={13} /> Incident report</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    )},
  ], [drivers, routes, selectVehicle]);

  const table = useReactTable({ data: filtered, columns, state: { sorting, rowSelection, columnVisibility, globalFilter }, enableRowSelection: true, onSortingChange: setSorting, onRowSelectionChange: setRowSelection, onColumnVisibilityChange: setColumnVisibility, onGlobalFilterChange: setGlobalFilter, getCoreRowModel: getCoreRowModel(), getFilteredRowModel: getFilteredRowModel(), getSortedRowModel: getSortedRowModel(), getPaginationRowModel: getPaginationRowModel(), getRowId: (r) => r.id, initialState: { pagination: { pageSize } }, globalFilterFn: (row, _col, filterValue) => { const v = String(filterValue).toLowerCase(); const veh = row.original; return veh.unit.toLowerCase().includes(v) || veh.region.toLowerCase().includes(v) || (drivers.find(d => d.id === veh.driverId)?.name.toLowerCase().includes(v) ?? false); } });
  useEffect(() => { table.setPageSize(pageSize); }, [pageSize, table]);

  const selectedRows = table.getSelectedRowModel().rows.map(r => r.original);

  return (
    <div className="p-5">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight">Live Fleet</h1>
          <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">{vehicles.length} vehicles · {vehicles.filter(v => v.status === "on-time").length} on time · {vehicles.filter(v => v.status === "delayed").length} delayed · {vehicles.filter(v => v.status === "offline").length} offline</p>
        </div>
        <div className="flex items-center gap-2">
          <ModernSelect
            value={statusFilter}
            onValueChange={setStatusFilter}
            size="sm"
            ariaLabel="Filter by status"
            options={[
              { value: "all", label: "All statuses" },
              { value: "on-time", label: "On Time" },
              { value: "at-risk", label: "At Risk" },
              { value: "delayed", label: "Delayed" },
              { value: "offline", label: "Offline" },
              { value: "maintenance", label: "Maintenance" },
            ]}
          />
          <button type="button" onClick={() => toast.success("Export started", { description: `${filtered.length} vehicles exporting to CSV` })} className="h-8 px-3 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5 text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}><Download size={13} /> Export</button>
        </div>
      </div>

      {/* Map + Table split */}
      <div className="grid grid-cols-1 xl:grid-cols-[38%_1fr] gap-4 mb-4">
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <div className="px-4 py-2 border-b flex items-center justify-between" style={{ borderColor: "var(--border)" }}>
            <h3 className="text-[12px] font-semibold">Fleet Map</h3>
            <span className="text-[10px] font-mono text-[var(--foreground-muted)]">{vehicles.filter(v => v.status !== "offline" && v.status !== "maintenance").length} active</span>
          </div>
          <FleetMap vehicles={vehicles} selectedId={selectedVehicleId} onSelect={selectVehicle} />
        </div>
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <div className="px-4 py-2 border-b" style={{ borderColor: "var(--border)" }}>
            <h3 className="text-[12px] font-semibold">Vehicle Details</h3>
          </div>
          {selectedVehicleId ? <VehicleDrawer vehicleId={selectedVehicleId} embedded /> : <div className="p-8 text-center"><MapPin size={28} className="mx-auto text-[var(--foreground-muted)] mb-2" /><p className="text-[12px] text-[var(--foreground-muted)]">Select a vehicle from the map or table to view details</p></div>}
        </div>
      </div>

      {/* Bulk action bar */}
      {selectedRows.length > 0 && (
        <div className="flex items-center gap-3 px-3 py-2 rounded-[6px] border mb-3" style={{ background: "var(--primary-soft)", borderColor: "var(--primary)" }}>
          <span className="text-[12px] font-semibold text-[var(--primary)]">{selectedRows.length} selected</span>
          <div className="flex items-center gap-2 ml-auto">
            <button type="button" onClick={() => toast.success("Dispatch started", { description: `${selectedRows.length} vehicles` })} className="px-2.5 py-1 text-[11px] font-medium rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground)]" style={{ borderColor: "var(--border)" }}>Dispatch</button>
            <button type="button" onClick={() => toast.success("Exported selected")} className="px-2.5 py-1 text-[11px] font-medium rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground)]" style={{ borderColor: "var(--border)" }}>Export</button>
            <button type="button" onClick={() => { setRowSelection({}); toast.success("Selection cleared"); }} className="px-2.5 py-1 text-[11px] font-medium rounded-[4px] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-muted)]">Clear</button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <div className="flex items-center gap-2 px-3 py-2 border-b flex-wrap" style={{ borderColor: "var(--border)" }}>
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" />
            <input value={globalFilter} onChange={(e) => setGlobalFilter(e.target.value)} placeholder="Search fleet…" className="w-full h-8 pl-8 pr-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none placeholder:text-[var(--foreground-muted)] text-[var(--foreground)]" style={{ borderColor: "var(--border)" }} aria-label="Search fleet" />
          </div>
          <div className="flex items-center gap-1.5 ml-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild><button type="button" className="h-8 px-2.5 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5 text-[var(--foreground-muted)]" style={{ borderColor: "var(--border)" }}><Settings2 size={13} /> Columns</button></DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40 font-sans" style={{ background: "var(--surface-floating)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "6px" }}>
                <DropdownMenuLabel className="text-[10px] uppercase text-[var(--foreground-muted)]">Toggle columns</DropdownMenuLabel>
                <DropdownMenuSeparator style={{ background: "var(--border)" }} />
                {table.getAllColumns().filter(c => c.getCanHide()).map(col => <DropdownMenuCheckboxItem key={col.id} checked={col.getIsVisible()} onCheckedChange={(v) => col.toggleVisibility(!!v)} className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] capitalize">{col.id.replace(/-/g, " ")}</DropdownMenuCheckboxItem>)}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead className="sticky top-0 z-10">
              {table.getHeaderGroups().map(hg => (
                <tr key={hg.id} className="border-b" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
                  {hg.headers.map(header => (
                    <th key={header.id} className={cn("px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap", header.column.getCanSort() && "cursor-pointer hover:text-[var(--foreground)] select-none")} style={{ width: header.getSize() !== 150 ? header.getSize() : undefined }}>
                      {header.isPlaceholder ? null : <div className="flex items-center gap-1" onClick={header.column.getToggleSortingHandler()}>{flexRender(header.column.columnDef.header, header.getContext())}{header.column.getCanSort() && <span className="opacity-50">{header.column.getIsSorted() === "asc" ? <ChevronUp size={11} /> : header.column.getIsSorted() === "desc" ? <ChevronDown size={11} /> : <ChevronsUpDown size={11} className="opacity-40" />}</span>}</div>}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody>
              {table.getRowModel().rows.map(row => {
                const isSelected = selectedVehicleId === row.original.id;
                return (
                  <tr key={row.id} data-state={row.getIsSelected() ? "selected" : undefined} onClick={() => selectVehicle(row.original.id)} tabIndex={0} onKeyDown={e => { if (e.key === "Enter") selectVehicle(row.original.id); }} className={cn("border-b last:border-0 transition-colors cursor-pointer outline-none", isSelected ? "bg-[var(--primary-soft)]" : row.getIsSelected() ? "bg-[var(--surface-elevated)]" : "hover:bg-[var(--surface-hover)]")} style={{ borderColor: "var(--border)" }} aria-selected={isSelected}>
                    {row.getVisibleCells().map(cell => <td key={cell.id} className="px-3 py-1.5" onClick={cell.column.id === "select" ? e => e.stopPropagation() : undefined}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>)}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-3 py-2 border-t flex-wrap gap-2" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
          <div className="flex items-center gap-2 text-[11px] font-mono text-[var(--foreground-muted)]">
            <span>{table.getFilteredRowModel().rows.length} vehicles</span><span style={{ color: "var(--border-strong)" }}>|</span>
            <ModernSelect
              value={String(pageSize)}
              onValueChange={(v) => setPageSize(Number(v))}
              size="sm"
              ariaLabel="Page size"
              options={[
                { value: "10", label: "10" },
                { value: "20", label: "20" },
                { value: "50", label: "50" },
              ]}
            /><span>per page</span>
          </div>
          <div className="flex items-center gap-1">
            <button type="button" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} className="w-7 h-7 rounded-[4px] border flex items-center justify-center disabled:opacity-40 hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" style={{ borderColor: "var(--border)" }}><ChevronLeft size={14} /></button>
            <span className="text-[11px] font-mono text-[var(--foreground-muted)] px-1">{table.getState().pagination.pageIndex + 1} / {table.getPageCount() || 1}</span>
            <button type="button" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()} className="w-7 h-7 rounded-[4px] border flex items-center justify-center disabled:opacity-40 hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" style={{ borderColor: "var(--border)" }}><ChevronRight size={14} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}
