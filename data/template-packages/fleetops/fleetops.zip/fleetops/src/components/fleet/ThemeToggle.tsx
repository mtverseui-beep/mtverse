"use client";
import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { Sun, Moon, Monitor } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type ThemeOption = "light" | "dark" | "system";
const OPTIONS: { id: ThemeOption; label: string; icon: React.ComponentType<{ size?: number }> }[] = [
  { id: "light", label: "Light", icon: Sun },
  { id: "dark", label: "Dark", icon: Moon },
  { id: "system", label: "System", icon: Monitor },
];

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);
  const current = (theme as ThemeOption) ?? "light";
  const CurrentIcon = mounted ? OPTIONS.find((o) => o.id === current)?.icon ?? Sun : Sun;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button type="button" aria-label="Toggle theme" className="w-9 h-9 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer">
          <AnimatePresence mode="wait" initial={false}>
            <motion.span key={mounted ? current : "placeholder"} initial={{ opacity: 0, rotate: -90, scale: 0.5 }} animate={{ opacity: 1, rotate: 0, scale: 1 }} exit={{ opacity: 0, rotate: 90, scale: 0.5 }} transition={{ duration: 0.15 }}>
              <CurrentIcon size={16} />
            </motion.span>
          </AnimatePresence>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" sideOffset={6} className="w-36 font-sans" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "6px", boxShadow: "var(--shadow-lg)" }}>
        {OPTIONS.map((opt) => {
          const Icon = opt.icon;
          const active = mounted && current === opt.id;
          return (
            <DropdownMenuItem key={opt.id} onClick={() => setTheme(opt.id)} className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 gap-2.5 px-2 py-1.5 text-[12px]">
              <Icon size={14} />
              <span className="flex-1">{opt.label}</span>
              {active && <motion.span layoutId="theme-active" className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--primary)" }} />}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
