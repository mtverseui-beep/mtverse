"use client";
import { useMemo, useState } from "react";
import { useFleetStore } from "@/store/fleet-store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { NOW } from "@/lib/fleet/format";
import type { NotificationCategory, Notification } from "@/lib/fleet/types";
import {
  Bell, Search, CheckCheck, Archive, AlertTriangle, Truck, Users,
  Building2, Server, Zap, Filter,
} from "lucide-react";

const CATEGORIES: { id: NotificationCategory | "all"; label: string; icon: React.ComponentType<{ size?: number; className?: string }> }[] = [
  { id: "all", label: "All", icon: Bell },
  { id: "critical", label: "Critical", icon: AlertTriangle },
  { id: "dispatch", label: "Dispatch", icon: Zap },
  { id: "fleet", label: "Fleet", icon: Truck },
  { id: "drivers", label: "Drivers", icon: Users },
  { id: "warehouses", label: "Warehouses", icon: Building2 },
  { id: "system", label: "System", icon: Server },
];

function groupByTime(notifs: Notification[]): { label: string; items: Notification[] }[] {
  const today: Notification[] = [];
  const yesterday: Notification[] = [];
  const earlier: Notification[] = [];
  const startOfToday = NOW - 24 * 3600000;
  const startOfYesterday = NOW - 48 * 3600000;
  for (const n of notifs) {
    const t = new Date(n.timestamp).getTime();
    if (t >= startOfToday) today.push(n);
    else if (t >= startOfYesterday) yesterday.push(n);
    else earlier.push(n);
  }
  return [
    { label: "Today", items: today },
    { label: "Yesterday", items: yesterday },
    { label: "Earlier", items: earlier },
  ].filter((g) => g.items.length > 0);
}

const CATEGORY_META: Record<NotificationCategory, { color: string; soft: string; icon: React.ComponentType<{ size?: number; className?: string }> }> = {
  critical: { color: "var(--status-delayed)", soft: "var(--status-delayed-soft)", icon: AlertTriangle },
  dispatch: { color: "var(--primary)", soft: "var(--primary-soft)", icon: Zap },
  fleet: { color: "var(--status-atrisk)", soft: "var(--status-atrisk-soft)", icon: Truck },
  drivers: { color: "var(--accent)", soft: "var(--accent-soft)", icon: Users },
  warehouses: { color: "var(--status-ontime)", soft: "var(--status-ontime-soft)", icon: Building2 },
  system: { color: "var(--status-maintenance)", soft: "var(--status-maintenance-soft)", icon: Server },
};

export function NotificationsPage() {
  const notifications = useFleetStore((s) => s.notifications);
  const markNotificationRead = useFleetStore((s) => s.markNotificationRead);
  const markAllNotificationsRead = useFleetStore((s) => s.markAllNotificationsRead);
  const archiveNotification = useFleetStore((s) => s.archiveNotification);

  const [activeCat, setActiveCat] = useState<NotificationCategory | "all">("all");
  const [query, setQuery] = useState("");
  const [showArchived, setShowArchived] = useState(false);

  const filtered = useMemo(() => {
    return notifications
      .filter((n) => (showArchived ? n.archived : !n.archived))
      .filter((n) => (activeCat === "all" ? true : n.category === activeCat))
      .filter((n) =>
        !query ||
        n.title.toLowerCase().includes(query.toLowerCase()) ||
        n.body.toLowerCase().includes(query.toLowerCase())
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [notifications, activeCat, query, showArchived]);

  const grouped = useMemo(() => groupByTime(filtered), [filtered]);
  const unreadCount = notifications.filter((n) => !n.read && !n.archived).length;
  const archivedCount = notifications.filter((n) => n.archived).length;

  const handleMarkAllRead = () => {
    markAllNotificationsRead();
    toast.success("All notifications marked as read");
  };

  const handleMarkRead = (n: Notification) => {
    if (!n.read) {
      markNotificationRead(n.id);
      toast.success("Marked as read", { description: n.title });
    }
  };

  const handleArchive = (n: Notification) => {
    archiveNotification(n.id);
    toast.success("Archived", { description: n.title });
  };

  return (
    <div className="p-5 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight flex items-center gap-2">
            <Bell size={20} style={{ color: "var(--primary)" }} />
            Notification Center
          </h1>
          <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">
            {unreadCount} unread · {archivedCount} archived · {notifications.length} total
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowArchived((s) => !s)}
            className="h-8 px-3 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5"
            style={{
              borderColor: showArchived ? "var(--primary)" : "var(--border)",
              color: showArchived ? "var(--primary)" : "var(--foreground-secondary)",
              background: showArchived ? "var(--primary-soft)" : "transparent",
            }}
          >
            <Archive size={13} /> {showArchived ? "Showing archived" : "Show archived"}
          </button>
          <button
            type="button"
            onClick={handleMarkAllRead}
            disabled={unreadCount === 0}
            className="h-8 px-3 text-[12px] font-medium rounded-[6px] text-[var(--background)] cursor-pointer focus-ring flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
            style={{ background: "var(--primary)" }}
          >
            <CheckCheck size={13} /> Mark all read
          </button>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-1 p-1 rounded-[8px] border overflow-x-auto" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <Filter size={13} className="text-[var(--foreground-muted)] ml-1.5 shrink-0" />
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          const count = cat.id === "all"
            ? notifications.filter((n) => !n.archived).length
            : notifications.filter((n) => n.category === cat.id && !n.archived).length;
          const unread = cat.id === "all"
            ? notifications.filter((n) => !n.read && !n.archived).length
            : notifications.filter((n) => n.category === cat.id && !n.read && !n.archived).length;
          const active = activeCat === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => { setActiveCat(cat.id); toast.info(`Filter: ${cat.label}`, { description: `${count} notifications` }); }}
              aria-pressed={active}
              className={cn(
                "flex items-center gap-1.5 px-2.5 py-1.5 text-[12px] font-medium rounded-[6px] cursor-pointer focus-ring transition-colors whitespace-nowrap",
                active ? "text-[var(--background)]" : "text-[var(--foreground-secondary)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]"
              )}
              style={active ? { background: "var(--primary)" } : undefined}
            >
              <Icon size={13} />
              <span>{cat.label}</span>
              {unread > 0 && (
                <span
                  className="text-[9px] font-mono font-bold px-1 py-px rounded-[3px]"
                  style={{
                    background: active ? "var(--background)" : "var(--status-delayed-soft)",
                    color: active ? "var(--primary)" : "var(--status-delayed)",
                  }}
                >
                  {unread}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Search */}
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <div className="px-3 py-2 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="relative max-w-md">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search notifications…"
              className="w-full h-8 pl-8 pr-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none placeholder:text-[var(--foreground-muted)] text-[var(--foreground)]"
              style={{ borderColor: "var(--border)" }}
              aria-label="Search notifications"
            />
          </div>
        </div>

        {/* Notifications grouped */}
        <div className="max-h-[600px] overflow-y-auto">
          {grouped.length === 0 && (
            <div className="px-4 py-12 text-center">
              <Bell size={32} className="mx-auto text-[var(--foreground-muted)] mb-3 opacity-40" />
              <p className="text-[13px] text-[var(--foreground-secondary)]">No notifications match your filters</p>
              <p className="text-[11px] text-[var(--foreground-muted)] mt-1">Try adjusting the category or search query</p>
            </div>
          )}

          {grouped.map((group) => (
            <div key={group.label}>
              <div className="sticky top-0 z-10 flex items-center gap-2 px-4 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] border-b border-t" style={{ background: "var(--surface-elevated)", borderColor: "var(--border)" }}>
                {group.label}
                <span className="font-mono text-[var(--foreground-muted)]">· {group.items.length}</span>
              </div>
              {group.items.map((n) => {
                const meta = CATEGORY_META[n.category];
                const CatIcon = meta.icon;
                const sevColor = n.severity === "critical" ? "var(--status-delayed)" : n.severity === "warning" ? "var(--status-atrisk)" : "var(--status-ontime)";
                return (
                  <div
                    key={n.id}
                    className={cn(
                      "flex items-start gap-3 px-4 py-2.5 border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors group",
                      !n.read && "bg-[var(--primary-soft)]"
                    )}
                    style={{ borderColor: "var(--border)" }}
                  >
                    {/* Category icon */}
                    <div className="shrink-0 w-8 h-8 rounded-[6px] flex items-center justify-center" style={{ background: meta.soft, color: meta.color }}>
                      <CatIcon size={14} />
                    </div>

                    {/* Body */}
                    <button
                      type="button"
                      onClick={() => handleMarkRead(n)}
                      className="flex-1 min-w-0 text-left cursor-pointer focus-ring rounded-[4px] outline-none"
                      aria-label={`Notification: ${n.title}`}
                    >
                      <div className="flex items-center gap-2">
                        {!n.read && <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: "var(--primary)" }} />}
                        <span className="text-[12px] font-semibold text-[var(--foreground)] truncate">{n.title}</span>
                        <span className="text-[9px] font-mono uppercase tracking-wider px-1 py-px rounded-[3px] shrink-0" style={{ background: `color-mix(in srgb, ${sevColor} 12%, transparent)`, color: sevColor }}>
                          {n.severity}
                        </span>
                      </div>
                      <p className="text-[11px] text-[var(--foreground-secondary)] mt-0.5 line-clamp-2">{n.body}</p>
                      <div className="flex items-center gap-2 mt-1 text-[10px] font-mono text-[var(--foreground-muted)]">
                        <span>{n.time}</span>
                        <span>·</span>
                        <span className="uppercase">{n.category}</span>
                        {n.vehicleId && (<><span>·</span><span>{n.vehicleId}</span></>)}
                        {n.driverId && (<><span>·</span><span>{n.driverId}</span></>)}
                      </div>
                    </button>

                    {/* Actions */}
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {!n.read && (
                        <button
                          type="button"
                          onClick={() => handleMarkRead(n)}
                          className="w-7 h-7 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--status-ontime)] hover:bg-[var(--status-ontime-soft)] cursor-pointer focus-ring"
                          aria-label="Mark as read"
                          title="Mark as read"
                        >
                          <CheckCheck size={13} />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleArchive(n)}
                        className="w-7 h-7 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring"
                        aria-label="Archive notification"
                        title="Archive"
                      >
                        <Archive size={13} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-3 py-2 border-t" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
          <span className="text-[11px] font-mono text-[var(--foreground-muted)]">{filtered.length} notifications</span>
          <button
            type="button"
            onClick={() => toast.success("All archived notifications cleared")}
            className="text-[11px] font-medium text-[var(--foreground-muted)] hover:text-[var(--status-delayed)] cursor-pointer focus-ring"
          >
            Clear archived
          </button>
        </div>
      </div>
    </div>
  );
}
