"use client";
import { useFleetStore } from "@/store/fleet-store";
import { NOW, fmtETA } from "@/lib/fleet/format";
import { Activity, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

export function RoutesPage() {
  const routes = useFleetStore((s) => s.routes);
  const vehicles = useFleetStore((s) => s.vehicles);
  const drivers = useFleetStore((s) => s.drivers);

  return (
    <div className="p-5">
      <div className="mb-4">
        <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight">Route Timeline</h1>
        <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">{routes.length} active routes · Gantt view</p>
      </div>
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <div className="px-4 py-2.5 border-b flex items-center gap-2" style={{ borderColor: "var(--border)" }}>
          <Activity size={15} style={{ color: "var(--primary)" }} />
          <h3 className="text-[13px] font-semibold">Active Routes</h3>
        </div>
        {/* Timeline header */}
        <div className="flex items-center px-4 py-1.5 border-b text-[10px] font-mono text-[var(--foreground-muted)]" style={{ borderColor: "var(--border)" }}>
          <span className="w-44">Route</span>
          <div className="flex-1 flex">
            {Array.from({ length: 12 }, (_, i) => <span key={i} className="flex-1 text-center">{String(i * 2).padStart(2, "0")}:00</span>)}
          </div>
          <span className="w-14 text-right">ETA</span>
        </div>
        {routes.map(r => {
          const v = vehicles.find(x => x.id === r.vehicleId);
          const d = drivers.find(x => x.id === r.driverId);
          const startMs = new Date(r.actualStart ?? r.plannedStart).getTime();
          const etaMs = new Date(r.eta).getTime();
          const spanMs = 24 * 3600000;
          const startPct = Math.max(0, Math.min(100, ((startMs - (NOW - 12 * 3600000)) / spanMs) * 100));
          const widthPct = Math.max(2, Math.min(100 - startPct, ((etaMs - startMs) / spanMs) * 100));
          const statusColor = r.status === "delayed" ? "var(--status-delayed)" : v?.status === "at-risk" ? "var(--status-atrisk)" : "var(--status-ontime)";
          return (
            <div key={r.id} className="flex items-center px-4 py-1.5 border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors" style={{ borderColor: "var(--border)" }}>
              <div className="w-44 min-w-0">
                <div className="flex items-center gap-1 text-[11px]">
                  <span className="font-mono font-semibold text-[var(--foreground)] truncate">{r.originCity} → {r.destCity}</span>
                </div>
                <div className="text-[9px] text-[var(--foreground-muted)] font-mono">{v?.unit} · {d?.name?.split(" ").slice(-1)[0]}</div>
              </div>
              <div className="flex-1 relative h-5" style={{ background: "var(--background)" }}>
                <div className="absolute inset-y-0 rounded-[3px] flex items-center px-1.5 cursor-grab hover:brightness-110" style={{ left: `${startPct}%`, width: `${widthPct}%`, background: statusColor }} title={`${r.originCity} → ${r.destCity} · ${r.distanceMiles}mi`}>
                  <span className="text-[9px] font-mono font-semibold text-[var(--background)] truncate">{v?.unit}</span>
                </div>
              </div>
              <span className={cn("w-14 text-right text-[10px] font-mono", r.status === "delayed" ? "text-[var(--status-delayed)]" : "text-[var(--foreground-muted)]")}>{fmtETA(r.eta)}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
