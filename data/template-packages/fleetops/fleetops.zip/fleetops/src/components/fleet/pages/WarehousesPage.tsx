"use client";
import { useState, useMemo } from "react";
import { useFleetStore } from "@/store/fleet-store";
import { KPI } from "../ui";
import { ModernSelect } from "../ModernSelect";
import { fmtNumber } from "@/lib/fleet/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { Building2, Package, Activity, ListOrdered, Search, Download, ArrowRight } from "lucide-react";
import type { Warehouse } from "@/lib/fleet/types";

export function WarehousesPage() {
  const warehouses = useFleetStore((s) => s.warehouses);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filtered = useMemo(() => {
    return warehouses.filter((w) => {
      const matchesQuery =
        !query ||
        w.code.toLowerCase().includes(query.toLowerCase()) ||
        w.name.toLowerCase().includes(query.toLowerCase()) ||
        w.city.toLowerCase().includes(query.toLowerCase()) ||
        w.region.toLowerCase().includes(query.toLowerCase());
      const matchesStatus = statusFilter === "all" || w.status === statusFilter;
      return matchesQuery && matchesStatus;
    });
  }, [warehouses, query, statusFilter]);

  const totalDocks = warehouses.reduce((a, w) => a + w.dockCount, 0);
  const occupiedDocks = warehouses.reduce((a, w) => a + w.docksOccupied, 0);
  const dockOccupancyPct = totalDocks > 0 ? (occupiedDocks / totalDocks) * 100 : 0;
  const totalBays = warehouses.reduce((a, w) => a + w.loadingBays, 0);
  const baysInUse = warehouses.reduce((a, w) => a + w.baysInUse, 0);
  const baysPct = totalBays > 0 ? (baysInUse / totalBays) * 100 : 0;
  const totalThroughput = warehouses.reduce((a, w) => a + w.throughputToday, 0);
  const totalQueue = warehouses.reduce((a, w) => a + w.queueLength, 0);
  const congested = warehouses.filter((w) => w.status === "congested").length;

  const onRowClick = (w: Warehouse) => {
    toast.info(`${w.code} · ${w.name}`, {
      description: `${w.city}, ${w.region} · ${w.docksOccupied}/${w.dockCount} docks occupied · ${w.queueLength} in queue · ${w.throughputToday} units today`,
    });
  };

  return (
    <div className="p-5 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight flex items-center gap-2">
            <Building2 size={20} style={{ color: "var(--primary)" }} />
            Warehouse Operations
          </h1>
          <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">
            {warehouses.length} distribution centers · {congested} congested · {fmtNumber(totalThroughput)} units processed today
          </p>
        </div>
        <button
          type="button"
          onClick={() => toast.success("Export started", { description: `${warehouses.length} warehouses exporting to CSV` })}
          className="h-8 px-3 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5 text-[var(--foreground-secondary)]"
          style={{ borderColor: "var(--border)" }}
        >
          <Download size={13} /> Export
        </button>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <KPI
          icon={Activity}
          label="Dock Occupancy"
          value={`${dockOccupancyPct.toFixed(0)}%`}
          sub={`${occupiedDocks}/${totalDocks} docks`}
          status={dockOccupancyPct > 85 ? "delayed" : dockOccupancyPct > 70 ? "at-risk" : "on-time"}
          onClick={() => toast.info("Dock occupancy", { description: `${occupiedDocks} of ${totalDocks} docks occupied across ${warehouses.length} warehouses` })}
        />
        <KPI
          icon={Package}
          label="Loading Bays"
          value={`${baysInUse}`}
          sub={`${baysPct.toFixed(0)}% in use · ${totalBays} total`}
          status={baysPct > 85 ? "at-risk" : "on-time"}
          onClick={() => toast.info("Loading bays", { description: `${baysInUse} of ${totalBays} bays active` })}
        />
        <KPI
          icon={ListOrdered}
          label="Throughput Today"
          value={fmtNumber(totalThroughput)}
          sub="units processed"
          status="on-time"
          onClick={() => toast.info("Throughput", { description: `${fmtNumber(totalThroughput)} units processed across network today` })}
        />
        <KPI
          icon={ArrowRight}
          label="Queue Length"
          value={String(totalQueue)}
          sub="trailers waiting"
          status={totalQueue > 20 ? "delayed" : totalQueue > 8 ? "at-risk" : "on-time"}
          onClick={() => toast.info("Queue length", { description: `${totalQueue} trailers queued network-wide` })}
        />
      </div>

      {/* Warehouse table */}
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        {/* Toolbar */}
        <div className="flex items-center gap-2 px-3 py-2 border-b flex-wrap" style={{ borderColor: "var(--border)" }}>
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search warehouses…"
              className="w-full h-8 pl-8 pr-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none placeholder:text-[var(--foreground-muted)] text-[var(--foreground)]"
              style={{ borderColor: "var(--border)" }}
              aria-label="Search warehouses"
            />
          </div>
          <ModernSelect
            value={statusFilter}
            onValueChange={setStatusFilter}
            size="sm"
            ariaLabel="Filter by status"
            options={[
              { value: "all", label: "All statuses" },
              { value: "operational", label: "Operational" },
              { value: "congested", label: "Congested" },
              { value: "maintenance", label: "Maintenance" },
              { value: "offline", label: "Offline" },
            ]}
          />
          <span className="ml-auto text-[11px] font-mono text-[var(--foreground-muted)]">{filtered.length} shown</span>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="border-b" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Code</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Name</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">City</th>
                <th className="px-3 py-2 text-right text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Docks</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap w-48">Occupancy</th>
                <th className="px-3 py-2 text-right text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Throughput</th>
                <th className="px-3 py-2 text-right text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Queue</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((w) => {
                const occPct = w.dockCount > 0 ? (w.docksOccupied / w.dockCount) * 100 : 0;
                const barColor = w.status === "congested" || occPct > 85 ? "var(--status-delayed)" : occPct > 70 ? "var(--status-atrisk)" : "var(--status-ontime)";
                const statusMeta = getStatusMeta(w.status);
                return (
                  <tr
                    key={w.id}
                    onClick={() => onRowClick(w)}
                    tabIndex={0}
                    onKeyDown={(e) => { if (e.key === "Enter") onRowClick(w); }}
                    className="border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring outline-none"
                    style={{ borderColor: "var(--border)" }}
                    aria-label={`${w.code} ${w.name}`}
                  >
                    <td className="px-3 py-2">
                      <span className="text-[12px] font-mono font-bold text-[var(--primary)]">{w.code}</span>
                    </td>
                    <td className="px-3 py-2">
                      <div className="text-[12px] font-semibold text-[var(--foreground)]">{w.name}</div>
                      <div className="text-[10px] text-[var(--foreground-muted)] font-mono">{w.region}</div>
                    </td>
                    <td className="px-3 py-2">
                      <span className="text-[12px] text-[var(--foreground-secondary)]">{w.city}</span>
                    </td>
                    <td className="px-3 py-2 text-right">
                      <span className="text-[12px] font-mono tabular-nums text-[var(--foreground)]">{w.docksOccupied}</span>
                      <span className="text-[10px] font-mono text-[var(--foreground-muted)]">/{w.dockCount}</span>
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 rounded-full" style={{ background: "var(--surface-hover)" }}>
                          <div className="h-full rounded-full transition-all" style={{ width: `${occPct}%`, background: barColor }} />
                        </div>
                        <span className="text-[10px] font-mono tabular-nums w-9 text-right" style={{ color: barColor }}>{occPct.toFixed(0)}%</span>
                      </div>
                    </td>
                    <td className="px-3 py-2 text-right">
                      <span className="text-[12px] font-mono tabular-nums text-[var(--foreground)]">{fmtNumber(w.throughputToday)}</span>
                    </td>
                    <td className="px-3 py-2 text-right">
                      <span className={cn("text-[12px] font-mono tabular-nums", w.queueLength > 4 ? "text-[var(--status-delayed)] font-semibold" : "text-[var(--foreground-secondary)]")}>{w.queueLength}</span>
                    </td>
                    <td className="px-3 py-2">
                      <span className={cn("inline-flex items-center gap-1 rounded font-semibold uppercase tracking-wide text-[10px] px-2 py-0.5", statusMeta.pulse)} style={{ background: statusMeta.soft, color: statusMeta.color }}>
                        <span className="w-1 h-1 rounded-full" style={{ background: statusMeta.color }} />
                        {statusMeta.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-3 py-8 text-center text-[12px] text-[var(--foreground-muted)]">No warehouses match your filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function getStatusMeta(status: Warehouse["status"]): { label: string; color: string; soft: string; pulse?: string } {
  switch (status) {
    case "operational": return { label: "Operational", color: "var(--status-ontime)", soft: "var(--status-ontime-soft)" };
    case "congested": return { label: "Congested", color: "var(--status-delayed)", soft: "var(--status-delayed-soft)", pulse: "pulse-delayed" };
    case "maintenance": return { label: "Maintenance", color: "var(--status-maintenance)", soft: "var(--status-maintenance-soft)" };
    case "offline": return { label: "Offline", color: "var(--status-offline)", soft: "var(--status-offline-soft)" };
  }
}
