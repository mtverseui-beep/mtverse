"use client";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { VehicleStatus } from "@/lib/fleet/types";

export function KPI({ icon: Icon, label, value, sub, status, onClick }: {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  label: string; value: string; sub: string;
  status?: VehicleStatus;
  onClick?: () => void;
}) {
  const color = status === "delayed" ? "var(--status-delayed)"
    : status === "at-risk" ? "var(--status-atrisk)"
    : status === "on-time" ? "var(--status-ontime)"
    : "var(--foreground)";
  return (
    <motion.button
      type="button"
      whileHover={{ y: -1 }}
      onClick={onClick}
      className="rounded-[8px] border p-3 text-left cursor-pointer focus-ring transition-colors hover:border-[var(--border-strong)]"
      style={{ background: "var(--surface)", borderColor: "var(--border)" }}
    >
      <div className="flex items-center justify-between mb-1">
        <span className="text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)]">{label}</span>
        <Icon size={13} className="text-[var(--foreground-muted)]" />
      </div>
      <p className="text-xl font-mono font-bold leading-tight" style={{ color }}>{value}</p>
      <p className="text-[10px] text-[var(--foreground-muted)] mt-0.5">{sub}</p>
    </motion.button>
  );
}

export function StatusBadge({ status, label, size = "md" }: {
  status: VehicleStatus;
  label?: string;
  size?: "sm" | "md";
}) {
  const colors: Record<VehicleStatus, string> = {
    "on-time": "var(--status-ontime)",
    "at-risk": "var(--status-atrisk)",
    "delayed": "var(--status-delayed)",
    "offline": "var(--status-offline)",
    "maintenance": "var(--status-maintenance)",
  };
  const softColors: Record<VehicleStatus, string> = {
    "on-time": "var(--status-ontime-soft)",
    "at-risk": "var(--status-atrisk-soft)",
    "delayed": "var(--status-delayed-soft)",
    "offline": "var(--status-offline-soft)",
    "maintenance": "var(--status-maintenance-soft)",
  };
  const labels: Record<VehicleStatus, string> = {
    "on-time": "On Time", "at-risk": "At Risk", "delayed": "Delayed",
    "offline": "Offline", "maintenance": "Maintenance",
  };
  const pulse = status === "delayed" ? "pulse-delayed" : status === "at-risk" ? "pulse-atrisk" : "";
  return (
    <span className={cn("inline-flex items-center gap-1 rounded font-semibold uppercase tracking-wide", pulse, size === "sm" ? "text-[9px] px-1.5 py-0.5" : "text-[10px] px-2 py-0.5")} style={{ background: softColors[status], color: colors[status] }}>
      <span className="w-1 h-1 rounded-full" style={{ background: colors[status] }} />
      {label ?? labels[status]}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: "low" | "medium" | "high" | "critical" }) {
  const colors = {
    critical: { bg: "var(--status-delayed-soft)", color: "var(--status-delayed)" },
    high: { bg: "var(--status-atrisk-soft)", color: "var(--status-atrisk)" },
    medium: { bg: "var(--primary-soft)", color: "var(--primary)" },
    low: { bg: "var(--surface-hover)", color: "var(--foreground-muted)" },
  };
  const s = colors[priority];
  return (
    <span className={cn("inline-flex items-center justify-center rounded font-mono font-bold uppercase", priority === "critical" && "pulse-delayed")} style={{ background: s.bg, color: s.color, fontSize: 9, padding: "2px 5px", minWidth: 18 }}>{priority.charAt(0).toUpperCase()}</span>
  );
}

export function Card({ title, icon: Icon, action, children, className }: {
  title: string;
  icon?: React.ComponentType<{ size?: number; className?: string }>;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-[8px] border overflow-hidden", className)} style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
      <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
        <div className="flex items-center gap-2">
          {Icon && <Icon size={15} className="text-[var(--primary)]" />}
          <h3 className="text-[13px] font-semibold text-[var(--foreground)]">{title}</h3>
        </div>
        {action}
      </header>
      <div className="p-4">{children}</div>
    </section>
  );
}
