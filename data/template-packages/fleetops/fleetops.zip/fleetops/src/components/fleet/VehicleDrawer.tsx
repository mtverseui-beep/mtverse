"use client";
import { motion, AnimatePresence } from "framer-motion";
import { X, Truck, User, Route as RouteIcon, Fuel, Wrench, FileText, Package, Phone, MessageSquare, MapPin, AlertTriangle, Download, Activity } from "lucide-react";
import { useFleetStore } from "@/store/fleet-store";
import { StatusBadge } from "./ui";
import { Avatar } from "./Avatar";
import { fmtETA, fmtRelative, fmtNumber } from "@/lib/fleet/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface VehicleDrawerProps {
  vehicleId: string;
  embedded?: boolean;
}

export function VehicleDrawer({ vehicleId, embedded }: VehicleDrawerProps) {
  const vehicles = useFleetStore((s) => s.vehicles);
  const drivers = useFleetStore((s) => s.drivers);
  const routes = useFleetStore((s) => s.routes);
  const maintenance = useFleetStore((s) => s.maintenance);
  const fuelEvents = useFleetStore((s) => s.fuelEvents);
  const selectVehicle = useFleetStore((s) => s.selectVehicle);

  const v = vehicles.find(x => x.id === vehicleId);
  if (!v) return null;
  const driver = drivers.find(d => d.id === v.driverId);
  const route = routes.find(r => r.id === v.currentRouteId);
  const vehMaintenance = maintenance.filter(m => m.vehicleId === v.id).slice(0, 3);
  const vehFuel = fuelEvents.filter(f => f.vehicleId === v.id).slice(0, 3);

  const content = (
    <div className={cn(embedded ? "" : "flex flex-col h-full")}>
      {/* Header */}
      <div className="px-4 py-3 border-b" style={{ borderColor: "var(--border)" }}>
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-[6px] flex items-center justify-center" style={{ background: "var(--primary-soft)" }}><Truck size={18} style={{ color: "var(--primary)" }} /></div>
            <div>
              <h2 className="text-[15px] font-bold text-[var(--foreground)]">{v.unit}</h2>
              <div className="flex items-center gap-1.5 mt-0.5"><StatusBadge status={v.status} size="sm" /><span className="text-[10px] font-mono text-[var(--foreground-muted)]">{v.region}</span></div>
            </div>
          </div>
          {!embedded && <button type="button" onClick={() => selectVehicle(null)} className="w-7 h-7 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" aria-label="Close"><X size={16} /></button>}
        </div>
        {/* Quick actions */}
        <div className="grid grid-cols-3 gap-1.5 mt-3">
          <ActionBtn icon={MapPin} label="Dispatch" onClick={() => toast.success("Dispatch started", { description: v.unit })} />
          <ActionBtn icon={MessageSquare} label="Message" onClick={() => toast.success("Message sent", { description: `Message to ${v.unit} driver` })} />
          <ActionBtn icon={Phone} label="Call" onClick={() => toast.success(`Calling ${driver?.name ?? "driver"}`, { description: driver?.phone })} />
          <ActionBtn icon={Wrench} label="Maintain" onClick={() => toast.success("Maintenance flagged", { description: v.unit })} />
          <ActionBtn icon={AlertTriangle} label="Incident" onClick={() => toast.success("Incident created", { description: v.unit })} danger />
          <ActionBtn icon={Download} label="Manifest" onClick={() => toast.success("Route manifest downloaded", { description: v.unit })} />
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Overview */}
        <Section title="Vehicle Overview" icon={Truck}>
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <Field label="Unit" value={v.unit} />
            <Field label="Trailer" value={v.trailerId ?? "—"} />
            <Field label="Odometer" value={`${fmtNumber(v.odometer)} mi`} />
            <Field label="Engine Temp" value={`${v.engineTemp}°F`} />
            <Field label="Load Type" value={v.loadType} />
            <Field label="Load Weight" value={`${fmtNumber(v.loadWeightLbs)} lbs`} />
            <Field label="Tire Pressure" value={v.tirePressureStatus.toUpperCase()} status={v.tirePressureStatus === "critical" ? "delayed" : v.tirePressureStatus === "low" ? "at-risk" : "on-time"} />
            <Field label="Last Check-In" value={fmtRelative(v.lastCheckIn)} />
          </div>
        </Section>

        {/* Driver */}
        {driver && (
          <Section title="Driver" icon={User}>
            <div className="flex items-center gap-2.5 mb-2">
              <Avatar seed={driver.avatarSeed} name={driver.name} size={32} />
              <div className="flex-1 min-w-0">
                <p className="text-[12px] font-semibold text-[var(--foreground)]">{driver.name}</p>
                <p className="text-[10px] text-[var(--foreground-muted)]">{driver.phone}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <Field label="CDL Class" value={`Class ${driver.cdlClass}`} />
              <Field label="Hours Left" value={`${driver.hoursRemaining.toFixed(1)}h`} />
              <Field label="Safety Score" value={String(driver.safetyScore)} status={driver.safetyScore >= 90 ? "on-time" : driver.safetyScore >= 80 ? "at-risk" : "delayed"} />
              <Field label="On-Time %" value={`${driver.onTimePct}%`} />
            </div>
          </Section>
        )}

        {/* Current Route */}
        {route && (
          <Section title="Current Route" icon={RouteIcon}>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[12px] font-mono font-semibold text-[var(--foreground)]">{route.originCity}</span>
              <RouteIcon size={12} className="text-[var(--foreground-muted)]" />
              <span className="text-[12px] font-mono font-semibold text-[var(--foreground)]">{route.destCity}</span>
              <span className="text-[10px] font-mono text-[var(--foreground-muted)] ml-auto">{route.distanceMiles} mi</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <Field label="ETA" value={fmtETA(route.eta)} status={v.status} />
              <Field label="Stops" value={String(route.stops)} />
              <Field label="Load ID" value={route.loadId} />
              <Field label="Priority" value={route.priority.toUpperCase()} />
              {route.delayReason && <Field label="Delay Reason" value={route.delayReason} status="delayed" />}
            </div>
          </Section>
        )}

        {/* Telemetry */}
        <Section title="Telemetry" icon={Activity}>
          <div className="grid grid-cols-3 gap-2 text-center">
            <Metric label="Speed" value={`${v.speed}`} unit="mph" />
            <Metric label="Fuel" value={`${v.fuelPct}`} unit="%" status={v.fuelPct < 25 ? "delayed" : v.fuelPct < 50 ? "at-risk" : "on-time"} />
            <Metric label="Engine" value={`${v.engineTemp}`} unit="°F" />
          </div>
        </Section>

        {/* Fuel History */}
        {vehFuel.length > 0 && (
          <Section title="Fuel History" icon={Fuel}>
            <div className="space-y-1">
              {vehFuel.map(f => (
                <div key={f.id} className="flex items-center justify-between text-[11px] py-1">
                  <span className="text-[var(--foreground-secondary)]">{f.location}</span>
                  <span className="font-mono text-[var(--foreground-muted)]">{f.gallons.toFixed(1)} gal · ${f.cost.toFixed(2)}</span>
                  <span className="font-mono text-[var(--foreground-muted)]">{fmtRelative(f.timestamp)}</span>
                </div>
              ))}
            </div>
          </Section>
        )}

        {/* Maintenance */}
        {vehMaintenance.length > 0 && (
          <Section title="Maintenance" icon={Wrench}>
            <div className="space-y-1">
              {vehMaintenance.map(m => (
                <div key={m.id} className="flex items-center justify-between text-[11px] py-1">
                  <span className="text-[var(--foreground-secondary)] truncate flex-1">{m.description}</span>
                  <span className={cn("text-[10px] px-1.5 py-0.5 rounded font-semibold uppercase ml-2", m.status === "overdue" && "pulse-delayed")} style={{ background: m.status === "overdue" ? "var(--status-delayed-soft)" : m.status === "completed" ? "var(--status-ontime-soft)" : "var(--surface-hover)", color: m.status === "overdue" ? "var(--status-delayed)" : m.status === "completed" ? "var(--status-ontime)" : "var(--foreground-muted)" }}>{m.status}</span>
                </div>
              ))}
            </div>
          </Section>
        )}
      </div>
    </div>
  );

  if (embedded) return content;

  return (
    <AnimatePresence>
      <motion.aside initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ duration: 0.22, ease: "easeOut" }} className="fixed right-0 top-0 bottom-0 z-50 w-full sm:w-[420px] bg-[var(--surface)] border-l" style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-xl)" }} role="complementary" aria-label={`Vehicle details for ${v.unit}`}>
        {content}
      </motion.aside>
    </AnimatePresence>
  );
}

function ActionBtn({ icon: Icon, label, onClick, danger }: { icon: React.ComponentType<{ size?: number }>; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button type="button" onClick={onClick} className={cn("flex flex-col items-center gap-1 py-1.5 rounded-[4px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring", danger && "hover:bg-[var(--status-delayed-soft)] hover:text-[var(--status-delayed)]")} style={{ borderColor: "var(--border)", color: danger ? "var(--status-delayed)" : "var(--foreground-secondary)" }}>
      <Icon size={14} />
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: React.ComponentType<{ size?: number }>; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] mb-2"><Icon size={12} /> {title}</h3>
      {children}
    </section>
  );
}

function Field({ label, value, status }: { label: string; value: string; status?: string }) {
  const color = status === "delayed" ? "var(--status-delayed)" : status === "at-risk" ? "var(--status-atrisk)" : status === "on-time" ? "var(--status-ontime)" : "var(--foreground)";
  return (
    <div>
      <span className="text-[9px] text-[var(--foreground-muted)] uppercase tracking-wide">{label}</span>
      <p className="text-[12px] font-medium font-mono mt-0.5" style={{ color }}>{value}</p>
    </div>
  );
}

function Metric({ label, value, unit, status }: { label: string; value: string; unit: string; status?: string }) {
  const color = status === "delayed" ? "var(--status-delayed)" : status === "at-risk" ? "var(--status-atrisk)" : status === "on-time" ? "var(--status-ontime)" : "var(--foreground)";
  return (
    <div className="rounded-[4px] border p-2" style={{ borderColor: "var(--border)" }}>
      <div className="text-[9px] text-[var(--foreground-muted)] uppercase">{label}</div>
      <div className="flex items-baseline justify-center gap-0.5 mt-0.5"><span className="text-[16px] font-mono font-bold" style={{ color }}>{value}</span><span className="text-[9px] text-[var(--foreground-muted)]">{unit}</span></div>
    </div>
  );
}
