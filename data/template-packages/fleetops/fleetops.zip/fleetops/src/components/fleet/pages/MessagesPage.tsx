"use client";
import { useState, useRef, useEffect, useMemo } from "react";
import { useFleetStore } from "@/store/fleet-store";
import { Avatar } from "../Avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { NOW, fmtRelative } from "@/lib/fleet/format";
import {
  MessageSquare, Send, Search, Phone, Video, MoreVertical,
  Paperclip, Zap, MapPin, Clock, CheckCheck,
} from "lucide-react";
import type { Message } from "@/lib/fleet/types";

const TEMPLATES = [
  { label: "Status check", text: "What's your current status and ETA?" },
  { label: "Reroute", text: "Please reroute to the next stop, current route is congested." },
  { label: "Break reminder", text: "Reminder: you have 1.5 hours of service remaining." },
  { label: "Dock clear", text: "Your dock is clear, proceed to bay when ready." },
  { label: "Incident", text: "Please report any incidents immediately to dispatch." },
];

export function MessagesPage() {
  const conversations = useFleetStore((s) => s.conversations);
  const messages = useFleetStore((s) => s.messages);
  const [activeId, setActiveId] = useState<string>(conversations[0]?.id ?? "c1");
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [localMsgs, setLocalMsgs] = useState<Message[]>([]);
  const [showTyping, setShowTyping] = useState(false);
  const threadRef = useRef<HTMLDivElement | null>(null);

  const activeConversation = conversations.find((c) => c.id === activeId) ?? conversations[0];
  const thread = useMemo(() => {
    const base = messages.filter((m) => m.conversationId === activeId);
    return [...base, ...localMsgs.filter((m) => m.conversationId === activeId)].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
  }, [messages, localMsgs, activeId]);

  useEffect(() => {
    if (threadRef.current) threadRef.current.scrollTop = threadRef.current.scrollHeight;
  }, [thread.length, activeId, showTyping]);

  const filteredConvos = useMemo(() => {
    return conversations.filter((c) =>
      !query ||
      c.participantName.toLowerCase().includes(query.toLowerCase()) ||
      c.participantRole.toLowerCase().includes(query.toLowerCase()) ||
      c.lastMessage.toLowerCase().includes(query.toLowerCase())
    );
  }, [conversations, query]);

  const handleSend = () => {
    const text = draft.trim();
    if (!text || !activeConversation) return;
    setSending(true);
    const newMsg: Message = {
      id: `local-${Date.now()}`,
      conversationId: activeConversation.id,
      sender: "dispatch",
      senderName: "Dispatch (You)",
      text,
      timestamp: new Date(NOW).toISOString(),
      read: true,
    };
    setTimeout(() => {
      setLocalMsgs((prev) => [...prev, newMsg]);
      setDraft("");
      setSending(false);
      toast.success("Message sent", { description: `To ${activeConversation.participantName}` });
      // Simulate typing + reply
      setShowTyping(true);
      setTimeout(() => {
        setShowTyping(false);
        const reply: Message = {
          id: `reply-${Date.now()}`,
          conversationId: activeConversation.id,
          sender: activeConversation.type === "dispatch-driver" ? "driver" : activeConversation.type === "dispatch-warehouse" ? "warehouse" : "manager",
          senderName: activeConversation.participantName,
          text: "Copy that dispatch, will update shortly.",
          timestamp: new Date(NOW).toISOString(),
          read: true,
        };
        setLocalMsgs((prev) => [...prev, reply]);
      }, 1800);
    }, 350);
  };

  const handleTemplate = (t: { label: string; text: string }) => {
    setDraft(t.text);
    toast.info(`Template loaded: ${t.label}`);
  };

  if (!activeConversation) {
    return (
      <div className="p-5">
        <div className="rounded-[8px] border p-12 text-center" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <MessageSquare size={32} className="mx-auto text-[var(--foreground-muted)] mb-3" />
          <p className="text-[13px] text-[var(--foreground-secondary)]">No conversations available</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-5">
      <div className="mb-3">
        <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight flex items-center gap-2">
          <MessageSquare size={20} style={{ color: "var(--primary)" }} />
          Messages
        </h1>
        <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">
          {conversations.length} conversations · {conversations.reduce((a, c) => a + c.unreadCount, 0)} unread
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4 h-[calc(100vh-220px)] min-h-[500px]">
        {/* Conversation list */}
        <div className="rounded-[8px] border overflow-hidden flex flex-col" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <div className="px-3 py-2 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search conversations…"
                className="w-full h-8 pl-8 pr-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none placeholder:text-[var(--foreground-muted)] text-[var(--foreground)]"
                style={{ borderColor: "var(--border)" }}
                aria-label="Search conversations"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {filteredConvos.map((c) => {
              const active = c.id === activeId;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => { setActiveId(c.id); setLocalMsgs((prev) => prev.filter((m) => m.conversationId !== c.id)); }}
                  className={cn(
                    "w-full text-left px-3 py-2.5 border-b last:border-0 transition-colors cursor-pointer focus-ring outline-none",
                    active ? "bg-[var(--primary-soft)]" : "hover:bg-[var(--surface-hover)]"
                  )}
                  style={{ borderColor: "var(--border)" }}
                  aria-pressed={active}
                >
                  <div className="flex items-start gap-2.5">
                    <Avatar seed={c.avatarSeed} name={c.participantName} size={36} ring={active} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className={cn("text-[12px] truncate", active ? "font-semibold text-[var(--foreground)]" : "font-medium text-[var(--foreground-secondary)]")}>{c.participantName}</span>
                        <span className="text-[9px] font-mono text-[var(--foreground-muted)] shrink-0">{fmtRelative(c.lastTimestamp)}</span>
                      </div>
                      <div className="text-[10px] text-[var(--foreground-muted)] uppercase tracking-wide">{c.participantRole}</div>
                      <div className="flex items-center justify-between gap-2 mt-0.5">
                        <p className={cn("text-[11px] truncate", c.unreadCount > 0 ? "text-[var(--foreground)] font-medium" : "text-[var(--foreground-muted)]")}>
                          {c.typing ? <span className="text-[var(--primary)] italic">typing…</span> : c.lastMessage}
                        </p>
                        {c.unreadCount > 0 && (
                          <span className="text-[9px] font-mono font-bold px-1.5 py-px rounded-[3px] shrink-0" style={{ background: "var(--primary)", color: "var(--background)" }}>
                            {c.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
            {filteredConvos.length === 0 && (
              <div className="px-4 py-8 text-center text-[12px] text-[var(--foreground-muted)]">No conversations match your search.</div>
            )}
          </div>
        </div>

        {/* Thread */}
        <div className="rounded-[8px] border overflow-hidden flex flex-col" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          {/* Thread header */}
          <header className="flex items-center gap-3 px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <Avatar seed={activeConversation.avatarSeed} name={activeConversation.participantName} size={32} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[13px] font-semibold text-[var(--foreground)] truncate">{activeConversation.participantName}</span>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-ontime)" }} title="Online" />
              </div>
              <span className="text-[10px] text-[var(--foreground-muted)] uppercase tracking-wide">{activeConversation.participantRole}</span>
            </div>
            <div className="flex items-center gap-1">
              <button type="button" onClick={() => toast.success("Call initiated", { description: activeConversation.participantName })} className="w-8 h-8 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" aria-label="Call"><Phone size={14} /></button>
              <button type="button" onClick={() => toast.success("Video call started", { description: activeConversation.participantName })} className="w-8 h-8 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" aria-label="Video call"><Video size={14} /></button>
              <button type="button" onClick={() => toast.info("Conversation actions")} className="w-8 h-8 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" aria-label="More actions"><MoreVertical size={14} /></button>
            </div>
          </header>

          {/* Thread body */}
          <div ref={threadRef} className="flex-1 overflow-y-auto p-4 space-y-3" style={{ background: "var(--background)" }}>
            {thread.length === 0 && (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare size={32} className="mx-auto text-[var(--foreground-muted)] opacity-40 mb-2" />
                  <p className="text-[12px] text-[var(--foreground-muted)]">No messages yet. Start the conversation.</p>
                </div>
              </div>
            )}
            {thread.map((m) => {
              const isMe = m.sender === "dispatch";
              return (
                <div key={m.id} className={cn("flex flex-col", isMe ? "items-end" : "items-start")}>
                  <div className={cn("max-w-[75%] rounded-[8px] px-3 py-2", isMe ? "rounded-br-[2px]" : "rounded-bl-[2px]")}
                    style={isMe ? { background: "var(--primary)", color: "var(--background)" } : { background: "var(--surface-elevated)", color: "var(--foreground)", border: "1px solid var(--border)" }}>
                    {!isMe && <div className="text-[10px] font-semibold mb-0.5" style={{ color: "var(--primary)" }}>{m.senderName}</div>}
                    <p className="text-[12px] leading-relaxed whitespace-pre-wrap break-words">{m.text}</p>
                    <div className={cn("flex items-center gap-1 mt-0.5 text-[9px] font-mono", isMe ? "text-[var(--background)] opacity-70 justify-end" : "text-[var(--foreground-muted)]")}>
                      <span>{new Date(m.timestamp).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })}</span>
                      {isMe && <CheckCheck size={10} />}
                    </div>
                  </div>
                </div>
              );
            })}
            {showTyping && (
              <div className="flex items-start">
                <div className="rounded-[8px] rounded-bl-[2px] px-3 py-2.5" style={{ background: "var(--surface-elevated)", border: "1px solid var(--border)" }}>
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: "var(--foreground-muted)", animationDelay: "0ms" }} />
                    <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: "var(--foreground-muted)", animationDelay: "150ms" }} />
                    <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: "var(--foreground-muted)", animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Templates */}
          <div className="px-3 py-1.5 border-t flex items-center gap-1.5 overflow-x-auto" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
            <Zap size={11} className="text-[var(--primary)] shrink-0" />
            <span className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)] shrink-0">Templates:</span>
            {TEMPLATES.map((t) => (
              <button
                key={t.label}
                type="button"
                onClick={() => handleTemplate(t)}
                className="shrink-0 text-[10px] font-medium px-2 py-0.5 rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]"
                style={{ borderColor: "var(--border)" }}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Composer */}
          <div className="px-3 py-2.5 border-t" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-end gap-2">
              <button type="button" onClick={() => toast.info("Attach file")} className="w-8 h-8 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring shrink-0" aria-label="Attach file"><Paperclip size={14} /></button>
              <button type="button" onClick={() => toast.info("Share location")} className="w-8 h-8 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring shrink-0" aria-label="Share location"><MapPin size={14} /></button>
              <div className="flex-1 relative">
                <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                  placeholder="Type a message… (Enter to send, Shift+Enter for newline)"
                  rows={1}
                  className="w-full min-h-[36px] max-h-24 px-3 py-2 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none placeholder:text-[var(--foreground-muted)] text-[var(--foreground)] resize-none"
                  style={{ borderColor: "var(--border)" }}
                  aria-label="Message input"
                />
              </div>
              <button
                type="button"
                onClick={handleSend}
                disabled={!draft.trim() || sending}
                className="h-9 px-3.5 text-[12px] font-semibold rounded-[6px] text-[var(--background)] cursor-pointer focus-ring flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                style={{ background: "var(--primary)" }}
                aria-label="Send message"
              >
                <Send size={13} /> {sending ? "…" : "Send"}
              </button>
            </div>
            <div className="flex items-center justify-between mt-1.5">
              <span className="text-[9px] font-mono text-[var(--foreground-muted)] flex items-center gap-1">
                <Clock size={9} /> Encryption: end-to-end
              </span>
              <span className="text-[9px] font-mono text-[var(--foreground-muted)]">{draft.length} chars</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
