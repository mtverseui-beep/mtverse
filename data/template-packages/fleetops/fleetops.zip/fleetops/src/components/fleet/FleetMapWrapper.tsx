"use client";
import dynamic from "next/dynamic";

const FleetMapLazy = dynamic(() => import("./FleetMap").then(m => ({ default: m.FleetMap })), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center" style={{ height: "100%", background: "var(--background)" }}>
      <div className="flex flex-col items-center gap-2">
        <div className="w-6 h-6 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor: "var(--primary)", borderTopColor: "transparent" }} />
        <span className="text-[11px] font-mono text-[var(--foreground-muted)]">Loading map…</span>
      </div>
    </div>
  ),
});

import type { Vehicle } from "@/lib/fleet/types";

interface FleetMapWrapperProps {
  vehicles: Vehicle[];
  selectedId?: string | null;
  onSelect?: (id: string) => void;
}

export function FleetMapWrapper(props: FleetMapWrapperProps) {
  return <FleetMapLazy {...props} />;
}
