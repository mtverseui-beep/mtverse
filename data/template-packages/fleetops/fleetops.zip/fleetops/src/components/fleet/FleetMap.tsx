"use client";
import { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, CircleMarker } from "react-leaflet";
import L from "leaflet";
import type { Vehicle } from "@/lib/fleet/types";
import { cn } from "@/lib/utils";

// Fix default icon issue with leaflet in webpack
delete (L.Icon.Default.prototype as unknown as { _getIconUrl?: unknown })._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const STATUS_COLORS: Record<string, string> = {
  "on-time": "#22C55E",
  "at-risk": "#FBBF24",
  "delayed": "#EF4444",
  "offline": "#6B7280",
  "maintenance": "#64748B",
};

interface FleetMapProps {
  vehicles: Vehicle[];
  selectedId?: string | null;
  onSelect?: (id: string) => void;
}

export function FleetMap({ vehicles, selectedId, onSelect }: FleetMapProps) {
  const active = vehicles.filter(v => v.status !== "offline" && v.status !== "maintenance");

  // Fix map rendering after mount
  useEffect(() => {
    setTimeout(() => {
      window.dispatchEvent(new Event("resize"));
    }, 100);
  }, []);

  return (
    <div style={{ height: "100%", width: "100%" }}>
      <MapContainer
        center={[39.5, -98.0]}
        zoom={4}
        style={{ height: "100%", width: "100%" }}
        scrollWheelZoom={true}
        attributionControl={true}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; OpenStreetMap contributors'
        />
        {active.map((v) => {
          const color = STATUS_COLORS[v.status] || "#6B7280";
          const isSelected = selectedId === v.id;
          const radius = isSelected ? 10 : 7;
          return (
            <CircleMarker
              key={v.id}
              center={[v.lat, v.lng]}
              radius={radius}
              pathOptions={{
                color: color,
                fillColor: color,
                fillOpacity: 0.8,
                weight: 2,
              }}
              eventHandlers={{ click: () => onSelect?.(v.id) }}
            >
              <Popup>
                <div style={{ fontFamily: "var(--font-sans)", minWidth: 120 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 4 }}>{v.unit}</div>
                  <div style={{ fontSize: 11, color: "#666" }}>Status: {v.status}</div>
                  <div style={{ fontSize: 11, color: "#666" }}>Speed: {v.speed} mph</div>
                  <div style={{ fontSize: 11, color: "#666" }}>Fuel: {v.fuelPct}%</div>
                  <div style={{ fontSize: 11, color: "#666" }}>Region: {v.region}</div>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}
      </MapContainer>
    </div>
  );
}
