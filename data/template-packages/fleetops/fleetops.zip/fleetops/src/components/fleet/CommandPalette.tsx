"use client";
import { useState } from "react";
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "@/components/ui/command";
import { useFleetStore } from "@/store/fleet-store";
import { Search, Truck, Users, MapPin, AlertTriangle, Wrench, Download, Settings, LifeBuoy, Bell, Activity } from "lucide-react";
import type { Route } from "@/hooks/use-hash-route";

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  navigate: (path: string) => void;
}

export function CommandPalette({ open, onOpenChange, navigate }: CommandPaletteProps) {
  const vehicles = useFleetStore((s) => s.vehicles);
  const drivers = useFleetStore((s) => s.drivers);
  const selectVehicle = useFleetStore((s) => s.selectVehicle);

  const go = (path: string) => { navigate(path); onOpenChange(false); };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="Search vehicles, drivers, routes, or type an action…" />
      <CommandList style={{ background: "var(--surface-floating)", color: "var(--foreground)" }}>
        <CommandEmpty className="text-[12px] text-[var(--foreground-muted)] py-6 text-center">No results found.</CommandEmpty>
        <CommandGroup heading="Quick Actions" className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">
          <CommandItem onSelect={() => go("dispatch")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><Truck size={14} /> Dispatch vehicle</CommandItem>
          <CommandItem onSelect={() => go("route-planner")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><MapPin size={14} /> Create route</CommandItem>
          <CommandItem onSelect={() => go("deliveries")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><Activity size={14} /> Create delivery</CommandItem>
          <CommandItem onSelect={() => go("fleet")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><Truck size={14} /> Open fleet</CommandItem>
          <CommandItem onSelect={() => go("drivers")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><Users size={14} /> Open drivers</CommandItem>
          <CommandItem onSelect={() => go("warehouses")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><MapPin size={14} /> Open warehouses</CommandItem>
          <CommandItem onSelect={() => go("notifications")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><Bell size={14} /> View alerts</CommandItem>
          <CommandItem onSelect={() => go("analytics")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><Wrench size={14} /> Start maintenance</CommandItem>
          <CommandItem onSelect={() => go("analytics")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><Download size={14} /> Export report</CommandItem>
          <CommandItem onSelect={() => go("help")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><LifeBuoy size={14} /> Go to help</CommandItem>
          <CommandItem onSelect={() => go("settings")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2"><Settings size={14} /> Open settings</CommandItem>
        </CommandGroup>
        <CommandSeparator style={{ background: "var(--border)" }} />
        <CommandGroup heading="Vehicles" className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">
          {vehicles.slice(0, 8).map(v => (
            <CommandItem key={v.id} value={`vehicle ${v.unit} ${v.region}`} onSelect={() => { selectVehicle(v.id); go("fleet"); }} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2">
              <Truck size={14} /> {v.unit} <span className="text-[var(--foreground-muted)]">· {v.region} · {v.status}</span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator style={{ background: "var(--border)" }} />
        <CommandGroup heading="Drivers" className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">
          {drivers.slice(0, 6).map(d => (
            <CommandItem key={d.id} value={`driver ${d.name}`} onSelect={() => go("drivers")} className="aria-selected:bg-[var(--surface-hover)] text-[var(--foreground)] text-[12px] gap-2">
              <Users size={14} /> {d.name} <span className="text-[var(--foreground-muted)]">· {d.homeBase} · {d.status}</span>
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
