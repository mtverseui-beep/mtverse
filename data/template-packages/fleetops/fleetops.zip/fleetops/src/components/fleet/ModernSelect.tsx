"use client";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface ModernSelectProps {
  value: string;
  onValueChange: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
  className?: string;
  size?: "sm" | "md";
  ariaLabel?: string;
}

export function ModernSelect({
  value, onValueChange, options, placeholder, className, size = "md", ariaLabel,
}: ModernSelectProps) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger
        aria-label={ariaLabel}
        size={size === "sm" ? "sm" : "default"}
        className={cn(
          "border focus-ring outline-none transition-colors hover:border-[var(--border-strong)] cursor-pointer font-sans",
          size === "sm" ? "h-8 px-2.5 text-[12px] rounded-[6px]" : "h-9 px-3 text-[12px] rounded-[6px]",
          className,
        )}
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--foreground)" }}
      >
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent
        position="popper"
        sideOffset={6}
        className="font-sans min-w-[var(--radix-select-trigger-width)]"
        style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "6px", boxShadow: "var(--shadow-lg)", overflow: "hidden" }}
      >
        {options.map((opt) => (
          <SelectItem
            key={opt.value}
            value={opt.value}
            disabled={opt.disabled}
            className="cursor-pointer focus:bg-[var(--surface-hover)] focus:text-[var(--foreground)] rounded-[4px] mx-1 text-[12px] gap-2 data-[state=checked]:text-[var(--primary)] data-[state=checked]:bg-[var(--primary-soft)]"
          >
            {opt.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
