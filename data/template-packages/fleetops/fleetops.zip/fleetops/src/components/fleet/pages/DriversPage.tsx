"use client";
import { useEffect, useMemo, useState } from "react";
import { flexRender, getCoreRowModel, getSortedRowModel, getPaginationRowModel, useReactTable, type ColumnDef, type SortingState } from "@tanstack/react-table";
import { Search, ChevronUp, ChevronDown, ChevronsUpDown, ChevronLeft, ChevronRight, Download, Trophy } from "lucide-react";
import { useFleetStore } from "@/store/fleet-store";
import { Avatar } from "../Avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Driver } from "@/lib/fleet/types";

export function DriversPage() {
  const drivers = useFleetStore((s) => s.drivers);
  const [sorting, setSorting] = useState<SortingState>([{ id: "onTimePct", desc: true }]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [pageSize, setPageSize] = useState(20);

  const columns = useMemo<ColumnDef<Driver>[]>(() => [
    { id: "rank", header: "#", size: 40, cell: ({ row }) => <span className="text-[11px] font-mono text-[var(--foreground-muted)]">{row.index + 1}</span>, enableSorting: false },
    { accessorKey: "name", header: "Driver", size: 160, cell: ({ row }) => <div className="flex items-center gap-2"><Avatar seed={row.original.avatarSeed} name={row.original.name} size={28} /><div><span className="text-[12px] font-semibold text-[var(--foreground)]">{row.original.name}</span><div className="text-[10px] text-[var(--foreground-muted)]">{row.original.homeBase}</div></div></div> },
    { id: "status", accessorFn: d => d.status, header: "Status", size: 90, cell: ({ row }) => { const s = row.original.status; const color = s === "on-duty" ? "var(--status-ontime)" : s === "off-duty" ? "var(--status-offline)" : "var(--status-atrisk)"; return <span className="text-[10px] px-1.5 py-0.5 rounded font-semibold uppercase" style={{ background: `color-mix(in srgb, ${color} 12%, transparent)`, color }}>{s.replace("-", " ")}</span>; } },
    { accessorKey: "onTimePct", header: "On-Time %", size: 90, cell: ({ row }) => <span className="text-[12px] font-mono tabular-nums text-[var(--foreground)]">{row.original.onTimePct}%</span> },
    { accessorKey: "deliveriesCompleted", header: "Deliveries", size: 90, cell: ({ row }) => <span className="text-[12px] font-mono tabular-nums text-[var(--foreground)]">{row.original.deliveriesCompleted.toLocaleString()}</span> },
    { accessorKey: "safetyScore", header: "Safety", size: 80, cell: ({ row }) => { const s = row.original.safetyScore; const color = s >= 90 ? "var(--status-ontime)" : s >= 80 ? "var(--status-atrisk)" : "var(--status-delayed)"; return <span className="text-[12px] font-mono tabular-nums font-semibold" style={{ color }}>{s}</span>; } },
    { accessorKey: "fuelEfficiency", header: "MPG", size: 70, cell: ({ row }) => <span className="text-[12px] font-mono tabular-nums text-[var(--foreground)]">{row.original.fuelEfficiency.toFixed(1)}</span> },
    { accessorKey: "customerRating", header: "Rating", size: 70, cell: ({ row }) => <span className="text-[12px] font-mono tabular-nums text-[var(--foreground)]">{row.original.customerRating.toFixed(2)}★</span> },
    { accessorKey: "incidents", header: "Incidents", size: 80, cell: ({ row }) => <span className={cn("text-[12px] font-mono tabular-nums", row.original.incidents > 2 && "text-[var(--status-delayed)]")}>{row.original.incidents}</span> },
    { accessorKey: "hoursRemaining", header: "HOS Left", size: 80, cell: ({ row }) => { const h = row.original.hoursRemaining; const color = h < 2 ? "var(--status-delayed)" : h < 4 ? "var(--status-atrisk)" : "var(--foreground)"; return <span className="text-[12px] font-mono tabular-nums" style={{ color }}>{h.toFixed(1)}h</span>; } },
  ], []);

  const table = useReactTable({ data: drivers, columns, state: { sorting, globalFilter }, onSortingChange: setSorting, onGlobalFilterChange: setGlobalFilter, getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel(), getPaginationRowModel: getPaginationRowModel(), initialState: { pagination: { pageSize } }, globalFilterFn: (row, _c, f) => row.original.name.toLowerCase().includes(String(f).toLowerCase()) });
  useEffect(() => { table.setPageSize(pageSize); }, [pageSize, table]);

  return (
    <div className="p-5">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div><h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight flex items-center gap-2"><Trophy size={20} style={{ color: "var(--primary)" }} /> Driver Leaderboard</h1><p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">{drivers.length} drivers · Sort by any column</p></div>
        <button type="button" onClick={() => toast.success("Export started", { description: `${drivers.length} drivers exporting` })} className="h-8 px-3 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5 text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}><Download size={13} /> Export</button>
      </div>
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <div className="px-3 py-2 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="relative max-w-xs"><Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)]" /><input value={globalFilter} onChange={e => setGlobalFilter(e.target.value)} placeholder="Search drivers…" className="w-full h-8 pl-8 pr-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none text-[var(--foreground)]" style={{ borderColor: "var(--border)" }} /></div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead>{table.getHeaderGroups().map(hg => <tr key={hg.id} className="border-b" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>{hg.headers.map(h => <th key={h.id} className={cn("px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap", h.column.getCanSort() && "cursor-pointer hover:text-[var(--foreground)] select-none")} style={{ width: h.getSize() !== 150 ? h.getSize() : undefined }} onClick={h.column.getToggleSortingHandler()}><div className="flex items-center gap-1">{flexRender(h.column.columnDef.header, h.getContext())}{h.column.getCanSort() && <span className="opacity-50">{h.column.getIsSorted() === "asc" ? <ChevronUp size={11} /> : h.column.getIsSorted() === "desc" ? <ChevronDown size={11} /> : <ChevronsUpDown size={11} className="opacity-40" />}</span>}</div></th>)}</tr>)}</thead>
            <tbody>{table.getRowModel().rows.map(row => <tr key={row.id} className="border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors cursor-pointer" style={{ borderColor: "var(--border)" }}>{row.getVisibleCells().map(cell => <td key={cell.id} className="px-3 py-1.5">{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>)}</tr>)}</tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-3 py-2 border-t" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
          <span className="text-[11px] font-mono text-[var(--foreground-muted)]">{table.getFilteredRowModel().rows.length} drivers</span>
          <div className="flex items-center gap-1"><button type="button" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} className="w-7 h-7 rounded-[4px] border flex items-center justify-center disabled:opacity-40 hover:bg-[var(--surface-hover)] cursor-pointer" style={{ borderColor: "var(--border)" }}><ChevronLeft size={14} /></button><span className="text-[11px] font-mono text-[var(--foreground-muted)] px-1">{table.getState().pagination.pageIndex + 1} / {table.getPageCount() || 1}</span><button type="button" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()} className="w-7 h-7 rounded-[4px] border flex items-center justify-center disabled:opacity-40 hover:bg-[var(--surface-hover)] cursor-pointer" style={{ borderColor: "var(--border)" }}><ChevronRight size={14} /></button></div>
        </div>
      </div>
    </div>
  );
}
