"use client";
import { useState, useEffect } from "react";
import { TopBar } from "./TopBar";
import { Sidebar } from "./Sidebar";
import { VehicleDrawer } from "./VehicleDrawer";
import { DashboardPage } from "./DashboardPage";
import { FleetPage } from "./FleetPage";
import { DispatchPage } from "./pages/DispatchPage";
import { RoutesPage } from "./pages/RoutesPage";
import { DriversPage } from "./pages/DriversPage";
import { WarehousesPage } from "./pages/WarehousesPage";
import { AnalyticsPage } from "./pages/AnalyticsPage";
import { NotificationsPage } from "./pages/NotificationsPage";
import { MessagesPage } from "./pages/MessagesPage";
import { ProfilePage } from "./pages/ProfilePage";
import { SettingsPage } from "./pages/SettingsPage";
import { HelpPage } from "./pages/HelpPage";
import { SystemStatusPage } from "./pages/SystemStatusPage";
import { UserManagementPage } from "./pages/UserManagementPage";
import { CommandPalette } from "./CommandPalette";
import { useHashRoute } from "@/hooks/use-hash-route";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useFleetStore } from "@/store/fleet-store";

export function FleetApp() {
  const [route, navigate] = useHashRoute();
  const [collapsed, setCollapsed] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const selectedVehicleId = useFleetStore((s) => s.selectedVehicleId);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
    const stored = localStorage.getItem("fleetops-sidebar");
    if (stored === "collapsed") setCollapsed(true);
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setCommandOpen(o => !o); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const toggleCollapse = () => {
    const next = !collapsed;
    setCollapsed(next);
    localStorage.setItem("fleetops-sidebar", next ? "collapsed" : "expanded");
  };

  if (!mounted) {
    return <div className="h-screen flex items-center justify-center" style={{ background: "var(--background)" }}><img src="/icon.svg" alt="FleetOps" width={40} height={40} /></div>;
  }

  const top = route.segments[0] ?? "dashboard";

  return (
    <div className="h-screen flex overflow-hidden" style={{ background: "var(--background)" }}>
      <Sidebar route={route} navigate={navigate} collapsed={collapsed} onToggleCollapse={toggleCollapse} />
      <div className="flex flex-col flex-1 min-w-0">
        <TopBar route={route} onOpenCommand={() => setCommandOpen(true)} navigate={navigate} />
        <main className="flex-1 overflow-hidden relative">
          <ScrollArea className="h-full">
            {top === "dashboard" && <DashboardPage navigate={navigate} />}
            {top === "fleet" && <FleetPage />}
            {top === "tracking" && <FleetPage />}
            {top === "dispatch" && <DispatchPage />}
            {top === "deliveries" && <DispatchPage />}
            {top === "route-planner" && <RoutesPage />}
            {top === "routes" && <RoutesPage />}
            {top === "warehouses" && <WarehousesPage />}
            {top === "dock-schedule" && <WarehousesPage />}
            {top === "loading-bays" && <WarehousesPage />}
            {top === "drivers" && <DriversPage />}
            {top === "analytics" && <AnalyticsPage />}
            {top === "notifications" && <NotificationsPage />}
            {top === "messages" && <MessagesPage />}
            {top === "profile" && <ProfilePage navigate={navigate} />}
            {top === "settings" && <SettingsPage />}
            {top === "help" && <HelpPage />}
            {top === "documentation" && <HelpPage />}
            {top === "system-status" && <SystemStatusPage />}
            {top === "admin" && <UserManagementPage />}
          </ScrollArea>
          {selectedVehicleId && <VehicleDrawer vehicleId={selectedVehicleId} />}
        </main>
      </div>
      <CommandPalette open={commandOpen} onOpenChange={setCommandOpen} navigate={navigate} />
    </div>
  );
}
