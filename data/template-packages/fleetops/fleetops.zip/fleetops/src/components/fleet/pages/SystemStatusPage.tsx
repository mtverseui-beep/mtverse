"use client";
import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { NOW, fmtRelative } from "@/lib/fleet/format";
import {
  Server, Activity, CheckCircle2, AlertTriangle, XCircle,
  Globe, Cpu, Database, Radio, Building2, MessageSquare, Bell,
  BarChart3, Map as MapIcon, RefreshCw, Clock, ChevronDown,
} from "lucide-react";

type ServiceStatus = "operational" | "degraded" | "down";

interface Service {
  id: string;
  name: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  status: ServiceStatus;
  uptime24h: number;
  uptime7d: number;
  uptime30d: number;
  responseTimeMs: number;
  description: string;
}

const SERVICES: Service[] = [
  { id: "api", name: "API Gateway", icon: Globe, status: "operational", uptime24h: 99.98, uptime7d: 99.95, uptime30d: 99.92, responseTimeMs: 84, description: "REST + WebSocket entry point for all client requests" },
  { id: "dispatch", name: "Dispatch Engine", icon: Cpu, status: "operational", uptime24h: 100.0, uptime7d: 99.99, uptime30d: 99.97, responseTimeMs: 142, description: "Real-time dispatch order matching and assignment" },
  { id: "gps", name: "GPS Feed", icon: Radio, status: "degraded", uptime24h: 97.42, uptime7d: 98.81, uptime30d: 99.12, responseTimeMs: 312, description: "Vehicle position ingest from onboard telematics" },
  { id: "warehouse", name: "Warehouse Sync", icon: Building2, status: "operational", uptime24h: 99.91, uptime7d: 99.88, uptime30d: 99.74, responseTimeMs: 196, description: "WMS integration for inventory and dock scheduling" },
  { id: "messaging", name: "Messaging Service", icon: MessageSquare, status: "operational", uptime24h: 100.0, uptime7d: 99.97, uptime30d: 99.91, responseTimeMs: 68, description: "Driver/dispatch two-way messaging with delivery receipts" },
  { id: "notifications", name: "Notifications", icon: Bell, status: "operational", uptime24h: 99.95, uptime7d: 99.86, uptime30d: 99.62, responseTimeMs: 124, description: "Email, push, and SMS notification delivery pipeline" },
  { id: "analytics", name: "Analytics Engine", icon: BarChart3, status: "operational", uptime24h: 99.88, uptime7d: 99.74, uptime30d: 99.45, responseTimeMs: 412, description: "Performance metrics aggregation and report generation" },
  { id: "maps", name: "Maps & Routing", icon: MapIcon, status: "operational", uptime24h: 99.99, uptime7d: 99.96, uptime30d: 99.85, responseTimeMs: 156, description: "Map tiles, geocoding, and turn-by-turn route calculation" },
];

interface IncidentEvent {
  id: string;
  serviceId: string;
  serviceName: string;
  time: string;
  type: "investigating" | "identified" | "monitoring" | "resolved" | "degraded" | "maintenance";
  message: string;
}

const INCIDENTS: IncidentEvent[] = [
  { id: "i1", serviceId: "gps", serviceName: "GPS Feed", time: new Date(NOW - 12 * 60000).toISOString(), type: "monitoring", message: "GPS telemetry lag has stabilized at 312ms average. Engineers monitoring for recurrence." },
  { id: "i2", serviceId: "gps", serviceName: "GPS Feed", time: new Date(NOW - 38 * 60000).toISOString(), type: "identified", message: "Root cause identified: upstream telematics provider rate-limiting API calls. Working with vendor." },
  { id: "i3", serviceId: "gps", serviceName: "GPS Feed", time: new Date(NOW - 52 * 60000).toISOString(), type: "investigating", message: "Investigating increased latency in GPS position updates from Western region vehicles." },
  { id: "i4", serviceId: "analytics", serviceName: "Analytics Engine", time: new Date(NOW - 4 * 3600000).toISOString(), type: "resolved", message: "Scheduled database maintenance completed. All systems nominal." },
  { id: "i5", serviceId: "warehouse", serviceName: "Warehouse Sync", time: new Date(NOW - 18 * 3600000).toISOString(), type: "resolved", message: "Resolved: WMS sync delay caused by stale connection pool. Pool restarted." },
  { id: "i6", serviceId: "api", serviceName: "API Gateway", time: new Date(NOW - 26 * 3600000).toISOString(), type: "maintenance", message: "Scheduled TLS certificate rotation completed. No customer impact." },
  { id: "i7", serviceId: "notifications", serviceName: "Notifications", time: new Date(NOW - 2 * 86400000).toISOString(), type: "resolved", message: "SMS provider outage resolved. Backup vendor failover worked as expected." },
];

const STATUS_META: Record<ServiceStatus, { label: string; color: string; soft: string; icon: React.ComponentType<{ size?: number; className?: string; style?: React.CSSProperties }> }> = {
  operational: { label: "Operational", color: "var(--status-ontime)", soft: "var(--status-ontime-soft)", icon: CheckCircle2 },
  degraded: { label: "Degraded", color: "var(--status-atrisk)", soft: "var(--status-atrisk-soft)", icon: AlertTriangle },
  down: { label: "Down", color: "var(--status-delayed)", soft: "var(--status-delayed-soft)", icon: XCircle },
};

const INCIDENT_TYPE_META: Record<IncidentEvent["type"], { label: string; color: string }> = {
  investigating: { label: "Investigating", color: "var(--status-delayed)" },
  identified: { label: "Identified", color: "var(--status-atrisk)" },
  monitoring: { label: "Monitoring", color: "var(--primary)" },
  resolved: { label: "Resolved", color: "var(--status-ontime)" },
  degraded: { label: "Degraded", color: "var(--status-atrisk)" },
  maintenance: { label: "Maintenance", color: "var(--status-maintenance)" },
};

export function SystemStatusPage() {
  const [range, setRange] = useState<"24h" | "7d" | "30d">("24h");
  const [expanded, setExpanded] = useState<string | null>("gps");

  const overall: ServiceStatus = useMemo(() => {
    if (SERVICES.some((s) => s.status === "down")) return "down";
    if (SERVICES.some((s) => s.status === "degraded")) return "degraded";
    return "operational";
  }, []);

  const overallMeta = STATUS_META[overall];
  const OverallIcon = overallMeta.icon;

  const getUptime = (s: Service) => range === "24h" ? s.uptime24h : range === "7d" ? s.uptime7d : s.uptime30d;

  return (
    <div className="p-5 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight flex items-center gap-2">
            <Server size={20} style={{ color: "var(--primary)" }} />
            System Status
          </h1>
          <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">
            Real-time status of all FleetOps services · last updated {fmtRelative(new Date(NOW - 30000).toISOString())}
          </p>
        </div>
        <button
          type="button"
          onClick={() => toast.success("Status refreshed", { description: "All service checks re-run" })}
          className="h-8 px-3 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5 text-[var(--foreground-secondary)]"
          style={{ borderColor: "var(--border)" }}
        >
          <RefreshCw size={13} /> Refresh
        </button>
      </div>

      {/* Overall banner */}
      <div
        className="flex items-center gap-3 px-4 py-3 rounded-[8px] border"
        style={{ background: overallMeta.soft, borderColor: overallMeta.color }}
      >
        <OverallIcon size={20} style={{ color: overallMeta.color }} />
        <div className="flex-1">
          <p className="text-[14px] font-bold" style={{ color: overallMeta.color }}>
            {overall === "operational" ? "All systems operational" : overall === "degraded" ? "Some systems degraded" : "Major outage in progress"}
          </p>
          <p className="text-[11px] text-[var(--foreground-secondary)]">
            {SERVICES.filter((s) => s.status === "operational").length} of {SERVICES.length} services fully operational · {SERVICES.filter((s) => s.status !== "operational").length} experiencing issues
          </p>
        </div>
        <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-1 rounded-[4px]" style={{ background: overallMeta.color, color: "var(--background)" }}>
          {range.toUpperCase()} view
        </span>
      </div>

      {/* Range toggle */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-1 p-0.5 rounded-[6px] border" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          {(["24h", "7d", "30d"] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRange(r)}
              aria-pressed={range === r}
              className="px-3 py-1 text-[11px] font-mono font-semibold rounded-[4px] cursor-pointer focus-ring transition-colors"
              style={{
                background: range === r ? "var(--primary)" : "transparent",
                color: range === r ? "var(--background)" : "var(--foreground-muted)",
              }}
            >
              {r.toUpperCase()}
            </button>
          ))}
        </div>
        <span className="text-[10px] font-mono text-[var(--foreground-muted)]">
          Showing uptime for last {range === "24h" ? "24 hours" : range === "7d" ? "7 days" : "30 days"}
        </span>
      </div>

      {/* Service cards grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {SERVICES.map((s) => {
          const meta = STATUS_META[s.status];
          const SIcon = s.icon;
          const StatusIcon = meta.icon;
          const uptime = getUptime(s);
          const isExpanded = expanded === s.id;
          const serviceIncidents = INCIDENTS.filter((i) => i.serviceId === s.id).slice(0, 2);
          return (
            <div
              key={s.id}
              className="rounded-[8px] border overflow-hidden"
              style={{ borderColor: "var(--border)", background: "var(--surface)" }}
            >
              <button
                type="button"
                onClick={() => setExpanded(isExpanded ? null : s.id)}
                className="w-full text-left p-3 cursor-pointer focus-ring outline-none hover:bg-[var(--surface-hover)] transition-colors"
                aria-expanded={isExpanded}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="w-8 h-8 rounded-[6px] flex items-center justify-center" style={{ background: meta.soft, color: meta.color }}>
                    <SIcon size={14} />
                  </div>
                  <span className={cn("inline-flex items-center gap-1 text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-[3px]", s.status === "degraded" && "pulse-atrisk", s.status === "down" && "pulse-delayed")} style={{ background: meta.soft, color: meta.color }}>
                    <StatusIcon size={10} /> {meta.label}
                  </span>
                </div>
                <h3 className="text-[13px] font-semibold text-[var(--foreground)]">{s.name}</h3>
                <p className="text-[10px] text-[var(--foreground-muted)] mt-0.5 line-clamp-1">{s.description}</p>
                <div className="flex items-center justify-between mt-2 pt-2 border-t" style={{ borderColor: "var(--border)" }}>
                  <div>
                    <div className="text-[9px] uppercase tracking-wider text-[var(--foreground-muted)]">Uptime</div>
                    <div className="text-[14px] font-mono font-bold" style={{ color: uptime >= 99.9 ? "var(--status-ontime)" : uptime >= 99 ? "var(--status-atrisk)" : "var(--status-delayed)" }}>{uptime.toFixed(2)}%</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[9px] uppercase tracking-wider text-[var(--foreground-muted)]">Response</div>
                    <div className="text-[12px] font-mono font-semibold text-[var(--foreground)]">{s.responseTimeMs}ms</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 mt-2 text-[10px] font-mono text-[var(--foreground-muted)]">
                  <span>{isExpanded ? "Hide" : "Show"} details</span>
                  <ChevronDown size={10} className={cn("transition-transform", isExpanded && "rotate-180")} />
                </div>
              </button>
              {isExpanded && (
                <div className="px-3 pb-3 -mt-1 space-y-2">
                  <div className="grid grid-cols-3 gap-1 text-center">
                    {[["24H", s.uptime24h], ["7D", s.uptime7d], ["30D", s.uptime30d]].map(([label, val]) => (
                      <div key={label as string} className="rounded-[4px] p-1.5" style={{ background: "var(--surface-elevated)" }}>
                        <div className="text-[9px] font-mono text-[var(--foreground-muted)]">{label as string}</div>
                        <div className="text-[11px] font-mono font-semibold text-[var(--foreground)]">{(val as number).toFixed(2)}%</div>
                      </div>
                    ))}
                  </div>
                  {serviceIncidents.length > 0 ? (
                    <div className="space-y-1.5">
                      <div className="text-[9px] uppercase tracking-wider text-[var(--foreground-muted)] flex items-center gap-1"><Activity size={9} /> Recent incidents</div>
                      {serviceIncidents.map((inc) => {
                        const tMeta = INCIDENT_TYPE_META[inc.type];
                        return (
                          <div key={inc.id} className="p-2 rounded-[4px]" style={{ background: "var(--surface-elevated)" }}>
                            <div className="flex items-center gap-1.5 mb-0.5">
                              <span className="w-1 h-1 rounded-full" style={{ background: tMeta.color }} />
                              <span className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: tMeta.color }}>{tMeta.label}</span>
                              <span className="text-[9px] font-mono text-[var(--foreground-muted)] ml-auto">{fmtRelative(inc.time)}</span>
                            </div>
                            <p className="text-[10px] text-[var(--foreground-secondary)] leading-snug">{inc.message}</p>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 p-2 rounded-[4px] text-[10px] text-[var(--foreground-muted)]" style={{ background: "var(--status-ontime-soft)" }}>
                      <CheckCircle2 size={11} style={{ color: "var(--status-ontime)" }} />
                      <span style={{ color: "var(--status-ontime)" }}>No incidents in the last 30 days</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Incident timeline */}
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-2">
            <Clock size={15} style={{ color: "var(--primary)" }} />
            <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Incident Timeline</h3>
          </div>
          <span className="text-[10px] font-mono text-[var(--foreground-muted)]">{INCIDENTS.length} events · last 30 days</span>
        </header>
        <div className="max-h-[500px] overflow-y-auto">
          {INCIDENTS.map((inc, idx) => {
            const meta = INCIDENT_TYPE_META[inc.type];
            return (
              <div key={inc.id} className="flex items-start gap-3 px-4 py-3 border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors" style={{ borderColor: "var(--border)" }}>
                <div className="flex flex-col items-center pt-1">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ background: meta.color }} />
                  {idx < INCIDENTS.length - 1 && <span className="w-px flex-1 mt-1" style={{ background: "var(--border)" }} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-[3px]" style={{ background: `color-mix(in srgb, ${meta.color} 12%, transparent)`, color: meta.color }}>{meta.label}</span>
                    <span className="text-[12px] font-semibold text-[var(--foreground)]">{inc.serviceName}</span>
                    <span className="text-[10px] font-mono text-[var(--foreground-muted)] ml-auto">{fmtRelative(inc.time)}</span>
                  </div>
                  <p className="text-[11px] text-[var(--foreground-secondary)] mt-1 leading-relaxed">{inc.message}</p>
                </div>
              </div>
            );
          })}
        </div>
        <div className="px-4 py-2 border-t flex items-center justify-between" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
          <span className="text-[10px] font-mono text-[var(--foreground-muted)] flex items-center gap-1.5">
            <Database size={10} /> Status data persisted to incident database
          </span>
          <button
            type="button"
            onClick={() => toast.success("Incident report exported", { description: `${INCIDENTS.length} events exported to CSV` })}
            className="text-[11px] font-medium text-[var(--primary)] hover:opacity-80 cursor-pointer focus-ring"
          >
            Export full history
          </button>
        </div>
      </div>
    </div>
  );
}
