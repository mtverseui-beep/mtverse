"use client";
import { useState } from "react";
import { useFleetStore } from "@/store/fleet-store";
import { KPI } from "../ui";
import { Avatar } from "../Avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { NOW, fmtRelative, fmtPct } from "@/lib/fleet/format";
import {
  User, Truck, TrendingUp, Calendar, Star, Shield, Bell, Globe,
  Phone, Mail, MapPin, Briefcase, Clock, Lock, Smartphone, LogOut,
  Check, Edit3, Camera, Award, Activity,
} from "lucide-react";

interface ProfilePageProps {
  navigate: (path: string) => void;
}

const USER = {
  name: "Daniel Kowalski",
  initials: "DK",
  role: "Operations Director",
  shift: "Day · 06:00 – 18:00",
  team: "Network Operations",
  email: "d.kowalski@fleetops.command",
  phone: "(555) 482-1109",
  location: "Dallas, TX",
  employeeId: "EMP-00042",
  joined: "2019-03-14",
  vehiclesManaged: 35,
  onTimePct: 94.2,
  years: 6.4,
  rating: 4.8,
};

const ACTIVITY_LOG = [
  { id: 1, action: "Assigned dispatch dsp-501 to FL-204", time: new Date(NOW - 8 * 60000).toISOString(), icon: Truck },
  { id: 2, action: "Acknowledged alert: FL-215 fuel anomaly", time: new Date(NOW - 47 * 60000).toISOString(), icon: Shield },
  { id: 3, action: "Updated route rte-3 ETA by 22 minutes", time: new Date(NOW - 2 * 3600000).toISOString(), icon: TrendingUp },
  { id: 4, action: "Reviewed driver leaderboard (35 drivers)", time: new Date(NOW - 3 * 3600000).toISOString(), icon: User },
  { id: 5, action: "Approved maintenance order mnt-803 ($1,240)", time: new Date(NOW - 5 * 3600000).toISOString(), icon: Award },
  { id: 6, action: "Logged in from 73.142.xxx.xx (Dallas, TX)", time: new Date(NOW - 8 * 3600000).toISOString(), icon: Smartphone },
  { id: 7, action: "Exported weekly performance report", time: new Date(NOW - 26 * 3600000).toISOString(), icon: Activity },
];

const SESSIONS = [
  { id: 1, device: "MacBook Pro · Chrome", location: "Dallas, TX", current: true, lastActive: "Active now" },
  { id: 2, device: "iPhone 15 Pro · FleetOps Mobile", location: "Dallas, TX", current: false, lastActive: "12m ago" },
  { id: 3, device: "iPad Air · Safari", location: "Houston, TX", current: false, lastActive: "3d ago" },
];

export function ProfilePage({ navigate }: ProfilePageProps) {
  const [mfaEnabled, setMfaEnabled] = useState(true);
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [pushNotifs, setPushNotifs] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(false);
  const [compactView, setCompactView] = useState(false);
  const [editingInfo, setEditingInfo] = useState(false);
  const [info, setInfo] = useState({
    name: USER.name,
    email: USER.email,
    phone: USER.phone,
    location: USER.location,
  });

  const handleSaveInfo = () => {
    setEditingInfo(false);
    toast.success("Profile updated", { description: "Your personal information has been saved" });
  };

  return (
    <div className="p-5 space-y-4">
      {/* Hero card */}
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <div className="h-20 relative" style={{ background: "linear-gradient(135deg, var(--primary-soft) 0%, var(--surface-elevated) 100%)" }}>
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "repeating-linear-gradient(45deg, var(--primary) 0, var(--primary) 1px, transparent 1px, transparent 12px)" }} />
          <button
            type="button"
            onClick={() => toast.info("Cover photo", { description: "Cover photo upload coming soon" })}
            className="absolute top-2 right-2 w-7 h-7 rounded-[4px] flex items-center justify-center text-[var(--foreground-secondary)] hover:text-[var(--foreground)] cursor-pointer focus-ring"
            style={{ background: "color-mix(in srgb, var(--surface) 80%, transparent)", border: "1px solid var(--border)" }}
            aria-label="Edit cover"
          >
            <Camera size={13} />
          </button>
        </div>
        <div className="px-5 pb-4 -mt-10">
          <div className="flex items-end justify-between flex-wrap gap-3">
            <div className="flex items-end gap-3">
              <Avatar seed="d-kowalski" name={USER.name} size={80} ring />
              <div className="pb-1">
                <div className="flex items-center gap-2">
                  <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight">{USER.name}</h1>
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-[4px]" style={{ background: "var(--status-ontime-soft)", color: "var(--status-ontime)" }}>
                    <Check size={10} /> Verified
                  </span>
                </div>
                <p className="text-[13px] text-[var(--foreground-secondary)] mt-0.5 flex items-center gap-1.5">
                  <Briefcase size={12} style={{ color: "var(--primary)" }} />
                  {USER.role}
                </p>
                <div className="flex items-center gap-3 mt-1.5 text-[11px] text-[var(--foreground-muted)]">
                  <span className="flex items-center gap-1"><Clock size={11} /> {USER.shift}</span>
                  <span className="flex items-center gap-1"><User size={11} /> {USER.team}</span>
                  <span className="flex items-center gap-1"><MapPin size={11} /> {USER.location}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 pb-1">
              <button
                type="button"
                onClick={() => setEditingInfo((v) => !v)}
                className="h-8 px-3 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5 text-[var(--foreground-secondary)]"
                style={{ borderColor: "var(--border)" }}
              >
                <Edit3 size={13} /> {editingInfo ? "Cancel" : "Edit profile"}
              </button>
              <button
                type="button"
                onClick={() => navigate("settings")}
                className="h-8 px-3 text-[12px] font-semibold rounded-[6px] text-[var(--background)] cursor-pointer focus-ring flex items-center gap-1.5"
                style={{ background: "var(--primary)" }}
              >
                Settings
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <KPI
          icon={Truck}
          label="Vehicles Managed"
          value={String(USER.vehiclesManaged)}
          sub="across 6 regions"
          status="on-time"
          onClick={() => navigate("fleet")}
        />
        <KPI
          icon={TrendingUp}
          label="On-Time %"
          value={fmtPct(USER.onTimePct)}
          sub="last 30 days"
          status="on-time"
          onClick={() => navigate("analytics")}
        />
        <KPI
          icon={Calendar}
          label="Years of Service"
          value={USER.years.toFixed(1)}
          sub={`since ${new Date(USER.joined).getFullYear()}`}
          status="on-time"
          onClick={() => toast.info("Tenure", { description: `${USER.years.toFixed(1)} years at FleetOps` })}
        />
        <KPI
          icon={Star}
          label="Operator Rating"
          value={`${USER.rating.toFixed(1)}★`}
          sub="driver feedback"
          status="on-time"
          onClick={() => toast.info("Rating", { description: `${USER.rating.toFixed(1)} out of 5 from 142 reviews` })}
        />
      </div>

      {/* Three-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Personal info */}
        <div className="rounded-[8px] border overflow-hidden lg:col-span-2" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <User size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Personal Information</h3>
            </div>
            {editingInfo && (
              <button
                type="button"
                onClick={handleSaveInfo}
                className="text-[11px] font-semibold px-2 py-1 rounded-[4px] text-[var(--background)] cursor-pointer focus-ring"
                style={{ background: "var(--status-ontime)" }}
              >
                Save changes
              </button>
            )}
          </header>
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <InfoField icon={User} label="Full name" value={info.name} editing={editingInfo} onChange={(v) => setInfo({ ...info, name: v })} />
            <InfoField icon={Mail} label="Email" value={info.email} editing={editingInfo} onChange={(v) => setInfo({ ...info, email: v })} />
            <InfoField icon={Phone} label="Phone" value={info.phone} editing={editingInfo} onChange={(v) => setInfo({ ...info, phone: v })} />
            <InfoField icon={MapPin} label="Location" value={info.location} editing={editingInfo} onChange={(v) => setInfo({ ...info, location: v })} />
            <InfoField icon={Briefcase} label="Employee ID" value={USER.employeeId} editing={false} />
            <InfoField icon={Calendar} label="Joined" value={new Date(USER.joined).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })} editing={false} />
          </div>
        </div>

        {/* Security */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Shield size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Security</h3>
            </div>
          </header>
          <div className="p-4 space-y-3">
            <ToggleRow
              icon={Lock}
              label="Multi-factor auth"
              description="Require code on new devices"
              checked={mfaEnabled}
              onChange={(v) => { setMfaEnabled(v); toast.success(v ? "MFA enabled" : "MFA disabled", { description: v ? "2FA now required for login" : "2FA no longer required" }); }}
            />
            <button
              type="button"
              onClick={() => toast.success("Password change", { description: "Reset link sent to your email" })}
              className="w-full h-8 px-3 text-[11px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)] flex items-center justify-center gap-1.5"
              style={{ borderColor: "var(--border)" }}
            >
              <Lock size={12} /> Change password
            </button>

            <div className="pt-2 border-t" style={{ borderColor: "var(--border)" }}>
              <div className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)] mb-2 flex items-center justify-between">
                <span>Active sessions</span>
                <span className="font-mono">{SESSIONS.length}</span>
              </div>
              <div className="space-y-2">
                {SESSIONS.map((s) => (
                  <div key={s.id} className="flex items-center gap-2 p-2 rounded-[4px]" style={{ background: s.current ? "var(--status-ontime-soft)" : "var(--surface-elevated)" }}>
                    <Smartphone size={13} className="shrink-0" style={{ color: s.current ? "var(--status-ontime)" : "var(--foreground-muted)" }} />
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-medium text-[var(--foreground)] truncate">{s.device}</div>
                      <div className="text-[9px] font-mono text-[var(--foreground-muted)]">{s.location} · {s.lastActive}</div>
                    </div>
                    {s.current ? (
                      <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-[3px]" style={{ background: "var(--status-ontime-soft)", color: "var(--status-ontime)" }}>CURRENT</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => toast.success("Session revoked", { description: s.device })}
                        className="text-[10px] font-medium px-1.5 py-0.5 rounded-[3px] hover:bg-[var(--status-delayed-soft)] hover:text-[var(--status-delayed)] cursor-pointer focus-ring text-[var(--foreground-muted)]"
                      >
                        Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() => toast.success("Signed out everywhere", { description: "All other sessions revoked" })}
                className="w-full mt-2 text-[10px] font-medium text-[var(--status-delayed)] hover:underline cursor-pointer focus-ring flex items-center justify-center gap-1"
              >
                <LogOut size={10} /> Sign out of all other sessions
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Preferences + Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Preferences */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Bell size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Preferences</h3>
            </div>
          </header>
          <div className="p-4 space-y-3">
            <ToggleRow icon={Mail} label="Email notifications" description="Daily digest + critical alerts" checked={emailNotifs} onChange={(v) => { setEmailNotifs(v); toast.success(`Email notifications ${v ? "on" : "off"}`); }} />
            <ToggleRow icon={Bell} label="Push notifications" description="Real-time in-browser alerts" checked={pushNotifs} onChange={(v) => { setPushNotifs(v); toast.success(`Push notifications ${v ? "on" : "off"}`); }} />
            <ToggleRow icon={Smartphone} label="SMS alerts" description="Critical-only text messages" checked={smsAlerts} onChange={(v) => { setSmsAlerts(v); toast.success(`SMS alerts ${v ? "on" : "off"}`); }} />
            <ToggleRow icon={Globe} label="Compact view" description="Denser layout for power users" checked={compactView} onChange={(v) => { setCompactView(v); toast.success(`Compact view ${v ? "on" : "off"}`); }} />
          </div>
        </div>

        {/* Activity log */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Activity size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Recent Activity</h3>
            </div>
            <button
              type="button"
              onClick={() => toast.info("Activity log", { description: "Full audit log available in admin panel" })}
              className="text-[11px] font-medium text-[var(--primary)] hover:opacity-80 cursor-pointer focus-ring"
            >
              View full log
            </button>
          </header>
          <div className="max-h-[360px] overflow-y-auto p-3 space-y-1">
            {ACTIVITY_LOG.map((a) => {
              const Icon = a.icon;
              return (
                <div key={a.id} className="flex items-start gap-3 px-2 py-1.5 rounded-[4px] hover:bg-[var(--surface-hover)] transition-colors">
                  <div className="w-6 h-6 rounded-[4px] flex items-center justify-center shrink-0" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>
                    <Icon size={12} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px] text-[var(--foreground-secondary)]">{a.action}</p>
                    <p className="text-[10px] font-mono text-[var(--foreground-muted)] mt-0.5">{fmtRelative(a.time)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoField({
  icon: Icon, label, value, editing, onChange,
}: {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  label: string;
  value: string;
  editing: boolean;
  onChange?: (v: string) => void;
}) {
  return (
    <div className="flex items-start gap-2.5">
      <div className="w-7 h-7 rounded-[4px] flex items-center justify-center shrink-0 mt-0.5" style={{ background: "var(--surface-elevated)", color: "var(--foreground-muted)" }}>
        <Icon size={13} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">{label}</div>
        {editing && onChange ? (
          <input
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full mt-0.5 h-7 px-2 text-[12px] rounded-[4px] border bg-[var(--background)] focus-ring outline-none text-[var(--foreground)]"
            style={{ borderColor: "var(--border-strong)" }}
          />
        ) : (
          <div className="text-[12px] font-medium text-[var(--foreground)] mt-0.5 truncate">{value}</div>
        )}
      </div>
    </div>
  );
}

function ToggleRow({
  icon: Icon, label, description, checked, onChange,
}: {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-3 py-1.5">
      <div className="w-7 h-7 rounded-[4px] flex items-center justify-center shrink-0" style={{ background: "var(--surface-elevated)", color: "var(--foreground-muted)" }}>
        <Icon size={13} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[12px] font-medium text-[var(--foreground)]">{label}</div>
        <div className="text-[10px] text-[var(--foreground-muted)]">{description}</div>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={() => onChange(!checked)}
        className={cn("relative w-9 h-5 rounded-full transition-colors cursor-pointer focus-ring shrink-0")}
        style={{ background: checked ? "var(--primary)" : "var(--surface-hover)", border: "1px solid var(--border-strong)" }}
      >
        <span
          className="absolute top-0.5 w-3.5 h-3.5 rounded-full bg-white transition-transform"
          style={{ left: "2px", transform: checked ? "translateX(16px)" : "translateX(0)" }}
        />
      </button>
    </div>
  );
}
