"use client";
import { useState } from "react";
import { useFleetStore } from "@/store/fleet-store";
import { PriorityBadge, StatusBadge } from "../ui";
import { Zap, ArrowRight, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function DispatchPage() {
  const orders = useFleetStore((s) => s.dispatchOrders);
  const vehicles = useFleetStore((s) => s.vehicles);
  const drivers = useFleetStore((s) => s.drivers);
  const assignDispatch = useFleetStore((s) => s.assignDispatch);
  const cancelDispatch = useFleetStore((s) => s.cancelDispatch);
  const escalateDispatch = useFleetStore((s) => s.escalateDispatch);
  const [assigning, setAssigning] = useState<string | null>(null);

  const unassigned = orders.filter(o => o.status === "unassigned");
  const assigned = orders.filter(o => o.status === "assigned");

  const doAssign = (orderId: string) => {
    const availVeh = vehicles.find(v => v.status === "on-time" && !v.driverId);
    const availDrv = drivers.find(d => d.status === "on-duty" && !d.assignedVehicleId);
    if (availVeh && availDrv) {
      assignDispatch(orderId, availVeh.id, availDrv.id);
      toast.success("Dispatch assigned", { description: `${availVeh.unit} → ${availDrv.name}` });
    } else {
      toast.error("No available vehicles or drivers");
    }
    setAssigning(null);
  };

  return (
    <div className="p-5">
      <div className="mb-4">
        <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight">Dispatch Queue</h1>
        <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">{unassigned.length} unassigned · {assigned.length} assigned · {orders.length} total</p>
      </div>

      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <div className="px-4 py-2.5 border-b flex items-center gap-2" style={{ borderColor: "var(--border)" }}>
          <Zap size={15} style={{ color: "var(--primary)" }} />
          <h3 className="text-[13px] font-semibold">Pending Assignments</h3>
        </div>
        <div className="max-h-[600px] overflow-y-auto">
          {orders.map(o => (
            <div key={o.id} className={cn("flex items-center gap-3 px-4 py-2.5 border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors", o.status === "cancelled" && "opacity-50")} style={{ borderColor: "var(--border)" }}>
              <PriorityBadge priority={o.priority} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 text-[12px]">
                  <span className="font-mono font-semibold text-[var(--foreground)]">{o.pickupCity}</span>
                  <ArrowRight size={10} className="text-[var(--foreground-muted)]" />
                  <span className="font-mono font-semibold text-[var(--foreground)]">{o.deliveryCity}</span>
                </div>
                <div className="text-[10px] text-[var(--foreground-muted)] font-mono mt-0.5">{o.id} · {o.pickup} → {o.delivery} · Window {new Date(o.windowStart).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })}–{new Date(o.windowEnd).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })}</div>
              </div>
              {o.status === "unassigned" && (
                <div className="flex items-center gap-1.5">
                  <button type="button" onClick={() => doAssign(o.id)} className="text-[11px] font-semibold px-2.5 py-1 rounded-[4px] text-[var(--background)] cursor-pointer focus-ring" style={{ background: "var(--primary)" }}>Assign</button>
                  <button type="button" onClick={() => { escalateDispatch(o.id); toast.success("Escalated to critical"); }} className="text-[11px] font-medium px-2 py-1 rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-secondary)]" style={{ borderColor: "var(--border)" }}>Escalate</button>
                  <button type="button" onClick={() => { cancelDispatch(o.id); toast.success("Dispatch cancelled"); }} className="w-7 h-7 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--status-delayed)] hover:bg-[var(--status-delayed-soft)] cursor-pointer focus-ring"><X size={13} /></button>
                </div>
              )}
              {o.status === "assigned" && <StatusBadge status="on-time" label="Assigned" size="sm" />}
              {o.status === "cancelled" && <StatusBadge status="offline" label="Cancelled" size="sm" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
