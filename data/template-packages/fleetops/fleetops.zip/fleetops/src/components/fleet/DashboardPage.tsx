"use client";
import { motion } from "framer-motion";
import { Truck, Clock, AlertTriangle, Activity, Fuel, Building2, Users, TrendingUp, ArrowRight, MapPin, Zap } from "lucide-react";
import { useFleetStore } from "@/store/fleet-store";
import { FleetMapWrapper as FleetMap } from "./FleetMapWrapper";
import { KPI, StatusBadge, PriorityBadge } from "./ui";
import { NOW, fmtETA, fmtRelative } from "@/lib/fleet/format";
import { cn } from "@/lib/utils";
import type { Route } from "@/hooks/use-hash-route";

interface DashboardPageProps {
  navigate: (path: string) => void;
}

export function DashboardPage({ navigate }: DashboardPageProps) {
  const vehicles = useFleetStore((s) => s.vehicles);
  const routes = useFleetStore((s) => s.routes);
  const dispatchOrders = useFleetStore((s) => s.dispatchOrders);
  const incidents = useFleetStore((s) => s.incidents);
  const alerts = useFleetStore((s) => s.alerts);
  const drivers = useFleetStore((s) => s.drivers);
  const warehouses = useFleetStore((s) => s.warehouses);
  const selectVehicle = useFleetStore((s) => s.selectVehicle);

  const onTime = vehicles.filter(v => v.status === "on-time").length;
  const atRisk = vehicles.filter(v => v.status === "at-risk").length;
  const delayed = vehicles.filter(v => v.status === "delayed").length;
  const offline = vehicles.filter(v => v.status === "offline").length;
  const maintenance = vehicles.filter(v => v.status === "maintenance").length;
  const activeVehicles = vehicles.filter(v => v.status !== "offline" && v.status !== "maintenance").length;
  const onTimePct = activeVehicles > 0 ? ((onTime / activeVehicles) * 100).toFixed(1) : "0";
  const fuelBurn = vehicles.reduce((a, v) => a + v.fuelGallons, 0);
  const throughput = warehouses.reduce((a, w) => a + w.throughputToday, 0);
  const availDrivers = drivers.filter(d => d.status === "on-duty").length;
  const avgEta = routes.filter(r => r.eta).length > 0 ? Math.round(routes.reduce((a, r) => a + (new Date(r.eta).getTime() - NOW) / 60000, 0) / routes.filter(r => r.eta).length) : 0;
  const unassignedDispatch = dispatchOrders.filter(o => o.status === "unassigned").length;
  const openIncidents = incidents.filter(i => i.status === "open" || i.status === "acknowledged").length;
  const unackAlerts = alerts.filter(a => !a.acknowledged);

  return (
    <div className="p-5 space-y-5">
      {/* Top KPI Strip */}
      <div className="grid grid-cols-4 lg:grid-cols-8 gap-2">
        <KPI icon={Truck} label="Active Vehicles" value={String(activeVehicles)} sub={`${vehicles.length} total`} onClick={() => navigate("fleet")} />
        <KPI icon={Activity} label="On-Time %" value={`${onTimePct}%`} sub={`${onTime} on time`} status="on-time" onClick={() => navigate("fleet")} />
        <KPI icon={AlertTriangle} label="Delayed" value={String(delayed)} sub="Need attention" status="delayed" onClick={() => navigate("fleet")} />
        <KPI icon={Clock} label="At Risk" value={String(atRisk)} sub="Monitor" status="at-risk" onClick={() => navigate("fleet")} />
        <KPI icon={Navigation} label="Avg ETA" value={`${avgEta}m`} sub="All routes" onClick={() => navigate("routes/timeline")} />
        <KPI icon={Fuel} label="Fuel Burn Today" value={`${(fuelBurn).toLocaleString()} gal`} sub={`$${(fuelBurn * 3.79).toFixed(0)}`} onClick={() => navigate("analytics/fuel")} />
        <KPI icon={Building2} label="Throughput" value={`${throughput}`} sub="Warehouse units" onClick={() => navigate("warehouses")} />
        <KPI icon={Users} label="Drivers Avail." value={String(availDrivers)} sub={`${drivers.length} total`} onClick={() => navigate("drivers")} />
      </div>

      {/* Critical Alert Banner */}
      {unackAlerts.length > 0 && unackAlerts[0] && (
        <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 px-4 py-2.5 rounded-[6px] border" style={{ background: "var(--status-delayed-soft)", borderColor: "var(--status-delayed)" }} role="alert" aria-live="assertive">
          <AlertTriangle size={16} className="pulse-delayed" style={{ color: "var(--status-delayed)" }} />
          <div className="flex-1 min-w-0">
            <p className="text-[13px] font-semibold text-[var(--foreground)]">{unackAlerts[0].title}</p>
            <p className="text-[12px] text-[var(--foreground-secondary)] truncate">{unackAlerts[0].description}</p>
          </div>
          <button type="button" onClick={() => navigate("fleet")} className="text-[11px] font-medium px-2 py-1 rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring" style={{ borderColor: "var(--border-strong)", color: "var(--foreground)" }}>View</button>
          <button type="button" className="text-[11px] font-medium px-2 py-1 rounded-[4px] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-muted)]">Dismiss</button>
        </motion.div>
      )}

      {/* Two-column command center */}
      <div className="grid grid-cols-1 lg:grid-cols-[42%_1fr] gap-4">
        {/* Live Fleet Map */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <div className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <MapPin size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Live Fleet Map</h3>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>{activeVehicles} active</span>
            </div>
            <div className="flex items-center gap-3 text-[10px] font-mono">
              <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-ontime)" }} />On Time</span>
              <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-atrisk)" }} />At Risk</span>
              <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-delayed)" }} />Delayed</span>
              <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-offline)" }} />Offline</span>
            </div>
          </div>
          <FleetMap vehicles={vehicles} onSelect={selectVehicle} />
        </div>

        {/* Dispatch Queue */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <div className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Zap size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Dispatch Queue</h3>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ background: "var(--status-atrisk-soft)", color: "var(--status-atrisk)" }}>{unassignedDispatch} unassigned</span>
            </div>
            <button type="button" onClick={() => navigate("dispatch")} className="flex items-center gap-1 text-[11px] font-medium text-[var(--primary)] hover:opacity-80 cursor-pointer focus-ring">View all <ArrowRight size={11} /></button>
          </div>
          <div className="max-h-[340px] overflow-y-auto">
            {dispatchOrders.slice(0, 6).map((o) => (
              <div key={o.id} className="flex items-center gap-3 px-4 py-2 border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors" style={{ borderColor: "var(--border)" }}>
                <PriorityBadge priority={o.priority} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-[12px]">
                    <span className="font-mono font-semibold text-[var(--foreground)]">{o.pickupCity}</span>
                    <ArrowRight size={10} className="text-[var(--foreground-muted)]" />
                    <span className="font-mono font-semibold text-[var(--foreground)]">{o.deliveryCity}</span>
                  </div>
                  <div className="text-[10px] text-[var(--foreground-muted)] font-mono mt-0.5">{o.id} · Window {new Date(o.windowStart).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })}–{new Date(o.windowEnd).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })}</div>
                </div>
                {o.status === "unassigned" ? (
                  <button type="button" onClick={() => navigate("dispatch")} className="text-[11px] font-semibold px-2 py-1 rounded-[4px] text-[var(--background)] cursor-pointer focus-ring" style={{ background: "var(--primary)" }}>Assign</button>
                ) : (
                  <StatusBadge status="on-time" label="Assigned" size="sm" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row: Route Timeline + Driver Status + Recent Incidents */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Route Timeline (mini) */}
        <div className="lg:col-span-2 rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <div className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Activity size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Route Timeline</h3>
            </div>
            <button type="button" onClick={() => navigate("routes/timeline")} className="flex items-center gap-1 text-[11px] font-medium text-[var(--primary)] hover:opacity-80 cursor-pointer focus-ring">View all <ArrowRight size={11} /></button>
          </div>
          <div className="p-3 space-y-1.5 max-h-[280px] overflow-y-auto">
            {routes.slice(0, 6).map((r) => {
              const vehicle = vehicles.find(v => v.id === r.vehicleId);
              const statusColor = r.status === "delayed" ? "var(--status-delayed)" : r.status === "completed" ? "var(--status-offline)" : vehicle?.status === "at-risk" ? "var(--status-atrisk)" : "var(--status-ontime)";
              return (
                <div key={r.id} className="flex items-center gap-3 px-2 py-1.5 rounded-[4px] hover:bg-[var(--surface-hover)] cursor-pointer" onClick={() => vehicle && selectVehicle(vehicle.id)}>
                  <span className="text-[11px] font-mono text-[var(--foreground-muted)] w-20 truncate">{r.originCity} → {r.destCity}</span>
                  <div className="flex-1 h-5 rounded-[3px] relative overflow-hidden" style={{ background: "var(--background)" }}>
                    <div className="absolute inset-y-0 left-0 rounded-[3px]" style={{ width: `${Math.min(100, ((NOW - new Date(r.actualStart ?? r.plannedStart).getTime()) / (new Date(r.eta).getTime() - new Date(r.plannedStart).getTime())) * 100)}%`, background: statusColor }} />
                    <span className="absolute inset-0 flex items-center justify-center text-[10px] font-mono font-semibold text-[var(--foreground)]">{vehicle?.unit} · {r.distanceMiles}mi</span>
                  </div>
                  <span className="text-[10px] font-mono text-[var(--foreground-muted)] w-14 text-right">{fmtETA(r.eta)}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Incidents */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <div className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <AlertTriangle size={15} style={{ color: "var(--status-delayed)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Recent Incidents</h3>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ background: "var(--status-delayed-soft)", color: "var(--status-delayed)" }}>{openIncidents} open</span>
            </div>
          </div>
          <div className="max-h-[280px] overflow-y-auto">
            {incidents.slice(0, 5).map((inc) => (
              <div key={inc.id} className="px-4 py-2 border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors" style={{ borderColor: "var(--border)" }}>
                <div className="flex items-center gap-2">
                  <span className={cn("w-1.5 h-1.5 rounded-full", inc.severity === "critical" && "pulse-delayed")} style={{ background: inc.severity === "critical" ? "var(--status-delayed)" : inc.severity === "high" ? "var(--status-atrisk)" : "var(--status-offline)" }} />
                  <span className="text-[12px] font-semibold text-[var(--foreground)] truncate flex-1">{inc.title}</span>
                  <span className="text-[10px] font-mono text-[var(--foreground-muted)]">{fmtRelative(inc.timestamp)}</span>
                </div>
                <p className="text-[11px] text-[var(--foreground-muted)] mt-0.5 line-clamp-2">{inc.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Navigation({ size }: { size?: number }) {
  return <TrendingUp size={size} />;
}
