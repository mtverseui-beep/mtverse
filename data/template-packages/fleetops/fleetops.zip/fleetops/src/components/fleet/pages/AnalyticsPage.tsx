"use client";
import { useMemo, useState, useEffect } from "react";
import ReactECharts from "echarts-for-react";
import { useFleetStore } from "@/store/fleet-store";
import { KPI } from "../ui";
import { NOW, fmtCurrency, fmtPct, fmtNumber } from "@/lib/fleet/format";
import { toast } from "sonner";
import { BarChart3, TrendingUp, Clock, Fuel, Activity, Truck, Building2, Gauge } from "lucide-react";

// Resolve CSS variable to hex (fallback to amber)
const cssVar = (name: string): string => {
  if (typeof window === "undefined") return "#F59E0B";
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || "#F59E0B";
};

export function AnalyticsPage() {
  const vehicles = useFleetStore((s) => s.vehicles);
  const routes = useFleetStore((s) => s.routes);
  const warehouses = useFleetStore((s) => s.warehouses);
  const fuelEvents = useFleetStore((s) => s.fuelEvents);
  const [range, setRange] = useState<"7d" | "14d" | "30d">("14d");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);

  // Derived stats
  const activeVehicles = vehicles.filter((v) => v.status !== "offline" && v.status !== "maintenance");
  const onTimeCount = vehicles.filter((v) => v.status === "on-time").length;
  const onTimePct = activeVehicles.length > 0 ? (onTimeCount / activeVehicles.length) * 100 : 0;
  const utilizationPct = activeVehicles.length > 0 ? (activeVehicles.length / vehicles.length) * 100 : 0;
  const fuelCostToday = fuelEvents
    .filter((f) => NOW - new Date(f.timestamp).getTime() < 24 * 3600000)
    .reduce((a, f) => a + f.cost, 0);
  const avgDeliveryMin = routes.length > 0
    ? Math.round(routes.reduce((a, r) => a + Math.max(0, (new Date(r.eta).getTime() - new Date(r.plannedStart).getTime()) / 60000), 0) / routes.length)
    : 0;

  // Delivery performance trend (line)
  const days = range === "7d" ? 7 : range === "14d" ? 14 : 30;
  const trendData = useMemo(() => {
    const base = onTimePct;
    const out: { day: string; pct: number }[] = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(NOW - i * 86400000);
      const wobble = Math.sin(i * 1.3) * 4 + Math.cos(i * 0.7) * 2.5;
      const v = Math.max(72, Math.min(99, base + wobble));
      out.push({ day: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }), pct: Number(v.toFixed(1)) });
    }
    return out;
  }, [onTimePct, days]);

  // Warehouse throughput (bar)
  const whData = useMemo(() => warehouses.slice(0, 8).map((w) => ({
    name: w.code,
    throughput: w.throughputToday,
    capacity: w.dockCount,
  })), [warehouses]);

  // Palette
  const C = useMemo(() => ({
    primary: cssVar("--primary"),
    accent: cssVar("--accent"),
    ontime: cssVar("--status-ontime"),
    atrisk: cssVar("--status-atrisk"),
    delayed: cssVar("--status-delayed"),
    fg: cssVar("--foreground"),
    fgMuted: cssVar("--foreground-muted"),
    fgSecondary: cssVar("--foreground-secondary"),
    border: cssVar("--border"),
    surface: cssVar("--surface"),
    surfaceHover: cssVar("--surface-hover"),
  }), [mounted]);

  const lineOption = {
    backgroundColor: "transparent",
    textStyle: { color: C.fgMuted, fontFamily: "var(--font-mono)" },
    grid: { left: 40, right: 16, top: 24, bottom: 28 },
    tooltip: {
      trigger: "axis",
      backgroundColor: C.surface,
      borderColor: C.border,
      textStyle: { color: C.fg, fontSize: 11, fontFamily: "var(--font-mono)" },
      formatter: (params: { axisValue: string; data: number }[]) => {
        const p = params[0];
        return `<div style="font-size:10px;color:${C.fgMuted}">${p.axisValue}</div><div style="font-size:12px;font-weight:600;color:${C.primary}">${p.data}%</div>`;
      },
    },
    xAxis: {
      type: "category",
      data: trendData.map((d) => d.day),
      axisLine: { lineStyle: { color: C.border } },
      axisTick: { show: false },
      axisLabel: { color: C.fgMuted, fontSize: 10, fontFamily: "var(--font-mono)", interval: days > 14 ? 3 : 0 },
    },
    yAxis: {
      type: "value",
      min: 60,
      max: 100,
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: C.border, type: "dashed" as const, opacity: 0.5 } },
      axisLabel: { color: C.fgMuted, fontSize: 10, fontFamily: "var(--font-mono)", formatter: "{value}%" },
    },
    series: [{
      type: "line",
      data: trendData.map((d) => d.pct),
      smooth: true,
      symbol: "circle",
      symbolSize: 5,
      lineStyle: { color: C.primary, width: 2 },
      itemStyle: { color: C.primary, borderColor: C.surface, borderWidth: 1.5 },
      areaStyle: {
        color: {
          type: "linear" as const, x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: hexA(C.primary, 0.28) },
            { offset: 1, color: hexA(C.primary, 0.02) },
          ],
        },
      },
      markLine: {
        symbol: "none",
        lineStyle: { color: C.ontime, type: "dashed" as const, width: 1 },
        data: [{ yAxis: 95, label: { formatter: "Target 95%", color: C.ontime, fontSize: 9, fontFamily: "var(--font-mono)", position: "insideEndTop" } }],
      },
    }],
  };

  const barOption = {
    backgroundColor: "transparent",
    textStyle: { color: C.fgMuted, fontFamily: "var(--font-mono)" },
    grid: { left: 44, right: 16, top: 24, bottom: 28 },
    tooltip: {
      trigger: "axis",
      axisPointer: { type: "shadow" },
      backgroundColor: C.surface,
      borderColor: C.border,
      textStyle: { color: C.fg, fontSize: 11, fontFamily: "var(--font-mono)" },
    },
    xAxis: {
      type: "category",
      data: whData.map((d) => d.name),
      axisLine: { lineStyle: { color: C.border } },
      axisTick: { show: false },
      axisLabel: { color: C.fgMuted, fontSize: 10, fontFamily: "var(--font-mono)", rotate: 0 },
    },
    yAxis: {
      type: "value",
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: C.border, type: "dashed" as const, opacity: 0.5 } },
      axisLabel: { color: C.fgMuted, fontSize: 10, fontFamily: "var(--font-mono)" },
    },
    series: [{
      type: "bar",
      data: whData.map((d) => ({
        value: d.throughput,
        itemStyle: {
          color: {
            type: "linear" as const, x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: C.primary },
              { offset: 1, color: hexA(C.primary, 0.4) },
            ],
          },
          borderRadius: [3, 3, 0, 0],
        },
      })),
      barWidth: "55%",
    }],
  };

  const gaugeOption = {
    backgroundColor: "transparent",
    textStyle: { color: C.fgMuted, fontFamily: "var(--font-mono)" },
    series: [{
      type: "gauge",
      startAngle: 200,
      endAngle: -20,
      min: 0,
      max: 100,
      progress: {
        show: true,
        width: 14,
        roundCap: true,
        itemStyle: {
          color: {
            type: "linear" as const, x: 0, y: 0, x2: 1, y2: 0,
            colorStops: [
              { offset: 0, color: C.delayed },
              { offset: 0.6, color: C.atrisk },
              { offset: 1, color: C.ontime },
            ],
          },
        },
      },
      axisLine: { lineStyle: { width: 14, color: [[1, C.surfaceHover]] } },
      pointer: { show: false },
      axisTick: { show: false },
      splitLine: { show: false },
      axisLabel: { show: false },
      anchor: { show: false },
      detail: {
        valueAnimation: true,
        offsetCenter: [0, "8%"],
        fontSize: 28,
        fontWeight: "bold" as const,
        fontFamily: "var(--font-mono)",
        color: C.fg,
        formatter: "{value}%",
      },
      title: {
        offsetCenter: [0, "42%"],
        fontSize: 10,
        color: C.fgMuted,
        fontFamily: "var(--font-mono)",
      },
      data: [{ value: Number(onTimePct.toFixed(1)), name: "ON-TIME DELIVERY" }],
    }],
  };

  return (
    <div className="p-5 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight flex items-center gap-2">
            <BarChart3 size={20} style={{ color: "var(--primary)" }} />
            Performance Analytics
          </h1>
          <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">
            Real-time fleet performance · last {days} days
          </p>
        </div>
        <div className="flex items-center gap-1 p-0.5 rounded-[6px] border" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          {(["7d", "14d", "30d"] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => { setRange(r); toast.info(`Range: last ${r}`); }}
              className="px-2.5 py-1 text-[11px] font-mono font-semibold rounded-[4px] cursor-pointer focus-ring transition-colors"
              style={{
                background: range === r ? "var(--primary)" : "transparent",
                color: range === r ? "var(--background)" : "var(--foreground-muted)",
              }}
              aria-pressed={range === r}
            >
              {r.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <KPI
          icon={TrendingUp}
          label="On-Time %"
          value={fmtPct(onTimePct)}
          sub={`${onTimeCount}/${activeVehicles.length} active vehicles`}
          status={onTimePct >= 90 ? "on-time" : onTimePct >= 80 ? "at-risk" : "delayed"}
          onClick={() => toast.info("On-Time performance", { description: `${fmtPct(onTimePct)} across ${activeVehicles.length} active vehicles` })}
        />
        <KPI
          icon={Truck}
          label="Fleet Utilization"
          value={fmtPct(utilizationPct)}
          sub={`${activeVehicles.length}/${vehicles.length} in service`}
          status={utilizationPct >= 80 ? "on-time" : "at-risk"}
          onClick={() => toast.info("Fleet utilization", { description: `${activeVehicles.length} of ${vehicles.length} vehicles active` })}
        />
        <KPI
          icon={Fuel}
          label="Fuel Cost Today"
          value={fmtCurrency(fuelCostToday)}
          sub={`${fuelEvents.filter((f) => NOW - new Date(f.timestamp).getTime() < 24 * 3600000).length} fuel events`}
          status="on-time"
          onClick={() => toast.info("Fuel cost", { description: `${fmtCurrency(fuelCostToday)} spent today` })}
        />
        <KPI
          icon={Clock}
          label="Avg Delivery Time"
          value={`${Math.floor(avgDeliveryMin / 60)}h ${avgDeliveryMin % 60}m`}
          sub={`across ${routes.length} routes`}
          status="on-time"
          onClick={() => toast.info("Avg delivery time", { description: `${avgDeliveryMin} min average across ${routes.length} routes` })}
        />
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-[1.7fr_1fr] gap-4">
        {/* Line chart */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Activity size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Delivery Performance Trend</h3>
            </div>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>{days} days</span>
          </header>
          <div className="p-2">
            <ReactECharts option={lineOption} style={{ height: 260 }} />
          </div>
        </div>

        {/* Gauge */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Gauge size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">On-Time Gauge</h3>
            </div>
          </header>
          <div className="p-2">
            <ReactECharts option={gaugeOption} style={{ height: 260 }} />
          </div>
        </div>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Bar chart */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Building2 size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Warehouse Throughput</h3>
            </div>
            <span className="text-[10px] font-mono text-[var(--foreground-muted)]">units today</span>
          </header>
          <div className="p-2">
            <ReactECharts option={barOption} style={{ height: 260 }} />
          </div>
        </div>

        {/* Summary metrics */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <BarChart3 size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Fleet Status Breakdown</h3>
            </div>
          </header>
          <div className="p-4 space-y-3">
            {([
              { label: "On Time", value: onTimeCount, color: "var(--status-ontime)" },
              { label: "At Risk", value: vehicles.filter((v) => v.status === "at-risk").length, color: "var(--status-atrisk)" },
              { label: "Delayed", value: vehicles.filter((v) => v.status === "delayed").length, color: "var(--status-delayed)" },
              { label: "Maintenance", value: vehicles.filter((v) => v.status === "maintenance").length, color: "var(--status-maintenance)" },
              { label: "Offline", value: vehicles.filter((v) => v.status === "offline").length, color: "var(--status-offline)" },
            ]).map((row) => {
              const pct = vehicles.length > 0 ? (row.value / vehicles.length) * 100 : 0;
              return (
                <div key={row.label}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[12px] text-[var(--foreground-secondary)]">{row.label}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[12px] font-mono font-semibold text-[var(--foreground)]">{row.value}</span>
                      <span className="text-[10px] font-mono text-[var(--foreground-muted)]">{pct.toFixed(0)}%</span>
                    </div>
                  </div>
                  <div className="h-1.5 rounded-full" style={{ background: "var(--surface-hover)" }}>
                    <div className="h-full rounded-full" style={{ width: `${pct}%`, background: row.color }} />
                  </div>
                </div>
              );
            })}
            <div className="pt-2 mt-2 border-t flex items-center justify-between" style={{ borderColor: "var(--border)" }}>
              <span className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">Total fleet</span>
              <span className="text-[14px] font-mono font-bold text-[var(--foreground)]">{fmtNumber(vehicles.length)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Hex with alpha helper (if input is rgb/hsl, fall back)
function hexA(color: string, alpha: number): string {
  if (color.startsWith("#")) {
    const c = color.length === 4
      ? color.slice(1).split("").map((x) => x + x).join("")
      : color.slice(1);
    const r = parseInt(c.slice(0, 2), 16);
    const g = parseInt(c.slice(2, 4), 16);
    const b = parseInt(c.slice(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  // If not hex, return color-mix as a string (echarts may not fully support, but better than crashing)
  return color;
}
