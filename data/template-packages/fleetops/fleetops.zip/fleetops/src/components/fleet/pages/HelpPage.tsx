"use client";
import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import {
  LifeBuoy, Search, BookOpen, Video, MessageSquare, Zap,
  ChevronDown, ChevronRight, Send, Mail, Phone, MapPin,
  Clock, CheckCircle2, AlertCircle, ArrowRight,
} from "lucide-react";

const RESOURCES = [
  { id: "docs", title: "Documentation", description: "Comprehensive guides, API reference, and tutorials for every feature.", icon: BookOpen, cta: "Browse docs", href: "documentation" },
  { id: "videos", title: "Video Library", description: "Walkthroughs, onboarding sessions, and recorded training webinars.", icon: Video, cta: "Watch videos", href: "documentation" },
  { id: "community", title: "Community Forum", description: "Connect with other fleet operators, share tips, and get peer help.", icon: MessageSquare, cta: "Join community", href: "documentation" },
  { id: "api", title: "API Reference", description: "Integrate FleetOps with your stack using our REST and webhook APIs.", icon: Zap, cta: "View API", href: "documentation" },
];

const FAQS = [
  {
    id: "faq1",
    q: "How do I assign a vehicle to a dispatch order?",
    a: "Open the Dispatch Queue from the sidebar. For any unassigned order, click the Assign button — FleetOps will auto-match the best available vehicle and driver based on location, hours of service, and load compatibility. You can override the suggestion by selecting a specific vehicle from the dropdown.",
  },
  {
    id: "faq2",
    q: "What triggers a vehicle to be flagged as 'at-risk' or 'delayed'?",
    a: "Vehicles are automatically flagged as 'at-risk' when their ETA slips by more than 15 minutes past the planned window. 'Delayed' status is triggered when the slip exceeds 30 minutes, or when the driver reports an issue via the messages panel. You can tune these thresholds in Settings → Fleet.",
  },
  {
    id: "faq3",
    q: "How do I reroute a vehicle around traffic or weather?",
    a: "Click any vehicle on the Live Fleet map or table, then choose 'Reroute' from the actions menu. The routing engine will calculate an alternate path accounting for current traffic, weather, and your fuel-efficiency preferences. You'll see a comparison of the original vs. new route before confirming.",
  },
  {
    id: "faq4",
    q: "Can I export fleet data for offline analysis?",
    a: "Yes. Every list view (Fleet, Drivers, Routes, Warehouses, Dispatch) has an Export button in the toolbar that downloads a CSV. For scheduled reports, navigate to Analytics → Performance and use the Export PDF option to generate a printable executive summary.",
  },
  {
    id: "faq5",
    q: "How does the Hours of Service (HOS) tracking work?",
    a: "FleetOps tracks each driver's on-duty, off-duty, sleeper, and driving time per FMCSA rules. When a driver approaches the 11-hour driving limit or 14-hour on-duty limit, an alert is raised and visible in the Drivers → HOS view. The system will not auto-assign new dispatches to drivers with insufficient remaining hours.",
  },
  {
    id: "faq6",
    q: "What should I do during a system outage?",
    a: "If FleetOps is unreachable, check the System Status page (auto-refreshed every 60s). For active outages, our incident response team posts updates every 15 minutes. Critical operations (dispatch, driver messaging) have offline fallbacks — see the printed Continuity Playbook in your operations binder.",
  },
];

export function HelpPage() {
  const [search, setSearch] = useState("");
  const [openFaq, setOpenFaq] = useState<string | null>("faq1");
  const [form, setForm] = useState({ name: "", email: "", subject: "", priority: "medium" as "low" | "medium" | "high" | "critical", message: "" });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const filteredFaqs = useMemo(() => {
    if (!search) return FAQS;
    const q = search.toLowerCase();
    return FAQS.filter((f) => f.q.toLowerCase().includes(q) || f.a.toLowerCase().includes(q));
  }, [search]);

  const handleNav = (href: string) => {
    toast.info(`Opening ${href}`, { description: "Resource will load in the documentation viewer" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.subject.trim() || !form.message.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      toast.error("Please enter a valid email address");
      return;
    }
    if (form.message.trim().length < 20) {
      toast.error("Message must be at least 20 characters");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      toast.success("Support ticket submitted", { description: `Ticket #TKT-${Math.floor(Math.random() * 90000) + 10000} created` });
      setForm({ name: "", email: "", subject: "", priority: "medium", message: "" });
      setTimeout(() => setSubmitted(false), 5000);
    }, 1100);
  };

  return (
    <div className="p-5 space-y-4">
      {/* Hero search */}
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        <div className="px-6 py-8 text-center" style={{ background: "linear-gradient(135deg, var(--primary-soft) 0%, var(--surface) 100%)" }}>
          <div className="w-12 h-12 mx-auto rounded-[8px] flex items-center justify-center mb-3" style={{ background: "var(--primary)", color: "var(--background)" }}>
            <LifeBuoy size={22} />
          </div>
          <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight">How can we help?</h1>
          <p className="text-[12px] text-[var(--foreground-muted)] mt-1 max-w-md mx-auto">
            Search the knowledge base, browse FAQs, or contact our support team directly.
          </p>
          <div className="max-w-xl mx-auto mt-4 relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search for help articles, guides, or topics…"
              className="w-full h-10 pl-10 pr-4 text-[13px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none placeholder:text-[var(--foreground-muted)] text-[var(--foreground)]"
              style={{ borderColor: "var(--border-strong)" }}
              aria-label="Search help center"
            />
          </div>
          <div className="flex items-center justify-center gap-3 mt-3 text-[10px] font-mono text-[var(--foreground-muted)]">
            <span>Popular:</span>
            {["dispatch", "reroute", "HOS", "export"].map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => { setSearch(t); toast.info(`Searching: ${t}`); }}
                className="px-2 py-0.5 rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring hover:text-[var(--primary)]"
                style={{ borderColor: "var(--border)" }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Resource cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {RESOURCES.map((r) => {
          const Icon = r.icon;
          return (
            <button
              key={r.id}
              type="button"
              onClick={() => handleNav(r.href)}
              className="text-left rounded-[8px] border p-4 hover:border-[var(--border-strong)] transition-colors cursor-pointer focus-ring group"
              style={{ background: "var(--surface)", borderColor: "var(--border)" }}
            >
              <div className="w-9 h-9 rounded-[6px] flex items-center justify-center mb-3" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>
                <Icon size={16} />
              </div>
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">{r.title}</h3>
              <p className="text-[11px] text-[var(--foreground-muted)] mt-1 leading-relaxed">{r.description}</p>
              <div className="flex items-center gap-1 mt-3 text-[11px] font-medium text-[var(--primary)] group-hover:gap-2 transition-all">
                {r.cta} <ArrowRight size={11} />
              </div>
            </button>
          );
        })}
      </div>

      {/* FAQ + Contact form */}
      <div className="grid grid-cols-1 lg:grid-cols-[1.3fr_1fr] gap-4">
        {/* FAQ accordion */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <BookOpen size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Frequently Asked Questions</h3>
            </div>
            <span className="text-[10px] font-mono text-[var(--foreground-muted)]">{filteredFaqs.length} articles</span>
          </header>
          <div className="max-h-[560px] overflow-y-auto">
            {filteredFaqs.length === 0 && (
              <div className="px-4 py-10 text-center">
                <Search size={28} className="mx-auto text-[var(--foreground-muted)] opacity-40 mb-2" />
                <p className="text-[12px] text-[var(--foreground-muted)]">No articles match "{search}"</p>
                <button
                  type="button"
                  onClick={() => setSearch("")}
                  className="text-[11px] font-medium text-[var(--primary)] hover:underline mt-2 cursor-pointer focus-ring"
                >
                  Clear search
                </button>
              </div>
            )}
            {filteredFaqs.map((f) => {
              const open = openFaq === f.id;
              return (
                <div key={f.id} className="border-b last:border-0" style={{ borderColor: "var(--border)" }}>
                  <button
                    type="button"
                    onClick={() => setOpenFaq(open ? null : f.id)}
                    aria-expanded={open}
                    className="w-full flex items-center gap-2.5 px-4 py-3 text-left hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring outline-none"
                  >
                    {open ? <ChevronDown size={13} style={{ color: "var(--primary)" }} /> : <ChevronRight size={13} className="text-[var(--foreground-muted)]" />}
                    <span className={cn("text-[12px] flex-1", open ? "font-semibold text-[var(--foreground)]" : "font-medium text-[var(--foreground-secondary)]")}>{f.q}</span>
                  </button>
                  {open && (
                    <div className="px-4 pb-3 pl-10">
                      <p className="text-[12px] text-[var(--foreground-secondary)] leading-relaxed">{f.a}</p>
                      <div className="flex items-center gap-3 mt-2 pt-2 border-t" style={{ borderColor: "var(--border)" }}>
                        <span className="text-[10px] text-[var(--foreground-muted)]">Was this helpful?</span>
                        <button type="button" onClick={() => toast.success("Thanks for the feedback!")} className="text-[10px] font-medium px-2 py-0.5 rounded-[3px] border hover:bg-[var(--status-ontime-soft)] hover:text-[var(--status-ontime)] cursor-pointer focus-ring text-[var(--foreground-muted)]" style={{ borderColor: "var(--border)" }}>Yes</button>
                        <button type="button" onClick={() => toast.info("Thanks — we'll improve this article")} className="text-[10px] font-medium px-2 py-0.5 rounded-[3px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-muted)]" style={{ borderColor: "var(--border)" }}>No</button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Contact form */}
        <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <header className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2">
              <Mail size={15} style={{ color: "var(--primary)" }} />
              <h3 className="text-[13px] font-semibold text-[var(--foreground)]">Contact Support</h3>
            </div>
          </header>
          <form onSubmit={handleSubmit} className="p-4 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-medium text-[var(--foreground-secondary)] mb-1 block">Name *</label>
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full h-8 px-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none text-[var(--foreground)] placeholder:text-[var(--foreground-muted)]"
                  style={{ borderColor: "var(--border)" }}
                  placeholder="Your name"
                  required
                />
              </div>
              <div>
                <label className="text-[11px] font-medium text-[var(--foreground-secondary)] mb-1 block">Email *</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full h-8 px-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none text-[var(--foreground)] placeholder:text-[var(--foreground-muted)]"
                  style={{ borderColor: "var(--border)" }}
                  placeholder="you@company.com"
                  required
                />
              </div>
            </div>
            <div>
              <label className="text-[11px] font-medium text-[var(--foreground-secondary)] mb-1 block">Subject *</label>
              <input
                value={form.subject}
                onChange={(e) => setForm({ ...form, subject: e.target.value })}
                className="w-full h-8 px-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none text-[var(--foreground)] placeholder:text-[var(--foreground-muted)]"
                style={{ borderColor: "var(--border)" }}
                placeholder="Brief subject line"
                required
              />
            </div>
            <div>
              <label className="text-[11px] font-medium text-[var(--foreground-secondary)] mb-1 block">Priority</label>
              <div className="grid grid-cols-4 gap-1.5">
                {(["low", "medium", "high", "critical"] as const).map((p) => {
                  const active = form.priority === p;
                  const color = p === "critical" ? "var(--status-delayed)" : p === "high" ? "var(--status-atrisk)" : p === "medium" ? "var(--primary)" : "var(--status-offline)";
                  return (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setForm({ ...form, priority: p })}
                      aria-pressed={active}
                      className={cn("text-[10px] font-semibold uppercase tracking-wider px-2 py-1.5 rounded-[4px] border cursor-pointer focus-ring transition-colors")}
                      style={{
                        borderColor: active ? color : "var(--border)",
                        background: active ? `color-mix(in srgb, ${color} 12%, transparent)` : "transparent",
                        color: active ? color : "var(--foreground-muted)",
                      }}
                    >
                      {p}
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <label className="text-[11px] font-medium text-[var(--foreground-secondary)] mb-1 block">Message * <span className="text-[var(--foreground-muted)] font-normal">(min 20 chars)</span></label>
              <textarea
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                rows={5}
                className="w-full px-3 py-2 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none text-[var(--foreground)] placeholder:text-[var(--foreground-muted)] resize-none"
                style={{ borderColor: "var(--border)" }}
                placeholder="Describe your issue or question in detail…"
                required
              />
              <div className="text-[10px] font-mono text-[var(--foreground-muted)] mt-0.5 text-right">{form.message.length} chars</div>
            </div>
            <button
              type="submit"
              disabled={submitting || submitted}
              className="w-full h-9 text-[12px] font-semibold rounded-[6px] text-[var(--background)] cursor-pointer focus-ring flex items-center justify-center gap-1.5 disabled:opacity-60 disabled:cursor-not-allowed transition-colors"
              style={{ background: submitted ? "var(--status-ontime)" : "var(--primary)" }}
            >
              {submitted ? (<><CheckCircle2 size={13} /> Submitted!</>) : submitting ? (<><Clock size={13} /> Submitting…</>) : (<><Send size={13} /> Submit ticket</>)}
            </button>
            <p className="text-[10px] text-[var(--foreground-muted)] text-center flex items-center justify-center gap-1">
              <AlertCircle size={10} /> Average response time: 2 hours for high-priority tickets
            </p>
          </form>
        </div>
      </div>

      {/* Contact methods */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <ContactCard icon={Phone} label="Phone support" value="+1 (555) 482-1109" sub="Mon – Fri · 06:00 – 22:00 CST" onClick={() => toast.success("Call initiated", { description: "+1 (555) 482-1109" })} />
        <ContactCard icon={Mail} label="Email support" value="support@fleetops.command" sub="24/7 · response within 4 hours" onClick={() => toast.success("Email composer opened", { description: "support@fleetops.command" })} />
        <ContactCard icon={MapPin} label="HQ address" value="1420 Commerce St, Dallas TX" sub="Visit by appointment only" onClick={() => toast.info("Map opened", { description: "Dallas, TX headquarters" })} />
      </div>
    </div>
  );
}

function ContactCard({
  icon: Icon, label, value, sub, onClick,
}: {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  label: string;
  value: string;
  sub: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="text-left rounded-[8px] border p-3 hover:border-[var(--border-strong)] transition-colors cursor-pointer focus-ring flex items-start gap-3"
      style={{ background: "var(--surface)", borderColor: "var(--border)" }}
    >
      <div className="w-8 h-8 rounded-[6px] flex items-center justify-center shrink-0" style={{ background: "var(--primary-soft)", color: "var(--primary)" }}>
        <Icon size={14} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">{label}</div>
        <div className="text-[12px] font-semibold text-[var(--foreground)] truncate">{value}</div>
        <div className="text-[10px] font-mono text-[var(--foreground-muted)] mt-0.5">{sub}</div>
      </div>
      <ArrowRight size={12} className="text-[var(--foreground-muted)] mt-1.5" />
    </button>
  );
}
