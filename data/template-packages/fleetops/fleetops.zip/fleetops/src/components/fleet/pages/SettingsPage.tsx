"use client";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import {
  Settings, SlidersHorizontal, Palette, Bell, Truck, Route, Shield,
  Check, Sun, Moon, Monitor, Save, RotateCcw, KeyRound, Smartphone, LogOut,
} from "lucide-react";
import { ModernSelect } from "../ModernSelect";
import { NumberInput } from "../NumberInput";

type Section = "general" | "appearance" | "notifications" | "fleet" | "routing" | "security";

const SECTIONS: { id: Section; label: string; icon: React.ComponentType<{ size?: number; className?: string }> }[] = [
  { id: "general", label: "General", icon: SlidersHorizontal },
  { id: "appearance", label: "Appearance", icon: Palette },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "fleet", label: "Fleet", icon: Truck },
  { id: "routing", label: "Routing", icon: Route },
  { id: "security", label: "Security", icon: Shield },
];

export function SettingsPage() {
  const [section, setSection] = useState<Section>("general");

  return (
    <div className="p-5">
      <div className="mb-4">
        <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight flex items-center gap-2">
          <Settings size={20} style={{ color: "var(--primary)" }} />
          Settings
        </h1>
        <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">
          Configure FleetOps Command Center to match your operational needs
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4">
        {/* Sub-nav */}
        <nav className="rounded-[8px] border overflow-hidden h-fit" style={{ borderColor: "var(--border)", background: "var(--surface)" }} aria-label="Settings sections">
          <ul className="p-1.5 space-y-px">
            {SECTIONS.map((s) => {
              const Icon = s.icon;
              const active = section === s.id;
              return (
                <li key={s.id}>
                  <button
                    type="button"
                    onClick={() => setSection(s.id)}
                    aria-current={active ? "page" : undefined}
                    className={cn(
                      "w-full flex items-center gap-2.5 px-2.5 py-2 rounded-[6px] text-[12px] font-medium transition-colors cursor-pointer focus-ring",
                      active ? "text-[var(--primary)]" : "text-[var(--foreground-secondary)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]"
                    )}
                    style={active ? { background: "var(--primary-soft)" } : undefined}
                  >
                    <Icon size={14} className="shrink-0" />
                    <span className="flex-1 text-left">{s.label}</span>
                    {active && <span className="w-0.5 h-4 rounded-full" style={{ background: "var(--primary)" }} />}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Content */}
        <div>
          {section === "general" && <GeneralSection />}
          {section === "appearance" && <AppearanceSection />}
          {section === "notifications" && <NotificationsSection />}
          {section === "fleet" && <FleetSection />}
          {section === "routing" && <RoutingSection />}
          {section === "security" && <SecuritySection />}
        </div>
      </div>
    </div>
  );
}

// ============== Shared bits ==============

function SettingsCard({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
      <header className="px-4 py-2.5 border-b" style={{ borderColor: "var(--border)" }}>
        <h3 className="text-[13px] font-semibold text-[var(--foreground)]">{title}</h3>
        {description && <p className="text-[11px] text-[var(--foreground-muted)] mt-0.5">{description}</p>}
      </header>
      <div className="p-4 space-y-3">{children}</div>
    </div>
  );
}

function ToggleRow({
  label, description, checked, onChange,
}: {
  label: string;
  description?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-3 py-1.5">
      <div className="flex-1 min-w-0">
        <div className="text-[12px] font-medium text-[var(--foreground)]">{label}</div>
        {description && <div className="text-[10px] text-[var(--foreground-muted)]">{description}</div>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={() => onChange(!checked)}
        className="relative w-9 h-5 rounded-full transition-colors cursor-pointer focus-ring shrink-0"
        style={{ background: checked ? "var(--primary)" : "var(--surface-hover)", border: "1px solid var(--border-strong)" }}
      >
        <span
          className="absolute top-0.5 w-3.5 h-3.5 rounded-full bg-white transition-transform"
          style={{ left: "2px", transform: checked ? "translateX(16px)" : "translateX(0)" }}
        />
      </button>
    </div>
  );
}

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div>
      <label className="text-[11px] font-medium text-[var(--foreground-secondary)] mb-1 block">{label}</label>
      {children}
      {hint && <p className="text-[10px] text-[var(--foreground-muted)] mt-1">{hint}</p>}
    </div>
  );
}

function inputCls(extra?: string) {
  return cn(
    "w-full h-8 px-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none text-[var(--foreground)] placeholder:text-[var(--foreground-muted)]",
    extra
  );
}

function SaveBar({ onSave, onReset }: { onSave: () => void; onReset: () => void }) {
  return (
    <div className="flex items-center justify-end gap-2 pt-2 mt-2 border-t" style={{ borderColor: "var(--border)" }}>
      <button
        type="button"
        onClick={onReset}
        className="h-8 px-3 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5 text-[var(--foreground-secondary)]"
        style={{ borderColor: "var(--border)" }}
      >
        <RotateCcw size={13} /> Reset
      </button>
      <button
        type="button"
        onClick={onSave}
        className="h-8 px-3 text-[12px] font-semibold rounded-[6px] text-[var(--background)] cursor-pointer focus-ring flex items-center gap-1.5"
        style={{ background: "var(--primary)" }}
      >
        <Save size={13} /> Save changes
      </button>
    </div>
  );
}

// ============== Sections ==============

function GeneralSection() {
  const [orgName, setOrgName] = useState("FleetOps Command Center");
  const [timezone, setTimezone] = useState("America/Chicago");
  const [units, setUnits] = useState<"imperial" | "metric">("imperial");
  const [language, setLanguage] = useState("en-US");
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState("30");

  const save = () => toast.success("General settings saved", { description: "Configuration updated successfully" });
  const reset = () => {
    setOrgName("FleetOps Command Center");
    setTimezone("America/Chicago");
    setUnits("imperial");
    setLanguage("en-US");
    setAutoRefresh(true);
    setRefreshInterval("30");
    toast.info("Reset to defaults");
  };

  return (
    <div className="space-y-4">
      <SettingsCard title="Organization" description="Basic organization details">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Field label="Organization name">
            <input value={orgName} onChange={(e) => setOrgName(e.target.value)} className={inputCls()} />
          </Field>
          <Field label="Language">
            <ModernSelect
              value={language}
              onValueChange={setLanguage}
              size="sm"
              ariaLabel="Language"
              className="w-full"
              options={[
                { value: "en-US", label: "English (US)" },
                { value: "en-GB", label: "English (UK)" },
                { value: "es-ES", label: "Spanish" },
                { value: "fr-FR", label: "French" },
              ]}
            />
          </Field>
          <Field label="Timezone">
            <ModernSelect
              value={timezone}
              onValueChange={setTimezone}
              size="sm"
              ariaLabel="Timezone"
              className="w-full"
              options={[
                { value: "America/Chicago", label: "America/Chicago (CST)" },
                { value: "America/New_York", label: "America/New_York (EST)" },
                { value: "America/Los_Angeles", label: "America/Los_Angeles (PST)" },
                { value: "America/Denver", label: "America/Denver (MST)" },
                { value: "UTC", label: "UTC" },
              ]}
            />
          </Field>
          <Field label="Measurement units">
            <ModernSelect
              value={units}
              onValueChange={(v) => setUnits(v as "imperial" | "metric")}
              size="sm"
              ariaLabel="Measurement units"
              className="w-full"
              options={[
                { value: "imperial", label: "Imperial (mi, lbs, gal)" },
                { value: "metric", label: "Metric (km, kg, L)" },
              ]}
            />
          </Field>
        </div>
      </SettingsCard>

      <SettingsCard title="Display" description="Real-time data behavior">
        <ToggleRow label="Auto-refresh dashboard" description="Update fleet data automatically" checked={autoRefresh} onChange={(v) => { setAutoRefresh(v); toast.success(`Auto-refresh ${v ? "enabled" : "disabled"}`); }} />
        <Field label="Refresh interval (seconds)" hint="How often to poll for new data when auto-refresh is on">
          <NumberInput value={refreshInterval} onChange={setRefreshInterval} min={5} max={300} suffix="sec" disabled={!autoRefresh} className="w-full" ariaLabel="Refresh interval" />
        </Field>
        <SaveBar onSave={save} onReset={reset} />
      </SettingsCard>
    </div>
  );
}

function AppearanceSection() {
  const [theme, setTheme] = useState<"dark" | "light" | "system">("dark");
  const [density, setDensity] = useState<"comfortable" | "compact">("comfortable");
  const [reducedMotion, setReducedMotion] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [showSeconds, setShowSeconds] = useState(true);

  const save = () => toast.success("Appearance saved", { description: "Theme and density updated" });
  const reset = () => {
    setTheme("dark");
    setDensity("comfortable");
    setReducedMotion(false);
    setHighContrast(false);
    setShowSeconds(true);
    toast.info("Reset to defaults");
  };

  const themes: { id: "dark" | "light" | "system"; label: string; icon: React.ComponentType<{ size?: number }> }[] = [
    { id: "dark", label: "Dark", icon: Moon },
    { id: "light", label: "Light", icon: Sun },
    { id: "system", label: "System", icon: Monitor },
  ];

  return (
    <SettingsCard title="Appearance" description="Customize how FleetOps looks on your device">
      <Field label="Theme">
        <div className="grid grid-cols-3 gap-2 max-w-md">
          {themes.map((t) => {
            const Icon = t.icon;
            const active = theme === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => { setTheme(t.id); toast.success(`Theme: ${t.label}`); }}
                aria-pressed={active}
                className={cn(
                  "flex flex-col items-center gap-1.5 p-3 rounded-[6px] border cursor-pointer focus-ring transition-colors",
                  active ? "text-[var(--primary)]" : "text-[var(--foreground-secondary)] hover:bg-[var(--surface-hover)]"
                )}
                style={active ? { borderColor: "var(--primary)", background: "var(--primary-soft)" } : { borderColor: "var(--border)" }}
              >
                <Icon size={18} />
                <span className="text-[11px] font-medium">{t.label}</span>
                {active && <Check size={11} />}
              </button>
            );
          })}
        </div>
      </Field>

      <Field label="Layout density">
        <div className="grid grid-cols-2 gap-2 max-w-md">
          {(["comfortable", "compact"] as const).map((d) => {
            const active = density === d;
            return (
              <button
                key={d}
                type="button"
                onClick={() => { setDensity(d); toast.success(`Density: ${d}`); }}
                aria-pressed={active}
                className={cn(
                  "p-2.5 rounded-[6px] border cursor-pointer focus-ring transition-colors text-left",
                  active ? "text-[var(--primary)]" : "text-[var(--foreground-secondary)] hover:bg-[var(--surface-hover)]"
                )}
                style={active ? { borderColor: "var(--primary)", background: "var(--primary-soft)" } : { borderColor: "var(--border)" }}
              >
                <div className="text-[12px] font-medium capitalize">{d}</div>
                <div className="text-[10px] text-[var(--foreground-muted)] mt-0.5">
                  {d === "comfortable" ? "More breathing room" : "More data per screen"}
                </div>
              </button>
            );
          })}
        </div>
      </Field>

      <ToggleRow label="Reduce motion" description="Minimize animations and transitions" checked={reducedMotion} onChange={(v) => { setReducedMotion(v); toast.success(`Reduced motion ${v ? "on" : "off"}`); }} />
      <ToggleRow label="High contrast" description="Increase contrast for accessibility" checked={highContrast} onChange={(v) => { setHighContrast(v); toast.success(`High contrast ${v ? "on" : "off"}`); }} />
      <ToggleRow label="Show seconds in clock" description="Display HH:MM:SS in the top bar" checked={showSeconds} onChange={(v) => { setShowSeconds(v); toast.success(`Seconds ${v ? "shown" : "hidden"}`); }} />
      <SaveBar onSave={save} onReset={reset} />
    </SettingsCard>
  );
}

function NotificationsSection() {
  const [email, setEmail] = useState(true);
  const [push, setPush] = useState(true);
  const [sms, setSms] = useState(false);
  const [criticalOnly, setCriticalOnly] = useState(false);
  const [digest, setDigest] = useState(true);
  const [categories, setCategories] = useState({
    critical: true, dispatch: true, fleet: true, drivers: false, warehouses: true, system: true,
  });

  const save = () => toast.success("Notification preferences saved");
  const reset = () => {
    setEmail(true); setPush(true); setSms(false); setCriticalOnly(false); setDigest(true);
    setCategories({ critical: true, dispatch: true, fleet: true, drivers: false, warehouses: true, system: true });
    toast.info("Reset to defaults");
  };

  const toggleCat = (key: keyof typeof categories) => {
    setCategories((c) => ({ ...c, [key]: !c[key] }));
  };

  return (
    <div className="space-y-4">
      <SettingsCard title="Delivery channels" description="Choose how you receive notifications">
        <ToggleRow label="Email" description="Daily digest + real-time alerts" checked={email} onChange={(v) => { setEmail(v); toast.success(`Email ${v ? "on" : "off"}`); }} />
        <ToggleRow label="Push" description="Browser push notifications" checked={push} onChange={(v) => { setPush(v); toast.success(`Push ${v ? "on" : "off"}`); }} />
        <ToggleRow label="SMS" description="Critical alerts via text message" checked={sms} onChange={(v) => { setSms(v); toast.success(`SMS ${v ? "on" : "off"}`); }} />
        <ToggleRow label="Critical only" description="Suppress non-critical notifications" checked={criticalOnly} onChange={(v) => { setCriticalOnly(v); toast.success(`Critical-only ${v ? "on" : "off"}`); }} />
        <ToggleRow label="Daily digest email" description="One summary email at 08:00" checked={digest} onChange={(v) => { setDigest(v); toast.success(`Digest ${v ? "on" : "off"}`); }} />
      </SettingsCard>

      <SettingsCard title="Categories" description="Pick which categories trigger notifications">
        <div className="grid grid-cols-2 gap-2">
          {([
            { key: "critical", label: "Critical alerts" },
            { key: "dispatch", label: "Dispatch updates" },
            { key: "fleet", label: "Fleet events" },
            { key: "drivers", label: "Driver activity" },
            { key: "warehouses", label: "Warehouse events" },
            { key: "system", label: "System & outages" },
          ] as const).map((c) => (
            <button
              key={c.key}
              type="button"
              onClick={() => { toggleCat(c.key); toast.success(`${c.label} ${categories[c.key] ? "disabled" : "enabled"}`); }}
              className={cn(
                "flex items-center justify-between p-2.5 rounded-[6px] border cursor-pointer focus-ring transition-colors text-left",
                categories[c.key] ? "text-[var(--primary)]" : "text-[var(--foreground-muted)]"
              )}
              style={categories[c.key] ? { borderColor: "var(--primary)", background: "var(--primary-soft)" } : { borderColor: "var(--border)" }}
            >
              <span className="text-[12px] font-medium">{c.label}</span>
              <span
                className="w-4 h-4 rounded-[3px] flex items-center justify-center"
                style={{ background: categories[c.key] ? "var(--primary)" : "var(--surface-hover)", color: "var(--background)" }}
              >
                {categories[c.key] && <Check size={11} />}
              </span>
            </button>
          ))}
        </div>
        <SaveBar onSave={save} onReset={reset} />
      </SettingsCard>
    </div>
  );
}

function FleetSection() {
  const [trackOffline, setTrackOffline] = useState(true);
  const [autoFlag, setAutoFlag] = useState(true);
  const [fuelThreshold, setFuelThreshold] = useState("25");
  const [idleTimeout, setIdleTimeout] = useState("15");
  const [defaultRegion, setDefaultRegion] = useState("Texas");
  const [maintenanceWindow, setMaintenanceWindow] = useState("overnight");

  const save = () => toast.success("Fleet settings saved");
  const reset = () => {
    setTrackOffline(true); setAutoFlag(true); setFuelThreshold("25"); setIdleTimeout("15");
    setDefaultRegion("Texas"); setMaintenanceWindow("overnight");
    toast.info("Reset to defaults");
  };

  return (
    <SettingsCard title="Fleet configuration" description="Tune how the fleet is monitored and flagged">
      <ToggleRow label="Track offline vehicles" description="Keep last-known position visible" checked={trackOffline} onChange={(v) => { setTrackOffline(v); toast.success(`Offline tracking ${v ? "on" : "off"}`); }} />
      <ToggleRow label="Auto-flag at-risk vehicles" description="Mark vehicles as at-risk when ETA slips" checked={autoFlag} onChange={(v) => { setAutoFlag(v); toast.success(`Auto-flag ${v ? "on" : "off"}`); }} />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
        <Field label="Low fuel threshold (%)" hint="Trigger alert when fuel drops below this level">
          <NumberInput value={fuelThreshold} onChange={setFuelThreshold} min={5} max={50} suffix="%" className="w-full" ariaLabel="Low fuel threshold" />
        </Field>
        <Field label="Idle timeout (minutes)" hint="Flag vehicles idle longer than this">
          <NumberInput value={idleTimeout} onChange={setIdleTimeout} min={5} max={120} suffix="min" className="w-full" ariaLabel="Idle timeout" />
        </Field>
        <Field label="Default region">
          <ModernSelect
            value={defaultRegion}
            onValueChange={setDefaultRegion}
            size="sm"
            ariaLabel="Default region"
            className="w-full"
            options={[
              { value: "Texas", label: "Texas" },
              { value: "Pacific Northwest", label: "Pacific Northwest" },
              { value: "Southwest", label: "Southwest" },
              { value: "Midwest", label: "Midwest" },
              { value: "Southeast", label: "Southeast" },
              { value: "Northeast", label: "Northeast" },
            ]}
          />
        </Field>
        <Field label="Preferred maintenance window">
          <ModernSelect
            value={maintenanceWindow}
            onValueChange={setMaintenanceWindow}
            size="sm"
            ariaLabel="Preferred maintenance window"
            className="w-full"
            options={[
              { value: "overnight", label: "Overnight (22:00 – 06:00)" },
              { value: "weekend", label: "Weekend (Sat – Sun)" },
              { value: "anytime", label: "Anytime" },
            ]}
          />
        </Field>
      </div>
      <SaveBar onSave={save} onReset={reset} />
    </SettingsCard>
  );
}

function RoutingSection() {
  const [avoidTolls, setAvoidTolls] = useState(false);
  const [avoidHighways, setAvoidHighways] = useState(false);
  const [preferFuelEfficient, setPreferFuelEfficient] = useState(true);
  const [maxDrivingHours, setMaxDrivingHours] = useState("11");
  const [routeAlgo, setRouteAlgo] = useState("balanced");
  const [trafficAware, setTrafficAware] = useState(true);

  const save = () => toast.success("Routing settings saved");
  const reset = () => {
    setAvoidTolls(false); setAvoidHighways(false); setPreferFuelEfficient(true);
    setMaxDrivingHours("11"); setRouteAlgo("balanced"); setTrafficAware(true);
    toast.info("Reset to defaults");
  };

  return (
    <SettingsCard title="Routing engine" description="Optimize how routes are calculated">
      <Field label="Routing algorithm">
        <ModernSelect
          value={routeAlgo}
          onValueChange={setRouteAlgo}
          size="sm"
          ariaLabel="Routing algorithm"
          className="max-w-xs"
          options={[
            { value: "balanced", label: "Balanced (time + fuel)" },
            { value: "fastest", label: "Fastest (time only)" },
            { value: "efficient", label: "Most fuel-efficient" },
            { value: "shortest", label: "Shortest distance" },
          ]}
        />
      </Field>

      <ToggleRow label="Avoid tolls" description="Skip toll roads where possible" checked={avoidTolls} onChange={(v) => { setAvoidTolls(v); toast.success(`Avoid tolls ${v ? "on" : "off"}`); }} />
      <ToggleRow label="Avoid highways" description="Prefer surface streets" checked={avoidHighways} onChange={(v) => { setAvoidHighways(v); toast.success(`Avoid highways ${v ? "on" : "off"}`); }} />
      <ToggleRow label="Prefer fuel-efficient routes" description="Optimize for MPG over speed" checked={preferFuelEfficient} onChange={(v) => { setPreferFuelEfficient(v); toast.success(`Fuel-efficient routing ${v ? "on" : "off"}`); }} />
      <ToggleRow label="Traffic-aware routing" description="Re-route around congestion in real time" checked={trafficAware} onChange={(v) => { setTrafficAware(v); toast.success(`Traffic-aware ${v ? "on" : "off"}`); }} />

      <Field label="Max driving hours per shift" hint="Per FMCSA Hours of Service rules">
        <NumberInput value={maxDrivingHours} onChange={setMaxDrivingHours} min={1} max={14} suffix="hrs" className="max-w-xs" ariaLabel="Max driving hours per shift" />
      </Field>

      <SaveBar onSave={save} onReset={reset} />
    </SettingsCard>
  );
}

function SecuritySection() {
  const [mfa, setMfa] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState("60");
  const [ipWhitelist, setIpWhitelist] = useState(false);
  const [auditLog, setAuditLog] = useState(true);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const changePassword = () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error("All password fields required");
      return;
    }
    if (newPassword.length < 8) {
      toast.error("New password must be at least 8 characters");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    toast.success("Password changed", { description: "Use the new password on next login" });
    setCurrentPassword(""); setNewPassword(""); setConfirmPassword("");
  };

  const save = () => toast.success("Security settings saved");
  const reset = () => {
    setMfa(true); setSessionTimeout("60"); setIpWhitelist(false); setAuditLog(true);
    toast.info("Reset to defaults");
  };

  return (
    <div className="space-y-4">
      <SettingsCard title="Authentication" description="Secure access to your account">
        <ToggleRow label="Multi-factor authentication" description="Require code on new devices" checked={mfa} onChange={(v) => { setMfa(v); toast.success(`MFA ${v ? "enabled" : "disabled"}`); }} />
        <Field label="Session timeout (minutes)" hint="Auto sign-out after this period of inactivity">
          <NumberInput value={sessionTimeout} onChange={setSessionTimeout} min={5} max={480} suffix="min" className="max-w-xs" ariaLabel="Session timeout" />
        </Field>
        <ToggleRow label="IP whitelist" description="Restrict access to known IPs only" checked={ipWhitelist} onChange={(v) => { setIpWhitelist(v); toast.success(`IP whitelist ${v ? "enabled" : "disabled"}`); }} />
        <ToggleRow label="Audit log" description="Track all user actions for compliance" checked={auditLog} onChange={(v) => { setAuditLog(v); toast.success(`Audit log ${v ? "enabled" : "disabled"}`); }} />
        <SaveBar onSave={save} onReset={reset} />
      </SettingsCard>

      <SettingsCard title="Change password" description="Use a strong, unique password">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <Field label="Current password">
            <input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className={inputCls()} placeholder="••••••••" />
          </Field>
          <Field label="New password">
            <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className={inputCls()} placeholder="Min 8 characters" />
          </Field>
          <Field label="Confirm new password">
            <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className={inputCls()} placeholder="Repeat new password" />
          </Field>
        </div>
        <div className="flex items-center justify-between pt-2 border-t" style={{ borderColor: "var(--border)" }}>
          <span className="text-[10px] text-[var(--foreground-muted)] flex items-center gap-1">
            <KeyRound size={10} /> Tip: use a passphrase you can remember
          </span>
          <button
            type="button"
            onClick={changePassword}
            className="h-8 px-3 text-[12px] font-semibold rounded-[6px] text-[var(--background)] cursor-pointer focus-ring flex items-center gap-1.5"
            style={{ background: "var(--primary)" }}
          >
            <KeyRound size={13} /> Update password
          </button>
        </div>
      </SettingsCard>

      <SettingsCard title="Sessions" description="Manage active sessions across devices">
        <div className="flex items-center justify-between p-2 rounded-[4px]" style={{ background: "var(--surface-elevated)" }}>
          <div className="flex items-center gap-2">
            <Smartphone size={14} style={{ color: "var(--status-ontime)" }} />
            <div>
              <div className="text-[12px] font-medium text-[var(--foreground)]">MacBook Pro · Chrome</div>
              <div className="text-[10px] font-mono text-[var(--foreground-muted)]">Dallas, TX · Active now</div>
            </div>
          </div>
          <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-[3px]" style={{ background: "var(--status-ontime-soft)", color: "var(--status-ontime)" }}>CURRENT</span>
        </div>
        <button
          type="button"
          onClick={() => toast.success("Signed out everywhere", { description: "All other sessions revoked" })}
          className="w-full h-8 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--status-delayed-soft)] hover:text-[var(--status-delayed)] cursor-pointer focus-ring flex items-center justify-center gap-1.5 text-[var(--foreground-secondary)]"
          style={{ borderColor: "var(--border)" }}
        >
          <LogOut size={13} /> Sign out of all other sessions
        </button>
      </SettingsCard>
    </div>
  );
}
