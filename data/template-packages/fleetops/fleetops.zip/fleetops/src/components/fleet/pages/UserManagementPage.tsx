"use client";
import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { NOW, fmtRelative } from "@/lib/fleet/format";
import {
  UserCog, Search, UserPlus, MoreHorizontal, Shield, Trash2, Pencil,
  Check, X, Mail, Download, Lock, Users,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ModernSelect } from "../ModernSelect";

interface User {
  id: string;
  name: string;
  email: string;
  role: "Administrator" | "Operations Director" | "Dispatcher" | "Driver Manager" | "Warehouse Lead" | "Analyst" | "Read-only";
  team: string;
  status: "active" | "invited" | "disabled";
  lastLogin: string | null;
  initials: string;
}

const SEED_USERS: User[] = [
  { id: "u1", name: "Daniel Kowalski", email: "d.kowalski@fleetops.command", role: "Operations Director", team: "Network Operations", status: "active", lastLogin: new Date(NOW - 4 * 60000).toISOString(), initials: "DK" },
  { id: "u2", name: "Sarah Chen", email: "s.chen@fleetops.command", role: "Administrator", team: "IT", status: "active", lastLogin: new Date(NOW - 38 * 60000).toISOString(), initials: "SC" },
  { id: "u3", name: "Marcus Johnson", email: "m.johnson@fleetops.command", role: "Dispatcher", team: "Day Dispatch", status: "active", lastLogin: new Date(NOW - 12 * 60000).toISOString(), initials: "MJ" },
  { id: "u4", name: "Patricia Brown", email: "p.brown@fleetops.command", role: "Driver Manager", team: "Driver Operations", status: "active", lastLogin: new Date(NOW - 2 * 3600000).toISOString(), initials: "PB" },
  { id: "u5", name: "Robert Davis", email: "r.davis@fleetops.command", role: "Warehouse Lead", team: "Dallas DC", status: "active", lastLogin: new Date(NOW - 6 * 3600000).toISOString(), initials: "RD" },
  { id: "u6", name: "Linda Martinez", email: "l.martinez@fleetops.command", role: "Analyst", team: "Performance Analytics", status: "active", lastLogin: new Date(NOW - 26 * 3600000).toISOString(), initials: "LM" },
  { id: "u7", name: "Michael Wilson", email: "m.wilson@fleetops.command", role: "Dispatcher", team: "Night Dispatch", status: "active", lastLogin: new Date(NOW - 8 * 3600000).toISOString(), initials: "MW" },
  { id: "u8", name: "Jennifer Taylor", email: "j.taylor@fleetops.command", role: "Driver Manager", team: "Driver Operations", status: "invited", lastLogin: null, initials: "JT" },
  { id: "u9", name: "Christopher Lee", email: "c.lee@fleetops.command", role: "Warehouse Lead", team: "Phoenix DC", status: "active", lastLogin: new Date(NOW - 12 * 3600000).toISOString(), initials: "CL" },
  { id: "u10", name: "Barbara White", email: "b.white@fleetops.command", role: "Read-only", team: "Compliance", status: "active", lastLogin: new Date(NOW - 3 * 86400000).toISOString(), initials: "BW" },
  { id: "u11", name: "Anthony Moore", email: "a.moore@fleetops.command", role: "Dispatcher", team: "Day Dispatch", status: "disabled", lastLogin: new Date(NOW - 18 * 86400000).toISOString(), initials: "AM" },
  { id: "u12", name: "Karen Allen", email: "k.allen@fleetops.command", role: "Analyst", team: "Performance Analytics", status: "active", lastLogin: new Date(NOW - 5 * 3600000).toISOString(), initials: "KA" },
];

const ROLES: User["role"][] = ["Administrator", "Operations Director", "Dispatcher", "Driver Manager", "Warehouse Lead", "Analyst", "Read-only"];

const STATUS_META: Record<User["status"], { label: string; color: string; soft: string }> = {
  active: { label: "Active", color: "var(--status-ontime)", soft: "var(--status-ontime-soft)" },
  invited: { label: "Invited", color: "var(--status-atrisk)", soft: "var(--status-atrisk-soft)" },
  disabled: { label: "Disabled", color: "var(--status-offline)", soft: "var(--status-offline-soft)" },
};

const ROLE_COLORS: Record<User["role"], string> = {
  "Administrator": "var(--status-delayed)",
  "Operations Director": "var(--primary)",
  "Dispatcher": "var(--status-ontime)",
  "Driver Manager": "var(--accent)",
  "Warehouse Lead": "var(--status-atrisk)",
  "Analyst": "var(--status-maintenance)",
  "Read-only": "var(--foreground-muted)",
};

export function UserManagementPage() {
  const [users, setUsers] = useState<User[]>(SEED_USERS);
  const [query, setQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const filtered = useMemo(() => {
    return users.filter((u) => {
      const matchesQuery =
        !query ||
        u.name.toLowerCase().includes(query.toLowerCase()) ||
        u.email.toLowerCase().includes(query.toLowerCase()) ||
        u.team.toLowerCase().includes(query.toLowerCase());
      const matchesRole = roleFilter === "all" || u.role === roleFilter;
      const matchesStatus = statusFilter === "all" || u.status === statusFilter;
      return matchesQuery && matchesRole && matchesStatus;
    });
  }, [users, query, roleFilter, statusFilter]);

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };
  const toggleSelectAll = () => {
    if (selected.size === filtered.length) setSelected(new Set());
    else setSelected(new Set(filtered.map((u) => u.id)));
  };

  const handleInvite = () => {
    const id = `u${users.length + 1}`;
    const newUser: User = {
      id,
      name: "New User",
      email: `new.user${users.length + 1}@fleetops.command`,
      role: "Dispatcher",
      team: "Day Dispatch",
      status: "invited",
      lastLogin: null,
      initials: "NU",
    };
    setUsers([newUser, ...users]);
    toast.success("Invitation sent", { description: `Email sent to ${newUser.email}` });
  };

  const handleRoleChange = (u: User, newRole: User["role"]) => {
    setUsers((us) => us.map((x) => (x.id === u.id ? { ...x, role: newRole } : x)));
    toast.success("Role updated", { description: `${u.name} is now ${newRole}` });
  };

  const handleDisable = (u: User) => {
    const next = u.status === "disabled" ? "active" : "disabled";
    setUsers((us) => us.map((x) => (x.id === u.id ? { ...x, status: next } : x)));
    toast.success(next === "disabled" ? "User disabled" : "User reactivated", { description: u.name });
  };

  const handleResendInvite = (u: User) => {
    toast.success("Invitation resent", { description: u.email });
  };

  const handleDelete = (u: User) => {
    setUsers((us) => us.filter((x) => x.id !== u.id));
    setSelected((prev) => { const n = new Set(prev); n.delete(u.id); return n; });
    toast.success("User deleted", { description: u.name });
  };

  const handleBulkDisable = () => {
    setUsers((us) => us.map((x) => (selected.has(x.id) ? { ...x, status: "disabled" } : x)));
    toast.success(`${selected.size} users disabled`);
    setSelected(new Set());
  };

  const handleBulkRole = () => {
    toast.info("Bulk role change", { description: `${selected.size} users selected — choose role in dialog (mock)` });
  };

  const handleBulkExport = () => {
    toast.success("Export started", { description: `${selected.size} users exporting to CSV` });
  };

  const handleExportAll = () => {
    toast.success("Export started", { description: `${users.length} users exporting to CSV` });
  };

  const counts = {
    total: users.length,
    active: users.filter((u) => u.status === "active").length,
    invited: users.filter((u) => u.status === "invited").length,
    disabled: users.filter((u) => u.status === "disabled").length,
    admins: users.filter((u) => u.role === "Administrator" || u.role === "Operations Director").length,
  };

  return (
    <div className="p-5 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[22px] font-bold text-[var(--foreground)] tracking-tight flex items-center gap-2">
            <UserCog size={20} style={{ color: "var(--primary)" }} />
            User Management
          </h1>
          <p className="text-[12px] text-[var(--foreground-muted)] mt-0.5">
            {counts.total} users · {counts.active} active · {counts.invited} invited · {counts.disabled} disabled · {counts.admins} admins
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportAll}
            className="h-8 px-3 text-[12px] font-medium rounded-[6px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring flex items-center gap-1.5 text-[var(--foreground-secondary)]"
            style={{ borderColor: "var(--border)" }}
          >
            <Download size={13} /> Export
          </button>
          <button
            type="button"
            onClick={handleInvite}
            className="h-8 px-3 text-[12px] font-semibold rounded-[6px] text-[var(--background)] cursor-pointer focus-ring flex items-center gap-1.5"
            style={{ background: "var(--primary)" }}
          >
            <UserPlus size={13} /> Invite user
          </button>
        </div>
      </div>

      {/* Bulk action bar */}
      {selected.size > 0 && (
        <div className="flex items-center gap-3 px-3 py-2 rounded-[6px] border" style={{ background: "var(--primary-soft)", borderColor: "var(--primary)" }}>
          <span className="text-[12px] font-semibold text-[var(--primary)]">{selected.size} selected</span>
          <div className="flex items-center gap-2 ml-auto">
            <button type="button" onClick={handleBulkRole} className="px-2.5 py-1 text-[11px] font-medium rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground)] flex items-center gap-1.5" style={{ borderColor: "var(--border)" }}><Shield size={11} /> Change role</button>
            <button type="button" onClick={handleBulkDisable} className="px-2.5 py-1 text-[11px] font-medium rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground)] flex items-center gap-1.5" style={{ borderColor: "var(--border)" }}><Lock size={11} /> Disable</button>
            <button type="button" onClick={handleBulkExport} className="px-2.5 py-1 text-[11px] font-medium rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground)] flex items-center gap-1.5" style={{ borderColor: "var(--border)" }}><Download size={11} /> Export</button>
            <button type="button" onClick={() => { setSelected(new Set()); toast.info("Selection cleared"); }} className="px-2.5 py-1 text-[11px] font-medium rounded-[4px] hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--foreground-muted)]">Clear</button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="rounded-[8px] border overflow-hidden" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
        {/* Toolbar */}
        <div className="flex items-center gap-2 px-3 py-2 border-b flex-wrap" style={{ borderColor: "var(--border)" }}>
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--foreground-muted)] pointer-events-none" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search users…"
              className="w-full h-8 pl-8 pr-3 text-[12px] rounded-[6px] border bg-[var(--background)] focus-ring outline-none placeholder:text-[var(--foreground-muted)] text-[var(--foreground)]"
              style={{ borderColor: "var(--border)" }}
              aria-label="Search users"
            />
          </div>
          <ModernSelect
            value={roleFilter}
            onValueChange={setRoleFilter}
            size="sm"
            ariaLabel="Filter by role"
            options={[
              { value: "all", label: "All roles" },
              ...ROLES.map((r) => ({ value: r, label: r })),
            ]}
          />
          <ModernSelect
            value={statusFilter}
            onValueChange={setStatusFilter}
            size="sm"
            ariaLabel="Filter by status"
            options={[
              { value: "all", label: "All statuses" },
              { value: "active", label: "Active" },
              { value: "invited", label: "Invited" },
              { value: "disabled", label: "Disabled" },
            ]}
          />
          <span className="ml-auto text-[11px] font-mono text-[var(--foreground-muted)]">{filtered.length} shown</span>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="border-b" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
                <th className="px-3 py-2 w-10">
                  <input
                    type="checkbox"
                    checked={selected.size === filtered.length && filtered.length > 0}
                    ref={(el) => { if (el) el.indeterminate = selected.size > 0 && selected.size < filtered.length; }}
                    onChange={toggleSelectAll}
                    className="w-3.5 h-3.5 rounded cursor-pointer accent-[var(--primary)]"
                    aria-label="Select all users"
                  />
                </th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Name</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Role</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Team</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Status</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Last login</th>
                <th className="px-3 py-2 text-right text-[10px] font-semibold uppercase tracking-wider text-[var(--foreground-muted)] whitespace-nowrap">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => {
                const statusMeta = STATUS_META[u.status];
                const roleColor = ROLE_COLORS[u.role];
                const isSelected = selected.has(u.id);
                return (
                  <tr
                    key={u.id}
                    className={cn("border-b last:border-0 transition-colors", isSelected ? "bg-[var(--primary-soft)]" : "hover:bg-[var(--surface-hover)]")}
                    style={{ borderColor: "var(--border)" }}
                  >
                    <td className="px-3 py-2">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelect(u.id)}
                        className="w-3.5 h-3.5 rounded cursor-pointer accent-[var(--primary)]"
                        aria-label={`Select ${u.name}`}
                      />
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                          style={{ background: u.status === "disabled" ? "var(--surface-hover)" : "var(--primary)", color: u.status === "disabled" ? "var(--foreground-muted)" : "var(--background)" }}
                        >
                          {u.initials}
                        </div>
                        <div className="min-w-0">
                          <div className={cn("text-[12px] font-semibold truncate", u.status === "disabled" ? "text-[var(--foreground-muted)]" : "text-[var(--foreground)]")}>{u.name}</div>
                          <div className="text-[10px] text-[var(--foreground-muted)] font-mono truncate">{u.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2">
                      <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-[3px]" style={{ background: `color-mix(in srgb, ${roleColor} 12%, transparent)`, color: roleColor }}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      <span className="text-[12px] text-[var(--foreground-secondary)] flex items-center gap-1">
                        <Users size={11} className="text-[var(--foreground-muted)]" /> {u.team}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-[3px]", u.status === "disabled" && "opacity-70")} style={{ background: statusMeta.soft, color: statusMeta.color }}>
                        <span className="w-1 h-1 rounded-full" style={{ background: statusMeta.color }} />
                        {statusMeta.label}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      {u.lastLogin ? (
                        <span className="text-[11px] font-mono text-[var(--foreground-secondary)]">{fmtRelative(u.lastLogin)}</span>
                      ) : (
                        <span className="text-[11px] font-mono text-[var(--foreground-muted)] italic">Never</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-right">
                      <div className="inline-flex items-center gap-1">
                        {u.status === "invited" && (
                          <button
                            type="button"
                            onClick={() => handleResendInvite(u)}
                            className="text-[10px] font-medium px-2 py-1 rounded-[4px] border hover:bg-[var(--surface-hover)] cursor-pointer focus-ring text-[var(--primary)] flex items-center gap-1"
                            style={{ borderColor: "var(--border)" }}
                          >
                            <Mail size={11} /> Resend
                          </button>
                        )}
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button type="button" className="w-7 h-7 rounded-[4px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label={`Actions for ${u.name}`}>
                              <MoreHorizontal size={14} />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48 font-sans" style={{ background: "var(--surface-floating)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "6px", boxShadow: "var(--shadow-lg)" }}>
                            <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">{u.name}</DropdownMenuLabel>
                            <DropdownMenuSeparator style={{ background: "var(--border)" }} />
                            <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => toast.info("Edit profile", { description: u.name })}>
                              <Pencil size={13} /> Edit profile
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => toast.success("Password reset sent", { description: u.email })}>
                              <Mail size={13} /> Reset password
                            </DropdownMenuItem>
                            <DropdownMenuSeparator style={{ background: "var(--border)" }} />
                            <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-[var(--foreground-muted)]">Change role to</DropdownMenuLabel>
                            {ROLES.filter((r) => r !== u.role).map((r) => (
                              <DropdownMenuItem key={r} className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => handleRoleChange(u, r)}>
                                <Shield size={13} style={{ color: ROLE_COLORS[r] }} /> {r}
                              </DropdownMenuItem>
                            ))}
                            <DropdownMenuSeparator style={{ background: "var(--border)" }} />
                            <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[4px] mx-1 text-[12px] gap-2" onClick={() => handleDisable(u)}>
                              {u.status === "disabled" ? (<><Check size={13} /> Reactivate user</>) : (<><Lock size={13} /> Disable user</>)}
                            </DropdownMenuItem>
                            <DropdownMenuItem className="cursor-pointer focus:bg-[var(--status-delayed-soft)] rounded-[4px] mx-1 text-[12px] gap-2 text-[var(--status-delayed)]" onClick={() => handleDelete(u)}>
                              <Trash2 size={13} /> Delete user
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-3 py-12 text-center">
                    <UserCog size={28} className="mx-auto text-[var(--foreground-muted)] opacity-40 mb-2" />
                    <p className="text-[12px] text-[var(--foreground-muted)]">No users match your filters.</p>
                    <button
                      type="button"
                      onClick={() => { setQuery(""); setRoleFilter("all"); setStatusFilter("all"); }}
                      className="text-[11px] font-medium text-[var(--primary)] hover:underline mt-2 cursor-pointer focus-ring"
                    >
                      Clear filters
                    </button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-3 py-2 border-t" style={{ borderColor: "var(--border)", background: "var(--surface-elevated)" }}>
          <span className="text-[11px] font-mono text-[var(--foreground-muted)]">{filtered.length} of {users.length} users</span>
          <div className="flex items-center gap-3 text-[10px] font-mono text-[var(--foreground-muted)]">
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-ontime)" }} /> {counts.active} active</span>
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-atrisk)" }} /> {counts.invited} invited</span>
            <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--status-offline)" }} /> {counts.disabled} disabled</span>
          </div>
        </div>
      </div>
    </div>
  );
}
