"use client";
import { useEffect, useState } from "react";
import { Search, Bell, AlertTriangle, MessageSquare } from "lucide-react";
import { useFleetStore } from "@/store/fleet-store";
import { Avatar } from "./Avatar";
import { ThemeToggle } from "./ThemeToggle";
import type { Route } from "@/hooks/use-hash-route";

interface TopBarProps {
  route: Route;
  onOpenCommand: () => void;
  navigate: (path: string) => void;
}

export function TopBar({ route, onOpenCommand, navigate }: TopBarProps) {
  const vehicles = useFleetStore((s) => s.vehicles);
  const notifications = useFleetStore((s) => s.notifications);
  const alerts = useFleetStore((s) => s.alerts);
  const conversations = useFleetStore((s) => s.conversations);
  const [now, setNow] = useState<string | null>(null);

  useEffect(() => {
    const tick = () => setNow(new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const activeVehicles = vehicles.filter(v => v.status !== "offline" && v.status !== "maintenance").length;
  const unreadNotifs = notifications.filter(n => !n.read).length;
  const unackAlerts = alerts.filter(a => !a.acknowledged).length;
  const unreadMsgs = conversations.reduce((a, c) => a + c.unreadCount, 0);

  return (
    <header className="h-16 flex items-center px-4 gap-3 border-b shrink-0" style={{ background: "var(--surface)", borderColor: "var(--border)" }} role="banner">
      {/* Search + Command */}
      <button type="button" onClick={onOpenCommand} className="flex-1 max-w-md flex items-center gap-2 h-9 px-3 rounded-[6px] border text-[13px] text-[var(--foreground-muted)] hover:border-[var(--border-strong)] transition-colors cursor-pointer focus-ring group" style={{ borderColor: "var(--border)", background: "var(--background)" }} aria-label="Global search and command palette">
        <Search size={15} className="text-[var(--foreground-muted)] group-hover:text-[var(--primary)] transition-colors" />
        <span className="flex-1 text-left">Search vehicles, drivers, routes…</span>
        <kbd className="text-[10px] font-mono px-1.5 py-0.5 rounded border" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>⌘K</kbd>
      </button>

      {/* Dispatch summary */}
      <div className="hidden xl:flex items-center gap-4 px-3 h-9 rounded-[6px] border" style={{ borderColor: "var(--border)", background: "var(--background)" }}>
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full pulse-ontime" style={{ background: "var(--status-ontime)" }} />
          <span className="text-[11px] font-mono text-[var(--foreground-muted)]">ACTIVE</span>
          <span className="text-[13px] font-mono font-semibold text-[var(--foreground)]">{activeVehicles}</span>
        </div>
        <div className="w-px h-4" style={{ background: "var(--border)" }} />
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-mono text-[var(--foreground-muted)]">SHIFT</span>
          <span className="text-[13px] font-mono font-semibold text-[var(--foreground)]">Day 06:00–18:00</span>
        </div>
        <div className="w-px h-4" style={{ background: "var(--border)" }} />
        <span className="text-[13px] font-mono font-semibold text-[var(--primary)]">{now ?? "--:--:--"}</span>
      </div>

      {/* Right actions */}
      <div className="flex items-center gap-0.5">
        <button type="button" onClick={() => navigate("system-status")} className="relative w-9 h-9 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--status-delayed)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label={`Alerts, ${unackAlerts} unacknowledged`}>
          <AlertTriangle size={16} />
          {unackAlerts > 0 && <span className="absolute top-1 right-1 min-w-[14px] h-[14px] px-0.5 rounded-full flex items-center justify-center text-[8px] font-bold text-white font-mono pulse-delayed" style={{ background: "var(--status-delayed)" }}>{unackAlerts}</span>}
        </button>
        <button type="button" onClick={() => navigate("messages")} className="relative w-9 h-9 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label={`Messages, ${unreadMsgs} unread`}>
          <MessageSquare size={16} />
          {unreadMsgs > 0 && <span className="absolute top-1 right-1 min-w-[14px] h-[14px] px-0.5 rounded-full flex items-center justify-center text-[8px] font-bold text-white font-mono" style={{ background: "var(--primary)" }}>{unreadMsgs}</span>}
        </button>
        <button type="button" onClick={() => navigate("notifications")} className="relative w-9 h-9 rounded-[6px] flex items-center justify-center text-[var(--foreground-muted)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label={`Notifications, ${unreadNotifs} unread`}>
          <Bell size={16} />
          {unreadNotifs > 0 && <span className="absolute top-1 right-1 min-w-[14px] h-[14px] px-0.5 rounded-full flex items-center justify-center text-[8px] font-bold text-white font-mono" style={{ background: "var(--accent)" }}>{unreadNotifs}</span>}
        </button>
        <ThemeToggle />
        <div className="w-px h-6 mx-1" style={{ background: "var(--border)" }} />
        <button type="button" onClick={() => navigate("profile")} className="flex items-center gap-2 h-9 px-1 pr-2 rounded-[6px] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring" aria-label="Profile menu">
          <Avatar seed="d-kowalski" name="D. Kowalski" size={28} />
          <div className="hidden lg:flex flex-col items-start leading-none">
            <span className="text-[12px] font-semibold text-[var(--foreground)]">D. Kowalski</span>
            <span className="text-[10px] text-[var(--foreground-muted)]">Ops Director</span>
          </div>
        </button>
      </div>
    </header>
  );
}
