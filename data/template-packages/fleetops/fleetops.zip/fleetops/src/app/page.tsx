import { FleetApp } from "@/components/fleet/FleetApp";

export default function Home() {
  return <FleetApp />;
}
