// FleetOps formatters — all relative time anchored to NOW (no hydration mismatch)
import { format } from "date-fns";

export const NOW = new Date("2026-08-01T08:00:00Z").getTime();

export function fmtDate(iso: string): string {
  return format(new Date(iso), "MMM d, yyyy");
}
export function fmtDateTime(iso: string): string {
  return format(new Date(iso), "MMM d · HH:mm");
}
export function fmtTime(iso: string): string {
  return format(new Date(iso), "HH:mm");
}
export function fmtTimeOnly(date: Date): string {
  return format(date, "HH:mm");
}
export function fmtRelative(iso: string): string {
  const diff = NOW - new Date(iso).getTime();
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  if (day < 7) return `${day}d ago`;
  return `${Math.floor(day / 7)}w ago`;
}
export function fmtDuration(iso: string): string {
  const diff = NOW - new Date(iso).getTime();
  const hr = Math.floor(diff / 3600000);
  const min = Math.floor((diff % 3600000) / 60000);
  if (hr > 0) return `${hr}h ${min}m`;
  return `${min}m`;
}
export function fmtETA(iso: string | null): string {
  if (!iso) return "—";
  const diff = new Date(iso).getTime() - NOW;
  if (diff < 0) {
    const absMin = Math.floor(Math.abs(diff) / 60000);
    if (absMin < 60) return `${absMin}m late`;
    return `${Math.floor(absMin / 60)}h ${absMin % 60}m late`;
  }
  const min = Math.floor(diff / 60000);
  if (min < 60) return `${min}m`;
  const hr = Math.floor(min / 60);
  return `${hr}h ${min % 60}m`;
}
export function fmtHours(h: number): string {
  if (h <= 0) return "0h";
  if (h < 1) return `${Math.round(h * 60)}m`;
  return `${h.toFixed(1)}h`;
}
export function fmtPct(n: number): string {
  return `${n.toFixed(1)}%`;
}
export function fmtNumber(n: number): string {
  return n.toLocaleString("en-US");
}
export function fmtCurrency(n: number): string {
  return `$${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
export function fmtDistance(miles: number): string {
  return `${miles.toFixed(0)} mi`;
}
