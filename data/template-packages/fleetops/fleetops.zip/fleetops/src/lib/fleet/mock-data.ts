// ============================================================
// FleetOps — Deterministic mock fleet operations data
// ============================================================
import { NOW } from "./format";
import type {
  Alert, DispatchOrder, Driver, FuelEvent, Incident, MaintenanceRecord,
  Message, Conversation, Notification, Route, Vehicle, Warehouse, DeliveryStop,
} from "./types";

// PRNG
function xmur3(str: string) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
  return function () { h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); h ^= h >>> 16; return h >>> 0; };
}
function mulberry32(a: number) {
  return function () { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const makeRng = (seed: string) => mulberry32(xmur3(seed)());
const rint = (r: () => number, lo: number, hi: number) => Math.floor(r() * (hi - lo + 1)) + lo;
const rfloat = (r: () => number, lo: number, hi: number) => r() * (hi - lo) + lo;
const pick = <T>(r: () => number, arr: readonly T[]): T => arr[Math.floor(r() * arr.length)];

// ---------- Drivers ----------
const DRIVER_NAMES = [
  "Marcus Johnson", "Sarah Williams", "David Chen", "Maria Garcia", "James Thompson",
  "Patricia Brown", "Robert Davis", "Linda Martinez", "Michael Wilson", "Jennifer Taylor",
  "Christopher Lee", "Barbara White", "Daniel Harris", "Susan Martin", "Matthew Jackson",
  "Jessica Thompson", "Anthony Moore", "Karen Allen", "Mark Young", "Nancy King",
  "Steven Wright", "Betty Scott", "Paul Green", "Helen Baker", "Andrew Adams",
  "Sandra Nelson", "Joshua Carter", "Donna Mitchell", "Kenneth Perez", "Carol Roberts",
  "Edward Turner", "Ruth Phillips", "Ronald Campbell", "Sharon Parker", "Timothy Evans",
];

export function buildDrivers(): Driver[] {
  const rng = makeRng("fleetops-drivers-v1");
  return DRIVER_NAMES.map((name, i) => {
    const status = pick(rng, ["on-duty", "on-duty", "on-duty", "off-duty", "on-break", "sleeper"] as const);
    const onTime = rint(rng, 82, 99);
    return {
      id: `drv-${101 + i}`,
      name,
      avatarSeed: name.toLowerCase().replace(/\s/g, "-"),
      phone: `(555) ${rint(rng, 100, 999)}-${rint(rng, 1000, 9999)}`,
      cdlClass: pick(rng, ["A", "A", "A", "B", "C"] as const),
      cdlExpiry: `2027-${String(rint(rng, 1, 12)).padStart(2, "0")}-${String(rint(rng, 1, 28)).padStart(2, "0")}`,
      homeBase: pick(rng, ["Dallas", "Phoenix", "Atlanta", "Chicago", "Seattle", "Denver"]),
      status,
      hoursRemaining: status === "off-duty" ? 11 : rfloat(rng, 1, 10),
      hoursWorkedToday: status === "off-duty" ? 0 : rfloat(rng, 2, 9),
      onTimePct: onTime,
      deliveriesCompleted: rint(rng, 840, 2400),
      safetyScore: rint(rng, 78, 98),
      fuelEfficiency: rfloat(rng, 6.2, 8.8),
      customerRating: rfloat(rng, 4.1, 4.95),
      incidents: rint(rng, 0, 4),
      hireDate: `20${rint(rng, 18, 24)}-${String(rint(rng, 1, 12)).padStart(2, "0")}-${String(rint(rng, 1, 28)).padStart(2, "0")}`,
      assignedVehicleId: null,
    } satisfies Driver;
  });
}

// ---------- Vehicles ----------
const CITIES = [
  { city: "Seattle", lat: 47.6, lng: -122.3, region: "Pacific Northwest" },
  { city: "Portland", lat: 45.5, lng: -122.7, region: "Pacific Northwest" },
  { city: "Phoenix", lat: 33.4, lng: -112.0, region: "Southwest" },
  { city: "Las Vegas", lat: 36.2, lng: -115.1, region: "Southwest" },
  { city: "Austin", lat: 30.3, lng: -97.7, region: "Texas" },
  { city: "Dallas", lat: 32.8, lng: -96.8, region: "Texas" },
  { city: "Houston", lat: 29.8, lng: -95.4, region: "Texas" },
  { city: "Chicago", lat: 41.9, lng: -87.6, region: "Midwest" },
  { city: "Indianapolis", lat: 39.8, lng: -86.2, region: "Midwest" },
  { city: "Atlanta", lat: 33.7, lng: -84.4, region: "Southeast" },
  { city: "Nashville", lat: 36.2, lng: -86.8, region: "Southeast" },
  { city: "Charlotte", lat: 35.2, lng: -80.8, region: "Southeast" },
  { city: "New York", lat: 40.7, lng: -74.0, region: "Northeast" },
  { city: "Boston", lat: 42.4, lng: -71.1, region: "Northeast" },
];

const LOAD_TYPES = ["General Freight", "Refrigerated", "Flatbed", "Tanker", "Dry Van", "Hazmat", "Oversized"];

export function buildVehicles(drivers: Driver[]): Vehicle[] {
  const rng = makeRng("fleetops-vehicles-v1");
  const vehicles: Vehicle[] = [];
  const count = 35;
  for (let i = 0; i < count; i++) {
    const statusRoll = rng();
    const status = statusRoll < 0.70 ? "on-time" : statusRoll < 0.85 ? "at-risk" : statusRoll < 0.95 ? "delayed" : rng() < 0.5 ? "offline" : "maintenance";
    const loc = pick(rng, CITIES);
    const driver = status === "offline" || status === "maintenance" ? null : pick(rng, drivers.filter(d => d.status === "on-duty"));
    const fuelPct = status === "offline" ? rint(rng, 10, 40) : rint(rng, 25, 95);
    vehicles.push({
      id: `veh-${201 + i}`,
      unit: `FL-${String(201 + i).padStart(3, "0")}`,
      driverId: driver?.id ?? null,
      currentRouteId: null,
      region: loc.region,
      lat: loc.lat + rfloat(rng, -1.5, 1.5),
      lng: loc.lng + rfloat(rng, -1.5, 1.5),
      speed: status === "offline" || status === "maintenance" ? 0 : rint(rng, 0, 72),
      heading: rint(rng, 0, 359),
      eta: status === "offline" || status === "maintenance" ? null : new Date(NOW + rint(rng, -40, 240) * 60000).toISOString(),
      fuelPct,
      fuelGallons: Math.round(fuelPct * 1.5),
      loadType: status === "offline" || status === "maintenance" ? "Empty" : pick(rng, LOAD_TYPES),
      loadWeightLbs: status === "offline" || status === "maintenance" ? 0 : rint(rng, 10000, 78000),
      capacityPct: status === "offline" || status === "maintenance" ? 0 : rint(rng, 45, 98),
      odometer: rint(rng, 120000, 480000),
      status,
      lastCheckIn: new Date(NOW - rint(rng, 1, 60) * 60000).toISOString(),
      trailerId: status === "offline" ? null : `TL-${rint(rng, 1000, 9999)}`,
      engineTemp: status === "offline" ? 0 : rint(rng, 175, 225),
      tirePressureStatus: rng() < 0.85 ? "ok" : rng() < 0.6 ? "low" : "critical",
    });
  }
  return vehicles;
}

// ---------- Routes ----------
const ROUTE_PAIRS = [
  ["Austin", "Dallas"], ["Dallas", "Houston"], ["Phoenix", "Las Vegas"],
  ["Seattle", "Portland"], ["Chicago", "Indianapolis"], ["Atlanta", "Nashville"],
  ["Charlotte", "Atlanta"], ["New York", "Boston"], ["Houston", "San Antonio"],
  ["Las Vegas", "Phoenix"], ["Portland", "Seattle"], ["Indianapolis", "Chicago"],
  ["Nashville", "Charlotte"], ["Boston", "New York"], ["Dallas", "Austin"],
];

export function buildRoutes(vehicles: Vehicle[], drivers: Driver[]): Route[] {
  const rng = makeRng("fleetops-routes-v1");
  const routes: Route[] = [];
  let seq = 1;
  for (const v of vehicles) {
    if (v.status === "offline" || v.status === "maintenance") continue;
    const [origin, dest] = pick(rng, ROUTE_PAIRS);
    const start = new Date(NOW - rint(rng, 1, 8) * 3600000).toISOString();
    const eta = new Date(NOW + rint(rng, 30, 300) * 60000).toISOString();
    const driver = drivers.find(d => d.id === v.driverId);
    routes.push({
      id: `rte-${seq++}`,
      vehicleId: v.id,
      driverId: v.driverId,
      origin,
      destination: dest,
      originCity: origin,
      destCity: dest,
      distanceMiles: rint(rng, 120, 980),
      plannedStart: start,
      actualStart: v.status === "delayed" ? new Date(new Date(start).getTime() + rint(rng, 15, 60) * 60000).toISOString() : start,
      eta,
      completedAt: null,
      status: v.status === "delayed" ? "delayed" : "in-progress",
      stops: rint(rng, 1, 5),
      delayReason: v.status === "delayed" ? pick(rng, ["Traffic congestion", "Weather delay", "Loading delay", "Driver break", "Mechanical issue"]) : null,
      loadId: `LOAD-${rint(rng, 10000, 99999)}`,
      priority: v.status === "delayed" ? "high" : v.status === "at-risk" ? "medium" : pick(rng, ["low", "medium", "medium", "high"] as const),
    });
    v.currentRouteId = routes[routes.length - 1].id;
  }
  return routes;
}

// ---------- Warehouses ----------
export function buildWarehouses(): Warehouse[] {
  const rng = makeRng("fleetops-warehouses-v1");
  const whData = CITIES.slice(0, 8);
  return whData.map((c, i) => {
    const dockCount = rint(rng, 8, 24);
    const docksOccupied = rint(rng, Math.floor(dockCount * 0.3), dockCount);
    const loadingBays = rint(rng, 4, 12);
    const baysInUse = rint(rng, Math.floor(loadingBays * 0.2), loadingBays);
    const util = Math.round((docksOccupied / dockCount) * 100);
    return {
      id: `wh-${i + 1}`,
      code: `WH-${c.city.substring(0, 3).toUpperCase()}`,
      name: `${c.city} Distribution Center`,
      city: c.city,
      region: c.region,
      lat: c.lat, lng: c.lng,
      dockCount, docksOccupied,
      loadingBays, baysInUse,
      inboundTrailers: rint(rng, 3, 18),
      outboundTrailers: rint(rng, 3, 18),
      queueLength: rint(rng, 0, 8),
      throughputToday: rint(rng, 40, 180),
      utilizationPct: util,
      status: util > 85 ? "congested" : rng() < 0.1 ? "maintenance" : "operational",
    } satisfies Warehouse;
  });
}

// ---------- Dispatch Orders ----------
export function buildDispatchOrders(routes: Route[]): DispatchOrder[] {
  const rng = makeRng("fleetops-dispatch-v1");
  const orders: DispatchOrder[] = [];
  const priorities = ["low", "medium", "high", "critical"] as const;
  for (let i = 0; i < 12; i++) {
    const [orig, dest] = pick(rng, ROUTE_PAIRS);
    const assigned = rng() < 0.3;
    orders.push({
      id: `dsp-${501 + i}`,
      priority: pick(rng, priorities),
      routeId: `rte-new-${i}`,
      vehicleId: assigned ? pick(rng, routes).vehicleId : null,
      driverId: assigned ? pick(rng, routes).driverId : null,
      pickup: `${orig} Warehouse`,
      pickupCity: orig,
      delivery: `${dest} Hub`,
      deliveryCity: dest,
      windowStart: new Date(NOW + rint(rng, 0, 4) * 3600000).toISOString(),
      windowEnd: new Date(NOW + rint(rng, 4, 12) * 3600000).toISOString(),
      status: assigned ? "assigned" : "unassigned",
      createdAt: new Date(NOW - rint(rng, 10, 120) * 60000).toISOString(),
    });
  }
  return orders.sort((a, b) => {
    const order = { critical: 0, high: 1, medium: 2, low: 3 };
    return order[a.priority] - order[b.priority];
  });
}

// ---------- Incidents ----------
export function buildIncidents(vehicles: Vehicle[]): Incident[] {
  const rng = makeRng("fleetops-incidents-v1");
  const incidents: Incident[] = [];
  const types = ["accident", "breakdown", "traffic", "weather", "fuel", "cargo", "equipment", "safety"] as const;
  for (let i = 0; i < 8; i++) {
    const v = pick(rng, vehicles);
    const type = pick(rng, types);
    incidents.push({
      id: `inc-${701 + i}`,
      type,
      vehicleId: v.id,
      driverId: v.driverId,
      routeId: v.currentRouteId,
      severity: pick(rng, ["low", "medium", "high", "critical"] as const),
      title: `${type.charAt(0).toUpperCase() + type.slice(1)} — ${v.unit}`,
      description: `${v.unit} reported a ${type} incident near ${v.region}. ${type === "accident" ? "Minor collision, no injuries reported." : type === "breakdown" ? "Engine malfunction, vehicle pulled over safely." : type === "weather" ? "Severe weather conditions affecting route." : "Operational issue requiring attention."}`,
      location: v.region,
      timestamp: new Date(NOW - rint(rng, 5, 300) * 60000).toISOString(),
      status: pick(rng, ["open", "acknowledged", "investigating", "resolved"] as const),
      reportedBy: pick(rng, ["System", "Driver", "Dispatcher", "Fleet Manager"]),
    });
  }
  return incidents.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

// ---------- Notifications ----------
export function buildNotifications(): Notification[] {
  return [
    { id: "n1", type: "vehicle-delayed", category: "critical", title: "Vehicle delayed", body: "FL-204 delayed by 38 min on Austin → Dallas", time: "2m ago", timestamp: new Date(NOW - 120000).toISOString(), read: false, archived: false, vehicleId: "veh-204", routeId: "rte-1", severity: "critical" },
    { id: "n2", type: "route-exception", category: "dispatch", title: "Route exception", body: "Route rte-3 missed delivery window at Houston", time: "8m ago", timestamp: new Date(NOW - 480000).toISOString(), read: false, archived: false, routeId: "rte-3", severity: "warning" },
    { id: "n3", type: "maintenance-due", category: "fleet", title: "Maintenance due", body: "FL-210 scheduled maintenance overdue by 2 days", time: "15m ago", timestamp: new Date(NOW - 900000).toISOString(), read: false, archived: false, vehicleId: "veh-210", severity: "warning" },
    { id: "n4", type: "delivery-completed", category: "dispatch", title: "Delivery completed", body: "FL-207 completed delivery at Phoenix Hub", time: "22m ago", timestamp: new Date(NOW - 1320000).toISOString(), read: false, archived: false, vehicleId: "veh-207", severity: "info" },
    { id: "n5", type: "warehouse-congestion", category: "warehouses", title: "Warehouse congestion", body: "WH-DAL at 92% dock capacity — 6 trailers queued", time: "35m ago", timestamp: new Date(NOW - 2100000).toISOString(), read: true, archived: false, severity: "warning" },
    { id: "n6", type: "driver-offline", category: "drivers", title: "Driver offline", body: "Marcus Johnson has been offline for 18 minutes", time: "45m ago", timestamp: new Date(NOW - 2700000).toISOString(), read: true, archived: false, driverId: "drv-101", severity: "warning" },
    { id: "n7", type: "fuel-anomaly", category: "fleet", title: "Fuel anomaly detected", body: "FL-215 fuel drop of 8% in 5 minutes — possible leak", time: "1h ago", timestamp: new Date(NOW - 3600000).toISOString(), read: true, archived: false, vehicleId: "veh-215", severity: "critical" },
    { id: "n8", type: "incident-reported", category: "critical", title: "Incident reported", body: "Breakdown reported on FL-220 near Atlanta", time: "2h ago", timestamp: new Date(NOW - 7200000).toISOString(), read: true, archived: false, vehicleId: "veh-220", severity: "critical" },
    { id: "n9", type: "weather-alert", category: "system", title: "Weather alert", body: "Severe thunderstorm warning: I-20 corridor Texas", time: "3h ago", timestamp: new Date(NOW - 10800000).toISOString(), read: true, archived: false, severity: "warning" },
    { id: "n10", type: "dispatch-assigned", category: "dispatch", title: "Dispatch assigned", body: "FL-209 assigned to route Chicago → Indianapolis", time: "5h ago", timestamp: new Date(NOW - 18000000).toISOString(), read: true, archived: false, vehicleId: "veh-209", severity: "info" },
  ];
}

// ---------- Alerts ----------
export function buildAlerts(): Alert[] {
  return [
    { id: "al1", priority: "critical", title: "FL-204 delayed 38 minutes", description: "Vehicle FL-204 has been delayed by 38 minutes on Route Austin → Dallas. Driver: Marcus Johnson.", vehicleId: "veh-204", driverId: "drv-101", routeId: "rte-1", timestamp: new Date(NOW - 120000).toISOString(), acknowledged: false, actions: ["View vehicle", "Contact driver", "Reroute", "Dismiss"] },
    { id: "al2", priority: "critical", title: "Fuel anomaly on FL-215", description: "Fuel level dropped 8% in 5 minutes. Possible leak or theft.", vehicleId: "veh-215", timestamp: new Date(NOW - 3600000).toISOString(), acknowledged: false, actions: ["View vehicle", "Contact driver", "Dispatch mechanic"] },
    { id: "al3", priority: "high", title: "WH-DAL dock congestion", description: "Dallas DC at 92% capacity, 6 trailers in queue. Estimated 45-min wait.", timestamp: new Date(NOW - 2100000).toISOString(), acknowledged: false, actions: ["View warehouse", "Reassign docks"] },
    { id: "al4", priority: "high", title: "Maintenance overdue: FL-210", description: "Scheduled maintenance is 2 days overdue. 247,000 miles on odometer.", vehicleId: "veh-210", timestamp: new Date(NOW - 900000).toISOString(), acknowledged: false, actions: ["Schedule maintenance", "View vehicle"] },
    { id: "al5", priority: "medium", title: "HOS limit approaching", description: "Sarah Williams has 1.5 hours of service remaining.", driverId: "drv-102", timestamp: new Date(NOW - 1800000).toISOString(), acknowledged: true, actions: ["View driver", "Schedule break"] },
  ];
}

// ---------- Messages ----------
export function buildConversations(): Conversation[] {
  return [
    { id: "c1", type: "dispatch-driver", participantName: "Marcus Johnson", participantRole: "Driver · FL-204", avatarSeed: "marcus-johnson", lastMessage: "Traffic is heavy on I-35, might be 20 min late", lastTimestamp: new Date(NOW - 180000).toISOString(), unreadCount: 2, typing: true },
    { id: "c2", type: "dispatch-warehouse", participantName: "WH-DAL Dock Manager", participantRole: "Warehouse · Dallas DC", avatarSeed: "wh-dal", lastMessage: "Dock 7 is clear for FL-207", lastTimestamp: new Date(NOW - 900000).toISOString(), unreadCount: 0, typing: false },
    { id: "c3", type: "dispatch-driver", participantName: "Sarah Williams", participantRole: "Driver · FL-205", avatarSeed: "sarah-williams", lastMessage: "Picking up load now, ETA on schedule", lastTimestamp: new Date(NOW - 2400000).toISOString(), unreadCount: 0, typing: false },
    { id: "c4", type: "manager-team", participantName: "Operations Team", participantRole: "Team · 8 members", avatarSeed: "ops-team", lastMessage: "Shift handover notes attached", lastTimestamp: new Date(NOW - 7200000).toISOString(), unreadCount: 1, typing: false },
  ];
}

export function buildMessages(): Message[] {
  return [
    { id: "m1", conversationId: "c1", sender: "driver", senderName: "Marcus Johnson", text: "Dispatch, I'm on I-35 northbound, traffic is backed up near Exit 42.", timestamp: new Date(NOW - 600000).toISOString(), read: true },
    { id: "m2", conversationId: "c1", sender: "dispatch", senderName: "Dispatch", text: "Copy that FL-204. What's your revised ETA to Dallas DC?", timestamp: new Date(NOW - 480000).toISOString(), read: true },
    { id: "m3", conversationId: "c1", sender: "driver", senderName: "Marcus Johnson", text: "Looking at another 38 minutes. Road is at a standstill.", timestamp: new Date(NOW - 300000).toISOString(), read: false },
    { id: "m4", conversationId: "c1", sender: "driver", senderName: "Marcus Johnson", text: "Traffic is heavy on I-35, might be 20 min late", timestamp: new Date(NOW - 180000).toISOString(), read: false },
    { id: "m5", conversationId: "c2", sender: "warehouse", senderName: "WH-DAL Dock Manager", text: "Dock 7 is clear for FL-207", timestamp: new Date(NOW - 900000).toISOString(), read: true },
  ];
}

// ---------- Maintenance ----------
export function buildMaintenance(vehicles: Vehicle[]): MaintenanceRecord[] {
  const rng = makeRng("fleetops-maintenance-v1");
  const records: MaintenanceRecord[] = [];
  for (let i = 0; i < 10; i++) {
    const v = pick(rng, vehicles);
    records.push({
      id: `mnt-${801 + i}`,
      vehicleId: v.id,
      type: pick(rng, ["scheduled", "corrective", "emergency", "inspection"] as const),
      description: pick(rng, ["Oil change and filter", "Brake inspection", "Tire rotation", "Engine diagnostic", "DOT inspection", "Transmission service"]),
      scheduledDate: new Date(NOW + rint(rng, -7, 14) * 86400000).toISOString(),
      completedDate: rng() < 0.3 ? new Date(NOW - rint(rng, 1, 30) * 86400000).toISOString() : null,
      cost: rint(rng, 200, 4500),
      status: pick(rng, ["scheduled", "in-progress", "completed", "overdue"] as const),
      odometer: v.odometer,
    });
  }
  return records;
}

// ---------- Fuel Events ----------
export function buildFuelEvents(vehicles: Vehicle[]): FuelEvent[] {
  const rng = makeRng("fleetops-fuel-v1");
  const events: FuelEvent[] = [];
  for (let i = 0; i < 20; i++) {
    const v = pick(rng, vehicles);
    events.push({
      id: `fuel-${901 + i}`,
      vehicleId: v.id,
      timestamp: new Date(NOW - rint(rng, 1, 72) * 3600000).toISOString(),
      gallons: rfloat(rng, 40, 120),
      cost: rfloat(rng, 140, 420),
      pricePerGallon: rfloat(rng, 3.45, 4.15),
      location: pick(rng, ["Pilot", "Love's", "TA Petro", "Flying J", "Speedway"]),
      odometer: v.odometer - rint(rng, 0, 500),
    });
  }
  return events.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

// ---------- Aggregate ----------
export interface FleetData {
  vehicles: Vehicle[];
  drivers: Driver[];
  routes: Route[];
  warehouses: Warehouse[];
  dispatchOrders: DispatchOrder[];
  incidents: Incident[];
  notifications: Notification[];
  alerts: Alert[];
  conversations: Conversation[];
  messages: Message[];
  maintenance: MaintenanceRecord[];
  fuelEvents: FuelEvent[];
}

export function buildFleetData(): FleetData {
  const drivers = buildDrivers();
  const vehicles = buildVehicles(drivers);
  const routes = buildRoutes(vehicles, drivers);
  const warehouses = buildWarehouses();
  const dispatchOrders = buildDispatchOrders(routes);
  const incidents = buildIncidents(vehicles);
  const notifications = buildNotifications();
  const alerts = buildAlerts();
  const conversations = buildConversations();
  const messages = buildMessages();
  const maintenance = buildMaintenance(vehicles);
  const fuelEvents = buildFuelEvents(vehicles);
  return { vehicles, drivers, routes, warehouses, dispatchOrders, incidents, notifications, alerts, conversations, messages, maintenance, fuelEvents };
}
