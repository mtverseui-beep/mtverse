// ============================================================
// FleetOps Command Center — Data models
// ============================================================

export type VehicleStatus = "on-time" | "at-risk" | "delayed" | "offline" | "maintenance";

export interface Vehicle {
  id: string;
  unit: string; // FL-204
  driverId: string | null;
  currentRouteId: string | null;
  region: string;
  lat: number;
  lng: number;
  speed: number; // mph
  heading: number; // degrees
  eta: string | null; // ISO
  fuelPct: number; // 0-100
  fuelGallons: number;
  loadType: string;
  loadWeightLbs: number;
  capacityPct: number; // 0-100
  odometer: number;
  status: VehicleStatus;
  lastCheckIn: string; // ISO
  trailerId: string | null;
  engineTemp: number;
  tirePressureStatus: "ok" | "low" | "critical";
}

export interface Driver {
  id: string;
  name: string;
  avatarSeed: string;
  phone: string;
  cdlClass: "A" | "B" | "C";
  cdlExpiry: string;
  homeBase: string;
  status: "on-duty" | "off-duty" | "on-break" | "sleeper";
  hoursRemaining: number; // hours
  hoursWorkedToday: number;
  onTimePct: number;
  deliveriesCompleted: number;
  safetyScore: number; // 0-100
  fuelEfficiency: number; // mpg
  customerRating: number; // 0-5
  incidents: number;
  hireDate: string;
  assignedVehicleId: string | null;
}

export interface Route {
  id: string;
  vehicleId: string | null;
  driverId: string | null;
  origin: string;
  destination: string;
  originCity: string;
  destCity: string;
  distanceMiles: number;
  plannedStart: string; // ISO
  actualStart: string | null;
  eta: string;
  completedAt: string | null;
  status: "planned" | "in-progress" | "completed" | "delayed" | "cancelled";
  stops: number;
  delayReason: string | null;
  loadId: string;
  priority: "low" | "medium" | "high" | "critical";
}

export interface DeliveryStop {
  id: string;
  routeId: string;
  sequence: number;
  location: string;
  city: string;
  lat: number;
  lng: number;
  windowStart: string;
  windowEnd: string;
  arrivalTime: string | null;
  status: "pending" | "arrived" | "departed" | "skipped" | "failed";
  contactName: string;
  contactPhone: string;
}

export interface Warehouse {
  id: string;
  code: string; // WH-DFW
  name: string;
  city: string;
  region: string;
  lat: number;
  lng: number;
  dockCount: number;
  docksOccupied: number;
  loadingBays: number;
  baysInUse: number;
  inboundTrailers: number;
  outboundTrailers: number;
  queueLength: number;
  throughputToday: number;
  utilizationPct: number;
  status: "operational" | "congested" | "maintenance" | "offline";
}

export interface DispatchOrder {
  id: string;
  priority: "low" | "medium" | "high" | "critical";
  routeId: string;
  vehicleId: string | null;
  driverId: string | null;
  pickup: string;
  pickupCity: string;
  delivery: string;
  deliveryCity: string;
  windowStart: string;
  windowEnd: string;
  status: "unassigned" | "assigned" | "in-progress" | "completed" | "cancelled";
  createdAt: string;
}

export type IncidentType =
  | "accident" | "breakdown" | "traffic" | "weather" | "fuel"
  | "cargo" | "hours-violation" | "equipment" | "safety" | "other";

export interface Incident {
  id: string;
  type: IncidentType;
  vehicleId: string | null;
  driverId: string | null;
  routeId: string | null;
  severity: "low" | "medium" | "high" | "critical";
  title: string;
  description: string;
  location: string;
  timestamp: string;
  status: "open" | "acknowledged" | "investigating" | "resolved" | "closed";
  reportedBy: string;
}

export type NotificationType =
  | "vehicle-delayed" | "route-exception" | "driver-checked-in" | "driver-offline"
  | "maintenance-due" | "fuel-anomaly" | "warehouse-congestion" | "delivery-completed"
  | "dispatch-assigned" | "incident-reported" | "weather-alert" | "system-outage";

export type NotificationCategory = "critical" | "dispatch" | "fleet" | "drivers" | "warehouses" | "system";

export interface Notification {
  id: string;
  type: NotificationType;
  category: NotificationCategory;
  title: string;
  body: string;
  time: string; // relative
  timestamp: string; // ISO for grouping
  read: boolean;
  archived: boolean;
  vehicleId?: string;
  driverId?: string;
  routeId?: string;
  severity: "info" | "warning" | "critical";
}

export interface Alert {
  id: string;
  priority: "critical" | "high" | "medium" | "low";
  title: string;
  description: string;
  vehicleId?: string;
  driverId?: string;
  routeId?: string;
  timestamp: string;
  acknowledged: boolean;
  actions: string[];
}

export interface Message {
  id: string;
  conversationId: string;
  sender: "dispatch" | "driver" | "warehouse" | "manager";
  senderName: string;
  text: string;
  timestamp: string;
  read: boolean;
}

export interface Conversation {
  id: string;
  type: "dispatch-driver" | "dispatch-warehouse" | "manager-team";
  participantName: string;
  participantRole: string;
  avatarSeed: string;
  lastMessage: string;
  lastTimestamp: string;
  unreadCount: number;
  typing: boolean;
}

export interface MaintenanceRecord {
  id: string;
  vehicleId: string;
  type: "scheduled" | "corrective" | "emergency" | "inspection";
  description: string;
  scheduledDate: string;
  completedDate: string | null;
  cost: number;
  status: "scheduled" | "in-progress" | "completed" | "overdue";
  odometer: number;
}

export interface FuelEvent {
  id: string;
  vehicleId: string;
  timestamp: string;
  gallons: number;
  cost: number;
  pricePerGallon: number;
  location: string;
  odometer: number;
}

export interface TelemetryPoint {
  vehicleId: string;
  timestamp: string;
  speed: number;
  fuelPct: number;
  engineTemp: number;
  lat: number;
  lng: number;
}

// Status helpers
export const STATUS_META: Record<VehicleStatus, { label: string; color: string; soft: string; pulse?: string }> = {
  "on-time": { label: "On Time", color: "var(--status-ontime)", soft: "var(--status-ontime-soft)" },
  "at-risk": { label: "At Risk", color: "var(--status-atrisk)", soft: "var(--status-atrisk-soft)", pulse: "pulse-atrisk" },
  "delayed": { label: "Delayed", color: "var(--status-delayed)", soft: "var(--status-delayed-soft)", pulse: "pulse-delayed" },
  "offline": { label: "Offline", color: "var(--status-offline)", soft: "var(--status-offline-soft)" },
  "maintenance": { label: "Maintenance", color: "var(--status-maintenance)", soft: "var(--status-maintenance-soft)" },
};

// Regions with coordinates for map placement
export const REGIONS = [
  { name: "Pacific Northwest", center: [47.6, -122.3], cities: ["Seattle", "Portland", "Spokane"] },
  { name: "Southwest", center: [33.4, -112.0], cities: ["Phoenix", "Tucson", "Las Vegas"] },
  { name: "Texas", center: [30.3, -97.7], cities: ["Austin", "Dallas", "Houston", "San Antonio"] },
  { name: "Midwest", center: [41.9, -87.6], cities: ["Chicago", "Indianapolis", "Detroit"] },
  { name: "Southeast", center: [33.7, -84.4], cities: ["Atlanta", "Nashville", "Charlotte"] },
  { name: "Northeast", center: [40.7, -74.0], cities: ["New York", "Boston", "Philadelphia"] },
] as const;
