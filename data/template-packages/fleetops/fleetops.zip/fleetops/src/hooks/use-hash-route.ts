"use client";
import { useEffect, useState, useCallback } from "react";

export interface Route {
  path: string;
  segments: string[];
}

function parse(): Route {
  if (typeof window === "undefined") return { path: "dashboard", segments: ["dashboard"] };
  const raw = window.location.hash.replace(/^#\/?/, "");
  return { path: raw || "dashboard", segments: raw ? raw.split("/").filter(Boolean) : ["dashboard"] };
}

export function useHashRoute(): [Route, (path: string) => void] {
  const [route, setRoute] = useState<Route>({ path: "dashboard", segments: ["dashboard"] });

  useEffect(() => {
    const r = parse();
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setRoute(r);
    const onHash = () => setRoute(parse());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = useCallback((path: string) => {
    const clean = path.replace(/^\/+/, "");
    window.location.hash = `/${clean}`;
  }, []);

  return [route, navigate];
}
