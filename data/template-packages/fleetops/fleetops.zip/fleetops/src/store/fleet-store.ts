"use client";
import { create } from "zustand";
import { buildFleetData, type FleetData } from "@/lib/fleet/mock-data";
import type { DispatchOrder, Notification, Vehicle } from "@/lib/fleet/types";

interface FleetState extends FleetData {
  selectedVehicleId: string | null;
  drawerOpen: boolean;
  commandOpen: boolean;
  searchQuery: string;
  searchOpen: boolean;
  selectedDispatchIds: string[];
  // Actions
  selectVehicle: (id: string | null) => void;
  setDrawerOpen: (open: boolean) => void;
  setCommandOpen: (open: boolean) => void;
  setSearchQuery: (q: string) => void;
  setSearchOpen: (open: boolean) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  archiveNotification: (id: string) => void;
  acknowledgeAlert: (id: string) => void;
  assignDispatch: (orderId: string, vehicleId: string, driverId: string) => void;
  cancelDispatch: (orderId: string) => void;
  escalateDispatch: (orderId: string) => void;
}

const _data = buildFleetData();

export const useFleetStore = create<FleetState>((set) => ({
  ..._data,
  selectedVehicleId: null,
  drawerOpen: false,
  commandOpen: false,
  searchQuery: "",
  searchOpen: false,
  selectedDispatchIds: [],

  selectVehicle: (id) => set({ selectedVehicleId: id, drawerOpen: id !== null }),
  setDrawerOpen: (open) => set((s) => ({ drawerOpen: open, selectedVehicleId: open ? s.selectedVehicleId : null })),
  setCommandOpen: (open) => set({ commandOpen: open }),
  setSearchQuery: (q) => set({ searchQuery: q, searchOpen: q.length > 0 }),
  setSearchOpen: (open) => set({ searchOpen: open }),

  markNotificationRead: (id) =>
    set((s) => ({ notifications: s.notifications.map((n) => n.id === id ? { ...n, read: true } : n) })),
  markAllNotificationsRead: () =>
    set((s) => ({ notifications: s.notifications.map((n) => ({ ...n, read: true })) })),
  archiveNotification: (id) =>
    set((s) => ({ notifications: s.notifications.map((n) => n.id === id ? { ...n, archived: true } : n) })),

  acknowledgeAlert: (id) =>
    set((s) => ({ alerts: s.alerts.map((a) => a.id === id ? { ...a, acknowledged: true } : a) })),

  assignDispatch: (orderId, vehicleId, driverId) =>
    set((s) => ({
      dispatchOrders: s.dispatchOrders.map((o) =>
        o.id === orderId ? { ...o, vehicleId, driverId, status: "assigned" } : o
      ),
    })),
  cancelDispatch: (orderId) =>
    set((s) => ({
      dispatchOrders: s.dispatchOrders.map((o) =>
        o.id === orderId ? { ...o, status: "cancelled" } : o
      ),
    })),
  escalateDispatch: (orderId) =>
    set((s) => ({
      dispatchOrders: s.dispatchOrders.map((o) =>
        o.id === orderId ? { ...o, priority: "critical" } : o
      ),
    })),
}));
