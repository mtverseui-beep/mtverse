# FleetOps Command Center

A production-ready, enterprise-grade fleet operations command center dashboard built with Next.js 16, TypeScript, and real-time map tracking. Designed for dispatchers, fleet managers, and operations directors managing 8-12 hour shifts.

## Features

### Core Modules
- **Dashboard** — 8 KPI strip, live fleet map, dispatch queue, route Gantt timeline, recent incidents, critical alert banner
- **Live Fleet** — Enterprise table with sorting, filtering, search, pagination, row selection, bulk actions, column visibility, real Leaflet map with vehicle markers
- **Dispatch Queue** — Priority-based assignment queue with assign, escalate, cancel actions
- **Route Timeline** — Gantt-style route visualization with status-colored bars
- **Driver Leaderboard** — Sortable table with on-time %, safety score, fuel efficiency, HOS tracking
- **Warehouse Operations** — Dock occupancy, loading bays, throughput metrics
- **Analytics** — ECharts line, bar, and gauge charts with theme-aware colors
- **Notifications** — Full notification center with 7 filter categories, grouped by date
- **Messages** — Two-pane messaging with typing indicators and quick templates
- **Profile** — Full user profile with security, preferences, and activity log
- **Settings** — 6 sub-sections with real toggles and form validation
- **Help Center** — Searchable FAQ, contact form, resource cards
- **System Status** — 8 service monitors with uptime tracking
- **User Management** — Admin table with roles, bulk actions

### Key Features
- **Real Map** — OpenStreetMap via react-leaflet with color-coded vehicle markers and popups
- **Command Palette** — ⌘K fuzzy search across vehicles, drivers, and actions
- **Theme System** — Light (default), Dark, and System themes with persistence
- **Modern Inputs** — All dropdowns use Radix Select, all number inputs are custom styled — zero native HTML selects
- **Real Avatars** — Profile photos via pravatar.cc with graceful initials fallback
- **Responsive** — Collapsible sidebar (256px ↔ 56px), responsive tables, mobile drawer
- **Accessible** — WCAG AA, full keyboard navigation, ARIA live regions, reduced motion support

## Tech Stack

| Category | Technology |
|----------|-----------|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript (strict mode) |
| Styling | Tailwind CSS 4 |
| UI Components | shadcn/ui (Radix UI) |
| Charts | Apache ECharts (echarts-for-react) |
| Maps | react-leaflet + OpenStreetMap |
| State | Zustand |
| Tables | TanStack Table v8 |
| Icons | lucide-react |
| Animation | Framer Motion |
| Fonts | IBM Plex Sans + IBM Plex Mono |

## Design System

| Token | Light | Dark |
|-------|-------|------|
| Background | `#F5F4F2` | `#141211` |
| Surface | `#FFFFFF` | `#1C1917` |
| Border | `#E7E5E4` | `#3A342F` |
| Primary | `#D97706` | `#F59E0B` |
| On-Time | `#16A34A` | `#22C55E` |
| Delayed | `#DC2626` | `#EF4444` |

- **Typography**: IBM Plex Sans (prose) + IBM Plex Mono (all numerals)
- **Radius**: 8px max (cards), 6px (buttons/inputs), 4px (small elements)
- **Spacing**: Dense 4/8/12/16/20/24/32 grid

## Getting Started

```bash
# Install dependencies
bun install

# Start development server
bun run dev

# Build for production
bun run build

# Run TypeScript check
bunx tsc --noEmit

# Run ESLint
bun run lint
```

## Project Structure

```
src/
├── app/                    # Next.js App Router
│   ├── layout.tsx          # Root layout with ThemeProvider
│   ├── page.tsx            # Entry point
│   ├── globals.css         # Theme system (light/dark)
│   ├── icon.svg            # Logo (file-based favicon)
│   ├── icon.png            # PNG favicon
│   ├── favicon.ico         # ICO favicon
│   └── apple-icon.png      # iOS home screen icon
├── components/
│   ├── fleet/              # All fleet components
│   │   ├── pages/          # Routed page components
│   │   ├── FleetApp.tsx    # Root app shell
│   │   ├── Sidebar.tsx     # Collapsible nav rail
│   │   ├── TopBar.tsx      # Command bar
│   │   ├── FleetMap.tsx    # Real Leaflet map
│   │   ├── ModernSelect.tsx # Radix Select wrapper
│   │   ├── NumberInput.tsx  # Styled number input
│   │   ├── Avatar.tsx       # Real photo avatars
│   │   └── ...
│   └── ui/                 # shadcn/ui primitives
├── lib/
│   └── fleet/              # Types, mock data, formatters
├── store/                  # Zustand store
└── hooks/                  # Shared hooks (hash router)
```

## Routes

| Route | Page |
|-------|------|
| `/#/dashboard` | Operations overview |
| `/#/fleet` | Live fleet table + map |
| `/#/dispatch` | Dispatch queue |
| `/#/routes/timeline` | Route Gantt timeline |
| `/#/warehouses` | Warehouse operations |
| `/#/drivers` | Driver leaderboard |
| `/#/analytics` | ECharts analytics |
| `/#/notifications` | Notification center |
| `/#/messages` | Messaging |
| `/#/profile` | User profile |
| `/#/settings` | Settings (6 sub-sections) |
| `/#/help` | Help center |
| `/#/system-status` | System status |
| `/#/admin/users` | User management |

## Production Audit

| Check | Command | Result |
|-------|---------|--------|
| TypeScript | `bunx tsc --noEmit` | ✅ 0 errors |
| ESLint | `bun run lint` | ✅ 0 errors |
| Hydration | Browser test | ✅ 0 errors |
| Native selects | `grep '<select'` | ✅ 0 found |
| Native number inputs | `grep 'type="number"'` | ✅ 0 found |
| All 14 routes | Browser test | ✅ 0 errors each |

## License

This is a template project. Customize and deploy as needed.
