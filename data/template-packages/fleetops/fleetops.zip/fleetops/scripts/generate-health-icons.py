#!/usr/bin/env python3
"""Generate PNG and ICO favicons for Meridian Health."""
from PIL import Image, ImageDraw
import os

OUT = "/home/z/my-project/src/app"

def draw_logo(size: int) -> ImageDraw.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    s = size / 32.0
    # Teal badge
    badge = (13, 148, 136, 255)
    radius = int(size * 0.28)
    draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=badge)
    # White cross
    white = (255, 255, 255, 255)
    # Vertical bar
    vw = max(2, int(4 * s))
    vx = int(14 * s)
    draw.rounded_rectangle([vx, int(8 * s), vx + vw, int(24 * s)], radius=max(1, int(s)), fill=white)
    # Horizontal bar
    hh = max(2, int(4 * s))
    hy = int(14 * s)
    draw.rounded_rectangle([int(8 * s), hy, int(24 * s), hy + hh], radius=max(1, int(s)), fill=white)
    return img

# PNGs
for name, sz in [("icon.png", 32), ("apple-icon.png", 180)]:
    draw_logo(sz).save(os.path.join(OUT, name))
    print(f"Generated {name} ({sz}x{sz})")

# ICO
ico_images = [draw_logo(s) for s in [16, 32, 48]]
ico_images[0].save(os.path.join(OUT, "favicon.ico"), format="ICO", sizes=[(s, s) for s in [16, 32, 48]])
print("Generated favicon.ico")
print("Done")
