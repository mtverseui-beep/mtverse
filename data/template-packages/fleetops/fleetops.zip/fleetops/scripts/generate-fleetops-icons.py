#!/usr/bin/env python3
"""Generate PNG and ICO favicons for FleetOps Command Center."""
from PIL import Image, ImageDraw
import os

OUT = "/home/z/my-project/src/app"

def draw_logo(size: int) -> ImageDraw.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    s = size / 32.0
    # Amber hexagon
    amber = (245, 158, 11, 255)
    dark = (20, 18, 17, 255)
    # Hex points
    import math
    pts = []
    for i in range(6):
        angle = math.radians(60 * i - 90)
        # Use a pointy-top hexagon matching the SVG
        cx, cy = 16, 16
        # The SVG hex is: top, upper-right, lower-right, bottom, lower-left, upper-left
        hex_pts = [(16, 2), (28, 9), (28, 23), (16, 30), (4, 23), (4, 9)]
    pts = [(int(x * s), int(y * s)) for x, y in hex_pts]
    draw.polygon(pts, fill=amber)
    # Route line (dark on amber)
    w = max(2, int(2.2 * s))
    # 9,22 -> 9,16 -> 16,16 -> 16,10 -> 23,10
    path_pts = [(9, 22), (9, 16), (16, 16), (16, 10), (23, 10)]
    for i in range(len(path_pts) - 1):
        x1, y1 = path_pts[i]
        x2, y2 = path_pts[i + 1]
        draw.line([(int(x1 * s), int(y1 * s)), (int(x2 * s), int(y2 * s))], fill=dark, width=w)
    # Origin circle
    r = max(1, int(2.2 * s))
    draw.ellipse([int(9 * s) - r, int(22 * s) - r, int(9 * s) + r, int(22 * s) + r], fill=dark)
    # Arrow head
    aw = max(2, int(2.2 * s))
    for (x1, y1), (x2, y2) in [((20, 7), (23, 10)), ((23, 10), (20, 13))]:
        draw.line([(int(x1 * s), int(y1 * s)), (int(x2 * s), int(y2 * s))], fill=dark, width=aw)
    return img

for name, sz in [("icon.png", 32), ("apple-icon.png", 180)]:
    draw_logo(sz).save(os.path.join(OUT, name))
    print(f"Generated {name} ({sz}x{sz})")

ico_images = [draw_logo(s) for s in [16, 32, 48]]
ico_images[0].save(os.path.join(OUT, "favicon.ico"), format="ICO", sizes=[(s, s) for s in [16, 32, 48]])
print("Generated favicon.ico")
print("Done")
