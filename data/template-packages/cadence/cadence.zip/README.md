# Cadence

> **Know what to reorder before you run out.**
>
> A premium B2B SaaS landing page template for an Inventory & Demand Forecasting product — built for retail, DTC, and multi-channel ecommerce operators. Designed to read as "expensive, considered, data-literate" — not another generic AI-startup gradient page.

![Cadence hero](download/cadence-premium-hero-light.png)

---

## What this is

Cadence is a production-ready Next.js 16 landing page template positioned for the underserved inventory-intelligence niche. Every visual on the page — the predictive forecast chart, the SKU status table, the velocity heatmap, the case-study metrics, the pricing tiers — pulls from a single typed dataset, so customizing the content is a one-file operation.

The design language is deliberately non-generic: a warm-paper palette (not pure white), a Fraunces serif display face paired with Geist Sans + Geist Mono, a gold/teal accent system tuned for WCAG AA in both light and dark modes, and a distinct background treatment per section (radial glows, dot grids, paper-grain noise, recessed bands, gradient washes) so the page has visual rhythm rather than feeling like one flat surface.

## Tech stack

| Layer | Choice |
|---|---|
| Framework | Next.js 16 (App Router, Turbopack, standalone output) |
| Language | TypeScript 5 (strict) |
| Styling | Tailwind CSS 4 + shadcn/ui (New York) |
| Charts | Recharts |
| Motion | Framer Motion (`whileInView` reveals + `useScroll`/`useTransform` parallax) |
| Forms | react-hook-form + zod |
| Theme | next-themes (zero-flash, system-aware) |
| Icons | lucide-react + 8 hand-crafted SVG integration marks |
| Toasts | sonner |
| Database | Prisma (SQLite client) — included for Phase 2 extension, unused at landing-page scope |

## Features

### Design system
- **Warm-paper palette** — light mode defaults to bone `#FAF7F1` / `#FFFFFF` surfaces; dark mode to `#12100D` / `#1B1812`. Never pure white, never pure black.
- **Gold + teal accents** tuned per mode for AA contrast (`#B8863A` light / `#D4A64A` dark for gold; `#2E5E52` / `#4A8A7A` for teal).
- **Four status tokens** (in-stock / low / critical / overstock) each with a paired soft-background tint for badges — never confusable with the brand accent.
- **Three typefaces** — Fraunces (serif display), Geist Sans (body), Geist Mono (tabular numerics via `.font-data` utility — no digit-width jitter during count-up animations).
- **Eight distinct background treatments** across sections — hero radial glow + grid fade, recessed dark band for problem stats, bento warm wash, vertical gradient for process, dark recessed band for deep-dive, case-study radial glow + paper grain, integrations horizontal wash, contact diagonal gradient, footer deep band.
- **Warm-tinted shadow scale** (`shadow-warm-sm` / `-md` / `-lg`) — never neutral black shadows.

### Motion
- **Scroll-linked parallax** via Framer Motion `useScroll` + `useTransform` — hero background layers, the floating reorder alert card, case-study metric numbers, and the final-CTA glow all move at different speeds.
- **Scroll-tied progress bar** on the "How it works" section — the connecting line fills as you scroll, not on a timer.
- **Stroke-dashoffset draw-in** on the hero forecast chart path (900ms `ease-out-expo`, staggered 200ms after hero entrance).
- **Magnetic primary CTAs** — desktop pointer-fine only, translates a few px toward the cursor, springs back on leave. Fully disabled under `prefers-reduced-motion` or coarse pointer.
- **`whileInView` reveals** — every major section fades + rises 24px, staggered 70–90ms between siblings, fires once.
- **Tab indicator** animates position/width via Framer Motion `layoutId`.
- **Pricing toggle** — monthly↔yearly price crossfades + counts up via `AnimatedCounter`.
- **`prefers-reduced-motion: reduce`** — every animation either disables or reduces to a simple opacity crossfade. Implemented as a single `useReducedMotion` hook applied consistently.

### Sections (13 on `/`)
1. **Navbar** — sticky glass condense-on-scroll, mobile Sheet drawer with focus trap
2. **Hero** — eyebrow, oversized serif H1, predictive chart with animated draw-in, 4 SKU rows with status badges, floating reorder alert with soft-pulse, +196 avatar cluster
3. **Logo cloud** — static monochrome marks (not a marquee — reads more B2B)
4. **Problem stats** — 4 `AnimatedCounter` stats with industry-estimate sources, on a recessed dark band
5. **Feature bento** — 6 asymmetric cards each with a real mini data viz; the SKU velocity heatmap is genuinely interactive (Radix Tooltip on every cell)
6. **How it works** — 4 steps with a scroll-tied SVG progress line
7. **Product deep-dive** — Radix Tabs with `layoutId` indicator + crossfade; 4 tabs each showing a believable dashboard mockup (ComposedChart, SKU table, draft PO list, KPI grid + BarChart)
8. **Case studies** — 4 quantified outcome cards with serif metrics + parallax
9. **Pricing** — 3 tiers with Monthly/Yearly Switch + crossfade + count-up, Growth tier visually elevated with gold radial glow, Tooltips on ambiguous features
10. **Integrations** — 8-mark grid with **real hand-crafted SVG icons** (Shopify, Amazon, WooCommerce, BigCommerce, NetSuite, ShipBob, ShipHero, Square), hover-lift with warm shadows
11. **FAQ** — Radix Accordion, 8 operational questions
12. **Contact form** — react-hook-form + zod, inline errors, success state replaces form, POSTs to `/api/contact`
13. **Final CTA + Footer** — gold glow banner + 4-column footer with validated newsletter signup and a deep warm band

### Real backend
- **`/api/contact`** — zod-validated POST handler. Logs the submission server-side and returns `{ ok: true }`. Documented as the swap-point for a real email/CRM integration (Resend, Mailgun, HubSpot, etc.).
- **`/api/newsletter`** — same pattern, zod-validated email, logs + returns success. Swap for Mailchimp / ConvertKit / Buttondown.

### Accessibility
- WCAG AA contrast in both light and dark modes (gold accent verified against both backgrounds).
- Full keyboard navigation — focus-visible states everywhere, focus trap in mobile drawer and dialogs.
- Radix primitives provide correct ARIA semantics for free (Tabs, Accordion, Dialog, Tooltip, Select, Switch).
- Every icon-only button has an `aria-label`.
- Single `<h1>` per page, strict logical heading nesting.
- All 96 heatmap cells have descriptive aria-labels ("Merino Crew, week 1, velocity 40%").

## Getting started

### Prerequisites
- Node.js 18.18+ (or Bun 1.3+)
- A package manager: npm, pnpm, yarn, or bun

### Install & run

```bash
# Clone and install
git clone <your-repo-url> cadence
cd cadence

# Pick your package manager:
npm install        # or: pnpm install / yarn install / bun install

# Copy env
cp .env.example .env

# Start dev server
npm run dev        # or: pnpm dev / yarn dev / bun dev
```

Open [http://localhost:3000](http://localhost:3000) — the page renders at the `/` route.

### Available scripts

| Script | What it does |
|---|---|
| `dev` | Starts Next.js dev server on port 3000 (Turbopack) |
| `build` | Production build with full TypeScript validation + standalone output |
| `start` | Serves the production build (requires `build` first) |
| `lint` | ESLint (Next.js + strict rules) |
| `db:push` | Pushes the Prisma schema to SQLite (only needed for Phase 2 app extension) |
| `db:generate` | Regenerates the Prisma client |

## Project structure

```
cadence/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── contact/route.ts        # zod-validated POST handler
│   │   │   └── newsletter/route.ts     # zod-validated POST handler
│   │   ├── globals.css                 # design tokens + bg utilities + base layer
│   │   ├── layout.tsx                  # fonts, ThemeProvider, metadata, zero-flash script
│   │   └── page.tsx                    # server-component composition of all 13 sections
│   ├── components/
│   │   ├── cadence/
│   │   │   ├── primitives/
│   │   │   │   ├── motion.tsx          # EASE, DURATION, useReducedMotion, AnimatedCounter, MagneticButton
│   │   │   │   └── scroll.tsx          # ParallaxLayer, ScrollProgressBar, StickyScrollStage
│   │   │   ├── sections/               # 14 section components (navbar, hero, ...footer)
│   │   │   ├── hero-dashboard.tsx      # the floating glass dashboard mockup
│   │   │   ├── integration-icons.tsx   # 8 hand-crafted SVG brand marks
│   │   │   ├── reveal.tsx              # whileInView scroll-reveal wrapper
│   │   │   ├── section-heading.tsx     # Eyebrow + H2Underline shared primitives
│   │   │   └── theme-toggle.tsx        # next-themes sun/moon switch
│   │   └── ui/                         # shadcn/ui primitives (do not modify)
│   ├── data/
│   │   └── demo.ts                     # single source of truth — SKUs, forecast, case studies, pricing, FAQ, integrations
│   └── lib/
│       ├── db.ts                       # Prisma client (unused at landing-page scope)
│       └── utils.ts                    # cn() helper
├── public/
│   └── favicon.svg                     # Cadence brand mark
├── prisma/
│   └── schema.prisma                   # empty schema — extend for Phase 2
├── .env.example
├── next.config.ts                      # standalone output, reactStrictMode, optimizePackageImports
├── tsconfig.json                       # strict, excludes env scaffolding
├── tailwind.config.ts
├── components.json                     # shadcn/ui config
├── eslint.config.mjs
└── README.md
```

## Customizing in 10 minutes

### 1. Brand & content — `src/data/demo.ts`

Every chart, table, mockup, pricing card, FAQ, case study, and integration on the page imports from this single file. Change values here and every consumer updates atomically.

```ts
// Swap the placeholder brand
export const navLinks = [
  { label: "Product", href: "#product" },
  // ...
];

// Edit the 18 demo SKUs
export const skus: Sku[] = [
  { id: "s1", name: "Your Product Name", sku: "YOUR-SKU-001", price: 128, /* ... */ },
];

// Edit pricing tiers (single source of truth — referenced by both the landing teaser and full pricing section)
export const pricingTiers: PricingTier[] = [ /* ... */ ];
```

### 2. Colors & typography — `src/app/globals.css`

All design tokens live as CSS variables in `:root` (light) and `.dark` (dark). Change once, applies everywhere.

```css
:root {
  --bg: #faf7f1;           /* page background */
  --accent-gold: #b8863a;  /* primary accent */
  --accent-teal: #2e5e52;  /* secondary accent */
  /* ... */
}
```

To swap the display font, change the `next/font/google` import in `src/app/layout.tsx` and update `--font-serif` in `globals.css`.

### 3. Background treatments — `src/app/globals.css`

Each section's background is a CSS utility class (`.bg-hero-glow`, `.bg-bento-wash`, `.bg-case-glow`, `.bg-integrations-wash`, `.bg-contact-wash`, etc.). Tweak the radial gradient position, opacity, or color stops to retune the visual rhythm.

### 4. Wire real backend — `src/app/api/contact/route.ts` and `src/app/api/newsletter/route.ts`

Both routes currently `console.log` the validated payload and return `{ ok: true }`. Swap the `console.log` line for your provider call:

```ts
// Resend example
import { Resend } from "resend";
const resend = new Resend(process.env.RESEND_API_KEY);
await resend.emails.send({
  from: process.env.CONTACT_FORM_FROM!,
  to: process.env.CONTACT_FORM_TO!,
  subject: `New demo request from ${parsed.data.name}`,
  html: `<p>${parsed.data.name} (${parsed.data.email}) at ${parsed.data.company}</p>
         <p>Team size: ${parsed.data.teamSize}</p>
         <p>${parsed.data.message ?? ""}</p>`,
});
```

Add the corresponding env vars to `.env` (see `.env.example`).

## What's real vs. illustrative

| Aspect | Status |
|---|---|
| Design system, motion, accessibility | Real — production-quality |
| Contact + newsletter forms | Real — validated client-side (zod), submitted to real API routes that validate server-side. The route handlers log submissions; swap in your email/CRM provider as documented above. |
| Theme toggle (zero-flash, system-aware) | Real |
| Mobile drawer, Tabs, Accordion, Dialog, Tooltip | Real — Radix primitives, full keyboard support |
| Charts (forecast, velocity, channel breakdown, reporting) | Real — rendered from the shared dataset via Recharts. Data is illustrative but internally consistent. |
| SKU table, case studies, pricing tiers, FAQ | Illustrative content — realistic but fictional companies and numbers. Swap via `src/data/demo.ts`. |
| Integration icons | Original hand-crafted SVG marks that evoke each brand without copying trademarked artwork. Replace with officially-licensed logos before commercial deployment if your license requires. |
| "Watch 90-sec overview" dialog | Real dialog, lazy-loads on open. The video asset itself is a placeholder — drop in your embed (YouTube/Vimeo/Wistia/Loom iframe) where the placeholder sits. |
| Avatars | Deterministic brand-colored initials (the spec's "acceptable alternative"). Swap for properly-licensed headshot photos in `src/data/demo.ts` `heroAvatars` if you have them. |

## Deployment

### Vercel (recommended)

```bash
vercel
```

Or connect your Git repo in the Vercel dashboard — Vercel auto-detects Next.js and applies the standalone output.

### Self-hosted (Docker)

The `next.config.ts` uses `output: "standalone"`, which produces a self-contained server:

```bash
npm run build
# Output: .next/standalone/ — copy this + .next/static/ + public/ into your Docker image
```

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY .next/standalone ./
COPY .next/static ./.next/static
COPY public ./public
EXPOSE 3000
ENV PORT=3000
CMD ["node", "server.js"]
```

### Environment variables

Only `DATABASE_URL` is required at landing-page scope (for Prisma client initialization, even though no DB queries run). Add email/CRM keys when you wire the contact/newsletter routes to real providers — see `.env.example`.

## Verification

The project is verified clean against:

| Check | Command | Result |
|---|---|---|
| ESLint | `bun run lint` | 0 errors, 0 warnings |
| TypeScript | `tsc --noEmit` | 0 errors |
| Production build | `next build` (with full TS validation) | Compiles successfully, 6 routes generated |
| Hydration | Agent Browser smoke-test | No hydration mismatches |
| Imports | Build-time resolution | 0 unresolved |
| Cursor audit | `getComputedStyle(el).cursor` on all clickable elements | 0 non-pointer across 174 elements |

## Phase 2 — extending to the full app

This template is landing-page scope. If you want the real working app behind Cadence (auth, real inventory database, real forecasting computed from actual data), the dataset shapes in `src/data/demo.ts` are designed to map directly onto Prisma models:

```prisma
model Sku {
  id           String   @id @default(cuid())
  name         String
  sku          String   @unique
  price        Int
  onHand       Int
  reorderPoint Int
  leadTimeDays Int
  status       StockStatus
  velocity30d  Float
  warehouse    Warehouse @relation(fields: [warehouseId], references: [id])
  warehouseId  String
  channels     Channel[]
}
```

The `/api/contact` and `/api/newsletter` route handlers are the documented integration points for your email/CRM provider.

## License

See `LICENSE`. Personal and commercial use permitted; resale as-is (rebranding required) is not.

---

**Built for operators.** Cadence is a fictional brand used to demonstrate the template — swap via `src/data/demo.ts`.
