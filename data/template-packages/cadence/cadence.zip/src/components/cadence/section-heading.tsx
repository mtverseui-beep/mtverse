"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useReducedMotion } from "./primitives/motion";
import { EASE } from "./primitives/motion";

/* ─────────────────────────────────────────────────────────────────────────────
   Section heading primitives — Task ID 4 Track 5.3 / 5.4

   - <Eyebrow> renders the eyebrow label with a small 6px gold square accent
     before the text (consistent across every section).
   - <H2Underline> renders the 32px gold underline that draws in via scaleX
     0→1 (300ms ease-out-expo) when the section scrolls into view.
   ─────────────────────────────────────────────────────────────────────────── */

interface EyebrowProps {
  children: React.ReactNode;
  className?: string;
}

export function Eyebrow({ children, className }: EyebrowProps) {
  return (
    <p
      className={cn(
        "inline-flex items-center gap-2 text-[0.8125rem] font-medium uppercase tracking-[0.08em] text-foreground-subtle",
        className,
      )}
    >
      <span className="size-1.5 rounded-sm bg-primary" aria-hidden="true" />
      {children}
    </p>
  );
}

interface H2UnderlineProps {
  className?: string;
  /** delay (s) before the draw-in animation starts */
  delay?: number;
}

export function H2Underline({ className, delay = 0.1 }: H2UnderlineProps) {
  const reduced = useReducedMotion();
  if (reduced) {
    return <span className={cn("h2-underline", className)} aria-hidden="true" />;
  }
  return (
    <motion.span
      className={cn("h2-underline", className)}
      aria-hidden="true"
      initial={{ scaleX: 0 }}
      whileInView={{ scaleX: 1 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ duration: 0.3, ease: EASE.outExpo, delay }}
    />
  );
}
