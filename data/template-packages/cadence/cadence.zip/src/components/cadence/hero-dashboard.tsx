"use client";

import * as React from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AlertTriangle, TrendingDown, Check, Box, ArrowUpRight } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { forecastSeries, heroSkus, type Sku, type StockStatus } from "@/data/demo";
import { useReducedMotion } from "@/components/cadence/primitives/motion";
import { ParallaxLayer } from "@/components/cadence/primitives/scroll";

const statusConfig: Record<
  StockStatus,
  {
    label: string;
    icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
    className: string;
    dotColor: string;
  }
> = {
  "in-stock": {
    label: "In stock",
    icon: Check,
    className: "text-status-in-stock-fg bg-status-in-stock-bg",
    dotColor: "var(--status-in-stock)",
  },
  low: {
    label: "Low",
    icon: TrendingDown,
    className: "text-status-low-fg bg-status-low-bg",
    dotColor: "var(--status-low)",
  },
  critical: {
    label: "Critical",
    icon: AlertTriangle,
    className: "text-status-critical-fg bg-status-critical-bg",
    dotColor: "var(--status-critical)",
  },
  overstock: {
    label: "Overstock",
    icon: ArrowUpRight,
    className: "text-status-overstock-fg bg-status-overstock-bg",
    dotColor: "var(--status-overstock)",
  },
};

function SkuRow({ sku }: { sku: Sku }) {
  const s = statusConfig[sku.status];
  const Icon = s.icon;
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border/60 py-2.5 last:border-b-0">
      <div className="min-w-0 flex-1">
        <div className="truncate text-[13px] font-medium text-foreground">
          {sku.name}
        </div>
        <div className="font-data text-[11px] text-foreground-subtle">
          {sku.sku}
        </div>
      </div>
      <div className="flex items-center gap-3">
        <div className="text-right">
          <div className="font-data text-sm font-medium tabular-nums text-foreground">
            {sku.onHand.toLocaleString("en-US")}
          </div>
          <div className="text-[10px] uppercase tracking-wide text-foreground-subtle">
            on-hand
          </div>
        </div>
        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium ${s.className}`}
        >
          {/* Track 5.7 — 4px status dot indicator before the text */}
          <span
            className="size-1 rounded-full"
            style={{ background: s.dotColor }}
            aria-hidden="true"
          />
          <Icon className="size-3" strokeWidth={1.5} />
          {s.label}
        </span>
      </div>
    </div>
  );
}

function CustomTooltip({ active, payload }: any) {
  if (!active || !payload || !payload.length) return null;
  const p = payload[0]?.payload;
  if (!p) return null;
  return (
    <div className="rounded-md border border-border bg-surface/95 px-2.5 py-1.5 text-xs shadow-md backdrop-blur">
      <div className="font-data text-[11px] text-foreground-subtle">{p.date}</div>
      {p.actual != null && (
        <div className="font-data text-foreground">
          actual: <span className="font-medium">{p.actual}</span>
        </div>
      )}
      {p.isFuture && (
        <>
          <div className="font-data text-foreground">
            forecast: <span className="font-medium">{p.forecast}</span>
          </div>
          <div className="font-data text-[10px] text-foreground-subtle">
            band {p.lower}–{p.upper}
          </div>
        </>
      )}
    </div>
  );
}

export function HeroDashboard() {
  const reduced = useReducedMotion();
  const chartData = React.useMemo(
    () =>
      forecastSeries.map((p) => ({
        date: p.date,
        actual: p.actual,
        forecast: p.forecast,
        lower: p.lower,
        upper: p.upper,
        isFuture: p.isFuture,
      })),
    [],
  );

  return (
    <div className="relative w-full">
      {/* KPI chips above the dashboard */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {[
          { label: "in-stock · 7d", value: "98.6%" },
          { label: "stockouts · 90d", value: "−34%" },
          { label: "dead stock freed", value: "$480K" },
        ].map((kpi) => (
          <span
            key={kpi.label}
            className="inline-flex cursor-default items-center gap-1.5 rounded-full border border-border bg-surface/80 px-3 py-1 text-xs backdrop-blur"
          >
            <span className="font-data font-medium tabular-nums text-foreground">
              {kpi.value}
            </span>
            <span className="text-foreground-subtle">{kpi.label}</span>
          </span>
        ))}
      </div>

      {/* Floating reorder alert (absolute, top-right) — parallax speed 0.4 */}
      <ParallaxLayer
        speed={0.4}
        className="pointer-events-none absolute -right-3 -top-2 z-20 sm:-right-6 sm:-top-4"
      >
        <div className="animate-soft-pulse pointer-events-auto w-[230px] rounded-xl border border-border bg-surface/95 p-3 shadow-warm-lg backdrop-blur-md">
          <div className="mb-1.5 flex items-center gap-2">
            <span className="flex size-7 items-center justify-center rounded-full bg-status-critical-bg text-status-critical-fg">
              <AlertTriangle className="size-3.5" strokeWidth={1.5} />
            </span>
            <div>
              <div className="text-[12px] font-semibold leading-tight text-foreground">
                Reorder recommended
              </div>
              <div className="text-[10px] text-foreground-subtle">
                Cashmere Watch Cap · lead 35d
              </div>
            </div>
          </div>
          <Button
            type="button"
            size="sm"
            className="h-7 w-full rounded-md px-2 text-[11px]"
            onClick={() =>
              toast.success("PO draft created", {
                description: "ACC-CSH-007 · 240 units · supplier notified",
              })
            }
          >
            Approve PO
          </Button>
        </div>
      </ParallaxLayer>

      {/* Glass-edged dashboard */}
      <div className="relative overflow-hidden rounded-2xl border border-border bg-surface/80 shadow-xl backdrop-blur-xl ring-1 ring-inset ring-white/10 dark:ring-white/5">
        {/* Track 5.5 — top-edge highlight: 1px gradient line transparent → gold/30 → transparent */}
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-px"
          style={{
            background:
              "linear-gradient(to right, transparent, color-mix(in srgb, var(--accent-gold) 30%, transparent), transparent)",
          }}
          aria-hidden="true"
        />

        <div className="grid grid-cols-1 lg:grid-cols-5">
          {/* Left: forecast chart */}
          <div className="lg:col-span-3 border-b border-border p-4 sm:p-6 lg:border-b-0 lg:border-r">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
                  Forecast · 14d horizon
                </div>
                <div className="font-display text-base font-medium text-foreground">
                  Heavyweight Merino Crew
                </div>
              </div>
              <div className="flex items-center gap-3 text-[11px]">
                <span className="inline-flex items-center gap-1.5 text-foreground-muted">
                  <span
                    className="size-2 rounded-full"
                    style={{ background: "var(--accent-teal)" }}
                  />
                  Actual
                </span>
                <span className="inline-flex items-center gap-1.5 text-foreground-muted">
                  <span
                    className="size-2 rounded-full"
                    style={{ background: "var(--accent-gold)" }}
                  />
                  Forecast
                </span>
              </div>
            </div>
            <div className="h-[200px] w-full sm:h-[240px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={chartData}
                  margin={{ top: 5, right: 4, left: -22, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="heroBandFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--accent-gold)" stopOpacity={0.22} />
                      <stop offset="100%" stopColor="var(--accent-gold)" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    stroke="var(--border-hairline)"
                    strokeDasharray="2 4"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "var(--text-tertiary)", fontSize: 10, fontFamily: "var(--font-mono)" }}
                    tickLine={false}
                    axisLine={false}
                    minTickGap={28}
                    tickFormatter={(d: string) => d.slice(5)}
                  />
                  <YAxis
                    tick={{ fill: "var(--text-tertiary)", fontSize: 10, fontFamily: "var(--font-mono)" }}
                    tickLine={false}
                    axisLine={false}
                    width={42}
                  />
                  <Tooltip
                    content={<CustomTooltip />}
                    cursor={{ stroke: "var(--border-emphasis)", strokeDasharray: "3 3" }}
                  />
                  {/* Confidence band */}
                  <Area
                    type="monotone"
                    dataKey="upper"
                    stroke="none"
                    fill="url(#heroBandFill)"
                    isAnimationActive={!reduced}
                    animationDuration={900}
                    animationEasing="ease-out"
                  />
                  <Area
                    type="monotone"
                    dataKey="lower"
                    stroke="none"
                    fill="var(--surface)"
                    isAnimationActive={!reduced}
                    animationDuration={900}
                    animationEasing="ease-out"
                  />
                  {/* Actual line */}
                  <Line
                    type="monotone"
                    dataKey="actual"
                    stroke="var(--accent-teal)"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={!reduced}
                    animationDuration={900}
                    animationEasing="ease-out"
                    connectNulls
                  />
                  {/* Forecast line */}
                  <Line
                    type="monotone"
                    dataKey="forecast"
                    stroke="var(--accent-gold)"
                    strokeWidth={2}
                    strokeDasharray="4 3"
                    dot={false}
                    isAnimationActive={!reduced}
                    animationDuration={900}
                    animationEasing="ease-out"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Right: SKU rows */}
          <div className="lg:col-span-2 p-4 sm:p-6">
            <div className="mb-3 flex items-center justify-between">
              <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
                Reorder queue
              </div>
              <span className="inline-flex cursor-default items-center gap-1 rounded-full bg-status-critical-bg px-2 py-0.5 text-[10px] font-medium text-status-critical-fg">
                <Box className="size-3" strokeWidth={1.5} />
                4 need attention
              </span>
            </div>
            <div className="space-y-0.5">
              {heroSkus.map((sku) => (
                <SkuRow key={sku.id} sku={sku} />
              ))}
            </div>
            <div className="mt-3 flex items-center justify-between border-t border-border/60 pt-3 text-[11px] text-foreground-subtle">
              <span>Synced 8s ago</span>
              <span className="inline-flex cursor-default items-center gap-1">
                <span className="size-1.5 rounded-full bg-status-in-stock animate-soft-pulse" />
                Live · 6 warehouses
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
