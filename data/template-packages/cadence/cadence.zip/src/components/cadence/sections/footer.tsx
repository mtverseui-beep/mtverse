"use client";

import * as React from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Activity, Twitter, Github, Linkedin, ArrowRight, Check, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { footerColumns } from "@/data/demo";

const schema = z.object({
  email: z.string().email("Enter a valid email address."),
});
type FormValues = z.infer<typeof schema>;

function NewsletterForm() {
  const [done, setDone] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: "" },
  });

  const onSubmit = async (values: FormValues) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) {
        setDone(false);
        return;
      }
      setDone(true);
      reset();
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="flex items-center gap-2 rounded-md border border-status-in-stock/40 bg-status-in-stock-bg px-3 py-2 text-[13px] text-status-in-stock-fg">
        <Check className="size-4" strokeWidth={2} />
        Subscribed — check your inbox to confirm.
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      noValidate
      className="flex flex-col gap-2"
    >
      <div className="flex gap-2">
        <Input
          type="email"
          placeholder="you@company.com"
          aria-label="Email address"
          aria-invalid={!!errors.email}
          className="border-white/10 bg-white/5 text-foreground placeholder:text-foreground-subtle"
          {...register("email")}
        />
        <Button
          type="submit"
          size="sm"
          disabled={submitting}
          className="shrink-0 rounded-md"
          aria-label="Subscribe to newsletter"
        >
          {submitting ? (
            <Loader2 className="size-4 animate-spin" strokeWidth={1.5} />
          ) : (
            <ArrowRight className="size-4" strokeWidth={1.5} />
          )}
        </Button>
      </div>
      {errors.email && (
        <p className="text-[11px] text-status-critical-fg">
          {errors.email.message}
        </p>
      )}
    </form>
  );
}

const social = [
  { icon: Twitter, label: "Cadence on Twitter", href: "#legal" },
  { icon: Github, label: "Cadence on GitHub", href: "#legal" },
  { icon: Linkedin, label: "Cadence on LinkedIn", href: "#legal" },
];

export function Footer() {
  return (
    <footer className="mt-auto border-t border-white/5 bg-footer">
      <div className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-6">
          {/* Brand + newsletter */}
          <div className="col-span-2">
            <Link href="#top" className="flex items-center gap-2" aria-label="Cadence — back to top">
              {/* Track 5.8 — logo mark sits in a tinted chip matching the navbar */}
              <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <Activity className="size-4" strokeWidth={1.5} />
              </span>
              <span className="font-display text-lg font-medium tracking-tight text-foreground">
                Cadence
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-[1.6] text-foreground-muted">
              Inventory intelligence for retail &amp; DTC operators. Know what to reorder before you run out.
            </p>
            <div className="mt-5 flex items-center gap-2">
              {social.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  className="flex size-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-foreground-muted transition-colors hover:border-white/20 hover:text-foreground"
                >
                  <s.icon className="size-4" strokeWidth={1.5} />
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {footerColumns.map((col) => (
            <div key={col.title}>
              <h3 className="text-xs font-medium uppercase tracking-[0.08em] text-foreground-subtle">
                {col.title}
              </h3>
              <ul className="mt-4 flex flex-col gap-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      className="link-underline text-sm text-foreground-muted transition-colors hover:text-foreground"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter row */}
        <div className="mt-12 grid grid-cols-1 gap-4 border-t border-white/5 pt-8 md:grid-cols-2">
          <div>
            <h3 className="text-xs font-medium uppercase tracking-[0.08em] text-foreground-subtle">
              The operator&apos;s brief
            </h3>
            <p className="mt-2 max-w-md text-sm leading-[1.6] text-foreground-muted">
              A monthly note on inventory ops, demand forecasting, and what we shipped. No spam, unsubscribe in one click.
            </p>
          </div>
          <div className="md:self-end md:justify-self-end md:w-full md:max-w-sm">
            <NewsletterForm />
          </div>
        </div>

        {/* Bottom row — pulsing teal status dot (Track 5.8) */}
        <div className="mt-10 flex flex-col items-start justify-between gap-3 border-t border-white/5 pt-6 sm:flex-row sm:items-center">
          <p className="text-xs text-foreground-subtle">
            © {new Date().getFullYear()} Cadence. Built for operators.
          </p>
          <a
            href="#legal"
            className="inline-flex cursor-pointer items-center gap-2 text-xs text-foreground-muted hover:text-foreground"
          >
            <span className="relative flex size-2">
              <span className="absolute inline-flex h-full w-full animate-pulse-teal rounded-full opacity-60" style={{ background: "var(--accent-teal)" }} />
              <span className="relative inline-flex size-2 rounded-full" style={{ background: "var(--accent-teal)" }} />
            </span>
            Status: All systems operational
          </a>
        </div>
      </div>
    </footer>
  );
}
