"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  Line,
  Area,
  ReferenceLine,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip as RTooltip,
} from "recharts";
import { Check, AlertTriangle, TrendingDown, ArrowUpRight, FileText } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow, H2Underline } from "@/components/cadence/section-heading";
import { useReducedMotion } from "@/components/cadence/primitives/motion";
import {
  forecastSeries,
  skus,
  deepDiveTabs,
  type StockStatus,
} from "@/data/demo";
import { toast } from "sonner";

const statusBadge: Record<StockStatus, { label: string; cls: string; dotColor: string }> = {
  "in-stock": { label: "In stock", cls: "text-status-in-stock-fg bg-status-in-stock-bg", dotColor: "var(--status-in-stock)" },
  low: { label: "Low", cls: "text-status-low-fg bg-status-low-bg", dotColor: "var(--status-low)" },
  critical: { label: "Critical", cls: "text-status-critical-fg bg-status-critical-bg", dotColor: "var(--status-critical)" },
  overstock: { label: "Overstock", cls: "text-status-overstock-fg bg-status-overstock-bg", dotColor: "var(--status-overstock)" },
};

const statusIcon: Record<StockStatus, React.ComponentType<{ className?: string; strokeWidth?: number }>> = {
  "in-stock": Check,
  low: TrendingDown,
  critical: AlertTriangle,
  overstock: ArrowUpRight,
};

// ─── Forecasting tab ─────────────────────────────────────────────────────────
function ForecastingTab() {
  const reduced = useReducedMotion();
  const data = React.useMemo(
    () =>
      forecastSeries.map((p) => ({
        date: p.date,
        actual: p.actual,
        forecast: p.forecast,
        lower: p.lower,
        upper: p.upper,
        isFuture: p.isFuture,
      })),
    [],
  );
  const reorderThreshold = 100;
  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div className="lg:col-span-2 rounded-xl border border-border bg-surface p-5">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
              75-day forecast · Heavyweight Merino Crew
            </div>
            <div className="font-display text-base font-medium text-foreground">
              Actual + 14-day predicted demand with confidence band
            </div>
          </div>
          <div className="hidden items-center gap-3 text-[11px] sm:flex">
            <span className="inline-flex items-center gap-1.5 text-foreground-muted">
              <span className="size-2 rounded-full" style={{ background: "var(--accent-teal)" }} />
              Actual
            </span>
            <span className="inline-flex items-center gap-1.5 text-foreground-muted">
              <span className="size-2 rounded-full" style={{ background: "var(--accent-gold)" }} />
              Forecast
            </span>
            <span className="inline-flex items-center gap-1.5 text-foreground-muted">
              <span className="size-2 rounded-full border border-dashed" style={{ borderColor: "var(--status-critical)" }} />
              Reorder point
            </span>
          </div>
        </div>
        <div className="h-[280px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 5, right: 8, left: -22, bottom: 0 }}>
              <defs>
                <linearGradient id="ddBand" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--accent-gold)" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="var(--accent-gold)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="var(--border-hairline)" strokeDasharray="2 4" vertical={false} />
              <XAxis
                dataKey="date"
                tick={{ fill: "var(--text-tertiary)", fontSize: 10, fontFamily: "var(--font-mono)" }}
                tickLine={false}
                axisLine={false}
                minTickGap={28}
                tickFormatter={(d: string) => d.slice(5)}
              />
              <YAxis
                tick={{ fill: "var(--text-tertiary)", fontSize: 10, fontFamily: "var(--font-mono)" }}
                tickLine={false}
                axisLine={false}
                width={42}
              />
              <RTooltip
                cursor={{ stroke: "var(--border-emphasis)", strokeDasharray: "3 3" }}
                content={({ active, payload }: any) => {
                  if (!active || !payload?.length) return null;
                  const p = payload[0].payload;
                  return (
                    <div className="rounded-md border border-border bg-surface/95 px-2.5 py-1.5 text-xs shadow-md backdrop-blur">
                      <div className="font-data text-[11px] text-foreground-subtle">{p.date}</div>
                      {p.actual != null && (
                        <div className="font-data text-foreground">
                          actual: <span className="font-medium">{p.actual}</span>
                        </div>
                      )}
                      {p.isFuture && (
                        <div className="font-data text-foreground">
                          forecast: <span className="font-medium">{p.forecast}</span>
                          <span className="text-foreground-subtle"> (band {p.lower}–{p.upper})</span>
                        </div>
                      )}
                    </div>
                  );
                }}
              />
              <Area type="monotone" dataKey="upper" stroke="none" fill="url(#ddBand)" isAnimationActive={!reduced} animationDuration={700} />
              <Area type="monotone" dataKey="lower" stroke="none" fill="var(--surface)" isAnimationActive={!reduced} animationDuration={700} />
              <ReferenceLine y={reorderThreshold} stroke="var(--status-critical)" strokeDasharray="4 3" />
              <Line type="monotone" dataKey="actual" stroke="var(--accent-teal)" strokeWidth={2} dot={false} isAnimationActive={!reduced} animationDuration={700} connectNulls />
              <Line type="monotone" dataKey="forecast" stroke="var(--accent-gold)" strokeWidth={2} strokeDasharray="4 3" dot={false} isAnimationActive={!reduced} animationDuration={700} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="flex flex-col gap-4">
        <div className="rounded-xl border border-border bg-surface p-5">
          <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
            Model accuracy
          </div>
          <div className="mt-3 space-y-3">
            {[
              { horizon: "30 days", acc: "87%", mape: "MAPE 13%" },
              { horizon: "90 days", acc: "78%", mape: "MAPE 22%" },
            ].map((m) => (
              <div key={m.horizon} className="flex items-center justify-between border-b border-border/60 pb-3 last:border-b-0 last:pb-0">
                <div>
                  <div className="text-sm font-medium text-foreground">{m.horizon}</div>
                  <div className="font-data text-[11px] text-foreground-subtle">{m.mape}</div>
                </div>
                <div className="font-display text-2xl font-medium text-foreground tabular-nums">{m.acc}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-xl border border-border bg-surface-alt/60 p-5">
          <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
            Method
          </div>
          <p className="mt-2 text-sm leading-[1.6] text-foreground-muted">
            Per-SKU seasonal exponential smoothing, weekly seasonality + supplier lead-time awareness. Slow-movers fall back to a moving average. New SKUs use a category baseline until 14d of history accrues.
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Multi-channel sync tab ──────────────────────────────────────────────────
function SyncTab() {
  const rows = skus.slice(0, 8);
  return (
    <div className="rounded-xl border border-border bg-surface p-2 sm:p-5">
      <div className="mb-3 flex items-center justify-between px-3 pt-2 sm:px-0 sm:pt-0">
        <div>
          <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
            Multi-channel sync · 8 of 18 SKUs
          </div>
          <div className="font-display text-base font-medium text-foreground">
            One ledger across every channel
          </div>
        </div>
        <span className="inline-flex cursor-default items-center gap-1.5 rounded-full bg-status-in-stock-bg px-2.5 py-1 text-[11px] font-medium text-status-in-stock-fg">
          <span className="size-1.5 rounded-full bg-status-in-stock animate-soft-pulse" />
          Live sync
        </span>
      </div>
      <Table>
        <TableHeader>
          <TableRow className="border-border">
            <TableHead className="text-foreground-muted">SKU</TableHead>
            <TableHead className="text-foreground-muted">Channels</TableHead>
            <TableHead className="text-right text-foreground-muted">On-hand</TableHead>
            <TableHead className="text-right text-foreground-muted">Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((s) => {
            const st = statusBadge[s.status];
            const Icon = statusIcon[s.status];
            return (
              <TableRow key={s.id} className="border-border">
                <TableCell>
                  <div className="font-medium text-foreground">{s.name}</div>
                  <div className="font-data text-[11px] text-foreground-subtle">{s.sku}</div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {s.channels.map((c) => (
                      <span
                        key={c}
                        className="inline-flex items-center rounded-md border border-border bg-surface-alt px-1.5 py-0.5 text-[10px] text-foreground-muted"
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <span className="font-data text-sm font-medium tabular-nums text-foreground">
                    {s.onHand.toLocaleString("en-US")}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <span className={`inline-flex cursor-default items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium ${st.cls}`}>
                    <span
                      className="size-1 rounded-full"
                      style={{ background: st.dotColor }}
                      aria-hidden="true"
                    />
                    <Icon className="size-3" strokeWidth={1.5} />
                    {st.label}
                  </span>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

// ─── Purchase orders tab ─────────────────────────────────────────────────────
const draftPOs = [
  { id: "PO-2041", supplier: "Cardiff Knitworks", skuCount: 4, total: 28640, status: "draft", eta: "28 days" },
  { id: "PO-2042", supplier: "Brambleton Tannery", skuCount: 2, total: 14820, status: "draft", eta: "42 days" },
  { id: "PO-2043", supplier: "Savannah Ceramics", skuCount: 3, total: 9840, status: "draft", eta: "21 days" },
];

function PurchaseOrdersTab() {
  const [approved, setApproved] = React.useState<string[]>([]);
  return (
    <div className="grid grid-cols-1 gap-4">
      {draftPOs.map((po) => {
        const isApproved = approved.includes(po.id);
        return (
          <div
            key={po.id}
            className="flex flex-col gap-4 rounded-xl border border-border bg-surface p-5 sm:flex-row sm:items-center sm:justify-between"
          >
            <div className="flex items-start gap-3">
              <span className="flex size-10 items-center justify-center rounded-xl bg-surface-alt text-foreground-muted">
                <FileText className="size-5" strokeWidth={1.5} />
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-data text-sm font-medium text-foreground">{po.id}</span>
                  <Badge
                    variant={isApproved ? "default" : "secondary"}
                    className={isApproved ? "bg-status-in-stock text-white" : "bg-surface-alt text-foreground-muted"}
                  >
                    {isApproved ? "Approved" : "Draft"}
                  </Badge>
                </div>
                <div className="mt-1 text-sm text-foreground-muted">
                  {po.supplier} · {po.skuCount} SKU{po.skuCount === 1 ? "" : "s"} · ETA {po.eta}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4 sm:gap-6">
              <div className="text-right">
                <div className="font-data text-lg font-medium tabular-nums text-foreground">
                  ${po.total.toLocaleString("en-US")}
                </div>
                <div className="text-[11px] text-foreground-subtle">total</div>
              </div>
              <Button
                type="button"
                size="sm"
                disabled={isApproved}
                onClick={() => {
                  setApproved((p) => [...p, po.id]);
                  toast.success(`${po.id} approved`, {
                    description: `${po.supplier} notified · ETA ${po.eta}`,
                  });
                }}
                className="rounded-full"
              >
                {isApproved ? (
                  <React.Fragment>
                    <Check className="size-4" strokeWidth={2} />
                    Approved
                  </React.Fragment>
                ) : (
                  "Approve PO"
                )}
              </Button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Reporting tab ───────────────────────────────────────────────────────────
function ReportingTab() {
  const reduced = useReducedMotion();
  const weeklyData = React.useMemo(() => {
    // derive last 8 weeks from forecastSeries.actual, aggregated weekly
    const actuals = forecastSeries.filter((p) => p.actual != null).slice(-56);
    const weeks: { week: string; units: number }[] = [];
    for (let i = 0; i < actuals.length; i += 7) {
      const slice = actuals.slice(i, i + 7);
      const sum = slice.reduce((acc, p) => acc + (p.actual ?? 0), 0);
      weeks.push({ week: `W${i / 7 + 1}`, units: sum });
    }
    return weeks;
  }, []);

  const kpis = [
    { label: "In-stock rate · 7d", value: "98.6%", delta: "+1.2pts", trend: "up" },
    { label: "Stockouts · 90d", value: "−34%", delta: "vs prior", trend: "up" },
    { label: "Dead stock freed", value: "$480K", delta: "this Q", trend: "up" },
    { label: "PO cycle time", value: "−11d", delta: "median", trend: "up" },
  ];

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <div className="grid grid-cols-2 gap-4">
        {kpis.map((k) => (
          <div key={k.label} className="rounded-xl border border-border bg-surface p-4">
            <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
              {k.label}
            </div>
            <div className="mt-2 font-display text-2xl font-medium tabular-nums text-foreground">
              {k.value}
            </div>
            <div className="mt-1 flex items-center gap-1 text-[11px] text-status-in-stock-fg">
              <ArrowUpRight className="size-3" strokeWidth={1.5} />
              {k.delta}
            </div>
          </div>
        ))}
      </div>
      <div className="rounded-xl border border-border bg-surface p-5">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
              Weekly sell-through · last 8 weeks
            </div>
            <div className="font-display text-base font-medium text-foreground">
              Aggregate units shipped
            </div>
          </div>
        </div>
        <div className="h-[220px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weeklyData} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
              <CartesianGrid stroke="var(--border-hairline)" strokeDasharray="2 4" vertical={false} />
              <XAxis
                dataKey="week"
                tick={{ fill: "var(--text-tertiary)", fontSize: 10, fontFamily: "var(--font-mono)" }}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                tick={{ fill: "var(--text-tertiary)", fontSize: 10, fontFamily: "var(--font-mono)" }}
                tickLine={false}
                axisLine={false}
                width={42}
              />
              <RTooltip
                cursor={{ fill: "color-mix(in srgb, var(--accent-gold) 8%, transparent)" }}
                content={({ active, payload }: any) => {
                  if (!active || !payload?.length) return null;
                  return (
                    <div className="rounded-md border border-border bg-surface/95 px-2.5 py-1.5 text-xs shadow-md backdrop-blur">
                      <div className="font-data text-foreground">
                        {payload[0].payload.week}: <span className="font-medium">{payload[0].value}</span> units
                      </div>
                    </div>
                  );
                }}
              />
              <Bar
                dataKey="units"
                fill="var(--accent-gold)"
                radius={[4, 4, 0, 0]}
                isAnimationActive={!reduced}
                animationDuration={700}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

const TAB_CONTENT: Record<string, React.ReactNode> = {
  forecasting: <ForecastingTab />,
  sync: <SyncTab />,
  "purchase-orders": <PurchaseOrdersTab />,
  reporting: <ReportingTab />,
};

export function DeepDiveTabs() {
  const [active, setActive] = React.useState<string>("forecasting");
  const reduced = useReducedMotion();

  return (
    <section
      id="platform"
      aria-label="Product deep-dive"
      className="relative overflow-hidden border-t border-border bg-surface-alt py-24 sm:py-32"
    >
      {/* Track 4 — recessed dark section with subtle dot grid at low opacity */}
      <div
        className="pointer-events-none absolute inset-0 bg-dotgrid opacity-[0.04]"
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-10 max-w-3xl">
          <Reveal>
            <Eyebrow>Deep-dive</Eyebrow>
            <h2 className="mt-3 font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
              The dashboards your ops team will actually live in.
            </h2>
            <H2Underline />
          </Reveal>
          <Reveal delay={0.07}>
            <p className="mt-5 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
              Four product surfaces, four internally-consistent datasets. Switch tabs to see the forecast model, the multi-channel ledger, the PO queue, and the reporting view — every number is derived from the same source of truth in <span className="font-data text-sm">src/data/demo.ts</span>.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.07}>
          <Tabs
            value={active}
            onValueChange={setActive}
            className="w-full"
          >
            <TabsList className="h-auto flex-wrap justify-start gap-1 rounded-xl border border-border bg-surface p-1.5">
              {deepDiveTabs.map((t) => (
                <TabsTrigger
                  key={t.id}
                  value={t.id}
                  className="relative rounded-lg px-4 py-2 text-sm font-medium data-[state=active]:bg-transparent data-[state=active]:text-foreground data-[state=inactive]:text-foreground-muted data-[state=inactive]:hover:text-foreground shadow-none"
                >
                  {active === t.id && !reduced && (
                    <motion.span
                      layoutId="active-tab"
                      className="absolute inset-0 rounded-lg border border-border-strong bg-surface-alt"
                      transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-2">
                    <span className="text-[10px] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
                      {t.eyebrow}
                    </span>
                    <span>{t.label}</span>
                  </span>
                </TabsTrigger>
              ))}
            </TabsList>

            <div className="mt-6">
              <AnimatePresence mode="wait">
                <motion.div
                  key={active}
                  initial={reduced ? { opacity: 0 } : { opacity: 0, x: 4 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={reduced ? { opacity: 0 } : { opacity: 0, x: -4 }}
                  transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
                >
                  {TAB_CONTENT[active]}
                </motion.div>
              </AnimatePresence>
            </div>
          </Tabs>
        </Reveal>
      </div>
    </section>
  );
}
