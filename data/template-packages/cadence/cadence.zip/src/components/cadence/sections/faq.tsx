"use client";

import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow, H2Underline } from "@/components/cadence/section-heading";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "@/components/ui/accordion";
import { faqs } from "@/data/demo";

export function Faq() {
  return (
    <section
      id="changelog"
      aria-label="Frequently asked questions"
      className="py-24 sm:py-32"
    >
      <div className="mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <Reveal>
            <Eyebrow>FAQ</Eyebrow>
            <h2 className="mt-3 font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
              Questions operators actually ask.
            </h2>
            <H2Underline />
          </Reveal>
          <Reveal delay={0.07}>
            <p className="mt-5 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
              The questions below come straight from our sales calls — forecast methodology, implementation time, channel coverage, data residency, contract terms. If a question isn&apos;t answered here, the contact form below routes you to a real human within one business day.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.07}>
          <Accordion
            type="single"
            collapsible
            defaultValue="faq-0"
            className="rounded-2xl border border-border bg-surface px-5 sm:px-7"
          >
            {faqs.map((f, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="border-border last:border-b-0"
              >
                <AccordionTrigger className="text-left text-[15px] font-medium text-foreground hover:no-underline">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm leading-[1.65] text-foreground-muted">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  );
}
