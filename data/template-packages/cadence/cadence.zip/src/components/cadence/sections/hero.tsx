"use client";

import * as React from "react";
import Link from "next/link";
import { Play, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { MagneticButton } from "@/components/cadence/primitives/motion";
import { ParallaxLayer } from "@/components/cadence/primitives/scroll";
import { Eyebrow } from "@/components/cadence/section-heading";
import { HeroDashboard } from "@/components/cadence/hero-dashboard";
import { heroAvatars } from "@/data/demo";

const avatarColors = [
  "var(--accent-gold)",
  "var(--accent-teal)",
  "var(--status-low)",
  "var(--status-overstock)",
  "var(--status-critical)",
  "var(--accent-gold)",
  "var(--accent-teal)",
];

function AvatarCluster() {
  return (
    <div className="flex items-center">
      <div className="flex -space-x-2">
        {heroAvatars.map((a, i) => (
          <span
            key={a.name}
            className="flex size-8 items-center justify-center rounded-full border-2 border-background text-[10px] font-semibold text-white"
            style={{ background: avatarColors[i % avatarColors.length] }}
            aria-label={a.name}
            title={a.name}
          >
            {a.initials}
          </span>
        ))}
      </div>
      <span className="ml-2.5 inline-flex cursor-default items-center justify-center rounded-full border border-border bg-surface px-2 py-1 text-[11px] font-medium text-foreground-muted">
        +196
      </span>
    </div>
  );
}

export function Hero() {
  return (
    <section
      id="top"
      aria-label="Hero"
      className="relative overflow-hidden bg-hero-glow"
    >
      {/* Architectural hairline grid that fades from top (visible) to bottom (transparent) */}
      <ParallaxLayer
        speed={0.15}
        className="pointer-events-none absolute inset-0"
      >
        <div className="absolute inset-0 bg-hero-grid-fade opacity-60" aria-hidden="true" />
        {/* keep the existing soft dot-grid atmosphere too */}
        <div
          className="absolute inset-0 bg-dotgrid opacity-[0.03]"
          aria-hidden="true"
        />
      </ParallaxLayer>

      {/* Subtle gold radial glow counter-scrolls very slowly */}
      <ParallaxLayer
        speed={0.08}
        className="pointer-events-none absolute inset-0"
      >
        <div className="absolute inset-0 bg-hero-glow" aria-hidden="true" />
      </ParallaxLayer>

      <div className="relative mx-auto w-full max-w-7xl px-4 pb-16 pt-16 sm:px-6 sm:pt-24 lg:px-8 lg:pb-24 lg:pt-28">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-8">
          {/* Left: copy */}
          <div className="lg:col-span-6">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-surface/70 px-3 py-1 text-[0.8125rem] font-medium uppercase tracking-[0.08em] text-foreground-muted backdrop-blur">
              <Eyebrow>Inventory Intelligence</Eyebrow>
            </div>

            <h1 className="font-display text-[clamp(2.75rem,2rem+4vw,5.5rem)] font-medium leading-[0.98] tracking-[-0.02em] text-foreground">
              Know what to reorder
              <br />
              <span className="text-foreground-muted">before you run out.</span>
            </h1>

            <p className="mt-6 max-w-xl text-[clamp(1.125rem,1.05rem+0.3vw,1.375rem)] leading-[1.5] text-foreground-muted">
              Cadence syncs stock across every warehouse and sales channel in real time, then runs a per-SKU forecast so reorder points update themselves. You stop firefighting POs on Mondays and start shipping on schedule.
            </p>

            <div className="mt-8 flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:gap-4">
              <MagneticButton>
                <Button asChild size="lg" className="h-11 rounded-full px-6 text-sm">
                  <Link href="#contact">
                    Book a demo
                    <ArrowRight className="size-4" strokeWidth={1.5} />
                  </Link>
                </Button>
              </MagneticButton>

              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="lg"
                    className="h-11 rounded-full px-4 text-sm font-medium text-foreground hover:bg-surface-alt"
                  >
                    <span className="flex size-6 items-center justify-center rounded-full border border-border bg-surface">
                      <Play className="size-3" strokeWidth={1.5} style={{ fill: "currentColor" }} />
                    </span>
                    Watch 90-sec overview
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="font-display text-xl font-medium">
                      Cadence in 90 seconds
                    </DialogTitle>
                    <DialogDescription>
                      A quick walkthrough of the forecast, reorder queue, and one-click PO flow.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="aspect-video w-full overflow-hidden rounded-lg border border-border bg-surface-alt">
                    <div className="flex h-full w-full items-center justify-center text-center">
                      <div className="max-w-sm px-6">
                        <div className="mx-auto mb-3 flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
                          <Play className="size-5" strokeWidth={1.5} style={{ fill: "currentColor" }} />
                        </div>
                        <p className="text-sm text-foreground-muted">
                          In the production template this slot loads a real embeddable walkthrough video on open. The dialog itself loads only when triggered — never pre-loaded on the page.
                        </p>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-5">
              <AvatarCluster />
              <p className="text-sm text-foreground-muted">
                Trusted by <span className="font-medium text-foreground">200+ retail &amp; DTC teams</span> across apparel, home goods, and footwear.
              </p>
            </div>
          </div>

          {/* Right: hero dashboard */}
          <div className="lg:col-span-6">
            <HeroDashboard />
          </div>
        </div>
      </div>
    </section>
  );
}
