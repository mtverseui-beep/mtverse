import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/cadence/reveal";
import { MagneticButton } from "@/components/cadence/primitives/motion";
import { ParallaxLayer } from "@/components/cadence/primitives/scroll";
import { Eyebrow } from "@/components/cadence/section-heading";

export function FinalCta() {
  return (
    <section
      aria-label="Get started"
      className="relative overflow-hidden bg-surface-alt py-24 sm:py-32"
    >
      {/* Track 3 — parallax glow layer (speed 0.12) */}
      <ParallaxLayer
        speed={0.12}
        className="pointer-events-none absolute inset-0"
      >
        <div className="absolute inset-0 bg-cta-glow" aria-hidden="true" />
      </ParallaxLayer>

      <div className="relative mx-auto w-full max-w-3xl px-4 text-center sm:px-6 lg:px-8">
        <Reveal>
          <div className="flex justify-center">
            <Eyebrow>Stop guessing</Eyebrow>
          </div>
          <h2 className="mt-3 font-display text-[clamp(2.25rem,1.8rem+2.5vw,4rem)] font-medium leading-[1.04] tracking-[-0.018em] text-foreground">
            Stop guessing what to reorder.
          </h2>
        </Reveal>
        <Reveal delay={0.07}>
          <p className="mt-5 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
            Set up in under a day. No credit card required for a demo. The first forecast against your real catalog runs in 30–60 minutes.
          </p>
        </Reveal>
        <Reveal delay={0.14}>
          <div className="mt-8 flex justify-center">
            <MagneticButton>
              <Button asChild size="lg" className="rounded-full px-6">
                <Link href="#contact">
                  Book a demo
                  <ArrowRight className="size-4" strokeWidth={1.5} />
                </Link>
              </Button>
            </MagneticButton>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
