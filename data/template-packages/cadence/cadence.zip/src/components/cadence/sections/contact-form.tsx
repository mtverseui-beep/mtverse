"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { CheckCircle2, Loader2, ShieldCheck, Clock, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow, H2Underline } from "@/components/cadence/section-heading";
import { toast } from "sonner";

const schema = z.object({
  name: z.string().min(2, "Please enter your full name (2+ characters)."),
  email: z.string().email("Enter a valid work email address."),
  company: z.string().min(1, "Company name is required."),
  teamSize: z.string().min(1, "Pick a team size range."),
  message: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

export function ContactForm() {
  const [submitted, setSubmitted] = React.useState<{ email: string } | null>(null);
  const [submitting, setSubmitting] = React.useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", email: "", company: "", teamSize: "", message: "" },
  });

  const teamSizeValue = watch("teamSize");

  const onSubmit = async (values: FormValues) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        if (data?.errors) {
          // Surface field-level errors from the server
          for (const [k, v] of Object.entries<any>(data.errors)) {
            const arr = Array.isArray(v) ? v : [v];
            toast.error(`${k}: ${arr[0]?.message ?? "invalid"}`);
          }
        } else {
          toast.error("Something went wrong. Please try again.");
        }
        return;
      }
      setSubmitted({ email: values.email });
      reset();
    } catch {
      toast.error("Network error — please retry in a moment.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section
      id="contact"
      aria-label="Book a demo"
      className="relative overflow-hidden py-24 sm:py-32"
    >
      {/* Track 4 — soft warm gradient (diagonal bg → surface-alt) + faint gold radial behind the form column */}
      <div
        className="pointer-events-none absolute inset-0 bg-contact-wash"
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-16">
          {/* Left: pitch + trust */}
          <div>
            <Reveal>
              <Eyebrow>Book a demo</Eyebrow>
              <h2 className="mt-3 font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
                See Cadence on your own inventory.
              </h2>
              <H2Underline />
            </Reveal>
            <Reveal delay={0.07}>
              <p className="mt-5 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
                A 30-minute call with a product engineer. We&apos;ll plug Cadence into a sandboxed copy of your live catalog, walk through the forecast model on your top SKUs, and show the reorder-to-PO flow end to end. No slideware.
              </p>
            </Reveal>

            <Reveal delay={0.14}>
              <ul className="mt-8 flex flex-col gap-4">
                {[
                  {
                    icon: Zap,
                    title: "Setup in under a day",
                    body: "OAuth your storefront, import warehouse CSV or 3PL feed, first forecast within 30–60 minutes.",
                  },
                  {
                    icon: ShieldCheck,
                    title: "No credit card required",
                    body: "The demo is free and the trial doesn&apos;t ask for a card. You only enter billing when you decide to ship to production.",
                  },
                  {
                    icon: Clock,
                    title: "What happens next",
                    body: "We confirm the slot by email within one business day and send a calendar hold with a prep checklist.",
                  },
                ].map((b) => (
                  <li key={b.title} className="flex gap-3.5">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-surface-alt text-foreground-muted">
                      <b.icon className="size-4" strokeWidth={1.5} />
                    </span>
                    <div>
                      <div className="text-sm font-medium text-foreground">{b.title}</div>
                      <p className="mt-0.5 text-[13px] leading-[1.5] text-foreground-muted">
                        {b.body}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          {/* Right: form / success state */}
          <Reveal delay={0.07}>
            <div className="rounded-2xl border border-border bg-surface p-6 shadow-warm-sm sm:p-8">
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <span className="flex size-14 items-center justify-center rounded-full bg-status-in-stock-bg text-status-in-stock-fg">
                    <CheckCircle2 className="size-7" strokeWidth={1.5} />
                  </span>
                  <h3 className="mt-5 font-display text-xl font-medium text-foreground">
                    Thanks — we&apos;ll reach out within 1 business day.
                  </h3>
                  <p className="mt-2 text-sm text-foreground-muted">
                    A confirmation just went to{" "}
                    <span className="font-data text-foreground">{submitted.email}</span>.
                    Check your inbox (and spam folder) for a calendar hold.
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    className="mt-6 rounded-full"
                    onClick={() => setSubmitted(null)}
                  >
                    Submit another request
                  </Button>
                </div>
              ) : (
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  noValidate
                  className="flex flex-col gap-5"
                >
                  <div className="flex flex-col gap-2">
                    <Label htmlFor="cf-name">Full name</Label>
                    <Input
                      id="cf-name"
                      autoComplete="name"
                      placeholder="Marisol Chen"
                      aria-invalid={!!errors.name}
                      aria-describedby={errors.name ? "cf-name-error" : undefined}
                      {...register("name")}
                    />
                    {errors.name && (
                      <p id="cf-name-error" className="text-[12px] text-status-critical-fg">
                        {errors.name.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label htmlFor="cf-email">Work email</Label>
                    <Input
                      id="cf-email"
                      type="email"
                      autoComplete="email"
                      placeholder="marisol@northbound.co"
                      aria-invalid={!!errors.email}
                      aria-describedby={errors.email ? "cf-email-error" : undefined}
                      {...register("email")}
                    />
                    {errors.email && (
                      <p id="cf-email-error" className="text-[12px] text-status-critical-fg">
                        {errors.email.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label htmlFor="cf-company">Company</Label>
                    <Input
                      id="cf-company"
                      autoComplete="organization"
                      placeholder="Northbound Apparel"
                      aria-invalid={!!errors.company}
                      aria-describedby={errors.company ? "cf-company-error" : undefined}
                      {...register("company")}
                    />
                    {errors.company && (
                      <p id="cf-company-error" className="text-[12px] text-status-critical-fg">
                        {errors.company.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label htmlFor="cf-team">Team size</Label>
                    <Select
                      value={teamSizeValue}
                      onValueChange={(v) => setValue("teamSize", v, { shouldValidate: true })}
                    >
                      <SelectTrigger
                        id="cf-team"
                        className="w-full"
                        aria-invalid={!!errors.teamSize}
                      >
                        <SelectValue placeholder="Pick a range" />
                      </SelectTrigger>
                      <SelectContent>
                        {["1-10", "11-50", "51-200", "200+"].map((opt) => (
                          <SelectItem key={opt} value={opt}>
                            {opt}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.teamSize && (
                      <p className="text-[12px] text-status-critical-fg">
                        {errors.teamSize.message}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col gap-2">
                    <Label htmlFor="cf-message">
                      Message <span className="text-foreground-subtle">(optional)</span>
                    </Label>
                    <Textarea
                      id="cf-message"
                      rows={3}
                      placeholder="Tell us about your stack — channels, warehouses, biggest inventory pain."
                      {...register("message")}
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    disabled={submitting}
                    className="mt-1 w-full rounded-full"
                  >
                    {submitting ? (
                      <React.Fragment>
                        <Loader2 className="size-4 animate-spin" strokeWidth={1.5} />
                        Sending…
                      </React.Fragment>
                    ) : (
                      "Request demo"
                    )}
                  </Button>

                  <p className="text-center text-[11px] text-foreground-subtle">
                    By submitting you agree to our{" "}
                    <a href="#legal" className="link-underline text-foreground-muted hover:text-foreground">
                      privacy policy
                    </a>
                    . We&apos;ll never share your data.
                  </p>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
