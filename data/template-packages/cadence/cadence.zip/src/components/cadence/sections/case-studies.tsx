"use client";

import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow, H2Underline } from "@/components/cadence/section-heading";
import { ParallaxLayer } from "@/components/cadence/primitives/scroll";
import { useReducedMotion } from "@/components/cadence/primitives/motion";
import { caseStudies } from "@/data/demo";

const accentTint: Record<"gold" | "teal", string> = {
  gold: "var(--accent-gold)",
  teal: "var(--accent-teal)",
};

function initialsOf(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("");
}

function CaseMetric({
  value,
  tint,
  reduced,
}: {
  value: string;
  tint: string;
  reduced: boolean;
}) {
  // Wrap the metric in a ParallaxLayer with speed 0.1 for subtle parallax against the card.
  // We render the ParallaxLayer inline (it's a div with relative positioning) so it stacks
  // inside the card flow without breaking layout.
  if (reduced) {
    return (
      <div
        className="font-display text-[clamp(2.5rem,2rem+2vw,4rem)] font-medium leading-[1.02] tracking-[-0.02em] tabular-nums"
        style={{ color: tint }}
      >
        {value}
      </div>
    );
  }
  return (
    <ParallaxLayer
      speed={0.1}
      className="block"
    >
      <div
        className="font-display text-[clamp(2.5rem,2rem+2vw,4rem)] font-medium leading-[1.02] tracking-[-0.02em] tabular-nums"
        style={{ color: tint }}
      >
        {value}
      </div>
    </ParallaxLayer>
  );
}

export function CaseStudies() {
  const reduced = useReducedMotion();
  return (
    <section
      id="customers"
      aria-label="Case studies"
      className="relative overflow-hidden border-y border-border py-24 sm:py-32"
    >
      {/* Track 4 — warm gold radial centered behind the section */}
      <div
        className="pointer-events-none absolute inset-0 bg-case-glow"
        aria-hidden="true"
      />
      {/* paper-grain overlay */}
      <div
        className="pointer-events-none absolute inset-0 bg-noise"
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-12 max-w-3xl">
          <Reveal>
            <Eyebrow>Customers</Eyebrow>
            <h2 className="mt-3 font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
              Operators who stopped guessing.
            </h2>
            <H2Underline />
          </Reveal>
          <Reveal delay={0.07}>
            <p className="mt-5 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
              We don&apos;t trade in vague testimonials. Every card below is a quantified outcome against a real operational metric — stockout rate, working capital, lead time, peak-season in-stock — pulled from teams who switched off the spreadsheet-and-gut-feel loop.
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          {caseStudies.map((c, i) => {
            const tint = accentTint[c.accent];
            return (
              <Reveal key={c.id} delay={0.07 * i}>
                <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-surface p-6 shadow-warm-sm transition-all duration-300 ease-out hover:-translate-y-1 hover:border-border-strong hover:shadow-warm-md sm:p-8">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-3">
                        <span
                          className="flex size-11 items-center justify-center rounded-xl font-display text-base font-medium text-white"
                          style={{
                            background: `color-mix(in srgb, ${tint} 85%, transparent)`,
                          }}
                          aria-hidden="true"
                        >
                          {c.logoMark}
                        </span>
                        <div>
                          <div className="font-display text-base font-medium text-foreground">
                            {c.company}
                          </div>
                          <div className="text-[11px] text-foreground-subtle">
                            {c.industry}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="relative mt-7">
                    <CaseMetric value={c.resultMetric} tint={tint} reduced={reduced} />
                    <div className="mt-1 text-sm font-medium text-foreground">
                      {c.resultHeadline}
                    </div>
                    <div className="mt-0.5 text-[12px] text-foreground-subtle">
                      {c.resultSuffix}
                    </div>
                  </div>

                  <blockquote className="mt-6 flex-1 border-l-2 pl-4 text-sm leading-[1.6] text-foreground-muted" style={{ borderColor: `color-mix(in srgb, ${tint} 35%, transparent)` }}>
                    &ldquo;{c.bodyQuote}&rdquo;
                  </blockquote>

                  <div className="mt-6 flex items-center gap-3 border-t border-border/60 pt-5">
                    <span
                      className="flex size-9 items-center justify-center rounded-full text-[11px] font-semibold text-white"
                      style={{
                        background: `color-mix(in srgb, ${tint} 75%, transparent)`,
                      }}
                      aria-hidden="true"
                    >
                      {initialsOf(c.personName)}
                    </span>
                    <div>
                      <div className="text-sm font-medium text-foreground">
                        {c.personName}
                      </div>
                      <div className="text-[11px] text-foreground-subtle">
                        {c.personRole}
                      </div>
                    </div>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
