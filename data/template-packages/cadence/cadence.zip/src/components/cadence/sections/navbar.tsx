"use client";

import * as React from "react";
import Link from "next/link";
import { Activity, Menu } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/cadence/theme-toggle";
import { MagneticButton } from "@/components/cadence/primitives/motion";
import { navLinks } from "@/data/demo";

export function Navbar() {
  const [scrolled, setScrolled] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={[
        "sticky top-0 z-50 w-full transition-all duration-300",
        scrolled
          ? "bg-background/80 backdrop-blur-xl border-b border-border"
          : "bg-transparent border-b border-transparent",
      ].join(" ")}
    >
      <nav
        aria-label="Primary"
        className="mx-auto flex h-16 w-full max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8"
      >
        {/* Logo */}
        <Link
          href="#top"
          className="flex items-center gap-2 text-foreground hover:text-foreground"
          aria-label="Cadence — home"
        >
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Activity className="size-4" strokeWidth={1.5} />
          </span>
          <span className="font-display text-lg font-medium tracking-tight">
            Cadence
          </span>
        </Link>

        {/* Desktop nav */}
        <ul className="hidden items-center gap-7 md:flex">
          {navLinks.map((l) => (
            <li key={l.href}>
              <Link
                href={l.href}
                className="link-underline text-sm font-medium text-foreground-muted transition-colors hover:text-foreground"
              >
                {l.label}
              </Link>
            </li>
          ))}
        </ul>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <div className="hidden md:block">
            <ThemeToggle />
          </div>
          <Button
            asChild
            variant="ghost"
            className="hidden md:inline-flex text-sm font-medium text-foreground-muted hover:text-foreground hover:bg-transparent"
          >
            <Link href="#contact">Log in</Link>
          </Button>
          <MagneticButton className="hidden md:inline-block">
            <Button asChild size="sm" className="rounded-full px-4">
              <Link href="#contact">Book a demo</Link>
            </Button>
          </MagneticButton>

          {/* Mobile drawer */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden size-9 rounded-full border border-border bg-surface"
                aria-label="Open menu"
              >
                <Menu className="size-4" strokeWidth={1.5} />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[88vw] max-w-sm p-0">
              <SheetHeader className="px-6 pt-6">
                <SheetTitle className="font-display text-lg font-medium">
                  Cadence
                </SheetTitle>
                <SheetDescription className="text-sm text-foreground-muted">
                  Navigate to a section of the Cadence landing page.
                </SheetDescription>
              </SheetHeader>
              <nav
                aria-label="Mobile"
                className="flex flex-col gap-1 px-4 py-4"
              >
                {navLinks.map((l) => (
                  <SheetClose asChild key={l.href}>
                    <Link
                      href={l.href}
                      className="rounded-md px-3 py-3 text-base font-medium text-foreground-muted transition-colors hover:bg-surface-alt hover:text-foreground"
                    >
                      {l.label}
                    </Link>
                  </SheetClose>
                ))}
              </nav>
              <div className="mt-auto flex flex-col gap-3 border-t border-border px-6 py-5">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground-muted">Theme</span>
                  <ThemeToggle />
                </div>
                <Button asChild variant="outline" className="w-full">
                  <Link href="#contact">Log in</Link>
                </Button>
                <SheetClose asChild>
                  <Button asChild className="w-full rounded-full">
                    <Link href="#contact">Book a demo</Link>
                  </Button>
                </SheetClose>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}
