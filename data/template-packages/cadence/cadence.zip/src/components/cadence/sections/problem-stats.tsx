"use client";

import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow, H2Underline } from "@/components/cadence/section-heading";
import { AnimatedCounter } from "@/components/cadence/primitives/motion";
import { problemStats } from "@/data/demo";

export function ProblemStats() {
  return (
    <section
      id="problem"
      aria-label="The cost of guessing"
      className="relative overflow-hidden border-y border-border bg-surface-alt py-24 sm:py-32"
    >
      {/* Track 4 — recessed dark warm band with paper-grain overlay */}
      <div
        className="pointer-events-none absolute inset-0 bg-noise"
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <Reveal>
              <Eyebrow className="mb-4">The problem</Eyebrow>
              <h2 className="font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
                The cost of guessing.
              </h2>
              <H2Underline />
            </Reveal>
            <Reveal delay={0.07}>
              <p className="mt-6 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
                Most operators still run reorder planning out of a spreadsheet and a gut feel. The result is a quiet, recurring tax: stockouts that cost real revenue, dead stock that ties up working capital, and entire Mondays lost reconciling numbers across Shopify, Amazon, and a 3PL that syncs once a day.
              </p>
            </Reveal>
            <Reveal delay={0.14}>
              <p className="mt-4 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
                Cadence replaces that loop with a single live view and a per-SKU forecast you can act on — so the numbers below stop being a quarterly surprise and start being a dashboard you glance at.
              </p>
            </Reveal>
          </div>

          <div className="lg:col-span-7">
            <div className="grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-border bg-border shadow-warm-sm sm:grid-cols-2">
              {problemStats.map((stat, i) => (
                <Reveal
                  key={stat.label}
                  delay={0.07 * (i + 1)}
                  className="bg-surface p-6 sm:p-8"
                >
                  <div className="font-display text-[clamp(2.5rem,2rem+2vw,4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-foreground">
                    <AnimatedCounter
                      value={stat.value}
                      prefix={stat.prefix}
                      suffix={stat.suffix}
                      compact={"compact" in stat && stat.compact === true}
                    />
                  </div>
                  <p className="mt-3 text-sm leading-[1.5] text-foreground">
                    {stat.label}
                  </p>
                  <p className="mt-2 text-xs italic text-foreground-subtle">
                    {stat.source}
                  </p>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
