"use client";

import * as React from "react";
import { ArrowRight } from "lucide-react";
import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow, H2Underline } from "@/components/cadence/section-heading";
import { ScrollProgressBar } from "@/components/cadence/primitives/scroll";
import { processSteps } from "@/data/demo";

export function HowItWorks() {
  return (
    <section
      id="how"
      aria-label="How Cadence works"
      className="relative overflow-hidden border-y border-border py-24 sm:py-32"
    >
      {/* Track 4 — vertical gradient from bg (top) → surface-alt (bottom) */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "linear-gradient(to bottom, var(--bg) 0%, var(--surface-alt) 100%)",
        }}
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-14 max-w-3xl">
          <Reveal>
            <Eyebrow>How it works</Eyebrow>
            <h2 className="mt-3 font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
              From spreadsheet to live forecast in four steps.
            </h2>
            <H2Underline />
          </Reveal>
          <Reveal delay={0.07}>
            <p className="mt-5 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
              Onboarding a typical retail or DTC team takes under a day. You connect your channels, Cadence spends an hour learning your velocity, and from there reorder recommendations land in your inbox before the warehouse even flags low stock.
            </p>
          </Reveal>
        </div>

        {/* Desktop: horizontal with scroll-tied progress line */}
        <div className="relative hidden md:block">
          {/* Track + scroll-linked fill bar (replaces the old whileInView pathLength approach) */}
          <ScrollProgressBar
            className="left-0 right-0 top-9 w-full"
            height={2}
          />

          {/* Subtle vertical hairline through the center on desktop */}
          <div
            className="pointer-events-none absolute left-1/2 top-0 h-full w-px -translate-x-1/2 opacity-30"
            style={{ background: "var(--border-hairline)" }}
            aria-hidden="true"
          />

          <div className="relative grid grid-cols-4 gap-6">
            {processSteps.map((step, i) => (
              <Reveal key={step.step} delay={0.1 * i}>
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-3">
                    <div className="relative z-10 flex size-[72px] items-center justify-center rounded-full border border-border bg-surface shadow-warm-sm">
                      <span className="font-display text-2xl font-medium text-foreground">
                        {step.step}
                      </span>
                    </div>
                    {i < processSteps.length - 1 && (
                      <ArrowRight
                        className="size-4 text-foreground-subtle"
                        strokeWidth={1.5}
                      />
                    )}
                  </div>
                  <div>
                    <h3 className="font-display text-lg font-medium leading-tight text-foreground">
                      {step.title}
                    </h3>
                    <p className="mt-2 text-sm leading-[1.6] text-foreground-muted">
                      {step.body}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        {/* Mobile: vertical stack */}
        <div className="flex flex-col gap-6 md:hidden">
          {processSteps.map((step, i) => (
            <Reveal key={step.step} delay={0.07 * i}>
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="flex size-14 items-center justify-center rounded-full border border-border bg-surface shadow-warm-sm">
                    <span className="font-display text-lg font-medium text-foreground">
                      {step.step}
                    </span>
                  </div>
                  {i < processSteps.length - 1 && (
                    <div className="mt-2 w-px flex-1 bg-border-strong" />
                  )}
                </div>
                <div className="pb-2">
                  <h3 className="font-display text-base font-medium leading-tight text-foreground">
                    {step.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-[1.6] text-foreground-muted">
                    {step.body}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
