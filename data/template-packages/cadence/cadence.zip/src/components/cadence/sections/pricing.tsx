"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { Check, X, Info, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow, H2Underline } from "@/components/cadence/section-heading";
import { AnimatedCounter, useReducedMotion, MagneticButton } from "@/components/cadence/primitives/motion";
import { pricingTiers } from "@/data/demo";

type Cycle = "monthly" | "yearly";

export function Pricing() {
  const [cycle, setCycle] = React.useState<Cycle>("monthly");
  const reduced = useReducedMotion();

  return (
    <section
      id="pricing"
      aria-label="Pricing"
      className="relative overflow-hidden py-24 sm:py-32"
    >
      {/* Track 4 — flat bg with subtle dot grid at 2% opacity */}
      <div
        className="pointer-events-none absolute inset-0 bg-dotgrid opacity-[0.02]"
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-10 flex flex-col items-center text-center">
          <Reveal>
            <Eyebrow>Pricing</Eyebrow>
            <h2 className="mt-3 font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
              Priced for ops teams, not per-seat sprawl.
            </h2>
            <H2Underline className="mx-auto" />
          </Reveal>
          <Reveal delay={0.07}>
            <p className="mt-5 max-w-2xl text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
              Starter and Growth are month-to-month. Annual billing drops the per-month price by ~20% and unlocks priority support. Enterprise ships with a dedicated implementation engineer on a 12-month term — with a 60-day no-fault exit so you can walk away if onboarding isn&apos;t tracking.
            </p>
          </Reveal>

          {/* Toggle */}
          <Reveal delay={0.14}>
            <div className="mt-7 inline-flex items-center gap-1 rounded-full border border-border bg-surface p-1">
              <button
                type="button"
                onClick={() => setCycle("monthly")}
                aria-pressed={cycle === "monthly"}
                className="relative rounded-full px-4 py-1.5 text-sm font-medium transition-colors"
              >
                {cycle === "monthly" && !reduced && (
                  <motion.span
                    layoutId="cycle-pill"
                    className="absolute inset-0 rounded-full bg-surface-alt"
                    transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
                  />
                )}
                <span className={`relative z-10 ${cycle === "monthly" ? "text-foreground" : "text-foreground-muted"}`}>
                  Monthly
                </span>
              </button>
              <button
                type="button"
                onClick={() => setCycle("yearly")}
                aria-pressed={cycle === "yearly"}
                className="relative flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium transition-colors"
              >
                {cycle === "yearly" && !reduced && (
                  <motion.span
                    layoutId="cycle-pill"
                    className="absolute inset-0 rounded-full bg-surface-alt"
                    transition={{ duration: 0.25, ease: [0.4, 0, 0.2, 1] }}
                  />
                )}
                <span className={`relative z-10 ${cycle === "yearly" ? "text-foreground" : "text-foreground-muted"}`}>
                  Yearly
                </span>
                <span className="relative z-10 inline-flex items-center rounded-full bg-status-in-stock-bg px-1.5 py-0.5 text-[10px] font-semibold text-status-in-stock-fg">
                  Save 20%
                </span>
              </button>
            </div>
          </Reveal>
        </div>

        {/* Tier cards */}
        <div className="grid grid-cols-1 items-stretch gap-5 md:grid-cols-3">
          {pricingTiers.map((tier, i) => {
            const isFeatured = tier.featured;
            const isEnterprise = tier.id === "enterprise";
            const price = cycle === "monthly" ? tier.monthly : tier.yearly;
            return (
              <Reveal
                key={tier.id}
                delay={0.07 * i}
                className={isFeatured ? "md:-mt-3 md:mb-3" : ""}
              >
                <div
                  className={[
                    "relative flex h-full flex-col rounded-2xl border bg-surface p-6 transition-all duration-300 sm:p-7",
                    isFeatured
                      ? "border-primary/40 shadow-warm-lg md:scale-[1.03]"
                      : "border-border shadow-warm-sm hover:border-border-strong hover:shadow-warm-md",
                  ].join(" ")}
                >
                  {/* Track 5.6 — featured tier gets a continuous gold radial glow behind the card */}
                  {isFeatured && (
                    <div
                      className="pointer-events-none absolute inset-0 rounded-2xl bg-pricing-featured-glow"
                      aria-hidden="true"
                    />
                  )}
                  {isFeatured && (
                    <div className="absolute -top-3 left-1/2 z-10 -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.06em]">
                        Most popular
                      </Badge>
                    </div>
                  )}

                  <div className="relative z-10 flex flex-col">
                    <div className="mb-4">
                      <h3 className="font-display text-lg font-medium text-foreground">
                        {tier.name}
                      </h3>
                      <p className="mt-1 text-sm leading-[1.5] text-foreground-muted">
                        {tier.tagline}
                      </p>
                    </div>

                  {/* Price */}
                  <div className="mb-5 flex items-end gap-2">
                    {isEnterprise ? (
                      <div className="font-display text-[clamp(2.25rem,1.8rem+1.5vw,3rem)] font-medium leading-none text-foreground">
                        Custom
                      </div>
                    ) : (
                      <React.Fragment>
                        <span className="font-display text-2xl font-medium text-foreground-muted">
                          $
                        </span>
                        <AnimatePresence mode="wait" initial={false}>
                          <motion.div
                            key={`${tier.id}-${cycle}`}
                            initial={reduced ? { opacity: 0 } : { opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={reduced ? { opacity: 0 } : { opacity: 0, y: -8 }}
                            transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
                            className="font-display text-[clamp(2.5rem,2rem+2vw,3.5rem)] font-medium leading-none tabular-nums text-foreground"
                          >
                            <AnimatedCounter
                              value={price}
                              durationMs={500}
                            />
                          </motion.div>
                        </AnimatePresence>
                        <span className="mb-1 text-sm text-foreground-muted">/mo</span>
                      </React.Fragment>
                    )}
                  </div>
                  <div className="mb-5 text-[12px] text-foreground-subtle">
                    {isEnterprise
                      ? "Annual contract, custom volume"
                      : cycle === "yearly"
                        ? "billed annually"
                        : "billed monthly"}
                  </div>

                  {/* CTA */}
                  {isFeatured ? (
                    <MagneticButton className="block">
                      <Button asChild size="lg" className="w-full rounded-full">
                        <Link href="#contact">
                          {tier.cta}
                          <ArrowRight className="size-4" strokeWidth={1.5} />
                        </Link>
                      </Button>
                    </MagneticButton>
                  ) : (
                    <Button
                      asChild
                      size="lg"
                      variant={isEnterprise ? "outline" : "outline"}
                      className="w-full rounded-full"
                    >
                      <Link href="#contact">{tier.cta}</Link>
                    </Button>
                  )}

                  {/* Divider */}
                  <div className="my-6 h-px bg-border" />

                  {/* Features */}
                  <ul className="flex flex-col gap-2.5 text-sm">
                    {tier.features.map((f) => (
                      <li key={f.label} className="flex items-start gap-2.5">
                        {f.included ? (
                          <Check
                            className="mt-0.5 size-4 shrink-0 text-status-in-stock-fg"
                            strokeWidth={2}
                          />
                        ) : (
                          <X
                            className="mt-0.5 size-4 shrink-0 text-foreground-subtle"
                            strokeWidth={1.5}
                          />
                        )}
                        <span className={f.included ? "text-foreground" : "text-foreground-subtle line-through"}>
                          {f.label}
                        </span>
                        {f.tooltip && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                type="button"
                                className="ml-0.5 mt-0.5 inline-flex size-3.5 cursor-pointer items-center justify-center text-foreground-subtle hover:text-foreground"
                                aria-label={`More info: ${f.label}`}
                              >
                                <Info className="size-3.5" strokeWidth={1.5} />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-[220px]">
                              <p className="text-[11px] leading-[1.4]">{f.tooltip}</p>
                            </TooltipContent>
                          </Tooltip>
                        )}
                      </li>
                    ))}
                  </ul>

                  {/* Description */}
                  <p className="mt-6 text-[12px] leading-[1.5] text-foreground-subtle">
                    {tier.description}
                  </p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
