import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow, H2Underline } from "@/components/cadence/section-heading";
import { IntegrationIconSvg } from "@/components/cadence/integration-icons";
import { integrations } from "@/data/demo";

const categoryColor: Record<string, string> = {
  Storefront: "var(--accent-gold)",
  Marketplace: "var(--accent-teal)",
  ERP: "var(--status-overstock)",
  POS: "var(--status-low)",
  Shipping: "var(--status-critical)",
};

export function Integrations() {
  return (
    <section
      id="integrations"
      aria-label="Integrations"
      className="relative overflow-hidden py-24 sm:py-32"
    >
      {/* Integrations-wash background — horizontal "connection" gradient */}
      <div
        className="pointer-events-none absolute inset-0 bg-integrations-wash"
        aria-hidden="true"
      />

      <div className="relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-12 max-w-3xl">
          <Reveal>
            <Eyebrow>Integrations</Eyebrow>
            <h2 className="mt-3 font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
              Connects to the stack you already run.
            </h2>
            <H2Underline />
          </Reveal>
          <Reveal delay={0.07}>
            <p className="mt-5 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
              Native OAuth for the storefronts, a real-time feed for the 3PLs, and a generic REST/webhook layer for everything else. ERP sync (NetSuite, SAP, Dynamics) ships with Enterprise. If your stack is custom, our API covers the long tail — most teams are live in under a day.
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 md:grid-cols-4 md:gap-5">
          {integrations.map((it, i) => {
            const tint = categoryColor[it.category] ?? "var(--accent-gold)";
            return (
              <Reveal key={it.name} delay={0.05 * i}>
                <article className="group flex h-full flex-col gap-3 rounded-2xl border border-border bg-surface p-5 shadow-warm-sm transition-all duration-300 ease-out hover:-translate-y-1 hover:border-border-strong hover:shadow-warm-md sm:p-6">
                  <div className="flex items-center justify-between">
                    <span
                      className="flex size-12 items-center justify-center rounded-xl"
                      style={{
                        background: `color-mix(in srgb, ${tint} 14%, var(--surface-alt))`,
                        color: tint,
                      }}
                      aria-hidden="true"
                    >
                      <IntegrationIconSvg name={it.icon} className="size-6" />
                    </span>
                    <span
                      className="inline-flex cursor-default items-center rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide"
                      style={{
                        background: `color-mix(in srgb, ${tint} 14%, transparent)`,
                        color: tint,
                      }}
                    >
                      {it.category}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-display text-base font-medium text-foreground">
                      {it.name}
                    </h3>
                    <p className="mt-1.5 text-[13px] leading-[1.5] text-foreground-muted">
                      {it.blurb}
                    </p>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
