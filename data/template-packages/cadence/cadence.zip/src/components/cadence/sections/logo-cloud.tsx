import { Reveal } from "@/components/cadence/reveal";
import { Eyebrow } from "@/components/cadence/section-heading";
import { logoCloud } from "@/data/demo";

export function LogoCloud() {
  return (
    <section
      aria-label="Customers"
      className="border-y border-border py-14 sm:py-16"
    >
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="mb-9 flex justify-center">
            <Eyebrow>Powering inventory decisions at</Eyebrow>
          </div>
        </Reveal>
        <Reveal delay={0.08}>
          <ul className="grid grid-cols-2 items-center gap-x-6 gap-y-7 sm:grid-cols-3 lg:grid-cols-6">
            {logoCloud.map((logo) => (
              <li
                key={logo.name}
                className="flex items-center justify-center text-center"
              >
                <span className="font-display text-base font-medium tracking-[0.1em] text-foreground-muted transition-colors hover:text-foreground sm:text-lg">
                  {logo.mark}
                </span>
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
