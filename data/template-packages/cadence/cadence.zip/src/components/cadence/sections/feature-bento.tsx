"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  RefreshCw,
  TrendingUp,
  Grid3x3,
  Warehouse,
  FileCheck2,
  PieChart,
  Check,
  ArrowRight,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
} from "recharts";
import { Switch } from "@/components/ui/switch";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Reveal } from "@/components/cadence/reveal";
import { useReducedMotion } from "@/components/cadence/primitives/motion";
import { ParallaxLayer } from "@/components/cadence/primitives/scroll";
import { Eyebrow as SectionEyebrow, H2Underline } from "@/components/cadence/section-heading";
import {
  velocityHeatmap,
  warehouses,
  channelBreakdown,
  forecastSeries,
} from "@/data/demo";

// ─── shared card chrome ──────────────────────────────────────────────────────
function Card({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className={
        "group relative flex flex-col gap-4 rounded-2xl border border-border bg-surface p-6 shadow-warm-sm transition-all duration-300 ease-out hover:-translate-y-1 hover:border-border-strong hover:shadow-warm-md sm:p-7 " +
        (className ?? "")
      }
    >
      {children}
    </div>
  );
}

function IconChip({
  icon: Icon,
  tint = "var(--accent-gold)",
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  tint?: string;
}) {
  return (
    <span
      className="flex size-10 items-center justify-center rounded-xl"
      style={{
        background: `color-mix(in srgb, ${tint} 14%, transparent)`,
        color: tint,
      }}
    >
      <Icon className="size-5" strokeWidth={1.5} />
    </span>
  );
}

function CardEyebrow({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[0.8125rem] font-medium uppercase tracking-[0.08em] text-foreground-subtle">
      {children}
    </p>
  );
}

// ─── Card 1: Real-time stock sync ────────────────────────────────────────────
function SyncDiagram() {
  const channels = ["Shopify", "Amazon", "Wholesale"];
  return (
    <div className="mt-4 flex items-center justify-between gap-2 rounded-xl border border-border bg-surface-alt/60 p-4">
      {channels.map((c, i) => (
        <React.Fragment key={c}>
          <div className="flex flex-col items-center gap-2">
            <motion.span
              className="size-3 rounded-full"
              style={{ background: "var(--accent-teal)" }}
              animate={{ scale: [1, 1.35, 1], opacity: [0.7, 1, 0.7] }}
              transition={{
                duration: 1.6,
                repeat: Infinity,
                delay: i * 0.32,
                ease: "easeInOut",
              }}
            />
            <span className="font-data text-[10px] text-foreground-muted cursor-default">
              {c}
            </span>
          </div>
          {i < channels.length - 1 && (
            <div className="relative h-px flex-1 bg-border-strong">
              <motion.span
                className="absolute -top-[3px] size-1.5 rounded-full"
                style={{ background: "var(--accent-gold)" }}
                animate={{ left: ["0%", "100%"] }}
                transition={{
                  duration: 1.6,
                  repeat: Infinity,
                  delay: i * 0.32,
                  ease: "easeInOut",
                }}
              />
            </div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

// ─── Card 2: Predictive reorder points (mini LineChart with threshold) ───────
function ThresholdChart() {
  const reduced = useReducedMotion();
  const data = React.useMemo(
    () =>
      forecastSeries.slice(-30).map((p) => ({
        d: p.date,
        v: p.actual ?? p.forecast,
      })),
    [],
  );
  const threshold = 80;
  return (
    <div className="mt-4 h-[120px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 6, left: -28, bottom: 0 }}>
          <ReferenceLine
            y={threshold}
            stroke="var(--status-critical)"
            strokeDasharray="4 3"
            label={{
              value: "reorder point",
              fill: "var(--text-tertiary)",
              fontSize: 9,
              position: "insideTopRight",
            }}
          />
          <Line
            type="monotone"
            dataKey="v"
            stroke="var(--accent-gold)"
            strokeWidth={2}
            dot={false}
            isAnimationActive={!reduced}
            animationDuration={800}
            animationEasing="ease-out"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── Card 3: SKU velocity heatmap (interactive) ──────────────────────────────
function heatColor(v: number) {
  // 0 → surface-alt, 1 → accent-gold
  const pct = Math.round(v * 100);
  return `color-mix(in srgb, var(--accent-gold) ${pct}%, var(--surface-alt))`;
}

function Heatmap() {
  const weeks = velocityHeatmap[0].weeks.length;
  return (
    <div className="mt-4 overflow-x-auto">
      <div className="min-w-[420px]">
        {/* week labels */}
        <div className="mb-1 flex items-center gap-1 pl-[120px]">
          {Array.from({ length: weeks }).map((_, i) => (
            <div
              key={i}
              className="flex-1 text-center font-data text-[9px] text-foreground-subtle"
            >
              W{i + 1}
            </div>
          ))}
        </div>
        {/* rows */}
        <div className="flex flex-col gap-1">
          {velocityHeatmap.map((row) => (
            <div key={row.sku} className="flex items-center gap-1">
              <div className="w-[120px] truncate text-[11px] text-foreground-muted">
                {row.name}
              </div>
              {row.weeks.map((v, i) => (
                <Tooltip key={i}>
                  <TooltipTrigger asChild>
                    <div
                      className="aspect-square flex-1 cursor-pointer rounded-[3px] border border-border/40 transition-transform hover:scale-110 hover:border-border-strong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1"
                      style={{ background: heatColor(v) }}
                      tabIndex={0}
                      role="button"
                      aria-label={`${row.name}, week ${i + 1}, velocity ${(v * 100).toFixed(0)}%`}
                    />
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="font-data text-[11px]">
                      <div className="text-primary-foreground/80">{row.name}</div>
                      <div>
                        Week {i + 1}: <span className="font-semibold">{(v * 100).toFixed(0)}%</span>
                      </div>
                      <div className="text-primary-foreground/70">sell-through</div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              ))}
            </div>
          ))}
        </div>
        {/* legend */}
        <div className="mt-4 flex items-center justify-end gap-2 text-[10px] text-foreground-subtle">
          <span>low</span>
          <div
            className="h-2 w-20 rounded-full"
            style={{
              background:
                "linear-gradient(to right, var(--surface-alt), var(--accent-gold))",
            }}
          />
          <span>high</span>
        </div>
      </div>
    </div>
  );
}

// ─── Card 4: Multi-warehouse visibility ───────────────────────────────────────
const warehouseStatusColor: Record<string, string> = {
  healthy: "var(--accent-teal)",
  stretching: "var(--status-low)",
  critical: "var(--status-critical)",
};

function WarehouseGrid() {
  return (
    <div className="mt-4 grid grid-cols-2 gap-2">
      {warehouses.map((w) => {
        const size = 16 + Math.round((w.skuCount / 1842) * 28);
        const color = warehouseStatusColor[w.status];
        return (
          <Tooltip key={w.id}>
            <TooltipTrigger asChild>
              <div className="flex cursor-default items-center gap-2.5 rounded-lg border border-border bg-surface-alt/60 p-2.5 hover:border-border-strong">
                <span
                  className="block shrink-0 rounded-full"
                  style={{
                    width: size,
                    height: size,
                    background: `color-mix(in srgb, ${color} 75%, transparent)`,
                    boxShadow: `0 0 0 3px color-mix(in srgb, ${color} 18%, transparent)`,
                  }}
                  aria-hidden="true"
                />
                <div className="min-w-0">
                  <div className="truncate text-[11px] font-medium text-foreground">
                    {w.name}
                  </div>
                  <div className="font-data text-[10px] text-foreground-subtle">
                    {w.skuCount.toLocaleString("en-US")} SKUs · {Math.round(w.utilization * 100)}%
                  </div>
                </div>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <div className="font-data text-[11px]">
                <div className="text-primary-foreground/80">{w.name}</div>
                <div>{w.city}</div>
                <div>Status: <span className="capitalize">{w.status}</span></div>
              </div>
            </TooltipContent>
          </Tooltip>
        );
      })}
    </div>
  );
}

// ─── Card 5: Automated POs (Switch with animated label) ──────────────────────
function PoToggle() {
  const [approved, setApproved] = React.useState(false);
  return (
    <div className="mt-4 flex flex-col gap-3">
      <div className="flex items-center justify-between rounded-xl border border-border bg-surface-alt/60 p-4">
        <div className="flex flex-col gap-0.5">
          <div className="text-[11px] uppercase tracking-wide text-foreground-subtle">
            Draft PO
          </div>
          <div className="font-display text-sm font-medium text-foreground">
            PO-2041 · 240 units
          </div>
        </div>
        <Switch
          checked={approved}
          onCheckedChange={setApproved}
          aria-label="Approve purchase order"
        />
      </div>
      <div className="flex items-center gap-2 text-[11px] text-foreground-muted transition-colors">
        {approved ? (
          <React.Fragment>
            <Check className="size-3.5 text-status-in-stock-fg" strokeWidth={2} />
            <span>Approved · supplier notified · est. arrival in 28d</span>
          </React.Fragment>
        ) : (
          <React.Fragment>
            <span className="size-1.5 rounded-full bg-foreground-subtle" />
            <span>Pending review · awaiting your approval</span>
          </React.Fragment>
        )}
      </div>
    </div>
  );
}

// ─── Card 6: Channel breakdown (proportional stacked bar) ────────────────────
function ChannelBar() {
  const [hovered, setHovered] = React.useState<number | null>(null);
  return (
    <div className="mt-4 flex flex-col gap-3">
      <div className="flex h-9 w-full overflow-hidden rounded-lg border border-border">
        {channelBreakdown.map((c, i) => (
          <Tooltip key={c.channel}>
            <TooltipTrigger asChild>
              <button
                type="button"
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                onFocus={() => setHovered(i)}
                onBlur={() => setHovered(null)}
                className="relative h-full cursor-pointer transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset"
                style={{
                  width: `${c.pct * 100}%`,
                  background:
                    hovered === i
                      ? `color-mix(in srgb, ${c.color} 100%, transparent)`
                      : c.color,
                  opacity: hovered === null || hovered === i ? 1 : 0.75,
                }}
                aria-label={`${c.channel}: ${Math.round(c.pct * 100)}%`}
              />
            </TooltipTrigger>
            <TooltipContent>
              <div className="font-data text-[11px]">
                <div className="text-primary-foreground/80">{c.channel}</div>
                <div>{Math.round(c.pct * 100)}% of revenue</div>
              </div>
            </TooltipContent>
          </Tooltip>
        ))}
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1.5">
        {channelBreakdown.map((c) => (
          <div key={c.channel} className="flex items-center gap-1.5 text-[11px] text-foreground-muted">
            <span
              className="size-2 rounded-full"
              style={{ background: c.color }}
            />
            {c.channel}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Bento section ───────────────────────────────────────────────────────────
export function FeatureBento() {
  return (
    <section
      id="product"
      aria-label="Platform features"
      className="relative overflow-hidden py-24 sm:py-32"
    >
      {/* Track 4 — soft warm radial wash + faint diagonal line pattern */}
      <ParallaxLayer
        speed={0.2}
        className="pointer-events-none absolute inset-0"
      >
        <div className="absolute inset-0 bg-bento-wash" aria-hidden="true" />
      </ParallaxLayer>

      <div className="relative mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-12 max-w-3xl">
          <Reveal>
            <SectionEyebrow>The platform</SectionEyebrow>
            <h2 className="mt-3 font-display text-[clamp(2rem,1.6rem+2vw,3.5rem)] font-medium leading-[1.05] tracking-[-0.015em] text-foreground">
              Six things Cadence does that your spreadsheet can&apos;t.
            </h2>
            <H2Underline />
          </Reveal>
          <Reveal delay={0.07}>
            <p className="mt-5 text-base leading-[1.6] text-foreground-muted sm:text-[17px]">
              The point of the bento isn&apos;t to look impressive — every card here is a real surface from the product, with live data wired into the same forecast model that powers the dashboard. Hover the heatmap, flip the PO switch, watch the sync pulse — these are the actual interactions your team will use every day.
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-3 md:gap-5">
          {/* 1: real-time stock sync */}
          <Reveal>
            <Card>
              <IconChip icon={RefreshCw} tint="var(--accent-teal)" />
              <CardEyebrow>Real-time</CardEyebrow>
              <h3 className="font-display text-lg font-medium leading-tight text-foreground">
                Stock sync across every channel
              </h3>
              <p className="text-sm leading-[1.6] text-foreground-muted">
                Shopify, Amazon, WooCommerce, wholesale, and POS — every sales channel and every 3PL feed syncs into one live inventory ledger, so the number you see is the number you have.
              </p>
              <SyncDiagram />
            </Card>
          </Reveal>

          {/* 2: predictive reorder points (wide) */}
          <Reveal delay={0.07} className="md:col-span-2">
            <Card>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <IconChip icon={TrendingUp} tint="var(--accent-gold)" />
                  <CardEyebrow>Predictive</CardEyebrow>
                  <h3 className="mt-2 font-display text-lg font-medium leading-tight text-foreground">
                    Reorder points that update themselves
                  </h3>
                  <p className="mt-2 max-w-xl text-sm leading-[1.6] text-foreground-muted">
                    Cadence builds a per-SKU baseline from your last 90 days of sell-through, layers in weekly seasonality and supplier lead time, then surfaces a reorder the moment projected on-hand drops below your threshold within the lead-time window.
                  </p>
                </div>
              </div>
              <ThresholdChart />
            </Card>
          </Reveal>

          {/* 3: SKU velocity heatmap (interactive, wide) */}
          <Reveal delay={0.07} className="md:col-span-2">
            <Card>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <IconChip icon={Grid3x3} tint="var(--accent-gold)" />
                  <CardEyebrow>Interactive</CardEyebrow>
                  <h3 className="mt-2 font-display text-lg font-medium leading-tight text-foreground">
                    SKU velocity, twelve weeks at a glance
                  </h3>
                  <p className="mt-2 max-w-xl text-sm leading-[1.6] text-foreground-muted">
                    Hover any cell to see real sell-through intensity per SKU per week. The heatmap is what tells you which slow-movers are quietly tying up capital — and which fast-movers are about to spike.
                  </p>
                </div>
              </div>
              <Heatmap />
            </Card>
          </Reveal>

          {/* 4: multi-warehouse visibility */}
          <Reveal delay={0.07}>
            <Card>
              <IconChip icon={Warehouse} tint="var(--accent-teal)" />
              <CardEyebrow>Multi-warehouse</CardEyebrow>
              <h3 className="font-display text-lg font-medium leading-tight text-foreground">
                Every node, one view
              </h3>
              <p className="text-sm leading-[1.6] text-foreground-muted">
                Six warehouses, three 3PLs, two countries — see utilization and status for every node without a dashboard export.
              </p>
              <WarehouseGrid />
            </Card>
          </Reveal>

          {/* 5: automated POs */}
          <Reveal delay={0.07}>
            <Card>
              <IconChip icon={FileCheck2} tint="var(--accent-gold)" />
              <CardEyebrow>Automated</CardEyebrow>
              <h3 className="font-display text-lg font-medium leading-tight text-foreground">
                From alert to approved PO in one click
              </h3>
              <p className="text-sm leading-[1.6] text-foreground-muted">
                Draft POs are generated against your reorder points — review, tweak quantities, and approve.
              </p>
              <PoToggle />
            </Card>
          </Reveal>

          {/* 6: channel breakdown (wide) */}
          <Reveal delay={0.07} className="md:col-span-2">
            <Card>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <IconChip icon={PieChart} tint="var(--accent-teal)" />
                  <CardEyebrow>Decision-grade</CardEyebrow>
                  <h3 className="mt-2 font-display text-lg font-medium leading-tight text-foreground">
                    Channel breakdown that actually informs reorders
                  </h3>
                  <p className="mt-2 max-w-xl text-sm leading-[1.6] text-foreground-muted">
                    See where revenue actually comes from by channel, then route reorders to the warehouse that serves the highest-velocity channel. Hover a segment to see the share.
                  </p>
                </div>
              </div>
              <ChannelBar />
            </Card>
          </Reveal>
        </div>

        <Reveal delay={0.07}>
          <div className="mt-12 flex items-center justify-center">
            <a
              href="#platform"
              className="link-underline inline-flex items-center gap-2 text-sm font-medium text-foreground"
            >
              See the deep-dive dashboards
              <ArrowRight className="size-4" strokeWidth={1.5} />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
