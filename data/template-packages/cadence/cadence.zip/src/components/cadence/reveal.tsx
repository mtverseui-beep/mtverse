"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { EASE, DURATION } from "./primitives/motion";

interface RevealProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section" | "li" | "article";
}

/**
 * Scroll-triggered fade + rise. Fires once, slightly before full visibility.
 * Per §3.7 of the spec — `ease-out-expo`, 550ms, 24px rise.
 */
export function Reveal({ children, delay = 0, className, as = "div" }: RevealProps) {
  const MotionTag = motion[as] as typeof motion.div;
  return (
    <MotionTag
      className={className}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ duration: DURATION.reveal, ease: EASE.outExpo, delay }}
    >
      {children}
    </MotionTag>
  );
}
