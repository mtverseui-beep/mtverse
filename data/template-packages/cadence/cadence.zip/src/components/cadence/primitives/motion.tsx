"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

// ─── easing + duration tokens (§3.7) ────────────────────────────────────────
export const EASE = {
  outExpo: [0.16, 1, 0.3, 1] as const,
  inOutSoft: [0.4, 0, 0.2, 1] as const,
};

export const DURATION = {
  micro: 0.15,
  standard: 0.22,
  reveal: 0.55,
  hero: 0.9,
};

// ─── useReducedMotion ────────────────────────────────────────────────────────
export function useReducedMotion() {
  const [reduced, setReduced] = React.useState(false);
  React.useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  return reduced;
}

// ─── AnimatedCounter — tabular-nums count-up on scroll-into-view ─────────────
interface CounterProps {
  value: number;
  prefix?: string;
  suffix?: string;
  compact?: boolean; // 1.4M / 980K style
  durationMs?: number;
  className?: string;
}

export function AnimatedCounter({
  value,
  prefix = "",
  suffix = "",
  compact = false,
  durationMs = 1400,
  className,
}: CounterProps) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const [display, setDisplay] = React.useState(0);
  const reduced = useReducedMotion();
  const startedRef = React.useRef(false);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const fmt = (n: number) => {
      if (compact) {
        if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(1) + "B";
        if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
        if (n >= 1_000) return Math.round(n / 1000) + "K";
        return Math.round(n).toString();
      }
      return Math.round(n).toLocaleString("en-US");
    };

    if (reduced) {
      setDisplay(value);
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting && !startedRef.current) {
            startedRef.current = true;
            const start = performance.now();
            const tick = (now: number) => {
              const t = Math.min(1, (now - start) / durationMs);
              // ease-out-expo
              const eased = t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
              setDisplay(value * eased);
              if (t < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
          }
        }
      },
      { threshold: 0.3, rootMargin: "0px 0px -10% 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [value, compact, reduced, durationMs]);

  const render = () => {
    if (compact) {
      if (display >= 1_000_000_000) return (display / 1_000_000_000).toFixed(1) + "B";
      if (display >= 1_000_000) return (display / 1_000_000).toFixed(1) + "M";
      if (display >= 1_000) return Math.round(display / 1000) + "K";
      return Math.round(display).toString();
    }
    return Math.round(display).toLocaleString("en-US");
  };

  return (
    <span
      ref={ref}
      className={cn("font-data tabular-nums", className)}
      aria-label={`${prefix}${value}${suffix}`}
    >
      {prefix}
      {render()}
      {suffix}
    </span>
  );
}

// ─── MagneticButton — desktop-only, pointer-tracking translate ──────────────
interface MagneticProps extends React.HTMLAttributes<HTMLDivElement> {
  strength?: number; // 0..1
  disabled?: boolean;
  children: React.ReactNode;
}

export function MagneticButton({
  strength = 0.25,
  disabled,
  children,
  className,
  ...rest
}: MagneticProps) {
  const ref = React.useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  const [fine, setFine] = React.useState(false);

  React.useEffect(() => {
    const mq = window.matchMedia("(pointer: fine)");
    const update = () => setFine(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  const onMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (disabled || reduced || !fine || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = e.clientX - (rect.left + rect.width / 2);
    const y = e.clientY - (rect.top + rect.height / 2);
    ref.current.style.transform = `translate(${x * strength}px, ${y * strength}px)`;
  };

  const onMouseLeave = () => {
    if (ref.current) ref.current.style.transform = "translate(0px, 0px)";
  };

  return (
    <div
      ref={ref}
      onMouseMove={onMouseMove}
      onMouseLeave={onMouseLeave}
      className={cn("inline-block transition-transform duration-200 ease-out will-change-transform", className)}
      style={{ transitionTimingFunction: "cubic-bezier(0.16, 1, 0.3, 1)" }}
      {...rest}
    >
      {children}
    </div>
  );
}
