"use client";

import * as React from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { cn } from "@/lib/utils";
import { useReducedMotion } from "./motion";

/* ─────────────────────────────────────────────────────────────────────────────
   Scroll-linked motion primitives — Task ID 4 Track 3.

   These sit ON TOP of the existing whileInView scroll-reveal pattern.
   They produce genuine scroll-tied transforms (parallax + progress bars)
   rather than fire-once fade-ins. All respect prefers-reduced-motion.
   ─────────────────────────────────────────────────────────────────────────── */

interface ParallaxLayerProps {
  /**
   * 0 = static. 1 = max counter-scroll movement (±50px).
   * Practical ranges:
   *   - bg decorations: 0.08 – 0.25 (subtle counter-scroll)
   *   - floating chips / alert cards: 0.4 – 0.6 (visible parallax)
   */
  speed?: number;
  className?: string;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export function ParallaxLayer({
  speed = 0.2,
  className,
  children,
  style,
}: ParallaxLayerProps) {
  const ref = React.useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  // Always call useScroll unconditionally (rules of hooks).
  // When reduced-motion is on, we just ignore the resulting transform
  // and render statically.
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  // ±(speed * 50)px. speed=0.15 → ±7.5px (subtle bg), speed=0.4 → ±20px (chip).
  const distance = speed * 50;
  const y = useTransform(scrollYProgress, [0, 0.5, 1], [-distance, 0, distance]);

  if (reduced) {
    return (
      <div ref={ref} className={cn(className)} style={style}>
        {children}
      </div>
    );
  }

  return (
    <motion.div ref={ref} className={cn(className)} style={{ ...style, y }}>
      {children}
    </motion.div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   ScrollProgressBar — a horizontal bar that fills its scaleX 0 → 1 as the
   section scrolls through the viewport. Use for the How It Works progress
   line, or any "you are here" indicator along a section.
   ─────────────────────────────────────────────────────────────────────────── */

interface ScrollProgressBarProps {
  className?: string;
  /** thickness of the bar; default 2px */
  height?: number;
  /** background color of the empty track; defaults to --border-emphasis */
  trackColor?: string;
  /** foreground fill color; defaults to --accent-gold */
  fillColor?: string;
}

export function ScrollProgressBar({
  className,
  height = 2,
  trackColor = "var(--border-emphasis)",
  fillColor = "var(--accent-gold)",
}: ScrollProgressBarProps) {
  const ref = React.useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start center", "end center"],
  });

  if (reduced) {
    return (
      <div
        ref={ref}
        className={cn("absolute", className)}
        style={{ height, background: fillColor }}
        aria-hidden="true"
      />
    );
  }

  return (
    <div
      ref={ref}
      className={cn("absolute", className)}
      style={{ height, background: trackColor }}
      aria-hidden="true"
    >
      <motion.div
        className="absolute inset-0 origin-left"
        style={{ background: fillColor, scaleX: scrollYProgress }}
      />
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   StickyScrollStage — wraps a section so that the heading column sticks at
   `top-20` while the body column scrolls past. Premium pattern for the
   deep-dive tabs section or any long-form comparison.
   ─────────────────────────────────────────────────────────────────────────── */

interface StickyScrollStageProps {
  heading: React.ReactNode;
  body: React.ReactNode;
  className?: string;
  /** sticky offset from top, default 5rem (80px) — clears the navbar */
  stickyTop?: string;
}

export function StickyScrollStage({
  heading,
  body,
  className,
  stickyTop = "5rem",
}: StickyScrollStageProps) {
  return (
    <div className={cn("grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12", className)}>
      <div
        className="lg:col-span-5"
        style={{ position: "sticky", top: stickyTop, alignSelf: "start" }}
      >
        {heading}
      </div>
      <div className="lg:col-span-7">{body}</div>
    </div>
  );
}
