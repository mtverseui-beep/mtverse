"use client";

import * as React from "react";
import type { IntegrationIcon } from "@/data/demo";

/**
 * Cadence — hand-crafted SVG integration marks.
 *
 * Each icon is an original ~24×24 SVG that captures the brand's spirit
 * without copying any trademarked artwork. All icons use `currentColor`
 * so they theme correctly inside the tinted chip wrapper.
 *
 * Visual language shared across the set:
 *   - 1.5 stroke-width for line elements (where applicable)
 *   - consistent 24×24 viewBox with 1.5 padding inset
 *   - rounded corners (rx=2 to rx=3) on geometric shapes
 *   - solid fills only where the silhouette demands it
 */

interface IconProps {
  className?: string;
}

/* ─── Shopify — shopping bag silhouette with a subtle "S" cutout ──────────── */
function ShopifyIcon({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {/* bag body */}
      <path
        d="M6.5 7.5h11l-.7 12.3a1.2 1.2 0 0 1-1.2 1.1H8.4a1.2 1.2 0 0 1-1.2-1.1L6.5 7.5z"
        fill="currentColor"
        fillOpacity={0.14}
        stroke="currentColor"
      />
      {/* handle */}
      <path d="M9 7.8V6.4a3 3 0 0 1 6 0v1.4" />
      {/* S cutout */}
      <path
        d="M10.6 11.5c.2-.7.8-1.1 1.5-1.1.9 0 1.4.5 1.4 1.1 0 .6-.5.9-1.3 1.1-.8.2-1.4.5-1.4 1.2 0 .6.6 1 1.4 1 .7 0 1.3-.4 1.5-1.1"
        strokeWidth={1.4}
      />
    </svg>
  );
}

/* ─── Amazon — stylized smile/arrow swoosh with arrowhead ─────────────────── */
function AmazonIcon({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {/* the lowercase 'a' stroke */}
      <path d="M16 7.5c-1-.8-2.3-1.2-3.7-1.2-2.4 0-4 1.3-4 3.1 0 1.7 1.2 2.5 3.5 3 1.8.4 2.4.7 2.4 1.4 0 .7-.7 1.1-2 1.1-1.4 0-2.5-.5-3.4-1.3" />
      {/* the swoosh / smile arrow */}
      <path d="M5.5 14.5c2.4 2.2 5.5 3 8.5 3 2.6 0 4-.9 4.6-1.7" />
      {/* arrowhead */}
      <path
        d="M18.2 12.4l.4 3.4-3.2-.6"
        fill="currentColor"
        fillOpacity={0.18}
      />
    </svg>
  );
}

/* ─── WooCommerce — "W" wordmark inside a soft rounded hexagon ────────────── */
function WooCommerceIcon({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {/* rounded hexagon outline */}
      <path
        d="M6.5 4.5h11a2 2 0 0 1 2 2v6.5a2 2 0 0 1-2 2H12l-3.2 3.3a.6.6 0 0 1-1-.4V15H6.5a2 2 0 0 1-2-2V6.5a2 2 0 0 1 2-2z"
        fill="currentColor"
        fillOpacity={0.10}
      />
      {/* W mark */}
      <path d="M7.5 8l1.6 5 1.7-3.4L12 13l1.6-5" strokeWidth={1.6} />
    </svg>
  );
}

/* ─── BigCommerce — "B" with an upward arrow integrated into the stem ─────── */
function BigCommerceIcon({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect
        x="4.5"
        y="4.5"
        width="15"
        height="15"
        rx="3"
        fill="currentColor"
        fillOpacity={0.10}
      />
      {/* B with arrow-stem: the left vertical is replaced by an up-arrow */}
      <path d="M9 7.5v9" />
      <path d="M8 9.5l1-2 1 2" />
      <path d="M9 7.5h3.5a2.2 2.2 0 0 1 0 4.4H9" />
      <path d="M9 11.9h4a2.2 2.2 0 0 1 0 4.6H9" />
    </svg>
  );
}

/* ─── NetSuite — 2x2 grid of squares, one filled (ERP modules) ────────────── */
function NetSuiteIcon({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect x="4.5" y="4.5" width="6.5" height="6.5" rx="1.5" fill="currentColor" fillOpacity={0.85} stroke="none" />
      <rect x="13" y="4.5" width="6.5" height="6.5" rx="1.5" />
      <rect x="4.5" y="13" width="6.5" height="6.5" rx="1.5" />
      <rect x="13" y="13" width="6.5" height="6.5" rx="1.5" />
    </svg>
  );
}

/* ─── ShipBob — isometric cardboard box with motion lines behind it ───────── */
function ShipBobIcon({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {/* motion lines (left, behind box) */}
      <path d="M3 9h3" opacity={0.55} />
      <path d="M3 12h3" opacity={0.55} />
      <path d="M3 15h3" opacity={0.55} />
      {/* box — isometric top face */}
      <path d="M9 6.5l6.5-2 5.5 2.2-6.5 2L9 6.5z" fill="currentColor" fillOpacity={0.18} />
      {/* left face */}
      <path d="M9 6.5v9.5l5.5 2V8.5L9 6.5z" fill="currentColor" fillOpacity={0.10} />
      {/* right face */}
      <path d="M14.5 8.5l6.5-2v9.5l-6.5 2V8.5z" fill="currentColor" fillOpacity={0.05} />
      {/* tape line on top */}
      <path d="M11.7 5.7l5.6 2" strokeWidth={1.2} />
    </svg>
  );
}

/* ─── ShipHero — shield with a checkmark inside ───────────────────────────── */
function ShipHeroIcon({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M12 3.5l7 2.2v5.2c0 4.3-3 7.7-7 9.1-4-1.4-7-4.8-7-9.1V5.7l7-2.2z"
        fill="currentColor"
        fillOpacity={0.12}
      />
      <path d="M9 12l2 2 4-4.2" strokeWidth={1.8} />
    </svg>
  );
}

/* ─── Square POS — rounded square with a smaller square cutout in one corner ── */
function SquareIcon({ className }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect
        x="4.5"
        y="4.5"
        width="15"
        height="15"
        rx="3"
        fill="currentColor"
        fillOpacity={0.12}
      />
      {/* smaller square in the bottom-right, drawn as a notch cutout */}
      <rect
        x="11.5"
        y="11.5"
        width="5"
        height="5"
        rx="1.5"
        fill="var(--surface)"
        stroke="currentColor"
      />
    </svg>
  );
}

const ICONS: Record<IntegrationIcon, React.ComponentType<IconProps>> = {
  shopify: ShopifyIcon,
  amazon: AmazonIcon,
  woocommerce: WooCommerceIcon,
  bigcommerce: BigCommerceIcon,
  netsuite: NetSuiteIcon,
  shipbob: ShipBobIcon,
  shiphero: ShipHeroIcon,
  square: SquareIcon,
};

export function IntegrationIconSvg({
  name,
  className,
}: {
  name: IntegrationIcon;
  className?: string;
}) {
  const Cmp = ICONS[name];
  return <Cmp className={className} />;
}
