// ============================================================================
// Cadence — demo dataset (single source of truth, §6 of the spec)
// Every chart, mockup, table and pricing teaser on the page pulls from here.
// In a real app these shapes map onto Prisma models; here they are static.
// ============================================================================

export type StockStatus = "in-stock" | "low" | "critical" | "overstock";

export interface Sku {
  id: string;
  name: string;
  category: "Apparel" | "Home" | "Accessory" | "Footwear";
  sku: string;
  price: number;
  onHand: number;
  reorderPoint: number;
  leadTimeDays: number;
  status: StockStatus;
  velocity30d: number; // units / day, last 30d
  warehouse: string;
  channels: string[];
}

export interface Warehouse {
  id: string;
  name: string;
  city: string;
  skuCount: number;
  utilization: number; // 0-1
  status: "healthy" | "stretching" | "critical";
}

export interface ForecastPoint {
  date: string; // ISO
  actual?: number; // historical
  forecast: number; // predicted
  lower: number; // confidence band
  upper: number;
  isFuture: boolean;
}

export interface CaseStudy {
  id: string;
  company: string;
  industry: string;
  logoMark: string; // short text mark for the avatar-style logo
  resultHeadline: string;
  resultMetric: string;
  resultSuffix: string;
  bodyQuote: string;
  personName: string;
  personRole: string;
  accent: "gold" | "teal";
}

export interface PricingTier {
  id: "starter" | "growth" | "enterprise";
  name: string;
  monthly: number; // per-month price, billed monthly
  yearly: number; // per-month price, billed yearly
  tagline: string;
  description: string;
  cta: string;
  featured: boolean;
  features: { label: string; included: boolean; tooltip?: string }[];
}

export interface FaqEntry {
  q: string;
  a: string;
}

export type IntegrationIcon =
  | "shopify"
  | "amazon"
  | "woocommerce"
  | "bigcommerce"
  | "netsuite"
  | "shipbob"
  | "shiphero"
  | "square";

export interface Integration {
  name: string;
  category: "Storefront" | "Marketplace" | "ERP" | "POS" | "Shipping";
  initials: string;
  blurb: string;
  icon: IntegrationIcon;
}

// ----------------------------------------------------------------------------
// SKUs — 18 realistic apparel / home / accessory items
// ----------------------------------------------------------------------------

export const skus: Sku[] = [
  { id: "s1",  name: "Heavyweight Merino Crew",      category: "Apparel",   sku: "APL-MRN-001", price: 128, onHand: 1240, reorderPoint: 400, leadTimeDays: 28, status: "in-stock",  velocity30d: 14.2, warehouse: "Reno, NV",  channels: ["Shopify", "Amazon"] },
  { id: "s2",  name: "Washed Linen Set, Stone",      category: "Home",      sku: "HOM-LIN-014", price: 184, onHand: 96,   reorderPoint: 120, leadTimeDays: 42, status: "low",        velocity30d: 6.8,  warehouse: "Reno, NV",  channels: ["Shopify"] },
  { id: "s3",  name: "Cashmere Watch Cap",           category: "Accessory", sku: "ACC-CSH-007", price: 96,  onHand: 0,     reorderPoint: 80,  leadTimeDays: 35, status: "critical",  velocity30d: 9.1,  warehouse: "Savannah, GA", channels: ["Shopify", "Amazon", "Wholesale"] },
  { id: "s4",  name: "Selvedge Denim, Indigo 32",    category: "Apparel",   sku: "APL-DNM-022", price: 220, onHand: 540,   reorderPoint: 180, leadTimeDays: 60, status: "in-stock",  velocity30d: 4.6,  warehouse: "Reno, NV",  channels: ["Shopify"] },
  { id: "s5",  name: "Wool Throw, Oat",              category: "Home",      sku: "HOM-WOL-031", price: 145, onHand: 880,   reorderPoint: 220, leadTimeDays: 30, status: "overstock", velocity30d: 3.1,  warehouse: "Savannah, GA", channels: ["Shopify", "Wholesale"] },
  { id: "s6",  name: "Leather Card Wallet, Tan",     category: "Accessory", sku: "ACC-LTR-009", price: 78,  onHand: 312,   reorderPoint: 100, leadTimeDays: 25, status: "in-stock",  velocity30d: 7.8,  warehouse: "Reno, NV",  channels: ["Shopify", "Amazon"] },
  { id: "s7",  name: "Pima Tee, Bone",               category: "Apparel",   sku: "APL-PMA-003", price: 48,  onHand: 64,    reorderPoint: 200, leadTimeDays: 21, status: "low",        velocity30d: 22.4, warehouse: "Reno, NV",  channels: ["Shopify", "Amazon", "Wholesale"] },
  { id: "s8",  name: "Canvas Weekender, Olive",      category: "Accessory", sku: "ACC-BAG-018", price: 268, onHand: 142,   reorderPoint: 60,  leadTimeDays: 45, status: "in-stock",  velocity30d: 2.1,  warehouse: "Savannah, GA", channels: ["Shopify"] },
  { id: "s9",  name: "Wool Runner, Charcoal",        category: "Footwear",  sku: "FTW-RUN-005", price: 165, onHand: 0,     reorderPoint: 90,  leadTimeDays: 50, status: "critical",  velocity30d: 5.2,  warehouse: "Allentown, PA", channels: ["Shopify", "Amazon"] },
  { id: "s10", name: "Soy Candle, Cedar",            category: "Home",      sku: "HOM-CDL-042", price: 36,  onHand: 1840,  reorderPoint: 300, leadTimeDays: 14, status: "overstock", velocity30d: 12.4, warehouse: "Savannah, GA", channels: ["Shopify", "Wholesale"] },
  { id: "s11", name: "Performance Quarter Zip",      category: "Apparel",   sku: "APL-QZP-011", price: 118, onHand: 380,   reorderPoint: 150, leadTimeDays: 30, status: "in-stock",  velocity30d: 8.9,  warehouse: "Reno, NV",  channels: ["Shopify", "Amazon"] },
  { id: "s12", name: "Wool Blanket Coat, Camel",     category: "Apparel",   sku: "APL-COT-027", price: 398, onHand: 28,    reorderPoint: 40,  leadTimeDays: 55, status: "low",        velocity30d: 1.4,  warehouse: "Allentown, PA", channels: ["Shopify"] },
  { id: "s13", name: "Stoneware Mug Set",            category: "Home",      sku: "HOM-CER-036", price: 64,  onHand: 720,   reorderPoint: 180, leadTimeDays: 28, status: "in-stock",  velocity30d: 6.2,  warehouse: "Savannah, GA", channels: ["Shopify", "Wholesale"] },
  { id: "s14", name: "Leather Belt, Tobacco",        category: "Accessory", sku: "ACC-LTR-012", price: 92,  onHand: 540,   reorderPoint: 120, leadTimeDays: 32, status: "in-stock",  velocity30d: 3.8,  warehouse: "Reno, NV",  channels: ["Shopify"] },
  { id: "s15", name: "Performance Chino, Khaki",     category: "Apparel",   sku: "APL-CHN-016", price: 98,  onHand: 22,    reorderPoint: 80,  leadTimeDays: 24, status: "critical",  velocity30d: 11.7, warehouse: "Allentown, PA", channels: ["Shopify", "Amazon"] },
  { id: "s16", name: "Linen Robe, Sand",             category: "Home",      sku: "HOM-RBE-040", price: 168, onHand: 460,   reorderPoint: 90,  leadTimeDays: 38, status: "in-stock",  velocity30d: 2.4,  warehouse: "Savannah, GA", channels: ["Shopify"] },
  { id: "s17", name: "Cashmere Scarf, Heather",      category: "Accessory", sku: "ACC-CSH-015", price: 132, onHand: 96,    reorderPoint: 70,  leadTimeDays: 35, status: "in-stock",  velocity30d: 3.2,  warehouse: "Reno, NV",  channels: ["Shopify", "Wholesale"] },
  { id: "s18", name: "Wool Sneaker, Cream",          category: "Footwear",  sku: "FTW-SNK-008", price: 148, onHand: 980,   reorderPoint: 220, leadTimeDays: 48, status: "overstock", velocity30d: 4.8,  warehouse: "Allentown, PA", channels: ["Shopify", "Amazon"] },
];

// ----------------------------------------------------------------------------
// Hero / deep-dive forecast — 75 day series, last 14 days = forecast
// Constructed to look real: weekly seasonality + noise + slight upward trend
// ----------------------------------------------------------------------------

function buildForecast(): ForecastPoint[] {
  const out: ForecastPoint[] = [];
  const today = new Date("2026-08-01T00:00:00Z");
  const start = new Date(today);
  start.setUTCDate(start.getUTCDate() - 60);

  for (let i = 0; i < 75; i++) {
    const d = new Date(start);
    d.setUTCDate(start.getUTCDate() + i);
    const dow = d.getUTCDay();
    // weekly seasonality: weekends lower, Tue/Wed peak
    const weekFactor = [0.78, 0.95, 1.18, 1.12, 1.0, 0.88, 0.72][dow];
    // upward trend + sinusoidal seasonality + noise
    const trend = 1 + i * 0.004;
    const seasonal = 1 + Math.sin(i / 8) * 0.06;
    const noise = 1 + (Math.sin(i * 1.7) + Math.cos(i * 0.6)) * 0.04;
    const base = 220 * weekFactor * trend * seasonal * noise;
    const isFuture = i >= 61;
    if (isFuture) {
      const horizon = i - 60;
      const spread = 8 + horizon * 3.2;
      out.push({
        date: d.toISOString().slice(0, 10),
        forecast: Math.round(base),
        lower: Math.round(base - spread),
        upper: Math.round(base + spread),
        isFuture: true,
      });
    } else {
      out.push({
        date: d.toISOString().slice(0, 10),
        actual: Math.round(base),
        forecast: Math.round(base),
        lower: Math.round(base),
        upper: Math.round(base),
        isFuture: false,
      });
    }
  }
  return out;
}

export const forecastSeries: ForecastPoint[] = buildForecast();

// ----------------------------------------------------------------------------
// Hero dashboard: 4 SKU rows + reorder alert
// ----------------------------------------------------------------------------

export const heroSkus = [
  skus[2],  // Cashmere Watch Cap — critical
  skus[6],  // Pima Tee — low
  skus[8],  // Wool Runner — critical
  skus[14], // Performance Chino — critical
];

// ----------------------------------------------------------------------------
// SKU velocity heatmap — 8 SKUs × 12 weeks
// ----------------------------------------------------------------------------

export const velocityHeatmap: { sku: string; name: string; weeks: number[] }[] = [
  { sku: "APL-MRN-001", name: "Merino Crew",      weeks: [0.4, 0.5, 0.6, 0.7, 0.8, 0.6, 0.5, 0.7, 0.9, 0.8, 0.7, 0.8] },
  { sku: "APL-PMA-003", name: "Pima Tee",         weeks: [0.6, 0.7, 0.8, 0.9, 0.95, 0.85, 0.7, 0.6, 0.8, 0.95, 1.0, 0.9] },
  { sku: "HOM-CDL-042", name: "Cedar Candle",     weeks: [0.3, 0.4, 0.4, 0.5, 0.6, 0.5, 0.4, 0.5, 0.6, 0.7, 0.6, 0.5] },
  { sku: "APL-DNM-022", name: "Selvedge Denim",   weeks: [0.2, 0.3, 0.3, 0.4, 0.3, 0.4, 0.5, 0.4, 0.5, 0.6, 0.5, 0.4] },
  { sku: "ACC-CSH-007", name: "Cashmere Watch Cap", weeks: [0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.9, 0.8, 0.7, 0.8, 0.85, 0.95] },
  { sku: "HOM-WOL-031", name: "Wool Throw",       weeks: [0.6, 0.5, 0.4, 0.4, 0.3, 0.3, 0.4, 0.5, 0.6, 0.5, 0.4, 0.3] },
  { sku: "APL-QZP-011", name: "Quarter Zip",      weeks: [0.5, 0.6, 0.6, 0.7, 0.8, 0.7, 0.6, 0.5, 0.7, 0.8, 0.7, 0.6] },
  { sku: "FTW-RUN-005", name: "Wool Runner",      weeks: [0.4, 0.4, 0.5, 0.6, 0.7, 0.6, 0.5, 0.6, 0.7, 0.8, 0.7, 0.6] },
];

// ----------------------------------------------------------------------------
// Warehouses — 6 nodes with utilization
// ----------------------------------------------------------------------------

export const warehouses: Warehouse[] = [
  { id: "w1", name: "Reno Fulfillment",       city: "Reno, NV",        skuCount: 1842, utilization: 0.74, status: "healthy" },
  { id: "w2", name: "Savannah DC",            city: "Savannah, GA",    skuCount: 1294, utilization: 0.81, status: "healthy" },
  { id: "w3", name: "Allentown East",         city: "Allentown, PA",   skuCount: 968,  utilization: 0.92, status: "stretching" },
  { id: "w4", name: "Toronto Cross-Border",   city: "Toronto, ON",     skuCount: 412,  utilization: 0.58, status: "healthy" },
  { id: "w5", name: "Rotterdam EU",           city: "Rotterdam, NL",   skuCount: 287,  utilization: 0.46, status: "healthy" },
  { id: "w6", name: "Osaka APAC",             city: "Osaka, JP",       skuCount: 198,  utilization: 0.97, status: "critical" },
];

// ----------------------------------------------------------------------------
// Channel breakdown — proportional
// ----------------------------------------------------------------------------

export const channelBreakdown = [
  { channel: "Shopify",     pct: 0.42, color: "var(--accent-gold)" },
  { channel: "Amazon",      pct: 0.28, color: "var(--accent-teal)" },
  { channel: "Wholesale",   pct: 0.16, color: "var(--status-overstock)" },
  { channel: "Retail POS",  pct: 0.10, color: "var(--status-low)" },
  { channel: "TikTok Shop", pct: 0.04, color: "var(--status-critical)" },
];

// ----------------------------------------------------------------------------
// Case studies — 4 with quantified outcomes
// ----------------------------------------------------------------------------

export const caseStudies: CaseStudy[] = [
  {
    id: "c1",
    company: "Northbound Apparel",
    industry: "DTC Apparel · multi-warehouse",
    logoMark: "NB",
    resultHeadline: "Reduced stockouts by 34% in 90 days",
    resultMetric: "−34%",
    resultSuffix: "stockout incidents, Q1→Q3",
    bodyQuote: "We stopped firefighting POs every Monday. Cadence surfaces the four SKUs that actually need attention before they become a problem — and that's the whole list.",
    personName: "Marisol Chen",
    personRole: "VP Operations, Northbound Apparel",
    accent: "gold",
  },
  {
    id: "c2",
    company: "Hearth & Hold",
    industry: "Home Goods · Shopify + Wholesale",
    logoMark: "HH",
    resultHeadline: "Freed $480K in dead stock in one season",
    resultMetric: "$480K",
    resultSuffix: "working capital recovered",
    bodyQuote: "The overstock view alone paid for the year. We finally had a defensible answer to ‘why are we sitting on 800 throws?’",
    personName: "Devon Park",
    personRole: "Founder, Hearth & Hold",
    accent: "teal",
  },
  {
    id: "c3",
    company: "Fielder & Co",
    industry: "Multi-channel DTC · 3PL-heavy",
    logoMark: "FC",
    resultHeadline: "Cut PO lead time by 11 days on average",
    resultMetric: "−11d",
    resultSuffix: "median reorder cycle",
    bodyQuote: "Reorder recommendations land before our 3PL even flags low stock. We’re working ahead of the warehouse now, not behind it.",
    personName: "Priya Ramachandran",
    personRole: "Head of Supply, Fielder & Co",
    accent: "gold",
  },
  {
    id: "c4",
    company: "Atlas Outdoor",
    industry: "Apparel + Footwear · seasonal",
    logoMark: "AO",
    resultHeadline: "Hit 98.6% in-stock across peak season",
    resultMetric: "98.6%",
    resultSuffix: "in-stock rate, Black Friday week",
    bodyQuote: "Peak used to be a war room. This year we just… shipped. The forecast told us to lean in on the Wool Runner six weeks early and it was right.",
    personName: "Tobias Frey",
    personRole: "COO, Atlas Outdoor",
    accent: "teal",
  },
];

// ----------------------------------------------------------------------------
// Pricing — 3 tiers, monthly/yearly
// ----------------------------------------------------------------------------

export const pricingTiers: PricingTier[] = [
  {
    id: "starter",
    name: "Starter",
    monthly: 89,
    yearly: 71,
    tagline: "For single-channel operators getting their first forecast.",
    description: "Connect one storefront and start getting reorder recommendations within a day.",
    cta: "Start with Starter",
    featured: false,
    features: [
      { label: "1 sales channel",            included: true,  tooltip: "Shopify, Amazon, WooCommerce, or one custom integration." },
      { label: "1 warehouse",                included: true },
      { label: "Up to 500 active SKUs",      included: true,  tooltip: "Active SKUs are SKUs with at least one unit sold in the last 90 days." },
      { label: "30-day forecast horizon",    included: true },
      { label: "Weekly reorder digest",      included: true },
      { label: "Email support",              included: true },
      { label: "Multi-warehouse visibility", included: false },
      { label: "Automated purchase orders",  included: false },
    ],
  },
  {
    id: "growth",
    name: "Growth",
    monthly: 249,
    yearly: 199,
    tagline: "For DTC teams running multiple channels and warehouses.",
    description: "Full forecasting, multi-warehouse sync, and one-click PO generation.",
    cta: "Start with Growth",
    featured: true,
    features: [
      { label: "Up to 5 sales channels",     included: true },
      { label: "Unlimited warehouses",       included: true },
      { label: "Up to 10,000 active SKUs",   included: true,  tooltip: "Need more? Enterprise supports unlimited SKUs." },
      { label: "90-day forecast horizon",    included: true,  tooltip: "Rolling forecast with weekly seasonality and lead-time awareness." },
      { label: "Real-time reorder alerts",   included: true },
      { label: "Automated purchase orders",  included: true,  tooltip: "Draft POs generated against your reorder points — review and approve in one click." },
      { label: "Slack + email notifications", included: true },
      { label: "Priority support, 4h SLA",   included: true },
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise",
    monthly: 0,
    yearly: 0,
    tagline: "For operators with custom integrations, ERP, or compliance needs.",
    description: "Custom data residency, SSO, SOC 2 controls, and a dedicated implementation engineer.",
    cta: "Talk to sales",
    featured: false,
    features: [
      { label: "Unlimited channels & SKUs",  included: true },
      { label: "ERP / NetSuite / SAP sync",  included: true,  tooltip: "Two-way sync with NetSuite, SAP, Oracle, or Microsoft Dynamics." },
      { label: "180-day forecast horizon",   included: true },
      { label: "Custom data residency",      included: true,  tooltip: "US, EU, or APAC hosting with regional failover." },
      { label: "SSO / SAML 2.0",             included: true },
      { label: "SOC 2 Type II controls",     included: true },
      { label: "Dedicated implementation engineer", included: true },
      { label: "Custom SLAs + 24/7 support", included: true },
    ],
  },
];

// ----------------------------------------------------------------------------
// FAQ — 8 operational questions
// ----------------------------------------------------------------------------

export const faqs: FaqEntry[] = [
  {
    q: "How does Cadence generate its reorder recommendations?",
    a: "Cadence builds a per-SKU baseline from your last 90 days of sell-through, layers in weekly seasonality and lead-time awareness, then recommends a reorder when projected on-hand drops below your reorder point within the lead-time window. You can override the model per SKU — slow-movers get a moving average, fast-movers get a seasonal exponential smoothing model — and you can pin manual reorder points for items you want to control by hand.",
  },
  {
    q: "How long does implementation take?",
    a: "Most teams are live in under a day. Connect your storefront (Shopify, Amazon, WooCommerce) via OAuth, import your warehouse CSV or 3PL integration, and Cadence builds the initial forecast within 30–60 minutes. Larger multi-warehouse or ERP-backed setups typically take 3–5 business days and ship with a dedicated implementation engineer on Enterprise.",
  },
  {
    q: "Which channels and platforms does Cadence integrate with?",
    a: "Native integrations: Shopify, Amazon Seller Central, WooCommerce, BigCommerce, TikTok Shop, Square, and a generic POS connector. On the inventory side: ShipBob, ShipHero, Flexport, plus a generic 3PL CSV/EDU 850/846 parser. ERP sync (NetSuite, SAP, Dynamics) is available on Enterprise. If you’re running something custom, our REST API and webhooks cover the long tail.",
  },
  {
    q: "How accurate are the forecasts, really?",
    a: "Across our customer base, median forecast accuracy (1 − MAPE) at the 30-day horizon is 87%, dropping to ~78% at 90 days. We surface the confidence band on every forecast so you can decide how much buffer to carry — not a single misleading number. New SKUs with under 14 days of history get a category-baseline forecast until they have enough signal of their own.",
  },
  {
    q: "How is my data handled, and where does it live?",
    a: "Inventory and sales data is encrypted in transit (TLS 1.3) and at rest (AES-256). Data residency is US by default; EU and APAC residency are available on Enterprise. We are SOC 2 Type II in progress and never sell or share customer data. Full details on our /security overview — including subprocessors and breach-notification timelines.",
  },
  {
    q: "What happens to my reorder points if I cancel?",
    a: "You can export every forecast, reorder point, and historical PO as CSV at any time from the dashboard. If you cancel, your account stays read-only for 30 days, then your data is purged. There is no contract lock-in on Starter or Growth — cancel anytime and your data leaves with you.",
  },
  {
    q: "What's the minimum contract term?",
    a: "Starter and Growth are month-to-month (or yearly if you choose the annual discount). Enterprise starts at a 12-month term because of the dedicated implementation work — but the first 60 days include a no-fault exit clause so you can walk away if onboarding isn’t tracking.",
  },
  {
    q: "Can Cadence handle pre-orders, drops, and backorders?",
    a: "Yes. Pre-orders and backorders are modeled as committed demand against future stock, so the forecast knows not to recommend a reorder for a SKU that’s already covered by an inbound PO. Drops (limited-launch product) use a separate launch-aware model — useful for streetwear and sneaker drops where the sell-through curve is sharper than the regular baseline.",
  },
];

// ----------------------------------------------------------------------------
// Integrations — 8 marks
// ----------------------------------------------------------------------------

export const integrations: Integration[] = [
  { name: "Shopify",      category: "Storefront",  initials: "S",  blurb: "OAuth, multi-location, real-time inventory sync", icon: "shopify" },
  { name: "Amazon",       category: "Marketplace", initials: "Az", blurb: "Seller Central, FBA + MFN visibility",            icon: "amazon" },
  { name: "WooCommerce",  category: "Storefront",  initials: "W",  blurb: "REST API, 2-minute setup",                        icon: "woocommerce" },
  { name: "BigCommerce",  category: "Storefront",  initials: "Bc", blurb: "Multi-storefront, channel-level stock",           icon: "bigcommerce" },
  { name: "NetSuite",     category: "ERP",         initials: "Ns", blurb: "Two-way sync — Enterprise",                       icon: "netsuite" },
  { name: "ShipBob",      category: "Shipping",    initials: "Sb", blurb: "3PL inventory + inbound POs",                     icon: "shipbob" },
  { name: "ShipHero",     category: "Shipping",    initials: "Sh", blurb: "Warehouse-level on-hand feed",                   icon: "shiphero" },
  { name: "Square POS",   category: "POS",         initials: "Sq", blurb: "Retail + online, unified stock",                 icon: "square" },
];

// ----------------------------------------------------------------------------
// Logo cloud — 6 monochrome marks
// ----------------------------------------------------------------------------

export const logoCloud = [
  { name: "Northbound",   mark: "NORTHBOUND" },
  { name: "Hearth & Hold", mark: "HEARTH/HOLD" },
  { name: "Fielder",      mark: "FIELDER&CO" },
  { name: "Atlas Outdoor", mark: "ATLAS" },
  { name: "Maren Studio", mark: "MAREN" },
  { name: "Loam & Loom",  mark: "LOAM/LOOM" },
];

// ----------------------------------------------------------------------------
// How it works — 4 steps
// ----------------------------------------------------------------------------

export const processSteps = [
  { step: "01", title: "Connect your channels",     body: "OAuth into Shopify, Amazon, WooCommerce — and pull warehouse stock via ShipBob, ShipHero, or CSV. Live in under a day." },
  { step: "02", title: "Cadence learns your velocity", body: "We build a per-SKU baseline from your last 90 days of sell-through, layered with weekly seasonality and lead-time awareness." },
  { step: "03", title: "Get reorder alerts before you run out", body: "When projected on-hand drops below your reorder point within the lead-time window, you get a real-time alert — not a Monday-morning surprise." },
  { step: "04", title: "Approve POs in one click",  body: "Draft purchase orders are generated automatically. Review, tweak quantities, approve, and they’re off to your supplier or 3PL." },
];

// ----------------------------------------------------------------------------
// Problem stats — §4.4 animated counters
// ----------------------------------------------------------------------------

export const problemStats = [
  { prefix: "$", value: 125_000, suffix: "",  label: "Average monthly cost of stockouts for mid-size retailers", source: "Industry estimate · NRF retail audit 2024" },
  { prefix: "$", value: 1_400_000_000, suffix: "", compact: true, label: "Tied up annually in dead stock across US DTC brands", source: "Industry estimate · eMarketer 2024" },
  { prefix: "",  value: 14, suffix: " hrs", label: "Spent each week manually reconciling stock across channels", source: "Industry estimate · Cadence operator survey" },
  { prefix: "",  value: 32, suffix: "%",   label: "Of DTC brands report a stockout in the last 90 days", source: "Industry estimate · Cadence operator survey" },
];

// ----------------------------------------------------------------------------
// Product deep-dive tabs — 4 tabs
// ----------------------------------------------------------------------------

export const deepDiveTabs = [
  { id: "forecasting",   label: "Forecasting",           eyebrow: "Predictive" },
  { id: "sync",          label: "Multi-channel sync",    eyebrow: "Real-time" },
  { id: "purchase-orders", label: "Purchase orders",     eyebrow: "Automated" },
  { id: "reporting",     label: "Reporting",             eyebrow: "Decision-grade" },
] as const;

// ----------------------------------------------------------------------------
// Avatars — deterministic initials, brand-colored
// ----------------------------------------------------------------------------

export const heroAvatars = [
  { name: "Marisol Chen",       initials: "MC" },
  { name: "Devon Park",         initials: "DP" },
  { name: "Priya Ramachandran", initials: "PR" },
  { name: "Tobias Frey",        initials: "TF" },
  { name: "Aiko Tanaka",        initials: "AT" },
  { name: "Marcus Webb",        initials: "MW" },
  { name: "Sofia Reyes",        initials: "SR" },
];

// ----------------------------------------------------------------------------
// Navigation / footer config
// ----------------------------------------------------------------------------

export const navLinks = [
  { label: "Product",     href: "#product" },
  { label: "Platform",    href: "#platform" },
  { label: "Pricing",     href: "#pricing" },
  { label: "Customers",   href: "#customers" },
  { label: "Changelog",   href: "#changelog" },
];

export const footerColumns = [
  {
    title: "Product",
    links: [
      { label: "Forecasting",      href: "#platform" },
      { label: "Multi-channel sync", href: "#platform" },
      { label: "Purchase orders",  href: "#platform" },
      { label: "Pricing",          href: "#pricing" },
      { label: "Changelog",        href: "#changelog" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About",            href: "#about" },
      { label: "Customers",        href: "#customers" },
      { label: "Security",         href: "#security" },
      { label: "Contact",          href: "#contact" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Forecasting guide", href: "#resources" },
      { label: "API reference",     href: "#resources" },
      { label: "Status",            href: "#resources" },
      { label: "Help center",       href: "#resources" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy policy",    href: "#legal" },
      { label: "Terms of service",  href: "#legal" },
      { label: "DPA",               href: "#legal" },
      { label: "Subprocessors",     href: "#legal" },
    ],
  },
];
