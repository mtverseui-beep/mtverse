import { Navbar } from "@/components/cadence/sections/navbar";
import { Hero } from "@/components/cadence/sections/hero";
import { LogoCloud } from "@/components/cadence/sections/logo-cloud";
import { ProblemStats } from "@/components/cadence/sections/problem-stats";
import { FeatureBento } from "@/components/cadence/sections/feature-bento";
import { HowItWorks } from "@/components/cadence/sections/how-it-works";
import { DeepDiveTabs } from "@/components/cadence/sections/deep-dive-tabs";
import { CaseStudies } from "@/components/cadence/sections/case-studies";
import { Pricing } from "@/components/cadence/sections/pricing";
import { Integrations } from "@/components/cadence/sections/integrations";
import { Faq } from "@/components/cadence/sections/faq";
import { ContactForm } from "@/components/cadence/sections/contact-form";
import { FinalCta } from "@/components/cadence/sections/final-cta";
import { Footer } from "@/components/cadence/sections/footer";

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <LogoCloud />
        <ProblemStats />
        <FeatureBento />
        <HowItWorks />
        <DeepDiveTabs />
        <CaseStudies />
        <Pricing />
        <Integrations />
        <Faq />
        <ContactForm />
        <FinalCta />
      </main>
      <Footer />
    </div>
  );
}
