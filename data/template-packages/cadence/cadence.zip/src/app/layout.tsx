import type { Metadata } from "next";
import { Geist, Geist_Mono, Fraunces } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

const fraunces = Fraunces({
  variable: "--font-fraunces",
  subsets: ["latin"],
  display: "swap",
  axes: ["opsz", "SOFT"],
});

const siteUrl = "https://cadence.example";
const siteDescription =
  "Cadence gives retail and DTC ecommerce operators real-time stock visibility and predictive reorder recommendations across every warehouse and sales channel — so you know what to reorder before you run out.";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Cadence — Know what to reorder before you run out",
    template: "%s · Cadence",
  },
  description: siteDescription,
  keywords: [
    "inventory forecasting",
    "demand forecasting",
    "reorder points",
    "stock visibility",
    "multi-channel ecommerce",
    "DTC operations",
    "warehouse management",
    "purchase order automation",
  ],
  authors: [{ name: "Cadence" }],
  creator: "Cadence",
  publisher: "Cadence",
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
    ],
    apple: "/apple-icon.png",
  },
  openGraph: {
    title: "Cadence — Know what to reorder before you run out",
    description: siteDescription,
    url: siteUrl,
    siteName: "Cadence",
    type: "website",
    locale: "en_US",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "Cadence — Inventory Intelligence for retail & DTC operators",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Cadence — Know what to reorder before you run out",
    description: siteDescription,
    images: ["/og.png"],
    creator: "@cadence",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
    },
  },
  alternates: {
    canonical: "/",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* zero-flash theme script — sets .dark before paint */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('cadence-theme');if(t==='dark'||(!t&&window.matchMedia('(prefers-color-scheme: dark)').matches)){document.documentElement.classList.add('dark');}}catch(e){}})();`,
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${fraunces.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
          storageKey="cadence-theme"
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
