# Changelog

## [1.0.0] — 2026-08-01
- Initial release.
- 13 landing-page sections with the full Cadence design system.
- Real SVG integration icons (8 brands).
- Scroll-linked parallax motion.
- 8 distinct section background treatments.
- Validated contact + newsletter forms with API route handlers.
- Light + dark mode, zero-flash, AA contrast in both.
- Production build clean: 0 lint, 0 TS, 0 build errors.
