# Ooster — Premium UX Research & Product Analytics Dashboard Template

> **Premium UX Research, Product Analytics, Usability Testing, and Experience Intelligence Dashboard template built on Next.js 16, TypeScript, Tailwind CSS 4, and shadcn/ui.**

Ooster is a calm, design-focused SaaS dashboard template engineered for UX researchers, product designers, product managers, CRO specialists, and design agencies. It ships with **110+ real routes**, a complete design-token system, polished light/dark themes, a global command palette, working modals/drawers/tables, and developer-ready architecture — ready to deploy or sell as a commercial template.

---

## Why Ooster?

- **Specialized UX intelligence product** — not a generic admin dashboard. Every route, widget, and chart speaks the language of UX research.
- **Calm, premium aesthetic** — soft warm-neutral shell, ivory surface, charcoal ink, emerald/amber/coral semantic accents. No loud colors, no cheap gradients.
- **110+ real App Router routes** — every navigation item opens a real page. Browser refresh, back/forward, and deep-linking all work.
- **Token-driven theming** — every color is a CSS variable. Switch to dark mode instantly. Customize your palette in one file.
- **Production-grade components** — `PageHeader`, `StatCard`, `DataTable`, `FilterBar`, `ScoreRadar`, `EmptyState`, `LoadingSkeleton`, plus 5 working modals and a Zustand-driven modal store.
- **Zero lock-in** — mock data lives in `src/lib/data.ts`. Swap with real API calls without touching UI.

---

## Quick Start

```bash
# Install dependencies
bun install

# Start dev server
bun run dev

# Lint
bun run lint

# Production build
bun run build
```

Open `http://localhost:3000` to see the dashboard.

---

## Tech Stack

| Layer | Choice |
|---|---|
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5 (strict) |
| Styling | Tailwind CSS 4 + CSS variables |
| UI primitives | shadcn/ui (New York) + Radix |
| Icons | lucide-react |
| Charts | Custom SVG (ScoreRadar, MiniTrend, BarChart, DonutChart, LineChart) — zero chart deps for fast load |
| State | Zustand (modals, UI) + React state (page-level) |
| Theme | next-themes (light/dark/system, persisted) |
| Notifications | sonner |
| Forms | react-hook-form + zod |

---

## Folder Structure

```
src/
├── app/
│   ├── (dashboard)/          # Primary dashboard shell + all product routes
│   │   ├── layout.tsx        # DashboardShell wrapper (header, pill nav, footer)
│   │   ├── page.tsx          # Dashboard overview (UX command center)
│   │   ├── projects/         # /projects, /projects/[slug]
│   │   ├── insights/         # /insights, /insights/[id]
│   │   ├── heatmaps/         # /heatmaps, /heatmaps/[id]
│   │   ├── session-replays/  # /session-replays, /session-replays/[id]
│   │   ├── reports/          # /reports, /reports/[id], /generate, /saved, /templates
│   │   ├── journeys/         # /journeys, /journeys/[id]
│   │   ├── funnels/          # /funnels, /funnels/[id]
│   │   ├── screens/          # /screens, /screens/[id]
│   │   ├── prototypes/       # /prototypes, /prototypes/[id]
│   │   ├── benchmarks/       # /benchmarks, /benchmarks/[id]
│   │   ├── research/         # /research, /[id], /interviews, /surveys, /studies, /findings, /participants
│   │   ├── personas/         # /personas, /personas/[id]
│   │   ├── segments/         # /segments, /segments/[id]
│   │   ├── ux-score/         # UX score overview
│   │   ├── usability-tests/  # /usability-tests, /usability-tests/[id]
│   │   ├── path-analysis/    # Path analysis
│   │   ├── attention-maps/   # Attention heatmaps
│   │   ├── click-maps/       # Click density
│   │   ├── scroll-maps/      # Scroll depth
│   │   ├── metrics/          # usability, accessibility, conversion, engagement, cognitive-load, friction, task-flow
│   │   ├── issues/           # /issues, /issues/[id]
│   │   ├── recommendations/  # /recommendations, /recommendations/[id]
│   │   ├── experiments/      # /experiments, /experiments/[id]
│   │   ├── ab-tests/         # /ab-tests, /ab-tests/[id]
│   │   ├── audit-checklist/  # /audit-checklist, /audit-checklist/[id]
│   │   ├── teams/            # /teams, /teams/[id]
│   │   ├── customers/        # /customers, /customers/[id]
│   │   ├── invite/           # Send team invite
│   │   ├── notifications/    # Notifications center
│   │   ├── history/          # Activity history
│   │   ├── audit-logs/       # Compliance audit logs
│   │   ├── integrations/     # /integrations, /integrations/[id]
│   │   ├── api-keys/         # API key management
│   │   ├── webhooks/         # Webhook management
│   │   ├── billing/          # /billing, /billing/subscription, /billing/invoices
│   │   ├── data-export/      # Data export center
│   │   └── settings/         # /profile, /workspace, /appearance, /notifications, /security, /sessions, /team, /roles, /api-keys, /webhooks
│   ├── (auth)/               # Auth pages (split-screen branded layout)
│   │   ├── sign-in, sign-up, forgot-password, reset-password
│   │   ├── verify-email, two-factor, accept-invite, onboarding
│   ├── (marketing)/          # Public marketing/showcase area
│   │   ├── landing, features, pricing, docs, changelog, contact, help
│   ├── errors/               # 401, 403, 404, 408, 429, 500, offline, maintenance, coming-soon
│   ├── layout.tsx            # Root layout (theme provider, fonts, metadata)
│   └── globals.css           # Design tokens (light + dark)
├── components/
│   ├── layout/               # DashboardShell, Logo, ThemeToggle, UserMenu, MobileNav, NotificationsDropdown, SearchButton
│   ├── common/               # PageHeader, StatCard, EmptyState, LoadingSkeleton, FilterBar, CircleProgress, badges
│   ├── charts/               # ScoreRadar, MiniTrend, BarChart, DonutChart, LineChart (pure SVG)
│   ├── tables/               # DataTable (search, sort, paginate, mobile cards)
│   ├── command/              # CommandPalette (Cmd+K, recent pages, quick actions)
│   ├── modals/               # CreateProject, GenerateReport, CreateInsight, Share, Confirm
│   └── ui/                   # shadcn/ui primitives (60+ components)
├── hooks/
│   ├── use-modals.ts         # Zustand modal store (command, create, share, drawer, confirm)
│   ├── use-toast.ts          # Toast hook
│   └── use-mobile.ts         # Mobile detection
├── lib/
│   ├── data.ts               # All mock data (projects, insights, reports, etc.) — swap for real API
│   ├── navigation.ts         # PRIMARY_NAV config
│   ├── utils.ts              # cn() and helpers
│   └── db.ts                 # Prisma client (if you need a database)
└── types/                    # Shared TypeScript types
```

---

## Design System

### Color Tokens (`src/app/globals.css`)

| Token | Light | Dark | Usage |
|---|---|---|---|
| `--shell` | Soft muted lavender | Deep charcoal-lavender | Outer app background |
| `--surface` | Ivory | Warm dark porcelain | Dashboard surface |
| `--card` | Pure white | Dark card | Cards, popovers |
| `--primary` | Slate/ink | Light slate | Primary actions |
| `--success` | Emerald | Light emerald | Good scores, completed |
| `--warning` | Amber | Light amber | Attention, medium severity |
| `--friction` | Coral | Light coral | Risk, critical severity |
| `--info` | Slate-blue | Light slate-blue | Info, neutral insights |
| `--border` | Soft warm gray | Subtle white overlay | Borders, dividers |

### Using Tokens

```tsx
// Surfaces
<div className="bg-shell p-6">
  <div className="bg-surface rounded-3xl p-6">
    <Card className="bg-card border-soft shadow-soft p-4">…</Card>
  </div>
</div>

// Text
<span className="text-ink">Primary text</span>
<span className="text-muted-foreground">Secondary text</span>
<span className="text-success">Good metric</span>
<span className="text-friction">Risk metric</span>

// Custom shadow utility
<div className="shadow-card">…</div>
```

### Typography

- Sans: Geist (default)
- Mono: Geist Mono (for numbers, code, IDs)

---

## Theme System

Light is the default. Dark mode is fully polished — every component, chart, and modal supports both.

- **Toggle**: Click the sun/moon icon in the header (or use the Appearance settings page)
- **Persistence**: Theme is stored in `localStorage` under `ooster-theme`
- **No hydration flicker**: An inline `<script>` in `app/layout.tsx` applies the theme before React hydrates
- **System option**: Follow OS preference with one click

---

## Command Palette (Cmd+K)

Press **⌘K** (Mac) or **Ctrl+K** (Windows/Linux) anywhere to open the command palette:

- **Quick actions** — Create project, Generate report, Create insight, Switch theme, Export data, Invite member
- **Page search** — All 110+ routes indexed
- **Project search** — Search by name, jump to project detail
- **Insight search** — Search by title, jump to insight detail
- **Report search** — Search by title, jump to report
- **Research, People** — Studies and team members
- **Recently visited** — Tracked in `localStorage` (last 6 pages)

---

## Adding a New Route

1. Create `src/app/(dashboard)/your-route/page.tsx`
2. Use the page template:

```tsx
"use client";

import * as React from "react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { SomeIcon } from "lucide-react";

export default function YourRoutePage() {
  const [loading, setLoading] = React.useState(true);
  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  return (
    <div>
      <PageHeader
        title="Your Page"
        description="What this page does."
        breadcrumbs={[{ label: "Your Page" }]}
        icon={<SomeIcon className="h-5 w-5" />}
      />
      {/* Content */}
    </div>
  );
}
```

3. (Optional) Add `loading.tsx` and `error.tsx` in the same directory using the templates in `scripts/create-loading-error.sh`
4. (Optional) Add to `PRIMARY_NAV` in `src/lib/navigation.ts` to surface in the top nav

---

## Mock Data → Real API

All data lives in **one file**: `src/lib/data.ts`. To go live:

1. Replace the export constants (`PROJECTS`, `INSIGHTS`, etc.) with API calls using TanStack Query or `fetch`
2. Keep the TypeScript interfaces (already exported) for type safety
3. Replace the `get*` helpers with async API calls
4. UI components don't need to change — they consume the typed data

Example swap:

```ts
// Before (mock)
export const PROJECTS: Project[] = [/* … */];

// After (real API)
export async function getProjects(): Promise<Project[]> {
  const res = await fetch("/api/projects");
  return res.json();
}
```

---

## Components Reference

### `PageHeader`

```tsx
<PageHeader
  title="Insights"
  description="Prioritized UX insights ranked by impact × confidence"
  breadcrumbs={[{ label: "Insights" }]}
  icon={<Lightbulb className="h-5 w-5" />}
  badge={<Badge variant="secondary">23 insights</Badge>}
  actions={
    <>
      <Button variant="outline" size="sm">Export</Button>
      <Button size="sm">New insight</Button>
    </>
  }
/>
```

### `StatCard`

```tsx
<StatCard
  label="UX score"
  value={87}
  unit="/100"
  icon={<Eye className="h-4 w-4" />}
  accent="success"
  trend={{ value: 4.2, direction: "up", good: true }}
  sublabel="vs last week"
/>
```

### `DataTable`

```tsx
<DataTable
  data={ISSUES}
  columns={[
    { key: "title", header: "Title", cell: (row) => row.title, sortable: true, sortAccessor: (row) => row.title },
    { key: "severity", header: "Severity", cell: (row) => <SeverityBadge severity={row.severity} /> },
  ]}
  searchable
  searchKeys={["title", "project"]}
  pageSize={10}
  getRowId={(row) => row.id}
  onRowClick={(row) => router.push(`/issues/${row.id}`)}
/>
```

### `ScoreRadar`

```tsx
<ScoreRadar
  data={[
    { label: "Usability", value: 78, key: "usability" },
    { label: "Accessibility", value: 86, key: "a11y" },
    // …up to 8 dimensions
  ]}
  size={280}
  color="var(--success)"
/>
```

### Modals (via Zustand store)

```tsx
import { useModals } from "@/hooks/use-modals";

function MyComponent() {
  const setCreateOpen = useModals((s) => s.setCreateProjectOpen);
  const openShare = useModals((s) => s.openShare);
  const openConfirm = useModals((s) => s.openConfirm);

  return (
    <>
      <Button onClick={() => setCreateOpen(true)}>New project</Button>
      <Button onClick={() => openShare("/projects/p-001", "Atlas Onboarding")}>Share</Button>
      <Button onClick={() => openConfirm({
        title: "Archive project?",
        description: "This action can be undone within 30 days.",
        onConfirm: () => console.log("archived"),
      })}>Archive</Button>
    </>
  );
}
```

---

## Charts

All charts are **pure SVG** — no chart library dependency, no extra bundle weight, theme-aware via CSS variables.

| Component | Props | Use case |
|---|---|---|
| `<ScoreRadar>` | `data`, `size`, `color` | UX score breakdown, multi-dimensional comparison |
| `<CircleProgress>` | `value`, `size`, `color`, `label` | Single KPI ring |
| `<MiniTrend>` | `data`, `width`, `height`, `color` | Sparkline in stat cards |
| `<BarChart>` | `data`, `height` | Categorical comparison |
| `<DonutChart>` | `data`, `size`, `centerValue` | Distribution (severity, status) |
| `<LineChart>` | `data`, `height` | Time-series trends |

---

## Mobile Experience

Every page is mobile-first:

- **Header**: Pill nav collapses into a hamburger sheet on `< lg`
- **Grids**: Stack from 1 → 2 → 3 columns across breakpoints
- **Tables**: Auto-collapse to card view on mobile (DataTable handles this)
- **Filter bars**: Stack vertically with full-width inputs
- **Modals**: Full-screen on mobile, centered on desktop
- **Touch targets**: All interactive elements ≥ 36px (44px on critical actions)
- **No horizontal overflow**: Wide tables scroll horizontally; flow diagrams wrap

---

## Accessibility

- Semantic HTML (`<main>`, `<header>`, `<nav>`, `<section>`, `<article>`)
- ARIA labels on all icon-only buttons
- Keyboard navigation (focus visible, focus trap in modals/drawers)
- Screen reader text via `sr-only`
- Color contrast meets WCAG AA in both light and dark mode
- Command palette keyboard accessible (arrow keys, enter, escape)

---

## Performance

- **Turbopack** dev server (Next.js 16 default)
- **Route-level code splitting** (each route is its own chunk)
- **Route-level loading/error boundaries** on every major route
- **Pure SVG charts** (no recharts/chart.js bundle)
- **Image optimization**: `next/image` for avatars and project previews
- **CSS variables** (no runtime style recalculation)
- **Zustand** for global state (lighter than Redux/Context)

---

## License Routes Summary

### Dashboard (37 routes)
`/`, `/projects`, `/projects/[slug]`, `/insights`, `/insights/[id]`, `/heatmaps`, `/heatmaps/[id]`, `/session-replays`, `/session-replays/[id]`, `/reports`, `/reports/[id]`, `/reports/generate`, `/reports/saved`, `/reports/templates`, `/journeys`, `/journeys/[id]`, `/funnels`, `/funnels/[id]`, `/screens`, `/screens/[id]`, `/prototypes`, `/prototypes/[id]`, `/benchmarks`, `/benchmarks/[id]`, `/ux-score`, `/usability-tests`, `/usability-tests/[id]`, `/path-analysis`, `/attention-maps`, `/click-maps`, `/scroll-maps`, `/issues`, `/issues/[id]`, `/recommendations`, `/recommendations/[id]`, `/experiments`, `/experiments/[id]`, `/ab-tests`, `/ab-tests/[id]`, `/audit-checklist`, `/audit-checklist/[id]`

### Metrics (7 routes)
`/metrics/usability`, `/metrics/accessibility`, `/metrics/conversion`, `/metrics/engagement`, `/metrics/cognitive-load`, `/metrics/friction`, `/metrics/task-flow`

### Research (8 routes)
`/research`, `/research/[id]`, `/research/interviews`, `/research/surveys`, `/research/surveys/[id]`, `/research/studies`, `/research/findings`, `/research/participants`

### People & Compliance (8 routes)
`/teams`, `/teams/[id]`, `/customers`, `/customers/[id]`, `/invite`, `/notifications`, `/history`, `/audit-logs`

### Personas & Segments (4 routes)
`/personas`, `/personas/[id]`, `/segments`, `/segments/[id]`

### Integrations & Billing (9 routes)
`/integrations`, `/integrations/[id]`, `/api-keys`, `/webhooks`, `/billing`, `/billing/subscription`, `/billing/invoices`, `/data-export`, `/settings`

### Settings (11 routes)
`/settings/profile`, `/settings/workspace`, `/settings/appearance`, `/settings/notifications`, `/settings/security`, `/settings/sessions`, `/settings/team`, `/settings/roles`, `/settings/api-keys`, `/settings/webhooks`, `/settings`

### Auth (8 routes)
`/sign-in`, `/sign-up`, `/forgot-password`, `/reset-password`, `/verify-email`, `/two-factor`, `/accept-invite`, `/onboarding`

### Marketing (7 routes)
`/landing`, `/features`, `/pricing`, `/docs`, `/changelog`, `/contact`, `/help`

### Errors (9 routes)
`/errors/401`, `/errors/403`, `/errors/404`, `/errors/408`, `/errors/429`, `/errors/500`, `/errors/offline`, `/errors/maintenance`, `/errors/coming-soon`

**Total: 110+ routes**

---

## Customization Guide

### Change the brand name

1. `src/components/layout/logo.tsx` — update wordmark text
2. `src/app/layout.tsx` — update `metadata.title` and `applicationName`
3. `src/app/globals.css` — update comment headers
4. Search-and-replace `Ooster` with your brand

### Change the color palette

Edit `src/app/globals.css` — both `:root` (light) and `.dark` blocks. Use OKLCH color space for perceptual consistency:

```css
:root {
  --primary: oklch(0.32 0.025 270);  /* Hue 270 = slate-purple */
  --success: oklch(0.62 0.13 160);   /* Hue 160 = emerald */
  /* … */
}
```

### Change the logo

Edit `src/components/layout/logo.tsx` — replace the SVG mark with your own. Also update `public/icon.svg` and regenerate PNGs:

```bash
node scripts/generate-icons.mjs
```

### Add a new chart type

Create a new file in `src/components/charts/` — follow the pattern of `score-radar.tsx` (pure SVG, theme-aware via CSS variables).

---

## Deployment

### Vercel (recommended)

```bash
vercel
```

Ooster is built for Vercel out of the box — no special configuration needed.

### Self-hosted (Docker)

```bash
bun run build
bun run start
```

The build outputs a standalone server in `.next/standalone/`.

### Environment variables

None required for the template (all data is mock). When you wire real APIs, add:

```env
DATABASE_URL=postgresql://…
NEXTAUTH_SECRET=…
NEXTAUTH_URL=https://your-domain.com
```

---

## Changelog

### v1.0.0 — 2026-07-02

- 🎉 Initial release
- 110+ real routes across dashboard, auth, marketing, and error boundaries
- Premium light/dark theme with token-driven design system
- Global command palette (Cmd+K) with recent pages
- 5 working modals (create project, generate report, create insight, share, confirm)
- Pure SVG charts (radar, donut, bar, line, sparkline) — zero chart deps
- Reusable DataTable with search, sort, paginate, mobile card view
- Mock data layer ready to swap for real API
- Mobile-first responsive design
- WCAG AA accessibility
- Route-level loading and error boundaries

---

## License

This template is released under a **commercial license**. Purchase includes:

- ✅ Unlimited personal projects
- ✅ Unlimited client projects
- ✅ SaaS product use
- ❌ No reselling as a template
- ❌ No open-sourcing

Contact `sales@ooster.app` for enterprise licensing.

---

## Support

- 📧 Email: `support@ooster.app`
- 📖 Docs: `/docs`
- 💬 Help center: `/help`
- 🔄 Changelog: `/changelog`

---

**Ooster** — Premium UX intelligence for modern product teams.
© 2026 Ooster Labs.
