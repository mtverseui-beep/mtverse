"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, SlidersHorizontal, X } from "lucide-react";

export interface FilterOption {
  label: string;
  value: string;
}

interface FilterBarProps {
  search?: {
    value: string;
    onChange: (v: string) => void;
    placeholder?: string;
  };
  selects?: {
    label: string;
    value: string;
    onChange: (v: string) => void;
    options: FilterOption[];
  }[];
  viewSwitch?: {
    options: { label: string; value: string }[];
    value: string;
    onChange: (v: string) => void;
  };
  onClear?: () => void;
  actions?: React.ReactNode;
  className?: string;
}

export function FilterBar({ search, selects, viewSwitch, onClear, actions, className }: FilterBarProps) {
  const hasActive = (search?.value || selects?.some((s) => s.value !== "all"));
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);

  return (
    <div className={cn("flex flex-col sm:flex-row gap-2 sm:items-center sm:justify-between", className)}>
      <div className="flex flex-wrap items-center gap-2 flex-1">
        {search && (
          <div className="relative flex-1 min-w-[180px] max-w-xs">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              value={search.value}
              onChange={(e) => search.onChange(e.target.value)}
              placeholder={search.placeholder || "Search…"}
              className="pl-8 h-9 text-xs"
            />
          </div>
        )}
        {selects?.map((s, i) => (
          mounted ? (
            <Select key={i} value={s.value} onValueChange={s.onChange}>
              <SelectTrigger className="h-9 w-auto text-xs gap-1.5 min-w-[120px]">
                <SlidersHorizontal className="h-3 w-3 opacity-60" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {s.options.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <div key={i} className="h-9 min-w-[120px] rounded-md border border-soft bg-card px-3 flex items-center gap-1.5 text-xs">
              <SlidersHorizontal className="h-3 w-3 opacity-60" />
              <span>{s.options.find((o) => o.value === s.value)?.label || s.label}</span>
            </div>
          )
        ))}
        {hasActive && onClear && (
          <Button variant="ghost" size="sm" className="h-9 text-xs" onClick={onClear}>
            <X className="mr-1 h-3 w-3" /> Clear
          </Button>
        )}
      </div>
      <div className="flex items-center gap-2">
        {viewSwitch && (
          <div className="inline-flex items-center rounded-full bg-surface-2 p-0.5">
            {viewSwitch.options.map((o) => (
              <button
                key={o.value}
                onClick={() => viewSwitch.onChange(o.value)}
                className={cn(
                  "px-3 py-1 text-xs font-medium rounded-full transition-all cursor-pointer",
                  viewSwitch.value === o.value
                    ? "bg-card text-ink shadow-soft"
                    : "text-muted-foreground hover:text-ink"
                )}
              >
                {o.label}
              </button>
            ))}
          </div>
        )}
        {actions}
      </div>
    </div>
  );
}
