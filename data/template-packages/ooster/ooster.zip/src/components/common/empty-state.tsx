"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: { label: string; onClick?: () => void; href?: string };
  secondaryAction?: { label: string; onClick?: () => void; href?: string };
  className?: string;
  compact?: boolean;
}

import { Button } from "@/components/ui/button";
import Link from "next/link";

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  secondaryAction,
  className,
  compact,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center text-center rounded-2xl border border-dashed border-soft bg-surface-2/40",
        compact ? "p-6" : "p-10 sm:p-14",
        className
      )}
    >
      <div className={cn("flex items-center justify-center rounded-2xl bg-surface-2 text-muted-foreground", compact ? "h-10 w-10" : "h-14 w-14")}>
        <Icon className={compact ? "h-5 w-5" : "h-7 w-7"} />
      </div>
      <h3 className={cn("font-semibold text-ink", compact ? "mt-3 text-sm" : "mt-4 text-base")}>{title}</h3>
      {description && (
        <p className={cn("text-muted-foreground mt-1 max-w-sm", compact ? "text-xs" : "text-sm")}>{description}</p>
      )}
      {(action || secondaryAction) && (
        <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
          {action && (
            action.href ? (
              <Button asChild size={compact ? "sm" : "default"}>
                <Link href={action.href}>{action.label}</Link>
              </Button>
            ) : (
              <Button size={compact ? "sm" : "default"} onClick={action.onClick}>{action.label}</Button>
            )
          )}
          {secondaryAction && (
            secondaryAction.href ? (
              <Button asChild variant="outline" size={compact ? "sm" : "default"}>
                <Link href={secondaryAction.href}>{secondaryAction.label}</Link>
              </Button>
            ) : (
              <Button variant="outline" size={compact ? "sm" : "default"} onClick={secondaryAction.onClick}>{secondaryAction.label}</Button>
            )
          )}
        </div>
      )}
    </div>
  );
}
