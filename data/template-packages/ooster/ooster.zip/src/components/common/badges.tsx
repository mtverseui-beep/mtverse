"use client";

import * as React from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type Severity = "critical" | "high" | "medium" | "low";
type Status = "active" | "paused" | "archived" | "draft" | "open" | "in-progress" | "resolved" | "wontfix" | "new" | "triaging" | "ready" | "generating" | "scheduled" | "live" | "closed" | "analyzing" | "completed" | "recruiting" | "planning" | "running" | "trialing" | "churned" | "paid" | "pending" | "failed" | "refunded" | "invited" | "suspended" | "connected" | "available" | "coming-soon";

const severityStyles: Record<Severity, string> = {
  critical: "bg-friction/15 text-friction border-friction/20",
  high: "bg-warning/15 text-warning border-warning/20",
  medium: "bg-info/15 text-info border-info/20",
  low: "bg-success/15 text-success border-success/20",
};

const statusStyles: Record<string, string> = {
  active: "bg-success/15 text-success border-success/20",
  ready: "bg-success/15 text-success border-success/20",
  completed: "bg-success/15 text-success border-success/20",
  resolved: "bg-success/15 text-success border-success/20",
  paid: "bg-success/15 text-success border-success/20",
  connected: "bg-success/15 text-success border-success/20",
  live: "bg-success/15 text-success border-success/20",

  paused: "bg-muted text-muted-foreground border-border",
  archived: "bg-muted text-muted-foreground border-border",
  draft: "bg-muted text-muted-foreground border-border",
  scheduled: "bg-info/15 text-info border-info/20",
  coming: "bg-muted text-muted-foreground border-border",
  "coming-soon": "bg-muted text-muted-foreground border-border",
  available: "bg-muted text-muted-foreground border-border",
  wontfix: "bg-muted text-muted-foreground border-border",
  closed: "bg-muted text-muted-foreground border-border",

  "in-progress": "bg-info/15 text-info border-info/20",
  planning: "bg-info/15 text-info border-info/20",
  recruiting: "bg-info/15 text-info border-info/20",
  running: "bg-info/15 text-info border-info/20",
  analyzing: "bg-info/15 text-info border-info/20",
  generating: "bg-info/15 text-info border-info/20",
  triaging: "bg-info/15 text-info border-info/20",
  new: "bg-info/15 text-info border-info/20",
  pending: "bg-warning/15 text-warning border-warning/20",
  invited: "bg-warning/15 text-warning border-warning/20",
  suspended: "bg-warning/15 text-warning border-warning/20",

  open: "bg-friction/15 text-friction border-friction/20",
  failed: "bg-friction/15 text-friction border-friction/20",
  churned: "bg-friction/15 text-friction border-friction/20",
};

export function SeverityBadge({ severity, label }: { severity: Severity; label?: string }) {
  return (
    <Badge variant="outline" className={cn("border text-[10px] font-medium capitalize", severityStyles[severity])}>
      {label || severity}
    </Badge>
  );
}

export function StatusBadge({ status, label }: { status: Status; label?: string }) {
  return (
    <Badge variant="outline" className={cn("border text-[10px] font-medium capitalize", statusStyles[status] || "bg-muted text-muted-foreground border-border")}>
      {label || status.replace("-", " ")}
    </Badge>
  );
}
