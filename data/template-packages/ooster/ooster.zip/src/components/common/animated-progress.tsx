"use client";

import * as React from "react";
import { motion, useMotionValue, useSpring, useTransform, animate } from "framer-motion";
import { cn } from "@/lib/utils";

// ============================================================================
// AnimatedNumber — counts up smoothly with spring physics
// ============================================================================

export function AnimatedNumber({
  value,
  duration = 1.2,
  format,
  className,
  prefix = "",
  suffix = "",
}: {
  value: number;
  duration?: number;
  format?: (v: number) => string;
  className?: string;
  prefix?: string;
  suffix?: string;
}) {
  const [display, setDisplay] = React.useState(0);
  const ref = React.useRef<HTMLSpanElement>(null);
  const started = React.useRef(false);

  React.useEffect(() => {
    if (started.current) return;
    started.current = true;
    let start: number | null = null;
    let raf: number;
    const step = (ts: number) => {
      if (start === null) start = ts;
      const progress = Math.min((ts - start) / (duration * 1000), 1);
      // easeOutExpo
      const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      setDisplay(value * eased);
      if (progress < 1) raf = requestAnimationFrame(step);
      else setDisplay(value);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);

  const formatted = format ? format(display) : Math.round(display).toLocaleString();
  return (
    <span ref={ref} className={className}>
      {prefix}{formatted}{suffix}
    </span>
  );
}

// ============================================================================
// ProgressBar — horizontal bar with animated fill
// ============================================================================

export function ProgressBar({
  value,
  max = 100,
  className,
  color = "var(--primary)",
  trackColor = "var(--muted)",
  height = 8,
  rounded = true,
  showLabel = false,
  animateOnMount = true,
  delay = 0,
}: {
  value: number;
  max?: number;
  className?: string;
  color?: string;
  trackColor?: string;
  height?: number;
  rounded?: boolean;
  showLabel?: boolean;
  animateOnMount?: boolean;
  delay?: number;
}) {
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div
        className={cn("flex-1 overflow-hidden", rounded && "rounded-full")}
        style={{ background: trackColor, height }}
      >
        <motion.div
          className={cn("h-full", rounded && "rounded-full")}
          style={{ background: color }}
          initial={animateOnMount ? { width: 0 } : false}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>
      {showLabel && (
        <span className="text-xs font-semibold text-ink tabular-nums w-9 text-right">
          {Math.round(pct)}%
        </span>
      )}
    </div>
  );
}

// ============================================================================
// RoundedProgress — circular progress ring (premium animated)
// ============================================================================

export function RoundedProgress({
  value,
  size = 80,
  strokeWidth = 6,
  color = "var(--success)",
  trackColor = "var(--muted)",
  label,
  sublabel,
  className,
  delay = 0,
  showGlow = false,
}: {
  value: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  trackColor?: string;
  label?: string;
  sublabel?: string;
  className?: string;
  delay?: number;
  showGlow?: boolean;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;

  return (
    <div className={cn("relative inline-flex items-center justify-center", className)} style={{ width: size, height: size }}>
      <svg className="-rotate-90" width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={trackColor} strokeWidth={strokeWidth} />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeLinecap="round"
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.2, delay, ease: [0.22, 1, 0.36, 1] }}
          style={showGlow ? { filter: `drop-shadow(0 0 6px ${color})` } : undefined}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-base font-semibold text-ink tabular-nums">{label ?? `${value}%`}</span>
        {sublabel && <span className="text-[9px] text-muted-foreground">{sublabel}</span>}
      </div>
    </div>
  );
}

// ============================================================================
// ActiveDot — pulsing dot indicator (for "live" / "active" states)
// ============================================================================

export function ActiveDot({
  color = "var(--success)",
  size = 8,
  pulse = true,
  className,
}: {
  color?: string;
  size?: number;
  pulse?: boolean;
  className?: string;
}) {
  return (
    <span className={cn("relative inline-flex", className)} style={{ width: size, height: size }}>
      {pulse && (
        <motion.span
          className="absolute inset-0 rounded-full"
          style={{ background: color }}
          animate={{ scale: [1, 2.2, 1], opacity: [0.6, 0, 0.6] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeOut" }}
        />
      )}
      <span
        className="relative inline-block rounded-full"
        style={{ width: size, height: size, background: color }}
      />
    </span>
  );
}

// ============================================================================
// StepDots — animated step indicator
// ============================================================================

export function StepDots({
  total,
  active,
  color = "var(--primary)",
  className,
}: {
  total: number;
  active: number;
  color?: string;
  className?: string;
}) {
  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      {Array.from({ length: total }).map((_, i) => (
        <motion.div
          key={i}
          className="rounded-full"
          style={{ background: i <= active ? color : "var(--muted)" }}
          animate={{
            width: i === active ? 24 : 8,
            height: 8,
          }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        />
      ))}
    </div>
  );
}

// ============================================================================
// TrendArrow — animated arrow that points up/down with color
// ============================================================================

export function TrendArrow({
  direction,
  good,
  value,
  className,
}: {
  direction: "up" | "down" | "flat";
  good?: boolean;
  value?: string;
  className?: string;
}) {
  const isGood = good ?? (direction === "up");
  const color = direction === "flat" ? "var(--muted-foreground)" : isGood ? "var(--success)" : "var(--friction)";
  const rotate = direction === "up" ? 0 : direction === "down" ? 180 : 90;

  return (
    <span className={cn("inline-flex items-center gap-0.5 text-xs font-medium", className)} style={{ color }}>
      <motion.svg
        width="12"
        height="12"
        viewBox="0 0 12 12"
        initial={{ rotate: rotate - 10, opacity: 0 }}
        animate={{ rotate, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        <path d="M6 2 L10 8 L2 8 Z" fill="currentColor" />
      </motion.svg>
      {value}
    </span>
  );
}
