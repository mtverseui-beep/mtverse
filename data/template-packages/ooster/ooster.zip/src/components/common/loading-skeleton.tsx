"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

interface LoadingSkeletonProps {
  variant?: "page" | "cards" | "table" | "radar" | "preview";
  className?: string;
}

export function LoadingSkeleton({ variant = "page", className }: LoadingSkeletonProps) {
  if (variant === "cards") {
    return (
      <div className={cn("grid grid-cols-2 lg:grid-cols-4 gap-3", className)}>
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="rounded-2xl bg-card border border-soft p-4 space-y-3">
            <div className="h-3 w-1/2 shimmer rounded" />
            <div className="h-8 w-2/3 shimmer rounded" />
            <div className="h-2 w-1/3 shimmer rounded" />
          </div>
        ))}
      </div>
    );
  }

  if (variant === "table") {
    return (
      <div className={cn("rounded-2xl bg-card border border-soft overflow-hidden", className)}>
        <div className="p-4 border-b border-soft flex gap-4">
          <div className="h-8 w-48 shimmer rounded" />
          <div className="h-8 w-24 shimmer rounded" />
        </div>
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="p-4 border-b border-soft last:border-0 flex gap-4">
            <div className="h-4 w-1/3 shimmer rounded" />
            <div className="h-4 w-1/5 shimmer rounded" />
            <div className="h-4 w-1/5 shimmer rounded" />
            <div className="h-4 w-1/6 shimmer rounded" />
          </div>
        ))}
      </div>
    );
  }

  if (variant === "radar") {
    return (
      <div className={cn("rounded-2xl bg-card border border-soft p-4 flex flex-col items-center justify-center", className)}>
        <div className="h-3 w-20 shimmer rounded mb-3 self-start" />
        <div className="h-48 w-48 rounded-full shimmer" />
        <div className="w-full space-y-2 mt-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="h-2 w-2 shimmer rounded-full" />
              <div className="h-2 w-1/2 shimmer rounded" />
              <div className="h-2 w-12 shimmer rounded ml-auto" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (variant === "preview") {
    return (
      <div className={cn("rounded-2xl bg-card border border-soft p-4 space-y-3", className)}>
        <div className="flex items-center justify-between">
          <div className="h-4 w-32 shimmer rounded" />
          <div className="h-6 w-6 shimmer rounded-full" />
        </div>
        <div className="h-48 w-full shimmer rounded-xl" />
      </div>
    );
  }

  // page
  return (
    <div className={cn("space-y-4", className)}>
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <div className="h-6 w-48 shimmer rounded" />
          <div className="h-3 w-72 shimmer rounded" />
        </div>
        <div className="h-9 w-24 shimmer rounded-full" />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="rounded-2xl bg-card border border-soft p-4 space-y-3">
            <div className="h-3 w-1/2 shimmer rounded" />
            <div className="h-8 w-2/3 shimmer rounded" />
            <div className="h-2 w-1/3 shimmer rounded" />
          </div>
        ))}
      </div>
      <div className="grid lg:grid-cols-3 gap-3">
        <div className="lg:col-span-2 h-72 rounded-2xl bg-card border border-soft p-4">
          <div className="h-4 w-32 shimmer rounded mb-4" />
          <div className="h-56 w-full shimmer rounded-xl" />
        </div>
        <div className="h-72 rounded-2xl bg-card border border-soft p-4 space-y-3">
          <div className="h-4 w-24 shimmer rounded" />
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="h-8 w-8 shimmer rounded-full" />
              <div className="flex-1 space-y-1">
                <div className="h-2 w-2/3 shimmer rounded" />
                <div className="h-2 w-1/3 shimmer rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
