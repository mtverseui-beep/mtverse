"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * ScreenMockup — a designed UI mockup that looks like a real product screen.
 * Used in project previews, heatmap backgrounds, session replay backgrounds, etc.
 * No stock photos — pure SVG/CSS, theme-aware, premium.
 */

interface ScreenMockupProps {
  variant?: "analytics" | "checkout" | "onboarding" | "list" | "dashboard" | "mobile";
  className?: string;
  accentColor?: string;
}

export function ScreenMockup({ variant = "analytics", className, accentColor }: ScreenMockupProps) {
  return (
    <div className={cn("relative w-full h-full bg-surface overflow-hidden", className)}>
      {/* Browser chrome */}
      <div className="absolute top-0 left-0 right-0 h-8 bg-surface-2 border-b border-soft flex items-center px-3 gap-1.5 z-20">
        <div className="h-2.5 w-2.5 rounded-full bg-friction/60" />
        <div className="h-2.5 w-2.5 rounded-full bg-warning/60" />
        <div className="h-2.5 w-2.5 rounded-full bg-success/60" />
        <div className="ml-3 flex-1 h-4 rounded-md bg-card/60 border border-soft flex items-center px-2">
          <div className="h-1.5 w-1/3 rounded-full bg-muted-foreground/30" />
        </div>
      </div>

      {/* Content area */}
      <div className="absolute top-8 left-0 right-0 bottom-0 p-4">
        {variant === "analytics" && <AnalyticsMockup accent={accentColor} />}
        {variant === "checkout" && <CheckoutMockup />}
        {variant === "onboarding" && <OnboardingMockup />}
        {variant === "list" && <ListMockup />}
        {variant === "dashboard" && <DashboardMockup accent={accentColor} />}
        {variant === "mobile" && <MobileMockup />}
      </div>
    </div>
  );
}

// ============================================================================
// Analytics dashboard mockup — chart + cards
// ============================================================================

function AnalyticsMockup({ accent }: { accent?: string }) {
  const color = accent || "var(--success)";
  return (
    <div className="w-full h-full flex flex-col gap-3">
      {/* Top stats row */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "Sessions", value: "12,840", trend: "+12%" },
          { label: "Conversion", value: "4.8%", trend: "+0.6pp" },
          { label: "Avg time", value: "3:42", trend: "-8s" },
        ].map((s, i) => (
          <motion.div
            key={s.label}
            className="rounded-lg bg-card border border-soft p-2"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.08, duration: 0.3 }}
          >
            <div className="text-[8px] text-muted-foreground">{s.label}</div>
            <div className="text-xs font-semibold text-ink mt-0.5">{s.value}</div>
            <div className="text-[7px] text-success mt-0.5">{s.trend}</div>
          </motion.div>
        ))}
      </div>

      {/* Main chart */}
      <div className="flex-1 rounded-lg bg-card border border-soft p-3 relative overflow-hidden">
        <div className="flex items-center justify-between mb-2">
          <div className="h-2 w-20 rounded-full bg-muted-foreground/30" />
          <div className="flex gap-1">
            <div className="h-3 w-6 rounded-full bg-surface-2" />
            <div className="h-3 w-6 rounded-full" style={{ background: color }} />
          </div>
        </div>
        <svg viewBox="0 0 200 80" className="w-full h-full" preserveAspectRatio="none">
          {/* Grid */}
          {[20, 40, 60].map((y) => (
            <line key={y} x1="0" y1={y} x2="200" y2={y} stroke="var(--border)" strokeWidth="0.5" strokeDasharray="2 2" />
          ))}
          {/* Area */}
          <motion.path
            d="M0,60 L20,55 L40,50 L60,45 L80,40 L100,30 L120,35 L140,25 L160,20 L180,15 L200,10 L200,80 L0,80 Z"
            fill={color}
            opacity={0.15}
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.15 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          />
          {/* Line */}
          <motion.path
            d="M0,60 L20,55 L40,50 L60,45 L80,40 L100,30 L120,35 L140,25 L160,20 L180,15 L200,10"
            fill="none"
            stroke={color}
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.2, ease: "easeInOut", delay: 0.3 }}
          />
          {/* Animated dot at the end */}
          <motion.circle
            cx="200"
            cy="10"
            r="3"
            fill={color}
            initial={{ scale: 0 }}
            animate={{ scale: [0, 1.2, 1] }}
            transition={{ delay: 1.5, duration: 0.4 }}
          />
        </svg>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-lg bg-card border border-soft p-2">
          <div className="h-2 w-16 rounded-full bg-muted-foreground/30 mb-1.5" />
          <div className="flex items-end gap-1 h-8">
            {[60, 80, 45, 70, 90, 55].map((h, i) => (
              <motion.div
                key={i}
                className="flex-1 rounded-sm"
                style={{ background: color, opacity: 0.5 + (i / 6) * 0.5 }}
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                transition={{ delay: 0.5 + i * 0.05, duration: 0.4, ease: "easeOut" }}
              />
            ))}
          </div>
        </div>
        <div className="rounded-lg bg-card border border-soft p-2 flex items-center justify-center">
          <svg viewBox="0 0 60 60" className="w-12 h-12">
            <circle cx="30" cy="30" r="22" fill="none" stroke="var(--muted)" strokeWidth="5" />
            <motion.circle
              cx="30"
              cy="30"
              r="22"
              fill="none"
              stroke={color}
              strokeWidth="5"
              strokeLinecap="round"
              strokeDasharray="138"
              initial={{ strokeDashoffset: 138 }}
              animate={{ strokeDashoffset: 138 - (138 * 78) / 100 }}
              transition={{ delay: 0.8, duration: 1, ease: "easeOut" }}
              transform="rotate(-90 30 30)"
            />
            <text x="30" y="34" textAnchor="middle" className="fill-ink text-[10px] font-semibold">78%</text>
          </svg>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// Checkout mockup
// ============================================================================

function CheckoutMockup() {
  return (
    <div className="w-full h-full flex gap-3">
      <div className="flex-1 flex flex-col gap-2">
        <motion.div className="rounded-lg bg-card border border-soft p-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
          <div className="h-2 w-24 rounded-full bg-muted-foreground/30 mb-1.5" />
          <div className="space-y-1.5">
            <div className="h-3 rounded-md bg-surface-2 border border-soft" />
            <div className="h-3 rounded-md bg-surface-2 border border-soft" />
            <div className="h-3 w-2/3 rounded-md bg-surface-2 border border-soft" />
          </div>
        </motion.div>
        <motion.div className="rounded-lg bg-card border border-soft p-2 flex-1" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
          <div className="h-2 w-20 rounded-full bg-muted-foreground/30 mb-1.5" />
          <div className="grid grid-cols-4 gap-1">
            {Array.from({ length: 12 }).map((_, i) => (
              <motion.div
                key={i}
                className="aspect-square rounded bg-surface-2 border border-soft"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + i * 0.02 }}
              />
            ))}
          </div>
        </motion.div>
      </div>
      <motion.div
        className="w-24 rounded-lg bg-card border border-soft p-2 flex flex-col"
        initial={{ opacity: 0, x: 10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.3 }}
      >
        <div className="h-2 w-12 rounded-full bg-muted-foreground/30 mb-2" />
        <div className="space-y-1.5 flex-1">
          <div className="h-2 rounded-full bg-surface-2" />
          <div className="h-2 rounded-full bg-surface-2" />
          <div className="h-2 w-2/3 rounded-full bg-surface-2" />
        </div>
        <motion.div
          className="h-5 rounded-md mt-2"
          style={{ background: "var(--primary)" }}
          initial={{ scale: 0.9 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.6 }}
        />
      </motion.div>
    </div>
  );
}

// ============================================================================
// Onboarding mockup — mobile-style step flow
// ============================================================================

function OnboardingMockup() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center gap-3">
      {/* Progress steps */}
      <div className="flex items-center gap-1.5 w-full max-w-[200px]">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="flex-1 h-1 rounded-full bg-surface-2 overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: i <= 2 ? "var(--success)" : "var(--muted)" }}
              initial={{ width: "0%" }}
              animate={{ width: i < 2 ? "100%" : i === 2 ? "60%" : "0%" }}
              transition={{ delay: 0.2 + i * 0.15, duration: 0.5 }}
            />
          </div>
        ))}
      </div>

      {/* Step card */}
      <motion.div
        className="w-full max-w-[200px] rounded-lg bg-card border border-soft p-3"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <div className="h-2 w-20 rounded-full bg-muted-foreground/30 mb-2" />
        <div className="space-y-1.5 mb-3">
          <div className="h-3 rounded-md bg-surface-2 border border-soft" />
          <div className="h-3 rounded-md bg-surface-2 border border-soft" />
          <div className="h-3 w-2/3 rounded-md bg-surface-2 border border-soft" />
        </div>
        <motion.div
          className="h-5 rounded-md"
          style={{ background: "var(--primary)" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        />
      </motion.div>

      {/* Dots */}
      <div className="flex items-center gap-1">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="h-1.5 rounded-full"
            style={{ background: i === 2 ? "var(--primary)" : "var(--muted-foreground)" }}
            initial={{ width: 6 }}
            animate={{ width: i === 2 ? 18 : 6 }}
            transition={{ delay: 0.5 + i * 0.1 }}
          />
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// List mockup — table-like
// ============================================================================

function ListMockup() {
  return (
    <div className="w-full h-full flex flex-col gap-2">
      <div className="flex items-center gap-2 mb-1">
        <div className="h-2 w-16 rounded-full bg-muted-foreground/30" />
        <div className="flex-1" />
        <div className="h-4 w-12 rounded-md bg-surface-2" />
      </div>
      {Array.from({ length: 6 }).map((_, i) => (
        <motion.div
          key={i}
          className="rounded-lg bg-card border border-soft p-2 flex items-center gap-2"
          initial={{ opacity: 0, x: -8 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 + i * 0.06 }}
        >
          <div className="h-5 w-5 rounded-full bg-surface-2 flex-shrink-0" />
          <div className="flex-1 space-y-1">
            <div className="h-1.5 rounded-full bg-muted-foreground/30 w-2/3" />
            <div className="h-1.5 rounded-full bg-surface-2 w-1/3" />
          </div>
          <div className="h-3 w-10 rounded-full" style={{ background: i % 3 === 0 ? "var(--success)" : i % 3 === 1 ? "var(--warning)" : "var(--friction)" }} />
        </motion.div>
      ))}
    </div>
  );
}

// ============================================================================
// Dashboard mockup — full KPI grid + chart
// ============================================================================

function DashboardMockup({ accent }: { accent?: string }) {
  const color = accent || "var(--success)";
  return (
    <div className="w-full h-full grid grid-cols-3 gap-2">
      {/* Left: stats column */}
      <div className="flex flex-col gap-2">
        {[
          { label: "UX Score", value: "87", trend: "+4" },
          { label: "Friction", value: "24", trend: "-3" },
          { label: "Sessions", value: "1.2K", trend: "+12%" },
        ].map((s, i) => (
          <motion.div
            key={s.label}
            className="rounded-lg bg-card border border-soft p-2"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.1 }}
          >
            <div className="text-[7px] text-muted-foreground">{s.label}</div>
            <div className="text-sm font-bold text-ink">{s.value}</div>
            <div className="text-[7px] text-success">{s.trend}</div>
          </motion.div>
        ))}
      </div>

      {/* Middle: radar */}
      <motion.div
        className="rounded-lg bg-card border border-soft p-2 flex items-center justify-center"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.4 }}
      >
        <svg viewBox="0 0 80 80" className="w-full h-full">
          {[15, 25, 35].map((r) => (
            <circle key={r} cx="40" cy="40" r={r} fill="none" stroke="var(--border)" strokeWidth="0.5" />
          ))}
          <motion.polygon
            points="40,15 60,28 58,55 40,65 22,55 20,28"
            fill={color}
            fillOpacity="0.2"
            stroke={color}
            strokeWidth="1"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7, duration: 0.6 }}
            style={{ transformOrigin: "center" }}
          />
        </svg>
      </motion.div>

      {/* Right: bar chart */}
      <motion.div
        className="rounded-lg bg-card border border-soft p-2 flex flex-col"
        initial={{ opacity: 0, x: 8 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.5 }}
      >
        <div className="h-1.5 w-12 rounded-full bg-muted-foreground/30 mb-2" />
        <div className="flex-1 flex items-end gap-1">
          {[40, 65, 50, 80, 60, 90, 70].map((h, i) => (
            <motion.div
              key={i}
              className="flex-1 rounded-t-sm"
              style={{ background: color, opacity: 0.4 + (i / 7) * 0.6 }}
              initial={{ height: 0 }}
              animate={{ height: `${h}%` }}
              transition={{ delay: 0.6 + i * 0.06, duration: 0.4, ease: "easeOut" }}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}

// ============================================================================
// Mobile mockup — phone-shaped
// ============================================================================

function MobileMockup() {
  return (
    <div className="w-full h-full flex items-center justify-center">
      <motion.div
        className="w-24 h-full rounded-2xl bg-card border-2 border-soft p-1.5 flex flex-col gap-1.5"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
      >
        {/* Status bar */}
        <div className="flex items-center justify-between px-1">
          <div className="h-1 w-4 rounded-full bg-muted-foreground/40" />
          <div className="h-1 w-1 rounded-full bg-muted-foreground/40" />
        </div>
        {/* Header */}
        <div className="flex items-center gap-1 px-1">
          <div className="h-3 w-3 rounded-full" style={{ background: "var(--primary)" }} />
          <div className="h-1.5 flex-1 rounded-full bg-muted-foreground/30" />
        </div>
        {/* Card */}
        <motion.div
          className="rounded-md p-1.5 flex-1"
          style={{ background: "linear-gradient(135deg, color-mix(in oklch, var(--primary) 15%, var(--card)), var(--card))" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <div className="h-1 w-8 rounded-full bg-muted-foreground/40 mb-1" />
          <div className="text-[6px] font-bold text-ink">87</div>
          <div className="h-0.5 w-6 rounded-full bg-success mb-1.5" />
          <div className="space-y-1">
            {[0.6, 0.4, 0.8].map((w, i) => (
              <motion.div
                key={i}
                className="h-1 rounded-full bg-muted-foreground/20"
                style={{ width: `${w * 100}%` }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 + i * 0.1 }}
              />
            ))}
          </div>
        </motion.div>
        {/* CTA */}
        <motion.div
          className="h-3 rounded-md"
          style={{ background: "var(--primary)" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        />
      </motion.div>
    </div>
  );
}
