"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { AnimatedNumber } from "@/components/common/motion";

interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  trend?: { value: number; direction: "up" | "down" | "flat"; good?: boolean };
  sublabel?: string;
  icon?: React.ReactNode;
  accent?: "default" | "success" | "warning" | "friction" | "info";
  className?: string;
  children?: React.ReactNode;
  /** When true and value is a number, animate the count-up on mount. */
  animate?: boolean;
}

const accentMap = {
  default: "",
  success: "text-success",
  warning: "text-warning",
  friction: "text-friction",
  info: "text-info",
};

export function StatCard({
  label,
  value,
  unit,
  trend,
  sublabel,
  icon,
  accent = "default",
  className,
  children,
  animate = false,
}: StatCardProps) {
  const isNumeric = typeof value === "number";
  const displayValue = animate && isNumeric
    ? <AnimatedNumber value={value as number} />
    : value;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -2, transition: { duration: 0.18 } }}
    >
      <Card className={cn("rounded-2xl border-soft shadow-soft p-4 card-hover", className)}>
        <div className="flex items-start justify-between">
          <div className="text-xs font-medium text-muted-foreground">{label}</div>
          {icon && (
            <div className={cn("flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2", accentMap[accent])}>
              {icon}
            </div>
          )}
        </div>
        <div className="mt-2 flex items-baseline gap-1">
          <span className={cn("text-2xl sm:text-3xl font-semibold tracking-tight text-ink", accentMap[accent])}>
            {displayValue}
          </span>
          {unit && <span className="text-xs text-muted-foreground">{unit}</span>}
        </div>
        <div className="mt-1 flex items-center gap-2 text-xs">
          {trend && (
            <span
              className={cn(
                "inline-flex items-center gap-0.5 font-medium",
                trend.good === undefined
                  ? trend.direction === "up"
                    ? "text-success"
                    : trend.direction === "down"
                    ? "text-friction"
                    : "text-muted-foreground"
                  : trend.good
                  ? "text-success"
                  : "text-friction"
              )}
            >
              {trend.direction === "up" ? (
                <ArrowUpRight className="h-3 w-3" />
              ) : trend.direction === "down" ? (
                <ArrowDownRight className="h-3 w-3" />
              ) : (
                <Minus className="h-3 w-3" />
              )}
              {trend.value}%
            </span>
          )}
          {sublabel && <span className="text-muted-foreground">{sublabel}</span>}
        </div>
        {children}
      </Card>
    </motion.div>
  );
}
