"use client";

import * as React from "react";
import { Bell, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import Link from "next/link";
import { NOTIFICATIONS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const dot: Record<string, string> = {
  insight: "bg-success",
  report: "bg-info",
  mention: "bg-friction",
  alert: "bg-warning",
  team: "bg-primary",
  billing: "bg-primary",
};

export function NotificationsDropdown() {
  const [items, setItems] = React.useState(NOTIFICATIONS);
  const unread = items.filter((n) => !n.read).length;

  const markAll = () => {
    setItems((prev) => prev.map((n) => ({ ...n, read: true })));
    toast.success("All notifications marked as read");
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative h-9 w-9 rounded-full hover:bg-accent/60"
          aria-label="Notifications"
        >
          <Bell className="h-4 w-4" />
          {unread > 0 && (
            <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-friction ring-2 ring-card" />
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between p-3">
          <div>
            <div className="text-sm font-semibold">Notifications</div>
            <div className="text-xs text-muted-foreground">{unread} unread</div>
          </div>
          <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={markAll}>
            <Check className="mr-1 h-3 w-3" /> Mark all
          </Button>
        </div>
        <DropdownMenuSeparator />
        <ScrollArea className="h-[320px]">
          {items.map((n) => (
            <Link
              key={n.id}
              href={n.action?.href || "#"}
              className={cn(
                "flex gap-3 px-3 py-3 hover:bg-accent/50 transition-colors border-b border-soft last:border-0",
                !n.read && "bg-accent/30"
              )}
            >
              <span className={cn("mt-1.5 h-2 w-2 flex-shrink-0 rounded-full", dot[n.type])} />
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-ink line-clamp-1">{n.title}</div>
                <div className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.description}</div>
                <div className="text-[10px] text-muted-foreground/80 mt-1">{n.timestamp}</div>
              </div>
            </Link>
          ))}
        </ScrollArea>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/notifications" className="text-center justify-center text-xs">
            View all notifications
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
