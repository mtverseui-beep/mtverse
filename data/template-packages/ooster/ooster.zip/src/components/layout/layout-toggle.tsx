"use client";

import * as React from "react";
import { Maximize2, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useLayoutStore } from "@/hooks/use-layout-mode";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export function LayoutToggle({ className }: { className?: string }) {
  const mode = useLayoutStore((s) => s.mode);
  const toggle = useLayoutStore((s) => s.toggle);
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    useLayoutStore.getState().init();
    setMounted(true);
  }, []);

  const handleToggle = () => {
    toggle();
    toast.success(mode === "boxed" ? "Switched to fullscreen mode" : "Switched to boxed mode");
  };

  return (
    <TooltipProvider delayDuration={300}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleToggle}
            className={cn("h-9 w-9 rounded-full hover:bg-accent/60", className)}
            aria-label="Toggle layout mode"
            suppressHydrationWarning
          >
            {mounted && mode === "boxed" ? <Maximize2 className="h-4 w-4" /> : <Square className="h-4 w-4" />}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-xs">
          {mode === "boxed" ? "Switch to fullscreen" : "Switch to boxed"}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
