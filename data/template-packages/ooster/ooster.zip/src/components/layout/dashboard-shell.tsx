"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Logo } from "@/components/layout/logo";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { SearchButton } from "@/components/layout/search-button";
import { NotificationsDropdown } from "@/components/layout/notifications-dropdown";
import { UserMenu } from "@/components/layout/user-menu";
import { MobileNav } from "@/components/layout/mobile-nav";
import { LayoutToggle } from "@/components/layout/layout-toggle";
import { Button } from "@/components/ui/button";
import { Plus, Menu, Bell, Search, Sun, Square } from "lucide-react";
import { PRIMARY_NAV } from "@/lib/navigation";
import { CreateProjectModal } from "@/components/modals/create-project-modal";
import { useCreateProjectModal } from "@/hooks/use-modals";
import { useLayoutStore } from "@/hooks/use-layout-mode";
import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { setOpen: setCreateOpen } = useCreateProjectModal();
  const mode = useLayoutStore((s) => s.mode);
  const initLayout = useLayoutStore((s) => s.init);
  const [mounted, setMounted] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  // Initialize layout mode from localStorage on mount
  React.useEffect(() => {
    initLayout();
    setMounted(true);
  }, [initLayout]);

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const isActive = (href: string) => {
    if (href === "/") return pathname === "/";
    return pathname === href || pathname.startsWith(href + "/");
  };

  // Use boxed as default during SSR, then switch to stored mode after mount
  const isFullscreen = mounted && mode === "fullscreen";

  return (
    <div className={cn("min-h-screen bg-shell font-sans transition-all duration-300", isFullscreen ? "p-0" : "p-1 sm:p-3 md:p-4 lg:p-6")}>
      <div
        className={cn(
          "mx-auto transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
          isFullscreen
            ? "max-w-screen-2xl bg-surface min-h-screen"
            : "max-w-[1440px] rounded-xl sm:rounded-2xl lg:rounded-3xl bg-surface shadow-pop"
        )}
      >
        {/* Sticky header */}
        <header
          className={cn(
            "sticky top-0 z-40 transition-all duration-300",
            isFullscreen ? "px-4 sm:px-6 lg:px-8" : "",
            scrolled
              ? "bg-surface/95 backdrop-blur-md shadow-soft border-b border-soft"
              : "bg-surface border-b border-transparent"
          )}
        >
          <div className={cn(isFullscreen ? "" : "px-3 sm:px-4 lg:px-6")}>
            {/* Top row: logo + nav + actions */}
            <div className="flex items-center justify-between h-14 gap-3">
              <div className="flex items-center gap-3">
                {/* Mobile nav — render placeholder during SSR to avoid hydration mismatch */}
                {mounted ? <MobileNav /> : (
                  <Button variant="ghost" size="icon" className="lg:hidden h-9 w-9 rounded-full" aria-label="Open menu">
                    <Menu className="h-5 w-5" />
                  </Button>
                )}
                <Link href="/" className="flex items-center" aria-label="Ooster home">
                  <Logo />
                </Link>
              </div>

              {/* Pill nav — desktop */}
              <nav
                className="hidden lg:flex items-center gap-0.5 flex-wrap p-1 rounded-full bg-surface-2/60 no-scrollbar"
                aria-label="Primary"
              >
                {PRIMARY_NAV.slice(0, 6).map((item) => {
                  const active = isActive(item.href);
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        "group relative inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-medium transition-all cursor-pointer",
                        active
                          ? "text-primary-foreground"
                          : "text-muted-foreground hover:text-ink hover:bg-accent/60"
                      )}
                    >
                      {active && (
                        <motion.span
                          layoutId="pill-active"
                          className="absolute inset-0 rounded-full bg-primary shadow-soft"
                          transition={{ type: "spring", stiffness: 400, damping: 32 }}
                        />
                      )}
                      <Icon className={cn("relative h-3.5 w-3.5", active ? "opacity-100" : "opacity-70 group-hover:opacity-100")} />
                      <span className="relative">{item.label}</span>
                    </Link>
                  );
                })}
              </nav>

              <div className="flex items-center gap-1 sm:gap-1.5">
                <Button
                  size="sm"
                  className="hidden md:inline-flex rounded-full h-8 px-3 text-xs gap-1"
                  onClick={() => setCreateOpen(true)}
                >
                  <Plus className="h-3.5 w-3.5" /> New project
                </Button>

                {/* Render Radix-dependent components only after mount to avoid hydration mismatch */}
                {mounted ? (
                  <>
                    <SearchButton />
                    <NotificationsDropdown />
                    <LayoutToggle className="hidden sm:inline-flex" />
                    <ThemeToggle />
                    <UserMenu />
                  </>
                ) : (
                  <>
                    {/* SSR placeholders — same dimensions, no Radix IDs */}
                    <Button variant="ghost" size="sm" className="h-9 rounded-full px-2.5" aria-label="Open command palette">
                      <Search className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="relative h-9 w-9 rounded-full" aria-label="Notifications">
                      <Bell className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="hidden sm:inline-flex h-9 w-9 rounded-full" aria-label="Toggle layout mode">
                      <Square className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full" aria-label="Toggle theme">
                      <Sun className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" className="h-9 pl-1 pr-2 rounded-full gap-1.5">
                      <Avatar className="h-7 w-7 ring-1 ring-soft">
                        <AvatarFallback>MH</AvatarFallback>
                      </Avatar>
                      <span className="hidden sm:inline text-xs font-medium">Mira</span>
                    </Button>
                  </>
                )}
              </div>
            </div>

            {/* Secondary pill nav */}
            <nav
              className="hidden md:flex items-center gap-0.5 flex-wrap pb-2 no-scrollbar overflow-x-auto"
              aria-label="Secondary"
            >
              {PRIMARY_NAV.slice(6).map((item) => {
                const active = isActive(item.href);
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "group inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-all whitespace-nowrap cursor-pointer",
                      active
                        ? "bg-primary text-primary-foreground shadow-soft"
                        : "text-muted-foreground hover:text-ink hover:bg-accent/60"
                    )}
                  >
                    <Icon className={cn("h-3.5 w-3.5", active ? "opacity-100" : "opacity-70")} />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          </div>
        </header>

        {/* Main content */}
        <main className={cn("min-h-[60vh] py-4 sm:py-6 transition-all duration-300", isFullscreen ? "px-4 sm:px-6 lg:px-8" : "px-3 sm:px-4 lg:px-6")}>
          {children}
        </main>

        {/* Footer */}
        <footer className={cn("mt-8 pt-6 border-t border-soft flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-muted-foreground transition-all duration-300", isFullscreen ? "px-4 sm:px-6 lg:px-8" : "px-3 sm:px-4 lg:px-6")}>
          <div className="flex items-center gap-2">
            <Logo size="sm" showWordmark={false} />
            <span>© 2026 Ooster Labs. Premium UX intelligence.</span>
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <Link href="/docs" className="hover:text-ink transition-colors cursor-pointer">Docs</Link>
            <Link href="/changelog" className="hover:text-ink transition-colors cursor-pointer">Changelog</Link>
            <Link href="/pricing" className="hover:text-ink transition-colors cursor-pointer">Pricing</Link>
            <Link href="/contact" className="hover:text-ink transition-colors cursor-pointer">Contact</Link>
            <span className="hidden sm:inline">v1.0.0</span>
          </div>
        </footer>
      </div>

      <CreateProjectModal />
    </div>
  );
}
