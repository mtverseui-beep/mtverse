"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";

export function SearchButton({ className }: { className?: string }) {
  const setCommandOpen = useModals((s) => s.setCommandOpen);

  // Listen for Cmd/Ctrl+K
  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        useModals.getState().setCommandOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => setCommandOpen(true)}
      className={cn(
        "h-9 rounded-full px-2.5 gap-2 text-muted-foreground hover:text-ink hover:bg-accent/60",
        className
      )}
      aria-label="Open command palette"
    >
      <Search className="h-4 w-4" />
      <span className="hidden lg:inline text-xs">Search…</span>
      <kbd className="hidden lg:inline-flex items-center gap-0.5 rounded border border-soft bg-surface px-1.5 py-0.5 text-[10px] font-mono">
        ⌘K
      </kbd>
    </Button>
  );
}
