"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ChevronsUpDown, LogOut, Settings, User, CreditCard, Users, HelpCircle, Sparkles } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuGroup,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

export function UserMenu() {
  const router = useRouter();
  const [workspace, setWorkspace] = React.useState("Halberg Studios");

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-9 pl-1 pr-2 rounded-full hover:bg-accent/60 gap-1.5">
          <Avatar className="h-7 w-7 ring-1 ring-soft">
            <AvatarImage src="https://i.pravatar.cc/80?img=12" alt="Mira Halberg" />
            <AvatarFallback>MH</AvatarFallback>
          </Avatar>
          <span className="hidden sm:inline text-xs font-medium">Mira</span>
          <ChevronsUpDown className="h-3 w-3 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64 p-0">
        <div className="flex items-center gap-3 p-3">
          <Avatar className="h-10 w-10 ring-1 ring-soft">
            <AvatarImage src="https://i.pravatar.cc/80?img=12" alt="Mira Halberg" />
            <AvatarFallback>MH</AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-medium truncate">Mira Halberg</div>
            <div className="text-xs text-muted-foreground truncate">mira@ooster.app</div>
          </div>
        </div>

        <DropdownMenuSeparator />

        <button
          className="w-full flex items-center gap-2 px-3 py-2 hover:bg-accent/50 transition-colors"
          onClick={() => toast.success(`Switched to Northwind Retail`)}
        >
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary text-primary-foreground text-xs font-semibold">HS</div>
          <div className="flex-1 text-left">
            <div className="text-xs font-medium">{workspace}</div>
            <div className="text-[10px] text-muted-foreground">Enterprise · 32 seats</div>
          </div>
          <ChevronsUpDown className="h-3 w-3 opacity-50" />
        </button>

        <DropdownMenuSeparator />

        <DropdownMenuLabel className="text-xs text-muted-foreground">Account</DropdownMenuLabel>
        <DropdownMenuGroup>
          <DropdownMenuItem asChild>
            <Link href="/settings/profile">
              <User className="mr-2 h-4 w-4" /> Profile
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/settings/workspace">
              <Settings className="mr-2 h-4 w-4" /> Workspace
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/billing">
              <CreditCard className="mr-2 h-4 w-4" /> Billing & plan
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/teams">
              <Users className="mr-2 h-4 w-4" /> Team members
            </Link>
          </DropdownMenuItem>
        </DropdownMenuGroup>

        <DropdownMenuSeparator />

        <DropdownMenuItem asChild>
          <Link href="/help">
            <HelpCircle className="mr-2 h-4 w-4" /> Help & support
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link href="/pricing">
            <Sparkles className="mr-2 h-4 w-4" /> Upgrade plan
          </Link>
        </DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuItem
          className="text-friction focus:text-friction"
          onClick={() => {
            toast.success("Signed out");
            router.push("/sign-in");
          }}
        >
          <LogOut className="mr-2 h-4 w-4" /> Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
