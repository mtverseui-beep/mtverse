import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  showWordmark?: boolean;
  size?: "sm" | "md" | "lg";
}

export function LogoMark({ className, size = "md" }: { className?: string; size?: "sm" | "md" | "lg" }) {
  const dims = size === "sm" ? "h-6 w-6" : size === "lg" ? "h-10 w-10" : "h-8 w-8";
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn(dims, className)}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="ooster-mark-grad" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop stopColor="var(--primary)" />
          <stop offset="1" stopColor="color-mix(in oklch, var(--primary) 80%, black)" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill="url(#ooster-mark-grad)" />
      <circle cx="32" cy="32" r="16" stroke="var(--card)" strokeWidth="3.5" fill="none" opacity="0.95" />
      <circle cx="32" cy="32" r="9" stroke="var(--success)" strokeWidth="2.5" fill="none" opacity="0.85" />
      <circle cx="44" cy="22" r="3.4" fill="var(--warning)" />
      <circle cx="20" cy="42" r="2.2" fill="var(--friction)" opacity="0.85" />
    </svg>
  );
}

export function Logo({ className, showWordmark = true, size = "md" }: LogoProps) {
  const textSize = size === "sm" ? "text-sm" : size === "lg" ? "text-xl" : "text-base";
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <LogoMark size={size} />
      {showWordmark && (
        <span className={cn("font-semibold tracking-tight text-ink", textSize)}>
          Ooster
        </span>
      )}
    </div>
  );
}
