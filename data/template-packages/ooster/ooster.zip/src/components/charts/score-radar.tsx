"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

interface ScoreRadarProps {
  data: { label: string; value: number; key: string }[];
  size?: number;
  className?: string;
  showLabels?: boolean;
  color?: string;
}

/**
 * A pure SVG radar chart, theme-aware via CSS variables.
 * No external deps — fast, accessible, and matches the calm Ooster aesthetic.
 */
export function ScoreRadar({
  data,
  size = 280,
  className,
  showLabels = true,
  color = "var(--success)",
}: ScoreRadarProps) {
  const cx = size / 2;
  const cy = size / 2;
  const radius = size / 2 - 32;
  const n = data.length;

  const pointFor = (i: number, r: number) => {
    const angle = (Math.PI * 2 * i) / n - Math.PI / 2;
    return { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
  };

  const labelFor = (i: number, r: number) => {
    const angle = (Math.PI * 2 * i) / n - Math.PI / 2;
    return {
      x: cx + (r + 14) * Math.cos(angle),
      y: cy + (r + 14) * Math.sin(angle),
      anchor: Math.cos(angle) > 0.2 ? "start" : Math.cos(angle) < -0.2 ? "end" : "middle",
    } as const;
  };

  const rings = [0.25, 0.5, 0.75, 1];

  const dataPoints = data.map((d, i) => pointFor(i, (d.value / 100) * radius));
  const dataPath = dataPoints.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ") + " Z";

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      className={cn("w-full h-full", className)}
      role="img"
      aria-label="UX score radar chart"
    >
      {/* Grid rings */}
      {rings.map((r) => (
        <polygon
          key={r}
          points={data.map((_, i) => {
            const p = pointFor(i, radius * r);
            return `${p.x},${p.y}`;
          }).join(" ")}
          fill="none"
          stroke="var(--border)"
          strokeWidth="1"
        />
      ))}

      {/* Axis lines */}
      {data.map((_, i) => {
        const p = pointFor(i, radius);
        return <line key={i} x1={cx} y1={cy} x2={p.x} y2={p.y} stroke="var(--border)" strokeWidth="1" />;
      })}

      {/* Data polygon */}
      <path
        d={dataPath}
        fill={color}
        fillOpacity="0.15"
        stroke={color}
        strokeWidth="2"
        strokeLinejoin="round"
      >
        <animate attributeName="opacity" from="0" to="1" dur="0.5s" fill="freeze" />
      </path>

      {/* Data points */}
      {dataPoints.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r="3.5" fill={color} stroke="var(--card)" strokeWidth="1.5" />
      ))}

      {/* Labels */}
      {showLabels &&
        data.map((d, i) => {
          const l = labelFor(i, radius);
          return (
            <g key={d.key}>
              <text
                x={l.x}
                y={l.y - 4}
                textAnchor={l.anchor}
                className="fill-muted-foreground text-[10px] font-medium"
              >
                {d.label}
              </text>
              <text
                x={l.x}
                y={l.y + 8}
                textAnchor={l.anchor}
                className="fill-ink text-[11px] font-semibold"
              >
                {d.value}
              </text>
            </g>
          );
        })}
    </svg>
  );
}
