"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

// ============================================================================
// MiniTrend — sparkline with hover dot
// ============================================================================

interface MiniTrendProps {
  data: number[];
  width?: number;
  height?: number;
  color?: string;
  className?: string;
  showArea?: boolean;
  strokeWidth?: number;
}

export function MiniTrend({
  data,
  width = 100,
  height = 28,
  color = "var(--success)",
  className,
  showArea = true,
  strokeWidth = 1.5,
}: MiniTrendProps) {
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null);
  if (!data.length) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1 || 1);
  const points = data.map((v, i) => ({ x: i * step, y: height - ((v - min) / range) * (height - 4) - 2, v }));
  const linePath = "M " + points.map((p) => `${p.x},${p.y}`).join(" L ");
  const areaPath = `${linePath} L ${width},${height} L 0,${height} Z`;

  return (
    <div className={cn("relative inline-block", className)}>
      <svg
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        className="overflow-visible cursor-crosshair"
        preserveAspectRatio="none"
        onMouseLeave={() => setHoverIdx(null)}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const x = ((e.clientX - rect.left) / rect.width) * width;
          const idx = Math.round(x / step);
          if (idx >= 0 && idx < data.length) setHoverIdx(idx);
        }}
      >
        {showArea && <path d={areaPath} fill={color} opacity={0.12} />}
        <motion.path
          d={linePath}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinejoin="round"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        />
        {hoverIdx !== null && (
          <g>
            <line
              x1={points[hoverIdx].x}
              y1={0}
              x2={points[hoverIdx].x}
              y2={height}
              stroke={color}
              strokeWidth={1}
              strokeDasharray="2 2"
              opacity={0.5}
            />
            <circle cx={points[hoverIdx].x} cy={points[hoverIdx].y} r={3} fill={color} stroke="var(--card)" strokeWidth={1.5} />
          </g>
        )}
      </svg>
      {hoverIdx !== null && (
        <div
          className="absolute -top-7 px-1.5 py-0.5 rounded-md bg-primary text-primary-foreground text-[10px] font-medium pointer-events-none shadow-pop whitespace-nowrap z-10"
          style={{ left: `${(points[hoverIdx].x / width) * 100}%`, transform: "translateX(-50%)" }}
        >
          {data[hoverIdx]}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// BarChart — with hover highlight + tooltip
// ============================================================================

interface BarChartProps {
  data: { label: string; value: number; color?: string }[];
  height?: number;
  className?: string;
  showLabels?: boolean;
  showValues?: boolean;
  formatValue?: (v: number) => string;
}

export function BarChart({ data, height = 180, className, showLabels = true, showValues = false, formatValue }: BarChartProps) {
  const [hover, setHover] = React.useState<number | null>(null);
  const max = Math.max(...data.map((d) => d.value)) || 1;
  return (
    <div className={cn("flex items-end gap-2 w-full", className)} style={{ height }}>
      {data.map((d, i) => (
        <div
          key={i}
          className="flex-1 flex flex-col items-center gap-1 min-w-0 cursor-pointer"
          onMouseEnter={() => setHover(i)}
          onMouseLeave={() => setHover(null)}
        >
          <div className="flex-1 w-full flex items-end relative">
            <motion.div
              className="w-full rounded-t-md transition-opacity"
              style={{
                background: d.color || "var(--primary)",
                minHeight: 4,
                opacity: hover === null || hover === i ? 1 : 0.45,
              }}
              initial={{ height: 0 }}
              animate={{ height: `${(d.value / max) * 100}%` }}
              transition={{ duration: 0.6, delay: i * 0.05, ease: [0.22, 1, 0.36, 1] }}
            />
            {hover === i && (
              <div className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 rounded-md bg-primary text-primary-foreground text-[10px] font-medium shadow-pop whitespace-nowrap z-10">
                {formatValue ? formatValue(d.value) : d.value}
              </div>
            )}
          </div>
          {showValues && <div className="text-[10px] font-medium text-ink">{formatValue ? formatValue(d.value) : d.value}</div>}
          {showLabels && <div className="text-[10px] text-muted-foreground truncate w-full text-center">{d.label}</div>}
        </div>
      ))}
    </div>
  );
}

// ============================================================================
// DonutChart — with hover segment expansion + center label
// ============================================================================

interface DonutChartProps {
  data: { label: string; value: number; color?: string }[];
  size?: number;
  strokeWidth?: number;
  className?: string;
  centerLabel?: string;
  centerValue?: string;
}

export function DonutChart({
  data,
  size = 140,
  strokeWidth = 16,
  className,
  centerLabel,
  centerValue,
}: DonutChartProps) {
  const [hover, setHover] = React.useState<number | null>(null);
  const radius = (size - strokeWidth) / 2;
  const cx = size / 2;
  const cy = size / 2;
  const circumference = 2 * Math.PI * radius;
  const total = data.reduce((s, d) => s + d.value, 0) || 1;

  const makeSeg = (d: { label: string; value: number; color?: string }, i: number, portion: number, offset: number) => ({
    color: d.color || `var(--chart-${(i % 6) + 1})`,
    dasharray: `${portion} ${circumference - portion}`,
    dashoffset: -offset,
    label: d.label,
    value: d.value,
    pct: Math.round((d.value / total) * 100),
  });

  const segments = data.reduce<{ items: ReturnType<typeof makeSeg>[]; offset: number }>(
    (acc, d, i) => {
      const portion = (d.value / total) * circumference;
      acc.items.push(makeSeg(d, i, portion, acc.offset));
      acc.offset += portion;
      return acc;
    },
    { items: [], offset: 0 }
  ).items;

  const active = hover !== null ? segments[hover] : null;

  return (
    <div className={cn("relative inline-flex items-center justify-center", className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle cx={cx} cy={cy} r={radius} fill="none" stroke="var(--muted)" strokeWidth={strokeWidth} />
        {segments.map((s, i) => (
          <motion.circle
            key={i}
            cx={cx}
            cy={cy}
            r={radius}
            fill="none"
            stroke={s.color}
            strokeWidth={hover === i ? strokeWidth + 4 : strokeWidth}
            strokeDasharray={s.dasharray}
            strokeDashoffset={s.dashoffset}
            initial={{ opacity: 0 }}
            animate={{ opacity: hover === null || hover === i ? 1 : 0.4 }}
            transition={{ duration: 0.2 }}
            style={{ cursor: "pointer", transition: "stroke-width 0.2s" }}
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
          />
        ))}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <span className="text-lg font-semibold text-ink">
          {active ? `${active.pct}%` : centerValue || ""}
        </span>
        <span className="text-[10px] text-muted-foreground">
          {active ? active.label : centerLabel || ""}
        </span>
      </div>
    </div>
  );
}

// ============================================================================
// LineChart — multi-series with hover crosshair + tooltip
// ============================================================================

interface LineChartProps {
  data: { label: string; values: { label: string; value: number; color?: string }[] }[];
  height?: number;
  className?: string;
  showXAxis?: boolean;
  showGrid?: boolean;
  showLegend?: boolean;
  formatValue?: (v: number) => string;
}

export function LineChart({
  data,
  height = 220,
  className,
  showXAxis = true,
  showGrid = true,
  showLegend = true,
  formatValue,
}: LineChartProps) {
  const [hoverX, setHoverX] = React.useState<number | null>(null);
  const width = 600;
  const padX = 28;
  const padY = 16;
  const innerW = width - padX * 2;
  const innerH = height - padY * 2 - (showXAxis ? 20 : 0);

  const allValues = data.flatMap((d) => d.values.map((v) => v.value));
  const max = Math.max(...allValues, 100);
  const min = Math.min(...allValues, 0);
  const range = max - min || 1;

  const seriesCount = data[0]?.values.length || 0;
  const colors = ["var(--success)", "var(--friction)", "var(--info)", "var(--warning)", "var(--chart-5)", "var(--chart-6)"];

  const xFor = (i: number) => padX + (i / (data.length - 1 || 1)) * innerW;
  const yFor = (v: number) => padY + innerH - ((v - min) / range) * innerH;

  return (
    <div className={cn("w-full", className)}>
      {showLegend && seriesCount > 1 && (
        <div className="flex flex-wrap items-center gap-3 mb-3">
          {data[0]?.values.map((v, i) => (
            <div key={i} className="flex items-center gap-1.5 text-[11px]">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: colors[i % colors.length] }} />
              <span className="text-muted-foreground">{v.label}</span>
            </div>
          ))}
        </div>
      )}
      <div className="relative">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full"
          preserveAspectRatio="none"
          onMouseLeave={() => setHoverX(null)}
          onMouseMove={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const x = ((e.clientX - rect.left) / rect.width) * width;
            // find nearest data point
            const ratio = (x - padX) / innerW;
            const idx = Math.round(ratio * (data.length - 1));
            if (idx >= 0 && idx < data.length) setHoverX(idx);
          }}
        >
          {/* Grid */}
          {showGrid && [0, 0.25, 0.5, 0.75, 1].map((g) => (
            <line key={g} x1={padX} x2={width - padX} y1={padY + g * innerH} y2={padY + g * innerH} stroke="var(--border)" strokeWidth="1" strokeDasharray="3 3" />
          ))}

          {/* Crosshair */}
          {hoverX !== null && (
            <line
              x1={xFor(hoverX)}
              x2={xFor(hoverX)}
              y1={padY}
              y2={padY + innerH}
              stroke="var(--muted-foreground)"
              strokeWidth="1"
              strokeDasharray="3 3"
              opacity={0.5}
            />
          )}

          {/* Lines */}
          {Array.from({ length: seriesCount }).map((_, sIdx) => {
            const color = colors[sIdx % colors.length];
            const pts = data.map((d, i) => `${xFor(i)},${yFor(d.values[sIdx]?.value ?? 0)}`);
            return (
              <g key={sIdx}>
                <motion.path
                  d={`M ${pts.join(" L ")}`}
                  fill="none"
                  stroke={color}
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: 1 }}
                  transition={{ duration: 1, ease: "easeInOut", delay: sIdx * 0.1 }}
                />
                {hoverX !== null && (
                  <circle
                    cx={xFor(hoverX)}
                    cy={yFor(data[hoverX].values[sIdx]?.value ?? 0)}
                    r="4"
                    fill={color}
                    stroke="var(--card)"
                    strokeWidth="2"
                  />
                )}
              </g>
            );
          })}

          {/* X axis labels */}
          {showXAxis && data.map((d, i) => {
            const x = xFor(i);
            return (
              <text key={i} x={x} y={height - 4} textAnchor="middle" className="fill-muted-foreground text-[10px]">
                {d.label}
              </text>
            );
          })}
        </svg>

        {/* Tooltip */}
        {hoverX !== null && (
          <div
            className="absolute top-2 px-2.5 py-1.5 rounded-lg bg-primary text-primary-foreground text-[10px] shadow-pop pointer-events-none z-10 min-w-[120px]"
            style={{ left: `${(xFor(hoverX) / width) * 100}%`, transform: "translateX(-50%)" }}
          >
            <div className="font-medium mb-1 opacity-90">{data[hoverX].label}</div>
            {data[hoverX].values.map((v, i) => (
              <div key={i} className="flex items-center justify-between gap-3">
                <span className="flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: colors[i % colors.length] }} />
                  {v.label}
                </span>
                <span className="font-semibold">{formatValue ? formatValue(v.value) : v.value}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// ProgressRing — animated fill
// ============================================================================

export function AnimatedRing({
  value,
  size = 80,
  strokeWidth = 6,
  color = "var(--success)",
  trackColor = "var(--muted)",
  label,
  sublabel,
  className,
}: {
  value: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  trackColor?: string;
  label?: string;
  sublabel?: string;
  className?: string;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;

  return (
    <div className={cn("relative inline-flex items-center justify-center", className)} style={{ width: size, height: size }}>
      <svg className="-rotate-90" width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={trackColor} strokeWidth={strokeWidth} />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeLinecap="round"
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-base font-semibold text-ink">{label ?? `${value}%`}</span>
        {sublabel && <span className="text-[9px] text-muted-foreground">{sublabel}</span>}
      </div>
    </div>
  );
}
