"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from "@/components/ui/command";
import { useModals } from "@/hooks/use-modals";
import { PRIMARY_NAV } from "@/lib/navigation";
import {
  PROJECTS,
  INSIGHTS,
  REPORTS,
  RESEARCH_STUDIES,
  TEAM_MEMBERS,
} from "@/lib/data";
import {
  Search,
  Plus,
  FileBarChart,
  Flame,
  Settings,
  Moon,
  Sun,
  BookOpen,
  Download,
  UserPlus,
  LayoutDashboard,
  ArrowRight,
} from "lucide-react";
import { useTheme } from "next-themes";

const RECENT_KEY = "ooster-recent-pages";

function pushRecent(path: string, label: string) {
  try {
    const raw = localStorage.getItem(RECENT_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    const next = [{ path, label, ts: Date.now() }, ...arr.filter((x: { path: string }) => x.path !== path)].slice(0, 6);
    localStorage.setItem(RECENT_KEY, JSON.stringify(next));
  } catch {}
}

function getRecent(): { path: string; label: string }[] {
  try {
    return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]");
  } catch {
    return [];
  }
}

export function CommandPalette() {
  const open = useModals((s) => s.commandOpen);
  const setOpen = useModals((s) => s.setCommandOpen);
  const setCreateOpen = useModals((s) => s.setCreateProjectOpen);
  const setReportOpen = useModals((s) => s.setGenerateReportOpen);
  const setInsightOpen = useModals((s) => s.setCreateInsightOpen);
  const { setTheme } = useTheme();
  const router = useRouter();
  const [recent, setRecent] = React.useState<{ path: string; label: string }[]>([]);

  React.useEffect(() => {
    if (open) setRecent(getRecent());
  }, [open]);

  const go = (path: string, label?: string) => {
    if (label) pushRecent(path, label);
    setOpen(false);
    router.push(path);
  };

  const run = (fn: () => void) => {
    setOpen(false);
    fn();
  };

  return (
    <CommandDialog open={open} onOpenChange={setOpen} className="max-w-2xl">
      <CommandInput placeholder="Search pages, projects, insights, reports, or run a command…" />
      <CommandList>
        <CommandEmpty>
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <Search className="h-8 w-8 text-muted-foreground/50 mb-3" />
            <p className="text-sm font-medium text-ink">No results found</p>
            <p className="text-xs text-muted-foreground mt-1">Try a different keyword or run a quick action below.</p>
          </div>
        </CommandEmpty>

        <CommandGroup heading="Quick actions">
          <CommandItem onSelect={() => run(() => setCreateOpen(true))}>
            <Plus className="mr-2 h-4 w-4" /> Create new project
            <CommandShortcut>⌘N</CommandShortcut>
          </CommandItem>
          <CommandItem onSelect={() => run(() => setReportOpen(true))}>
            <FileBarChart className="mr-2 h-4 w-4" /> Generate AI report
          </CommandItem>
          <CommandItem onSelect={() => run(() => setInsightOpen(true))}>
            <Plus className="mr-2 h-4 w-4" /> Create insight
          </CommandItem>
          <CommandItem onSelect={() => run(() => setTheme("light"))}>
            <Sun className="mr-2 h-4 w-4" /> Switch to light theme
          </CommandItem>
          <CommandItem onSelect={() => run(() => setTheme("dark"))}>
            <Moon className="mr-2 h-4 w-4" /> Switch to dark theme
          </CommandItem>
          <CommandItem onSelect={() => go("/data-export", "Data export")}>
            <Download className="mr-2 h-4 w-4" /> Export data
          </CommandItem>
          <CommandItem onSelect={() => go("/teams", "Invite team")}>
            <UserPlus className="mr-2 h-4 w-4" /> Invite team member
          </CommandItem>
          <CommandItem onSelect={() => go("/docs", "Documentation")}>
            <BookOpen className="mr-2 h-4 w-4" /> Open documentation
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        {recent.length > 0 && (
          <>
            <CommandGroup heading="Recently visited">
              {recent.map((r) => (
                <CommandItem key={r.path} onSelect={() => go(r.path, r.label)}>
                  <ArrowRight className="mr-2 h-4 w-4 opacity-50" /> {r.label}
                  <CommandShortcut className="opacity-50">{r.path}</CommandShortcut>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        <CommandGroup heading="Pages">
          <CommandItem onSelect={() => go("/", "Dashboard")}>
            <LayoutDashboard className="mr-2 h-4 w-4" /> Dashboard
          </CommandItem>
          {PRIMARY_NAV.slice(1).map((item) => {
            const Icon = item.icon;
            return (
              <CommandItem key={item.href} onSelect={() => go(item.href, item.label)}>
                <Icon className="mr-2 h-4 w-4" /> {item.label}
                {item.description && <CommandShortcut>{item.description}</CommandShortcut>}
              </CommandItem>
            );
          })}
          <CommandItem onSelect={() => go("/settings", "Settings")}>
            <Settings className="mr-2 h-4 w-4" /> Settings
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Projects">
          {PROJECTS.slice(0, 5).map((p) => (
            <CommandItem key={p.id} onSelect={() => go(`/projects/${p.slug}`, p.name)}>
              <span className="mr-2 inline-block h-2 w-2 rounded-full" style={{ background: p.thumbColor }} />
              {p.name}
              <CommandShortcut>UX {p.uxScore}</CommandShortcut>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandGroup heading="Insights">
          {INSIGHTS.slice(0, 5).map((i) => (
            <CommandItem key={i.id} onSelect={() => go(`/insights/${i.id}`, i.title)}>
              <span className={cn("mr-2 inline-block h-2 w-2 rounded-full", severityDot(i.severity))} />
              {i.title}
              <CommandShortcut>{i.projectName}</CommandShortcut>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandGroup heading="Reports">
          {REPORTS.slice(0, 5).map((r) => (
            <CommandItem key={r.id} onSelect={() => go(`/reports/${r.id}`, r.title)}>
              <FileBarChart className="mr-2 h-4 w-4 opacity-60" />
              {r.title}
              <CommandShortcut>{r.pages}p</CommandShortcut>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Research studies">
          {RESEARCH_STUDIES.slice(0, 4).map((s) => (
            <CommandItem key={s.id} onSelect={() => go(`/research/${s.id}`, s.title)}>
              <Flame className="mr-2 h-4 w-4 opacity-60" />
              {s.title}
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandGroup heading="People">
          {TEAM_MEMBERS.slice(0, 4).map((m) => (
            <CommandItem key={m.id} onSelect={() => go(`/teams/${m.id}`, m.name)}>
              <span className="mr-2 text-xs text-muted-foreground">{m.role}</span>
              {m.name}
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}

function severityDot(sev: string) {
  switch (sev) {
    case "critical":
      return "bg-friction";
    case "high":
      return "bg-warning";
    case "medium":
      return "bg-info";
    default:
      return "bg-success";
  }
}

import { cn } from "@/lib/utils";
