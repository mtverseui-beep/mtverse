"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useShareModal } from "@/hooks/use-modals";
import { toast } from "sonner";
import { Copy, Link2, Mail, MessageSquare } from "lucide-react";

export function ShareModal() {
  const { open, setOpen, url, title } = useShareModal();
  const [copied, setCopied] = React.useState(false);
  const inputRef = React.useRef<HTMLInputElement>(null);

  const fullUrl = typeof window !== "undefined" && url ? `${window.location.origin}${url}` : url;

  const copy = () => {
    if (!fullUrl) return;
    navigator.clipboard?.writeText(fullUrl);
    setCopied(true);
    toast.success("Link copied to clipboard");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[460px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 className="h-4 w-4" /> Share link
          </DialogTitle>
          <DialogDescription>
            {title ? `Anyone with this link can view "${title}".` : "Anyone with this link can view this resource."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-2">
            <Label htmlFor="share-url">Shareable URL</Label>
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                id="share-url"
                value={fullUrl}
                readOnly
                onFocus={(e) => e.currentTarget.select()}
                className="font-mono text-xs"
              />
              <Button onClick={copy} variant={copied ? "secondary" : "default"}>
                <Copy className="mr-2 h-4 w-4" /> {copied ? "Copied" : "Copy"}
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1">
            <Button variant="outline" size="sm" className="rounded-xl" onClick={() => toast.success("Opened in email")}>
              <Mail className="mr-2 h-4 w-4" /> Email
            </Button>
            <Button variant="outline" size="sm" className="rounded-xl" onClick={() => toast.success("Sent to Slack")}>
              <MessageSquare className="mr-2 h-4 w-4" /> Slack
            </Button>
            <Button variant="outline" size="sm" className="rounded-xl" onClick={() => toast.success("Sent to Notion")}>
              <MessageSquare className="mr-2 h-4 w-4" /> Notion
            </Button>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
