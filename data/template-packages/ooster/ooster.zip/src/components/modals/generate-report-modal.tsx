"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useGenerateReportModal } from "@/hooks/use-modals";
import { PROJECTS } from "@/lib/data";
import { toast } from "sonner";
import { Loader2, FileBarChart, Check } from "lucide-react";

const REPORT_TYPES = [
  { value: "executive", label: "Executive summary", desc: "1-page leadership overview" },
  { value: "audit", label: "Full UX audit", desc: "Screen-by-screen deep dive" },
  { value: "competitor", label: "Competitor benchmark", desc: "Side-by-side with 5 competitors" },
  { value: "task-flow", label: "Task flow analysis", desc: "Step-by-step friction inventory" },
  { value: "user-journey", label: "User journey map", desc: "End-to-end journey & emotion curve" },
];

const STEPS = [
  "Collecting screens & sessions…",
  "Running friction detection models…",
  "Cross-referencing with WCAG 2.1…",
  "Synthesizing insights with AI…",
  "Formatting report & executive summary…",
];

export function GenerateReportModal() {
  const { open, setOpen } = useGenerateReportModal();
  const [step, setStep] = React.useState(0);
  const [generating, setGenerating] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const [projectId, setProjectId] = React.useState(PROJECTS[0].id);
  const [reportType, setReportType] = React.useState("executive");

  const reset = () => {
    setStep(0);
    setGenerating(false);
    setDone(false);
  };

  const start = () => {
    setGenerating(true);
    setStep(0);
    const timer = setInterval(() => {
      setStep((s) => {
        if (s >= STEPS.length - 1) {
          clearInterval(timer);
          setGenerating(false);
          setDone(true);
          return s;
        }
        return s + 1;
      });
    }, 800);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setTimeout(reset, 200); }}>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileBarChart className="h-4 w-4 text-info" /> Generate AI report
          </DialogTitle>
          <DialogDescription>
            Ooster AI will analyze your latest data and produce a polished, shareable report.
          </DialogDescription>
        </DialogHeader>

        {!generating && !done && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Project</Label>
              <Select value={projectId} onValueChange={setProjectId}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PROJECTS.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Report type</Label>
              <div className="grid gap-2">
                {REPORT_TYPES.map((t) => (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => setReportType(t.value)}
                    className={`flex items-start gap-3 rounded-xl border p-3 text-left transition-colors ${
                      reportType === t.value ? "border-primary bg-accent/40" : "border-soft hover:bg-accent/30"
                    }`}
                  >
                    <div className={`mt-0.5 h-4 w-4 rounded-full border ${reportType === t.value ? "border-primary bg-primary" : "border-muted-foreground/40"}`} />
                    <div className="flex-1">
                      <div className="text-sm font-medium">{t.label}</div>
                      <div className="text-xs text-muted-foreground">{t.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5">
              <Badge variant="secondary">~2-3 min</Badge>
              <Badge variant="secondary">AI synthesized</Badge>
              <Badge variant="secondary">Exportable PDF</Badge>
            </div>
          </div>
        )}

        {generating && (
          <div className="space-y-4 py-2">
            <div className="space-y-3">
              {STEPS.map((s, i) => (
                <div key={s} className="flex items-center gap-3">
                  {i < step ? (
                    <div className="h-5 w-5 rounded-full bg-success text-success-foreground flex items-center justify-center">
                      <Check className="h-3 w-3" />
                    </div>
                  ) : i === step ? (
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  ) : (
                    <div className="h-5 w-5 rounded-full border border-soft" />
                  )}
                  <span className={`text-sm ${i <= step ? "text-ink" : "text-muted-foreground"}`}>{s}</span>
                </div>
              ))}
            </div>
            <Progress value={((step + 1) / STEPS.length) * 100} className="h-1" />
          </div>
        )}

        {done && (
          <div className="py-6 text-center space-y-3">
            <div className="mx-auto h-12 w-12 rounded-full bg-success/15 flex items-center justify-center">
              <Check className="h-6 w-6 text-success" />
            </div>
            <div className="text-sm font-medium">Report ready!</div>
            <div className="text-xs text-muted-foreground">
              Your {REPORT_TYPES.find((t) => t.value === reportType)?.label.toLowerCase()} for {PROJECTS.find((p) => p.id === projectId)?.name} is ready to view.
            </div>
          </div>
        )}

        <DialogFooter>
          {!generating && !done && (
            <>
              <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={start}>
                <FileBarChart className="mr-2 h-4 w-4" /> Generate report
              </Button>
            </>
          )}
          {done && (
            <>
              <Button variant="ghost" onClick={() => setOpen(false)}>Close</Button>
              <Button onClick={() => { setOpen(false); toast.success("Opening report…"); }}>
                View report
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
