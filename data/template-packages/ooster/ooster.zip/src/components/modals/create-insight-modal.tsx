"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useCreateInsightModal } from "@/hooks/use-modals";
import { toast } from "sonner";
import { Loader2, Lightbulb } from "lucide-react";
import { PROJECTS } from "@/lib/data";

export function CreateInsightModal() {
  const { open, setOpen } = useCreateInsightModal();
  const [submitting, setSubmitting] = React.useState(false);
  const [title, setTitle] = React.useState("");
  const [project, setProject] = React.useState(PROJECTS[0].id);
  const [severity, setSeverity] = React.useState("medium");
  const [category, setCategory] = React.useState("usability");

  const reset = () => {
    setTitle("");
    setProject(PROJECTS[0].id);
    setSeverity("medium");
    setCategory("usability");
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Insight title is required");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setOpen(false);
      toast.success(`Insight "${title}" created`, {
        description: "Triaged into your insights queue.",
      });
      reset();
    }, 900);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Lightbulb className="h-4 w-4 text-warning" /> Create new insight
          </DialogTitle>
          <DialogDescription>
            Document a UX finding with evidence and a clear recommendation.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="ins-title">Title</Label>
            <Input
              id="ins-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Address autocomplete reduces checkout drop-off"
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Project</Label>
              <Select value={project} onValueChange={setProject}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PROJECTS.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Severity</Label>
              <Select value={severity} onValueChange={setSeverity}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="usability">Usability</SelectItem>
                <SelectItem value="accessibility">Accessibility</SelectItem>
                <SelectItem value="conversion">Conversion</SelectItem>
                <SelectItem value="engagement">Engagement</SelectItem>
                <SelectItem value="friction">Friction</SelectItem>
                <SelectItem value="clarity">Clarity</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="ins-evidence">Evidence</Label>
            <Textarea
              id="ins-evidence"
              placeholder="What did you observe? Reference heatmaps, sessions, surveys…"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ins-rec">Recommendation</Label>
            <Textarea
              id="ins-rec"
              placeholder="What should the team do about it?"
              rows={2}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={submitting}>
              {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create insight
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
