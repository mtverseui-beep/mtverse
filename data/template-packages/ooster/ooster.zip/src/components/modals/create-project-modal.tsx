"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useCreateProjectModal } from "@/hooks/use-modals";
import { toast } from "sonner";
import { Sparkles, Loader2 } from "lucide-react";

const TYPES = [
  { value: "web", label: "Web app" },
  { value: "mobile", label: "Mobile app" },
  { value: "prototype", label: "Prototype" },
  { value: "design-system", label: "Design system" },
];

export function CreateProjectModal() {
  const { open, setOpen } = useCreateProjectModal();
  const [submitting, setSubmitting] = React.useState(false);
  const [name, setName] = React.useState("");
  const [type, setType] = React.useState("web");
  const [tags, setTags] = React.useState<string[]>([]);
  const [tagInput, setTagInput] = React.useState("");

  const reset = () => {
    setName("");
    setType("web");
    setTags([]);
    setTagInput("");
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Project name is required");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setOpen(false);
      toast.success(`Project "${name}" created`, {
        description: "We've started initial analysis. This usually takes ~3 minutes.",
      });
      reset();
    }, 1100);
  };

  const addTag = () => {
    const t = tagInput.trim().toLowerCase();
    if (t && !tags.includes(t)) setTags([...tags, t]);
    setTagInput("");
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-success" /> Create new project
          </DialogTitle>
          <DialogDescription>
            Add a new project to your workspace. Ooster will analyze screens, generate insights, and seed your first report automatically.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="proj-name">Project name</Label>
            <Input
              id="proj-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Atlas Onboarding"
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="proj-type">Project type</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger id="proj-type"><SelectValue /></SelectTrigger>
              <SelectContent>
                {TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="proj-desc">Description (optional)</Label>
            <Textarea
              id="proj-desc"
              placeholder="One-line summary of what the project is and what you're testing…"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="proj-tag">Tags</Label>
            <div className="flex gap-2">
              <Input
                id="proj-tag"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") { e.preventDefault(); addTag(); }
                }}
                placeholder="Type a tag and press Enter"
              />
              <Button type="button" variant="secondary" onClick={addTag}>Add</Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {tags.map((t) => (
                  <Badge key={t} variant="secondary" className="cursor-pointer" onClick={() => setTags(tags.filter((x) => x !== t))}>
                    {t} ×
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={submitting}>
              {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create project
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
