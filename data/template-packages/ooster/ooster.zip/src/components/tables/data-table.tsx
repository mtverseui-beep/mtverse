"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, ChevronsUpDown, Search, Inbox } from "lucide-react";

export interface Column<T> {
  key: string;
  header: string;
  cell: (row: T) => React.ReactNode;
  sortable?: boolean;
  sortAccessor?: (row: T) => string | number;
  width?: string;
  className?: string;
  hideOnMobile?: boolean;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  searchable?: boolean;
  searchPlaceholder?: string;
  searchKeys?: (keyof T)[];
  pageSize?: number;
  emptyTitle?: string;
  emptyDescription?: string;
  onRowClick?: (row: T) => void;
  className?: string;
  toolbar?: React.ReactNode;
  getRowId: (row: T) => string;
}

export function DataTable<T>({
  data,
  columns,
  searchable,
  searchPlaceholder = "Search…",
  searchKeys,
  pageSize = 10,
  emptyTitle = "No results found",
  emptyDescription = "Try adjusting your search or filters.",
  onRowClick,
  className,
  toolbar,
  getRowId,
}: DataTableProps<T>) {
  const [search, setSearch] = React.useState("");
  const [page, setPage] = React.useState(1);
  const [sortKey, setSortKey] = React.useState<string | null>(null);
  const [sortDir, setSortDir] = React.useState<"asc" | "desc">("asc");

  const filtered = React.useMemo(() => {
    if (!search) return data;
    const q = search.toLowerCase();
    return data.filter((row) => {
      const keys = searchKeys || (Object.keys(row as any) as (keyof T)[]);
      return keys.some((k) => String((row as any)[k] ?? "").toLowerCase().includes(q));
    });
  }, [data, search, searchKeys]);

  const sorted = React.useMemo(() => {
    if (!sortKey) return filtered;
    const col = columns.find((c) => c.key === sortKey);
    if (!col?.sortAccessor) return filtered;
    const arr = [...filtered].sort((a, b) => {
      const av = col.sortAccessor!(a);
      const bv = col.sortAccessor!(b);
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return arr;
  }, [filtered, sortKey, sortDir, columns]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const current = Math.min(page, totalPages);
  const paged = sorted.slice((current - 1) * pageSize, current * pageSize);

  const toggleSort = (col: Column<T>) => {
    if (!col.sortable) return;
    if (sortKey === col.key) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(col.key);
      setSortDir("asc");
    }
  };

  return (
    <Card className={cn("rounded-2xl border-soft shadow-soft overflow-hidden", className)}>
      {(searchable || toolbar) && (
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 p-3 border-b border-soft">
          {searchable && (
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                placeholder={searchPlaceholder}
                className="pl-8 h-9 text-xs"
              />
            </div>
          )}
          {toolbar && <div className="sm:ml-auto">{toolbar}</div>}
        </div>
      )}

      {/* Desktop table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-soft">
              {columns.map((c) => (
                <th
                  key={c.key}
                  className={cn(
                    "text-left font-medium text-muted-foreground px-3 py-2.5",
                    c.sortable && "cursor-pointer hover:text-ink",
                    c.className
                  )}
                  style={{ width: c.width }}
                  onClick={() => toggleSort(c)}
                >
                  <div className="flex items-center gap-1">
                    {c.header}
                    {c.sortable && <ChevronsUpDown className="h-3 w-3 opacity-50" />}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {paged.map((row) => (
              <tr
                key={getRowId(row)}
                onClick={() => onRowClick?.(row)}
                className={cn(
                  "border-b border-soft last:border-0 transition-colors",
                  onRowClick && "cursor-pointer hover:bg-accent/30"
                )}
              >
                {columns.map((c) => (
                  <td key={c.key} className={cn("px-3 py-2.5 text-ink", c.className)}>
                    {c.cell(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="md:hidden divide-y divide-border">
        {paged.map((row) => (
          <div
            key={getRowId(row)}
            onClick={() => onRowClick?.(row)}
            className={cn("p-3 space-y-1", onRowClick && "cursor-pointer hover:bg-accent/30")}
          >
            {columns.filter((c) => !c.hideOnMobile).map((c) => (
              <div key={c.key} className="flex items-center justify-between gap-2">
                <span className="text-[10px] text-muted-foreground">{c.header}</span>
                <span className="text-xs text-ink text-right">{c.cell(row)}</span>
              </div>
            ))}
          </div>
        ))}
      </div>

      {paged.length === 0 && (
        <div className="p-10 flex flex-col items-center text-center">
          <div className="h-12 w-12 rounded-2xl bg-surface-2 flex items-center justify-center text-muted-foreground mb-3">
            <Inbox className="h-5 w-5" />
          </div>
          <div className="text-sm font-medium text-ink">{emptyTitle}</div>
          <div className="text-xs text-muted-foreground mt-1 max-w-sm">{emptyDescription}</div>
        </div>
      )}

      {sorted.length > pageSize && (
        <div className="flex items-center justify-between gap-2 p-3 border-t border-soft">
          <div className="text-xs text-muted-foreground">
            Showing {(current - 1) * pageSize + 1}–{Math.min(current * pageSize, sorted.length)} of {sorted.length}
          </div>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="sm" className="h-7 w-7 p-0" disabled={current === 1} onClick={() => setPage(current - 1)}>
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            <span className="text-xs text-muted-foreground px-2">{current} / {totalPages}</span>
            <Button variant="outline" size="sm" className="h-7 w-7 p-0" disabled={current === totalPages} onClick={() => setPage(current + 1)}>
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
}
