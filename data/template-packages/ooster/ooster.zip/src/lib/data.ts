// ============================================================================
// Ooster — UX Analytics mock data layer
// All routes consume these typed datasets. Swap with real API later.
// ============================================================================

export type Trend = "up" | "down" | "flat";

export interface UxScoreBreakdown {
  usability: number;
  accessibility: number;
  conversion: number;
  engagement: number;
  cognitiveLoad: number;
  clarity: number;
  consistency: number;
  friction: number;
}

export interface Project {
  id: string;
  slug: string;
  name: string;
  description: string;
  status: "active" | "paused" | "archived" | "draft";
  type: "web" | "mobile" | "prototype" | "design-system";
  uxScore: number;
  frictionScore: number;
  accessibilityScore: number;
  conversionScore: number;
  engagementScore: number;
  cognitiveLoadScore: number;
  taskSuccessRate: number;
  dropOffRisk: number;
  screenCount: number;
  issueCount: number;
  insightCount: number;
  reportCount: number;
  tags: string[];
  owner: { name: string; avatar: string; role: string };
  members: { name: string; avatar: string; role: string }[];
  lastAnalyzed: string;
  updatedAt: string;
  createdAt: string;
  thumbColor: string;
  thumbPattern: "rings" | "grid" | "wave" | "blob";
}

export interface Insight {
  id: string;
  title: string;
  summary: string;
  severity: "critical" | "high" | "medium" | "low";
  category: "usability" | "accessibility" | "conversion" | "engagement" | "friction" | "clarity" | "cognitive-load";
  impact: number;
  confidence: number;
  status: "new" | "triaging" | "in-progress" | "resolved" | "wontfix";
  affectedScreens: number;
  affectedUsers: number;
  projectId: string;
  projectName: string;
  owner: { name: string; avatar: string };
  recommendation: string;
  evidence: string[];
  createdAt: string;
}

export interface Report {
  id: string;
  title: string;
  type: "competitor" | "task-flow" | "user-journey" | "executive" | "audit" | "benchmark";
  status: "ready" | "generating" | "scheduled" | "draft";
  summary: string;
  uxScore: number;
  pages: number;
  duration: string;
  project: string;
  createdBy: { name: string; avatar: string };
  createdAt: string;
  shared: boolean;
  tags: string[];
}

export interface Heatmap {
  id: string;
  screen: string;
  projectId: string;
  projectName: string;
  type: "click" | "scroll" | "attention" | "rage" | "dead";
  sessions: number;
  avgTime: string;
  topHotspot: { x: number; y: number; intensity: number; label: string };
  coldZones: number;
  dropOffAreas: number;
  device: "desktop" | "mobile" | "tablet";
  updatedAt: string;
}

export interface SessionReplay {
  id: string;
  user: string;
  avatar: string;
  device: "desktop" | "mobile" | "tablet";
  browser: string;
  duration: string;
  events: number;
  rageClicks: number;
  deadClicks: number;
  errors: number;
  tags: string[];
  outcome: "completed" | "dropped" | "rage" | "error";
  segments: string[];
  startedAt: string;
  project: string;
}

export interface Journey {
  id: string;
  name: string;
  persona: string;
  steps: JourneyStep[];
  completionRate: number;
  avgTime: string;
  frictionPoints: number;
  dropOff: number;
  project: string;
  status: "active" | "archived";
  updatedAt: string;
}

export interface JourneyStep {
  id: string;
  name: string;
  description: string;
  users: number;
  conversion: number;
  avgTime: string;
  friction: "low" | "medium" | "high";
  dropOff: number;
}

export interface FunnelStep {
  id: string;
  name: string;
  users: number;
  conversion: number;
  dropOff: number;
  avgTime: string;
}

export interface ResearchStudy {
  id: string;
  title: string;
  type: "interview" | "survey" | "usability-test" | "diary-study" | "card-sort" | "tree-test";
  status: "planning" | "recruiting" | "in-progress" | "analyzing" | "completed" | "archived";
  method: string;
  participants: number;
  targetParticipants: number;
  duration: string;
  owner: { name: string; avatar: string };
  project: string;
  tags: string[];
  findings: number;
  startDate: string;
  endDate: string;
}

export interface Persona {
  id: string;
  name: string;
  role: string;
  avatar: string;
  age: number;
  goals: string[];
  frustrations: string[];
  behaviors: string[];
  devices: string[];
  segment: string;
  quote: string;
}

export interface TeamMember {
  id: string;
  name: string;
  avatar: string;
  email: string;
  role: "Owner" | "Admin" | "Researcher" | "Designer" | "PM" | "Viewer";
  status: "active" | "invited" | "suspended";
  lastActive: string;
  projects: number;
  insights: number;
  twoFactor: boolean;
}

export interface Customer {
  id: string;
  name: string;
  avatar: string;
  company: string;
  plan: "Free" | "Pro" | "Team" | "Enterprise";
  mrr: number;
  seats: number;
  status: "active" | "trialing" | "churned";
  joinedAt: string;
  projects: number;
  contact: string;
}

export interface Issue {
  id: string;
  title: string;
  severity: "critical" | "high" | "medium" | "low";
  type: "bug" | "ux" | "accessibility" | "performance" | "content";
  status: "open" | "in-progress" | "resolved" | "wontfix";
  project: string;
  screen: string;
  assignee: { name: string; avatar: string } | null;
  reporter: { name: string; avatar: string };
  createdAt: string;
  updatedAt: string;
  comments: number;
  reactions: number;
}

export interface AuditLog {
  id: string;
  actor: string;
  avatar: string;
  action: string;
  target: string;
  category: "auth" | "project" | "report" | "team" | "billing" | "integration" | "data";
  ip: string;
  timestamp: string;
}

export interface ApiKey {
  id: string;
  name: string;
  prefix: string;
  scopes: string[];
  lastUsed: string;
  createdAt: string;
  createdBy: string;
  status: "active" | "revoked";
}

export interface Integration {
  id: string;
  name: string;
  description: string;
  category: "analytics" | "design" | "project-management" | "communication" | "feedback" | "auth";
  icon: string;
  connected: boolean;
  connectedAt?: string;
  status: "connected" | "available" | "coming-soon";
}

export interface Invoice {
  id: string;
  number: string;
  customer: string;
  amount: number;
  status: "paid" | "pending" | "failed" | "refunded";
  date: string;
  plan: string;
  method: string;
}

export interface Survey {
  id: string;
  title: string;
  status: "draft" | "live" | "closed" | "analyzing";
  questions: number;
  responses: number;
  completionRate: number;
  avgTime: string;
  project: string;
  owner: { name: string; avatar: string };
  createdAt: string;
  closesAt: string;
}

export interface Experiment {
  id: string;
  name: string;
  type: "ab-test" | "multivariate" | "split-url" | "prototype";
  status: "draft" | "running" | "completed" | "paused";
  hypothesis: string;
  variants: { name: string; visitors: number; conversion: number; confidence: number }[];
  primaryMetric: string;
  startDate: string;
  endDate: string;
  project: string;
  significance: number;
}

export interface Notification {
  id: string;
  title: string;
  description: string;
  type: "insight" | "report" | "mention" | "alert" | "team" | "billing";
  read: boolean;
  timestamp: string;
  action?: { label: string; href: string };
}

// ============================================================================
// Helpers
// ============================================================================

const av = (seed: number | string, w = 80, h = 80) => `https://i.pravatar.cc/${w}?img=${seed}`;

// ============================================================================
// Projects
// ============================================================================

export const PROJECTS: Project[] = [
  {
    id: "p-001",
    slug: "atlas-onboarding",
    name: "Atlas Onboarding",
    description: "Mobile-first onboarding flow for the Atlas fintech app — KYC, wallet setup, and first transfer.",
    status: "active",
    type: "mobile",
    uxScore: 87,
    frictionScore: 24,
    accessibilityScore: 92,
    conversionScore: 78,
    engagementScore: 81,
    cognitiveLoadScore: 64,
    taskSuccessRate: 91,
    dropOffRisk: 18,
    screenCount: 24,
    issueCount: 14,
    insightCount: 23,
    reportCount: 8,
    tags: ["fintech", "mobile", "onboarding"],
    owner: { name: "Mira Halberg", avatar: av(12), role: "Lead Researcher" },
    members: [
      { name: "Mira Halberg", avatar: av(12), role: "Lead Researcher" },
      { name: "Theo Park", avatar: av(13), role: "Product Designer" },
      { name: "Lena Ortiz", avatar: av(45), role: "PM" },
      { name: "Idris Khoury", avatar: av(33), role: "Engineer" },
    ],
    lastAnalyzed: "2026-06-30",
    updatedAt: "2026-07-01",
    createdAt: "2026-03-12",
    thumbColor: "var(--success)",
    thumbPattern: "rings",
  },
  {
    id: "p-002",
    slug: "northwind-checkout",
    name: "Northwind Checkout",
    description: "Redesigned e-commerce checkout for Northwind — guest cart, express pay, and address autocomplete.",
    status: "active",
    type: "web",
    uxScore: 72,
    frictionScore: 41,
    accessibilityScore: 84,
    conversionScore: 69,
    engagementScore: 73,
    cognitiveLoadScore: 58,
    taskSuccessRate: 76,
    dropOffRisk: 34,
    screenCount: 18,
    issueCount: 26,
    insightCount: 31,
    reportCount: 5,
    tags: ["e-commerce", "checkout", "web"],
    owner: { name: "Theo Park", avatar: av(13), role: "Product Designer" },
    members: [
      { name: "Theo Park", avatar: av(13), role: "Product Designer" },
      { name: "Mira Halberg", avatar: av(12), role: "Lead Researcher" },
      { name: "Sana Iqbal", avatar: av(20), role: "CRO Specialist" },
    ],
    lastAnalyzed: "2026-06-29",
    updatedAt: "2026-07-01",
    createdAt: "2026-02-22",
    thumbColor: "var(--warning)",
    thumbPattern: "grid",
  },
  {
    id: "p-003",
    slug: "helix-prototype",
    name: "Helix Prototype",
    description: "Next-gen analytics dashboard prototype for Helix Health — tested with 14 clinicians.",
    status: "active",
    type: "prototype",
    uxScore: 81,
    frictionScore: 32,
    accessibilityScore: 88,
    conversionScore: 71,
    engagementScore: 84,
    cognitiveLoadScore: 69,
    taskSuccessRate: 83,
    dropOffRisk: 22,
    screenCount: 12,
    issueCount: 9,
    insightCount: 17,
    reportCount: 4,
    tags: ["healthcare", "prototype", "analytics"],
    owner: { name: "Lena Ortiz", avatar: av(45), role: "PM" },
    members: [
      { name: "Lena Ortiz", avatar: av(45), role: "PM" },
      { name: "Idris Khoury", avatar: av(33), role: "Engineer" },
      { name: "Aria Mendez", avatar: av(48), role: "UX Researcher" },
    ],
    lastAnalyzed: "2026-06-28",
    updatedAt: "2026-06-30",
    createdAt: "2026-04-05",
    thumbColor: "var(--info)",
    thumbPattern: "wave",
  },
  {
    id: "p-004",
    slug: "riverside-design-system",
    name: "Riverside Design System",
    description: "Component library audit & usability benchmarking for Riverside's design system.",
    status: "paused",
    type: "design-system",
    uxScore: 90,
    frictionScore: 14,
    accessibilityScore: 95,
    conversionScore: 82,
    engagementScore: 86,
    cognitiveLoadScore: 71,
    taskSuccessRate: 94,
    dropOffRisk: 9,
    screenCount: 56,
    issueCount: 7,
    insightCount: 12,
    reportCount: 6,
    tags: ["design-system", "components", "audit"],
    owner: { name: "Aria Mendez", avatar: av(48), role: "UX Researcher" },
    members: [
      { name: "Aria Mendez", avatar: av(48), role: "UX Researcher" },
      { name: "Mira Halberg", avatar: av(12), role: "Lead Researcher" },
    ],
    lastAnalyzed: "2026-06-15",
    updatedAt: "2026-06-22",
    createdAt: "2026-01-18",
    thumbColor: "var(--chart-5)",
    thumbPattern: "blob",
  },
  {
    id: "p-005",
    slug: "cadence-mobile",
    name: "Cadence Mobile",
    description: "Habit-tracking mobile app — onboarding, streaks, and notification flows.",
    status: "active",
    type: "mobile",
    uxScore: 76,
    frictionScore: 36,
    accessibilityScore: 80,
    conversionScore: 74,
    engagementScore: 88,
    cognitiveLoadScore: 62,
    taskSuccessRate: 79,
    dropOffRisk: 28,
    screenCount: 32,
    issueCount: 19,
    insightCount: 24,
    reportCount: 3,
    tags: ["mobile", "wellness", "engagement"],
    owner: { name: "Idris Khoury", avatar: av(33), role: "Engineer" },
    members: [
      { name: "Idris Khoury", avatar: av(33), role: "Engineer" },
      { name: "Theo Park", avatar: av(13), role: "Product Designer" },
      { name: "Sana Iqbal", avatar: av(20), role: "CRO Specialist" },
    ],
    lastAnalyzed: "2026-06-30",
    updatedAt: "2026-07-01",
    createdAt: "2026-05-02",
    thumbColor: "var(--chart-6)",
    thumbPattern: "rings",
  },
  {
    id: "p-006",
    slug: "voyage-booking",
    name: "Voyage Booking",
    description: "Travel booking experience — search, itinerary, payment, and post-trip feedback.",
    status: "draft",
    type: "web",
    uxScore: 68,
    frictionScore: 48,
    accessibilityScore: 76,
    conversionScore: 64,
    engagementScore: 70,
    cognitiveLoadScore: 55,
    taskSuccessRate: 71,
    dropOffRisk: 41,
    screenCount: 22,
    issueCount: 33,
    insightCount: 18,
    reportCount: 2,
    tags: ["travel", "web", "booking"],
    owner: { name: "Sana Iqbal", avatar: av(20), role: "CRO Specialist" },
    members: [
      { name: "Sana Iqbal", avatar: av(20), role: "CRO Specialist" },
      { name: "Lena Ortiz", avatar: av(45), role: "PM" },
    ],
    lastAnalyzed: "2026-06-25",
    updatedAt: "2026-06-28",
    createdAt: "2026-06-10",
    thumbColor: "var(--friction)",
    thumbPattern: "grid",
  },
];

// ============================================================================
// Insights
// ============================================================================

export const INSIGHTS: Insight[] = [
  {
    id: "i-001",
    title: "Address autocomplete reduces checkout drop-off by 23%",
    summary:
      "Users who trigger the address autocomplete suggestion complete checkout 23% more often than those who type manually. The friction is concentrated in the manual zip-code entry step.",
    severity: "high",
    category: "conversion",
    impact: 87,
    confidence: 92,
    status: "in-progress",
    affectedScreens: 4,
    affectedUsers: 4280,
    projectId: "p-002",
    projectName: "Northwind Checkout",
    owner: { name: "Sana Iqbal", avatar: av(20) },
    recommendation:
      "Default to autocomplete for all address fields. Add a clear 'enter manually' fallback below. Re-test with 12 users before full rollout.",
    evidence: [
      "Heatmap shows 68% of users abandon at zip-code field on mobile",
      "Session replays reveal repeated delete-retype cycles in address line 2",
      "A/B prototype with autocomplete lifted completion to 91% in pilot",
    ],
    createdAt: "2026-06-28",
  },
  {
    id: "i-002",
    title: "KYC step 3 creates cognitive overload on small screens",
    summary:
      "The document upload screen asks for ID type, country, and file in a single dense form. 41% of mobile users pause for >12s before action.",
    severity: "critical",
    category: "cognitive-load",
    impact: 94,
    confidence: 88,
    status: "new",
    affectedScreens: 1,
    affectedUsers: 2140,
    projectId: "p-001",
    projectName: "Atlas Onboarding",
    owner: { name: "Mira Halberg", avatar: av(12) },
    recommendation:
      "Split into 3 progressive steps. Use camera-first capture with auto-cropping. Reduce visible form fields to one per step.",
    evidence: [
      "Rage clicks on document-type selector spike on screens < 414px",
      "Eye-tracking study shows split attention between ID type and file input",
      "Avg time on step 3 is 38s vs 14s industry benchmark",
    ],
    createdAt: "2026-07-01",
  },
  {
    id: "i-003",
    title: "Color contrast below WCAG AA on primary action buttons",
    summary:
      "The 'Continue' button uses a 3.8:1 ratio against its background. Fails WCAG AA for normal text. Affects keyboard-only users most.",
    severity: "high",
    category: "accessibility",
    impact: 76,
    confidence: 100,
    status: "triaging",
    affectedScreens: 12,
    affectedUsers: 0,
    projectId: "p-004",
    projectName: "Riverside Design System",
    owner: { name: "Aria Mendez", avatar: av(48) },
    recommendation:
      "Darken primary token from oklch(0.62 0.13 160) to oklch(0.55 0.13 160). Update in token file — propagates to all components.",
    evidence: [
      "Automated axe-core scan flags 47 button instances",
      "Manual review confirms 3.8:1 ratio on 12 screens",
      "Keyboard nav testing shows focus state also fails",
    ],
    createdAt: "2026-06-26",
  },
  {
    id: "i-004",
    title: "Empty state on insights list confuses new PMs",
    summary:
      "First-time PMs land on Insights with no data and see a generic 'No results' message. 38% leave within 8s without action.",
    severity: "medium",
    category: "clarity",
    impact: 54,
    confidence: 81,
    status: "in-progress",
    affectedScreens: 1,
    affectedUsers: 312,
    projectId: "p-003",
    projectName: "Helix Prototype",
    owner: { name: "Lena Ortiz", avatar: av(45) },
    recommendation:
      "Replace with onboarding empty state — sample insights, a 'Generate first report' CTA, and a 30s setup video.",
    evidence: [
      "Session replay shows 38% bounce in <8s on empty insights",
      "5/5 usability test participants asked 'where do I start?'",
      "Help center search volume for 'no insights' up 4x after launch",
    ],
    createdAt: "2026-06-22",
  },
  {
    id: "i-005",
    title: "Notification permission prompt appears too early in onboarding",
    summary:
      "Push permission prompt fires on screen 2 of onboarding. 71% deny. Grant rate would lift to ~48% if moved to post-first-action.",
    severity: "high",
    category: "engagement",
    impact: 82,
    confidence: 87,
    status: "new",
    affectedScreens: 1,
    affectedUsers: 1820,
    projectId: "p-005",
    projectName: "Cadence Mobile",
    owner: { name: "Idris Khoury", avatar: av(33) },
    recommendation:
      "Move permission prompt to after first habit completion. Add a pre-prompt explaining value ('Get a gentle nudge at your chosen time').",
    evidence: [
      "71% deny rate on current placement vs 48% grant after first habit",
      "Qualitative interviews cite 'too early, don't know what I'd get'",
      "Benchmark data: 31% grant rate when prompted pre-value vs 52% post-value",
    ],
    createdAt: "2026-06-30",
  },
  {
    id: "i-006",
    title: "Date picker keyboard inaccessible on booking flow",
    summary:
      "Calendar widget traps focus and prevents tab navigation. Screen reader announces 'group' with no date context.",
    severity: "critical",
    category: "accessibility",
    impact: 71,
    confidence: 100,
    status: "in-progress",
    affectedScreens: 3,
    affectedUsers: 0,
    projectId: "p-006",
    projectName: "Voyage Booking",
    owner: { name: "Aria Mendez", avatar: av(48) },
    recommendation:
      "Replace custom date picker with Radix Popover + calendar grid. Add aria-label per cell and arrow-key navigation.",
    evidence: [
      "Manual screen reader test: dates not announced",
      "Keyboard test: tab key exits calendar without selection",
      "WCAG 2.1 SC 2.1.1 violation confirmed",
    ],
    createdAt: "2026-06-27",
  },
  {
    id: "i-007",
    title: "Search results lack filter affordance on mobile",
    summary:
      "Mobile users can't find the filter button (hidden behind an unclear icon). 44% scroll through 5+ pages of results instead.",
    severity: "medium",
    category: "usability",
    impact: 61,
    confidence: 79,
    status: "resolved",
    affectedScreens: 2,
    affectedUsers: 940,
    projectId: "p-006",
    projectName: "Voyage Booking",
    owner: { name: "Sana Iqbal", avatar: av(20) },
    recommendation:
      "Use a labeled 'Filters' chip with active count badge. Pin to top of results on mobile. Test in next usability round.",
    evidence: [
      "Heatmap: 44% of users scroll past page 5 with no filter applied",
      "Usability test: 7/8 participants didn't recognize filter icon",
      "Post-fix A/B: filter usage up 3.2x, time-to-result down 41%",
    ],
    createdAt: "2026-06-18",
  },
  {
    id: "i-008",
    title: "First-transfer flow has 6 steps — reduce to 4",
    summary:
      "After wallet setup, the first transfer requires 6 screens. Industry benchmark is 4. Drop-off compounds at step 4.",
    severity: "high",
    category: "friction",
    impact: 84,
    confidence: 90,
    status: "new",
    affectedScreens: 6,
    affectedUsers: 3120,
    projectId: "p-001",
    projectName: "Atlas Onboarding",
    owner: { name: "Mira Halberg", avatar: av(12) },
    recommendation:
      "Merge 'review' and 'confirm' into a single screen with inline confirmation. Auto-fill recipient from contacts when possible.",
    evidence: [
      "Funnel: 34% drop-off between step 4 and 5",
      "Session replay: users hesitate 22s on review screen",
      "Competitor benchmark: 4-step flow is industry standard",
    ],
    createdAt: "2026-07-01",
  },
];

// ============================================================================
// Reports
// ============================================================================

export const REPORTS: Report[] = [
  {
    id: "r-001",
    title: "Atlas Onboarding — Q2 UX Audit",
    type: "audit",
    status: "ready",
    summary: "Comprehensive audit across 24 screens. 14 active issues, 23 prioritized insights, 4 critical frictions.",
    uxScore: 87,
    pages: 32,
    duration: "8 min read",
    project: "Atlas Onboarding",
    createdBy: { name: "Mira Halberg", avatar: av(12) },
    createdAt: "2026-06-30",
    shared: true,
    tags: ["audit", "mobile", "fintech"],
  },
  {
    id: "r-002",
    title: "Northwind Checkout — Competitor Benchmark",
    type: "competitor",
    status: "ready",
    summary: "Benchmarked against 5 competitors. Northwind trails on mobile checkout speed by 12s on average.",
    uxScore: 72,
    pages: 18,
    duration: "5 min read",
    project: "Northwind Checkout",
    createdBy: { name: "Sana Iqbal", avatar: av(20) },
    createdAt: "2026-06-29",
    shared: false,
    tags: ["benchmark", "e-commerce"],
  },
  {
    id: "r-003",
    title: "Helix Prototype — Task Flow Analysis",
    type: "task-flow",
    status: "ready",
    summary: "3 core task flows analyzed. Clinician task success rate improved from 67% to 83% after redesign.",
    uxScore: 81,
    pages: 14,
    duration: "4 min read",
    project: "Helix Prototype",
    createdBy: { name: "Lena Ortiz", avatar: av(45) },
    createdAt: "2026-06-28",
    shared: true,
    tags: ["task-flow", "healthcare"],
  },
  {
    id: "r-004",
    title: "Riverside Design System — Accessibility Audit",
    type: "audit",
    status: "ready",
    summary: "56 components audited against WCAG 2.1 AA. 7 critical issues, all in button & form components.",
    uxScore: 90,
    pages: 24,
    duration: "6 min read",
    project: "Riverside Design System",
    createdBy: { name: "Aria Mendez", avatar: av(48) },
    createdAt: "2026-06-22",
    shared: true,
    tags: ["accessibility", "design-system"],
  },
  {
    id: "r-005",
    title: "Cadence Mobile — User Journey Map",
    type: "user-journey",
    status: "ready",
    summary: "End-to-end journey from install to 7-day retention. Identified 3 emotional valleys and 2 peaks.",
    uxScore: 76,
    pages: 16,
    duration: "5 min read",
    project: "Cadence Mobile",
    createdBy: { name: "Idris Khoury", avatar: av(33) },
    createdAt: "2026-06-30",
    shared: false,
    tags: ["journey", "engagement"],
  },
  {
    id: "r-006",
    title: "Voyage Booking — Executive Summary",
    type: "executive",
    status: "generating",
    summary: "Generating executive overview of UX health, key risks, and prioritized roadmap for leadership.",
    uxScore: 68,
    pages: 8,
    duration: "3 min read",
    project: "Voyage Booking",
    createdBy: { name: "Sana Iqbal", avatar: av(20) },
    createdAt: "2026-07-01",
    shared: false,
    tags: ["executive", "roadmap"],
  },
  {
    id: "r-007",
    title: "Atlas Onboarding — Q1 Baseline Report",
    type: "audit",
    status: "ready",
    summary: "Baseline UX score and friction inventory before redesign work began. Used as pre-redesign reference.",
    uxScore: 64,
    pages: 22,
    duration: "6 min read",
    project: "Atlas Onboarding",
    createdBy: { name: "Mira Halberg", avatar: av(12) },
    createdAt: "2026-03-15",
    shared: true,
    tags: ["baseline", "audit"],
  },
];

// ============================================================================
// Heatmaps
// ============================================================================

export const HEATMAPS: Heatmap[] = [
  { id: "h-001", screen: "Onboarding — Step 3", projectId: "p-001", projectName: "Atlas Onboarding", type: "click", sessions: 1240, avgTime: "38s", topHotspot: { x: 62, y: 41, intensity: 92, label: "Upload button" }, coldZones: 3, dropOffAreas: 2, device: "mobile", updatedAt: "2026-07-01" },
  { id: "h-002", screen: "Checkout — Payment", projectId: "p-002", projectName: "Northwind Checkout", type: "scroll", sessions: 980, avgTime: "22s", topHotspot: { x: 48, y: 65, intensity: 78, label: "CVV field" }, coldZones: 5, dropOffAreas: 4, device: "desktop", updatedAt: "2026-06-30" },
  { id: "h-003", screen: "Dashboard — Home", projectId: "p-003", projectName: "Helix Prototype", type: "attention", sessions: 540, avgTime: "47s", topHotspot: { x: 32, y: 22, intensity: 88, label: "Hero chart" }, coldZones: 2, dropOffAreas: 1, device: "desktop", updatedAt: "2026-06-28" },
  { id: "h-004", screen: "Habit detail", projectId: "p-005", projectName: "Cadence Mobile", type: "rage", sessions: 720, avgTime: "31s", topHotspot: { x: 78, y: 88, intensity: 65, label: "Streak badge" }, coldZones: 1, dropOffAreas: 3, device: "mobile", updatedAt: "2026-06-30" },
  { id: "h-005", screen: "Search results", projectId: "p-006", projectName: "Voyage Booking", type: "dead", sessions: 410, avgTime: "18s", topHotspot: { x: 14, y: 52, intensity: 54, label: "Filter icon" }, coldZones: 7, dropOffAreas: 5, device: "mobile", updatedAt: "2026-06-25" },
  { id: "h-006", screen: "Component — Button", projectId: "p-004", projectName: "Riverside Design System", type: "click", sessions: 320, avgTime: "12s", topHotspot: { x: 50, y: 50, intensity: 95, label: "Primary CTA" }, coldZones: 0, dropOffAreas: 0, device: "desktop", updatedAt: "2026-06-22" },
];

// ============================================================================
// Session Replays
// ============================================================================

export const SESSION_REPLAYS: SessionReplay[] = [
  { id: "s-001", user: "User_4280", avatar: av(15), device: "mobile", browser: "Safari iOS 17", duration: "3:42", events: 47, rageClicks: 3, deadClicks: 1, errors: 0, tags: ["checkout", "friction"], outcome: "rage", segments: ["Mobile", "Returning"], startedAt: "2026-07-01 14:22", project: "Northwind Checkout" },
  { id: "s-002", user: "User_5102", avatar: av(16), device: "mobile", browser: "Chrome Android", duration: "5:18", events: 68, rageClicks: 0, deadClicks: 2, errors: 1, tags: ["onboarding", "KYC"], outcome: "dropped", segments: ["Mobile", "First-time"], startedAt: "2026-07-01 11:08", project: "Atlas Onboarding" },
  { id: "s-003", user: "User_3310", avatar: av(17), device: "desktop", browser: "Chrome 126", duration: "8:24", events: 102, rageClicks: 0, deadClicks: 0, errors: 0, tags: ["power-user"], outcome: "completed", segments: ["Desktop", "Pro"], startedAt: "2026-07-01 09:45", project: "Helix Prototype" },
  { id: "s-004", user: "User_7891", avatar: av(18), device: "mobile", browser: "Safari iOS 17", duration: "2:15", events: 28, rageClicks: 5, deadClicks: 3, errors: 2, tags: ["booking", "errors"], outcome: "error", segments: ["Mobile", "First-time"], startedAt: "2026-06-30 22:14", project: "Voyage Booking" },
  { id: "s-005", user: "User_2204", avatar: av(19), device: "desktop", browser: "Firefox 127", duration: "6:48", events: 84, rageClicks: 1, deadClicks: 0, errors: 0, tags: ["research"], outcome: "completed", segments: ["Desktop", "Researcher"], startedAt: "2026-06-30 16:30", project: "Cadence Mobile" },
  { id: "s-006", user: "User_6612", avatar: av(21), device: "tablet", browser: "Safari iPadOS", duration: "4:02", events: 56, rageClicks: 0, deadClicks: 1, errors: 0, tags: ["browsing"], outcome: "completed", segments: ["Tablet", "Casual"], startedAt: "2026-06-30 13:12", project: "Riverside Design System" },
];

// ============================================================================
// Journeys
// ============================================================================

export const JOURNEYS: Journey[] = [
  {
    id: "j-001",
    name: "First-time user → First transfer",
    persona: "New Customer",
    steps: [
      { id: "js-1", name: "App install", description: "User installs app from store", users: 5240, conversion: 100, avgTime: "0s", friction: "low", dropOff: 0 },
      { id: "js-2", name: "Account signup", description: "Email + phone verification", users: 4180, conversion: 79, avgTime: "1:42", friction: "medium", dropOff: 21 },
      { id: "js-3", name: "KYC verification", description: "ID upload + selfie", users: 3120, conversion: 74, avgTime: "3:18", friction: "high", dropOff: 26 },
      { id: "js-4", name: "Wallet setup", description: "Link funding source", users: 2640, conversion: 84, avgTime: "1:08", friction: "low", dropOff: 16 },
      { id: "js-5", name: "First transfer", description: "Recipient + amount + send", users: 1980, conversion: 75, avgTime: "2:24", friction: "medium", dropOff: 25 },
    ],
    completionRate: 38,
    avgTime: "8:32",
    frictionPoints: 3,
    dropOff: 62,
    project: "Atlas Onboarding",
    status: "active",
    updatedAt: "2026-07-01",
  },
  {
    id: "j-002",
    name: "Browse → Purchase",
    persona: "Returning Shopper",
    steps: [
      { id: "js-1", name: "Landing", description: "Home or category page", users: 8200, conversion: 100, avgTime: "0s", friction: "low", dropOff: 0 },
      { id: "js-2", name: "Product view", description: "PDP visit", users: 5840, conversion: 71, avgTime: "1:12", friction: "low", dropOff: 29 },
      { id: "js-3", name: "Add to cart", description: "Add product to cart", users: 3120, conversion: 53, avgTime: "0:42", friction: "low", dropOff: 47 },
      { id: "js-4", name: "Checkout", description: "Begin checkout flow", users: 1840, conversion: 59, avgTime: "2:08", friction: "high", dropOff: 41 },
      { id: "js-5", name: "Payment", description: "Complete payment", users: 920, conversion: 50, avgTime: "1:38", friction: "high", dropOff: 50 },
    ],
    completionRate: 11,
    avgTime: "5:40",
    frictionPoints: 2,
    dropOff: 89,
    project: "Northwind Checkout",
    status: "active",
    updatedAt: "2026-06-30",
  },
];

// ============================================================================
// Funnel steps (generic example)
// ============================================================================

export const FUNNEL_STEPS: FunnelStep[] = JOURNEYS[0].steps.map((s) => ({
  id: s.id,
  name: s.name,
  users: s.users,
  conversion: s.conversion,
  dropOff: s.dropOff,
  avgTime: s.avgTime,
}));

// ============================================================================
// Research studies
// ============================================================================

export const RESEARCH_STUDIES: ResearchStudy[] = [
  { id: "rs-001", title: "Atlas KYC Friction — Moderated Interviews", type: "interview", status: "completed", method: "1:1 moderated remote", participants: 12, targetParticipants: 12, duration: "3 weeks", owner: { name: "Mira Halberg", avatar: av(12) }, project: "Atlas Onboarding", tags: ["KYC", "mobile"], findings: 8, startDate: "2026-06-05", endDate: "2026-06-26" },
  { id: "rs-002", title: "Northwind Checkout — Unmoderated Usability Test", type: "usability-test", status: "analyzing", method: "Unmoderated, UserTesting.com", participants: 24, targetParticipants: 24, duration: "1 week", owner: { name: "Sana Iqbal", avatar: av(20) }, project: "Northwind Checkout", tags: ["checkout", "e-commerce"], findings: 14, startDate: "2026-06-22", endDate: "2026-06-29" },
  { id: "rs-003", title: "Helix Dashboard — Card Sort", type: "card-sort", status: "completed", method: "Open card sort, 42 items", participants: 18, targetParticipants: 18, duration: "2 weeks", owner: { name: "Lena Ortiz", avatar: av(45) }, project: "Helix Prototype", tags: ["IA", "navigation"], findings: 5, startDate: "2026-05-12", endDate: "2026-05-26" },
  { id: "rs-004", title: "Cadence Habit-Setting — Survey", type: "survey", status: "in-progress", method: "In-app micro-survey, 6 questions", participants: 482, targetParticipants: 1000, duration: "Ongoing", owner: { name: "Idris Khoury", avatar: av(33) }, project: "Cadence Mobile", tags: ["habits", "engagement"], findings: 0, startDate: "2026-06-20", endDate: "2026-07-20" },
  { id: "rs-005", title: "Riverside Components — Tree Test", type: "tree-test", status: "completed", method: "Tree jack, 3 tasks", participants: 60, targetParticipants: 60, duration: "1 week", owner: { name: "Aria Mendez", avatar: av(48) }, project: "Riverside Design System", tags: ["IA", "components"], findings: 4, startDate: "2026-05-04", endDate: "2026-05-11" },
  { id: "rs-006", title: "Voyage Booking — Diary Study", type: "diary-study", status: "recruiting", method: "7-day diary, entries on bookings", participants: 0, targetParticipants: 10, duration: "2 weeks", owner: { name: "Sana Iqbal", avatar: av(20) }, project: "Voyage Booking", tags: ["travel", "longitudinal"], findings: 0, startDate: "2026-07-15", endDate: "2026-07-29" },
];

// ============================================================================
// Personas
// ============================================================================

export const PERSONAS: Persona[] = [
  { id: "pe-001", name: "Pragmatic Priya", role: "Senior Product Designer", avatar: av(5), age: 34, goals: ["Ship measurable UX wins", "Defend decisions with data"], frustrations: ["Slow research turnaround", "Vague stakeholder feedback"], behaviors: ["Reviews heatmaps weekly", "Prefers async over sync"], devices: ["MacBook", "iPhone"], segment: "Power user", quote: "Show me the funnel before I redesign anything." },
  { id: "pe-002", name: "Evidence-First Ethan", role: "UX Researcher", avatar: av(11), age: 29, goals: ["Build a defensible insights repo", "Run studies weekly"], frustrations: ["Findings buried in slide decks", "Tool fragmentation"], behaviors: ["Tags everything", "Runs tree tests before redesigns"], devices: ["MacBook", "iPad"], segment: "Researcher", quote: "If it isn't tagged, it doesn't exist." },
  { id: "pe-003", name: "Conversion Cara", role: "CRO Specialist", avatar: av(20), age: 41, goals: ["Lift checkout conversion 15%", "Win the next A/B test"], frustrations: ["Slow A/B tooling", "Low sample sizes"], behaviors: ["Lives in funnels", "Reviews session replays daily"], devices: ["Windows laptop", "Android"], segment: "CRO", quote: "Every percentage point is a quarter-million." },
  { id: "pe-004", name: "Mobile-First Mateo", role: "PM", avatar: av(33), age: 36, goals: ["Ship a 4-star mobile experience", "Cut onboarding drop-off"], frustrations: ["Slow mobile analytics", "Cross-device attribution gaps"], behaviors: ["Reviews mobile funnels first", "Pushes for native patterns"], devices: ["iPhone", "Pixel"], segment: "Mobile PM", quote: "If it doesn't work on a 4-inch screen, it doesn't ship." },
];

// ============================================================================
// Team members
// ============================================================================

export const TEAM_MEMBERS: TeamMember[] = [
  { id: "u-001", name: "Mira Halberg", avatar: av(12), email: "mira@ooster.app", role: "Owner", status: "active", lastActive: "2 min ago", projects: 4, insights: 38, twoFactor: true },
  { id: "u-002", name: "Theo Park", avatar: av(13), email: "theo@ooster.app", role: "Designer", status: "active", lastActive: "1 hour ago", projects: 3, insights: 24, twoFactor: true },
  { id: "u-003", name: "Lena Ortiz", avatar: av(45), email: "lena@ooster.app", role: "PM", status: "active", lastActive: "4 hours ago", projects: 5, insights: 12, twoFactor: true },
  { id: "u-004", name: "Idris Khoury", avatar: av(33), email: "idris@ooster.app", role: "Admin", status: "active", lastActive: "Yesterday", projects: 2, insights: 8, twoFactor: false },
  { id: "u-005", name: "Aria Mendez", avatar: av(48), email: "aria@ooster.app", role: "Researcher", status: "active", lastActive: "3 days ago", projects: 4, insights: 41, twoFactor: true },
  { id: "u-006", name: "Sana Iqbal", avatar: av(20), email: "sana@ooster.app", role: "Researcher", status: "invited", lastActive: "—", projects: 0, insights: 0, twoFactor: false },
  { id: "u-007", name: "Noah Becker", avatar: av(51), email: "noah@ooster.app", role: "Viewer", status: "active", lastActive: "1 week ago", projects: 1, insights: 0, twoFactor: false },
];

// ============================================================================
// Customers
// ============================================================================

export const CUSTOMERS: Customer[] = [
  { id: "c-001", name: "Halberg Studios", avatar: av(60), company: "Halberg Studios", plan: "Enterprise", mrr: 2400, seats: 32, status: "active", joinedAt: "2024-08-12", projects: 18, contact: "ops@halberg.co" },
  { id: "c-002", name: "Northwind Retail", avatar: av(61), company: "Northwind Retail", plan: "Team", mrr: 580, seats: 12, status: "active", joinedAt: "2025-01-22", projects: 6, contact: "design@northwind.io" },
  { id: "c-003", name: "Helix Health", avatar: av(62), company: "Helix Health", plan: "Team", mrr: 580, seats: 8, status: "trialing", joinedAt: "2026-06-04", projects: 3, contact: "ux@helixhealth.com" },
  { id: "c-004", name: "Cadence Labs", avatar: av(63), company: "Cadence Labs", plan: "Pro", mrr: 120, seats: 3, status: "active", joinedAt: "2025-09-14", projects: 2, contact: "team@cadence.app" },
  { id: "c-005", name: "Voyage Travel", avatar: av(64), company: "Voyage Travel", plan: "Pro", mrr: 120, seats: 4, status: "trialing", joinedAt: "2026-06-18", projects: 1, contact: "pm@voyage.co" },
  { id: "c-006", name: "Riverside Inc", avatar: av(65), company: "Riverside Inc", plan: "Enterprise", mrr: 2400, seats: 24, status: "active", joinedAt: "2024-11-30", projects: 9, contact: "platform@riverside.io" },
];

// ============================================================================
// Issues
// ============================================================================

export const ISSUES: Issue[] = [
  { id: "is-001", title: "Address autocomplete fails for rural zip codes", severity: "high", type: "bug", status: "in-progress", project: "Northwind Checkout", screen: "Shipping address", assignee: { name: "Idris Khoury", avatar: av(33) }, reporter: { name: "Sana Iqbal", avatar: av(20) }, createdAt: "2026-06-28", updatedAt: "2026-07-01", comments: 8, reactions: 14 },
  { id: "is-002", title: "KYC document type selector mislabels 'Passport'", severity: "critical", type: "content", status: "open", project: "Atlas Onboarding", screen: "Step 3", assignee: null, reporter: { name: "Mira Halberg", avatar: av(12) }, createdAt: "2026-07-01", updatedAt: "2026-07-01", comments: 3, reactions: 9 },
  { id: "is-003", title: "Color contrast below WCAG AA on primary buttons", severity: "high", type: "accessibility", status: "open", project: "Riverside Design System", screen: "Button component", assignee: { name: "Aria Mendez", avatar: av(48) }, reporter: { name: "Aria Mendez", avatar: av(48) }, createdAt: "2026-06-26", updatedAt: "2026-06-30", comments: 12, reactions: 22 },
  { id: "is-004", title: "Calendar widget traps keyboard focus", severity: "critical", type: "accessibility", status: "in-progress", project: "Voyage Booking", screen: "Date picker", assignee: { name: "Idris Khoury", avatar: av(33) }, reporter: { name: "Aria Mendez", avatar: av(48) }, createdAt: "2026-06-27", updatedAt: "2026-07-01", comments: 6, reactions: 11 },
  { id: "is-005", title: "Push permission prompt appears too early", severity: "high", type: "ux", status: "open", project: "Cadence Mobile", screen: "Onboarding step 2", assignee: { name: "Theo Park", avatar: av(13) }, reporter: { name: "Idris Khoury", avatar: av(33) }, createdAt: "2026-06-30", updatedAt: "2026-07-01", comments: 4, reactions: 7 },
  { id: "is-006", title: "Empty insights list confuses new PMs", severity: "medium", type: "ux", status: "in-progress", project: "Helix Prototype", screen: "Insights list", assignee: { name: "Lena Ortiz", avatar: av(45) }, reporter: { name: "Mira Halberg", avatar: av(12) }, createdAt: "2026-06-22", updatedAt: "2026-06-28", comments: 9, reactions: 18 },
  { id: "is-007", title: "Slow loading on heatmap viewer >5MB", severity: "low", type: "performance", status: "open", project: "Atlas Onboarding", screen: "Heatmap", assignee: null, reporter: { name: "Mira Halberg", avatar: av(12) }, createdAt: "2026-06-29", updatedAt: "2026-06-30", comments: 2, reactions: 3 },
  { id: "is-008", title: "Filter icon unclear on mobile search", severity: "medium", type: "ux", status: "resolved", project: "Voyage Booking", screen: "Search results", assignee: { name: "Theo Park", avatar: av(13) }, reporter: { name: "Sana Iqbal", avatar: av(20) }, createdAt: "2026-06-18", updatedAt: "2026-06-25", comments: 5, reactions: 8 },
];

// ============================================================================
// Audit logs
// ============================================================================

export const AUDIT_LOGS: AuditLog[] = [
  { id: "a-001", actor: "Mira Halberg", avatar: av(12), action: "Generated report", target: "Atlas Onboarding — Q2 UX Audit", category: "report", ip: "203.0.113.42", timestamp: "2026-07-01 14:32" },
  { id: "a-002", actor: "Theo Park", avatar: av(13), action: "Updated project settings", target: "Northwind Checkout", category: "project", ip: "198.51.100.18", timestamp: "2026-07-01 13:15" },
  { id: "a-003", actor: "Idris Khoury", avatar: av(33), action: "Invited team member", target: "sana@ooster.app", category: "team", ip: "203.0.113.99", timestamp: "2026-07-01 11:08" },
  { id: "a-004", actor: "Aria Mendez", avatar: av(48), action: "Created API key", target: "Production readonly key", category: "integration", ip: "198.51.100.77", timestamp: "2026-06-30 18:22" },
  { id: "a-005", actor: "Lena Ortiz", avatar: av(45), action: "Signed in", target: "—", category: "auth", ip: "203.0.113.12", timestamp: "2026-06-30 09:42" },
  { id: "a-006", actor: "Sana Iqbal", avatar: av(20), action: "Exported data", target: "Northwind Checkout — sessions.csv", category: "data", ip: "198.51.100.55", timestamp: "2026-06-29 16:50" },
  { id: "a-007", actor: "Mira Halberg", avatar: av(12), action: "Upgraded plan", target: "Team → Enterprise", category: "billing", ip: "203.0.113.42", timestamp: "2026-06-28 10:14" },
];

// ============================================================================
// API keys
// ============================================================================

export const API_KEYS: ApiKey[] = [
  { id: "k-001", name: "Production — Readonly", prefix: "oost_live_ro_", scopes: ["read:projects", "read:insights", "read:reports"], lastUsed: "2 min ago", createdAt: "2026-05-12", createdBy: "Mira Halberg", status: "active" },
  { id: "k-002", name: "Staging — Full Access", prefix: "oost_test_fa_", scopes: ["read:projects", "write:projects", "read:insights", "write:insights"], lastUsed: "Yesterday", createdAt: "2026-04-22", createdBy: "Idris Khoury", status: "active" },
  { id: "k-003", name: "Webhook signer", prefix: "oost_live_wh_", scopes: ["webhook:sign"], lastUsed: "3 days ago", createdAt: "2026-03-30", createdBy: "Aria Mendez", status: "active" },
  { id: "k-004", name: "Legacy export key", prefix: "oost_live_xl_", scopes: ["export:data"], lastUsed: "2 months ago", createdAt: "2025-12-04", createdBy: "Mira Halberg", status: "revoked" },
];

// ============================================================================
// Integrations
// ============================================================================

export const INTEGRATIONS: Integration[] = [
  { id: "int-001", name: "Figma", description: "Sync Figma frames as Ooster screens for analysis", category: "design", icon: "Figma", connected: true, connectedAt: "2026-05-10", status: "connected" },
  { id: "int-002", name: "Slack", description: "Pipe insights and reports into Slack channels", category: "communication", icon: "Slack", connected: true, connectedAt: "2026-04-22", status: "connected" },
  { id: "int-003", name: "Linear", description: "Create issues from Ooster insights automatically", category: "project-management", icon: "Linear", connected: false, status: "available" },
  { id: "int-004", name: "Jira", description: "Sync insights to Jira epics and stories", category: "project-management", icon: "Jira", connected: false, status: "available" },
  { id: "int-005", name: "Notion", description: "Publish reports to your Notion workspace", category: "project-management", icon: "Notion", connected: true, connectedAt: "2026-06-12", status: "connected" },
  { id: "int-006", name: "Segment", description: "Stream session events from Segment CDP", category: "analytics", icon: "Segment", connected: false, status: "available" },
  { id: "int-007", name: "Amplitude", description: "Pull cohort data into Ooster segments", category: "analytics", icon: "Amplitude", connected: false, status: "available" },
  { id: "int-008", name: "Maze", description: "Import usability test results", category: "feedback", icon: "Maze", connected: false, status: "coming-soon" },
  { id: "int-009", name: "UserTesting", description: "Embed session videos alongside Ooster replays", category: "feedback", icon: "UserTesting", connected: false, status: "coming-soon" },
  { id: "int-010", name: "Okta", description: "SSO for Enterprise plans via Okta", category: "auth", icon: "Okta", connected: true, connectedAt: "2026-02-18", status: "connected" },
];

// ============================================================================
// Invoices
// ============================================================================

export const INVOICES: Invoice[] = [
  { id: "in-001", number: "OOST-2026-0006", customer: "Halberg Studios", amount: 2400, status: "paid", date: "2026-06-01", plan: "Enterprise — Monthly", method: "Card •• 4242" },
  { id: "in-002", number: "OOST-2026-0005", customer: "Halberg Studios", amount: 2400, status: "paid", date: "2026-05-01", plan: "Enterprise — Monthly", method: "Card •• 4242" },
  { id: "in-003", number: "OOST-2026-0004", customer: "Northwind Retail", amount: 580, status: "paid", date: "2026-06-01", plan: "Team — Monthly", method: "ACH" },
  { id: "in-004", number: "OOST-2026-0003", customer: "Cadence Labs", amount: 120, status: "pending", date: "2026-07-01", plan: "Pro — Monthly", method: "Card •• 8810" },
  { id: "in-005", number: "OOST-2026-0002", customer: "Riverside Inc", amount: 2400, status: "paid", date: "2026-06-01", plan: "Enterprise — Monthly", method: "Wire" },
  { id: "in-006", number: "OOST-2026-0001", customer: "Helix Health", amount: 580, status: "failed", date: "2026-07-01", plan: "Team — Monthly", method: "Card •• 1199" },
];

// ============================================================================
// Surveys
// ============================================================================

export const SURVEYS: Survey[] = [
  { id: "sv-001", title: "Post-onboarding satisfaction (CSAT)", status: "live", questions: 4, responses: 482, completionRate: 78, avgTime: "1:12", project: "Cadence Mobile", owner: { name: "Idris Khoury", avatar: av(33) }, createdAt: "2026-06-20", closesAt: "2026-07-20" },
  { id: "sv-002", title: "Checkout friction survey", status: "analyzing", questions: 8, responses: 312, completionRate: 64, avgTime: "2:48", project: "Northwind Checkout", owner: { name: "Sana Iqbal", avatar: av(20) }, createdAt: "2026-06-10", closesAt: "2026-06-30" },
  { id: "sv-003", title: "Clinician dashboard — discoverability", status: "closed", questions: 6, responses: 18, completionRate: 100, avgTime: "3:24", project: "Helix Prototype", owner: { name: "Lena Ortiz", avatar: av(45) }, createdAt: "2026-05-22", closesAt: "2026-06-05" },
  { id: "sv-004", title: "Riverside component naming", status: "draft", questions: 0, responses: 0, completionRate: 0, avgTime: "—", project: "Riverside Design System", owner: { name: "Aria Mendez", avatar: av(48) }, createdAt: "2026-06-28", closesAt: "—" },
];

// ============================================================================
// Experiments
// ============================================================================

export const EXPERIMENTS: Experiment[] = [
  {
    id: "ex-001",
    name: "Address autocomplete vs manual entry",
    type: "ab-test",
    status: "running",
    hypothesis: "Autocomplete reduces checkout drop-off by ≥15%",
    variants: [
      { name: "Control (manual)", visitors: 4200, conversion: 62, confidence: 0 },
      { name: "Autocomplete", visitors: 4180, conversion: 81, confidence: 99.4 },
    ],
    primaryMetric: "Checkout completion",
    startDate: "2026-06-20",
    endDate: "2026-07-15",
    project: "Northwind Checkout",
    significance: 99.4,
  },
  {
    id: "ex-002",
    name: "KYC: single screen vs progressive steps",
    type: "ab-test",
    status: "completed",
    hypothesis: "Progressive steps reduce abandonment on step 3",
    variants: [
      { name: "Control (single screen)", visitors: 2100, conversion: 58, confidence: 0 },
      { name: "Progressive (3 steps)", visitors: 2120, conversion: 74, confidence: 99.8 },
    ],
    primaryMetric: "KYC completion",
    startDate: "2026-05-15",
    endDate: "2026-06-12",
    project: "Atlas Onboarding",
    significance: 99.8,
  },
  {
    id: "ex-003",
    name: "Notification prompt timing",
    type: "ab-test",
    status: "running",
    hypothesis: "Post-first-action prompts lift grant rate by ≥20pp",
    variants: [
      { name: "Control (early)", visitors: 1820, conversion: 29, confidence: 0 },
      { name: "Post-action", visitors: 1840, conversion: 48, confidence: 97.2 },
    ],
    primaryMetric: "Permission grant rate",
    startDate: "2026-06-25",
    endDate: "2026-07-20",
    project: "Cadence Mobile",
    significance: 97.2,
  },
];

// ============================================================================
// Notifications
// ============================================================================

export const NOTIFICATIONS: Notification[] = [
  { id: "n-001", title: "Critical insight on Atlas Onboarding", description: "KYC step 3 shows cognitive overload — 41% mobile users pause >12s", type: "insight", read: false, timestamp: "12 min ago", action: { label: "View insight", href: "/insights/i-002" } },
  { id: "n-002", title: "Report ready: Atlas Q2 UX Audit", description: "32-page audit across 24 screens is ready to share", type: "report", read: false, timestamp: "1 hour ago", action: { label: "Open report", href: "/reports/r-001" } },
  { id: "n-003", title: "Aria mentioned you in an insight", description: "@mira — can you confirm the cognitive load finding on step 3?", type: "mention", read: false, timestamp: "3 hours ago", action: { label: "View insight", href: "/insights/i-002" } },
  { id: "n-004", title: "A/B test 'Address autocomplete' reached 99% significance", description: "Variant beat control by 19pp on checkout completion", type: "alert", read: true, timestamp: "Yesterday", action: { label: "View experiment", href: "/experiments/ex-001" } },
  { id: "n-005", title: "Sana accepted your invite", description: "Sana Iqbal joined the workspace as Researcher", type: "team", read: true, timestamp: "Yesterday" },
  { id: "n-006", title: "Invoice OOST-2026-0006 paid", description: "$2,400 charged to Card •• 4242", type: "billing", read: true, timestamp: "2 days ago", action: { label: "View invoice", href: "/billing/invoices" } },
];

// ============================================================================
// Helpers
// ============================================================================

export function getProject(id: string): Project | undefined {
  return PROJECTS.find((p) => p.id === id || p.slug === id);
}

export function getInsight(id: string): Insight | undefined {
  return INSIGHTS.find((i) => i.id === id);
}

export function getReport(id: string): Report | undefined {
  return REPORTS.find((r) => r.id === id);
}

export function getHeatmap(id: string): Heatmap | undefined {
  return HEATMAPS.find((h) => h.id === id);
}

export function getReplay(id: string): SessionReplay | undefined {
  return SESSION_REPLAYS.find((s) => s.id === id);
}

export function getStudy(id: string): ResearchStudy | undefined {
  return RESEARCH_STUDIES.find((s) => s.id === id);
}

export function getMember(id: string): TeamMember | undefined {
  return TEAM_MEMBERS.find((m) => m.id === id);
}

export function getCustomer(id: string): Customer | undefined {
  return CUSTOMERS.find((c) => c.id === id);
}

export function getIssue(id: string): Issue | undefined {
  return ISSUES.find((i) => i.id === id);
}

export function getExperiment(id: string): Experiment | undefined {
  return EXPERIMENTS.find((e) => e.id === id);
}

export function getPersona(id: string): Persona | undefined {
  return PERSONAS.find((p) => p.id === id);
}

export function getSurvey(id: string): Survey | undefined {
  return SURVEYS.find((s) => s.id === id);
}

export function getJourney(id: string): Journey | undefined {
  return JOURNEYS.find((j) => j.id === id);
}

// Aggregate UX score breakdown used by radar chart
export const AGGREGATE_UX: UxScoreBreakdown = {
  usability: 78,
  accessibility: 86,
  conversion: 71,
  engagement: 81,
  cognitiveLoad: 64,
  clarity: 74,
  consistency: 80,
  friction: 62,
};

// Trend series (12-week)
export const TREND_SERIES = Array.from({ length: 12 }, (_, i) => {
  const week = i + 1;
  return {
    week: `W${week}`,
    ux: 62 + Math.round(i * 1.8 + Math.sin(i) * 3),
    friction: 48 - Math.round(i * 1.2 + Math.cos(i) * 4),
    taskSuccess: 70 + Math.round(i * 1.5 + Math.sin(i * 0.8) * 3),
    completion: 58 + Math.round(i * 1.6 + Math.cos(i * 0.6) * 4),
    engagement: 68 + Math.round(i * 1.2 + Math.sin(i * 0.5) * 2),
  };
});

// Passing rate distribution
export const PASSING_RATE = {
  complete: 61,
  failed: 17,
  partial: 22,
};

// Recent activity feed (used on dashboard)
export const RECENT_ACTIVITY = [
  { id: "ra-1", actor: "Mira Halberg", avatar: av(12), action: "generated the Q2 UX Audit report", target: "Atlas Onboarding", time: "12 min ago" },
  { id: "ra-2", actor: "Aria Mendez", avatar: av(48), action: "marked insight as resolved", target: "Filter icon unclear on mobile search", time: "1 hour ago" },
  { id: "ra-3", actor: "Theo Park", avatar: av(13), action: "uploaded 4 new screens", target: "Northwind Checkout", time: "3 hours ago" },
  { id: "ra-4", actor: "Idris Khoury", avatar: av(33), action: "kicked off A/B test", target: "Address autocomplete vs manual", time: "Yesterday" },
  { id: "ra-5", actor: "Sana Iqbal", avatar: av(20), action: "closed survey", target: "Checkout friction survey", time: "Yesterday" },
];
