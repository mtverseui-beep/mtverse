import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard,
  FolderKanban,
  Lightbulb,
  Flame,
  PlayCircle,
  GitBranch,
  Filter,
  FileBarChart,
  Microscope,
  Users,
  Settings,
  History,
} from "lucide-react";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  description?: string;
}

export const PRIMARY_NAV: NavItem[] = [
  { label: "Dashboard", href: "/", icon: LayoutDashboard, description: "UX command center" },
  { label: "Projects", href: "/projects", icon: FolderKanban, description: "Project portfolio" },
  { label: "Insights", href: "/insights", icon: Lightbulb, description: "Recommendation engine" },
  { label: "Heatmaps", href: "/heatmaps", icon: Flame, description: "Click, scroll, attention" },
  { label: "Replays", href: "/session-replays", icon: PlayCircle, description: "Session playback" },
  { label: "Journeys", href: "/journeys", icon: GitBranch, description: "User journey analysis" },
  { label: "Funnels", href: "/funnels", icon: Filter, description: "Conversion analysis" },
  { label: "Reports", href: "/reports", icon: FileBarChart, description: "AI research reports" },
  { label: "Research", href: "/research", icon: Microscope, description: "Research repository" },
  { label: "Team", href: "/teams", icon: Users, description: "Team & members" },
  { label: "History", href: "/history", icon: History, description: "Activity timeline" },
  { label: "Settings", href: "/settings", icon: Settings, description: "Account & workspace" },
];
