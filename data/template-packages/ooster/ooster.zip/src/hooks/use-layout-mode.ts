"use client";

import { create } from "zustand";

export type LayoutMode = "boxed" | "fullscreen";

const STORAGE_KEY = "ooster-layout";

interface LayoutState {
  mode: LayoutMode;
  mounted: boolean;
  setMode: (mode: LayoutMode) => void;
  toggle: () => void;
  init: () => void;
}

export const useLayoutStore = create<LayoutState>((set, get) => ({
  mode: "boxed",
  mounted: false,
  setMode: (mode) => {
    try {
      localStorage.setItem(STORAGE_KEY, mode);
    } catch {}
    set({ mode });
  },
  toggle: () => {
    const next = get().mode === "boxed" ? "fullscreen" : "boxed";
    try {
      localStorage.setItem(STORAGE_KEY, next);
    } catch {}
    set({ mode: next });
  },
  init: () => {
    if (get().mounted) return;
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored === "boxed" || stored === "fullscreen") {
        set({ mode: stored, mounted: true });
        return;
      }
    } catch {}
    set({ mounted: true });
  },
}));
