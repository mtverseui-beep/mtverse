"use client";

import * as React from "react";
import { create } from "zustand";

interface ModalState {
  // Command palette
  commandOpen: boolean;
  setCommandOpen: (open: boolean) => void;
  toggleCommand: () => void;

  // Create project
  createProjectOpen: boolean;
  setCreateProjectOpen: (open: boolean) => void;

  // Generate report
  generateReportOpen: boolean;
  setGenerateReportOpen: (open: boolean) => void;

  // Create insight
  createInsightOpen: boolean;
  setCreateInsightOpen: (open: boolean) => void;

  // Share (generic) — pass URL via attribute
  shareOpen: boolean;
  shareUrl: string;
  shareTitle: string;
  openShare: (url: string, title?: string) => void;
  setShareOpen: (open: boolean) => void;

  // Detail drawer (generic) — pass content descriptor
  drawerOpen: boolean;
  drawerPayload: { type: string; id: string; title?: string } | null;
  openDrawer: (payload: { type: string; id: string; title?: string }) => void;
  setDrawerOpen: (open: boolean) => void;

  // Settings drawer (on project detail)
  settingsDrawerOpen: boolean;
  setSettingsDrawerOpen: (open: boolean) => void;

  // Confirm modal (generic)
  confirmOpen: boolean;
  confirmPayload: { title: string; description: string; onConfirm: () => void } | null;
  openConfirm: (payload: { title: string; description: string; onConfirm: () => void }) => void;
  setConfirmOpen: (open: boolean) => void;
}

export const useModals = create<ModalState>((set, get) => ({
  commandOpen: false,
  setCommandOpen: (open) => set({ commandOpen: open }),
  toggleCommand: () => set((s) => ({ commandOpen: !s.commandOpen })),

  createProjectOpen: false,
  setCreateProjectOpen: (open) => set({ createProjectOpen: open }),

  generateReportOpen: false,
  setGenerateReportOpen: (open) => set({ generateReportOpen: open }),

  createInsightOpen: false,
  setCreateInsightOpen: (open) => set({ createInsightOpen: open }),

  shareOpen: false,
  shareUrl: "",
  shareTitle: "",
  openShare: (url, title = "") => set({ shareOpen: true, shareUrl: url, shareTitle: title }),
  setShareOpen: (open) => set({ shareOpen: open }),

  drawerOpen: false,
  drawerPayload: null,
  openDrawer: (payload) => set({ drawerOpen: true, drawerPayload: payload }),
  setDrawerOpen: (open) => set({ drawerOpen: open }),

  settingsDrawerOpen: false,
  setSettingsDrawerOpen: (open) => set({ settingsDrawerOpen: open }),

  confirmOpen: false,
  confirmPayload: null,
  openConfirm: (payload) => set({ confirmOpen: true, confirmPayload: payload }),
  setConfirmOpen: (open) => set({ confirmOpen: open }),
}));

// Convenience hooks (named exports for tree-shaking clarity)
export const useCommandPalette = () => {
  const open = useModals((s) => s.commandOpen);
  const setOpen = useModals((s) => s.setCommandOpen);
  return [open, setOpen] as const;
};

export const useCreateProjectModal = () => {
  const open = useModals((s) => s.createProjectOpen);
  const setOpen = useModals((s) => s.setCreateProjectOpen);
  return { open, setOpen };
};

export const useGenerateReportModal = () => {
  const open = useModals((s) => s.generateReportOpen);
  const setOpen = useModals((s) => s.setGenerateReportOpen);
  return { open, setOpen };
};

export const useCreateInsightModal = () => {
  const open = useModals((s) => s.createInsightOpen);
  const setOpen = useModals((s) => s.setCreateInsightOpen);
  return { open, setOpen };
};

export const useShareModal = () => {
  const open = useModals((s) => s.shareOpen);
  const setOpen = useModals((s) => s.setShareOpen);
  const url = useModals((s) => s.shareUrl);
  const title = useModals((s) => s.shareTitle);
  const openShare = useModals((s) => s.openShare);
  return { open, setOpen, url, title, openShare };
};

export const useDetailDrawer = () => {
  const open = useModals((s) => s.drawerOpen);
  const setOpen = useModals((s) => s.setDrawerOpen);
  const payload = useModals((s) => s.drawerPayload);
  const openDrawer = useModals((s) => s.openDrawer);
  return { open, setOpen, payload, openDrawer };
};

export const useSettingsDrawer = () => {
  const open = useModals((s) => s.settingsDrawerOpen);
  const setOpen = useModals((s) => s.setSettingsDrawerOpen);
  return { open, setOpen };
};

export const useConfirmModal = () => {
  const open = useModals((s) => s.confirmOpen);
  const setOpen = useModals((s) => s.setConfirmOpen);
  const payload = useModals((s) => s.confirmPayload);
  const openConfirm = useModals((s) => s.openConfirm);
  return { open, setOpen, payload, openConfirm };
};
