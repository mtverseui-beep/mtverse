import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";
import { CommandPalette } from "@/components/command/command-palette";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "Ooster — UX Research & Product Analytics",
    template: "%s · Ooster",
  },
  description:
    "Ooster is a premium UX research, product analytics, usability testing, and experience intelligence platform. Heatmaps, session replays, journeys, funnels, AI reports, and a research repository — all in one calm dashboard.",
  keywords: [
    "UX analytics",
    "product analytics",
    "usability testing",
    "UX research",
    "heatmaps",
    "session replay",
    "user journey",
    "funnel analysis",
    "AI UX reports",
    "Ooster",
  ],
  authors: [{ name: "Ooster Labs" }],
  creator: "Ooster Labs",
  applicationName: "Ooster",
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
      { url: "/icon-light-32x32.png", media: "(prefers-color-scheme: light)" },
      { url: "/icon-dark-32x32.png", media: "(prefers-color-scheme: dark)" },
    ],
    apple: "/apple-icon.png",
  },
  openGraph: {
    title: "Ooster — UX Research & Product Analytics",
    description:
      "Premium UX research, product analytics, usability testing, and experience intelligence platform for modern product teams.",
    url: "https://ooster.app",
    siteName: "Ooster",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Ooster — UX Research & Product Analytics",
    description:
      "Premium UX research, product analytics, usability testing, and experience intelligence platform.",
  },
  manifest: undefined,
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f3f1ec" },
    { media: "(prefers-color-scheme: dark)", color: "#1f1d2b" },
  ],
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* No hydration flicker — apply theme before paint */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('ooster-theme');if(t==='dark'||(!t&&window.matchMedia('(prefers-color-scheme: dark)').matches)){document.documentElement.classList.add('dark');}}catch(e){}})();`,
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          storageKey="ooster-theme"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <SonnerToaster
            position="bottom-right"
            richColors
            closeButton
            toastOptions={{ style: { borderRadius: "12px" } }}
          />
          <CommandPalette />
        </ThemeProvider>
      </body>
    </html>
  );
}
