"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Users,
  Quote,
  Target,
  AlertTriangle,
  Activity,
  Smartphone,
  Monitor,
  Tablet,
  Share2,
  Pencil,
  Layers,
  BookOpen,
  Mic,
  ChevronRight,
  CalendarDays,
  User,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { StatusBadge } from "@/components/common/badges";
import { getPersona, type Persona } from "@/lib/data";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ----------------------------------------------------------------------------
// Mock related research studies + verbatim quotes
// ----------------------------------------------------------------------------

const RELATED_STUDIES = [
  {
    id: "rs-001",
    title: "Atlas KYC Friction — Moderated Interviews",
    method: "1:1 moderated remote",
    status: "completed" as const,
    findings: 8,
    owner: { name: "Mira Halberg", avatar: "https://i.pravatar.cc/80?img=12" },
    date: "2026-06-26",
  },
  {
    id: "rs-003",
    title: "Helix Dashboard — Card Sort",
    method: "Open card sort, 42 items",
    status: "completed" as const,
    findings: 5,
    owner: { name: "Lena Ortiz", avatar: "https://i.pravatar.cc/80?img=45" },
    date: "2026-05-26",
  },
  {
    id: "rs-002",
    title: "Northwind Checkout — Usability Test",
    method: "Unmoderated, UserTesting.com",
    status: "analyzing" as const,
    findings: 14,
    owner: { name: "Sana Iqbal", avatar: "https://i.pravatar.cc/80?img=20" },
    date: "2026-06-29",
  },
];

const VERBATIM_QUOTES = [
  {
    quote: "Show me the funnel before I redesign anything. Numbers first, opinions later.",
    context: "Moderated interview · Atlas KYC Friction",
    date: "2026-06-23",
  },
  {
    quote: "If I can't see the drop-off in under 30 seconds, I'm opening a different tool.",
    context: "Diary study · Riverside Components",
    date: "2026-06-14",
  },
  {
    quote: "I tag every clip. If I can't find it in three months, the research didn't happen.",
    context: "Unmoderated test · Northwind Checkout",
    date: "2026-06-25",
  },
];

// ----------------------------------------------------------------------------
// Helpers
// ----------------------------------------------------------------------------

function DeviceRow({ device }: { device: string }) {
  let Icon = Monitor;
  if (device.toLowerCase().includes("iphone") || device.toLowerCase().includes("pixel") || device.toLowerCase().includes("android")) {
    Icon = Smartphone;
  } else if (device.toLowerCase().includes("ipad") || device.toLowerCase().includes("tablet")) {
    Icon = Tablet;
  }
  return (
    <div className="flex items-center justify-between gap-2 py-2 border-b border-soft last:border-0">
      <div className="flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/10 text-info">
          <Icon className="h-3.5 w-3.5" />
        </div>
        <span className="text-xs text-ink">{device}</span>
      </div>
      <Badge variant="secondary" className="text-[10px]">
        Primary
      </Badge>
    </div>
  );
}

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function PersonaDetailPage() {
  const params = useParams<{ id: string }>();
  const persona = getPersona(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  if (!persona) {
    return (
      <EmptyState
        icon={Users}
        title="Persona not found"
        description="This persona may have been archived or the link is incorrect."
        action={{ label: "Back to personas", href: "/personas" }}
      />
    );
  }

  const handleShare = () => {
    openShare(`https://ooster.app/p/${persona.id}`, persona.name);
  };
  const handleEdit = () => toast.info("Edit persona", { description: "Opening persona editor in a new pane." });

  return (
    <div>
      <PageHeader
        title={persona.name}
        description={`${persona.role} · ${persona.age} years · ${persona.segment}`}
        breadcrumbs={[
          { label: "Personas", href: "/personas" },
          { label: persona.name },
        ]}
        icon={<Users className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {persona.segment}
          </Badge>
        }
        actions={
          <>
            <Button variant="outline" size="sm" className="rounded-full" onClick={handleShare}>
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button size="sm" className="rounded-full" onClick={handleEdit}>
              <Pencil className="mr-2 h-3.5 w-3.5" /> Edit
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* LEFT column */}
        <div className="lg:col-span-2 space-y-4">
          {/* Persona profile card */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="flex flex-col sm:flex-row items-start gap-4">
              <Avatar className="h-20 w-20 ring-2 ring-soft flex-shrink-0">
                <AvatarImage src={persona.avatar} alt={persona.name} />
                <AvatarFallback>{persona.name.slice(0, 2)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-lg font-semibold text-ink">{persona.name}</span>
                  <Badge variant="secondary" className="text-[10px]">
                    {persona.segment}
                  </Badge>
                </div>
                <div className="text-sm text-muted-foreground mt-0.5">
                  {persona.role}
                </div>
                <div className="flex items-center gap-3 mt-2 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <User className="h-3 w-3" /> {persona.age} yrs
                  </span>
                  <span className="flex items-center gap-1">
                    <Activity className="h-3 w-3" /> Active daily
                  </span>
                </div>
              </div>
            </div>
            <div className="mt-4 rounded-xl bg-surface-2/40 p-3 flex items-start gap-2">
              <Quote className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
              <p className="text-sm italic text-ink leading-relaxed">
                {persona.quote}
              </p>
            </div>
          </Card>

          {/* About card */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/10 text-info">
                <BookOpen className="h-3.5 w-3.5" />
              </div>
              <span className="text-sm font-semibold text-ink">About this persona</span>
            </div>
            <div className="space-y-3 text-xs text-muted-foreground leading-relaxed">
              <p>
                {persona.name.split(" ")[1]} is a {persona.age}-year-old {persona.role.toLowerCase()} working on
                high-velocity product teams. Their day rotates between research
                synthesis, design review, and stakeholder alignment — they
                lean on quantitative evidence to defend decisions and rarely
                ship a redesign without funnel data to back it up.
              </p>
              <p>
                {persona.name.split(" ")[1]} has been in their role for 6+ years and is
                fluent across research methods, analytics tooling, and
                design systems. They expect their UX tooling to be as fast
                and defensible as the rest of their stack — vague
                visualizations or slow dashboards lose their trust quickly.
              </p>
            </div>
          </Card>

          {/* Goals + Frustrations */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="rounded-2xl border-soft shadow-soft p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-success/10 text-success">
                  <Target className="h-3.5 w-3.5" />
                </div>
                <span className="text-sm font-semibold text-ink">Goals</span>
              </div>
              <ul className="space-y-2">
                {persona.goals.map((g, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-ink">
                    <span className="flex h-4 w-4 items-center justify-center rounded bg-success/15 text-success text-[10px] font-bold flex-shrink-0 mt-0.5">
                      ✓
                    </span>
                    <span className="leading-relaxed">{g}</span>
                  </li>
                ))}
              </ul>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/10 text-friction">
                  <AlertTriangle className="h-3.5 w-3.5" />
                </div>
                <span className="text-sm font-semibold text-ink">Frustrations</span>
              </div>
              <ul className="space-y-2">
                {persona.frustrations.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-ink">
                    <span className="flex h-4 w-4 items-center justify-center rounded bg-friction/15 text-friction text-[10px] font-bold flex-shrink-0 mt-0.5">
                      !
                    </span>
                    <span className="leading-relaxed">{f}</span>
                  </li>
                ))}
              </ul>
            </Card>
          </div>

          {/* Behaviors card */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/10 text-info">
                <Activity className="h-3.5 w-3.5" />
              </div>
              <span className="text-sm font-semibold text-ink">Behaviors</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {persona.behaviors.map((b) => (
                <Badge
                  key={b}
                  variant="outline"
                  className="text-[10px] border-info/20 bg-info/10 text-info"
                >
                  {b}
                </Badge>
              ))}
            </div>
          </Card>
        </div>

        {/* RIGHT column */}
        <div className="space-y-4">
          {/* Devices used */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-ink">Devices used</span>
              <Badge variant="secondary" className="text-[10px]">
                {persona.devices.length} devices
              </Badge>
            </div>
            <div>
              {persona.devices.map((d) => (
                <DeviceRow key={d} device={d} />
              ))}
            </div>
          </Card>

          {/* Segments */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Layers className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-sm font-semibold text-ink">Segments</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <Badge variant="outline" className="text-[10px] border-primary/20 bg-primary/10 text-primary">
                {persona.segment}
              </Badge>
              <Badge variant="secondary" className="text-[10px]">Daily active</Badge>
              <Badge variant="secondary" className="text-[10px]">Decision-maker</Badge>
              <Badge variant="secondary" className="text-[10px]">Power user</Badge>
            </div>
            <Link
              href="/segments"
              className="inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-ink mt-3 transition-colors"
            >
              View all segments <ChevronRight className="h-3 w-3" />
            </Link>
          </Card>

          {/* Related research studies */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Mic className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-sm font-semibold text-ink">Related studies</span>
            </div>
            <div className="space-y-2">
              {RELATED_STUDIES.map((s) => (
                <Link
                  key={s.id}
                  href={`/research/${s.id}`}
                  className="block p-2.5 rounded-xl hover:bg-accent/30 transition-colors group"
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-medium text-ink group-hover:text-primary transition-colors line-clamp-1">
                      {s.title}
                    </span>
                    <StatusBadge status={s.status} />
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span className="truncate">{s.method}</span>
                    <span className="flex items-center gap-1 flex-shrink-0">
                      <CalendarDays className="h-3 w-3" />
                      {s.date}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </Card>

          {/* Verbatim quotes gallery */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Quote className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-sm font-semibold text-ink">Verbatim quotes</span>
            </div>
            <div className="space-y-2.5">
              {VERBATIM_QUOTES.map((q, i) => (
                <div key={i} className="rounded-xl bg-surface-2/40 p-3">
                  <p className="text-xs italic text-ink leading-relaxed">
                    &ldquo;{q.quote}&rdquo;
                  </p>
                  <div className="flex items-center justify-between gap-2 mt-2 text-[10px] text-muted-foreground">
                    <span className="truncate">{q.context}</span>
                    <span className="flex-shrink-0 font-mono">{q.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
