"use client";

import * as React from "react";
import Link from "next/link";
import {
  Users,
  Quote,
  Target,
  AlertTriangle,
  Activity,
  Smartphone,
  Monitor,
  Tablet,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PERSONAS, type Persona } from "@/lib/data";

// ----------------------------------------------------------------------------
// Device icon helper
// ----------------------------------------------------------------------------

function DeviceBadge({ device }: { device: string }) {
  let Icon = Monitor;
  if (device.toLowerCase().includes("iphone") || device.toLowerCase().includes("pixel") || device.toLowerCase().includes("android")) {
    Icon = Smartphone;
  } else if (device.toLowerCase().includes("ipad") || device.toLowerCase().includes("tablet")) {
    Icon = Tablet;
  }
  return (
    <Badge variant="outline" className="text-[10px] gap-1 border-soft bg-surface-2/50">
      <Icon className="h-3 w-3" />
      {device}
    </Badge>
  );
}

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function PersonasPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  return (
    <div>
      <PageHeader
        title="Personas"
        description="Research-backed personas with goals, frustrations, and behaviors"
        breadcrumbs={[{ label: "Personas" }]}
        icon={<Users className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {PERSONAS.length} personas
          </Badge>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : PERSONAS.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No personas yet"
          description="Create research-backed personas to anchor design decisions in real user needs."
          action={{ label: "Browse research", href: "/research" }}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {PERSONAS.map((p) => (
            <PersonaCard key={p.id} persona={p} />
          ))}
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// Persona card
// ----------------------------------------------------------------------------

function PersonaCard({ persona }: { persona: Persona }) {
  return (
    <Link href={`/personas/${persona.id}`} className="group">
      <Card className="rounded-2xl border-soft shadow-soft p-5 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
        {/* Header: avatar + name + meta */}
        <div className="flex items-start gap-4 mb-4">
          <Avatar className="h-16 w-16 ring-2 ring-soft flex-shrink-0">
            <AvatarImage src={persona.avatar} alt={persona.name} />
            <AvatarFallback>{persona.name.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-base font-semibold text-ink group-hover:text-primary transition-colors">
                {persona.name}
              </span>
              <Badge variant="secondary" className="text-[10px]">
                {persona.segment}
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground mt-0.5">
              {persona.role} · {persona.age} years
            </div>
            <div className="flex flex-wrap gap-1 mt-2">
              {persona.devices.map((d) => (
                <DeviceBadge key={d} device={d} />
              ))}
            </div>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink transition-colors flex-shrink-0" />
        </div>

        {/* Quote */}
        <div className="rounded-xl bg-surface-2/40 p-3 mb-4 flex items-start gap-2">
          <Quote className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
          <p className="text-xs italic text-ink leading-relaxed">
            {persona.quote}
          </p>
        </div>

        {/* Goals + frustrations grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <Target className="h-3.5 w-3.5 text-success" />
              <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">
                Goals
              </span>
            </div>
            <ul className="space-y-1.5">
              {persona.goals.map((g, i) => (
                <li key={i} className="flex items-start gap-1.5 text-xs text-ink">
                  <span className="text-success mt-0.5">✓</span>
                  <span className="leading-relaxed">{g}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <AlertTriangle className="h-3.5 w-3.5 text-friction" />
              <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">
                Frustrations
              </span>
            </div>
            <ul className="space-y-1.5">
              {persona.frustrations.map((f, i) => (
                <li key={i} className="flex items-start gap-1.5 text-xs text-ink">
                  <span className="text-friction mt-0.5">!</span>
                  <span className="leading-relaxed">{f}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Behaviors */}
        <div className="mt-auto pt-3 border-t border-soft">
          <div className="flex items-center gap-1.5 mb-2">
            <Activity className="h-3.5 w-3.5 text-info" />
            <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">
              Behaviors
            </span>
          </div>
          <div className="flex flex-wrap gap-1">
            {persona.behaviors.map((b) => (
              <Badge
                key={b}
                variant="outline"
                className="text-[10px] border-info/20 bg-info/10 text-info"
              >
                {b}
              </Badge>
            ))}
          </div>
        </div>
      </Card>
    </Link>
  );
}
