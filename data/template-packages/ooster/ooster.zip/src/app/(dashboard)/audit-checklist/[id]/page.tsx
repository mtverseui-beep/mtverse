"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  ClipboardCheck,
  Download,
  Share2,
  CheckCircle2,
  CircleDashed,
  Filter,
  User,
  Calendar,
  Flag,
  Link2,
  PenLine,
  ShieldCheck,
  Accessibility,
  Keyboard,
  Eye,
  AlertTriangle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { CircleProgress } from "@/components/common/circle-progress";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const av = (seed: number) => `https://i.pravatar.cc/80?img=${seed}`;

interface AuditItem {
  id: string;
  category: "Keyboard & focus" | "Contrast & color" | "Forms & labels" | "Layout & structure";
  title: string;
  description: string;
  severity: "critical" | "high" | "medium" | "low";
  evidence: string;
  done: boolean;
  notes: string;
}

const AUDIT_ITEMS: AuditItem[] = [
  // Keyboard & focus
  {
    id: "a1",
    category: "Keyboard & focus",
    title: "Skip-to-content link present and visible on focus",
    description:
      "First focusable element on every page must be a same-page skip link. Verify it appears on Tab focus and moves focus to the main content region.",
    severity: "high",
    evidence: "/heatmaps",
    done: true,
    notes: "Skip link present on all 24 screens. Verified with VoiceOver + NVDA.",
  },
  {
    id: "a2",
    category: "Keyboard & focus",
    title: "Logical tab order matches reading order",
    description:
      "Tab navigation must follow the visual reading order top-to-bottom, left-to-right. No focus traps, no skipped interactive elements.",
    severity: "critical",
    evidence: "/session-replays",
    done: true,
    notes: "Found and fixed 2 violations on date-picker and modal dialogs.",
  },
  {
    id: "a3",
    category: "Keyboard & focus",
    title: "Visible focus indicator on every interactive element",
    description:
      "All interactive elements (links, buttons, inputs, custom widgets) must show a visible focus ring on keyboard focus. Min 3:1 contrast against background.",
    severity: "high",
    evidence: "/screens",
    done: false,
    notes: "",
  },
  // Contrast & color
  {
    id: "a4",
    category: "Contrast & color",
    title: "Body text contrast ≥ 4.5:1 (WCAG AA)",
    description:
      "All body text smaller than 18pt (or 14pt bold) must meet 4.5:1 contrast ratio against its background. Use the WCAG contrast checker.",
    severity: "high",
    evidence: "/heatmaps",
    done: true,
    notes: "All text meets AA. Two grey-on-grey cases fixed in last sprint.",
  },
  {
    id: "a5",
    category: "Contrast & color",
    title: "Large text and UI components ≥ 3:1 contrast",
    description:
      "Text 18pt+ (or 14pt+ bold) and UI component boundaries (button outlines, input borders, icon meaning) must meet 3:1 contrast.",
    severity: "medium",
    evidence: "/screens",
    done: false,
    notes: "",
  },
  {
    id: "a6",
    category: "Contrast & color",
    title: "Color is not the only means of conveying information",
    description:
      "Error states, success states, and required-field indicators must not rely on color alone. Pair color with icon, text, or pattern.",
    severity: "critical",
    evidence: "/insights",
    done: false,
    notes: "",
  },
  // Forms & labels
  {
    id: "a7",
    category: "Forms & labels",
    title: "All form inputs have programmatic labels",
    description:
      "Every input, select, and textarea must have an associated <label>, aria-label, or aria-labelledby. Placeholder is not a label.",
    severity: "critical",
    evidence: "/issues",
    done: true,
    notes: "All 38 form inputs verified. Two placeholder-only fields fixed.",
  },
  {
    id: "a8",
    category: "Forms & labels",
    title: "Error messages are announced and associated",
    description:
      "Form errors must use aria-invalid, aria-describedby pointing to the error text, and the error text must have role='alert' or aria-live='assertive'.",
    severity: "high",
    evidence: "/issues",
    done: false,
    notes: "",
  },
  {
    id: "a9",
    category: "Forms & labels",
    title: "Required fields are programmatically indicated",
    description:
      "Use the `required` attribute or aria-required='true'. Visual required indicators (asterisk) must also have a text alternative.",
    severity: "medium",
    evidence: "/screens",
    done: true,
    notes: "Required attribute present on all 24 required inputs across checkout.",
  },
  // Layout & structure
  {
    id: "a10",
    category: "Layout & structure",
    title: "Page has landmark regions (header, nav, main, footer)",
    description:
      "Every page must use HTML5 landmark elements or ARIA landmark roles. Each landmark must appear exactly once except for complementary and region.",
    severity: "high",
    evidence: "/screens",
    done: true,
    notes: "All 24 screens use semantic landmarks. Verified with axe-core.",
  },
  {
    id: "a11",
    category: "Layout & structure",
    title: "Headings are properly nested (h1 → h2 → h3)",
    description:
      "Heading levels must not skip (no h2 → h4). Each page must have exactly one h1. Headings must describe their content, not be used for styling.",
    severity: "medium",
    evidence: "/heatmaps",
    done: false,
    notes: "",
  },
  {
    id: "a12",
    category: "Layout & structure",
    title: "Responsive at 320px, 768px, 1024px, 1440px viewports",
    description:
      "All screens must reflow without horizontal scroll at 320px. Text must remain readable, touch targets ≥ 44×44px, no overlapping content.",
    severity: "high",
    evidence: "/screens",
    done: false,
    notes: "",
  },
];

const CATEGORY_ICONS: Record<AuditItem["category"], React.ComponentType<{ className?: string }>> = {
  "Keyboard & focus": Keyboard,
  "Contrast & color": Eye,
  "Forms & labels": PenLine,
  "Layout & structure": ShieldCheck,
};

const SEVERITY_STYLES: Record<string, string> = {
  critical: "bg-friction/15 text-friction border-friction/20",
  high: "bg-warning/15 text-warning border-warning/20",
  medium: "bg-info/15 text-info border-info/20",
  low: "bg-muted text-muted-foreground border-border",
};

const SEVERITY_DOT: Record<string, string> = {
  critical: "bg-friction",
  high: "bg-warning",
  medium: "bg-info",
  low: "bg-muted-foreground",
};

export default function AuditChecklistDetailPage() {
  const params = useParams<{ id: string }>();
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [items, setItems] = React.useState<AuditItem[]>(AUDIT_ITEMS);
  const [notesDraft, setNotesDraft] = React.useState<Record<string, string>>({});
  const [severityFilter, setSeverityFilter] = React.useState<string>("all");
  const [categoryFilter, setCategoryFilter] = React.useState<string>("all");
  const [statusFilter, setStatusFilter] = React.useState<string>("all");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  // For the mock: accept any id starting with "cl-" as the same checklist; otherwise not-found.
  if (!params.id || !params.id.startsWith("cl-")) {
    return (
      <EmptyState
        icon={ClipboardCheck}
        title="Audit checklist not found"
        description="This checklist may have been archived, deleted, or never existed."
        action={{ label: "Back to checklists", href: "/audit-checklist" }}
      />
    );
  }

  const toggleItem = (id: string) => {
    setItems((prev) =>
      prev.map((it) => (it.id === id ? { ...it, done: !it.done } : it))
    );
    const target = items.find((i) => i.id === id);
    if (target) {
      toast.success(target.done ? "Item unmarked" : "Item marked complete");
    }
  };

  const saveNotes = (id: string) => {
    const val = notesDraft[id];
    if (val === undefined) return;
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, notes: val } : it)));
    setNotesDraft((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    toast.success("Notes saved");
  };

  const categories = Array.from(new Set(items.map((i) => i.category)));
  const doneCount = items.filter((i) => i.done).length;
  const pct = Math.round((doneCount / items.length) * 100);

  const filtered = items.filter((i) => {
    if (severityFilter !== "all" && i.severity !== severityFilter) return false;
    if (categoryFilter !== "all" && i.category !== categoryFilter) return false;
    if (statusFilter === "done" && !i.done) return false;
    if (statusFilter === "todo" && i.done) return false;
    return true;
  });

  const grouped = categories
    .map((cat) => ({
      category: cat,
      items: filtered.filter((i) => i.category === cat),
    }))
    .filter((g) => g.items.length > 0);

  // Category breakdown
  const categoryStats = categories.map((cat) => {
    const catItems = items.filter((i) => i.category === cat);
    const done = catItems.filter((i) => i.done).length;
    return {
      category: cat,
      total: catItems.length,
      done,
      pct: Math.round((done / catItems.length) * 100),
    };
  });

  return (
    <div>
      <PageHeader
        title="Mobile Onboarding Audit"
        description="End-to-end audit of the Atlas mobile onboarding flow — WCAG 2.2 AA + usability heuristics."
        breadcrumbs={[
          { label: "Audit checklists", href: "/audit-checklist" },
          { label: `#${params.id}` },
        ]}
        icon={<Accessibility className="h-5 w-5" />}
        badge={
          <Badge
            variant="outline"
            className={cn(
              "text-[10px] font-medium",
              pct === 100
                ? "bg-success/15 text-success border-success/20"
                : pct >= 50
                ? "bg-warning/15 text-warning border-warning/20"
                : "bg-info/15 text-info border-info/20"
            )}
          >
            {pct}% complete
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Audit report exported as PDF")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export PDF
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => openShare(`/audit-checklist/${params.id}`, "Mobile Onboarding Audit")}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
          </>
        }
      />

      {/* Top: progress summary + category breakdown */}
      <Card className="rounded-2xl border-soft shadow-soft p-4 mb-4">
        <div className="grid grid-cols-1 md:grid-cols-[auto_1fr] gap-6 items-center">
          {/* Circular progress */}
          <div className="flex items-center gap-4 justify-center md:justify-start">
            <CircleProgress
              value={pct}
              size={88}
              strokeWidth={8}
              color={pct === 100 ? "var(--success)" : pct >= 50 ? "var(--warning)" : "var(--info)"}
            >
              <div className="flex flex-col items-center">
                <span className="text-base font-semibold text-ink">{pct}%</span>
                <span className="text-[9px] text-muted-foreground">{doneCount}/{items.length}</span>
              </div>
            </CircleProgress>
            <div className="text-xs">
              <div className="font-semibold text-ink text-sm">Audit progress</div>
              <div className="text-muted-foreground mt-0.5">
                {items.length - doneCount} items remaining
              </div>
              <div className="mt-2 flex items-center gap-1.5">
                <AlertTriangle className="h-3 w-3 text-friction" />
                <span className="text-[10px] text-friction">
                  {items.filter((i) => i.severity === "critical" && !i.done).length} critical open
                </span>
              </div>
            </div>
          </div>

          {/* Category breakdown bars */}
          <div className="space-y-2">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1">
              Category breakdown
            </div>
            {categoryStats.map((c) => {
              const Icon = CATEGORY_ICONS[c.category];
              return (
                <div key={c.category} className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5 w-36 flex-shrink-0">
                    <Icon className="h-3 w-3 text-muted-foreground" />
                    <span className="text-[11px] text-ink truncate">{c.category}</span>
                  </div>
                  <div className="flex-1 h-2 rounded-full bg-surface-2 overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all",
                        c.pct === 100 ? "bg-success" : c.pct >= 50 ? "bg-warning" : "bg-info"
                      )}
                      style={{ width: `${c.pct}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-muted-foreground w-16 text-right flex-shrink-0">
                    {c.done}/{c.total}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* LEFT: grouped checklist */}
        <div className="lg:col-span-2 space-y-4">
          {grouped.length === 0 ? (
            <EmptyState
              icon={Filter}
              title="No items match your filters"
              description="Try a different severity, category, or status filter."
              compact
            />
          ) : (
            grouped.map((group) => {
              const Icon = CATEGORY_ICONS[group.category];
              const groupDone = group.items.filter((i) => i.done).length;
              return (
                <Card key={group.category} className="rounded-2xl border-soft shadow-soft p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                      <Icon className="h-4 w-4" />
                    </div>
                    <h3 className="text-sm font-semibold text-ink">{group.category}</h3>
                    <Badge variant="secondary" className="text-[10px] ml-auto">
                      {groupDone}/{group.items.length}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    {group.items.map((item) => (
                      <div
                        key={item.id}
                        className={cn(
                          "rounded-xl border border-soft p-3 transition-colors",
                          item.done && "bg-success/5"
                        )}
                      >
                        <div className="flex items-start gap-2.5">
                          <Checkbox
                            checked={item.done}
                            onCheckedChange={() => toggleItem(item.id)}
                            className="mt-0.5"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <div
                                className={cn(
                                  "text-xs font-medium leading-snug",
                                  item.done ? "text-muted-foreground line-through" : "text-ink"
                                )}
                              >
                                {item.title}
                              </div>
                              <div className="flex items-center gap-1.5 flex-shrink-0">
                                <span className={cn("h-1.5 w-1.5 rounded-full", SEVERITY_DOT[item.severity])} />
                                <Badge
                                  variant="outline"
                                  className={cn("text-[9px] capitalize", SEVERITY_STYLES[item.severity])}
                                >
                                  {item.severity}
                                </Badge>
                              </div>
                            </div>
                            <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">
                              {item.description}
                            </p>
                            <div className="flex items-center gap-3 mt-2">
                              <Link
                                href={item.evidence}
                                className="flex items-center gap-1 text-[10px] text-info hover:underline"
                              >
                                <Link2 className="h-3 w-3" />
                                View evidence
                              </Link>
                              {item.done && (
                                <span className="flex items-center gap-1 text-[10px] text-success">
                                  <CheckCircle2 className="h-3 w-3" />
                                  Resolved
                                </span>
                              )}
                              {!item.done && (
                                <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                                  <CircleDashed className="h-3 w-3" />
                                  Pending
                                </span>
                              )}
                            </div>
                            {/* Notes input */}
                            <div className="mt-2 flex items-start gap-2">
                              <Textarea
                                value={notesDraft[item.id] ?? item.notes}
                                onChange={(e) =>
                                  setNotesDraft((prev) => ({ ...prev, [item.id]: e.target.value }))
                                }
                                placeholder="Add auditor notes…"
                                className="min-h-[44px] text-[11px] resize-none"
                              />
                              {notesDraft[item.id] !== undefined && notesDraft[item.id] !== item.notes && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 rounded-full text-[10px] flex-shrink-0"
                                  onClick={() => saveNotes(item.id)}
                                >
                                  Save
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              );
            })
          )}
        </div>

        {/* RIGHT: filters + audit info */}
        <div className="space-y-4">
          {/* Filters */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Filters</h3>
              {(severityFilter !== "all" || categoryFilter !== "all" || statusFilter !== "all") && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-auto h-6 text-[10px]"
                  onClick={() => {
                    setSeverityFilter("all");
                    setCategoryFilter("all");
                    setStatusFilter("all");
                  }}
                >
                  Clear
                </Button>
              )}
            </div>
            <div className="space-y-3">
              <div>
                <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  Severity
                </Label>
                <Select value={severityFilter} onValueChange={setSeverityFilter}>
                  <SelectTrigger className="h-8 text-xs mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All severities</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  Category
                </Label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="h-8 text-xs mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All categories</SelectItem>
                    {categories.map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  Status
                </Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="h-8 text-xs mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="done">Resolved</SelectItem>
                    <SelectItem value="todo">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>

          {/* Audit info */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Audit info</h3>
            </div>
            <dl className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-muted-foreground">
                  <User className="h-3 w-3" />
                  Auditor
                </dt>
                <dd className="flex items-center gap-2">
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={av(48)} alt="Aria Mendez" />
                    <AvatarFallback>AM</AvatarFallback>
                  </Avatar>
                  <span className="text-ink">Aria Mendez</span>
                </dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-muted-foreground">
                  <Flag className="h-3 w-3" />
                  Project
                </dt>
                <dd className="text-ink">Atlas Onboarding</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  Started
                </dt>
                <dd className="text-ink">2026-06-20</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  Last updated
                </dt>
                <dd className="text-ink">2026-07-01</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-muted-foreground">
                  <ClipboardCheck className="h-3 w-3" />
                  Standard
                </dt>
                <dd className="text-ink">WCAG 2.2 AA</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="flex items-center gap-1.5 text-muted-foreground">
                  <Accessibility className="h-3 w-3" />
                  Framework
                </dt>
                <dd className="text-ink">axe-core + manual</dd>
              </div>
            </dl>
          </Card>

          {/* Sign-off */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <ShieldCheck className="h-4 w-4 text-success" />
              <h3 className="text-sm font-semibold text-ink">Sign-off</h3>
            </div>
            <div className="rounded-xl border border-soft bg-surface-2/40 p-3 mb-3">
              <div className="flex items-center gap-2 mb-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={av(12)} alt="Mira Halberg" />
                  <AvatarFallback>MH</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <div className="text-xs font-medium text-ink">Mira Halberg</div>
                  <div className="text-[10px] text-muted-foreground">Lead Researcher · Approver</div>
                </div>
              </div>
              <Input
                placeholder="Approver signature / initials"
                className="h-8 text-xs"
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                className="rounded-full text-xs flex-1"
                disabled={pct < 100}
                onClick={() => toast.success(pct < 100 ? "Resolve all items first" : "Audit approved and signed off")}
              >
                <ShieldCheck className="mr-1.5 h-3 w-3" />
                {pct < 100 ? `Resolve all items to sign off` : "Approve audit"}
              </Button>
            </div>
            {pct < 100 && (
              <div className="text-[10px] text-muted-foreground mt-2 text-center">
                {items.length - doneCount} items remaining before sign-off
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
