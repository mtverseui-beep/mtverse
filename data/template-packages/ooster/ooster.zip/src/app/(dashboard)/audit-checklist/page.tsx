"use client";

import * as React from "react";
import Link from "next/link";
import {
  ClipboardCheck,
  Plus,
  Download,
  ChevronRight,
  Smartphone,
  ShoppingCart,
  Component,
  MousePointerClick,
  Accessibility,
  Map,
  Calendar,
  User,
  CheckCircle2,
  CircleDashed,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const av = (seed: number) => `https://i.pravatar.cc/80?img=${seed}`;

interface ChecklistSummary {
  id: string;
  name: string;
  description: string;
  category: "mobile" | "checkout" | "design-system" | "usability" | "accessibility" | "journey";
  totalItems: number;
  completedItems: number;
  lastUpdated: string;
  owner: { name: string; avatar: string };
  auditor: string;
}

const CHECKLISTS: ChecklistSummary[] = [
  {
    id: "cl-001",
    name: "Mobile Onboarding Audit",
    description:
      "End-to-end audit of the Atlas mobile onboarding flow — KYC, wallet setup, and first transfer. Covers first-tap to activation.",
    category: "mobile",
    totalItems: 24,
    completedItems: 18,
    lastUpdated: "2026-07-01",
    owner: { name: "Mira Halberg", avatar: av(12) },
    auditor: "Aria Mendez",
  },
  {
    id: "cl-002",
    name: "Checkout WCAG Audit",
    description:
      "WCAG 2.2 AA conformance audit for the Northwind checkout flow — keyboard nav, focus management, contrast, ARIA labels.",
    category: "checkout",
    totalItems: 32,
    completedItems: 27,
    lastUpdated: "2026-06-30",
    owner: { name: "Aria Mendez", avatar: av(48) },
    auditor: "Idris Khoury",
  },
  {
    id: "cl-003",
    name: "Design System Component Audit",
    description:
      "Audit of all Riverside design-system components against the latest usage guidelines — props, variants, accessibility, documentation.",
    category: "design-system",
    totalItems: 48,
    completedItems: 31,
    lastUpdated: "2026-06-28",
    owner: { name: "Theo Park", avatar: av(13) },
    auditor: "Mira Halberg",
  },
  {
    id: "cl-004",
    name: "Prototype Usability Checklist",
    description:
      "Usability heuristics checklist for the Helix clinician dashboard prototype — Nielsen's 10 + 5 healthcare-specific heuristics.",
    category: "usability",
    totalItems: 18,
    completedItems: 12,
    lastUpdated: "2026-06-29",
    owner: { name: "Lena Ortiz", avatar: av(45) },
    auditor: "Aria Mendez",
  },
  {
    id: "cl-005",
    name: "Accessibility Audit AA",
    description:
      "Full WCAG 2.2 AA accessibility audit across all Voyage Booking screens — automated axe-core + manual screen reader verification.",
    category: "accessibility",
    totalItems: 56,
    completedItems: 38,
    lastUpdated: "2026-06-27",
    owner: { name: "Aria Mendez", avatar: av(48) },
    auditor: "Idris Khoury",
  },
  {
    id: "cl-006",
    name: "Journey Mapping Checklist",
    description:
      "End-to-end journey-mapping checklist for the Cadence Mobile notification flow — covers trigger, delivery, interaction, and unsubscribe states.",
    category: "journey",
    totalItems: 20,
    completedItems: 14,
    lastUpdated: "2026-06-25",
    owner: { name: "Idris Khoury", avatar: av(33) },
    auditor: "Sana Iqbal",
  },
];

const CATEGORY_META: Record<
  ChecklistSummary["category"],
  { icon: React.ComponentType<{ className?: string }>; label: string; color: string }
> = {
  mobile: { icon: Smartphone, label: "Mobile", color: "bg-info/15 text-info border-info/20" },
  checkout: { icon: ShoppingCart, label: "Checkout", color: "bg-success/15 text-success border-success/20" },
  "design-system": { icon: Component, label: "Design system", color: "bg-warning/15 text-warning border-warning/20" },
  usability: { icon: MousePointerClick, label: "Usability", color: "bg-friction/15 text-friction border-friction/20" },
  accessibility: { icon: Accessibility, label: "Accessibility", color: "bg-info/15 text-info border-info/20" },
  journey: { icon: Map, label: "Journey", color: "bg-muted text-muted-foreground border-border" },
};

export default function AuditChecklistPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const totalChecklists = CHECKLISTS.length;
  const totalItems = CHECKLISTS.reduce((s, c) => s + c.totalItems, 0);
  const completedItems = CHECKLISTS.reduce((s, c) => s + c.completedItems, 0);
  const overallPct = Math.round((completedItems / totalItems) * 100);
  const completedAudits = CHECKLISTS.filter((c) => c.completedItems === c.totalItems).length;

  return (
    <div>
      <PageHeader
        title="UX Audit Checklist"
        description="WCAG, usability, and design system audit checklists for systematic reviews"
        icon={<ClipboardCheck className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {CHECKLISTS.length} checklists
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Audit summary exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Opening new audit checklist wizard…")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> New audit
            </Button>
          </>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Audit checklists"
          value={totalChecklists}
          icon={<ClipboardCheck className="h-4 w-4" />}
          accent="info"
          sublabel="active this quarter"
        />
        <StatCard
          label="Total items"
          value={totalItems}
          icon={<CircleDashed className="h-4 w-4" />}
          accent="default"
          sublabel={`${completedItems} completed`}
        />
        <StatCard
          label="Overall progress"
          value={`${overallPct}%`}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          trend={{ value: 6, direction: "up", good: true }}
          sublabel="vs last month"
        />
        <StatCard
          label="Completed audits"
          value={completedAudits}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="warning"
          sublabel="all items resolved"
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : CHECKLISTS.length === 0 ? (
        <EmptyState
          icon={ClipboardCheck}
          title="No audit checklists yet"
          description="Start a WCAG, usability, or design-system audit to systematically review your product."
          action={{ label: "New audit", onClick: () => toast.message("Opening new audit checklist wizard…") }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CHECKLISTS.map((c) => {
            const cat = CATEGORY_META[c.category];
            const Icon = cat.icon;
            const pct = Math.round((c.completedItems / c.totalItems) * 100);
            const isComplete = c.completedItems === c.totalItems;
            return (
              <Link key={c.id} href={`/audit-checklist/${c.id}`} className="group">
                <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
                  {/* Header */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-surface-2 text-primary">
                        <Icon className="h-4 w-4" />
                      </div>
                      <Badge variant="outline" className={cn("text-[10px]", cat.color)}>
                        {cat.label}
                      </Badge>
                    </div>
                    {isComplete ? (
                      <Badge variant="outline" className="text-[10px] bg-success/15 text-success border-success/20">
                        <CheckCircle2 className="h-2.5 w-2.5 mr-1" /> Done
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-[10px] text-muted-foreground">
                        In progress
                      </Badge>
                    )}
                  </div>

                  {/* Name + description */}
                  <h3 className="text-sm font-semibold text-ink group-hover:text-primary transition-colors line-clamp-1">
                    {c.name}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2 flex-1">{c.description}</p>

                  {/* Progress */}
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-[10px] mb-1">
                      <span className="text-muted-foreground">
                        {c.completedItems} / {c.totalItems} items
                      </span>
                      <span className="font-medium text-ink">{pct}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all",
                          isComplete ? "bg-success" : pct >= 50 ? "bg-warning" : "bg-info"
                        )}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="mt-3 pt-3 border-t border-soft flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <Avatar className="h-6 w-6 ring-1 ring-soft flex-shrink-0">
                        <AvatarImage src={c.owner.avatar} alt={c.owner.name} />
                        <AvatarFallback>{c.owner.name.slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div className="text-[10px] text-muted-foreground truncate">
                        <div className="flex items-center gap-1 truncate">
                          <User className="h-2.5 w-2.5" />
                          <span className="truncate">{c.owner.name}</span>
                        </div>
                        <div className="flex items-center gap-1 mt-0.5">
                          <Calendar className="h-2.5 w-2.5" />
                          <span>{c.lastUpdated}</span>
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink transition-colors flex-shrink-0" />
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
