"use client";

import * as React from "react";
import Link from "next/link";
import {
  Lightbulb,
  Download,
  Target,
  Gauge,
  CheckCircle2,
  Zap,
  TrendingUp,
  Sparkles,
  ArrowRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Recommendation {
  id: string;
  title: string;
  description: string;
  category: "usability" | "accessibility" | "conversion" | "engagement" | "performance" | "clarity";
  priority: "P0" | "P1" | "P2" | "P3";
  status: "suggested" | "in-progress" | "implemented" | "deferred";
  impact: number;
  confidence: number;
  ease: number;
  owner: { name: string; avatar: string };
  project: string;
  effort: "low" | "medium" | "high";
}

const av = (seed: number) => `https://i.pravatar.cc/80?img=${seed}`;

const RECOMMENDATIONS: Recommendation[] = [
  {
    id: "r-001",
    title: "Add inline validation to checkout address fields",
    description:
      "42% of checkout errors are address-related and only surface on submit. Validate on blur, show green check on success, and remove the inline 'Edit' toggle on each field.",
    category: "conversion",
    priority: "P0",
    status: "in-progress",
    impact: 87,
    confidence: 92,
    ease: 64,
    owner: { name: "Sana Iqbal", avatar: av(20) },
    project: "Northwind Checkout",
    effort: "medium",
  },
  {
    id: "r-002",
    title: "Reorder form fields to match mental model",
    description:
      "Tree testing shows users expect email → password → confirm. Current order (email → confirm → password) adds 4.2s median completion time and 11% error rate.",
    category: "usability",
    priority: "P1",
    status: "suggested",
    impact: 72,
    confidence: 84,
    ease: 91,
    owner: { name: "Theo Park", avatar: av(13) },
    project: "Atlas Onboarding",
    effort: "low",
  },
  {
    id: "r-003",
    title: "Lift color contrast on primary buttons to WCAG AAA",
    description:
      "Primary CTA is 3.9:1 — fails AA. Bumping from #4F46E5 to #3730A3 reaches 8.4:1 (AAA). Zero visual design trade-off, fully reversible via design token.",
    category: "accessibility",
    priority: "P1",
    status: "suggested",
    impact: 68,
    confidence: 99,
    ease: 96,
    owner: { name: "Aria Mendez", avatar: av(48) },
    project: "Riverside Design System",
    effort: "low",
  },
  {
    id: "r-004",
    title: "Replace 'Continue' button with context-specific labels",
    description:
      "Vague 'Continue' label on 6 screens. Replace with 'Continue to payment', 'Continue to review', etc. Heatmaps show hesitation peaks at every Continue button.",
    category: "clarity",
    priority: "P2",
    status: "suggested",
    impact: 54,
    confidence: 78,
    ease: 88,
    owner: { name: "Mira Halberg", avatar: av(12) },
    project: "Northwind Checkout",
    effort: "low",
  },
  {
    id: "r-005",
    title: "Defer push permission prompt until after first action",
    description:
      "Push prompt fires on app launch with 29% grant rate. Postponing until after first completed action should lift grant rate by ~20pp based on similar apps.",
    category: "engagement",
    priority: "P0",
    status: "in-progress",
    impact: 91,
    confidence: 88,
    ease: 52,
    owner: { name: "Idris Khoury", avatar: av(33) },
    project: "Cadence Mobile",
    effort: "medium",
  },
  {
    id: "r-006",
    title: "Lazy-load heatmap viewer payloads >2MB",
    description:
      "Heatmap viewer takes 4.8s to render on 5MB+ payloads. Implement chunked tile loading and progressive rendering to cut TTI below 1.5s.",
    category: "performance",
    priority: "P2",
    status: "suggested",
    impact: 61,
    confidence: 95,
    ease: 41,
    owner: { name: "Idris Khoury", avatar: av(33) },
    project: "Atlas Onboarding",
    effort: "high",
  },
  {
    id: "r-007",
    title: "Add empty-state guidance for new PM insights view",
    description:
      "New PMs see an empty insights list with no guidance. Add a 3-step onboarding card with sample insights to seed expectations.",
    category: "usability",
    priority: "P3",
    status: "implemented",
    impact: 48,
    confidence: 82,
    ease: 79,
    owner: { name: "Lena Ortiz", avatar: av(45) },
    project: "Helix Prototype",
    effort: "low",
  },
  {
    id: "r-008",
    title: "Consolidate 3 filter UIs into one shared component",
    description:
      "Three slightly different filter bars exist (Issues, Insights, Reports). Unify into the shared FilterBar component — consistency win plus easier to maintain.",
    category: "clarity",
    priority: "P3",
    status: "deferred",
    impact: 39,
    confidence: 71,
    ease: 35,
    owner: { name: "Mira Halberg", avatar: av(12) },
    project: "Riverside Design System",
    effort: "high",
  },
  {
    id: "r-009",
    title: "Add 'Skip to content' link as first focusable element",
    description:
      "No skip link on any project. Adding one is a 5-line change per layout and resolves the #1 keyboard-navigation complaint from AT users.",
    category: "accessibility",
    priority: "P1",
    status: "implemented",
    impact: 74,
    confidence: 96,
    ease: 92,
    owner: { name: "Aria Mendez", avatar: av(48) },
    project: "Atlas Onboarding",
    effort: "low",
  },
];

const CATEGORY_OPTIONS: FilterOption[] = [
  { label: "All categories", value: "all" },
  { label: "Usability", value: "usability" },
  { label: "Accessibility", value: "accessibility" },
  { label: "Conversion", value: "conversion" },
  { label: "Engagement", value: "engagement" },
  { label: "Performance", value: "performance" },
  { label: "Clarity", value: "clarity" },
];

const PRIORITY_OPTIONS: FilterOption[] = [
  { label: "All priorities", value: "all" },
  { label: "P0 — urgent", value: "P0" },
  { label: "P1 — high", value: "P1" },
  { label: "P2 — medium", value: "P2" },
  { label: "P3 — low", value: "P3" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Suggested", value: "suggested" },
  { label: "In progress", value: "in-progress" },
  { label: "Implemented", value: "implemented" },
  { label: "Deferred", value: "deferred" },
];

const CATEGORY_STYLES: Record<string, string> = {
  usability: "bg-info/15 text-info border-info/20",
  accessibility: "bg-warning/15 text-warning border-warning/20",
  conversion: "bg-success/15 text-success border-success/20",
  engagement: "bg-friction/15 text-friction border-friction/20",
  performance: "bg-info/15 text-info border-info/20",
  clarity: "bg-muted text-muted-foreground border-border",
};

const PRIORITY_STYLES: Record<string, string> = {
  P0: "bg-friction/15 text-friction border-friction/20",
  P1: "bg-warning/15 text-warning border-warning/20",
  P2: "bg-info/15 text-info border-info/20",
  P3: "bg-muted text-muted-foreground border-border",
};

const STATUS_STYLES: Record<string, string> = {
  suggested: "bg-info/15 text-info border-info/20",
  "in-progress": "bg-warning/15 text-warning border-warning/20",
  implemented: "bg-success/15 text-success border-success/20",
  deferred: "bg-muted text-muted-foreground border-border",
};

const iceScore = (r: Recommendation) =>
  Math.round((r.impact * r.confidence * r.ease) / 10000);

export default function RecommendationsPage() {
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("all");
  const [priority, setPriority] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return RECOMMENDATIONS.filter((r) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !r.title.toLowerCase().includes(q) &&
          !r.description.toLowerCase().includes(q) &&
          !r.project.toLowerCase().includes(q)
        )
          return false;
      }
      if (category !== "all" && r.category !== category) return false;
      if (priority !== "all" && r.priority !== priority) return false;
      if (status !== "all" && r.status !== status) return false;
      return true;
    }).sort((a, b) => iceScore(b) - iceScore(a));
  }, [search, category, priority, status]);

  const clearFilters = () => {
    setSearch("");
    setCategory("all");
    setPriority("all");
    setStatus("all");
  };

  const total = RECOMMENDATIONS.length;
  const highImpact = RECOMMENDATIONS.filter((r) => r.impact >= 70).length;
  const implemented = RECOMMENDATIONS.filter((r) => r.status === "implemented").length;
  const avgIce = Math.round(
    RECOMMENDATIONS.reduce((s, r) => s + iceScore(r), 0) / RECOMMENDATIONS.length
  );

  return (
    <div>
      <PageHeader
        title="Recommendations"
        description="AI-prioritized recommendations ranked by ICE score (Impact × Confidence × Ease)"
        icon={<Lightbulb className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {RECOMMENDATIONS.length} recommendations
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Recommendations exported as CSV")}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export
          </Button>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total recommendations"
          value={total}
          icon={<Lightbulb className="h-4 w-4" />}
          accent="info"
          sublabel="across all projects"
        />
        <StatCard
          label="High impact"
          value={highImpact}
          icon={<Target className="h-4 w-4" />}
          accent="friction"
          sublabel="impact score ≥ 70"
        />
        <StatCard
          label="Implemented"
          value={implemented}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          trend={{ value: 8, direction: "up", good: true }}
          sublabel="vs last month"
        />
        <StatCard
          label="Avg ICE score"
          value={avgIce}
          unit="/100"
          icon={<Gauge className="h-4 w-4" />}
          accent="warning"
          sublabel="weighted priority score"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search recommendations…",
          }}
          selects={[
            { label: "Category", value: category, onChange: setCategory, options: CATEGORY_OPTIONS },
            { label: "Priority", value: priority, onChange: setPriority, options: PRIORITY_OPTIONS },
            { label: "Status", value: status, onChange: setStatus, options: STATUS_OPTIONS },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Lightbulb}
          title="No recommendations match your filters"
          description="AI recommendations regenerate nightly based on the latest heatmaps, sessions, and insights. Try adjusting filters."
          action={{ label: "Clear filters", onClick: clearFilters }}
          secondaryAction={{ label: "Generate now", onClick: () => toast.success("Generating fresh recommendations…") }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((r) => {
            const ice = iceScore(r);
            return (
              <Card
                key={r.id}
                className="rounded-2xl border-soft shadow-soft p-4 hover:shadow-card hover:border-primary/30 transition-all flex flex-col"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Badge variant="outline" className={cn("text-[10px] capitalize", CATEGORY_STYLES[r.category])}>
                      {r.category}
                    </Badge>
                    <Badge variant="outline" className={cn("text-[10px] font-medium", PRIORITY_STYLES[r.priority])}>
                      {r.priority}
                    </Badge>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="text-[9px] uppercase tracking-wide text-muted-foreground">ICE</div>
                    <div
                      className={cn(
                        "text-base font-semibold",
                        ice >= 70 ? "text-success" : ice >= 50 ? "text-warning" : "text-friction"
                      )}
                    >
                      {ice}
                    </div>
                  </div>
                </div>

                {/* Title */}
                <Link href={`/recommendations/${r.id}`} className="group">
                  <h3 className="text-sm font-semibold text-ink group-hover:text-primary transition-colors line-clamp-2">
                    {r.title}
                  </h3>
                </Link>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2 flex-1">{r.description}</p>

                {/* ICE breakdown */}
                <div className="space-y-1.5 mt-3">
                  <IceBar label="Impact" value={r.impact} color="var(--friction)" />
                  <IceBar label="Confidence" value={r.confidence} color="var(--info)" />
                  <IceBar label="Ease" value={r.ease} color="var(--success)" />
                </div>

                {/* Status + owner + CTA */}
                <div className="mt-3 pt-3 border-t border-soft flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <Badge variant="outline" className={cn("text-[10px] capitalize", STATUS_STYLES[r.status])}>
                      {r.status.replace("-", " ")}
                    </Badge>
                    <Avatar className="h-6 w-6 ring-1 ring-soft flex-shrink-0">
                      <AvatarImage src={r.owner.avatar} alt={r.owner.name} />
                      <AvatarFallback>{r.owner.name.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <span className="text-[10px] text-muted-foreground truncate hidden sm:inline">
                      {r.project}
                    </span>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 rounded-full text-xs flex-shrink-0"
                    onClick={() => toast.success(`Started implementation: ${r.title}`)}
                  >
                    <Zap className="mr-1 h-3 w-3" /> Implement
                  </Button>
                </div>
                <Link
                  href={`/recommendations/${r.id}`}
                  className="mt-2 flex items-center justify-center gap-1 text-[10px] text-muted-foreground hover:text-ink transition-colors"
                >
                  View details <ArrowRight className="h-3 w-3" />
                </Link>
              </Card>
            );
          })}
        </div>
      )}

      {/* AI banner */}
      {!loading && (
        <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4 bg-surface-2/40">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary flex-shrink-0">
              <Sparkles className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-ink">AI recommendations refresh nightly</div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Generated from the latest heatmaps, session replays, and insights. Last refresh: 2 hours ago.
              </div>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="rounded-full text-xs flex-shrink-0"
              onClick={() => toast.success("Regenerating recommendations…")}
            >
              <TrendingUp className="mr-1.5 h-3 w-3" /> Regenerate now
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}

function IceBar({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-[10px] mb-0.5">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium text-ink">{value}</span>
      </div>
      <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${value}%`, background: color }}
        />
      </div>
    </div>
  );
}
