"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Lightbulb,
  Share2,
  CheckCircle2,
  XCircle,
  ChevronRight,
  Gauge,
  Layers,
  TrendingUp,
  CircleCheck,
  CircleDashed,
  Target,
  AlertCircle,
  ArrowRight,
  ListChecks,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { CircleProgress } from "@/components/common/circle-progress";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const av = (seed: number) => `https://i.pravatar.cc/80?img=${seed}`;

interface RecommendationDetail {
  id: string;
  title: string;
  category: "conversion";
  priority: "P0" | "P1" | "P2" | "P3";
  status: "in-progress";
  impact: number;
  confidence: number;
  ease: number;
  owner: { name: string; avatar: string };
  project: string;
  effort: "medium";
  description: string[];
  affectedScreens: { name: string; project: string; severity: "high" | "medium" | "low" }[];
  expectedImpact: { metric: string; before: string; after: string; delta: string }[];
  linkedInsights: { id: string; title: string; project: string; impact: number }[];
  linkedIssues: { id: string; title: string; severity: "critical" | "high" | "medium" | "low" }[];
  checklist: { id: string; label: string; done: boolean }[];
  createdAt: string;
  updatedAt: string;
}

const RECOMMENDATION: RecommendationDetail = {
  id: "r-001",
  title: "Add inline validation to checkout address fields",
  category: "conversion",
  priority: "P0",
  status: "in-progress",
  impact: 87,
  confidence: 92,
  ease: 64,
  owner: { name: "Sana Iqbal", avatar: av(20) },
  project: "Northwind Checkout",
  effort: "medium",
  description: [
    "42% of all checkout errors on Northwind Checkout are address-related, and the current implementation only surfaces them after the user taps Submit. By the time the error appears, the user has already mentally moved on — they then have to scroll back, locate the offending field, and re-read the inline error in a different visual position. This adds a median 11.4 seconds per error event, and 8% of users abandon checkout entirely after the second error.",
    "The recommended fix is to validate each address field on blur (not on every keystroke — that's noisy), show a green checkmark icon when valid, and replace the existing per-field 'Edit' toggle with a single 'Edit address' affordance at the bottom of the address block. Inline validation gives immediate feedback, the green checkmark builds momentum, and removing the Edit toggle eliminates a redundant interaction that currently breaks the visual flow.",
    "We've validated this pattern against three competitor checkouts (Apple, Amazon, Shopify) and against the WCAG 3.2.1 (On Input) and 3.3.1 (Error Identification) criteria. The expected lift in checkout completion is +6 to +9 percentage points based on a back-of-envelope calculation using current error rates and abandonment rates. Cart-to-purchase rate is the primary metric; form-error rate and time-on-form are the guardrail metrics we'll watch for regressions.",
    "Implementation is bounded: a single AddressField React component wraps the 5 fields, fires validation on blur, and exposes a `valid` prop for the parent form. Estimated 3 engineering days + 1 design day for the checkmark states. Roll out via the existing ab-test framework — variant B at 50% traffic for 14 days or until 95% significance, whichever comes first. Monitor cart-to-purchase rate as the primary metric, with form-error rate and time-on-form as guardrails.",
  ],
  affectedScreens: [
    { name: "Shipping address form", project: "Northwind Checkout", severity: "high" },
    { name: "Billing address form", project: "Northwind Checkout", severity: "high" },
    { name: "Address review step", project: "Northwind Checkout", severity: "medium" },
    { name: "Saved address picker", project: "Northwind Checkout", severity: "low" },
  ],
  expectedImpact: [
    { metric: "Checkout completion rate", before: "62.0%", after: "69.5%", delta: "+7.5pp" },
    { metric: "Form-error rate per session", before: "0.41", after: "0.12", delta: "-71%" },
    { metric: "Median time on address form", before: "48s", after: "31s", delta: "-35%" },
  ],
  linkedInsights: [
    { id: "i-003", title: "Address autocomplete fails for rural zip codes", project: "Northwind Checkout", impact: 84 },
    { id: "i-007", title: "Submit-time validation causes 8% abandonment", project: "Northwind Checkout", impact: 91 },
  ],
  linkedIssues: [
    { id: "is-001", title: "Address autocomplete fails for rural zip codes", severity: "high" },
    { id: "is-008", title: "Filter icon unclear on mobile search", severity: "medium" },
  ],
  checklist: [
    { id: "c1", label: "Audit current validation logic across all 5 address fields", done: true },
    { id: "c2", label: "Design 3 checkmark / error states in Figma", done: true },
    { id: "c3", label: "Build AddressField React component with on-blur validation", done: true },
    { id: "c4", label: "Wire to ab-test framework at 50% traffic", done: false },
    { id: "c5", label: "Run for 14 days or until 95% significance", done: false },
  ],
  createdAt: "2026-06-22",
  updatedAt: "2026-07-01",
};

const CATEGORY_STYLES: Record<string, string> = {
  conversion: "bg-success/15 text-success border-success/20",
};

const PRIORITY_STYLES: Record<string, string> = {
  P0: "bg-friction/15 text-friction border-friction/20",
  P1: "bg-warning/15 text-warning border-warning/20",
  P2: "bg-info/15 text-info border-info/20",
  P3: "bg-muted text-muted-foreground border-border",
};

const SEVERITY_DOT: Record<string, string> = {
  high: "bg-friction",
  medium: "bg-warning",
  low: "bg-success",
  critical: "bg-friction",
};

export default function RecommendationDetailPage() {
  const params = useParams<{ id: string }>();
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [checklist, setChecklist] = React.useState(RECOMMENDATION.checklist);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  // For the mock: always show the same recommendation but vary title with id so the
  // not-found path is exercised when an unknown id is requested.
  if (params.id !== "r-001" && params.id !== RECOMMENDATION.id) {
    return (
      <EmptyState
        icon={Lightbulb}
        title="Recommendation not found"
        description="This recommendation may have been archived, deferred, or never existed."
        action={{ label: "Back to recommendations", href: "/recommendations" }}
      />
    );
  }

  const r = RECOMMENDATION;
  const ice = Math.round((r.impact * r.confidence * r.ease) / 10000);
  const doneCount = checklist.filter((c) => c.done).length;
  const pct = Math.round((doneCount / checklist.length) * 100);

  const toggleChecklist = (id: string) => {
    setChecklist((prev) =>
      prev.map((c) => (c.id === id ? { ...c, done: !c.done } : c))
    );
    toast.success("Checklist updated");
  };

  return (
    <div>
      <PageHeader
        title={r.title}
        breadcrumbs={[
          { label: "Recommendations", href: "/recommendations" },
          { label: `#${r.id}` },
        ]}
        icon={<Lightbulb className="h-5 w-5" />}
        badge={
          <div className="flex items-center gap-1.5 flex-wrap">
            <Badge variant="outline" className={cn("text-[10px] capitalize", CATEGORY_STYLES[r.category])}>
              {r.category}
            </Badge>
            <Badge variant="outline" className={cn("text-[10px] font-medium", PRIORITY_STYLES[r.priority])}>
              {r.priority}
            </Badge>
            <Badge
              variant="outline"
              className={cn(
                "text-[10px] font-semibold",
                ice >= 70
                  ? "bg-success/15 text-success border-success/20"
                  : ice >= 50
                  ? "bg-warning/15 text-warning border-warning/20"
                  : "bg-friction/15 text-friction border-friction/20"
              )}
            >
              ICE {ice}
            </Badge>
          </div>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Recommendation deferred to next quarter")}
            >
              <XCircle className="mr-2 h-3.5 w-3.5" /> Defer
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => openShare(`/recommendations/${r.id}`, r.title)}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button size="sm" className="rounded-full" onClick={() => toast.success("Marked as implemented")}>
              <CheckCircle2 className="mr-2 h-3.5 w-3.5" /> Implement
            </Button>
          </>
        }
      />

      {/* ICE score card */}
      <Card className="rounded-2xl border-soft shadow-soft p-4 mb-4">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="flex items-center gap-6">
            <div className="text-center">
              <CircleProgress
                value={ice}
                size={88}
                strokeWidth={8}
                color="var(--primary)"
                label={`${ice}`}
                sublabel="ICE"
              />
              <div className="text-[10px] text-muted-foreground mt-1">Composite score</div>
            </div>
            <div className="hidden sm:block w-px h-16 bg-border" />
            <div className="grid grid-cols-3 gap-3 sm:gap-6">
              <IceRing label="Impact" value={r.impact} color="var(--friction)" icon={<Target className="h-3 w-3" />} />
              <IceRing label="Confidence" value={r.confidence} color="var(--info)" icon={<Gauge className="h-3 w-3" />} />
              <IceRing label="Ease" value={r.ease} color="var(--success)" icon={<CircleCheck className="h-3 w-3" />} />
            </div>
          </div>
          <div className="md:ml-auto flex flex-col items-start gap-2 text-xs">
            <div className="flex items-center gap-2 text-muted-foreground">
              <ListChecks className="h-3.5 w-3.5" />
              <span>Effort: <span className="text-ink font-medium capitalize">{r.effort}</span></span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <TrendingUp className="h-3.5 w-3.5" />
              <span>Status: <span className="text-ink font-medium capitalize">{r.status.replace("-", " ")}</span></span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <AlertCircle className="h-3.5 w-3.5" />
              <span>Updated <span className="text-ink font-medium">{r.updatedAt}</span></span>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* LEFT */}
        <div className="lg:col-span-2 space-y-4">
          {/* Recommendation body */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Lightbulb className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Recommendation</h3>
            </div>
            <div className="space-y-3 text-sm text-ink leading-relaxed">
              {r.description.map((p, idx) => (
                <p key={idx}>{p}</p>
              ))}
            </div>
          </Card>

          {/* Affected screens */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-warning">
                <Layers className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Affected screens</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {r.affectedScreens.length} screens
              </Badge>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {r.affectedScreens.map((s, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 rounded-xl border border-soft p-2.5"
                >
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-2 text-muted-foreground flex-shrink-0">
                    <Layers className="h-3.5 w-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink line-clamp-1">{s.name}</div>
                    <div className="text-[10px] text-muted-foreground truncate">{s.project}</div>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className={cn("h-1.5 w-1.5 rounded-full", SEVERITY_DOT[s.severity])} />
                    <span className="text-[10px] text-muted-foreground capitalize">{s.severity}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Expected impact */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <TrendingUp className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Expected impact</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                Modeled · pre-test
              </Badge>
            </div>
            <div className="space-y-2">
              {r.expectedImpact.map((m, idx) => (
                <div
                  key={idx}
                  className="grid grid-cols-[1fr_auto_auto_auto] items-center gap-3 rounded-xl border border-soft p-3"
                >
                  <div className="text-xs font-medium text-ink truncate">{m.metric}</div>
                  <div className="text-[10px] text-muted-foreground text-right">
                    <div className="text-[9px] uppercase tracking-wide">Before</div>
                    <div className="text-ink font-medium">{m.before}</div>
                  </div>
                  <ArrowRight className="h-3 w-3 text-muted-foreground" />
                  <div className="text-right">
                    <div className="text-[9px] uppercase tracking-wide text-muted-foreground">After</div>
                    <div className="text-success font-semibold text-xs">{m.after}</div>
                    <div className="text-[10px] text-success font-medium">{m.delta}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* RIGHT */}
        <div className="space-y-4">
          {/* Metadata */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <h3 className="text-sm font-semibold text-ink mb-3">Metadata</h3>
            <dl className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Owner</dt>
                <dd className="flex items-center gap-2">
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={r.owner.avatar} alt={r.owner.name} />
                    <AvatarFallback>{r.owner.name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <span className="text-ink">{r.owner.name}</span>
                </dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Project</dt>
                <dd className="text-ink">{r.project}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Category</dt>
                <dd className="text-ink capitalize">{r.category}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Priority</dt>
                <dd className="text-ink">{r.priority}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Effort</dt>
                <dd className="text-ink capitalize">{r.effort}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Created</dt>
                <dd className="text-ink">{r.createdAt}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Updated</dt>
                <dd className="text-ink">{r.updatedAt}</dd>
              </div>
            </dl>
          </Card>

          {/* Linked insights */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Lightbulb className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Linked insights</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {r.linkedInsights.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {r.linkedInsights.map((i) => (
                <Link
                  key={i.id}
                  href={`/insights/${i.id}`}
                  className="block rounded-xl border border-soft p-2.5 hover:bg-accent/30 transition-colors group"
                >
                  <div className="text-xs font-medium text-ink group-hover:text-primary line-clamp-1">
                    {i.title}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    {i.project} · Impact {i.impact}/100
                  </div>
                </Link>
              ))}
            </div>
          </Card>

          {/* Linked issues */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Linked issues</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {r.linkedIssues.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {r.linkedIssues.map((i) => (
                <Link
                  key={i.id}
                  href={`/issues/${i.id}`}
                  className="flex items-center gap-2 rounded-xl border border-soft p-2.5 hover:bg-accent/30 transition-colors group"
                >
                  <span className={cn("h-1.5 w-1.5 rounded-full flex-shrink-0", SEVERITY_DOT[i.severity])} />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink group-hover:text-primary line-clamp-1">
                      {i.title}
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 capitalize">
                      {i.severity} · #{i.id}
                    </div>
                  </div>
                  <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-ink flex-shrink-0" />
                </Link>
              ))}
            </div>
          </Card>

          {/* Implementation checklist */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <ListChecks className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Implementation checklist</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {doneCount}/{checklist.length}
              </Badge>
            </div>
            <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden mb-3">
              <div
                className="h-full rounded-full bg-success transition-all"
                style={{ width: `${pct}%` }}
              />
            </div>
            <div className="space-y-2">
              {checklist.map((c) => (
                <label
                  key={c.id}
                  className="flex items-start gap-2.5 rounded-lg p-2 hover:bg-accent/30 transition-colors cursor-pointer"
                >
                  <Checkbox
                    checked={c.done}
                    onCheckedChange={() => toggleChecklist(c.id)}
                    className="mt-0.5"
                  />
                  <div className="flex-1">
                    <div
                      className={cn(
                        "text-xs leading-snug",
                        c.done ? "text-muted-foreground line-through" : "text-ink"
                      )}
                    >
                      {c.label}
                    </div>
                  </div>
                  {c.done ? (
                    <CircleCheck className="h-3.5 w-3.5 text-success flex-shrink-0" />
                  ) : (
                    <CircleDashed className="h-3.5 w-3.5 text-muted-foreground/60 flex-shrink-0" />
                  )}
                </label>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function IceRing({
  label,
  value,
  color,
  icon,
}: {
  label: string;
  value: number;
  color: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center text-center">
      <CircleProgress value={value} size={64} strokeWidth={6} color={color}>
        <div className="flex flex-col items-center">
          <span className="text-sm font-semibold text-ink">{value}</span>
          <span className="text-[8px] text-muted-foreground flex items-center gap-0.5">
            {icon}
            /100
          </span>
        </div>
      </CircleProgress>
      <div className="text-[10px] font-medium text-ink mt-1.5">{label}</div>
    </div>
  );
}
