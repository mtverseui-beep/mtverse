"use client";

import * as React from "react";
import {
  Key,
  KeyRound,
  Plus,
  Copy,
  Ban,
  Activity,
  Clock,
  Zap,
  Lightbulb,
  ShieldAlert,
  Eye,
  EyeOff,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { API_KEYS, type ApiKey } from "@/lib/data";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ScopeDef {
  scope: string;
  description: string;
  level: "read" | "write" | "admin";
}

const SCOPE_REFERENCE: ScopeDef[] = [
  { scope: "read:projects", description: "List and view all projects in the workspace", level: "read" },
  { scope: "write:projects", description: "Create, update, archive projects", level: "write" },
  { scope: "read:insights", description: "View insights, evidence, and metadata", level: "read" },
  { scope: "write:insights", description: "Create or update insights, change status", level: "write" },
  { scope: "read:reports", description: "List generated reports and templates", level: "read" },
  { scope: "write:reports", description: "Trigger report generation, edit templates", level: "write" },
  { scope: "export:data", description: "Download CSV/JSON exports of any dataset", level: "admin" },
  { scope: "webhook:sign", description: "Sign outbound webhook payloads with HMAC", level: "admin" },
  { scope: "admin:team", description: "Invite, remove, and manage team members", level: "admin" },
];

const SCOPE_LEVEL_STYLES: Record<string, string> = {
  read: "bg-info/10 text-info border-info/20",
  write: "bg-warning/10 text-warning border-warning/20",
  admin: "bg-friction/10 text-friction border-friction/20",
};

const USAGE_TIPS = [
  {
    icon: ShieldAlert,
    title: "Rotate keys every 90 days",
    body: "Mark old keys as revoked after rotating. Never reuse a key across environments.",
  },
  {
    icon: Eye,
    title: "Scope to the minimum",
    body: "Prefer read-only keys for dashboards and embeds. Reserve write scopes for server-side jobs.",
  },
  {
    icon: Key,
    title: "Never expose in client code",
    body: "All Ooster API keys are workspace-scoped. Keep them on your backend; use short-lived tokens for the browser.",
  },
  {
    icon: Zap,
    title: "Watch the rate limit",
    body: "Enterprise: 600 req/min. Team: 120 req/min. Pro: 30 req/min. Burst up to 2× for 10s.",
  },
];

export default function ApiKeysPage() {
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);
  const [revealedKeys, setRevealedKeys] = React.useState<Record<string, boolean>>({});

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const activeCount = API_KEYS.filter((k) => k.status === "active").length;
  const revokedCount = API_KEYS.filter((k) => k.status === "revoked").length;

  const handleCreate = () => {
    toast.success("API key created", {
      description: "New key oost_live_xK9p…Qb2 has been added to your workspace.",
    });
  };

  const handleCopy = (key: ApiKey) => {
    navigator.clipboard?.writeText(`${key.prefix}••••`).catch(() => {});
    toast.success("Key prefix copied", {
      description: `${key.prefix}•••• copied to clipboard`,
    });
  };

  const handleRevoke = (key: ApiKey) => {
    openConfirm({
      title: `Revoke "${key.name}"?`,
      description:
        "This key will stop working immediately. Any service using it will receive 401 errors. This cannot be undone.",
      onConfirm: () => {
        toast.success(`"${key.name}" revoked`);
      },
    });
  };

  const toggleReveal = (id: string) => {
    setRevealedKeys((s) => ({ ...s, [id]: !s[id] }));
  };

  const columns: Column<ApiKey>[] = [
    {
      key: "name",
      header: "Name",
      cell: (row) => (
        <div className="flex items-center gap-2 min-w-0">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0">
            <KeyRound className="h-3.5 w-3.5" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-medium text-ink truncate">{row.name}</div>
            <div className="text-[10px] text-muted-foreground">{row.id}</div>
          </div>
        </div>
      ),
      sortable: true,
      sortAccessor: (row) => row.name,
    },
    {
      key: "prefix",
      header: "Key prefix",
      cell: (row) => (
        <div className="flex items-center gap-1.5">
          <code className="text-[10px] font-mono text-ink bg-surface-2 px-1.5 py-1 rounded">
            {revealedKeys[row.id] ? `${row.prefix}sk_live_xK9p2Qb2` : `${row.prefix}••••••••`}
          </code>
          <button
            onClick={() => toggleReveal(row.id)}
            className="text-muted-foreground hover:text-ink transition-colors"
            aria-label={revealedKeys[row.id] ? "Hide key" : "Reveal key"}
          >
            {revealedKeys[row.id] ? (
              <EyeOff className="h-3 w-3" />
            ) : (
              <Eye className="h-3 w-3" />
            )}
          </button>
        </div>
      ),
    },
    {
      key: "scopes",
      header: "Scopes",
      cell: (row) => (
        <div className="flex flex-wrap gap-1 max-w-[220px]">
          {row.scopes.map((s) => (
            <code
              key={s}
              className="text-[10px] font-mono text-info bg-info/10 px-1.5 py-0.5 rounded"
            >
              {s}
            </code>
          ))}
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "lastUsed",
      header: "Last used",
      cell: (row) => <span className="text-[11px] text-muted-foreground">{row.lastUsed}</span>,
      sortable: true,
      sortAccessor: (row) => row.lastUsed,
      hideOnMobile: true,
    },
    {
      key: "createdAt",
      header: "Created",
      cell: (row) => <span className="text-[11px] text-muted-foreground">{row.createdAt}</span>,
      sortable: true,
      sortAccessor: (row) => row.createdAt,
      hideOnMobile: true,
    },
    {
      key: "createdBy",
      header: "Created by",
      cell: (row) => <span className="text-[11px] text-ink">{row.createdBy}</span>,
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (row) => <StatusBadge status={row.status === "active" ? "active" : "suspended"} label={row.status} />,
    },
    {
      key: "actions",
      header: "Actions",
      cell: (row) => (
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 rounded-full"
            onClick={() => handleCopy(row)}
            aria-label="Copy key"
          >
            <Copy className="h-3.5 w-3.5" />
          </Button>
          {row.status === "active" ? (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 rounded-full text-friction hover:text-friction"
              onClick={() => handleRevoke(row)}
              aria-label="Revoke key"
            >
              <Ban className="h-3.5 w-3.5" />
            </Button>
          ) : (
            <span className="text-[10px] text-muted-foreground px-2">—</span>
          )}
        </div>
      ),
      className: "text-right",
    },
  ];

  return (
    <div>
      <PageHeader
        title="API Keys"
        description="Manage programmatic access to your Ooster workspace"
        icon={<Key className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {API_KEYS.length} keys
          </Badge>
        }
        actions={
          <Button
            size="sm"
            className="rounded-full"
            onClick={handleCreate}
          >
            <Plus className="mr-2 h-3.5 w-3.5" /> Create API key
          </Button>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Active keys"
          value={activeCount}
          icon={<Key className="h-4 w-4" />}
          accent="success"
          sublabel="in use right now"
        />
        <StatCard
          label="Revoked"
          value={revokedCount}
          icon={<Ban className="h-4 w-4" />}
          accent="friction"
          sublabel="permanently disabled"
        />
        <StatCard
          label="Requests today"
          value="14,287"
          icon={<Activity className="h-4 w-4" />}
          accent="info"
          trend={{ value: 12, direction: "up", good: true }}
          sublabel="across all keys"
        />
        <StatCard
          label="Avg latency"
          value="84"
          unit="ms"
          icon={<Clock className="h-4 w-4" />}
          accent="warning"
          trend={{ value: 4, direction: "down", good: true }}
          sublabel="p50 · last 24h"
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="table" />
      ) : API_KEYS.length === 0 ? (
        <EmptyState
          icon={Key}
          title="No API keys yet"
          description="Create your first API key to enable programmatic access to your Ooster workspace."
          action={{ label: "Create API key", onClick: handleCreate }}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main table */}
          <div className="lg:col-span-2">
            <DataTable
              data={API_KEYS}
              columns={columns}
              searchable
              searchPlaceholder="Search keys…"
              searchKeys={["name", "createdBy", "prefix"]}
              pageSize={10}
              getRowId={(row) => row.id}
              emptyTitle="No API keys found"
              emptyDescription="Try a different search, or create a new key."
            />
          </div>

          {/* Side: scopes reference + usage tips */}
          <div className="space-y-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                  <ShieldAlert className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">Scope reference</h3>
              </div>
              <div className="space-y-2">
                {SCOPE_REFERENCE.map((s) => (
                  <div key={s.scope} className="rounded-xl border border-soft p-2.5">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <code className="text-[10px] font-mono text-info bg-info/10 px-1.5 py-0.5 rounded">
                        {s.scope}
                      </code>
                      <Badge
                        variant="outline"
                        className={cn("text-[9px] capitalize border", SCOPE_LEVEL_STYLES[s.level])}
                      >
                        {s.level}
                      </Badge>
                    </div>
                    <div className="text-[10px] text-muted-foreground leading-relaxed">
                      {s.description}
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <Lightbulb className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-ink">Usage tips</h3>
              </div>
              <div className="space-y-3">
                {USAGE_TIPS.map((tip, i) => {
                  const Icon = tip.icon;
                  return (
                    <div key={i} className="flex items-start gap-2.5">
                      <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0 mt-0.5">
                        <Icon className="h-3.5 w-3.5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-ink">{tip.title}</div>
                        <div className="text-[10px] text-muted-foreground leading-relaxed mt-0.5">
                          {tip.body}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
