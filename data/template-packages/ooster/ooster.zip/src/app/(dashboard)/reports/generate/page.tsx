"use client";

import * as React from "react";
import Link from "next/link";
import {
  Sparkles,
  ArrowLeft,
  ArrowRight,
  Check,
  Loader2,
  FileBarChart,
  FileText,
  ShieldCheck,
  Trophy,
  GitBranch,
  Map,
  FolderKanban,
  Eye,
  MessageSquare,
  Mic,
  ClipboardList,
  FileDown,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PROJECTS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const STEP_LABELS = ["Project", "Report type", "Scope", "Format"];

const REPORT_TYPES = [
  {
    value: "executive",
    label: "Executive summary",
    desc: "1-page leadership overview",
    icon: FileText,
    tint: "var(--info)",
  },
  {
    value: "audit",
    label: "Full UX audit",
    desc: "Screen-by-screen deep dive",
    icon: ShieldCheck,
    tint: "var(--success)",
  },
  {
    value: "competitor",
    label: "Competitor benchmark",
    desc: "Side-by-side with 5 competitors",
    icon: Trophy,
    tint: "var(--warning)",
  },
  {
    value: "task-flow",
    label: "Task flow analysis",
    desc: "Step-by-step friction inventory",
    icon: GitBranch,
    tint: "var(--chart-5)",
  },
  {
    value: "user-journey",
    label: "User journey map",
    desc: "End-to-end journey & emotion curve",
    icon: Map,
    tint: "var(--chart-6)",
  },
  {
    value: "benchmark",
    label: "Benchmark snapshot",
    desc: "Quantitative KPI snapshot vs last period",
    icon: FileBarChart,
    tint: "var(--friction)",
  },
];

const SCOPE_OPTIONS = [
  { id: "screens", label: "Screens & heatmaps", desc: "24 screens · 6 heatmap variants", icon: Eye },
  { id: "sessions", label: "Session replays", desc: "312 replays · last 30 days", icon: FileDown },
  { id: "surveys", label: "Survey responses", desc: "1,204 responses · 4 surveys", icon: ClipboardList },
  { id: "interviews", label: "Interview transcripts", desc: "18 transcripts · 6 hours", icon: Mic },
];

const FORMATS = [
  { value: "pdf", label: "PDF", desc: "Polished, branded, ready to share", icon: FileText },
  { value: "markdown", label: "Markdown", desc: "Plain text for docs & wikis", icon: FileDown },
  { value: "slack", label: "Slack digest", desc: "Condensed thread for #product", icon: MessageSquare },
];

const STEPS = [
  "Collecting screens & sessions…",
  "Running friction detection models…",
  "Cross-referencing with WCAG 2.1…",
  "Synthesizing insights with AI…",
  "Formatting report & executive summary…",
];

export default function GenerateReportPage() {
  const [step, setStep] = React.useState(0);
  const [projectId, setProjectId] = React.useState(PROJECTS[0].id);
  const [reportType, setReportType] = React.useState("executive");
  const [scope, setScope] = React.useState<string[]>(["screens", "sessions"]);
  const [format, setFormat] = React.useState("pdf");
  const [generating, setGenerating] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const [activeStep, setActiveStep] = React.useState(0);

  const toggleScope = (id: string) => {
    setScope((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  };

  const canNext =
    (step === 0 && !!projectId) ||
    (step === 1 && !!reportType) ||
    (step === 2 && scope.length > 0) ||
    step === 3;

  const start = () => {
    setGenerating(true);
    setActiveStep(0);
    const timer = setInterval(() => {
      setActiveStep((s) => {
        if (s >= STEPS.length - 1) {
          clearInterval(timer);
          setGenerating(false);
          setDone(true);
          return s;
        }
        return s + 1;
      });
    }, 900);
  };

  const reset = () => {
    setStep(0);
    setGenerating(false);
    setDone(false);
    setActiveStep(0);
  };

  const selectedProject = PROJECTS.find((p) => p.id === projectId);
  const selectedType = REPORT_TYPES.find((t) => t.value === reportType);

  return (
    <div>
      <PageHeader
        title="Generate AI Report"
        description="Configure and generate a new report."
        breadcrumbs={[
          { label: "Reports", href: "/reports" },
          { label: "Generate" },
        ]}
        icon={<Sparkles className="h-5 w-5" />}
        actions={
          <Button asChild variant="outline" size="sm" className="rounded-full">
            <Link href="/reports">
              <ArrowLeft className="mr-2 h-3.5 w-3.5" /> Back to reports
            </Link>
          </Button>
        }
      />

      {done ? (
        <Card className="rounded-2xl border-soft shadow-soft p-8 sm:p-12 max-w-xl mx-auto text-center">
          <div className="mx-auto h-14 w-14 rounded-full bg-success/15 flex items-center justify-center">
            <Check className="h-7 w-7 text-success" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-ink">Report ready!</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Your {selectedType?.label.toLowerCase()} for{" "}
            <span className="font-medium text-ink">{selectedProject?.name}</span> is
            ready to view. We also saved a copy to your{" "}
            <Link href="/reports/saved" className="text-primary underline underline-offset-2">
              Saved reports
            </Link>
            .
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <Button asChild className="rounded-full">
              <Link href="/reports/r-001">
                <FileBarChart className="mr-2 h-4 w-4" /> View report
              </Link>
            </Button>
            <Button variant="outline" className="rounded-full" onClick={reset}>
              <Sparkles className="mr-2 h-4 w-4" /> Generate another
            </Button>
          </div>
        </Card>
      ) : generating ? (
        <Card className="rounded-2xl border-soft shadow-soft p-6 max-w-xl mx-auto">
          <div className="text-center mb-5">
            <div className="mx-auto h-12 w-12 rounded-full bg-info/10 flex items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-info" />
            </div>
            <h2 className="mt-3 text-sm font-semibold text-ink">
              Generating your {selectedType?.label.toLowerCase()}…
            </h2>
            <p className="text-xs text-muted-foreground mt-1">
              {selectedProject?.name} · {format.toUpperCase()} · {scope.length} data sources
            </p>
          </div>
          <div className="space-y-3">
            {STEPS.map((s, i) => (
              <div key={s} className="flex items-center gap-3">
                {i < activeStep ? (
                  <div className="h-5 w-5 rounded-full bg-success text-success-foreground flex items-center justify-center">
                    <Check className="h-3 w-3" />
                  </div>
                ) : i === activeStep ? (
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                ) : (
                  <div className="h-5 w-5 rounded-full border border-soft" />
                )}
                <span
                  className={cn(
                    "text-sm",
                    i <= activeStep ? "text-ink" : "text-muted-foreground"
                  )}
                >
                  {s}
                </span>
              </div>
            ))}
          </div>
          <Progress
            value={((activeStep + 1) / STEPS.length) * 100}
            className="h-1 mt-5"
          />
          <p className="text-[10px] text-muted-foreground mt-2 text-center">
            Step {activeStep + 1} of {STEPS.length} · ~{Math.max(1, STEPS.length - activeStep)} min remaining
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Form panel */}
          <Card className="rounded-2xl border-soft shadow-soft p-5 lg:col-span-2">
            {/* Step indicator */}
            <div className="flex items-center gap-2 mb-6">
              {STEP_LABELS.map((label, i) => (
                <React.Fragment key={label}>
                  <button
                    onClick={() => i < step && setStep(i)}
                    disabled={i > step}
                    className={cn(
                      "flex items-center gap-2 rounded-full px-2.5 py-1 text-xs transition-colors",
                      i === step
                        ? "bg-primary text-primary-foreground"
                        : i < step
                        ? "bg-success/15 text-success hover:bg-success/25"
                        : "bg-surface-2 text-muted-foreground"
                    )}
                  >
                    <span
                      className={cn(
                        "flex h-4 w-4 items-center justify-center rounded-full text-[9px] font-semibold",
                        i === step
                          ? "bg-primary-foreground/20 text-primary-foreground"
                          : i < step
                          ? "bg-success text-success-foreground"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      {i < step ? <Check className="h-2.5 w-2.5" /> : i + 1}
                    </span>
                    {label}
                  </button>
                  {i < STEP_LABELS.length - 1 && (
                    <div
                      className={cn(
                        "h-px flex-1",
                        i < step ? "bg-success/40" : "bg-border"
                      )}
                    />
                  )}
                </React.Fragment>
              ))}
            </div>

            {/* Step 1 — Project */}
            {step === 0 && (
              <div className="space-y-3 animate-fade-in">
                <div>
                  <h2 className="text-sm font-semibold text-ink">Select a project</h2>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Ooster AI will analyze the latest data from this project.
                  </p>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Project</Label>
                  <Select value={projectId} onValueChange={setProjectId}>
                    <SelectTrigger className="h-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PROJECTS.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name} · {p.screenCount} screens
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {selectedProject && (
                  <div className="rounded-xl border border-soft p-3 bg-surface-2/50">
                    <div className="flex items-start gap-3">
                      <div
                        className="flex h-9 w-9 items-center justify-center rounded-lg text-white"
                        style={{ background: selectedProject.thumbColor }}
                      >
                        <FolderKanban className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-ink">
                          {selectedProject.name}
                        </div>
                        <div className="text-[10px] text-muted-foreground line-clamp-2 mt-0.5">
                          {selectedProject.description}
                        </div>
                        <div className="flex flex-wrap gap-3 mt-2 text-[10px] text-muted-foreground">
                          <span>UX {selectedProject.uxScore}</span>
                          <span>{selectedProject.screenCount} screens</span>
                          <span>{selectedProject.issueCount} issues</span>
                          <span>{selectedProject.insightCount} insights</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Step 2 — Report type */}
            {step === 1 && (
              <div className="space-y-3 animate-fade-in">
                <div>
                  <h2 className="text-sm font-semibold text-ink">Choose report type</h2>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Each type uses a different Ooster AI synthesis template.
                  </p>
                </div>
                <RadioGroup
                  value={reportType}
                  onValueChange={setReportType}
                  className="grid sm:grid-cols-2 gap-2"
                >
                  {REPORT_TYPES.map((t) => {
                    const Icon = t.icon;
                    const active = reportType === t.value;
                    return (
                      <label
                        key={t.value}
                        className={cn(
                          "flex items-start gap-3 rounded-xl border p-3 cursor-pointer transition-colors",
                          active
                            ? "border-primary bg-accent/40"
                            : "border-soft hover:bg-accent/30"
                        )}
                      >
                        <RadioGroupItem
                          value={t.value}
                          className="mt-0.5"
                        />
                        <div
                          className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md text-white"
                          style={{ background: t.tint }}
                        >
                          <Icon className="h-3.5 w-3.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-ink">{t.label}</div>
                          <div className="text-[10px] text-muted-foreground mt-0.5">
                            {t.desc}
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </RadioGroup>
              </div>
            )}

            {/* Step 3 — Scope */}
            {step === 2 && (
              <div className="space-y-3 animate-fade-in">
                <div>
                  <h2 className="text-sm font-semibold text-ink">Select data scope</h2>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Pick which data sources Ooster AI should include in the synthesis.
                  </p>
                </div>
                <div className="grid sm:grid-cols-2 gap-2">
                  {SCOPE_OPTIONS.map((s) => {
                    const Icon = s.icon;
                    const checked = scope.includes(s.id);
                    return (
                      <label
                        key={s.id}
                        className={cn(
                          "flex items-start gap-3 rounded-xl border p-3 cursor-pointer transition-colors",
                          checked
                            ? "border-primary bg-accent/40"
                            : "border-soft hover:bg-accent/30"
                        )}
                      >
                        <Checkbox
                          checked={checked}
                          onCheckedChange={() => toggleScope(s.id)}
                          className="mt-0.5"
                        />
                        <Icon className="h-4 w-4 text-info mt-0.5 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-ink">{s.label}</div>
                          <div className="text-[10px] text-muted-foreground mt-0.5">
                            {s.desc}
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>
                {scope.length === 0 && (
                  <div className="text-[10px] text-friction text-center">
                    Select at least one data source to continue.
                  </div>
                )}
              </div>
            )}

            {/* Step 4 — Format */}
            {step === 3 && (
              <div className="space-y-3 animate-fade-in">
                <div>
                  <h2 className="text-sm font-semibold text-ink">Choose output format</h2>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    You can export to other formats later from the report page.
                  </p>
                </div>
                <RadioGroup
                  value={format}
                  onValueChange={setFormat}
                  className="grid gap-2"
                >
                  {FORMATS.map((f) => {
                    const Icon = f.icon;
                    const active = format === f.value;
                    return (
                      <label
                        key={f.value}
                        className={cn(
                          "flex items-start gap-3 rounded-xl border p-3 cursor-pointer transition-colors",
                          active
                            ? "border-primary bg-accent/40"
                            : "border-soft hover:bg-accent/30"
                        )}
                      >
                        <RadioGroupItem value={f.value} className="mt-0.5" />
                        <Icon className="h-4 w-4 text-info mt-0.5 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-ink">{f.label}</div>
                          <div className="text-[10px] text-muted-foreground mt-0.5">
                            {f.desc}
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </RadioGroup>

                <div className="rounded-xl border border-soft p-3 bg-surface-2/50 mt-4">
                  <div className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide mb-2">
                    Configuration summary
                  </div>
                  <dl className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <dt className="text-muted-foreground">Project</dt>
                      <dd className="font-medium text-ink">{selectedProject?.name}</dd>
                    </div>
                    <div>
                      <dt className="text-muted-foreground">Type</dt>
                      <dd className="font-medium text-ink">{selectedType?.label}</dd>
                    </div>
                    <div>
                      <dt className="text-muted-foreground">Scope</dt>
                      <dd className="font-medium text-ink capitalize">
                        {scope.map((s) => SCOPE_OPTIONS.find((o) => o.id === s)?.label.split(" ")[0]).join(", ")}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-muted-foreground">Format</dt>
                      <dd className="font-medium text-ink uppercase">{format}</dd>
                    </div>
                  </dl>
                </div>
              </div>
            )}

            {/* Nav buttons */}
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-soft">
              <Button
                variant="ghost"
                size="sm"
                disabled={step === 0}
                onClick={() => setStep((s) => Math.max(0, s - 1))}
              >
                <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back
              </Button>
              {step < STEP_LABELS.length - 1 ? (
                <Button
                  size="sm"
                  disabled={!canNext}
                  onClick={() => setStep((s) => Math.min(STEP_LABELS.length - 1, s + 1))}
                >
                  Next <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
                </Button>
              ) : (
                <Button size="sm" onClick={start} disabled={!canNext}>
                  <Sparkles className="mr-2 h-3.5 w-3.5" /> Generate report
                </Button>
              )}
            </div>
          </Card>

          {/* Sidebar summary */}
          <div className="space-y-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:sticky lg:top-20">
              <h3 className="text-sm font-semibold text-ink mb-3 flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-info" /> What you'll get
              </h3>
              <ul className="space-y-2 text-xs text-ink/90">
                {[
                  "AI-synthesized executive summary",
                  "UX score breakdown with 6 metrics",
                  "Prioritized findings with severity",
                  "Actionable recommendations with effort",
                  `${format.toUpperCase()} export, ready to share`,
                ].map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <Check className="h-3.5 w-3.5 text-success mt-0.5 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <div className="mt-4 pt-3 border-t border-soft flex flex-wrap gap-1.5">
                <Badge variant="secondary" className="text-[10px]">~2-3 min</Badge>
                <Badge variant="secondary" className="text-[10px]">WCAG 2.1</Badge>
                <Badge variant="secondary" className="text-[10px]">Re-runnable</Badge>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <h3 className="text-sm font-semibold text-ink mb-2">Need a head start?</h3>
              <p className="text-[10px] text-muted-foreground mb-3">
                Start from a prebuilt template — exec summary, full audit, or competitor benchmark.
              </p>
              <Button asChild variant="outline" size="sm" className="w-full rounded-full">
                <Link href="/reports/templates">
                  Browse templates <ArrowRight className="ml-1.5 h-3 w-3" />
                </Link>
              </Button>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
