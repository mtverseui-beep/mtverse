"use client";

import * as React from "react";
import Link from "next/link";
import {
  FileBarChart,
  FileText,
  ShieldCheck,
  Trophy,
  GitBranch,
  Map,
  BarChart3,
  Plus,
  Share2,
  Clock,
  FileStack,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { StatusBadge } from "@/components/common/badges";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useModals } from "@/hooks/use-modals";
import { REPORTS, type Report } from "@/lib/data";
import { cn } from "@/lib/utils";

const TYPE_META: Record<
  Report["type"],
  { label: string; icon: React.ElementType; tint: string }
> = {
  executive: { label: "Executive", icon: FileText, tint: "var(--info)" },
  audit: { label: "Audit", icon: ShieldCheck, tint: "var(--success)" },
  competitor: { label: "Competitor", icon: Trophy, tint: "var(--warning)" },
  "task-flow": { label: "Task flow", icon: GitBranch, tint: "var(--chart-5)" },
  "user-journey": { label: "User journey", icon: Map, tint: "var(--chart-6)" },
  benchmark: { label: "Benchmark", icon: BarChart3, tint: "var(--friction)" },
};

const TYPE_FILTERS = [
  { value: "all", label: "All types" },
  { value: "executive", label: "Executive" },
  { value: "audit", label: "Audit" },
  { value: "competitor", label: "Competitor" },
  { value: "task-flow", label: "Task flow" },
  { value: "user-journey", label: "User journey" },
  { value: "benchmark", label: "Benchmark" },
];

const STATUS_FILTERS = [
  { value: "all", label: "All statuses" },
  { value: "ready", label: "Ready" },
  { value: "generating", label: "Generating" },
  { value: "scheduled", label: "Scheduled" },
  { value: "draft", label: "Draft" },
];

const SHARED_FILTERS = [
  { value: "all", label: "Shared & private" },
  { value: "shared", label: "Shared only" },
  { value: "private", label: "Private only" },
];

export default function ReportsPage() {
  const setGenerateOpen = useModals((s) => s.setGenerateReportOpen);
  const [search, setSearch] = React.useState("");
  const [type, setType] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [shared, setShared] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return REPORTS.filter((r) => {
      if (
        search &&
        !r.title.toLowerCase().includes(search.toLowerCase()) &&
        !r.summary.toLowerCase().includes(search.toLowerCase()) &&
        !r.tags.some((t) => t.includes(search.toLowerCase()))
      )
        return false;
      if (type !== "all" && r.type !== type) return false;
      if (status !== "all" && r.status !== status) return false;
      if (shared === "shared" && !r.shared) return false;
      if (shared === "private" && r.shared) return false;
      return true;
    });
  }, [search, type, status, shared]);

  const clearFilters = () => {
    setSearch("");
    setType("all");
    setStatus("all");
    setShared("all");
  };

  const totalReady = REPORTS.filter((r) => r.status === "ready").length;
  const generating = REPORTS.filter((r) => r.status === "generating").length;
  const avgPages = Math.round(
    REPORTS.reduce((s, r) => s + r.pages, 0) / REPORTS.length
  );

  return (
    <div>
      <PageHeader
        title="AI Reports"
        description="Generated research reports, audits, and benchmarks — synthesized by Ooster AI."
        breadcrumbs={[{ label: "Reports" }]}
        icon={<FileBarChart className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {REPORTS.length} reports
          </Badge>
        }
        actions={
          <Button
            size="sm"
            className="rounded-full"
            onClick={() => setGenerateOpen(true)}
          >
            <Plus className="mr-2 h-3.5 w-3.5" /> Generate report
          </Button>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total reports"
          value={REPORTS.length}
          icon={<FileStack className="h-4 w-4" />}
          trend={{ value: 12, direction: "up", good: true }}
          sublabel="vs last month"
        />
        <StatCard
          label="Ready to share"
          value={totalReady}
          icon={<Share2 className="h-4 w-4" />}
          accent="success"
          sublabel={`${REPORTS.filter((r) => r.shared).length} already shared`}
        />
        <StatCard
          label="Generating now"
          value={generating}
          icon={<Sparkles className="h-4 w-4" />}
          accent="info"
          sublabel="AI synthesis in progress"
        />
        <StatCard
          label="Avg pages"
          value={avgPages}
          unit="p"
          icon={<TrendingUp className="h-4 w-4" />}
          trend={{ value: 3, direction: "up", good: true }}
          sublabel="per report"
        />
      </div>

      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search reports by title, summary, tag…",
          }}
          selects={[
            {
              label: "Type",
              value: type,
              onChange: setType,
              options: TYPE_FILTERS,
            },
            {
              label: "Status",
              value: status,
              onChange: setStatus,
              options: STATUS_FILTERS,
            },
            {
              label: "Shared",
              value: shared,
              onChange: setShared,
              options: SHARED_FILTERS,
            },
          ]}
          onClear={clearFilters}
          actions={
            <Button
              asChild
              variant="outline"
              size="sm"
              className="rounded-full h-9"
            >
              <Link href="/reports/templates">
                <FileBarChart className="mr-2 h-3.5 w-3.5" /> Templates
              </Link>
            </Button>
          }
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={FileBarChart}
          title="No reports match your filters"
          description="Adjust your search or filters, or generate a new AI report to get started."
          action={{
            label: "Generate report",
            onClick: () => setGenerateOpen(true),
          }}
          secondaryAction={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((r) => {
            const meta = TYPE_META[r.type];
            const Icon = meta.icon;
            return (
              <Link key={r.id} href={`/reports/${r.id}`} className="group">
                <Card className="rounded-2xl border-soft shadow-soft overflow-hidden h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
                  <div className="p-4 space-y-3 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <div
                        className="flex h-9 w-9 items-center justify-center rounded-lg text-white"
                        style={{ background: meta.tint }}
                      >
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="flex items-center gap-1.5">
                        {r.shared && (
                          <Badge
                            variant="outline"
                            className="text-[9px] gap-0.5 px-1.5 text-info border-info/20 bg-info/10"
                          >
                            <Share2 className="h-2.5 w-2.5" /> Shared
                          </Badge>
                        )}
                        <StatusBadge status={r.status as any} />
                      </div>
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-ink group-hover:text-primary transition-colors line-clamp-1">
                        {r.title}
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                        {r.summary}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {r.tags.slice(0, 3).map((t) => (
                        <Badge
                          key={t}
                          variant="secondary"
                          className="text-[9px] font-normal"
                        >
                          {t}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="border-t border-soft p-3 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <Avatar className="h-6 w-6 ring-1 ring-soft">
                        <AvatarImage
                          src={r.createdBy.avatar}
                          alt={r.createdBy.name}
                        />
                        <AvatarFallback>
                          {r.createdBy.name.slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <div className="text-[10px] font-medium text-ink truncate">
                          {r.createdBy.name}
                        </div>
                        <div className="text-[9px] text-muted-foreground truncate">
                          {r.project}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-muted-foreground flex-shrink-0">
                      <span className="inline-flex items-center gap-0.5">
                        <FileText className="h-2.5 w-2.5" /> {r.pages}p
                      </span>
                      <span className="inline-flex items-center gap-0.5">
                        <Clock className="h-2.5 w-2.5" /> {r.duration}
                      </span>
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
