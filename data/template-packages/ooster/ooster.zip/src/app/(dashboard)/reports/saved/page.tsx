"use client";

import * as React from "react";
import Link from "next/link";
import {
  Bookmark,
  Calendar,
  Clock,
  FileText,
  ShieldCheck,
  Trophy,
  GitBranch,
  Map,
  BarChart3,
  Share2,
  Play,
  Pencil,
  Plus,
  Repeat,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { REPORTS, type Report } from "@/lib/data";
import { useModals } from "@/hooks/use-modals";
import { toast } from "sonner";

const TYPE_META: Record<
  Report["type"],
  { label: string; icon: React.ElementType; tint: string }
> = {
  executive: { label: "Executive", icon: FileText, tint: "var(--info)" },
  audit: { label: "Audit", icon: ShieldCheck, tint: "var(--success)" },
  competitor: { label: "Competitor", icon: Trophy, tint: "var(--warning)" },
  "task-flow": { label: "Task flow", icon: GitBranch, tint: "var(--chart-5)" },
  "user-journey": { label: "User journey", icon: Map, tint: "var(--chart-6)" },
  benchmark: { label: "Benchmark", icon: BarChart3, tint: "var(--friction)" },
};

// Mock bookmarked reports — reuse REPORTS, mark a subset as bookmarked.
const BOOKMARKED = REPORTS.filter((_, i) => i % 2 === 0);

const SCHEDULED = [
  {
    id: "sch-001",
    title: "Atlas Onboarding — Weekly UX Digest",
    project: "Atlas Onboarding",
    cadence: "Weekly · Mondays 09:00",
    nextRun: "Mon Jul 7, 09:00",
    type: "executive" as Report["type"],
    enabled: true,
    lastRun: "Mon Jun 30, 09:02",
  },
  {
    id: "sch-002",
    title: "Northwind Checkout — Monthly Benchmark",
    project: "Northwind Checkout",
    cadence: "Monthly · 1st at 10:00",
    nextRun: "Thu Aug 1, 10:00",
    type: "benchmark" as Report["type"],
    enabled: true,
    lastRun: "Mon Jul 1, 10:01",
  },
  {
    id: "sch-003",
    title: "Helix Prototype — Fortnightly Accessibility Audit",
    project: "Helix Prototype",
    cadence: "Every 2 weeks · Fridays",
    nextRun: "Fri Jul 11, 16:00",
    type: "audit" as Report["type"],
    enabled: false,
    lastRun: "Fri Jun 27, 16:00",
  },
  {
    id: "sch-004",
    title: "Cadence Mobile — Monthly Journey Snapshot",
    project: "Cadence Mobile",
    cadence: "Monthly · 15th at 11:00",
    nextRun: "Tue Jul 15, 11:00",
    type: "user-journey" as Report["type"],
    enabled: true,
    lastRun: "Sat Jun 15, 11:03",
  },
];

const DRAFTS = [
  {
    id: "d-001",
    title: "Voyage Booking — Q3 Executive Summary (draft)",
    project: "Voyage Booking",
    type: "executive" as Report["type"],
    progress: 60,
    updated: "2 hours ago",
    step: "Synthesizing insights with AI",
  },
  {
    id: "d-002",
    title: "Riverside DS — Component Accessibility Audit (draft)",
    project: "Riverside Design System",
    type: "audit" as Report["type"],
    progress: 35,
    updated: "Yesterday",
    step: "Cross-referencing with WCAG 2.1",
  },
  {
    id: "d-003",
    title: "Northwind — Competitor Teardown (draft)",
    project: "Northwind Checkout",
    type: "competitor" as Report["type"],
    progress: 15,
    updated: "3 days ago",
    step: "Collecting screens & sessions",
  },
];

export default function SavedReportsPage() {
  const setGenerateOpen = useModals((s) => s.setGenerateReportOpen);
  const [scheduledState, setScheduledState] = React.useState(SCHEDULED);

  const toggleScheduled = (id: string) => {
    setScheduledState((arr) =>
      arr.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s))
    );
    const item = scheduledState.find((s) => s.id === id);
    toast.success(
      item?.enabled ? "Schedule paused" : "Schedule resumed",
      { description: item?.title }
    );
  };

  return (
    <div>
      <PageHeader
        title="Saved Reports"
        description="Your bookmarked and scheduled reports."
        breadcrumbs={[
          { label: "Reports", href: "/reports" },
          { label: "Saved" },
        ]}
        icon={<Bookmark className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {BOOKMARKED.length + SCHEDULED.length + DRAFTS.length} items
          </Badge>
        }
        actions={
          <Button
            size="sm"
            className="rounded-full"
            onClick={() => setGenerateOpen(true)}
          >
            <Plus className="mr-2 h-3.5 w-3.5" /> Generate report
          </Button>
        }
      />

      <Tabs defaultValue="bookmarked">
        <TabsList className="bg-surface-2 rounded-full p-0.5 h-9 overflow-x-auto no-scrollbar max-w-full">
          <TabsTrigger
            value="bookmarked"
            className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft gap-1.5"
          >
            <Bookmark className="h-3 w-3" /> Bookmarked
            <Badge variant="secondary" className="text-[9px] ml-1 px-1">
              {BOOKMARKED.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger
            value="scheduled"
            className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft gap-1.5"
          >
            <Repeat className="h-3 w-3" /> Scheduled
            <Badge variant="secondary" className="text-[9px] ml-1 px-1">
              {scheduledState.filter((s) => s.enabled).length}/{scheduledState.length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger
            value="drafts"
            className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft gap-1.5"
          >
            <Pencil className="h-3 w-3" /> Drafts
            <Badge variant="secondary" className="text-[9px] ml-1 px-1">
              {DRAFTS.length}
            </Badge>
          </TabsTrigger>
        </TabsList>

        {/* Bookmarked */}
        <TabsContent value="bookmarked" className="mt-4">
          {BOOKMARKED.length === 0 ? (
            <EmptyState
              icon={Bookmark}
              title="No bookmarked reports"
              description="Tap the bookmark icon on any report to save it here for quick access."
              action={{
                label: "Browse reports",
                href: "/reports",
              }}
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {BOOKMARKED.map((r) => {
                const meta = TYPE_META[r.type];
                const Icon = meta.icon;
                return (
                  <Link key={r.id} href={`/reports/${r.id}`} className="group">
                    <Card className="rounded-2xl border-soft shadow-soft overflow-hidden h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
                      <div className="p-4 space-y-3 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div
                            className="flex h-9 w-9 items-center justify-center rounded-lg text-white"
                            style={{ background: meta.tint }}
                          >
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Bookmark className="h-3.5 w-3.5 fill-warning text-warning" />
                            <StatusBadge status={r.status as any} />
                          </div>
                        </div>
                        <div>
                          <div className="font-semibold text-sm text-ink group-hover:text-primary transition-colors line-clamp-1">
                            {r.title}
                          </div>
                          <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                            {r.summary}
                          </p>
                        </div>
                      </div>
                      <div className="border-t border-soft p-3 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Avatar className="h-6 w-6 ring-1 ring-soft">
                            <AvatarImage
                              src={r.createdBy.avatar}
                              alt={r.createdBy.name}
                            />
                            <AvatarFallback>
                              {r.createdBy.name.slice(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-[10px] text-muted-foreground truncate">
                            {r.project}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-muted-foreground flex-shrink-0">
                          <span className="inline-flex items-center gap-0.5">
                            <FileText className="h-2.5 w-2.5" /> {r.pages}p
                          </span>
                          <span className="inline-flex items-center gap-0.5">
                            <Clock className="h-2.5 w-2.5" /> {r.duration}
                          </span>
                        </div>
                      </div>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* Scheduled */}
        <TabsContent value="scheduled" className="mt-4">
          {scheduledState.length === 0 ? (
            <EmptyState
              icon={Repeat}
              title="No scheduled reports"
              description="Set up a recurring AI report to land in your inbox every week or month."
              action={{
                label: "Browse templates",
                href: "/reports/templates",
              }}
            />
          ) : (
            <Card className="rounded-2xl border-soft shadow-soft overflow-hidden">
              {scheduledState.map((s, i) => {
                const meta = TYPE_META[s.type];
                const Icon = meta.icon;
                return (
                  <div
                    key={s.id}
                    className={`flex flex-col sm:flex-row sm:items-center gap-3 p-4 hover:bg-accent/30 transition-colors ${
                      i !== scheduledState.length - 1 ? "border-b border-soft" : ""
                    }`}
                  >
                    <div
                      className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg text-white"
                      style={{ background: meta.tint }}
                    >
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium text-ink">{s.title}</span>
                        {s.enabled ? (
                          <Badge
                            variant="outline"
                            className="text-[9px] text-success border-success/20 bg-success/10"
                          >
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-[9px] text-muted-foreground">
                            Paused
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-1 text-[10px] text-muted-foreground">
                        <span className="inline-flex items-center gap-1">
                          <Repeat className="h-2.5 w-2.5" /> {s.cadence}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Calendar className="h-2.5 w-2.5" /> Next: {s.nextRun}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Clock className="h-2.5 w-2.5" /> Last: {s.lastRun}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 text-xs rounded-full"
                        onClick={() =>
                          toast.success("Running report now", {
                            description: s.title,
                          })
                        }
                      >
                        <Play className="mr-1 h-3 w-3" /> Run now
                      </Button>
                      <Switch
                        checked={s.enabled}
                        onCheckedChange={() => toggleScheduled(s.id)}
                      />
                    </div>
                  </div>
                );
              })}
            </Card>
          )}
        </TabsContent>

        {/* Drafts */}
        <TabsContent value="drafts" className="mt-4">
          {DRAFTS.length === 0 ? (
            <EmptyState
              icon={Pencil}
              title="No drafts in progress"
              description="Reports you start generating but don't finish will save here automatically."
              action={{
                label: "Start a new report",
                onClick: () => setGenerateOpen(true),
              }}
            />
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
              {DRAFTS.map((d) => {
                const meta = TYPE_META[d.type];
                const Icon = meta.icon;
                return (
                  <Card
                    key={d.id}
                    className="rounded-2xl border-soft shadow-soft p-4 hover:shadow-card transition-shadow"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg text-white"
                        style={{ background: meta.tint }}
                      >
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className="text-sm font-medium text-ink line-clamp-1">
                            {d.title}
                          </div>
                          <Badge
                            variant="outline"
                            className="text-[9px] text-warning border-warning/20 bg-warning/10"
                          >
                            Draft
                          </Badge>
                        </div>
                        <div className="text-[10px] text-muted-foreground mt-0.5">
                          {d.project} · updated {d.updated}
                        </div>
                        <div className="mt-3">
                          <div className="flex items-center justify-between text-[10px] mb-1">
                            <span className="text-muted-foreground">{d.step}</span>
                            <span className="font-medium text-ink">{d.progress}%</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                            <div
                              className="h-full rounded-full bg-info transition-all"
                              style={{ width: `${d.progress}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-soft flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs h-8"
                        onClick={() =>
                          toast.success("Draft discarded", { description: d.title })
                        }
                      >
                        Discard
                      </Button>
                      <Button
                        asChild
                        size="sm"
                        className="text-xs h-8 rounded-full"
                      >
                        <Link href="/reports/generate">
                          Resume <ChevronRight className="ml-1 h-3 w-3" />
                        </Link>
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
