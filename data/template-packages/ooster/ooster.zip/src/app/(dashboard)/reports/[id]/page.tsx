"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  FileBarChart,
  FileText,
  ShieldCheck,
  Trophy,
  GitBranch,
  Map,
  BarChart3,
  Download,
  Copy,
  Share2,
  Printer,
  Clock,
  Calendar,
  User,
  FolderKanban,
  ListTree,
  ArrowRight,
  ChevronRight,
  Check,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { SeverityBadge, StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { useModals } from "@/hooks/use-modals";
import { REPORTS, getReport, type Report } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { ScreenMockup } from "@/components/common/screen-mockup";

const TYPE_META: Record<
  Report["type"],
  { label: string; icon: React.ElementType; tint: string }
> = {
  executive: { label: "Executive", icon: FileText, tint: "var(--info)" },
  audit: { label: "Audit", icon: ShieldCheck, tint: "var(--success)" },
  competitor: { label: "Competitor", icon: Trophy, tint: "var(--warning)" },
  "task-flow": { label: "Task flow", icon: GitBranch, tint: "var(--chart-5)" },
  "user-journey": { label: "User journey", icon: Map, tint: "var(--chart-6)" },
  benchmark: { label: "Benchmark", icon: BarChart3, tint: "var(--friction)" },
};

// Build a deterministic UX breakdown from a report's uxScore.
function scoreBreakdown(uxScore: number) {
  return [
    { label: "Usability", value: uxScore, color: "var(--success)" },
    { label: "Accessibility", value: Math.min(100, uxScore + 5), color: "var(--info)" },
    { label: "Conversion", value: Math.max(40, uxScore - 9), color: "var(--warning)" },
    { label: "Engagement", value: Math.max(45, uxScore - 6), color: "var(--chart-5)" },
    { label: "Cognitive load", value: Math.max(35, 100 - uxScore + 5), color: "var(--friction)" },
    { label: "Clarity", value: Math.max(50, uxScore - 3), color: "var(--chart-6)" },
  ];
}

const FINDINGS: { severity: "critical" | "high" | "medium" | "low"; title: string; detail: string }[] = [
  {
    severity: "critical",
    title: "KYC document upload fails silently on iOS Safari 17",
    detail:
      "13% of mobile onboarding sessions stall at step 3 because the file picker returns an empty selection. Users retry 2.4x on average before abandoning.",
  },
  {
    severity: "high",
    title: "Wallet setup lacks inline validation for routing numbers",
    detail:
      "Errors only surface after submit, forcing full-screen re-render. Field-level validation would reduce form completion time by an estimated 22s.",
  },
  {
    severity: "medium",
    title: "First-transfer confirmation page creates decision fatigue",
    detail:
      "Users see 4 distinct CTAs (review, edit, cancel, confirm). Eye-tracking shows hesitation 2.8s longer than benchmark before primary action.",
  },
  {
    severity: "medium",
    title: "Color contrast on secondary buttons falls below WCAG AA",
    detail:
      "Slate-on-ivory secondary buttons measure 3.9:1 contrast against background, below the 4.5:1 threshold for normal-sized text.",
  },
  {
    severity: "low",
    title: "Microcopy on success states is inconsistent",
    detail:
      "Three different phrasings for transfer completion across screens. Consolidating to a single voice pattern would strengthen brand trust.",
  },
];

const RECOMMENDATIONS: { action: string; priority: "P0" | "P1" | "P2" | "P3"; effort: string }[] = [
  {
    action:
      "Patch the iOS Safari file-picker handler with a fallback to a native input[type=file] and add a server-side retry when no file is returned.",
    priority: "P0",
    effort: "2 days",
  },
  {
    action:
      "Add inline validation with optimistic checks on routing-number field, with debounce of 400ms after first blur.",
    priority: "P1",
    effort: "1 day",
  },
  {
    action:
      "Collapse the review/confirm step into a single screen with an inline confirmation panel and inline edit affordances.",
    priority: "P1",
    effort: "3 days",
  },
  {
    action:
      "Bump secondary button color from oklch(0.55 0.02 280) to oklch(0.45 0.02 280) and update the design-system token.",
    priority: "P2",
    effort: "2 hours",
  },
  {
    action:
      "Adopt a single voice pattern for success states in the Ooster microcopy library and audit all screens against it.",
    priority: "P3",
    effort: "1 day",
  },
];

const COMPETITORS = [
  { name: "Northwind", ux: 72, speed: 18, a11y: 84, conv: 69, self: true },
  { name: "Stripe Checkout", ux: 94, speed: 9, a11y: 97, conv: 88, self: false },
  { name: "Shopify Pay", ux: 91, speed: 11, a11y: 92, conv: 84, self: false },
  { name: "Adyen Drop-in", ux: 85, speed: 14, a11y: 90, conv: 79, self: false },
  { name: "PayPal Smart", ux: 83, speed: 13, a11y: 88, conv: 81, self: false },
  { name: "Square Pay", ux: 79, speed: 16, a11y: 86, conv: 74, self: false },
];

const SECTIONS = [
  { id: "executive-summary", label: "Executive summary" },
  { id: "ux-breakdown", label: "UX score breakdown" },
  { id: "key-findings", label: "Key findings" },
  { id: "competitor-analysis", label: "Competitor analysis" },
  { id: "recommendations", label: "Recommendations" },
  { id: "related-reports", label: "Related reports" },
];

export default function ReportDetailPage() {
  const params = useParams<{ id: string }>();
  const report = getReport(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [publicSharing, setPublicSharing] = React.useState(!!report?.shared);
  const [activeSection, setActiveSection] = React.useState("executive-summary");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 250);
    return () => clearTimeout(t);
  }, []);

  React.useEffect(() => {
    if (!report) return;
    const onScroll = () => {
      for (let i = SECTIONS.length - 1; i >= 0; i--) {
        const el = document.getElementById(SECTIONS[i].id);
        if (el && el.getBoundingClientRect().top < 140) {
          setActiveSection(SECTIONS[i].id);
          return;
        }
      }
      setActiveSection(SECTIONS[0].id);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, [report]);

  if (loading) return <LoadingSkeleton variant="page" />;

  if (!report) {
    return (
      <EmptyState
        icon={FileBarChart}
        title="Report not found"
        description="This report may have been deleted, archived, or the link is incorrect."
        action={{ label: "Back to reports", href: "/reports" }}
      />
    );
  }

  const meta = TYPE_META[report.type];
  const Icon = meta.icon;
  const breakdown = scoreBreakdown(report.uxScore);
  const relatedReports = REPORTS.filter(
    (r) => r.id !== report.id && (r.project === report.project || r.type === report.type)
  ).slice(0, 3);
  const showCompetitor = report.type === "competitor";
  const shareUrl = `https://ooster.app/r/${report.id}`;

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 96;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title={report.title}
        description={report.summary}
        breadcrumbs={[
          { label: "Reports", href: "/reports" },
          { label: report.title },
        ]}
        icon={
          <div
            className="flex h-5 w-5 items-center justify-center rounded-md text-white"
            style={{ background: meta.tint }}
          >
            <Icon className="h-3.5 w-3.5" />
          </div>
        }
        badge={
          <div className="flex items-center gap-1.5">
            <Badge
              variant="outline"
              className="text-[10px] capitalize"
              style={{ background: `${meta.tint}15`, color: meta.tint, borderColor: `${meta.tint}30` }}
            >
              {meta.label}
            </Badge>
            <StatusBadge status={report.status as any} />
          </div>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Exporting PDF…", { description: "Your report will download shortly." })}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export PDF
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => {
                navigator.clipboard?.writeText(report.summary);
                toast.success("Summary copied");
              }}
            >
              <Copy className="mr-2 h-3.5 w-3.5" /> Copy summary
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => openShare(shareUrl, report.title)}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => window.print()}
            >
              <Printer className="mr-2 h-3.5 w-3.5" /> Print
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column */}
        <div className="lg:col-span-2 space-y-4">
          {/* Hero cover mockup */}
          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden card-hover">
            <div className="relative h-48 rounded-xl overflow-hidden bg-surface-2">
              <ScreenMockup variant="analytics" accentColor={meta.tint} />
              <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between gap-3 z-10">
                <div className="min-w-0 rounded-lg bg-card/85 backdrop-blur-md px-2.5 py-1.5 border border-soft shadow-soft">
                  <Badge
                    variant="outline"
                    className="text-[10px] capitalize mb-1 bg-surface-2 text-ink border-soft"
                  >
                    {meta.label} report
                  </Badge>
                  <div className="text-ink text-sm font-semibold line-clamp-1">
                    {report.title}
                  </div>
                  <div className="text-muted-foreground text-[10px] mt-0.5">
                    {report.project} · {report.pages} pages · {report.duration}
                  </div>
                </div>
                <div
                  className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl text-white shadow-card"
                  style={{ background: meta.tint }}
                >
                  <Icon className="h-5 w-5" />
                </div>
              </div>
            </div>
          </Card>

          {/* Executive summary */}
          <Card
            id="executive-summary"
            className="rounded-2xl border-soft shadow-soft p-5 scroll-mt-24 card-hover"
          >
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-ink flex items-center gap-2">
                <FileText className="h-4 w-4 text-info" /> Executive summary
              </h2>
              <Badge variant="secondary" className="text-[10px]">
                AI synthesized
              </Badge>
            </div>
            <div className="space-y-3 text-sm text-ink/90 leading-relaxed">
              <p>
                {report.project} maintains an overall UX score of{" "}
                <span className="font-semibold text-ink">{report.uxScore}/100</span>{" "}
                across {report.pages} analyzed screens. The product delivers a strong
                first-impression baseline, with accessibility scoring above industry
                average and task success holding steady for returning users. However,
                the deeper layers of the funnel — particularly first-time onboarding
                and confirmation flows — surface {FINDINGS.length} prioritized findings,
                including {FINDINGS.filter((f) => f.severity === "critical").length} critical
                friction points that correlate directly with measurable drop-off in
                session replays and heatmap dead zones.
              </p>
              <p>
                The competitor benchmark reveals a {report.type === "competitor" ? "12-second" : "measurable"}{" "}
                gap on mobile checkout speed against top-quartile peers, driven primarily
                by redundant review screens and reactive (rather than inline) validation.
                Ooster AI recommends a sequenced remediation plan: patch the silent KYC
                failure on iOS Safari as a P0, ship inline validation on form fields as a
                P1, and consolidate the review/confirm step into a single inline-confirmation
                screen. Together these changes are projected to lift task success by{" "}
                <span className="font-semibold text-success">+8 points</span> and reduce
                time-to-first-value by an estimated{" "}
                <span className="font-semibold text-success">34%</span> over the next
                two release cycles. Full evidence trails, session-replay excerpts, and
                WCAG citations are linked in the sections below.
              </p>
            </div>
          </Card>

          {/* UX score breakdown */}
          <Card
            id="ux-breakdown"
            className="rounded-2xl border-soft shadow-soft p-5 scroll-mt-24 card-hover"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-ink flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-info" /> UX score breakdown
              </h2>
              <div className="text-xs text-muted-foreground">
                Overall <span className="font-semibold text-ink">{report.uxScore}/100</span>
              </div>
            </div>
            <div className="space-y-3">
              {breakdown.map((m) => (
                <div key={m.label} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-ink font-medium">{m.label}</span>
                    <span className="text-muted-foreground tabular-nums">{m.value}/100</span>
                  </div>
                  <div className="h-2 rounded-full bg-surface-2 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${m.value}%`, background: m.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Key findings */}
          <Card
            id="key-findings"
            className="rounded-2xl border-soft shadow-soft p-5 scroll-mt-24 card-hover"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-ink flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-info" /> Key findings
              </h2>
              <Badge variant="secondary" className="text-[10px]">
                {FINDINGS.length} findings
              </Badge>
            </div>
            <StaggerGroup className="space-y-3">
              {FINDINGS.map((f, i) => (
                <StaggerItem key={i}>
                  <div
                    className="rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors card-hover"
                  >
                    <div className="flex items-start gap-2">
                      <SeverityBadge severity={f.severity} />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-ink">{f.title}</div>
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                          {f.detail}
                        </p>
                      </div>
                    </div>
                  </div>
                </StaggerItem>
              ))}
            </StaggerGroup>
          </Card>

          {/* Competitor analysis (conditional) */}
          {showCompetitor && (
            <Card
              id="competitor-analysis"
              className="rounded-2xl border-soft shadow-soft p-5 scroll-mt-24 card-hover"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-semibold text-ink flex items-center gap-2">
                  <Trophy className="h-4 w-4 text-warning" /> Competitor analysis
                </h2>
                <Badge variant="secondary" className="text-[10px]">
                  5 competitors · 4 metrics
                </Badge>
              </div>
              <div className="overflow-x-auto -mx-2 px-2">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-soft text-muted-foreground">
                      <th className="text-left font-medium py-2 pr-4">Competitor</th>
                      <th className="text-right font-medium py-2 px-2">UX score</th>
                      <th className="text-right font-medium py-2 px-2">Checkout (s)</th>
                      <th className="text-right font-medium py-2 px-2">A11y</th>
                      <th className="text-right font-medium py-2 pl-2">Conv.</th>
                    </tr>
                  </thead>
                  <tbody>
                    {COMPETITORS.map((c) => {
                      const speedColor =
                        c.speed <= 11
                          ? "text-success"
                          : c.speed >= 16
                          ? "text-friction"
                          : "text-warning";
                      return (
                        <tr
                          key={c.name}
                          className={cn(
                            "border-b border-soft last:border-0",
                            c.self && "bg-info/5"
                          )}
                        >
                          <td className="py-2.5 pr-4">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-ink">{c.name}</span>
                              {c.self && (
                                <Badge
                                  variant="outline"
                                  className="text-[9px] text-info border-info/30 bg-info/10"
                                >
                                  You
                                </Badge>
                              )}
                            </div>
                          </td>
                          <td className="text-right py-2.5 px-2 font-semibold tabular-nums text-ink">
                            {c.ux}
                          </td>
                          <td
                            className={cn(
                              "text-right py-2.5 px-2 tabular-nums font-medium",
                              speedColor
                            )}
                          >
                            {c.speed}s
                          </td>
                          <td className="text-right py-2.5 px-2 tabular-nums text-ink">
                            {c.a11y}
                          </td>
                          <td className="text-right py-2.5 pl-2 tabular-nums text-ink">
                            {c.conv}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <p className="text-[10px] text-muted-foreground mt-3">
                Benchmark data sourced from Ooster's competitor panel (n=5),
                synthesized from public teardowns + 312 anonymized session replays.
              </p>
            </Card>
          )}

          {/* Recommendations */}
          <Card
            id="recommendations"
            className="rounded-2xl border-soft shadow-soft p-5 scroll-mt-24 card-hover"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-ink flex items-center gap-2">
                <ArrowRight className="h-4 w-4 text-success" /> Recommendations
              </h2>
              <Badge variant="secondary" className="text-[10px]">
                Prioritized · with effort
              </Badge>
            </div>
            <ol className="space-y-3">
              {RECOMMENDATIONS.map((r, i) => {
                const priorityTint =
                  r.priority === "P0"
                    ? "var(--friction)"
                    : r.priority === "P1"
                    ? "var(--warning)"
                    : r.priority === "P2"
                    ? "var(--info)"
                    : "var(--muted-foreground)";
                return (
                  <li
                    key={i}
                    className="flex items-start gap-3 rounded-xl border border-soft p-3"
                  >
                    <div
                      className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full text-white text-xs font-semibold"
                      style={{ background: priorityTint }}
                    >
                      {i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge
                          variant="outline"
                          className="text-[9px] font-semibold"
                          style={{
                            color: priorityTint,
                            borderColor: `${priorityTint}30`,
                            background: `${priorityTint}10`,
                          }}
                        >
                          {r.priority}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground">
                          Effort: {r.effort}
                        </span>
                      </div>
                      <p className="text-sm text-ink leading-relaxed">{r.action}</p>
                    </div>
                  </li>
                );
              })}
            </ol>
          </Card>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Report meta */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <h3 className="text-sm font-semibold text-ink mb-3 flex items-center gap-2">
              <FileBarChart className="h-4 w-4 text-info" /> Report meta
            </h3>
            <dl className="space-y-2.5 text-xs">
              <MetaRow icon={Calendar} label="Created" value={report.createdAt} />
              <MetaRow
                icon={User}
                label="Created by"
                value={
                  <div className="flex items-center gap-1.5">
                    <Avatar className="h-4 w-4 ring-1 ring-soft">
                      <AvatarImage src={report.createdBy.avatar} alt={report.createdBy.name} />
                      <AvatarFallback>{report.createdBy.name.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <span>{report.createdBy.name}</span>
                  </div>
                }
              />
              <MetaRow icon={FolderKanban} label="Project" value={report.project} />
              <MetaRow icon={FileText} label="Pages" value={`${report.pages} pages`} />
              <MetaRow icon={Clock} label="Duration" value={report.duration} />
              <MetaRow icon={Icon} label="Type" value={meta.label} />
              <MetaRow
                icon={StatusBadge as any}
                label="Status"
                value={<StatusBadge status={report.status as any} />}
              />
            </dl>
            <div className="mt-3 pt-3 border-t border-soft flex flex-wrap gap-1">
              {report.tags.map((t) => (
                <Badge key={t} variant="secondary" className="text-[9px] font-normal">
                  {t}
                </Badge>
              ))}
            </div>
          </Card>

          {/* Table of contents (sticky) */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 lg:sticky lg:top-20 card-hover">
            <h3 className="text-sm font-semibold text-ink mb-3 flex items-center gap-2">
              <ListTree className="h-4 w-4 text-info" /> Table of contents
            </h3>
            <nav className="space-y-0.5">
              {SECTIONS.filter((s) => showCompetitor || s.id !== "competitor-analysis").map(
                (s) => (
                  <button
                    key={s.id}
                    onClick={() => scrollTo(s.id)}
                    className={cn(
                      "w-full text-left text-xs px-2 py-1.5 rounded-md transition-colors flex items-center gap-2",
                      activeSection === s.id
                        ? "bg-accent/60 text-ink font-medium"
                        : "text-muted-foreground hover:text-ink hover:bg-accent/30"
                    )}
                  >
                    <ChevronRight
                      className={cn(
                        "h-3 w-3 transition-transform",
                        activeSection === s.id && "rotate-90 text-primary"
                      )}
                    />
                    {s.label}
                  </button>
                )
              )}
            </nav>
          </Card>

          {/* Share settings */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <h3 className="text-sm font-semibold text-ink mb-3 flex items-center gap-2">
              <Share2 className="h-4 w-4 text-info" /> Share settings
            </h3>
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <div className="text-xs font-medium text-ink">Public sharing</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  Anyone with the link can view
                </div>
              </div>
              <Switch
                checked={publicSharing}
                onCheckedChange={(v) => {
                  setPublicSharing(v);
                  toast.success(v ? "Public sharing enabled" : "Public sharing disabled");
                }}
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                readOnly
                value={shareUrl}
                className="flex-1 h-8 rounded-lg border border-soft bg-surface px-2 text-[10px] text-muted-foreground truncate"
              />
              <Button
                size="sm"
                variant="outline"
                className="h-8 px-2"
                onClick={() => {
                  navigator.clipboard?.writeText(shareUrl);
                  toast.success("Link copied to clipboard");
                }}
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
            {publicSharing && (
              <div className="mt-2 flex items-center gap-1.5 text-[10px] text-success">
                <Check className="h-3 w-3" /> Link is live and accessible
              </div>
            )}
          </Card>

          {/* Related reports */}
          <Card id="related-reports" className="rounded-2xl border-soft shadow-soft p-4 scroll-mt-24 card-hover">
            <h3 className="text-sm font-semibold text-ink mb-3 flex items-center gap-2">
              <FileText className="h-4 w-4 text-info" /> Related reports
            </h3>
            <div className="space-y-2">
              {relatedReports.map((r) => {
                const m = TYPE_META[r.type];
                const RIcon = m.icon;
                return (
                  <Link
                    key={r.id}
                    href={`/reports/${r.id}`}
                    className="flex items-start gap-2 rounded-xl border border-soft p-2.5 hover:bg-accent/30 transition-colors group"
                  >
                    <div
                      className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md text-white"
                      style={{ background: m.tint }}
                    >
                      <RIcon className="h-3 w-3" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium text-ink group-hover:text-primary transition-colors line-clamp-1">
                        {r.title}
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        {r.project} · {r.pages}p · {r.duration}
                      </div>
                    </div>
                    <ChevronRight className="h-3 w-3 text-muted-foreground mt-0.5" />
                  </Link>
                );
              })}
              {relatedReports.length === 0 && (
                <div className="text-[10px] text-muted-foreground text-center py-3">
                  No related reports yet.
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </motion.div>
  );
}

function MetaRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <dt className="flex items-center gap-1.5 text-muted-foreground">
        <Icon className="h-3 w-3" /> {label}
      </dt>
      <dd className="font-medium text-ink text-right truncate">{value}</dd>
    </div>
  );
}
