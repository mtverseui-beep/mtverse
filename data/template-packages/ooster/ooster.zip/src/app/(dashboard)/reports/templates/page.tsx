"use client";

import * as React from "react";
import Link from "next/link";
import {
  LayoutTemplate,
  FileText,
  ShieldCheck,
  Trophy,
  Map,
  GitBranch,
  BarChart3,
  Check,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Layers,
  Clock,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Template {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  tint: string;
  category: "leadership" | "audit" | "competitive" | "journey" | "flow";
  sections: number;
  pages: number;
  popular?: boolean;
  includes: string[];
}

const TEMPLATES: Template[] = [
  {
    id: "tpl-exec",
    name: "Executive Summary",
    description:
      "1-page leadership overview of UX health, top risks, and prioritized roadmap. Built for stakeholder review.",
    icon: FileText,
    tint: "var(--info)",
    category: "leadership",
    sections: 5,
    pages: 8,
    popular: true,
    includes: ["UX health snapshot", "Top 3 risks", "Quarterly roadmap", "KPI table"],
  },
  {
    id: "tpl-audit",
    name: "Full UX Audit",
    description:
      "Screen-by-screen deep dive with friction inventory, severity scoring, and prioritized recommendations.",
    icon: ShieldCheck,
    tint: "var(--success)",
    category: "audit",
    sections: 12,
    pages: 32,
    popular: true,
    includes: ["24+ screens", "WCAG 2.1 cross-ref", "Friction inventory", "Rec with effort"],
  },
  {
    id: "tpl-a11y",
    name: "Accessibility Audit",
    description:
      "WCAG 2.1 AA compliance audit across every component, with citation trail and remediation tickets.",
    icon: ShieldCheck,
    tint: "var(--chart-6)",
    category: "audit",
    sections: 9,
    pages: 24,
    includes: ["WCAG AA + AAA notes", "Component matrix", "Screen reader notes", "Color contrast"],
  },
  {
    id: "tpl-comp",
    name: "Competitor Benchmark",
    description:
      "Side-by-side benchmark of up to 5 competitors across 4 KPIs, with teardown excerpts and gap analysis.",
    icon: Trophy,
    tint: "var(--warning)",
    category: "competitive",
    sections: 8,
    pages: 18,
    popular: true,
    includes: ["5 competitors", "4 KPIs", "Teardown excerpts", "Gap analysis"],
  },
  {
    id: "tpl-journey",
    name: "User Journey Map",
    description:
      "End-to-end journey map with emotional curve, friction points, and opportunity annotations per stage.",
    icon: Map,
    tint: "var(--chart-6)",
    category: "journey",
    sections: 7,
    pages: 16,
    includes: ["Stage-by-stage map", "Emotion curve", "Touchpoint inventory", "Opportunity list"],
  },
  {
    id: "tpl-flow",
    name: "Task Flow Analysis",
    description:
      "Step-by-step friction inventory for 3 core task flows, with success rates and drop-off hotspots.",
    icon: GitBranch,
    tint: "var(--chart-5)",
    category: "flow",
    sections: 6,
    pages: 14,
    includes: ["3 task flows", "Success rates", "Drop-off hotspots", "Before/after"],
  },
];

const CATEGORIES = [
  { value: "all", label: "All templates", icon: LayoutTemplate },
  { value: "leadership", label: "Leadership", icon: FileText },
  { value: "audit", label: "Audits", icon: ShieldCheck },
  { value: "competitive", label: "Competitive", icon: Trophy },
  { value: "journey", label: "Journeys", icon: Map },
  { value: "flow", label: "Task flows", icon: GitBranch },
];

export default function TemplatesPage() {
  const [category, setCategory] = React.useState("all");

  const filtered =
    category === "all"
      ? TEMPLATES
      : TEMPLATES.filter((t) => t.category === category);

  return (
    <div>
      <PageHeader
        title="Report Templates"
        description="Start from a prebuilt template. Customize sections, branding, and scheduling."
        breadcrumbs={[
          { label: "Reports", href: "/reports" },
          { label: "Templates" },
        ]}
        icon={<LayoutTemplate className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {TEMPLATES.length} templates
          </Badge>
        }
        actions={
          <Button asChild variant="outline" size="sm" className="rounded-full">
            <Link href="/reports">
              <ArrowLeft className="mr-2 h-3.5 w-3.5" /> Back to reports
            </Link>
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Sidebar */}
        <Card className="rounded-2xl border-soft shadow-soft p-3 h-fit lg:sticky lg:top-20">
          <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-2 py-2">
            Categories
          </div>
          <nav className="space-y-0.5">
            {CATEGORIES.map((c) => {
              const Icon = c.icon;
              const active = category === c.value;
              const count =
                c.value === "all"
                  ? TEMPLATES.length
                  : TEMPLATES.filter((t) => t.category === c.value).length;
              return (
                <button
                  key={c.value}
                  onClick={() => setCategory(c.value)}
                  className={cn(
                    "w-full flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-xs transition-colors text-left",
                    active
                      ? "bg-accent/60 text-ink font-medium"
                      : "text-muted-foreground hover:text-ink hover:bg-accent/30"
                  )}
                >
                  <span className="flex items-center gap-2">
                    <Icon className="h-3.5 w-3.5" /> {c.label}
                  </span>
                  <span
                    className={cn(
                      "text-[9px] rounded-full px-1.5 py-0.5",
                      active
                        ? "bg-primary text-primary-foreground"
                        : "bg-surface-2 text-muted-foreground"
                    )}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </nav>
          <div className="mt-4 pt-3 border-t border-soft px-2">
            <div className="text-[10px] font-medium text-ink mb-1 flex items-center gap-1.5">
              <Sparkles className="h-3 w-3 text-info" /> Pro tip
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Every template can be re-run on a schedule. Pick one, then enable weekly or
              monthly cadence from the report page.
            </p>
          </div>
        </Card>

        {/* Template grid */}
        <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filtered.map((t) => {
            const Icon = t.icon;
            return (
              <Card
                key={t.id}
                className="rounded-2xl border-soft shadow-soft p-4 flex flex-col hover:shadow-card hover:border-primary/30 transition-all"
              >
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div
                    className="flex h-10 w-10 items-center justify-center rounded-xl text-white"
                    style={{ background: t.tint }}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  {t.popular && (
                    <Badge
                      variant="outline"
                      className="text-[9px] text-warning border-warning/20 bg-warning/10"
                    >
                      <Sparkles className="h-2.5 w-2.5 mr-1" /> Popular
                    </Badge>
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-semibold text-ink">{t.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed line-clamp-3">
                    {t.description}
                  </p>
                  <div className="flex items-center gap-3 mt-3 text-[10px] text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <Layers className="h-3 w-3" /> {t.sections} sections
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <FileText className="h-3 w-3" /> ~{t.pages}p
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3 w-3" /> ~3 min
                    </span>
                  </div>
                  <div className="mt-3 pt-3 border-t border-soft">
                    <div className="text-[9px] font-medium uppercase tracking-wide text-muted-foreground mb-1.5">
                      Includes
                    </div>
                    <ul className="grid grid-cols-2 gap-y-1 gap-x-2">
                      {t.includes.map((inc) => (
                        <li
                          key={inc}
                          className="flex items-start gap-1 text-[10px] text-ink/90"
                        >
                          <Check className="h-2.5 w-2.5 text-success mt-0.5 flex-shrink-0" />
                          {inc}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <Button
                    size="sm"
                    className="flex-1 rounded-full"
                    onClick={() =>
                      toast.success("Template applied", {
                        description: `Starting new report from "${t.name}".`,
                      })
                    }
                  >
                    Use template <ArrowRight className="ml-1.5 h-3 w-3" />
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    size="sm"
                    className="rounded-full"
                  >
                    <Link href="/reports/generate">Customize</Link>
                  </Button>
                </div>
              </Card>
            );
          })}

          {filtered.length === 0 && (
            <Card className="col-span-full rounded-2xl border-soft shadow-soft p-10 text-center">
              <BarChart3 className="h-8 w-8 text-muted-foreground mx-auto" />
              <p className="text-sm font-medium text-ink mt-3">
                No templates in this category
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Try another category or request a custom template.
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-4 rounded-full"
                onClick={() => setCategory("all")}
              >
                Show all templates
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
