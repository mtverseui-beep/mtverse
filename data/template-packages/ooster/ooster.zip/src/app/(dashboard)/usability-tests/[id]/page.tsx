"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  ClipboardCheck,
  Video,
  Monitor,
  Smartphone,
  MapPin,
  Users,
  Timer,
  AlertTriangle,
  GraduationCap,
  Download,
  Share2,
  PlayCircle,
  ChevronRight,
  ChevronLeft,
  Quote,
  CheckCircle2,
  ImageIcon,
  ListChecks,
  Lightbulb,
  CalendarDays,
  FileText,
  Target,
  ScrollText,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { EmptyState } from "@/components/common/empty-state";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BarChart } from "@/components/charts";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type TestType = "moderated" | "unmoderated" | "remote" | "in-person";

interface MockTest {
  id: string;
  name: string;
  project: string;
  type: TestType;
  status: "completed" | "in-progress" | "analyzing";
  method: string;
  duration: string;
  startDate: string;
  endDate: string;
  owner: { name: string; avatar: string };
  tasks: MockTask[];
  participants: MockParticipant[];
  sessions: MockSession[];
  findings: string[];
  recommendations: string[];
  quotes: { text: string; participant: string; avatar: string }[];
  susScore: number;
}

interface MockTask {
  id: string;
  name: string;
  description: string;
  successRate: number;
  avgTime: string;
  errors: number;
  screenshot: string;
}

interface MockParticipant {
  id: string;
  name: string;
  avatar: string;
  age: number;
  device: "Desktop" | "Mobile" | "Tablet";
  completed: boolean;
  duration: string;
  errors: number;
}

interface MockSession {
  id: string;
  participant: string;
  avatar: string;
  duration: string;
  outcome: "completed" | "dropped" | "partial";
  recordedAt: string;
  thumbHue: number;
}

const TEST: MockTest = {
  id: "ut-301",
  name: "Atlas KYC Step 3 — Document Upload",
  project: "Atlas Onboarding",
  type: "moderated",
  status: "completed",
  method: "1:1 moderated remote · Zoom + Maze prototype",
  duration: "45 min per session",
  startDate: "2026-06-15",
  endDate: "2026-06-26",
  owner: { name: "Mira Halberg", avatar: "https://i.pravatar.cc/80?img=12" },
  susScore: 68,
  tasks: [
    { id: "t1", name: "Locate document upload field", description: "From the KYC step 3 screen, find where to upload your ID.", successRate: 92, avgTime: "0:18", errors: 0.3, screenshot: "220" },
    { id: "t2", name: "Upload passport photo", description: "Upload a passport photo from your device.", successRate: 71, avgTime: "1:42", errors: 1.1, screenshot: "180" },
    { id: "t3", name: "Fix rejected document", description: "After a rejection, retake and reupload the photo.", successRate: 41, avgTime: "3:08", errors: 2.4, screenshot: "260" },
    { id: "t4", name: "Confirm document type", description: "Select 'Passport' from the document type dropdown.", successRate: 58, avgTime: "0:54", errors: 1.8, screenshot: "140" },
    { id: "t5", name: "Submit and continue", description: "Submit the document and proceed to step 4.", successRate: 83, avgTime: "0:24", errors: 0.5, screenshot: "100" },
  ],
  participants: [
    { id: "p1", name: "Anika Rao", avatar: "https://i.pravatar.cc/80?img=5", age: 28, device: "Mobile", completed: true, duration: "42:18", errors: 2 },
    { id: "p2", name: "Marcus Chen", avatar: "https://i.pravatar.cc/80?img=11", age: 34, device: "Desktop", completed: true, duration: "38:04", errors: 1 },
    { id: "p3", name: "Priya Nair", avatar: "https://i.pravatar.cc/80?img=20", age: 31, device: "Mobile", completed: false, duration: "27:52", errors: 4 },
    { id: "p4", name: "Diego Alvarez", avatar: "https://i.pravatar.cc/80?img=33", age: 26, device: "Mobile", completed: true, duration: "44:36", errors: 3 },
    { id: "p5", name: "Yuki Tanaka", avatar: "https://i.pravatar.cc/80?img=45", age: 39, device: "Desktop", completed: true, duration: "35:21", errors: 0 },
    { id: "p6", name: "Sofia Rossi", avatar: "https://i.pravatar.cc/80?img=48", age: 42, device: "Tablet", completed: false, duration: "22:09", errors: 5 },
    { id: "p7", name: "Liam Walsh", avatar: "https://i.pravatar.cc/80?img=51", age: 29, device: "Mobile", completed: true, duration: "41:53", errors: 2 },
    { id: "p8", name: "Zara Ahmed", avatar: "https://i.pravatar.cc/80?img=60", age: 36, device: "Desktop", completed: true, duration: "37:42", errors: 1 },
  ],
  sessions: [
    { id: "s1", participant: "Anika Rao", avatar: "https://i.pravatar.cc/80?img=5", duration: "42:18", outcome: "completed", recordedAt: "Jun 15, 14:02", thumbHue: 280 },
    { id: "s2", participant: "Marcus Chen", avatar: "https://i.pravatar.cc/80?img=11", duration: "38:04", outcome: "completed", recordedAt: "Jun 16, 10:18", thumbHue: 160 },
    { id: "s3", participant: "Priya Nair", avatar: "https://i.pravatar.cc/80?img=20", duration: "27:52", outcome: "dropped", recordedAt: "Jun 17, 16:45", thumbHue: 25 },
    { id: "s4", participant: "Diego Alvarez", avatar: "https://i.pravatar.cc/80?img=33", duration: "44:36", outcome: "partial", recordedAt: "Jun 18, 09:30", thumbHue: 75 },
    { id: "s5", participant: "Yuki Tanaka", avatar: "https://i.pravatar.cc/80?img=45", duration: "35:21", outcome: "completed", recordedAt: "Jun 19, 13:12", thumbHue: 250 },
  ],
  findings: [
    "Document type dropdown labels ('Passport', 'Travel Doc') confuse users — 42% select the wrong type on first try.",
    "Rejection feedback is generic ('Try again') and doesn't explain which quality criteria failed.",
    "Mobile users struggle with file picker — 3 of 5 mobile participants accidentally chose the wrong photo.",
    "Average recovery time after rejection exceeds 3 minutes, well above the 90-second target.",
  ],
  recommendations: [
    "Relabel document type options with example images and clearer naming (e.g., 'Passport (international)').",
    "Show specific rejection reasons (blur, glare, cropped edges) with annotated previews.",
    "Replace native file picker with an in-app capture flow that guides framing.",
    "Add a 'Help me fix this' inline assistant on the rejection screen.",
  ],
  quotes: [
    { text: "I had no idea why my passport was rejected — it just said 'Try again'. I almost gave up.", participant: "Priya Nair", avatar: "https://i.pravatar.cc/80?img=20" },
    { text: "The dropdown labels are weird. 'Travel Doc' — is a passport a travel doc? I guessed wrong.", participant: "Diego Alvarez", avatar: "https://i.pravatar.cc/80?img=33" },
    { text: "On mobile, I accidentally picked a selfie instead of my passport photo. The picker is overwhelming.", participant: "Anika Rao", avatar: "https://i.pravatar.cc/80?img=5" },
  ],
};

const TYPE_ICON: Record<TestType, typeof Video> = {
  moderated: Video,
  unmoderated: Monitor,
  remote: Smartphone,
  "in-person": MapPin,
};

export default function UsabilityTestDetailPage() {
  const params = useParams<{ id: string }>();
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const test = TEST; // in real impl, look up by params.id

  const avgSuccess = Math.round(test.tasks.reduce((a, b) => a + b.successRate, 0) / test.tasks.length);
  const avgTimeMin = test.tasks.reduce((a, b) => {
    const [m, s] = b.avgTime.split(":").map(Number);
    return a + m * 60 + s;
  }, 0) / test.tasks.length;
  const avgTimeStr = `${Math.floor(avgTimeMin / 60)}:${String(Math.round(avgTimeMin % 60)).padStart(2, "0")}`;
  const avgErrors = (test.tasks.reduce((a, b) => a + b.errors, 0) / test.tasks.length).toFixed(1);

  const TypeIcon = TYPE_ICON[test.type];

  const taskBarData = test.tasks.map((t) => ({
    label: `T${t.id.replace("t", "")}`,
    value: t.successRate,
    color: t.successRate >= 80 ? "var(--success)" : t.successRate >= 60 ? "var(--warning)" : "var(--friction)",
  }));

  const participantColumns: Column<MockParticipant>[] = [
    {
      key: "name",
      header: "Participant",
      cell: (row) => (
        <div className="flex items-center gap-2 min-w-0">
          <Avatar className="h-7 w-7 flex-shrink-0">
            <AvatarImage src={row.avatar} alt={row.name} />
            <AvatarFallback className="text-[10px]">{row.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="font-medium text-ink truncate">{row.name}</div>
            <div className="text-[10px] text-muted-foreground">Age {row.age}</div>
          </div>
        </div>
      ),
      sortable: true,
      sortAccessor: (row) => row.name,
    },
    {
      key: "device",
      header: "Device",
      cell: (row) => <span className="text-xs">{row.device}</span>,
      sortable: true,
      sortAccessor: (row) => row.device,
      hideOnMobile: true,
    },
    {
      key: "duration",
      header: "Duration",
      cell: (row) => <span className="text-xs font-mono tabular-nums">{row.duration}</span>,
      sortable: true,
      sortAccessor: (row) => row.duration,
    },
    {
      key: "errors",
      header: "Errors",
      cell: (row) => (
        <span className={cn("text-xs tabular-nums", row.errors > 3 ? "text-friction" : "text-ink")}>{row.errors}</span>
      ),
      sortable: true,
      sortAccessor: (row) => row.errors,
      hideOnMobile: true,
    },
    {
      key: "completed",
      header: "Completed",
      cell: (row) =>
        row.completed ? (
          <Badge variant="outline" className="text-[10px] border-success/20 bg-success/10 text-success">
            <CheckCircle2 className="mr-1 h-3 w-3" /> Completed
          </Badge>
        ) : (
          <Badge variant="outline" className="text-[10px] border-friction/20 bg-friction/10 text-friction">
            <AlertTriangle className="mr-1 h-3 w-3" /> Dropped
          </Badge>
        ),
      sortable: true,
      sortAccessor: (row) => (row.completed ? 1 : 0),
    },
  ];

  const outcomeMeta: Record<MockSession["outcome"], { color: string; label: string }> = {
    completed: { color: "border-success/20 bg-success/10 text-success", label: "Completed" },
    dropped: { color: "border-friction/20 bg-friction/10 text-friction", label: "Dropped" },
    partial: { color: "border-warning/20 bg-warning/10 text-warning", label: "Partial" },
  };

  if (loading) return <LoadingSkeleton variant="page" />;

  return (
    <div>
      <PageHeader
        title={test.name}
        description={`${test.project} · ${test.method}`}
        breadcrumbs={[
          { label: "Research", href: "/research" },
          { label: "Usability Tests", href: "/usability-tests" },
          { label: test.id },
        ]}
        icon={<ClipboardCheck className="h-5 w-5" />}
        badge={
          <Badge variant="outline" className="text-[10px] capitalize border-info/20 bg-info/10 text-info">
            <TypeIcon className="mr-1 h-3 w-3" /> {test.type}
          </Badge>
        }
        actions={
          <>
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.info("Opening session recordings…")}>
              <Video className="mr-2 h-3.5 w-3.5" /> Sessions
            </Button>
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.success("Test report exported as PDF")}>
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="rounded-full" onClick={() => toast.success("Share link copied to clipboard")}>
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
          </>
        }
      />

      {/* Top stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Task success rate"
          value={`${avgSuccess}%`}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent={avgSuccess >= 80 ? "success" : avgSuccess >= 60 ? "warning" : "friction"}
          trend={{ value: 3.1, direction: "down", good: false }}
          sublabel="avg across 5 tasks"
        />
        <StatCard
          label="Avg time on task"
          value={avgTimeStr}
          unit="mm:ss"
          icon={<Timer className="h-4 w-4" />}
          accent="info"
          trend={{ value: 8.2, direction: "up", good: false }}
          sublabel="vs benchmark 1:30"
        />
        <StatCard
          label="Error rate"
          value={avgErrors}
          unit="/task"
          icon={<AlertTriangle className="h-4 w-4" />}
          accent="warning"
          trend={{ value: 1.4, direction: "up", good: false }}
          sublabel="across participants"
        />
        <StatCard
          label="SUS score"
          value={test.susScore}
          unit="/100"
          icon={<GraduationCap className="h-4 w-4" />}
          accent={test.susScore >= 80 ? "success" : test.susScore >= 68 ? "warning" : "friction"}
          sublabel="below 68 avg"
        />
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="bg-surface-2 h-9 rounded-xl p-1 overflow-x-auto no-scrollbar max-w-full">
          <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
          <TabsTrigger value="tasks" className="text-xs">Tasks ({test.tasks.length})</TabsTrigger>
          <TabsTrigger value="participants" className="text-xs">Participants ({test.participants.length})</TabsTrigger>
          <TabsTrigger value="sessions" className="text-xs">Sessions ({test.sessions.length})</TabsTrigger>
          <TabsTrigger value="results" className="text-xs">Results</TabsTrigger>
        </TabsList>

        {/* Overview tab */}
        <TabsContent value="overview" className="mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="h-4 w-4 text-info" />
                <div className="text-sm font-semibold text-ink">Test metadata</div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <div className="text-[10px] text-muted-foreground mb-0.5">Method</div>
                  <div className="font-medium text-ink">{test.method}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground mb-0.5">Duration</div>
                  <div className="font-medium text-ink">{test.duration}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground mb-0.5">Participants</div>
                  <div className="font-medium text-ink">{test.participants.length} recruited</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground mb-0.5">Start date</div>
                  <div className="font-medium text-ink">{test.startDate}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground mb-0.5">End date</div>
                  <div className="font-medium text-ink">{test.endDate}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground mb-0.5">Owner</div>
                  <div className="flex items-center gap-1.5">
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={test.owner.avatar} alt={test.owner.name} />
                      <AvatarFallback className="text-[9px]">{test.owner.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                    </Avatar>
                    <span className="font-medium text-ink">{test.owner.name}</span>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <ScrollText className="h-4 w-4 text-warning" />
                <div className="text-sm font-semibold text-ink">Methodology</div>
              </div>
              <ul className="space-y-2 text-xs text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-ink mt-0.5">•</span> Recruited 12 participants matching the Atlas KYC persona</li>
                <li className="flex items-start gap-2"><span className="text-ink mt-0.5">•</span> 45-minute moderated sessions over Zoom + Maze</li>
                <li className="flex items-start gap-2"><span className="text-ink mt-0.5">•</span> Think-aloud protocol, 5 tasks, SUS questionnaire at end</li>
                <li className="flex items-start gap-2"><span className="text-ink mt-0.5">•</span> Recorded with consent; analyzed by 2 researchers</li>
              </ul>
            </Card>
          </div>

          <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4">
            <div className="flex items-center gap-2 mb-3">
              <Lightbulb className="h-4 w-4 text-warning" />
              <div className="text-sm font-semibold text-ink">Key findings</div>
            </div>
            <div className="space-y-3">
              {test.findings.map((f, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-surface-2/50">
                  <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-warning/15 text-warning text-[10px] font-semibold">
                    {i + 1}
                  </span>
                  <p className="text-xs text-ink leading-relaxed">{f}</p>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Tasks tab */}
        <TabsContent value="tasks" className="mt-4">
          <div className="space-y-3">
            {test.tasks.map((task, i) => {
              const color = task.successRate >= 80 ? "var(--success)" : task.successRate >= 60 ? "var(--warning)" : "var(--friction)";
              return (
                <Card key={task.id} className="rounded-2xl border-soft shadow-soft p-4">
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                    {/* Screenshot mock */}
                    <div className="md:col-span-3">
                      <div
                        className="aspect-video rounded-xl flex items-center justify-center"
                        style={{
                          background: `linear-gradient(135deg, hsl(${task.screenshot} 35% 85%), hsl(${task.screenshot} 40% 70%))`,
                        }}
                      >
                        <ImageIcon className="h-6 w-6 text-white/70" />
                      </div>
                    </div>

                    {/* Task details */}
                    <div className="md:col-span-6">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-[10px]">Task {i + 1}</Badge>
                      </div>
                      <h3 className="text-sm font-semibold text-ink mb-1">{task.name}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{task.description}</p>
                      <div className="flex items-center gap-4 mt-2 text-[10px]">
                        <span className="text-muted-foreground">Avg time: <span className="font-mono text-ink">{task.avgTime}</span></span>
                        <span className="text-muted-foreground">Errors: <span className="text-ink tabular-nums">{task.errors.toFixed(1)}</span></span>
                      </div>
                    </div>

                    {/* Success rate */}
                    <div className="md:col-span-3 flex flex-col items-start md:items-end justify-center gap-1.5">
                      <div className="text-[10px] text-muted-foreground">Success rate</div>
                      <div className="text-2xl font-semibold tabular-nums" style={{ color }}>{task.successRate}%</div>
                      <div className="h-1.5 w-full md:w-24 rounded-full bg-surface-2 overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${task.successRate}%`, background: color }} />
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Participants tab */}
        <TabsContent value="participants" className="mt-4">
          <DataTable
            data={test.participants}
            columns={participantColumns}
            getRowId={(row) => row.id}
            searchable
            searchPlaceholder="Search participants…"
            searchKeys={["name", "device"]}
            pageSize={10}
          />
        </TabsContent>

        {/* Sessions tab */}
        <TabsContent value="sessions" className="mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {test.sessions.map((s) => {
              const meta = outcomeMeta[s.outcome];
              return (
                <Card key={s.id} className="rounded-2xl border-soft shadow-soft overflow-hidden group cursor-pointer hover:shadow-card transition-all"
                  onClick={() => toast.info(`Opening replay: ${s.participant}`)}
                >
                  <div
                    className="aspect-video relative flex items-center justify-center"
                    style={{
                      background: `linear-gradient(135deg, hsl(${s.thumbHue} 40% 80%), hsl(${s.thumbHue} 50% 55%))`,
                    }}
                  >
                    <div className="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-colors" />
                    <PlayCircle className="h-10 w-10 text-white/90 relative z-10 group-hover:scale-110 transition-transform" />
                    <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/40 text-white text-[10px] font-mono">
                      {s.duration}
                    </div>
                  </div>
                  <div className="p-3">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <Avatar className="h-5 w-5">
                          <AvatarImage src={s.avatar} alt={s.participant} />
                          <AvatarFallback className="text-[9px]">{s.participant.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                        </Avatar>
                        <span className="text-xs font-medium text-ink truncate">{s.participant}</span>
                      </div>
                      <Badge variant="outline" className={cn("text-[10px]", meta.color)}>{meta.label}</Badge>
                    </div>
                    <div className="text-[10px] text-muted-foreground">{s.recordedAt}</div>
                  </div>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Results tab */}
        <TabsContent value="results" className="mt-4 space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center gap-2 mb-3">
                <Target className="h-4 w-4 text-info" />
                <div className="text-sm font-semibold text-ink">Success rate by task</div>
              </div>
              <BarChart data={taskBarData} height={200} showValues />
              <div className="mt-3 pt-3 border-t border-soft flex items-center gap-3 text-[10px]">
                <div className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ background: "var(--success)" }} /><span className="text-muted-foreground">≥80%</span></div>
                <div className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ background: "var(--warning)" }} /><span className="text-muted-foreground">60–79%</span></div>
                <div className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ background: "var(--friction)" }} /><span className="text-muted-foreground">&lt;60%</span></div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <ListChecks className="h-4 w-4 text-warning" />
                <div className="text-sm font-semibold text-ink">Recommendations</div>
              </div>
              <ol className="space-y-2.5">
                {test.recommendations.map((r, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-warning/15 text-warning text-[9px] font-semibold mt-0.5">
                      {i + 1}
                    </span>
                    <p className="text-xs text-ink leading-relaxed">{r}</p>
                  </li>
                ))}
              </ol>
            </Card>
          </div>

          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Quote className="h-4 w-4 text-info" />
              <div className="text-sm font-semibold text-ink">Qualitative feedback</div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {test.quotes.map((q, i) => (
                <div key={i} className="p-3 rounded-xl bg-surface-2/50 border border-soft">
                  <Quote className="h-4 w-4 text-muted-foreground/40 mb-2" />
                  <p className="text-xs text-ink italic leading-relaxed mb-3">"{q.text}"</p>
                  <div className="flex items-center gap-1.5">
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={q.avatar} alt={q.participant} />
                      <AvatarFallback className="text-[9px]">{q.participant.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                    </Avatar>
                    <span className="text-[10px] text-muted-foreground">{q.participant}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Footer nav */}
      <div className="mt-6 flex items-center justify-between">
        <Link href="/usability-tests" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-ink transition-colors">
          <ChevronLeft className="h-3.5 w-3.5" /> Back to all tests
        </Link>
        <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.success("Recommendations synced to Issues")}>
          <ListChecks className="mr-2 h-3.5 w-3.5" /> Sync to issues
        </Button>
      </div>
    </div>
  );
}
