"use client";

import * as React from "react";
import Link from "next/link";
import {
  ClipboardCheck,
  Plus,
  Users,
  CheckCircle2,
  Timer,
  FlaskConical,
  Video,
  Monitor,
  Smartphone,
  MapPin,
  ChevronRight,
  Search,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { EmptyState } from "@/components/common/empty-state";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type TestType = "moderated" | "unmoderated" | "remote" | "in-person";
type TestStatus = "completed" | "in-progress" | "scheduled" | "analyzing";

interface UsabilityTest {
  id: string;
  name: string;
  project: string;
  type: TestType;
  status: TestStatus;
  taskCount: number;
  participants: number;
  targetParticipants: number;
  taskSuccess: number;
  lastRun: string;
  owner: { name: string; avatar: string };
}

const TESTS: UsabilityTest[] = [
  { id: "ut-301", name: "Atlas KYC Step 3 — Document Upload", project: "Atlas Onboarding", type: "moderated", status: "completed", taskCount: 5, participants: 12, targetParticipants: 12, taskSuccess: 58, lastRun: "2 days ago", owner: { name: "Mira Halberg", avatar: "https://i.pravatar.cc/80?img=12" } },
  { id: "ut-302", name: "Northwind Guest Checkout Flow", project: "Northwind Checkout", type: "unmoderated", status: "completed", taskCount: 4, participants: 24, targetParticipants: 24, taskSuccess: 81, lastRun: "5 days ago", owner: { name: "Sana Iqbal", avatar: "https://i.pravatar.cc/80?img=20" } },
  { id: "ut-303", name: "Voyage Mobile Filter Discovery", project: "Voyage Booking", type: "remote", status: "in-progress", taskCount: 6, participants: 8, targetParticipants: 16, taskSuccess: 64, lastRun: "Today", owner: { name: "Theo Park", avatar: "https://i.pravatar.cc/80?img=13" } },
  { id: "ut-304", name: "Cadence Habit-Setting Onboarding", project: "Cadence Mobile", type: "unmoderated", status: "analyzing", taskCount: 5, participants: 32, targetParticipants: 32, taskSuccess: 73, lastRun: "1 week ago", owner: { name: "Idris Khoury", avatar: "https://i.pravatar.cc/80?img=33" } },
  { id: "ut-305", name: "Helix Dashboard Information Architecture", project: "Helix Prototype", type: "in-person", status: "completed", taskCount: 7, participants: 6, targetParticipants: 6, taskSuccess: 89, lastRun: "3 weeks ago", owner: { name: "Lena Ortiz", avatar: "https://i.pravatar.cc/80?img=45" } },
  { id: "ut-306", name: "Riverside Component Library — Naming", project: "Riverside Design System", type: "moderated", status: "scheduled", taskCount: 3, participants: 0, targetParticipants: 10, taskSuccess: 0, lastRun: "—", owner: { name: "Aria Mendez", avatar: "https://i.pravatar.cc/80?img=48" } },
  { id: "ut-307", name: "Atlas Wallet Recovery Flow", project: "Atlas Onboarding", type: "remote", status: "completed", taskCount: 4, participants: 14, targetParticipants: 14, taskSuccess: 92, lastRun: "4 days ago", owner: { name: "Mira Halberg", avatar: "https://i.pravatar.cc/80?img=12" } },
  { id: "ut-308", name: "Voyage Booking Cancellation Path", project: "Voyage Booking", type: "unmoderated", status: "completed", taskCount: 3, participants: 18, targetParticipants: 18, taskSuccess: 96, lastRun: "6 days ago", owner: { name: "Sana Iqbal", avatar: "https://i.pravatar.cc/80?img=20" } },
  { id: "ut-309", name: "Northwind Address Autocomplete Comparison", project: "Northwind Checkout", type: "moderated", status: "in-progress", taskCount: 5, participants: 4, targetParticipants: 12, taskSuccess: 67, lastRun: "Today", owner: { name: "Sana Iqbal", avatar: "https://i.pravatar.cc/80?img=20" } },
];

const TYPE_META: Record<TestType, { label: string; icon: typeof Video; color: string }> = {
  moderated: { label: "Moderated", icon: Video, color: "border-info/20 bg-info/10 text-info" },
  unmoderated: { label: "Unmoderated", icon: Monitor, color: "border-success/20 bg-success/10 text-success" },
  remote: { label: "Remote", icon: Smartphone, color: "border-warning/20 bg-warning/10 text-warning" },
  "in-person": { label: "In-person", icon: MapPin, color: "border-chart-5/20 bg-chart-5/10 text-chart-5" },
};

const STATUS_META: Record<TestStatus, string> = {
  completed: "border-success/20 bg-success/10 text-success",
  "in-progress": "border-info/20 bg-info/10 text-info",
  scheduled: "border-border bg-muted text-muted-foreground",
  analyzing: "border-warning/20 bg-warning/10 text-warning",
};

export default function UsabilityTestsPage() {
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [typeFilter, setTypeFilter] = React.useState("all");
  const [statusFilter, setStatusFilter] = React.useState("all");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return TESTS.filter((t) => {
      if (search && !`${t.name} ${t.project}`.toLowerCase().includes(search.toLowerCase())) return false;
      if (typeFilter !== "all" && t.type !== typeFilter) return false;
      if (statusFilter !== "all" && t.status !== statusFilter) return false;
      return true;
    });
  }, [search, typeFilter, statusFilter]);

  const totalParticipants = TESTS.reduce((a, b) => a + b.participants, 0);
  const inProgress = TESTS.filter((t) => t.status === "in-progress").length;
  const completedTests = TESTS.filter((t) => t.status === "completed");
  const avgSuccess = completedTests.length
    ? Math.round(completedTests.reduce((a, b) => a + b.taskSuccess, 0) / completedTests.length)
    : 0;

  return (
    <div>
      <PageHeader
        title="Usability Tests"
        description="Moderated and unmoderated usability testing across tasks and prototypes"
        breadcrumbs={[{ label: "Research" }, { label: "Usability Tests" }]}
        icon={<ClipboardCheck className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">{TESTS.length} tests</Badge>}
        actions={
          <Button size="sm" className="rounded-full" onClick={() => toast.success("New test wizard opened")}>
            <Plus className="mr-2 h-3.5 w-3.5" /> New test
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Total tests"
              value={TESTS.length}
              icon={<FlaskConical className="h-4 w-4" />}
              accent="info"
              trend={{ value: 12, direction: "up", good: true }}
              sublabel="vs last quarter"
            />
            <StatCard
              label="In progress"
              value={inProgress}
              icon={<Timer className="h-4 w-4" />}
              accent="warning"
              sublabel="across 2 projects"
            />
            <StatCard
              label="Avg task success"
              value={`${avgSuccess}%`}
              icon={<CheckCircle2 className="h-4 w-4" />}
              accent="success"
              trend={{ value: 4.2, direction: "up", good: true }}
              sublabel="completed tests"
            />
            <StatCard
              label="Participants tested"
              value={totalParticipants}
              icon={<Users className="h-4 w-4" />}
              accent="default"
              trend={{ value: 18, direction: "up", good: true }}
              sublabel="all-time"
            />
          </div>

          {/* Filter bar */}
          <Card className="rounded-2xl border-soft shadow-soft p-3 mb-4">
            <FilterBar
              search={{ value: search, onChange: setSearch, placeholder: "Search tests or projects…" }}
              selects={[
                {
                  label: "Type",
                  value: typeFilter,
                  onChange: setTypeFilter,
                  options: [
                    { label: "All types", value: "all" },
                    { label: "Moderated", value: "moderated" },
                    { label: "Unmoderated", value: "unmoderated" },
                    { label: "Remote", value: "remote" },
                    { label: "In-person", value: "in-person" },
                  ],
                },
                {
                  label: "Status",
                  value: statusFilter,
                  onChange: setStatusFilter,
                  options: [
                    { label: "All statuses", value: "all" },
                    { label: "Completed", value: "completed" },
                    { label: "In progress", value: "in-progress" },
                    { label: "Analyzing", value: "analyzing" },
                    { label: "Scheduled", value: "scheduled" },
                  ],
                },
              ]}
              onClear={() => { setSearch(""); setTypeFilter("all"); setStatusFilter("all"); }}
            />
          </Card>

          {/* Test cards grid */}
          {filtered.length === 0 ? (
            <EmptyState
              icon={Search}
              title="No tests match your filters"
              description="Try widening your search or clearing filters to see all usability tests."
              action={{ label: "Clear filters", onClick: () => { setSearch(""); setTypeFilter("all"); setStatusFilter("all"); } }}
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filtered.map((t) => {
                const typeMeta = TYPE_META[t.type];
                const TypeIcon = typeMeta.icon;
                const successColor =
                  t.taskSuccess >= 85 ? "var(--success)" : t.taskSuccess >= 70 ? "var(--warning)" : t.taskSuccess > 0 ? "var(--friction)" : "var(--muted-foreground)";
                return (
                  <Link key={t.id} href={`/usability-tests/${t.id}`} className="group">
                    <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card transition-all group-hover:-translate-y-0.5">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <Badge variant="outline" className={cn("text-[10px] capitalize", typeMeta.color)}>
                          <TypeIcon className="mr-1 h-3 w-3" /> {typeMeta.label}
                        </Badge>
                        <Badge variant="outline" className={cn("text-[10px] capitalize", STATUS_META[t.status])}>
                          {t.status.replace("-", " ")}
                        </Badge>
                      </div>
                      <h3 className="text-sm font-semibold text-ink leading-snug mb-1 line-clamp-2">
                        {t.name}
                      </h3>
                      <div className="text-[11px] text-muted-foreground mb-3">{t.project}</div>

                      {/* task success bar */}
                      <div className="space-y-1 mb-3">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="text-muted-foreground">Task success</span>
                          <span className="font-semibold tabular-nums" style={{ color: successColor }}>
                            {t.taskSuccess > 0 ? `${t.taskSuccess}%` : "—"}
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all"
                            style={{ width: `${t.taskSuccess}%`, background: successColor }}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-[10px] pt-3 border-t border-soft">
                        <div>
                          <div className="text-muted-foreground">Tasks</div>
                          <div className="font-semibold text-ink tabular-nums">{t.taskCount}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Participants</div>
                          <div className="font-semibold text-ink tabular-nums">{t.participants}/{t.targetParticipants}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Last run</div>
                          <div className="font-semibold text-ink">{t.lastRun}</div>
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-soft flex items-center justify-between">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Avatar className="h-5 w-5">
                            <AvatarImage src={t.owner.avatar} alt={t.owner.name} />
                            <AvatarFallback className="text-[9px]">{t.owner.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                          </Avatar>
                          <span className="text-[10px] text-muted-foreground truncate">{t.owner.name}</span>
                        </div>
                        <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-ink group-hover:translate-x-0.5 transition-all" />
                      </div>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}
