"use client";

import * as React from "react";
import Link from "next/link";
import {
  GitBranch,
  Plus,
  Download,
  ChevronRight,
  Users,
  Clock,
  AlertTriangle,
  TrendingDown,
  Activity,
  ArrowRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { CircleProgress } from "@/components/common/circle-progress";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { JOURNEYS, PERSONAS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const frictionColor = (n: number) => {
  if (n >= 3) return "var(--friction)";
  if (n === 2) return "var(--warning)";
  return "var(--success)";
};

// Stable persona avatar lookup by persona string
const personaAvatars: Record<string, { name: string; avatar: string }> = {
  "New Customer": { name: "Pragmatic Priya", avatar: PERSONAS[0].avatar },
  "Returning Shopper": { name: "Conversion Cara", avatar: PERSONAS[2].avatar },
};

function parseDurationToSeconds(d: string): number {
  // formats like "8:32" or "1:42"
  const parts = d.split(":").map((p) => parseInt(p, 10));
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return 0;
}

export default function JourneysPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const total = JOURNEYS.length;
  const avgCompletion = Math.round(
    JOURNEYS.reduce((s, j) => s + j.completionRate, 0) / JOURNEYS.length
  );
  const totalFriction = JOURNEYS.reduce((s, j) => s + j.frictionPoints, 0);
  const avgSeconds =
    JOURNEYS.reduce((s, j) => s + parseDurationToSeconds(j.avgTime), 0) /
    JOURNEYS.length;
  const avgTimeStr = `${Math.floor(avgSeconds / 60)}:${String(
    Math.round(avgSeconds % 60)
  ).padStart(2, "0")}`;

  return (
    <div>
      <PageHeader
        title="User Journeys"
        description="End-to-end journey maps with friction indicators and drop-off points"
        icon={<GitBranch className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {JOURNEYS.length} journeys mapped
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Journey map exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Map a new journey from a session")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> New journey
            </Button>
          </>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total journeys"
          value={total}
          icon={<GitBranch className="h-4 w-4" />}
          accent="info"
          sublabel="across all projects"
        />
        <StatCard
          label="Avg completion rate"
          value={`${avgCompletion}%`}
          icon={<Activity className="h-4 w-4" />}
          accent={avgCompletion >= 50 ? "success" : "warning"}
          trend={{ value: 4.1, direction: "up", good: true }}
          sublabel="vs last sprint"
        />
        <StatCard
          label="Total friction points"
          value={totalFriction}
          icon={<AlertTriangle className="h-4 w-4" />}
          accent="friction"
          sublabel="across active journeys"
        />
        <StatCard
          label="Avg time-to-complete"
          value={avgTimeStr}
          icon={<Clock className="h-4 w-4" />}
          accent="default"
          trend={{ value: 6.4, direction: "down", good: true }}
          sublabel="vs last sprint"
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : JOURNEYS.length === 0 ? (
        <EmptyState
          icon={GitBranch}
          title="No journeys mapped yet"
          description="Map your first end-to-end journey from session replays or research studies to surface friction and drop-off points."
          action={{ label: "Map a journey", onClick: () => toast.message("Opening journey builder") }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {JOURNEYS.map((j) => {
            const persona = personaAvatars[j.persona] ?? {
              name: j.persona,
              avatar: PERSONAS[0].avatar,
            };
            const color = frictionColor(j.frictionPoints);
            const lastStep = j.steps[j.steps.length - 1];
            const firstStep = j.steps[0];
            const finalUsers = lastStep?.users ?? 0;
            const startUsers = firstStep?.users ?? 1;
            const finalPct = Math.round((finalUsers / startUsers) * 100);

            return (
              <Card
                key={j.id}
                className="rounded-2xl border-soft shadow-soft p-5 flex flex-col hover:shadow-card hover:border-primary/30 transition-all"
              >
                {/* Header: persona + completion ring */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar className="h-10 w-10 ring-1 ring-soft flex-shrink-0">
                      <AvatarImage src={persona.avatar} alt={persona.name} />
                      <AvatarFallback>{persona.name.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                        {j.persona}
                      </div>
                      <div className="text-[10px] text-muted-foreground truncate">
                        {persona.name}
                      </div>
                    </div>
                  </div>
                  <CircleProgress
                    value={j.completionRate}
                    size={56}
                    strokeWidth={5}
                    color={color}
                    sublabel="done"
                  >
                    <span className="text-sm font-semibold text-ink">
                      {j.completionRate}%
                    </span>
                  </CircleProgress>
                </div>

                {/* Title */}
                <Link
                  href={`/journeys/${j.id}`}
                  className="text-sm font-semibold text-ink hover:text-primary transition-colors line-clamp-2 mb-2"
                >
                  {j.name}
                </Link>

                {/* Meta badges */}
                <div className="flex flex-wrap items-center gap-1.5 mb-4">
                  <Badge variant="outline" className="text-[10px]">
                    {j.project}
                  </Badge>
                  <Badge
                    variant="secondary"
                    className="text-[10px] capitalize"
                  >
                    {j.status}
                  </Badge>
                </div>

                {/* Mini metric strip */}
                <div className="grid grid-cols-3 gap-2 mb-4 py-3 border-y border-soft">
                  <div>
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                      <GitBranch className="h-3 w-3" />
                      Steps
                    </div>
                    <div className="text-sm font-semibold text-ink">
                      {j.steps.length}
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                      <AlertTriangle className="h-3 w-3" />
                      Friction
                    </div>
                    <div
                      className="text-sm font-semibold"
                      style={{ color }}
                    >
                      {j.frictionPoints}
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                      <TrendingDown className="h-3 w-3" />
                      Drop-off
                    </div>
                    <div className="text-sm font-semibold text-friction">
                      {j.dropOff}%
                    </div>
                  </div>
                </div>

                {/* Mini step flow */}
                <div className="flex items-center gap-0.5 mb-4">
                  {j.steps.map((s, i) => {
                    const sc =
                      s.friction === "high"
                        ? "var(--friction)"
                        : s.friction === "medium"
                        ? "var(--warning)"
                        : "var(--success)";
                    const pct = Math.max(
                      8,
                      Math.round((s.users / startUsers) * 100)
                    );
                    return (
                      <React.Fragment key={s.id}>
                        <div
                          className="h-1.5 rounded-full"
                          style={{ width: `${pct / 5}%`, background: sc }}
                          title={`${s.name} · ${s.users} users`}
                        />
                        {i < j.steps.length - 1 && (
                          <ChevronRight className="h-2.5 w-2.5 text-muted-foreground flex-shrink-0" />
                        )}
                      </React.Fragment>
                    );
                  })}
                </div>

                {/* Footer */}
                <div className="mt-auto flex items-center justify-between pt-1">
                  <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {j.avgTime}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Users className="h-3 w-3" /> {finalPct}% reach end
                    </span>
                  </div>
                  <Button
                    asChild
                    size="sm"
                    variant="ghost"
                    className="h-7 text-xs rounded-full px-2 hover:bg-accent/30"
                  >
                    <Link href={`/journeys/${j.id}`}>
                      View journey
                      <ArrowRight className="ml-1 h-3 w-3" />
                    </Link>
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
