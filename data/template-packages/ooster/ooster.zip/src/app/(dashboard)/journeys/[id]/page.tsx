"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  GitBranch,
  Share2,
  Download,
  Clock,
  AlertTriangle,
  TrendingDown,
  Activity,
  Users,
  Target,
  Lightbulb,
  ChevronRight,
  ArrowRight,
  CheckCircle2,
  PersonStanding,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useModals } from "@/hooks/use-modals";
import { JOURNEYS, PERSONAS, getJourney } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { motion } from "framer-motion";

const frictionColor = (level: "low" | "medium" | "high") =>
  level === "high"
    ? "var(--friction)"
    : level === "medium"
    ? "var(--warning)"
    : "var(--success)";

const frictionLabel = (level: "low" | "medium" | "high") =>
  level === "high" ? "High friction" : level === "medium" ? "Medium friction" : "Low friction";

interface Suggestion {
  title: string;
  detail: string;
  impact: "high" | "medium" | "low";
  stepRef: string;
}

const SUGGESTIONS_BY_JOURNEY: Record<string, Suggestion[]> = {
  "j-001": [
    {
      title: "Split KYC into 3 micro-steps",
      detail:
        "The KYC step shows 26% drop-off — break the single screen into 'Document type', 'Front of ID', and 'Selfie' with a progress indicator to reduce cognitive load.",
      impact: "high",
      stepRef: "Step 3 · KYC verification",
    },
    {
      title: "Prefill phone from device",
      detail:
        "Account signup could auto-fill phone number from device telephony API. Reduces input friction and verification retries by ~14%.",
      impact: "medium",
      stepRef: "Step 2 · Account signup",
    },
    {
      title: "Surface funding options earlier",
      detail:
        "Show 1-line funding summaries on the wallet setup screen (e.g. 'Bank · Instant · 0 fee') to reduce decision time before funding source selection.",
      impact: "medium",
      stepRef: "Step 4 · Wallet setup",
    },
    {
      title: "Add 'first transfer' template",
      detail:
        "Pre-fill recipient + amount from a saved template to halve median first-transfer time for repeat-user pairs.",
      impact: "low",
      stepRef: "Step 5 · First transfer",
    },
  ],
  "j-002": [
    {
      title: "Single-page checkout",
      detail:
        "Checkout currently splits shipping + payment across 2 screens. Merge into one progressive form with a sticky summary — projected 12pp lift on completion.",
      impact: "high",
      stepRef: "Step 4 · Checkout",
    },
    {
      title: "Guest checkout by default",
      detail:
        "Force-account at checkout is the top reason for abandonment. Default to guest, offer account creation post-purchase.",
      impact: "high",
      stepRef: "Step 4 · Checkout",
    },
    {
      title: "Express pay on PDP",
      detail:
        "Add Apple Pay / Google Pay buttons directly on the product page to skip cart for high-intent buyers.",
      impact: "medium",
      stepRef: "Step 3 · Add to cart",
    },
    {
      title: "Persistent cart summary",
      detail:
        "Keep cart summary visible during checkout steps so users don't bounce back to review items.",
      impact: "low",
      stepRef: "Step 4 · Checkout",
    },
  ],
};

function formatUsers(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return `${n}`;
}

export default function JourneyDetailPage() {
  const params = useParams<{ id: string }>();
  const journey = getJourney(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  if (!journey) {
    return (
      <EmptyState
        icon={GitBranch}
        title="Journey not found"
        description="This journey may have been archived, deleted, or never existed."
        action={{ label: "Back to journeys", href: "/journeys" }}
      />
    );
  }

  const startUsers = journey.steps[0]?.users ?? 1;
  const suggestions =
    SUGGESTIONS_BY_JOURNEY[journey.id] ?? SUGGESTIONS_BY_JOURNEY["j-001"];
  const persona = PERSONAS.find((p) => p.segment.toLowerCase().includes(journey.persona.toLowerCase().split(" ")[0])) ?? PERSONAS[0];

  const handleExport = () => toast.success("Journey map exported as PDF");
  const handleShare = () => openShare(`/journeys/${journey.id}`, journey.name);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title={journey.name}
        description={`${journey.steps.length} steps · ${journey.persona} persona · ${journey.project}`}
        breadcrumbs={[
          { label: "Journeys", href: "/journeys" },
          { label: `#${journey.id}` },
        ]}
        icon={<GitBranch className="h-5 w-5" />}
        badge={
          <Badge
            variant="outline"
            className={cn(
              "text-[10px] capitalize",
              journey.status === "active"
                ? "bg-success/15 text-success border-success/20"
                : "bg-muted text-muted-foreground border-border"
            )}
          >
            {journey.status}
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleShare}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleExport}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main content — step flow + stats */}
        <div className="lg:col-span-2 space-y-4">
          {/* Step flow visualization */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <Activity className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">
                  Step-by-step flow
                </h3>
              </div>
              <div className="hidden sm:flex items-center gap-3 text-[10px] text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--success)" }} />
                  Low
                </span>
                <span className="inline-flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--warning)" }} />
                  Medium
                </span>
                <span className="inline-flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--friction)" }} />
                  High
                </span>
              </div>
            </div>

            <div className="overflow-x-auto -mx-1 px-1 pb-2">
              <div className="flex items-stretch gap-2 min-w-max">
                {journey.steps.map((step, idx) => {
                  const color = frictionColor(step.friction);
                  const isLast = idx === journey.steps.length - 1;
                  return (
                    <React.Fragment key={step.id}>
                      <motion.div
                        className="w-56 flex-shrink-0 rounded-2xl border bg-card p-3 flex flex-col card-hover"
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{
                          duration: 0.35,
                          delay: idx * 0.1,
                          ease: [0.22, 1, 0.36, 1],
                        }}
                        whileHover={{ y: -3 }}
                        style={{
                          borderColor: `color-mix(in oklch, ${color} 35%, var(--border))`,
                          background: `linear-gradient(180deg, color-mix(in oklch, ${color} 5%, var(--card)), var(--card))`,
                        }}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span
                            className="flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-semibold"
                            style={{
                              background: `color-mix(in oklch, ${color} 18%, var(--card))`,
                              color,
                            }}
                          >
                            {idx + 1}
                          </span>
                          <span
                            className="text-[9px] font-medium px-1.5 py-0.5 rounded-full"
                            style={{
                              background: `color-mix(in oklch, ${color} 12%, var(--card))`,
                              color,
                            }}
                          >
                            {frictionLabel(step.friction)}
                          </span>
                        </div>

                        <div className="text-sm font-semibold text-ink mb-1 line-clamp-1">
                          {step.name}
                        </div>
                        <div className="text-[10px] text-muted-foreground line-clamp-2 mb-3 leading-relaxed">
                          {step.description}
                        </div>

                        <div className="mt-auto grid grid-cols-2 gap-1.5 pt-2 border-t border-soft">
                          <div>
                            <div className="text-[9px] text-muted-foreground">
                              Users
                            </div>
                            <div className="text-xs font-semibold text-ink">
                              {formatUsers(step.users)}
                            </div>
                          </div>
                          <div>
                            <div className="text-[9px] text-muted-foreground">
                              Conversion
                            </div>
                            <div className="text-xs font-semibold text-ink">
                              {step.conversion}%
                            </div>
                          </div>
                          <div>
                            <div className="text-[9px] text-muted-foreground">
                              Avg time
                            </div>
                            <div className="text-xs font-semibold text-ink">
                              {step.avgTime}
                            </div>
                          </div>
                          <div>
                            <div className="text-[9px] text-muted-foreground">
                              Drop-off
                            </div>
                            <div
                              className="text-xs font-semibold"
                              style={{ color }}
                            >
                              {step.dropOff}%
                            </div>
                          </div>
                        </div>
                      </motion.div>

                      {!isLast && (
                        <div className="flex items-center justify-center w-8 flex-shrink-0">
                          <ArrowRight
                            className="h-5 w-5 text-muted-foreground"
                            style={{ color: frictionColor(journey.steps[idx + 1].friction) }}
                          />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>
          </Card>

          {/* Overall stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard
              label="Overall completion"
              value={`${journey.completionRate}%`}
              icon={<CheckCircle2 className="h-4 w-4" />}
              accent={journey.completionRate >= 50 ? "success" : "warning"}
              sublabel={`${formatUsers(startUsers)} → ${formatUsers(
                journey.steps[journey.steps.length - 1].users
              )} users`}
            />
            <StatCard
              label="Avg time-to-complete"
              value={journey.avgTime}
              icon={<Clock className="h-4 w-4" />}
              trend={{ value: 8.2, direction: "down", good: true }}
              sublabel="vs last sprint"
            />
            <StatCard
              label="Friction points"
              value={journey.frictionPoints}
              icon={<AlertTriangle className="h-4 w-4" />}
              accent="friction"
              sublabel="across all steps"
            />
            <StatCard
              label="Overall drop-off"
              value={`${journey.dropOff}%`}
              icon={<TrendingDown className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 3.1, direction: "down", good: true }}
              sublabel="vs last sprint"
            />
          </div>

          {/* Per-step breakdown */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <TrendingDown className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                Per-step conversion breakdown
              </h3>
            </div>
            <div className="space-y-3">
              {journey.steps.map((s, i) => {
                const color = frictionColor(s.friction);
                const userPct = Math.round((s.users / startUsers) * 100);
                return (
                  <div key={s.id} className="flex items-center gap-3">
                    <div className="flex items-center gap-2 w-40 flex-shrink-0">
                      <span
                        className="flex h-5 w-5 items-center justify-center rounded-full text-[9px] font-semibold"
                        style={{
                          background: `color-mix(in oklch, ${color} 18%, var(--card))`,
                          color,
                        }}
                      >
                        {i + 1}
                      </span>
                      <span className="text-xs font-medium text-ink truncate">
                        {s.name}
                      </span>
                    </div>
                    <div className="flex-1 h-2 rounded-full bg-surface-2 overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${userPct}%`,
                          background: color,
                        }}
                      />
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-muted-foreground w-32 justify-end flex-shrink-0">
                      <span className="text-ink font-semibold">{formatUsers(s.users)}</span>
                      <span className="text-friction">-{s.dropOff}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Right column — meta, persona, suggestions */}
        <div className="space-y-4">
          {/* Journey meta */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <GitBranch className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Journey meta</h3>
            </div>
            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Project</span>
                <span className="text-ink font-medium">{journey.project}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Status</span>
                <Badge variant="outline" className="text-[10px] capitalize">
                  {journey.status}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Steps</span>
                <span className="text-ink font-medium">{journey.steps.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Avg time</span>
                <span className="text-ink font-medium">{journey.avgTime}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Last updated</span>
                <span className="text-ink font-medium">{journey.updatedAt}</span>
              </div>
            </div>
          </Card>

          {/* Persona card */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <PersonStanding className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Persona</h3>
            </div>
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="h-10 w-10 ring-1 ring-soft flex-shrink-0">
                <AvatarImage src={persona.avatar} alt={persona.name} />
                <AvatarFallback>{persona.name.slice(0, 2)}</AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <div className="text-sm font-medium text-ink">
                  {persona.name}
                </div>
                <div className="text-[10px] text-muted-foreground">
                  {persona.role} · {journey.persona}
                </div>
              </div>
            </div>
            <blockquote className="text-xs text-muted-foreground italic border-l-2 border-soft pl-3 mb-3">
              "{persona.quote}"
            </blockquote>
            <div className="space-y-2">
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1">
                  Goals
                </div>
                <ul className="space-y-0.5">
                  {persona.goals.slice(0, 2).map((g, i) => (
                    <li key={i} className="text-[11px] text-ink flex items-start gap-1.5">
                      <Target className="h-3 w-3 text-success mt-0.5 flex-shrink-0" />
                      {g}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1">
                  Frustrations
                </div>
                <ul className="space-y-0.5">
                  {persona.frustrations.slice(0, 2).map((g, i) => (
                    <li key={i} className="text-[11px] text-ink flex items-start gap-1.5">
                      <AlertTriangle className="h-3 w-3 text-friction mt-0.5 flex-shrink-0" />
                      {g}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Card>

          {/* Improvement suggestions */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Lightbulb className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                Improvement suggestions
              </h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {suggestions.length}
              </Badge>
            </div>
            <div className="space-y-2.5">
              {suggestions.map((s, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors"
                >
                  <div className="flex items-start gap-2 mb-1">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[9px] capitalize flex-shrink-0",
                        s.impact === "high"
                          ? "bg-friction/15 text-friction border-friction/20"
                          : s.impact === "medium"
                          ? "bg-warning/15 text-warning border-warning/20"
                          : "bg-info/15 text-info border-info/20"
                      )}
                    >
                      {s.impact} impact
                    </Badge>
                    <span className="text-[10px] text-muted-foreground ml-auto">
                      {s.stepRef}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-ink mb-1">
                    {s.title}
                  </div>
                  <div className="text-[11px] text-muted-foreground leading-relaxed">
                    {s.detail}
                  </div>
                </div>
              ))}
            </div>
            <Button
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Roadmap updated with journey fixes")}
            >
              <Users className="mr-2 h-3.5 w-3.5" /> Send to roadmap
            </Button>
          </Card>
        </div>
      </div>

      {/* Related journeys */}
      {JOURNEYS.filter((j) => j.id !== journey.id).length > 0 && (
        <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-ink">Related journeys</h3>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                Other active journeys in your workspace
              </p>
            </div>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/journeys">
                All journeys <ChevronRight className="h-3 w-3" />
              </Link>
            </Button>
          </div>
          <div className="space-y-2">
            {JOURNEYS.filter((j) => j.id !== journey.id).map((j) => (
              <Link
                key={j.id}
                href={`/journeys/${j.id}`}
                className="flex items-center gap-3 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors group"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <GitBranch className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink group-hover:text-primary transition-colors line-clamp-1">
                    {j.name}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    {j.project} · {j.completionRate}% completion · {j.steps.length} steps
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
              </Link>
            ))}
          </div>
        </Card>
      )}
    </motion.div>
  );
}
