"use client";

import * as React from "react";
import {
  Webhook,
  Plus,
  Copy,
  Trash2,
  Pencil,
  CheckCircle2,
  XCircle,
  Clock,
  Eye,
  EyeOff,
  Zap,
  Send,
  AlertTriangle,
  Radio,
  Server,
  ArrowRight,
} from "lucide-react";
import Link from "next/link";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";

interface WebhookEndpoint {
  id: string;
  url: string;
  events: string[];
  lastStatus: "success" | "failed" | "pending";
  lastDelivery: string;
  successRate: number;
  secret: string;
  active: boolean;
}

const WEBHOOK_ENDPOINTS: WebhookEndpoint[] = [
  {
    id: "wh-001",
    url: "https://api.halberg.co/v2/ooster/events",
    events: ["insight.created", "report.ready", "project.updated"],
    lastStatus: "success",
    lastDelivery: "2 min ago",
    successRate: 99.8,
    secret: "whsec_K9p2xQb2oost7r3Lm",
    active: true,
  },
  {
    id: "wh-002",
    url: "https://hooks.northwind.io/ooster/ingest",
    events: ["insight.created", "issue.created"],
    lastStatus: "success",
    lastDelivery: "18 min ago",
    successRate: 100,
    secret: "whsec_Nw7vP4mQb2oost3xK",
    active: true,
  },
  {
    id: "wh-003",
    url: "https://zapier.com/hooks/catch/123456/oost-9p2/",
    events: ["report.ready"],
    lastStatus: "failed",
    lastDelivery: "1 hour ago",
    successRate: 86.4,
    secret: "whsec_Zk3pQb2oost7r3Lm",
    active: true,
  },
  {
    id: "wh-004",
    url: "https://internal.cadence-tools.dev/svc/ooster",
    events: ["insight.created", "report.ready", "project.updated", "member.invited"],
    lastStatus: "pending",
    lastDelivery: "3 hours ago",
    successRate: 94.2,
    secret: "whsec_Cd8pR4b2oost7r3Lm",
    active: false,
  },
];

interface EventDef {
  event: string;
  description: string;
  payload: string;
}

const EVENT_REFERENCE: EventDef[] = [
  { event: "insight.created", description: "Fired when a new insight is generated from an analysis run", payload: "insight.id, project.id, severity" },
  { event: "insight.resolved", description: "An insight's status moved to resolved or wontfix", payload: "insight.id, status, resolver.id" },
  { event: "report.ready", description: "A scheduled or ad-hoc report finished generating", payload: "report.id, format, download_url" },
  { event: "project.updated", description: "A project's UX score, members, or settings changed", payload: "project.id, change_type, actor.id" },
  { event: "project.archived", description: "A project was archived by an admin", payload: "project.id, actor.id" },
  { event: "member.invited", description: "A new team member was invited to the workspace", payload: "member.id, email, role" },
  { event: "member.removed", description: "A team member was removed from the workspace", payload: "member.id, actor.id" },
  { event: "issue.created", description: "An issue was created from an insight via Ooster or an integration", payload: "issue.id, insight.id, integration" },
  { event: "export.completed", description: "A data export finished packaging", payload: "export.id, format, expiry" },
  { event: "experiment.concluded", description: "An A/B or multivariate test reached significance", payload: "experiment.id, winner, lift" },
];

const STATUS_STYLE: Record<
  WebhookEndpoint["lastStatus"],
  { color: string; bg: string; icon: React.ComponentType<{ className?: string }>; label: string }
> = {
  success: { color: "text-success", bg: "bg-success/15", icon: CheckCircle2, label: "Delivered" },
  failed: { color: "text-friction", bg: "bg-friction/15", icon: XCircle, label: "Failed" },
  pending: { color: "text-warning", bg: "bg-warning/15", icon: Clock, label: "Pending" },
};

export default function SettingsWebhooksPage() {
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);
  const [revealed, setRevealed] = React.useState<Record<string, boolean>>({});

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const activeCount = WEBHOOK_ENDPOINTS.filter((w) => w.active).length;
  const avgSuccess =
    WEBHOOK_ENDPOINTS.reduce((acc, w) => acc + w.successRate, 0) /
    WEBHOOK_ENDPOINTS.length;

  const handleAdd = () => {
    toast.success("Webhook endpoint added", {
      description: "Don't forget to copy the signing secret — it won't be shown again.",
    });
  };

  const handleEdit = (wh: WebhookEndpoint) => {
    toast.info(`Editing ${wh.url}`, {
      description: "Endpoint configuration drawer will open.",
    });
  };

  const handleDelete = (wh: WebhookEndpoint) => {
    openConfirm({
      title: "Delete this webhook endpoint?",
      description: `Ooster will stop delivering events to ${wh.url}. Subscribed integrations will not receive further updates.`,
      onConfirm: () => {
        toast.success("Webhook endpoint deleted");
      },
    });
  };

  const handleCopySecret = (wh: WebhookEndpoint) => {
    navigator.clipboard?.writeText(wh.secret).catch(() => {});
    toast.success("Signing secret copied");
  };

  const toggleReveal = (id: string) => {
    setRevealed((s) => ({ ...s, [id]: !s[id] }));
  };

  const handleTest = (wh: WebhookEndpoint) => {
    toast.promise(new Promise((resolve) => setTimeout(resolve, 900)), {
      loading: `Sending test event to ${wh.url}…`,
      success: `Test event delivered to ${wh.url}`,
      error: "Test delivery failed",
    });
  };

  return (
    <div>
      <PageHeader
        title="Webhooks"
        description="Subscribe to real-time events via HTTP webhooks"
        icon={<Webhook className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Webhooks" },
        ]}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {WEBHOOK_ENDPOINTS.length} endpoints
          </Badge>
        }
        actions={
          <Button size="sm" className="rounded-full" onClick={handleAdd}>
            <Plus className="mr-2 h-3.5 w-3.5" /> Add endpoint
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard
              label="Active endpoints"
              value={activeCount}
              icon={<Server className="h-4 w-4" />}
              accent="success"
              sublabel="receiving events"
            />
            <StatCard
              label="Events delivered"
              value="48,219"
              icon={<Send className="h-4 w-4" />}
              accent="info"
              trend={{ value: 8, direction: "up", good: true }}
              sublabel="last 30 days"
            />
            <StatCard
              label="Failed deliveries"
              value="38"
              icon={<XCircle className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 22, direction: "down", good: true }}
              sublabel="auto-retried 3×"
            />
            <StatCard
              label="Avg delivery time"
              value="142"
              unit="ms"
              icon={<Clock className="h-4 w-4" />}
              accent="warning"
              sublabel={`p50 · ${avgSuccess.toFixed(1)}% success`}
            />
          </div>

          {/* Endpoints list */}
          <div className="space-y-3">
            {WEBHOOK_ENDPOINTS.map((wh) => {
              const status = STATUS_STYLE[wh.lastStatus];
              const StatusIcon = status.icon;
              return (
                <Card
                  key={wh.id}
                  className={cn(
                    "rounded-2xl border-soft shadow-soft p-4",
                    !wh.active && "opacity-70"
                  )}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-surface-2 text-primary flex-shrink-0">
                        <Webhook className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <code className="text-[11px] font-mono text-ink bg-surface-2 px-2 py-0.5 rounded break-all">
                            {wh.url}
                          </code>
                          {!wh.active && (
                            <Badge variant="outline" className="text-[10px] text-muted-foreground">
                              Paused
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 flex-wrap text-[10px] text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <StatusIcon className={cn("h-3 w-3", status.color)} />
                            {status.label} · {wh.lastDelivery}
                          </span>
                          <span className="flex items-center gap-1">
                            <Zap className="h-3 w-3" />
                            {wh.successRate}% success · 30d
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-xs h-8"
                        onClick={() => handleTest(wh)}
                      >
                        <Zap className="mr-1 h-3.5 w-3.5" /> Test
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 rounded-full"
                        onClick={() => handleEdit(wh)}
                        aria-label="Edit endpoint"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 rounded-full text-friction hover:text-friction"
                        onClick={() => handleDelete(wh)}
                        aria-label="Delete endpoint"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>

                  {/* Subscribed events + secret */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="sm:col-span-2">
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">
                        Subscribed events
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {wh.events.map((e) => (
                          <code
                            key={e}
                            className="text-[10px] font-mono text-info bg-info/10 px-1.5 py-0.5 rounded"
                          >
                            {e}
                          </code>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1.5">
                        Signing secret
                      </div>
                      <div className="flex items-center gap-1.5 rounded-lg border border-soft bg-surface-2 px-2 py-1">
                        <code className="text-[10px] font-mono text-ink flex-1 truncate">
                          {revealed[wh.id] ? wh.secret : "•".repeat(20)}
                        </code>
                        <button
                          onClick={() => toggleReveal(wh.id)}
                          className="text-muted-foreground hover:text-ink transition-colors flex-shrink-0"
                          aria-label={revealed[wh.id] ? "Hide secret" : "Reveal secret"}
                        >
                          {revealed[wh.id] ? (
                            <EyeOff className="h-3 w-3" />
                          ) : (
                            <Eye className="h-3 w-3" />
                          )}
                        </button>
                        <button
                          onClick={() => handleCopySecret(wh)}
                          className="text-muted-foreground hover:text-ink transition-colors flex-shrink-0"
                          aria-label="Copy secret"
                        >
                          <Copy className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Success rate bar */}
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                      <span>Delivery success rate</span>
                      <span
                        className={cn(
                          "font-medium",
                          wh.successRate >= 99
                            ? "text-success"
                            : wh.successRate >= 90
                            ? "text-warning"
                            : "text-friction"
                        )}
                      >
                        {wh.successRate}%
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all",
                          wh.successRate >= 99
                            ? "bg-success"
                            : wh.successRate >= 90
                            ? "bg-warning"
                            : "bg-friction"
                        )}
                        style={{ width: `${wh.successRate}%` }}
                      />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Event reference */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Radio className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Event reference</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {EVENT_REFERENCE.length} events
              </Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {EVENT_REFERENCE.map((ev) => (
                <div
                  key={ev.event}
                  className="rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <code className="text-[11px] font-mono text-info bg-info/10 px-1.5 py-0.5 rounded">
                      {ev.event}
                    </code>
                  </div>
                  <div className="text-[11px] text-ink leading-relaxed mb-1">
                    {ev.description}
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    <span className="font-medium">Payload:</span> {ev.payload}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-start gap-2 rounded-xl bg-info/5 border border-info/20 p-3">
              <AlertTriangle className="h-4 w-4 text-info flex-shrink-0 mt-0.5" />
              <div className="text-[11px] text-ink leading-relaxed">
                <span className="font-medium">Verification:</span> Every webhook is signed with
                HMAC-SHA256 using your endpoint's signing secret. Verify the{" "}
                <code className="text-[10px] font-mono bg-surface-2 px-1 rounded">
                  X-Ooster-Signature
                </code>{" "}
                header before processing.
              </div>
            </div>
          </Card>

          {/* Link to full page */}
          <div className="flex justify-center">
            <Link
              href="/webhooks"
              className="text-xs text-info hover:underline flex items-center gap-1"
            >
              Open full webhooks dashboard <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        </SettingsLayout>
      )}
    </div>
  );
}
