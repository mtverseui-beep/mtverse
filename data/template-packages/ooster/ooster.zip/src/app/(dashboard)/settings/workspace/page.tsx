"use client";

import * as React from "react";
import {
  Building2,
  Upload,
  Link2,
  Globe,
  Clock,
  DollarSign,
  Database,
  AlertTriangle,
  Trash2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Slider,
} from "@/components/ui/slider";
import { useModals } from "@/hooks/use-modals";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";

const VISIBILITY_OPTIONS = [
  { value: "workspace", label: "Workspace (all members)" },
  { value: "team", label: "Team (members + invitees)" },
  { value: "private", label: "Private (admins only)" },
];

const CURRENCIES = [
  { value: "USD", label: "USD — US Dollar" },
  { value: "EUR", label: "EUR — Euro" },
  { value: "GBP", label: "GBP — British Pound" },
  { value: "JPY", label: "JPY — Japanese Yen" },
  { value: "INR", label: "INR — Indian Rupee" },
];

const RETENTION_MARKS = [30, 60, 90];

export default function WorkspaceSettingsPage() {
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);
  const [name, setName] = React.useState("Halberg Studios");
  const [url] = React.useState("ooster.app/halberg");
  const [visibility, setVisibility] = React.useState("workspace");
  const [timezone, setTimezone] = React.useState("Europe/Helsinki (UTC+2)");
  const [currency, setCurrency] = React.useState("EUR");
  const [retention, setRetention] = React.useState(60);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const handleLogoUpload = () =>
    toast.success("Logo uploaded", {
      description: "Your workspace branding will update within a few minutes.",
    });

  const handleSave = () =>
    toast.success("Workspace settings saved", {
      description: "Defaults updated for all new projects.",
    });

  const handleDelete = () => {
    openConfirm({
      title: "Delete Halberg Studios workspace?",
      description:
        "This permanently deletes all projects, insights, reports, sessions, and team members. This action cannot be undone.",
      onConfirm: () => {
        toast.error("Workspace deletion scheduled", {
          description: "Halberg Studios will be removed in 30 days. Contact support to cancel.",
        });
      },
    });
  };

  return (
    <div>
      <PageHeader
        title="Workspace"
        description="Manage your workspace name, branding, and defaults"
        icon={<Building2 className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Workspace" },
        ]}
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Branding */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <Building2 className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Workspace identity</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-[auto_minmax(0,1fr)] gap-5 items-start">
              <div className="flex flex-col items-center gap-2">
                <div className="h-20 w-20 rounded-2xl bg-surface-2 border border-soft flex items-center justify-center">
                  <span className="text-2xl font-semibold text-primary">H</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-full"
                  onClick={handleLogoUpload}
                >
                  <Upload className="mr-1.5 h-3.5 w-3.5" /> Upload logo
                </Button>
                <p className="text-[10px] text-muted-foreground">SVG, PNG · max 256px</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
                <div className="space-y-1.5">
                  <Label htmlFor="ws-name">Workspace name</Label>
                  <Input
                    id="ws-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ws-url">Workspace URL</Label>
                  <div className="relative">
                    <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                    <Input
                      id="ws-url"
                      value={url}
                      readOnly
                      className="pl-9 bg-surface-2 font-mono text-xs"
                    />
                  </div>
                  <p className="text-[10px] text-muted-foreground">
                    Changing the URL requires owner approval.{" "}
                    <button
                      className="text-info hover:underline"
                      onClick={() => toast.info("URL change request sent to owner")}
                    >
                      Request change
                    </button>
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Defaults */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <Database className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Project defaults</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Default project visibility</Label>
                <Select value={visibility} onValueChange={setVisibility}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {VISIBILITY_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5" /> Default timezone
                </Label>
                <Select value={timezone} onValueChange={setTimezone}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[
                      "America/Los_Angeles (UTC−8)",
                      "America/New_York (UTC−5)",
                      "Europe/London (UTC+0)",
                      "Europe/Berlin (UTC+1)",
                      "Europe/Helsinki (UTC+2)",
                      "Asia/Tokyo (UTC+9)",
                    ].map((tz) => (
                      <SelectItem key={tz} value={tz}>
                        {tz}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <DollarSign className="h-3.5 w-3.5" /> Default currency
                </Label>
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CURRENCIES.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        {c.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Globe className="h-3.5 w-3.5" /> Region
                </Label>
                <Select defaultValue="eu">
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">United States (us-east-1)</SelectItem>
                    <SelectItem value="eu">Europe (eu-central-1)</SelectItem>
                    <SelectItem value="ap">Asia-Pacific (ap-northeast-1)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>

          {/* Data retention */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Database className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-ink">Data retention</h3>
              </div>
              <Badge variant="outline" className="text-[10px] bg-info/10 text-info border-info/20">
                {retention} days
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mb-4 max-w-2xl">
              Session replays, raw events, and heatmaps older than this window are automatically
              purged. Aggregated insights and reports are retained indefinitely.
            </p>
            <div className="space-y-3">
              <Slider
                value={[retention]}
                min={30}
                max={90}
                step={30}
                onValueChange={(v) => setRetention(v[0])}
              />
              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                {RETENTION_MARKS.map((m) => (
                  <button
                    key={m}
                    onClick={() => setRetention(m)}
                    className={
                      retention === m
                        ? "text-ink font-medium"
                        : "hover:text-ink transition-colors"
                    }
                  >
                    {m} days
                  </button>
                ))}
              </div>
            </div>
          </Card>

          {/* Footer actions */}
          <div className="flex items-center justify-end gap-2">
            <Button variant="ghost" size="sm" className="rounded-full" onClick={() => toast.info("Changes discarded")}>
              Discard
            </Button>
            <Button size="sm" className="rounded-full" onClick={handleSave}>
              Save changes
            </Button>
          </div>

          {/* Danger zone */}
          <Card className="rounded-2xl border-friction/30 shadow-soft p-5 bg-friction/[0.02]">
            <div className="mb-3 flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/10 text-friction">
                <AlertTriangle className="h-4 w-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-friction">Danger zone</h3>
                <p className="text-[11px] text-muted-foreground">
                  Irreversible actions that affect every member of this workspace.
                </p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 rounded-xl border border-friction/20 bg-card p-3">
              <div className="min-w-0">
                <div className="text-xs font-medium text-ink">Delete this workspace</div>
                <div className="text-[11px] text-muted-foreground mt-0.5">
                  All projects, members, and historical data will be permanently removed.
                </div>
              </div>
              <Button
                variant="destructive"
                size="sm"
                className="rounded-full flex-shrink-0"
                onClick={handleDelete}
              >
                <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Delete workspace
              </Button>
            </div>
          </Card>
        </SettingsLayout>
      )}
    </div>
  );
}
