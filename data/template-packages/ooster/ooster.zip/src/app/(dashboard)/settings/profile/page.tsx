"use client";

import * as React from "react";
import {
  User,
  Upload,
  Mail,
  CheckCircle2,
  Globe,
  Clock,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";

const TIMEZONES = [
  "Pacific/Honolulu (UTC−10)",
  "America/Los_Angeles (UTC−8)",
  "America/Denver (UTC−7)",
  "America/Chicago (UTC−6)",
  "America/New_York (UTC−5)",
  "America/São_Paulo (UTC−3)",
  "Europe/London (UTC+0)",
  "Europe/Berlin (UTC+1)",
  "Europe/Helsinki (UTC+2)",
  "Asia/Dubai (UTC+4)",
  "Asia/Kolkata (UTC+5:30)",
  "Asia/Shanghai (UTC+8)",
  "Asia/Tokyo (UTC+9)",
  "Australia/Sydney (UTC+11)",
];

const LANGUAGES = [
  "English (US)",
  "English (UK)",
  "Deutsch",
  "Français",
  "Español",
  "Português (BR)",
  "日本語",
  "中文 (简体)",
  "한국어",
];

export default function ProfileSettingsPage() {
  const [loading, setLoading] = React.useState(true);
  const [name, setName] = React.useState("Lena Halberg");
  const [email] = React.useState("lena@halberg.co");
  const [bio, setBio] = React.useState(
    "Lead UX researcher at Halberg Studios. Focused on evidence-driven product decisions, generative research, and making insights actually ship."
  );
  const [timezone, setTimezone] = React.useState("Europe/Helsinki (UTC+2)");
  const [language, setLanguage] = React.useState("English (US)");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const handleAvatarChange = () => {
    toast.success("Avatar updated", {
      description: "Your new profile picture will appear across Ooster shortly.",
    });
  };

  const handleSave = () => {
    toast.success("Profile saved", {
      description: "Your personal information has been updated.",
    });
  };

  return (
    <div>
      <PageHeader
        title="Profile"
        description="Update your personal information and avatar"
        icon={<User className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Profile" },
        ]}
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Avatar card */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <Avatar className="h-20 w-20 rounded-2xl">
                <AvatarImage src="https://avatar.vercel.sh/lena-halberg.svg?text=LH" />
                <AvatarFallback className="rounded-2xl bg-surface-2 text-primary text-lg font-semibold">
                  LH
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-ink">Avatar</div>
                <p className="text-xs text-muted-foreground mt-1 max-w-md">
                  PNG, JPG or SVG up to 2MB. Square images render best at 256×256px.
                </p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-full"
                  onClick={handleAvatarChange}
                >
                  <Upload className="mr-1.5 h-3.5 w-3.5" /> Change
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="rounded-full text-friction hover:text-friction"
                  onClick={() => toast.info("Avatar reset to default")}
                >
                  Remove
                </Button>
              </div>
            </div>
          </Card>

          {/* Personal info */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Personal information</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="profile-name">Full name</Label>
                <Input
                  id="profile-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="profile-email">Email address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  <Input
                    id="profile-email"
                    value={email}
                    readOnly
                    className="pl-9 pr-24 bg-surface-2"
                  />
                  <Badge
                    variant="outline"
                    className="absolute right-2 top-1/2 -translate-y-1/2 gap-1 text-[10px] bg-success/10 text-success border-success/20"
                  >
                    <CheckCircle2 className="h-3 w-3" /> Verified
                  </Badge>
                </div>
                <p className="text-[10px] text-muted-foreground">
                  Email changes require verification.{" "}
                  <button
                    className="text-info hover:underline"
                    onClick={() => toast.info("Verification email sent")}
                  >
                    Change email
                  </button>
                </p>
              </div>
            </div>

            <div className="mt-4 space-y-1.5">
              <Label htmlFor="profile-bio">Bio</Label>
              <Textarea
                id="profile-bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={4}
                placeholder="Tell your team a little about yourself…"
              />
              <p className="text-[10px] text-muted-foreground">
                {bio.length}/500 characters · Shown on your profile and in mentions
              </p>
            </div>
          </Card>

          {/* Locale */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <Globe className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Locale &amp; regional</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5" /> Timezone
                </Label>
                <Select value={timezone} onValueChange={setTimezone}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select timezone" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIMEZONES.map((tz) => (
                      <SelectItem key={tz} value={tz}>
                        {tz}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Globe className="h-3.5 w-3.5" /> Language
                </Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    {LANGUAGES.map((lng) => (
                      <SelectItem key={lng} value={lng}>
                        {lng}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>

          {/* Footer actions */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 rounded-2xl border border-soft bg-card p-4 shadow-soft">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-info" />
              Changes apply across all Ooster surfaces including API responses.
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="rounded-full"
                onClick={() => {
                  setName("Lena Halberg");
                  setBio(
                    "Lead UX researcher at Halberg Studios. Focused on evidence-driven product decisions, generative research, and making insights actually ship."
                  );
                  setTimezone("Europe/Helsinki (UTC+2)");
                  setLanguage("English (US)");
                  toast.info("Changes discarded");
                }}
              >
                Discard
              </Button>
              <Button
                size="sm"
                className="rounded-full"
                onClick={handleSave}
              >
                Save changes
              </Button>
            </div>
          </div>
        </SettingsLayout>
      )}
    </div>
  );
}
