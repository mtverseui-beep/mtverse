"use client";

import * as React from "react";
import {
  Bell,
  Mail,
  MessageSquare,
  Clock,
  Lightbulb,
  FileText,
  AtSign,
  UserPlus,
  CreditCard,
  CalendarDays,
  Slack,
  Moon,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";
import { cn } from "@/lib/utils";

interface NotifChannel {
  key: string;
  label: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}

const EMAIL_EVENTS: NotifChannel[] = [
  { key: "insights", label: "New insights", description: "When Ooster surfaces a new friction or opportunity insight", icon: Lightbulb },
  { key: "reports", label: "Reports ready", description: "When a scheduled or ad-hoc report finishes generating", icon: FileText },
  { key: "mentions", label: "Mentions", description: "When a teammate @mentions you in a comment or insight", icon: AtSign },
  { key: "invites", label: "Team invites", description: "When someone joins or is invited to your workspace", icon: UserPlus },
  { key: "billing", label: "Billing & usage", description: "Receipts, threshold alerts, plan changes", icon: CreditCard },
  { key: "digest", label: "Weekly digest", description: "A Monday-morning summary of last week's UX activity", icon: CalendarDays },
];

function NotificationRow({
  event,
  enabled,
  onToggle,
}: {
  event: NotifChannel;
  enabled: boolean;
  onToggle: () => void;
}) {
  const Icon = event.icon;
  return (
    <div className="flex items-center justify-between gap-3 py-3 border-b border-soft last:border-0">
      <div className="flex items-start gap-3 min-w-0 flex-1">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0">
          <Icon className="h-4 w-4" />
        </div>
        <div className="min-w-0">
          <div className="text-xs font-medium text-ink">{event.label}</div>
          <div className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">
            {event.description}
          </div>
        </div>
      </div>
      <Switch checked={enabled} onCheckedChange={onToggle} />
    </div>
  );
}

export default function NotificationsSettingsPage() {
  const [loading, setLoading] = React.useState(true);
  const [emailPrefs, setEmailPrefs] = React.useState<Record<string, boolean>>({
    insights: true,
    reports: true,
    mentions: true,
    invites: true,
    billing: true,
    digest: false,
  });
  const [appPrefs, setAppPrefs] = React.useState<Record<string, boolean>>({
    insights: true,
    reports: true,
    mentions: true,
    invites: true,
    billing: false,
    digest: false,
  });
  const [slackPrefs, setSlackPrefs] = React.useState<Record<string, boolean>>({
    insights: true,
    reports: true,
    mentions: false,
    invites: true,
    billing: false,
    digest: false,
  });
  const [slackConnected, setSlackConnected] = React.useState(false);
  const [quietHoursEnabled, setQuietHoursEnabled] = React.useState(true);
  const [quietStart, setQuietStart] = React.useState("22:00");
  const [quietEnd, setQuietEnd] = React.useState("08:00");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const toggleEmail = (k: string) =>
    setEmailPrefs((s) => ({ ...s, [k]: !s[k] }));
  const toggleApp = (k: string) =>
    setAppPrefs((s) => ({ ...s, [k]: !s[k] }));
  const toggleSlack = (k: string) =>
    setSlackPrefs((s) => ({ ...s, [k]: !s[k] }));

  const handleSave = () =>
    toast.success("Notification preferences saved", {
      description: "Changes take effect immediately.",
    });

  return (
    <div>
      <PageHeader
        title="Notifications"
        description="Choose what you want to be notified about and how"
        icon={<Bell className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Notifications" },
        ]}
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Email */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/10 text-info">
                  <Mail className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-ink">Email notifications</h3>
                  <p className="text-[10px] text-muted-foreground">Sent to lena@halberg.co</p>
                </div>
              </div>
              <Badge variant="outline" className="text-[10px] bg-success/10 text-success border-success/20">
                {Object.values(emailPrefs).filter(Boolean).length}/{EMAIL_EVENTS.length} on
              </Badge>
            </div>
            <div>
              {EMAIL_EVENTS.map((ev) => (
                <NotificationRow
                  key={ev.key}
                  event={ev}
                  enabled={emailPrefs[ev.key]}
                  onToggle={() => toggleEmail(ev.key)}
                />
              ))}
            </div>
          </Card>

          {/* In-app */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Bell className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-ink">In-app notifications</h3>
                  <p className="text-[10px] text-muted-foreground">Show in the bell dropdown</p>
                </div>
              </div>
              <Badge variant="outline" className="text-[10px] bg-success/10 text-success border-success/20">
                {Object.values(appPrefs).filter(Boolean).length}/{EMAIL_EVENTS.length} on
              </Badge>
            </div>
            <div>
              {EMAIL_EVENTS.map((ev) => (
                <NotificationRow
                  key={ev.key}
                  event={ev}
                  enabled={appPrefs[ev.key]}
                  onToggle={() => toggleApp(ev.key)}
                />
              ))}
            </div>
          </Card>

          {/* Slack */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/10 text-friction">
                  <Slack className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-ink">Slack notifications</h3>
                  <p className="text-[10px] text-muted-foreground">
                    {slackConnected
                      ? "Connected to #ux-alerts in halberg-studios"
                      : "Connect a Slack workspace to deliver alerts to channels"}
                  </p>
                </div>
              </div>
              {slackConnected ? (
                <Button
                  variant="ghost"
                  size="sm"
                  className="rounded-full text-friction hover:text-friction"
                  onClick={() => {
                    setSlackConnected(false);
                    toast.info("Slack disconnected");
                  }}
                >
                  Disconnect
                </Button>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-full"
                  onClick={() => {
                    setSlackConnected(true);
                    toast.success("Slack connected", {
                      description: "Default channel: #ux-alerts",
                    });
                  }}
                >
                  <Slack className="mr-1.5 h-3.5 w-3.5" /> Connect Slack
                </Button>
              )}
            </div>
            {slackConnected ? (
              <div className={cn(!slackConnected && "pointer-events-none opacity-50")}>
                {EMAIL_EVENTS.map((ev) => (
                  <NotificationRow
                    key={ev.key}
                    event={ev}
                    enabled={slackPrefs[ev.key]}
                    onToggle={() => toggleSlack(ev.key)}
                  />
                ))}
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-soft p-4 text-center">
                <MessageSquare className="h-5 w-5 text-muted-foreground mx-auto mb-2" />
                <p className="text-xs text-muted-foreground">
                  Connect Slack to mirror critical UX alerts into your team channels.
                </p>
              </div>
            )}
          </Card>

          {/* Quiet hours */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-warning/10 text-warning">
                  <Moon className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-ink">Quiet hours</h3>
                  <p className="text-[10px] text-muted-foreground">
                    Pause non-critical notifications during your focus time
                  </p>
                </div>
              </div>
              <Switch checked={quietHoursEnabled} onCheckedChange={setQuietHoursEnabled} />
            </div>
            {quietHoursEnabled && (
              <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_1fr] gap-3 items-end pt-2">
                <div className="space-y-1.5">
                  <Label className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5" /> Start
                  </Label>
                  <Input
                    type="time"
                    value={quietStart}
                    onChange={(e) => setQuietStart(e.target.value)}
                  />
                </div>
                <div className="text-center text-xs text-muted-foreground pb-2">to</div>
                <div className="space-y-1.5">
                  <Label className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5" /> End
                  </Label>
                  <Input
                    type="time"
                    value={quietEnd}
                    onChange={(e) => setQuietEnd(e.target.value)}
                  />
                </div>
              </div>
            )}
            {quietHoursEnabled && (
              <p className="text-[10px] text-muted-foreground mt-3">
                Critical security and billing alerts bypass quiet hours.
              </p>
            )}
          </Card>

          {/* Footer */}
          <div className="flex items-center justify-end gap-2">
            <Button variant="ghost" size="sm" className="rounded-full" onClick={() => toast.info("Changes discarded")}>
              Discard
            </Button>
            <Button size="sm" className="rounded-full" onClick={handleSave}>
              Save changes
            </Button>
          </div>
        </SettingsLayout>
      )}
    </div>
  );
}
