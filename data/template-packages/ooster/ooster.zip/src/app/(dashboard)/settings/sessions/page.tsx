"use client";

import * as React from "react";
import {
  MonitorSmartphone,
  Smartphone,
  Laptop,
  Tablet,
  Monitor,
  ShieldCheck,
  Activity,
  CalendarClock,
  AlertTriangle,
  Globe,
  Wifi,
  Trash2,
  ShieldAlert,
  Clock,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { EmptyState } from "@/components/common/empty-state";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useModals } from "@/hooks/use-modals";
import { SettingsLayout } from "../_components/settings-sidebar";

interface Session {
  id: string;
  device: "laptop" | "mobile" | "tablet" | "desktop";
  deviceName: string;
  os: string;
  browser: string;
  location: string;
  ip: string;
  ipType: "home" | "office" | "vpn" | "unknown";
  lastActive: string;
  signedIn: string;
  current?: boolean;
  suspicious?: boolean;
}

const INITIAL_SESSIONS: Session[] = [
  {
    id: "s-1",
    device: "laptop",
    deviceName: 'MacBook Pro 16"',
    os: "macOS 14.5 Sonoma",
    browser: "Chrome 127",
    location: "Helsinki, FI",
    ip: "82.181.12.44",
    ipType: "home",
    lastActive: "Active now",
    signedIn: "Aug 22, 09:42",
    current: true,
  },
  {
    id: "s-2",
    device: "mobile",
    deviceName: "iPhone 15 Pro",
    os: "iOS 17.5",
    browser: "Safari",
    location: "Helsinki, FI",
    ip: "82.181.12.44",
    ipType: "home",
    lastActive: "2 hours ago",
    signedIn: "Aug 20, 18:11",
  },
  {
    id: "s-3",
    device: "tablet",
    deviceName: "iPad Pro 12.9",
    os: "iPadOS 17.5",
    browser: "Safari",
    location: "Helsinki, FI",
    ip: "82.181.12.44",
    ipType: "home",
    lastActive: "Yesterday",
    signedIn: "Aug 18, 21:05",
  },
  {
    id: "s-4",
    device: "desktop",
    deviceName: "Windows Workstation",
    os: "Windows 11 Pro",
    browser: "Firefox 129",
    location: "Berlin, DE",
    ip: "5.146.221.18",
    ipType: "office",
    lastActive: "2 days ago",
    signedIn: "Aug 14, 11:30",
  },
  {
    id: "s-5",
    device: "laptop",
    deviceName: "ThinkPad X1 Carbon",
    os: "Ubuntu 24.04",
    browser: "Chrome 127",
    location: "Singapore, SG",
    ip: "165.22.91.7",
    ipType: "vpn",
    lastActive: "3 days ago",
    signedIn: "Aug 11, 04:18",
    suspicious: true,
  },
];

const IP_TYPE_META: Record<Session["ipType"], { label: string; cls: string }> = {
  home: { label: "Home network", cls: "bg-success/10 text-success border-success/20" },
  office: { label: "Office network", cls: "bg-info/10 text-info border-info/20" },
  vpn: { label: "VPN / proxy", cls: "bg-warning/10 text-warning border-warning/20" },
  unknown: { label: "Unknown", cls: "bg-muted text-muted-foreground border-border" },
};

function getDeviceIcon(device: Session["device"]) {
  if (device === "mobile") return Smartphone;
  if (device === "tablet") return Tablet;
  if (device === "laptop") return Laptop;
  if (device === "desktop") return Monitor;
  return MonitorSmartphone;
}

export default function SessionsSettingsPage() {
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);
  const [sessions, setSessions] = React.useState<Session[]>(INITIAL_SESSIONS);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const activeCount = sessions.filter((s) => s.lastActive === "Active now").length;
  const weekCount = sessions.length;
  const monthCount = 12; // mock
  const suspiciousCount = sessions.filter((s) => s.suspicious).length;

  const handleRevoke = (s: Session) => {
    if (s.current) {
      toast.error("Cannot revoke your current session", {
        description: "Sign out from the user menu instead.",
      });
      return;
    }
    openConfirm({
      title: `Revoke session on ${s.deviceName}?`,
      description: `The device will be immediately signed out and will need to re-authenticate.`,
      onConfirm: () => {
        setSessions((prev) => prev.filter((x) => x.id !== s.id));
        toast.success("Session revoked", {
          description: `${s.deviceName} has been signed out.`,
        });
      },
    });
  };

  const handleRevokeAll = () => {
    const others = sessions.filter((s) => !s.current);
    if (others.length === 0) {
      toast.info("No other sessions to revoke");
      return;
    }
    openConfirm({
      title: `Revoke ${others.length} other session${others.length === 1 ? "" : "s"}?`,
      description: "All other devices will be signed out immediately. Your current session will remain active.",
      onConfirm: () => {
        setSessions((prev) => prev.filter((s) => s.current));
        toast.success("All other sessions revoked");
      },
    });
  };

  return (
    <div>
      <PageHeader
        title="Sessions"
        description="View and revoke your active sessions across devices"
        icon={<MonitorSmartphone className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Sessions" },
        ]}
        actions={
          sessions.length > 1 && (
            <Button
              variant="outline"
              size="sm"
              className="rounded-full text-friction hover:text-friction"
              onClick={handleRevokeAll}
            >
              <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Revoke all others
            </Button>
          )
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard
              label="Active sessions"
              value={activeCount}
              icon={<Activity className="h-4 w-4" />}
              accent="success"
              sublabel="signed in right now"
            />
            <StatCard
              label="This week"
              value={weekCount}
              icon={<Clock className="h-4 w-4" />}
              accent="info"
              sublabel="unique devices"
            />
            <StatCard
              label="This month"
              value={monthCount}
              icon={<CalendarClock className="h-4 w-4" />}
              accent="default"
              sublabel="across all locations"
            />
            <StatCard
              label="Suspicious activity"
              value={suspiciousCount}
              icon={<ShieldAlert className="h-4 w-4" />}
              accent={suspiciousCount > 0 ? "friction" : "success"}
              sublabel={suspiciousCount > 0 ? "needs review" : "all clear"}
            />
          </div>

          {/* Sessions list */}
          {sessions.length === 0 ? (
            <EmptyState
              icon={MonitorSmartphone}
              title="No active sessions"
              description="You've revoked every device. Sign in again to start a new session."
              action={{
                label: "Sign in again",
                onClick: () => toast.info("Redirecting to sign-in…"),
              }}
            />
          ) : (
            <div className="space-y-3">
              {sessions.map((s) => {
                const DeviceIcon = getDeviceIcon(s.device);
                const ipMeta = IP_TYPE_META[s.ipType];
                return (
                  <Card
                    key={s.id}
                    className={cn(
                      "rounded-2xl border-soft shadow-soft p-4",
                      s.suspicious && "border-friction/30 bg-friction/[0.02]"
                    )}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <div
                          className={cn(
                            "flex h-11 w-11 items-center justify-center rounded-xl flex-shrink-0",
                            s.suspicious
                              ? "bg-friction/10 text-friction"
                              : s.current
                              ? "bg-success/10 text-success"
                              : "bg-surface-2 text-primary"
                          )}
                        >
                          <DeviceIcon className="h-5 w-5" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-semibold text-ink">{s.deviceName}</span>
                            {s.current && (
                              <Badge variant="outline" className="text-[9px] bg-success/10 text-success border-success/20">
                                <ShieldCheck className="h-3 w-3" /> This device
                              </Badge>
                            )}
                            {s.suspicious && (
                              <Badge variant="outline" className="text-[9px] bg-friction/10 text-friction border-friction/20">
                                <AlertTriangle className="h-3 w-3" /> Suspicious
                              </Badge>
                            )}
                          </div>
                          <div className="text-[11px] text-muted-foreground mt-0.5">
                            {s.os} · {s.browser}
                          </div>
                          <div className="flex items-center gap-3 flex-wrap mt-1.5 text-[10px] text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Globe className="h-3 w-3" /> {s.location}
                            </span>
                            <span className="flex items-center gap-1">
                              <Wifi className="h-3 w-3" /> {s.ip}
                            </span>
                            <Badge variant="outline" className={cn("text-[9px]", ipMeta.cls)}>
                              {ipMeta.label}
                            </Badge>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-3 flex-shrink-0 pl-14 sm:pl-0">
                        <div className="text-right">
                          <div className="text-[11px] text-ink">{s.lastActive}</div>
                          <div className="text-[10px] text-muted-foreground">
                            Since {s.signedIn}
                          </div>
                        </div>
                        {s.current ? (
                          <Button variant="ghost" size="sm" className="rounded-full text-xs" disabled>
                            Current
                          </Button>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            className="rounded-full text-friction hover:text-friction"
                            onClick={() => handleRevoke(s)}
                          >
                            Revoke
                          </Button>
                        )}
                      </div>
                    </div>

                    {s.suspicious && (
                      <div className="mt-3 rounded-xl border border-friction/20 bg-friction/[0.04] p-2.5 flex items-start gap-2">
                        <AlertTriangle className="h-3.5 w-3.5 text-friction flex-shrink-0 mt-0.5" />
                        <div className="text-[11px] text-ink leading-relaxed">
                          <span className="font-medium">Unusual sign-in location.</span> This session
                          originated from a VPN/proxy in a region you don't typically sign in from.
                          If this wasn't you, revoke it immediately and rotate your password.
                        </div>
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          )}

          {/* Help card */}
          <Card className="rounded-2xl border-soft shadow-soft p-5 bg-info/[0.03]">
            <div className="flex items-start gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-info/10 text-info flex-shrink-0">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <div>
                <div className="text-sm font-semibold text-ink">Don't recognize a session?</div>
                <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">
                  Revoke it immediately, change your password, and enable 2FA from{" "}
                  <span className="text-info">Security settings</span>. Sessions stay active for up
                  to 30 days unless revoked.
                </p>
              </div>
            </div>
          </Card>
        </SettingsLayout>
      )}
    </div>
  );
}
