"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  User,
  Building2,
  Palette,
  Bell,
  Shield,
  MonitorSmartphone,
  Users,
  KeySquare,
  KeyRound,
  Webhook,
  Plug,
  CreditCard,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  external?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { label: "Profile", href: "/settings/profile", icon: User },
  { label: "Workspace", href: "/settings/workspace", icon: Building2 },
  { label: "Appearance", href: "/settings/appearance", icon: Palette },
  { label: "Notifications", href: "/settings/notifications", icon: Bell },
  { label: "Security", href: "/settings/security", icon: Shield },
  { label: "Sessions", href: "/settings/sessions", icon: MonitorSmartphone },
  { label: "Team", href: "/settings/team", icon: Users },
  { label: "Roles", href: "/settings/roles", icon: KeySquare },
  { label: "API Keys", href: "/settings/api-keys", icon: KeyRound },
  { label: "Webhooks", href: "/settings/webhooks", icon: Webhook },
  { label: "Integrations", href: "/integrations", icon: Plug, external: true },
  { label: "Billing", href: "/billing", icon: CreditCard, external: true },
];

export function SettingsSidebar() {
  const pathname = usePathname();
  return (
    <nav className="space-y-1">
      <div className="px-2 pb-2 mb-2 flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
          <Settings className="h-4 w-4" />
        </div>
        <div className="text-xs font-semibold text-ink uppercase tracking-wide">
          Settings
        </div>
      </div>
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = !item.external && pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors",
              isActive
                ? "bg-primary text-primary-foreground shadow-soft"
                : "text-muted-foreground hover:text-ink hover:bg-accent/50"
            )}
          >
            <Icon className="h-4 w-4 flex-shrink-0" />
            <span className="truncate">{item.label}</span>
            {item.external && (
              <span className="ml-auto text-[10px] text-muted-foreground opacity-60">
                →
              </span>
            )}
          </Link>
        );
      })}
    </nav>
  );
}

/**
 * Layout wrapper that renders the settings sidebar on the left and the
 * active page content on the right. On mobile the sidebar collapses to
 * a horizontally scrollable strip.
 */
export function SettingsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[220px_minmax(0,1fr)] gap-4 lg:gap-6">
      {/* Desktop sidebar */}
      <aside className="hidden lg:block">
        <div className="sticky top-4 rounded-2xl bg-card border border-soft shadow-soft p-3">
          <SettingsSidebar />
        </div>
      </aside>

      {/* Mobile horizontal nav */}
      <div className="lg:hidden -mx-1">
        <div className="flex gap-1.5 overflow-x-auto px-1 pb-2 no-scrollbar">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = !item.external && pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs whitespace-nowrap transition-colors flex-shrink-0",
                  isActive
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card border-soft text-muted-foreground hover:text-ink"
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {item.label}
              </Link>
            );
          })}
        </div>
      </div>

      {/* Content area */}
      <div className="min-w-0 space-y-4">{children}</div>
    </div>
  );
}
