"use client";

import * as React from "react";
import {
  Users,
  UserPlus,
  Mail,
  Clock,
  Send,
  X,
  MoreHorizontal,
  Trash2,
  Check,
  ShieldCheck,
  Eye,
  Pencil,
  FileText,
  Database,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";

interface Member {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: string;
  status: "active" | "invited" | "suspended";
  lastActive: string;
}

interface Invite {
  id: string;
  email: string;
  role: string;
  sentAt: string;
}

const INITIAL_MEMBERS: Member[] = [
  {
    id: "m1",
    name: "Lena Halberg",
    email: "lena@halberg.co",
    avatar: "https://avatar.vercel.sh/lena.svg?text=LH",
    role: "Owner",
    status: "active",
    lastActive: "Active now",
  },
  {
    id: "m2",
    name: "Mateo Rossi",
    email: "mateo@halberg.co",
    avatar: "https://avatar.vercel.sh/mateo.svg?text=MR",
    role: "Admin",
    status: "active",
    lastActive: "2 hours ago",
  },
  {
    id: "m3",
    name: "Priya Nair",
    email: "priya@halberg.co",
    avatar: "https://avatar.vercel.sh/priya.svg?text=PN",
    role: "Researcher",
    status: "active",
    lastActive: "Yesterday",
  },
  {
    id: "m4",
    name: "Jonas Weber",
    email: "jonas@halberg.co",
    avatar: "https://avatar.vercel.sh/jonas.svg?text=JW",
    role: "Designer",
    status: "active",
    lastActive: "3 days ago",
  },
  {
    id: "m5",
    name: "Sara Chen",
    email: "sara@halberg.co",
    avatar: "https://avatar.vercel.sh/sara.svg?text=SC",
    role: "PM",
    status: "active",
    lastActive: "5 days ago",
  },
];

const INITIAL_INVITES: Invite[] = [
  { id: "i1", email: "kai.tanaka@halberg.co", role: "Researcher", sentAt: "2 hours ago" },
  { id: "i2", email: "external@northwind.io", role: "Viewer", sentAt: "Yesterday" },
  { id: "i3", email: "contractor@cadence.dev", role: "Designer", sentAt: "3 days ago" },
];

const ROLE_BADGE: Record<string, string> = {
  Owner: "bg-primary/10 text-primary border-primary/20",
  Admin: "bg-info/15 text-info border-info/20",
  Researcher: "bg-success/15 text-success border-success/20",
  Designer: "bg-warning/15 text-warning border-warning/20",
  PM: "bg-friction/15 text-friction border-friction/20",
  Viewer: "bg-muted text-muted-foreground border-border",
};

const ROLE_OPTIONS = ["Owner", "Admin", "Researcher", "Designer", "PM", "Viewer"];

const DEFAULT_PERMISSIONS = [
  { icon: Eye, label: "View projects", description: "Browse all projects and read insights" },
  { icon: Pencil, label: "Comment on insights", description: "Add comments, suggestions, and @mentions" },
  { icon: FileText, label: "Generate reports", description: "Create one-off reports from templates" },
  { icon: Database, label: "View session replays", description: "Watch recorded sessions for assigned projects" },
];

export default function TeamSettingsPage() {
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);
  const [members, setMembers] = React.useState<Member[]>(INITIAL_MEMBERS);
  const [invites, setInvites] = React.useState<Invite[]>(INITIAL_INVITES);
  const [inviteEmail, setInviteEmail] = React.useState("");
  const [inviteRole, setInviteRole] = React.useState("Researcher");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const handleSendInvite = () => {
    if (!inviteEmail || !inviteEmail.includes("@")) {
      toast.error("Enter a valid email address");
      return;
    }
    const newInvite: Invite = {
      id: `i-${Date.now()}`,
      email: inviteEmail,
      role: inviteRole,
      sentAt: "Just now",
    };
    setInvites((prev) => [newInvite, ...prev]);
    toast.success("Invite sent", {
      description: `${inviteEmail} will receive an email invitation to join Halberg Studios.`,
    });
    setInviteEmail("");
  };

  const handleResend = (inv: Invite) => {
    toast.success(`Invitation resent to ${inv.email}`);
  };

  const handleCancelInvite = (inv: Invite) => {
    openConfirm({
      title: "Cancel this invitation?",
      description: `${inv.email} will no longer be able to accept the invite. You can re-invite them at any time.`,
      onConfirm: () => {
        setInvites((prev) => prev.filter((x) => x.id !== inv.id));
        toast.success("Invitation cancelled");
      },
    });
  };

  const handleRoleChange = (member: Member, newRole: string) => {
    if (member.role === "Owner") {
      toast.error("Cannot change the owner's role");
      return;
    }
    setMembers((prev) =>
      prev.map((m) => (m.id === member.id ? { ...m, role: newRole } : m))
    );
    toast.success(`${member.name} is now ${newRole}`);
  };

  const handleRemoveMember = (member: Member) => {
    if (member.role === "Owner") {
      toast.error("Cannot remove the workspace owner");
      return;
    }
    openConfirm({
      title: `Remove ${member.name}?`,
      description: `${member.name} will lose access to all projects, insights, and reports in Halberg Studios immediately.`,
      onConfirm: () => {
        setMembers((prev) => prev.filter((m) => m.id !== member.id));
        toast.success(`${member.name} removed`);
      },
    });
  };

  return (
    <div>
      <PageHeader
        title="Team Management"
        description="Manage roles, permissions, and access for your workspace"
        icon={<Users className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Team" },
        ]}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {members.length} members · {invites.length} pending
          </Badge>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Invite form */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <UserPlus className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Invite teammates</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_auto] gap-3 items-end">
              <div className="space-y-1.5">
                <Label htmlFor="invite-email">Email address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  <Input
                    id="invite-email"
                    type="email"
                    placeholder="teammate@company.com"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    className="pl-9"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleSendInvite();
                    }}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Role</Label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger className="w-full sm:w-[160px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ROLE_OPTIONS.filter((r) => r !== "Owner").map((r) => (
                      <SelectItem key={r} value={r}>
                        {r}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button size="sm" className="rounded-full h-9" onClick={handleSendInvite}>
                <Send className="mr-1.5 h-3.5 w-3.5" /> Send invite
              </Button>
            </div>
          </Card>

          {/* Pending invites */}
          {invites.length > 0 && (
            <Card className="rounded-2xl border-soft shadow-soft p-5">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <h3 className="text-sm font-semibold text-ink">Pending invites</h3>
                </div>
                <Badge variant="outline" className="text-[10px] bg-warning/10 text-warning border-warning/20">
                  {invites.length} awaiting
                </Badge>
              </div>
              <div className="space-y-2">
                {invites.map((inv) => (
                  <div
                    key={inv.id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-soft p-3"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-warning/10 text-warning flex-shrink-0">
                        <Mail className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-ink truncate">{inv.email}</div>
                        <div className="text-[10px] text-muted-foreground">
                          Invited as {inv.role} · {inv.sentAt}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-xs h-8"
                        onClick={() => handleResend(inv)}
                      >
                        <Send className="mr-1 h-3 w-3" /> Resend
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 rounded-full text-friction hover:text-friction"
                        onClick={() => handleCancelInvite(inv)}
                        aria-label="Cancel invite"
                      >
                        <X className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Team members */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-ink">Team members</h3>
              </div>
              <Badge variant="outline" className="text-[10px] bg-surface-2">
                {members.length} total
              </Badge>
            </div>
            <div className="space-y-2">
              {members.map((m) => (
                <div
                  key={m.id}
                  className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-xl border border-soft p-3"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={m.avatar} />
                      <AvatarFallback className="bg-surface-2 text-primary text-xs font-medium">
                        {m.name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-medium text-ink">{m.name}</span>
                        <Badge
                          variant="outline"
                          className={cn("text-[9px] border", ROLE_BADGE[m.role])}
                        >
                          {m.role}
                        </Badge>
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        {m.email} · {m.lastActive}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0 pl-12 sm:pl-0">
                    {m.role === "Owner" ? (
                      <Badge variant="outline" className="text-[10px] bg-primary/10 text-primary border-primary/20 gap-1">
                        <ShieldCheck className="h-3 w-3" /> Owner
                      </Badge>
                    ) : (
                      <>
                        <Select value={m.role} onValueChange={(r) => handleRoleChange(m, r)}>
                          <SelectTrigger size="sm" className="h-8 w-[130px] text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {ROLE_OPTIONS.filter((r) => r !== "Owner").map((r) => (
                              <SelectItem key={r} value={r}>
                                {r}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 rounded-full text-friction hover:text-friction"
                          onClick={() => handleRemoveMember(m)}
                          aria-label={`Remove ${m.name}`}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Default permissions */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Default permissions for new members</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-4 max-w-2xl">
              New teammates are granted this baseline set of permissions when they accept their
              invite. Project-specific access is managed per project.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {DEFAULT_PERMISSIONS.map((p) => {
                const Icon = p.icon;
                return (
                  <div
                    key={p.label}
                    className="flex items-start gap-3 rounded-xl border border-soft p-3 bg-surface-2/40"
                  >
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-success/10 text-success flex-shrink-0">
                      <Icon className="h-3.5 w-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium text-ink flex items-center gap-1.5">
                        {p.label}
                        <Check className="h-3 w-3 text-success" />
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">{p.description}</div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-4 flex justify-end">
              <Button
                variant="outline"
                size="sm"
                className="rounded-full"
                onClick={() => toast.info("Open role editor")}
              >
                <MoreHorizontal className="mr-1.5 h-3.5 w-3.5" /> Edit per-role defaults
              </Button>
            </div>
          </Card>
        </SettingsLayout>
      )}
    </div>
  );
}
