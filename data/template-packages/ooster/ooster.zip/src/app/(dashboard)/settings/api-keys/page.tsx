"use client";

import * as React from "react";
import {
  KeyRound,
  Plus,
  Copy,
  Ban,
  Eye,
  EyeOff,
  ShieldAlert,
  Lightbulb,
  Key,
  Zap,
  Activity,
  Clock,
  ArrowRight,
} from "lucide-react";
import Link from "next/link";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/common/badges";
import { API_KEYS, type ApiKey } from "@/lib/data";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";

interface ScopeDef {
  scope: string;
  description: string;
  level: "read" | "write" | "admin";
}

const SCOPE_REFERENCE: ScopeDef[] = [
  { scope: "read:projects", description: "List and view all projects in the workspace", level: "read" },
  { scope: "write:projects", description: "Create, update, archive projects", level: "write" },
  { scope: "read:insights", description: "View insights, evidence, and metadata", level: "read" },
  { scope: "write:insights", description: "Create or update insights, change status", level: "write" },
  { scope: "read:reports", description: "List generated reports and templates", level: "read" },
  { scope: "write:reports", description: "Trigger report generation, edit templates", level: "write" },
  { scope: "export:data", description: "Download CSV/JSON exports of any dataset", level: "admin" },
  { scope: "webhook:sign", description: "Sign outbound webhook payloads with HMAC", level: "admin" },
  { scope: "admin:team", description: "Invite, remove, and manage team members", level: "admin" },
];

const SCOPE_LEVEL_STYLES: Record<string, string> = {
  read: "bg-info/10 text-info border-info/20",
  write: "bg-warning/10 text-warning border-warning/20",
  admin: "bg-friction/10 text-friction border-friction/20",
};

const USAGE_TIPS = [
  {
    icon: ShieldAlert,
    title: "Rotate keys every 90 days",
    body: "Mark old keys as revoked after rotating. Never reuse a key across environments.",
  },
  {
    icon: Eye,
    title: "Scope to the minimum",
    body: "Prefer read-only keys for dashboards and embeds. Reserve write scopes for server-side jobs.",
  },
  {
    icon: Key,
    title: "Never expose in client code",
    body: "All Ooster API keys are workspace-scoped. Keep them on your backend; use short-lived tokens for the browser.",
  },
  {
    icon: Zap,
    title: "Watch the rate limit",
    body: "Enterprise: 600 req/min. Team: 120 req/min. Pro: 30 req/min. Burst up to 2× for 10s.",
  },
];

export default function SettingsApiKeysPage() {
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);
  const [revealedKeys, setRevealedKeys] = React.useState<Record<string, boolean>>({});

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const activeCount = API_KEYS.filter((k) => k.status === "active").length;
  const revokedCount = API_KEYS.filter((k) => k.status === "revoked").length;

  const handleCreate = () => {
    toast.success("API key created", {
      description: "New key oost_live_xK9p…Qb2 has been added to your workspace.",
    });
  };

  const handleCopy = (key: ApiKey) => {
    navigator.clipboard?.writeText(`${key.prefix}••••`).catch(() => {});
    toast.success("Key prefix copied", {
      description: `${key.prefix}•••• copied to clipboard`,
    });
  };

  const handleRevoke = (key: ApiKey) => {
    openConfirm({
      title: `Revoke "${key.name}"?`,
      description:
        "This key will stop working immediately. Any service using it will receive 401 errors. This cannot be undone.",
      onConfirm: () => {
        toast.success(`"${key.name}" revoked`);
      },
    });
  };

  const toggleReveal = (id: string) => {
    setRevealedKeys((s) => ({ ...s, [id]: !s[id] }));
  };

  return (
    <div>
      <PageHeader
        title="API Keys"
        description="Manage programmatic access to your Ooster workspace"
        icon={<KeyRound className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "API Keys" },
        ]}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {API_KEYS.length} keys
          </Badge>
        }
        actions={
          <Button size="sm" className="rounded-full" onClick={handleCreate}>
            <Plus className="mr-2 h-3.5 w-3.5" /> Create API key
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard
              label="Active keys"
              value={activeCount}
              icon={<KeyRound className="h-4 w-4" />}
              accent="success"
              sublabel="in use right now"
            />
            <StatCard
              label="Revoked"
              value={revokedCount}
              icon={<Ban className="h-4 w-4" />}
              accent="friction"
              sublabel="permanently disabled"
            />
            <StatCard
              label="Requests today"
              value="14,287"
              icon={<Activity className="h-4 w-4" />}
              accent="info"
              trend={{ value: 12, direction: "up", good: true }}
              sublabel="across all keys"
            />
            <StatCard
              label="Avg latency"
              value="84"
              unit="ms"
              icon={<Clock className="h-4 w-4" />}
              accent="warning"
              trend={{ value: 4, direction: "down", good: true }}
              sublabel="p50 · last 24h"
            />
          </div>

          {/* Keys list */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-ink">Your API keys</h3>
              <Link
                href="/api-keys"
                className="text-[10px] text-info hover:underline flex items-center gap-1"
              >
                Open full API keys page <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <div className="space-y-2">
              {API_KEYS.map((key) => (
                <div
                  key={key.id}
                  className="rounded-xl border border-soft p-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0">
                        <KeyRound className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-ink truncate">{key.name}</div>
                        <div className="text-[10px] text-muted-foreground">
                          Created by {key.createdBy} · {key.createdAt}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <code className="text-[10px] font-mono text-ink bg-surface-2 px-2 py-1 rounded">
                        {revealedKeys[key.id] ? `${key.prefix}sk_live_xK9p2Qb2` : `${key.prefix}••••••••`}
                      </code>
                      <button
                        onClick={() => toggleReveal(key.id)}
                        className="text-muted-foreground hover:text-ink transition-colors p-1"
                        aria-label={revealedKeys[key.id] ? "Hide key" : "Reveal key"}
                      >
                        {revealedKeys[key.id] ? (
                          <EyeOff className="h-3.5 w-3.5" />
                        ) : (
                          <Eye className="h-3.5 w-3.5" />
                        )}
                      </button>
                      <button
                        onClick={() => handleCopy(key)}
                        className="text-muted-foreground hover:text-ink transition-colors p-1"
                        aria-label="Copy key"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0 pl-10 sm:pl-0">
                      <StatusBadge status={key.status === "active" ? "active" : "suspended"} label={key.status} />
                      {key.status === "active" ? (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 rounded-full text-friction hover:text-friction"
                          onClick={() => handleRevoke(key)}
                          aria-label="Revoke key"
                        >
                          <Ban className="h-3.5 w-3.5" />
                        </Button>
                      ) : (
                        <span className="text-[10px] text-muted-foreground px-2">—</span>
                      )}
                    </div>
                  </div>

                  <div className="mt-2 flex flex-wrap gap-1">
                    {key.scopes.map((s) => (
                      <code
                        key={s}
                        className="text-[10px] font-mono text-info bg-info/10 px-1.5 py-0.5 rounded"
                      >
                        {s}
                      </code>
                    ))}
                    <span className="text-[10px] text-muted-foreground ml-auto">
                      Last used {key.lastUsed}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Scopes reference */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <ShieldAlert className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Scope reference</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {SCOPE_REFERENCE.length} scopes
              </Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {SCOPE_REFERENCE.map((s) => (
                <div key={s.scope} className="rounded-xl border border-soft p-2.5">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <code className="text-[10px] font-mono text-info bg-info/10 px-1.5 py-0.5 rounded">
                      {s.scope}
                    </code>
                    <Badge
                      variant="outline"
                      className={cn("text-[9px] capitalize border", SCOPE_LEVEL_STYLES[s.level])}
                    >
                      {s.level}
                    </Badge>
                  </div>
                  <div className="text-[10px] text-muted-foreground leading-relaxed">
                    {s.description}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Usage tips */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Lightbulb className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Best practices</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {USAGE_TIPS.map((tip, i) => {
                const Icon = tip.icon;
                return (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0 mt-0.5">
                      <Icon className="h-3.5 w-3.5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-medium text-ink">{tip.title}</div>
                      <div className="text-[10px] text-muted-foreground leading-relaxed mt-0.5">
                        {tip.body}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </SettingsLayout>
      )}
    </div>
  );
}
