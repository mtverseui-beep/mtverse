"use client";

import * as React from "react";
import {
  KeySquare,
  Crown,
  Shield,
  Microscope,
  PenTool,
  ClipboardList,
  Eye,
  Plus,
  Check,
  Lock,
  FolderPlus,
  FolderMinus,
  UserPlus,
  CreditCard,
  BarChart3,
  Download,
  Plug,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";

interface RoleDef {
  key: string;
  label: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  badge: string;
  system?: boolean;
  memberCount: number;
}

const ROLES: RoleDef[] = [
  {
    key: "owner",
    label: "Owner",
    description: "Full control · billing & deletion",
    icon: Crown,
    badge: "bg-primary/10 text-primary border-primary/20",
    system: true,
    memberCount: 1,
  },
  {
    key: "admin",
    label: "Admin",
    description: "Manage members & settings",
    icon: Shield,
    badge: "bg-info/15 text-info border-info/20",
    system: true,
    memberCount: 2,
  },
  {
    key: "researcher",
    label: "Researcher",
    description: "Create studies & insights",
    icon: Microscope,
    badge: "bg-success/15 text-success border-success/20",
    system: true,
    memberCount: 4,
  },
  {
    key: "designer",
    label: "Designer",
    description: "Contribute prototypes & screens",
    icon: PenTool,
    badge: "bg-warning/15 text-warning border-warning/20",
    system: true,
    memberCount: 3,
  },
  {
    key: "pm",
    label: "PM",
    description: "Coordinate projects & reports",
    icon: ClipboardList,
    badge: "bg-friction/15 text-friction border-friction/20",
    system: true,
    memberCount: 2,
  },
  {
    key: "viewer",
    label: "Viewer",
    description: "Read-only access",
    icon: Eye,
    badge: "bg-muted text-muted-foreground border-border",
    system: true,
    memberCount: 8,
  },
];

interface PermissionDef {
  key: string;
  label: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  group: "Projects" | "Team" | "Billing" | "Data" | "Integrations";
}

const PERMISSIONS: PermissionDef[] = [
  { key: "create_project", label: "Create projects", description: "Spin up new UX tracking projects", icon: FolderPlus, group: "Projects" },
  { key: "delete_project", label: "Delete projects", description: "Permanently remove projects and their data", icon: FolderMinus, group: "Projects" },
  { key: "invite_members", label: "Invite members", description: "Send workspace invitations to new teammates", icon: UserPlus, group: "Team" },
  { key: "manage_billing", label: "Manage billing", description: "Update plan, payment method, and view invoices", icon: CreditCard, group: "Billing" },
  { key: "view_reports", label: "View reports", description: "Open and download any report in the workspace", icon: BarChart3, group: "Data" },
  { key: "export_data", label: "Export data", description: "Download CSV/JSON exports of sessions and events", icon: Download, group: "Data" },
  { key: "manage_integrations", label: "Manage integrations", description: "Connect & configure Slack, Jira, Linear, etc.", icon: Plug, group: "Integrations" },
];

// Initial matrix — which roles have which permissions
const INITIAL_MATRIX: Record<string, Record<string, boolean>> = {
  owner: Object.fromEntries(PERMISSIONS.map((p) => [p.key, true])),
  admin: Object.fromEntries(
    PERMISSIONS.map((p) => [p.key, !["manage_billing"].includes(p.key)])
  ),
  researcher: Object.fromEntries(
    PERMISSIONS.map((p) => [p.key, ["create_project", "view_reports", "export_data"].includes(p.key)])
  ),
  designer: Object.fromEntries(
    PERMISSIONS.map((p) => [p.key, ["create_project", "view_reports"].includes(p.key)])
  ),
  pm: Object.fromEntries(
    PERMISSIONS.map((p) => [p.key, ["create_project", "view_reports", "invite_members"].includes(p.key)])
  ),
  viewer: Object.fromEntries(
    PERMISSIONS.map((p) => [p.key, ["view_reports"].includes(p.key)])
  ),
};

const PERMISSION_GROUPS = ["Projects", "Team", "Billing", "Data", "Integrations"];

export default function RolesSettingsPage() {
  const [loading, setLoading] = React.useState(true);
  const [activeRole, setActiveRole] = React.useState("researcher");
  const [matrix, setMatrix] = React.useState(INITIAL_MATRIX);
  const [customRoleName, setCustomRoleName] = React.useState("");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const togglePermission = (permKey: string) => {
    if (activeRole === "owner") {
      toast.error("Owner permissions are locked", {
        description: "Owners always have full access.",
      });
      return;
    }
    setMatrix((prev) => ({
      ...prev,
      [activeRole]: {
        ...prev[activeRole],
        [permKey]: !prev[activeRole][permKey],
      },
    }));
  };

  const handleCreateCustom = () => {
    if (!customRoleName.trim()) {
      toast.error("Enter a name for the custom role");
      return;
    }
    toast.success("Custom role created", {
      description: `${customRoleName} has been added to your workspace roles.`,
    });
    setCustomRoleName("");
  };

  const handleSave = () => {
    toast.success("Permissions matrix saved", {
      description: "Role changes apply to existing members immediately.",
    });
  };

  const currentRole = ROLES.find((r) => r.key === activeRole)!;

  return (
    <div>
      <PageHeader
        title="Roles & Permissions"
        description="Define what each role can do in your workspace"
        icon={<KeySquare className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Roles" },
        ]}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {ROLES.length} roles · {PERMISSIONS.length} permissions
          </Badge>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Roles grid */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <KeySquare className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-ink">Roles</h3>
              </div>
              <span className="text-[10px] text-muted-foreground">
                Click a role to edit its permissions
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
              {ROLES.map((r) => {
                const Icon = r.icon;
                const isActive = activeRole === r.key;
                return (
                  <button
                    key={r.key}
                    onClick={() => setActiveRole(r.key)}
                    className={cn(
                      "text-left rounded-xl border p-3 transition-all",
                      isActive
                        ? "border-primary ring-2 ring-primary/20 bg-primary/[0.03]"
                        : "border-soft hover:border-primary/30"
                    )}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className={cn("flex h-7 w-7 items-center justify-center rounded-lg", r.badge)}>
                        <Icon className="h-3.5 w-3.5" />
                      </div>
                      {isActive && (
                        <div className="flex h-4 w-4 items-center justify-center rounded-full bg-primary text-primary-foreground">
                          <Check className="h-3 w-3" />
                        </div>
                      )}
                    </div>
                    <div className="text-xs font-medium text-ink">{r.label}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 leading-tight">
                      {r.description}
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-1.5">
                      {r.memberCount} {r.memberCount === 1 ? "member" : "members"}
                    </div>
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Permissions matrix */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                {(() => {
                  const ActiveIcon = currentRole.icon;
                  const textColor = currentRole.badge
                    .split(" ")
                    .find((c) => c.startsWith("text-"));
                  return <ActiveIcon className={cn("h-4 w-4", textColor)} />;
                })()}
                <h3 className="text-sm font-semibold text-ink">
                  {currentRole.label} permissions
                </h3>
                {currentRole.system && (
                  <Badge variant="outline" className="text-[9px] bg-surface-2">
                    <Lock className="h-2.5 w-2.5" /> System role
                  </Badge>
                )}
              </div>
              <div className="text-[10px] text-muted-foreground">
                {Object.values(matrix[activeRole]).filter(Boolean).length}/{PERMISSIONS.length} granted
              </div>
            </div>

            <div className="overflow-x-auto -mx-2 px-2">
              <div className="min-w-[640px] space-y-1">
                {/* Header */}
                <div className="grid grid-cols-[2fr_1fr_1fr_1fr_1fr_1fr_1fr] gap-2 px-3 py-2 text-[10px] uppercase tracking-wide text-muted-foreground font-medium">
                  <div>Permission</div>
                  {ROLES.map((r) => (
                    <div key={r.key} className="text-center">
                      {r.label}
                    </div>
                  ))}
                </div>
                {/* Body */}
                {PERMISSION_GROUPS.map((group) => {
                  const perms = PERMISSIONS.filter((p) => p.group === group);
                  if (perms.length === 0) return null;
                  return (
                    <React.Fragment key={group}>
                      <div className="text-[10px] uppercase tracking-wide text-muted-foreground px-3 pt-3 pb-1 font-medium">
                        {group}
                      </div>
                      {perms.map((p) => {
                        const Icon = p.icon;
                        return (
                          <div
                            key={p.key}
                            className={cn(
                              "grid grid-cols-[2fr_1fr_1fr_1fr_1fr_1fr_1fr] gap-2 items-center px-3 py-2 rounded-lg",
                              "hover:bg-accent/30 transition-colors"
                            )}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0">
                                <Icon className="h-3.5 w-3.5" />
                              </div>
                              <div className="min-w-0">
                                <div className="text-xs font-medium text-ink">{p.label}</div>
                                <div className="text-[10px] text-muted-foreground truncate">
                                  {p.description}
                                </div>
                              </div>
                            </div>
                            {ROLES.map((r) => {
                              const checked = matrix[r.key][p.key];
                              const isLocked = r.key === "owner";
                              return (
                                <div key={r.key} className="flex justify-center">
                                  <Checkbox
                                    checked={checked}
                                    onCheckedChange={() => {
                                      if (activeRole === r.key) {
                                        togglePermission(p.key);
                                      } else {
                                        setActiveRole(r.key);
                                        toast.info(`Switched to ${r.label} role`, {
                                          description: "Now editing this role's permissions.",
                                        });
                                      }
                                    }}
                                    disabled={isLocked}
                                    className={cn(isLocked && "opacity-60")}
                                  />
                                </div>
                              );
                            })}
                          </div>
                        );
                      })}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {activeRole === "owner" && (
              <div className="mt-4 rounded-xl border border-primary/20 bg-primary/[0.03] p-3 flex items-start gap-2">
                <Lock className="h-3.5 w-3.5 text-primary flex-shrink-0 mt-0.5" />
                <div className="text-[11px] text-ink leading-relaxed">
                  <span className="font-medium">Owner permissions are immutable.</span> The owner
                  always has full access to every workspace resource and cannot be revoked or
                  downgraded by other members.
                </div>
              </div>
            )}
          </Card>

          {/* Custom role */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-3 flex items-center gap-2">
              <Plus className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Custom role</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-3 max-w-2xl">
              Create a tailored role for contractors, vendors, or part-time teammates. Custom roles
              can be edited and deleted at any time.
            </p>
            <div className="flex flex-col sm:flex-row sm:items-end gap-3">
              <div className="space-y-1.5 flex-1">
                <Label htmlFor="custom-role">Role name</Label>
                <Input
                  id="custom-role"
                  placeholder="e.g. External Auditor"
                  value={customRoleName}
                  onChange={(e) => setCustomRoleName(e.target.value)}
                />
              </div>
              <Button
                variant="outline"
                size="sm"
                className="rounded-full h-9"
                onClick={handleCreateCustom}
              >
                <Plus className="mr-1.5 h-3.5 w-3.5" /> Create role
              </Button>
            </div>
          </Card>

          {/* Footer */}
          <div className="flex items-center justify-end gap-2">
            <Button variant="ghost" size="sm" className="rounded-full" onClick={() => toast.info("Changes discarded")}>
              Discard
            </Button>
            <Button size="sm" className="rounded-full" onClick={handleSave}>
              Save changes
            </Button>
          </div>
        </SettingsLayout>
      )}
    </div>
  );
}
