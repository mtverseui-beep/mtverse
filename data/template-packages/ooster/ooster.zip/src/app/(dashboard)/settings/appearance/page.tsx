"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import {
  Palette,
  Sun,
  Moon,
  Monitor,
  Check,
  Sparkles,
  Type,
  Rows3,
  Zap,
  Eye,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";
import { cn } from "@/lib/utils";

const ACCENT_COLORS = [
  { key: "emerald", label: "Emerald", swatch: "bg-success" },
  { key: "amber", label: "Amber", swatch: "bg-warning" },
  { key: "coral", label: "Coral", swatch: "bg-friction" },
  { key: "info", label: "Slate-blue", swatch: "bg-info" },
  { key: "chart-5", label: "Violet", swatch: "bg-chart-5" },
  { key: "primary", label: "Ink", swatch: "bg-primary" },
];

const FONT_SIZES = [
  { value: "compact", label: "Compact", description: "13px base · tighter spacing" },
  { value: "default", label: "Default", description: "14px base · balanced" },
  { value: "comfortable", label: "Comfortable", description: "15px base · roomy" },
];

const DENSITIES = [
  { value: "comfortable", label: "Comfortable", description: "Generous padding" },
  { value: "compact", label: "Compact", description: "Dense data-first" },
];

function ThemePreview({ variant }: { variant: "light" | "dark" | "system" }) {
  // Mini mock dashboard preview
  const isDark = variant === "dark";
  const surfaceBg = isDark ? "bg-zinc-900" : "bg-white";
  const shellBg = isDark ? "bg-zinc-950" : "bg-zinc-100";
  const inkColor = isDark ? "text-zinc-100" : "text-zinc-800";
  const mutedColor = isDark ? "text-zinc-500" : "text-zinc-400";
  const bar1 = isDark ? "bg-emerald-500" : "bg-emerald-600";
  const bar2 = isDark ? "bg-amber-500" : "bg-amber-500";
  const bar3 = isDark ? "bg-sky-500" : "bg-sky-500";

  return (
    <div className={cn("rounded-lg overflow-hidden border", isDark ? "border-zinc-800" : "border-zinc-200")}>
      {/* Mini topbar */}
      <div className={cn("h-6 flex items-center gap-1 px-2", surfaceBg)}>
        <div className="h-1.5 w-1.5 rounded-full bg-zinc-400" />
        <div className="h-1.5 w-1.5 rounded-full bg-zinc-400" />
        <div className="h-1.5 w-1.5 rounded-full bg-zinc-400" />
        <div className={cn("ml-2 h-2 w-16 rounded-sm", isDark ? "bg-zinc-800" : "bg-zinc-200")} />
        <div className="ml-auto h-2 w-2 rounded-full bg-emerald-500" />
      </div>
      {/* Body */}
      <div className={cn("p-2 space-y-1.5", shellBg)}>
        {/* Stat row */}
        <div className="grid grid-cols-3 gap-1">
          {[0, 1, 2].map((i) => (
            <div key={i} className={cn("rounded p-1", surfaceBg)}>
              <div className={cn("h-1 w-2/3 rounded-sm", isDark ? "bg-zinc-700" : "bg-zinc-200")} />
              <div className={cn("mt-1 h-2 w-1/2 rounded-sm", inkColor, "bg-current opacity-70")} />
            </div>
          ))}
        </div>
        {/* Bars */}
        <div className={cn("rounded p-1.5 space-y-1", surfaceBg)}>
          <div className={cn("h-1 w-1/3 rounded-sm", isDark ? "bg-zinc-700" : "bg-zinc-200")} />
          <div className="flex items-end gap-0.5 h-6">
            <div className={cn("flex-1 rounded-sm", bar1)} style={{ height: "60%" }} />
            <div className={cn("flex-1 rounded-sm", bar2)} style={{ height: "85%" }} />
            <div className={cn("flex-1 rounded-sm", bar3)} style={{ height: "45%" }} />
            <div className={cn("flex-1 rounded-sm", bar1)} style={{ height: "70%" }} />
            <div className={cn("flex-1 rounded-sm", bar2)} style={{ height: "55%" }} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AppearanceSettingsPage() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [accent, setAccent] = React.useState<string>("emerald");
  const [fontSize, setFontSize] = React.useState("default");
  const [density, setDensity] = React.useState("comfortable");
  const [reduceMotion, setReduceMotion] = React.useState(false);
  const [highContrast, setHighContrast] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const currentTheme = (mounted ? theme : "light") as "light" | "dark" | "system";

  const handleThemeChange = (next: "light" | "dark" | "system") => {
    if (next === "system") {
      setTheme("system");
      toast.success("Following system preference");
    } else {
      setTheme(next);
      toast.success(`${next === "dark" ? "Dark" : "Light"} mode enabled`);
    }
  };

  const handleAccent = (key: string) => {
    setAccent(key);
    try {
      localStorage.setItem("ooster.accent", key);
    } catch {}
    toast.success("Accent color updated", {
      description: `${ACCENT_COLORS.find((c) => c.key === key)?.label} is now your accent color.`,
    });
  };

  const handleSave = () => {
    try {
      localStorage.setItem("ooster.fontSize", fontSize);
      localStorage.setItem("ooster.density", density);
      localStorage.setItem("ooster.reduceMotion", String(reduceMotion));
    } catch {}
    toast.success("Appearance preferences saved");
  };

  const themeOptions: {
    key: "light" | "dark" | "system";
    label: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    { key: "light", label: "Light", description: "Bright ivory surfaces", icon: Sun },
    { key: "dark", label: "Dark", description: "Low-light charcoal", icon: Moon },
    { key: "system", label: "System", description: "Match OS preference", icon: Monitor },
  ];

  return (
    <div>
      <PageHeader
        title="Appearance"
        description="Customize how Ooster looks for you"
        icon={<Palette className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Appearance" },
        ]}
        badge={
          <Badge variant="outline" className="text-[10px] bg-surface-2">
            <Sparkles className="h-3 w-3 mr-1" /> Personal
          </Badge>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Theme selector */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sun className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-ink">Theme</h3>
              </div>
              <Badge variant="outline" className="text-[10px] capitalize bg-surface-2">
                Current: {currentTheme}
              </Badge>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {themeOptions.map((opt) => {
                const Icon = opt.icon;
                const isActive = currentTheme === opt.key;
                return (
                  <button
                    key={opt.key}
                    onClick={() => handleThemeChange(opt.key)}
                    className={cn(
                      "text-left rounded-xl border p-3 transition-all hover:shadow-soft",
                      isActive
                        ? "border-primary ring-2 ring-primary/20 bg-primary/[0.03]"
                        : "border-soft hover:border-primary/30"
                    )}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1.5">
                        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-xs font-medium text-ink">{opt.label}</span>
                      </div>
                      {isActive && (
                        <div className="flex h-4 w-4 items-center justify-center rounded-full bg-primary text-primary-foreground">
                          <Check className="h-3 w-3" />
                        </div>
                      )}
                    </div>
                    <ThemePreview variant={opt.key === "system" ? "light" : opt.key} />
                    <div className="text-[10px] text-muted-foreground mt-2">{opt.description}</div>
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Accent color */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <Palette className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Accent color</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-4 max-w-2xl">
              Used for highlights, focus rings, active states, and primary chart series.
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
              {ACCENT_COLORS.map((c) => {
                const isActive = accent === c.key;
                return (
                  <button
                    key={c.key}
                    onClick={() => handleAccent(c.key)}
                    className={cn(
                      "flex flex-col items-center gap-2 rounded-xl border p-3 transition-all",
                      isActive
                        ? "border-primary ring-2 ring-primary/20 bg-primary/[0.03]"
                        : "border-soft hover:border-primary/30"
                    )}
                  >
                    <div
                      className={cn(
                        "h-8 w-8 rounded-full flex items-center justify-center",
                        c.swatch
                      )}
                    >
                      {isActive && <Check className="h-4 w-4 text-white" />}
                    </div>
                    <span className="text-[10px] font-medium text-ink">{c.label}</span>
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Font size */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <Type className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Font size</h3>
            </div>
            <RadioGroup
              value={fontSize}
              onValueChange={setFontSize}
              className="grid grid-cols-1 sm:grid-cols-3 gap-3"
            >
              {FONT_SIZES.map((opt) => (
                <Label
                  key={opt.value}
                  htmlFor={`fs-${opt.value}`}
                  className={cn(
                    "flex items-start gap-3 rounded-xl border p-3 cursor-pointer transition-all",
                    fontSize === opt.value
                      ? "border-primary ring-2 ring-primary/20 bg-primary/[0.03]"
                      : "border-soft hover:border-primary/30"
                  )}
                >
                  <RadioGroupItem id={`fs-${opt.value}`} value={opt.value} className="mt-0.5" />
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink">{opt.label}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{opt.description}</div>
                  </div>
                </Label>
              ))}
            </RadioGroup>
          </Card>

          {/* Density */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <Rows3 className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Density</h3>
            </div>
            <RadioGroup
              value={density}
              onValueChange={setDensity}
              className="grid grid-cols-1 sm:grid-cols-2 gap-3"
            >
              {DENSITIES.map((opt) => (
                <Label
                  key={opt.value}
                  htmlFor={`d-${opt.value}`}
                  className={cn(
                    "flex items-start gap-3 rounded-xl border p-3 cursor-pointer transition-all",
                    density === opt.value
                      ? "border-primary ring-2 ring-primary/20 bg-primary/[0.03]"
                      : "border-soft hover:border-primary/30"
                  )}
                >
                  <RadioGroupItem id={`d-${opt.value}`} value={opt.value} className="mt-0.5" />
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink">{opt.label}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{opt.description}</div>
                  </div>
                </Label>
              ))}
            </RadioGroup>
          </Card>

          {/* Motion & accessibility */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <Zap className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Motion &amp; accessibility</h3>
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between py-3 border-b border-soft last:border-0">
                <div className="min-w-0 pr-3">
                  <div className="text-xs font-medium text-ink flex items-center gap-1.5">
                    <Zap className="h-3.5 w-3.5 text-muted-foreground" /> Reduce animations
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    Disable transitions, slide-ins, and shimmer effects.
                  </div>
                </div>
                <Switch checked={reduceMotion} onCheckedChange={setReduceMotion} />
              </div>
              <div className="flex items-center justify-between py-3 border-b border-soft last:border-0">
                <div className="min-w-0 pr-3">
                  <div className="text-xs font-medium text-ink flex items-center gap-1.5">
                    <Eye className="h-3.5 w-3.5 text-muted-foreground" /> High contrast mode
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    Increase text contrast and border weight for low-vision users.
                  </div>
                </div>
                <Switch checked={highContrast} onCheckedChange={setHighContrast} />
              </div>
            </div>
          </Card>

          {/* Footer */}
          <div className="flex items-center justify-end gap-2">
            <Button variant="ghost" size="sm" className="rounded-full" onClick={() => toast.info("Changes discarded")}>
              Discard
            </Button>
            <Button size="sm" className="rounded-full" onClick={handleSave}>
              Save preferences
            </Button>
          </div>
        </SettingsLayout>
      )}
    </div>
  );
}
