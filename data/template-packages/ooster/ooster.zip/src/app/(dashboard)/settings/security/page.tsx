"use client";

import * as React from "react";
import Link from "next/link";
import {
  Shield,
  Lock,
  KeyRound,
  Smartphone,
  Monitor,
  Tablet,
  Laptop,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  LogIn,
  ArrowRight,
  ShieldCheck,
  Download,
  Copy,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { SettingsLayout } from "../_components/settings-sidebar";

interface Session {
  id: string;
  device: "desktop" | "mobile" | "tablet" | "laptop";
  os: string;
  browser: string;
  location: string;
  ip: string;
  lastActive: string;
  current?: boolean;
}

const MOCK_SESSIONS: Session[] = [
  {
    id: "s-1",
    device: "laptop",
    os: "macOS 14.5",
    browser: "Chrome 127",
    location: "Helsinki, FI",
    ip: "82.181.12.44",
    lastActive: "Active now",
    current: true,
  },
  {
    id: "s-2",
    device: "mobile",
    os: "iOS 17.5",
    browser: "Safari",
    location: "Helsinki, FI",
    ip: "82.181.12.44",
    lastActive: "2 hours ago",
  },
  {
    id: "s-3",
    device: "desktop",
    os: "Windows 11",
    browser: "Firefox 129",
    location: "Berlin, DE",
    ip: "5.146.221.18",
    lastActive: "Yesterday",
  },
];

interface SecurityEvent {
  id: string;
  type: "login" | "password" | "2fa" | "logout" | "session";
  description: string;
  timestamp: string;
  ip: string;
  status: "success" | "warning";
}

const SECURITY_LOG: SecurityEvent[] = [
  { id: "l1", type: "login", description: "Signed in from Chrome on macOS", timestamp: "Today, 09:42", ip: "82.181.12.44", status: "success" },
  { id: "l2", type: "2fa", description: "2FA code verified via authenticator app", timestamp: "Today, 09:42", ip: "82.181.12.44", status: "success" },
  { id: "l3", type: "login", description: "Signed in from Safari on iOS", timestamp: "Today, 07:18", ip: "82.181.12.44", status: "success" },
  { id: "l4", type: "session", description: "Session revoked from Firefox in Berlin", timestamp: "Yesterday, 16:30", ip: "82.181.12.44", status: "warning" },
  { id: "l5", type: "password", description: "Password changed successfully", timestamp: "Aug 14, 11:02", ip: "82.181.12.44", status: "success" },
];

const BACKUP_CODES = [
  "8X4P2-K9M3Q",
  "L7V1T-R6N2W",
  "Y3Z5B-J8H4F",
  "C9D2X-K7M1P",
  "T4Q6L-V3R8N",
  "W2J5H-F9B3Y",
  "M6K1P-X4Z7D",
  "R8N3V-L2Q5T",
];

const EVENT_META: Record<SecurityEvent["type"], { icon: React.ComponentType<{ className?: string }>; cls: string }> = {
  login: { icon: LogIn, cls: "bg-info/10 text-info" },
  password: { icon: KeyRound, cls: "bg-warning/10 text-warning" },
  "2fa": { icon: ShieldCheck, cls: "bg-success/10 text-success" },
  logout: { icon: XCircle, cls: "bg-muted text-muted-foreground" },
  session: { icon: Smartphone, cls: "bg-friction/10 text-friction" },
};

function getDeviceIcon(device: Session["device"]) {
  if (device === "mobile") return Smartphone;
  if (device === "tablet") return Tablet;
  if (device === "laptop") return Laptop;
  return Monitor;
}

function passwordStrength(pwd: string): { score: number; label: string; cls: string } {
  let score = 0;
  if (pwd.length >= 8) score++;
  if (pwd.length >= 12) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;
  const labels = ["Too weak", "Weak", "Fair", "Good", "Strong", "Excellent"];
  const cls = [
    "bg-friction",
    "bg-friction",
    "bg-warning",
    "bg-info",
    "bg-success",
    "bg-success",
  ];
  return { score, label: labels[score], cls: cls[score] };
}

export default function SecuritySettingsPage() {
  const [loading, setLoading] = React.useState(true);
  const [currentPwd, setCurrentPwd] = React.useState("");
  const [newPwd, setNewPwd] = React.useState("");
  const [confirmPwd, setConfirmPwd] = React.useState("");
  const [twoFAEnabled, setTwoFAEnabled] = React.useState(true);
  const [codesRevealed, setCodesRevealed] = React.useState(false);
  const [sessions, setSessions] = React.useState<Session[]>(MOCK_SESSIONS);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const strength = passwordStrength(newPwd);
  const passwordsMatch = confirmPwd.length > 0 && newPwd === confirmPwd;

  const handlePasswordUpdate = () => {
    if (!currentPwd || !newPwd) {
      toast.error("Please fill in all password fields");
      return;
    }
    if (newPwd !== confirmPwd) {
      toast.error("Passwords do not match");
      return;
    }
    if (strength.score < 3) {
      toast.error("Password is too weak", {
        description: "Use 12+ characters with mixed case, numbers, and symbols.",
      });
      return;
    }
    toast.success("Password updated", {
      description: "You'll need to sign in again on other devices.",
    });
    setCurrentPwd("");
    setNewPwd("");
    setConfirmPwd("");
  };

  const handleEnable2FA = () => {
    setTwoFAEnabled(true);
    toast.success("2FA enabled", {
      description: "Save your backup codes somewhere safe.",
    });
  };

  const handleDisable2FA = () => {
    setTwoFAEnabled(false);
    toast.info("2FA disabled", {
      description: "Your account is less secure. Consider re-enabling soon.",
    });
  };

  const handleCopyCodes = () => {
    navigator.clipboard?.writeText(BACKUP_CODES.join("\n")).catch(() => {});
    toast.success("Backup codes copied");
  };

  const handleDownloadCodes = () => {
    toast.success("Backup codes downloaded", {
      description: "Saved to ~/Downloads/ooster-backup-codes.txt",
    });
  };

  const handleRevokeSession = (id: string) => {
    setSessions((s) => s.filter((x) => x.id !== id));
    toast.success("Session revoked", {
      description: "The device will need to sign in again.",
    });
  };

  return (
    <div>
      <PageHeader
        title="Security"
        description="Manage your password, 2FA, and security settings"
        icon={<Shield className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Settings", href: "/settings/profile" },
          { label: "Security" },
        ]}
        badge={
          twoFAEnabled ? (
            <Badge variant="outline" className="text-[10px] bg-success/10 text-success border-success/20">
              <ShieldCheck className="h-3 w-3" /> 2FA on
            </Badge>
          ) : (
            <Badge variant="outline" className="text-[10px] bg-warning/10 text-warning border-warning/20">
              <AlertTriangle className="h-3 w-3" /> 2FA off
            </Badge>
          )
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <SettingsLayout>
          {/* Password */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Password</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="current-pwd">Current password</Label>
                <Input
                  id="current-pwd"
                  type="password"
                  placeholder="••••••••"
                  value={currentPwd}
                  onChange={(e) => setCurrentPwd(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="new-pwd">New password</Label>
                <Input
                  id="new-pwd"
                  type="password"
                  placeholder="At least 12 characters"
                  value={newPwd}
                  onChange={(e) => setNewPwd(e.target.value)}
                />
                {newPwd.length > 0 && (
                  <div className="space-y-1">
                    <div className="flex gap-1">
                      {[0, 1, 2, 3, 4].map((i) => (
                        <div
                          key={i}
                          className={cn(
                            "h-1 flex-1 rounded-full transition-colors",
                            i < strength.score ? strength.cls : "bg-surface-2"
                          )}
                        />
                      ))}
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-muted-foreground">Strength</span>
                      <span
                        className={cn(
                          "font-medium",
                          strength.score >= 4
                            ? "text-success"
                            : strength.score >= 3
                            ? "text-info"
                            : strength.score >= 2
                            ? "text-warning"
                            : "text-friction"
                        )}
                      >
                        {strength.label}
                      </span>
                    </div>
                  </div>
                )}
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <Label htmlFor="confirm-pwd">Confirm new password</Label>
                <Input
                  id="confirm-pwd"
                  type="password"
                  placeholder="Re-enter new password"
                  value={confirmPwd}
                  onChange={(e) => setConfirmPwd(e.target.value)}
                  className={confirmPwd && !passwordsMatch ? "border-friction" : ""}
                />
                {confirmPwd && !passwordsMatch && (
                  <p className="text-[10px] text-friction">Passwords do not match</p>
                )}
                {passwordsMatch && (
                  <p className="text-[10px] text-success flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3" /> Passwords match
                  </p>
                )}
              </div>
            </div>
            <div className="mt-4 flex justify-end">
              <Button size="sm" className="rounded-full" onClick={handlePasswordUpdate}>
                <Lock className="mr-1.5 h-3.5 w-3.5" /> Update password
              </Button>
            </div>
          </Card>

          {/* 2FA */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Smartphone className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-ink">Two-factor authentication</h3>
              </div>
              {twoFAEnabled ? (
                <Badge variant="outline" className="text-[10px] bg-success/10 text-success border-success/20">
                  Enabled
                </Badge>
              ) : (
                <Badge variant="outline" className="text-[10px] bg-warning/10 text-warning border-warning/20">
                  Disabled
                </Badge>
              )}
            </div>

            {twoFAEnabled ? (
              <div className="space-y-4">
                <div className="rounded-xl border border-soft bg-surface-2 p-3">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-success mt-0.5 flex-shrink-0" />
                    <div className="text-[11px] text-ink leading-relaxed">
                      Two-factor authentication is active. You'll be prompted for a code from your
                      authenticator app on every new device sign-in.
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-xs font-medium text-ink">Backup recovery codes</div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 rounded-full text-xs"
                        onClick={() => setCodesRevealed((s) => !s)}
                      >
                        {codesRevealed ? "Hide" : "Reveal"}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 rounded-full text-xs"
                        onClick={handleCopyCodes}
                      >
                        <Copy className="mr-1 h-3 w-3" /> Copy
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 rounded-full text-xs"
                        onClick={handleDownloadCodes}
                      >
                        <Download className="mr-1 h-3 w-3" /> Download
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                    {BACKUP_CODES.map((code, i) => (
                      <code
                        key={i}
                        className="text-[10px] font-mono text-ink bg-surface-2 border border-soft px-2 py-1.5 rounded text-center"
                      >
                        {codesRevealed ? code : "••••-••••"}
                      </code>
                    ))}
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-2">
                    Each code can be used once. Generate new codes if you lose these.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center gap-2 pt-2 border-t border-soft">
                  <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.info("New backup codes generated")}>
                    Regenerate codes
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="rounded-full text-friction hover:text-friction"
                    onClick={handleDisable2FA}
                  >
                    Disable 2FA
                  </Button>
                </div>
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-warning/30 bg-warning/[0.03] p-4">
                <AlertTriangle className="h-5 w-5 text-warning mb-2" />
                <div className="text-xs font-medium text-ink mb-1">Your account is not protected</div>
                <p className="text-[11px] text-muted-foreground mb-3">
                  Add a second factor (authenticator app or SMS) to drastically reduce the risk of
                  account takeover.
                </p>
                <Button size="sm" className="rounded-full" onClick={handleEnable2FA}>
                  <Shield className="mr-1.5 h-3.5 w-3.5" /> Enable 2FA
                </Button>
              </div>
            )}
          </Card>

          {/* Active sessions */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Monitor className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-ink">Active sessions</h3>
              </div>
              <Link
                href="/settings/sessions"
                className="text-[10px] text-info hover:underline flex items-center gap-1"
              >
                Manage all <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <div className="space-y-2">
              {sessions.map((s) => {
                const DeviceIcon = getDeviceIcon(s.device);
                return (
                  <div
                    key={s.id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-soft p-3"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0">
                        <DeviceIcon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-medium text-ink">
                            {s.os} · {s.browser}
                          </span>
                          {s.current && (
                            <Badge variant="outline" className="text-[9px] bg-success/10 text-success border-success/20">
                              This device
                            </Badge>
                          )}
                        </div>
                        <div className="text-[10px] text-muted-foreground mt-0.5">
                          {s.location} · {s.ip} · {s.lastActive}
                        </div>
                      </div>
                    </div>
                    {!s.current && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-friction hover:text-friction flex-shrink-0"
                        onClick={() => handleRevokeSession(s.id)}
                      >
                        Revoke
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Security log */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-muted-foreground" />
                <h3 className="text-sm font-semibold text-ink">Recent security events</h3>
              </div>
              <Link
                href="/audit-logs"
                className="text-[10px] text-info hover:underline flex items-center gap-1"
              >
                View audit log <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <div className="space-y-1">
              {SECURITY_LOG.map((ev) => {
                const meta = EVENT_META[ev.type];
                const Icon = meta.icon;
                return (
                  <div key={ev.id} className="flex items-center gap-3 py-2 border-b border-soft last:border-0">
                    <div className={cn("flex h-7 w-7 items-center justify-center rounded-lg flex-shrink-0", meta.cls)}>
                      <Icon className="h-3.5 w-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs text-ink">{ev.description}</div>
                      <div className="text-[10px] text-muted-foreground">
                        {ev.timestamp} · {ev.ip}
                      </div>
                    </div>
                    {ev.status === "warning" ? (
                      <AlertTriangle className="h-3.5 w-3.5 text-warning flex-shrink-0" />
                    ) : (
                      <CheckCircle2 className="h-3.5 w-3.5 text-success flex-shrink-0" />
                    )}
                  </div>
                );
              })}
            </div>
          </Card>

          {/* API access */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-info/10 text-info">
                  <KeyRound className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-ink">API access</div>
                  <p className="text-[11px] text-muted-foreground">
                    Manage programmatic keys for server-to-server integrations.
                  </p>
                </div>
              </div>
              <Link
                href="/settings/api-keys"
                className="inline-flex items-center justify-center gap-2 h-9 rounded-full bg-primary text-primary-foreground px-4 text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                Manage keys <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </Card>
        </SettingsLayout>
      )}
    </div>
  );
}
