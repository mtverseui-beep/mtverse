"use client";

import * as React from "react";
import Link from "next/link";
import {
  Lightbulb,
  AlertOctagon,
  CheckCircle2,
  HelpCircle,
  Search,
  Quote,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { EmptyState } from "@/components/common/empty-state";
import { SeverityBadge } from "@/components/common/badges";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type FindingStatus = "new" | "validated" | "implemented" | "needs-validation" | "wontfix";
type Severity = "critical" | "high" | "medium" | "low";

interface Finding {
  id: string;
  title: string;
  studyName: string;
  studyId: string;
  severity: Severity;
  theme: string;
  quote: string;
  evidence: number;
  status: FindingStatus;
  confidence: number;
  createdAt: string;
}

const FINDINGS: Finding[] = [
  { id: "f-1", title: "Document upload fails silently on iOS Safari 17", studyName: "Atlas KYC Friction — Moderated Interviews", studyId: "rs-001", severity: "critical", theme: "Mobile", quote: "I tapped upload and nothing happened. I thought my phone was frozen.", evidence: 7, status: "implemented", confidence: 94, createdAt: "2026-06-28" },
  { id: "f-2", title: "Field validation only triggers on submit", studyName: "Northwind Checkout — Unmoderated Usability Test", studyId: "rs-002", severity: "high", theme: "Forms", quote: "I only saw the error after I hit Continue — annoying because I had to redo the whole form.", evidence: 5, status: "needs-validation", confidence: 88, createdAt: "2026-06-29" },
  { id: "f-3", title: "Confirmation page creates decision fatigue", studyName: "Atlas KYC Friction — Moderated Interviews", studyId: "rs-001", severity: "high", theme: "Cognitive Load", quote: "Four buttons and I'm not sure which one to press. I just stared for a while.", evidence: 4, status: "new", confidence: 81, createdAt: "2026-07-01" },
  { id: "f-4", title: "Card sort reveals IA mismatch on 'Settings'", studyName: "Helix Dashboard — Card Sort", studyId: "rs-003", severity: "medium", theme: "IA", quote: "I expected 'Settings' to be under my profile, not in the sidebar.", evidence: 6, status: "validated", confidence: 90, createdAt: "2026-05-22" },
  { id: "f-5", title: "Habit reminder time picker off by timezone", studyName: "Cadence Habit-Setting — Survey", studyId: "rs-004", severity: "high", theme: "Reliability", quote: "My reminders come an hour late after I traveled. Had to disable them.", evidence: 12, status: "implemented", confidence: 96, createdAt: "2026-06-25" },
  { id: "f-6", title: "Tree test: 'Components' buried too deep", studyName: "Riverside Components — Tree Test", studyId: "rs-005", severity: "medium", theme: "IA", quote: "Took me three wrong clicks to find the component I needed.", evidence: 8, status: "validated", confidence: 87, createdAt: "2026-05-10" },
  { id: "f-7", title: "Color contrast below WCAG AA on secondary buttons", studyName: "Riverside Components — Tree Test", studyId: "rs-005", severity: "high", theme: "Accessibility", quote: "I literally could not read the button text in bright sunlight.", evidence: 3, status: "needs-validation", confidence: 99, createdAt: "2026-05-12" },
  { id: "f-8", title: "Diary entries feel heavy on mobile keyboard", studyName: "Voyage Booking — Diary Study", studyId: "rs-006", severity: "low", theme: "Mobile", quote: "Typing long diary entries on the small keyboard is painful. Wish I could dictate.", evidence: 2, status: "new", confidence: 72, createdAt: "2026-07-02" },
  { id: "f-9", title: "Onboarding skips contextual value explanation", studyName: "Cadence Habit-Setting — Survey", studyId: "rs-004", severity: "medium", theme: "Onboarding", quote: "I skipped step 2 because I didn't understand what it was for.", evidence: 9, status: "validated", confidence: 84, createdAt: "2026-06-22" },
  { id: "f-10", title: "Tooltip timing feels jumpy at 200ms", studyName: "Atlas KYC Friction — Moderated Interviews", studyId: "rs-001", severity: "low", theme: "Microinteraction", quote: "The tooltips feel twitchy — they appear before I even mean to hover.", evidence: 2, status: "wontfix", confidence: 65, createdAt: "2026-06-20" },
];

const STATUS_META: Record<FindingStatus, { label: string; color: string; icon: typeof CheckCircle2 }> = {
  new: { label: "New", color: "border-info/20 bg-info/10 text-info", icon: Sparkles },
  validated: { label: "Validated", color: "border-success/20 bg-success/10 text-success", icon: CheckCircle2 },
  implemented: { label: "Implemented", color: "border-success/20 bg-success/10 text-success", icon: CheckCircle2 },
  "needs-validation": { label: "Needs validation", color: "border-warning/20 bg-warning/10 text-warning", icon: HelpCircle },
  wontfix: { label: "Won't fix", color: "border-border bg-muted text-muted-foreground", icon: AlertOctagon },
};

const THEMES = ["All themes", "Mobile", "Forms", "Cognitive Load", "IA", "Accessibility", "Onboarding", "Reliability", "Microinteraction"];

export default function FindingsPage() {
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [studyFilter, setStudyFilter] = React.useState("all");
  const [severityFilter, setSeverityFilter] = React.useState("all");
  const [themeFilter, setThemeFilter] = React.useState("all");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return FINDINGS.filter((f) => {
      if (search && !`${f.title} ${f.studyName} ${f.quote}`.toLowerCase().includes(search.toLowerCase())) return false;
      if (studyFilter !== "all" && f.studyId !== studyFilter) return false;
      if (severityFilter !== "all" && f.severity !== severityFilter) return false;
      if (themeFilter !== "all" && f.theme !== themeFilter) return false;
      return true;
    });
  }, [search, studyFilter, severityFilter, themeFilter]);

  const criticalCount = FINDINGS.filter((f) => f.severity === "critical" || f.severity === "high").length;
  const implementedCount = FINDINGS.filter((f) => f.status === "implemented").length;
  const needsValidation = FINDINGS.filter((f) => f.status === "needs-validation").length;

  return (
    <div>
      <PageHeader
        title="Findings"
        description="Cross-study findings synthesized from all your research"
        breadcrumbs={[{ label: "Research", href: "/research" }, { label: "Findings" }]}
        icon={<Lightbulb className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">{FINDINGS.length} findings</Badge>}
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Total findings"
              value={FINDINGS.length}
              icon={<Lightbulb className="h-4 w-4" />}
              accent="info"
              trend={{ value: 14, direction: "up", good: true }}
              sublabel="across 6 studies"
            />
            <StatCard
              label="Critical / high"
              value={criticalCount}
              icon={<AlertOctagon className="h-4 w-4" />}
              accent="friction"
              sublabel="needs triage"
            />
            <StatCard
              label="Implemented"
              value={implementedCount}
              icon={<CheckCircle2 className="h-4 w-4" />}
              accent="success"
              trend={{ value: 22, direction: "up", good: true }}
              sublabel="shipped to product"
            />
            <StatCard
              label="Needs validation"
              value={needsValidation}
              icon={<HelpCircle className="h-4 w-4" />}
              accent="warning"
              sublabel="awaiting follow-up"
            />
          </div>

          {/* Filter bar */}
          <Card className="rounded-2xl border-soft shadow-soft p-3 mb-4">
            <FilterBar
              search={{ value: search, onChange: setSearch, placeholder: "Search findings, quotes, studies…" }}
              selects={[
                {
                  label: "Study",
                  value: studyFilter,
                  onChange: setStudyFilter,
                  options: [
                    { label: "All studies", value: "all" },
                    { label: "Atlas KYC Friction", value: "rs-001" },
                    { label: "Northwind Checkout", value: "rs-002" },
                    { label: "Helix Dashboard", value: "rs-003" },
                    { label: "Cadence Habit-Setting", value: "rs-004" },
                    { label: "Riverside Components", value: "rs-005" },
                    { label: "Voyage Booking", value: "rs-006" },
                  ],
                },
                {
                  label: "Severity",
                  value: severityFilter,
                  onChange: setSeverityFilter,
                  options: [
                    { label: "All severities", value: "all" },
                    { label: "Critical", value: "critical" },
                    { label: "High", value: "high" },
                    { label: "Medium", value: "medium" },
                    { label: "Low", value: "low" },
                  ],
                },
                {
                  label: "Theme",
                  value: themeFilter,
                  onChange: setThemeFilter,
                  options: THEMES.map((t) => ({ label: t === "All themes" ? "All themes" : t, value: t === "All themes" ? "all" : t })),
                },
              ]}
              onClear={() => { setSearch(""); setStudyFilter("all"); setSeverityFilter("all"); setThemeFilter("all"); }}
            />
          </Card>

          {/* Findings grid */}
          {filtered.length === 0 ? (
            <EmptyState
              icon={Search}
              title="No findings match your filters"
              description="Try adjusting your search or clearing filters to see all synthesized findings."
              action={{ label: "Clear filters", onClick: () => { setSearch(""); setStudyFilter("all"); setSeverityFilter("all"); setThemeFilter("all"); } }}
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filtered.map((f) => {
                const status = STATUS_META[f.status];
                const StatusIcon = status.icon;
                const sevColor =
                  f.severity === "critical" ? "var(--friction)" :
                  f.severity === "high" ? "var(--warning)" :
                  f.severity === "medium" ? "var(--info)" : "var(--success)";
                return (
                  <Card
                    key={f.id}
                    className="rounded-2xl border-soft shadow-soft p-4 hover:shadow-card transition-all cursor-pointer flex flex-col"
                    onClick={() => toast.info(`Opening study: ${f.studyName}`)}
                  >
                    {/* Top row: severity + theme */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <SeverityBadge severity={f.severity} />
                        <Badge variant="outline" className="text-[10px] border-info/20 bg-info/10 text-info">
                          {f.theme}
                        </Badge>
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="text-sm font-semibold text-ink leading-snug mb-2">{f.title}</h3>

                    {/* Quote */}
                    <div className="relative pl-4 mb-3">
                      <Quote className="absolute left-0 top-0.5 h-3 w-3 text-muted-foreground/40" />
                      <p className="text-[11px] text-muted-foreground italic leading-relaxed line-clamp-3">
                        "{f.quote}"
                      </p>
                    </div>

                    {/* Evidence + confidence */}
                    <div className="grid grid-cols-2 gap-2 text-[10px] mb-3">
                      <div className="p-1.5 rounded-lg bg-surface-2/50">
                        <div className="text-muted-foreground">Evidence</div>
                        <div className="font-semibold text-ink tabular-nums">{f.evidence} quotes</div>
                      </div>
                      <div className="p-1.5 rounded-lg bg-surface-2/50">
                        <div className="text-muted-foreground">Confidence</div>
                        <div className="flex items-center gap-1.5">
                          <div className="h-1 w-8 rounded-full bg-surface-2 overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${f.confidence}%`, background: sevColor }} />
                          </div>
                          <span className="font-semibold text-ink tabular-nums">{f.confidence}%</span>
                        </div>
                      </div>
                    </div>

                    {/* Footer: study + status */}
                    <div className="mt-auto pt-3 border-t border-soft">
                      <Link
                        href={`/research/${f.studyId}`}
                        className="flex items-center justify-between gap-2 group/link"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="min-w-0">
                          <div className="text-[9px] text-muted-foreground uppercase tracking-wide">From study</div>
                          <div className="text-[11px] font-medium text-ink truncate group-hover/link:text-primary transition-colors">
                            {f.studyName}
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <Badge variant="outline" className={cn("text-[9px]", status.color)}>
                            <StatusIcon className="mr-1 h-2.5 w-2.5" /> {status.label}
                          </Badge>
                          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover/link:text-ink group-hover/link:translate-x-0.5 transition-all" />
                        </div>
                      </Link>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}
