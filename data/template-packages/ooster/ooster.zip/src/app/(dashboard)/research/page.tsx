"use client";

import * as React from "react";
import Link from "next/link";
import {
  Microscope,
  Mic,
  ClipboardList,
  MousePointerClick,
  BookOpen,
  Layers,
  Network,
  GitBranch,
  Plus,
  Users,
  Activity,
  CheckCircle2,
  ChevronRight,
  CalendarDays,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RESEARCH_STUDIES, type ResearchStudy } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ----------------------------------------------------------------------------
// Type metadata
// ----------------------------------------------------------------------------

const TYPE_META: Record<
  ResearchStudy["type"],
  { label: string; icon: React.ElementType; tint: string }
> = {
  interview: { label: "Interview", icon: Mic, tint: "bg-info/10 text-info" },
  survey: {
    label: "Survey",
    icon: ClipboardList,
    tint: "bg-success/10 text-success",
  },
  "usability-test": {
    label: "Usability test",
    icon: MousePointerClick,
    tint: "bg-warning/10 text-warning",
  },
  "diary-study": {
    label: "Diary study",
    icon: BookOpen,
    tint: "bg-friction/10 text-friction",
  },
  "card-sort": {
    label: "Card sort",
    icon: Layers,
    tint: "bg-info/10 text-info",
  },
  "tree-test": {
    label: "Tree test",
    icon: Network,
    tint: "bg-chart-5/10 text-chart-5",
  },
};

const TYPE_OPTIONS: FilterOption[] = [
  { label: "All types", value: "all" },
  { label: "Interview", value: "interview" },
  { label: "Survey", value: "survey" },
  { label: "Usability test", value: "usability-test" },
  { label: "Diary study", value: "diary-study" },
  { label: "Card sort", value: "card-sort" },
  { label: "Tree test", value: "tree-test" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Planning", value: "planning" },
  { label: "Recruiting", value: "recruiting" },
  { label: "In progress", value: "in-progress" },
  { label: "Analyzing", value: "analyzing" },
  { label: "Completed", value: "completed" },
  { label: "Archived", value: "archived" },
];

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function ResearchRepositoryPage() {
  const [search, setSearch] = React.useState("");
  const [type, setType] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return RESEARCH_STUDIES.filter((s) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !s.title.toLowerCase().includes(q) &&
          !s.project.toLowerCase().includes(q) &&
          !s.method.toLowerCase().includes(q) &&
          !s.owner.name.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (type !== "all" && s.type !== type) return false;
      if (status !== "all" && s.status !== status) return false;
      return true;
    });
  }, [search, type, status]);

  const clearFilters = () => {
    setSearch("");
    setType("all");
    setStatus("all");
  };

  // KPIs
  const total = RESEARCH_STUDIES.length;
  const inProgress = RESEARCH_STUDIES.filter(
    (s) =>
      s.status === "planning" ||
      s.status === "recruiting" ||
      s.status === "in-progress" ||
      s.status === "analyzing"
  ).length;
  const completedThisQuarter = RESEARCH_STUDIES.filter(
    (s) => s.status === "completed"
  ).length;
  const totalParticipants = RESEARCH_STUDIES.reduce(
    (sum, s) => sum + s.participants,
    0
  );

  return (
    <div>
      <PageHeader
        title="Research Repository"
        description="All your studies, interviews, surveys, and findings in one searchable knowledge base"
        breadcrumbs={[{ label: "Research" }]}
        icon={<Microscope className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {RESEARCH_STUDIES.length} studies
          </Badge>
        }
        actions={
          <Button
            size="sm"
            className="rounded-full"
            onClick={() =>
              toast.success("New study", {
                description: "Study builder will open in a new pane.",
              })
            }
          >
            <Plus className="mr-2 h-3.5 w-3.5" /> New study
          </Button>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total studies"
          value={total}
          icon={<Microscope className="h-4 w-4" />}
          accent="info"
          sublabel="across all projects"
        />
        <StatCard
          label="In progress"
          value={inProgress}
          icon={<Activity className="h-4 w-4" />}
          accent="warning"
          sublabel="planning → analyzing"
        />
        <StatCard
          label="Completed this quarter"
          value={completedThisQuarter}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          sublabel="Q2 2026 cycle"
        />
        <StatCard
          label="Total participants"
          value={totalParticipants}
          icon={<Users className="h-4 w-4" />}
          accent="info"
          sublabel="across all studies"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search study, project, method, owner…",
          }}
          selects={[
            { label: "Type", value: type, onChange: setType, options: TYPE_OPTIONS },
            {
              label: "Status",
              value: status,
              onChange: setStatus,
              options: STATUS_OPTIONS,
            },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Microscope}
          title="No studies match your filters"
          description="Try adjusting your search or filters, or kick off a new study to populate the repository."
          action={{ label: "Clear filters", onClick: clearFilters }}
          secondaryAction={{ label: "New study", onClick: () => toast.success("New study", { description: "Study builder will open in a new pane." }) }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((study) => (
            <StudyCard key={study.id} study={study} />
          ))}
        </div>
      )}

      {/* Helper note */}
      {!loading && filtered.length > 0 && (
        <Card className="mt-4 rounded-2xl border-soft shadow-soft p-3 flex items-start gap-2 bg-surface-2/40">
          <GitBranch className="h-3.5 w-3.5 text-muted-foreground mt-0.5 flex-shrink-0" />
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            Every study links to its findings, participants, raw notes, and evidence clips.
            Tag studies consistently so insights become searchable across the workspace.
          </p>
        </Card>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// Study card
// ----------------------------------------------------------------------------

function StudyCard({ study }: { study: ResearchStudy }) {
  const meta = TYPE_META[study.type];
  const Icon = meta.icon;
  const participantPct = study.targetParticipants
    ? Math.min(100, Math.round((study.participants / study.targetParticipants) * 100))
    : 0;

  return (
    <Link href={`/research/${study.id}`} className="group">
      <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div
              className={cn(
                "flex h-7 w-7 items-center justify-center rounded-lg",
                meta.tint
              )}
            >
              <Icon className="h-3.5 w-3.5" />
            </div>
            <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
              {meta.label}
            </span>
          </div>
          <StatusBadge status={study.status} />
        </div>

        <div className="font-semibold text-sm text-ink group-hover:text-primary transition-colors line-clamp-2 mb-1">
          {study.title}
        </div>
        <div className="text-[11px] text-muted-foreground line-clamp-1 mb-3">
          {study.method}
        </div>

        {/* Participants progress */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
            <span>Participants</span>
            <span className="font-medium text-ink tabular-nums">
              {study.participants}/{study.targetParticipants}
            </span>
          </div>
          <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
            <div
              className={cn(
                "h-full rounded-full transition-all",
                participantPct >= 100
                  ? "bg-success"
                  : participantPct > 0
                  ? "bg-info"
                  : "bg-muted"
              )}
              style={{ width: `${Math.max(participantPct, study.participants > 0 ? 6 : 0)}%` }}
            />
          </div>
        </div>

        {/* Tags + findings */}
        <div className="flex flex-wrap gap-1 mb-3">
          {study.tags.map((t) => (
            <Badge key={t} variant="secondary" className="text-[10px]">
              {t}
            </Badge>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-auto flex items-center justify-between pt-3 border-t border-soft">
          <div className="flex items-center gap-2 min-w-0">
            <Avatar className="h-6 w-6 ring-1 ring-soft flex-shrink-0">
              <AvatarImage src={study.owner.avatar} alt={study.owner.name} />
              <AvatarFallback>{study.owner.name.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <div className="text-[10px] text-muted-foreground truncate">
              {study.project}
            </div>
          </div>
          <div className="flex items-center gap-2 text-[10px] text-muted-foreground flex-shrink-0">
            <span className="inline-flex items-center gap-0.5">
              <CheckCircle2 className="h-3 w-3" />
              {study.findings} findings
            </span>
            <ChevronRight className="h-3.5 w-3.5 group-hover:text-ink transition-colors" />
          </div>
        </div>

        <div className="mt-2 flex items-center gap-1 text-[10px] text-muted-foreground">
          <CalendarDays className="h-3 w-3" />
          <span>
            {study.startDate} → {study.endDate}
          </span>
        </div>
      </Card>
    </Link>
  );
}
