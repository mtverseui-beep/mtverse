"use client";

import * as React from "react";
import {
  Mic,
  Clock,
  CalendarDays,
  Eye,
  Headphones,
  Monitor,
  Smartphone,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RESEARCH_STUDIES } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ----------------------------------------------------------------------------
// Mock interviews — derived deterministically from RESEARCH_STUDIES
// ----------------------------------------------------------------------------

interface Interview {
  id: string;
  participant: string;
  avatar: string;
  studyId: string;
  study: string;
  date: string;
  duration: string;
  type: "moderated" | "unmoderated";
  status: "completed" | "scheduled" | "in-progress" | "transcribing" | "no-show";
  statusTone: "success" | "info" | "warning" | "friction";
  tags: string[];
}

const INTERVIEWS: Interview[] = [
  {
    id: "iv-001",
    participant: "Anya Petrov",
    avatar: "https://i.pravatar.cc/80?img=5",
    studyId: "rs-001",
    study: "Atlas KYC Friction",
    date: "2026-06-23",
    duration: "47:12",
    type: "moderated",
    status: "completed",
    statusTone: "success",
    tags: ["KYC", "mobile"],
  },
  {
    id: "iv-002",
    participant: "Marcus Lin",
    avatar: "https://i.pravatar.cc/80?img=11",
    studyId: "rs-001",
    study: "Atlas KYC Friction",
    date: "2026-06-23",
    duration: "38:04",
    type: "moderated",
    status: "completed",
    statusTone: "success",
    tags: ["KYC", "desktop"],
  },
  {
    id: "iv-003",
    participant: "Priya Shah",
    avatar: "https://i.pravatar.cc/80?img=20",
    studyId: "rs-001",
    study: "Atlas KYC Friction",
    date: "2026-06-24",
    duration: "52:30",
    type: "moderated",
    status: "transcribing",
    statusTone: "info",
    tags: ["address", "friction"],
  },
  {
    id: "iv-004",
    participant: "Diego Costa",
    avatar: "https://i.pravatar.cc/80?img=33",
    studyId: "rs-002",
    study: "Northwind Checkout — Usability",
    date: "2026-06-25",
    duration: "18:42",
    type: "unmoderated",
    status: "completed",
    statusTone: "success",
    tags: ["checkout", "iOS"],
  },
  {
    id: "iv-005",
    participant: "Hana Sato",
    avatar: "https://i.pravatar.cc/80?img=45",
    studyId: "rs-002",
    study: "Northwind Checkout — Usability",
    date: "2026-06-25",
    duration: "22:11",
    type: "unmoderated",
    status: "completed",
    statusTone: "success",
    tags: ["checkout", "tablet"],
  },
  {
    id: "iv-006",
    participant: "Liam O'Brien",
    avatar: "https://i.pravatar.cc/80?img=51",
    studyId: "rs-001",
    study: "Atlas KYC Friction",
    date: "2026-06-26",
    duration: "41:55",
    type: "moderated",
    status: "scheduled",
    statusTone: "warning",
    tags: ["KYC", "mobile"],
  },
  {
    id: "iv-007",
    participant: "Sofia Romano",
    avatar: "https://i.pravatar.cc/80?img=48",
    studyId: "rs-002",
    study: "Northwind Checkout — Usability",
    date: "2026-06-26",
    duration: "—",
    type: "unmoderated",
    status: "no-show",
    statusTone: "friction",
    tags: ["checkout"],
  },
  {
    id: "iv-008",
    participant: "Tomas Berg",
    avatar: "https://i.pravatar.cc/80?img=12",
    studyId: "rs-001",
    study: "Atlas KYC Friction",
    date: "2026-06-27",
    duration: "33:20",
    type: "moderated",
    status: "in-progress",
    statusTone: "info",
    tags: ["KYC", "desktop"],
  },
];

// ----------------------------------------------------------------------------
// Filters
// ----------------------------------------------------------------------------

const STUDY_OPTIONS: FilterOption[] = [
  { label: "All studies", value: "all" },
  ...RESEARCH_STUDIES.filter((s) => s.type === "interview" || s.type === "usability-test").map(
    (s) => ({ label: s.title.split("—")[0].trim(), value: s.id })
  ),
];

const TYPE_OPTIONS: FilterOption[] = [
  { label: "All types", value: "all" },
  { label: "Moderated", value: "moderated" },
  { label: "Unmoderated", value: "unmoderated" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Completed", value: "completed" },
  { label: "Scheduled", value: "scheduled" },
  { label: "In progress", value: "in-progress" },
  { label: "Transcribing", value: "transcribing" },
  { label: "No-show", value: "no-show" },
];

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function InterviewsPage() {
  const [search, setSearch] = React.useState("");
  const [study, setStudy] = React.useState("all");
  const [type, setType] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return INTERVIEWS.filter((i) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !i.participant.toLowerCase().includes(q) &&
          !i.study.toLowerCase().includes(q) &&
          !i.tags.join(" ").toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (study !== "all" && i.studyId !== study) return false;
      if (type !== "all" && i.type !== type) return false;
      if (status !== "all" && i.status !== status) return false;
      return true;
    });
  }, [search, study, type, status]);

  const clearFilters = () => {
    setSearch("");
    setStudy("all");
    setType("all");
    setStatus("all");
  };

  // KPIs
  const total = INTERVIEWS.length;
  const completed = INTERVIEWS.filter((i) => i.status === "completed").length;
  const scheduled = INTERVIEWS.filter(
    (i) => i.status === "scheduled" || i.status === "in-progress"
  ).length;
  const noShows = INTERVIEWS.filter((i) => i.status === "no-show").length;

  const columns: Column<Interview>[] = [
    {
      key: "participant",
      header: "Participant",
      cell: (i) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7 ring-1 ring-soft">
            <AvatarImage src={i.avatar} alt={i.participant} />
            <AvatarFallback>{i.participant.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="font-medium text-ink text-xs truncate">{i.participant}</div>
            <div className="text-[10px] text-muted-foreground">{i.id}</div>
          </div>
        </div>
      ),
      sortAccessor: (i) => i.participant,
      sortable: true,
    },
    {
      key: "study",
      header: "Study",
      cell: (i) => (
        <span className="text-xs text-ink line-clamp-1 max-w-[200px]">{i.study}</span>
      ),
      sortAccessor: (i) => i.study,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "date",
      header: "Date",
      cell: (i) => (
        <span className="text-xs font-mono text-muted-foreground">{i.date}</span>
      ),
      sortAccessor: (i) => i.date,
      sortable: true,
    },
    {
      key: "duration",
      header: "Duration",
      cell: (i) => (
        <span className="text-xs font-mono tabular-nums">{i.duration}</span>
      ),
      sortAccessor: (i) => i.duration,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "type",
      header: "Type",
      cell: (i) => (
        <Badge
          variant="outline"
          className={
            i.type === "moderated"
              ? "text-[10px] border-info/20 bg-info/10 text-info"
              : "text-[10px] border-warning/20 bg-warning/10 text-warning"
          }
        >
          {i.type}
        </Badge>
      ),
      sortAccessor: (i) => i.type,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (i) => {
        const tones: Record<Interview["statusTone"], string> = {
          success: "border-success/20 bg-success/10 text-success",
          info: "border-info/20 bg-info/10 text-info",
          warning: "border-warning/20 bg-warning/10 text-warning",
          friction: "border-friction/20 bg-friction/10 text-friction",
        };
        return (
          <Badge variant="outline" className={cn("text-[10px] font-medium capitalize", tones[i.statusTone])}>
            {i.status.replace("-", " ")}
          </Badge>
        );
      },
      sortAccessor: (i) => i.status,
      sortable: true,
    },
    {
      key: "tags",
      header: "Tags",
      cell: (i) => (
        <div className="flex flex-wrap gap-1">
          {i.tags.slice(0, 2).map((t) => (
            <Badge key={t} variant="secondary" className="text-[10px]">
              {t}
            </Badge>
          ))}
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "actions",
      header: "",
      cell: (i) => (
        <Button
          size="sm"
          variant="ghost"
          className="h-8 px-2 text-xs"
          onClick={() =>
            toast.info(`Opening ${i.participant}'s interview`, {
              description: i.type === "moderated"
                ? "Transcript + audio will open in a new pane."
                : "Video + behavior log will open in a new pane.",
            })
          }
        >
          <Eye className="mr-1 h-3.5 w-3.5" /> View
        </Button>
      ),
      width: "80px",
    },
  ];

  return (
    <div>
      <PageHeader
        title="User Interviews"
        description="Moderated and unmoderated interview notes and transcripts"
        breadcrumbs={[{ label: "Research", href: "/research" }, { label: "Interviews" }]}
        icon={<Mic className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {INTERVIEWS.length} interviews
          </Badge>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total interviews"
          value={total}
          icon={<Mic className="h-4 w-4" />}
          accent="info"
          sublabel="across studies"
        />
        <StatCard
          label="Completed"
          value={completed}
          icon={<Clock className="h-4 w-4" />}
          accent="success"
          sublabel="transcripts ready"
        />
        <StatCard
          label="Scheduled / live"
          value={scheduled}
          icon={<CalendarDays className="h-4 w-4" />}
          accent="warning"
          sublabel="upcoming sessions"
        />
        <StatCard
          label="No-shows"
          value={noShows}
          icon={<Headphones className="h-4 w-4" />}
          accent={noShows > 0 ? "friction" : "success"}
          sublabel="need rebooking"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search participant, study, tags…",
          }}
          selects={[
            { label: "Study", value: study, onChange: setStudy, options: STUDY_OPTIONS },
            { label: "Type", value: type, onChange: setType, options: TYPE_OPTIONS },
            { label: "Status", value: status, onChange: setStatus, options: STATUS_OPTIONS },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="table" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Mic}
          title="No interviews match your filters"
          description="Try adjusting your search or filters. New interviews appear here as studies progress."
          action={{ label: "Clear filters", onClick: clearFilters }}
          secondaryAction={{ label: "Browse research", href: "/research" }}
        />
      ) : (
        <DataTable
          data={filtered}
          columns={columns}
          getRowId={(i) => i.id}
          pageSize={10}
          emptyTitle="No interviews found"
          emptyDescription="Try adjusting your search or filters."
        />
      )}
    </div>
  );
}
