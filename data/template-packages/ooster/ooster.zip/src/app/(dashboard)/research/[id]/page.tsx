"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import {
  Microscope,
  Mic,
  ClipboardList,
  MousePointerClick,
  BookOpen,
  Layers,
  Network,
  Share2,
  Download,
  Pencil,
  Users,
  CalendarDays,
  FolderKanban,
  Activity,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Video,
  ImageIcon,
  Flame,
  PlayCircle,
  MapPin,
  Monitor,
  Smartphone,
  Tablet,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge, SeverityBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  getStudy,
  type ResearchStudy,
} from "@/lib/data";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ----------------------------------------------------------------------------
// Type meta (mirrors the repository page)
// ----------------------------------------------------------------------------

const TYPE_META: Record<
  ResearchStudy["type"],
  { label: string; icon: React.ElementType; tint: string }
> = {
  interview: { label: "Interview", icon: Mic, tint: "bg-info/10 text-info" },
  survey: {
    label: "Survey",
    icon: ClipboardList,
    tint: "bg-success/10 text-success",
  },
  "usability-test": {
    label: "Usability test",
    icon: MousePointerClick,
    tint: "bg-warning/10 text-warning",
  },
  "diary-study": {
    label: "Diary study",
    icon: BookOpen,
    tint: "bg-friction/10 text-friction",
  },
  "card-sort": { label: "Card sort", icon: Layers, tint: "bg-info/10 text-info" },
  "tree-test": {
    label: "Tree test",
    icon: Network,
    tint: "bg-chart-5/10 text-chart-5",
  },
};

// ----------------------------------------------------------------------------
// Mock content — deterministically derived from the study id
// ----------------------------------------------------------------------------

interface Finding {
  severity: "critical" | "high" | "medium" | "low";
  title: string;
  description: string;
  evidence: number;
}

const FINDINGS: Finding[] = [
  {
    severity: "critical",
    title: "Document upload fails silently on iOS Safari 17",
    description:
      "13% of mobile sessions stall at the upload step because the file picker returns an empty selection. Participants retried 2.4× on average before abandoning.",
    evidence: 7,
  },
  {
    severity: "high",
    title: "Field-level validation missing on routing number",
    description:
      "Errors only surface after submit, triggering a full-screen re-render. Inline validation would cut completion time by an estimated 22s.",
    evidence: 5,
  },
  {
    severity: "high",
    title: "Confirmation page creates decision fatigue",
    description:
      "Four competing CTAs (review, edit, cancel, confirm) caused hesitation 2.8s longer than benchmark before primary action.",
    evidence: 4,
  },
  {
    severity: "medium",
    title: "Color contrast on secondary buttons falls below WCAG AA",
    description:
      "Slate-on-ivory secondary buttons measure 3.9:1 contrast, below the 4.5:1 threshold required for normal-sized text.",
    evidence: 3,
  },
  {
    severity: "medium",
    title: "Microcopy inconsistency erodes trust on success states",
    description:
      "Three different phrasings for transfer completion across screens. Consolidating to a single voice pattern would strengthen brand confidence.",
    evidence: 2,
  },
  {
    severity: "low",
    title: "Tooltip timing on help icons feels jumpy",
    description:
      "Hover-triggered tooltips appear after 200ms; benchmark is 400–600ms. Participants described the experience as 'twitchy'.",
    evidence: 2,
  },
];

interface Participant {
  id: string;
  name: string;
  avatar: string;
  status: "completed" | "in-progress" | "scheduled" | "no-show";
  statusTone: "success" | "info" | "warning" | "friction";
  sessions: number;
  device: "desktop" | "mobile" | "tablet";
  location: string;
}

const PARTICIPANTS: Participant[] = [
  { id: "p-01", name: "Anya Petrov", avatar: "https://i.pravatar.cc/80?img=5", status: "completed", statusTone: "success", sessions: 3, device: "mobile", location: "Berlin, DE" },
  { id: "p-02", name: "Marcus Lin", avatar: "https://i.pravatar.cc/80?img=11", status: "completed", statusTone: "success", sessions: 2, device: "desktop", location: "Toronto, CA" },
  { id: "p-03", name: "Priya Shah", avatar: "https://i.pravatar.cc/80?img=20", status: "in-progress", statusTone: "info", sessions: 1, device: "mobile", location: "Mumbai, IN" },
  { id: "p-04", name: "Diego Costa", avatar: "https://i.pravatar.cc/80?img=33", status: "completed", statusTone: "success", sessions: 3, device: "desktop", location: "Lisbon, PT" },
  { id: "p-05", name: "Hana Sato", avatar: "https://i.pravatar.cc/80?img=45", status: "scheduled", statusTone: "warning", sessions: 0, device: "tablet", location: "Osaka, JP" },
  { id: "p-06", name: "Liam O'Brien", avatar: "https://i.pravatar.cc/80?img=51", status: "completed", statusTone: "success", sessions: 2, device: "mobile", location: "Dublin, IE" },
  { id: "p-07", name: "Sofia Romano", avatar: "https://i.pravatar.cc/80?img=48", status: "no-show", statusTone: "friction", sessions: 0, device: "desktop", location: "Milan, IT" },
  { id: "p-08", name: "Tomas Berg", avatar: "https://i.pravatar.cc/80?img=12", status: "completed", statusTone: "success", sessions: 3, device: "desktop", location: "Stockholm, SE" },
];

interface InterviewNote {
  id: string;
  participant: string;
  avatar: string;
  timestamp: string;
  author: string;
  body: string;
  tags: string[];
}

const NOTES: InterviewNote[] = [
  {
    id: "n-01",
    participant: "Anya Petrov",
    avatar: "https://i.pravatar.cc/80?img=5",
    timestamp: "2026-06-23 · 14:02",
    author: "Mira Halberg",
    body:
      "Anya navigated to the upload screen in 18s, then spent 47s examining the document type selector. She tapped 'Passport' twice before realizing it was mislabeled — said 'this is a visa, not a passport'. Strong signal for the labeling fix already in flight.",
    tags: ["KYC", "labeling", "mobile"],
  },
  {
    id: "n-02",
    participant: "Marcus Lin",
    avatar: "https://i.pravatar.cc/80?img=11",
    timestamp: "2026-06-23 · 15:48",
    author: "Mira Halberg",
    body:
      "Marcus completed the full flow in 4:12 — fastest of the cohort. Commented that the progress indicator 'finally feels honest' after the previous build. Did pause for 8s on the confirmation page, called out 4 buttons as 'too many choices'.",
    tags: ["confirmation", "CTA overload"],
  },
  {
    id: "n-03",
    participant: "Priya Shah",
    avatar: "https://i.pravatar.cc/80?img=20",
    timestamp: "2026-06-24 · 10:15",
    author: "Sana Iqbal",
    body:
      "Session ran 38 minutes. Priya explicitly asked 'why do I have to enter my address twice?' — captured the friction on video at 14:22. Recommend surfacing this in the next stakeholder review; the address re-entry adds 19s on average.",
    tags: ["friction", "address", "video evidence"],
  },
  {
    id: "n-04",
    participant: "Diego Costa",
    avatar: "https://i.pravatar.cc/80?img=33",
    timestamp: "2026-06-24 · 16:30",
    author: "Mira Halberg",
    body:
      "Diego's session surfaced the silent upload failure on iOS Safari 17 — file picker returned empty selection, no toast, no error state. He retried 3 times before abandoning. Logged as critical; engineering ticket IS-002 created during the session.",
    tags: ["critical", "iOS Safari", "upload"],
  },
];

interface Evidence {
  id: string;
  type: "heatmap" | "replay" | "screenshot" | "audio";
  title: string;
  meta: string;
}

const EVIDENCE: Evidence[] = [
  { id: "e-01", type: "heatmap", title: "Upload screen — click heatmap", meta: "1,240 sessions · mobile" },
  { id: "e-02", type: "replay", title: "Diego Costa — session 4 retry loop", meta: "2:41 · iOS Safari 17" },
  { id: "e-03", type: "screenshot", title: "Mislabelled Passport selector", meta: "Step 3 · captured 14:02" },
  { id: "e-04", type: "audio", title: "Priya Shah — 'why enter address twice?'", meta: "0:14 clip · 14:22 mark" },
  { id: "e-05", type: "replay", title: "Anya Petrov — hesitation at upload", meta: "0:47 · mobile" },
  { id: "e-06", type: "screenshot", title: "Confirmation page — 4 CTAs", meta: "Final step · annotated" },
];

// ----------------------------------------------------------------------------
// Subcomponents
// ----------------------------------------------------------------------------

function InfoRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        {icon}
        <span className="text-xs">{label}</span>
      </div>
      <span className="text-xs text-ink font-medium text-right truncate max-w-[60%]">
        {value}
      </span>
    </div>
  );
}

function EvidenceIcon({ type }: { type: Evidence["type"] }) {
  const cls = "h-4 w-4";
  if (type === "heatmap") return <Flame className={cn(cls, "text-friction")} />;
  if (type === "replay") return <PlayCircle className={cn(cls, "text-info")} />;
  if (type === "screenshot") return <ImageIcon className={cn(cls, "text-success")} />;
  return <Video className={cn(cls, "text-warning")} />;
}

function DeviceIcon({ device }: { device: Participant["device"] }) {
  if (device === "mobile") return <Smartphone className="h-3.5 w-3.5" />;
  if (device === "tablet") return <Tablet className="h-3.5 w-3.5" />;
  return <Monitor className="h-3.5 w-3.5" />;
}

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function StudyDetailPage() {
  const params = useParams<{ id: string }>();
  const study = getStudy(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [tab, setTab] = React.useState("overview");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  if (!study) {
    return (
      <EmptyState
        icon={Microscope}
        title="Study not found"
        description="This study may have been archived, deleted, or the link is incorrect."
        action={{ label: "Back to research", href: "/research" }}
      />
    );
  }

  const meta = TYPE_META[study.type];
  const Icon = meta.icon;
  const participantPct = study.targetParticipants
    ? Math.min(100, Math.round((study.participants / study.targetParticipants) * 100))
    : 0;

  const handleShare = () => {
    openShare(`https://ooster.app/r/${study.id}`, study.title);
  };

  const handleExport = () => {
    toast.success("Export queued", {
      description: "PDF with findings, notes, and evidence will be emailed when ready.",
    });
  };

  const handleEdit = () => {
    toast.info("Edit study", { description: "Opening study editor in a new pane." });
  };

  // Participants table columns
  const participantColumns: Column<Participant>[] = [
    {
      key: "name",
      header: "Participant",
      cell: (p) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-7 w-7 ring-1 ring-soft">
            <AvatarImage src={p.avatar} alt={p.name} />
            <AvatarFallback>{p.name.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="font-medium text-ink text-xs truncate">{p.name}</div>
            <div className="text-[10px] text-muted-foreground">{p.id}</div>
          </div>
        </div>
      ),
      sortAccessor: (p) => p.name,
      sortable: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (p) => {
        const tones: Record<Participant["statusTone"], string> = {
          success: "border-success/20 bg-success/10 text-success",
          info: "border-info/20 bg-info/10 text-info",
          warning: "border-warning/20 bg-warning/10 text-warning",
          friction: "border-friction/20 bg-friction/10 text-friction",
        };
        return (
          <Badge variant="outline" className={cn("text-[10px] font-medium capitalize", tones[p.statusTone])}>
            {p.status.replace("-", " ")}
          </Badge>
        );
      },
      sortAccessor: (p) => p.status,
      sortable: true,
    },
    {
      key: "sessions",
      header: "Sessions",
      cell: (p) => (
        <span className="text-xs tabular-nums">
          {p.sessions} {p.sessions === 1 ? "session" : "sessions"}
        </span>
      ),
      sortAccessor: (p) => p.sessions,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "device",
      header: "Device",
      cell: (p) => (
        <div className="flex items-center gap-1.5 text-xs capitalize">
          <DeviceIcon device={p.device} />
          <span>{p.device}</span>
        </div>
      ),
      sortAccessor: (p) => p.device,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "location",
      header: "Location",
      cell: (p) => (
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="h-3 w-3" />
          <span>{p.location}</span>
        </div>
      ),
      hideOnMobile: true,
    },
  ];

  return (
    <div>
      <PageHeader
        title={study.title}
        description={study.method}
        breadcrumbs={[
          { label: "Research", href: "/research" },
          { label: study.id },
        ]}
        icon={<Icon className="h-5 w-5" />}
        badge={<StatusBadge status={study.status} />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleShare}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleExport}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm" className="rounded-full" onClick={handleEdit}>
              <Pencil className="mr-2 h-3.5 w-3.5" /> Edit
            </Button>
          </>
        }
      />

      {/* Tabs */}
      <Tabs value={tab} onValueChange={setTab} className="w-full">
        <TabsList className="mb-4 overflow-x-auto no-scrollbar max-w-full flex-wrap h-auto sm:flex-nowrap">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="findings">Findings</TabsTrigger>
          <TabsTrigger value="participants">Participants</TabsTrigger>
          <TabsTrigger value="notes">Notes</TabsTrigger>
          <TabsTrigger value="evidence">Evidence</TabsTrigger>
        </TabsList>

        {/* Overview tab */}
        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Study meta */}
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-1 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={cn("flex h-8 w-8 items-center justify-center rounded-lg", meta.tint)}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-semibold text-ink">Study details</span>
                </div>
                <Badge variant="secondary" className="text-[10px]">
                  {meta.label}
                </Badge>
              </div>
              <div className="space-y-2 pt-1">
                <InfoRow icon={<FolderKanban className="h-3.5 w-3.5" />} label="Project" value={study.project} />
                <InfoRow icon={<Activity className="h-3.5 w-3.5" />} label="Method" value={study.method} />
                <InfoRow icon={<CalendarDays className="h-3.5 w-3.5" />} label="Start date" value={study.startDate} />
                <InfoRow icon={<CalendarDays className="h-3.5 w-3.5" />} label="End date" value={study.endDate} />
                <InfoRow icon={<Clock className="h-3.5 w-3.5" />} label="Duration" value={study.duration} />
                <InfoRow icon={<Users className="h-3.5 w-3.5" />} label="Target participants" value={`${study.targetParticipants}`} />
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Activity className="h-3.5 w-3.5" />
                    <span className="text-xs">Status</span>
                  </div>
                  <StatusBadge status={study.status} />
                </div>
              </div>
              <div className="pt-2 border-t border-soft">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8 ring-1 ring-soft">
                    <AvatarImage src={study.owner.avatar} alt={study.owner.name} />
                    <AvatarFallback>{study.owner.name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink truncate">{study.owner.name}</div>
                    <div className="text-[10px] text-muted-foreground">Study owner</div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 pt-2 border-t border-soft">
                {study.tags.map((t) => (
                  <Badge key={t} variant="secondary" className="text-[10px]">
                    {t}
                  </Badge>
                ))}
              </div>
            </Card>

            {/* Progress + key findings */}
            <div className="lg:col-span-2 space-y-4">
              {/* Participant progress */}
              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm font-semibold text-ink">Participant recruitment</div>
                    <div className="text-[11px] text-muted-foreground">
                      {study.participants} of {study.targetParticipants} recruited
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-semibold tabular-nums text-ink">
                      {participantPct}%
                    </div>
                    <div className="text-[10px] text-muted-foreground">of target</div>
                  </div>
                </div>
                <div className="h-2.5 rounded-full bg-surface-2 overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all",
                      participantPct >= 100 ? "bg-success" : "bg-info"
                    )}
                    style={{ width: `${Math.max(participantPct, study.participants > 0 ? 4 : 0)}%` }}
                  />
                </div>
                <div className="grid grid-cols-3 gap-3 mt-4">
                  <div className="rounded-xl bg-surface-2/50 p-2.5">
                    <div className="text-[10px] text-muted-foreground">Recruited</div>
                    <div className="text-lg font-semibold tabular-nums text-ink">{study.participants}</div>
                  </div>
                  <div className="rounded-xl bg-surface-2/50 p-2.5">
                    <div className="text-[10px] text-muted-foreground">Completed</div>
                    <div className="text-lg font-semibold tabular-nums text-ink">
                      {Math.max(0, study.participants - 2)}
                    </div>
                  </div>
                  <div className="rounded-xl bg-surface-2/50 p-2.5">
                    <div className="text-[10px] text-muted-foreground">No-shows</div>
                    <div className="text-lg font-semibold tabular-nums text-friction">1</div>
                  </div>
                </div>
              </Card>

              {/* Key findings summary */}
              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-success" />
                    <span className="text-sm font-semibold text-ink">Key findings summary</span>
                  </div>
                  <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setTab("findings")}>
                    View all
                  </Button>
                </div>
                <div className="space-y-2">
                  {FINDINGS.slice(0, 3).map((f, i) => (
                    <div
                      key={i}
                      className="flex items-start gap-3 p-2.5 rounded-xl bg-surface-2/30"
                    >
                      <SeverityBadge severity={f.severity} />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-medium text-ink line-clamp-1">{f.title}</div>
                        <div className="text-[10px] text-muted-foreground line-clamp-1 mt-0.5">
                          {f.description}
                        </div>
                      </div>
                      <span className="text-[10px] text-muted-foreground flex-shrink-0">
                        {f.evidence} evidence
                      </span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Mini stat row */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <StatCard
                  label="Findings"
                  value={study.findings}
                  icon={<CheckCircle2 className="h-4 w-4" />}
                  accent="success"
                  sublabel="captured"
                />
                <StatCard
                  label="Evidence clips"
                  value={EVIDENCE.length}
                  icon={<FileText className="h-4 w-4" />}
                  accent="info"
                  sublabel="tagged"
                />
                <StatCard
                  label="Avg session"
                  value="38m"
                  icon={<Clock className="h-4 w-4" />}
                  sublabel="across cohort"
                />
                <StatCard
                  label="Critical findings"
                  value={FINDINGS.filter((f) => f.severity === "critical").length}
                  icon={<AlertTriangle className="h-4 w-4" />}
                  accent="friction"
                  sublabel="P0 priority"
                />
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Findings tab */}
        <TabsContent value="findings">
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-sm font-semibold text-ink">Findings</div>
                <div className="text-[11px] text-muted-foreground">
                  {FINDINGS.length} findings ranked by severity
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="rounded-full"
                onClick={() => toast.success("Findings exported as CSV")}
              >
                <Download className="mr-2 h-3.5 w-3.5" /> Export
              </Button>
            </div>
            <div className="space-y-3">
              {FINDINGS.map((f, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-soft p-3 hover:border-primary/30 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2">
                      <SeverityBadge severity={f.severity} />
                      <span className="text-sm font-medium text-ink">{f.title}</span>
                    </div>
                    <Badge variant="secondary" className="text-[10px] flex-shrink-0">
                      {f.evidence} evidence
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {f.description}
                  </p>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Participants tab */}
        <TabsContent value="participants">
          <DataTable
            data={PARTICIPANTS}
            columns={participantColumns}
            getRowId={(p) => p.id}
            pageSize={10}
            emptyTitle="No participants yet"
            emptyDescription="Recruitment is still in progress."
          />
        </TabsContent>

        {/* Notes tab */}
        <TabsContent value="notes">
          <div className="space-y-3">
            {NOTES.map((n) => (
              <Card key={n.id} className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-start gap-3">
                  <Avatar className="h-9 w-9 ring-1 ring-soft flex-shrink-0">
                    <AvatarImage src={n.avatar} alt={n.participant} />
                    <AvatarFallback>{n.participant.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="text-sm font-medium text-ink">{n.participant}</div>
                      <span className="text-[10px] text-muted-foreground flex-shrink-0 font-mono">
                        {n.timestamp}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed mb-2">
                      {n.body}
                    </p>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex flex-wrap gap-1">
                        {n.tags.map((t) => (
                          <Badge key={t} variant="secondary" className="text-[10px]">
                            {t}
                          </Badge>
                        ))}
                      </div>
                      <span className="text-[10px] text-muted-foreground">
                        by {n.author}
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Evidence tab */}
        <TabsContent value="evidence">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {EVIDENCE.map((e) => (
              <Card
                key={e.id}
                className="rounded-2xl border-soft shadow-soft p-4 hover:shadow-card hover:border-primary/30 transition-all cursor-pointer group"
                onClick={() => toast.info(`Opening ${e.title}`, { description: e.meta })}
              >
                <div className="aspect-video rounded-xl bg-surface-2/50 flex items-center justify-center mb-3 overflow-hidden">
                  <EvidenceIcon type={e.type} />
                </div>
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink group-hover:text-primary transition-colors line-clamp-1">
                      {e.title}
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">
                      {e.meta}
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
