"use client";

import * as React from "react";
import {
  Users,
  Search,
  MoreHorizontal,
  ShieldCheck,
  ShieldX,
  ShieldAlert,
  MapPin,
  Monitor,
  Smartphone,
  Tablet,
  Cake,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { EmptyState } from "@/components/common/empty-state";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DataTable, type Column } from "@/components/tables/data-table";
import { DonutChart } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type ParticipantStatus = "active" | "inactive" | "withdrawn";
type Consent = "given" | "partial" | "withdrawn";

interface Participant {
  id: string;
  name: string;
  email: string;
  avatar: string;
  age: number;
  studies: number;
  lastParticipated: string;
  status: ParticipantStatus;
  segments: string[];
  consent: Consent;
  device: "Desktop" | "Mobile" | "Tablet";
  location: string;
}

const PARTICIPANTS: Participant[] = [
  { id: "pt-1", name: "Anika Rao", email: "anika.rao@example.com", avatar: "https://i.pravatar.cc/80?img=5", age: 28, studies: 4, lastParticipated: "2 days ago", status: "active", segments: ["Mobile", "Power user"], consent: "given", device: "Mobile", location: "Bengaluru, IN" },
  { id: "pt-2", name: "Marcus Chen", email: "m.chen@example.com", avatar: "https://i.pravatar.cc/80?img=11", age: 34, studies: 2, lastParticipated: "1 week ago", status: "active", segments: ["Desktop", "CRO"], consent: "given", device: "Desktop", location: "Singapore, SG" },
  { id: "pt-3", name: "Priya Nair", email: "priya.n@example.com", avatar: "https://i.pravatar.cc/80?img=20", age: 31, studies: 6, lastParticipated: "Today", status: "active", segments: ["Mobile", "Returning"], consent: "given", device: "Mobile", location: "Mumbai, IN" },
  { id: "pt-4", name: "Diego Alvarez", email: "diego.a@example.com", avatar: "https://i.pravatar.cc/80?img=33", age: 26, studies: 3, lastParticipated: "3 weeks ago", status: "inactive", segments: ["Mobile", "New"], consent: "given", device: "Mobile", location: "Madrid, ES" },
  { id: "pt-5", name: "Yuki Tanaka", email: "yuki.t@example.com", avatar: "https://i.pravatar.cc/80?img=45", age: 39, studies: 5, lastParticipated: "1 month ago", status: "active", segments: ["Desktop", "Power user"], consent: "given", device: "Desktop", location: "Osaka, JP" },
  { id: "pt-6", name: "Sofia Rossi", email: "s.rossi@example.com", avatar: "https://i.pravatar.cc/80?img=48", age: 42, studies: 1, lastParticipated: "2 months ago", status: "withdrawn", segments: ["Tablet"], consent: "withdrawn", device: "Tablet", location: "Milan, IT" },
  { id: "pt-7", name: "Liam Walsh", email: "liam.w@example.com", avatar: "https://i.pravatar.cc/80?img=51", age: 29, studies: 7, lastParticipated: "5 days ago", status: "active", segments: ["Mobile", "Returning"], consent: "partial", device: "Mobile", location: "Dublin, IE" },
  { id: "pt-8", name: "Zara Ahmed", email: "zara.a@example.com", avatar: "https://i.pravatar.cc/80?img=60", age: 36, studies: 2, lastParticipated: "3 days ago", status: "active", segments: ["Desktop", "CRO"], consent: "given", device: "Desktop", location: "Dubai, AE" },
  { id: "pt-9", name: "Noah Becker", email: "noah.b@example.com", avatar: "https://i.pravatar.cc/80?img=13", age: 24, studies: 0, lastParticipated: "—", status: "inactive", segments: ["New"], consent: "given", device: "Mobile", location: "Berlin, DE" },
  { id: "pt-10", name: "Lena Ortiz", email: "lena.o@example.com", avatar: "https://i.pravatar.cc/80?img=45", age: 33, studies: 8, lastParticipated: "Yesterday", status: "active", segments: ["Desktop", "Power user"], consent: "given", device: "Desktop", location: "Austin, US" },
  { id: "pt-11", name: "Idris Khoury", email: "idris.k@example.com", avatar: "https://i.pravatar.cc/80?img=33", age: 41, studies: 3, lastParticipated: "6 days ago", status: "active", segments: ["Mobile", "Returning"], consent: "given", device: "Mobile", location: "Beirut, LB" },
  { id: "pt-12", name: "Aria Mendez", email: "aria.m@example.com", avatar: "https://i.pravatar.cc/80?img=48", age: 27, studies: 1, lastParticipated: "2 weeks ago", status: "inactive", segments: ["Tablet", "New"], consent: "partial", device: "Tablet", location: "Lisbon, PT" },
];

const STATUS_TINT: Record<ParticipantStatus, string> = {
  active: "border-success/20 bg-success/10 text-success",
  inactive: "border-border bg-muted text-muted-foreground",
  withdrawn: "border-friction/20 bg-friction/10 text-friction",
};

const CONSENT_META: Record<Consent, { color: string; icon: typeof ShieldCheck; label: string }> = {
  given: { color: "border-success/20 bg-success/10 text-success", icon: ShieldCheck, label: "Consented" },
  partial: { color: "border-warning/20 bg-warning/10 text-warning", icon: ShieldAlert, label: "Partial" },
  withdrawn: { color: "border-friction/20 bg-friction/10 text-friction", icon: ShieldX, label: "Withdrawn" },
};

const AGE_DISTRIBUTION = [
  { label: "18–24", value: 14, color: "var(--chart-1)" },
  { label: "25–34", value: 38, color: "var(--chart-2)" },
  { label: "35–44", value: 28, color: "var(--chart-3)" },
  { label: "45–54", value: 14, color: "var(--chart-4)" },
  { label: "55+", value: 6, color: "var(--chart-5)" },
];

const DEVICE_SPLIT = [
  { label: "Mobile", value: 58, color: "var(--success)" },
  { label: "Desktop", value: 32, color: "var(--info)" },
  { label: "Tablet", value: 10, color: "var(--warning)" },
];

const LOCATIONS = [
  { region: "Asia Pacific", count: 4, pct: 33 },
  { region: "Europe", count: 5, pct: 42 },
  { region: "North America", count: 1, pct: 8 },
  { region: "Middle East", count: 1, pct: 8 },
  { region: "Other", count: 1, pct: 8 },
];

const DEVICE_ICON = { Desktop: Monitor, Mobile: Smartphone, Tablet: Tablet };

export default function ParticipantsPage() {
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [statusFilter, setStatusFilter] = React.useState("all");
  const [consentFilter, setConsentFilter] = React.useState("all");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return PARTICIPANTS.filter((p) => {
      if (search && !`${p.name} ${p.email} ${p.location}`.toLowerCase().includes(search.toLowerCase())) return false;
      if (statusFilter !== "all" && p.status !== statusFilter) return false;
      if (consentFilter !== "all" && p.consent !== consentFilter) return false;
      return true;
    });
  }, [search, statusFilter, consentFilter]);

  const active = PARTICIPANTS.filter((p) => p.status === "active").length;
  const consented = PARTICIPANTS.filter((p) => p.consent === "given").length;
  const avgStudies = (PARTICIPANTS.reduce((a, b) => a + b.studies, 0) / PARTICIPANTS.length).toFixed(1);

  const columns: Column<Participant>[] = [
    {
      key: "name",
      header: "Participant",
      cell: (row) => (
        <div className="flex items-center gap-2 min-w-0">
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarImage src={row.avatar} alt={row.name} />
            <AvatarFallback className="text-[10px]">{row.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="font-medium text-ink truncate">{row.name}</div>
            <div className="text-[10px] text-muted-foreground truncate">{row.email}</div>
          </div>
        </div>
      ),
      sortable: true,
      sortAccessor: (row) => row.name,
    },
    {
      key: "studies",
      header: "Studies",
      cell: (row) => (
        <span className="text-xs font-medium tabular-nums text-ink">{row.studies}</span>
      ),
      sortable: true,
      sortAccessor: (row) => row.studies,
      hideOnMobile: true,
    },
    {
      key: "lastParticipated",
      header: "Last participated",
      cell: (row) => <span className="text-xs text-muted-foreground">{row.lastParticipated}</span>,
      sortable: true,
      sortAccessor: (row) => row.lastParticipated,
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (row) => (
        <Badge variant="outline" className={cn("text-[10px] capitalize", STATUS_TINT[row.status])}>
          {row.status}
        </Badge>
      ),
      sortable: true,
      sortAccessor: (row) => row.status,
    },
    {
      key: "segments",
      header: "Segments",
      cell: (row) => (
        <div className="flex flex-wrap gap-1 max-w-[180px]">
          {row.segments.map((s) => (
            <span key={s} className="px-1.5 py-0.5 rounded text-[9px] bg-surface-2 text-muted-foreground">
              {s}
            </span>
          ))}
        </div>
      ),
      sortable: false,
      hideOnMobile: true,
    },
    {
      key: "consent",
      header: "Consent",
      cell: (row) => {
        const meta = CONSENT_META[row.consent];
        const Icon = meta.icon;
        return (
          <Badge variant="outline" className={cn("text-[10px]", meta.color)}>
            <Icon className="mr-1 h-2.5 w-2.5" /> {meta.label}
          </Badge>
        );
      },
      sortable: true,
      sortAccessor: (row) => row.consent,
    },
    {
      key: "actions",
      header: "",
      cell: () => (
        <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={(e) => { e.stopPropagation(); toast.info("Participant actions menu"); }}>
          <MoreHorizontal className="h-3.5 w-3.5" />
        </Button>
      ),
      width: "40px",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Participants"
        description="Research participants across all studies with consent and demographic info"
        breadcrumbs={[{ label: "Research", href: "/research" }, { label: "Participants" }]}
        icon={<Users className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">{PARTICIPANTS.length} participants</Badge>}
        actions={
          <Button size="sm" className="rounded-full" onClick={() => toast.success("Recruitment panel opened")}>
            <Users className="mr-2 h-3.5 w-3.5" /> Recruit
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Main column: filter + data table */}
          <div className="lg:col-span-3 space-y-4">
            {/* Stat row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <StatCard
                label="Total participants"
                value={PARTICIPANTS.length}
                icon={<Users className="h-4 w-4" />}
                accent="info"
                trend={{ value: 12, direction: "up", good: true }}
                sublabel="in directory"
              />
              <StatCard
                label="Active"
                value={active}
                icon={<ShieldCheck className="h-4 w-4" />}
                accent="success"
                sublabel={`of ${PARTICIPANTS.length}`}
              />
              <StatCard
                label="Consented"
                value={consented}
                icon={<ShieldCheck className="h-4 w-4" />}
                accent="success"
                sublabel={`${Math.round((consented / PARTICIPANTS.length) * 100)}% of pool`}
              />
              <StatCard
                label="Avg studies / participant"
                value={avgStudies}
                icon={<Search className="h-4 w-4" />}
                accent="default"
                sublabel="engagement"
              />
            </div>

            {/* Filter bar */}
            <Card className="rounded-2xl border-soft shadow-soft p-3">
              <FilterBar
                search={{ value: search, onChange: setSearch, placeholder: "Search name, email, location…" }}
                selects={[
                  {
                    label: "Status",
                    value: statusFilter,
                    onChange: setStatusFilter,
                    options: [
                      { label: "All statuses", value: "all" },
                      { label: "Active", value: "active" },
                      { label: "Inactive", value: "inactive" },
                      { label: "Withdrawn", value: "withdrawn" },
                    ],
                  },
                  {
                    label: "Consent",
                    value: consentFilter,
                    onChange: setConsentFilter,
                    options: [
                      { label: "All consent", value: "all" },
                      { label: "Consented", value: "given" },
                      { label: "Partial", value: "partial" },
                      { label: "Withdrawn", value: "withdrawn" },
                    ],
                  },
                ]}
                onClear={() => { setSearch(""); setStatusFilter("all"); setConsentFilter("all"); }}
              />
            </Card>

            {/* Data table */}
            {filtered.length === 0 ? (
              <EmptyState
                icon={Search}
                title="No participants match your filters"
                description="Try adjusting your search or clearing filters to see all participants."
                action={{ label: "Clear filters", onClick: () => { setSearch(""); setStatusFilter("all"); setConsentFilter("all"); } }}
              />
            ) : (
              <DataTable
                data={filtered}
                columns={columns}
                getRowId={(row) => row.id}
                pageSize={10}
                searchable={false}
                onRowClick={(row) => toast.info(`Opening participant profile: ${row.name}`)}
                emptyTitle="No participants found"
                emptyDescription="Try adjusting your search."
              />
            )}
          </div>

          {/* Side: demographic breakdown */}
          <div className="flex flex-col gap-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <Cake className="h-4 w-4 text-info" />
                <div className="text-sm font-semibold text-ink">Age distribution</div>
              </div>
              <div className="flex flex-col items-center">
                <DonutChart
                  data={AGE_DISTRIBUTION}
                  size={140}
                  strokeWidth={16}
                  centerValue="33"
                  centerLabel="median age"
                />
                <div className="mt-3 w-full space-y-1.5">
                  {AGE_DISTRIBUTION.map((d) => (
                    <div key={d.label} className="flex items-center justify-between text-[10px]">
                      <div className="flex items-center gap-1.5">
                        <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
                        <span className="text-muted-foreground">{d.label}</span>
                      </div>
                      <span className="font-semibold text-ink tabular-nums">{d.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <Monitor className="h-4 w-4 text-success" />
                <div className="text-sm font-semibold text-ink">Device split</div>
              </div>
              <div className="space-y-3">
                {DEVICE_SPLIT.map((d) => {
                  const Icon = DEVICE_ICON[d.label as keyof typeof DEVICE_ICON];
                  return (
                    <div key={d.label} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5">
                          <Icon className="h-3 w-3 text-muted-foreground" />
                          <span className="text-ink">{d.label}</span>
                        </div>
                        <span className="font-semibold tabular-nums text-ink">{d.value}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${d.value}%`, background: d.color }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <MapPin className="h-4 w-4 text-warning" />
                <div className="text-sm font-semibold text-ink">Location</div>
              </div>
              <div className="space-y-2">
                {LOCATIONS.map((l) => (
                  <div key={l.region} className="flex items-center justify-between gap-2">
                    <span className="text-xs text-ink truncate">{l.region}</span>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <div className="h-1.5 w-12 rounded-full bg-surface-2 overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${l.pct}%`, background: "var(--info)" }} />
                      </div>
                      <span className="text-[10px] text-muted-foreground tabular-nums w-4 text-right">{l.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
