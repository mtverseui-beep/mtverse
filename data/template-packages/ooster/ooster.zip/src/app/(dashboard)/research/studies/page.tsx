"use client";

import * as React from "react";
import Link from "next/link";
import {
  Microscope,
  Mic,
  ClipboardList,
  MousePointerClick,
  BookOpen,
  Layers,
  Network,
  Plus,
  Search,
  Users,
  Lightbulb,
  CalendarDays,
  ChevronRight,
  TrendingUp,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { EmptyState } from "@/components/common/empty-state";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RESEARCH_STUDIES, type ResearchStudy } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const TYPE_META: Record<
  ResearchStudy["type"],
  { label: string; icon: React.ElementType; tint: string }
> = {
  interview: { label: "Interview", icon: Mic, tint: "bg-info/10 text-info border-info/20" },
  survey: { label: "Survey", icon: ClipboardList, tint: "bg-success/10 text-success border-success/20" },
  "usability-test": { label: "Usability test", icon: MousePointerClick, tint: "bg-warning/10 text-warning border-warning/20" },
  "diary-study": { label: "Diary study", icon: BookOpen, tint: "bg-friction/10 text-friction border-friction/20" },
  "card-sort": { label: "Card sort", icon: Layers, tint: "bg-info/10 text-info border-info/20" },
  "tree-test": { label: "Tree test", icon: Network, tint: "bg-chart-5/10 text-chart-5 border-chart-5/20" },
};

const STATUS_TINT: Record<ResearchStudy["status"], string> = {
  planning: "bg-muted text-muted-foreground border-border",
  recruiting: "bg-warning/10 text-warning border-warning/20",
  "in-progress": "bg-info/10 text-info border-info/20",
  analyzing: "bg-warning/10 text-warning border-warning/20",
  completed: "bg-success/10 text-success border-success/20",
  archived: "bg-muted text-muted-foreground border-border",
};

export default function ResearchStudiesPage() {
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [typeFilter, setTypeFilter] = React.useState("all");
  const [statusFilter, setStatusFilter] = React.useState("all");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return RESEARCH_STUDIES.filter((s) => {
      if (search && !`${s.title} ${s.project} ${s.owner.name}`.toLowerCase().includes(search.toLowerCase())) return false;
      if (typeFilter !== "all" && s.type !== typeFilter) return false;
      if (statusFilter !== "all" && s.status !== statusFilter) return false;
      return true;
    });
  }, [search, typeFilter, statusFilter]);

  const totalParticipants = RESEARCH_STUDIES.reduce((a, b) => a + b.participants, 0);
  const totalFindings = RESEARCH_STUDIES.reduce((a, b) => a + b.findings, 0);
  const activeStudies = RESEARCH_STUDIES.filter((s) => ["recruiting", "in-progress", "analyzing"].includes(s.status)).length;

  return (
    <div>
      <PageHeader
        title="Research Studies"
        description="All research studies — moderated, unmoderated, longitudinal, and diary"
        breadcrumbs={[{ label: "Research", href: "/research" }, { label: "Studies" }]}
        icon={<Microscope className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">{RESEARCH_STUDIES.length} studies</Badge>}
        actions={
          <Button size="sm" className="rounded-full" onClick={() => toast.success("New study wizard opened")}>
            <Plus className="mr-2 h-3.5 w-3.5" /> New study
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Total studies"
              value={RESEARCH_STUDIES.length}
              icon={<Microscope className="h-4 w-4" />}
              accent="info"
              trend={{ value: 12, direction: "up", good: true }}
              sublabel="vs last quarter"
            />
            <StatCard
              label="Active studies"
              value={activeStudies}
              icon={<TrendingUp className="h-4 w-4" />}
              accent="warning"
              sublabel="recruiting or running"
            />
            <StatCard
              label="Total participants"
              value={totalParticipants.toLocaleString()}
              icon={<Users className="h-4 w-4" />}
              accent="success"
              trend={{ value: 18, direction: "up", good: true }}
              sublabel="across all studies"
            />
            <StatCard
              label="Findings synthesized"
              value={totalFindings}
              icon={<Lightbulb className="h-4 w-4" />}
              accent="default"
              sublabel="tagged in repository"
            />
          </div>

          {/* Filter bar */}
          <Card className="rounded-2xl border-soft shadow-soft p-3 mb-4">
            <FilterBar
              search={{ value: search, onChange: setSearch, placeholder: "Search studies, projects, owners…" }}
              selects={[
                {
                  label: "Method",
                  value: typeFilter,
                  onChange: setTypeFilter,
                  options: [
                    { label: "All methods", value: "all" },
                    { label: "Interview", value: "interview" },
                    { label: "Survey", value: "survey" },
                    { label: "Usability test", value: "usability-test" },
                    { label: "Diary study", value: "diary-study" },
                    { label: "Card sort", value: "card-sort" },
                    { label: "Tree test", value: "tree-test" },
                  ],
                },
                {
                  label: "Status",
                  value: statusFilter,
                  onChange: setStatusFilter,
                  options: [
                    { label: "All statuses", value: "all" },
                    { label: "Planning", value: "planning" },
                    { label: "Recruiting", value: "recruiting" },
                    { label: "In progress", value: "in-progress" },
                    { label: "Analyzing", value: "analyzing" },
                    { label: "Completed", value: "completed" },
                  ],
                },
              ]}
              onClear={() => { setSearch(""); setTypeFilter("all"); setStatusFilter("all"); }}
            />
          </Card>

          {/* Studies grid */}
          {filtered.length === 0 ? (
            <EmptyState
              icon={Search}
              title="No studies match your filters"
              description="Try adjusting your search or clearing filters to see all research studies."
              action={{ label: "Clear filters", onClick: () => { setSearch(""); setTypeFilter("all"); setStatusFilter("all"); } }}
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filtered.map((study) => {
                const meta = TYPE_META[study.type];
                const TypeIcon = meta.icon;
                const pct = study.targetParticipants > 0 ? Math.min(100, (study.participants / study.targetParticipants) * 100) : 0;
                return (
                  <Link key={study.id} href={`/research/${study.id}`} className="group">
                    <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card transition-all group-hover:-translate-y-0.5 flex flex-col">
                      {/* Header */}
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <Badge variant="outline" className={cn("text-[10px] capitalize", meta.tint)}>
                          <TypeIcon className="mr-1 h-3 w-3" /> {meta.label}
                        </Badge>
                        <Badge variant="outline" className={cn("text-[10px] capitalize", STATUS_TINT[study.status])}>
                          {study.status.replace("-", " ")}
                        </Badge>
                      </div>

                      {/* Title */}
                      <h3 className="text-sm font-semibold text-ink leading-snug mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                        {study.title}
                      </h3>
                      <div className="text-[11px] text-muted-foreground mb-2">{study.project}</div>

                      {/* Method */}
                      <div className="text-[10px] text-muted-foreground mb-3 line-clamp-1 italic">
                        {study.method}
                      </div>

                      {/* Participants progress */}
                      <div className="space-y-1 mb-3">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="text-muted-foreground">Participants</span>
                          <span className="font-semibold text-ink tabular-nums">
                            {study.participants.toLocaleString()}/{study.targetParticipants.toLocaleString()}
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all"
                            style={{
                              width: `${pct}%`,
                              background: pct === 100 ? "var(--success)" : pct > 0 ? "var(--info)" : "var(--muted-foreground)",
                            }}
                          />
                        </div>
                      </div>

                      {/* Tags */}
                      {study.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-3">
                          {study.tags.map((tag) => (
                            <span key={tag} className="px-1.5 py-0.5 rounded text-[9px] bg-surface-2 text-muted-foreground">
                              #{tag}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* Footer */}
                      <div className="mt-auto pt-3 border-t border-soft flex items-center justify-between">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Avatar className="h-5 w-5">
                            <AvatarImage src={study.owner.avatar} alt={study.owner.name} />
                            <AvatarFallback className="text-[9px]">{study.owner.name.split(" ").map((p) => p[0]).join("")}</AvatarFallback>
                          </Avatar>
                          <span className="text-[10px] text-muted-foreground truncate">{study.owner.name}</span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-muted-foreground flex-shrink-0">
                          <span className="inline-flex items-center gap-0.5">
                            <Lightbulb className="h-3 w-3" /> {study.findings}
                          </span>
                          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-ink group-hover:translate-x-0.5 transition-all" />
                        </div>
                      </div>

                      {/* Dates */}
                      <div className="mt-2 flex items-center gap-1 text-[9px] text-muted-foreground">
                        <CalendarDays className="h-2.5 w-2.5" />
                        <span>{study.startDate} → {study.endDate}</span>
                        <span className="ml-auto">{study.duration}</span>
                      </div>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}
