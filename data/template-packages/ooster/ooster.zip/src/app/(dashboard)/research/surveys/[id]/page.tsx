"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import {
  ClipboardList,
  Eye,
  Download,
  XCircle,
  Clock,
  CheckCircle2,
  ListChecks,
  Users,
  Star,
  AlignLeft,
  Trophy,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { BarChart } from "@/components/charts";
import { getSurvey } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ----------------------------------------------------------------------------
// Mock survey questions with response distributions
// ----------------------------------------------------------------------------

interface RatingQuestion {
  id: string;
  type: "rating";
  prompt: string;
  scale: { label: string; value: number; count: number }[];
}

interface ChoiceQuestion {
  id: string;
  type: "choice";
  prompt: string;
  options: { label: string; count: number }[];
}

interface TextQuestion {
  id: string;
  type: "text";
  prompt: string;
  responses: { quote: string; author: string }[];
}

interface NPSQuestion {
  id: string;
  type: "nps";
  prompt: string;
  promoters: number;
  passives: number;
  detractors: number;
}

interface RankingQuestion {
  id: string;
  type: "ranking";
  prompt: string;
  items: { label: string; avgRank: number }[];
}

type SurveyQuestion =
  | RatingQuestion
  | ChoiceQuestion
  | TextQuestion
  | NPSQuestion
  | RankingQuestion;

const QUESTIONS: SurveyQuestion[] = [
  {
    id: "q-1",
    type: "rating",
    prompt: "How easy was it to complete onboarding?",
    scale: [
      { label: "1", value: 1, count: 8 },
      { label: "2", value: 2, count: 14 },
      { label: "3", value: 3, count: 42 },
      { label: "4", value: 4, count: 198 },
      { label: "5", value: 5, count: 220 },
    ],
  },
  {
    id: "q-2",
    type: "choice",
    prompt: "Which step caused the most friction?",
    options: [
      { label: "Account creation", count: 38 },
      { label: "Email verification", count: 96 },
      { label: "Profile setup", count: 142 },
      { label: "First habit creation", count: 110 },
      { label: "Notification opt-in", count: 96 },
    ],
  },
  {
    id: "q-3",
    type: "text",
    prompt: "What's one thing you'd change about onboarding?",
    responses: [
      { quote: "The email verification took ages to arrive — I almost gave up.", author: "Anya P." },
      { quote: "Profile setup felt repetitive. Just ask for my name once.", author: "Marcus L." },
      { quote: "Loved the habit builder, but the notification prompt came too early.", author: "Priya S." },
    ],
  },
  {
    id: "q-4",
    type: "nps",
    prompt: "How likely are you to recommend Cadence to a friend?",
    promoters: 312,
    passives: 124,
    detractors: 46,
  },
  {
    id: "q-5",
    type: "ranking",
    prompt: "Rank these habits by importance to your routine (1 = most important)",
    items: [
      { label: "Morning hydration", avgRank: 1.8 },
      { label: "10-minute walk", avgRank: 2.4 },
      { label: "Journaling", avgRank: 3.1 },
      { label: "Reading", avgRank: 3.6 },
      { label: "Meditation", avgRank: 4.1 },
    ],
  },
];

// ----------------------------------------------------------------------------
// Mock individual responses
// ----------------------------------------------------------------------------

const RESPONSE_FEED = [
  {
    id: "r-1",
    respondent: "Anya Petrov",
    avatar: "https://i.pravatar.cc/80?img=5",
    timestamp: "2 min ago",
    rating: 4,
    nps: 9,
    key: "Would recommend but notification prompt felt too early.",
  },
  {
    id: "r-2",
    respondent: "Marcus Lin",
    avatar: "https://i.pravatar.cc/80?img=11",
    timestamp: "18 min ago",
    rating: 5,
    nps: 10,
    key: "Onboarding was smooth; profile setup needs consolidation.",
  },
  {
    id: "r-3",
    respondent: "Priya Shah",
    avatar: "https://i.pravatar.cc/80?img=20",
    timestamp: "1 hour ago",
    rating: 3,
    nps: 6,
    key: "Email verification delay nearly caused me to abandon.",
  },
];

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function SurveyDetailPage() {
  const params = useParams<{ id: string }>();
  const survey = getSurvey(params.id);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  if (!survey) {
    return (
      <EmptyState
        icon={ClipboardList}
        title="Survey not found"
        description="This survey may have been closed, deleted, or the link is incorrect."
        action={{ label: "Back to surveys", href: "/research/surveys" }}
      />
    );
  }

  const nps = QUESTIONS.find((q) => q.type === "nps") as NPSQuestion | undefined;
  const npsScore = nps
    ? Math.round(
        ((nps.promoters - nps.detractors) /
          (nps.promoters + nps.passives + nps.detractors)) *
          100
      )
    : 0;

  const target = 500;
  const progressPct = target
    ? Math.min(100, Math.round((survey.responses / target) * 100))
    : 0;

  const handleViewResponses = () =>
    toast.info("Opening responses feed", { description: "Full CSV export also available." });
  const handleExport = () =>
    toast.success("Export queued", { description: "CSV with all responses will be emailed." });
  const handleClose = () =>
    toast.warning("Close survey?", { description: "Confirm in the modal to stop collecting responses." });

  return (
    <div>
      <PageHeader
        title={survey.title}
        description={`${survey.questions} questions · ${survey.project}`}
        breadcrumbs={[
          { label: "Research", href: "/research" },
          { label: "Surveys", href: "/research/surveys" },
          { label: survey.id },
        ]}
        icon={<ClipboardList className="h-5 w-5" />}
        badge={<StatusBadge status={survey.status} />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleViewResponses}
            >
              <Eye className="mr-2 h-3.5 w-3.5" /> View responses
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleExport}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={handleClose}
              disabled={survey.status === "closed" || survey.status === "draft"}
            >
              <XCircle className="mr-2 h-3.5 w-3.5" /> Close
            </Button>
          </>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Responses"
          value={survey.responses.toLocaleString()}
          icon={<Users className="h-4 w-4" />}
          accent="info"
          sublabel={`of ${target} target`}
        />
        <StatCard
          label="Completion rate"
          value={`${survey.completionRate}%`}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          sublabel="started → finished"
        />
        <StatCard
          label="Avg time"
          value={survey.avgTime}
          icon={<Clock className="h-4 w-4" />}
          sublabel="per respondent"
        />
        <StatCard
          label="Questions"
          value={survey.questions}
          icon={<ListChecks className="h-4 w-4" />}
          accent="info"
          sublabel={`${QUESTIONS.length} shown in preview`}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: survey preview */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-sm font-semibold text-ink">Survey preview</div>
                <div className="text-[11px] text-muted-foreground">
                  Live questions with mock response distributions
                </div>
              </div>
              <Badge variant="secondary" className="text-[10px]">
                {QUESTIONS.length} questions
              </Badge>
            </div>

            <div className="space-y-4">
              {QUESTIONS.map((q, idx) => (
                <QuestionCard key={q.id} question={q} index={idx + 1} />
              ))}
            </div>
          </Card>
        </div>

        {/* Right: settings + responses feed */}
        <div className="space-y-4">
          {/* Settings card */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-ink">Survey settings</span>
              <StatusBadge status={survey.status} />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Opened</span>
                <span className="font-mono text-ink">{survey.createdAt}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Closes</span>
                <span className="font-mono text-ink">{survey.closesAt}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Target responses</span>
                <span className="font-medium text-ink tabular-nums">{target.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Owner</span>
                <div className="flex items-center gap-1.5">
                  <Avatar className="h-5 w-5 ring-1 ring-soft">
                    <AvatarImage src={survey.owner.avatar} alt={survey.owner.name} />
                    <AvatarFallback>{survey.owner.name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <span className="text-ink">{survey.owner.name}</span>
                </div>
              </div>
            </div>
            <div className="pt-2 border-t border-soft">
              <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1.5">
                <span>Progress to target</span>
                <span className="font-medium text-ink tabular-nums">{progressPct}%</span>
              </div>
              <Progress value={progressPct} className="h-1.5" />
            </div>
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-soft">
              <div className="rounded-xl bg-surface-2/50 p-2">
                <div className="text-[10px] text-muted-foreground">NPS score</div>
                <div className={cn(
                  "text-lg font-semibold tabular-nums",
                  npsScore >= 50 ? "text-success" : npsScore >= 0 ? "text-warning" : "text-friction"
                )}>
                  {npsScore > 0 ? "+" : ""}{npsScore}
                </div>
              </div>
              <div className="rounded-xl bg-surface-2/50 p-2">
                <div className="text-[10px] text-muted-foreground">Completion</div>
                <div className="text-lg font-semibold tabular-nums text-ink">
                  {survey.completionRate}%
                </div>
              </div>
            </div>
          </Card>

          {/* Responses feed */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-ink">Recent responses</span>
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={handleViewResponses}>
                View all
              </Button>
            </div>
            <div className="space-y-3">
              {RESPONSE_FEED.map((r) => (
                <div key={r.id} className="flex items-start gap-3">
                  <Avatar className="h-8 w-8 ring-1 ring-soft flex-shrink-0">
                    <AvatarImage src={r.avatar} alt={r.respondent} />
                    <AvatarFallback>{r.respondent.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-medium text-ink truncate">{r.respondent}</span>
                      <span className="text-[10px] text-muted-foreground flex-shrink-0">{r.timestamp}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <Badge variant="outline" className="text-[10px] border-info/20 bg-info/10 text-info">
                        ★ {r.rating}/5
                      </Badge>
                      <Badge variant="outline" className="text-[10px] border-success/20 bg-success/10 text-success">
                        NPS {r.nps}
                      </Badge>
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-1.5 line-clamp-2 leading-relaxed">
                      &ldquo;{r.key}&rdquo;
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------------
// Question card
// ----------------------------------------------------------------------------

function QuestionCard({
  question,
  index,
}: {
  question: SurveyQuestion;
  index: number;
}) {
  return (
    <div className="rounded-xl border border-soft p-3.5">
      <div className="flex items-start gap-2 mb-3">
        <Badge variant="secondary" className="text-[10px]">Q{index}</Badge>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium text-ink">{question.prompt}</div>
          <div className="text-[10px] text-muted-foreground mt-0.5 capitalize flex items-center gap-1">
            <QuestionTypeIcon type={question.type} />
            <span>{question.type === "nps" ? "NPS" : question.type === "choice" ? "Multiple choice" : question.type === "text" ? "Open text" : question.type === "ranking" ? "Ranking" : "Rating scale"}</span>
          </div>
        </div>
      </div>

      {question.type === "rating" && (
        <BarChart
          data={question.scale.map((s) => ({
            label: s.label,
            value: s.count,
            color: s.value >= 4 ? "var(--success)" : s.value === 3 ? "var(--warning)" : "var(--friction)",
          }))}
          height={120}
          showValues
        />
      )}

      {question.type === "choice" && (
        <div className="space-y-2">
          {question.options.map((o) => {
            const total = question.options.reduce((s, x) => s + x.count, 0) || 1;
            const pct = Math.round((o.count / total) * 100);
            return (
              <div key={o.label}>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                  <span className="text-ink">{o.label}</span>
                  <span className="font-medium text-ink tabular-nums">
                    {o.count} · {pct}%
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-info"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {question.type === "text" && (
        <div className="space-y-2">
          {question.responses.map((r, i) => (
            <div key={i} className="rounded-lg bg-surface-2/40 p-2.5">
              <p className="text-xs text-ink italic leading-relaxed">&ldquo;{r.quote}&rdquo;</p>
              <div className="text-[10px] text-muted-foreground mt-1">— {r.author}</div>
            </div>
          ))}
        </div>
      )}

      {question.type === "nps" && (
        <div className="grid grid-cols-3 gap-2">
          {([
            { label: "Promoters", value: question.promoters, color: "var(--success)" },
            { label: "Passives", value: question.passives, color: "var(--warning)" },
            { label: "Detractors", value: question.detractors, color: "var(--friction)" },
          ] as const).map((g) => (
            <div key={g.label} className="rounded-xl bg-surface-2/50 p-2.5">
              <div className="text-[10px] text-muted-foreground">{g.label}</div>
              <div className="text-lg font-semibold tabular-nums" style={{ color: g.color }}>
                {g.value}
              </div>
            </div>
          ))}
        </div>
      )}

      {question.type === "ranking" && (
        <div className="space-y-1.5">
          {[...question.items].sort((a, b) => a.avgRank - b.avgRank).map((it, i) => (
            <div key={it.label} className="flex items-center gap-2">
              <span className="flex h-5 w-5 items-center justify-center rounded-md bg-surface-2 text-[10px] font-medium text-muted-foreground tabular-nums flex-shrink-0">
                {i + 1}
              </span>
              <span className="text-xs text-ink flex-1">{it.label}</span>
              <span className="text-[10px] text-muted-foreground tabular-nums">
                avg {it.avgRank.toFixed(1)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function QuestionTypeIcon({ type }: { type: SurveyQuestion["type"] }) {
  const cls = "h-3 w-3";
  if (type === "rating") return <Star className={cls} />;
  if (type === "choice") return <ListChecks className={cls} />;
  if (type === "text") return <AlignLeft className={cls} />;
  if (type === "nps") return <Trophy className={cls} />;
  return <Trophy className={cls} />;
}
