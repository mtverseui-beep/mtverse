"use client";

import * as React from "react";
import Link from "next/link";
import {
  ClipboardList,
  Plus,
  Clock,
  CheckCircle2,
  Users,
  ChevronRight,
  ListChecks,
  Activity,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SURVEYS, type Survey } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ----------------------------------------------------------------------------
// Filters
// ----------------------------------------------------------------------------

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Draft", value: "draft" },
  { label: "Live", value: "live" },
  { label: "Closed", value: "closed" },
  { label: "Analyzing", value: "analyzing" },
];

const PROJECT_OPTIONS: FilterOption[] = [
  { label: "All projects", value: "all" },
  ...Array.from(new Set(SURVEYS.map((s) => s.project))).map((p) => ({
    label: p,
    value: p,
  })),
];

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function SurveysPage() {
  const [search, setSearch] = React.useState("");
  const [status, setStatus] = React.useState("all");
  const [project, setProject] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return SURVEYS.filter((s) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !s.title.toLowerCase().includes(q) &&
          !s.project.toLowerCase().includes(q) &&
          !s.owner.name.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (status !== "all" && s.status !== status) return false;
      if (project !== "all" && s.project !== project) return false;
      return true;
    });
  }, [search, status, project]);

  const clearFilters = () => {
    setSearch("");
    setStatus("all");
    setProject("all");
  };

  // KPIs
  const total = SURVEYS.length;
  const live = SURVEYS.filter((s) => s.status === "live").length;
  const totalResponses = SURVEYS.reduce((sum, s) => sum + s.responses, 0);
  const avgCompletion =
    SURVEYS.length > 0
      ? Math.round(
          SURVEYS.reduce((sum, s) => sum + s.completionRate, 0) / SURVEYS.length
        )
      : 0;

  return (
    <div>
      <PageHeader
        title="Surveys"
        description="In-product micro-surveys and longitudinal feedback"
        breadcrumbs={[{ label: "Research", href: "/research" }, { label: "Surveys" }]}
        icon={<ClipboardList className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {SURVEYS.length} surveys
          </Badge>
        }
        actions={
          <Button
            size="sm"
            className="rounded-full"
            onClick={() =>
              toast.success("New survey", {
                description: "Survey builder will open in a new pane.",
              })
            }
          >
            <Plus className="mr-2 h-3.5 w-3.5" /> New survey
          </Button>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total surveys"
          value={total}
          icon={<ClipboardList className="h-4 w-4" />}
          accent="info"
          sublabel="across projects"
        />
        <StatCard
          label="Live surveys"
          value={live}
          icon={<Activity className="h-4 w-4" />}
          accent="success"
          sublabel="collecting responses"
        />
        <StatCard
          label="Total responses"
          value={totalResponses.toLocaleString()}
          icon={<Users className="h-4 w-4" />}
          accent="info"
          sublabel="all-time"
        />
        <StatCard
          label="Avg completion"
          value={`${avgCompletion}%`}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          sublabel="across live + closed"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search survey, project, owner…",
          }}
          selects={[
            { label: "Status", value: status, onChange: setStatus, options: STATUS_OPTIONS },
            { label: "Project", value: project, onChange: setProject, options: PROJECT_OPTIONS },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={ClipboardList}
          title="No surveys match your filters"
          description="Try adjusting your search or filters, or create a new micro-survey to start collecting feedback."
          action={{ label: "Clear filters", onClick: clearFilters }}
          secondaryAction={{
            label: "New survey",
            onClick: () =>
              toast.success("New survey", {
                description: "Survey builder will open in a new pane.",
              }),
          }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((s) => (
            <SurveyCard key={s.id} survey={s} />
          ))}
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// Survey card
// ----------------------------------------------------------------------------

function SurveyCard({ survey }: { survey: Survey }) {
  // Estimate a target based on response volume — most surveys target 500 responses.
  const target = Math.max(survey.responses, survey.status === "draft" ? 500 : 500);
  const progressPct = target
    ? Math.min(100, Math.round((survey.responses / target) * 100))
    : 0;

  return (
    <Link href={`/research/surveys/${survey.id}`} className="group">
      <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-success/10 text-success">
              <ClipboardList className="h-3.5 w-3.5" />
            </div>
            <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
              {survey.questions} questions
            </span>
          </div>
          <StatusBadge status={survey.status} />
        </div>

        <div className="font-semibold text-sm text-ink group-hover:text-primary transition-colors line-clamp-2 mb-1">
          {survey.title}
        </div>
        <div className="text-[11px] text-muted-foreground mb-3">
          {survey.project}
        </div>

        {/* Response progress */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
            <span>Responses</span>
            <span className="font-medium text-ink tabular-nums">
              {survey.responses.toLocaleString()} / {target.toLocaleString()}
            </span>
          </div>
          <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
            <div
              className={cn(
                "h-full rounded-full transition-all",
                progressPct >= 100 ? "bg-success" : "bg-info"
              )}
              style={{
                width: `${Math.max(progressPct, survey.responses > 0 ? 4 : 0)}%`,
              }}
            />
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="rounded-xl bg-surface-2/50 p-2">
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground mb-0.5">
              <CheckCircle2 className="h-3 w-3" />
              Completion
            </div>
            <div className="text-sm font-semibold tabular-nums text-ink">
              {survey.completionRate}%
            </div>
          </div>
          <div className="rounded-xl bg-surface-2/50 p-2">
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground mb-0.5">
              <Clock className="h-3 w-3" />
              Avg time
            </div>
            <div className="text-sm font-semibold tabular-nums text-ink">
              {survey.avgTime}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-auto flex items-center justify-between pt-3 border-t border-soft">
          <div className="flex items-center gap-2 min-w-0">
            <Avatar className="h-6 w-6 ring-1 ring-soft flex-shrink-0">
              <AvatarImage src={survey.owner.avatar} alt={survey.owner.name} />
              <AvatarFallback>{survey.owner.name.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <ListChecks className="h-3 w-3" />
              <span className="truncate">{survey.owner.name}</span>
            </div>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink transition-colors flex-shrink-0" />
        </div>
      </Card>
    </Link>
  );
}
