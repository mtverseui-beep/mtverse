"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import {
  UserPlus,
  Mail,
  Shield,
  Check,
  X,
  Send,
  ArrowRight,
  Users,
  KeyRound,
  CreditCard,
  Database,
  Plug,
  FileText,
  Eye,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type RoleKey =
  | "Owner"
  | "Admin"
  | "Researcher"
  | "Designer"
  | "PM"
  | "Viewer";

interface PermissionMatrix {
  key: string;
  label: string;
  desc: string;
  roles: Record<RoleKey, boolean>;
}

const PERMISSIONS: PermissionMatrix[] = [
  {
    key: "create_projects",
    label: "Create projects",
    desc: "Spin up new UX workspaces",
    roles: { Owner: true, Admin: true, Researcher: true, Designer: true, PM: true, Viewer: false },
  },
  {
    key: "invite_members",
    label: "Invite members",
    desc: "Send workspace invitations",
    roles: { Owner: true, Admin: true, Researcher: false, Designer: false, PM: false, Viewer: false },
  },
  {
    key: "delete_data",
    label: "Delete data",
    desc: "Permanently remove resources",
    roles: { Owner: true, Admin: false, Researcher: false, Designer: false, PM: false, Viewer: false },
  },
  {
    key: "view_billing",
    label: "View billing",
    desc: "See invoices & payment methods",
    roles: { Owner: true, Admin: true, Researcher: false, Designer: false, PM: false, Viewer: false },
  },
  {
    key: "export_reports",
    label: "Export reports",
    desc: "Download PDF / CSV exports",
    roles: { Owner: true, Admin: true, Researcher: true, Designer: true, PM: true, Viewer: true },
  },
  {
    key: "manage_integrations",
    label: "Manage integrations",
    desc: "Connect / disconnect tools",
    roles: { Owner: true, Admin: true, Researcher: false, Designer: false, PM: false, Viewer: false },
  },
  {
    key: "view_insights",
    label: "View insights",
    desc: "Read findings & evidence",
    roles: { Owner: true, Admin: true, Researcher: true, Designer: true, PM: true, Viewer: true },
  },
  {
    key: "create_insights",
    label: "Create insights",
    desc: "Author new findings",
    roles: { Owner: true, Admin: true, Researcher: true, Designer: true, PM: false, Viewer: false },
  },
];

const ROLE_ICONS: Record<RoleKey, React.ReactNode> = {
  Owner: <Shield className="h-3.5 w-3.5" />,
  Admin: <KeyRound className="h-3.5 w-3.5" />,
  Researcher: <Users className="h-3.5 w-3.5" />,
  Designer: <FileText className="h-3.5 w-3.5" />,
  PM: <Users className="h-3.5 w-3.5" />,
  Viewer: <Eye className="h-3.5 w-3.5" />,
};

const ROLE_DESCRIPTIONS: Record<RoleKey, string> = {
  Owner: "Full control including billing, members, and data deletion. There must always be at least one Owner.",
  Admin: "Manage projects, members, and integrations. Cannot delete data or change billing.",
  Researcher: "Run studies, author insights, and export reports. Read-only on billing.",
  Designer: "Upload screens, contribute insights, and export reports. No member management.",
  PM: "Coordinate projects and review insights. Cannot author findings or manage members.",
  Viewer: "Read-only access to insights, reports, and dashboards. No exports.",
};

const ROLE_BADGE_CLASS: Record<string, string> = {
  Owner: "bg-primary/10 text-primary border-primary/20",
  Admin: "bg-info/15 text-info border-info/20",
  Researcher: "bg-success/15 text-success border-success/20",
  Designer: "bg-warning/15 text-warning border-warning/20",
  PM: "bg-friction/15 text-friction border-friction/20",
  Viewer: "bg-muted text-muted-foreground border-border",
};

export default function InvitePage() {
  const router = useRouter();
  const [loading, setLoading] = React.useState(true);
  const [email, setEmail] = React.useState("");
  const [role, setRole] = React.useState<RoleKey>("Researcher");
  const [message, setMessage] = React.useState(
    "Hi! I'd like to invite you to join our Ooster workspace so we can collaborate on UX research and analytics."
  );
  const [sending, setSending] = React.useState(false);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailValid) {
      toast.error("Invalid email", {
        description: "Please enter a valid email address.",
      });
      return;
    }
    setSending(true);
    setTimeout(() => {
      setSending(false);
      toast.success("Invitation sent", {
        description: `${email} invited as ${role}.`,
      });
      router.push("/teams");
    }, 600);
  };

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  return (
    <div>
      <PageHeader
        title="Invite Team Member"
        description="Send an invitation to join your Ooster workspace"
        icon={<UserPlus className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            4 of 8 seats used
          </Badge>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Form */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs">
                  Email address <span className="text-friction">*</span>
                </Label>
                <div className="relative">
                  <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="teammate@company.com"
                    className="pl-8"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                {email && !emailValid && (
                  <p className="text-[10px] text-friction">
                    Please enter a valid email address.
                  </p>
                )}
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs">
                  Role <span className="text-friction">*</span>
                </Label>
                <Select
                  value={role}
                  onValueChange={(v) => setRole(v as RoleKey)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {(Object.keys(ROLE_DESCRIPTIONS) as RoleKey[]).map((r) => (
                      <SelectItem key={r} value={r}>
                        <span className="flex items-center gap-2">
                          {ROLE_ICONS[r]}
                          {r}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="rounded-lg border border-soft p-2.5 bg-surface-2/40">
                  <div className="flex items-start gap-2">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[9px] font-medium border flex-shrink-0",
                        ROLE_BADGE_CLASS[role]
                      )}
                    >
                      {role}
                    </Badge>
                    <p className="text-[11px] text-muted-foreground leading-relaxed">
                      {ROLE_DESCRIPTIONS[role]}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="message" className="text-xs">
                  Personal message
                </Label>
                <Textarea
                  id="message"
                  placeholder="Add a personal note to your invitation…"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="min-h-[100px]"
                />
                <p className="text-[10px] text-muted-foreground">
                  Optional — included in the invitation email.
                </p>
              </div>

              <Separator />

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="text-[11px] text-muted-foreground">
                  Invitations expire after{" "}
                  <span className="text-ink font-medium">7 days</span> if not
                  accepted.
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="rounded-full"
                    onClick={() => router.push("/teams")}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    size="sm"
                    className="rounded-full"
                    disabled={!emailValid || sending}
                  >
                    {sending ? (
                      <>Sending…</>
                    ) : (
                      <>
                        <Send className="mr-2 h-3.5 w-3.5" /> Send invitation
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </form>
          </Card>

          {/* Permission summary for selected role */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <Shield className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-ink">
                    Permission summary
                  </h3>
                  <div className="text-[10px] text-muted-foreground">
                    What this {role} can do
                  </div>
                </div>
              </div>
              <Badge
                variant="outline"
                className={cn(
                  "text-[10px] font-medium border",
                  ROLE_BADGE_CLASS[role]
                )}
              >
                {role}
              </Badge>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PERMISSIONS.map((p) => {
                const allowed = p.roles[role];
                return (
                  <div
                    key={p.key}
                    className={cn(
                      "flex items-start gap-2 rounded-lg border p-2.5 transition-colors",
                      allowed
                        ? "border-success/20 bg-success/[0.04]"
                        : "border-soft bg-surface-2/40 opacity-60"
                    )}
                  >
                    <div
                      className={cn(
                        "flex h-5 w-5 items-center justify-center rounded-full flex-shrink-0 mt-0.5",
                        allowed
                          ? "bg-success/15 text-success"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      {allowed ? (
                        <Check className="h-3 w-3" />
                      ) : (
                        <X className="h-3 w-3" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-medium text-ink">
                        {p.label}
                      </div>
                      <div className="text-[10px] text-muted-foreground leading-snug">
                        {p.desc}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Side: roles comparison */}
        <div className="space-y-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Users className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Roles comparison</h3>
            </div>
            <div className="overflow-x-auto -mx-4 px-4">
              <table className="w-full text-[10px] min-w-[420px]">
                <thead>
                  <tr className="border-b border-soft">
                    <th className="text-left font-medium text-muted-foreground py-2 pr-2">
                      Permission
                    </th>
                    {(Object.keys(ROLE_DESCRIPTIONS) as RoleKey[]).map((r) => (
                      <th
                        key={r}
                        className={cn(
                          "text-center font-medium py-2 px-1",
                          role === r ? "text-primary" : "text-muted-foreground"
                        )}
                      >
                        {r}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {PERMISSIONS.map((p) => (
                    <tr
                      key={p.key}
                      className="border-b border-soft last:border-0"
                    >
                      <td className="py-2 pr-2 text-ink">{p.label}</td>
                      {(Object.keys(ROLE_DESCRIPTIONS) as RoleKey[]).map((r) => (
                        <td key={r} className="text-center py-2 px-1">
                          {p.roles[r] ? (
                            <Check className="h-3.5 w-3.5 text-success inline-block" />
                          ) : (
                            <X className="h-3.5 w-3.5 text-muted-foreground inline-block" />
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-[10px] text-muted-foreground mt-3 leading-relaxed">
              Owners can edit role permissions from workspace settings. Custom
              roles are available on Enterprise plans.
            </p>
          </Card>

          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-warning">
                <CreditCard className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Seat usage</h3>
            </div>
            <div className="text-xs text-muted-foreground mb-3">
              Inviting this member will use 1 of your remaining seats.
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-ink">Plan</span>
                <span className="font-medium text-ink">Team · 8 seats</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-ink">Used</span>
                <span className="font-medium text-ink">4 / 8</span>
              </div>
              <div className="h-2 rounded-full bg-surface-2 overflow-hidden">
                <div className="h-full rounded-full bg-success" style={{ width: "50%" }} />
              </div>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground pt-1">
                <span>4 remaining</span>
                <button
                  className="text-primary hover:underline inline-flex items-center gap-0.5"
                  onClick={() => toast.success("Opening billing portal")}
                >
                  Upgrade plan <ArrowRight className="h-2.5 w-2.5" />
                </button>
              </div>
            </div>
          </Card>

          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Plug className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Onboarding flow</h3>
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2">
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-success/15 text-success text-[10px] font-medium flex-shrink-0">
                  1
                </div>
                <div className="text-ink">
                  Invitation email sent to{" "}
                  <span className="font-medium">
                    {emailValid ? email : "teammate@company.com"}
                  </span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-surface-2 text-muted-foreground text-[10px] font-medium flex-shrink-0">
                  2
                </div>
                <div className="text-muted-foreground">
                  Recipient accepts invite & sets password
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-surface-2 text-muted-foreground text-[10px] font-medium flex-shrink-0">
                  3
                </div>
                <div className="text-muted-foreground">
                  Member joins workspace with {role} role
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="flex h-5 w-5 items-center justify-center rounded-full bg-surface-2 text-muted-foreground text-[10px] font-medium flex-shrink-0">
                  4
                </div>
                <div className="text-muted-foreground">
                  Suggested: assign to first project
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
