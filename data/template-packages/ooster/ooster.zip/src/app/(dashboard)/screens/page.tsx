"use client";

import * as React from "react";
import Link from "next/link";
import {
  Smartphone,
  Plus,
  Download,
  ChevronRight,
  Clock,
  AlertTriangle,
  TrendingUp,
  Layers,
  Users,
  Flame,
  LayoutDashboard,
  Monitor,
  Tablet,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { HEATMAPS, PROJECTS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ScreenRow {
  id: string;
  name: string;
  project: string;
  projectId: string;
  uxScore: number;
  sessions: number;
  avgTime: string;
  topIssues: number;
  device: "mobile" | "desktop" | "tablet";
  gradient: string;
  icon: React.ElementType;
}

const SCREEN_GRADIENTS = [
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-1) 35%, var(--card)), color-mix(in oklch, var(--chart-4) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-2) 35%, var(--card)), color-mix(in oklch, var(--chart-3) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-4) 35%, var(--card)), color-mix(in oklch, var(--chart-5) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-5) 35%, var(--card)), color-mix(in oklch, var(--chart-6) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-3) 35%, var(--card)), color-mix(in oklch, var(--chart-1) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-6) 35%, var(--card)), color-mix(in oklch, var(--chart-2) 18%, var(--card)))",
];

const SCREEN_ICONS = [LayoutDashboard, Smartphone, Monitor, Tablet, Flame, LayoutDashboard];

// Build screens from HEATMAPS + extra mock screens
const SCREENS: ScreenRow[] = [
  ...HEATMAPS.map((h, i) => ({
    id: h.id,
    name: h.screen,
    project: h.projectName,
    projectId: h.projectId,
    uxScore: 62 + ((i * 7) % 32),
    sessions: h.sessions,
    avgTime: h.avgTime,
    topIssues: h.coldZones + h.dropOffAreas,
    device: h.device,
    gradient: SCREEN_GRADIENTS[i % SCREEN_GRADIENTS.length],
    icon: SCREEN_ICONS[i % SCREEN_ICONS.length],
  })),
];

const PROJECT_FILTERS = [
  { label: "All projects", value: "all" },
  ...PROJECTS.map((p) => ({ label: p.name, value: p.id })),
];

const DEVICE_FILTERS = [
  { label: "All devices", value: "all" },
  { label: "Mobile", value: "mobile" },
  { label: "Desktop", value: "desktop" },
  { label: "Tablet", value: "tablet" },
];

const SORT_FILTERS = [
  { label: "UX score", value: "ux" },
  { label: "Sessions", value: "sessions" },
  { label: "Friction", value: "friction" },
];

const deviceIcon: Record<string, React.ElementType> = {
  mobile: Smartphone,
  desktop: Monitor,
  tablet: Tablet,
};

function uxScoreBadge(score: number) {
  if (score >= 85) return { label: "Excellent", cls: "bg-success/15 text-success border-success/20" };
  if (score >= 70) return { label: "Good", cls: "bg-info/15 text-info border-info/20" };
  if (score >= 55) return { label: "Fair", cls: "bg-warning/15 text-warning border-warning/20" };
  return { label: "Poor", cls: "bg-friction/15 text-friction border-friction/20" };
}

export default function ScreensPage() {
  const [search, setSearch] = React.useState("");
  const [project, setProject] = React.useState("all");
  const [device, setDevice] = React.useState("all");
  const [sort, setSort] = React.useState("ux");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    const arr = SCREENS.filter((s) => {
      if (search && !s.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (project !== "all" && s.projectId !== project) return false;
      if (device !== "all" && s.device !== device) return false;
      return true;
    });
    if (sort === "ux") return arr.sort((a, b) => b.uxScore - a.uxScore);
    if (sort === "sessions") return arr.sort((a, b) => b.sessions - a.sessions);
    if (sort === "friction") return arr.sort((a, b) => b.topIssues - a.topIssues);
    return arr;
  }, [search, project, device, sort]);

  const clearFilters = () => {
    setSearch("");
    setProject("all");
    setDevice("all");
    setSort("ux");
  };

  const totalScreens = SCREENS.length;
  const avgUx = Math.round(SCREENS.reduce((s, x) => s + x.uxScore, 0) / SCREENS.length);
  const totalSessions = SCREENS.reduce((s, x) => s + x.sessions, 0);
  const totalIssues = SCREENS.reduce((s, x) => s + x.topIssues, 0);

  return (
    <div>
      <PageHeader
        title="Screen Analysis"
        description="Individual screen performance, friction, and attention metrics"
        icon={<Smartphone className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {SCREENS.length} screens analyzed
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Screen analysis exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Connect a new screen to analyze")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> Add screen
            </Button>
          </>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Screens analyzed"
          value={totalScreens}
          icon={<Layers className="h-4 w-4" />}
          accent="info"
          sublabel="across all projects"
        />
        <StatCard
          label="Avg UX score"
          value={avgUx}
          unit="/100"
          icon={<TrendingUp className="h-4 w-4" />}
          accent={avgUx >= 70 ? "success" : "warning"}
          trend={{ value: 2.8, direction: "up", good: true }}
          sublabel="vs last sprint"
        />
        <StatCard
          label="Total sessions"
          value={totalSessions.toLocaleString()}
          icon={<Users className="h-4 w-4" />}
          trend={{ value: 6.4, direction: "up", good: true }}
          sublabel="last 30 days"
        />
        <StatCard
          label="Open issues"
          value={totalIssues}
          icon={<AlertTriangle className="h-4 w-4" />}
          accent="friction"
          sublabel="across all screens"
        />
      </div>

      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search screen name…",
          }}
          selects={[
            {
              label: "Project",
              value: project,
              onChange: setProject,
              options: PROJECT_FILTERS,
            },
            {
              label: "Device",
              value: device,
              onChange: setDevice,
              options: DEVICE_FILTERS,
            },
            {
              label: "Sort",
              value: sort,
              onChange: setSort,
              options: SORT_FILTERS,
            },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Smartphone}
          title="No screens match your filters"
          description="Try adjusting search or filters, or connect a new screen to start collecting UX data."
          action={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((s) => {
            const DevIcon = deviceIcon[s.device];
            const Icon = s.icon;
            const scoreBadge = uxScoreBadge(s.uxScore);
            return (
              <Link key={s.id} href={`/screens/${s.id}`} className="group">
                <Card className="rounded-2xl border-soft shadow-soft overflow-hidden hover:shadow-card hover:border-primary/30 transition-all flex flex-col h-full">
                  {/* 3:4 mock screen preview */}
                  <div
                    className="relative aspect-[3/4] flex items-center justify-center overflow-hidden"
                    style={{ background: s.gradient }}
                  >
                    {/* Mock browser chrome */}
                    <div className="absolute top-0 left-0 right-0 h-5 bg-card/40 backdrop-blur-sm border-b border-soft flex items-center px-2 gap-1 z-10">
                      <span className="h-1.5 w-1.5 rounded-full bg-friction/60" />
                      <span className="h-1.5 w-1.5 rounded-full bg-warning/60" />
                      <span className="h-1.5 w-1.5 rounded-full bg-success/60" />
                    </div>
                    {/* Faux content */}
                    <div className="absolute inset-0 pt-8 px-4">
                      <div className="h-2 w-2/3 rounded-full bg-card/60 mb-2" />
                      <div className="h-2 w-1/2 rounded-full bg-card/40 mb-4" />
                      <div className="h-12 w-full rounded-lg bg-card/30 mb-3" />
                      <div className="h-2 w-3/4 rounded-full bg-card/30 mb-1.5" />
                      <div className="h-2 w-1/2 rounded-full bg-card/20 mb-3" />
                      <div className="h-8 w-2/3 rounded-full bg-card/40" />
                    </div>
                    {/* Center icon overlay */}
                    <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-2xl bg-card/70 backdrop-blur-sm shadow-soft">
                      <Icon className="h-5 w-5 text-ink" />
                    </div>
                    {/* UX score badge */}
                    <div className="absolute top-7 right-2 z-10">
                      <Badge
                        variant="outline"
                        className={cn("text-[10px] font-semibold", scoreBadge.cls)}
                      >
                        UX {s.uxScore}
                      </Badge>
                    </div>
                    {/* Device label */}
                    <div className="absolute bottom-2 left-2 z-10">
                      <Badge variant="secondary" className="text-[9px] capitalize gap-1">
                        <DevIcon className="h-3 w-3" />
                        {s.device}
                      </Badge>
                    </div>
                  </div>

                  {/* Body */}
                  <div className="p-4 flex flex-col flex-1">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="text-sm font-semibold text-ink group-hover:text-primary transition-colors line-clamp-1">
                        {s.name}
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
                    </div>
                    <div className="text-[10px] text-muted-foreground mb-3">
                      {s.project}
                    </div>

                    {/* Stats strip */}
                    <div className="grid grid-cols-3 gap-2 pt-3 border-t border-soft mt-auto">
                      <div>
                        <div className="flex items-center gap-1 text-[9px] text-muted-foreground">
                          <Users className="h-2.5 w-2.5" />
                          Sessions
                        </div>
                        <div className="text-xs font-semibold text-ink">
                          {s.sessions.toLocaleString()}
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-[9px] text-muted-foreground">
                          <Clock className="h-2.5 w-2.5" />
                          Avg time
                        </div>
                        <div className="text-xs font-semibold text-ink">
                          {s.avgTime}
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-[9px] text-muted-foreground">
                          <AlertTriangle className="h-2.5 w-2.5" />
                          Issues
                        </div>
                        <div
                          className={cn(
                            "text-xs font-semibold",
                            s.topIssues > 4 ? "text-friction" : "text-warning"
                          )}
                        >
                          {s.topIssues}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
