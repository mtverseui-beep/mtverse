"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Smartphone,
  Share2,
  Download,
  PlayCircle,
  ChevronRight,
  AlertTriangle,
  Clock,
  Eye,
  TrendingUp,
  Target,
  Lightbulb,
  Accessibility,
  Zap,
  MousePointerClick,
  CheckCircle2,
  Flame,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { SeverityBadge, StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useModals } from "@/hooks/use-modals";
import { HEATMAPS, ISSUES, getHeatmap } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ScreenDetail {
  id: string;
  name: string;
  project: string;
  projectId: string;
  device: "desktop" | "mobile" | "tablet";
  type: string;
  sessions: number;
  avgTime: string;
  uxScore: number;
  gradient: string;
  topHotspot: { x: number; y: number; intensity: number; label: string };
  coldZones: number;
  dropOffAreas: number;
  updatedAt: string;
}

const SCREEN_GRADIENTS = [
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-1) 30%, var(--card)), color-mix(in oklch, var(--chart-4) 15%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-2) 30%, var(--card)), color-mix(in oklch, var(--chart-3) 15%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-4) 30%, var(--card)), color-mix(in oklch, var(--chart-5) 15%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-5) 30%, var(--card)), color-mix(in oklch, var(--chart-6) 15%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-3) 30%, var(--card)), color-mix(in oklch, var(--chart-1) 15%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-6) 30%, var(--card)), color-mix(in oklch, var(--chart-2) 15%, var(--card)))",
];

function getScreenDetail(id: string): ScreenDetail | undefined {
  const heatmap = getHeatmap(id);
  if (!heatmap) return undefined;
  const idx = HEATMAPS.findIndex((h) => h.id === id);
  return {
    id: heatmap.id,
    name: heatmap.screen,
    project: heatmap.projectName,
    projectId: heatmap.projectId,
    device: heatmap.device,
    type: heatmap.type,
    sessions: heatmap.sessions,
    avgTime: heatmap.avgTime,
    uxScore: 62 + ((idx * 7) % 32),
    gradient: SCREEN_GRADIENTS[idx % SCREEN_GRADIENTS.length],
    topHotspot: heatmap.topHotspot,
    coldZones: heatmap.coldZones,
    dropOffAreas: heatmap.dropOffAreas,
    updatedAt: heatmap.updatedAt,
  };
}

interface Recommendation {
  title: string;
  detail: string;
  priority: "high" | "medium" | "low";
}

const RECS_BY_SCREEN: Record<string, Recommendation[]> = {
  "h-001": [
    { title: "Increase CTA tap target", detail: "Upload button is below the 44px iOS minimum tap target. Increase to 48×48.", priority: "high" },
    { title: "Add inline validation", detail: "Form fields fail silently. Show inline errors on blur for faster recovery.", priority: "medium" },
    { title: "Add progress indicator", detail: "Step 3 of 3 should show progress dots to set expectations.", priority: "low" },
  ],
  "h-002": [
    { title: "Auto-focus first field", detail: "CVV field requires manual focus on desktop. Auto-focus after card number.", priority: "high" },
    { title: "Reduce form length", detail: "5 fields on payment — combine ZIP + city into one autocomplete.", priority: "medium" },
    { title: "Show error inline", detail: "Generic 'invalid card' errors frustrate users. Be specific about which field failed.", priority: "medium" },
  ],
};

const TAB_METRICS = {
  performance: [
    { label: "Load time", value: "1.8s", trend: -12, status: "good" },
    { label: "First contentful paint", value: "0.6s", trend: -8, status: "good" },
    { label: "Time to interactive", value: "2.1s", trend: -5, status: "good" },
    { label: "Cumulative layout shift", value: "0.04", trend: -2, status: "good" },
    { label: "Total blocking time", value: "180ms", trend: 14, status: "warning" },
  ],
  friction: [
    { label: "Rage clicks", value: "23", trend: 8, status: "bad" },
    { label: "Dead clicks", value: "11", trend: -3, status: "good" },
    { label: "Form abandonment", value: "14%", trend: 4, status: "warning" },
    { label: "Back-navigation", value: "9%", trend: -2, status: "good" },
    { label: "Avg error recovery", value: "8.2s", trend: -18, status: "good" },
  ],
  attention: [
    { label: "Above-fold dwell", value: "4.2s", trend: 12, status: "good" },
    { label: "Scroll depth (median)", value: "68%", trend: 5, status: "good" },
    { label: "Bottom-of-fold reach", value: "32%", trend: -8, status: "warning" },
    { label: "Hotspot concentration", value: "92%", trend: 3, status: "good" },
    { label: "Cold zone coverage", value: "18%", trend: -4, status: "good" },
  ],
  accessibility: [
    { label: "WCAG AA contrast", value: "Pass", trend: 0, status: "good" },
    { label: "Keyboard navigation", value: "Partial", trend: 0, status: "warning" },
    { label: "Screen reader labels", value: "94%", trend: 6, status: "good" },
    { label: "Focus indicator visible", value: "Yes", trend: 0, status: "good" },
    { label: "Tap target size", value: "Below min", trend: 0, status: "bad" },
  ],
} as const;

function trendIcon(trend: number) {
  if (trend === 0) return <span className="text-muted-foreground text-[10px]">—</span>;
  if (trend > 0) return <span className="text-success text-[10px] font-medium">▲ {trend}%</span>;
  return <span className="text-friction text-[10px] font-medium">▼ {Math.abs(trend)}%</span>;
}

function statusColor(status: string) {
  if (status === "good") return "text-success";
  if (status === "warning") return "text-warning";
  return "text-friction";
}

export default function ScreenDetailPage() {
  const params = useParams<{ id: string }>();
  const screen = getScreenDetail(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  if (!screen) {
    return (
      <EmptyState
        icon={Smartphone}
        title="Screen not found"
        description="This screen may have been archived or never existed."
        action={{ label: "Back to screens", href: "/screens" }}
      />
    );
  }

  const screenIssues = ISSUES.filter((i) => i.screen === screen.name || i.project === screen.project).slice(0, 5);
  const recommendations = RECS_BY_SCREEN[screen.id] ?? RECS_BY_SCREEN["h-001"];

  const handleShare = () => openShare(`/screens/${screen.id}`, screen.name);
  const handleExport = () => toast.success("Screen report exported as PDF");

  return (
    <div>
      <PageHeader
        title={screen.name}
        description={`${screen.project} · ${screen.device} · last analyzed ${screen.updatedAt}`}
        breadcrumbs={[
          { label: "Screens", href: "/screens" },
          { label: `#${screen.id}` },
        ]}
        icon={<Smartphone className="h-5 w-5" />}
        badge={
          <Badge
            variant="outline"
            className={cn(
              "text-[10px] font-semibold",
              screen.uxScore >= 85
                ? "bg-success/15 text-success border-success/20"
                : screen.uxScore >= 70
                ? "bg-info/15 text-info border-info/20"
                : screen.uxScore >= 55
                ? "bg-warning/15 text-warning border-warning/20"
                : "bg-friction/15 text-friction border-friction/20"
            )}
          >
            UX {screen.uxScore}
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Opening heatmap viewer")}
            >
              <Flame className="mr-2 h-3.5 w-3.5" /> View heatmap
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Opening session replays for this screen")}
            >
              <PlayCircle className="mr-2 h-3.5 w-3.5" /> View sessions
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleExport}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={handleShare}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column — preview + metric tabs */}
        <div className="lg:col-span-2 space-y-4">
          {/* Large screen preview with mock browser chrome */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <Smartphone className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">
                  Screen preview
                </h3>
              </div>
              <Badge variant="secondary" className="text-[10px] capitalize">
                {screen.type} · {screen.device}
              </Badge>
            </div>
            {/* 16:9 preview with browser chrome */}
            <div
              className="relative aspect-[16/9] rounded-xl overflow-hidden border border-soft"
              style={{ background: screen.gradient }}
            >
              {/* Browser chrome */}
              <div className="absolute top-0 left-0 right-0 h-7 bg-card/60 backdrop-blur-sm border-b border-soft flex items-center px-3 gap-2 z-20">
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-friction/60" />
                  <span className="h-2 w-2 rounded-full bg-warning/60" />
                  <span className="h-2 w-2 rounded-full bg-success/60" />
                </div>
                <div className="flex-1 mx-3 h-4 rounded-md bg-card/60 flex items-center px-2">
                  <span className="text-[9px] text-muted-foreground truncate">
                    app.ooster.dev/{screen.project.toLowerCase().replace(/\s/g, "-")}/{screen.id}
                  </span>
                </div>
              </div>
              {/* Faux content */}
              <div className="absolute inset-0 pt-10 px-6 pb-4">
                <div className="grid grid-cols-3 gap-3 h-full">
                  <div className="col-span-2 space-y-2">
                    <div className="h-3 w-1/3 rounded-full bg-card/50 mb-1" />
                    <div className="h-2 w-2/3 rounded-full bg-card/30 mb-3" />
                    <div className="h-16 w-full rounded-lg bg-card/30 mb-2" />
                    <div className="h-2 w-3/4 rounded-full bg-card/30 mb-1" />
                    <div className="h-2 w-1/2 rounded-full bg-card/20 mb-3" />
                    <div className="h-8 w-2/3 rounded-full bg-card/40" />
                  </div>
                  <div className="space-y-2">
                    <div className="h-3 w-1/2 rounded-full bg-card/40 mb-1" />
                    <div className="h-2 w-3/4 rounded-full bg-card/30 mb-2" />
                    <div className="h-10 w-full rounded-lg bg-card/30 mb-1" />
                    <div className="h-10 w-full rounded-lg bg-card/20" />
                  </div>
                </div>
              </div>
              {/* Top hotspot indicator */}
              <div
                className="absolute pointer-events-none"
                style={{
                  left: `${screen.topHotspot.x}%`,
                  top: `${screen.topHotspot.y + 8}%`,
                  transform: "translate(-50%, -50%)",
                  width: "120px",
                  height: "120px",
                  borderRadius: "9999px",
                  background: `radial-gradient(circle, color-mix(in oklch, var(--friction) ${screen.topHotspot.intensity}%, transparent), transparent)`,
                  filter: "blur(10px)",
                  mixBlendMode: "multiply",
                }}
              />
              {/* Top hotspot label */}
              <div
                className="absolute z-10 flex items-center gap-1.5 rounded-full bg-card/90 backdrop-blur-sm border border-soft px-2 py-1 shadow-soft"
                style={{
                  left: `${screen.topHotspot.x}%`,
                  top: `${screen.topHotspot.y + 8}%`,
                  transform: "translate(-50%, -120%)",
                }}
              >
                <span className="h-1.5 w-1.5 rounded-full bg-friction" />
                <span className="text-[9px] font-medium text-ink">
                  {screen.topHotspot.label} · {screen.topHotspot.intensity}%
                </span>
              </div>
            </div>
          </Card>

          {/* Metric tabs */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <TrendingUp className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                Detailed metrics
              </h3>
            </div>
            <Tabs defaultValue="performance">
              <TabsList className="w-full justify-start h-auto flex-wrap">
                <TabsTrigger value="performance" className="text-xs gap-1">
                  <Zap className="h-3 w-3" /> Performance
                </TabsTrigger>
                <TabsTrigger value="friction" className="text-xs gap-1">
                  <AlertTriangle className="h-3 w-3" /> Friction
                </TabsTrigger>
                <TabsTrigger value="attention" className="text-xs gap-1">
                  <Eye className="h-3 w-3" /> Attention
                </TabsTrigger>
                <TabsTrigger value="accessibility" className="text-xs gap-1">
                  <Accessibility className="h-3 w-3" /> Accessibility
                </TabsTrigger>
              </TabsList>

              {Object.entries(TAB_METRICS).map(([key, metrics]) => (
                <TabsContent key={key} value={key} className="mt-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {metrics.map((m) => (
                      <div
                        key={m.label}
                        className="flex items-center justify-between rounded-xl border border-soft p-3"
                      >
                        <div className="min-w-0">
                          <div className="text-[10px] text-muted-foreground">
                            {m.label}
                          </div>
                          <div
                            className={cn(
                              "text-sm font-semibold",
                              statusColor(m.status)
                            )}
                          >
                            {m.value}
                          </div>
                        </div>
                        <div className="flex-shrink-0">
                          {trendIcon(m.trend)}
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </Card>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Screen meta */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Smartphone className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Screen meta</h3>
            </div>
            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Project</span>
                <span className="text-ink font-medium">{screen.project}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Device</span>
                <Badge variant="outline" className="text-[10px] capitalize">{screen.device}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Heatmap type</span>
                <Badge variant="outline" className="text-[10px] capitalize">{screen.type}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Sessions</span>
                <span className="text-ink font-medium">{screen.sessions.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Avg time on screen</span>
                <span className="text-ink font-medium">{screen.avgTime}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Last analyzed</span>
                <span className="text-ink font-medium">{screen.updatedAt}</span>
              </div>
            </div>
          </Card>

          {/* KPIs */}
          <div className="grid grid-cols-2 gap-3">
            <StatCard
              label="UX score"
              value={screen.uxScore}
              unit="/100"
              icon={<TrendingUp className="h-4 w-4" />}
              accent={screen.uxScore >= 70 ? "success" : "warning"}
            />
            <StatCard
              label="Avg time"
              value={screen.avgTime}
              icon={<Clock className="h-4 w-4" />}
              accent="info"
            />
            <StatCard
              label="Top hotspot"
              value={`${screen.topHotspot.intensity}%`}
              icon={<MousePointerClick className="h-4 w-4" />}
              accent="friction"
              sublabel={screen.topHotspot.label}
            />
            <StatCard
              label="Cold zones"
              value={screen.coldZones}
              icon={<Eye className="h-4 w-4" />}
              accent="warning"
              sublabel={`${screen.dropOffAreas} drop areas`}
            />
          </div>

          {/* Top issues */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-friction">
                <AlertTriangle className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Top issues</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {screenIssues.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {screenIssues.length === 0 ? (
                <div className="text-[11px] text-muted-foreground py-3 text-center">
                  No issues logged for this screen yet.
                </div>
              ) : (
                screenIssues.map((issue) => (
                  <Link
                    key={issue.id}
                    href={`/insights`}
                    className="block rounded-xl border border-soft p-2.5 hover:bg-accent/30 transition-colors group"
                  >
                    <div className="flex items-start gap-2 mb-1">
                      <SeverityBadge severity={issue.severity} />
                      <span className="text-[9px] text-muted-foreground ml-auto">
                        {issue.project}
                      </span>
                    </div>
                    <div className="text-xs font-medium text-ink group-hover:text-primary transition-colors line-clamp-2">
                      {issue.title}
                    </div>
                    <div className="flex items-center gap-2 mt-1.5 text-[9px] text-muted-foreground">
                      <span>{issue.type}</span>
                      <span>·</span>
                      <StatusBadge status={issue.status} />
                    </div>
                  </Link>
                ))
              )}
            </div>
          </Card>

          {/* Top hotspots mini list */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-friction">
                <Flame className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Top hotspots</h3>
            </div>
            <div className="space-y-2">
              {[
                { label: screen.topHotspot.label, intensity: screen.topHotspot.intensity, x: screen.topHotspot.x, y: screen.topHotspot.y },
                { label: "Submit button", intensity: 78, x: 48, y: 72 },
                { label: "Skip link", intensity: 54, x: 82, y: 14 },
              ].map((h, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 rounded-lg border border-soft p-2"
                >
                  <div className="flex h-7 w-7 items-center justify-center rounded-md bg-friction/10 text-friction flex-shrink-0">
                    <span className="text-[10px] font-semibold">{i + 1}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink truncate">
                      {h.label}
                    </div>
                    <div className="text-[9px] text-muted-foreground">
                      ({h.x}%, {h.y}%)
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-friction flex-shrink-0">
                    {h.intensity}%
                  </span>
                </div>
              ))}
            </div>
          </Card>

          {/* Recommendations */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Target className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Recommendations</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {recommendations.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {recommendations.map((r, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-soft p-2.5"
                >
                  <div className="flex items-start gap-2 mb-1">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[9px] capitalize flex-shrink-0",
                        r.priority === "high"
                          ? "bg-friction/15 text-friction border-friction/20"
                          : r.priority === "medium"
                          ? "bg-warning/15 text-warning border-warning/20"
                          : "bg-info/15 text-info border-info/20"
                      )}
                    >
                      {r.priority}
                    </Badge>
                    <span className="text-xs font-medium text-ink flex-1">
                      {r.title}
                    </span>
                  </div>
                  <div className="text-[10px] text-muted-foreground leading-relaxed ml-1">
                    {r.detail}
                  </div>
                </div>
              ))}
            </div>
            <Button
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Issues created from recommendations")}
            >
              <Sparkles className="mr-2 h-3.5 w-3.5" /> Create issues
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
