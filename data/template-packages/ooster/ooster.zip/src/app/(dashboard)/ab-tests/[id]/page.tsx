"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  GitCompareArrows,
  Share2,
  Pause,
  Pencil,
  Trophy,
  Users,
  TrendingUp,
  TrendingDown,
  Calendar,
  Activity,
  Calculator,
  Target,
  Sparkles,
  ChevronRight,
  Lightbulb,
  Equal,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { LineChart } from "@/components/charts";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useModals } from "@/hooks/use-modals";
import { getExperiment } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// 14-day daily progress: conversion-rate per day, control vs variant
const TIMELINE = [
  { label: "D1", values: [{ label: "Control", value: 61 }, { label: "Variant", value: 63 }] },
  { label: "D2", values: [{ label: "Control", value: 60 }, { label: "Variant", value: 65 }] },
  { label: "D3", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 67 }] },
  { label: "D4", values: [{ label: "Control", value: 61 }, { label: "Variant", value: 69 }] },
  { label: "D5", values: [{ label: "Control", value: 63 }, { label: "Variant", value: 71 }] },
  { label: "D6", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 73 }] },
  { label: "D7", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 75 }] },
  { label: "D8", values: [{ label: "Control", value: 61 }, { label: "Variant", value: 76 }] },
  { label: "D9", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 78 }] },
  { label: "D10", values: [{ label: "Control", value: 63 }, { label: "Variant", value: 79 }] },
  { label: "D11", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 80 }] },
  { label: "D12", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 80 }] },
  { label: "D13", values: [{ label: "Control", value: 61 }, { label: "Variant", value: 81 }] },
  { label: "D14", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 81 }] },
];

export default function AbTestDetailPage() {
  const params = useParams<{ id: string }>();
  const test = getExperiment(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  // Significance calculator inputs (mock local state)
  const [sampleSize, setSampleSize] = React.useState("8400");
  const [baseline, setBaseline] = React.useState("62");
  const [mde, setMde] = React.useState("5");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  if (!test) {
    return (
      <EmptyState
        icon={GitCompareArrows}
        title="A/B test not found"
        description="This test may have been archived or never existed."
        action={{ label: "Back to A/B tests", href: "/ab-tests" }}
      />
    );
  }

  const control = test.variants[0];
  const variant = test.variants[1] ?? test.variants[0];
  const lift = control.conversion > 0
    ? Math.round(((variant.conversion - control.conversion) / control.conversion) * 100)
    : 0;
  const totalVisitors = test.variants.reduce((s, v) => s + v.visitors, 0);
  const isWin = variant.conversion > control.conversion && test.significance >= 95;
  const daysRunning = Math.max(
    1,
    Math.round(
      (new Date(test.endDate).getTime() - new Date(test.startDate).getTime()) / (1000 * 60 * 60 * 24)
    )
  );

  const handlePause = () => toast.success(`Test "${test.name}" paused`);

  // Mock significance calculator output (just for display)
  const calcSampleSize = Math.round(
    Math.max(1000, (Number(sampleSize) || 0) * (1 + Number(mde) / 100) * (Number(baseline) / 100) * 8)
  );

  return (
    <div>
      <PageHeader
        title={test.name}
        breadcrumbs={[
          { label: "A/B Tests", href: "/ab-tests" },
          { label: `#${test.id}` },
        ]}
        icon={<GitCompareArrows className="h-5 w-5" />}
        badge={
          <div className="flex items-center gap-1.5 flex-wrap">
            <StatusBadge status={test.status} />
            {isWin && (
              <Badge variant="outline" className="text-[10px] bg-success/15 text-success border-success/20">
                <Trophy className="h-2.5 w-2.5 mr-1" /> Variant won
              </Badge>
            )}
          </div>
        }
        actions={
          <>
            <Button variant="outline" size="sm" className="rounded-full" onClick={handlePause}>
              <Pause className="mr-2 h-3.5 w-3.5" /> Pause
            </Button>
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.message("Opening editor…")}>
              <Pencil className="mr-2 h-3.5 w-3.5" /> Edit
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => openShare(`/ab-tests/${test.id}`, test.name)}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
          </>
        }
      />

      {/* Top: 4 StatCards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Visitors"
          value={totalVisitors.toLocaleString()}
          icon={<Users className="h-4 w-4" />}
          accent="info"
          sublabel={`${test.variants.length} variants`}
        />
        <StatCard
          label="Conversion lift"
          value={`${lift > 0 ? "+" : ""}${lift}%`}
          icon={lift >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
          accent={lift >= 0 ? "success" : "friction"}
          sublabel={`${variant.conversion}% vs ${control.conversion}%`}
        />
        <StatCard
          label="Confidence"
          value={`${test.significance}%`}
          icon={<Activity className="h-4 w-4" />}
          accent={test.significance >= 95 ? "success" : "warning"}
          sublabel={test.significance >= 95 ? "≥95% threshold" : "below threshold"}
        />
        <StatCard
          label="Days running"
          value={daysRunning}
          icon={<Calendar className="h-4 w-4" />}
          accent="default"
          sublabel={`${test.startDate} → ${test.endDate}`}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* LEFT: bar chart + timeline */}
        <div className="lg:col-span-2 space-y-4">
          {/* Variant comparison with horizontal bars */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <GitCompareArrows className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Variant comparison</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                Conversion rate
              </Badge>
            </div>

            <div className="space-y-4">
              {test.variants.map((v, idx) => {
                const isControl = idx === 0;
                const maxConv = Math.max(...test.variants.map((vv) => vv.conversion));
                const widthPct = (v.conversion / maxConv) * 100;
                const vLift = isControl ? 0 : Math.round(((v.conversion - control.conversion) / control.conversion) * 100);
                return (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            "h-2 w-2 rounded-full",
                            isControl ? "bg-muted-foreground" : "bg-success"
                          )}
                        />
                        <span className="text-xs font-medium text-ink">{v.name}</span>
                        {isControl && (
                          <Badge variant="outline" className="text-[9px] text-muted-foreground">Control</Badge>
                        )}
                        {!isControl && isWin && (
                          <Badge variant="outline" className="text-[9px] bg-success/15 text-success border-success/20">
                            <Trophy className="h-2.5 w-2.5 mr-1" /> Winner
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-ink font-semibold">{v.conversion}%</span>
                        {!isControl && (
                          <span
                            className={cn(
                              "font-medium",
                              vLift > 0 ? "text-success" : vLift < 0 ? "text-friction" : "text-muted-foreground"
                            )}
                          >
                            {vLift > 0 ? "+" : ""}{vLift}%
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="h-7 rounded-lg bg-surface-2 overflow-hidden">
                      <div
                        className={cn(
                          "h-full rounded-lg transition-all flex items-center justify-end px-2",
                          isControl ? "bg-muted-foreground/30" : "bg-success/70"
                        )}
                        style={{ width: `${widthPct}%` }}
                      >
                        <span className="text-[10px] font-medium text-ink">{v.visitors.toLocaleString()} visitors</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 pt-4 border-t border-soft grid grid-cols-3 gap-3 text-xs">
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Absolute lift</div>
                <div className="text-base font-semibold text-ink">
                  +{variant.conversion - control.conversion}pp
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Relative lift</div>
                <div className="text-base font-semibold text-success">+{lift}%</div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">P-value</div>
                <div className="text-base font-semibold text-ink">
                  {test.significance >= 99 ? "< 0.001" : test.significance >= 95 ? "0.012" : "0.14"}
                </div>
              </div>
            </div>
          </Card>

          {/* Timeline */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Activity className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Test progress timeline</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">14 days</Badge>
            </div>
            <div className="h-48">
              <LineChart data={TIMELINE} height={192} showXAxis />
            </div>
            <div className="mt-3 flex items-center gap-4 text-[10px]">
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-muted-foreground" />
                <span className="text-muted-foreground">Control ({control.conversion}%)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-success" />
                <span className="text-muted-foreground">Variant ({variant.conversion}%)</span>
              </div>
              <div className="ml-auto text-muted-foreground">
                <Equal className="inline h-3 w-3 mr-1" />
                daily aggregated conversion rate
              </div>
            </div>
          </Card>
        </div>

        {/* RIGHT: significance calculator + audience + recommendations */}
        <div className="space-y-4">
          {/* Significance calculator */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Calculator className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Significance calculator</h3>
            </div>
            <div className="space-y-3">
              <div>
                <Label htmlFor="ss" className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  Sample size (per variant)
                </Label>
                <Input
                  id="ss"
                  value={sampleSize}
                  onChange={(e) => setSampleSize(e.target.value)}
                  className="h-8 text-xs mt-1"
                />
              </div>
              <div>
                <Label htmlFor="bl" className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  Baseline conversion %
                </Label>
                <Input
                  id="bl"
                  value={baseline}
                  onChange={(e) => setBaseline(e.target.value)}
                  className="h-8 text-xs mt-1"
                />
              </div>
              <div>
                <Label htmlFor="mde" className="text-[10px] text-muted-foreground uppercase tracking-wide">
                  Min. detectable effect (MDE) %
                </Label>
                <Input
                  id="mde"
                  value={mde}
                  onChange={(e) => setMde(e.target.value)}
                  className="h-8 text-xs mt-1"
                />
              </div>
              <div className="rounded-xl border border-soft bg-surface-2/40 p-3 mt-2">
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Recommended sample size</div>
                <div className="text-lg font-semibold text-ink mt-0.5">{calcSampleSize.toLocaleString()}</div>
                <div className="text-[10px] text-muted-foreground">per variant · 80% power · α=0.05</div>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="w-full rounded-full text-xs"
                onClick={() => toast.success("Calculator inputs saved")}
              >
                Save calculation
              </Button>
            </div>
          </Card>

          {/* Audience targeting */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Target className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Audience targeting</h3>
            </div>
            <dl className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Project</dt>
                <dd className="text-ink font-medium">{test.project}</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Audience</dt>
                <dd className="text-ink font-medium">All checkout sessions</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Device</dt>
                <dd className="text-ink font-medium">Desktop + Mobile</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Geography</dt>
                <dd className="text-ink font-medium">US, CA, UK</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Traffic split</dt>
                <dd className="text-ink font-medium">50 / 50</dd>
              </div>
              <div className="flex items-center justify-between gap-3">
                <dt className="text-muted-foreground">Sticky bucketing</dt>
                <dd className="text-ink font-medium">Yes (cookie)</dd>
              </div>
            </dl>
            <div className="mt-3 flex items-center gap-2">
              <div className="flex-1 h-2 rounded-full bg-surface-2 overflow-hidden flex">
                <div className="h-full bg-muted-foreground" style={{ width: "50%" }} />
                <div className="h-full bg-success" style={{ width: "50%" }} />
              </div>
            </div>
          </Card>

          {/* Recommendations */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold text-ink">Recommendations</h3>
            </div>
            <div className="space-y-2">
              <div className="rounded-xl border border-soft p-2.5">
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="text-[9px] bg-friction/15 text-friction border-friction/20">P0</Badge>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink line-clamp-1">Ship variant to 100% traffic</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2">
                      Variant beat control by {lift}% with {test.significance}% confidence. Roll out now.
                    </div>
                  </div>
                </div>
              </div>
              <div className="rounded-xl border border-soft p-2.5">
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="text-[9px] bg-warning/15 text-warning border-warning/20">P1</Badge>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink line-clamp-1">Segment lift by device</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2">
                      Mobile lift appears +21pp vs desktop +14pp. Consider a mobile-only follow-up.
                    </div>
                  </div>
                </div>
              </div>
              <div className="rounded-xl border border-soft p-2.5">
                <div className="flex items-start gap-2">
                  <Badge variant="outline" className="text-[9px] bg-info/15 text-info border-info/20">P2</Badge>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink line-clamp-1">Watch form-error guardrail</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2">
                      Form-error rate +1.2pp on variant. Verify with next 7-day window before committing.
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Recommendation drafted")}
            >
              <ChevronRight className="mr-1.5 h-3 w-3" /> Draft recommendation
            </Button>
          </Card>
        </div>
      </div>

      {/* Bottom: summary banner */}
      <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4 bg-surface-2/40">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-success/15 text-success flex-shrink-0">
            <Lightbulb className="h-4 w-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-ink">
              {isWin
                ? `Variant wins with ${test.significance}% confidence`
                : "Test still collecting data"}
            </div>
            <div className="text-xs text-muted-foreground mt-0.5">
              {isWin
                ? `Recommended action: roll variant "${variant.name}" to 100% of traffic and monitor guardrails for 7 days.`
                : `Currently at ${test.significance}% confidence — need 95% to declare a winner. Estimated ${Math.max(1, 14 - daysRunning)} days remaining.`}
            </div>
          </div>
          <Button
            size="sm"
            className="rounded-full text-xs flex-shrink-0"
            onClick={() => toast.success(isWin ? "Rolling variant to 100% traffic" : "Test monitor enabled")}
          >
            {isWin ? "Roll out variant" : "Monitor"}
          </Button>
        </div>
      </Card>
    </div>
  );
}
