"use client";

import * as React from "react";
import Link from "next/link";
import {
  GitCompareArrows,
  Download,
  Plus,
  PlayCircle,
  CheckCircle2,
  Trophy,
  Activity,
  TrendingUp,
  TrendingDown,
  Minus,
  MoreHorizontal,
  Pause,
  Pencil,
  Eye,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EXPERIMENTS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface AbTestRow {
  id: string;
  name: string;
  project: string;
  status: "running" | "completed" | "paused" | "draft";
  controlConversion: number;
  variantConversion: number;
  lift: number;
  confidence: number;
  winner: "control" | "variant" | "inconclusive";
}

// Derive an A/B-test view from the EXPERIMENTS dataset.
const AB_TESTS: AbTestRow[] = EXPERIMENTS.map((e) => {
  const control = e.variants[0];
  const variant = e.variants[1] ?? e.variants[0];
  const lift = control.conversion > 0
    ? Math.round(((variant.conversion - control.conversion) / control.conversion) * 100)
    : 0;
  let winner: AbTestRow["winner"] = "inconclusive";
  if (e.significance >= 95) {
    winner = variant.conversion > control.conversion ? "variant" : "control";
  }
  return {
    id: e.id,
    name: e.name,
    project: e.project,
    status: e.status,
    controlConversion: control.conversion,
    variantConversion: variant.conversion,
    lift,
    confidence: e.significance,
    winner,
  };
});

const columns: Column<AbTestRow>[] = [
  {
    key: "name",
    header: "Name",
    sortable: true,
    sortAccessor: (r) => r.name,
    cell: (r) => (
      <Link href={`/ab-tests/${r.id}`} className="block max-w-[260px]">
        <div className="text-sm font-medium text-ink hover:text-primary line-clamp-1">
          {r.name}
        </div>
        <div className="text-[10px] text-muted-foreground mt-0.5 truncate">
          {r.project}
        </div>
      </Link>
    ),
  },
  {
    key: "project",
    header: "Project",
    sortable: true,
    sortAccessor: (r) => r.project,
    hideOnMobile: true,
    cell: (r) => (
      <Badge variant="outline" className="text-[10px]">
        {r.project}
      </Badge>
    ),
  },
  {
    key: "status",
    header: "Status",
    cell: (r) => <StatusBadge status={r.status} />,
  },
  {
    key: "controlConversion",
    header: "Control conv.",
    sortable: true,
    sortAccessor: (r) => r.controlConversion,
    hideOnMobile: true,
    cell: (r) => <span className="text-ink font-medium">{r.controlConversion}%</span>,
  },
  {
    key: "variantConversion",
    header: "Variant conv.",
    sortable: true,
    sortAccessor: (r) => r.variantConversion,
    hideOnMobile: true,
    cell: (r) => <span className="text-ink font-medium">{r.variantConversion}%</span>,
  },
  {
    key: "lift",
    header: "Lift %",
    sortable: true,
    sortAccessor: (r) => r.lift,
    cell: (r) => (
      <span
        className={cn(
          "inline-flex items-center gap-0.5 font-medium",
          r.lift > 0 ? "text-success" : r.lift < 0 ? "text-friction" : "text-muted-foreground"
        )}
      >
        {r.lift > 0 ? <TrendingUp className="h-3 w-3" /> : r.lift < 0 ? <TrendingDown className="h-3 w-3" /> : <Minus className="h-3 w-3" />}
        {r.lift > 0 ? "+" : ""}{r.lift}%
      </span>
    ),
  },
  {
    key: "confidence",
    header: "Confidence",
    sortable: true,
    sortAccessor: (r) => r.confidence,
    hideOnMobile: true,
    cell: (r) => (
      <div className="flex items-center gap-2">
        <div className="w-14 h-1.5 rounded-full bg-surface-2 overflow-hidden">
          <div
            className={cn(
              "h-full rounded-full",
              r.confidence >= 95 ? "bg-success" : r.confidence >= 80 ? "bg-warning" : "bg-muted-foreground"
            )}
            style={{ width: `${r.confidence}%` }}
          />
        </div>
        <span className="text-ink">{r.confidence}%</span>
      </div>
    ),
  },
  {
    key: "winner",
    header: "Winner",
    cell: (r) => {
      if (r.winner === "variant")
        return (
          <Badge variant="outline" className="text-[10px] bg-success/15 text-success border-success/20">
            <Trophy className="h-2.5 w-2.5 mr-1" /> Variant
          </Badge>
        );
      if (r.winner === "control")
        return (
          <Badge variant="outline" className="text-[10px] bg-muted text-muted-foreground border-border">
            Control
          </Badge>
        );
      return (
        <Badge variant="outline" className="text-[10px] text-muted-foreground">
          Inconclusive
        </Badge>
      );
    },
  },
  {
    key: "actions",
    header: "",
    className: "w-10",
    cell: (r) => (
      <div className="flex items-center justify-end gap-1">
        <Button
          variant="ghost"
          size="sm"
          className="h-7 w-7 p-0"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toast.success(`Paused "${r.name}"`);
          }}
        >
          <Pause className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 w-7 p-0"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toast.message(`Opening "${r.name}" editor`);
          }}
        >
          <Pencil className="h-3.5 w-3.5" />
        </Button>
        <Button asChild variant="ghost" size="sm" className="h-7 w-7 p-0">
          <Link href={`/ab-tests/${r.id}`} onClick={(e) => e.stopPropagation()}>
            <Eye className="h-3.5 w-3.5" />
          </Link>
        </Button>
      </div>
    ),
  },
];

export default function AbTestsPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const running = AB_TESTS.filter((t) => t.status === "running").length;
  const completed = AB_TESTS.filter((t) => t.status === "completed").length;
  const significant = AB_TESTS.filter((t) => t.confidence >= 95).length;
  const avgLift = Math.round(
    AB_TESTS.reduce((s, t) => s + t.lift, 0) / AB_TESTS.length
  );

  return (
    <div>
      <PageHeader
        title="A/B Tests"
        description="Head-to-head variant tests with statistical significance"
        icon={<GitCompareArrows className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {AB_TESTS.length} tests
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("A/B tests log exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Opening new A/B test wizard…")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> New test
            </Button>
          </>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Running tests"
          value={running}
          icon={<PlayCircle className="h-4 w-4" />}
          accent="info"
          sublabel="collecting data now"
        />
        <StatCard
          label="Completed"
          value={completed}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          sublabel="concluded this quarter"
        />
        <StatCard
          label="Significant results"
          value={significant}
          icon={<Activity className="h-4 w-4" />}
          accent="warning"
          sublabel="≥95% confidence"
        />
        <StatCard
          label="Avg lift"
          value={`${avgLift > 0 ? "+" : ""}${avgLift}%`}
          icon={<TrendingUp className="h-4 w-4" />}
          accent={avgLift >= 0 ? "success" : "friction"}
          trend={{ value: 4, direction: avgLift >= 0 ? "up" : "down", good: avgLift >= 0 }}
          sublabel="vs prior period"
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="table" />
      ) : AB_TESTS.length === 0 ? (
        <EmptyState
          icon={GitCompareArrows}
          title="No A/B tests yet"
          description="Spin up a head-to-head test from any insight or recommendation. Results update in real time."
          action={{ label: "New test", onClick: () => toast.message("Opening new A/B test wizard…") }}
        />
      ) : (
        <DataTable
          data={AB_TESTS}
          columns={columns}
          getRowId={(r) => r.id}
          onRowClick={(r) => {
            window.location.href = `/ab-tests/${r.id}`;
          }}
          searchable
          searchPlaceholder="Search tests…"
          searchKeys={["name", "project"]}
          pageSize={8}
          emptyTitle="No tests match your search"
          emptyDescription="Try a different search term or clear the search to see all A/B tests."
          toolbar={
            <Button
              variant="outline"
              size="sm"
              className="h-9 text-xs rounded-full"
              onClick={() => toast.message("Opening column settings")}
            >
              <MoreHorizontal className="h-3.5 w-3.5" /> Columns
            </Button>
          }
        />
      )}

      {/* Footer summary */}
      {!loading && AB_TESTS.length > 0 && (
        <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4 bg-surface-2/40">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Win rate</div>
              <div className="text-base font-semibold text-ink">
                {Math.round((AB_TESTS.filter((t) => t.winner === "variant").length / AB_TESTS.length) * 100)}%
              </div>
              <div className="text-[10px] text-muted-foreground">variants that beat control</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Median confidence</div>
              <div className="text-base font-semibold text-ink">
                {[...AB_TESTS].sort((a, b) => a.confidence - b.confidence)[Math.floor(AB_TESTS.length / 2)].confidence}%
              </div>
              <div className="text-[10px] text-muted-foreground">across all tests</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Total visitors tested</div>
              <div className="text-base font-semibold text-ink">
                {EXPERIMENTS.reduce((s, e) => s + e.variants.reduce((a, v) => a + v.visitors, 0), 0).toLocaleString()}
              </div>
              <div className="text-[10px] text-muted-foreground">sum across variants</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Avg test duration</div>
              <div className="text-base font-semibold text-ink">18 days</div>
              <div className="text-[10px] text-muted-foreground">until significance</div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
