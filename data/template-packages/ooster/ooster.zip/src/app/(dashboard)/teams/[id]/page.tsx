"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Users,
  Pencil,
  MessageSquare,
  Mail,
  ShieldCheck,
  Activity,
  FolderKanban,
  Lightbulb,
  Laptop,
  Smartphone,
  Globe,
  Monitor,
  AlertTriangle,
  Ban,
  Trash2,
  CheckCircle2,
  XCircle,
  ChevronRight,
  Clock,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { getMember } from "@/lib/data";
import { toast } from "sonner";

const ROLE_BADGE_CLASS: Record<string, string> = {
  Owner: "bg-primary/10 text-primary border-primary/20",
  Admin: "bg-info/15 text-info border-info/20",
  Researcher: "bg-success/15 text-success border-success/20",
  Designer: "bg-warning/15 text-warning border-warning/20",
  PM: "bg-friction/15 text-friction border-friction/20",
  Viewer: "bg-muted text-muted-foreground border-border",
};

interface AssignedProject {
  name: string;
  role: string;
  uxScore: number;
  thumbColor: string;
}

interface AssignedInsight {
  title: string;
  severity: "critical" | "high" | "medium" | "low";
  project: string;
}

interface ActivityEntry {
  action: string;
  target: string;
  time: string;
}

interface Session {
  device: "Desktop" | "Mobile" | "Tablet";
  os: string;
  ip: string;
  location: string;
  lastActive: string;
  current: boolean;
}

const MOCK_ACTIVITY: ActivityEntry[] = [
  { action: "Generated report", target: "Atlas Onboarding — Q2 UX Audit", time: "12 min ago" },
  { action: "Updated project settings", target: "Northwind Checkout", time: "2 hours ago" },
  { action: "Marked insight resolved", target: "Address autocomplete fails", time: "5 hours ago" },
  { action: "Invited team member", target: "sana@ooster.app", time: "Yesterday" },
  { action: "Upgraded plan", target: "Team → Enterprise", time: "3 days ago" },
];

const MOCK_PROJECTS: AssignedProject[] = [
  { name: "Atlas Onboarding", role: "Lead", uxScore: 84, thumbColor: "var(--info)" },
  { name: "Northwind Checkout", role: "Contributor", uxScore: 71, thumbColor: "var(--warning)" },
  { name: "Helix Prototype", role: "Reviewer", uxScore: 88, thumbColor: "var(--success)" },
];

const MOCK_INSIGHTS: AssignedInsight[] = [
  { title: "KYC step 3 cognitive overload", severity: "critical", project: "Atlas Onboarding" },
  { title: "Address autocomplete fails for rural zip codes", severity: "high", project: "Northwind Checkout" },
  { title: "Empty insights list confuses new PMs", severity: "medium", project: "Helix Prototype" },
];

const MOCK_SESSIONS: Session[] = [
  { device: "Desktop", os: "macOS · Chrome 124", ip: "203.0.113.42", location: "Berlin, DE", lastActive: "2 min ago", current: true },
  { device: "Mobile", os: "iOS · Safari 17", ip: "203.0.113.43", location: "Berlin, DE", lastActive: "3 hours ago", current: false },
  { device: "Desktop", os: "macOS · Firefox 121", ip: "198.51.100.18", location: "Lisbon, PT", lastActive: "2 days ago", current: false },
];

const SEVERITY_CLASS: Record<string, string> = {
  critical: "bg-friction/15 text-friction border-friction/20",
  high: "bg-warning/15 text-warning border-warning/20",
  medium: "bg-info/15 text-info border-info/20",
  low: "bg-success/15 text-success border-success/20",
};

const DEVICE_ICON: Record<string, React.ReactNode> = {
  Desktop: <Monitor className="h-4 w-4" />,
  Mobile: <Smartphone className="h-4 w-4" />,
  Tablet: <Smartphone className="h-4 w-4" />,
};

export default function TeamMemberDetailPage() {
  const params = useParams<{ id: string }>();
  const member = getMember(params.id);
  const [loading, setLoading] = React.useState(true);

  // Permission toggles
  const [perms, setPerms] = React.useState({
    can_create_projects: member?.role === "Owner" || member?.role === "Admin",
    can_invite_members: member?.role === "Owner" || member?.role === "Admin",
    can_delete_data: member?.role === "Owner",
    can_view_billing: member?.role === "Owner" || member?.role === "Admin",
    can_export_reports: true,
    can_manage_integrations: member?.role === "Owner" || member?.role === "Admin",
  });

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  React.useEffect(() => {
    if (member) {
      setPerms({
        can_create_projects: member.role === "Owner" || member.role === "Admin",
        can_invite_members: member.role === "Owner" || member.role === "Admin",
        can_delete_data: member.role === "Owner",
        can_view_billing: member.role === "Owner" || member.role === "Admin",
        can_export_reports: true,
        can_manage_integrations: member.role === "Owner" || member.role === "Admin",
      });
    }
  }, [member?.id]);

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  if (!member) {
    return (
      <EmptyState
        icon={Users}
        title="Team member not found"
        description="This member may have been removed or never existed in your workspace."
        action={{ label: "Back to team", href: "/teams" }}
      />
    );
  }

  const toggle = (key: keyof typeof perms) => (v: boolean) => {
    setPerms((p) => ({ ...p, [key]: v }));
    toast.success(`Permission updated`, {
      description: `${key.replace(/_/g, " ")} ${v ? "granted" : "revoked"} for ${member.name}`,
    });
  };

  return (
    <div>
      <PageHeader
        title={member.name}
        description={`${member.role} · ${member.email}`}
        breadcrumbs={[
          { label: "Team", href: "/teams" },
          { label: member.name },
        ]}
        icon={<Users className="h-5 w-5" />}
        badge={
          <Badge
            variant="outline"
            className={`text-[10px] font-medium border ${ROLE_BADGE_CLASS[member.role]}`}
          >
            {member.role}
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.message(`Composing message to ${member.name}`)}
            >
              <MessageSquare className="mr-2 h-3.5 w-3.5" /> Message
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message(`Editing ${member.name}`)}
            >
              <Pencil className="mr-2 h-3.5 w-3.5" /> Edit
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* LEFT COLUMN */}
        <div className="lg:col-span-2 space-y-4">
          {/* Profile */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="flex flex-col sm:flex-row sm:items-start gap-4">
              <Avatar className="h-20 w-20 rounded-2xl ring-2 ring-soft flex-shrink-0">
                <AvatarImage src={member.avatar} alt={member.name} />
                <AvatarFallback className="rounded-2xl text-lg">
                  {member.name.slice(0, 2)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg font-semibold text-ink">{member.name}</h2>
                  <Badge
                    variant="outline"
                    className={`text-[10px] font-medium border ${ROLE_BADGE_CLASS[member.role]}`}
                  >
                    {member.role}
                  </Badge>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1">
                  <Mail className="h-3.5 w-3.5" /> {member.email}
                </div>
                <div className="mt-3 space-y-2 text-sm text-ink leading-relaxed">
                  <p>
                    {member.name.split(" ")[0]} leads UX research and analytics
                    initiatives across the customer-facing product surface. They
                    own research operations, run weekly studies, and translate
                    findings into prioritized roadmap inputs for engineering.
                  </p>
                  <p>
                    Before joining Ooster, they shipped accessibility audits at
                    scale and built the design-systems practice at a previous
                    role. Currently focused on onboarding friction and mobile
                    checkout conversion.
                  </p>
                </div>
              </div>
            </div>
            <Separator className="my-4" />
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  Projects
                </div>
                <div className="text-sm font-semibold text-ink mt-0.5">
                  {member.projects}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  Insights
                </div>
                <div className="text-sm font-semibold text-ink mt-0.5">
                  {member.insights}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  Last active
                </div>
                <div className="text-sm font-semibold text-ink mt-0.5">
                  {member.lastActive}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  Status
                </div>
                <div className="text-sm font-semibold text-ink mt-0.5 capitalize">
                  {member.status}
                </div>
              </div>
            </div>
          </Card>

          {/* Activity feed */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Activity className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Recent activity</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {MOCK_ACTIVITY.length} actions
              </Badge>
            </div>
            <div className="relative pl-5">
              <div className="absolute left-1.5 top-1 bottom-1 w-px bg-soft" />
              <div className="space-y-3">
                {MOCK_ACTIVITY.map((a, i) => (
                  <div key={i} className="relative">
                    <div className="absolute -left-[14px] top-1 h-2.5 w-2.5 rounded-full bg-primary ring-2 ring-card" />
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-0.5">
                      <div className="text-xs text-ink">
                        <span className="font-medium">{a.action}</span>{" "}
                        <span className="text-muted-foreground">{a.target}</span>
                      </div>
                      <div className="text-[10px] text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {a.time}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Assigned projects */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <FolderKanban className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Assigned projects</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {MOCK_PROJECTS.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {MOCK_PROJECTS.map((p) => (
                <div
                  key={p.name}
                  className="flex items-center gap-3 rounded-xl border border-soft p-3"
                >
                  <div
                    className="h-8 w-8 rounded-lg flex-shrink-0 flex items-center justify-center text-white"
                    style={{ background: p.thumbColor }}
                  >
                    <FolderKanban className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink truncate">
                      {p.name}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      Role: {p.role} · UX score {p.uxScore}
                    </div>
                  </div>
                  <div className="hidden sm:block w-20">
                    <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-success"
                        style={{ width: `${p.uxScore}%` }}
                      />
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              ))}
            </div>
          </Card>

          {/* Assigned insights */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-warning">
                <Lightbulb className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Assigned insights</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {MOCK_INSIGHTS.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {MOCK_INSIGHTS.map((i) => (
                <div
                  key={i.title}
                  className="flex items-center gap-3 rounded-xl border border-soft p-3"
                >
                  <Badge
                    variant="outline"
                    className={`text-[10px] font-medium capitalize border ${SEVERITY_CLASS[i.severity]}`}
                  >
                    {i.severity}
                  </Badge>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink truncate">
                      {i.title}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      {i.project}
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* RIGHT COLUMN */}
        <div className="space-y-4">
          {/* Permissions */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Permissions</h3>
              <Badge
                variant="outline"
                className={`text-[10px] font-medium ml-auto border ${ROLE_BADGE_CLASS[member.role]}`}
              >
                {member.role}
              </Badge>
            </div>
            <div className="space-y-3">
              {(
                [
                ["can_create_projects", "Create projects", "Add new project workspaces"],
                ["can_invite_members", "Invite members", "Send workspace invitations"],
                ["can_delete_data", "Delete data", "Permanently remove insights, reports, projects"],
                ["can_view_billing", "View billing", "See invoices, plan, and payment methods"],
                ["can_export_reports", "Export reports", "Download PDF / CSV exports"],
                ["can_manage_integrations", "Manage integrations", "Connect or disconnect tools"],
                ] as [keyof typeof perms, string, string][]
              ).map(([key, label, desc]) => (
                <div
                  key={key}
                  className="flex items-start justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink">{label}</div>
                    <div className="text-[10px] text-muted-foreground">
                      {desc}
                    </div>
                  </div>
                  <Switch
                    checked={perms[key]}
                    onCheckedChange={toggle(key)}
                  />
                </div>
              ))}
            </div>
          </Card>

          {/* 2FA status */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Two-factor auth</h3>
            </div>
            <div className="flex items-center gap-3 rounded-xl border border-soft p-3">
              {member.twoFactor ? (
                <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0" />
              ) : (
                <XCircle className="h-5 w-5 text-friction flex-shrink-0" />
              )}
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-ink">
                  {member.twoFactor ? "Enabled" : "Not enabled"}
                </div>
                <div className="text-[10px] text-muted-foreground">
                  {member.twoFactor
                    ? "Authenticator app configured"
                    : "Recommend enabling for admin-level roles"}
                </div>
              </div>
              {!member.twoFactor && (
                <Button
                  variant="outline"
                  size="sm"
                  className="text-[10px] h-7"
                  onClick={() =>
                    toast.success(`2FA reminder sent to ${member.email}`)
                  }
                >
                  Remind
                </Button>
              )}
            </div>
          </Card>

          {/* Sessions */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Laptop className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Active sessions</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {MOCK_SESSIONS.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {MOCK_SESSIONS.map((s, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-soft p-3 space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-muted-foreground flex-shrink-0">
                        {DEVICE_ICON[s.device]}
                      </span>
                      <span className="text-xs font-medium text-ink truncate">
                        {s.device} · {s.os}
                      </span>
                    </div>
                    {s.current && (
                      <Badge
                        variant="outline"
                        className="text-[9px] border-success/30 bg-success/10 text-success"
                      >
                        Current
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Globe className="h-3 w-3" /> {s.location} · {s.ip}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {s.lastActive}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Danger zone */}
          <Card className="rounded-2xl border-friction/30 shadow-soft p-4 bg-friction/[0.02]">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/10 text-friction">
                <AlertTriangle className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Danger zone</h3>
            </div>
            <div className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start text-xs h-9 border-warning/30 text-warning hover:bg-warning/10"
                onClick={() =>
                  toast.error(`Suspend ${member.name}?`, {
                    description: "They will lose access immediately.",
                  })
                }
              >
                <Ban className="mr-2 h-3.5 w-3.5" /> Suspend member
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start text-xs h-9 border-friction/30 text-friction hover:bg-friction/10"
                onClick={() =>
                  toast.error(`Remove ${member.name}?`, {
                    description: "This action is permanent and cannot be undone.",
                  })
                }
              >
                <Trash2 className="mr-2 h-3.5 w-3.5" /> Remove from workspace
              </Button>
            </div>
          </Card>
        </div>
      </div>

      {/* Footer link */}
      <div className="mt-4">
        <Button asChild variant="ghost" size="sm" className="text-xs">
          <Link href="/teams">
            <Users className="mr-2 h-3.5 w-3.5" /> Back to team
          </Link>
        </Button>
      </div>
    </div>
  );
}
