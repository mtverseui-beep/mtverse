"use client";

import * as React from "react";
import Link from "next/link";
import {
  Users,
  UserPlus,
  UserCheck,
  Mail,
  ShieldCheck,
  Check,
  X,
  MoreHorizontal,
  Pencil,
  Trash2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { TEAM_MEMBERS, type TeamMember } from "@/lib/data";
import { toast } from "sonner";

const ROLE_OPTIONS: FilterOption[] = [
  { label: "All roles", value: "all" },
  { label: "Owner", value: "Owner" },
  { label: "Admin", value: "Admin" },
  { label: "Researcher", value: "Researcher" },
  { label: "Designer", value: "Designer" },
  { label: "PM", value: "PM" },
  { label: "Viewer", value: "Viewer" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Active", value: "active" },
  { label: "Invited", value: "invited" },
  { label: "Suspended", value: "suspended" },
];

const ROLE_BADGE_CLASS: Record<string, string> = {
  Owner: "bg-primary/10 text-primary border-primary/20",
  Admin: "bg-info/15 text-info border-info/20",
  Researcher: "bg-success/15 text-success border-success/20",
  Designer: "bg-warning/15 text-warning border-warning/20",
  PM: "bg-friction/15 text-friction border-friction/20",
  Viewer: "bg-muted text-muted-foreground border-border",
};

function RoleBadge({ role }: { role: string }) {
  return (
    <Badge
      variant="outline"
      className={`text-[10px] font-medium border ${ROLE_BADGE_CLASS[role] ?? "bg-muted text-muted-foreground border-border"}`}
    >
      {role}
    </Badge>
  );
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { dot: string; label: string; cls: string }> = {
    active: {
      dot: "bg-success",
      label: "Active",
      cls: "text-success",
    },
    invited: {
      dot: "bg-warning",
      label: "Invited",
      cls: "text-warning",
    },
    suspended: {
      dot: "bg-friction",
      label: "Suspended",
      cls: "text-friction",
    },
  };
  const s = map[status] ?? map.active;
  return (
    <span className="inline-flex items-center gap-1.5 text-[11px] font-medium">
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      <span className={s.cls}>{s.label}</span>
    </span>
  );
}

export default function TeamsPage() {
  const [search, setSearch] = React.useState("");
  const [role, setRole] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return TEAM_MEMBERS.filter((m) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !m.name.toLowerCase().includes(q) &&
          !m.email.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (role !== "all" && m.role !== role) return false;
      if (status !== "all" && m.status !== status) return false;
      return true;
    });
  }, [search, role, status]);

  const clearFilters = () => {
    setSearch("");
    setRole("all");
    setStatus("all");
  };

  // KPIs
  const total = TEAM_MEMBERS.length;
  const activeToday = TEAM_MEMBERS.filter(
    (m) => m.lastActive.includes("min") || m.lastActive.includes("hour")
  ).length;
  const pendingInvites = TEAM_MEMBERS.filter(
    (m) => m.status === "invited"
  ).length;
  const admins = TEAM_MEMBERS.filter(
    (m) => m.role === "Owner" || m.role === "Admin"
  ).length;

  const columns: Column<TeamMember>[] = [
    {
      key: "member",
      header: "Member",
      cell: (m) => (
        <div className="flex items-center gap-2.5 min-w-0">
          <Avatar className="h-8 w-8 ring-1 ring-soft flex-shrink-0">
            <AvatarImage src={m.avatar} alt={m.name} />
            <AvatarFallback>{m.name.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="text-xs font-medium text-ink truncate">{m.name}</div>
            <div className="text-[10px] text-muted-foreground truncate">
              {m.email}
            </div>
          </div>
        </div>
      ),
      width: "32%",
    },
    {
      key: "role",
      header: "Role",
      cell: (m) => <RoleBadge role={m.role} />,
      width: "10%",
    },
    {
      key: "status",
      header: "Status",
      cell: (m) => <StatusPill status={m.status} />,
      width: "12%",
    },
    {
      key: "projects",
      header: "Projects",
      cell: (m) => (
        <span className="text-xs font-medium text-ink">{m.projects}</span>
      ),
      width: "8%",
      hideOnMobile: true,
    },
    {
      key: "insights",
      header: "Insights",
      cell: (m) => (
        <span className="text-xs font-medium text-ink">{m.insights}</span>
      ),
      width: "8%",
      hideOnMobile: true,
    },
    {
      key: "lastActive",
      header: "Last active",
      cell: (m) => (
        <span className="text-[11px] text-muted-foreground">{m.lastActive}</span>
      ),
      width: "12%",
      hideOnMobile: true,
    },
    {
      key: "2fa",
      header: "2FA",
      cell: (m) =>
        m.twoFactor ? (
          <Check className="h-4 w-4 text-success" />
        ) : (
          <X className="h-4 w-4 text-muted-foreground" />
        ),
      width: "6%",
      hideOnMobile: true,
    },
    {
      key: "actions",
      header: "",
      cell: (m) => (
        <div className="flex items-center gap-1 justify-end">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={(e) => {
              e.stopPropagation();
              toast.message(`Editing ${m.name}`, {
                description: "Opening member profile editor",
              });
            }}
          >
            <Pencil className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-friction"
            onClick={(e) => {
              e.stopPropagation();
              toast.error(`Remove ${m.name}?`, {
                description: "They will lose access immediately.",
              });
            }}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      ),
      width: "10%",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Team"
        description="Manage workspace members, roles, and permissions"
        icon={<Users className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {TEAM_MEMBERS.length} members
          </Badge>
        }
        actions={
          <Button
            size="sm"
            className="rounded-full"
            onClick={() =>
              toast.success("Invite sent", {
                description: "Open the invite page to send team invitations.",
              })
            }
          >
            <UserPlus className="mr-2 h-3.5 w-3.5" /> Invite member
          </Button>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total members"
          value={total}
          icon={<Users className="h-4 w-4" />}
          accent="info"
          sublabel="across workspace"
        />
        <StatCard
          label="Active today"
          value={activeToday}
          icon={<UserCheck className="h-4 w-4" />}
          accent="success"
          sublabel="online in last 24h"
        />
        <StatCard
          label="Pending invites"
          value={pendingInvites}
          icon={<Mail className="h-4 w-4" />}
          accent="warning"
          sublabel="awaiting acceptance"
        />
        <StatCard
          label="Admins"
          value={admins}
          icon={<ShieldCheck className="h-4 w-4" />}
          accent="default"
          sublabel="owners + admins"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search by name or email…",
          }}
          selects={[
            { label: "Role", value: role, onChange: setRole, options: ROLE_OPTIONS },
            { label: "Status", value: status, onChange: setStatus, options: STATUS_OPTIONS },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="table" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No team members match your filters"
          description="Try adjusting your search or filters, or invite a new member to your workspace."
          action={{ label: "Invite member", href: "/invite" }}
          secondaryAction={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <DataTable<TeamMember>
          data={filtered}
          columns={columns}
          getRowId={(m) => m.id}
          onRowClick={(m) => {
            window.location.href = `/teams/${m.id}`;
          }}
          emptyTitle="No team members found"
          emptyDescription="Adjust filters to find members."
        />
      )}

      {/* Hint footer */}
      <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-2 text-primary">
            <ShieldCheck className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs font-medium text-ink">
              Role-based access control
            </div>
            <div className="text-[10px] text-muted-foreground">
              Owners can manage billing and members. Viewers have read-only access.
            </div>
          </div>
        </div>
        <Button asChild variant="outline" size="sm" className="rounded-full text-xs">
          <Link href="/invite">
            <UserPlus className="mr-2 h-3.5 w-3.5" /> Invite a teammate
          </Link>
        </Button>
      </Card>
    </div>
  );
}
