"use client";

import * as React from "react";
import {
  Accessibility,
  ShieldCheck,
  AlertOctagon,
  Component,
  ScanLine,
  Download,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DonutChart } from "@/components/charts";
import { SeverityBadge } from "@/components/common/badges";
import { AGGREGATE_UX } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { AnimatedNumber, ActiveDot } from "@/components/common/animated-progress";

const VIOLATION_CATEGORIES = [
  { label: "Contrast", value: 35, color: "var(--friction)" },
  { label: "Keyboard", value: 22, color: "var(--warning)" },
  { label: "ARIA", value: 18, color: "var(--info)" },
  { label: "Forms", value: 15, color: "var(--chart-5)" },
  { label: "Others", value: 10, color: "var(--muted-foreground)" },
];

const CRITICAL_VIOLATIONS = [
  {
    id: "cv-1",
    component: "Primary button",
    screen: "Atlas / Checkout",
    severity: "critical" as const,
    issue: "3.8:1 contrast on white background",
  },
  {
    id: "cv-2",
    component: "Date picker",
    screen: "Voyage / Booking",
    severity: "critical" as const,
    issue: "Focus trap — Tab key escapes calendar",
  },
  {
    id: "cv-3",
    component: "Modal close",
    screen: "Riverside / System",
    severity: "critical" as const,
    issue: "Close button has no aria-label",
  },
  {
    id: "cv-4",
    component: "Toast dismiss",
    screen: "Riverside / System",
    severity: "high" as const,
    issue: "No keyboard way to dismiss",
  },
  {
    id: "cv-5",
    component: "Filter chips",
    screen: "Voyage / Search",
    severity: "high" as const,
    issue: "Role=button missing — not announced",
  },
];

interface ComponentRow {
  id: string;
  name: string;
  levelA: "pass" | "fail";
  levelAA: "pass" | "fail";
  levelAAA: "pass" | "fail";
  violations: number;
}

const COMPONENTS: ComponentRow[] = [
  { id: "c-1", name: "Button", levelA: "pass", levelAA: "fail", levelAAA: "fail", violations: 2 },
  { id: "c-2", name: "Input", levelA: "pass", levelAA: "pass", levelAAA: "fail", violations: 1 },
  { id: "c-3", name: "Modal", levelA: "fail", levelAA: "fail", levelAAA: "fail", violations: 4 },
  { id: "c-4", name: "Tooltip", levelA: "pass", levelAA: "pass", levelAAA: "pass", violations: 0 },
  { id: "c-5", name: "Tabs", levelA: "pass", levelAA: "pass", levelAAA: "fail", violations: 1 },
  { id: "c-6", name: "Dropdown", levelA: "pass", levelAA: "pass", levelAAA: "fail", violations: 1 },
  { id: "c-7", name: "DatePicker", levelA: "fail", levelAA: "fail", levelAAA: "fail", violations: 5 },
  { id: "c-8", name: "Toast", levelA: "pass", levelAA: "fail", levelAAA: "fail", violations: 3 },
];

function PassFail({ status }: { status: "pass" | "fail" }) {
  return status === "pass" ? (
    <span className="inline-flex items-center justify-center h-5 w-5 rounded-md bg-success/15 text-success text-[10px] font-bold">
      ✓
    </span>
  ) : (
    <span className="inline-flex items-center justify-center h-5 w-5 rounded-md bg-friction/15 text-friction text-[10px] font-bold">
      ✗
    </span>
  );
}

export default function AccessibilityMetricsPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  return (
    <div>
      <PageHeader
        title="Accessibility Metrics"
        description="WCAG 2.1 conformance, screen-reader tests, and contrast audits"
        breadcrumbs={[{ label: "Metrics" }, { label: "Accessibility" }]}
        icon={<Accessibility className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            WCAG {AGGREGATE_UX.accessibility}/100
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Accessibility audit exported")}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export audit
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="WCAG AA pass rate"
              value={84}
              unit="%"
              animate
              icon={<ShieldCheck className="h-4 w-4" />}
              accent="success"
              trend={{ value: 2.1, direction: "up", good: true }}
              sublabel="42 of 50 audits"
            />
            <StatCard
              label="Critical violations"
              value={12}
              animate
              icon={<AlertOctagon className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 3, direction: "down", good: true }}
              sublabel="vs last scan"
            >
              <div className="mt-2 flex items-center gap-1.5 text-[10px] font-medium text-friction">
                <ActiveDot color="var(--friction)" size={6} />
                Live monitoring
              </div>
            </StatCard>
            <StatCard
              label="Components audited"
              value="56/72"
              icon={<Component className="h-4 w-4" />}
              accent="warning"
              sublabel="16 remaining"
            />
            <StatCard
              label="Auto scan coverage"
              value={92}
              unit="%"
              animate
              icon={<ScanLine className="h-4 w-4" />}
              accent="info"
              trend={{ value: 4.0, direction: "up", good: true }}
              sublabel="axe-core + manual"
            />
          </div>

          {/* Donut + critical violations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="text-sm font-semibold text-ink mb-1">Violation categories</div>
              <div className="text-[11px] text-muted-foreground mb-4">
                Distribution across WCAG 2.1 SCs
              </div>
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <DonutChart
                  data={VIOLATION_CATEGORIES}
                  size={170}
                  strokeWidth={20}
                  centerValue="100"
                  centerLabel="total issues"
                />
                <div className="flex-1 w-full space-y-2">
                  {VIOLATION_CATEGORIES.map((c) => (
                    <div key={c.label} className="flex items-center gap-2 text-xs">
                      <span className="h-2.5 w-2.5 rounded-sm" style={{ background: c.color }} />
                      <span className="text-muted-foreground flex-1">{c.label}</span>
                      <span className="font-semibold text-ink tabular-nums">
                        <AnimatedNumber value={c.value} suffix="%" duration={1.2} />
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Top critical violations</div>
                  <div className="text-[11px] text-muted-foreground">By severity × reach</div>
                </div>
                <AlertOctagon className="h-4 w-4 text-friction" />
              </div>
              <div className="space-y-2.5">
                {CRITICAL_VIOLATIONS.map((v) => (
                  <div
                    key={v.id}
                    className="flex items-start gap-3 p-2.5 rounded-lg border border-soft bg-surface-2/40 hover:bg-surface-2/70 transition-colors"
                  >
                    <SeverityBadge severity={v.severity} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-ink truncate">{v.component}</span>
                        <span className="text-[10px] text-muted-foreground truncate flex-shrink-0">{v.screen}</span>
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">{v.issue}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Components compliance matrix */}
          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden">
            <div className="p-4 border-b border-soft">
              <div className="text-sm font-semibold text-ink">Component compliance matrix</div>
              <div className="text-[11px] text-muted-foreground">WCAG conformance by level per component</div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-soft">
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Component</th>
                    <th className="text-center font-medium text-muted-foreground px-3 py-2.5">Level A</th>
                    <th className="text-center font-medium text-muted-foreground px-3 py-2.5">Level AA</th>
                    <th className="text-center font-medium text-muted-foreground px-3 py-2.5">Level AAA</th>
                    <th className="text-right font-medium text-muted-foreground px-4 py-2.5">Violations</th>
                  </tr>
                </thead>
                <tbody>
                  {COMPONENTS.map((c) => {
                    const failing = [c.levelA, c.levelAA, c.levelAAA].filter((s) => s === "fail").length;
                    return (
                      <tr key={c.id} className="border-b border-soft last:border-0 hover:bg-accent/20 transition-colors">
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-ink">{c.name}</span>
                            {failing === 3 && (
                              <Badge variant="outline" className="text-[9px] border-friction/20 bg-friction/10 text-friction">
                                Blocked
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td className="text-center px-3 py-2.5"><PassFail status={c.levelA} /></td>
                        <td className="text-center px-3 py-2.5"><PassFail status={c.levelAA} /></td>
                        <td className="text-center px-3 py-2.5"><PassFail status={c.levelAAA} /></td>
                        <td className="px-4 py-2.5 text-right">
                          <span
                            className={cn(
                              "text-xs font-semibold tabular-nums",
                              c.violations === 0
                                ? "text-success"
                                : c.violations >= 3
                                ? "text-friction"
                                : "text-warning"
                            )}
                          >
                            {c.violations}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="p-3 border-t border-soft flex flex-wrap items-center justify-between gap-2 text-[10px] text-muted-foreground">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="inline-flex items-center justify-center h-4 w-4 rounded-md bg-success/15 text-success text-[9px] font-bold">✓</span>
                  Pass
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="inline-flex items-center justify-center h-4 w-4 rounded-md bg-friction/15 text-friction text-[9px] font-bold">✗</span>
                  Fail
                </span>
              </div>
              <span>Updated 2 hours ago · axe-core 4.9 + manual SR test</span>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
