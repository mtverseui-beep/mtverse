"use client";

import * as React from "react";
import {
  Zap,
  Gauge,
  MousePointerClick,
  Ban,
  FileX,
  TrendingDown,
  TrendingUp,
  Minus,
  Download,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LineChart } from "@/components/charts";
import { TREND_SERIES, AGGREGATE_UX } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { AnimatedNumber, ProgressBar, ActiveDot } from "@/components/common/animated-progress";

const HOTSPOTS = [
  { screen: "KYC document upload", type: "Rage clicks", intensity: 92, project: "Atlas Onboarding" },
  { screen: "Filter chip — mobile", type: "Dead clicks", intensity: 78, project: "Voyage Booking" },
  { screen: "Wallet seed backup", type: "U-turns", intensity: 71, project: "Atlas Onboarding" },
  { screen: "Checkout review", type: "Form abandonment", intensity: 64, project: "Northwind Checkout" },
  { screen: "Notification toggle", type: "Rage clicks", intensity: 58, project: "Cadence Mobile" },
];

interface FrictionTypeRow {
  id: string;
  type: string;
  icon: React.ElementType;
  count: number;
  affectedSessions: number;
  trend: "up" | "down" | "flat";
  trendValue: number;
  severity: "high" | "medium" | "low";
}

const FRICTION_TYPES: FrictionTypeRow[] = [
  { id: "ft-1", type: "Rage clicks", icon: Zap, count: 412, affectedSessions: 184, trend: "down", trendValue: 8.2, severity: "high" },
  { id: "ft-2", type: "Dead clicks", icon: Ban, count: 318, affectedSessions: 142, trend: "up", trendValue: 3.4, severity: "high" },
  { id: "ft-3", type: "U-turns", icon: TrendingDown, count: 246, affectedSessions: 98, trend: "down", trendValue: 2.1, severity: "medium" },
  { id: "ft-4", type: "Form abandonment", icon: FileX, count: 194, affectedSessions: 76, trend: "down", trendValue: 5.6, severity: "medium" },
  { id: "ft-5", type: "Excessive scrolling", icon: MousePointerClick, count: 88, affectedSessions: 41, trend: "flat", trendValue: 0.4, severity: "low" },
];

function FrictionTrendBadge({ trend, value }: { trend: "up" | "down" | "flat"; value: number }) {
  const isGood = trend === "down"; // down friction = good
  const Icon = trend === "up" ? TrendingUp : trend === "down" ? TrendingDown : Minus;
  const color = trend === "flat" ? "text-muted-foreground" : isGood ? "text-success" : "text-friction";
  return (
    <span className={cn("inline-flex items-center gap-0.5 text-[10px] font-medium", color)}>
      <Icon className="h-3 w-3" />
      {value}%
    </span>
  );
}

export default function FrictionAnalysisPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  // Invert friction so lower = better visual (higher line = better/less friction)
  const lineData = React.useMemo(
    () =>
      TREND_SERIES.map((d) => ({
        label: d.week,
        values: [
          { label: "Friction (inverted)", value: 100 - d.friction },
          { label: "Friction raw", value: d.friction },
        ],
      })),
    []
  );

  const columns: Column<FrictionTypeRow>[] = [
    {
      key: "type",
      header: "Friction type",
      cell: (row) => (
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/10 text-friction">
            <row.icon className="h-3.5 w-3.5" />
          </div>
          <span className="text-xs font-medium text-ink">{row.type}</span>
        </div>
      ),
      sortAccessor: (row) => row.type,
      sortable: true,
    },
    {
      key: "count",
      header: "Occurrences",
      cell: (row) => <span className="text-xs font-semibold tabular-nums">{row.count}</span>,
      sortAccessor: (row) => row.count,
      sortable: true,
    },
    {
      key: "affectedSessions",
      header: "Sessions",
      cell: (row) => <span className="text-xs tabular-nums">{row.affectedSessions}</span>,
      sortAccessor: (row) => row.affectedSessions,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "trend",
      header: "Trend (7d)",
      cell: (row) => <FrictionTrendBadge trend={row.trend} value={row.trendValue} />,
      sortAccessor: (row) => row.trendValue,
      sortable: true,
    },
    {
      key: "severity",
      header: "Severity",
      cell: (row) => (
        <Badge
          variant="outline"
          className={cn(
            "text-[10px] capitalize",
            row.severity === "high" && "border-friction/20 bg-friction/10 text-friction",
            row.severity === "medium" && "border-warning/20 bg-warning/10 text-warning",
            row.severity === "low" && "border-info/20 bg-info/10 text-info"
          )}
        >
          {row.severity}
        </Badge>
      ),
      sortAccessor: (row) => row.severity,
      sortable: true,
    },
    {
      key: "share",
      header: "Share",
      cell: (row) => {
        const total = FRICTION_TYPES.reduce((a, b) => a + b.count, 0);
        const pct = Math.round((row.count / total) * 100);
        return (
          <div className="flex items-center gap-2">
            <ProgressBar
              value={pct}
              color="var(--friction)"
              trackColor="var(--surface-2)"
              height={6}
              className="w-12"
              showLabel={false}
            />
            <span className="text-[10px] text-muted-foreground tabular-nums">{pct}%</span>
          </div>
        );
      },
      hideOnMobile: true,
    },
  ];

  // Friction score trend metrics
  const latestFriction = TREND_SERIES[TREND_SERIES.length - 1].friction;
  const firstFriction = TREND_SERIES[0].friction;
  const delta = latestFriction - firstFriction;

  return (
    <div>
      <PageHeader
        title="Friction Analysis"
        description="Rage clicks, dead clicks, u-turns, and form abandonment hotspots"
        breadcrumbs={[{ label: "Metrics" }, { label: "Friction" }]}
        icon={<Zap className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            Score {AGGREGATE_UX.friction}/100
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Friction heatmap exported")}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export hotspots
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Friction score"
              value={24}
              unit="/100"
              animate
              icon={<Gauge className="h-4 w-4" />}
              accent="success"
              trend={{ value: 12, direction: "down", good: true }}
              sublabel="lower is better"
            />
            <StatCard
              label="Rage click sessions"
              value={12}
              unit="%"
              animate
              icon={<Zap className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 2.1, direction: "down", good: true }}
              sublabel="of all sessions"
            >
              <div className="mt-2 flex items-center gap-1.5 text-[10px] font-medium text-friction">
                <ActiveDot color="var(--friction)" size={6} />
                Spiking now
              </div>
            </StatCard>
            <StatCard
              label="Dead clicks"
              value={8}
              unit="%"
              animate
              icon={<Ban className="h-4 w-4" />}
              accent="warning"
              trend={{ value: 0.4, direction: "up", good: false }}
              sublabel="non-interactive taps"
            />
            <StatCard
              label="Form abandonment"
              value={16}
              unit="%"
              animate
              icon={<FileX className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 3.2, direction: "down", good: true }}
              sublabel="before submit"
            />
          </div>

          {/* Main chart + side hotspots */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Friction score trend</div>
                  <div className="text-[11px] text-muted-foreground">
                    12-week · inverted (higher line = less friction = better)
                  </div>
                </div>
                <div className="flex items-center gap-3 text-[10px]">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full" style={{ background: "var(--success)" }} />
                    <span className="text-muted-foreground">Anti-friction</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full" style={{ background: "var(--friction)" }} />
                    <span className="text-muted-foreground">Raw friction</span>
                  </div>
                </div>
              </div>
              <LineChart data={lineData} height={260} />
              <div className="mt-3 pt-3 border-t border-soft grid grid-cols-3 gap-3 text-[10px]">
                <div>
                  <div className="text-muted-foreground">12-wk change</div>
                  <div className={cn("font-semibold tabular-nums", delta <= 0 ? "text-success" : "text-friction")}>
                    {delta > 0 ? "+" : ""}<AnimatedNumber value={delta} duration={1.2} /> pts
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Best week</div>
                  <div className="font-semibold text-success tabular-nums">
                    <AnimatedNumber value={Math.min(...TREND_SERIES.map((d) => d.friction))} duration={1.2} />
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Latest</div>
                  <div className="font-semibold text-ink tabular-nums"><AnimatedNumber value={latestFriction} duration={1.2} /></div>
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Friction hotspots</div>
                  <div className="text-[11px] text-muted-foreground">Top 5 by intensity</div>
                </div>
                <Zap className="h-4 w-4 text-friction" />
              </div>
              <div className="space-y-2.5">
                {HOTSPOTS.map((h, i) => {
                  const color =
                    h.intensity >= 85 ? "var(--friction)" : h.intensity >= 65 ? "var(--warning)" : "var(--info)";
                  return (
                    <div key={i} className="space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-xs font-medium text-ink truncate">{h.screen}</div>
                          <div className="text-[10px] text-muted-foreground truncate">
                            {h.project} · {h.type}
                          </div>
                        </div>
                        <span
                          className="text-[10px] font-semibold tabular-nums px-1.5 py-0.5 rounded flex-shrink-0"
                          style={{ background: `color-mix(in oklch, ${color} 15%, transparent)`, color }}
                        >
                          <AnimatedNumber value={h.intensity} duration={1.2} />
                        </span>
                      </div>
                      <ProgressBar
                        value={h.intensity}
                        color={color}
                        trackColor="var(--surface-2)"
                        height={6}
                        delay={0.1 + i * 0.08}
                      />
                    </div>
                  );
                })}
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="w-full mt-3 text-[11px] h-8"
                onClick={() => toast.message("Opening full hotspot map")}
              >
                View all hotspots →
              </Button>
            </Card>
          </div>

          {/* Bottom: friction types breakdown */}
          <DataTable
            data={FRICTION_TYPES}
            columns={columns}
            getRowId={(row) => row.id}
            pageSize={5}
            searchable
            searchPlaceholder="Search friction types…"
            searchKeys={["type"]}
            emptyTitle="No friction types found"
            emptyDescription="Try adjusting your search."
          />
        </>
      )}
    </div>
  );
}
