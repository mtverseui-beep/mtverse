"use client";

import * as React from "react";
import {
  BrainCircuit,
  Gauge,
  SplitSquareHorizontal,
  Timer,
  AlertTriangle,
  Download,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { AGGREGATE_UX } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const TASKS = [
  "Create first wallet",
  "Complete KYC",
  "Schedule transfer",
  "Invite teammate",
  "Cancel booking",
];

const STEPS = ["Step 1", "Step 2", "Step 3", "Step 4", "Step 5"];

// 5x5 cognitive load matrix (0-100, higher = more load)
const LOAD_MATRIX: number[][] = [
  [22, 38, 64, 71, 28], // Create first wallet
  [18, 42, 88, 76, 34], // Complete KYC (worst at step 3)
  [25, 48, 56, 62, 30], // Schedule transfer
  [16, 28, 35, 22, 14], // Invite teammate
  [20, 32, 44, 38, 26], // Cancel booking
];

const HIGH_LOAD_SCREENS = [
  {
    name: "KYC document upload",
    task: "Complete KYC",
    step: "Step 3",
    load: 88,
    cause: "Dense form with 3 decisions on one screen",
  },
  {
    name: "Wallet seed phrase review",
    task: "Create first wallet",
    step: "Step 4",
    load: 71,
    cause: "12-word phrase shown without chunking",
  },
  {
    name: "Transfer review summary",
    task: "Schedule transfer",
    step: "Step 4",
    load: 62,
    cause: "4 CTAs + amount + fees + recipient on one view",
  },
];

interface TaskComplexity {
  id: string;
  task: string;
  decisions: number;
  screens: number;
  avgLoad: number;
  timeOnTask: string;
  mentalMismatch: number;
  status: "optimize" | "monitor" | "ok";
}

const COMPLEXITY: TaskComplexity[] = [
  { id: "tc-1", task: "Complete KYC", decisions: 9, screens: 4, avgLoad: 52, timeOnTask: "4:18", mentalMismatch: 31, status: "optimize" },
  { id: "tc-2", task: "Schedule transfer", decisions: 7, screens: 5, avgLoad: 44, timeOnTask: "3:24", mentalMismatch: 22, status: "optimize" },
  { id: "tc-3", task: "Create first wallet", decisions: 6, screens: 5, avgLoad: 41, timeOnTask: "3:42", mentalMismatch: 24, status: "monitor" },
  { id: "tc-4", task: "Cancel booking", decisions: 3, screens: 3, avgLoad: 32, timeOnTask: "1:14", mentalMismatch: 12, status: "ok" },
  { id: "tc-5", task: "Invite teammate", decisions: 2, screens: 2, avgLoad: 23, timeOnTask: "0:48", mentalMismatch: 8, status: "ok" },
  { id: "tc-6", task: "Manage notifications", decisions: 4, screens: 3, avgLoad: 35, timeOnTask: "1:56", mentalMismatch: 14, status: "monitor" },
];

function loadColor(load: number) {
  if (load >= 70) return "var(--friction)";
  if (load >= 50) return "var(--warning)";
  if (load >= 30) return "var(--info)";
  return "var(--success)";
}

function loadLabel(load: number) {
  if (load >= 70) return "High";
  if (load >= 50) return "Elevated";
  if (load >= 30) return "Moderate";
  return "Low";
}

export default function CognitiveLoadMetricsPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const columns: Column<TaskComplexity>[] = [
    {
      key: "task",
      header: "Task",
      cell: (row) => <span className="text-xs font-medium text-ink">{row.task}</span>,
      sortAccessor: (row) => row.task,
      sortable: true,
    },
    {
      key: "decisions",
      header: "Decisions",
      cell: (row) => <span className="text-xs tabular-nums">{row.decisions}</span>,
      sortAccessor: (row) => row.decisions,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "screens",
      header: "Screens",
      cell: (row) => <span className="text-xs tabular-nums">{row.screens}</span>,
      sortAccessor: (row) => row.screens,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "avgLoad",
      header: "Avg load",
      cell: (row) => {
        const color = loadColor(row.avgLoad);
        return (
          <div className="flex items-center gap-2">
            <div className="h-1.5 w-12 rounded-full bg-surface-2 overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${row.avgLoad}%`, background: color }} />
            </div>
            <span className="text-xs font-medium tabular-nums" style={{ color }}>{row.avgLoad}</span>
          </div>
        );
      },
      sortAccessor: (row) => row.avgLoad,
      sortable: true,
    },
    {
      key: "timeOnTask",
      header: "Avg time",
      cell: (row) => <span className="text-xs font-mono tabular-nums">{row.timeOnTask}</span>,
      sortAccessor: (row) => row.timeOnTask,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "mentalMismatch",
      header: "Model mismatch",
      cell: (row) => (
        <span
          className={cn(
            "text-xs font-medium tabular-nums",
            row.mentalMismatch >= 25 ? "text-friction" : row.mentalMismatch >= 15 ? "text-warning" : "text-success"
          )}
        >
          {row.mentalMismatch}%
        </span>
      ),
      sortAccessor: (row) => row.mentalMismatch,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (row) => (
        <Badge
          variant="outline"
          className={cn(
            "text-[10px] capitalize",
            row.status === "optimize" && "border-friction/20 bg-friction/10 text-friction",
            row.status === "monitor" && "border-warning/20 bg-warning/10 text-warning",
            row.status === "ok" && "border-success/20 bg-success/10 text-success"
          )}
        >
          {row.status === "ok" ? "Healthy" : row.status === "monitor" ? "Monitor" : "Optimize"}
        </Badge>
      ),
      sortAccessor: (row) => row.status,
      sortable: true,
    },
  ];

  return (
    <div>
      <PageHeader
        title="Cognitive Load Metrics"
        description="Time-to-first-action, decision fatigue, mental model alignment"
        breadcrumbs={[{ label: "Metrics" }, { label: "Cognitive Load" }]}
        icon={<BrainCircuit className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            Load index {AGGREGATE_UX.cognitiveLoad}
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Cognitive load study exported")}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export study
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Avg cognitive load"
              value="64"
              unit="/100"
              icon={<Gauge className="h-4 w-4" />}
              accent="warning"
              trend={{ value: 4.2, direction: "down", good: true }}
              sublabel="lower is better"
            />
            <StatCard
              label="Decision points/task"
              value="5.2"
              icon={<SplitSquareHorizontal className="h-4 w-4" />}
              accent="info"
              trend={{ value: 0.6, direction: "down", good: true }}
              sublabel="benchmark 3.8"
            />
            <StatCard
              label="Time-to-first-action"
              value="8s"
              icon={<Timer className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 1.2, direction: "down", good: true }}
              sublabel="median session"
            />
            <StatCard
              label="Mental model mismatch"
              value="18%"
              icon={<AlertTriangle className="h-4 w-4" />}
              accent="warning"
              trend={{ value: 3.0, direction: "down", good: true }}
              sublabel="vs mental model test"
            />
          </div>

          {/* Heatmap + high-load screens */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Cognitive load heatmap</div>
                  <div className="text-[11px] text-muted-foreground">5 tasks × 5 steps · color = load intensity</div>
                </div>
                <div className="flex items-center gap-2 text-[10px]">
                  <span className="text-muted-foreground">Low</span>
                  <div className="flex h-2 w-24 rounded-full overflow-hidden">
                    <div className="flex-1" style={{ background: "var(--success)" }} />
                    <div className="flex-1" style={{ background: "var(--info)" }} />
                    <div className="flex-1" style={{ background: "var(--warning)" }} />
                    <div className="flex-1" style={{ background: "var(--friction)" }} />
                  </div>
                  <span className="text-muted-foreground">High</span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <div className="min-w-[480px]">
                  {/* Column headers */}
                  <div className="grid grid-cols-[180px_repeat(5,1fr)] gap-2 mb-2">
                    <div />
                    {STEPS.map((s) => (
                      <div key={s} className="text-center text-[10px] font-medium text-muted-foreground">
                        {s}
                      </div>
                    ))}
                  </div>
                  {/* Rows */}
                  {TASKS.map((task, ti) => (
                    <div key={task} className="grid grid-cols-[180px_repeat(5,1fr)] gap-2 mb-2 items-center">
                      <div className="text-xs font-medium text-ink truncate pr-2">{task}</div>
                      {LOAD_MATRIX[ti].map((load, si) => {
                        const color = loadColor(load);
                        return (
                          <button
                            key={`${ti}-${si}`}
                            className="group relative h-12 rounded-lg flex items-center justify-center text-[11px] font-semibold text-white transition-transform hover:scale-[1.04] focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                            style={{
                              background: `color-mix(in oklch, ${color} ${50 + load / 2}%, var(--card))`,
                              color: load >= 50 ? "var(--card)" : "var(--card-foreground)",
                            }}
                            onClick={() => toast.message(`${task} · ${STEPS[si]}`, { description: `${loadLabel(load)} cognitive load · index ${load}` })}
                            title={`${task} · ${STEPS[si]} — ${loadLabel(load)} (${load})`}
                          >
                            {load}
                          </button>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-soft grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                {[
                  { label: "Low (0-29)", color: "var(--success)", count: LOAD_MATRIX.flat().filter((v) => v < 30).length },
                  { label: "Moderate (30-49)", color: "var(--info)", count: LOAD_MATRIX.flat().filter((v) => v >= 30 && v < 50).length },
                  { label: "Elevated (50-69)", color: "var(--warning)", count: LOAD_MATRIX.flat().filter((v) => v >= 50 && v < 70).length },
                  { label: "High (70+)", color: "var(--friction)", count: LOAD_MATRIX.flat().filter((v) => v >= 70).length },
                ].map((b) => (
                  <div key={b.label} className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-sm" style={{ background: b.color }} />
                    <span className="text-muted-foreground">{b.label}</span>
                    <span className="ml-auto font-semibold text-ink tabular-nums">{b.count}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">High-load screens</div>
                  <div className="text-[11px] text-muted-foreground">Top 3 — needs simplification</div>
                </div>
                <BrainCircuit className="h-4 w-4 text-friction" />
              </div>
              <div className="space-y-3">
                {HIGH_LOAD_SCREENS.map((s, i) => {
                  const color = loadColor(s.load);
                  return (
                    <div
                      key={s.name}
                      className="p-3 rounded-lg border border-soft bg-surface-2/40 hover:bg-surface-2/70 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="inline-flex items-center justify-center h-5 w-5 rounded-md bg-friction/15 text-friction text-[10px] font-bold flex-shrink-0">
                              #{i + 1}
                            </span>
                            <span className="text-xs font-semibold text-ink truncate">{s.name}</span>
                          </div>
                          <div className="text-[10px] text-muted-foreground mt-0.5 ml-6">
                            {s.task} · {s.step}
                          </div>
                        </div>
                        <span
                          className="text-xs font-semibold tabular-nums px-2 py-0.5 rounded-md flex-shrink-0"
                          style={{ background: `color-mix(in oklch, ${color} 15%, transparent)`, color }}
                        >
                          {s.load}
                        </span>
                      </div>
                      <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden mt-2">
                        <div className="h-full rounded-full" style={{ width: `${s.load}%`, background: color }} />
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-2 leading-snug">{s.cause}</div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>

          {/* Bottom: task complexity table */}
          <DataTable
            data={COMPLEXITY}
            columns={columns}
            getRowId={(row) => row.id}
            pageSize={6}
            searchable
            searchPlaceholder="Search tasks…"
            searchKeys={["task"]}
            emptyTitle="No tasks found"
            emptyDescription="Try adjusting your search."
          />
        </>
      )}
    </div>
  );
}
