"use client";

import * as React from "react";
import {
  Workflow,
  ArrowRight,
  Users,
  TrendingDown,
  Zap,
  Lightbulb,
  Download,
  ArrowDown,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AGGREGATE_UX } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface TaskOption {
  id: string;
  name: string;
  project: string;
}

const TASKS: TaskOption[] = [
  { id: "tf-1", name: "Create first wallet", project: "Atlas Onboarding" },
  { id: "tf-2", name: "Complete KYC verification", project: "Atlas Onboarding" },
  { id: "tf-3", name: "Checkout as guest", project: "Northwind Checkout" },
  { id: "tf-4", name: "Find and book a trip", project: "Voyage Booking" },
  { id: "tf-5", name: "Set up recurring transfer", project: "Atlas Onboarding" },
];

// Flow steps per task — keyed by task id
const FLOWS: Record<string, { name: string; users: number; conversion: number; friction: number; dropOff?: number }[]> = {
  "tf-1": [
    { name: "Welcome", users: 12480, conversion: 100, friction: 12 },
    { name: "Email verify", users: 9420, conversion: 75, friction: 24, dropOff: 25 },
    { name: "Wallet setup", users: 6810, conversion: 55, friction: 38, dropOff: 28 },
    { name: "Seed backup", users: 4150, conversion: 33, friction: 72, dropOff: 39 },
    { name: "Done", users: 3120, conversion: 25, friction: 14, dropOff: 25 },
  ],
  "tf-2": [
    { name: "Start KYC", users: 8240, conversion: 100, friction: 18 },
    { name: "Personal info", users: 6920, conversion: 84, friction: 28, dropOff: 16 },
    { name: "Document upload", users: 4180, conversion: 51, friction: 88, dropOff: 40 },
    { name: "Liveness check", users: 3120, conversion: 38, friction: 46, dropOff: 25 },
    { name: "Verified", users: 2780, conversion: 34, friction: 12, dropOff: 11 },
  ],
  "tf-3": [
    { name: "View cart", users: 6240, conversion: 100, friction: 8 },
    { name: "Address", users: 5410, conversion: 87, friction: 22, dropOff: 13 },
    { name: "Shipping", users: 4820, conversion: 77, friction: 34, dropOff: 11 },
    { name: "Payment", users: 3980, conversion: 64, friction: 41, dropOff: 17 },
    { name: "Confirmed", users: 3420, conversion: 55, friction: 12, dropOff: 15 },
  ],
  "tf-4": [
    { name: "Search", users: 9840, conversion: 100, friction: 14 },
    { name: "Results", users: 7120, conversion: 72, friction: 32, dropOff: 28 },
    { name: "Trip detail", users: 5180, conversion: 53, friction: 38, dropOff: 27 },
    { name: "Book", users: 3120, conversion: 32, friction: 52, dropOff: 40 },
    { name: "Confirmed", users: 2480, conversion: 25, friction: 16, dropOff: 20 },
  ],
  "tf-5": [
    { name: "Pick recipient", users: 4180, conversion: 100, friction: 16 },
    { name: "Amount + freq", users: 3420, conversion: 82, friction: 28, dropOff: 18 },
    { name: "Schedule", users: 2810, conversion: 67, friction: 36, dropOff: 18 },
    { name: "Review", users: 2180, conversion: 52, friction: 48, dropOff: 22 },
    { name: "Confirmed", users: 1840, conversion: 44, friction: 12, dropOff: 16 },
  ],
};

const INSIGHTS_BY_TASK: Record<string, { title: string; detail: string; severity: "critical" | "high" | "medium" }[]> = {
  "tf-1": [
    { title: "Seed backup causes 39% drop-off", detail: "12-word phrase shown without chunking. Users hesitate 22s on average.", severity: "critical" },
    { title: "Wallet setup has 38 friction index", detail: "Three sequential password requirements confuse first-timers. Inline validation would help.", severity: "high" },
    { title: "Email verify loses 25% of users", detail: "Verification email goes to spam for 8% of Outlook users. Add magic link fallback.", severity: "medium" },
  ],
  "tf-2": [
    { title: "Document upload is the killer step", detail: "88 friction index — single dense form with 3 decisions on screens < 414px.", severity: "critical" },
    { title: "Liveness check adds 25% drop-off", detail: "Camera permission prompt appears too late and lacks pre-prompt explanation.", severity: "high" },
    { title: "Personal info step has minor friction", detail: "Country picker is unsearchable. Users scroll through 200+ entries.", severity: "medium" },
  ],
  "tf-3": [
    { title: "Payment step loses 17% of users", detail: "Credit card fields lack auto-detection and inline formatting.", severity: "high" },
    { title: "Shipping choice creates decision fatigue", detail: "4 options shown with no recommendation. Default highlight would lift conversion.", severity: "medium" },
    { title: "Address autocomplete underused", detail: "32% of users type manually due to unclear autocomplete affordance.", severity: "medium" },
  ],
  "tf-4": [
    { title: "Booking step drops 40%", detail: "Price summary reveals fees late. Surface estimated total earlier.", severity: "critical" },
    { title: "Result filters too hard to find", detail: "Hidden behind an icon — 44% scroll past page 5 instead.", severity: "high" },
    { title: "Trip detail page loads slowly", detail: "3.2s LCP on 3G. Lazy-load images below fold.", severity: "medium" },
  ],
  "tf-5": [
    { title: "Review screen causes 22% drop-off", detail: "4 CTAs compete for attention. Eye-tracking shows 2.8s hesitation.", severity: "high" },
    { title: "Schedule picker is non-obvious", detail: "Frequency dropdown defaults to 'one-time'. Add toggle for recurring.", severity: "medium" },
    { title: "Recipient lookup is manual", detail: "No contacts integration. Users re-type IBAN each time.", severity: "medium" },
  ],
};

interface Opportunity {
  id: string;
  title: string;
  step: string;
  impact: number;
  effort: "S" | "M" | "L";
  score: number;
  type: "UX fix" | "Content" | "A/B test" | "Refactor";
}

const OPPORTUNITIES_BY_TASK: Record<string, Opportunity[]> = {
  "tf-1": [
    { id: "op-1", title: "Chunk seed phrase into groups of 3", step: "Seed backup", impact: 92, effort: "S", score: 46, type: "UX fix" },
    { id: "op-2", title: "Inline password requirements with live checks", step: "Wallet setup", impact: 76, effort: "S", score: 38, type: "UX fix" },
    { id: "op-3", title: "Add magic-link fallback to email verify", step: "Email verify", impact: 64, effort: "M", score: 21, type: "Refactor" },
    { id: "op-4", title: "A/B test seed backup vs social recovery", step: "Seed backup", impact: 81, effort: "L", score: 16, type: "A/B test" },
    { id: "op-5", title: "Reword 'backup' → 'safety net' copy", step: "Seed backup", impact: 38, effort: "S", score: 19, type: "Content" },
  ],
  "tf-2": [
    { id: "op-1", title: "Split document upload into 3 progressive steps", step: "Document upload", impact: 94, effort: "L", score: 31, type: "UX fix" },
    { id: "op-2", title: "Add searchable country picker", step: "Personal info", impact: 58, effort: "S", score: 29, type: "UX fix" },
    { id: "op-3", title: "Pre-prompt for camera permission", step: "Liveness check", impact: 72, effort: "S", score: 36, type: "Content" },
    { id: "op-4", title: "Auto-crop document with ML detection", step: "Document upload", impact: 68, effort: "M", score: 23, type: "Refactor" },
    { id: "op-5", title: "A/B test camera-first vs file-first capture", step: "Document upload", impact: 76, effort: "M", score: 25, type: "A/B test" },
  ],
  "tf-3": [
    { id: "op-1", title: "Add inline card formatting + brand detection", step: "Payment", impact: 84, effort: "S", score: 42, type: "UX fix" },
    { id: "op-2", title: "Default-highlight recommended shipping option", step: "Shipping", impact: 62, effort: "S", score: 31, type: "UX fix" },
    { id: "op-3", title: "Surface autocomplete chip above address field", step: "Address", impact: 71, effort: "S", score: 36, type: "Content" },
    { id: "op-4", title: "A/B test 1-page vs 3-page checkout", step: "Payment", impact: 88, effort: "L", score: 29, type: "A/B test" },
    { id: "op-5", title: "Lazy-load trust badges below fold", step: "Payment", impact: 42, effort: "S", score: 21, type: "Refactor" },
  ],
  "tf-4": [
    { id: "op-1", title: "Surface estimated total on trip detail", step: "Trip detail", impact: 91, effort: "M", score: 30, type: "UX fix" },
    { id: "op-2", title: "Add labeled 'Filters' chip with active count", step: "Results", impact: 78, effort: "S", score: 39, type: "UX fix" },
    { id: "op-3", title: "Lazy-load images below fold", step: "Trip detail", impact: 54, effort: "S", score: 27, type: "Refactor" },
    { id: "op-4", title: "A/B test sticky book button on mobile", step: "Trip detail", impact: 68, effort: "S", score: 34, type: "A/B test" },
    { id: "op-5", title: "Reword fee disclosure copy", step: "Book", impact: 46, effort: "S", score: 23, type: "Content" },
  ],
  "tf-5": [
    { id: "op-1", title: "Reduce review screen CTAs to 2", step: "Review", impact: 82, effort: "S", score: 41, type: "UX fix" },
    { id: "op-2", title: "Add 'Recurring' toggle on amount step", step: "Amount + freq", impact: 64, effort: "S", score: 32, type: "UX fix" },
    { id: "op-3", title: "Integrate contacts API for recipient lookup", step: "Pick recipient", impact: 72, effort: "L", score: 24, type: "Refactor" },
    { id: "op-4", title: "A/B test review vs inline confirm merge", step: "Review", impact: 86, effort: "M", score: 29, type: "A/B test" },
    { id: "op-5", title: "Add IBAN paste hint with validation", step: "Pick recipient", impact: 48, effort: "S", score: 24, type: "Content" },
  ],
};

function frictionColor(f: number) {
  if (f >= 60) return "var(--friction)";
  if (f >= 35) return "var(--warning)";
  if (f >= 20) return "var(--info)";
  return "var(--success)";
}

function frictionLabel(f: number) {
  if (f >= 60) return "High";
  if (f >= 35) return "Elevated";
  if (f >= 20) return "Moderate";
  return "Low";
}

export default function TaskFlowPage() {
  const [taskId, setTaskId] = React.useState<string>("tf-1");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const task = TASKS.find((t) => t.id === taskId)!;
  const flow = FLOWS[taskId];
  const insights = INSIGHTS_BY_TASK[taskId];
  const opportunities = OPPORTUNITIES_BY_TASK[taskId];

  // Aggregate KPIs from selected flow
  const startUsers = flow[0].users;
  const endUsers = flow[flow.length - 1].users;
  const overallConversion = Math.round((endUsers / startUsers) * 100);
  const avgFriction = Math.round(flow.reduce((a, b) => a + b.friction, 0) / flow.length);
  const biggestDrop = Math.max(...flow.map((s) => s.dropOff ?? 0));

  const oppColumns: Column<Opportunity>[] = [
    {
      key: "title",
      header: "Opportunity",
      cell: (row) => (
        <div className="min-w-0">
          <div className="text-xs font-medium text-ink truncate">{row.title}</div>
          <div className="text-[10px] text-muted-foreground">{row.step}</div>
        </div>
      ),
      sortAccessor: (row) => row.title,
      sortable: true,
    },
    {
      key: "type",
      header: "Type",
      cell: (row) => (
        <Badge variant="secondary" className="text-[10px]">
          {row.type}
        </Badge>
      ),
      sortAccessor: (row) => row.type,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "impact",
      header: "Impact",
      cell: (row) => {
        const color = row.impact >= 80 ? "var(--friction)" : row.impact >= 60 ? "var(--warning)" : "var(--info)";
        return (
          <div className="flex items-center gap-2">
            <div className="h-1.5 w-14 rounded-full bg-surface-2 overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${row.impact}%`, background: color }} />
            </div>
            <span className="text-xs font-medium tabular-nums">{row.impact}</span>
          </div>
        );
      },
      sortAccessor: (row) => row.impact,
      sortable: true,
    },
    {
      key: "effort",
      header: "Effort",
      cell: (row) => {
        const color = row.effort === "S" ? "var(--success)" : row.effort === "M" ? "var(--warning)" : "var(--friction)";
        return (
          <span
            className="inline-flex items-center justify-center h-5 w-5 rounded-md text-[10px] font-bold"
            style={{ background: `color-mix(in oklch, ${color} 15%, transparent)`, color }}
          >
            {row.effort}
          </span>
        );
      },
      sortAccessor: (row) => row.effort,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "score",
      header: "ICE score",
      cell: (row) => {
        const color = row.score >= 35 ? "var(--success)" : row.score >= 20 ? "var(--warning)" : "var(--info)";
        return (
          <span className="text-xs font-semibold tabular-nums" style={{ color }}>
            {row.score}
          </span>
        );
      },
      sortAccessor: (row) => row.score,
      sortable: true,
    },
  ];

  return (
    <div>
      <PageHeader
        title="Task Flow Analysis"
        description="Multi-step task performance with friction overlay and improvement opportunities"
        breadcrumbs={[{ label: "Metrics" }, { label: "Task Flow" }]}
        icon={<Workflow className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {TASKS.length} flows mapped
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success(`Task flow exported — ${task.name}`)}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export flow
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Task selector + KPIs */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-3 mb-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-1">
              <div className="text-[10px] font-medium text-muted-foreground mb-2">Select task flow</div>
              <Select value={taskId} onValueChange={(v) => { setTaskId(v); toast.message(`Loaded flow: ${TASKS.find((t) => t.id === v)?.name}`); }}>
                <SelectTrigger className="w-full" size="sm">
                  <SelectValue placeholder="Pick a task" />
                </SelectTrigger>
                <SelectContent>
                  {TASKS.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="mt-3 text-[10px] text-muted-foreground">
                Project · <span className="text-ink font-medium">{task.project}</span>
              </div>
              <div className="mt-3 pt-3 border-t border-soft grid grid-cols-2 gap-2 text-[10px]">
                <div>
                  <div className="text-muted-foreground">Steps</div>
                  <div className="font-semibold text-ink">{flow.length}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Total users</div>
                  <div className="font-semibold text-ink">{startUsers.toLocaleString()}</div>
                </div>
              </div>
            </Card>

            <StatCard
              label="Overall conversion"
              value={`${overallConversion}%`}
              icon={<Workflow className="h-4 w-4" />}
              accent={overallConversion >= 50 ? "success" : overallConversion >= 30 ? "warning" : "friction"}
              sublabel={`${endUsers.toLocaleString()} of ${startUsers.toLocaleString()} users`}
            />
            <StatCard
              label="Avg friction"
              value={avgFriction}
              unit="/100"
              icon={<Zap className="h-4 w-4" />}
              accent={avgFriction >= 50 ? "friction" : avgFriction >= 30 ? "warning" : "success"}
              sublabel={`across ${flow.length} steps`}
            />
            <StatCard
              label="Biggest step drop"
              value={`${biggestDrop}%`}
              icon={<TrendingDown className="h-4 w-4" />}
              accent={biggestDrop >= 35 ? "friction" : biggestDrop >= 20 ? "warning" : "success"}
              sublabel="single-step loss"
            />
          </div>

          {/* Flow visualization + insights */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-3">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-sm font-semibold text-ink">Step-by-step flow</div>
                  <div className="text-[11px] text-muted-foreground">{task.name} · friction overlay</div>
                </div>
                <Badge variant="outline" className="text-[10px]">
                  {endUsers.toLocaleString()} complete
                </Badge>
              </div>

              {/* Desktop horizontal flow */}
              <div className="hidden md:flex items-stretch gap-1 overflow-x-auto pb-2">
                {flow.map((s, i) => {
                  const color = frictionColor(s.friction);
                  return (
                    <React.Fragment key={s.name}>
                      <div className="flex-1 min-w-[150px] rounded-xl border border-soft bg-surface-2/40 p-3 flex flex-col gap-2 hover:bg-surface-2/70 transition-colors">
                        <div className="flex items-center justify-between">
                          <span className="inline-flex items-center justify-center h-5 w-5 rounded-md bg-surface text-[10px] font-semibold text-ink">
                            {i + 1}
                          </span>
                          <span
                            className="inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded"
                            style={{ background: `color-mix(in oklch, ${color} 15%, transparent)`, color }}
                          >
                            <Zap className="h-2.5 w-2.5" />
                            {frictionLabel(s.friction)}
                          </span>
                        </div>
                        <div className="text-xs font-semibold text-ink truncate">{s.name}</div>
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="text-muted-foreground flex items-center gap-1">
                              <Users className="h-2.5 w-2.5" /> Users
                            </span>
                            <span className="font-semibold text-ink tabular-nums">{s.users.toLocaleString()}</span>
                          </div>
                          <div className="flex items-center justify-between text-[10px]">
                            <span className="text-muted-foreground">Conv.</span>
                            <span className="font-semibold text-ink tabular-nums">{s.conversion}%</span>
                          </div>
                          <div className="h-1 rounded-full bg-surface overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${s.conversion}%`, background: "var(--info)" }} />
                          </div>
                        </div>
                        {s.dropOff !== undefined && (
                          <div className="text-[10px] text-friction flex items-center gap-0.5">
                            <ArrowDown className="h-2.5 w-2.5" /> {s.dropOff}% drop
                          </div>
                        )}
                      </div>
                      {i < flow.length - 1 && (
                        <div className="flex items-center justify-center self-center">
                          <ArrowRight className="h-4 w-4 text-muted-foreground" />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>

              {/* Mobile vertical flow */}
              <div className="md:hidden space-y-2">
                {flow.map((s, i) => {
                  const color = frictionColor(s.friction);
                  return (
                    <React.Fragment key={s.name}>
                      <div className="rounded-xl border border-soft bg-surface-2/40 p-3 flex items-center gap-3">
                        <span className="inline-flex items-center justify-center h-7 w-7 rounded-md bg-surface text-[11px] font-semibold text-ink flex-shrink-0">
                          {i + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-semibold text-ink truncate">{s.name}</span>
                            <span
                              className="inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded flex-shrink-0"
                              style={{ background: `color-mix(in oklch, ${color} 15%, transparent)`, color }}
                            >
                              <Zap className="h-2.5 w-2.5" />
                              {frictionLabel(s.friction)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-[10px] text-muted-foreground mt-1">
                            <span><Users className="h-2.5 w-2.5 inline mr-0.5" />{s.users.toLocaleString()}</span>
                            <span>{s.conversion}% conv.</span>
                            {s.dropOff !== undefined && <span className="text-friction">↓ {s.dropOff}%</span>}
                          </div>
                        </div>
                      </div>
                      {i < flow.length - 1 && (
                        <div className="flex justify-center">
                          <ArrowDown className="h-3 w-3 text-muted-foreground" />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Flow insights</div>
                  <div className="text-[11px] text-muted-foreground">Top 3 — by severity</div>
                </div>
                <Lightbulb className="h-4 w-4 text-warning" />
              </div>
              <div className="space-y-2.5">
                {insights.map((ins, i) => (
                  <div
                    key={i}
                    className={cn(
                      "p-2.5 rounded-lg border bg-surface-2/40",
                      ins.severity === "critical"
                        ? "border-friction/20"
                        : ins.severity === "high"
                        ? "border-warning/20"
                        : "border-info/20"
                    )}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Badge
                        variant="outline"
                        className={cn(
                          "text-[9px] capitalize",
                          ins.severity === "critical" && "border-friction/20 bg-friction/10 text-friction",
                          ins.severity === "high" && "border-warning/20 bg-warning/10 text-warning",
                          ins.severity === "medium" && "border-info/20 bg-info/10 text-info"
                        )}
                      >
                        {ins.severity}
                      </Badge>
                    </div>
                    <div className="text-xs font-medium text-ink leading-snug mb-1">{ins.title}</div>
                    <div className="text-[10px] text-muted-foreground leading-relaxed line-clamp-3">
                      {ins.detail}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Bottom: optimization opportunities */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="text-sm font-semibold text-ink">Optimization opportunities</div>
                <div className="text-[11px] text-muted-foreground">
                  ICE-scored · impact × confidence ÷ effort
                </div>
              </div>
              <Badge variant="outline" className="text-[10px]">
                {opportunities.length} opportunities
              </Badge>
            </div>
            <DataTable
              data={opportunities}
              columns={oppColumns}
              getRowId={(row) => row.id}
              pageSize={5}
              searchable
              searchPlaceholder="Search opportunities…"
              searchKeys={["title", "step"]}
              emptyTitle="No opportunities found"
              emptyDescription="Try adjusting your search."
            />
          </div>
        </>
      )}
    </div>
  );
}
