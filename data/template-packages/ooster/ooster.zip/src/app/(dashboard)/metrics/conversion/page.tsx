"use client";

import * as React from "react";
import {
  TrendingUp,
  ShoppingCart,
  CheckCircle2,
  Timer,
  Download,
  Filter,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { INSIGHTS, AGGREGATE_UX } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { AnimatedNumber, ProgressBar, ActiveDot } from "@/components/common/animated-progress";

const FUNNEL_STEPS = [
  { step: "Visit landing", users: 12480, pct: 100 },
  { step: "View product", users: 8920, pct: 71.5 },
  { step: "Add to cart", users: 4310, pct: 34.5 },
  { step: "Begin checkout", users: 2480, pct: 19.9 },
  { step: "Complete order", users: 1373, pct: 11.0 },
];

interface ChannelRow {
  id: string;
  channel: string;
  sessions: number;
  conversion: number;
  avgValue: string;
  dropOff: number;
}

const CHANNELS: ChannelRow[] = [
  { id: "ch-1", channel: "Direct", sessions: 4820, conversion: 14.2, avgValue: "$92", dropOff: 22 },
  { id: "ch-2", channel: "Organic search", sessions: 6310, conversion: 12.8, avgValue: "$78", dropOff: 28 },
  { id: "ch-3", channel: "Paid social", sessions: 3940, conversion: 8.1, avgValue: "$84", dropOff: 41 },
  { id: "ch-4", channel: "Email", sessions: 2150, conversion: 18.4, avgValue: "$103", dropOff: 14 },
  { id: "ch-5", channel: "Referral", sessions: 1680, conversion: 10.6, avgValue: "$71", dropOff: 33 },
];

export default function ConversionMetricsPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  // Pull conversion blockers from INSIGHTS where category=conversion,
  // then augment with related friction/blocker entries to reach top 3.
  const blockers = React.useMemo(() => {
    const fromInsights = INSIGHTS.filter((i) => i.category === "conversion").map((i) => ({
      id: i.id,
      title: i.title,
      detail: i.recommendation,
      impact: i.impact,
      href: `/insights/${i.id}`,
    }));
    const supplemental = [
      {
        id: "cb-mock-1",
        title: "Account creation required mid-checkout",
        detail: "62% of guest users abandon at the email/password wall. Offering 'continue as guest' would recover an estimated 8% of lost orders.",
        impact: 78,
        href: "/insights/i-008",
      },
      {
        id: "cb-mock-2",
        title: "Shipping cost revealed only at final review",
        detail: "Late-fee surprise drives 31% of checkout bounces. Surface estimated shipping on the cart page before asking for payment.",
        impact: 73,
        href: "/insights/i-001",
      },
    ];
    return [...fromInsights, ...supplemental].slice(0, 3);
  }, []);

  const channelColumns: Column<ChannelRow>[] = [
    {
      key: "channel",
      header: "Channel",
      cell: (row) => <span className="text-xs font-medium text-ink">{row.channel}</span>,
      sortAccessor: (row) => row.channel,
      sortable: true,
    },
    {
      key: "sessions",
      header: "Sessions",
      cell: (row) => <span className="text-xs tabular-nums">{row.sessions.toLocaleString()}</span>,
      sortAccessor: (row) => row.sessions,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "conversion",
      header: "Conversion",
      cell: (row) => {
        const color = row.conversion >= 12 ? "var(--success)" : row.conversion >= 8 ? "var(--warning)" : "var(--friction)";
        return (
          <div className="flex items-center gap-2">
            <ProgressBar
              value={(row.conversion / 20) * 100}
              color={color}
              trackColor="var(--surface-2)"
              height={6}
              className="w-14"
              showLabel={false}
            />
            <span className="text-xs font-medium tabular-nums">{row.conversion}%</span>
          </div>
        );
      },
      sortAccessor: (row) => row.conversion,
      sortable: true,
    },
    {
      key: "avgValue",
      header: "Avg cart",
      cell: (row) => <span className="text-xs tabular-nums">{row.avgValue}</span>,
      sortAccessor: (row) => row.avgValue,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "dropOff",
      header: "Drop-off",
      cell: (row) => (
        <Badge
          variant="outline"
          className={cn(
            "text-[10px]",
            row.dropOff >= 35
              ? "border-friction/20 bg-friction/10 text-friction"
              : row.dropOff >= 25
              ? "border-warning/20 bg-warning/10 text-warning"
              : "border-success/20 bg-success/10 text-success"
          )}
        >
          {row.dropOff}%
        </Badge>
      ),
      sortAccessor: (row) => row.dropOff,
      sortable: true,
    },
  ];

  return (
    <div>
      <PageHeader
        title="Conversion Metrics"
        description="Funnel conversion, drop-off points, and conversion friction analysis"
        breadcrumbs={[{ label: "Metrics" }, { label: "Conversion" }]}
        icon={<TrendingUp className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            UX {AGGREGATE_UX.conversion}/100
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Funnel analysis exported")}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export funnel
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Overall conversion"
              value={11}
              unit="%"
              animate
              icon={<TrendingUp className="h-4 w-4" />}
              accent="success"
              trend={{ value: 1.4, direction: "up", good: true }}
              sublabel="across all funnels"
            >
              <div className="mt-2 flex items-center gap-1.5 text-[10px] font-medium text-success">
                <ActiveDot color="var(--success)" size={6} />
                Live conversion
              </div>
            </StatCard>
            <StatCard
              label="Avg cart value"
              value="$84"
              icon={<ShoppingCart className="h-4 w-4" />}
              accent="info"
              trend={{ value: 3.6, direction: "up", good: true }}
              sublabel="vs last month"
            />
            <StatCard
              label="Checkout completion"
              value={76}
              unit="%"
              animate
              icon={<CheckCircle2 className="h-4 w-4" />}
              accent="warning"
              trend={{ value: 2.1, direction: "up", good: true }}
              sublabel="of carts started"
            />
            <StatCard
              label="Time-to-convert"
              value="4:32"
              unit="mm:ss"
              icon={<Timer className="h-4 w-4" />}
              accent="info"
              trend={{ value: 0.8, direction: "down", good: true }}
              sublabel="median session"
            />
          </div>

          {/* Funnel + blockers */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-sm font-semibold text-ink">Conversion funnel</div>
                  <div className="text-[11px] text-muted-foreground">5-step purchase journey · last 30 days</div>
                </div>
                <Badge variant="outline" className="text-[10px]">
                  <Filter className="h-3 w-3 mr-1" /> All channels
                </Badge>
              </div>
              <div className="space-y-2.5">
                {FUNNEL_STEPS.map((s, i) => {
                  const prev = i === 0 ? s.pct : FUNNEL_STEPS[i - 1].pct;
                  const stepDrop = i === 0 ? 0 : Math.round(((FUNNEL_STEPS[i - 1].users - s.users) / FUNNEL_STEPS[i - 1].users) * 100);
                  const color = i === FUNNEL_STEPS.length - 1 ? "var(--success)" : i >= 2 ? "var(--warning)" : "var(--info)";
                  return (
                    <div key={s.step}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center justify-center h-5 w-5 rounded-md bg-surface-2 text-[10px] font-semibold text-ink">
                            {i + 1}
                          </span>
                          <span className="font-medium text-ink">{s.step}</span>
                          {i > 0 && (
                            <span className="text-[10px] text-friction flex items-center gap-0.5">
                              ↓ {stepDrop}% drop
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-muted-foreground tabular-nums">{s.users.toLocaleString()}</span>
                          <span className="font-semibold text-ink tabular-nums w-12 text-right">
                            <AnimatedNumber value={s.pct} suffix="%" duration={1.2} />
                          </span>
                        </div>
                      </div>
                      <div className="h-7 rounded-md bg-surface-2 overflow-hidden relative">
                        <motion.div
                          className="h-full rounded-md"
                          style={{
                            background: `color-mix(in oklch, ${color} 70%, transparent)`,
                          }}
                          initial={{ width: 0 }}
                          animate={{ width: `${(s.pct / FUNNEL_STEPS[0].pct) * 100}%` }}
                          transition={{ duration: 0.9, delay: 0.1 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                        />
                        <motion.div
                          className="absolute top-0 left-0 h-full rounded-md"
                          style={{
                            background: `linear-gradient(90deg, transparent, ${color})`,
                            opacity: 0.4,
                          }}
                          initial={{ width: 0 }}
                          animate={{ width: `${(s.pct / FUNNEL_STEPS[0].pct) * 100}%` }}
                          transition={{ duration: 0.9, delay: 0.1 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-4 pt-3 border-t border-soft grid grid-cols-3 gap-3 text-center">
                <div>
                  <div className="text-[10px] text-muted-foreground">Start</div>
                  <div className="text-sm font-semibold text-ink">
                    <AnimatedNumber value={12.5} format={(v) => `${v.toFixed(1)}K`} duration={1.2} />
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground">Converted</div>
                  <div className="text-sm font-semibold text-success">
                    <AnimatedNumber value={1.4} format={(v) => `${v.toFixed(1)}K`} duration={1.2} />
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground">Lost revenue est.</div>
                  <div className="text-sm font-semibold text-friction">
                    <AnimatedNumber value={284} prefix="$" suffix="K" duration={1.2} />
                  </div>
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Top conversion blockers</div>
                  <div className="text-[11px] text-muted-foreground">Ranked by impact</div>
                </div>
                <TrendingUp className="h-4 w-4 text-warning" />
              </div>
              <div className="space-y-3">
                {blockers.map((b, i) => (
                  <div
                    key={b.id}
                    className="p-3 rounded-lg border border-soft bg-surface-2/40 hover:bg-surface-2/70 transition-colors cursor-pointer"
                    onClick={() => toast.message(`Opening insight ${b.id}`)}
                  >
                    <div className="flex items-start gap-2 mb-1.5">
                      <span className="inline-flex items-center justify-center h-5 w-5 rounded-md bg-friction/15 text-friction text-[10px] font-bold flex-shrink-0">
                        #{i + 1}
                      </span>
                      <div className="text-xs font-medium text-ink leading-snug">{b.title}</div>
                    </div>
                    <div className="text-[10px] text-muted-foreground leading-relaxed mb-2 line-clamp-2">
                      {b.detail}
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-muted-foreground">Impact</span>
                      <div className="flex items-center gap-1.5">
                        <ProgressBar
                          value={b.impact}
                          color="var(--friction)"
                          trackColor="var(--surface)"
                          height={4}
                          className="w-12"
                          showLabel={false}
                          delay={0.15 + i * 0.08}
                        />
                        <span className="font-semibold text-friction tabular-nums"><AnimatedNumber value={b.impact} duration={1.2} /></span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Bottom: per-channel table */}
          <DataTable
            data={CHANNELS}
            columns={channelColumns}
            getRowId={(row) => row.id}
            pageSize={5}
            searchable
            searchPlaceholder="Search channels…"
            searchKeys={["channel"]}
            emptyTitle="No channels found"
            emptyDescription="Try adjusting your search."
          />
        </>
      )}
    </div>
  );
}
