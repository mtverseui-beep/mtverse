"use client";

import * as React from "react";
import {
  MousePointerClick,
  Timer,
  AlertTriangle,
  GraduationCap,
  Download,
  ArrowDownRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LineChart } from "@/components/charts";
import { TREND_SERIES, AGGREGATE_UX } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { AnimatedNumber, ProgressBar, ActiveDot } from "@/components/common/animated-progress";

interface UsabilityTest {
  id: string;
  task: string;
  project: string;
  successRate: number;
  avgTime: string;
  errors: number;
  lastRun: string;
  status: "completed" | "in-progress" | "scheduled";
}

const TESTS: UsabilityTest[] = [
  { id: "ut-1", task: "Create first wallet", project: "Atlas Onboarding", successRate: 71, avgTime: "3:42", errors: 1.4, lastRun: "2d ago", status: "completed" },
  { id: "ut-2", task: "Complete KYC step 3", project: "Atlas Onboarding", successRate: 58, avgTime: "4:18", errors: 2.1, lastRun: "3d ago", status: "completed" },
  { id: "ut-3", task: "Checkout as guest", project: "Northwind Checkout", successRate: 81, avgTime: "1:54", errors: 0.8, lastRun: "5d ago", status: "completed" },
  { id: "ut-4", task: "Find filter on mobile", project: "Voyage Booking", successRate: 64, avgTime: "2:31", errors: 1.2, lastRun: "1w ago", status: "completed" },
  { id: "ut-5", task: "Schedule recurring transfer", project: "Atlas Onboarding", successRate: 89, avgTime: "2:02", errors: 0.5, lastRun: "4d ago", status: "in-progress" },
  { id: "ut-6", task: "Cancel pending booking", project: "Voyage Booking", successRate: 92, avgTime: "0:48", errors: 0.3, lastRun: "6d ago", status: "completed" },
];

const WORST_TASKS = [
  { name: "Complete KYC step 3", project: "Atlas Onboarding", successRate: 58 },
  { name: "Find filter on mobile", project: "Voyage Booking", successRate: 64 },
  { name: "Create first wallet", project: "Atlas Onboarding", successRate: 71 },
  { name: "Checkout as guest", project: "Northwind Checkout", successRate: 81 },
  { name: "Schedule recurring transfer", project: "Atlas Onboarding", successRate: 89 },
];

export default function UsabilityMetricsPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const lineData = React.useMemo(
    () =>
      TREND_SERIES.map((d) => ({
        label: d.week,
        values: [{ label: "Task success", value: d.taskSuccess }],
      })),
    []
  );

  const columns: Column<UsabilityTest>[] = [
    {
      key: "task",
      header: "Task",
      cell: (row) => (
        <div className="min-w-0">
          <div className="font-medium text-ink truncate">{row.task}</div>
          <div className="text-[10px] text-muted-foreground truncate">{row.project}</div>
        </div>
      ),
      sortAccessor: (row) => row.task,
      sortable: true,
    },
    {
      key: "project",
      header: "Project",
      cell: (row) => <span className="text-xs">{row.project}</span>,
      sortAccessor: (row) => row.project,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "successRate",
      header: "Success rate",
      cell: (row) => {
        const color =
          row.successRate >= 85 ? "var(--success)" : row.successRate >= 70 ? "var(--warning)" : "var(--friction)";
        return (
          <div className="flex items-center gap-2">
            <ProgressBar
              value={row.successRate}
              color={color}
              trackColor="var(--surface-2)"
              height={6}
              className="w-16"
              showLabel={false}
            />
            <span className="text-xs font-medium tabular-nums">{row.successRate}%</span>
          </div>
        );
      },
      sortAccessor: (row) => row.successRate,
      sortable: true,
    },
    {
      key: "avgTime",
      header: "Avg time",
      cell: (row) => <span className="text-xs font-mono tabular-nums">{row.avgTime}</span>,
      sortAccessor: (row) => row.avgTime,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "errors",
      header: "Errors",
      cell: (row) => (
        <span className={cn("text-xs tabular-nums", row.errors > 1.5 ? "text-friction" : "text-ink")}>
          {row.errors.toFixed(1)}
        </span>
      ),
      sortAccessor: (row) => row.errors,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "lastRun",
      header: "Last run",
      cell: (row) => <span className="text-xs text-muted-foreground">{row.lastRun}</span>,
      sortAccessor: (row) => row.lastRun,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (row) => (
        <Badge
          variant="outline"
          className={cn(
            "text-[10px] capitalize",
            row.status === "completed" && "border-success/20 bg-success/10 text-success",
            row.status === "in-progress" && "border-info/20 bg-info/10 text-info",
            row.status === "scheduled" && "border-border bg-muted text-muted-foreground"
          )}
        >
          {row.status.replace("-", " ")}
        </Badge>
      ),
      sortAccessor: (row) => row.status,
      sortable: true,
    },
  ];

  return (
    <div>
      <PageHeader
        title="Usability Metrics"
        description="Task success, time-on-task, error rate, and learnability across all projects"
        breadcrumbs={[{ label: "Metrics" }, { label: "Usability" }]}
        icon={<MousePointerClick className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            UX {AGGREGATE_UX.usability}/100
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Usability report exported")}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Top stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Task success rate"
              value={87}
              unit="%"
              animate
              icon={<MousePointerClick className="h-4 w-4" />}
              accent="success"
              trend={{ value: 3.2, direction: "up", good: true }}
              sublabel="vs last quarter"
            />
            <StatCard
              label="Avg time-on-task"
              value="2:18"
              unit="mm:ss"
              icon={<Timer className="h-4 w-4" />}
              accent="info"
              trend={{ value: 1.4, direction: "down", good: true }}
              sublabel="vs last quarter"
            />
            <StatCard
              label="Error rate"
              value="8.4%"
              icon={<AlertTriangle className="h-4 w-4" />}
              accent="warning"
              trend={{ value: 0.6, direction: "down", good: true }}
              sublabel="vs last quarter"
            />
            <StatCard
              label="Learnability index"
              value={76}
              unit="/100"
              animate
              icon={<GraduationCap className="h-4 w-4" />}
              accent="info"
              trend={{ value: 4.8, direction: "up", good: true }}
              sublabel="first vs repeat users"
            />
          </div>

          {/* Main chart + side list */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink flex items-center gap-1.5">
                    Task success trend
                    <ActiveDot color="var(--success)" size={6} />
                  </div>
                  <div className="text-[11px] text-muted-foreground">12-week rolling success rate · live monitoring</div>
                </div>
                <div className="flex items-center gap-3 text-[10px]">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full" style={{ background: "var(--success)" }} />
                    <span className="text-muted-foreground">Task success %</span>
                  </div>
                </div>
              </div>
              <LineChart data={lineData} height={260} />
              <div className="mt-3 pt-3 border-t border-soft grid grid-cols-3 gap-2 text-[10px]">
                <div>
                  <div className="text-muted-foreground">Min</div>
                  <div className="font-semibold text-ink tabular-nums">
                    <AnimatedNumber value={Math.min(...TREND_SERIES.map((d) => d.taskSuccess))} suffix="%" duration={1.2} />
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Avg</div>
                  <div className="font-semibold text-ink tabular-nums">
                    <AnimatedNumber value={Math.round(TREND_SERIES.reduce((a, b) => a + b.taskSuccess, 0) / TREND_SERIES.length)} suffix="%" duration={1.2} />
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Latest</div>
                  <div className="font-semibold text-success tabular-nums">
                    <AnimatedNumber value={TREND_SERIES[TREND_SERIES.length - 1].taskSuccess} suffix="%" duration={1.2} />
                  </div>
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Lowest success tasks</div>
                  <div className="text-[11px] text-muted-foreground">Top 5 — needs attention</div>
                </div>
                <ArrowDownRight className="h-4 w-4 text-friction" />
              </div>
              <div className="space-y-3">
                {WORST_TASKS.map((t, i) => {
                  const intensity = (100 - t.successRate) / 42; // 0..1, worse = higher
                  const barColor = `color-mix(in oklch, var(--friction) ${Math.round(intensity * 100)}%, var(--warning))`;
                  return (
                    <div key={t.name} className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-xs font-medium text-ink truncate">
                            <span className="text-muted-foreground mr-1.5">#{i + 1}</span>
                            {t.name}
                          </div>
                          <div className="text-[10px] text-muted-foreground truncate">{t.project}</div>
                        </div>
                        <span className="text-xs font-semibold text-friction tabular-nums flex-shrink-0">
                          <AnimatedNumber value={t.successRate} suffix="%" duration={1.2} />
                        </span>
                      </div>
                      <ProgressBar
                        value={100 - t.successRate}
                        color={barColor}
                        trackColor="var(--surface-2)"
                        height={6}
                        delay={0.1 + i * 0.08}
                      />
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>

          {/* Bottom: data table */}
          <DataTable
            data={TESTS}
            columns={columns}
            getRowId={(row) => row.id}
            pageSize={6}
            searchable
            searchPlaceholder="Search tasks or projects…"
            searchKeys={["task", "project"]}
            emptyTitle="No tests found"
            emptyDescription="Try adjusting your search."
          />
        </>
      )}
    </div>
  );
}
