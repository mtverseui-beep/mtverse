"use client";

import * as React from "react";
import {
  HeartPulse,
  Layers,
  Activity,
  Sparkles,
  Repeat,
  Download,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LineChart } from "@/components/charts";
import { TREND_SERIES, AGGREGATE_UX } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { AnimatedNumber, ProgressBar, ActiveDot } from "@/components/common/animated-progress";

const FEATURE_ADOPTION = [
  { name: "Smart search", adopters: 8420, pct: 84 },
  { name: "Saved filters", adopters: 6910, pct: 69 },
  { name: "Bulk actions", adopters: 5180, pct: 52 },
  { name: "Keyboard shortcuts", adopters: 4320, pct: 43 },
  { name: "API access", adopters: 2780, pct: 28 },
];

const COHORTS = [
  { label: "Week 1", retention: 100, color: "var(--success)" },
  { label: "Week 2", retention: 64, color: "var(--info)" },
  { label: "Week 4", retention: 41, color: "var(--warning)" },
  { label: "Week 8", retention: 28, color: "var(--friction)" },
];

export default function EngagementMetricsPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  // Build DAU/MAU series from TREND_SERIES (engagement field scaled to look like real DAU/MAU)
  const lineData = React.useMemo(
    () =>
      TREND_SERIES.map((d) => ({
        label: d.week,
        values: [
          { label: "DAU", value: Math.round(d.engagement * 320) },
          { label: "MAU", value: Math.round(d.engagement * 760) },
        ],
      })),
    []
  );

  const totalAdopters = FEATURE_ADOPTION.reduce((a, b) => a + b.adopters, 0);
  const maxRetention = Math.max(...COHORTS.map((c) => c.retention));

  return (
    <div>
      <PageHeader
        title="Engagement Metrics"
        description="Session depth, return rate, feature adoption, and DAU/MAU"
        breadcrumbs={[{ label: "Metrics" }, { label: "Engagement" }]}
        icon={<HeartPulse className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            UX {AGGREGATE_UX.engagement}/100
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Engagement cohort exported")}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export cohorts
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Avg session depth"
              value="4.2"
              unit="pages"
              icon={<Layers className="h-4 w-4" />}
              accent="info"
              trend={{ value: 0.3, direction: "up", good: true }}
              sublabel="per session"
            />
            <StatCard
              label="DAU/MAU ratio"
              value={42}
              unit="%"
              animate
              icon={<Activity className="h-4 w-4" />}
              accent="success"
              trend={{ value: 2.4, direction: "up", good: true }}
              sublabel="stickiness benchmark"
            >
              <div className="mt-2 flex items-center gap-1.5 text-[10px] font-medium text-success">
                <ActiveDot color="var(--success)" size={6} />
                DAU/MAU live
              </div>
            </StatCard>
            <StatCard
              label="Feature adoption"
              value={68}
              unit="%"
              animate
              icon={<Sparkles className="h-4 w-4" />}
              accent="warning"
              trend={{ value: 5.1, direction: "up", good: true }}
              sublabel="core 3 features"
            />
            <StatCard
              label="Return rate"
              value={54}
              unit="%"
              animate
              icon={<Repeat className="h-4 w-4" />}
              accent="info"
              trend={{ value: 1.8, direction: "up", good: true }}
              sublabel="7-day rolling"
            />
          </div>

          {/* Main chart + features */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">DAU vs MAU trend</div>
                  <div className="text-[11px] text-muted-foreground">12-week active user counts</div>
                </div>
                <div className="flex items-center gap-3 text-[10px]">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full" style={{ background: "var(--success)" }} />
                    <span className="text-muted-foreground">DAU</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full" style={{ background: "var(--friction)" }} />
                    <span className="text-muted-foreground">MAU</span>
                  </div>
                </div>
              </div>
              <LineChart data={lineData} height={260} />
              <div className="mt-3 pt-3 border-t border-soft grid grid-cols-3 gap-3 text-[10px]">
                <div>
                  <div className="text-muted-foreground">Peak DAU</div>
                  <div className="font-semibold text-ink tabular-nums">
                    <AnimatedNumber value={Math.max(...TREND_SERIES.map((d) => d.engagement * 320))} format={(v) => Math.round(v).toLocaleString()} duration={1.4} />
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Latest DAU</div>
                  <div className="font-semibold text-success tabular-nums">
                    <AnimatedNumber value={Math.round(TREND_SERIES[TREND_SERIES.length - 1].engagement * 320)} format={(v) => Math.round(v).toLocaleString()} duration={1.4} />
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Stickiness</div>
                  <div className="font-semibold text-ink tabular-nums">
                    <AnimatedNumber value={42} suffix="%" duration={1.4} />
                  </div>
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Feature adoption</div>
                  <div className="text-[11px] text-muted-foreground">Top 5 by user count</div>
                </div>
                <Sparkles className="h-4 w-4 text-warning" />
              </div>
              <div className="space-y-3">
                {FEATURE_ADOPTION.map((f, i) => {
                  const color =
                    f.pct >= 60 ? "var(--success)" : f.pct >= 40 ? "var(--warning)" : "var(--friction)";
                  return (
                    <div key={f.name} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-[10px] text-muted-foreground w-3">#{i + 1}</span>
                          <span className="font-medium text-ink truncate">{f.name}</span>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className="text-[10px] text-muted-foreground tabular-nums">
                            <AnimatedNumber value={f.adopters} format={(v) => Math.round(v).toLocaleString()} duration={1.2} />
                          </span>
                          <span className="font-semibold text-ink tabular-nums">
                            <AnimatedNumber value={f.pct} suffix="%" duration={1.2} />
                          </span>
                        </div>
                      </div>
                      <ProgressBar
                        value={f.pct}
                        color={color}
                        trackColor="var(--surface-2)"
                        height={6}
                        delay={0.1 + i * 0.08}
                      />
                    </div>
                  );
                })}
              </div>
              <div className="mt-3 pt-3 border-t border-soft text-[10px] text-muted-foreground">
                <AnimatedNumber value={totalAdopters} format={(v) => Math.round(v).toLocaleString()} duration={1.4} /> total feature activations
              </div>
            </Card>
          </div>

          {/* Retention by cohort — unique composition: retention curve + cohort cards */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-sm font-semibold text-ink">Engagement by cohort</div>
                <div className="text-[11px] text-muted-foreground">Retention curve from first-session week</div>
              </div>
              <Badge variant="outline" className="text-[10px]">
                4 cohorts · 12,420 users
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {/* Retention curve SVG */}
              <div className="md:col-span-3">
                <svg viewBox="0 0 480 200" className="w-full h-44">
                  {/* Grid */}
                  {[0, 0.25, 0.5, 0.75, 1].map((g) => (
                    <line
                      key={g}
                      x1="40"
                      x2="460"
                      y1={20 + g * 150}
                      y2={20 + g * 150}
                      stroke="var(--border)"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                    />
                  ))}
                  {/* Y labels */}
                  {[100, 75, 50, 25, 0].map((v, i) => (
                    <text key={v} x="34" y={24 + i * 37.5} textAnchor="end" className="fill-muted-foreground text-[10px]">
                      {v}%
                    </text>
                  ))}
                  {/* X labels */}
                  {COHORTS.map((c, i) => (
                    <text
                      key={c.label}
                      x={40 + (i / (COHORTS.length - 1)) * 420}
                      y="195"
                      textAnchor="middle"
                      className="fill-muted-foreground text-[10px]"
                    >
                      {c.label}
                    </text>
                  ))}
                  {/* Area */}
                  <path
                    d={`M 40 ${20 + (1 - COHORTS[0].retention / maxRetention) * 150} ${COHORTS.map(
                      (c, i) =>
                        `L ${40 + (i / (COHORTS.length - 1)) * 420} ${20 + (1 - c.retention / maxRetention) * 150}`
                    ).join(" ")} L 460 170 L 40 170 Z`}
                    fill="var(--success)"
                    opacity={0.12}
                  />
                  {/* Line */}
                  <path
                    d={`M 40 ${20 + (1 - COHORTS[0].retention / maxRetention) * 150} ${COHORTS.map(
                      (c, i) =>
                        `L ${40 + (i / (COHORTS.length - 1)) * 420} ${20 + (1 - c.retention / maxRetention) * 150}`
                    ).join(" ")}`}
                    fill="none"
                    stroke="var(--success)"
                    strokeWidth="2.5"
                    strokeLinejoin="round"
                    strokeLinecap="round"
                  />
                  {/* Points */}
                  {COHORTS.map((c, i) => (
                    <g key={c.label}>
                      <circle
                        cx={40 + (i / (COHORTS.length - 1)) * 420}
                        cy={20 + (1 - c.retention / maxRetention) * 150}
                        r="5"
                        fill={c.color}
                        stroke="var(--card)"
                        strokeWidth="2"
                      />
                      <text
                        x={40 + (i / (COHORTS.length - 1)) * 420}
                        y={12 + (1 - c.retention / maxRetention) * 150}
                        textAnchor="middle"
                        className="fill-ink text-[10px] font-semibold"
                      >
                        {c.retention}%
                      </text>
                    </g>
                  ))}
                </svg>
              </div>

              {/* Cohort detail cards */}
              <div className="md:col-span-2 grid grid-cols-2 gap-2.5">
                {COHORTS.map((c, i) => (
                  <div
                    key={c.label}
                    className="rounded-xl border border-soft bg-surface-2/40 p-3 flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-medium text-muted-foreground">{c.label}</span>
                      <span className="h-2 w-2 rounded-full" style={{ background: c.color }} />
                    </div>
                    <div className="mt-2">
                      <div className="text-xl font-semibold text-ink tabular-nums">
                        <AnimatedNumber value={c.retention} suffix="%" duration={1.4} />
                      </div>
                      <div className="text-[10px] text-muted-foreground">retained</div>
                    </div>
                    <ProgressBar
                      value={c.retention}
                      color={c.color}
                      trackColor="var(--surface)"
                      height={4}
                      delay={0.1 + i * 0.08}
                      className="mt-2"
                    />
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
