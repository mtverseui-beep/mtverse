"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Building2,
  Mail,
  Calendar,
  DollarSign,
  Users,
  CreditCard,
  Activity,
  Gauge,
  Headphones,
  Star,
  Pencil,
  MessageSquare,
  ChevronRight,
  Server,
  HardDrive,
  Zap,
  Clock,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { LineChart } from "@/components/charts";
import { getCustomer } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const PLAN_BADGE_CLASS: Record<string, string> = {
  Free: "bg-muted text-muted-foreground border-border",
  Pro: "bg-info/15 text-info border-info/20",
  Team: "bg-success/15 text-success border-success/20",
  Enterprise: "bg-primary/10 text-primary border-primary/20",
};

interface TeamMemberMock {
  name: string;
  avatar: string;
  role: string;
  email: string;
}

interface ActivityEntry {
  action: string;
  target: string;
  time: string;
}

const MOCK_TEAM: TeamMemberMock[] = [
  { name: "Mira Halberg", avatar: "https://i.pravatar.cc/80?img=12", role: "Owner", email: "mira@halberg.co" },
  { name: "Theo Park", avatar: "https://i.pravatar.cc/80?img=13", role: "Designer", email: "theo@halberg.co" },
  { name: "Lena Ortiz", avatar: "https://i.pravatar.cc/80?img=45", role: "PM", email: "lena@halberg.co" },
  { name: "Idris Khoury", avatar: "https://i.pravatar.cc/80?img=33", role: "Admin", email: "idris@halberg.co" },
];

const MOCK_ACTIVITY: ActivityEntry[] = [
  { action: "Generated report", target: "Q2 UX Audit", time: "12 min ago" },
  { action: "Added 3 new screens", target: "Atlas Onboarding", time: "3 hours ago" },
  { action: "Upgraded seats", target: "28 → 32", time: "Yesterday" },
  { action: "Connected integration", target: "Slack", time: "2 days ago" },
  { action: "Created project", target: "Helix Prototype", time: "5 days ago" },
];

// Mock 12-month MRR history
const MRR_HISTORY = [
  { label: "Jul", values: [{ label: "MRR", value: 1800 }] },
  { label: "Aug", values: [{ label: "MRR", value: 1900 }] },
  { label: "Sep", values: [{ label: "MRR", value: 2100 }] },
  { label: "Oct", values: [{ label: "MRR", value: 2200 }] },
  { label: "Nov", values: [{ label: "MRR", value: 2400 }] },
  { label: "Dec", values: [{ label: "MRR", value: 2400 }] },
  { label: "Jan", values: [{ label: "MRR", value: 2400 }] },
  { label: "Feb", values: [{ label: "MRR", value: 2400 }] },
  { label: "Mar", values: [{ label: "MRR", value: 2400 }] },
  { label: "Apr", values: [{ label: "MRR", value: 2400 }] },
  { label: "May", values: [{ label: "MRR", value: 2400 }] },
  { label: "Jun", values: [{ label: "MRR", value: 2400 }] },
];

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { dot: string; label: string; cls: string }> = {
    active: { dot: "bg-success", label: "Active", cls: "text-success" },
    trialing: { dot: "bg-warning", label: "Trialing", cls: "text-warning" },
    churned: { dot: "bg-friction", label: "Churned", cls: "text-friction" },
  };
  const s = map[status] ?? map.active;
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium">
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      <span className={s.cls}>{s.label}</span>
    </span>
  );
}

export default function CustomerDetailPage() {
  const params = useParams<{ id: string }>();
  const customer = getCustomer(params.id);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  if (!customer) {
    return (
      <EmptyState
        icon={Building2}
        title="Customer not found"
        description="This customer may have been removed or never existed."
        action={{ label: "Back to customers", href: "/customers" }}
      />
    );
  }

  // Health indicators (mock based on customer data)
  const usageScore = Math.min(100, Math.round((customer.projects / 20) * 100 + 30));
  const supportScore = customer.status === "churned" ? 32 : 78;
  const npsScore = customer.status === "active" ? 9 : customer.status === "trialing" ? 7 : 4;
  const healthScore = Math.round((usageScore + supportScore + (npsScore * 10)) / 3);

  return (
    <div>
      <PageHeader
        title={customer.company}
        description={`${customer.plan} plan · joined ${new Date(customer.joinedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}`}
        breadcrumbs={[
          { label: "Customers", href: "/customers" },
          { label: customer.company },
        ]}
        icon={<Building2 className="h-5 w-5" />}
        badge={
          <Badge
            variant="outline"
            className={cn(
              "text-[10px] font-medium border",
              PLAN_BADGE_CLASS[customer.plan]
            )}
          >
            {customer.plan}
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.message(`Composing message to ${customer.contact}`)}
            >
              <MessageSquare className="mr-2 h-3.5 w-3.5" /> Contact
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message(`Editing ${customer.company}`)}
            >
              <Pencil className="mr-2 h-3.5 w-3.5" /> Edit
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* LEFT COLUMN */}
        <div className="lg:col-span-2 space-y-4">
          {/* Profile */}
          <Card className="rounded-2xl border-soft shadow-soft p-5">
            <div className="flex flex-col sm:flex-row sm:items-start gap-4">
              <Avatar className="h-16 w-16 rounded-2xl ring-2 ring-soft flex-shrink-0">
                <AvatarImage src={customer.avatar} alt={customer.company} />
                <AvatarFallback className="rounded-2xl text-lg">
                  {customer.company.slice(0, 2)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg font-semibold text-ink">
                    {customer.company}
                  </h2>
                  <StatusPill status={customer.status} />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-1.5 gap-x-4 mt-3 text-xs">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Mail className="h-3.5 w-3.5" />
                    <span className="text-ink">{customer.contact}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" />
                    <span className="text-ink">
                      Joined{" "}
                      {new Date(customer.joinedAt).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <DollarSign className="h-3.5 w-3.5" />
                    <span className="text-ink">
                      ${customer.mrr.toLocaleString()}/mo MRR
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Users className="h-3.5 w-3.5" />
                    <span className="text-ink">{customer.seats} seats</span>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* MRR history */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                  <DollarSign className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-ink">MRR history</h3>
                  <div className="text-[10px] text-muted-foreground">
                    Trailing 12 months
                  </div>
                </div>
              </div>
              <Badge
                variant="outline"
                className="text-[10px] border-success/30 bg-success/10 text-success"
              >
                +${(customer.mrr - 1800).toLocaleString()} since join
              </Badge>
            </div>
            <LineChart
              data={MRR_HISTORY}
              height={220}
              showXAxis
              showGrid
            />
            <div className="grid grid-cols-3 gap-3 mt-4 pt-3 border-t border-soft">
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  Current
                </div>
                <div className="text-sm font-semibold text-ink">
                  ${customer.mrr.toLocaleString()}/mo
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  ARR
                </div>
                <div className="text-sm font-semibold text-ink">
                  ${(customer.mrr * 12).toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                  Lifetime
                </div>
                <div className="text-sm font-semibold text-ink">
                  ${(customer.mrr * 14).toLocaleString()}
                </div>
              </div>
            </div>
          </Card>

          {/* Usage stats */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Gauge className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Usage stats</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="rounded-xl border border-soft p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Server className="h-3.5 w-3.5 text-muted-foreground" />
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    Projects
                  </div>
                </div>
                <div className="text-xl font-semibold text-ink">
                  {customer.projects}
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  Active workspaces
                </div>
              </div>
              <div className="rounded-xl border border-soft p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Users className="h-3.5 w-3.5 text-muted-foreground" />
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    Seats used
                  </div>
                </div>
                <div className="text-xl font-semibold text-ink">
                  {Math.min(customer.seats, customer.seats - 2)}/{customer.seats}
                </div>
                <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden mt-2">
                  <div
                    className="h-full rounded-full bg-info"
                    style={{
                      width: `${((customer.seats - 2) / customer.seats) * 100}%`,
                    }}
                  />
                </div>
              </div>
              <div className="rounded-xl border border-soft p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Zap className="h-3.5 w-3.5 text-muted-foreground" />
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    API calls this month
                  </div>
                </div>
                <div className="text-xl font-semibold text-ink">
                  {(customer.seats * 4128).toLocaleString()}
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  of {(customer.seats * 5000).toLocaleString()} quota
                </div>
              </div>
              <div className="rounded-xl border border-soft p-3">
                <div className="flex items-center gap-2 mb-1">
                  <HardDrive className="h-3.5 w-3.5 text-muted-foreground" />
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    Storage used
                  </div>
                </div>
                <div className="text-xl font-semibold text-ink">
                  {(customer.seats * 1.4).toFixed(1)} GB
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  of {customer.seats * 5} GB
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* RIGHT COLUMN */}
        <div className="space-y-4">
          {/* Health score */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Gauge className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Health score</h3>
            </div>
            <div className="flex items-baseline gap-2 mb-3">
              <span className="text-3xl font-semibold text-success">
                {healthScore}
              </span>
              <span className="text-xs text-muted-foreground">/100</span>
              <Badge
                variant="outline"
                className="text-[9px] border-success/30 bg-success/10 text-success ml-auto"
              >
                Healthy
              </Badge>
            </div>
            <Separator className="mb-3" />
            <div className="space-y-2.5">
              <div>
                <div className="flex items-center justify-between text-[10px] mb-1">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Activity className="h-3 w-3" /> Usage
                  </span>
                  <span className="font-medium text-ink">{usageScore}</span>
                </div>
                <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-success"
                    style={{ width: `${usageScore}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-[10px] mb-1">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Headphones className="h-3 w-3" /> Support tickets
                  </span>
                  <span className="font-medium text-ink">{supportScore}</span>
                </div>
                <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-warning"
                    style={{ width: `${supportScore}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-[10px] mb-1">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Star className="h-3 w-3" /> NPS
                  </span>
                  <span className="font-medium text-ink">{npsScore}/10</span>
                </div>
                <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-info"
                    style={{ width: `${npsScore * 10}%` }}
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* Billing */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-warning">
                <CreditCard className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Billing</h3>
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Current plan</span>
                <span className="text-ink font-medium">{customer.plan}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Billing cycle</span>
                <span className="text-ink font-medium">Monthly</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Next invoice</span>
                <span className="text-ink font-medium">
                  ${customer.mrr.toLocaleString()} · Aug 1
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Payment method</span>
                <span className="text-ink font-medium">Card •• 4242</span>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Invoice downloaded")}
            >
              Download latest invoice
            </Button>
          </Card>

          {/* Team members */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                  <Users className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">Team members</h3>
              </div>
              <Badge variant="secondary" className="text-[10px]">
                {MOCK_TEAM.length} of {customer.seats}
              </Badge>
            </div>
            <div className="space-y-2">
              {MOCK_TEAM.map((m) => (
                <div
                  key={m.email}
                  className="flex items-center gap-2.5 rounded-lg border border-soft p-2"
                >
                  <Avatar className="h-7 w-7 ring-1 ring-soft flex-shrink-0">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback>{m.name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink truncate">
                      {m.name}
                    </div>
                    <div className="text-[10px] text-muted-foreground truncate">
                      {m.email}
                    </div>
                  </div>
                  <Badge
                    variant="outline"
                    className="text-[9px] border-info/30 bg-info/10 text-info"
                  >
                    {m.role}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>

          {/* Activity */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Activity className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Activity feed</h3>
            </div>
            <div className="relative pl-5">
              <div className="absolute left-1.5 top-1 bottom-1 w-px bg-soft" />
              <div className="space-y-3">
                {MOCK_ACTIVITY.map((a, i) => (
                  <div key={i} className="relative">
                    <div className="absolute -left-[14px] top-1 h-2.5 w-2.5 rounded-full bg-primary ring-2 ring-card" />
                    <div className="flex flex-col gap-0.5">
                      <div className="text-xs text-ink">
                        <span className="font-medium">{a.action}</span>{" "}
                        <span className="text-muted-foreground">{a.target}</span>
                      </div>
                      <div className="text-[10px] text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {a.time}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </div>

      <div className="mt-4">
        <Button asChild variant="ghost" size="sm" className="text-xs">
          <Link href="/customers">
            <Building2 className="mr-2 h-3.5 w-3.5" /> Back to customers
            <ChevronRight className="h-3 w-3 ml-1" />
          </Link>
        </Button>
      </div>
    </div>
  );
}
