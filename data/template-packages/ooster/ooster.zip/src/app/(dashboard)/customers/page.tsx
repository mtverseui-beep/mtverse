"use client";

import * as React from "react";
import Link from "next/link";
import {
  Building2,
  Users,
  DollarSign,
  TrendingUp,
  TrendingDown,
  ChevronRight,
  Mail,
  Calendar,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MiniTrend } from "@/components/charts";
import { CUSTOMERS, type Customer } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const PLAN_OPTIONS: FilterOption[] = [
  { label: "All plans", value: "all" },
  { label: "Free", value: "Free" },
  { label: "Pro", value: "Pro" },
  { label: "Team", value: "Team" },
  { label: "Enterprise", value: "Enterprise" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Active", value: "active" },
  { label: "Trialing", value: "trialing" },
  { label: "Churned", value: "churned" },
];

const PLAN_BADGE_CLASS: Record<string, string> = {
  Free: "bg-muted text-muted-foreground border-border",
  Pro: "bg-info/15 text-info border-info/20",
  Team: "bg-success/15 text-success border-success/20",
  Enterprise: "bg-primary/10 text-primary border-primary/20",
};

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { dot: string; label: string; cls: string }> = {
    active: { dot: "bg-success", label: "Active", cls: "text-success" },
    trialing: { dot: "bg-warning", label: "Trialing", cls: "text-warning" },
    churned: { dot: "bg-friction", label: "Churned", cls: "text-friction" },
  };
  const s = map[status] ?? map.active;
  return (
    <span className="inline-flex items-center gap-1.5 text-[11px] font-medium">
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      <span className={s.cls}>{s.label}</span>
    </span>
  );
}

// Mock MRR sparkline data per customer (deterministic)
const SPARKLINE: Record<string, number[]> = {
  "c-001": [1800, 1900, 2100, 2200, 2400, 2400, 2400, 2400, 2400, 2400, 2400, 2400],
  "c-002": [400, 420, 450, 480, 520, 550, 580, 580, 580, 580, 580, 580],
  "c-003": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 200, 580],
  "c-004": [80, 90, 100, 100, 110, 120, 120, 120, 120, 120, 120, 120],
  "c-005": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120],
  "c-006": [1800, 2000, 2200, 2300, 2350, 2400, 2400, 2400, 2400, 2400, 2400, 2400],
};

export default function CustomersPage() {
  const [search, setSearch] = React.useState("");
  const [plan, setPlan] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return CUSTOMERS.filter((c) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !c.company.toLowerCase().includes(q) &&
          !c.contact.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (plan !== "all" && c.plan !== plan) return false;
      if (status !== "all" && c.status !== status) return false;
      return true;
    });
  }, [search, plan, status]);

  const clearFilters = () => {
    setSearch("");
    setPlan("all");
    setStatus("all");
  };

  // KPIs
  const total = CUSTOMERS.length;
  const activeMrr = CUSTOMERS.filter((c) => c.status === "active").reduce(
    (s, c) => s + c.mrr,
    0
  );
  const trialConversion = 68;
  const churnRate = 3.2;

  return (
    <div>
      <PageHeader
        title="Customers"
        description="Workspace customers with plan, MRR, and engagement metrics"
        icon={<Building2 className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {CUSTOMERS.length} customers
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Customer list exported as CSV")}
          >
            Export
          </Button>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total customers"
          value={total}
          icon={<Building2 className="h-4 w-4" />}
          accent="info"
          sublabel="across all plans"
        />
        <StatCard
          label="Active MRR"
          value={`$${(activeMrr / 1000).toFixed(1)}k`}
          unit="/mo"
          icon={<DollarSign className="h-4 w-4" />}
          accent="success"
          trend={{ value: 8.4, direction: "up", good: true }}
          sublabel="recurring revenue"
        />
        <StatCard
          label="Trial conversion"
          value={`${trialConversion}%`}
          icon={<TrendingUp className="h-4 w-4" />}
          accent="warning"
          trend={{ value: 4.1, direction: "up", good: true }}
          sublabel="trial → paid"
        />
        <StatCard
          label="Churn rate"
          value={`${churnRate}%`}
          icon={<TrendingDown className="h-4 w-4" />}
          accent="friction"
          trend={{ value: 0.8, direction: "down", good: true }}
          sublabel="trailing 30 days"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search by company or contact…",
          }}
          selects={[
            { label: "Plan", value: plan, onChange: setPlan, options: PLAN_OPTIONS },
            { label: "Status", value: status, onChange: setStatus, options: STATUS_OPTIONS },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No customers match your filters"
          description="Adjust your search or filter criteria to find customers."
          action={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((c) => {
            const spark = SPARKLINE[c.id] || [c.mrr * 0.6, c.mrr * 0.7, c.mrr * 0.8, c.mrr * 0.9, c.mrr];
            return (
              <Link key={c.id} href={`/customers/${c.id}`} className="group">
                <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Avatar className="h-10 w-10 rounded-xl ring-1 ring-soft flex-shrink-0">
                        <AvatarImage src={c.avatar} alt={c.company} />
                        <AvatarFallback className="rounded-xl">
                          {c.company.slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-ink group-hover:text-primary transition-colors truncate">
                          {c.company}
                        </div>
                        <div className="text-[10px] text-muted-foreground flex items-center gap-1 truncate">
                          <Mail className="h-3 w-3" /> {c.contact}
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
                  </div>

                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[10px] font-medium border",
                        PLAN_BADGE_CLASS[c.plan]
                      )}
                    >
                      {c.plan}
                    </Badge>
                    <StatusPill status={c.status} />
                  </div>

                  {/* MRR + sparkline */}
                  <div className="rounded-xl border border-soft p-3 mb-3">
                    <div className="flex items-center justify-between mb-1">
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">
                        MRR
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {c.seats} seats
                      </div>
                    </div>
                    <div className="flex items-end justify-between gap-2">
                      <div className="text-xl font-semibold text-ink">
                        ${c.mrr.toLocaleString()}
                        <span className="text-[10px] text-muted-foreground font-normal">
                          {" "}/mo
                        </span>
                      </div>
                      <MiniTrend
                        data={spark}
                        width={80}
                        height={28}
                        color="var(--success)"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-auto pt-3 border-t border-soft">
                    <div>
                      <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
                        Projects
                      </div>
                      <div className="text-xs font-semibold text-ink">
                        {c.projects}
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
                        Seats
                      </div>
                      <div className="text-xs font-semibold text-ink">
                        {c.seats}
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
                        Joined
                      </div>
                      <div className="text-xs font-semibold text-ink flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {new Date(c.joinedAt).toLocaleDateString("en-US", {
                          month: "short",
                          year: "2-digit",
                        })}
                      </div>
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
