"use client";

import * as React from "react";
import {
  Shield,
  Download,
  Eye,
  FolderKanban,
  FileText,
  Users,
  CreditCard,
  Plug,
  LogIn,
  Database,
  AlertTriangle,
  Activity,
  Lock,
  ShieldAlert,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AUDIT_LOGS, type AuditLog } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const CATEGORY_OPTIONS: FilterOption[] = [
  { label: "All categories", value: "all" },
  { label: "Project", value: "project" },
  { label: "Report", value: "report" },
  { label: "Team", value: "team" },
  { label: "Billing", value: "billing" },
  { label: "Integration", value: "integration" },
  { label: "Auth", value: "auth" },
  { label: "Data", value: "data" },
];

const ACTOR_OPTIONS: FilterOption[] = [
  { label: "All actors", value: "all" },
  ...Array.from(new Set(AUDIT_LOGS.map((l) => l.actor))).map((a) => ({
    label: a,
    value: a,
  })),
];

const RANGE_OPTIONS: FilterOption[] = [
  { label: "Last 7 days", value: "7d" },
  { label: "Last 30 days", value: "30d" },
  { label: "Last 90 days", value: "90d" },
  { label: "All time", value: "all" },
];

const CATEGORY_META: Record<
  AuditLog["category"],
  { icon: React.ReactNode; cls: string }
> = {
  project: {
    icon: <FolderKanban className="h-3 w-3" />,
    cls: "bg-info/15 text-info border-info/20",
  },
  report: {
    icon: <FileText className="h-3 w-3" />,
    cls: "bg-primary/10 text-primary border-primary/20",
  },
  team: {
    icon: <Users className="h-3 w-3" />,
    cls: "bg-success/15 text-success border-success/20",
  },
  billing: {
    icon: <CreditCard className="h-3 w-3" />,
    cls: "bg-warning/15 text-warning border-warning/20",
  },
  integration: {
    icon: <Plug className="h-3 w-3" />,
    cls: "bg-muted text-muted-foreground border-border",
  },
  auth: {
    icon: <LogIn className="h-3 w-3" />,
    cls: "bg-info/15 text-info border-info/20",
  },
  data: {
    icon: <Database className="h-3 w-3" />,
    cls: "bg-friction/15 text-friction border-friction/20",
  },
};

export default function AuditLogsPage() {
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("all");
  const [actor, setActor] = React.useState("all");
  const [range, setRange] = React.useState("30d");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return AUDIT_LOGS.filter((l) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !l.actor.toLowerCase().includes(q) &&
          !l.action.toLowerCase().includes(q) &&
          !l.target.toLowerCase().includes(q) &&
          !l.ip.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (category !== "all" && l.category !== category) return false;
      if (actor !== "all" && l.actor !== actor) return false;
      return true;
    });
  }, [search, category, actor]);

  const clearFilters = () => {
    setSearch("");
    setCategory("all");
    setActor("all");
    setRange("30d");
  };

  // Stats
  const eventsToday = AUDIT_LOGS.filter((l) =>
    l.timestamp.startsWith("2026-07-01")
  ).length;
  const uniqueActors = new Set(AUDIT_LOGS.map((l) => l.actor)).size;
  const topCategory = Object.entries(
    AUDIT_LOGS.reduce<Record<string, number>>((acc, l) => {
      acc[l.category] = (acc[l.category] || 0) + 1;
      return acc;
    }, {})
  ).sort((a, b) => b[1] - a[1])[0];

  const columns: Column<AuditLog>[] = [
    {
      key: "timestamp",
      header: "Timestamp",
      cell: (l) => (
        <span className="text-[11px] text-muted-foreground font-mono whitespace-nowrap">
          {l.timestamp}
        </span>
      ),
      width: "16%",
      sortable: true,
      sortAccessor: (l) => l.timestamp,
    },
    {
      key: "actor",
      header: "Actor",
      cell: (l) => (
        <div className="flex items-center gap-2 min-w-0">
          <Avatar className="h-6 w-6 ring-1 ring-soft flex-shrink-0">
            <AvatarImage src={l.avatar} alt={l.actor} />
            <AvatarFallback>{l.actor.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <span className="text-xs font-medium text-ink truncate">{l.actor}</span>
        </div>
      ),
      width: "18%",
    },
    {
      key: "action",
      header: "Action",
      cell: (l) => (
        <span className="text-xs text-ink">{l.action}</span>
      ),
      width: "18%",
    },
    {
      key: "target",
      header: "Target",
      cell: (l) => (
        <span className="text-[11px] text-muted-foreground truncate block max-w-[200px]">
          {l.target}
        </span>
      ),
      width: "22%",
      hideOnMobile: true,
    },
    {
      key: "category",
      header: "Category",
      cell: (l) => {
        const meta = CATEGORY_META[l.category];
        return (
          <Badge
            variant="outline"
            className={cn(
              "text-[9px] font-medium capitalize border inline-flex items-center gap-1",
              meta.cls
            )}
          >
            {meta.icon}
            {l.category}
          </Badge>
        );
      },
      width: "10%",
    },
    {
      key: "ip",
      header: "IP address",
      cell: (l) => (
        <span className="text-[11px] text-muted-foreground font-mono">
          {l.ip}
        </span>
      ),
      width: "12%",
      hideOnMobile: true,
    },
    {
      key: "actions",
      header: "",
      cell: (l) => (
        <div className="flex justify-end">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() =>
              toast.message("View log details", {
                description: `${l.actor} · ${l.action} · ${l.timestamp}`,
              })
            }
          >
            <Eye className="h-3.5 w-3.5" />
          </Button>
        </div>
      ),
      width: "6%",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Audit Logs"
        description="Immutable record of all workspace activity for compliance and security"
        icon={<Shield className="h-5 w-5" />}
        badge={
          <Badge
            variant="outline"
            className="text-[10px] font-medium border-success/30 bg-success/10 text-success"
          >
            <Lock className="h-3 w-3 mr-1" /> Immutable
          </Badge>
        }
        actions={
          <Button
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Audit log exported as CSV")}
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export CSV
          </Button>
        }
      />

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search by actor, action, target, IP…",
          }}
          selects={[
            {
              label: "Category",
              value: category,
              onChange: setCategory,
              options: CATEGORY_OPTIONS,
            },
            {
              label: "Actor",
              value: actor,
              onChange: setActor,
              options: ACTOR_OPTIONS,
            },
            {
              label: "Range",
              value: range,
              onChange: setRange,
              options: RANGE_OPTIONS,
            },
          ]}
          onClear={clearFilters}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main: data table */}
        <div className="lg:col-span-2">
          {loading ? (
            <LoadingSkeleton variant="table" />
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={Shield}
              title="No audit logs match your filters"
              description="Audit logs are immutable — try widening your date range or clearing filters."
              action={{ label: "Clear filters", onClick: clearFilters }}
            />
          ) : (
            <DataTable<AuditLog>
              data={filtered}
              columns={columns}
              getRowId={(l) => l.id}
              emptyTitle="No audit logs found"
              emptyDescription="Try adjusting your filters."
              pageSize={8}
            />
          )}
        </div>

        {/* Side */}
        <div className="space-y-4">
          {/* Stats */}
          <div className="grid grid-cols-1 gap-3">
            <StatCard
              label="Events today"
              value={eventsToday}
              icon={<Activity className="h-4 w-4" />}
              accent="info"
              sublabel="recorded since 00:00 UTC"
            />
            <StatCard
              label="Unique actors"
              value={uniqueActors}
              icon={<Users className="h-4 w-4" />}
              accent="default"
              sublabel="active in last 30 days"
            />
            <StatCard
              label="Top category"
              value={topCategory ? topCategory[0] : "—"}
              icon={<FolderKanban className="h-4 w-4" />}
              accent="success"
              sublabel={topCategory ? `${topCategory[1]} events` : "no data"}
            />
          </div>

          {/* Security insights */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/10 text-friction">
                <ShieldAlert className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Security insights</h3>
            </div>
            <div className="space-y-2.5">
              <div className="flex items-center justify-between rounded-lg border border-soft p-2.5">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/10 text-friction flex-shrink-0">
                    <AlertTriangle className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink">
                      Failed logins
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      Last 24h · 3 attempts
                    </div>
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className="text-[9px] border-warning/30 bg-warning/10 text-warning"
                >
                  Watch
                </Badge>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-soft p-2.5">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-warning/10 text-warning flex-shrink-0">
                    <LogIn className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink">
                      New device sign-ins
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      2 devices this week
                    </div>
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className="text-[9px] border-info/30 bg-info/10 text-info"
                >
                  Reviewed
                </Badge>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-soft p-2.5">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/10 text-info flex-shrink-0">
                    <Database className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink">
                      Data exports
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      1 export · approved
                    </div>
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className="text-[9px] border-success/30 bg-success/10 text-success"
                >
                  Cleared
                </Badge>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-soft p-2.5">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/10 text-friction flex-shrink-0">
                    <ShieldAlert className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink">
                      Suspicious activity
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      None detected
                    </div>
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className="text-[9px] border-success/30 bg-success/10 text-success"
                >
                  Clear
                </Badge>
              </div>
            </div>
          </Card>

          {/* Retention */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Lock className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Retention policy</h3>
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Plan</span>
                <span className="text-ink font-medium">Enterprise</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Retention</span>
                <span className="text-ink font-medium">7 years</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Storage</span>
                <span className="text-ink font-medium">Tamper-evident</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Export format</span>
                <span className="text-ink font-medium">CSV / JSON</span>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() =>
                toast.message("Contact support", {
                  description: "Enterprise customers can request signed export bundles.",
                })
              }
            >
              Request signed export
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
