"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Lightbulb,
  Share2,
  Download,
  CheckCircle2,
  ChevronRight,
  Zap,
  TrendingUp,
  Users,
  LayoutGrid,
  MessageSquare,
  Target,
  Activity,
  CheckCircle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { SeverityBadge, StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useModals } from "@/hooks/use-modals";
import { INSIGHTS, getInsight } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { ScreenMockup } from "@/components/common/screen-mockup";

const STATUS_WORKFLOW: { value: string; label: string }[] = [
  { value: "new", label: "New" },
  { value: "triaging", label: "Triaging" },
  { value: "in-progress", label: "In progress" },
  { value: "resolved", label: "Resolved" },
  { value: "wontfix", label: "Won't fix" },
];

interface MockComment {
  author: string;
  avatar: string;
  time: string;
  body: string;
}

const MOCK_COMMENTS: MockComment[] = [
  {
    author: "Mira Halberg",
    avatar: "https://i.pravatar.cc/80?img=12",
    time: "2 hours ago",
    body: "Agreed — the impact score makes this a P0. Let's slot it into next sprint planning and pair with the engineering team on feasibility.",
  },
  {
    author: "Theo Park",
    avatar: "https://i.pravatar.cc/80?img=13",
    time: "5 hours ago",
    body: "I'll mock up the proposed change in Figma today. Need design review by EOD Thursday before we lock scope.",
  },
  {
    author: "Lena Ortiz",
    avatar: "https://i.pravatar.cc/80?img=45",
    time: "Yesterday",
    body: "Pulled this into the Q3 roadmap discussion. Eng capacity is tight but the evidence is compelling — pushing to prioritize.",
  },
];

function formatUsers(n: number): string {
  if (n === 0) return "—";
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return `${n}`;
}

export default function InsightDetailPage() {
  const params = useParams<{ id: string }>();
  const insight = getInsight(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [currentStatus, setCurrentStatus] = React.useState<string>(
    insight?.status ?? "new"
  );

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  // Keep the local status in sync when navigating between insights
  React.useEffect(() => {
    if (insight) setCurrentStatus(insight.status);
  }, [insight?.id]);

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  if (!insight) {
    return (
      <EmptyState
        icon={Lightbulb}
        title="Insight not found"
        description="This insight may have been moved, archived, or never existed."
        action={{ label: "Back to insights", href: "/insights" }}
      />
    );
  }

  const relatedInsights = INSIGHTS.filter(
    (i) => i.projectId === insight.projectId && i.id !== insight.id
  );
  const screenLabel = insight.projectName.split(" ")[0];

  const handleStatusChange = (next: string) => {
    setCurrentStatus(next);
    const label = STATUS_WORKFLOW.find((s) => s.value === next)?.label ?? next;
    toast.success(`Status changed to "${label}"`);
  };

  const handleMarkResolved = () => {
    setCurrentStatus("resolved");
    toast.success("Marked as resolved");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title={insight.title}
        description={insight.summary}
        breadcrumbs={[
          { label: "Insights", href: "/insights" },
          { label: `#${insight.id}` },
        ]}
        icon={<Lightbulb className="h-5 w-5" />}
        badge={<SeverityBadge severity={insight.severity} />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => openShare(`/insights/${insight.id}`, insight.title)}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Insight exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={handleMarkResolved}
              disabled={currentStatus === "resolved"}
            >
              <CheckCircle2 className="mr-2 h-3.5 w-3.5" /> Mark resolved
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column */}
        <div className="lg:col-span-2 space-y-4">
          {/* Summary */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Lightbulb className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Summary</h3>
            </div>
            <p className="text-sm text-ink leading-relaxed">{insight.summary}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge variant="secondary" className="text-[10px] capitalize">
                {insight.category.replace("-", " ")}
              </Badge>
              <Badge variant="outline" className="text-[10px]">
                {insight.projectName}
              </Badge>
              <Badge variant="outline" className="text-[10px]">
                Created {insight.createdAt}
              </Badge>
            </div>
          </Card>

          {/* Evidence */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <CheckCircle className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Evidence</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {insight.evidence.length} sources
              </Badge>
            </div>
            <div className="space-y-2">
              {insight.evidence.map((e, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-2.5 rounded-xl border border-soft p-3"
                >
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-success/15 text-success flex-shrink-0 mt-0.5">
                    <CheckCircle className="h-3 w-3" />
                  </div>
                  <div className="text-xs text-ink leading-relaxed">{e}</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Affected screens */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-warning">
                <LayoutGrid className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Affected screens</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {insight.affectedScreens} screen{insight.affectedScreens === 1 ? "" : "s"}
              </Badge>
            </div>
            <StaggerGroup className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {Array.from({ length: insight.affectedScreens }).map((_, i) => {
                const variants = ["analytics", "mobile", "list", "dashboard"] as const;
                return (
                  <StaggerItem key={i}>
                    <motion.div
                      className="rounded-xl border border-soft overflow-hidden card-hover"
                      whileHover={{ y: -3 }}
                      transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
                    >
                      <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-surface-2">
                        <ScreenMockup variant={variants[i % variants.length]} />
                        <div className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-friction z-10" />
                      </div>
                      <div className="p-1.5">
                        <div className="text-[10px] font-medium text-ink truncate">
                          {screenLabel} · {i + 1}
                        </div>
                        <div className="text-[9px] text-muted-foreground">
                          flagged in audit
                        </div>
                      </div>
                    </motion.div>
                  </StaggerItem>
                );
              })}
            </StaggerGroup>
          </Card>

          {/* Recommendation */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Target className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Recommendation</h3>
            </div>
            <p className="text-sm text-ink leading-relaxed">
              {insight.recommendation}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                size="sm"
                className="rounded-full"
                onClick={() => toast.success("Issue created from insight")}
              >
                <Zap className="mr-2 h-3.5 w-3.5" /> Create issue from insight
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="rounded-full"
                onClick={() => toast.success("Added to roadmap")}
              >
                Add to roadmap
              </Button>
            </div>
          </Card>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Impact metrics */}
          <StaggerGroup className="grid grid-cols-2 gap-3">
            <StaggerItem>
              <StatCard
                label="Impact score"
                value={insight.impact}
                unit="/100"
                icon={<TrendingUp className="h-4 w-4" />}
                accent="friction"
              />
            </StaggerItem>
            <StaggerItem>
              <StatCard
                label="Confidence"
                value={`${insight.confidence}%`}
                icon={<CheckCircle2 className="h-4 w-4" />}
                accent="info"
              />
            </StaggerItem>
            <StaggerItem>
              <StatCard
                label="Affected users"
                value={formatUsers(insight.affectedUsers)}
                icon={<Users className="h-4 w-4" />}
              />
            </StaggerItem>
            <StaggerItem>
              <StatCard
                label="Affected screens"
                value={insight.affectedScreens}
                icon={<LayoutGrid className="h-4 w-4" />}
                accent="warning"
              />
            </StaggerItem>
          </StaggerGroup>

          {/* Owner */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wide">
              Owner
            </div>
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10 ring-1 ring-soft">
                <AvatarImage src={insight.owner.avatar} alt={insight.owner.name} />
                <AvatarFallback>{insight.owner.name.slice(0, 2)}</AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <div className="text-sm font-medium text-ink">
                  {insight.owner.name}
                </div>
                <div className="text-[10px] text-muted-foreground">
                  {insight.projectName}
                </div>
              </div>
            </div>
          </Card>

          {/* Status workflow */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center gap-2 mb-3">
              <Activity className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Status workflow</h3>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {STATUS_WORKFLOW.map((s) => {
                const active = currentStatus === s.value;
                return (
                  <button
                    key={s.value}
                    onClick={() => handleStatusChange(s.value)}
                    className={cn(
                      "rounded-full border px-2.5 py-1 text-[10px] font-medium transition-all",
                      active
                        ? "border-primary/30 bg-primary/10 text-ink shadow-soft"
                        : "border-soft text-muted-foreground hover:bg-accent/30 hover:text-ink"
                    )}
                  >
                    {s.label}
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Discussion */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center gap-2 mb-3">
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Discussion</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {MOCK_COMMENTS.length}
              </Badge>
            </div>
            <div className="space-y-3">
              {MOCK_COMMENTS.map((c, idx) => (
                <div key={idx} className="flex gap-2">
                  <Avatar className="h-7 w-7 ring-1 ring-soft flex-shrink-0">
                    <AvatarImage src={c.avatar} alt={c.author} />
                    <AvatarFallback>{c.author.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-medium text-ink">
                        {c.author}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {c.time}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                      {c.body}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Comment posted")}
            >
              Add a comment
            </Button>
          </Card>
        </div>
      </div>

      {/* Related insights */}
      {relatedInsights.length > 0 && (
        <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4 card-hover">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-ink">Related insights</h3>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                From the same project — {insight.projectName}
              </p>
            </div>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/insights">
                All insights <ChevronRight className="h-3 w-3" />
              </Link>
            </Button>
          </div>
          <div className="space-y-2">
            {relatedInsights.map((i) => (
              <Link
                key={i.id}
                href={`/insights/${i.id}`}
                className="flex items-start gap-3 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors group"
              >
                <SeverityBadge severity={i.severity} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-ink group-hover:text-primary transition-colors line-clamp-1">
                    {i.title}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    Impact {i.impact} · Confidence {i.confidence}%
                  </div>
                </div>
                <StatusBadge status={i.status} />
                <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
              </Link>
            ))}
          </div>
        </Card>
      )}
    </motion.div>
  );
}
