"use client";

import * as React from "react";
import Link from "next/link";
import {
  Lightbulb,
  Plus,
  Download,
  ChevronRight,
  AlertTriangle,
  TrendingUp,
  CheckCircle2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { SeverityBadge, StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useModals } from "@/hooks/use-modals";
import { INSIGHTS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { AnimatedNumber, ProgressBar, ActiveDot } from "@/components/common/animated-progress";

const SEVERITY_OPTIONS: FilterOption[] = [
  { label: "All severities", value: "all" },
  { label: "Critical", value: "critical" },
  { label: "High", value: "high" },
  { label: "Medium", value: "medium" },
  { label: "Low", value: "low" },
];

const CATEGORY_OPTIONS: FilterOption[] = [
  { label: "All categories", value: "all" },
  { label: "Usability", value: "usability" },
  { label: "Accessibility", value: "accessibility" },
  { label: "Conversion", value: "conversion" },
  { label: "Engagement", value: "engagement" },
  { label: "Friction", value: "friction" },
  { label: "Clarity", value: "clarity" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "New", value: "new" },
  { label: "Triaging", value: "triaging" },
  { label: "In progress", value: "in-progress" },
  { label: "Resolved", value: "resolved" },
  { label: "Won't fix", value: "wontfix" },
];

const VIEW_OPTIONS = [
  { label: "Cards", value: "cards" },
  { label: "List", value: "list" },
];

export default function InsightsPage() {
  const setCreateInsightOpen = useModals((s) => s.setCreateInsightOpen);
  const [search, setSearch] = React.useState("");
  const [severity, setSeverity] = React.useState("all");
  const [category, setCategory] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [view, setView] = React.useState("cards");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return INSIGHTS.filter((i) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !i.title.toLowerCase().includes(q) &&
          !i.summary.toLowerCase().includes(q) &&
          !i.projectName.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (severity !== "all" && i.severity !== severity) return false;
      if (category !== "all" && i.category !== category) return false;
      if (status !== "all" && i.status !== status) return false;
      return true;
    }).sort((a, b) => b.impact * b.confidence - (a.impact * a.confidence));
  }, [search, severity, category, status]);

  const clearFilters = () => {
    setSearch("");
    setSeverity("all");
    setCategory("all");
    setStatus("all");
  };

  // KPIs derived directly from the INSIGHTS array
  const total = INSIGHTS.length;
  const critical = INSIGHTS.filter((i) => i.severity === "critical").length;
  const avgImpact = Math.round(
    INSIGHTS.reduce((acc, i) => acc + i.impact, 0) / INSIGHTS.length
  );
  const resolvedThisMonth = INSIGHTS.filter((i) => i.status === "resolved").length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title="Insights"
        description="Prioritized UX insights ranked by impact × confidence"
        icon={<Lightbulb className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {INSIGHTS.length} insights
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Insights exported as CSV")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export CSV
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => setCreateInsightOpen(true)}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> Create insight
            </Button>
          </>
        }
      />

      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total insights"
          value={total}
          animate
          icon={<Lightbulb className="h-4 w-4" />}
          accent="info"
          sublabel="across all projects"
        />
        <StatCard
          label="Critical"
          value={critical}
          animate
          icon={<AlertTriangle className="h-4 w-4" />}
          accent={critical > 0 ? "friction" : "success"}
          sublabel="need immediate triage"
        />
        <StatCard
          label="Avg impact"
          value={avgImpact}
          unit="/100"
          animate
          icon={<TrendingUp className="h-4 w-4" />}
          accent="warning"
          sublabel="weighted by confidence"
        />
        <StatCard
          label="Resolved this month"
          value={resolvedThisMonth}
          animate
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          sublabel="closed in July"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search insights, projects…",
          }}
          selects={[
            {
              label: "Severity",
              value: severity,
              onChange: setSeverity,
              options: SEVERITY_OPTIONS,
            },
            {
              label: "Category",
              value: category,
              onChange: setCategory,
              options: CATEGORY_OPTIONS,
            },
            {
              label: "Status",
              value: status,
              onChange: setStatus,
              options: STATUS_OPTIONS,
            },
          ]}
          viewSwitch={{ options: VIEW_OPTIONS, value: view, onChange: setView }}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Lightbulb}
          title="No insights match your filters"
          description="Try adjusting search or filters, or create a new insight to capture a finding."
          action={{ label: "Create insight", onClick: () => setCreateInsightOpen(true) }}
          secondaryAction={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : view === "cards" ? (
        <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {filtered.map((i) => (
              <StaggerItem key={i.id}>
                <Link href={`/insights/${i.id}`} className="group block h-full">
                  <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col card-hover">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <SeverityBadge severity={i.severity} />
                        <Badge variant="secondary" className="text-[10px] capitalize">
                          {i.category.replace("-", " ")}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {i.status === "new" && <ActiveDot color="var(--info)" size={6} />}
                        <StatusBadge status={i.status} />
                      </div>
                    </div>
                    <div className="font-semibold text-sm text-ink group-hover:text-primary transition-colors line-clamp-2 mb-1">
                      {i.title}
                    </div>
                    <div className="text-xs text-muted-foreground line-clamp-2 mb-3">
                      {i.summary}
                    </div>
                    <div className="space-y-2 mb-3">
                      <div>
                        <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                          <span>Impact</span>
                          <span className="font-medium text-ink"><AnimatedNumber value={i.impact} duration={1.2} /></span>
                        </div>
                        <ProgressBar
                          value={i.impact}
                          color="var(--friction)"
                          trackColor="var(--surface-2)"
                          height={6}
                          delay={0.15}
                        />
                      </div>
                      <div>
                        <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                          <span>Confidence</span>
                          <span className="font-medium text-ink"><AnimatedNumber value={i.confidence} suffix="%" duration={1.2} /></span>
                        </div>
                        <ProgressBar
                          value={i.confidence}
                          color="var(--info)"
                          trackColor="var(--surface-2)"
                          height={6}
                          delay={0.25}
                        />
                      </div>
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-3 border-t border-soft">
                      <div className="flex items-center gap-2 min-w-0">
                        <Avatar className="h-6 w-6 ring-1 ring-soft flex-shrink-0">
                          <AvatarImage src={i.owner.avatar} alt={i.owner.name} />
                          <AvatarFallback>{i.owner.name.slice(0, 2)}</AvatarFallback>
                        </Avatar>
                        <div className="text-[10px] text-muted-foreground truncate">
                          {i.projectName}
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
                    </div>
                  </Card>
                </Link>
              </StaggerItem>
            ))}
          </AnimatePresence>
        </StaggerGroup>
      ) : (
        <Card className="rounded-2xl border-soft shadow-soft overflow-hidden card-hover">
          <AnimatePresence mode="popLayout">
            {filtered.map((i, idx) => (
              <motion.div
                key={i.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
              >
                <Link
                  href={`/insights/${i.id}`}
                  className={cn(
                    "flex items-center gap-3 p-3 hover:bg-accent/30 transition-colors group",
                    idx !== filtered.length - 1 && "border-b border-soft"
                  )}
                >
                  <SeverityBadge severity={i.severity} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-ink group-hover:text-primary transition-colors line-clamp-1">
                      {i.title}
                    </div>
                    <div className="text-[10px] text-muted-foreground truncate">
                      {i.projectName} · Impact <AnimatedNumber value={i.impact} duration={1.2} /> · Confidence <AnimatedNumber value={i.confidence} suffix="%" duration={1.2} />
                    </div>
                  </div>
                  <Avatar className="hidden sm:flex h-6 w-6 ring-1 ring-soft flex-shrink-0">
                    <AvatarImage src={i.owner.avatar} alt={i.owner.name} />
                    <AvatarFallback>{i.owner.name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex items-center gap-1.5">
                    {i.status === "new" && <ActiveDot color="var(--info)" size={6} />}
                    <StatusBadge status={i.status} />
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
                </Link>
              </motion.div>
            ))}
          </AnimatePresence>
        </Card>
      )}
    </motion.div>
  );
}
