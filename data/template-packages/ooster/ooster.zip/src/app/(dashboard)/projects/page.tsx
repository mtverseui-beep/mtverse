"use client";

import * as React from "react";
import Link from "next/link";
import { FolderKanban, Plus, LayoutGrid, List, Search, SlidersHorizontal, ChevronRight } from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { useModals } from "@/hooks/use-modals";
import { PROJECTS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { AnimatedNumber, ActiveDot } from "@/components/common/animated-progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const TYPES = [
  { value: "all", label: "All types" },
  { value: "web", label: "Web app" },
  { value: "mobile", label: "Mobile app" },
  { value: "prototype", label: "Prototype" },
  { value: "design-system", label: "Design system" },
];

const STATUSES = [
  { value: "all", label: "All statuses" },
  { value: "active", label: "Active" },
  { value: "paused", label: "Paused" },
  { value: "draft", label: "Draft" },
  { value: "archived", label: "Archived" },
];

const SORTS = [
  { value: "recent", label: "Recently updated" },
  { value: "score", label: "UX score (high to low)" },
  { value: "issues", label: "Most issues" },
  { value: "screens", label: "Most screens" },
];

export default function ProjectsPage() {
  const setCreateOpen = useModals((s) => s.setCreateProjectOpen);
  const [search, setSearch] = React.useState("");
  const [type, setType] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [sort, setSort] = React.useState("recent");
  const [view, setView] = React.useState<"grid" | "list">("grid");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 350);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    let arr = PROJECTS.filter((p) => {
      if (search && !p.name.toLowerCase().includes(search.toLowerCase()) && !p.tags.some((t) => t.includes(search.toLowerCase()))) return false;
      if (type !== "all" && p.type !== type) return false;
      if (status !== "all" && p.status !== status) return false;
      return true;
    });
    if (sort === "score") arr = arr.sort((a, b) => b.uxScore - a.uxScore);
    else if (sort === "issues") arr = arr.sort((a, b) => b.issueCount - a.issueCount);
    else if (sort === "screens") arr = arr.sort((a, b) => b.screenCount - a.screenCount);
    return arr;
  }, [search, type, status, sort]);

  const clearFilters = () => {
    setSearch("");
    setType("all");
    setStatus("all");
    setSort("recent");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title="Projects"
        description="Your UX research & analytics portfolio. Each project is a complete audit workspace."
        breadcrumbs={[{ label: "Projects" }]}
        icon={<FolderKanban className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">{PROJECTS.length} projects</Badge>}
        actions={
          <>
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.success("View saved")}>
              <SlidersHorizontal className="mr-2 h-3.5 w-3.5" /> Save view
            </Button>
            <Button size="sm" className="rounded-full" onClick={() => setCreateOpen(true)}>
              <Plus className="mr-2 h-3.5 w-3.5" /> New project
            </Button>
          </>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search projects, tags…"
            className="pl-8 h-9 text-xs"
          />
        </div>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="h-9 w-auto text-xs gap-1.5 min-w-[120px]"><SlidersHorizontal className="h-3 w-3 opacity-60" /><SelectValue /></SelectTrigger>
          <SelectContent>{TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="h-9 w-auto text-xs gap-1.5 min-w-[120px]"><SlidersHorizontal className="h-3 w-3 opacity-60" /><SelectValue /></SelectTrigger>
          <SelectContent>{STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger className="h-9 w-auto text-xs gap-1.5 min-w-[140px]"><SelectValue /></SelectTrigger>
          <SelectContent>{SORTS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
        </Select>
        {(search || type !== "all" || status !== "all") && (
          <Button variant="ghost" size="sm" className="h-9 text-xs" onClick={clearFilters}>Clear</Button>
        )}
        <div className="ml-auto inline-flex items-center rounded-full bg-surface-2 p-0.5">
          <motion.button
            onClick={() => setView("grid")}
            className={cn("p-1.5 rounded-full", view === "grid" ? "bg-card shadow-soft text-ink" : "text-muted-foreground")}
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.94 }}
            aria-label="Grid view"
          >
            <LayoutGrid className="h-3.5 w-3.5" />
          </motion.button>
          <motion.button
            onClick={() => setView("list")}
            className={cn("p-1.5 rounded-full", view === "list" ? "bg-card shadow-soft text-ink" : "text-muted-foreground")}
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.94 }}
            aria-label="List view"
          >
            <List className="h-3.5 w-3.5" />
          </motion.button>
        </div>
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={FolderKanban}
          title="No projects match your filters"
          description="Try adjusting search or filters, or create a new project to get started."
          action={{ label: "Create project", onClick: () => setCreateOpen(true) }}
          secondaryAction={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : view === "grid" ? (
        <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {filtered.map((p) => (
              <StaggerItem key={p.id}>
                <Link href={`/projects/${p.slug}`} className="group block">
                  <Card className="rounded-2xl border-soft shadow-soft overflow-hidden hover:shadow-card hover:border-primary/30 transition-all card-hover">
                    <div className="h-28 relative" style={{ background: `linear-gradient(135deg, color-mix(in oklch, ${p.thumbColor} 30%, var(--surface-2)), var(--surface-2))` }}>
                      <div className="absolute top-2 right-2 flex items-center gap-1.5">
                        {p.status === "active" && <ActiveDot color="var(--success)" size={6} />}
                        <StatusBadge status={p.status as any} />
                      </div>
                      <div className="absolute bottom-2 left-3 flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg text-white" style={{ background: p.thumbColor }}>
                          <FolderKanban className="h-4 w-4" />
                        </div>
                        <Badge variant="secondary" className="text-[10px] capitalize">{p.type.replace("-", " ")}</Badge>
                      </div>
                    </div>
                    <div className="p-4 space-y-3">
                      <div>
                        <div className="font-semibold text-sm text-ink group-hover:text-primary transition-colors">{p.name}</div>
                        <div className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{p.description}</div>
                      </div>
                      <div className="flex items-center gap-4 text-xs">
                        <div>
                          <div className="text-[10px] text-muted-foreground">UX score</div>
                          <div className="font-semibold text-ink"><AnimatedNumber value={p.uxScore} duration={1.2} /></div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground">Screens</div>
                          <div className="font-semibold text-ink"><AnimatedNumber value={p.screenCount} duration={1.2} /></div>
                        </div>
                        <div>
                          <div className="text-[10px] text-muted-foreground">Issues</div>
                          <div className="font-semibold text-ink"><AnimatedNumber value={p.issueCount} duration={1.2} /></div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-soft">
                        <div className="flex -space-x-1.5">
                          {p.members.slice(0, 3).map((m) => (
                            <Avatar key={m.name} className="h-6 w-6 ring-2 ring-card">
                              <AvatarImage src={m.avatar} alt={m.name} />
                              <AvatarFallback>{m.name.slice(0, 2)}</AvatarFallback>
                            </Avatar>
                          ))}
                          {p.members.length > 3 && (
                            <div className="h-6 w-6 rounded-full bg-surface-2 ring-2 ring-card flex items-center justify-center text-[9px] font-medium">
                              +{p.members.length - 3}
                            </div>
                          )}
                        </div>
                        <span className="text-[10px] text-muted-foreground">{p.lastAnalyzed}</span>
                      </div>
                    </div>
                  </Card>
                </Link>
              </StaggerItem>
            ))}
          </AnimatePresence>
        </StaggerGroup>
      ) : (
        <Card className="rounded-2xl border-soft shadow-soft overflow-hidden card-hover">
          <AnimatePresence mode="popLayout">
            {filtered.map((p, i) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
              >
                <Link
                  href={`/projects/${p.slug}`}
                  className={cn("flex items-center gap-4 p-3 hover:bg-accent/30 transition-colors group", i !== filtered.length - 1 && "border-b border-soft")}
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg text-white flex-shrink-0" style={{ background: p.thumbColor }}>
                    <FolderKanban className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-ink group-hover:text-primary transition-colors">{p.name}</div>
                    <div className="text-xs text-muted-foreground truncate">{p.description}</div>
                  </div>
                  <div className="hidden sm:flex items-center gap-6 text-xs">
                    <div className="text-center">
                      <div className="text-[10px] text-muted-foreground">UX</div>
                      <div className="font-semibold"><AnimatedNumber value={p.uxScore} duration={1.2} /></div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] text-muted-foreground">Screens</div>
                      <div className="font-semibold"><AnimatedNumber value={p.screenCount} duration={1.2} /></div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] text-muted-foreground">Issues</div>
                      <div className="font-semibold"><AnimatedNumber value={p.issueCount} duration={1.2} /></div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {p.status === "active" && <ActiveDot color="var(--success)" size={6} />}
                    <StatusBadge status={p.status as any} />
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink" />
                </Link>
              </motion.div>
            ))}
          </AnimatePresence>
        </Card>
      )}
    </motion.div>
  );
}
