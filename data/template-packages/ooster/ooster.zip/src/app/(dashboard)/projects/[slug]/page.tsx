"use client";

import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { ScreenMockup } from "@/components/common/screen-mockup";
import {
  FolderKanban, Settings, Share2, Download, ChevronRight, Flame, FileText,
  Lightbulb, Users, Activity, Eye, AlertTriangle, CheckCircle2, Clock, Plus, MoreHorizontal, Maximize2
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter } from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ScoreRadar } from "@/components/charts/score-radar";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge, SeverityBadge } from "@/components/common/badges";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { EmptyState } from "@/components/common/empty-state";
import { motion } from "framer-motion";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { useModals } from "@/hooks/use-modals";
import { PROJECTS, INSIGHTS, REPORTS, ISSUES, RECENT_ACTIVITY, getProject } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function ProjectDetailPage() {
  const params = useParams<{ slug: string }>();
  const router = useRouter();
  const project = getProject(params.slug);
  const setSettingsOpen = useModals((s) => s.setSettingsDrawerOpen);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [tab, setTab] = React.useState("overview");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 250);
    return () => clearTimeout(t);
  }, []);

  if (!project) {
    return (
      <EmptyState
        icon={FolderKanban}
        title="Project not found"
        description="This project may have been moved, archived, or never existed."
        action={{ label: "Back to projects", href: "/projects" }}
      />
    );
  }

  const projectInsights = INSIGHTS.filter((i) => i.projectId === project.id);
  const projectReports = REPORTS.filter((r) => r.project === project.name);
  const projectIssues = ISSUES.filter((i) => i.project === project.name);

  const radarData = [
    { label: "Usability", value: project.uxScore, key: "usability" },
    { label: "Accessibility", value: project.accessibilityScore, key: "a11y" },
    { label: "Conversion", value: project.conversionScore, key: "conv" },
    { label: "Engagement", value: project.engagementScore, key: "eng" },
    { label: "Cognitive", value: project.cognitiveLoadScore, key: "cog" },
    { label: "Friction", value: 100 - project.frictionScore, key: "fric" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title={project.name}
        description={project.description}
        breadcrumbs={[
          { label: "Projects", href: "/projects" },
          { label: project.name },
        ]}
        icon={<div className="flex h-5 w-5 items-center justify-center rounded-md text-white" style={{ background: project.thumbColor }}><FolderKanban className="h-3.5 w-3.5" /></div>}
        badge={<StatusBadge status={project.status as any} />}
        actions={
          <>
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.success("Snapshot exported")}>
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button variant="outline" size="sm" className="rounded-full" onClick={() => openShare(`/projects/${project.slug}`, project.name)}>
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button size="sm" className="rounded-full" onClick={() => setSettingsOpen(true)}>
              <Settings className="mr-2 h-3.5 w-3.5" /> Settings
            </Button>
          </>
        }
      />

      {/* Stat row */}
      <StaggerGroup className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StaggerItem><StatCard label="UX score" value={project.uxScore} unit="/100" icon={<Eye className="h-4 w-4" />} accent={project.uxScore > 80 ? "success" : project.uxScore > 65 ? "warning" : "friction"} trend={{ value: 4.2, direction: "up", good: true }} sublabel="vs last week" /></StaggerItem>
        <StaggerItem><StatCard label="Friction" value={project.frictionScore} unit="/100" icon={<AlertTriangle className="h-4 w-4" />} accent={project.frictionScore < 30 ? "success" : "friction"} trend={{ value: 2.8, direction: "down", good: true }} sublabel="vs last week" /></StaggerItem>
        <StaggerItem><StatCard label="Task success" value={`${project.taskSuccessRate}%`} icon={<CheckCircle2 className="h-4 w-4" />} trend={{ value: 1.5, direction: "up", good: true }} sublabel="vs last week" /></StaggerItem>
        <StaggerItem><StatCard label="Drop-off risk" value={`${project.dropOffRisk}%`} icon={<AlertTriangle className="h-4 w-4" />} accent={project.dropOffRisk < 25 ? "success" : "friction"} trend={{ value: 3.1, direction: "up", good: false }} sublabel="vs last week" /></StaggerItem>
      </StaggerGroup>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-surface-2 rounded-full p-0.5 h-9 overflow-x-auto no-scrollbar max-w-full">
          <TabsTrigger value="overview" className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft hover:-translate-y-0.5 transition-transform">Overview</TabsTrigger>
          <TabsTrigger value="screens" className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft hover:-translate-y-0.5 transition-transform">Screens</TabsTrigger>
          <TabsTrigger value="insights" className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft hover:-translate-y-0.5 transition-transform">Insights</TabsTrigger>
          <TabsTrigger value="issues" className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft hover:-translate-y-0.5 transition-transform">Issues</TabsTrigger>
          <TabsTrigger value="reports" className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft hover:-translate-y-0.5 transition-transform">Reports</TabsTrigger>
          <TabsTrigger value="team" className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft hover:-translate-y-0.5 transition-transform">Team</TabsTrigger>
          <TabsTrigger value="activity" className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft hover:-translate-y-0.5 transition-transform">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4 space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
              <h3 className="text-sm font-semibold text-ink mb-3">UX score breakdown</h3>
              <div className="h-56 flex items-center justify-center">
                <ScoreRadar data={radarData} size={240} />
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2 card-hover">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-ink">Screen preview</h3>
                <Button variant="ghost" size="sm" className="text-xs" onClick={() => { toast.message("Opening heatmaps…"); router.push(`/heatmaps`); }}>
                  Open heatmaps <ChevronRight className="h-3 w-3" />
                </Button>
              </div>
              <div className="relative h-56 rounded-xl overflow-hidden bg-surface-2">
                <ScreenMockup variant="dashboard" accentColor={project.thumbColor} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
                <div className="absolute inset-x-0 top-0 z-10 flex flex-col items-center justify-center h-full text-center px-6">
                  <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl text-white shadow-card" style={{ background: project.thumbColor }}>
                    <Eye className="h-5 w-5" />
                  </div>
                  <div className="text-xs font-medium text-white drop-shadow-sm">{project.screenCount} screens analyzed</div>
                  <Button asChild size="sm" variant="secondary" className="mt-3 h-7 text-xs rounded-full">
                    <Link href={`/heatmaps`}><Flame className="mr-1 h-3 w-3" /> View heatmaps</Link>
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-ink">Recent insights</h3>
                <Button asChild variant="ghost" size="sm" className="text-xs">
                  <Link href="/insights">All <ChevronRight className="h-3 w-3" /></Link>
                </Button>
              </div>
              <div className="space-y-2">
                {projectInsights.slice(0, 3).map((i) => (
                  <Link key={i.id} href={`/insights/${i.id}`} className="flex items-start gap-2 rounded-xl border border-soft p-2.5 hover:bg-accent/30 transition-colors">
                    <SeverityBadge severity={i.severity as any} />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium text-ink line-clamp-1">{i.title}</div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">Impact {i.impact} · Confidence {i.confidence}%</div>
                    </div>
                  </Link>
                ))}
                {projectInsights.length === 0 && (
                  <div className="text-xs text-muted-foreground text-center py-6">No insights yet for this project.</div>
                )}
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-ink">Recent activity</h3>
                <Button asChild variant="ghost" size="sm" className="text-xs">
                  <Link href="/history">All <ChevronRight className="h-3 w-3" /></Link>
                </Button>
              </div>
              <div className="space-y-2">
                {RECENT_ACTIVITY.slice(0, 4).map((a) => (
                  <div key={a.id} className="flex gap-2">
                    <Avatar className="h-6 w-6 ring-1 ring-soft">
                      <AvatarImage src={a.avatar} alt={a.actor} />
                      <AvatarFallback>{a.actor.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs"><span className="font-medium text-ink">{a.actor}</span> <span className="text-muted-foreground">{a.action}</span> <span className="font-medium text-ink">{a.target}</span></div>
                      <div className="text-[10px] text-muted-foreground">{a.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="screens" className="mt-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <StaggerGroup className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {Array.from({ length: Math.min(8, project.screenCount) }).map((_, i) => {
                const variants = ["analytics", "checkout", "onboarding", "list", "dashboard", "mobile"] as const;
                return (
                  <StaggerItem key={i}>
                    <motion.div
                      className="rounded-xl border border-soft overflow-hidden card-hover"
                      whileHover={{ y: -3 }}
                      transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
                    >
                      <div className="relative aspect-[4/3] rounded-lg overflow-hidden bg-surface-2">
                        <ScreenMockup variant={variants[i % variants.length]} />
                        <div className="absolute top-1.5 right-1.5 z-10">
                          <Badge variant="outline" className="text-[9px] bg-card/80 backdrop-blur-sm">UX {70 + i * 2}</Badge>
                        </div>
                      </div>
                      <div className="p-2">
                        <div className="text-[10px] font-medium text-ink truncate">Screen {i + 1}</div>
                        <div className="text-[9px] text-muted-foreground">UX {70 + i * 2}</div>
                      </div>
                    </motion.div>
                  </StaggerItem>
                );
              })}
            </StaggerGroup>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="mt-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            {projectInsights.length > 0 ? (
              <div className="space-y-2">
                {projectInsights.map((i) => (
                  <Link key={i.id} href={`/insights/${i.id}`} className="flex items-start gap-3 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors">
                    <SeverityBadge severity={i.severity as any} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-ink">{i.title}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{i.summary}</div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </Link>
                ))}
              </div>
            ) : (
              <EmptyState icon={Lightbulb} title="No insights yet" description="Generate an AI report or run usability tests to surface insights." compact />
            )}
          </Card>
        </TabsContent>

        <TabsContent value="issues" className="mt-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            {projectIssues.length > 0 ? (
              <div className="space-y-2">
                {projectIssues.map((i) => (
                  <Link key={i.id} href={`/issues/${i.id}`} className="flex items-center gap-3 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors">
                    <SeverityBadge severity={i.severity as any} />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-ink">{i.title}</div>
                      <div className="text-[10px] text-muted-foreground">{i.screen} · {i.comments} comments</div>
                    </div>
                    <StatusBadge status={i.status as any} />
                  </Link>
                ))}
              </div>
            ) : (
              <EmptyState icon={AlertTriangle} title="No issues tracked" description="Issues from audits and tests will appear here." compact />
            )}
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="mt-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            {projectReports.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {projectReports.map((r) => (
                  <Link key={r.id} href={`/reports/${r.id}`} className="rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors">
                    <div className="flex items-center justify-between mb-1">
                      <FileText className="h-4 w-4 text-info" />
                      <StatusBadge status={r.status as any} />
                    </div>
                    <div className="text-sm font-medium text-ink">{r.title}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{r.pages}p · {r.duration}</div>
                  </Link>
                ))}
              </div>
            ) : (
              <EmptyState icon={FileText} title="No reports yet" description="Generate your first AI report for this project." compact action={{ label: "Generate report", onClick: () => useModals.getState().setGenerateReportOpen(true) }} />
            )}
          </Card>
        </TabsContent>

        <TabsContent value="team" className="mt-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="space-y-2">
              {project.members.map((m) => (
                <div key={m.name} className="flex items-center gap-3 rounded-xl border border-soft p-3">
                  <Avatar className="h-9 w-9 ring-1 ring-soft">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback>{m.name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-ink">{m.name}</div>
                    <div className="text-[10px] text-muted-foreground">{m.role}</div>
                  </div>
                  <Badge variant="secondary" className="text-[10px]">{m.role}</Badge>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="mt-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="space-y-3">
              {RECENT_ACTIVITY.map((a) => (
                <div key={a.id} className="flex gap-3">
                  <Avatar className="h-8 w-8 ring-1 ring-soft">
                    <AvatarImage src={a.avatar} alt={a.actor} />
                    <AvatarFallback>{a.actor.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="text-xs"><span className="font-medium text-ink">{a.actor}</span> <span className="text-muted-foreground">{a.action}</span> <span className="font-medium text-ink">{a.target}</span></div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{a.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      <ProjectSettingsDrawer project={project} />
    </motion.div>
  );
}

function ProjectSettingsDrawer({ project }: { project: any }) {
  const open = useModals((s) => s.settingsDrawerOpen);
  const setOpen = useModals((s) => s.setSettingsDrawerOpen);
  const openConfirm = useModals((s) => s.openConfirm);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent className="w-full sm:max-w-md p-0 overflow-y-auto">
        <SheetHeader className="p-4 border-b border-soft">
          <SheetTitle>Project settings</SheetTitle>
        </SheetHeader>
        <div className="p-4 space-y-5">
          <div className="space-y-2">
            <Label>Project name</Label>
            <input defaultValue={project.name} className="w-full h-9 rounded-lg border border-soft bg-surface px-3 text-sm" />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <textarea defaultValue={project.description} rows={3} className="w-full rounded-lg border border-soft bg-surface px-3 py-2 text-sm" />
          </div>
          <div className="space-y-3">
            <Label>Preferences</Label>
            <div className="space-y-3">
              {[
                { label: "Auto-generate weekly reports", desc: "Ooster AI creates a summary every Monday" },
                { label: "Notify on critical insights", desc: "Slack + email when severity = critical" },
                { label: "Allow public sharing", desc: "Anyone with link can view this project" },
                { label: "Track scroll depth", desc: "Adds scroll tracking to all screens" },
              ].map((opt) => (
                <div key={opt.label} className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-medium text-ink">{opt.label}</div>
                    <div className="text-[10px] text-muted-foreground">{opt.desc}</div>
                  </div>
                  <Switch defaultChecked />
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-friction/20 bg-friction/5 p-3">
            <div className="text-sm font-medium text-friction mb-1">Danger zone</div>
            <Button
              variant="outline"
              size="sm"
              className="border-friction/30 text-friction hover:bg-friction/10"
              onClick={() => {
                setOpen(false);
                openConfirm({
                  title: "Archive this project?",
                  description: `"${project.name}" will be archived. You can restore it later, but active tracking stops immediately.`,
                  onConfirm: () => toast.success("Project archived"),
                });
              }}
            >
              Archive project
            </Button>
          </div>
        </div>
        <SheetFooter className="p-4 border-t border-soft flex-row gap-2">
          <Button variant="ghost" className="flex-1" onClick={() => setOpen(false)}>Cancel</Button>
          <Button className="flex-1" onClick={() => { setOpen(false); toast.success("Settings saved"); }}>Save changes</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
