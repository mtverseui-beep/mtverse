"use client";

import * as React from "react";
import {
  MousePointerClick,
  Flame,
  XCircle,
  Users,
  Download,
  Zap,
  TrendingUp,
  Layers,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LineChart } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type ClickType = "normal" | "rage" | "dead";

interface ClickCluster {
  x: number;
  y: number;
  count: number;
  type: ClickType;
  label: string;
}

// Mock click clusters on 16:9 canvas (percentages)
const CLICK_CLUSTERS: ClickCluster[] = [
  { x: 48, y: 42, count: 384, type: "normal", label: "Primary CTA" },
  { x: 72, y: 38, count: 218, type: "normal", label: "Sign up link" },
  { x: 24, y: 48, count: 142, type: "normal", label: "Logo / home" },
  { x: 48, y: 42, count: 64, type: "rage", label: "CTA (rage clicks)" },
  { x: 88, y: 70, count: 38, type: "dead", label: "Decorative image" },
  { x: 14, y: 82, count: 28, type: "dead", label: "Footer divider" },
  { x: 60, y: 68, count: 96, type: "normal", label: "Pricing tier 2" },
  { x: 38, y: 70, count: 22, type: "rage", label: "Disabled button" },
  { x: 78, y: 82, count: 18, type: "dead", label: "Static banner" },
];

const TOP_ELEMENTS = [
  { rank: 1, name: "Primary CTA", clicks: 384, conversion: 42, type: "normal" as const },
  { rank: 2, name: "Sign up link", clicks: 218, conversion: 28, type: "normal" as const },
  { rank: 3, name: "Pricing tier 2", clicks: 96, conversion: 19, type: "normal" as const },
  { rank: 4, name: "Logo / home", clicks: 142, conversion: 8, type: "normal" as const },
  { rank: 5, name: "Play demo", clicks: 74, conversion: 22, type: "normal" as const },
];

const RAGE_HOTSPOTS = [
  { name: "Disabled button (form submit)", clicks: 38, sessions: 12 },
  { name: "CTA on success state", clicks: 64, sessions: 21 },
  { name: "Image-based 'button'", clicks: 22, sessions: 8 },
];

const DEAD_ZONES = [
  { name: "Decorative hero image", clicks: 38 },
  { name: "Footer divider line", clicks: 28 },
  { name: "Static promo banner", clicks: 18 },
];

const TYPE_COLOR: Record<ClickType, string> = {
  normal: "var(--info)",
  rage: "var(--friction)",
  dead: "var(--warning)",
};

const TYPE_LABEL: Record<ClickType, string> = {
  normal: "Normal",
  rage: "Rage",
  dead: "Dead",
};

const TREND = Array.from({ length: 12 }, (_, i) => ({
  label: `W${i + 1}`,
  values: [
    { label: "Total clicks", value: 2400 + i * 180 + Math.round(Math.sin(i) * 220) },
    { label: "Rage clicks", value: 120 + Math.round(Math.sin(i * 0.7) * 40) + i * 4 },
  ],
}));

export default function ClickMapsPage() {
  const [loading, setLoading] = React.useState(true);
  const [project, setProject] = React.useState("all");
  const [screen, setScreen] = React.useState("0");
  const [device, setDevice] = React.useState("all");
  const [clickType, setClickType] = React.useState("all");
  const [hovered, setHovered] = React.useState<string | null>(null);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const totalClicks = CLICK_CLUSTERS.reduce((a, b) => a + b.count, 0);
  const avgPerSession = 8.4;
  const rageClicks = CLICK_CLUSTERS.filter((c) => c.type === "rage").reduce((a, b) => a + b.count, 0);
  const deadClicks = CLICK_CLUSTERS.filter((c) => c.type === "dead").reduce((a, b) => a + b.count, 0);

  const filteredClusters = clickType === "all" ? CLICK_CLUSTERS : CLICK_CLUSTERS.filter((c) => c.type === clickType);

  return (
    <div>
      <PageHeader
        title="Click Maps"
        description="Click, tap, and rage-click density across all screens"
        breadcrumbs={[{ label: "Analytics" }, { label: "Click Maps" }]}
        icon={<MousePointerClick className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">Real-time</Badge>}
        actions={
          <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.success("Click data exported as CSV")}>
            <Download className="mr-2 h-3.5 w-3.5" /> Export
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Filter bar */}
          <Card className="rounded-2xl border-soft shadow-soft p-3 mb-4">
            <FilterBar
              selects={[
                {
                  label: "Project",
                  value: project,
                  onChange: setProject,
                  options: [
                    { label: "All projects", value: "all" },
                    { label: "Atlas Onboarding", value: "atlas" },
                    { label: "Northwind Checkout", value: "northwind" },
                    { label: "Voyage Booking", value: "voyage" },
                  ],
                },
                {
                  label: "Screen",
                  value: screen,
                  onChange: setScreen,
                  options: [
                    { label: "Landing / Home", value: "0" },
                    { label: "Pricing", value: "1" },
                    { label: "Checkout — Step 1", value: "2" },
                    { label: "Product detail", value: "3" },
                  ],
                },
                {
                  label: "Device",
                  value: device,
                  onChange: setDevice,
                  options: [
                    { label: "All devices", value: "all" },
                    { label: "Desktop", value: "desktop" },
                    { label: "Mobile", value: "mobile" },
                    { label: "Tablet", value: "tablet" },
                  ],
                },
                {
                  label: "Click type",
                  value: clickType,
                  onChange: setClickType,
                  options: [
                    { label: "All clicks", value: "all" },
                    { label: "Normal", value: "normal" },
                    { label: "Rage", value: "rage" },
                    { label: "Dead", value: "dead" },
                  ],
                },
              ]}
              onClear={() => { setProject("all"); setScreen("0"); setDevice("all"); setClickType("all"); }}
            />
          </Card>

          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Total clicks"
              value={totalClicks.toLocaleString()}
              icon={<MousePointerClick className="h-4 w-4" />}
              accent="info"
              trend={{ value: 12, direction: "up", good: true }}
              sublabel="last 30 days"
            />
            <StatCard
              label="Avg clicks per session"
              value={avgPerSession}
              icon={<Layers className="h-4 w-4" />}
              accent="default"
              trend={{ value: 0.4, direction: "up", good: false }}
              sublabel="vs benchmark 6.2"
            />
            <StatCard
              label="Rage clicks"
              value={rageClicks}
              icon={<Flame className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 1.8, direction: "up", good: false }}
              sublabel="across 41 sessions"
            />
            <StatCard
              label="Dead clicks"
              value={deadClicks}
              icon={<XCircle className="h-4 w-4" />}
              accent="warning"
              trend={{ value: 3.2, direction: "down", good: true }}
              sublabel="clicks on non-interactive"
            />
          </div>

          {/* Main grid: visualization + side */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            {/* Click visualization */}
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Click density map</div>
                  <div className="text-[11px] text-muted-foreground">9 active clusters · hover for detail</div>
                </div>
                <div className="flex items-center gap-3 text-[10px]">
                  {(["normal", "rage", "dead"] as const).map((k) => (
                    <div key={k} className="flex items-center gap-1.5">
                      <span className="h-3 w-3 rounded-full" style={{ background: TYPE_COLOR[k] }} />
                      <span className="text-muted-foreground">{TYPE_LABEL[k]}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 16:9 visualization */}
              <div className="relative w-full overflow-hidden rounded-xl bg-surface-2" style={{ aspectRatio: "16 / 9" }}>
                {/* Mock screen content */}
                <div className="absolute inset-0 p-4 sm:p-6 flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <div className="h-3 w-20 rounded bg-muted-foreground/20" />
                    <div className="flex gap-2">
                      <div className="h-3 w-8 rounded bg-muted-foreground/15" />
                      <div className="h-3 w-8 rounded bg-muted-foreground/15" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 flex-1">
                    <div className="space-y-2">
                      <div className="h-5 w-3/4 rounded bg-muted-foreground/25" />
                      <div className="h-2 w-full rounded bg-muted-foreground/10" />
                      <div className="h-2 w-5/6 rounded bg-muted-foreground/10" />
                      <div className="h-7 w-24 rounded-lg bg-info/30 mt-2" />
                    </div>
                    <div className="rounded-lg bg-muted-foreground/15" />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="h-10 rounded bg-muted-foreground/10" />
                    <div className="h-10 rounded bg-muted-foreground/10" />
                    <div className="h-10 rounded bg-muted-foreground/10" />
                  </div>
                </div>

                {/* Click clusters */}
                {filteredClusters.map((c, i) => {
                  const size = Math.min(48, Math.max(16, c.count / 12));
                  const isHovered = hovered === `${c.label}-${i}`;
                  return (
                    <button
                      key={`${c.label}-${i}`}
                      className="absolute -translate-x-1/2 -translate-y-1/2 group"
                      style={{ left: `${c.x}%`, top: `${c.y}%` }}
                      onMouseEnter={() => setHovered(`${c.label}-${i}`)}
                      onMouseLeave={() => setHovered(null)}
                      onClick={() => toast.info(`${c.label}: ${c.count} ${c.type} clicks`)}
                      aria-label={`${c.label}: ${c.count} clicks`}
                    >
                      {/* Outer pulse for rage */}
                      {c.type === "rage" && (
                        <span
                          className="absolute inset-0 rounded-full animate-ping"
                          style={{ background: TYPE_COLOR.rage, opacity: 0.3 }}
                        />
                      )}
                      {/* Dot */}
                      <span
                        className="block rounded-full border-2 border-white/80 shadow-soft transition-transform group-hover:scale-110"
                        style={{ width: size, height: size, background: TYPE_COLOR[c.type], opacity: 0.85 }}
                      />
                      {/* Count badge */}
                      <span
                        className={cn(
                          "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[9px] font-bold text-white pointer-events-none",
                          isHovered ? "scale-110" : ""
                        )}
                        style={{ transition: "transform 0.15s" }}
                      >
                        {c.count}
                      </span>
                      {/* Hover tooltip */}
                      {isHovered && (
                        <div className="absolute left-1/2 -translate-x-1/2 -bottom-7 px-1.5 py-0.5 rounded bg-card border border-soft text-[9px] font-medium text-ink shadow-pop whitespace-nowrap z-20">
                          {c.label}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="mt-3 pt-3 border-t border-soft text-[10px] text-muted-foreground">
                Click any cluster to view session replays filtered to that element.
              </div>
            </Card>

            {/* Side lists */}
            <div className="flex flex-col gap-4">
              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <MousePointerClick className="h-4 w-4 text-info" />
                  <div className="text-sm font-semibold text-ink">Top clicked elements</div>
                </div>
                <div className="space-y-2.5">
                  {TOP_ELEMENTS.map((e) => (
                    <div key={e.rank} className="space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="text-[10px] text-muted-foreground tabular-nums w-3">{e.rank}</span>
                          <span className="text-xs font-medium text-ink truncate">{e.name}</span>
                        </div>
                        <span className="text-xs font-semibold tabular-nums text-ink flex-shrink-0">{e.clicks}</span>
                      </div>
                      <div className="flex items-center gap-2 pl-4">
                        <div className="h-1.5 flex-1 rounded-full bg-surface-2 overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{ width: `${(e.clicks / 400) * 100}%`, background: TYPE_COLOR[e.type] }}
                          />
                        </div>
                        <span className="text-[9px] text-success tabular-nums w-10 text-right">{e.conversion}% conv</span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Flame className="h-4 w-4 text-friction" />
                  <div className="text-sm font-semibold text-ink">Rage-click hotspots</div>
                </div>
                <div className="space-y-2">
                  {RAGE_HOTSPOTS.map((r) => (
                    <div key={r.name} className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-ink truncate">{r.name}</div>
                        <div className="text-[10px] text-muted-foreground">{r.sessions} sessions</div>
                      </div>
                      <Badge variant="outline" className="text-[10px] border-friction/20 bg-friction/10 text-friction flex-shrink-0">
                        <Flame className="mr-1 h-2.5 w-2.5" /> {r.clicks}
                      </Badge>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <XCircle className="h-4 w-4 text-warning" />
                  <div className="text-sm font-semibold text-ink">Dead-click zones</div>
                </div>
                <div className="space-y-2">
                  {DEAD_ZONES.map((d) => (
                    <div key={d.name} className="flex items-center justify-between">
                      <span className="text-xs text-ink truncate">{d.name}</span>
                      <span className="text-[10px] text-warning tabular-nums">{d.clicks} clicks</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>

          {/* Bottom: click trend chart */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-sm font-semibold text-ink">Click trend (12 weeks)</div>
                <div className="text-[11px] text-muted-foreground">Total clicks vs rage clicks over time</div>
              </div>
              <div className="flex items-center gap-3 text-[10px]">
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--info)" }} />
                  <span className="text-muted-foreground">Total clicks</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--friction)" }} />
                  <span className="text-muted-foreground">Rage clicks</span>
                </div>
              </div>
            </div>
            <LineChart data={TREND} height={240} />
            <div className="mt-3 pt-3 border-t border-soft grid grid-cols-3 gap-2 text-[10px]">
              <div>
                <div className="text-muted-foreground">Peak week</div>
                <div className="font-semibold text-ink tabular-nums">W12 · 4,580 clicks</div>
              </div>
              <div>
                <div className="text-muted-foreground">Avg rage / week</div>
                <div className="font-semibold text-friction tabular-nums">
                  {Math.round(TREND.reduce((a, b) => a + b.values[1].value, 0) / TREND.length)}
                </div>
              </div>
              <div className="text-right">
                <div className="text-muted-foreground inline-flex items-center gap-1"><TrendingUp className="h-3 w-3" /> Rage trend</div>
                <div className="font-semibold text-friction tabular-nums">+18% WoW</div>
              </div>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
