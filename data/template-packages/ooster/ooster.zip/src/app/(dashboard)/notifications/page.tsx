"use client";

import * as React from "react";
import Link from "next/link";
import {
  Bell,
  CheckCheck,
  Lightbulb,
  FileText,
  AtSign,
  AlertTriangle,
  Users,
  CreditCard,
  Inbox,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { NOTIFICATIONS, type Notification } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type FilterTab =
  | "all"
  | "unread"
  | "mention"
  | "insight"
  | "report"
  | "alert";

const TABS: { label: string; value: FilterTab }[] = [
  { label: "All", value: "all" },
  { label: "Unread", value: "unread" },
  { label: "Mentions", value: "mention" },
  { label: "Insights", value: "insight" },
  { label: "Reports", value: "report" },
  { label: "Alerts", value: "alert" },
];

const NOTIF_META: Record<
  Notification["type"],
  { icon: React.ReactNode; cls: string; label: string }
> = {
  insight: {
    icon: <Lightbulb className="h-4 w-4" />,
    cls: "bg-warning/15 text-warning",
    label: "Insight",
  },
  report: {
    icon: <FileText className="h-4 w-4" />,
    cls: "bg-info/15 text-info",
    label: "Report",
  },
  mention: {
    icon: <AtSign className="h-4 w-4" />,
    cls: "bg-primary/10 text-primary",
    label: "Mention",
  },
  alert: {
    icon: <AlertTriangle className="h-4 w-4" />,
    cls: "bg-friction/15 text-friction",
    label: "Alert",
  },
  team: {
    icon: <Users className="h-4 w-4" />,
    cls: "bg-success/15 text-success",
    label: "Team",
  },
  billing: {
    icon: <CreditCard className="h-4 w-4" />,
    cls: "bg-muted text-muted-foreground",
    label: "Billing",
  },
};

const PREF_CATEGORIES: {
  key: string;
  label: string;
  desc: string;
  defaultOn: boolean;
}[] = [
  { key: "insights", label: "Insights", desc: "New findings, severity changes, resolved items", defaultOn: true },
  { key: "reports", label: "Reports", desc: "Report ready, scheduled, generation failed", defaultOn: true },
  { key: "mentions", label: "Mentions", desc: "When someone @-mentions you", defaultOn: true },
  { key: "alerts", label: "Alerts", desc: "A/B significance, threshold breaches, anomalies", defaultOn: true },
  { key: "team", label: "Team", desc: "Invitations accepted, role changes, joins", defaultOn: false },
  { key: "billing", label: "Billing", desc: "Invoice paid, failed, plan upgrades", defaultOn: true },
];

export default function NotificationsPage() {
  const [tab, setTab] = React.useState<FilterTab>("all");
  const [loading, setLoading] = React.useState(true);
  const [readSet, setReadSet] = React.useState<Set<string>>(new Set());

  const [prefs, setPrefs] = React.useState<Record<string, boolean>>(
    PREF_CATEGORIES.reduce((acc, c) => {
      acc[c.key] = c.defaultOn;
      return acc;
    }, {} as Record<string, boolean>)
  );

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return NOTIFICATIONS.filter((n) => {
      const isRead = readSet.has(n.id) || n.read;
      if (tab === "all") return true;
      if (tab === "unread") return !isRead;
      return n.type === tab;
    });
  }, [tab, readSet]);

  const unreadCount = NOTIFICATIONS.filter(
    (n) => !readSet.has(n.id) && !n.read
  ).length;

  const markAllRead = () => {
    setReadSet(new Set(NOTIFICATIONS.map((n) => n.id)));
    toast.success("All notifications marked as read", {
      description: `${unreadCount} notification${unreadCount === 1 ? "" : "s"} cleared`,
    });
  };

  const markRead = (id: string) => {
    setReadSet((s) => new Set(s).add(id));
  };

  const togglePref = (key: string) => (v: boolean) => {
    setPrefs((p) => ({ ...p, [key]: v }));
    toast.success(`Preference updated`, {
      description: `${key.charAt(0).toUpperCase() + key.slice(1)} notifications ${v ? "on" : "off"}`,
    });
  };

  return (
    <div>
      <PageHeader
        title="Notifications"
        description="Stay on top of insights, reports, mentions, and alerts"
        icon={<Bell className="h-5 w-5" />}
        badge={
          unreadCount > 0 ? (
            <Badge
              variant="outline"
              className="text-[10px] font-medium border-friction/30 bg-friction/10 text-friction"
            >
              {unreadCount} unread
            </Badge>
          ) : (
            <Badge variant="secondary" className="text-[10px]">
              All caught up
            </Badge>
          )
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={markAllRead}
            disabled={unreadCount === 0}
          >
            <CheckCheck className="mr-2 h-3.5 w-3.5" /> Mark all read
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main list */}
        <div className="lg:col-span-2 space-y-4">
          {/* Filter tabs */}
          <div className="flex flex-wrap items-center gap-1 rounded-full bg-surface-2 p-1 w-fit max-w-full overflow-x-auto">
            {TABS.map((t) => {
              const count =
                t.value === "all"
                  ? NOTIFICATIONS.length
                  : t.value === "unread"
                  ? unreadCount
                  : NOTIFICATIONS.filter((n) => n.type === t.value).length;
              return (
                <button
                  key={t.value}
                  onClick={() => setTab(t.value)}
                  className={cn(
                    "px-3 py-1.5 text-xs font-medium rounded-full transition-all whitespace-nowrap inline-flex items-center gap-1.5",
                    tab === t.value
                      ? "bg-card text-ink shadow-soft"
                      : "text-muted-foreground hover:text-ink"
                  )}
                >
                  {t.label}
                  <span
                    className={cn(
                      "text-[9px] rounded-full px-1.5 py-0.5",
                      tab === t.value
                        ? "bg-surface-2 text-muted-foreground"
                        : "bg-card text-muted-foreground"
                    )}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* List */}
          {loading ? (
            <LoadingSkeleton variant="preview" className="h-[420px]" />
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={Inbox}
              title="No notifications here"
              description={
                tab === "unread"
                  ? "You're all caught up — no unread notifications."
                  : "Notifications for this category will appear here."
              }
              compact
            />
          ) : (
            <Card className="rounded-2xl border-soft shadow-soft overflow-hidden">
              <div className="divide-y divide-[color:var(--border)]">
                {filtered.map((n) => {
                  const meta = NOTIF_META[n.type];
                  const isRead = readSet.has(n.id) || n.read;
                  return (
                    <div
                      key={n.id}
                      onClick={() => !isRead && markRead(n.id)}
                      className={cn(
                        "flex items-start gap-3 p-3.5 transition-colors cursor-pointer group",
                        isRead ? "bg-card" : "bg-primary/[0.025] hover:bg-primary/[0.05]"
                      )}
                    >
                      <div
                        className={cn(
                          "flex h-9 w-9 items-center justify-center rounded-xl flex-shrink-0",
                          meta.cls
                        )}
                      >
                        {meta.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className={cn(
                              "text-sm text-ink",
                              !isRead && "font-semibold"
                            )}
                          >
                            {n.title}
                          </span>
                          {!isRead && (
                            <span className="h-1.5 w-1.5 rounded-full bg-friction flex-shrink-0" />
                          )}
                          <Badge
                            variant="outline"
                            className={cn(
                              "text-[9px] font-medium border",
                              meta.cls
                            )}
                          >
                            {meta.label}
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                          {n.description}
                        </div>
                        <div className="flex items-center justify-between gap-2 mt-2">
                          <span className="text-[10px] text-muted-foreground">
                            {n.timestamp}
                          </span>
                          {n.action && (
                            <Button
                              asChild
                              variant="link"
                              size="sm"
                              className="h-auto p-0 text-[11px] text-primary"
                            >
                              <Link href={n.action.href}>
                                {n.action.label}
                                <ChevronRight className="h-3 w-3 ml-0.5" />
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}

          <Card className="rounded-2xl border-soft shadow-soft p-3 flex items-center justify-between">
            <div className="text-[10px] text-muted-foreground">
              Showing {filtered.length} of {NOTIFICATIONS.length} notifications
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-[11px] h-7"
              onClick={() => toast.message("Load more", { description: "Loaded 6 more notifications" })}
            >
              Load more
            </Button>
          </Card>
        </div>

        {/* Side: preferences */}
        <div className="space-y-4">
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Bell className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Preferences</h3>
            </div>
            <p className="text-[11px] text-muted-foreground mb-3">
              Choose which notifications you receive across email, in-app, and Slack.
            </p>
            <div className="space-y-3">
              {PREF_CATEGORIES.map((c) => (
                <div
                  key={c.key}
                  className="flex items-start justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink">{c.label}</div>
                    <div className="text-[10px] text-muted-foreground leading-snug">
                      {c.desc}
                    </div>
                  </div>
                  <Switch
                    checked={prefs[c.key]}
                    onCheckedChange={togglePref(c.key)}
                  />
                </div>
              ))}
            </div>
          </Card>

          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Inbox className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Delivery channels</h3>
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between rounded-lg border border-soft p-2.5">
                <span className="text-ink">In-app</span>
                <Badge
                  variant="outline"
                  className="text-[9px] border-success/30 bg-success/10 text-success"
                >
                  Always on
                </Badge>
              </div>
              <div className="flex items-center justify-between rounded-lg border border-soft p-2.5">
                <span className="text-ink">Email digest (daily)</span>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between rounded-lg border border-soft p-2.5">
                <span className="text-ink">Slack #ooster-alerts</span>
                <Switch />
              </div>
              <div className="flex items-center justify-between rounded-lg border border-soft p-2.5">
                <span className="text-ink">Mobile push</span>
                <Switch defaultChecked />
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Channel settings saved")}
            >
              Save delivery settings
            </Button>
          </Card>

          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-2">
              Daily summary
            </div>
            <div className="text-sm font-medium text-ink">
              {NOTIFICATIONS.length} notifications today
            </div>
            <div className="text-[11px] text-muted-foreground mt-1">
              {unreadCount} unread · {NOTIFICATIONS.length - unreadCount} read
            </div>
            <div className="mt-3 flex items-center gap-1.5">
              {NOTIFICATIONS.slice(0, 6).map((n) => (
                <div
                  key={n.id}
                  className={cn(
                    "h-1.5 flex-1 rounded-full",
                    readSet.has(n.id) || n.read
                      ? "bg-surface-2"
                      : "bg-friction/60"
                  )}
                />
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
