"use client";

import * as React from "react";
import {
  Download,
  FileText,
  FileArchive,
  FileJson,
  Database,
  Clock,
  HardDrive,
  Loader2,
  CheckCircle2,
  Eye,
  AlertTriangle,
  ShieldCheck,
  FileType,
  CalendarClock,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ExportOption {
  id: string;
  label: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  defaultChecked?: boolean;
}

const EXPORT_OPTIONS: ExportOption[] = [
  { id: "projects", label: "Projects", description: "All projects, metadata, scores", icon: Database, defaultChecked: true },
  { id: "insights", label: "Insights", description: "Insights, evidence, severity", icon: FileText, defaultChecked: true },
  { id: "reports", label: "Reports", description: "Saved reports & templates", icon: FileType, defaultChecked: true },
  { id: "heatmaps", label: "Heatmaps", description: "Click, scroll, attention maps", icon: HardDrive },
  { id: "replays", label: "Session replays", description: "Metadata + DOM snapshots", icon: Eye },
  { id: "surveys", label: "Surveys", description: "Questions & raw responses", icon: FileJson },
  { id: "members", label: "Team members", description: "Members, roles, audit trail", icon: ShieldCheck },
  { id: "audit", label: "Audit logs", description: "Full workspace activity log", icon: CalendarClock },
];

const FORMAT_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  CSV: FileText,
  JSON: FileJson,
  ZIP: FileArchive,
};

interface ExportRecord {
  id: string;
  filename: string;
  size: string;
  format: "CSV" | "JSON" | "ZIP";
  requestedBy: string;
  status: "ready" | "processing" | "expired" | "failed";
  createdAt: string;
  expiresAt: string;
  items: number;
}

const MOCK_EXPORTS: ExportRecord[] = [
  {
    id: "ex-001",
    filename: "ooster-projects-insights-2026-06-30.zip",
    size: "84.2 MB",
    format: "ZIP",
    requestedBy: "Mira Halberg",
    status: "ready",
    createdAt: "Jun 30, 2026 · 14:22",
    expiresAt: "Jul 30, 2026",
    items: 1248,
  },
  {
    id: "ex-002",
    filename: "ooster-heatmaps-q2-2026.csv",
    size: "12.7 MB",
    format: "CSV",
    requestedBy: "Idris Khoury",
    status: "ready",
    createdAt: "Jun 28, 2026 · 09:14",
    expiresAt: "Jul 28, 2026",
    items: 84,
  },
  {
    id: "ex-003",
    filename: "ooster-session-replays-jun.json",
    size: "312.4 MB",
    format: "JSON",
    requestedBy: "Aria Mendez",
    status: "processing",
    createdAt: "Jul 2, 2026 · 08:02",
    expiresAt: "Aug 1, 2026",
    items: 0,
  },
  {
    id: "ex-004",
    filename: "ooster-audit-logs-2026-h1.csv",
    size: "3.1 MB",
    format: "CSV",
    requestedBy: "Mira Halberg",
    status: "expired",
    createdAt: "Jan 15, 2026 · 11:48",
    expiresAt: "Apr 15, 2026",
    items: 4291,
  },
  {
    id: "ex-005",
    filename: "ooster-surveys-csatisfaction.zip",
    size: "—",
    format: "ZIP",
    requestedBy: "Sana Iqbal",
    status: "failed",
    createdAt: "Jun 12, 2026 · 16:30",
    expiresAt: "—",
    items: 0,
  },
];

const STATUS_LABEL_MAP: Record<ExportRecord["status"], string> = {
  ready: "Ready",
  processing: "Processing",
  expired: "Expired",
  failed: "Failed",
};

export default function DataExportPage() {
  const [loading, setLoading] = React.useState(true);
  const [selected, setSelected] = React.useState<Record<string, boolean>>(() =>
    Object.fromEntries(EXPORT_OPTIONS.map((o) => [o.id, !!o.defaultChecked]))
  );
  const [format, setFormat] = React.useState("ZIP");
  const [range, setRange] = React.useState("ytd");
  const [generating, setGenerating] = React.useState(false);
  const [progress, setProgress] = React.useState(0);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const selectedCount = Object.values(selected).filter(Boolean).length;

  const handleGenerate = () => {
    if (selectedCount === 0) {
      toast.error("Select at least one dataset", {
        description: "Choose what to include in your export.",
      });
      return;
    }
    setGenerating(true);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          setGenerating(false);
          toast.success("Export ready", {
            description: `Your ${format} export has been packaged. Download link is valid for 30 days.`,
          });
          return 100;
        }
        return p + 8;
      });
    }, 200);
  };

  const handleDownload = (rec: ExportRecord) => {
    if (rec.status !== "ready") {
      toast.error(`${rec.filename} is not ready`);
      return;
    }
    toast.success(`Downloading ${rec.filename}`, {
      description: `${rec.size} · link expires ${rec.expiresAt}`,
    });
  };

  const toggle = (id: string) => {
    setSelected((s) => ({ ...s, [id]: !s[id] }));
  };

  return (
    <div>
      <PageHeader
        title="Data Export"
        description="Export your projects, insights, sessions, and reports. GDPR-ready."
        icon={<Download className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px] gap-1">
            <ShieldCheck className="h-3 w-3" />
            GDPR compliant
          </Badge>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total exports"
          value={MOCK_EXPORTS.length}
          icon={<Database className="h-4 w-4" />}
          accent="info"
          sublabel="last 90 days"
        />
        <StatCard
          label="Last export"
          value="2 days ago"
          icon={<Clock className="h-4 w-4" />}
          accent="success"
          sublabel="projects + insights"
        />
        <StatCard
          label="Pending exports"
          value={MOCK_EXPORTS.filter((e) => e.status === "processing").length}
          icon={<Loader2 className="h-4 w-4" />}
          accent="warning"
          sublabel="currently processing"
        />
        <StatCard
          label="Avg file size"
          value="64"
          unit="MB"
          icon={<HardDrive className="h-4 w-4" />}
          sublabel="across all formats"
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left: Create export form */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-4">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <Download className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">Create new export</h3>
                <Badge variant="secondary" className="text-[10px] ml-auto">
                  {selectedCount} of {EXPORT_OPTIONS.length} selected
                </Badge>
              </div>

              {/* What to include */}
              <div className="mb-4">
                <Label className="text-xs mb-2 block">What to include</Label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {EXPORT_OPTIONS.map((opt) => {
                    const Icon = opt.icon;
                    const checked = selected[opt.id];
                    return (
                      <label
                        key={opt.id}
                        htmlFor={`exp-${opt.id}`}
                        className={cn(
                          "flex items-start gap-2.5 rounded-xl border p-2.5 cursor-pointer transition-all",
                          checked
                            ? "border-primary/30 bg-primary/5"
                            : "border-soft hover:bg-accent/30"
                        )}
                      >
                        <Checkbox
                          id={`exp-${opt.id}`}
                          checked={checked}
                          onCheckedChange={() => toggle(opt.id)}
                          className="mt-0.5"
                        />
                        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0">
                          <Icon className="h-3.5 w-3.5" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-medium text-ink">{opt.label}</div>
                          <div className="text-[10px] text-muted-foreground leading-relaxed">
                            {opt.description}
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Format + date range */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                <div className="space-y-1.5">
                  <Label className="text-xs">Format</Label>
                  <Select value={format} onValueChange={setFormat}>
                    <SelectTrigger className="h-9 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="CSV">CSV — spreadsheet-friendly</SelectItem>
                      <SelectItem value="JSON">JSON — API-friendly</SelectItem>
                      <SelectItem value="ZIP">ZIP — bundled (all formats)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-[10px] text-muted-foreground">
                    {format === "ZIP"
                      ? "Each dataset in its native format, bundled together."
                      : format === "JSON"
                      ? "Nested objects, ideal for re-import or programmatic use."
                      : "One file per dataset, RFC 4180 compliant."}
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Date range</Label>
                  <Select value={range} onValueChange={setRange}>
                    <SelectTrigger className="h-9 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7d">Last 7 days</SelectItem>
                      <SelectItem value="30d">Last 30 days</SelectItem>
                      <SelectItem value="90d">Last 90 days</SelectItem>
                      <SelectItem value="ytd">Year to date</SelectItem>
                      <SelectItem value="all">All time</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-[10px] text-muted-foreground">
                    Filters records by their created date.
                  </p>
                </div>
              </div>

              {/* Progress / generate */}
              {generating ? (
                <div className="rounded-xl border border-info/20 bg-info/5 p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin text-info" />
                      <span className="text-xs font-medium text-ink">
                        Generating export…
                      </span>
                    </div>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {Math.min(progress, 100)}%
                    </span>
                  </div>
                  <Progress value={progress} className="h-1.5" />
                  <div className="text-[10px] text-muted-foreground mt-1.5">
                    {progress < 30
                      ? "Collecting dataset metadata…"
                      : progress < 60
                      ? "Streaming records from primary store…"
                      : progress < 90
                      ? "Compressing and signing archive…"
                      : "Finalizing download URL…"}
                  </div>
                </div>
              ) : (
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <Button
                    size="sm"
                    className="rounded-full flex-1"
                    onClick={handleGenerate}
                    disabled={selectedCount === 0}
                  >
                    <Download className="mr-2 h-3.5 w-3.5" /> Generate export
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="rounded-full text-xs"
                    onClick={() => {
                      setSelected(Object.fromEntries(EXPORT_OPTIONS.map((o) => [o.id, false])));
                      toast.info("Selection cleared");
                    }}
                  >
                    Clear
                  </Button>
                </div>
              )}
            </Card>

            {/* Recent exports */}
            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                  <Clock className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">Recent exports</h3>
                <Badge variant="secondary" className="text-[10px] ml-auto">
                  {MOCK_EXPORTS.length} total
                </Badge>
              </div>

              {MOCK_EXPORTS.length === 0 ? (
                <EmptyState
                  icon={Download}
                  title="No exports yet"
                  description="Your generated exports will appear here, with download links valid for 30 days."
                  compact
                />
              ) : (
                <div className="space-y-2">
                  {MOCK_EXPORTS.map((rec) => {
                    const FormatIcon = FORMAT_ICONS[rec.format];
                    const isReady = rec.status === "ready";
                    const isProcessing = rec.status === "processing";
                    return (
                      <div
                        key={rec.id}
                        className={cn(
                          "rounded-xl border border-soft p-3 flex items-start gap-3 transition-all",
                          !isReady && !isProcessing && "opacity-70"
                        )}
                      >
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0">
                          <FormatIcon className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-0.5">
                            <code className="text-[11px] font-mono text-ink truncate max-w-full">
                              {rec.filename}
                            </code>
                          </div>
                          <div className="flex items-center gap-3 flex-wrap text-[10px] text-muted-foreground">
                            <span>{rec.size}</span>
                            <span>· {rec.format}</span>
                            <span>· by {rec.requestedBy}</span>
                            <span>· {rec.createdAt}</span>
                          </div>
                          <div className="flex items-center gap-2 mt-1.5">
                            <StatusBadge
                              status={
                                rec.status === "ready"
                                  ? "completed"
                                  : rec.status === "processing"
                                  ? "generating"
                                  : rec.status === "failed"
                                  ? "failed"
                                  : "archived"
                              }
                              label={STATUS_LABEL_MAP[rec.status]}
                            />
                            {isReady && (
                              <span className="text-[10px] text-muted-foreground">
                                Expires {rec.expiresAt}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex-shrink-0">
                          {isReady ? (
                            <Button
                              size="sm"
                              className="rounded-full text-xs h-8"
                              onClick={() => handleDownload(rec)}
                            >
                              <Download className="mr-1.5 h-3 w-3" /> Download
                            </Button>
                          ) : isProcessing ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="rounded-full text-xs h-8 text-muted-foreground"
                              disabled
                            >
                              <Loader2 className="mr-1.5 h-3 w-3 animate-spin" /> Packaging
                            </Button>
                          ) : (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="rounded-full text-xs h-8 text-muted-foreground"
                              disabled
                            >
                              —
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          </div>

          {/* Right: Compliance + tips */}
          <div className="space-y-4">
            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-success/15 text-success">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">GDPR & compliance</h3>
              </div>
              <div className="space-y-2.5 text-[11px] text-muted-foreground leading-relaxed">
                <p>
                  Exports include a manifest.json with checksums, source IDs, and generation
                  timestamp for audit trails.
                </p>
                <p>
                  All exports are signed with your workspace key. Anyone with the download URL can
                  fetch the file — share links carefully.
                </p>
                <p>
                  Download links expire after <span className="font-medium text-ink">30 days</span>.
                  Re-generate anytime; we don't keep expired files.
                </p>
              </div>
              <div className="mt-3 flex items-start gap-2 rounded-xl bg-friction/5 border border-friction/20 p-2.5">
                <AlertTriangle className="h-3.5 w-3.5 text-friction flex-shrink-0 mt-0.5" />
                <div className="text-[10px] text-ink leading-relaxed">
                  Session replays and heatmaps may contain end-user PII. Review the contents
                  before sharing externally.
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                  <FileJson className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">Format guide</h3>
              </div>
              <div className="space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <FileText className="h-3.5 w-3.5 text-info flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-[11px] font-medium text-ink">CSV</div>
                    <div className="text-[10px] text-muted-foreground leading-relaxed">
                      One file per dataset. RFC 4180 compliant. Opens in Excel, Sheets, Numbers.
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <FileJson className="h-3.5 w-3.5 text-info flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-[11px] font-medium text-ink">JSON</div>
                    <div className="text-[10px] text-muted-foreground leading-relaxed">
                      Nested objects, UTF-8. Best for re-importing into another Ooster workspace.
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <FileArchive className="h-3.5 w-3.5 text-info flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="text-[11px] font-medium text-ink">ZIP</div>
                    <div className="text-[10px] text-muted-foreground leading-relaxed">
                      All datasets bundled. Each dataset is in its native format (CSV for tabular,
                      JSON for nested).
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="rounded-2xl border-soft shadow-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle2 className="h-4 w-4 text-success" />
                <h3 className="text-sm font-semibold text-ink">Ready to schedule?</h3>
              </div>
              <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">
                Automate monthly exports delivered straight to your S3 bucket, Google Drive, or
                Dropbox. Enterprise plans include unlimited scheduled exports.
              </p>
              <Button
                variant="outline"
                size="sm"
                className="w-full rounded-full text-xs"
                onClick={() =>
                  toast.info("Scheduled exports", {
                    description: "Available on Enterprise — talk to your CSM to enable.",
                  })
                }
              >
                Set up scheduled export
              </Button>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
