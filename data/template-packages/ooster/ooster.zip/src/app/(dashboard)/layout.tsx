import { DashboardShell } from "@/components/layout/dashboard-shell";
import { ShareModal } from "@/components/modals/share-modal";
import { ConfirmModal } from "@/components/modals/confirm-modal";
import { CreateInsightModal } from "@/components/modals/create-insight-modal";
import { GenerateReportModal } from "@/components/modals/generate-report-modal";
import { PageTransition } from "@/components/common/motion";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <DashboardShell>
      <PageTransition>{children}</PageTransition>
      <ShareModal />
      <ConfirmModal />
      <CreateInsightModal />
      <GenerateReportModal />
    </DashboardShell>
  );
}
