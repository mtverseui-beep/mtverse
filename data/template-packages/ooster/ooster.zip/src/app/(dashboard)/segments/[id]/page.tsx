"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Layers,
  Users,
  Smartphone,
  Monitor,
  Tablet,
  Activity,
  Target,
  ChevronRight,
  TrendingUp,
  Clock,
  Sparkles,
  AlertTriangle,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DonutChart } from "@/components/charts";
import { SEGMENTS, type Segment } from "../page";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ----------------------------------------------------------------------------
// Mock detail enrichments — keyed by segment id, fall back to defaults
// ----------------------------------------------------------------------------

interface DeviceBreakdown {
  device: string;
  pct: number;
}

interface Journey {
  id: string;
  name: string;
  users: number;
  completion: number;
}

interface RecommendedAction {
  action: string;
  priority: "P0" | "P1" | "P2" | "P3";
  rationale: string;
}

const SEGMENT_ENRICHMENTS: Record<
  string,
  {
    devices: DeviceBreakdown[];
    journeys: Journey[];
    actions: RecommendedAction[];
  }
> = {
  "sg-001": {
    devices: [
      { device: "Desktop", pct: 64 },
      { device: "Mobile", pct: 28 },
      { device: "Tablet", pct: 8 },
    ],
    journeys: [
      { id: "j-1", name: "Dashboard → Insights → Report", users: 3120, completion: 78 },
      { id: "j-2", name: "Heatmap → Insight tag", users: 2240, completion: 64 },
      { id: "j-3", name: "Figma sync → Screen analysis", users: 1980, completion: 71 },
      { id: "j-4", name: "Replay → Insight create", users: 1420, completion: 58 },
    ],
    actions: [
      { action: "Surface 'power tips' in-product to drive cross-feature adoption", priority: "P1", rationale: "Power users adopt 3.4× more features when prompted" },
      { action: "Open API early access for verified power users", priority: "P2", rationale: "Top-requested feature in Q2 NPS feedback" },
      { action: "Launch an advocate program to convert power users into evangelists", priority: "P3", rationale: "Net retention impact estimated at +6pp" },
    ],
  },
  "sg-002": {
    devices: [
      { device: "Mobile", pct: 71 },
      { device: "Desktop", pct: 24 },
      { device: "Tablet", pct: 5 },
    ],
    journeys: [
      { id: "j-1", name: "Signup → First project → First screen", users: 1820, completion: 42 },
      { id: "j-2", name: "Onboarding → Heatmap tour", users: 1440, completion: 38 },
      { id: "j-3", name: "Onboarding → Insight example", users: 980, completion: 31 },
      { id: "j-4", name: "Invite teammate → Collaborate", users: 620, completion: 22 },
    ],
    actions: [
      { action: "Reduce onboarding from 5 steps to 3; defer optional setup", priority: "P0", rationale: "42% completion is below 60% target" },
      { action: "Add 'first insight in 90 seconds' guided tour", priority: "P1", rationale: "Time-to-value is the leading churn signal" },
      { action: "Send day-3 mobile push for users who stalled in onboarding", priority: "P2", rationale: "Re-engagement lifts activation by ~14%" },
    ],
  },
  "sg-003": {
    devices: [
      { device: "Mobile", pct: 92 },
      { device: "Tablet", pct: 6 },
      { device: "Desktop", pct: 2 },
    ],
    journeys: [
      { id: "j-1", name: "Push open → Dashboard → Insight", users: 4180, completion: 48 },
      { id: "j-2", name: "Replay open → Tag", users: 2960, completion: 39 },
      { id: "j-3", name: "Heatmap → Share to Slack", users: 1840, completion: 27 },
      { id: "j-4", name: "Onboarding → Push opt-in", users: 1520, completion: 34 },
    ],
    actions: [
      { action: "Improve push timing — surface post-first-action not at signup", priority: "P0", rationale: "A/B test ex-003 shows +19pp grant rate" },
      { action: "Add offline-friendly mobile dashboard with cached insights", priority: "P1", rationale: "32% of mobile sessions end on a blank state" },
      { action: "Redesign mobile insight cards for one-thumb scrolling", priority: "P2", rationale: "Heatmaps show cold zones on upper card areas" },
    ],
  },
  "sg-004": {
    devices: [
      { device: "Desktop", pct: 58 },
      { device: "Mobile", pct: 34 },
      { device: "Tablet", pct: 8 },
    ],
    journeys: [
      { id: "j-1", name: "Login → Weekly digest → Insight", users: 5640, completion: 82 },
      { id: "j-2", name: "Report open → Share with team", users: 4320, completion: 74 },
      { id: "j-3", name: "Dashboard → Renewal nudge", users: 3110, completion: 68 },
      { id: "j-4", name: "Settings → Add seat", users: 1980, completion: 41 },
    ],
    actions: [
      { action: "Launch seat-expansion in-app offer for teams at 90% seat capacity", priority: "P1", rationale: "Expansion motion: 12% accept rate estimated" },
      { action: "Schedule Q3 quarterly business review with top 50 accounts", priority: "P2", rationale: "QBRs cut churn by 18% in last cohort" },
      { action: "Surface usage analytics to admins monthly", priority: "P3", rationale: "Admin engagement correlates with renewal" },
    ],
  },
  "sg-005": {
    devices: [
      { device: "Mobile", pct: 52 },
      { device: "Desktop", pct: 41 },
      { device: "Tablet", pct: 7 },
    ],
    journeys: [
      { id: "j-1", name: "Login → Dashboard → Exit (rage)", users: 620, completion: 18 },
      { id: "j-2", name: "Replay → Try filter → Abandon", users: 480, completion: 22 },
      { id: "j-3", name: "Insight list → Search → No results", users: 340, completion: 12 },
      { id: "j-4", name: "Settings → Subscription → Cancel intent", users: 280, completion: 8 },
    ],
    actions: [
      { action: "Trigger in-app CSAT for at-risk users after session 3 of rage clicks", priority: "P0", rationale: "Early intervention cuts churn by 24%" },
      { action: "Auto-route at-risk users to CSM queue with context", priority: "P1", rationale: "Human outreach is the highest-leverage retention move" },
      { action: "Fix top 3 rage-click targets identified in heatmaps", priority: "P1", rationale: "Friction reduction is the second-highest retention driver" },
    ],
  },
  "sg-006": {
    devices: [
      { device: "Desktop", pct: 49 },
      { device: "Mobile", pct: 44 },
      { device: "Tablet", pct: 7 },
    ],
    journeys: [
      { id: "j-1", name: "Cancel → Exit survey → Submit", users: 540, completion: 88 },
      { id: "j-2", name: "Cancel → Win-back offer → Decline", users: 410, completion: 64 },
      { id: "j-3", name: "Subscription expiry → Re-login attempt", users: 220, completion: 32 },
      { id: "j-4", name: "Email re-engagement → Click", users: 180, completion: 14 },
    ],
    actions: [
      { action: "Personalize win-back email with last-used insight screenshots", priority: "P1", rationale: "Personalized win-backs convert 2.3× higher than generic" },
      { action: "Run 5 exit interviews per month with recently churned users", priority: "P2", rationale: "Qualitative signal feeds product strategy" },
      { action: "Time-box 60-day reactivation discount for high-LTV cohorts", priority: "P3", rationale: "Margin-positive win-back for top quartile" },
    ],
  },
};

// ----------------------------------------------------------------------------
// Helpers
// ----------------------------------------------------------------------------

function DeviceIcon({ device }: { device: string }) {
  if (device.toLowerCase().includes("mobile")) return <Smartphone className="h-3.5 w-3.5" />;
  if (device.toLowerCase().includes("tablet")) return <Tablet className="h-3.5 w-3.5" />;
  return <Monitor className="h-3.5 w-3.5" />;
}

const PRIORITY_COLORS: Record<RecommendedAction["priority"], string> = {
  P0: "bg-friction/15 text-friction border-friction/20",
  P1: "bg-warning/15 text-warning border-warning/20",
  P2: "bg-info/15 text-info border-info/20",
  P3: "bg-muted text-muted-foreground border-border",
};

const DEVICE_COLORS = ["var(--info)", "var(--success)", "var(--warning)"];

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function SegmentDetailPage() {
  const params = useParams<{ id: string }>();
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  const segment: Segment | undefined = SEGMENTS.find((s) => s.id === params.id);

  if (!segment) {
    return (
      <EmptyState
        icon={Layers}
        title="Segment not found"
        description="This segment may have been archived or the link is incorrect."
        action={{ label: "Back to segments", href: "/segments" }}
      />
    );
  }

  const enrich = SEGMENT_ENRICHMENTS[segment.id] ?? SEGMENT_ENRICHMENTS["sg-001"];
  const donutData = enrich.devices.map((d, i) => ({
    label: d.device,
    value: d.pct,
    color: DEVICE_COLORS[i % DEVICE_COLORS.length],
  }));

  return (
    <div>
      <PageHeader
        title={segment.name}
        description={segment.description}
        breadcrumbs={[
          { label: "Segments", href: "/segments" },
          { label: segment.name },
        ]}
        icon={<Layers className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {segment.pctOfTotal}% of users
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Segment exported", { description: "CSV with all users in this segment is being prepared." })}
          >
            Export segment
          </Button>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total users"
          value={segment.users.toLocaleString()}
          icon={<Users className="h-4 w-4" />}
          accent="info"
          sublabel={`${segment.pctOfTotal}% of all users`}
        />
        <StatCard
          label="Trend"
          value={`${segment.trend === "up" ? "+" : segment.trend === "down" ? "−" : ""}${segment.trendValue}%`}
          icon={<TrendingUp className="h-4 w-4" />}
          accent={
            segment.trend === "up" ? "success" : segment.trend === "down" ? "friction" : "default"
          }
          sublabel="vs last 30 days"
        />
        <StatCard
          label="Avg sessions"
          value={segment.id === "sg-001" ? "42" : segment.id === "sg-002" ? "3" : segment.id === "sg-006" ? "—" : "14"}
          icon={<Activity className="h-4 w-4" />}
          sublabel="per user / month"
        />
        <StatCard
          label="Last updated"
          value={segment.lastUpdated.slice(5)}
          icon={<Clock className="h-4 w-4" />}
          sublabel={segment.lastUpdated.slice(0, 4)}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: traits + journeys */}
        <div className="lg:col-span-2 space-y-4">
          {/* Traits */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-info" />
                <span className="text-sm font-semibold text-ink">Key traits</span>
              </div>
              <Badge variant="secondary" className="text-[10px]">
                {segment.traits.length} traits
              </Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              {segment.traits.map((t) => (
                <Badge
                  key={t}
                  variant="outline"
                  className="text-[10px] border-info/20 bg-info/10 text-info"
                >
                  {t}
                </Badge>
              ))}
            </div>
          </Card>

          {/* Top journeys */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-info" />
                <span className="text-sm font-semibold text-ink">Top journeys</span>
              </div>
              <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
                <Link href="/journeys">View all <ChevronRight className="h-3 w-3" /></Link>
              </Button>
            </div>
            <div className="space-y-2">
              {enrich.journeys.map((j) => (
                <div
                  key={j.id}
                  className="flex items-center gap-3 p-2.5 rounded-xl bg-surface-2/30 hover:bg-surface-2/60 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink line-clamp-1">{j.name}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">
                      {j.users.toLocaleString()} users
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-xs font-semibold tabular-nums text-ink">{j.completion}%</div>
                    <div className="text-[10px] text-muted-foreground">completion</div>
                  </div>
                  <div className="w-16 h-1.5 rounded-full bg-surface-2 overflow-hidden flex-shrink-0">
                    <div
                      className={cn(
                        "h-full rounded-full",
                        j.completion >= 70 ? "bg-success" : j.completion >= 40 ? "bg-warning" : "bg-friction"
                      )}
                      style={{ width: `${j.completion}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right: device breakdown + actions */}
        <div className="space-y-4">
          {/* Device breakdown donut */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Smartphone className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-sm font-semibold text-ink">Device breakdown</span>
            </div>
            <div className="flex flex-col items-center">
              <DonutChart
                data={donutData}
                size={150}
                centerValue={`${enrich.devices[0].pct}%`}
                centerLabel={enrich.devices[0].device}
              />
              <div className="w-full mt-3 space-y-1.5">
                {enrich.devices.map((d, i) => (
                  <div key={d.device} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span
                        className="h-2.5 w-2.5 rounded-full"
                        style={{ background: DEVICE_COLORS[i % DEVICE_COLORS.length] }}
                      />
                      <DeviceIcon device={d.device} />
                      <span className="text-ink">{d.device}</span>
                    </div>
                    <span className="font-medium tabular-nums text-ink">{d.pct}%</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>

          {/* Recommended actions */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Target className="h-3.5 w-3.5 text-success" />
              <span className="text-sm font-semibold text-ink">Recommended actions</span>
            </div>
            <div className="space-y-2.5">
              {enrich.actions.map((a, i) => (
                <div key={i} className="rounded-xl border border-soft p-2.5">
                  <div className="flex items-center gap-2 mb-1.5">
                    <Badge variant="outline" className={cn("text-[10px] font-bold", PRIORITY_COLORS[a.priority])}>
                      {a.priority}
                    </Badge>
                    <span className="text-xs font-medium text-ink flex-1">{a.action}</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground leading-relaxed flex items-start gap-1">
                    <AlertTriangle className="h-3 w-3 mt-0.5 flex-shrink-0" />
                    <span>{a.rationale}</span>
                  </p>
                </div>
              ))}
            </div>
          </Card>

          {/* Helper */}
          <Card className="rounded-2xl border-soft shadow-soft p-3 flex items-start gap-2 bg-surface-2/40">
            <Layers className="h-3.5 w-3.5 text-muted-foreground mt-0.5 flex-shrink-0" />
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Segments update nightly from the events pipeline. Use these to target research studies, A/B tests, and lifecycle campaigns.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
