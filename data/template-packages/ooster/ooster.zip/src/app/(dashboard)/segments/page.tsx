"use client";

import * as React from "react";
import Link from "next/link";
import {
  Layers,
  Users,
  TrendingUp,
  Activity,
  Clock,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

// ----------------------------------------------------------------------------
// Mock segments
// ----------------------------------------------------------------------------

export interface Segment {
  id: string;
  name: string;
  description: string;
  users: number;
  pctOfTotal: number;
  traits: string[];
  lastUpdated: string;
  trend: "up" | "down" | "flat";
  trendValue: number;
}

export const SEGMENTS: Segment[] = [
  {
    id: "sg-001",
    name: "Power users",
    description:
      "Daily active users with 30+ sessions in the last month. Heavy feature adoption, low churn risk.",
    users: 4820,
    pctOfTotal: 18,
    traits: ["Daily active", "Multi-project", "API access", "Slack connected"],
    lastUpdated: "2026-07-01",
    trend: "up",
    trendValue: 8.4,
  },
  {
    id: "sg-002",
    name: "First-time users",
    description:
      "Signed up within the last 7 days. Onboarding completion and time-to-value are the leading signals.",
    users: 2140,
    pctOfTotal: 8,
    traits: ["Onboarding", "Trial", "Single project", "Mobile-first"],
    lastUpdated: "2026-07-01",
    trend: "up",
    trendValue: 22.1,
  },
  {
    id: "sg-003",
    name: "Mobile-only",
    description:
      "Have only ever interacted with the product via the mobile app. Notification opt-in rates are critical.",
    users: 6310,
    pctOfTotal: 24,
    traits: ["iOS", "Push opt-in", "Single session", "Low NPS"],
    lastUpdated: "2026-06-30",
    trend: "flat",
    trendValue: 1.2,
  },
  {
    id: "sg-004",
    name: "Returning customers",
    description:
      "Existing customers with active subscriptions of 90+ days. Renewal and expansion motions matter most.",
    users: 9150,
    pctOfTotal: 35,
    traits: ["Renewed", "Multi-seat", "Report usage", "Stable MRR"],
    lastUpdated: "2026-07-01",
    trend: "up",
    trendValue: 4.7,
  },
  {
    id: "sg-005",
    name: "At-risk users",
    description:
      "Active in the last 30 days but showing declining session count, rising rage clicks, and lower CSAT.",
    users: 1180,
    pctOfTotal: 4,
    traits: ["Declining sessions", "Rage clicks", "Support tickets", "Low CSAT"],
    lastUpdated: "2026-06-30",
    trend: "down",
    trendValue: 12.3,
  },
  {
    id: "sg-006",
    name: "Churned",
    description:
      "Cancelled subscription in the last 60 days. Win-back research and exit survey themes feed product strategy.",
    users: 740,
    pctOfTotal: 3,
    traits: ["Cancelled", "Exit survey", "Low NPS", "Win-back target"],
    lastUpdated: "2026-06-28",
    trend: "down",
    trendValue: 6.8,
  },
];

// ----------------------------------------------------------------------------
// Page
// ----------------------------------------------------------------------------

export default function SegmentsPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  // KPIs
  const totalUsers = SEGMENTS.reduce((s, x) => s + x.users, 0);
  const atRisk = SEGMENTS.find((s) => s.id === "sg-005")?.users ?? 0;
  const churned = SEGMENTS.find((s) => s.id === "sg-006")?.users ?? 0;
  const power = SEGMENTS.find((s) => s.id === "sg-001")?.users ?? 0;

  return (
    <div>
      <PageHeader
        title="Segments"
        description="Behavioral and demographic user segments for targeted analysis"
        breadcrumbs={[{ label: "Segments" }]}
        icon={<Layers className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {SEGMENTS.length} segments
          </Badge>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total segments"
          value={SEGMENTS.length}
          icon={<Layers className="h-4 w-4" />}
          accent="info"
          sublabel="active + churned"
        />
        <StatCard
          label="Tracked users"
          value={totalUsers.toLocaleString()}
          icon={<Users className="h-4 w-4" />}
          accent="info"
          sublabel="across all segments"
        />
        <StatCard
          label="At-risk users"
          value={atRisk.toLocaleString()}
          icon={<TrendingUp className="h-4 w-4" />}
          accent="warning"
          sublabel="need intervention"
        />
        <StatCard
          label="Power users"
          value={power.toLocaleString()}
          icon={<Activity className="h-4 w-4" />}
          accent="success"
          sublabel="expansion ready"
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : SEGMENTS.length === 0 ? (
        <EmptyState
          icon={Layers}
          title="No segments yet"
          description="Define behavioral or demographic segments to start targeted analysis."
          action={{ label: "Browse research", href: "/research" }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {SEGMENTS.map((s) => (
            <SegmentCard key={s.id} segment={s} total={totalUsers} />
          ))}
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------------
// Segment card
// ----------------------------------------------------------------------------

function SegmentCard({ segment, total }: { segment: Segment; total: number }) {
  const trendColor =
    segment.trend === "up"
      ? "text-success"
      : segment.trend === "down"
      ? "text-friction"
      : "text-muted-foreground";
  const trendArrow = segment.trend === "up" ? "↑" : segment.trend === "down" ? "↓" : "→";

  return (
    <Link href={`/segments/${segment.id}`} className="group">
      <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold text-ink group-hover:text-primary transition-colors">
              {segment.name}
            </div>
            <div className="text-[10px] text-muted-foreground mt-0.5">
              Updated {segment.lastUpdated}
            </div>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <span className={cn("text-xs font-semibold tabular-nums", trendColor)}>
              {trendArrow} {segment.trendValue}%
            </span>
          </div>
        </div>

        <p className="text-[11px] text-muted-foreground line-clamp-2 mb-3 leading-relaxed">
          {segment.description}
        </p>

        {/* User count + pct */}
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="rounded-xl bg-surface-2/50 p-2.5">
            <div className="text-[10px] text-muted-foreground">Users</div>
            <div className="text-base font-semibold tabular-nums text-ink">
              {segment.users.toLocaleString()}
            </div>
          </div>
          <div className="rounded-xl bg-surface-2/50 p-2.5">
            <div className="text-[10px] text-muted-foreground">% of total</div>
            <div className="text-base font-semibold tabular-nums text-ink">
              {segment.pctOfTotal}%
            </div>
          </div>
        </div>

        {/* Progress bar against total */}
        <div className="mb-3">
          <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
            <div
              className="h-full rounded-full bg-info"
              style={{ width: `${segment.pctOfTotal}%` }}
            />
          </div>
        </div>

        {/* Traits */}
        <div className="flex flex-wrap gap-1 mb-3">
          {segment.traits.slice(0, 3).map((t) => (
            <Badge key={t} variant="secondary" className="text-[10px]">
              {t}
            </Badge>
          ))}
          {segment.traits.length > 3 && (
            <Badge variant="secondary" className="text-[10px]">
              +{segment.traits.length - 3}
            </Badge>
          )}
        </div>

        {/* Footer */}
        <div className="mt-auto flex items-center justify-between pt-3 border-t border-soft">
          <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
            <Clock className="h-3 w-3" />
            {segment.lastUpdated}
          </span>
          <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink transition-colors flex-shrink-0" />
        </div>
      </Card>
    </Link>
  );
}
