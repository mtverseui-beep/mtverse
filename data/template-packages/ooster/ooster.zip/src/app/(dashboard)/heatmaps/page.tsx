"use client";

import * as React from "react";
import Link from "next/link";
import {
  Flame,
  Search,
  SlidersHorizontal,
  Smartphone,
  Monitor,
  Tablet,
  MousePointerClick,
  Scroll as ScrollIcon,
  Eye,
  Zap,
  Ban,
  ChevronRight,
  Layers,
  Users,
  Thermometer,
  Snowflake,
  Clock,
  Plus,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { HEATMAPS, PROJECTS } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const TYPES = [
  { value: "all", label: "All types" },
  { value: "click", label: "Click map" },
  { value: "scroll", label: "Scroll map" },
  { value: "attention", label: "Attention map" },
  { value: "rage", label: "Rage clicks" },
  { value: "dead", label: "Dead clicks" },
];

const DEVICES = [
  { value: "all", label: "All devices" },
  { value: "desktop", label: "Desktop" },
  { value: "mobile", label: "Mobile" },
  { value: "tablet", label: "Tablet" },
];

const PROJECT_FILTERS = [
  { value: "all", label: "All projects" },
  ...PROJECTS.map((p) => ({ value: p.id, label: p.name })),
];

const typeMeta: Record<
  string,
  { icon: React.ElementType; color: string; label: string }
> = {
  click: { icon: MousePointerClick, color: "var(--friction)", label: "Click" },
  scroll: { icon: ScrollIcon, color: "var(--info)", label: "Scroll" },
  attention: { icon: Eye, color: "var(--warning)", label: "Attention" },
  rage: { icon: Zap, color: "var(--destructive)", label: "Rage" },
  dead: { icon: Ban, color: "var(--muted-foreground)", label: "Dead" },
};

const deviceMeta: Record<
  string,
  { icon: React.ElementType; label: string }
> = {
  desktop: { icon: Monitor, label: "Desktop" },
  mobile: { icon: Smartphone, label: "Mobile" },
  tablet: { icon: Tablet, label: "Tablet" },
};

// Deterministic pseudo-random based on a string seed
function seededSpots(seed: string, count: number) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) % 9973;
  const out: { x: number; y: number; intensity: number }[] = [];
  for (let i = 0; i < count; i++) {
    h = (h * 1103515245 + 12345) % 2147483648;
    const x = 10 + (h % 80);
    h = (h * 1103515245 + 12345) % 2147483648;
    const y = 12 + (h % 76);
    h = (h * 1103515245 + 12345) % 2147483648;
    const intensity = 35 + (h % 55);
    out.push({ x, y, intensity });
  }
  return out;
}

interface Spot {
  x: number;
  y: number;
  intensity: number;
  w: number;
}

function HeatmapPreview({
  hotspots,
  coldZones,
  type,
}: {
  hotspots: { x: number; y: number; intensity: number; w?: number }[];
  coldZones: { x: number; y: number; w: number; h: number }[];
  type: string;
}) {
  return (
    <div className="relative h-32 overflow-hidden bg-surface-2">
      {/* Mock browser chrome strip */}
      <div className="absolute top-0 left-0 right-0 h-4 bg-card/60 border-b border-soft flex items-center px-2 gap-1 z-10">
        <span className="h-1.5 w-1.5 rounded-full bg-friction/60" />
        <span className="h-1.5 w-1.5 rounded-full bg-warning/60" />
        <span className="h-1.5 w-1.5 rounded-full bg-success/60" />
      </div>
      {/* Faux content skeleton lines */}
      <div className="absolute inset-0 pt-6 px-3">
        <div className="h-2 w-1/3 rounded-full bg-card/70 mb-1.5" />
        <div className="h-2 w-1/2 rounded-full bg-card/50 mb-3" />
        <div className="h-10 w-full rounded-md bg-card/40 mb-2" />
        <div className="h-2 w-2/3 rounded-full bg-card/40 mb-1" />
        <div className="h-2 w-1/2 rounded-full bg-card/30" />
      </div>
      {/* Cold zones (outlined boxes) */}
      {coldZones.map((c, i) => (
        <div
          key={`cold-${i}`}
          className="absolute border border-dashed border-info/40 rounded-md"
          style={{
            left: `${c.x}%`,
            top: `${c.y}%`,
            width: `${c.w}%`,
            height: `${c.h}%`,
            background:
              "color-mix(in oklch, var(--info) 6%, transparent)",
          }}
        />
      ))}
      {/* Hotspots as blurred radial gradients */}
      {hotspots.map((h, i) => (
        <div
          key={`hot-${i}`}
          className="absolute pointer-events-none"
          style={{
            left: `${h.x}%`,
            top: `${h.y}%`,
            width: `${h.w ?? 70}px`,
            height: `${h.w ?? 70}px`,
            transform: "translate(-50%, -50%)",
            borderRadius: "9999px",
            background:
              type === "rage"
                ? `radial-gradient(circle, color-mix(in oklch, var(--destructive) ${h.intensity}%, transparent), transparent)`
                : type === "dead"
                ? `radial-gradient(circle, color-mix(in oklch, var(--muted-foreground) ${h.intensity}%, transparent), transparent)`
                : type === "attention"
                ? `radial-gradient(circle, color-mix(in oklch, var(--warning) ${h.intensity}%, transparent), transparent)`
                : type === "scroll"
                ? `radial-gradient(circle, color-mix(in oklch, var(--info) ${h.intensity}%, transparent), transparent)`
                : `radial-gradient(circle, color-mix(in oklch, var(--friction) ${h.intensity}%, transparent), transparent)`,
            filter: "blur(8px)",
            mixBlendMode: "multiply",
          }}
        />
      ))}
      {/* Rage click markers as small X */}
      {type === "rage" &&
        hotspots.map((h, i) => (
          <div
            key={`x-${i}`}
            className="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 text-destructive"
            style={{ left: `${h.x}%`, top: `${h.y}%` }}
          >
            <Zap className="h-3 w-3" fill="currentColor" />
          </div>
        ))}
    </div>
  );
}

export default function HeatmapsPage() {
  const [search, setSearch] = React.useState("");
  const [type, setType] = React.useState("all");
  const [device, setDevice] = React.useState("all");
  const [project, setProject] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return HEATMAPS.filter((h) => {
      if (
        search &&
        !h.screen.toLowerCase().includes(search.toLowerCase())
      )
        return false;
      if (type !== "all" && h.type !== type) return false;
      if (device !== "all" && h.device !== device) return false;
      if (project !== "all" && h.projectId !== project) return false;
      return true;
    });
  }, [search, type, device, project]);

  const clearFilters = () => {
    setSearch("");
    setType("all");
    setDevice("all");
    setProject("all");
  };

  // Aggregate stats
  const totalScreens = HEATMAPS.length;
  const totalSessions = HEATMAPS.reduce((s, h) => s + h.sessions, 0);
  const avgSessions = Math.round(totalSessions / totalScreens);
  const topIntensity = Math.max(...HEATMAPS.map((h) => h.topHotspot.intensity));
  const coldZonesTotal = HEATMAPS.reduce((s, h) => s + h.coldZones, 0);

  return (
    <div>
      <PageHeader
        title="Heatmaps"
        description="Click, scroll, attention, rage, and dead-click maps across all screens"
        breadcrumbs={[{ label: "Heatmaps" }]}
        icon={<Flame className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {HEATMAPS.length} screens mapped
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Heatmaps exported to CSV")}
            >
              <Sparkles className="mr-2 h-3.5 w-3.5" /> Export report
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Connect a screen to start mapping")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> New heatmap
            </Button>
          </>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total screens mapped"
          value={totalScreens}
          icon={<Layers className="h-4 w-4" />}
          trend={{ value: 8.2, direction: "up", good: true }}
          sublabel="vs last week"
        />
        <StatCard
          label="Avg sessions/screen"
          value={avgSessions.toLocaleString()}
          unit="sessions"
          icon={<Users className="h-4 w-4" />}
          accent="info"
          trend={{ value: 3.4, direction: "up", good: true }}
          sublabel="vs last week"
        />
        <StatCard
          label="Top hotspot intensity"
          value={topIntensity}
          unit="/100"
          icon={<Thermometer className="h-4 w-4" />}
          accent="friction"
          sublabel="Onboarding step 3"
        />
        <StatCard
          label="Cold zones identified"
          value={coldZonesTotal}
          icon={<Snowflake className="h-4 w-4" />}
          accent="warning"
          trend={{ value: 1.8, direction: "down", good: true }}
          sublabel="vs last week"
        />
      </div>

      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search screen name…",
          }}
          selects={[
            {
              label: "Type",
              value: type,
              onChange: setType,
              options: TYPES,
            },
            {
              label: "Device",
              value: device,
              onChange: setDevice,
              options: DEVICES,
            },
            {
              label: "Project",
              value: project,
              onChange: setProject,
              options: PROJECT_FILTERS,
            },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Flame}
          title="No heatmaps match your filters"
          description="Try adjusting search or filters, or connect a new screen to start collecting heatmap data."
          action={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((h) => {
            const tm = typeMeta[h.type];
            const dm = deviceMeta[h.device];
            // Compose hotspots for preview — always include the top hotspot
            const extra = seededSpots(h.id, 3).map((s) => ({
              ...s,
              w: 60,
            }));
            const hotspots = [
              {
                x: h.topHotspot.x,
                y: h.topHotspot.y,
                intensity: h.topHotspot.intensity,
                w: 78,
              },
              ...extra,
            ];
            const coldZones = Array.from({ length: h.coldZones }).map((_, i) => {
              const s = seededSpots(h.id + "-cold" + i, 1)[0];
              return {
                x: s.x,
                y: s.y,
                w: 18 + (i * 6) % 24,
                h: 14 + (i * 4) % 18,
              };
            });
            return (
              <Link key={h.id} href={`/heatmaps/${h.id}`} className="group">
                <Card className="rounded-2xl border-soft shadow-soft overflow-hidden hover:shadow-card hover:border-primary/30 transition-all">
                  <HeatmapPreview
                    hotspots={hotspots}
                    coldZones={coldZones}
                    type={h.type}
                  />
                  <div className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-ink group-hover:text-primary transition-colors line-clamp-1">
                          {h.screen}
                        </div>
                        <div className="text-[11px] text-muted-foreground mt-0.5 line-clamp-1">
                          {h.projectName}
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink mt-0.5 flex-shrink-0" />
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge
                        variant="secondary"
                        className="text-[10px] gap-1 capitalize"
                      >
                        <tm.icon
                          className="h-3 w-3"
                          style={{ color: tm.color }}
                        />
                        {tm.label}
                      </Badge>
                      <Badge
                        variant="outline"
                        className="text-[10px] gap-1 capitalize"
                      >
                        <dm.icon className="h-3 w-3" />
                        {dm.label}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-soft">
                      <div>
                        <div className="text-[10px] text-muted-foreground">
                          Sessions
                        </div>
                        <div className="text-xs font-semibold text-ink">
                          {h.sessions.toLocaleString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground">
                          Avg time
                        </div>
                        <div className="text-xs font-semibold text-ink">
                          {h.avgTime}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground">
                          Cold zones
                        </div>
                        <div className="text-xs font-semibold text-friction">
                          {h.coldZones}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <Thermometer className="h-3 w-3" />
                      <span className="text-ink font-medium">
                        Top hotspot:
                      </span>
                      <span className="truncate">{h.topHotspot.label}</span>
                      <span className="ml-auto text-friction font-semibold">
                        {h.topHotspot.intensity}%
                      </span>
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
