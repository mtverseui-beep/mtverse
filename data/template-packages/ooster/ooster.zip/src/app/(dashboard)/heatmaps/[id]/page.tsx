"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Flame,
  Share2,
  Download,
  PlayCircle,
  MousePointerClick,
  Scroll as ScrollIcon,
  Eye,
  Zap,
  Ban,
  ChevronRight,
  Lightbulb,
  Snowflake,
  TrendingDown,
  Sparkles,
  Target,
  Hand,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from "@/components/ui/sheet";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { useModals } from "@/hooks/use-modals";
import { getHeatmap } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { ScreenMockup } from "@/components/common/screen-mockup";

type Spot = { x: number; y: number; intensity: number; size: number };
type ColdBox = { x: number; y: number; w: number; h: number };
type DropArrow = { x: number; y: number };
type HotspotMeta = { label: string; intensity: number; count: string };

// Tab-specific visualization data — same screen, different overlays
const TAB_VIS: Record<
  string,
  {
    spots: Spot[];
    cold: ColdBox[];
    arrows: DropArrow[];
    colorVar: string;
  }
> = {
  click: {
    spots: [
      { x: 62, y: 41, intensity: 92, size: 90 },
      { x: 38, y: 28, intensity: 68, size: 60 },
      { x: 22, y: 64, intensity: 54, size: 50 },
      { x: 74, y: 72, intensity: 41, size: 44 },
      { x: 50, y: 50, intensity: 76, size: 70 },
      { x: 14, y: 38, intensity: 33, size: 38 },
    ],
    cold: [
      { x: 8, y: 80, w: 22, h: 14 },
      { x: 70, y: 12, w: 22, h: 10 },
    ],
    arrows: [{ x: 50, y: 86 }],
    colorVar: "var(--friction)",
  },
  scroll: {
    spots: [
      { x: 50, y: 20, intensity: 88, size: 110 },
      { x: 50, y: 45, intensity: 64, size: 80 },
      { x: 50, y: 70, intensity: 38, size: 60 },
      { x: 50, y: 92, intensity: 14, size: 40 },
    ],
    cold: [{ x: 4, y: 76, w: 92, h: 18 }],
    arrows: [
      { x: 88, y: 60 },
      { x: 88, y: 82 },
    ],
    colorVar: "var(--info)",
  },
  attention: {
    spots: [
      { x: 22, y: 22, intensity: 94, size: 100 },
      { x: 32, y: 42, intensity: 72, size: 70 },
      { x: 18, y: 62, intensity: 48, size: 50 },
      { x: 58, y: 26, intensity: 60, size: 60 },
      { x: 70, y: 60, intensity: 22, size: 36 },
    ],
    cold: [
      { x: 70, y: 76, w: 26, h: 18 },
      { x: 48, y: 78, w: 20, h: 12 },
    ],
    arrows: [],
    colorVar: "var(--warning)",
  },
  rage: {
    spots: [
      { x: 78, y: 38, intensity: 96, size: 80 },
      { x: 78, y: 42, intensity: 88, size: 70 },
      { x: 80, y: 36, intensity: 74, size: 60 },
      { x: 30, y: 68, intensity: 62, size: 56 },
      { x: 32, y: 64, intensity: 54, size: 50 },
    ],
    cold: [],
    arrows: [{ x: 78, y: 38 }],
    colorVar: "var(--destructive)",
  },
  dead: {
    spots: [
      { x: 14, y: 52, intensity: 54, size: 56 },
      { x: 86, y: 30, intensity: 42, size: 50 },
      { x: 50, y: 80, intensity: 36, size: 44 },
    ],
    cold: [
      { x: 8, y: 46, w: 18, h: 14 },
      { x: 80, y: 24, w: 18, h: 14 },
      { x: 44, y: 74, w: 18, h: 14 },
      { x: 30, y: 14, w: 20, h: 10 },
      { x: 66, y: 56, w: 22, h: 14 },
    ],
    arrows: [],
    colorVar: "var(--muted-foreground)",
  },
};

const HOTSPOT_LIST: HotspotMeta[] = [
  { label: "Upload button", intensity: 92, count: "1,142 clicks" },
  { label: "Hero CTA", intensity: 84, count: "986 clicks" },
  { label: "Continue button", intensity: 76, count: "812 clicks" },
  { label: "Skip link", intensity: 58, count: "498 clicks" },
  { label: "Help icon", intensity: 41, count: "224 clicks" },
];

const TOP_INTERACTIONS = [
  { label: "Tap · Upload button", count: 1142, type: "click" as const },
  { label: "Tap · Continue", count: 868, type: "click" as const },
  { label: "Scroll past 70%", count: 540, type: "scroll" as const },
  { label: "Form field focus", count: 1280, type: "input" as const },
  { label: "Back navigation", count: 312, type: "nav" as const },
];

const RECOMMENDATIONS = [
  {
    title: "Move primary CTA above the fold",
    detail:
      "62% of mobile sessions never scroll past 70%. Lifting the Upload button into the first viewport could lift conversion by an estimated 12%.",
    impact: "high",
    effort: "low",
  },
  {
    title: "Reduce form from 7 to 4 fields",
    detail:
      "Rage clicks cluster on the address autocomplete field. Cutting optional fields and adding inline validation should remove the dominant friction source.",
    impact: "high",
    effort: "medium",
  },
  {
    title: "Remove dead 'Help' affordance",
    detail:
      "412 dead clicks recorded on the gray help icon — it isn't wired. Either wire it to a contextual tooltip or remove it from this screen.",
    impact: "medium",
    effort: "low",
  },
  {
    title: "Add scroll prompt on long content",
    detail:
      "Only 18% of users reach the bottom of the legal disclosures. A subtle scroll affordance or sticky CTA may recover engagement.",
    impact: "medium",
    effort: "low",
  },
  {
    title: "Re-evaluate hero copy",
    detail:
      "Attention map shows the F-pattern favours top-left. Move value proposition into the top-left block currently occupied by the logo lockup.",
    impact: "low",
    effort: "medium",
  },
];

const typeMeta: Record<
  string,
  { icon: React.ElementType; color: string; label: string }
> = {
  click: { icon: MousePointerClick, color: "var(--friction)", label: "Click map" },
  scroll: { icon: ScrollIcon, color: "var(--info)", label: "Scroll map" },
  attention: { icon: Eye, color: "var(--warning)", label: "Attention map" },
  rage: { icon: Zap, color: "var(--destructive)", label: "Rage clicks" },
  dead: { icon: Ban, color: "var(--muted-foreground)", label: "Dead clicks" },
};

export default function HeatmapDetailPage() {
  const params = useParams<{ id: string }>();
  const heatmap = getHeatmap(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [tab, setTab] = React.useState("click");
  const [intensity, setIntensity] = React.useState(70);
  const [recOpen, setRecOpen] = React.useState(false);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 250);
    return () => clearTimeout(t);
  }, []);

  // Initialise the active tab to the heatmap's own type
  React.useEffect(() => {
    if (heatmap) setTab(heatmap.type);
  }, [heatmap?.id]);

  if (!heatmap) {
    return (
      <EmptyState
        icon={Flame}
        title="Heatmap not found"
        description="This heatmap may have been archived or the session data expired."
        action={{ label: "Back to heatmaps", href: "/heatmaps" }}
      />
    );
  }

  const tm = typeMeta[heatmap.type] ?? typeMeta.click;
  const vis = TAB_VIS[tab] ?? TAB_VIS.click;
  const opacity = intensity / 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title={heatmap.screen}
        description={`${heatmap.projectName} · ${heatmap.device} · ${heatmap.sessions.toLocaleString()} sessions · updated ${heatmap.updatedAt}`}
        breadcrumbs={[
          { label: "Heatmaps", href: "/heatmaps" },
          { label: heatmap.screen },
        ]}
        icon={<Flame className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px] gap-1">
            <tm.icon className="h-3 w-3" style={{ color: tm.color }} />
            {tm.label}
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Heatmap image exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export image
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => openShare(`/heatmaps/${heatmap.id}`, heatmap.screen)}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              asChild
              size="sm"
              className="rounded-full"
            >
              <Link href="/session-replays" onClick={() => toast.message("Opening session replay…")}>
                <PlayCircle className="mr-2 h-3.5 w-3.5" /> Open replay
              </Link>
            </Button>
          </>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          <Tabs value={tab} onValueChange={setTab} className="mb-4">
            <TabsList className="bg-surface-2 rounded-full p-0.5 h-9 flex-wrap">
              {(
                [
                  ["click", "Click map", MousePointerClick],
                  ["scroll", "Scroll map", ScrollIcon],
                  ["attention", "Attention map", Eye],
                  ["rage", "Rage clicks", Zap],
                  ["dead", "Dead clicks", Ban],
                ] as const
              ).map(([value, label, Icon]) => (
                <TabsTrigger
                  key={value}
                  value={value}
                  className="rounded-full text-xs data-[state=active]:bg-card data-[state=active]:shadow-soft gap-1.5"
                >
                  <Icon className="h-3 w-3" />
                  {label}
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value={tab} className="mt-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4">
                {/* Main visualization */}
                <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2 card-hover">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <div>
                      <h3 className="text-sm font-semibold text-ink">
                        {typeMeta[tab]?.label} · {heatmap.screen}
                      </h3>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        {heatmap.sessions.toLocaleString()} sessions ·{" "}
                        {heatmap.avgTime} avg time
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {/* Legend */}
                      <div className="hidden sm:flex items-center gap-1.5">
                        <span className="text-[10px] text-muted-foreground">Cool</span>
                        <div
                          className="h-2 w-24 rounded-full"
                          style={{
                            background:
                              "linear-gradient(90deg, var(--info), var(--success), var(--warning), var(--friction), var(--destructive))",
                          }}
                        />
                        <span className="text-[10px] text-muted-foreground">Hot</span>
                      </div>
                    </div>
                  </div>

                  {/* Browser chrome + 16:9 visualization */}
                  <div className="rounded-xl overflow-hidden border border-soft bg-surface-2">
                    <div className="h-7 bg-card border-b border-soft flex items-center px-3 gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-friction/70" />
                      <span className="h-2 w-2 rounded-full bg-warning/70" />
                      <span className="h-2 w-2 rounded-full bg-success/70" />
                      <div className="ml-3 h-4 flex-1 max-w-xs rounded-full bg-surface-2" />
                      <div className="ml-auto text-[10px] text-muted-foreground font-mono">
                        ooster.app/{heatmap.id}
                      </div>
                    </div>
                    <div className="relative w-full" style={{ aspectRatio: "16 / 9" }}>
                      {/* Base layer: animated analytics UI mockup (no stock photos) */}
                      <ScreenMockup variant="analytics" />

                      {/* Scroll depth band (only for scroll tab) */}
                      {tab === "scroll" && (
                        <div
                          className="absolute inset-x-0 top-0 pointer-events-none"
                          style={{
                            height: "100%",
                            background:
                              "linear-gradient(180deg, color-mix(in oklch, var(--info) 18%, transparent) 0%, transparent 70%)",
                          }}
                        />
                      )}

                      {/* Hotspots — div radial gradients with blur (animated stagger in) */}
                      {vis.spots.map((s, i) => (
                        <motion.div
                          key={`spot-${i}`}
                          className="absolute pointer-events-none"
                          initial={{ scale: 0, opacity: 0 }}
                          animate={{ scale: 1, opacity: opacity }}
                          transition={{
                            duration: 0.5,
                            delay: 0.15 + i * 0.08,
                            ease: [0.22, 1, 0.36, 1],
                          }}
                          style={{
                            left: `${s.x}%`,
                            top: `${s.y}%`,
                            width: `${s.size}px`,
                            height: `${s.size}px`,
                            transform: "translate(-50%, -50%)",
                            borderRadius: "9999px",
                            background: `radial-gradient(circle, color-mix(in oklch, ${vis.colorVar} ${s.intensity}%, transparent), transparent)`,
                            filter: "blur(8px)",
                            mixBlendMode: "multiply",
                          }}
                        />
                      ))}

                      {/* SVG overlay — cold zone outlined boxes + drop-off arrows */}
                      <svg
                        className="absolute inset-0 w-full h-full pointer-events-none"
                        viewBox="0 0 100 56.25"
                        preserveAspectRatio="none"
                      >
                        {vis.cold.map((c, i) => (
                          <rect
                            key={`cold-${i}`}
                            x={c.x}
                            y={c.y * 0.5625}
                            width={c.w}
                            height={c.h * 0.5625}
                            fill="color-mix(in oklch, var(--info) 6%, transparent)"
                            stroke="var(--info)"
                            strokeOpacity="0.55"
                            strokeWidth="0.3"
                            strokeDasharray="1 0.6"
                            rx="0.6"
                          />
                        ))}
                        {/* Drop-off arrows */}
                        {vis.arrows.map((a, i) => (
                          <g key={`arrow-${i}`}>
                            <line
                              x1={a.x}
                              y1={a.y * 0.5625 - 3}
                              x2={a.x}
                              y2={a.y * 0.5625 + 3}
                              stroke="var(--friction)"
                              strokeWidth="0.5"
                              strokeLinecap="round"
                            />
                            <polygon
                              points={`${a.x - 1.2},${a.y * 0.5625 + 2} ${a.x + 1.2},${a.y * 0.5625 + 2} ${a.x},${a.y * 0.5625 + 4}`}
                              fill="var(--friction)"
                            />
                          </g>
                        ))}
                      </svg>

                      {/* Hotspot center dots (animated in, hoverable) */}
                      {vis.spots
                        .filter((s) => s.intensity >= 70)
                        .map((s, i) => (
                          <motion.div
                            key={`dot-${i}`}
                            className="absolute pointer-events-auto cursor-pointer"
                            style={{
                              left: `${s.x}%`,
                              top: `${s.y}%`,
                              transform: "translate(-50%, -50%)",
                            }}
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{
                              duration: 0.4,
                              delay: 0.35 + i * 0.08,
                              ease: [0.22, 1, 0.36, 1],
                            }}
                            whileHover={{ scale: 1.6 }}
                          >
                            <span
                              className="block rounded-full"
                              style={{
                                width: 10,
                                height: 10,
                                background: vis.colorVar,
                                opacity: opacity,
                                boxShadow: "0 0 0 2px var(--card)",
                              }}
                            />
                          </motion.div>
                        ))}

                      {/* Rage click X markers */}
                      {tab === "rage" &&
                        vis.spots.map((s, i) => (
                          <div
                            key={`x-${i}`}
                            className="absolute -translate-x-1/2 -translate-y-1/2 text-destructive"
                            style={{ left: `${s.x}%`, top: `${s.y}%`, opacity }}
                          >
                            <Zap className="h-4 w-4" fill="currentColor" />
                          </div>
                        ))}
                    </div>
                  </div>

                  {/* Intensity slider + legend */}
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-3 items-center">
                    <div className="flex items-center gap-3">
                      <Target className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[11px] text-muted-foreground">
                            Hotspot intensity
                          </span>
                          <span className="text-[11px] font-semibold text-ink">
                            {intensity}%
                          </span>
                        </div>
                        <Slider
                          value={[intensity]}
                          onValueChange={(v) => setIntensity(v[0])}
                          min={0}
                          max={100}
                          step={1}
                          className="w-full transition-opacity duration-300"
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-muted-foreground">Cool</span>
                      <div
                        className="h-2.5 w-28 rounded-full"
                        style={{
                          background:
                            "linear-gradient(90deg, var(--info), var(--success), var(--warning), var(--friction), var(--destructive))",
                        }}
                      />
                      <span className="text-[10px] text-muted-foreground">Hot</span>
                    </div>
                  </div>
                </Card>

                {/* Side panel */}
                <div className="space-y-3 sm:space-y-4">
                  {/* Hotspot list */}
                  <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-sm font-semibold text-ink">
                        Top hotspots
                      </h3>
                      <Badge variant="secondary" className="text-[10px]">
                        {HOTSPOT_LIST.length}
                      </Badge>
                    </div>
                    <div className="space-y-3">
                      {HOTSPOT_LIST.map((h, i) => (
                        <div key={i} className="space-y-1.5">
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="flex h-5 w-5 items-center justify-center rounded-md bg-surface-2 text-[10px] font-semibold text-muted-foreground">
                                {i + 1}
                              </span>
                              <span className="font-medium text-ink truncate">
                                {h.label}
                              </span>
                            </div>
                            <span className="text-friction font-semibold">
                              {h.intensity}%
                            </span>
                          </div>
                          <div className="h-1.5 w-full rounded-full bg-surface-2 overflow-hidden ml-7">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${h.intensity}%`,
                                background:
                                  h.intensity > 75
                                    ? "var(--destructive)"
                                    : h.intensity > 50
                                    ? "var(--friction)"
                                    : h.intensity > 30
                                    ? "var(--warning)"
                                    : "var(--info)",
                              }}
                            />
                          </div>
                          <div className="text-[10px] text-muted-foreground ml-7">
                            {h.count}
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>

                  {/* Summary cards */}
                  <div className="grid grid-cols-2 gap-3">
                    <Card className="rounded-2xl border-soft shadow-soft p-3 card-hover">
                      <div className="flex items-center gap-2 mb-1">
                        <Snowflake className="h-3.5 w-3.5 text-info" />
                        <span className="text-[10px] text-muted-foreground font-medium">
                          Cold zones
                        </span>
                      </div>
                      <div className="text-xl font-semibold text-ink">
                        {heatmap.coldZones}
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        Low-interaction areas
                      </div>
                    </Card>
                    <Card className="rounded-2xl border-soft shadow-soft p-3 card-hover">
                      <div className="flex items-center gap-2 mb-1">
                        <TrendingDown className="h-3.5 w-3.5 text-friction" />
                        <span className="text-[10px] text-muted-foreground font-medium">
                          Drop-off areas
                        </span>
                      </div>
                      <div className="text-xl font-semibold text-ink">
                        {heatmap.dropOffAreas}
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        Where users leave
                      </div>
                    </Card>
                  </div>

                  {/* Top interactions */}
                  <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-sm font-semibold text-ink">
                        Top interactions
                      </h3>
                      <Hand className="h-3.5 w-3.5 text-muted-foreground" />
                    </div>
                    <div className="space-y-2">
                      {TOP_INTERACTIONS.map((it, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-2 rounded-lg border border-soft p-2"
                        >
                          <Badge
                            variant="outline"
                            className="text-[10px] capitalize flex-shrink-0"
                          >
                            {it.type}
                          </Badge>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-medium text-ink truncate">
                              {it.label}
                            </div>
                          </div>
                          <div className="text-xs font-semibold text-ink">
                            {it.count.toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                </div>
              </div>

              {/* Recommendations trigger */}
              <div className="mt-4">
                <Card className="rounded-2xl border-soft shadow-soft p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 card-hover">
                  <div className="flex items-start gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-surface-2 text-warning">
                      <Lightbulb className="h-4 w-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-ink">
                        {RECOMMENDATIONS.length} AI recommendations for this screen
                      </h3>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        Based on hotspot clustering, drop-off patterns, and rage
                        signals.
                      </p>
                    </div>
                  </div>
                  <Button
                    className="rounded-full"
                    onClick={() => setRecOpen(true)}
                  >
                    View recommendations
                    <ChevronRight className="ml-1 h-3.5 w-3.5" />
                  </Button>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </>
      )}

      {/* Recommendations sheet */}
      <Sheet open={recOpen} onOpenChange={setRecOpen}>
        <SheetContent
          side="right"
          className="w-full sm:max-w-md p-0 overflow-y-auto"
        >
          <SheetHeader className="p-4 border-b border-soft">
            <SheetTitle className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-warning" />
              Recommendations
            </SheetTitle>
            <SheetDescription>
              AI-generated actions for {heatmap.screen}
            </SheetDescription>
          </SheetHeader>
          <div className="p-4 space-y-3">
            {RECOMMENDATIONS.map((r, i) => (
              <div
                key={i}
                className="rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors"
              >
                <div className="flex items-start justify-between gap-2 mb-1">
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-md bg-surface-2 text-[10px] font-semibold text-muted-foreground">
                      {i + 1}
                    </span>
                    <h4 className="text-sm font-semibold text-ink">{r.title}</h4>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mb-2 ml-8">{r.detail}</p>
                <div className="flex items-center gap-1.5 ml-8">
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-[10px] capitalize",
                      r.impact === "high"
                        ? "text-friction border-friction/30"
                        : r.impact === "medium"
                        ? "text-warning border-warning/30"
                        : "text-info border-info/30"
                    )}
                  >
                    {r.impact} impact
                  </Badge>
                  <Badge variant="outline" className="text-[10px] capitalize">
                    {r.effort} effort
                  </Badge>
                </div>
              </div>
            ))}
          </div>
          <SheetFooter className="p-4 border-t border-soft flex-row gap-2">
            <Button
              variant="ghost"
              className="flex-1"
              onClick={() => setRecOpen(false)}
            >
              Close
            </Button>
            <Button
              className="flex-1"
              onClick={() => {
                setRecOpen(false);
                toast.success("Recommendations exported to PDF");
              }}
            >
              <Download className="mr-1 h-3.5 w-3.5" /> Export
            </Button>
          </SheetFooter>
        </SheetContent>
      </Sheet>
    </motion.div>
  );
}
