"use client";

import * as React from "react";
import {
  Route,
  Users,
  TrendingDown,
  GitBranch,
  Zap,
  AlertTriangle,
  Download,
  ArrowRight,
  Search,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface PathStep {
  id: string;
  label: string;
  users: number;
  pct: number;
  conversion: number;
  type: "start" | "middle" | "end-good" | "end-bad";
}

// 7 nodes total: 1 start -> 3 middle -> 2 end + 1 drop
const FLOW_NODES: PathStep[] = [
  { id: "n1", label: "Landing / Home", users: 12480, pct: 100, conversion: 100, type: "start" },
  { id: "n2", label: "Product browse", users: 8920, pct: 71, conversion: 71, type: "middle" },
  { id: "n3", label: "Search results", users: 2140, pct: 17, conversion: 17, type: "middle" },
  { id: "n4", label: "Featured promo", users: 1420, pct: 11, conversion: 11, type: "middle" },
  { id: "n5", label: "Checkout complete", users: 4180, pct: 33, conversion: 33, type: "end-good" },
  { id: "n6", label: "Cart abandon", users: 2940, pct: 24, conversion: 0, type: "end-bad" },
  { id: "n7", label: "Bounce / drop-off", users: 3760, pct: 30, conversion: 0, type: "end-bad" },
];

const TOP_PATHS = [
  { rank: 1, path: "Home → Browse → Checkout", users: 3840, conversion: 42, color: "var(--success)" },
  { rank: 2, path: "Home → Browse → Cart abandon", users: 2120, conversion: 0, color: "var(--friction)" },
  { rank: 3, path: "Home → Search → Checkout", users: 980, conversion: 38, color: "var(--success)" },
  { rank: 4, path: "Home → Promo → Browse → Checkout", users: 760, conversion: 29, color: "var(--info)" },
  { rank: 5, path: "Home → Bounce", users: 2480, conversion: 0, color: "var(--friction)" },
];

const UNEXPECTED = [
  { path: "Home → Search → Search → Search", users: 540, anomaly: "Loop", severity: "high" as const },
  { path: "Home → Browse → Cart → Browse → Cart", users: 320, anomaly: "Backtrack", severity: "medium" as const },
  { path: "Home → Promo → Checkout → Promo", users: 180, anomaly: "Cross-loop", severity: "low" as const },
];

const SEGMENT_COMPARISON = [
  { segment: "New visitors", paths: 8420, avgLength: 3.4, dropOff: 38, conversion: 22 },
  { segment: "Returning users", paths: 6210, avgLength: 2.8, dropOff: 21, conversion: 41 },
  { segment: "Mobile (iOS/Android)", paths: 7180, avgLength: 3.9, dropOff: 44, conversion: 19 },
];

const SEVERITY_COLOR = {
  high: "border-friction/20 bg-friction/10 text-friction",
  medium: "border-warning/20 bg-warning/10 text-warning",
  low: "border-info/20 bg-info/10 text-info",
};

export default function PathAnalysisPage() {
  const [loading, setLoading] = React.useState(true);
  const [startPage, setStartPage] = React.useState("all");
  const [endPage, setEndPage] = React.useState("all");
  const [segment, setSegment] = React.useState("all");
  const [dateRange, setDateRange] = React.useState("30d");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const totalPaths = 12480;
  const mostCommon = TOP_PATHS[0];
  const avgLength = 3.2;
  const dropOffRate = 32;

  // Find min/max for scaling widths
  const maxUsers = Math.max(...FLOW_NODES.map((n) => n.users));

  return (
    <div>
      <PageHeader
        title="Path Analysis"
        description="User flow paths through your product with friction and drop-off overlay"
        breadcrumbs={[{ label: "Analytics" }, { label: "Path Analysis" }]}
        icon={<Route className="h-5 w-5" />}
        actions={
          <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.success("Path data exported as CSV")}>
            <Download className="mr-2 h-3.5 w-3.5" /> Export
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Filter bar */}
          <Card className="rounded-2xl border-soft shadow-soft p-3 mb-4">
            <FilterBar
              selects={[
                {
                  label: "Start page",
                  value: startPage,
                  onChange: setStartPage,
                  options: [
                    { label: "Any start page", value: "all" },
                    { label: "Landing / Home", value: "home" },
                    { label: "Search", value: "search" },
                    { label: "Direct / Email", value: "direct" },
                  ],
                },
                {
                  label: "End page",
                  value: endPage,
                  onChange: setEndPage,
                  options: [
                    { label: "Any end page", value: "all" },
                    { label: "Checkout complete", value: "checkout" },
                    { label: "Cart abandon", value: "abandon" },
                    { label: "Bounce", value: "bounce" },
                  ],
                },
                {
                  label: "Segment",
                  value: segment,
                  onChange: setSegment,
                  options: [
                    { label: "All segments", value: "all" },
                    { label: "New visitors", value: "new" },
                    { label: "Returning users", value: "returning" },
                    { label: "Mobile", value: "mobile" },
                  ],
                },
                {
                  label: "Date range",
                  value: dateRange,
                  onChange: setDateRange,
                  options: [
                    { label: "Last 7 days", value: "7d" },
                    { label: "Last 30 days", value: "30d" },
                    { label: "Last quarter", value: "90d" },
                  ],
                },
              ]}
              onClear={() => { setStartPage("all"); setEndPage("all"); setSegment("all"); setDateRange("30d"); }}
            />
          </Card>

          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Total paths analyzed"
              value={totalPaths.toLocaleString()}
              icon={<GitBranch className="h-4 w-4" />}
              accent="info"
              trend={{ value: 8.4, direction: "up", good: true }}
              sublabel="last 30 days"
            />
            <StatCard
              label="Most common path"
              value="Browse → Buy"
              icon={<Users className="h-4 w-4" />}
              accent="success"
              sublabel={`${mostCommon.users.toLocaleString()} users`}
            />
            <StatCard
              label="Avg path length"
              value={avgLength}
              unit="steps"
              icon={<Route className="h-4 w-4" />}
              accent="default"
              trend={{ value: 0.3, direction: "down", good: true }}
              sublabel="vs last month"
            />
            <StatCard
              label="Drop-off rate"
              value={`${dropOffRate}%`}
              icon={<TrendingDown className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 2.1, direction: "up", good: false }}
              sublabel="vs last month"
            />
          </div>

          {/* Main grid: Sankey + side */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            {/* Sankey-style flow */}
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-sm font-semibold text-ink">User flow visualization</div>
                  <div className="text-[11px] text-muted-foreground">Bar width = user volume · color = conversion outcome</div>
                </div>
                <div className="flex items-center gap-2 text-[10px]">
                  <div className="flex items-center gap-1"><span className="h-2 w-3 rounded-sm" style={{ background: "var(--success)" }} /><span className="text-muted-foreground">Converted</span></div>
                  <div className="flex items-center gap-1"><span className="h-2 w-3 rounded-sm" style={{ background: "var(--friction)" }} /><span className="text-muted-foreground">Dropped</span></div>
                  <div className="flex items-center gap-1"><span className="h-2 w-3 rounded-sm" style={{ background: "var(--info)" }} /><span className="text-muted-foreground">In flow</span></div>
                </div>
              </div>

              {/* Sankey mock with 4 columns */}
              <div className="grid grid-cols-4 gap-2 sm:gap-4 items-start">
                {/* Column 1: Start */}
                <div className="flex flex-col gap-2">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1 text-center">Start</div>
                  {FLOW_NODES.filter((n) => n.type === "start").map((n) => (
                    <FlowNode key={n.id} node={n} maxUsers={maxUsers} />
                  ))}
                </div>

                {/* Column 2: Middle */}
                <div className="flex flex-col gap-2">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1 text-center">Mid-step</div>
                  {FLOW_NODES.filter((n) => n.type === "middle").map((n) => (
                    <FlowNode key={n.id} node={n} maxUsers={maxUsers} />
                  ))}
                </div>

                {/* Column 3: arrow / transition */}
                <div className="flex flex-col items-center justify-center pt-8">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-2">Flow</div>
                  <svg viewBox="0 0 60 200" className="w-full h-32 sm:h-40" preserveAspectRatio="none">
                    <path d="M 0 30 Q 30 30 60 60" fill="none" stroke="var(--success)" strokeWidth="6" opacity="0.6" />
                    <path d="M 0 30 Q 30 80 60 100" fill="none" stroke="var(--info)" strokeWidth="4" opacity="0.5" />
                    <path d="M 0 30 Q 30 130 60 140" fill="none" stroke="var(--warning)" strokeWidth="3" opacity="0.4" />
                    <path d="M 0 30 Q 30 170 60 180" fill="none" stroke="var(--friction)" strokeWidth="5" opacity="0.5" />
                  </svg>
                </div>

                {/* Column 4: End states */}
                <div className="flex flex-col gap-2">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1 text-center">End state</div>
                  {FLOW_NODES.filter((n) => n.type === "end-good" || n.type === "end-bad").map((n) => (
                    <FlowNode key={n.id} node={n} maxUsers={maxUsers} />
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-soft grid grid-cols-3 gap-3 text-[10px]">
                <div className="text-center">
                  <div className="text-muted-foreground">Start volume</div>
                  <div className="font-semibold text-ink tabular-nums">12,480</div>
                </div>
                <div className="text-center">
                  <div className="text-muted-foreground">Reached end state</div>
                  <div className="font-semibold text-success tabular-nums">10,880</div>
                </div>
                <div className="text-center">
                  <div className="text-muted-foreground">Net conversion</div>
                  <div className="font-semibold text-success tabular-nums">33.5%</div>
                </div>
              </div>
            </Card>

            {/* Top paths + unexpected */}
            <div className="flex flex-col gap-4">
              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <GitBranch className="h-4 w-4 text-info" />
                  <div className="text-sm font-semibold text-ink">Top 5 paths</div>
                </div>
                <div className="space-y-2.5">
                  {TOP_PATHS.map((p) => (
                    <div key={p.rank} className="space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="text-[10px] text-muted-foreground tabular-nums w-4">{p.rank}</span>
                          <span className="text-xs font-medium text-ink truncate">{p.path}</span>
                        </div>
                        <span className="text-[10px] font-semibold tabular-nums flex-shrink-0" style={{ color: p.color }}>
                          {p.conversion > 0 ? `${p.conversion}%` : "drop"}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 pl-5">
                        <div className="h-1.5 flex-1 rounded-full bg-surface-2 overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{ width: `${Math.min(100, (p.users / 4000) * 100)}%`, background: p.color }}
                          />
                        </div>
                        <span className="text-[10px] text-muted-foreground tabular-nums flex-shrink-0 w-12 text-right">
                          {p.users.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="h-4 w-4 text-warning" />
                  <div className="text-sm font-semibold text-ink">Unexpected paths</div>
                </div>
                <div className="space-y-2">
                  {UNEXPECTED.map((u, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-surface-2/50">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="text-xs font-medium text-ink leading-tight">{u.path}</div>
                        <Badge variant="outline" className={cn("text-[9px] capitalize flex-shrink-0", SEVERITY_COLOR[u.severity])}>
                          <AlertTriangle className="mr-1 h-2.5 w-2.5" /> {u.anomaly}
                        </Badge>
                      </div>
                      <div className="text-[10px] text-muted-foreground">{u.users} users · anomaly detected</div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>

          {/* Bottom: segment comparison table */}
          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden">
            <div className="p-4 border-b border-soft">
              <div className="text-sm font-semibold text-ink">Path comparison by segment</div>
              <div className="text-[11px] text-muted-foreground">3 segments × 4 key metrics</div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-soft">
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Segment</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Paths analyzed</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Avg length</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Drop-off rate</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Conversion</th>
                  </tr>
                </thead>
                <tbody>
                  {SEGMENT_COMPARISON.map((s) => (
                    <tr key={s.segment} className="border-b border-soft last:border-0 hover:bg-accent/30 transition-colors">
                      <td className="px-4 py-3 font-medium text-ink">{s.segment}</td>
                      <td className="px-4 py-3 tabular-nums text-ink">{s.paths.toLocaleString()}</td>
                      <td className="px-4 py-3 tabular-nums text-ink">{s.avgLength}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-12 rounded-full bg-surface-2 overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${s.dropOff}%`, background: "var(--friction)" }} />
                          </div>
                          <span className="text-friction tabular-nums">{s.dropOff}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-12 rounded-full bg-surface-2 overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${s.conversion * 2}%`, background: "var(--success)" }} />
                          </div>
                          <span className="text-success tabular-nums">{s.conversion}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}

function FlowNode({ node, maxUsers }: { node: PathStep; maxUsers: number }) {
  const colorMap: Record<PathStep["type"], string> = {
    start: "var(--info)",
    middle: "var(--warning)",
    "end-good": "var(--success)",
    "end-bad": "var(--friction)",
  };
  const color = colorMap[node.type];
  const widthPct = Math.max(35, (node.users / maxUsers) * 100);
  return (
    <div className="flex flex-col items-center">
      <div
        className="w-full rounded-lg p-2 text-center text-white shadow-soft transition-all hover:scale-[1.02]"
        style={{ width: `${widthPct}%`, background: color, minWidth: 60 }}
      >
        <div className="text-[10px] font-semibold leading-tight truncate">{node.label}</div>
        <div className="text-[9px] opacity-90 tabular-nums mt-0.5">{node.users.toLocaleString()}</div>
      </div>
      {node.conversion > 0 && node.type !== "start" && (
        <div className="text-[9px] text-muted-foreground mt-1 tabular-nums">{node.pct}% of start</div>
      )}
    </div>
  );
}
