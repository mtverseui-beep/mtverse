"use client";

import * as React from "react";
import Link from "next/link";
import {
  Search,
  HelpCircle,
  Settings,
  List,
  Maximize2,
  AlertCircle,
  Copy,
  FileText,
  Plus,
  ChevronRight,
  Flame,
  TrendingUp,
  TrendingDown,
  Sparkles,
  ArrowUpRight,
  Eye,
  Filter,
} from "lucide-react";
import { motion } from "framer-motion";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { AnimatedNumber, ProgressBar, RoundedProgress, ActiveDot, StepDots, TrendArrow } from "@/components/common/animated-progress";
import { ScreenMockup } from "@/components/common/screen-mockup";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScoreRadar } from "@/components/charts/score-radar";
import { StatusBadge, SeverityBadge } from "@/components/common/badges";
import { useModals } from "@/hooks/use-modals";
import {
  PROJECTS,
  INSIGHTS,
  REPORTS,
  RESEARCH_STUDIES,
  RECENT_ACTIVITY,
  AGGREGATE_UX,
  TREND_SERIES,
  PASSING_RATE,
} from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const RADAR_DATA = [
  { label: "Usability", value: AGGREGATE_UX.usability, key: "usability" },
  { label: "Accessibility", value: AGGREGATE_UX.accessibility, key: "accessibility" },
  { label: "Conversion", value: AGGREGATE_UX.conversion, key: "conversion" },
  { label: "Engagement", value: AGGREGATE_UX.engagement, key: "engagement" },
  { label: "Cognitive", value: AGGREGATE_UX.cognitiveLoad, key: "cognitiveLoad" },
  { label: "Clarity", value: AGGREGATE_UX.clarity, key: "clarity" },
  { label: "Consistency", value: AGGREGATE_UX.consistency, key: "consistency" },
  { label: "Friction", value: AGGREGATE_UX.friction, key: "friction" },
];

const METRIC_LIST = [
  { label: "Usability", value: AGGREGATE_UX.usability, color: "bg-success" },
  { label: "Accessibility", value: AGGREGATE_UX.accessibility, color: "bg-success" },
  { label: "Conversion", value: AGGREGATE_UX.conversion, color: "bg-warning" },
  { label: "Engagement", value: AGGREGATE_UX.engagement, color: "bg-success" },
  { label: "Cognitive load", value: AGGREGATE_UX.cognitiveLoad, color: "bg-friction" },
  { label: "Clarity", value: AGGREGATE_UX.clarity, color: "bg-info" },
  { label: "Consistency", value: AGGREGATE_UX.consistency, color: "bg-success" },
  { label: "Friction", value: AGGREGATE_UX.friction, color: "bg-warning" },
];

export default function DashboardPage() {
  const setReportOpen = useModals((s) => s.setGenerateReportOpen);
  const setCreateOpen = useModals((s) => s.setCreateProjectOpen);
  const [activeProject, setActiveProject] = React.useState(PROJECTS[0]);
  const [view, setView] = React.useState<"standard" | "heatmap" | "insights" | "skeleton">("standard");
  const [activeMetric, setActiveMetric] = React.useState<number | null>(null);

  return (
    <StaggerGroup className="space-y-4">
      {/* Top context bar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Workspace</span>
          <Badge variant="outline" className="text-[10px]">Halberg Studios · Enterprise</Badge>
        </div>
        <div className="flex items-center gap-2">
          <ProjectSwitcher value={activeProject} onChange={setActiveProject} />
          <DateRangePicker />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4">
        {/* Left Column - Overview */}
        <div className="lg:col-span-4 space-y-3 sm:space-y-4">
          {/* Radar Chart Card */}
          <StaggerItem>
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-ink">UX health overview</h2>
                <p className="text-[11px] text-muted-foreground">8 dimensions · 12-week rolling</p>
              </div>
              <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" aria-label="Settings" onClick={() => toast.info("Adjusting radar dimensions")}>
                <Settings className="h-3.5 w-3.5" />
              </Button>
            </div>

            <div className="relative mb-3 flex h-52 items-center justify-center">
              <ScoreRadar data={RADAR_DATA} size={260} />
              {activeMetric !== null && (
                <svg className="absolute inset-0 h-full w-full pointer-events-none" viewBox="0 0 260 260">
                  {(() => {
                    const cx = 130, cy = 130, radius = 98, n = RADAR_DATA.length;
                    const angle = (Math.PI * 2 * activeMetric) / n - Math.PI / 2;
                    const vx = cx + radius * Math.cos(angle);
                    const vy = cy + radius * Math.sin(angle);
                    const px = cx + (RADAR_DATA[activeMetric].value / 100) * radius * Math.cos(angle);
                    const py = cy + (RADAR_DATA[activeMetric].value / 100) * radius * Math.sin(angle);
                    return (
                      <>
                        <line x1={cx} y1={cy} x2={vx} y2={vy} stroke="var(--primary)" strokeWidth="2" strokeDasharray="3 3" opacity="0.5" />
                        <circle cx={px} cy={py} r="7" fill="var(--primary)" stroke="var(--card)" strokeWidth="2.5" />
                        <circle cx={px} cy={py} r="12" fill="none" stroke="var(--primary)" strokeWidth="1.5" opacity="0.3">
                          <animate attributeName="r" from="7" to="14" dur="1.2s" repeatCount="indefinite" />
                          <animate attributeName="opacity" from="0.5" to="0" dur="1.2s" repeatCount="indefinite" />
                        </circle>
                      </>
                    );
                  })()}
                </svg>
              )}
            </div>

            <div className="space-y-1">
              {METRIC_LIST.map((m, i) => (
                <div
                  key={m.label}
                  onMouseEnter={() => setActiveMetric(i)}
                  onMouseLeave={() => setActiveMetric(null)}
                  className={cn(
                    "flex items-center gap-2 rounded-md px-1.5 py-1 transition-colors cursor-pointer",
                    activeMetric === i && "bg-accent/50"
                  )}
                >
                  <span className="w-4 text-[10px] font-mono text-muted-foreground">{i + 1}</span>
                  <span className={cn("flex-1 text-xs", activeMetric === i ? "font-semibold text-ink" : "text-ink")}>{m.label}</span>
                  <div className="flex items-center gap-1.5">
                    <ProgressBar
                      value={m.value}
                      color={m.color.replace("bg-", "var(--") + ")"}
                      height={6}
                      delay={i * 0.08}
                      className="w-12 sm:w-16"
                    />
                    <span className="w-9 text-right text-xs font-semibold text-ink tabular-nums">
                      <AnimatedNumber value={m.value} suffix="%" duration={1.2} />
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <Button asChild variant="ghost" size="sm" className="w-full mt-3 text-xs">
              <Link href="/ux-score">Full UX score breakdown <ChevronRight className="h-3 w-3" /></Link>
            </Button>
          </Card>
          </StaggerItem>

          {/* Upgrade Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          >
          <Card className="relative overflow-hidden rounded-2xl border-0 shadow-card p-5 text-primary-foreground card-hover" style={{ background: "linear-gradient(135deg, var(--primary), color-mix(in oklch, var(--primary) 70%, black))" }}>
            <div className="relative z-10">
              <Badge className="bg-white/15 text-white border-0 mb-2 text-[10px]">Enterprise</Badge>
              <h3 className="text-lg font-bold tracking-tight">Unlock Ooster AI Reports</h3>
              <p className="text-xs opacity-90 mt-1 max-w-[200px]">
                Unlimited AI-generated reports, advanced segments, and SSO. Cancel anytime.
              </p>
              <Button asChild size="sm" className="mt-3 bg-white text-primary hover:bg-white/90 rounded-full h-7 text-xs">
                <Link href="/pricing">Upgrade plan <ArrowUpRight className="ml-1 h-3 w-3" /></Link>
              </Button>
            </div>
            <div className="absolute -right-4 -bottom-4 opacity-20 pointer-events-none">
              <Sparkles className="h-28 w-28" />
            </div>
          </Card>
          </motion.div>
        </div>

        {/* Middle Column - Recent Project */}
        <div className="lg:col-span-5 space-y-3 sm:space-y-4">
          {/* Recent Project Card */}
          <StaggerItem>
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-ink">Recent project</h2>
                <p className="text-[11px] text-muted-foreground">{activeProject.name}</p>
              </div>
              <div className="flex items-center gap-1">
                <Button asChild variant="ghost" size="sm" className="h-7 text-xs" onClick={() => toast.info("Opening fullscreen preview")}>
                  <Link href={`/projects/${activeProject.slug}`}>
                    <Maximize2 className="mr-1 h-3 w-3" /> Fullscreen
                  </Link>
                </Button>
              </div>
            </div>

            <div className="mb-3 flex items-center gap-1 flex-wrap">
              {([
                ["standard", "Standard"],
                ["heatmap", "Heatmap"],
                ["insights", "Insights"],
                ["skeleton", "Skeleton"],
              ] as const).map(([key, label]) => (
                <motion.button
                  key={key}
                  onClick={() => setView(key)}
                  whileTap={{ scale: 0.97 }}
                  className={cn(
                    "cursor-pointer rounded-full px-3 py-1 text-[10px] font-medium transition-colors",
                    view === key
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-accent/60"
                  )}
                >
                  {label}
                </motion.button>
              ))}
              <div className="ml-auto">
                <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg bg-surface-2" aria-label="List view" onClick={() => toast.info("Switching to list view")}>
                  <List className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            {/* Project preview area */}
            <div className="relative flex h-[280px] sm:h-[340px] items-center justify-center rounded-xl overflow-hidden bg-surface-2">
              <motion.div
                key={view}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className="absolute inset-0"
              >
                <ProjectPreview project={activeProject} view={view} />
              </motion.div>

              {/* Floating controls */}
              <div className="absolute left-3 top-3 flex items-center gap-1.5 z-10">
                <div className="rounded-md border border-soft bg-card shadow-soft p-1.5">
                  <List className="h-3.5 w-3.5" />
                </div>
                <div className="rounded-md border border-soft bg-card shadow-soft p-1.5">
                  <Settings className="h-3.5 w-3.5" />
                </div>
              </div>

              <div className="absolute right-3 top-3 z-10">
                <div className="rounded-full border border-soft bg-card shadow-soft px-2 py-1 flex items-center gap-1.5">
                  <span className="text-[10px] font-medium text-muted-foreground">About</span>
                  <span className="text-[10px] font-medium text-muted-foreground">Blog</span>
                  <Link
                    href={`/projects/${activeProject.slug}`}
                    className="rounded-full bg-primary px-2 py-0.5 text-[10px] font-medium text-primary-foreground"
                  >
                    View more
                  </Link>
                </div>
              </div>

              <button
                className="absolute bottom-3 left-3 flex h-8 w-8 items-center justify-center rounded-lg border border-soft bg-card shadow-soft hover:bg-card z-10"
                aria-label="Maximize"
                onClick={() => toast.info("Opening project workspace")}
              >
                <Maximize2 className="h-3.5 w-3.5" />
              </button>

              <div className="absolute bottom-3 right-3 z-10 flex items-center gap-1.5">
                <Button variant="ghost" size="sm" className="h-7 text-[10px] bg-card shadow-soft" onClick={() => toast.success("Snapshot exported")}>
                  <Copy className="mr-1 h-3 w-3" /> Snapshot
                </Button>
              </div>
            </div>
          </Card>
          </StaggerItem>

          {/* AI Reports Card */}
          <StaggerItem>
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-ink">AI reports</h2>
                <p className="text-[11px] text-muted-foreground">Generated insights & summaries</p>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg" aria-label="Copy" onClick={() => toast.success("Report link copied")}>
                  <Copy className="h-3.5 w-3.5" />
                </Button>
                <Button size="sm" className="h-7 text-xs rounded-full" onClick={() => setReportOpen(true)}>
                  <Sparkles className="mr-1 h-3 w-3" /> Generate
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <ReportCircle iconType="chart" label="Competitors" value={87} delay={0} />
              <ReportCircle iconType="list" label="Task flow" value={72} delay={120} />
              <ReportCircle iconType="book" label="User journey" value={81} delay={240} />
            </div>

            <div className="mt-4 space-y-2">
              {REPORTS.slice(0, 2).map((r) => (
                <Link
                  key={r.id}
                  href={`/reports/${r.id}`}
                  className="flex items-center gap-3 rounded-xl border border-soft p-2.5 hover:bg-accent/40 transition-colors group"
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-2 text-primary">
                    <FileText className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">{r.title}</div>
                    <div className="text-[10px] text-muted-foreground">{r.pages}p · {r.duration} · {r.project}</div>
                  </div>
                  <StatusBadge status={r.status as any} />
                  <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-ink" />
                </Link>
              ))}
            </div>
          </Card>
          </StaggerItem>
        </div>

        {/* Right Column - Stats */}
        <div className="lg:col-span-3 space-y-3 sm:space-y-4">
          {/* Transfer Flow Card */}
          <StaggerItem>
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center justify-between mb-1">
              <div className="text-[11px] font-medium text-muted-foreground">Task success rate</div>
              <div className="flex items-center gap-1.5">
                <ActiveDot color="var(--success)" size={6} />
                <TrendingUp className="h-3 w-3 text-success" />
              </div>
            </div>
            <div className="mb-2 text-3xl font-bold tracking-tight text-ink">
              <AnimatedNumber value={87} suffix="%" duration={1.4} />
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-success/15 text-success border-0 text-[10px]">GOOD</Badge>
              <TrendArrow direction="up" good value="+4.2pp" />
            </div>
          </Card>
          </StaggerItem>

          {/* Request Flow Card */}
          <StaggerItem>
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center justify-between mb-1">
              <div className="text-[11px] font-medium text-muted-foreground">Drop-off risk</div>
              <div className="flex items-center gap-1.5">
                <ActiveDot color="var(--warning)" size={6} />
                <TrendingDown className="h-3 w-3 text-friction" />
              </div>
            </div>
            <div className="mb-2 text-3xl font-bold tracking-tight text-ink">
              <AnimatedNumber value={52} suffix="%" duration={1.4} />
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-warning/15 text-warning border-0 text-[10px]">ATTENTION</Badge>
            </div>
            <div className="mt-3 flex items-start gap-1.5 rounded-lg bg-warning/10 p-2">
              <AlertCircle className="mt-0.5 h-3 w-3 flex-shrink-0 text-warning" />
              <p className="text-[10px] leading-relaxed text-muted-foreground">
                KYC step 3 has 41% pause rate on mobile. See insight i-002.
              </p>
            </div>
          </Card>
          </StaggerItem>

          {/* Add new card */}
          <button
            onClick={() => setCreateOpen(true)}
            className="w-full rounded-2xl border-2 border-dashed border-soft bg-card/50 p-4 flex items-center justify-center hover:bg-accent/30 hover:border-primary/40 transition-colors group"
          >
            <div className="flex items-center gap-2 text-muted-foreground group-hover:text-ink">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-surface-2 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                <Plus className="h-4 w-4" />
              </div>
              <span className="text-xs font-medium">Add new project</span>
            </div>
          </button>

          {/* Cascade banking mini-card */}
          <StaggerItem>
          <Card className="rounded-2xl border-soft shadow-soft p-3 card-hover">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-ink">{activeProject.name}</span>
              <span className="text-muted-foreground">{activeProject.screenCount} screens</span>
            </div>
            <div className="mt-2 flex items-center gap-2">
              {activeProject.tags.slice(0, 2).map((t) => (
                <Badge key={t} variant="secondary" className="text-[9px]">{t}</Badge>
              ))}
            </div>
          </Card>
          </StaggerItem>

          {/* Passing Rate Card */}
          <StaggerItem>
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-ink">Passing rate</h2>
              <Button asChild variant="ghost" size="icon" className="h-6 w-6 rounded-lg" aria-label="Open report">
                <Link href="/reports"><FileText className="h-3.5 w-3.5" /></Link>
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <div className="mb-0.5 text-[10px] text-muted-foreground">Complete</div>
                <div className="text-xl font-bold text-success"><AnimatedNumber value={PASSING_RATE.complete} format={(v) => `${Math.round(v)}%`} /></div>
              </div>
              <div>
                <div className="mb-0.5 text-[10px] text-muted-foreground">Failed</div>
                <div className="text-xl font-bold text-friction"><AnimatedNumber value={PASSING_RATE.failed} format={(v) => `${Math.round(v)}%`} /></div>
              </div>
              <div>
                <div className="mb-0.5 text-[10px] text-muted-foreground">Partial</div>
                <div className="text-xl font-bold text-ink"><AnimatedNumber value={PASSING_RATE.partial} format={(v) => `${Math.round(v)}%`} /></div>
              </div>
            </div>

            <div className="mt-3 flex h-2.5 overflow-hidden rounded-full bg-muted">
              <motion.div
                className="h-full bg-success"
                initial={{ width: 0 }}
                animate={{ width: `${PASSING_RATE.complete}%` }}
                transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              />
              <motion.div
                className="h-full bg-friction"
                initial={{ width: 0 }}
                animate={{ width: `${PASSING_RATE.failed}%` }}
                transition={{ duration: 1, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
              />
              <motion.div
                className="h-full bg-muted-foreground/40"
                initial={{ width: 0 }}
                animate={{ width: `${PASSING_RATE.partial}%` }}
                transition={{ duration: 1, delay: 0.7, ease: [0.22, 1, 0.36, 1] }}
              />
            </div>

            <Button asChild variant="ghost" size="sm" className="w-full mt-3 text-xs">
              <Link href="/usability-tests">View usability tests <ChevronRight className="h-3 w-3" /></Link>
            </Button>
          </Card>
          </StaggerItem>
        </div>
      </div>

      {/* Bottom row — insights + activity + research */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4">
        {/* Top insights */}
        <StaggerItem className="lg:col-span-2">
        <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-semibold text-ink">Top insights</h2>
              <p className="text-[11px] text-muted-foreground">Prioritized by impact × confidence</p>
            </div>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/insights">View all <ChevronRight className="h-3 w-3" /></Link>
            </Button>
          </div>
          <div className="space-y-2">
            {INSIGHTS.slice(0, 4).map((insight) => (
              <Link
                key={insight.id}
                href={`/insights/${insight.id}`}
                className="flex items-start gap-3 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors group"
              >
                <SeverityBadge severity={insight.severity as any} />
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-ink line-clamp-1">{insight.title}</div>
                  <div className="text-[10px] text-muted-foreground mt-0.5 line-clamp-1">{insight.summary}</div>
                  <div className="flex items-center gap-2 mt-1.5 text-[10px] text-muted-foreground">
                    <span>{insight.projectName}</span>
                    <span>·</span>
                    <span>Impact {insight.impact}</span>
                    <span>·</span>
                    <span>Confidence {insight.confidence}%</span>
                  </div>
                </div>
                <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-ink mt-1" />
              </Link>
            ))}
          </div>
        </Card>
        </StaggerItem>

        {/* Recent activity */}
        <StaggerItem>
        <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-ink">Recent activity</h2>
            <Button asChild variant="ghost" size="sm" className="text-xs">
              <Link href="/history">All</Link>
            </Button>
          </div>
          <div className="space-y-3">
            {RECENT_ACTIVITY.map((a) => (
              <div key={a.id} className="flex gap-2.5">
                <Avatar className="h-7 w-7 ring-1 ring-soft">
                  <AvatarImage src={a.avatar} alt={a.actor} />
                  <AvatarFallback>{a.actor.slice(0, 2)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="text-xs">
                    <span className="font-medium text-ink">{a.actor}</span>{" "}
                    <span className="text-muted-foreground">{a.action}</span>{" "}
                    <span className="font-medium text-ink">{a.target}</span>
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">{a.time}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
        </StaggerItem>
      </div>

      {/* Research strip */}
      <StaggerItem>
      <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-sm font-semibold text-ink">Active research</h2>
            <p className="text-[11px] text-muted-foreground">Studies currently in progress</p>
          </div>
          <Button asChild variant="ghost" size="sm" className="text-xs">
            <Link href="/research">Open repository <ChevronRight className="h-3 w-3" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {RESEARCH_STUDIES.filter((s) => s.status === "in-progress" || s.status === "analyzing" || s.status === "recruiting").slice(0, 3).map((s) => (
            <Link key={s.id} href={`/research/${s.id}`} className="rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors">
              <div className="flex items-center justify-between mb-1.5">
                <StatusBadge status={s.status as any} />
                <span className="text-[10px] text-muted-foreground">{s.method}</span>
              </div>
              <div className="text-xs font-medium text-ink line-clamp-2 mb-1">{s.title}</div>
              <div className="text-[10px] text-muted-foreground">{s.project} · {s.participants}/{s.targetParticipants} participants</div>
            </Link>
          ))}
        </div>
      </Card>
      </StaggerItem>
    </StaggerGroup>
  );
}

// ============================================================================
// Sub-components
// ============================================================================

function ProjectSwitcher({ value, onChange }: { value: typeof PROJECTS[number]; onChange: (p: typeof PROJECTS[number]) => void }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 rounded-full bg-surface-2 px-3 py-1.5 text-xs font-medium hover:bg-accent/60"
      >
        <span className="h-2 w-2 rounded-full" style={{ background: value.thumbColor }} />
        {value.name}
        <ChevronRight className={cn("h-3 w-3 transition-transform", open && "rotate-90")} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute z-20 mt-1 right-0 w-56 rounded-xl border border-soft bg-popover p-1 shadow-pop animate-soft-enter">
            {PROJECTS.map((p) => (
              <button
                key={p.id}
                onClick={() => { onChange(p); setOpen(false); }}
                className={cn(
                  "flex items-center gap-2 w-full rounded-lg px-2 py-1.5 text-left text-xs hover:bg-accent/60",
                  p.id === value.id && "bg-accent/40"
                )}
              >
                <span className="h-2 w-2 rounded-full" style={{ background: p.thumbColor }} />
                <span className="flex-1 truncate">{p.name}</span>
                <span className="text-[10px] text-muted-foreground">UX {p.uxScore}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function DateRangePicker() {
  const [range, setRange] = React.useState("12w");
  return (
    <div className="inline-flex items-center rounded-full bg-surface-2 p-0.5">
      {[
        ["7d", "7d"],
        ["4w", "4w"],
        ["12w", "12w"],
        ["qtd", "QTD"],
      ].map(([key, label]) => (
        <button
          key={key}
          onClick={() => setRange(key)}
          className={cn(
            "px-2.5 py-1 text-[10px] font-medium rounded-full transition-colors",
            range === key ? "bg-card text-ink shadow-soft" : "text-muted-foreground hover:text-ink"
          )}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

function ProjectPreview({ project, view }: { project: typeof PROJECTS[number]; view: string }) {
  if (view === "skeleton") {
    return (
      <div className="w-full h-full p-8 space-y-3">
        <div className="h-4 w-1/3 shimmer rounded" />
        <div className="h-32 w-full shimmer rounded-xl" />
        <div className="h-4 w-1/2 shimmer rounded" />
        <div className="h-20 w-full shimmer rounded" />
      </div>
    );
  }

  if (view === "heatmap") {
    return (
      <div className="relative w-full h-full bg-surface-2 overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center space-y-3">
            <Flame className="h-12 w-12 text-friction mx-auto opacity-50" />
            <div className="text-xs text-muted-foreground">Click heatmap preview</div>
            <div className="text-[10px] text-muted-foreground">1,240 sessions analyzed</div>
          </div>
        </div>
        {/* Hotspots */}
        {[
          { x: 30, y: 40, r: 60, c: "rgba(244, 81, 30, 0.6)" },
          { x: 65, y: 55, r: 90, c: "rgba(244, 81, 30, 0.4)" },
          { x: 50, y: 75, r: 40, c: "rgba(244, 179, 0, 0.5)" },
        ].map((h, i) => (
          <div
            key={i}
            className="absolute rounded-full blur-xl pointer-events-none"
            style={{ left: `${h.x}%`, top: `${h.y}%`, width: h.r, height: h.r, background: h.c, transform: "translate(-50%, -50%)" }}
          />
        ))}
      </div>
    );
  }

  if (view === "insights") {
    return (
      <div className="w-full h-full p-4 overflow-y-auto space-y-2 bg-surface-2">
        {INSIGHTS.slice(0, 4).map((i) => (
          <div key={i.id} className="rounded-xl bg-card border border-soft p-2.5">
            <div className="flex items-center gap-2 mb-1">
              <SeverityBadge severity={i.severity as any} />
              <span className="text-[10px] text-muted-foreground">Impact {i.impact}</span>
            </div>
            <div className="text-[11px] font-medium text-ink line-clamp-1">{i.title}</div>
            <div className="text-[10px] text-muted-foreground line-clamp-2 mt-0.5">{i.summary}</div>
          </div>
        ))}
      </div>
    );
  }

  // Standard
  return (
    <div className="relative w-full h-full overflow-hidden bg-surface-2">
      <ScreenMockup variant="dashboard" accentColor={project.thumbColor} />
      {/* Bottom info overlay */}
      <div className="absolute bottom-0 left-0 right-0 z-10 p-3 bg-gradient-to-t from-black/60 to-transparent">
        <div className="flex items-end justify-between gap-2">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <div
                className="flex h-5 w-5 items-center justify-center rounded-md text-white shadow-soft"
                style={{ background: project.thumbColor }}
              >
                <Eye className="h-3 w-3" />
              </div>
              <div className="text-xs font-semibold text-white drop-shadow">{project.name}</div>
            </div>
            <div className="flex items-center gap-1.5">
              <Badge variant="secondary" className="text-[9px] bg-white/90">UX {project.uxScore}</Badge>
              <Badge variant="secondary" className="text-[9px] bg-white/90">{project.screenCount} screens</Badge>
              <Badge variant="secondary" className="text-[9px] bg-white/90">{project.issueCount} issues</Badge>
            </div>
          </div>
          <ActiveDot color={project.thumbColor} size={6} />
        </div>
      </div>
    </div>
  );
}

function ReportCircle({ iconType, label, value, delay }: { iconType: "chart" | "list" | "book"; label: string; value: number; delay: number }) {
  const renderIcon = () => {
    switch (iconType) {
      case "chart":
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-5 w-5">
            <rect x="3" y="3" width="18" height="18" rx="2" />
            <path d="M8 10v7M12 7v10M16 13v4" />
          </svg>
        );
      case "list":
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-5 w-5">
            <rect x="3" y="5" width="18" height="4" rx="1" />
            <rect x="3" y="11" width="18" height="4" rx="1" />
            <rect x="3" y="17" width="18" height="4" rx="1" />
          </svg>
        );
      case "book":
        return (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-5 w-5">
            <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
            <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
            <path d="M12 6v8M9 10h6" />
          </svg>
        );
    }
  };

  const color = value > 80 ? "var(--success)" : value > 65 ? "var(--warning)" : "var(--friction)";

  return (
    <div className="text-center">
      <div className="relative mx-auto mb-2 flex h-16 w-16 md:h-20 md:w-20 items-center justify-center">
        <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" fill="none" stroke="var(--muted)" strokeWidth="3" />
          <motion.circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke={color}
            strokeWidth="3"
            strokeDasharray="283"
            strokeLinecap="round"
            initial={{ strokeDashoffset: 283 }}
            animate={{ strokeDashoffset: 283 - (283 * value) / 100 }}
            transition={{ duration: 0.9, delay: delay / 1000, ease: [0.22, 1, 0.36, 1] }}
          />
        </svg>
        <div className="relative z-10 flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-xl bg-card shadow-soft text-primary">
          {renderIcon()}
        </div>
      </div>
      <div className="text-[10px] font-medium text-ink">{label}</div>
      <div className="text-[10px] text-muted-foreground">
        <AnimatedNumber value={value} suffix="%" duration={1.4} />
      </div>
    </div>
  );
}
