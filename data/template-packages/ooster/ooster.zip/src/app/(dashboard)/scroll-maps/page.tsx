"use client";

import * as React from "react";
import {
  ArrowDownUp,
  ArrowDown,
  Download,
  Pause,
  TrendingDown,
  Monitor,
  Smartphone,
  Tablet,
  Eye,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DonutChart } from "@/components/charts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const PAUSE_POINTS = [
  { element: "Pricing table", avgPause: "8.4s", depth: 45, sessions: 642 },
  { element: "FAQ accordion", avgPause: "6.1s", depth: 62, sessions: 318 },
  { element: "Testimonial section", avgPause: "4.8s", depth: 55, sessions: 412 },
  { element: "CTA banner (mid-page)", avgPause: "3.2s", depth: 70, sessions: 824 },
  { element: "Footer newsletter form", avgPause: "2.4s", depth: 92, sessions: 186 },
];

const DROP_OFFS = [
  { element: "Long legal paragraph", dropOff: 38, depth: 30 },
  { element: "Heavy image gallery", dropOff: 24, depth: 48 },
  { element: "Testimonial carousel", dropOff: 18, depth: 58 },
];

const DEPTH_DISTRIBUTION = [
  { label: "0–25%", value: 28, color: "var(--success)" },
  { label: "26–50%", value: 34, color: "var(--info)" },
  { label: "51–75%", value: 22, color: "var(--warning)" },
  { label: "76–100%", value: 16, color: "var(--friction)" },
];

const DEVICE_DEPTH = [
  { device: "Desktop", avgDepth: 78, reachBottom: 42, icon: Monitor },
  { device: "Mobile", avgDepth: 54, reachBottom: 19, icon: Smartphone },
  { device: "Tablet", avgDepth: 71, reachBottom: 33, icon: Tablet },
];

export default function ScrollMapsPage() {
  const [loading, setLoading] = React.useState(true);
  const [project, setProject] = React.useState("all");
  const [screen, setScreen] = React.useState("0");
  const [device, setDevice] = React.useState("all");
  const [segment, setSegment] = React.useState("all");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const avgDepth = 64;
  const aboveFoldViews = 100;
  const reachBottom = 21;
  const avgVelocity = 412;

  return (
    <div>
      <PageHeader
        title="Scroll Maps"
        description="How far users scroll, where they pause, and what they miss"
        breadcrumbs={[{ label: "Analytics" }, { label: "Scroll Maps" }]}
        icon={<ArrowDownUp className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">2,140 sessions</Badge>}
        actions={
          <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.success("Scroll data exported")}>
            <Download className="mr-2 h-3.5 w-3.5" /> Export
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Filter bar */}
          <Card className="rounded-2xl border-soft shadow-soft p-3 mb-4">
            <FilterBar
              selects={[
                {
                  label: "Project",
                  value: project,
                  onChange: setProject,
                  options: [
                    { label: "All projects", value: "all" },
                    { label: "Atlas Onboarding", value: "atlas" },
                    { label: "Northwind Checkout", value: "northwind" },
                    { label: "Voyage Booking", value: "voyage" },
                  ],
                },
                {
                  label: "Screen",
                  value: screen,
                  onChange: setScreen,
                  options: [
                    { label: "Landing / Home", value: "0" },
                    { label: "Pricing", value: "1" },
                    { label: "Product detail", value: "2" },
                  ],
                },
                {
                  label: "Device",
                  value: device,
                  onChange: setDevice,
                  options: [
                    { label: "All devices", value: "all" },
                    { label: "Desktop", value: "desktop" },
                    { label: "Mobile", value: "mobile" },
                    { label: "Tablet", value: "tablet" },
                  ],
                },
                {
                  label: "Segment",
                  value: segment,
                  onChange: setSegment,
                  options: [
                    { label: "All segments", value: "all" },
                    { label: "New visitors", value: "new" },
                    { label: "Returning", value: "returning" },
                  ],
                },
              ]}
              onClear={() => { setProject("all"); setScreen("0"); setDevice("all"); setSegment("all"); }}
            />
          </Card>

          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Avg scroll depth"
              value={`${avgDepth}%`}
              icon={<ArrowDown className="h-4 w-4" />}
              accent="info"
              trend={{ value: 4, direction: "up", good: true }}
              sublabel="vs last month"
            />
            <StatCard
              label="Above-fold views"
              value={`${aboveFoldViews}%`}
              icon={<Eye className="h-4 w-4" />}
              accent="success"
              sublabel="of all sessions"
            />
            <StatCard
              label="Reach bottom rate"
              value={`${reachBottom}%`}
              icon={<ArrowDownUp className="h-4 w-4" />}
              accent="friction"
              trend={{ value: 2.1, direction: "down", good: false }}
              sublabel="below benchmark"
            />
            <StatCard
              label="Avg scroll velocity"
              value={`${avgVelocity}`}
              unit="px/s"
              icon={<ArrowDown className="h-4 w-4" />}
              accent="default"
              trend={{ value: 8, direction: "up", good: false }}
              sublabel="faster = lower engagement"
            />
          </div>

          {/* Main grid: tall viz + side */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            {/* Tall 9:16 scroll visualization */}
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Scroll depth heatmap</div>
                  <div className="text-[11px] text-muted-foreground">Brighter = more viewers · darker = fewer</div>
                </div>
                <Badge variant="outline" className="text-[10px]">9:16 viewport</Badge>
              </div>

              <div className="flex gap-4 justify-center">
                {/* The mock screen */}
                <div className="relative w-full max-w-[280px]" style={{ aspectRatio: "9 / 16" }}>
                  {/* Background mock content */}
                  <div className="absolute inset-0 rounded-2xl overflow-hidden bg-surface-2 border border-soft">
                    <div className="h-full flex flex-col gap-2 p-3">
                      {/* Hero */}
                      <div className="space-y-1.5">
                        <div className="h-4 w-3/4 rounded bg-muted-foreground/25" />
                        <div className="h-2 w-full rounded bg-muted-foreground/15" />
                        <div className="h-2 w-2/3 rounded bg-muted-foreground/15" />
                        <div className="h-8 w-24 rounded-lg bg-success/30 mt-1" />
                      </div>
                      {/* Pricing table */}
                      <div className="grid grid-cols-2 gap-1.5 mt-2">
                        <div className="h-12 rounded bg-muted-foreground/10" />
                        <div className="h-12 rounded bg-muted-foreground/10" />
                      </div>
                      {/* Testimonials */}
                      <div className="space-y-1 mt-2">
                        <div className="h-2 w-full rounded bg-muted-foreground/10" />
                        <div className="h-2 w-5/6 rounded bg-muted-foreground/10" />
                      </div>
                      {/* FAQ */}
                      <div className="space-y-1 mt-2">
                        <div className="h-2 w-full rounded bg-muted-foreground/10" />
                        <div className="h-2 w-4/5 rounded bg-muted-foreground/10" />
                      </div>
                      {/* Footer */}
                      <div className="mt-auto space-y-1">
                        <div className="h-2 w-2/3 rounded bg-muted-foreground/10" />
                        <div className="h-2 w-1/2 rounded bg-muted-foreground/10" />
                      </div>
                    </div>

                    {/* Scroll depth gradient overlay — top bright, bottom dark */}
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{
                        background: "linear-gradient(to bottom, var(--success) 0%, var(--success) 8%, color-mix(in oklch, var(--info) 80%, transparent) 30%, color-mix(in oklch, var(--warning) 60%, transparent) 55%, color-mix(in oklch, var(--friction) 40%, transparent) 80%, color-mix(in oklch, var(--friction) 20%, transparent) 100%)",
                        opacity: 0.4,
                      }}
                    />

                    {/* Percentage markers */}
                    {[25, 50, 75, 100].map((pct) => (
                      <div
                        key={pct}
                        className="absolute left-0 right-0 flex items-center gap-1 group"
                        style={{ top: `${pct}%`, transform: "translateY(-50%)" }}
                      >
                        <div
                          className="flex-1 border-t border-dashed"
                          style={{ borderColor: pct <= 50 ? "var(--success)" : pct <= 75 ? "var(--warning)" : "var(--friction)" }}
                        />
                        <span
                          className="px-1.5 py-0.5 rounded text-[9px] font-semibold tabular-nums shadow-soft"
                          style={{
                            background: pct <= 50 ? "var(--success)" : pct <= 75 ? "var(--warning)" : "var(--friction)",
                            color: "white",
                          }}
                        >
                          {pct}%
                        </span>
                      </div>
                    ))}

                    {/* Pause indicators */}
                    {PAUSE_POINTS.map((p, i) => (
                      <div
                        key={i}
                        className="absolute -right-1 group cursor-pointer"
                        style={{ top: `${p.depth}%`, transform: "translateY(-50%)" }}
                        onClick={() => toast.info(`${p.element}: ${p.avgPause} avg pause`)}
                      >
                        <span className="block h-3 w-3 rounded-full bg-warning border-2 border-white shadow-soft" />
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute right-4 top-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded bg-card border border-soft text-[9px] text-ink shadow-pop whitespace-nowrap z-10">
                          {p.element}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Side scale */}
                <div className="hidden sm:flex flex-col justify-between text-[10px] text-muted-foreground py-1">
                  <span>0%<br /><span className="text-success">100% view</span></span>
                  <span>25%<br /><span className="text-info">95% view</span></span>
                  <span>50%<br /><span className="text-warning">66% view</span></span>
                  <span>75%<br /><span className="text-warning">38% view</span></span>
                  <span>100%<br /><span className="text-friction">21% reach</span></span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-soft grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                <div>
                  <div className="text-muted-foreground">0–25% depth</div>
                  <div className="font-semibold text-success tabular-nums">95% of sessions</div>
                </div>
                <div>
                  <div className="text-muted-foreground">26–50% depth</div>
                  <div className="font-semibold text-info tabular-nums">66% of sessions</div>
                </div>
                <div>
                  <div className="text-muted-foreground">51–75% depth</div>
                  <div className="font-semibold text-warning tabular-nums">38% of sessions</div>
                </div>
                <div>
                  <div className="text-muted-foreground">76–100% depth</div>
                  <div className="font-semibold text-friction tabular-nums">21% of sessions</div>
                </div>
              </div>
            </Card>

            {/* Side: distribution donut + pause + drop-off */}
            <div className="flex flex-col gap-4">
              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="text-sm font-semibold text-ink mb-3">Scroll depth distribution</div>
                <div className="flex flex-col items-center">
                  <DonutChart
                    data={DEPTH_DISTRIBUTION}
                    size={140}
                    strokeWidth={16}
                    centerValue="64%"
                    centerLabel="avg depth"
                  />
                  <div className="mt-3 w-full space-y-1.5">
                    {DEPTH_DISTRIBUTION.map((d) => (
                      <div key={d.label} className="flex items-center justify-between text-[10px]">
                        <div className="flex items-center gap-1.5">
                          <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
                          <span className="text-muted-foreground">{d.label}</span>
                        </div>
                        <span className="font-semibold text-ink tabular-nums">{d.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>

              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Pause className="h-4 w-4 text-warning" />
                  <div className="text-sm font-semibold text-ink">Pause points</div>
                </div>
                <div className="space-y-2">
                  {PAUSE_POINTS.map((p, i) => (
                    <div key={i} className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-ink truncate">{p.element}</div>
                        <div className="text-[10px] text-muted-foreground">{p.sessions} sessions · {p.depth}% depth</div>
                      </div>
                      <span className="text-xs font-semibold tabular-nums text-warning flex-shrink-0">{p.avgPause}</span>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingDown className="h-4 w-4 text-friction" />
                  <div className="text-sm font-semibold text-ink">Drop-off points</div>
                </div>
                <div className="space-y-2">
                  {DROP_OFFS.map((d) => (
                    <div key={d.element} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-ink truncate">{d.element}</span>
                        <span className="text-[10px] text-friction tabular-nums">{d.dropOff}% drop</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${d.dropOff * 2}%`, background: "var(--friction)" }} />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>

          {/* Bottom: device comparison */}
          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden">
            <div className="p-4 border-b border-soft">
              <div className="text-sm font-semibold text-ink">Scroll depth by device</div>
              <div className="text-[11px] text-muted-foreground">Desktop, Mobile, and Tablet scroll behavior comparison</div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-border">
              {DEVICE_DEPTH.map((d) => {
                const Icon = d.icon;
                return (
                  <div key={d.device} className="p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-2 text-info">
                        <Icon className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-ink">{d.device}</div>
                        <div className="text-[10px] text-muted-foreground">{d.reachBottom}% reach bottom</div>
                      </div>
                    </div>

                    {/* Mini scroll bar */}
                    <div className="relative h-32 w-full rounded-lg bg-surface-2 overflow-hidden mb-2">
                      <div
                        className="absolute inset-x-0 top-0"
                        style={{
                          height: `${d.avgDepth}%`,
                          background: "linear-gradient(to bottom, var(--success) 0%, color-mix(in oklch, var(--info) 70%, transparent) 50%, color-mix(in oklch, var(--warning) 50%, transparent) 100%)",
                          opacity: 0.7,
                        }}
                      />
                      <div
                        className="absolute inset-x-0 border-t-2 border-dashed"
                        style={{ top: `${d.avgDepth}%`, borderColor: "var(--friction)" }}
                      >
                        <span className="absolute -top-2.5 right-1 text-[9px] font-semibold text-friction tabular-nums">{d.avgDepth}%</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-muted-foreground">Avg depth</span>
                      <span className="font-semibold text-ink tabular-nums">{d.avgDepth}%</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px] mt-1">
                      <span className="text-muted-foreground">Reach bottom</span>
                      <span className={cn("font-semibold tabular-nums", d.reachBottom >= 35 ? "text-success" : d.reachBottom >= 20 ? "text-warning" : "text-friction")}>
                        {d.reachBottom}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
