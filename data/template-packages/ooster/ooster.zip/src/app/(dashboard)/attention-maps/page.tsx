"use client";

import * as React from "react";
import {
  Eye,
  Timer,
  ArrowUp,
  ArrowDown,
  Lightbulb,
  Download,
  Flame,
  Snowflake,
  Monitor,
  Smartphone,
  Tablet,
  EyeOff,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Hotspot {
  x: number;
  y: number;
  size: number;
  intensity: "high" | "medium" | "low";
  label: string;
}

// Mock attention hotspots on a 16:9 canvas (percentages)
const HOTSPOTS: Hotspot[] = [
  { x: 22, y: 28, size: 180, intensity: "high", label: "Hero headline" },
  { x: 58, y: 32, size: 140, intensity: "high", label: "Primary CTA" },
  { x: 40, y: 55, size: 120, intensity: "medium", label: "Product image" },
  { x: 75, y: 60, size: 90, intensity: "medium", label: "Pricing pill" },
  { x: 15, y: 72, size: 70, intensity: "low", label: "Footer link" },
  { x: 85, y: 80, size: 60, intensity: "low", label: "Legal text" },
];

const ATTENTION_ZONES = [
  { rank: 1, name: "Hero headline", pct: 38, intensity: "high" as const, firstFix: "0.4s" },
  { rank: 2, name: "Primary CTA", pct: 27, intensity: "high" as const, firstFix: "1.2s" },
  { rank: 3, name: "Product image", pct: 14, intensity: "medium" as const, firstFix: "2.1s" },
  { rank: 4, name: "Pricing pill", pct: 9, intensity: "medium" as const, firstFix: "3.8s" },
  { rank: 5, name: "Testimonial quote", pct: 6, intensity: "low" as const, firstFix: "5.4s" },
];

const COLD_ZONES = [
  { name: "Footer legal text", views: 4 },
  { name: "Cookie banner detail", views: 6 },
  { name: "Below-fold disclaimer", views: 9 },
];

const DEVICE_COMPARISON = [
  { zone: "Hero headline", desktop: 42, mobile: 31, tablet: 38 },
  { zone: "Primary CTA", desktop: 28, mobile: 22, tablet: 26 },
  { zone: "Product image", desktop: 15, mobile: 19, tablet: 17 },
  { zone: "Pricing pill", desktop: 9, mobile: 14, tablet: 11 },
  { zone: "Footer area", desktop: 6, mobile: 14, tablet: 8 },
];

const RECOMMENDATIONS = [
  "Hero headline captures 38% of attention — move the value prop higher within it.",
  "CTA fixation is delayed (1.2s); increase contrast or proximity to the headline.",
  "Below-fold disclaimer receives <10% attention — relocate compliance info inline.",
];

const INTENSITY_COLOR: Record<Hotspot["intensity"], string> = {
  high: "var(--success)",
  medium: "var(--info)",
  low: "var(--muted-foreground)",
};

const INTENSITY_LABEL: Record<Hotspot["intensity"], string> = {
  high: "High",
  medium: "Medium",
  low: "Low",
};

const SCREENS = ["Landing / Home", "Pricing", "Checkout — Step 1", "Product detail"];

export default function AttentionMapsPage() {
  const [loading, setLoading] = React.useState(true);
  const [project, setProject] = React.useState("all");
  const [screen, setScreen] = React.useState("0");
  const [device, setDevice] = React.useState("all");
  const [segment, setSegment] = React.useState("all");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const totalSessions = 1842;
  const avgFirstFix = 0.7;
  const avgDuration = 12.4;
  const aboveFold = 71;
  const belowFold = 18;

  return (
    <div>
      <PageHeader
        title="Attention Maps"
        description="Where users look first, longest, and most often — powered by eye-tracking and scroll velocity"
        breadcrumbs={[{ label: "Analytics" }, { label: "Attention Maps" }]}
        icon={<Eye className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">Eye-tracking</Badge>}
        actions={
          <Button variant="outline" size="sm" className="rounded-full" onClick={() => toast.success("Attention heatmap exported")}>
            <Download className="mr-2 h-3.5 w-3.5" /> Export
          </Button>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Filter bar */}
          <Card className="rounded-2xl border-soft shadow-soft p-3 mb-4">
            <FilterBar
              selects={[
                {
                  label: "Project",
                  value: project,
                  onChange: setProject,
                  options: [
                    { label: "All projects", value: "all" },
                    { label: "Atlas Onboarding", value: "atlas" },
                    { label: "Northwind Checkout", value: "northwind" },
                    { label: "Voyage Booking", value: "voyage" },
                  ],
                },
                {
                  label: "Screen",
                  value: screen,
                  onChange: setScreen,
                  options: SCREENS.map((s, i) => ({ label: s, value: String(i) })),
                },
                {
                  label: "Device",
                  value: device,
                  onChange: setDevice,
                  options: [
                    { label: "All devices", value: "all" },
                    { label: "Desktop", value: "desktop" },
                    { label: "Mobile", value: "mobile" },
                    { label: "Tablet", value: "tablet" },
                  ],
                },
                {
                  label: "Segment",
                  value: segment,
                  onChange: setSegment,
                  options: [
                    { label: "All segments", value: "all" },
                    { label: "New visitors", value: "new" },
                    { label: "Returning", value: "returning" },
                  ],
                },
              ]}
              onClear={() => { setProject("all"); setScreen("0"); setDevice("all"); setSegment("all"); }}
            />
          </Card>

          {/* Stat row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            <StatCard
              label="Avg first-fixation time"
              value={`${avgFirstFix}s`}
              icon={<Timer className="h-4 w-4" />}
              accent="info"
              trend={{ value: 0.2, direction: "down", good: true }}
              sublabel="faster than benchmark"
            />
            <StatCard
              label="Attention duration"
              value={`${avgDuration}s`}
              icon={<Eye className="h-4 w-4" />}
              accent="success"
              trend={{ value: 8, direction: "up", good: true }}
              sublabel="avg per session"
            />
            <StatCard
              label="Above-the-fold attention"
              value={`${aboveFold}%`}
              icon={<ArrowUp className="h-4 w-4" />}
              accent="success"
              sublabel="of total fixation"
            />
            <StatCard
              label="Below-fold attention"
              value={`${belowFold}%`}
              icon={<ArrowDown className="h-4 w-4" />}
              accent="friction"
              sublabel={`${totalSessions.toLocaleString()} sessions`}
            />
          </div>

          {/* Main grid: visualization + side */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            {/* Attention visualization */}
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">Attention heatmap</div>
                  <div className="text-[11px] text-muted-foreground">{SCREENS[Number(screen)]} · {totalSessions.toLocaleString()} sessions</div>
                </div>
                {/* Screen selector */}
                <div className="inline-flex items-center rounded-lg bg-surface-2 p-0.5">
                  {SCREENS.map((s, i) => (
                    <button
                      key={s}
                      onClick={() => setScreen(String(i))}
                      className={cn(
                        "px-2 py-1 text-[10px] font-medium rounded-md transition-all",
                        screen === String(i) ? "bg-card text-ink shadow-soft" : "text-muted-foreground hover:text-ink"
                      )}
                    >
                      {s.split(" ")[0]}
                    </button>
                  ))}
                </div>
              </div>

              {/* 16:9 visualization */}
              <div className="relative w-full overflow-hidden rounded-xl bg-surface-2" style={{ aspectRatio: "16 / 9" }}>
                {/* Mock screen content */}
                <div className="absolute inset-0 p-4 sm:p-6 flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <div className="h-3 w-24 rounded bg-muted-foreground/20" />
                    <div className="flex gap-2">
                      <div className="h-3 w-8 rounded bg-muted-foreground/15" />
                      <div className="h-3 w-8 rounded bg-muted-foreground/15" />
                      <div className="h-3 w-8 rounded bg-muted-foreground/15" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 flex-1">
                    <div className="space-y-2">
                      <div className="h-5 w-3/4 rounded bg-muted-foreground/25" />
                      <div className="h-5 w-1/2 rounded bg-muted-foreground/20" />
                      <div className="h-2 w-full rounded bg-muted-foreground/10" />
                      <div className="h-2 w-5/6 rounded bg-muted-foreground/10" />
                      <div className="h-7 w-24 rounded-lg bg-success/30 mt-2" />
                    </div>
                    <div className="rounded-lg bg-muted-foreground/15" />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="h-10 rounded bg-muted-foreground/10" />
                    <div className="h-10 rounded bg-muted-foreground/10" />
                    <div className="h-10 rounded bg-muted-foreground/10" />
                  </div>
                </div>

                {/* Attention hotspots */}
                {HOTSPOTS.map((h, i) => (
                  <div
                    key={i}
                    className="absolute rounded-full pointer-events-none mix-blend-multiply"
                    style={{
                      left: `${h.x}%`,
                      top: `${h.y}%`,
                      width: h.size,
                      height: h.size,
                      transform: "translate(-50%, -50%)",
                      background: `radial-gradient(circle, ${INTENSITY_COLOR[h.intensity]} 0%, transparent 70%)`,
                      opacity: 0.65,
                    }}
                  />
                ))}

                {/* Hotspot labels */}
                {HOTSPOTS.filter((h) => h.intensity !== "low").map((h, i) => (
                  <div
                    key={`l-${i}`}
                    className="absolute -translate-x-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded bg-card/90 border border-soft text-[9px] font-medium text-ink shadow-soft backdrop-blur-sm whitespace-nowrap"
                    style={{ left: `${h.x}%`, top: `calc(${h.y}% + ${h.size / 2 + 8}px)` }}
                  >
                    {h.label}
                  </div>
                ))}
              </div>

              {/* Legend */}
              <div className="mt-3 flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-3 text-[10px]">
                  {(["high", "medium", "low"] as const).map((k) => (
                    <div key={k} className="flex items-center gap-1.5">
                      <span
                        className="h-3 w-3 rounded-full"
                        style={{ background: `radial-gradient(circle, ${INTENSITY_COLOR[k]} 0%, transparent 70%)` }}
                      />
                      <span className="text-muted-foreground">{INTENSITY_LABEL[k]} attention</span>
                    </div>
                  ))}
                </div>
                <span className="text-[10px] text-muted-foreground">Mix-blend: multiply · 65% opacity</span>
              </div>
            </Card>

            {/* Side: zones + cold + recommendations */}
            <div className="flex flex-col gap-4">
              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Flame className="h-4 w-4 text-success" />
                  <div className="text-sm font-semibold text-ink">Top attention zones</div>
                </div>
                <div className="space-y-2.5">
                  {ATTENTION_ZONES.map((z) => (
                    <div key={z.rank} className="space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="text-[10px] text-muted-foreground tabular-nums w-3">{z.rank}</span>
                          <span className="text-xs font-medium text-ink truncate">{z.name}</span>
                        </div>
                        <span className="text-xs font-semibold tabular-nums text-ink flex-shrink-0">{z.pct}%</span>
                      </div>
                      <div className="flex items-center gap-2 pl-4">
                        <div className="h-1.5 flex-1 rounded-full bg-surface-2 overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${z.pct * 2.5}%`,
                              background: INTENSITY_COLOR[z.intensity],
                            }}
                          />
                        </div>
                        <span className="text-[9px] text-muted-foreground tabular-nums w-10 text-right">fix {z.firstFix}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Snowflake className="h-4 w-4 text-info" />
                  <div className="text-sm font-semibold text-ink">Cold zones</div>
                </div>
                <div className="space-y-2">
                  {COLD_ZONES.map((c) => (
                    <div key={c.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <EyeOff className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                        <span className="text-xs text-ink truncate">{c.name}</span>
                      </div>
                      <span className="text-[10px] text-muted-foreground tabular-nums">{c.views}% viewed</span>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Lightbulb className="h-4 w-4 text-warning" />
                  <div className="text-sm font-semibold text-ink">Recommendations</div>
                </div>
                <ul className="space-y-2">
                  {RECOMMENDATIONS.map((r, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full bg-warning/15 text-warning text-[9px] font-semibold mt-0.5">{i + 1}</span>
                      <p className="text-[11px] text-ink leading-relaxed">{r}</p>
                    </li>
                  ))}
                </ul>
              </Card>
            </div>
          </div>

          {/* Bottom: device comparison */}
          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden">
            <div className="p-4 border-b border-soft flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold text-ink">Device comparison</div>
                <div className="text-[11px] text-muted-foreground">Attention % by zone across Desktop, Mobile, and Tablet</div>
              </div>
              <div className="flex items-center gap-3 text-[10px]">
                <div className="flex items-center gap-1"><Monitor className="h-3 w-3" /><span className="text-muted-foreground">Desktop</span></div>
                <div className="flex items-center gap-1"><Smartphone className="h-3 w-3" /><span className="text-muted-foreground">Mobile</span></div>
                <div className="flex items-center gap-1"><Tablet className="h-3 w-3" /><span className="text-muted-foreground">Tablet</span></div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-soft">
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Zone</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Desktop</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Mobile</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Tablet</th>
                  </tr>
                </thead>
                <tbody>
                  {DEVICE_COMPARISON.map((row) => (
                    <tr key={row.zone} className="border-b border-soft last:border-0 hover:bg-accent/30 transition-colors">
                      <td className="px-4 py-3 font-medium text-ink">{row.zone}</td>
                      {[row.desktop, row.mobile, row.tablet].map((v, i) => (
                        <td key={i} className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="h-1.5 w-16 rounded-full bg-surface-2 overflow-hidden">
                              <div
                                className="h-full rounded-full"
                                style={{
                                  width: `${v * 2}%`,
                                  background: v >= 30 ? "var(--success)" : v >= 15 ? "var(--warning)" : "var(--friction)",
                                }}
                              />
                            </div>
                            <span className="tabular-nums text-ink">{v}%</span>
                          </div>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
