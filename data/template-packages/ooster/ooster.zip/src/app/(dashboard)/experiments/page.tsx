"use client";

import * as React from "react";
import Link from "next/link";
import {
  FlaskConical,
  Plus,
  Download,
  ChevronRight,
  PlayCircle,
  CheckCircle2,
  Trophy,
  Target,
  GitCompareArrows,
  Activity,
  Clock,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EXPERIMENTS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const TYPE_OPTIONS: FilterOption[] = [
  { label: "All types", value: "all" },
  { label: "A/B test", value: "ab-test" },
  { label: "Multivariate", value: "multivariate" },
  { label: "Split URL", value: "split-url" },
  { label: "Prototype", value: "prototype" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Running", value: "running" },
  { label: "Completed", value: "completed" },
  { label: "Paused", value: "paused" },
  { label: "Draft", value: "draft" },
];

const TYPE_LABELS: Record<string, string> = {
  "ab-test": "A/B test",
  multivariate: "Multivariate",
  "split-url": "Split URL",
  prototype: "Prototype",
};

const TYPE_BADGE_STYLES: Record<string, string> = {
  "ab-test": "bg-info/15 text-info border-info/20",
  multivariate: "bg-friction/15 text-friction border-friction/20",
  "split-url": "bg-warning/15 text-warning border-warning/20",
  prototype: "bg-muted text-muted-foreground border-border",
};

export default function ExperimentsPage() {
  const [search, setSearch] = React.useState("");
  const [type, setType] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return EXPERIMENTS.filter((e) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !e.name.toLowerCase().includes(q) &&
          !e.hypothesis.toLowerCase().includes(q) &&
          !e.project.toLowerCase().includes(q)
        )
          return false;
      }
      if (type !== "all" && e.type !== type) return false;
      if (status !== "all" && e.status !== status) return false;
      return true;
    });
  }, [search, type, status]);

  const clearFilters = () => {
    setSearch("");
    setType("all");
    setStatus("all");
  };

  const running = EXPERIMENTS.filter((e) => e.status === "running").length;
  const completed = EXPERIMENTS.filter((e) => e.status === "completed").length;
  const avgSig = Math.round(
    EXPERIMENTS.reduce((s, e) => s + e.significance, 0) / EXPERIMENTS.length
  );
  const winners = EXPERIMENTS.filter(
    (e) =>
      e.status === "completed" &&
      e.variants.some((v, idx) => idx > 0 && v.conversion > e.variants[0].conversion)
  ).length;

  return (
    <div>
      <PageHeader
        title="Experiments"
        description="A/B tests, multivariate tests, and prototype experiments"
        icon={<FlaskConical className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {EXPERIMENTS.length} experiments
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Experiments log exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Opening new experiment wizard…")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> New experiment
            </Button>
          </>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Running"
          value={running}
          icon={<PlayCircle className="h-4 w-4" />}
          accent="info"
          sublabel="collecting data now"
        />
        <StatCard
          label="Completed"
          value={completed}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          sublabel="concluded this quarter"
        />
        <StatCard
          label="Avg significance"
          value={`${avgSig}%`}
          icon={<Activity className="h-4 w-4" />}
          accent="warning"
          sublabel="across all experiments"
        />
        <StatCard
          label="Winners"
          value={winners}
          icon={<Trophy className="h-4 w-4" />}
          accent="success"
          trend={{ value: 14, direction: "up", good: true }}
          sublabel="variant beat control"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search experiments…",
          }}
          selects={[
            { label: "Type", value: type, onChange: setType, options: TYPE_OPTIONS },
            { label: "Status", value: status, onChange: setStatus, options: STATUS_OPTIONS },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={FlaskConical}
          title="No experiments match your filters"
          description="Spin up an A/B test from any insight or recommendation, or prototype test from a Figma frame."
          action={{ label: "New experiment", onClick: () => toast.message("Opening new experiment wizard…") }}
          secondaryAction={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((e) => {
            const control = e.variants[0];
            const leading = e.variants.slice(1).sort((a, b) => b.conversion - a.conversion)[0] ?? control;
            const isWin = leading.conversion > control.conversion;
            const lift = control.conversion > 0
              ? Math.round(((leading.conversion - control.conversion) / control.conversion) * 100)
              : 0;
            return (
              <Link key={e.id} href={`/experiments/${e.id}`} className="group">
                <Card className="rounded-2xl border-soft shadow-soft p-4 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1.5">
                      <Badge variant="outline" className={cn("text-[10px]", TYPE_BADGE_STYLES[e.type])}>
                        {TYPE_LABELS[e.type]}
                      </Badge>
                      <StatusBadge status={e.status} />
                    </div>
                    <Badge variant="outline" className="text-[10px]">
                      {e.variants.length} variants
                    </Badge>
                  </div>

                  {/* Name */}
                  <h3 className="text-sm font-semibold text-ink group-hover:text-primary transition-colors line-clamp-1">
                    {e.name}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2 flex-1">{e.hypothesis}</p>

                  {/* Primary metric */}
                  <div className="mt-3 flex items-center gap-2 text-xs">
                    <Target className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-muted-foreground">Primary metric:</span>
                    <span className="text-ink font-medium truncate">{e.primaryMetric}</span>
                  </div>

                  {/* Leading variant */}
                  <div className="mt-3 rounded-xl border border-soft p-2.5 bg-surface-2/40">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                        Leading variant
                      </div>
                      {isWin && (
                        <Badge variant="outline" className="text-[10px] bg-success/15 text-success border-success/20">
                          <Trophy className="h-2.5 w-2.5 mr-1" /> Winner
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-ink truncate">{leading.name}</div>
                        <div className="text-[10px] text-muted-foreground">
                          {leading.conversion}% conv · {leading.confidence > 0 ? `${leading.confidence}% conf` : "—"}
                        </div>
                      </div>
                      <div
                        className={cn(
                          "text-sm font-semibold",
                          lift > 0 ? "text-success" : lift < 0 ? "text-friction" : "text-muted-foreground"
                        )}
                      >
                        {lift > 0 ? "+" : ""}{lift}%
                      </div>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="mt-3 pt-3 border-t border-soft flex items-center justify-between text-[10px] text-muted-foreground">
                    <div className="flex items-center gap-1.5">
                      <Clock className="h-3 w-3" />
                      <span>{e.startDate} → {e.endDate}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <ChevronRight className="h-3.5 w-3.5 group-hover:text-ink transition-colors" />
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}

      {/* Helper card */}
      {!loading && (
        <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4 bg-surface-2/40">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary flex-shrink-0">
              <Sparkles className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-ink">Need experiment ideas?</div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Ooster will draft hypotheses from any open recommendation, insight, or friction point in your backlog.
              </div>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="rounded-full text-xs flex-shrink-0"
              onClick={() => toast.success("Drafting experiment hypotheses…")}
            >
              <GitCompareArrows className="mr-1.5 h-3 w-3" /> Draft from backlog
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
