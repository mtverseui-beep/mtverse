"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  FlaskConical,
  Share2,
  Pause,
  Pencil,
  Trophy,
  Target,
  Activity,
  Users,
  Calendar,
  Percent,
  TrendingUp,
  TrendingDown,
  MessageSquare,
  Send,
  ChevronRight,
  Sparkles,
  Lightbulb,
  PieChart,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { LineChart, MiniTrend } from "@/components/charts";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { useModals } from "@/hooks/use-modals";
import { getExperiment } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const av = (seed: number) => `https://i.pravatar.cc/80?img=${seed}`;

interface MockComment {
  author: string;
  avatar: string;
  time: string;
  body: string;
}

const MOCK_COMMENTS: MockComment[] = [
  {
    author: "Sana Iqbal",
    avatar: av(20),
    time: "3 hours ago",
    body: "Variant has crossed 99% significance this morning — calling it. I'll roll to 100% traffic today and start drafting the launch note.",
  },
  {
    author: "Theo Park",
    avatar: av(13),
    time: "Yesterday",
    body: "Curious if we should hold the variant for one more week to check the guardrail metrics (form-error rate is up 1.2pp). Probably noise but worth confirming.",
  },
  {
    author: "Mira Halberg",
    avatar: av(12),
    time: "2 days ago",
    body: "Let's also segment by device — mobile lifts tend to be larger here. If the desktop lift is flat we may want to ship mobile-only.",
  },
];

// Mocked daily conversion-rate timeline (Control vs Variant)
const TIMELINE = [
  { label: "Day 1", values: [{ label: "Control", value: 61 }, { label: "Variant", value: 64 }] },
  { label: "Day 2", values: [{ label: "Control", value: 60 }, { label: "Variant", value: 66 }] },
  { label: "Day 3", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 70 }] },
  { label: "Day 4", values: [{ label: "Control", value: 61 }, { label: "Variant", value: 73 }] },
  { label: "Day 5", values: [{ label: "Control", value: 63 }, { label: "Variant", value: 76 }] },
  { label: "Day 6", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 79 }] },
  { label: "Day 7", values: [{ label: "Control", value: 62 }, { label: "Variant", value: 81 }] },
];

const RECOMMENDATIONS = [
  {
    title: "Ship variant to 100% traffic",
    detail: "Variant beats control by 19pp on checkout completion with 99.4% confidence. Roll out now.",
    priority: "P0",
  },
  {
    title: "Test variant on mobile-first audience",
    detail: "Mobile lift is +21pp vs desktop +14pp. Consider a follow-up test focused on mobile-only entry points.",
    priority: "P1",
  },
  {
    title: "Watch form-error guardrail",
    detail: "Form-error rate is +1.2pp on variant. Likely noise but verify with the next 7-day window before fully committing.",
    priority: "P2",
  },
];

export default function ExperimentDetailPage() {
  const params = useParams<{ id: string }>();
  const experiment = getExperiment(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [reply, setReply] = React.useState("");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  if (!experiment) {
    return (
      <EmptyState
        icon={FlaskConical}
        title="Experiment not found"
        description="This experiment may have been archived or never existed."
        action={{ label: "Back to experiments", href: "/experiments" }}
      />
    );
  }

  const control = experiment.variants[0];
  const variant = experiment.variants[1] ?? experiment.variants[0];
  const lift = control.conversion > 0
    ? Math.round(((variant.conversion - control.conversion) / control.conversion) * 100)
    : 0;
  const totalVisitors = experiment.variants.reduce((s, v) => s + v.visitors, 0);
  const isWin = variant.conversion > control.conversion;
  const isSignificant = experiment.significance >= 95;

  const handlePause = () => toast.success(`Experiment "${experiment.name}" paused`);
  const handleEdit = () => toast.message("Opening experiment editor…");
  const handlePost = () => {
    if (!reply.trim()) {
      toast.error("Comment is empty");
      return;
    }
    toast.success("Comment posted");
    setReply("");
  };

  return (
    <div>
      <PageHeader
        title={experiment.name}
        breadcrumbs={[
          { label: "Experiments", href: "/experiments" },
          { label: `#${experiment.id}` },
        ]}
        icon={<FlaskConical className="h-5 w-5" />}
        badge={
          <div className="flex items-center gap-1.5 flex-wrap">
            <StatusBadge status={experiment.status} />
            <Badge variant="outline" className="text-[10px] capitalize">
              {experiment.type.replace("-", " ")}
            </Badge>
            {isSignificant && isWin && (
              <Badge variant="outline" className="text-[10px] bg-success/15 text-success border-success/20">
                <Trophy className="h-2.5 w-2.5 mr-1" /> Winner
              </Badge>
            )}
          </div>
        }
        actions={
          <>
            <Button variant="outline" size="sm" className="rounded-full" onClick={handlePause}>
              <Pause className="mr-2 h-3.5 w-3.5" /> Pause
            </Button>
            <Button variant="outline" size="sm" className="rounded-full" onClick={handleEdit}>
              <Pencil className="mr-2 h-3.5 w-3.5" /> Edit
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => openShare(`/experiments/${experiment.id}`, experiment.name)}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
          </>
        }
      />

      {/* Top: hypothesis + primary metric + significance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        {/* Hypothesis */}
        <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-1">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
              <Lightbulb className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-semibold text-ink">Hypothesis</h3>
          </div>
          <p className="text-sm text-ink leading-relaxed">{experiment.hypothesis}</p>
          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="text-[10px]">
              {experiment.project}
            </Badge>
            <Badge variant="secondary" className="text-[10px] capitalize">
              {experiment.type.replace("-", " ")}
            </Badge>
          </div>
        </Card>

        {/* Primary metric */}
        <StatCard
          label="Primary metric"
          value={experiment.primaryMetric}
          icon={<Target className="h-4 w-4" />}
          accent="info"
          className="lg:col-span-1"
        >
          <div className="mt-2 flex items-center gap-2 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <TrendingUp className="h-3 w-3 text-success" />
              {lift > 0 ? `+${lift}% lift` : `${lift}% lift`}
            </span>
            <span>·</span>
            <span>{totalVisitors.toLocaleString()} visitors</span>
          </div>
        </StatCard>

        {/* Significance */}
        <StatCard
          label="Significance"
          value={`${experiment.significance}%`}
          icon={<Activity className="h-4 w-4" />}
          accent={experiment.significance >= 95 ? "success" : "warning"}
          className="lg:col-span-1"
        >
          <div className="mt-2 flex items-center gap-1">
            <div className="flex-1 h-1.5 rounded-full bg-surface-2 overflow-hidden">
              <div
                className={cn(
                  "h-full rounded-full transition-all",
                  experiment.significance >= 95 ? "bg-success" : "bg-warning"
                )}
                style={{ width: `${experiment.significance}%` }}
              />
            </div>
            <span className="text-[10px] text-muted-foreground">
              {experiment.significance >= 95 ? "Passed 95%" : "Below 95%"}
            </span>
          </div>
        </StatCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* LEFT: variant comparison + timeline + discussion */}
        <div className="lg:col-span-2 space-y-4">
          {/* Variant comparison table */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Trophy className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Variant comparison</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {experiment.variants.length} variants
              </Badge>
            </div>

            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-soft text-left">
                    <th className="font-medium text-muted-foreground px-3 py-2">Variant</th>
                    <th className="font-medium text-muted-foreground px-3 py-2">Visitors</th>
                    <th className="font-medium text-muted-foreground px-3 py-2">Conversion</th>
                    <th className="font-medium text-muted-foreground px-3 py-2">Lift</th>
                    <th className="font-medium text-muted-foreground px-3 py-2">Confidence</th>
                    <th className="font-medium text-muted-foreground px-3 py-2 text-right">Result</th>
                  </tr>
                </thead>
                <tbody>
                  {experiment.variants.map((v, idx) => {
                    const isControl = idx === 0;
                    const vLift = isControl ? 0 : control.conversion > 0
                      ? Math.round(((v.conversion - control.conversion) / control.conversion) * 100)
                      : 0;
                    const isWinner = !isControl && v.conversion > control.conversion && experiment.significance >= 95;
                    return (
                      <tr key={idx} className="border-b border-soft last:border-0">
                        <td className="px-3 py-2.5">
                          <div className="flex items-center gap-2">
                            <span
                              className={cn(
                                "h-2 w-2 rounded-full",
                                isControl ? "bg-muted-foreground" : "bg-success"
                              )}
                            />
                            <span className="text-ink font-medium">{v.name}</span>
                            {isControl && (
                              <Badge variant="outline" className="text-[9px]">Control</Badge>
                            )}
                          </div>
                        </td>
                        <td className="px-3 py-2.5 text-muted-foreground">{v.visitors.toLocaleString()}</td>
                        <td className="px-3 py-2.5 text-ink font-medium">{v.conversion}%</td>
                        <td className="px-3 py-2.5">
                          {isControl ? (
                            <span className="text-muted-foreground">—</span>
                          ) : (
                            <span
                              className={cn(
                                "inline-flex items-center gap-0.5 font-medium",
                                vLift > 0 ? "text-success" : vLift < 0 ? "text-friction" : "text-muted-foreground"
                              )}
                            >
                              {vLift > 0 ? <TrendingUp className="h-3 w-3" /> : vLift < 0 ? <TrendingDown className="h-3 w-3" /> : null}
                              {vLift > 0 ? "+" : ""}{vLift}%
                            </span>
                          )}
                        </td>
                        <td className="px-3 py-2.5">
                          {isControl ? (
                            <span className="text-muted-foreground">—</span>
                          ) : (
                            <div className="flex items-center gap-2">
                              <div className="w-12 h-1.5 rounded-full bg-surface-2 overflow-hidden">
                                <div
                                  className={cn(
                                    "h-full rounded-full",
                                    v.confidence >= 95 ? "bg-success" : "bg-warning"
                                  )}
                                  style={{ width: `${v.confidence}%` }}
                                />
                              </div>
                              <span className="text-ink">{v.confidence}%</span>
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-2.5 text-right">
                          {isWinner ? (
                            <Badge variant="outline" className="text-[10px] bg-success/15 text-success border-success/20">
                              <Trophy className="h-2.5 w-2.5 mr-1" /> Winner
                            </Badge>
                          ) : isControl ? (
                            <Badge variant="outline" className="text-[10px] text-muted-foreground">Baseline</Badge>
                          ) : (
                            <Badge variant="outline" className="text-[10px]">Trailing</Badge>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <div className="md:hidden divide-y divide-border">
              {experiment.variants.map((v, idx) => {
                const isControl = idx === 0;
                const vLift = isControl ? 0 : Math.round(((v.conversion - control.conversion) / control.conversion) * 100);
                return (
                  <div key={idx} className="py-3 first:pt-0 last:pb-0 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            "h-2 w-2 rounded-full",
                            isControl ? "bg-muted-foreground" : "bg-success"
                          )}
                        />
                        <span className="text-sm font-medium text-ink">{v.name}</span>
                      </div>
                      {isControl ? (
                        <Badge variant="outline" className="text-[10px] text-muted-foreground">Baseline</Badge>
                      ) : vLift > 0 ? (
                        <Badge variant="outline" className="text-[10px] bg-success/15 text-success border-success/20">
                          Winner
                        </Badge>
                      ) : null}
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-[10px] text-muted-foreground">
                      <div>
                        <div className="uppercase tracking-wide">Visitors</div>
                        <div className="text-ink text-xs">{v.visitors.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="uppercase tracking-wide">Conv.</div>
                        <div className="text-ink text-xs">{v.conversion}%</div>
                      </div>
                      <div>
                        <div className="uppercase tracking-wide">Lift</div>
                        <div className={cn("text-xs font-medium", vLift > 0 ? "text-success" : vLift < 0 ? "text-friction" : "text-muted-foreground")}>
                          {isControl ? "—" : `${vLift > 0 ? "+" : ""}${vLift}%`}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Results timeline */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Activity className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Results timeline</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">7 days</Badge>
            </div>
            <div className="h-48">
              <LineChart data={TIMELINE} height={192} showXAxis />
            </div>
            <div className="mt-3 flex items-center gap-4 text-[10px]">
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-muted-foreground" />
                <span className="text-muted-foreground">Control</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-success" />
                <span className="text-muted-foreground">Variant</span>
              </div>
            </div>
          </Card>

          {/* Discussion */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <MessageSquare className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Discussion</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {MOCK_COMMENTS.length} comments
              </Badge>
            </div>
            <div className="space-y-4">
              {MOCK_COMMENTS.map((c, idx) => (
                <div key={idx} className="flex gap-3">
                  <Avatar className="h-8 w-8 ring-1 ring-soft flex-shrink-0">
                    <AvatarImage src={c.avatar} alt={c.author} />
                    <AvatarFallback>{c.author.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-medium text-ink">{c.author}</span>
                      <span className="text-[10px] text-muted-foreground">{c.time}</span>
                    </div>
                    <div className="text-xs text-ink mt-1 leading-relaxed">{c.body}</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-xl border border-soft bg-surface-2/40 p-3">
              <Textarea
                value={reply}
                onChange={(e) => setReply(e.target.value)}
                placeholder="Add a comment about this experiment…"
                className="min-h-[64px] text-xs resize-none border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 p-0"
              />
              <div className="flex items-center justify-end mt-2">
                <Button size="sm" className="h-7 rounded-full text-xs" onClick={handlePost}>
                  <Send className="mr-1.5 h-3 w-3" /> Post
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* RIGHT: setup + recommendations */}
        <div className="space-y-4">
          {/* Experiment setup */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <PieChart className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Experiment setup</h3>
            </div>
            <dl className="space-y-2.5 text-xs">
              <SetupRow icon={Calendar} label="Start date" value={experiment.startDate} />
              <SetupRow icon={Calendar} label="End date" value={experiment.endDate} />
              <SetupRow icon={Users} label="Total visitors" value={totalVisitors.toLocaleString()} />
              <SetupRow icon={Percent} label="Traffic split" value="50 / 50" />
              <SetupRow icon={Target} label="Audience" value="All checkout sessions" />
              <SetupRow icon={Activity} label="Device" value="Desktop + mobile" />
            </dl>
            <div className="mt-3 pt-3 border-t border-soft">
              <div className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wide">Variant allocation</div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 rounded-full bg-surface-2 overflow-hidden flex">
                  <div className="h-full bg-muted-foreground" style={{ width: "50%" }} />
                  <div className="h-full bg-success" style={{ width: "50%" }} />
                </div>
              </div>
              <div className="flex items-center justify-between mt-1.5 text-[10px]">
                <span className="flex items-center gap-1 text-muted-foreground">
                  <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground" />
                  {control.name} · 50%
                </span>
                <span className="flex items-center gap-1 text-muted-foreground">
                  <span className="h-1.5 w-1.5 rounded-full bg-success" />
                  {variant.name} · 50%
                </span>
              </div>
            </div>
          </Card>

          {/* Mini trend */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-4 w-4 text-success" />
              <h3 className="text-sm font-semibold text-ink">Variant trend (7d)</h3>
            </div>
            <div className="text-2xl font-semibold text-ink">
              {variant.conversion}<span className="text-sm text-muted-foreground">%</span>
            </div>
            <div className="text-[10px] text-success font-medium flex items-center gap-1">
              <TrendingUp className="h-3 w-3" /> +{lift}pp vs control
            </div>
            <div className="mt-2">
              <MiniTrend
                data={TIMELINE.map((t) => t.values[1].value)}
                width={240}
                height={40}
                color="var(--success)"
              />
            </div>
          </Card>

          {/* Recommendations */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold text-ink">Recommendations</h3>
            </div>
            <div className="space-y-2">
              {RECOMMENDATIONS.map((r, idx) => (
                <div
                  key={idx}
                  className="rounded-xl border border-soft p-2.5"
                >
                  <div className="flex items-start gap-2">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[9px] font-medium",
                        r.priority === "P0"
                          ? "bg-friction/15 text-friction border-friction/20"
                          : r.priority === "P1"
                          ? "bg-warning/15 text-warning border-warning/20"
                          : "bg-info/15 text-info border-info/20"
                      )}
                    >
                      {r.priority}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium text-ink line-clamp-1">{r.title}</div>
                      <div className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2">{r.detail}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Recommendation drafted from experiment results")}
            >
              <ChevronRight className="mr-1.5 h-3 w-3" /> Draft recommendation
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}

function SetupRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="flex items-center gap-1.5 text-muted-foreground">
        <Icon className="h-3 w-3" />
        {label}
      </dt>
      <dd className="text-ink font-medium">{value}</dd>
    </div>
  );
}
