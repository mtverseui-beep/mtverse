"use client";

import * as React from "react";
import Link from "next/link";
import {
  History,
  Search,
  ChevronDown,
  FolderKanban,
  FileText,
  Users,
  CreditCard,
  Plug,
  LogIn,
  Database,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RECENT_ACTIVITY } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const CATEGORY_OPTIONS: FilterOption[] = [
  { label: "All categories", value: "all" },
  { label: "Project", value: "project" },
  { label: "Report", value: "report" },
  { label: "Team", value: "team" },
  { label: "Billing", value: "billing" },
  { label: "Integration", value: "integration" },
  { label: "Auth", value: "auth" },
  { label: "Data", value: "data" },
];

const RANGE_OPTIONS: FilterOption[] = [
  { label: "Last 7 days", value: "7d" },
  { label: "Last 30 days", value: "30d" },
  { label: "Last 90 days", value: "90d" },
  { label: "All time", value: "all" },
];

// Mock extended activity feed with categories & grouping
interface TimelineEvent {
  id: string;
  actor: string;
  avatar: string;
  action: string;
  target: string;
  category:
    | "project"
    | "report"
    | "team"
    | "billing"
    | "integration"
    | "auth"
    | "data";
  timestamp: string;
  group: "Today" | "Yesterday" | "This week" | "Earlier";
}

const TIMELINE: TimelineEvent[] = [
  { id: "t-1", actor: "Mira Halberg", avatar: "https://i.pravatar.cc/80?img=12", action: "generated the Q2 UX Audit report", target: "Atlas Onboarding", category: "report", timestamp: "12 min ago", group: "Today" },
  { id: "t-2", actor: "Aria Mendez", avatar: "https://i.pravatar.cc/80?img=48", action: "marked insight as resolved", target: "Filter icon unclear on mobile search", category: "project", timestamp: "1 hour ago", group: "Today" },
  { id: "t-3", actor: "Theo Park", avatar: "https://i.pravatar.cc/80?img=13", action: "uploaded 4 new screens", target: "Northwind Checkout", category: "project", timestamp: "3 hours ago", group: "Today" },
  { id: "t-4", actor: "Lena Ortiz", avatar: "https://i.pravatar.cc/80?img=45", action: "signed in", target: "—", category: "auth", timestamp: "9:42 AM", group: "Today" },
  { id: "t-5", actor: "Idris Khoury", avatar: "https://i.pravatar.cc/80?img=33", action: "kicked off A/B test", target: "Address autocomplete vs manual", category: "project", timestamp: "Yesterday at 4:15 PM", group: "Yesterday" },
  { id: "t-6", actor: "Sana Iqbal", avatar: "https://i.pravatar.cc/80?img=20", action: "closed survey", target: "Checkout friction survey", category: "project", timestamp: "Yesterday at 11:08 AM", group: "Yesterday" },
  { id: "t-7", actor: "Mira Halberg", avatar: "https://i.pravatar.cc/80?img=12", action: "upgraded plan", target: "Team → Enterprise", category: "billing", timestamp: "Yesterday at 9:02 AM", group: "Yesterday" },
  { id: "t-8", actor: "Aria Mendez", avatar: "https://i.pravatar.cc/80?img=48", action: "connected integration", target: "Notion", category: "integration", timestamp: "Mon at 2:30 PM", group: "This week" },
  { id: "t-9", actor: "Theo Park", avatar: "https://i.pravatar.cc/80?img=13", action: "exported data", target: "Atlas Onboarding — sessions.csv", category: "data", timestamp: "Sun at 5:48 PM", group: "This week" },
  { id: "t-10", actor: "Idris Khoury", avatar: "https://i.pravatar.cc/80?img=33", action: "invited team member", target: "sana@ooster.app", category: "team", timestamp: "Fri at 1:20 PM", group: "This week" },
  { id: "t-11", actor: "Lena Ortiz", avatar: "https://i.pravatar.cc/80?img=45", action: "created project", target: "Helix Prototype", category: "project", timestamp: "Jun 22, 2026", group: "Earlier" },
  { id: "t-12", actor: "Mira Halberg", avatar: "https://i.pravatar.cc/80?img=12", action: "generated report", target: "Atlas Q1 UX Audit", category: "report", timestamp: "Jun 18, 2026", group: "Earlier" },
  { id: "t-13", actor: "Aria Mendez", avatar: "https://i.pravatar.cc/80?img=48", action: "revoked API key", target: "Legacy export key", category: "integration", timestamp: "Jun 14, 2026", group: "Earlier" },
  { id: "t-14", actor: "Theo Park", avatar: "https://i.pravatar.cc/80?img=13", action: "signed in", target: "—", category: "auth", timestamp: "Jun 10, 2026", group: "Earlier" },
];

const CATEGORY_META: Record<
  TimelineEvent["category"],
  { icon: React.ReactNode; cls: string }
> = {
  project: {
    icon: <FolderKanban className="h-3.5 w-3.5" />,
    cls: "bg-info/15 text-info border-info/20",
  },
  report: {
    icon: <FileText className="h-3.5 w-3.5" />,
    cls: "bg-primary/10 text-primary border-primary/20",
  },
  team: {
    icon: <Users className="h-3.5 w-3.5" />,
    cls: "bg-success/15 text-success border-success/20",
  },
  billing: {
    icon: <CreditCard className="h-3.5 w-3.5" />,
    cls: "bg-warning/15 text-warning border-warning/20",
  },
  integration: {
    icon: <Plug className="h-3.5 w-3.5" />,
    cls: "bg-muted text-muted-foreground border-border",
  },
  auth: {
    icon: <LogIn className="h-3.5 w-3.5" />,
    cls: "bg-info/15 text-info border-info/20",
  },
  data: {
    icon: <Database className="h-3.5 w-3.5" />,
    cls: "bg-friction/15 text-friction border-friction/20",
  },
};

const GROUPS: TimelineEvent["group"][] = [
  "Today",
  "Yesterday",
  "This week",
  "Earlier",
];

export default function ActivityHistoryPage() {
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("all");
  const [range, setRange] = React.useState("30d");
  const [loading, setLoading] = React.useState(true);
  const [visibleCount, setVisibleCount] = React.useState(8);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return TIMELINE.filter((e) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !e.actor.toLowerCase().includes(q) &&
          !e.action.toLowerCase().includes(q) &&
          !e.target.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (category !== "all" && e.category !== category) return false;
      return true;
    });
  }, [search, category]);

  const clearFilters = () => {
    setSearch("");
    setCategory("all");
    setRange("30d");
  };

  const visible = filtered.slice(0, visibleCount);

  const loadMore = () => {
    setVisibleCount((c) => c + 12);
    toast.success("Loaded 12 more events");
  };

  // Category breakdown
  const categoryCounts = TIMELINE.reduce<Record<string, number>>((acc, e) => {
    acc[e.category] = (acc[e.category] || 0) + 1;
    return acc;
  }, {});

  return (
    <div>
      <PageHeader
        title="Activity History"
        description="Full audit trail of actions across your workspace"
        icon={<History className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {TIMELINE.length} events
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() => toast.success("Activity exported as CSV")}
          >
            Export
          </Button>
        }
      />

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search by actor, action, or target…",
          }}
          selects={[
            {
              label: "Category",
              value: category,
              onChange: setCategory,
              options: CATEGORY_OPTIONS,
            },
            {
              label: "Range",
              value: range,
              onChange: setRange,
              options: RANGE_OPTIONS,
            },
          ]}
          onClear={clearFilters}
        />
      </div>

      {/* Category quick filters */}
      <div className="flex flex-wrap items-center gap-1.5 mb-4">
        {Object.entries(categoryCounts).map(([cat, count]) => {
          const meta = CATEGORY_META[cat as TimelineEvent["category"]];
          const active = category === cat;
          return (
            <button
              key={cat}
              onClick={() => setCategory(active ? "all" : cat)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-medium transition-all",
                active
                  ? meta.cls + " shadow-soft"
                  : "border-soft text-muted-foreground hover:text-ink hover:bg-accent/30"
              )}
            >
              {meta.icon}
              <span className="capitalize">{cat}</span>
              <span className="opacity-60">{count}</span>
            </button>
          );
        })}
      </div>

      {loading ? (
        <LoadingSkeleton variant="preview" className="h-[420px]" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={History}
          title="No activity matches your filters"
          description="Try widening your date range or clearing search to see more events."
          action={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <Card className="rounded-2xl border-soft shadow-soft p-4 sm:p-6">
          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-[15px] sm:left-[19px] top-2 bottom-2 w-px bg-soft" />

            <div className="space-y-6">
              {GROUPS.map((g) => {
                const events = visible.filter((e) => e.group === g);
                if (events.length === 0) return null;
                return (
                  <div key={g} className="relative">
                    {/* Group header */}
                    <div className="flex items-center gap-3 mb-3">
                      <div className="relative z-10 flex h-8 w-8 items-center justify-center rounded-full bg-surface-2 border border-soft">
                        <History className="h-3.5 w-3.5 text-muted-foreground" />
                      </div>
                      <div className="text-xs font-semibold text-ink uppercase tracking-wide">
                        {g}
                      </div>
                      <div className="flex-1 h-px bg-soft" />
                      <div className="text-[10px] text-muted-foreground">
                        {events.length} event{events.length === 1 ? "" : "s"}
                      </div>
                    </div>

                    {/* Events */}
                    <div className="space-y-2 ml-11">
                      {events.map((e) => {
                        const meta = CATEGORY_META[e.category];
                        return (
                          <div
                            key={e.id}
                            className="relative flex items-start gap-3 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors group"
                          >
                            <Avatar className="h-7 w-7 ring-1 ring-soft flex-shrink-0">
                              <AvatarImage src={e.avatar} alt={e.actor} />
                              <AvatarFallback>{e.actor.slice(0, 2)}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="text-xs text-ink leading-snug">
                                <span className="font-medium">{e.actor}</span>{" "}
                                <span className="text-muted-foreground">
                                  {e.action}
                                </span>{" "}
                                {e.target !== "—" && (
                                  <span className="font-medium">{e.target}</span>
                                )}
                              </div>
                              <div className="flex items-center gap-2 mt-1 flex-wrap">
                                <Badge
                                  variant="outline"
                                  className={cn(
                                    "text-[9px] font-medium capitalize border inline-flex items-center gap-1",
                                    meta.cls
                                  )}
                                >
                                  {meta.icon}
                                  {e.category}
                                </Badge>
                                <span className="text-[10px] text-muted-foreground">
                                  {e.timestamp}
                                </span>
                              </div>
                            </div>
                            <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Load more */}
          {visibleCount < filtered.length && (
            <div className="mt-6 flex justify-center">
              <Button
                variant="outline"
                size="sm"
                className="rounded-full text-xs"
                onClick={loadMore}
              >
                <ChevronDown className="mr-2 h-3.5 w-3.5" /> Load more
                <span className="ml-1 text-[10px] text-muted-foreground">
                  ({filtered.length - visibleCount} remaining)
                </span>
              </Button>
            </div>
          )}
        </Card>
      )}

      {/* Footer hint */}
      <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-2 text-info">
            <History className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs font-medium text-ink">
              Need compliance-grade logs?
            </div>
            <div className="text-[10px] text-muted-foreground">
              Audit logs include IP addresses, immutable records, and CSV export for SOC2.
            </div>
          </div>
        </div>
        <Button asChild variant="outline" size="sm" className="rounded-full text-xs">
          <Link href="/audit-logs">
            View audit logs <ChevronRight className="h-3 w-3" />
          </Link>
        </Button>
      </Card>
    </div>
  );
}
