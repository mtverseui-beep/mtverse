"use client";

import * as React from "react";
import Link from "next/link";
import {
  CircleAlert,
  Plus,
  Download,
  ChevronRight,
  AlertTriangle,
  Loader2,
  CheckCircle2,
  MessageSquare,
  ThumbsUp,
  Filter,
  X,
  Trash2,
  UserPlus,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { SeverityBadge, StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ISSUES, TEAM_MEMBERS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const SEVERITY_OPTIONS: FilterOption[] = [
  { label: "All severities", value: "all" },
  { label: "Critical", value: "critical" },
  { label: "High", value: "high" },
  { label: "Medium", value: "medium" },
  { label: "Low", value: "low" },
];

const TYPE_OPTIONS: FilterOption[] = [
  { label: "All types", value: "all" },
  { label: "Bug", value: "bug" },
  { label: "UX", value: "ux" },
  { label: "Accessibility", value: "accessibility" },
  { label: "Performance", value: "performance" },
  { label: "Content", value: "content" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Open", value: "open" },
  { label: "In progress", value: "in-progress" },
  { label: "Resolved", value: "resolved" },
  { label: "Won't fix", value: "wontfix" },
];

const ASSIGNEE_OPTIONS: FilterOption[] = [
  { label: "Anyone", value: "all" },
  { label: "Unassigned", value: "unassigned" },
  ...TEAM_MEMBERS.map((m) => ({ label: m.name, value: m.name })),
];

const TYPE_BADGE_STYLES: Record<string, string> = {
  bug: "bg-friction/15 text-friction border-friction/20",
  ux: "bg-info/15 text-info border-info/20",
  accessibility: "bg-warning/15 text-warning border-warning/20",
  performance: "bg-success/15 text-success border-success/20",
  content: "bg-muted text-muted-foreground border-border",
};

export default function IssuesPage() {
  const [search, setSearch] = React.useState("");
  const [severity, setSeverity] = React.useState("all");
  const [type, setType] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [assignee, setAssignee] = React.useState("all");
  const [loading, setLoading] = React.useState(true);
  const [selected, setSelected] = React.useState<Set<string>>(new Set());

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return ISSUES.filter((i) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !i.title.toLowerCase().includes(q) &&
          !i.project.toLowerCase().includes(q) &&
          !i.screen.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (severity !== "all" && i.severity !== severity) return false;
      if (type !== "all" && i.type !== type) return false;
      if (status !== "all" && i.status !== status) return false;
      if (assignee === "unassigned" && i.assignee) return false;
      if (assignee !== "all" && assignee !== "unassigned" && i.assignee?.name !== assignee) return false;
      return true;
    }).sort((a, b) => {
      const sevOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      return sevOrder[a.severity] - sevOrder[b.severity];
    });
  }, [search, severity, type, status, assignee]);

  const clearFilters = () => {
    setSearch("");
    setSeverity("all");
    setType("all");
    setStatus("all");
    setAssignee("all");
  };

  // KPIs
  const open = ISSUES.filter((i) => i.status === "open").length;
  const critical = ISSUES.filter((i) => i.severity === "critical").length;
  const inProgress = ISSUES.filter((i) => i.status === "in-progress").length;
  const resolvedThisWeek = ISSUES.filter((i) => i.status === "resolved").length;

  const allOnPageSelected = filtered.length > 0 && filtered.every((i) => selected.has(i.id));
  const toggleAll = () => {
    if (allOnPageSelected) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filtered.map((i) => i.id)));
    }
  };
  const toggleOne = (id: string) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
  };

  return (
    <div>
      <PageHeader
        title="Issues"
        description="Tracked UX, accessibility, and performance issues across all projects"
        icon={<CircleAlert className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {ISSUES.length} issues
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Issues backlog exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Opening new issue composer…")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> New issue
            </Button>
          </>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Open issues"
          value={open}
          icon={<CircleAlert className="h-4 w-4" />}
          accent="friction"
          sublabel="awaiting triage or work"
        />
        <StatCard
          label="Critical"
          value={critical}
          icon={<AlertTriangle className="h-4 w-4" />}
          accent="friction"
          sublabel="must resolve this sprint"
        />
        <StatCard
          label="In progress"
          value={inProgress}
          icon={<Loader2 className="h-4 w-4" />}
          accent="info"
          sublabel="actively being fixed"
        />
        <StatCard
          label="Resolved this week"
          value={resolvedThisWeek}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent="success"
          trend={{ value: 12, direction: "up", good: true }}
          sublabel="vs last week"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search issues, projects, screens…",
          }}
          selects={[
            { label: "Severity", value: severity, onChange: setSeverity, options: SEVERITY_OPTIONS },
            { label: "Type", value: type, onChange: setType, options: TYPE_OPTIONS },
            { label: "Status", value: status, onChange: setStatus, options: STATUS_OPTIONS },
            { label: "Assignee", value: assignee, onChange: setAssignee, options: ASSIGNEE_OPTIONS },
          ]}
          onClear={clearFilters}
        />
      </div>

      {/* Bulk action toolbar */}
      {selected.size > 0 && (
        <div className="mb-3 flex flex-wrap items-center gap-2 rounded-xl border border-soft bg-surface-2 px-3 py-2">
          <Badge variant="secondary" className="text-[10px]">
            {selected.size} selected
          </Badge>
          <Button
            variant="outline"
            size="sm"
            className="h-7 rounded-full text-xs"
            onClick={() => toast.success(`Bulk-assigned ${selected.size} issues`)}
          >
            <UserPlus className="mr-1.5 h-3 w-3" /> Assign
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-7 rounded-full text-xs"
            onClick={() => toast.success(`Marked ${selected.size} as resolved`)}
          >
            <CheckCircle2 className="mr-1.5 h-3 w-3" /> Resolve
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-7 rounded-full text-xs"
            onClick={() => toast.success(`Exported ${selected.size} issues`)}
          >
            <Download className="mr-1.5 h-3 w-3" /> Export
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 rounded-full text-xs text-friction hover:text-friction"
            onClick={() => {
              toast.success(`Closed ${selected.size} issues as won't fix`);
              setSelected(new Set());
            }}
          >
            <Trash2 className="mr-1.5 h-3 w-3" /> Won't fix
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 rounded-full text-xs ml-auto"
            onClick={() => setSelected(new Set())}
          >
            <X className="mr-1 h-3 w-3" /> Clear
          </Button>
        </div>
      )}

      {loading ? (
        <LoadingSkeleton variant="table" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={CircleAlert}
          title="No issues match your filters"
          description="Try adjusting search or filters, or log a new issue from any heatmap, replay, or insight."
          action={{ label: "New issue", onClick: () => toast.message("Opening new issue composer…") }}
          secondaryAction={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <Card className="rounded-2xl border-soft shadow-soft overflow-hidden">
          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-soft">
                  <th className="w-8 px-3 py-2.5">
                    <Checkbox
                      checked={allOnPageSelected}
                      onCheckedChange={toggleAll}
                      aria-label="Select all"
                    />
                  </th>
                  <th className="text-left font-medium text-muted-foreground px-3 py-2.5">Title</th>
                  <th className="text-left font-medium text-muted-foreground px-3 py-2.5">Severity</th>
                  <th className="text-left font-medium text-muted-foreground px-3 py-2.5">Type</th>
                  <th className="text-left font-medium text-muted-foreground px-3 py-2.5">Status</th>
                  <th className="text-left font-medium text-muted-foreground px-3 py-2.5">Assignee</th>
                  <th className="text-left font-medium text-muted-foreground px-3 py-2.5">Created</th>
                  <th className="text-left font-medium text-muted-foreground px-3 py-2.5">Comments</th>
                  <th className="text-left font-medium text-muted-foreground px-3 py-2.5">Reactions</th>
                  <th className="w-8 px-3 py-2.5" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((i) => {
                  const isSelected = selected.has(i.id);
                  return (
                    <tr
                      key={i.id}
                      className={cn(
                        "border-b border-soft last:border-0 transition-colors hover:bg-accent/30",
                        isSelected && "bg-accent/20"
                      )}
                    >
                      <td className="px-3 py-2.5" onClick={(e) => e.stopPropagation()}>
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleOne(i.id)}
                          aria-label={`Select ${i.title}`}
                        />
                      </td>
                      <td className="px-3 py-2.5">
                        <Link href={`/issues/${i.id}`} className="block max-w-[280px]">
                          <div className="text-sm font-medium text-ink hover:text-primary line-clamp-1">
                            {i.title}
                          </div>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <Badge variant="outline" className="text-[10px] font-normal">
                              {i.project}
                            </Badge>
                            <span className="text-[10px] text-muted-foreground">·</span>
                            <span className="text-[10px] text-muted-foreground">{i.screen}</span>
                          </div>
                        </Link>
                      </td>
                      <td className="px-3 py-2.5">
                        <SeverityBadge severity={i.severity} />
                      </td>
                      <td className="px-3 py-2.5">
                        <Badge
                          variant="outline"
                          className={cn("text-[10px] font-medium capitalize", TYPE_BADGE_STYLES[i.type])}
                        >
                          {i.type}
                        </Badge>
                      </td>
                      <td className="px-3 py-2.5">
                        <StatusBadge status={i.status} />
                      </td>
                      <td className="px-3 py-2.5">
                        {i.assignee ? (
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6 ring-1 ring-soft">
                              <AvatarImage src={i.assignee.avatar} alt={i.assignee.name} />
                              <AvatarFallback>{i.assignee.name.slice(0, 2)}</AvatarFallback>
                            </Avatar>
                            <span className="text-[11px] text-ink hidden lg:inline">
                              {i.assignee.name}
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-muted-foreground italic">Unassigned</span>
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-muted-foreground whitespace-nowrap">{i.createdAt}</td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <MessageSquare className="h-3 w-3" />
                          <span>{i.comments}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <ThumbsUp className="h-3 w-3" />
                          <span>{i.reactions}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2.5">
                        <Link href={`/issues/${i.id}`}>
                          <ChevronRight className="h-4 w-4 text-muted-foreground hover:text-ink" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden divide-y divide-border">
            {filtered.map((i) => {
              const isSelected = selected.has(i.id);
              return (
                <Link
                  key={i.id}
                  href={`/issues/${i.id}`}
                  className={cn("block p-3 space-y-2", isSelected && "bg-accent/20")}
                >
                  <div className="flex items-start gap-2">
                    <span
                      onClick={(e) => {
                        e.preventDefault();
                        toggleOne(i.id);
                      }}
                    >
                      <Checkbox checked={isSelected} onCheckedChange={() => toggleOne(i.id)} aria-label="Select" />
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-ink line-clamp-2">{i.title}</div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        {i.project} · {i.screen}
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap pl-6">
                    <SeverityBadge severity={i.severity} />
                    <StatusBadge status={i.status} />
                    <Badge
                      variant="outline"
                      className={cn("text-[10px] capitalize", TYPE_BADGE_STYLES[i.type])}
                    >
                      {i.type}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between pl-6 text-[10px] text-muted-foreground">
                    <span>{i.assignee?.name ?? "Unassigned"}</span>
                    <span className="flex items-center gap-2">
                      <span className="flex items-center gap-1">
                        <MessageSquare className="h-3 w-3" /> {i.comments}
                      </span>
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="h-3 w-3" /> {i.reactions}
                      </span>
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>
      )}

      {/* Footer note */}
      {!loading && filtered.length > 0 && (
        <div className="mt-3 flex items-center gap-2 text-[10px] text-muted-foreground">
          <Filter className="h-3 w-3" />
          Showing {filtered.length} of {ISSUES.length} issues · sorted by severity
        </div>
      )}
    </div>
  );
}
