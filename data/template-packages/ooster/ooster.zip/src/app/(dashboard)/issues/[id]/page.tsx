"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  CircleAlert,
  Share2,
  UserPlus,
  Pencil,
  CheckCircle2,
  ThumbsUp,
  Heart,
  PartyPopper,
  Flame,
  MessageSquare,
  Send,
  Link2,
  PlayCircle,
  Image as ImageIcon,
  FlaskConical,
  Lightbulb,
  Paperclip,
  ChevronRight,
  Calendar,
  Flag,
  Layers,
  User,
  Clock,
  Plus,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { SeverityBadge, StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { useModals } from "@/hooks/use-modals";
import { getIssue } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const TYPE_BADGE_STYLES: Record<string, string> = {
  bug: "bg-friction/15 text-friction border-friction/20",
  ux: "bg-info/15 text-info border-info/20",
  accessibility: "bg-warning/15 text-warning border-warning/20",
  performance: "bg-success/15 text-success border-success/20",
  content: "bg-muted text-muted-foreground border-border",
};

interface MockComment {
  author: string;
  avatar: string;
  time: string;
  body: string;
}

const MOCK_COMMENTS: MockComment[] = [
  {
    author: "Aria Mendez",
    avatar: "https://i.pravatar.cc/80?img=48",
    time: "2 hours ago",
    body: "Reproduced this on Safari 17 with VoiceOver enabled. The focus order jumps from the calendar header directly to the footer link, completely skipping the date cells. Logs attached.",
  },
  {
    author: "Idris Khoury",
    avatar: "https://i.pravatar.cc/80?img=33",
    time: "5 hours ago",
    body: "I've started a draft PR — adding `tabindex=0` to each cell and a roving-tabindex controller. Should have something reviewable by Thursday EOD.",
  },
  {
    author: "Mira Halberg",
    avatar: "https://i.pravatar.cc/80?img=12",
    time: "Yesterday",
    body: "Pulling this into the accessibility OKR for Q3. WCAG 2.2 SC 2.4.3 is the explicit criterion we're failing here — let's make sure the fix is verified by both automated AND manual screen reader tests.",
  },
  {
    author: "Sana Iqbal",
    avatar: "https://i.pravatar.cc/80?img=20",
    time: "2 days ago",
    body: "Adding to the regression suite — we should add an axe-core check + a Playwright keyboard-traversal test so this can't slip back in.",
  },
];

interface EvidenceItem {
  type: "heatmap" | "replay" | "screenshot";
  title: string;
  detail: string;
  href: string;
}

const EVIDENCE: EvidenceItem[] = [
  {
    type: "heatmap",
    title: "Heatmap — Date picker attention",
    detail: "Rage-click cluster detected on the previous-month arrow (412 dead clicks across 1,820 sessions).",
    href: "/heatmaps",
  },
  {
    type: "replay",
    title: "Session replay · sr-1042",
    detail: "VoiceOver user pauses 14s on the date picker, then abandons booking. Captured 2026-06-29.",
    href: "/session-replays",
  },
  {
    type: "screenshot",
    title: "Screenshot — focus state captured",
    detail: "Browser DevTools screenshot showing focus ring trapped on the calendar container element.",
    href: "#",
  },
];

const REACTIONS = [
  { icon: ThumbsUp, count: 14, active: false },
  { icon: Heart, count: 6, active: false },
  { icon: PartyPopper, count: 3, active: false },
  { icon: Flame, count: 9, active: true },
];

const LINKED_INSIGHTS = [
  { id: "i-003", title: "Calendar widget traps keyboard focus", impact: 84, project: "Voyage Booking" },
  { id: "i-007", title: "Form field order violates reading order", impact: 71, project: "Voyage Booking" },
];

const LINKED_EXPERIMENTS = [
  { id: "ex-001", name: "Date picker: native input vs custom widget", status: "running", lift: "+18%" },
];

export default function IssueDetailPage() {
  const params = useParams<{ id: string }>();
  const issue = getIssue(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);
  const [reply, setReply] = React.useState("");
  const [reactions, setReactions] = React.useState(REACTIONS);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <LoadingSkeleton variant="page" />;

  if (!issue) {
    return (
      <EmptyState
        icon={CircleAlert}
        title="Issue not found"
        description="This issue may have been moved, archived, or never existed."
        action={{ label: "Back to issues", href: "/issues" }}
      />
    );
  }

  const handleResolve = () => toast.success(`Issue #${issue.id} marked as resolved`);
  const handleAssign = () => toast.message("Opening assignee picker…");
  const handleEdit = () => toast.message("Entering edit mode…");
  const handlePostReply = () => {
    if (!reply.trim()) {
      toast.error("Reply is empty");
      return;
    }
    toast.success("Comment posted");
    setReply("");
  };
  const toggleReaction = (idx: number) => {
    setReactions((prev) =>
      prev.map((r, i) =>
        i === idx ? { ...r, active: !r.active, count: r.count + (r.active ? -1 : 1) } : r
      )
    );
  };

  return (
    <div>
      <PageHeader
        title={issue.title}
        breadcrumbs={[
          { label: "Issues", href: "/issues" },
          { label: `#${issue.id}` },
        ]}
        icon={<CircleAlert className="h-5 w-5" />}
        badge={
          <div className="flex items-center gap-1.5 flex-wrap">
            <SeverityBadge severity={issue.severity} />
            <StatusBadge status={issue.status} />
            <Badge variant="outline" className={cn("text-[10px] capitalize", TYPE_BADGE_STYLES[issue.type])}>
              {issue.type}
            </Badge>
          </div>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleAssign}
            >
              <UserPlus className="mr-2 h-3.5 w-3.5" /> Assign
            </Button>
            <Button variant="outline" size="sm" className="rounded-full" onClick={handleEdit}>
              <Pencil className="mr-2 h-3.5 w-3.5" /> Edit
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => openShare(`/issues/${issue.id}`, issue.title)}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button size="sm" className="rounded-full" onClick={handleResolve}>
              <CheckCircle2 className="mr-2 h-3.5 w-3.5" /> Resolve
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* LEFT */}
        <div className="lg:col-span-2 space-y-4">
          {/* Description */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <CircleAlert className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Description</h3>
            </div>
            <div className="space-y-3 text-sm text-ink leading-relaxed">
              <p>
                When a screen reader user (VoiceOver on macOS 14 / iOS 17, NVDA on Windows 11) navigates into
                the calendar date picker on the booking flow, focus becomes trapped inside the calendar container.
                The Tab key cycles between the previous-month and next-month arrow buttons but never reaches the
                individual date cells, the "Today" link, or the close button. Shift+Tab from the previous-month
                arrow also fails to escape back to the surrounding form.
              </p>
              <p>
                Reproduction steps: (1) Navigate to /book and tab into the date field. (2) Activate the picker
                with Enter. (3) Press Tab repeatedly. Expected: focus moves through date cells in DOM order and
                escapes via the close button. Actual: focus is locked between the two arrow buttons
                indefinitely — the only escape is pressing Esc, which dismisses the picker entirely without
                committing a date. This blocks WCAG 2.2 SC 2.4.3 (Focus Order) and SC 2.1.2 (No Keyboard Trap).
              </p>
              <p>
                Impact: 8.2% of mobile booking sessions include a screen reader user, and within those sessions
                the date picker is the single largest drop-off point — 41% of AT users abandon booking after
                encountering the trap, compared to 11% of non-AT users. Estimated revenue impact is ~$48k/month
                based on average booking value. The fix is well-bounded: implement a roving-tabindex controller
                on the date grid and ensure Esc / click-outside returns focus to the trigger input.
              </p>
            </div>
          </Card>

          {/* Evidence */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Paperclip className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Evidence</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {EVIDENCE.length} sources
              </Badge>
            </div>
            <div className="space-y-2">
              {EVIDENCE.map((e, idx) => {
                const Icon = e.type === "heatmap" ? Flame : e.type === "replay" ? PlayCircle : ImageIcon;
                return (
                  <Link
                    key={idx}
                    href={e.href}
                    className="flex items-start gap-3 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors group"
                  >
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-2 text-info flex-shrink-0">
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-ink group-hover:text-primary transition-colors line-clamp-1">
                        {e.title}
                      </div>
                      <div className="text-[11px] text-muted-foreground mt-0.5 line-clamp-2">{e.detail}</div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
                  </Link>
                );
              })}
            </div>
          </Card>

          {/* Discussion */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <MessageSquare className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Discussion</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {MOCK_COMMENTS.length} comments
              </Badge>
            </div>
            <div className="space-y-4">
              {MOCK_COMMENTS.map((c, idx) => (
                <div key={idx} className="flex gap-3">
                  <Avatar className="h-8 w-8 ring-1 ring-soft flex-shrink-0">
                    <AvatarImage src={c.avatar} alt={c.author} />
                    <AvatarFallback>{c.author.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-medium text-ink">{c.author}</span>
                      <span className="text-[10px] text-muted-foreground">{c.time}</span>
                    </div>
                    <div className="text-xs text-ink mt-1 leading-relaxed">{c.body}</div>
                    <div className="flex items-center gap-3 mt-2">
                      <button
                        className="text-[10px] text-muted-foreground hover:text-ink transition-colors"
                        onClick={() => toast.message("Replying to comment…")}
                      >
                        Reply
                      </button>
                      <button
                        className="text-[10px] text-muted-foreground hover:text-ink transition-colors"
                        onClick={() => toast.success("Reaction added")}
                      >
                        React
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {/* Reply input */}
            <div className="mt-4 rounded-xl border border-soft bg-surface-2/40 p-3">
              <Textarea
                value={reply}
                onChange={(e) => setReply(e.target.value)}
                placeholder="Add a comment…"
                className="min-h-[64px] text-xs resize-none border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 p-0"
              />
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => toast.message("Attach file")}>
                    <Paperclip className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => toast.message("Link resource")}>
                    <Link2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <Button size="sm" className="h-7 rounded-full text-xs" onClick={handlePostReply}>
                  <Send className="mr-1.5 h-3 w-3" /> Post
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* RIGHT */}
        <div className="space-y-4">
          {/* Meta */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <h3 className="text-sm font-semibold text-ink mb-3">Details</h3>
            <dl className="space-y-2.5 text-xs">
              <MetaRow icon={User} label="Assignee">
                {issue.assignee ? (
                  <div className="flex items-center gap-2">
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={issue.assignee.avatar} alt={issue.assignee.name} />
                      <AvatarFallback>{issue.assignee.name.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <span className="text-ink">{issue.assignee.name}</span>
                  </div>
                ) : (
                  <span className="text-muted-foreground italic">Unassigned</span>
                )}
              </MetaRow>
              <MetaRow icon={User} label="Reporter">
                <div className="flex items-center gap-2">
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={issue.reporter.avatar} alt={issue.reporter.name} />
                    <AvatarFallback>{issue.reporter.name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <span className="text-ink">{issue.reporter.name}</span>
                </div>
              </MetaRow>
              <MetaRow icon={Layers} label="Project">
                <span className="text-ink">{issue.project}</span>
              </MetaRow>
              <MetaRow icon={Layers} label="Screen">
                <span className="text-ink">{issue.screen}</span>
              </MetaRow>
              <MetaRow icon={Flag} label="Priority">
                <Badge variant="outline" className="text-[10px] capitalize">
                  {issue.severity === "critical" ? "P0 — urgent" : issue.severity === "high" ? "P1 — high" : issue.severity === "medium" ? "P2 — medium" : "P3 — low"}
                </Badge>
              </MetaRow>
              <MetaRow icon={Calendar} label="Created">
                <span className="text-ink">{issue.createdAt}</span>
              </MetaRow>
              <MetaRow icon={Clock} label="Updated">
                <span className="text-ink">{issue.updatedAt}</span>
              </MetaRow>
            </dl>
          </Card>

          {/* Reactions */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <ThumbsUp className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Reactions</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {reactions.map((r, idx) => {
                const Icon = r.icon;
                return (
                  <button
                    key={idx}
                    onClick={() => toggleReaction(idx)}
                    className={cn(
                      "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs transition-all",
                      r.active
                        ? "border-primary/30 bg-primary/10 text-ink"
                        : "border-soft text-muted-foreground hover:bg-accent/30 hover:text-ink"
                    )}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span className="font-medium">{r.count}</span>
                  </button>
                );
              })}
              <button
                onClick={() => toast.message("Add another reaction")}
                className="flex items-center gap-1 rounded-full border border-dashed border-soft px-2.5 py-1 text-xs text-muted-foreground hover:bg-accent/30 hover:text-ink transition-all"
              >
                <Plus className="h-3 w-3" /> Add
              </button>
            </div>
          </Card>

          {/* Linked insights */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Lightbulb className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Linked insights</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {LINKED_INSIGHTS.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {LINKED_INSIGHTS.map((i) => (
                <Link
                  key={i.id}
                  href={`/insights/${i.id}`}
                  className="block rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors group"
                >
                  <div className="text-xs font-medium text-ink group-hover:text-primary line-clamp-1">
                    {i.title}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-1 flex items-center gap-2">
                    <span>{i.project}</span>
                    <span>·</span>
                    <span>Impact {i.impact}/100</span>
                  </div>
                </Link>
              ))}
            </div>
          </Card>

          {/* Linked experiments */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <FlaskConical className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Linked experiments</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {LINKED_EXPERIMENTS.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {LINKED_EXPERIMENTS.map((e) => (
                <Link
                  key={e.id}
                  href={`/experiments/${e.id}`}
                  className="flex items-center gap-2 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors group"
                >
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-ink group-hover:text-primary line-clamp-1">
                      {e.name}
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 capitalize">
                      {e.status} · lift {e.lift}
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink" />
                </Link>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function MetaRow({
  icon: Icon,
  label,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="flex items-center gap-1.5 text-muted-foreground">
        <Icon className="h-3 w-3" />
        {label}
      </dt>
      <dd className="text-right">{children}</dd>
    </div>
  );
}
