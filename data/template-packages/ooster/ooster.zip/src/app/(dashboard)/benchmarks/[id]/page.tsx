"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Trophy,
  Share2,
  Download,
  TrendingUp,
  TrendingDown,
  Crown,
  Target,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ChevronRight,
  Activity,
  ArrowRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { ScoreRadar } from "@/components/charts/score-radar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface MetricRow {
  key: string;
  label: string;
  yourScore: number;
  competitorScore: number;
}

interface BenchmarkDetail {
  id: string;
  name: string;
  industry: string;
  logoColor: string;
  website: string;
  yourScores: {
    usability: number;
    accessibility: number;
    conversion: number;
    engagement: number;
    performance: number;
    clarity: number;
  };
  competitorScores: {
    usability: number;
    accessibility: number;
    conversion: number;
    engagement: number;
    performance: number;
    clarity: number;
  };
  strengths: string[];
  weaknesses: string[];
  recommendations: { title: string; detail: string; priority: "high" | "medium" | "low" }[];
  lastUpdated: string;
}

const YOUR_DEFAULT = {
  usability: 78,
  accessibility: 86,
  conversion: 71,
  engagement: 81,
  performance: 74,
  clarity: 80,
};

const BENCHMARK_DETAILS: Record<string, BenchmarkDetail> = {
  "b-001": {
    id: "b-001",
    name: "Northwind",
    industry: "Retail / E-commerce",
    logoColor: "var(--chart-1)",
    website: "northwind.io",
    yourScores: YOUR_DEFAULT,
    competitorScores: { usability: 70, accessibility: 68, conversion: 74, engagement: 72, performance: 76, clarity: 71 },
    strengths: [
      "Higher checkout completion (74% vs your 71%) — strong guest-checkout default",
      "Faster first-contentful-paint on mobile (1.1s vs your 1.8s)",
      "Better-optimized product detail page layout above the fold",
    ],
    weaknesses: [
      "Lower accessibility score (68 vs your 86) — multiple WCAG AA contrast failures",
      "Weaker mobile onboarding (38% completion vs your 52%)",
      "No express payment on PDP — you have Apple Pay / Google Pay",
    ],
    recommendations: [
      { title: "Adopt guest-checkout default", detail: "Northwind wins on conversion by allowing guest checkout first, account creation post-purchase. Projected +12pp on completion.", priority: "high" },
      { title: "Optimize mobile LCP", detail: "Leverage lazy-loading on below-fold images to match Northwind's 1.1s LCP. Saves ~700ms on 4G.", priority: "medium" },
      { title: "Promote express pay on PDP", detail: "You already have Apple Pay / Google Pay — surface them above the fold on PDP for high-intent buyers.", priority: "medium" },
    ],
    lastUpdated: "2026-07-01",
  },
  "b-002": {
    id: "b-002",
    name: "Acme Pay",
    industry: "Fintech / Payments",
    logoColor: "var(--chart-2)",
    website: "acmepay.com",
    yourScores: YOUR_DEFAULT,
    competitorScores: { usability: 82, accessibility: 79, conversion: 84, engagement: 80, performance: 83, clarity: 78 },
    strengths: [
      "Higher overall UX score (81 vs your 78) — clear category leader",
      "Better onboarding completion (78% vs your 52%) — progressive disclosure done right",
      "Stronger SUS score (84 vs your 79)",
    ],
    weaknesses: [
      "Lower accessibility score (79 vs your 86) — focus traps in modals",
      "Less transparent fee disclosure — you surface fees on the review screen",
      "Weaker mobile-first navigation patterns — you have bottom-sheet CTAs",
    ],
    recommendations: [
      { title: "Adopt progressive onboarding", detail: "Acme Pay splits KYC into 3 micro-steps. Replicate their pattern to lift onboarding completion by ~20pp.", priority: "high" },
      { title: "Audit modal focus traps", detail: "Your accessibility lead (86) is a competitive moat — pressure-test all modals to maintain it while Acme catches up.", priority: "medium" },
      { title: "Differentiate on fee transparency", detail: "Lead with 'no hidden fees' messaging on your homepage — Acme hides fees until review.", priority: "low" },
    ],
    lastUpdated: "2026-07-01",
  },
  "b-003": {
    id: "b-003",
    name: "Stripe",
    industry: "Fintech / Payments",
    logoColor: "var(--chart-4)",
    website: "stripe.com",
    yourScores: YOUR_DEFAULT,
    competitorScores: { usability: 90, accessibility: 88, conversion: 87, engagement: 89, performance: 92, clarity: 88 },
    strengths: [
      "Best-in-class UX score (89) — industry benchmark across all 6 dimensions",
      "Fastest LCP / TTI in category (LCP 0.7s, TTI 1.1s)",
      "Excellent developer documentation clarity (clarity 88)",
    ],
    weaknesses: [
      "Less consumer-facing polish — designed for developers, not end-customers",
      "No mobile-first KYC flow — Stripe Dashboard is desktop-first",
      "Higher cognitive load on first-time setup wizard (SUS 76 for non-devs)",
    ],
    recommendations: [
      { title: "Differentiate on consumer-facing UX", detail: "Stripe wins on developer UX but loses on end-customer flows. Lean into consumer-first patterns — bottom sheets, large tap targets, progress dots.", priority: "high" },
      { title: "Benchmark docs clarity against Stripe", detail: "Stripe's docs are the gold standard. Audit your in-product copy against their patterns — aim for parity.", priority: "medium" },
      { title: "Maintain mobile-first lead", detail: "Stripe Dashboard is desktop-first — your mobile KYC is a clear differentiator. Double down on mobile-only features.", priority: "medium" },
    ],
    lastUpdated: "2026-07-01",
  },
  "b-004": {
    id: "b-004",
    name: "Wise",
    industry: "Fintech / Transfers",
    logoColor: "var(--chart-3)",
    website: "wise.com",
    yourScores: YOUR_DEFAULT,
    competitorScores: { usability: 78, accessibility: 75, conversion: 73, engagement: 77, performance: 74, clarity: 79 },
    strengths: [
      "Stronger clarity score (79 vs your 80) — fee transparency messaging is best-in-class",
      "Higher engagement (77 vs your 81) — gamified streak features",
      "Better multi-currency UX patterns",
    ],
    weaknesses: [
      "Lower accessibility (75 vs your 86)",
      "Weaker conversion on first transfer (73 vs your 71) — you're close",
      "Higher cognitive load on rate-calculator step",
    ],
    recommendations: [
      { title: "Study Wise's fee transparency messaging", detail: "Wise's 'you save $X vs banks' messaging is iconic. Adapt for your transfer flow to lift clarity parity.", priority: "high" },
      { title: "Adopt gamified streak features", detail: "Wise's transfer streaks boost engagement +6pp. Pilot a 'send 3 transfers in 30 days' badge.", priority: "medium" },
      { title: "Press accessibility lead", detail: "You're +11 on accessibility — make this a marketing differentiator in compliance-conscious segments.", priority: "medium" },
    ],
    lastUpdated: "2026-07-01",
  },
  "b-005": {
    id: "b-005",
    name: "Revolut",
    industry: "Fintech / Banking",
    logoColor: "var(--chart-5)",
    website: "revolut.com",
    yourScores: YOUR_DEFAULT,
    competitorScores: { usability: 73, accessibility: 70, conversion: 76, engagement: 75, performance: 77, clarity: 73 },
    strengths: [
      "Higher conversion on upsell flows (76 vs your 71) — aggressive but effective",
      "Stronger engagement loops with vaults and round-ups",
      "Faster cold-start on mobile app launch",
    ],
    weaknesses: [
      "Lower accessibility (70 vs your 86) — color contrast failures on dark theme",
      "Higher cognitive load — feature density overwhelms new users",
      "Lower clarity (73 vs your 80) — buried primary actions",
    ],
    recommendations: [
      { title: "Avoid Revolut's feature-density trap", detail: "Revolut packs the home screen with 14+ tiles. Maintain your 6-tile hierarchy — clarity is your moat.", priority: "high" },
      { title: "Pilot round-ups feature", detail: "Revolut's round-ups drive 18% of engagement. Consider a similar savings nudge in your transfer flow.", priority: "medium" },
      { title: "Market your accessibility lead", detail: "You're +16 on accessibility vs Revolut. Lead with this in B2B sales to compliance-driven buyers.", priority: "medium" },
    ],
    lastUpdated: "2026-07-01",
  },
  "b-006": {
    id: "b-006",
    name: "Mercury",
    industry: "Fintech / Banking",
    logoColor: "var(--chart-6)",
    website: "mercury.com",
    yourScores: YOUR_DEFAULT,
    competitorScores: { usability: 84, accessibility: 85, conversion: 82, engagement: 83, performance: 81, clarity: 83 },
    strengths: [
      "Strong overall UX (83) — close to your 78, you're 5pp behind",
      "Excellent clarity on business banking flows (clarity 83)",
      "Best-in-class onboarding for SMB segment",
    ],
    weaknesses: [
      "Lower accessibility (85 vs your 86) — you hold a narrow lead",
      "Weaker mobile-first experience — Mercury is desktop-first",
      "Higher cognitive load on first account setup",
    ],
    recommendations: [
      { title: "Replicate Mercury's SMB onboarding clarity", detail: "Mercury's 'open account in 10 minutes' flow is the SMB gold standard. Audit your SMB onboarding against their pattern.", priority: "high" },
      { title: "Maintain mobile-first lead", detail: "Mercury's desktop-first design leaves mobile underserved. Press your mobile advantage in product marketing.", priority: "medium" },
      { title: "Narrow the conversion gap", detail: "Mercury's conversion (82 vs your 71) is the biggest gap. Run a CRO sprint targeting the 11pp differential.", priority: "high" },
    ],
    lastUpdated: "2026-07-01",
  },
};

const FALLBACK_DETAIL: BenchmarkDetail = BENCHMARK_DETAILS["b-001"];

function getBenchmark(id: string): BenchmarkDetail | undefined {
  return BENCHMARK_DETAILS[id] ?? FALLBACK_DETAIL;
}

const metricLabels: Record<string, string> = {
  usability: "Usability",
  accessibility: "Accessibility",
  conversion: "Conversion",
  engagement: "Engagement",
  performance: "Performance",
  clarity: "Clarity",
};

function buildRadarData(scores: Record<string, number>) {
  return Object.entries(scores).map(([key, value]) => ({
    label: metricLabels[key] ?? key,
    value,
    key,
  }));
}

export default function BenchmarkDetailPage() {
  const params = useParams<{ id: string }>();
  const benchmark = getBenchmark(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return <LoadingSkeleton variant="radar" />;
  }

  if (!benchmark) {
    return (
      <EmptyState
        icon={Trophy}
        title="Benchmark not found"
        description="This competitor benchmark may have been archived or never existed."
        action={{ label: "Back to benchmarks", href: "/benchmarks" }}
      />
    );
  }

  const yourOverall = Math.round(
    Object.values(benchmark.yourScores).reduce((s, v) => s + v, 0) / 6
  );
  const competitorOverall = Math.round(
    Object.values(benchmark.competitorScores).reduce((s, v) => s + v, 0) / 6
  );
  const delta = yourOverall - competitorOverall;
  const ahead = delta > 0;

  // 8 metrics table — use the 6 dimensions plus overall + trend
  const metricRows: MetricRow[] = [
    ...Object.keys(benchmark.yourScores).map((key) => ({
      key,
      label: metricLabels[key],
      yourScore: benchmark.yourScores[key as keyof typeof benchmark.yourScores],
      competitorScore: benchmark.competitorScores[key as keyof typeof benchmark.competitorScores],
    })),
    { key: "overall", label: "Overall UX score", yourScore: yourOverall, competitorScore: competitorOverall },
    { key: "trend", label: "Quarter-over-quarter", yourScore: 4, competitorScore: 2 },
  ];

  const handleShare = () => openShare(`/benchmarks/${benchmark.id}`, `Benchmark vs ${benchmark.name}`);
  const handleExport = () => toast.success("Benchmark report exported as PDF");

  return (
    <div>
      <PageHeader
        title={`vs. ${benchmark.name}`}
        description={`${benchmark.industry} · ${benchmark.website} · last updated ${benchmark.lastUpdated}`}
        breadcrumbs={[
          { label: "Benchmarks", href: "/benchmarks" },
          { label: benchmark.name },
        ]}
        icon={
          <div
            className="h-5 w-5 rounded-md flex items-center justify-center text-[10px] font-semibold text-white"
            style={{ background: benchmark.logoColor }}
          >
            {benchmark.name.slice(0, 2).toUpperCase()}
          </div>
        }
        badge={
          <Badge
            variant="outline"
            className={cn(
              "text-[10px] gap-1",
              ahead
                ? "bg-success/15 text-success border-success/20"
                : "bg-friction/15 text-friction border-friction/20"
            )}
          >
            {ahead ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {ahead ? "+" : ""}{delta} vs competitor
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleShare}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleExport}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
          </>
        }
      />

      {/* Overall comparison stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Your UX score"
          value={yourOverall}
          unit="/100"
          icon={<Target className="h-4 w-4" />}
          accent="success"
          trend={{ value: 4.2, direction: "up", good: true }}
          sublabel="vs last quarter"
        />
        <StatCard
          label={`${benchmark.name} score`}
          value={competitorOverall}
          unit="/100"
          icon={
            <div
              className="h-3 w-3 rounded"
              style={{ background: benchmark.logoColor }}
            />
          }
          accent="info"
          trend={{ value: 2.4, direction: "up", good: true }}
          sublabel="vs last quarter"
        />
        <StatCard
          label="Overall delta"
          value={`${ahead ? "+" : ""}${delta}`}
          icon={ahead ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
          accent={ahead ? "success" : "friction"}
          sublabel={ahead ? "you're ahead" : "you're behind"}
        />
        <StatCard
          label="Metrics won"
          value={`${metricRows.filter((m) => m.yourScore > m.competitorScore).length}/${metricRows.length}`}
          icon={<Crown className="h-4 w-4" />}
          accent="warning"
          sublabel="dimensions where you lead"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main — radar comparison + metric table */}
        <div className="lg:col-span-2 space-y-4">
          {/* Side-by-side radars */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <Activity className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">
                  UX score radar — side by side
                </h3>
              </div>
              <div className="flex items-center gap-3 text-[10px]">
                <span className="inline-flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--success)" }} />
                  You
                </span>
                <span className="inline-flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full" style={{ background: benchmark.logoColor }} />
                  {benchmark.name}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="text-center mb-2">
                  <div className="text-xs font-semibold text-success">
                    Your product
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    Overall {yourOverall}/100
                  </div>
                </div>
                <div className="aspect-square max-w-[280px] mx-auto">
                  <ScoreRadar
                    data={buildRadarData(benchmark.yourScores)}
                    size={280}
                    color="var(--success)"
                  />
                </div>
              </div>
              <div>
                <div className="text-center mb-2">
                  <div className="text-xs font-semibold" style={{ color: benchmark.logoColor }}>
                    {benchmark.name}
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    Overall {competitorOverall}/100
                  </div>
                </div>
                <div className="aspect-square max-w-[280px] mx-auto">
                  <ScoreRadar
                    data={buildRadarData(benchmark.competitorScores)}
                    size={280}
                    color={benchmark.logoColor}
                  />
                </div>
              </div>
            </div>
          </Card>

          {/* Detailed comparison table */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Target className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                Detailed metric comparison
              </h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {metricRows.length} metrics
              </Badge>
            </div>

            <div className="overflow-x-auto -mx-2 px-2">
              <table className="w-full text-xs min-w-[560px]">
                <thead>
                  <tr className="border-b border-soft">
                    <th className="text-left text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Metric
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      You
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      {benchmark.name}
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Delta
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Winner
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {metricRows.map((m) => {
                    const mDelta = m.yourScore - m.competitorScore;
                    const youWin = mDelta > 0;
                    const tie = mDelta === 0;
                    return (
                      <tr key={m.key} className="border-b border-soft last:border-0">
                        <td className="px-2 py-3">
                          <span className="text-xs font-medium text-ink">
                            {m.label}
                          </span>
                        </td>
                        <td className="px-2 py-3 text-center">
                          <span
                            className={cn(
                              "text-xs font-semibold",
                              youWin && !tie ? "text-success" : "text-ink"
                            )}
                          >
                            {m.yourScore}
                            {m.key === "trend" && "%"}
                          </span>
                        </td>
                        <td className="px-2 py-3 text-center">
                          <span
                            className={cn(
                              "text-xs font-semibold",
                              !youWin && !tie ? "text-info" : "text-ink"
                            )}
                          >
                            {m.competitorScore}
                            {m.key === "trend" && "%"}
                          </span>
                        </td>
                        <td className="px-2 py-3 text-center">
                          <span
                            className={cn(
                              "text-xs font-semibold inline-flex items-center gap-0.5",
                              tie
                                ? "text-muted-foreground"
                                : youWin
                                ? "text-success"
                                : "text-friction"
                            )}
                          >
                            {!tie && (
                              youWin ? (
                                <TrendingUp className="h-3 w-3" />
                              ) : (
                                <TrendingDown className="h-3 w-3" />
                              )
                            )}
                            {tie ? "—" : `${youWin ? "+" : ""}${mDelta}`}
                          </span>
                        </td>
                        <td className="px-2 py-3 text-center">
                          {tie ? (
                            <span className="text-[9px] text-muted-foreground">Tie</span>
                          ) : youWin ? (
                            <Badge variant="outline" className="text-[9px] bg-success/15 text-success border-success/20 gap-1">
                              <Crown className="h-2.5 w-2.5" /> You
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-[9px] bg-info/15 text-info border-info/20 gap-1">
                              <Crown className="h-2.5 w-2.5" /> {benchmark.name}
                            </Badge>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        {/* Right column — strengths, weaknesses, recommendations */}
        <div className="space-y-4">
          {/* Strengths */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/15 text-info">
                <TrendingUp className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                {benchmark.name} strengths
              </h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {benchmark.strengths.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {benchmark.strengths.map((s, i) => (
                <div key={i} className="flex items-start gap-2 rounded-xl border border-soft p-2.5">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-info/15 text-info flex-shrink-0 mt-0.5">
                    <CheckCircle2 className="h-3 w-3" />
                  </div>
                  <div className="text-[11px] text-ink leading-relaxed">
                    {s}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Weaknesses */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-success/15 text-success">
                <TrendingDown className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                {benchmark.name} weaknesses
              </h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {benchmark.weaknesses.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {benchmark.weaknesses.map((s, i) => (
                <div key={i} className="flex items-start gap-2 rounded-xl border border-soft p-2.5">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-success/15 text-success flex-shrink-0 mt-0.5">
                    <AlertTriangle className="h-3 w-3" />
                  </div>
                  <div className="text-[11px] text-ink leading-relaxed">
                    {s}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recommendations */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Target className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                Recommendations
              </h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {benchmark.recommendations.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {benchmark.recommendations.map((r, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-soft p-2.5"
                >
                  <div className="flex items-start gap-2 mb-1">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[9px] capitalize flex-shrink-0",
                        r.priority === "high"
                          ? "bg-friction/15 text-friction border-friction/20"
                          : r.priority === "medium"
                          ? "bg-warning/15 text-warning border-warning/20"
                          : "bg-info/15 text-info border-info/20"
                      )}
                    >
                      {r.priority}
                    </Badge>
                    <span className="text-xs font-medium text-ink flex-1">
                      {r.title}
                    </span>
                  </div>
                  <div className="text-[10px] text-muted-foreground leading-relaxed ml-1">
                    {r.detail}
                  </div>
                </div>
              ))}
            </div>
            <Button
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Recommendations synced to roadmap")}
            >
              <Sparkles className="mr-2 h-3.5 w-3.5" /> Sync to roadmap
            </Button>
          </Card>
        </div>
      </div>

      {/* Footer CTA */}
      <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4 bg-gradient-to-r from-surface-2/50 to-card">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-ink mb-1">
              Deep-dive this competitor
            </h3>
            <p className="text-[11px] text-muted-foreground">
              Generate a full 12-page competitor teardown report with screen-by-screen analysis, insights, and action items.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="rounded-full text-xs"
              onClick={handleExport}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export report
            </Button>
            <Button
              size="sm"
              className="rounded-full text-xs"
              onClick={() => toast.success("Competitor teardown scheduled")}
            >
              Generate teardown
              <ArrowRight className="ml-2 h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
