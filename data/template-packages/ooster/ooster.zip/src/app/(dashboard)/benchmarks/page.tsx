"use client";

import * as React from "react";
import Link from "next/link";
import {
  Trophy,
  Plus,
  Download,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Crown,
  Target,
  Activity,
  Users,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Benchmark {
  id: string;
  name: string;
  industry: string;
  logoColor: string;
  overallScore: number;
  yourScore: number;
  delta: number;
  isLeader: boolean;
  segments: {
    usability: number;
    accessibility: number;
    conversion: number;
    engagement: number;
    performance: number;
    clarity: number;
  };
  trend: number;
}

// Your product's scores — used as the reference point across all benchmarks
const YOUR_SCORES = {
  usability: 78,
  accessibility: 86,
  conversion: 71,
  engagement: 81,
  performance: 74,
  clarity: 80,
};
const YOUR_OVERALL = 78;

const BENCHMARKS: Benchmark[] = [
  {
    id: "b-001",
    name: "Northwind",
    industry: "Retail / E-commerce",
    logoColor: "var(--chart-1)",
    overallScore: 72,
    yourScore: YOUR_OVERALL,
    delta: YOUR_OVERALL - 72,
    isLeader: false,
    segments: { usability: 70, accessibility: 68, conversion: 74, engagement: 72, performance: 76, clarity: 71 },
    trend: 2.4,
  },
  {
    id: "b-002",
    name: "Acme Pay",
    industry: "Fintech / Payments",
    logoColor: "var(--chart-2)",
    overallScore: 81,
    yourScore: YOUR_OVERALL,
    delta: YOUR_OVERALL - 81,
    isLeader: true,
    segments: { usability: 82, accessibility: 79, conversion: 84, engagement: 80, performance: 83, clarity: 78 },
    trend: -1.2,
  },
  {
    id: "b-003",
    name: "Stripe",
    industry: "Fintech / Payments",
    logoColor: "var(--chart-4)",
    overallScore: 89,
    yourScore: YOUR_OVERALL,
    delta: YOUR_OVERALL - 89,
    isLeader: true,
    segments: { usability: 90, accessibility: 88, conversion: 87, engagement: 89, performance: 92, clarity: 88 },
    trend: 3.1,
  },
  {
    id: "b-004",
    name: "Wise",
    industry: "Fintech / Transfers",
    logoColor: "var(--chart-3)",
    overallScore: 76,
    yourScore: YOUR_OVERALL,
    delta: YOUR_OVERALL - 76,
    isLeader: false,
    segments: { usability: 78, accessibility: 75, conversion: 73, engagement: 77, performance: 74, clarity: 79 },
    trend: 4.2,
  },
  {
    id: "b-005",
    name: "Revolut",
    industry: "Fintech / Banking",
    logoColor: "var(--chart-5)",
    overallScore: 74,
    yourScore: YOUR_OVERALL,
    delta: YOUR_OVERALL - 74,
    isLeader: false,
    segments: { usability: 73, accessibility: 70, conversion: 76, engagement: 75, performance: 77, clarity: 73 },
    trend: 1.8,
  },
  {
    id: "b-006",
    name: "Mercury",
    industry: "Fintech / Banking",
    logoColor: "var(--chart-6)",
    overallScore: 83,
    yourScore: YOUR_OVERALL,
    delta: YOUR_OVERALL - 83,
    isLeader: true,
    segments: { usability: 84, accessibility: 85, conversion: 82, engagement: 83, performance: 81, clarity: 83 },
    trend: 2.6,
  },
];

const deltaColor = (delta: number) =>
  delta > 0 ? "text-success" : delta < 0 ? "text-friction" : "text-muted-foreground";

export default function BenchmarksPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const total = BENCHMARKS.length;
  const leaders = BENCHMARKS.filter((b) => b.isLeader).length;
  const avgCompetitor = Math.round(
    BENCHMARKS.reduce((s, b) => s + b.overallScore, 0) / BENCHMARKS.length
  );
  const aheadCount = BENCHMARKS.filter((b) => b.delta > 0).length;

  return (
    <div>
      <PageHeader
        title="Competitor Benchmarks"
        description="Side-by-side UX performance vs. industry competitors"
        icon={<Trophy className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {BENCHMARKS.length} competitors tracked
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Benchmark report exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Add a competitor to track")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> Add competitor
            </Button>
          </>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Competitors tracked"
          value={total}
          icon={<Trophy className="h-4 w-4" />}
          accent="info"
          sublabel="across 2 industries"
        />
        <StatCard
          label="Your UX score"
          value={YOUR_OVERALL}
          unit="/100"
          icon={<Target className="h-4 w-4" />}
          accent="success"
          trend={{ value: 4.2, direction: "up", good: true }}
          sublabel="vs last quarter"
        />
        <StatCard
          label="Avg competitor score"
          value={avgCompetitor}
          unit="/100"
          icon={<Activity className="h-4 w-4" />}
          accent="warning"
          sublabel={`you're ${YOUR_OVERALL - avgCompetitor > 0 ? "+" : ""}${YOUR_OVERALL - avgCompetitor} vs avg`}
        />
        <StatCard
          label="Industry leaders"
          value={leaders}
          icon={<Crown className="h-4 w-4" />}
          accent="warning"
          sublabel={`${aheadCount} competitors you're ahead of`}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : BENCHMARKS.length === 0 ? (
        <EmptyState
          icon={Trophy}
          title="No competitors tracked yet"
          description="Add a competitor to start benchmarking your UX performance against the industry."
          action={{ label: "Add competitor", onClick: () => toast.message("Opening competitor form") }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {BENCHMARKS.map((b) => {
            const ahead = b.delta > 0;
            return (
              <Link key={b.id} href={`/benchmarks/${b.id}`} className="group">
                <Card className="rounded-2xl border-soft shadow-soft p-5 h-full hover:shadow-card hover:border-primary/30 transition-all flex flex-col">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div
                        className="flex h-11 w-11 items-center justify-center rounded-xl font-semibold text-white text-sm flex-shrink-0"
                        style={{ background: b.logoColor }}
                      >
                        {b.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-ink group-hover:text-primary transition-colors line-clamp-1">
                          {b.name}
                        </div>
                        <div className="text-[10px] text-muted-foreground line-clamp-1">
                          {b.industry}
                        </div>
                      </div>
                    </div>
                    {b.isLeader && (
                      <Badge
                        variant="outline"
                        className="text-[9px] bg-warning/15 text-warning border-warning/20 gap-1 flex-shrink-0"
                      >
                        <Crown className="h-2.5 w-2.5" /> Leader
                      </Badge>
                    )}
                  </div>

                  {/* Score comparison */}
                  <div className="grid grid-cols-3 gap-2 py-3 border-y border-soft mb-3">
                    <div>
                      <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
                        You
                      </div>
                      <div className="text-lg font-semibold text-success">
                        {b.yourScore}
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
                        {b.name}
                      </div>
                      <div className="text-lg font-semibold text-ink">
                        {b.overallScore}
                      </div>
                    </div>
                    <div>
                      <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
                        Delta
                      </div>
                      <div
                        className={cn(
                          "text-lg font-semibold inline-flex items-center gap-1",
                          deltaColor(b.delta)
                        )}
                      >
                        {ahead ? (
                          <TrendingUp className="h-4 w-4" />
                        ) : (
                          <TrendingDown className="h-4 w-4" />
                        )}
                        {ahead ? "+" : ""}
                        {b.delta}
                      </div>
                    </div>
                  </div>

                  {/* Mini comparison bar */}
                  <div className="space-y-2 mb-3">
                    <div>
                      <div className="flex items-center justify-between text-[9px] text-muted-foreground mb-1">
                        <span>Your UX</span>
                        <span className="text-ink font-semibold">{b.yourScore}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-success"
                          style={{ width: `${b.yourScore}%` }}
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-[9px] text-muted-foreground mb-1">
                        <span>{b.name}</span>
                        <span className="text-ink font-semibold">{b.overallScore}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-surface-2 overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${b.overallScore}%`,
                            background: b.logoColor,
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="mt-auto flex items-center justify-between pt-1">
                    <div className="flex items-center gap-1.5 text-[10px]">
                      {b.trend > 0 ? (
                        <TrendingUp className="h-3 w-3 text-success" />
                      ) : (
                        <TrendingDown className="h-3 w-3 text-friction" />
                      )}
                      <span className="text-muted-foreground">YoY:</span>
                      <span className={cn("font-medium", b.trend > 0 ? "text-success" : "text-friction")}>
                        {b.trend > 0 ? "+" : ""}{b.trend}%
                      </span>
                    </div>
                    <Button
                      asChild
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs rounded-full px-2 hover:bg-accent/30"
                    >
                      <Link href={`/benchmarks/${b.id}`}>
                        Compare
                        <ChevronRight className="ml-1 h-3 w-3" />
                      </Link>
                    </Button>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
