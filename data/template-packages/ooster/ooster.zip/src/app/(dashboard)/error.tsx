"use client";

import Link from "next/link";
import { AlertTriangle, RefreshCw, Home } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Error({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="text-center max-w-md">
        <div className="mx-auto h-14 w-14 rounded-2xl bg-friction/15 text-friction flex items-center justify-center mb-4">
          <AlertTriangle className="h-7 w-7" />
        </div>
        <h2 className="text-lg font-semibold text-ink">Something went wrong</h2>
        <p className="text-sm text-muted-foreground mt-2 mb-5">
          An unexpected error occurred while rendering this page. Our team has been notified — try refreshing, or head back to the dashboard.
        </p>
        <div className="flex items-center justify-center gap-2">
          <Button onClick={reset}>
            <RefreshCw className="mr-2 h-4 w-4" /> Try again
          </Button>
          <Button asChild variant="outline">
            <Link href="/"><Home className="mr-2 h-4 w-4" /> Dashboard</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
