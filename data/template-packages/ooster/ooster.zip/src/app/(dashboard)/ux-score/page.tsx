"use client";

import * as React from "react";
import {
  Gauge,
  Trophy,
  TrendingUp,
  TrendingDown,
  Building2,
  Sparkles,
  Download,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { CircleProgress } from "@/components/common/circle-progress";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LineChart } from "@/components/charts";
import { AGGREGATE_UX, TREND_SERIES } from "@/lib/data";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { AnimatedNumber, ProgressBar, ActiveDot } from "@/components/common/animated-progress";

interface Dimension {
  key: string;
  label: string;
  value: number;
  delta: number;
}

const DIMENSIONS: Dimension[] = [
  { key: "usability", label: "Usability", value: AGGREGATE_UX.usability, delta: 2.4 },
  { key: "accessibility", label: "Accessibility", value: AGGREGATE_UX.accessibility, delta: 1.1 },
  { key: "conversion", label: "Conversion", value: AGGREGATE_UX.conversion, delta: -0.8 },
  { key: "engagement", label: "Engagement", value: AGGREGATE_UX.engagement, delta: 3.2 },
  { key: "cognitiveLoad", label: "Cognitive Load", value: AGGREGATE_UX.cognitiveLoad, delta: -1.4 },
  { key: "clarity", label: "Clarity", value: AGGREGATE_UX.clarity, delta: 1.8 },
  { key: "consistency", label: "Consistency", value: AGGREGATE_UX.consistency, delta: 0.6 },
  { key: "friction", label: "Friction (inv.)", value: AGGREGATE_UX.friction, delta: -2.1 },
];

interface LeaderRow {
  rank: number;
  project: string;
  score: number;
  delta: number;
  screens: number;
  criticalIssues: number;
  trend: number[];
}

const LEADERBOARD: LeaderRow[] = [
  { rank: 1, project: "Riverside Design System", score: 89, delta: 2.1, screens: 64, criticalIssues: 0, trend: [82, 83, 84, 85, 85, 86, 87, 87, 88, 88, 89, 89] },
  { rank: 2, project: "Helix Prototype", score: 84, delta: 3.4, screens: 38, criticalIssues: 1, trend: [76, 77, 78, 79, 80, 80, 81, 82, 82, 83, 84, 84] },
  { rank: 3, project: "Northwind Checkout", score: 79, delta: -0.6, screens: 22, criticalIssues: 2, trend: [80, 81, 81, 80, 80, 79, 80, 79, 80, 79, 79, 79] },
  { rank: 4, project: "Voyage Booking", score: 76, delta: 1.2, screens: 47, criticalIssues: 1, trend: [71, 72, 72, 73, 73, 74, 74, 75, 75, 75, 76, 76] },
  { rank: 5, project: "Cadence Mobile", score: 71, delta: 4.0, screens: 31, criticalIssues: 2, trend: [62, 63, 64, 65, 66, 67, 68, 69, 70, 70, 71, 71] },
  { rank: 6, project: "Atlas Onboarding", score: 64, delta: -1.8, screens: 19, criticalIssues: 3, trend: [68, 68, 67, 67, 66, 66, 65, 65, 64, 64, 64, 64] },
];

const MOVERS = [
  { project: "Cadence Mobile", delta: 4.0, direction: "up" as const },
  { project: "Helix Prototype", delta: 3.4, direction: "up" as const },
  { project: "Atlas Onboarding", delta: -1.8, direction: "down" as const },
];

const BENCHMARKS = [
  { label: "Your UX score", value: 78, color: "var(--success)" },
  { label: "Industry avg (FinTech)", value: 71, color: "var(--info)" },
  { label: "Top quartile", value: 84, color: "var(--warning)" },
];

type SortKey = "score" | "delta" | "screens" | "criticalIssues";

export default function UxScorePage() {
  const [loading, setLoading] = React.useState(true);
  const [sortKey, setSortKey] = React.useState<SortKey>("score");
  const [sortDir, setSortDir] = React.useState<"asc" | "desc">("desc");

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const overall = 78;

  const sortedBoard = React.useMemo(() => {
    const arr = [...LEADERBOARD];
    arr.sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return arr;
  }, [sortKey, sortDir]);

  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(k);
      setSortDir("desc");
    }
  };

  const trendData = React.useMemo(
    () =>
      TREND_SERIES.map((d) => ({
        label: d.week,
        values: [{ label: "UX score", value: d.ux }],
      })),
    []
  );

  const scoreColor = overall >= 80 ? "var(--success)" : overall >= 70 ? "var(--warning)" : "var(--friction)";

  const renderSortHeader = (k: SortKey, label: string) => (
    <button
      onClick={() => toggleSort(k)}
      className="inline-flex items-center gap-1 hover:text-ink transition-colors"
    >
      {label}
      {sortKey === k ? (
        sortDir === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
      ) : (
        <ChevronDown className="h-3 w-3 opacity-30" />
      )}
    </button>
  );

  return (
    <div>
      <PageHeader
        title="UX Score"
        description="Composite UX health score across all dimensions and projects"
        breadcrumbs={[{ label: "Analytics" }, { label: "UX Score" }]}
        icon={<Gauge className="h-5 w-5" />}
        badge={<Badge variant="secondary" className="text-[10px]">Composite</Badge>}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("UX score methodology PDF opened")}
            >
              <Sparkles className="mr-2 h-3.5 w-3.5" /> Methodology
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("UX score report exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
          </>
        }
      />

      {loading ? (
        <LoadingSkeleton variant="page" />
      ) : (
        <>
          {/* Hero card */}
          <Card className="rounded-2xl border-soft shadow-soft p-5 mb-4 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left — overall score */}
              <div className="lg:col-span-4 flex flex-col items-center justify-center text-center">
                <div className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1.5 justify-center">
                  <ActiveDot color="var(--success)" size={6} />
                  Overall UX Score · Live
                </div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.85 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                >
                  <CircleProgress
                    value={overall}
                    size={180}
                    strokeWidth={12}
                    color={scoreColor}
                    label=""
                  >
                    <AnimatedNumber
                      value={overall}
                      duration={1.6}
                      className="text-5xl font-semibold tracking-tight text-gradient-ink"
                    />
                    <span className="text-[10px] text-muted-foreground mt-1">out of 100</span>
                  </CircleProgress>
                </motion.div>
                <div className="mt-3 flex items-center gap-2 flex-wrap justify-center">
                  <Badge variant="outline" className="text-[10px] border-success/20 bg-success/10 text-success">
                    <TrendingUp className="mr-1 h-3 w-3" /> +2.4 this quarter
                  </Badge>
                  <Badge variant="outline" className="text-[10px] border-border bg-muted text-muted-foreground">
                    Above industry avg
                  </Badge>
                </div>
              </div>

              {/* Right — 8 dimension bars */}
              <div className="lg:col-span-8">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm font-semibold text-ink">Score breakdown by dimension</div>
                    <div className="text-[11px] text-muted-foreground">8 weighted dimensions · weekly recalibration</div>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-5 gap-y-3">
                  {DIMENSIONS.map((d) => {
                    const color =
                      d.value >= 80 ? "var(--success)" : d.value >= 70 ? "var(--warning)" : "var(--friction)";
                    const isUp = d.delta > 0;
                    const goodDir = d.key === "friction" ? !isUp : isUp;
                    return (
                      <div key={d.key} className="space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-medium text-ink truncate">{d.label}</span>
                          <div className="flex items-center gap-1.5 flex-shrink-0">
                            <span className="text-xs font-semibold tabular-nums text-ink">
                              <AnimatedNumber value={d.value} duration={1.2} />
                            </span>
                            <span
                              className={cn(
                                "text-[10px] tabular-nums inline-flex items-center gap-0.5",
                                goodDir ? "text-success" : "text-friction"
                              )}
                            >
                              {isUp ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                              {Math.abs(d.delta)}
                            </span>
                          </div>
                        </div>
                        <ProgressBar
                          value={d.value}
                          color={color}
                          trackColor="var(--surface-2)"
                          height={6}
                          delay={0.05 * DIMENSIONS.indexOf(d)}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </Card>

          {/* Trend + Benchmark + Movers */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            {/* Trend chart */}
            <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm font-semibold text-ink">12-week UX score trend</div>
                  <div className="text-[11px] text-muted-foreground">Composite score across all projects</div>
                </div>
                <Badge variant="outline" className="text-[10px] border-success/20 bg-success/10 text-success">
                  <TrendingUp className="mr-1 h-3 w-3" /> +16 pts since W1
                </Badge>
                <ActiveDot color="var(--success)" size={6} className="ml-1" />
              </div>
              <LineChart data={trendData} height={240} />
              <div className="mt-3 pt-3 border-t border-soft grid grid-cols-3 gap-2 text-[10px]">
                <div>
                  <div className="text-muted-foreground">Min (W1)</div>
                  <div className="font-semibold text-ink tabular-nums"><AnimatedNumber value={TREND_SERIES[0].ux} duration={1.2} /></div>
                </div>
                <div>
                  <div className="text-muted-foreground">Average</div>
                  <div className="font-semibold text-ink tabular-nums">
                    <AnimatedNumber value={Math.round(TREND_SERIES.reduce((a, b) => a + b.ux, 0) / TREND_SERIES.length)} duration={1.2} />
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Latest (W12)</div>
                  <div className="font-semibold text-success tabular-nums">
                    <AnimatedNumber value={TREND_SERIES[TREND_SERIES.length - 1].ux} duration={1.2} />
                  </div>
                </div>
              </div>
            </Card>

            {/* Benchmark + Movers stacked */}
            <div className="flex flex-col gap-4">
              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Building2 className="h-4 w-4 text-info" />
                  <div className="text-sm font-semibold text-ink">Benchmark comparison</div>
                </div>
                <div className="space-y-3">
                  {BENCHMARKS.map((b, i) => (
                    <div key={b.label} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">{b.label}</span>
                        <span className="font-semibold text-ink tabular-nums"><AnimatedNumber value={b.value} duration={1.2} /></span>
                      </div>
                      <ProgressBar
                        value={b.value}
                        color={b.color}
                        trackColor="var(--surface-2)"
                        height={8}
                        delay={0.15 + i * 0.08}
                      />
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-soft text-[10px] text-muted-foreground">
                  You're <span className="text-success font-semibold">7 points</span> above the FinTech industry
                  average and 6 points below the top quartile.
                </div>
              </Card>

              <Card className="rounded-2xl border-soft shadow-soft p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Trophy className="h-4 w-4 text-warning" />
                  <div className="text-sm font-semibold text-ink">Top movers (WoW)</div>
                </div>
                <div className="space-y-2.5">
                  {MOVERS.map((m, i) => (
                    <div key={m.project} className="flex items-center justify-between">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-[10px] text-muted-foreground tabular-nums w-4">{i + 1}</span>
                        <span className="text-xs font-medium text-ink truncate">{m.project}</span>
                      </div>
                      <span
                        className={cn(
                          "text-xs font-semibold tabular-nums inline-flex items-center gap-0.5",
                          m.direction === "up" ? "text-success" : "text-friction"
                        )}
                      >
                        {m.direction === "up" ? (
                          <TrendingUp className="h-3 w-3" />
                        ) : (
                          <TrendingDown className="h-3 w-3" />
                        )}
                        {m.delta > 0 ? "+" : ""}
                        <AnimatedNumber value={m.delta} duration={1} />
                      </span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>

          {/* Project leaderboard table */}
          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden">
            <div className="p-4 border-b border-soft flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold text-ink">Project leaderboard</div>
                <div className="text-[11px] text-muted-foreground">6 active projects ranked by UX score</div>
              </div>
              <Badge variant="secondary" className="text-[10px]">Sortable</Badge>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-soft">
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">#</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">Project</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">{renderSortHeader("score", "UX Score")}</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">{renderSortHeader("delta", "Δ WoW")}</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">12-week trend</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">{renderSortHeader("screens", "Screens")}</th>
                    <th className="text-left font-medium text-muted-foreground px-4 py-2.5">{renderSortHeader("criticalIssues", "Critical")}</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedBoard.map((row) => {
                    const color =
                      row.score >= 80 ? "var(--success)" : row.score >= 70 ? "var(--warning)" : "var(--friction)";
                    return (
                      <tr key={row.project} className="border-b border-soft last:border-0 hover:bg-accent/30 transition-colors">
                        <td className="px-4 py-3">
                          <span className={cn(
                            "inline-flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-semibold",
                            row.rank === 1 ? "bg-warning/15 text-warning" : "bg-surface-2 text-muted-foreground"
                          )}>
                            {row.rank}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium text-ink">{row.project}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold tabular-nums text-ink"><AnimatedNumber value={row.score} duration={1.2} /></span>
                            <ProgressBar
                              value={row.score}
                              color={color}
                              trackColor="var(--surface-2)"
                              height={6}
                              className="w-16"
                              delay={0.05}
                            />
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={cn(
                            "inline-flex items-center gap-0.5 tabular-nums font-medium",
                            row.delta > 0 ? "text-success" : "text-friction"
                          )}>
                            {row.delta > 0 ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                            {Math.abs(row.delta)}
                          </span>
                        </td>
                        <td className="px-4 py-3 w-32">
                          <div className="flex items-end gap-0.5 h-8">
                            {row.trend.map((v, i) => {
                              const max = Math.max(...row.trend);
                              const min = Math.min(...row.trend);
                              const range = max - min || 1;
                              const h = ((v - min) / range) * 100;
                              return (
                                <div
                                  key={i}
                                  className="flex-1 rounded-sm"
                                  style={{
                                    height: `${Math.max(8, h)}%`,
                                    background: i === row.trend.length - 1 ? color : "color-mix(in oklch, var(--muted-foreground) 35%, transparent)",
                                  }}
                                />
                              );
                            })}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground tabular-nums"><AnimatedNumber value={row.screens} duration={1} /></td>
                        <td className="px-4 py-3">
                          {row.criticalIssues === 0 ? (
                            <span className="text-success text-[10px] font-medium">None</span>
                          ) : (
                            <Badge variant="outline" className="text-[10px] border-friction/20 bg-friction/10 text-friction">
                              {row.criticalIssues} critical
                            </Badge>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
