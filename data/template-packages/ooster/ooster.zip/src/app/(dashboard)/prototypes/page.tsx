"use client";

import * as React from "react";
import Link from "next/link";
import {
  FlaskConical,
  Plus,
  Download,
  ChevronRight,
  Users,
  CheckCircle2,
  Clock,
  Crown,
  Beaker,
  MousePointerClick,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { CircleProgress } from "@/components/common/circle-progress";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Prototype {
  id: string;
  name: string;
  project: string;
  testType: "usability" | "ab-test" | "first-click";
  variants: { name: string; isWinner: boolean }[];
  participants: number;
  completionRate: number;
  timeOnTask: string;
  status: "running" | "completed" | "draft";
  gradient: string;
}

const GRADIENTS = [
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-1) 35%, var(--card)), color-mix(in oklch, var(--chart-4) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-2) 35%, var(--card)), color-mix(in oklch, var(--chart-3) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-4) 35%, var(--card)), color-mix(in oklch, var(--chart-5) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-5) 35%, var(--card)), color-mix(in oklch, var(--chart-6) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-3) 35%, var(--card)), color-mix(in oklch, var(--chart-1) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-6) 35%, var(--card)), color-mix(in oklch, var(--chart-2) 18%, var(--card)))",
];

const PROTOTYPES: Prototype[] = [
  {
    id: "pr-001",
    name: "KYC: single screen vs progressive steps",
    project: "Atlas Onboarding",
    testType: "ab-test",
    variants: [
      { name: "A", isWinner: false },
      { name: "B", isWinner: true },
    ],
    participants: 42,
    completionRate: 74,
    timeOnTask: "2:18",
    status: "completed",
    gradient: GRADIENTS[0],
  },
  {
    id: "pr-002",
    name: "Checkout: 1-page vs 2-page",
    project: "Northwind Checkout",
    testType: "ab-test",
    variants: [
      { name: "A", isWinner: false },
      { name: "B", isWinner: true },
      { name: "C", isWinner: false },
    ],
    participants: 64,
    completionRate: 81,
    timeOnTask: "1:48",
    status: "running",
    gradient: GRADIENTS[1],
  },
  {
    id: "pr-003",
    name: "Dashboard IA: card sort validation",
    project: "Helix Prototype",
    testType: "usability",
    variants: [
      { name: "A", isWinner: true },
      { name: "B", isWinner: false },
    ],
    participants: 18,
    completionRate: 88,
    timeOnTask: "3:42",
    status: "completed",
    gradient: GRADIENTS[2],
  },
  {
    id: "pr-004",
    name: "Habit creation flow: 3 vs 5 steps",
    project: "Cadence Mobile",
    testType: "usability",
    variants: [
      { name: "A", isWinner: false },
      { name: "B", isWinner: true },
    ],
    participants: 24,
    completionRate: 91,
    timeOnTask: "1:12",
    status: "completed",
    gradient: GRADIENTS[3],
  },
  {
    id: "pr-005",
    name: "Search first-click: icon vs label",
    project: "Voyage Booking",
    testType: "first-click",
    variants: [
      { name: "A", isWinner: false },
      { name: "B", isWinner: false },
      { name: "C", isWinner: true },
    ],
    participants: 36,
    completionRate: 67,
    timeOnTask: "0:48",
    status: "completed",
    gradient: GRADIENTS[4],
  },
  {
    id: "pr-006",
    name: "Notification prompt: timing variants",
    project: "Cadence Mobile",
    testType: "ab-test",
    variants: [
      { name: "A", isWinner: false },
      { name: "B", isWinner: false },
    ],
    participants: 12,
    completionRate: 58,
    timeOnTask: "0:32",
    status: "draft",
    gradient: GRADIENTS[5],
  },
];

const testTypeMeta: Record<string, { icon: React.ElementType; label: string; color: string }> = {
  usability: { icon: Beaker, label: "Usability", color: "var(--info)" },
  "ab-test": { icon: FlaskConical, label: "A/B test", color: "var(--success)" },
  "first-click": { icon: MousePointerClick, label: "First-click", color: "var(--warning)" },
};

export default function PrototypesPage() {
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const total = PROTOTYPES.length;
  const completed = PROTOTYPES.filter((p) => p.status === "completed").length;
  const totalParticipants = PROTOTYPES.reduce((s, p) => s + p.participants, 0);
  const avgCompletion = Math.round(
    PROTOTYPES.reduce((s, p) => s + p.completionRate, 0) / PROTOTYPES.length
  );
  const winners = PROTOTYPES.filter((p) =>
    p.variants.some((v) => v.isWinner)
  ).length;

  return (
    <div>
      <PageHeader
        title="Prototype Analysis"
        description="Test prototypes before shipping. Compare variants, measure learnability."
        icon={<FlaskConical className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {PROTOTYPES.length} prototypes
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Prototype results exported")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Upload a new prototype to test")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> New prototype
            </Button>
          </>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Active prototypes"
          value={total}
          icon={<FlaskConical className="h-4 w-4" />}
          accent="info"
          sublabel={`${completed} completed`}
        />
        <StatCard
          label="Total participants"
          value={totalParticipants}
          icon={<Users className="h-4 w-4" />}
          accent="success"
          trend={{ value: 12.4, direction: "up", good: true }}
          sublabel="across all tests"
        />
        <StatCard
          label="Avg task completion"
          value={`${avgCompletion}%`}
          icon={<CheckCircle2 className="h-4 w-4" />}
          accent={avgCompletion >= 75 ? "success" : "warning"}
          trend={{ value: 4.2, direction: "up", good: true }}
          sublabel="vs last sprint"
        />
        <StatCard
          label="Winners declared"
          value={winners}
          icon={<Crown className="h-4 w-4" />}
          accent="warning"
          sublabel="ship-ready variants"
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : PROTOTYPES.length === 0 ? (
        <EmptyState
          icon={FlaskConical}
          title="No prototypes yet"
          description="Upload your first prototype to compare variants, run usability tests, and validate design decisions before shipping."
          action={{ label: "New prototype", onClick: () => toast.message("Opening prototype uploader") }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {PROTOTYPES.map((p) => {
            const tt = testTypeMeta[p.testType];
            const winner = p.variants.find((v) => v.isWinner);
            return (
              <Link key={p.id} href={`/prototypes/${p.id}`} className="group">
                <Card className="rounded-2xl border-soft shadow-soft overflow-hidden hover:shadow-card hover:border-primary/30 transition-all h-full flex flex-col">
                  {/* Header with gradient + variant badges */}
                  <div
                    className="relative p-4 pb-3"
                    style={{ background: p.gradient }}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <Badge
                        variant="outline"
                        className="text-[10px] gap-1 bg-card/80 backdrop-blur-sm"
                      >
                        <tt.icon className="h-3 w-3" style={{ color: tt.color }} />
                        {tt.label}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={cn(
                          "text-[9px] capitalize bg-card/80 backdrop-blur-sm",
                          p.status === "completed"
                            ? "text-success"
                            : p.status === "running"
                            ? "text-info"
                            : "text-muted-foreground"
                        )}
                      >
                        {p.status}
                      </Badge>
                    </div>

                    {/* Variant cards row */}
                    <div className="flex items-center gap-1.5 mb-2">
                      {p.variants.map((v) => (
                        <div
                          key={v.name}
                          className={cn(
                            "flex-1 rounded-lg border-2 bg-card/90 backdrop-blur-sm p-1.5 text-center relative",
                            v.isWinner ? "border-success" : "border-transparent"
                          )}
                        >
                          <div className="text-[10px] font-semibold text-ink">
                            Variant {v.name}
                          </div>
                          {v.isWinner && (
                            <div className="absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full bg-success flex items-center justify-center">
                              <Crown className="h-2.5 w-2.5 text-white" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Body */}
                  <div className="p-4 flex flex-col flex-1">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="text-sm font-semibold text-ink group-hover:text-primary transition-colors line-clamp-2 flex-1">
                        {p.name}
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-ink flex-shrink-0" />
                    </div>
                    <div className="text-[10px] text-muted-foreground mb-3">
                      {p.project}
                    </div>

                    {/* Metric strip */}
                    <div className="grid grid-cols-3 gap-2 py-3 border-y border-soft">
                      <div>
                        <div className="flex items-center gap-1 text-[9px] text-muted-foreground">
                          <Users className="h-2.5 w-2.5" /> Participants
                        </div>
                        <div className="text-xs font-semibold text-ink">
                          {p.participants}
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-[9px] text-muted-foreground">
                          <CheckCircle2 className="h-2.5 w-2.5" /> Completion
                        </div>
                        <div className="text-xs font-semibold text-success">
                          {p.completionRate}%
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-[9px] text-muted-foreground">
                          <Clock className="h-2.5 w-2.5" /> Time/task
                        </div>
                        <div className="text-xs font-semibold text-ink">
                          {p.timeOnTask}
                        </div>
                      </div>
                    </div>

                    {/* Winner / footer */}
                    <div className="mt-3 flex items-center justify-between">
                      {winner ? (
                        <div className="flex items-center gap-1.5 text-[10px]">
                          <Crown className="h-3 w-3 text-success" />
                          <span className="text-muted-foreground">Winner:</span>
                          <span className="text-success font-semibold">
                            Variant {winner.name}
                          </span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                          <TrendingUp className="h-3 w-3" />
                          Test in progress
                        </div>
                      )}
                      <span className="text-[10px] text-muted-foreground">
                        {p.variants.length} variants
                      </span>
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
