"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  FlaskConical,
  Share2,
  Download,
  Crown,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Target,
  Sparkles,
  ChevronRight,
  TrendingUp,
  Quote,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Variant {
  name: string;
  description: string;
  participants: number;
  taskSuccess: number;
  timeOnTask: string;
  errorRate: number;
  susScore: number;
  isWinner: boolean;
  gradient: string;
  confidence: number;
}

interface ParticipantQuote {
  author: string;
  avatar: string;
  role: string;
  variant: string;
  body: string;
  rating: number;
}

interface Recommendation {
  title: string;
  detail: string;
  priority: "high" | "medium" | "low";
}

const GRADIENTS = [
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-1) 35%, var(--card)), color-mix(in oklch, var(--chart-4) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-2) 35%, var(--card)), color-mix(in oklch, var(--chart-3) 18%, var(--card)))",
  "linear-gradient(135deg, color-mix(in oklch, var(--chart-4) 35%, var(--card)), color-mix(in oklch, var(--chart-5) 18%, var(--card)))",
];

interface PrototypeDetail {
  id: string;
  name: string;
  project: string;
  testType: "usability" | "ab-test" | "first-click";
  description: string;
  status: "running" | "completed" | "draft";
  hypothesis: string;
  primaryMetric: string;
  startDate: string;
  endDate: string;
  variants: Variant[];
  quotes: ParticipantQuote[];
  recommendations: Recommendation[];
}

const PROTOTYPE_DETAILS: Record<string, PrototypeDetail> = {
  "pr-001": {
    id: "pr-001",
    name: "KYC: single screen vs progressive steps",
    project: "Atlas Onboarding",
    testType: "ab-test",
    description:
      "Compares a single long KYC form (variant A) against a 3-step progressive disclosure flow (variant B) on mobile. Hypothesis: progressive steps reduce abandonment on step 3 by surfacing one decision at a time.",
    status: "completed",
    hypothesis:
      "Progressive steps reduce abandonment on step 3 by ≥20% compared to a single long screen, while keeping completion time under 4 minutes.",
    primaryMetric: "KYC completion rate",
    startDate: "2026-05-15",
    endDate: "2026-06-12",
    variants: [
      {
        name: "A",
        description: "Single long screen — all fields on one page with scroll",
        participants: 21,
        taskSuccess: 58,
        timeOnTask: "3:48",
        errorRate: 18,
        susScore: 64,
        isWinner: false,
        gradient: GRADIENTS[0],
        confidence: 0,
      },
      {
        name: "B",
        description: "Progressive 3 steps — one decision per screen with progress dots",
        participants: 21,
        taskSuccess: 74,
        timeOnTask: "2:18",
        errorRate: 9,
        susScore: 82,
        isWinner: true,
        gradient: GRADIENTS[1],
        confidence: 99.8,
      },
    ],
    quotes: [
      {
        author: "Maya Chen",
        avatar: "https://i.pravatar.cc/80?img=23",
        role: "First-time customer, 27",
        variant: "B",
        body: "Loved the step-by-step — felt doable, not overwhelming. The progress dots helped me know exactly how much was left.",
        rating: 5,
      },
      {
        author: "Daniel Okoye",
        avatar: "https://i.pravatar.cc/80?img=33",
        role: "Returning user, 34",
        variant: "A",
        body: "The long form felt endless. I started second-guessing if I had filled something wrong because there was so much on screen at once.",
        rating: 2,
      },
      {
        author: "Priya Raman",
        avatar: "https://i.pravatar.cc/80?img=44",
        role: "First-time customer, 41",
        variant: "B",
        body: "Selfie step on its own page was great — I knew exactly what to focus on. Quick, clean, and the success state was reassuring.",
        rating: 5,
      },
    ],
    recommendations: [
      {
        title: "Ship Variant B as default",
        detail: "Variant B won on every metric (task success +16pp, SUS +18, error rate -9pp). Roll out at 100% with feature flag fallback.",
        priority: "high",
      },
      {
        title: "Tighten error recovery on selfie step",
        detail: "Even in Variant B, the selfie step had 2 false-negative rejections. Add explicit 'lighting too low' hint before capture.",
        priority: "medium",
      },
      {
        title: "Add estimated-time chip",
        detail: "Show 'About 3 minutes' next to progress dots to set expectations and reduce early abandonment.",
        priority: "low",
      },
    ],
  },
  "pr-002": {
    id: "pr-002",
    name: "Checkout: 1-page vs 2-page",
    project: "Northwind Checkout",
    testType: "ab-test",
    description:
      "Compares 3 checkout layouts: 1-page form (A), 2-page form (B), and 1-page with sticky summary (C). Measures completion and time-to-purchase.",
    status: "running",
    hypothesis:
      "Single-page with sticky summary (C) reduces checkout abandonment by ≥12pp while keeping time-on-task below 2 minutes.",
    primaryMetric: "Checkout completion",
    startDate: "2026-06-20",
    endDate: "2026-07-15",
    variants: [
      {
        name: "A",
        description: "Single page, no summary",
        participants: 22,
        taskSuccess: 62,
        timeOnTask: "2:08",
        errorRate: 14,
        susScore: 68,
        isWinner: false,
        gradient: GRADIENTS[0],
        confidence: 0,
      },
      {
        name: "B",
        description: "Two pages: shipping → payment",
        participants: 22,
        taskSuccess: 71,
        timeOnTask: "2:24",
        errorRate: 11,
        susScore: 73,
        isWinner: false,
        gradient: GRADIENTS[1],
        confidence: 0,
      },
      {
        name: "C",
        description: "Single page + sticky cart summary",
        participants: 20,
        taskSuccess: 81,
        timeOnTask: "1:48",
        errorRate: 7,
        susScore: 84,
        isWinner: true,
        gradient: GRADIENTS[2],
        confidence: 99.4,
      },
    ],
    quotes: [
      {
        author: "Sara Whitfield",
        avatar: "https://i.pravatar.cc/80?img=27",
        role: "Returning shopper, 38",
        variant: "C",
        body: "Loved seeing my cart total stay visible — no jumping back to double-check shipping cost mid-checkout.",
        rating: 5,
      },
      {
        author: "Marcus Lee",
        avatar: "https://i.pravatar.cc/80?img=14",
        role: "First-time buyer, 24",
        variant: "A",
        body: "The single page felt long but doable. I would have preferred seeing my total update live as I added the promo code.",
        rating: 3,
      },
      {
        author: "Elena Vasquez",
        avatar: "https://i.pravatar.cc/80?img=40",
        role: "Mobile-first shopper, 29",
        variant: "C",
        body: "Sticky summary was the deciding factor. I knew exactly what I was paying before tapping 'Place order'.",
        rating: 5,
      },
    ],
    recommendations: [
      {
        title: "Promote Variant C to 50% rollout",
        detail: "Variant C is winning at 99.4% confidence on completion. Roll to 50% to validate at scale before full ship.",
        priority: "high",
      },
      {
        title: "Test express-pay on C",
        detail: "Add Apple Pay / Google Pay buttons above the form on Variant C for an additional +5-8pp lift on mobile.",
        priority: "medium",
      },
      {
        title: "Improve promo-code visibility",
        detail: "Several participants on Variant A struggled to find the promo field. Surface it as a primary affordance, not a footer link.",
        priority: "medium",
      },
    ],
  },
};

// Fallback for any prototype id not in PROTOTYPE_DETAILS
const FALLBACK_DETAIL: PrototypeDetail = PROTOTYPE_DETAILS["pr-001"];

function getPrototype(id: string): PrototypeDetail | undefined {
  return PROTOTYPE_DETAILS[id] ?? FALLBACK_DETAIL;
}

const testTypeLabel: Record<string, string> = {
  usability: "Usability test",
  "ab-test": "A/B test",
  "first-click": "First-click test",
};

export default function PrototypeDetailPage() {
  const params = useParams<{ id: string }>();
  const prototype = getPrototype(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  if (!prototype) {
    return (
      <EmptyState
        icon={FlaskConical}
        title="Prototype not found"
        description="This prototype may have been archived, deleted, or never existed."
        action={{ label: "Back to prototypes", href: "/prototypes" }}
      />
    );
  }

  const winner = prototype.variants.find((v) => v.isWinner);
  const totalParticipants = prototype.variants.reduce((s, v) => s + v.participants, 0);
  const avgSuccess = Math.round(
    prototype.variants.reduce((s, v) => s + v.taskSuccess, 0) / prototype.variants.length
  );
  const avgSus = Math.round(
    prototype.variants.reduce((s, v) => s + v.susScore, 0) / prototype.variants.length
  );

  const handleShare = () => openShare(`/prototypes/${prototype.id}`, prototype.name);
  const handleExport = () => toast.success("Prototype results exported as PDF");

  return (
    <div>
      <PageHeader
        title={prototype.name}
        description={prototype.description}
        breadcrumbs={[
          { label: "Prototypes", href: "/prototypes" },
          { label: `#${prototype.id}` },
        ]}
        icon={<FlaskConical className="h-5 w-5" />}
        badge={
          <div className="flex items-center gap-1.5">
            <Badge variant="outline" className="text-[10px] capitalize">
              {testTypeLabel[prototype.testType]}
            </Badge>
            <Badge
              variant="outline"
              className={cn(
                "text-[10px] capitalize",
                prototype.status === "completed"
                  ? "bg-success/15 text-success border-success/20"
                  : prototype.status === "running"
                  ? "bg-info/15 text-info border-info/20"
                  : "bg-muted text-muted-foreground border-border"
              )}
            >
              {prototype.status}
            </Badge>
          </div>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleShare}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleExport}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            {winner && (
              <Button
                size="sm"
                className="rounded-full"
                onClick={() => toast.success(`Variant ${winner.name} promoted to production`)}
              >
                <Crown className="mr-2 h-3.5 w-3.5" /> Ship Variant {winner.name}
              </Button>
            )}
          </>
        }
      />

      {/* Hypothesis banner */}
      <Card className="rounded-2xl border-soft shadow-soft p-4 mb-4 bg-gradient-to-r from-surface-2/50 to-card">
        <div className="flex items-start gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary flex-shrink-0">
            <Target className="h-4 w-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                Hypothesis
              </span>
              <Badge variant="secondary" className="text-[10px]">
                {prototype.primaryMetric}
              </Badge>
            </div>
            <p className="text-sm text-ink leading-relaxed">
              {prototype.hypothesis}
            </p>
            <div className="flex flex-wrap gap-3 mt-2 text-[10px] text-muted-foreground">
              <span>Started {prototype.startDate}</span>
              <span>·</span>
              <span>Ended {prototype.endDate}</span>
              <span>·</span>
              <span>{totalParticipants} participants total</span>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main — variant comparison */}
        <div className="lg:col-span-2 space-y-4">
          {/* Variant comparison table */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <FlaskConical className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">
                  Variant comparison
                </h3>
              </div>
              <Badge variant="secondary" className="text-[10px]">
                {prototype.variants.length} variants
              </Badge>
            </div>

            <div className="overflow-x-auto -mx-2 px-2">
              <table className="w-full text-xs min-w-[640px]">
                <thead>
                  <tr className="border-b border-soft">
                    <th className="text-left text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Variant
                    </th>
                    <th className="text-left text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Preview
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Participants
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Task success
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Time / task
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Error rate
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      SUS score
                    </th>
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Winner
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {prototype.variants.map((v) => (
                    <tr
                      key={v.name}
                      className={cn(
                        "border-b border-soft last:border-0",
                        v.isWinner && "bg-success/5"
                      )}
                    >
                      <td className="px-2 py-3">
                        <div className="flex items-center gap-2">
                          <span
                            className={cn(
                              "flex h-7 w-7 items-center justify-center rounded-lg text-xs font-bold",
                              v.isWinner
                                ? "bg-success/15 text-success"
                                : "bg-surface-2 text-muted-foreground"
                            )}
                          >
                            {v.name}
                          </span>
                          <div className="min-w-0">
                            <div className="text-xs font-medium text-ink">
                              Variant {v.name}
                            </div>
                            <div className="text-[9px] text-muted-foreground truncate max-w-[140px]">
                              {v.description}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-2 py-3">
                        <div
                          className="h-10 w-16 rounded-md border border-soft"
                          style={{ background: v.gradient }}
                        />
                      </td>
                      <td className="px-2 py-3 text-center text-ink font-medium">
                        {v.participants}
                      </td>
                      <td className="px-2 py-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <div className="w-10 h-1.5 rounded-full bg-surface-2 overflow-hidden">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${v.taskSuccess}%`,
                                background:
                                  v.taskSuccess >= 75
                                    ? "var(--success)"
                                    : v.taskSuccess >= 60
                                    ? "var(--warning)"
                                    : "var(--friction)",
                              }}
                            />
                          </div>
                          <span className="text-xs font-semibold text-ink">
                            {v.taskSuccess}%
                          </span>
                        </div>
                      </td>
                      <td className="px-2 py-3 text-center text-ink font-medium">
                        {v.timeOnTask}
                      </td>
                      <td className="px-2 py-3 text-center">
                        <span
                          className={cn(
                            "text-xs font-semibold",
                            v.errorRate <= 10
                              ? "text-success"
                              : v.errorRate <= 15
                              ? "text-warning"
                              : "text-friction"
                          )}
                        >
                          {v.errorRate}%
                        </span>
                      </td>
                      <td className="px-2 py-3 text-center">
                        <span
                          className={cn(
                            "text-xs font-semibold",
                            v.susScore >= 80
                              ? "text-success"
                              : v.susScore >= 68
                              ? "text-info"
                              : "text-warning"
                          )}
                        >
                          {v.susScore}
                        </span>
                      </td>
                      <td className="px-2 py-3 text-center">
                        {v.isWinner ? (
                          <Badge
                            variant="outline"
                            className="text-[9px] bg-success/15 text-success border-success/20 gap-1"
                          >
                            <Crown className="h-2.5 w-2.5" /> Winner
                          </Badge>
                        ) : (
                          <span className="text-[9px] text-muted-foreground">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Confidence footer */}
            <div className="mt-3 pt-3 border-t border-soft flex flex-wrap items-center gap-3 text-[10px] text-muted-foreground">
              {prototype.variants.map((v) => (
                <span key={v.name}>
                  Variant {v.name} confidence:{" "}
                  <span className="text-ink font-semibold">
                    {v.confidence > 0 ? `${v.confidence}%` : "—"}
                  </span>
                </span>
              ))}
            </div>
          </Card>

          {/* Qualitative feedback */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                  <Quote className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">
                  Qualitative feedback
                </h3>
              </div>
              <Badge variant="secondary" className="text-[10px]">
                {prototype.quotes.length} quotes
              </Badge>
            </div>
            <div className="space-y-3">
              {prototype.quotes.map((q, i) => (
                <div
                  key={i}
                  className="flex gap-3 rounded-xl border border-soft p-3 hover:bg-accent/30 transition-colors"
                >
                  <Avatar className="h-9 w-9 ring-1 ring-soft flex-shrink-0">
                    <AvatarImage src={q.avatar} alt={q.author} />
                    <AvatarFallback>{q.author.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-medium text-ink">
                          {q.author}
                        </span>
                        <span className="text-[10px] text-muted-foreground">
                          {q.role}
                        </span>
                      </div>
                      <Badge variant="outline" className="text-[9px]">
                        Variant {q.variant}
                      </Badge>
                    </div>
                    <p className="text-xs text-ink leading-relaxed italic">
                      "{q.body}"
                    </p>
                    <div className="flex items-center gap-0.5 mt-2">
                      {Array.from({ length: 5 }).map((_, idx) => (
                        <span
                          key={idx}
                          className={cn(
                            "text-xs",
                            idx < q.rating ? "text-warning" : "text-muted-foreground/30"
                          )}
                        >
                          ★
                        </span>
                      ))}
                      <span className="text-[9px] text-muted-foreground ml-1.5">
                        {q.rating}/5
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right column — stats + recommendations */}
        <div className="space-y-4">
          {/* Summary stats */}
          <div className="grid grid-cols-2 gap-3">
            <StatCard
              label="Total participants"
              value={totalParticipants}
              icon={<FlaskConical className="h-4 w-4" />}
              accent="info"
            />
            <StatCard
              label="Avg task success"
              value={`${avgSuccess}%`}
              icon={<CheckCircle2 className="h-4 w-4" />}
              accent={avgSuccess >= 75 ? "success" : "warning"}
            />
            <StatCard
              label="Avg SUS score"
              value={avgSus}
              icon={<TrendingUp className="h-4 w-4" />}
              accent={avgSus >= 75 ? "success" : "warning"}
            />
            <StatCard
              label="Winning variant"
              value={winner ? `Variant ${winner.name}` : "TBD"}
              icon={<Crown className="h-4 w-4" />}
              accent="warning"
            />
          </div>

          {/* Winner callout */}
          {winner && (
            <Card className="rounded-2xl border-success/30 shadow-soft p-4 bg-gradient-to-br from-success/5 to-card">
              <div className="flex items-center gap-2 mb-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-success/15 text-success">
                  <Crown className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">
                  Winner: Variant {winner.name}
                </h3>
              </div>
              <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">
                {winner.description}. Confidence{" "}
                <span className="text-success font-semibold">
                  {winner.confidence}%
                </span>{" "}
                — significantly outperforms other variants on{" "}
                <span className="text-ink font-medium">
                  {prototype.primaryMetric.toLowerCase()}
                </span>
                .
              </p>
              <Button
                size="sm"
                className="w-full text-xs rounded-full"
                onClick={() => toast.success(`Variant ${winner.name} promoted to production`)}
              >
                <Sparkles className="mr-2 h-3.5 w-3.5" /> Promote to production
              </Button>
            </Card>
          )}

          {/* Recommendations */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Target className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Recommendations</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {prototype.recommendations.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {prototype.recommendations.map((r, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-soft p-2.5"
                >
                  <div className="flex items-start gap-2 mb-1">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[9px] capitalize flex-shrink-0",
                        r.priority === "high"
                          ? "bg-friction/15 text-friction border-friction/20"
                          : r.priority === "medium"
                          ? "bg-warning/15 text-warning border-warning/20"
                          : "bg-info/15 text-info border-info/20"
                      )}
                    >
                      {r.priority}
                    </Badge>
                    <span className="text-xs font-medium text-ink flex-1">
                      {r.title}
                    </span>
                  </div>
                  <div className="text-[10px] text-muted-foreground leading-relaxed ml-1">
                    {r.detail}
                  </div>
                </div>
              ))}
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
              onClick={() => toast.success("Recommendations sent to roadmap")}
            >
              Add all to roadmap
              <ChevronRight className="ml-1 h-3 w-3" />
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
