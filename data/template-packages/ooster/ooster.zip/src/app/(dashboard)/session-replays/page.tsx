"use client";

import * as React from "react";
import Link from "next/link";
import {
  PlayCircle,
  Play,
  Download,
  Smartphone,
  Monitor,
  Tablet,
  Flame,
  AlertTriangle,
  Clock,
  Users,
  MousePointerClick,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { FilterBar } from "@/components/common/filter-bar";
import { DataTable, type Column } from "@/components/tables/data-table";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SESSION_REPLAYS, type SessionReplay } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const DEVICE_OPTIONS = [
  { value: "all", label: "All devices" },
  { value: "desktop", label: "Desktop" },
  { value: "mobile", label: "Mobile" },
  { value: "tablet", label: "Tablet" },
];

const OUTCOME_OPTIONS = [
  { value: "all", label: "All outcomes" },
  { value: "completed", label: "Completed" },
  { value: "dropped", label: "Dropped" },
  { value: "rage", label: "Rage click" },
  { value: "error", label: "Error" },
];

const SEGMENT_OPTIONS = [
  { value: "all", label: "All segments" },
  { value: "Mobile", label: "Mobile" },
  { value: "Desktop", label: "Desktop" },
  { value: "Tablet", label: "Tablet" },
  { value: "First-time", label: "First-time" },
  { value: "Returning", label: "Returning" },
  { value: "Pro", label: "Pro" },
  { value: "Casual", label: "Casual" },
  { value: "Researcher", label: "Researcher" },
];

// Gather unique tags from the dataset
const TAG_OPTIONS = [
  { value: "all", label: "All tags" },
  ...Array.from(new Set(SESSION_REPLAYS.flatMap((s) => s.tags))).map((t) => ({
    value: t,
    label: t,
  })),
];

function DeviceIcon({ device }: { device: SessionReplay["device"] }) {
  if (device === "mobile") return <Smartphone className="h-3.5 w-3.5" />;
  if (device === "tablet") return <Tablet className="h-3.5 w-3.5" />;
  return <Monitor className="h-3.5 w-3.5" />;
}

function OutcomeBadge({ outcome }: { outcome: SessionReplay["outcome"] }) {
  const map: Record<SessionReplay["outcome"], string> = {
    completed: "bg-success/15 text-success border-success/20",
    dropped: "bg-muted text-muted-foreground border-border",
    rage: "bg-friction/15 text-friction border-friction/20",
    error: "bg-friction/15 text-friction border-friction/20",
  };
  return (
    <Badge
      variant="outline"
      className={cn("border text-[10px] font-medium capitalize", map[outcome])}
    >
      {outcome}
    </Badge>
  );
}

export default function SessionReplaysPage() {
  const [search, setSearch] = React.useState("");
  const [device, setDevice] = React.useState("all");
  const [outcome, setOutcome] = React.useState("all");
  const [segment, setSegment] = React.useState("all");
  const [tag, setTag] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return SESSION_REPLAYS.filter((s) => {
      if (search) {
        const q = search.toLowerCase();
        const matches =
          s.user.toLowerCase().includes(q) ||
          s.device.toLowerCase().includes(q) ||
          s.browser.toLowerCase().includes(q) ||
          s.project.toLowerCase().includes(q);
        if (!matches) return false;
      }
      if (device !== "all" && s.device !== device) return false;
      if (outcome !== "all" && s.outcome !== outcome) return false;
      if (segment !== "all" && !s.segments.includes(segment)) return false;
      if (tag !== "all" && !s.tags.includes(tag)) return false;
      return true;
    });
  }, [search, device, outcome, segment, tag]);

  const clearFilters = () => {
    setSearch("");
    setDevice("all");
    setOutcome("all");
    setSegment("all");
    setTag("all");
  };

  // Aggregate stats from the full dataset (not filtered) for stable KPIs
  const totalSessions = SESSION_REPLAYS.length;
  const rageSessions = SESSION_REPLAYS.filter((s) => s.rageClicks > 0).length;
  const errorSessions = SESSION_REPLAYS.filter((s) => s.errors > 0).length;

  const durations = SESSION_REPLAYS.map((s) => {
    const [m, sec] = s.duration.split(":").map(Number);
    return m * 60 + sec;
  });
  const avgSec =
    durations.reduce((a, b) => a + b, 0) / (durations.length || 1);
  const avgDur = `${Math.floor(avgSec / 60)}:${String(
    Math.round(avgSec % 60)
  ).padStart(2, "0")}`;

  const columns: Column<SessionReplay>[] = [
    {
      key: "user",
      header: "User",
      cell: (row) => (
        <Link
          href={`/session-replays/${row.id}`}
          className="flex items-center gap-2 group"
        >
          <Avatar className="h-7 w-7 ring-1 ring-soft">
            <AvatarImage src={row.avatar} alt={row.user} />
            <AvatarFallback>{row.user.slice(-2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="font-medium text-ink group-hover:text-primary transition-colors text-xs truncate">
              {row.user}
            </div>
            <div className="text-[10px] text-muted-foreground truncate max-w-[160px]">
              {row.project}
            </div>
          </div>
        </Link>
      ),
      sortAccessor: (row) => row.user,
      sortable: true,
    },
    {
      key: "device",
      header: "Device",
      cell: (row) => (
        <div className="flex items-center gap-1.5 text-xs">
          <DeviceIcon device={row.device} />
          <span className="capitalize">{row.device}</span>
        </div>
      ),
      sortAccessor: (row) => row.device,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "duration",
      header: "Duration",
      cell: (row) => <span className="text-xs font-mono">{row.duration}</span>,
      sortAccessor: (row) => {
        const [m, s] = row.duration.split(":").map(Number);
        return m * 60 + s;
      },
      sortable: true,
    },
    {
      key: "events",
      header: "Events",
      cell: (row) => <span className="text-xs tabular-nums">{row.events}</span>,
      sortAccessor: (row) => row.events,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "rage",
      header: "Rage clicks",
      cell: (row) =>
        row.rageClicks > 0 ? (
          <Badge
            variant="outline"
            className="text-[10px] border-friction/20 bg-friction/10 text-friction"
          >
            {row.rageClicks}
          </Badge>
        ) : (
          <span className="text-xs text-muted-foreground">0</span>
        ),
      sortAccessor: (row) => row.rageClicks,
      sortable: true,
    },
    {
      key: "dead",
      header: "Dead clicks",
      cell: (row) =>
        row.deadClicks > 0 ? (
          <Badge
            variant="outline"
            className="text-[10px] border-warning/20 bg-warning/10 text-warning"
          >
            {row.deadClicks}
          </Badge>
        ) : (
          <span className="text-xs text-muted-foreground">0</span>
        ),
      sortAccessor: (row) => row.deadClicks,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "errors",
      header: "Errors",
      cell: (row) =>
        row.errors > 0 ? (
          <Badge
            variant="outline"
            className="text-[10px] border-friction/20 bg-friction/10 text-friction"
          >
            {row.errors}
          </Badge>
        ) : (
          <span className="text-xs text-muted-foreground">0</span>
        ),
      sortAccessor: (row) => row.errors,
      sortable: true,
      hideOnMobile: true,
    },
    {
      key: "tags",
      header: "Tags",
      cell: (row) => (
        <div className="flex flex-wrap gap-1">
          {row.tags.slice(0, 2).map((t) => (
            <Badge key={t} variant="secondary" className="text-[10px]">
              {t}
            </Badge>
          ))}
          {row.tags.length > 2 && (
            <Badge variant="secondary" className="text-[10px]">
              +{row.tags.length - 2}
            </Badge>
          )}
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "outcome",
      header: "Outcome",
      cell: (row) => <OutcomeBadge outcome={row.outcome} />,
    },
    {
      key: "actions",
      header: "",
      cell: (row) => (
        <Button asChild size="sm" variant="ghost" className="h-8 px-2 text-xs">
          <Link href={`/session-replays/${row.id}`}>
            <Play className="h-3.5 w-3.5 mr-1" /> Play
          </Link>
        </Button>
      ),
      width: "80px",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Session Replays"
        description="Watch real user sessions. Filter by friction signals, errors, and outcomes."
        breadcrumbs={[{ label: "Replays" }]}
        icon={<PlayCircle className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {SESSION_REPLAYS.length} sessions
          </Badge>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={() =>
              toast.success("Export queued", {
                description: "CSV will be emailed when ready.",
              })
            }
          >
            <Download className="mr-2 h-3.5 w-3.5" /> Export
          </Button>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total sessions"
          value={totalSessions}
          icon={<Users className="h-4 w-4" />}
          accent="info"
          trend={{ value: 12.4, direction: "up", good: true }}
          sublabel="vs last week"
        />
        <StatCard
          label="Avg duration"
          value={avgDur}
          icon={<Clock className="h-4 w-4" />}
          sublabel="across all sessions"
        />
        <StatCard
          label="Rage click sessions"
          value={rageSessions}
          icon={<Flame className="h-4 w-4" />}
          accent={rageSessions > 0 ? "friction" : "default"}
          sublabel={`${Math.round((rageSessions / totalSessions) * 100)}% of total`}
        />
        <StatCard
          label="Sessions with errors"
          value={errorSessions}
          icon={<AlertTriangle className="h-4 w-4" />}
          accent={errorSessions > 0 ? "friction" : "default"}
          sublabel={`${Math.round((errorSessions / totalSessions) * 100)}% of total`}
        />
      </div>

      <FilterBar
        className="mb-4"
        search={{
          value: search,
          onChange: setSearch,
          placeholder: "Search user, device, browser, project…",
        }}
        selects={[
          {
            label: "Device",
            value: device,
            onChange: setDevice,
            options: DEVICE_OPTIONS,
          },
          {
            label: "Outcome",
            value: outcome,
            onChange: setOutcome,
            options: OUTCOME_OPTIONS,
          },
          {
            label: "Segment",
            value: segment,
            onChange: setSegment,
            options: SEGMENT_OPTIONS,
          },
          {
            label: "Tags",
            value: tag,
            onChange: setTag,
            options: TAG_OPTIONS,
          },
        ]}
        onClear={clearFilters}
      />

      {loading ? (
        <LoadingSkeleton variant="table" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={PlayCircle}
          title="No sessions match your filters"
          description="Try clearing filters or widening your search to surface more replays."
          action={{ label: "Clear filters", onClick: clearFilters }}
          secondaryAction={{ label: "Browse all replays", href: "/session-replays" }}
        />
      ) : (
        <DataTable
          data={filtered}
          columns={columns}
          getRowId={(row) => row.id}
          pageSize={10}
          emptyTitle="No sessions found"
          emptyDescription="Try adjusting your search or filters."
        />
      )}

      {/* Helper note */}
      {!loading && filtered.length > 0 && (
        <Card className="mt-4 rounded-2xl border-soft shadow-soft p-3 flex items-start gap-2 bg-surface-2/40">
          <MousePointerClick className="h-3.5 w-3.5 text-muted-foreground mt-0.5 flex-shrink-0" />
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            Replays retain DOM mutations, network requests, and console errors for 30 days.
            Click <span className="font-medium text-ink">Play</span> on any row to scrub through the session, view friction markers, and tag insights for your team.
          </p>
        </Card>
      )}
    </div>
  );
}
