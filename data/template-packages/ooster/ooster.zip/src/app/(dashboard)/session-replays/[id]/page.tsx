"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import {
  PlayCircle,
  Play,
  Pause,
  Share2,
  Tag as TagIcon,
  Plus,
  Save,
  SkipBack,
  SkipForward,
  RotateCcw,
  MousePointerClick,
  Flame,
  AlertTriangle,
  XCircle,
  Smartphone,
  Monitor,
  Tablet,
  Globe,
  Clock,
  Navigation,
  Users,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/empty-state";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { getReplay, type SessionReplay } from "@/lib/data";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { ScreenMockup } from "@/components/common/screen-mockup";

// ----------------------------------------------------------------------------
// Helpers
// ----------------------------------------------------------------------------

interface ReplayEvent {
  time: number; // seconds from start
  type: "rage" | "dead" | "error" | "click" | "navigate";
  label: string;
}

function buildEvents(replay: SessionReplay): ReplayEvent[] {
  const events: ReplayEvent[] = [];
  const [m, s] = replay.duration.split(":").map(Number);
  const total = m * 60 + s;

  const rageTargets = [
    "checkout submit button",
    "primary CTA banner",
    "navigation menu item",
    "form continue button",
    "filter apply button",
  ];
  const deadTargets = [
    "decorative footer icon",
    "non-interactive image",
    "disabled form field",
    "static label text",
  ];
  const errorMessages = [
    "Network request failed (POST /api/checkout)",
    "Form validation error: email format invalid",
    "Unhandled promise rejection in cart sync",
  ];
  const navTargets = [
    `/${replay.project.toLowerCase().replace(/\s+/g, "-")}`,
    "/products",
    "/cart",
    "/checkout",
    "/account",
  ];

  // Deterministic distribution across the timeline
  for (let i = 0; i < replay.rageClicks; i++) {
    const t = Math.round((total / (replay.rageClicks + 2)) * (i + 1));
    events.push({
      time: t,
      type: "rage",
      label: `Rage click on ${rageTargets[i % rageTargets.length]}`,
    });
  }
  for (let i = 0; i < replay.deadClicks; i++) {
    const t = Math.round((total / (replay.deadClicks + 3)) * (i + 1.5));
    events.push({
      time: t,
      type: "dead",
      label: `Dead click on ${deadTargets[i % deadTargets.length]}`,
    });
  }
  for (let i = 0; i < replay.errors; i++) {
    const t = Math.round((total / (replay.errors + 4)) * (i + 2));
    events.push({
      time: t,
      type: "error",
      label: errorMessages[i % errorMessages.length],
    });
  }
  // Navigation events sprinkled across the session
  events.push({
    time: 1,
    type: "navigate",
    label: `Navigated to ${navTargets[0]}`,
  });
  const midPoint = Math.round(total * 0.4);
  if (midPoint > 2) {
    events.push({
      time: midPoint,
      type: "navigate",
      label: `Navigated to ${navTargets[2 % navTargets.length]}`,
    });
  }
  // A regular click event near the middle
  if (total > 8) {
    events.push({
      time: Math.round(total * 0.55),
      type: "click",
      label: "Clicked primary CTA",
    });
  }
  return events.sort((a, b) => a.time - b.time);
}

function fmt(sec: number): string {
  const safe = Math.max(0, Math.floor(sec));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

const SPEEDS = [0.5, 1, 2] as const;

// ----------------------------------------------------------------------------
// Small subcomponents
// ----------------------------------------------------------------------------

function OutcomeBadge({ outcome }: { outcome: SessionReplay["outcome"] }) {
  const map: Record<SessionReplay["outcome"], string> = {
    completed: "bg-success/15 text-success border-success/20",
    dropped: "bg-muted text-muted-foreground border-border",
    rage: "bg-friction/15 text-friction border-friction/20",
    error: "bg-friction/15 text-friction border-friction/20",
  };
  return (
    <Badge
      variant="outline"
      className={cn("border text-[10px] font-medium capitalize", map[outcome])}
    >
      {outcome}
    </Badge>
  );
}

function DeviceIcon({ device }: { device: SessionReplay["device"] }) {
  if (device === "mobile") return <Smartphone className="h-3.5 w-3.5" />;
  if (device === "tablet") return <Tablet className="h-3.5 w-3.5" />;
  return <Monitor className="h-3.5 w-3.5" />;
}

function EventIcon({ type }: { type: ReplayEvent["type"] }) {
  const cls = "h-3.5 w-3.5 flex-shrink-0 mt-0.5";
  if (type === "rage") return <Flame className={cn(cls, "text-friction")} />;
  if (type === "dead")
    return <MousePointerClick className={cn(cls, "text-warning")} />;
  if (type === "error") return <XCircle className={cn(cls, "text-friction")} />;
  if (type === "navigate")
    return <Navigation className={cn(cls, "text-success")} />;
  return <MousePointerClick className={cn(cls, "text-info")} />;
}

function InfoRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        {icon}
        <span className="text-xs">{label}</span>
      </div>
      <span className="text-xs text-ink font-medium text-right truncate max-w-[60%]">
        {value}
      </span>
    </div>
  );
}

function FrictionRow({
  icon,
  label,
  value,
  severity,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  severity: "success" | "warning" | "friction";
}) {
  const colors: Record<typeof severity, string> = {
    success: "text-success bg-success/10",
    warning: "text-warning bg-warning/10",
    friction: "text-friction bg-friction/10",
  };
  const valueColors: Record<typeof severity, string> = {
    success: "text-success",
    warning: "text-warning",
    friction: "text-friction",
  };
  return (
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-2">
        <div
          className={cn(
            "flex h-7 w-7 items-center justify-center rounded-lg",
            colors[severity]
          )}
        >
          {icon}
        </div>
        <span className="text-xs text-ink">{label}</span>
      </div>
      <span
        className={cn(
          "text-sm font-semibold tabular-nums",
          valueColors[severity]
        )}
      >
        {value}
      </span>
    </div>
  );
}

// ----------------------------------------------------------------------------
// Main page
// ----------------------------------------------------------------------------

export default function ReplayDetailPage() {
  const params = useParams<{ id: string }>();
  const replay = getReplay(params.id);
  const openShare = useModals((s) => s.openShare);

  const [m, s] = replay ? replay.duration.split(":").map(Number) : [0, 0];
  const total = m * 60 + s;

  const [playing, setPlaying] = React.useState(false);
  const [current, setCurrent] = React.useState(0);
  const [speed, setSpeed] = React.useState<number>(1);
  const [tags, setTags] = React.useState<string[]>(replay?.tags ?? []);
  const [newTag, setNewTag] = React.useState("");
  const [notes, setNotes] = React.useState("");

  const events = React.useMemo(
    () => (replay ? buildEvents(replay) : []),
    [replay]
  );

  // Playback tick — advances current time when playing
  React.useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setCurrent((c) => {
        const next = c + 0.5 * speed;
        if (next >= total) {
          setPlaying(false);
          return total;
        }
        return next;
      });
    }, 500);
    return () => clearInterval(id);
  }, [playing, speed, total]);

  if (!replay) {
    return (
      <EmptyState
        icon={PlayCircle}
        title="Replay not found"
        description="This session may have expired, been deleted, or never existed."
        action={{ label: "Back to replays", href: "/session-replays" }}
      />
    );
  }

  const addTag = () => {
    const t = newTag.trim();
    if (!t) return;
    if (tags.includes(t)) {
      toast.error("Tag already exists", { description: `"${t}" is already on this session.` });
      return;
    }
    setTags((prev) => [...prev, t]);
    setNewTag("");
    toast.success("Tag added", { description: `"${t}" attached to this session.` });
  };

  const removeTag = (t: string) => {
    setTags((prev) => prev.filter((x) => x !== t));
    toast.success("Tag removed", { description: `"${t}" removed from this session.` });
  };

  const skip = (delta: number) => {
    setCurrent((c) => Math.max(0, Math.min(total, c + delta)));
  };

  const reset = () => {
    setCurrent(0);
    setPlaying(false);
  };

  const togglePlay = () => {
    if (current >= total) setCurrent(0);
    setPlaying((p) => !p);
  };

  // Show events that have already "happened" in playback, newest first
  const visibleEvents = events
    .filter((e) => e.time <= current)
    .slice()
    .reverse();

  const projectSlug = replay.project.toLowerCase().replace(/\s+/g, "-");
  const urlBar = `https://${projectSlug}.ooster.app/checkout`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
    >
      <PageHeader
        title={`Session — ${replay.user}`}
        description={`${replay.project} · started ${replay.startedAt}`}
        breadcrumbs={[
          { label: "Replays", href: "/session-replays" },
          { label: replay.user },
        ]}
        icon={<PlayCircle className="h-5 w-5" />}
        badge={<OutcomeBadge outcome={replay.outcome} />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() =>
                openShare(`/session-replays/${replay.id}`, `Session ${replay.user}`)
              }
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() =>
                toast.success("Issue draft created", {
                  description: `Linked to ${replay.id} — find it in Issues.`,
                })
              }
            >
              <AlertTriangle className="mr-2 h-3.5 w-3.5" /> Create issue
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => {
                if (!tags.includes("needs-review")) {
                  setTags((prev) => [...prev, "needs-review"]);
                  toast.success("Quick tag added", {
                    description: "Tagged as 'needs-review'.",
                  });
                } else {
                  toast.info("Already tagged", {
                    description: "This session is already marked 'needs-review'.",
                  });
                }
              }}
            >
              <TagIcon className="mr-2 h-3.5 w-3.5" /> Tag session
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* ============ LEFT COLUMN — playback ============ */}
        <div className="lg:col-span-2 space-y-4">
          {/* Mock playback screen */}
          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden card-hover">
            {/* Browser chrome */}
            <div className="flex items-center gap-2 px-3 py-2 bg-surface-2 border-b border-soft">
              <div className="flex gap-1.5 flex-shrink-0">
                <span className="h-3 w-3 rounded-full bg-friction/60" />
                <span className="h-3 w-3 rounded-full bg-warning/60" />
                <span className="h-3 w-3 rounded-full bg-success/60" />
              </div>
              <div className="flex-1 mx-2 min-w-0">
                <div className="flex items-center gap-1.5 bg-card border border-soft rounded-full px-3 py-1 max-w-md mx-auto">
                  <Globe className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                  <span className="text-[10px] text-muted-foreground truncate">
                    {urlBar}
                  </span>
                </div>
              </div>
              <div className="text-[10px] text-muted-foreground hidden sm:block flex-shrink-0">
                {replay.browser}
              </div>
            </div>

            {/* 16:9 mock screen content */}
            <div className="relative aspect-video bg-surface-2 overflow-hidden">
              {/* Browser-chrome mockup of a checkout flow fills the playback area */}
              <ScreenMockup variant="checkout" />

              {/* Mock cursor — visible while playing */}
              {playing && (
                <div
                  className="absolute pointer-events-none transition-all duration-500 ease-linear z-30"
                  style={{
                    left: `${30 + ((current * 13) % 40)}%`,
                    top: `${35 + ((current * 7) % 30)}%`,
                  }}
                >
                  <MousePointerClick className="h-5 w-5 text-info drop-shadow-sm" />
                </div>
              )}

              {/* Live indicator */}
              <div className="absolute top-3 right-3 flex items-center gap-1.5 bg-card/80 backdrop-blur-sm border border-soft rounded-full px-2 py-0.5">
                <span
                  className={cn(
                    "h-1.5 w-1.5 rounded-full",
                    playing ? "bg-friction animate-pulse" : "bg-muted-foreground"
                  )}
                />
                <span className="text-[10px] text-muted-foreground">
                  {playing ? "Playing" : "Paused"}
                </span>
              </div>

              {/* Click burst overlay when rage events happen near current time */}
              {events.some(
                (e) =>
                  e.type === "rage" && Math.abs(e.time - current) < 0.6
              ) && (
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                    <Flame className="h-10 w-10 text-friction/70 animate-ping" />
                  </div>
                </div>
              )}
            </div>

            {/* Playback controls */}
            <div className="p-3 border-t border-soft space-y-3">
              {/* Timeline with event markers */}
              <div className="relative h-6 flex items-center">
                <input
                  type="range"
                  min={0}
                  max={total}
                  step={0.1}
                  value={current}
                  onChange={(e) => setCurrent(Number(e.target.value))}
                  aria-label="Timeline scrubber"
                  className="w-full h-1.5 accent-primary cursor-pointer relative z-10"
                />
                {/* Event marker overlay — pointer-events-none so clicks pass through to the range input */}
                <div className="absolute inset-0 pointer-events-none z-20">
                  {events.map((e, i) => (
                    <div
                      key={i}
                      className={cn(
                        "absolute top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-card shadow-soft",
                        e.type === "rage" && "bg-friction",
                        e.type === "dead" && "bg-warning",
                        e.type === "error" && "bg-friction",
                        e.type === "click" && "bg-info",
                        e.type === "navigate" && "bg-success"
                      )}
                      style={{ left: `${(e.time / total) * 100}%` }}
                      title={`${fmt(e.time)} · ${e.label}`}
                    />
                  ))}
                </div>
              </div>

              {/* Controls row */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => skip(-10)}
                  title="Back 10s"
                  aria-label="Back 10 seconds"
                >
                  <SkipBack className="h-4 w-4" />
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  className="h-9 w-9 p-0 rounded-full"
                  onClick={togglePlay}
                  aria-label={playing ? "Pause" : "Play"}
                >
                  {playing ? (
                    <Pause className="h-4 w-4" />
                  ) : (
                    <motion.span
                      initial={{ scale: 1 }}
                      animate={{ scale: [1, 1.05, 1] }}
                      transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                      className="inline-flex"
                    >
                      <Play className="h-4 w-4 ml-0.5" />
                    </motion.span>
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => skip(10)}
                  title="Forward 10s"
                  aria-label="Forward 10 seconds"
                >
                  <SkipForward className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={reset}
                  title="Restart"
                  aria-label="Restart playback"
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
                <div className="text-xs font-mono text-muted-foreground ml-1 tabular-nums">
                  {fmt(current)} / {fmt(total)}
                </div>

                {/* Legend */}
                <div className="hidden md:flex items-center gap-2 ml-2 text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-friction" /> Rage
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-warning" /> Dead
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-info" /> Click
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-success" /> Nav
                  </span>
                </div>

                {/* Speed selector */}
                <div className="ml-auto flex items-center gap-1 bg-surface-2 rounded-lg p-0.5">
                  {SPEEDS.map((sp) => (
                    <button
                      key={sp}
                      onClick={() => setSpeed(sp)}
                      className={cn(
                        "px-2 h-6 rounded-md text-[11px] font-medium transition-colors",
                        speed === sp
                          ? "bg-card text-ink shadow-soft"
                          : "text-muted-foreground hover:text-ink"
                      )}
                    >
                      {sp}x
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          {/* Event log */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-ink">Event log</h3>
              <Badge variant="secondary" className="text-[10px]">
                {events.length} events · {visibleEvents.length} played
              </Badge>
            </div>
            <div className="space-y-0.5 max-h-72 overflow-y-auto pr-1">
              {visibleEvents.length === 0 ? (
                <div className="text-xs text-muted-foreground text-center py-8 px-4">
                  Press play to surface events as they occur during playback.
                  Drag the scrubber to jump to a specific moment.
                </div>
              ) : (
                visibleEvents.map((e, i) => (
                  <motion.div
                    key={i}
                    className="flex items-start gap-2 py-1.5 px-2 -mx-2 rounded-md hover:bg-accent/30 transition-colors"
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
                  >
                    <span className="text-[10px] font-mono text-muted-foreground w-12 mt-0.5 tabular-nums">
                      {fmt(e.time)}
                    </span>
                    <EventIcon type={e.type} />
                    <span className="text-xs text-ink flex-1 leading-relaxed">
                      {e.label}
                    </span>
                  </motion.div>
                ))
              )}
            </div>
          </Card>
        </div>

        {/* ============ RIGHT COLUMN — session meta ============ */}
        <div className="space-y-4">
          {/* Session info */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <h3 className="text-sm font-semibold text-ink mb-3">Session info</h3>
            <div className="flex items-center gap-3 mb-3 pb-3 border-b border-soft">
              <Avatar className="h-10 w-10 ring-1 ring-soft">
                <AvatarImage src={replay.avatar} alt={replay.user} />
                <AvatarFallback>{replay.user.slice(-2)}</AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <div className="text-sm font-medium text-ink truncate">
                  {replay.user}
                </div>
                <div className="text-[10px] text-muted-foreground truncate">
                  {replay.project}
                </div>
              </div>
            </div>
            <dl className="space-y-2">
              <InfoRow
                icon={<DeviceIcon device={replay.device} />}
                label="Device"
                value={<span className="capitalize">{replay.device}</span>}
              />
              <InfoRow
                icon={<Globe className="h-3.5 w-3.5" />}
                label="Browser"
                value={replay.browser}
              />
              <InfoRow
                icon={<Clock className="h-3.5 w-3.5" />}
                label="Started"
                value={replay.startedAt}
              />
              <InfoRow
                icon={<PlayCircle className="h-3.5 w-3.5" />}
                label="Duration"
                value={replay.duration}
              />
              <InfoRow
                icon={<MousePointerClick className="h-3.5 w-3.5" />}
                label="Events"
                value={replay.events}
              />
              <InfoRow
                icon={<Users className="h-3.5 w-3.5" />}
                label="Segments"
                value={replay.segments.join(", ")}
              />
            </dl>
          </Card>

          {/* Friction signals */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <h3 className="text-sm font-semibold text-ink mb-3">
              Friction signals
            </h3>
            <div className="space-y-2.5">
              <FrictionRow
                icon={<Flame className="h-4 w-4" />}
                label="Rage clicks"
                value={replay.rageClicks}
                severity={replay.rageClicks > 0 ? "friction" : "success"}
              />
              <FrictionRow
                icon={<MousePointerClick className="h-4 w-4" />}
                label="Dead clicks"
                value={replay.deadClicks}
                severity={replay.deadClicks > 0 ? "warning" : "success"}
              />
              <FrictionRow
                icon={<AlertTriangle className="h-4 w-4" />}
                label="Errors"
                value={replay.errors}
                severity={replay.errors > 0 ? "friction" : "success"}
              />
            </div>
            {replay.outcome !== "completed" && (
              <div className="mt-3 pt-3 border-t border-soft text-[11px] text-muted-foreground leading-relaxed">
                Outcome flagged as{" "}
                <span className="font-medium text-ink capitalize">
                  {replay.outcome}
                </span>
                . Consider filing an issue or attaching a research note.
              </div>
            )}
          </Card>

          {/* Tags card */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <h3 className="text-sm font-semibold text-ink mb-3">Tags</h3>
            <div className="flex flex-wrap gap-1.5 mb-3 min-h-[24px]">
              {tags.length === 0 ? (
                <span className="text-xs text-muted-foreground">
                  No tags yet — add one below.
                </span>
              ) : (
                tags.map((t) => (
                  <Badge
                    key={t}
                    variant="secondary"
                    className="text-[10px] gap-1 pr-1.5"
                  >
                    {t}
                    <button
                      onClick={() => removeTag(t)}
                      className="ml-0.5 text-muted-foreground hover:text-friction transition-colors"
                      aria-label={`Remove tag ${t}`}
                    >
                      <XCircle className="h-3 w-3" />
                    </button>
                  </Badge>
                ))
              )}
            </div>
            <div className="flex gap-1.5">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addTag();
                  }
                }}
                placeholder="Add tag…"
                className="h-8 text-xs"
              />
              <Button
                size="sm"
                variant="outline"
                className="h-8 w-8 p-0"
                onClick={addTag}
                aria-label="Add tag"
              >
                <Plus className="h-3.5 w-3.5" />
              </Button>
            </div>
          </Card>

          {/* Reviewer notes */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 card-hover">
            <h3 className="text-sm font-semibold text-ink mb-3">
              Reviewer notes
            </h3>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Note friction points, hypotheses, follow-ups for the design team…"
              rows={4}
              className="text-xs resize-none"
            />
            <Button
              size="sm"
              className="mt-2 w-full"
              onClick={() =>
                toast.success("Notes saved", {
                  description: "Visible to your team on this replay.",
                })
              }
            >
              <Save className="mr-1.5 h-3.5 w-3.5" /> Save notes
            </Button>
          </Card>
        </div>
      </div>
    </motion.div>
  );
}
