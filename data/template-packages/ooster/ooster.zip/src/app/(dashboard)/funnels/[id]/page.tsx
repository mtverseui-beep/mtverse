"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Filter,
  Share2,
  Download,
  TrendingDown,
  TrendingUp,
  Layers,
  Users,
  Calendar,
  Smartphone,
  Monitor,
  Tablet,
  FlaskConical,
  ChevronRight,
  Lightbulb,
  Sparkles,
  CheckCircle2,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useModals } from "@/hooks/use-modals";
import { JOURNEYS, INSIGHTS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface FunnelDetail {
  id: string;
  name: string;
  project: string;
  description: string;
  status: "active" | "completed" | "draft";
  steps: {
    id: string;
    name: string;
    users: number;
    conversion: number;
    dropOff: number;
    avgTime: string;
  }[];
  segments: {
    name: string;
    icon: "mobile" | "desktop" | "tablet";
    perStep: number[];
  }[];
  updatedAt: string;
}

// Helper to build a funnel from a JOURNEY
function funnelFromJourney(j: typeof JOURNEYS[number], id: string): FunnelDetail {
  const segBase = (factor: number) =>
    j.steps.map((s) => Math.round(s.conversion * factor));
  return {
    id,
    name: j.name,
    project: j.project,
    description: `End-to-end funnel mapped from the ${j.persona} persona journey across ${j.steps.length} critical steps.`,
    status: j.status === "active" ? "active" : "completed",
    steps: j.steps.map((s) => ({
      id: s.id,
      name: s.name,
      users: s.users,
      conversion: s.conversion,
      dropOff: s.dropOff,
      avgTime: s.avgTime,
    })),
    segments: [
      { name: "Mobile", icon: "mobile", perStep: segBase(0.86) },
      { name: "Desktop", icon: "desktop", perStep: segBase(1.12) },
      { name: "Tablet", icon: "tablet", perStep: segBase(0.95) },
    ],
    updatedAt: j.updatedAt,
  };
}

const J0 = JOURNEYS[0];
const J1 = JOURNEYS[1];

const MOCK_FUNNELS: FunnelDetail[] = [
  funnelFromJourney(J0, "f-001"),
  funnelFromJourney(J1, "f-002"),
  {
    id: "f-003",
    name: "Sign-up → Pro upgrade",
    project: "Helix Prototype",
    description:
      "Conversion funnel from new account sign-up through Pro plan upgrade — 6 steps across pricing, trial activation, and payment.",
    status: "active",
    steps: [
      { id: "fs-1", name: "Sign-up complete", users: 6400, conversion: 100, dropOff: 0, avgTime: "1:18" },
      { id: "fs-2", name: "Dashboard first-visit", users: 5800, conversion: 91, dropOff: 9, avgTime: "0:42" },
      { id: "fs-3", name: "Pricing page view", users: 3120, conversion: 54, dropOff: 46, avgTime: "1:34" },
      { id: "fs-4", name: "Trial activation", users: 1840, conversion: 59, dropOff: 41, avgTime: "2:08" },
      { id: "fs-5", name: "Trial → upgrade CTA", users: 1380, conversion: 75, dropOff: 25, avgTime: "0:48" },
      { id: "fs-6", name: "Pro plan purchased", users: 1152, conversion: 84, dropOff: 16, avgTime: "1:52" },
    ],
    segments: [
      { name: "Mobile", icon: "mobile", perStep: [100, 88, 48, 38, 71, 80] },
      { name: "Desktop", icon: "desktop", perStep: [100, 94, 62, 78, 79, 89] },
      { name: "Tablet", icon: "tablet", perStep: [100, 90, 54, 49, 75, 83] },
    ],
    updatedAt: "2026-07-01",
  },
  {
    id: "f-004",
    name: "Habit create → 7-day streak",
    project: "Cadence Mobile",
    description:
      "Funnel from first habit creation through 7-day streak completion — measures onboarding-to-retention conversion across mobile.",
    status: "active",
    steps: [
      { id: "fs-1", name: "Habit created", users: 4200, conversion: 100, dropOff: 0, avgTime: "1:24" },
      { id: "fs-2", name: "Reminder setup", users: 2772, conversion: 66, dropOff: 34, avgTime: "0:58" },
      { id: "fs-3", name: "First check-in", users: 2108, conversion: 76, dropOff: 24, avgTime: "—" },
      { id: "fs-4", name: "7-day streak", users: 1722, conversion: 82, dropOff: 18, avgTime: "7 days" },
    ],
    segments: [
      { name: "Mobile", icon: "mobile", perStep: [100, 64, 78, 84] },
      { name: "Desktop", icon: "desktop", perStep: [100, 72, 71, 76] },
      { name: "Tablet", icon: "tablet", perStep: [100, 68, 74, 80] },
    ],
    updatedAt: "2026-06-30",
  },
  {
    id: "f-005",
    name: "Search → Booking confirmed",
    project: "Voyage Booking",
    description:
      "End-to-end funnel from initial search to confirmed booking — currently in draft while date-selection redesign is being tested.",
    status: "draft",
    steps: [
      { id: "fs-1", name: "Search performed", users: 9800, conversion: 100, dropOff: 0, avgTime: "0:42" },
      { id: "fs-2", name: "Results viewed", users: 7448, conversion: 76, dropOff: 24, avgTime: "1:08" },
      { id: "fs-3", name: "Date selection", users: 3128, conversion: 42, dropOff: 58, avgTime: "2:34" },
      { id: "fs-4", name: "Guest info entered", users: 1876, conversion: 60, dropOff: 40, avgTime: "1:58" },
      { id: "fs-5", name: "Booking confirmed", users: 882, conversion: 47, dropOff: 53, avgTime: "2:12" },
    ],
    segments: [
      { name: "Mobile", icon: "mobile", perStep: [100, 74, 38, 56, 44] },
      { name: "Desktop", icon: "desktop", perStep: [100, 82, 52, 68, 54] },
      { name: "Tablet", icon: "tablet", perStep: [100, 78, 45, 60, 47] },
    ],
    updatedAt: "2026-06-25",
  },
];

function getFunnel(id: string): FunnelDetail | undefined {
  return MOCK_FUNNELS.find((f) => f.id === id);
}

const segmentIcon: Record<string, React.ElementType> = {
  mobile: Smartphone,
  desktop: Monitor,
  tablet: Tablet,
};

function barColorFor(dropOff: number) {
  if (dropOff >= 40) return "var(--friction)";
  if (dropOff >= 20) return "var(--warning)";
  return "var(--success)";
}

function formatUsers(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return `${n}`;
}

export default function FunnelDetailPage() {
  const params = useParams<{ id: string }>();
  const funnel = getFunnel(params.id);
  const openShare = useModals((s) => s.openShare);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  if (!funnel) {
    return (
      <EmptyState
        icon={Filter}
        title="Funnel not found"
        description="This funnel may have been archived or never existed."
        action={{ label: "Back to funnels", href: "/funnels" }}
      />
    );
  }

  const startUsers = funnel.steps[0]?.users ?? 1;
  const endUsers = funnel.steps[funnel.steps.length - 1]?.users ?? 0;
  const overallConv = Math.round((endUsers / startUsers) * 100);
  const totalDropOff = 100 - overallConv;
  const biggestDropStep = funnel.steps.reduce(
    (max, s) => (s.dropOff > max.dropOff ? s : max),
    funnel.steps[0]
  );

  // Pull top 3 friction insights for this project
  const frictionInsights = INSIGHTS.filter(
    (i) =>
      i.projectName === funnel.project ||
      i.category === "friction" ||
      i.category === "conversion"
  )
    .slice(0, 3);

  const handleShare = () => openShare(`/funnels/${funnel.id}`, funnel.name);
  const handleExport = () => toast.success("Funnel analysis exported as PDF");

  return (
    <div>
      <PageHeader
        title={funnel.name}
        description={funnel.description}
        breadcrumbs={[
          { label: "Funnels", href: "/funnels" },
          { label: `#${funnel.id}` },
        ]}
        icon={<Filter className="h-5 w-5" />}
        badge={
          <Badge
            variant="outline"
            className={cn(
              "text-[10px] capitalize",
              funnel.status === "active"
                ? "bg-success/15 text-success border-success/20"
                : funnel.status === "completed"
                ? "bg-info/15 text-info border-info/20"
                : "bg-muted text-muted-foreground border-border"
            )}
          >
            {funnel.status}
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleShare}
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleExport}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main — funnel visualization + segment comparison */}
        <div className="lg:col-span-2 space-y-4">
          {/* Vertical funnel chart */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <Filter className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">
                  Funnel visualization
                </h3>
              </div>
              <Badge variant="secondary" className="text-[10px]">
                {funnel.steps.length} steps
              </Badge>
            </div>

            <div className="space-y-2.5">
              {funnel.steps.map((step, idx) => {
                const widthPct = Math.max(
                  18,
                  Math.round((step.users / startUsers) * 100)
                );
                const color = barColorFor(step.dropOff);
                const isLast = idx === funnel.steps.length - 1;
                return (
                  <div key={step.id}>
                    <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                      <span className="text-ink font-medium text-xs">
                        {idx + 1}. {step.name}
                      </span>
                      <span className="flex items-center gap-3">
                        <span className="inline-flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          <span className="text-ink font-semibold">{formatUsers(step.users)}</span>
                        </span>
                        <span className="text-ink font-semibold">{step.conversion}%</span>
                      </span>
                    </div>
                    <div className="relative h-9 rounded-xl bg-surface-2 overflow-hidden">
                      <div
                        className="h-full rounded-xl flex items-center justify-end pr-3 transition-all"
                        style={{
                          width: `${widthPct}%`,
                          background: `linear-gradient(90deg, color-mix(in oklch, ${color} 75%, transparent), ${color})`,
                        }}
                      >
                        <span className="text-[10px] font-semibold text-white">
                          {step.avgTime}
                        </span>
                      </div>
                    </div>
                    {!isLast && (
                      <div className="flex items-center justify-center gap-2 my-1 text-[10px] text-muted-foreground">
                        <TrendingDown className="h-3 w-3 text-friction" />
                        <span>
                          Drop-off:{" "}
                          <span className="text-friction font-semibold">
                            {step.dropOff}%
                          </span>
                        </span>
                        <span>·</span>
                        <span>
                          {formatUsers(step.users - funnel.steps[idx + 1].users)} users lost
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Bottom totals */}
            <div className="mt-4 pt-3 border-t border-soft flex flex-wrap items-center gap-4 text-[10px]">
              <div className="inline-flex items-center gap-1.5">
                <CheckCircle2 className="h-3 w-3 text-success" />
                <span className="text-muted-foreground">Overall:</span>
                <span className="text-success font-semibold">{overallConv}% conversion</span>
              </div>
              <div className="inline-flex items-center gap-1.5">
                <TrendingDown className="h-3 w-3 text-friction" />
                <span className="text-muted-foreground">Total drop-off:</span>
                <span className="text-friction font-semibold">{totalDropOff}%</span>
              </div>
              <div className="inline-flex items-center gap-1.5">
                <Users className="h-3 w-3 text-info" />
                <span className="text-muted-foreground">Cohort:</span>
                <span className="text-ink font-semibold">{formatUsers(startUsers)} → {formatUsers(endUsers)}</span>
              </div>
            </div>
          </Card>

          {/* Segment comparison */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                  <Layers className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">
                  Conversion by segment
                </h3>
              </div>
              <Badge variant="secondary" className="text-[10px]">
                {funnel.segments.length} segments
              </Badge>
            </div>

            <div className="overflow-x-auto -mx-2 px-2">
              <table className="w-full text-xs min-w-[480px]">
                <thead>
                  <tr className="border-b border-soft">
                    <th className="text-left text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Segment
                    </th>
                    {funnel.steps.map((s, i) => (
                      <th
                        key={s.id}
                        className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2"
                      >
                        Step {i + 1}
                        <div className="text-[9px] text-muted-foreground/70 font-normal truncate max-w-[80px] mx-auto">
                          {s.name}
                        </div>
                      </th>
                    ))}
                    <th className="text-center text-[10px] font-medium text-muted-foreground px-2 py-2">
                      Overall
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {funnel.segments.map((seg) => {
                    const SegIcon = segmentIcon[seg.icon];
                    const overall = seg.perStep[seg.perStep.length - 1];
                    return (
                      <tr key={seg.name} className="border-b border-soft last:border-0">
                        <td className="px-2 py-2.5">
                          <div className="flex items-center gap-1.5">
                            <SegIcon className="h-3.5 w-3.5 text-muted-foreground" />
                            <span className="text-xs font-medium text-ink">
                              {seg.name}
                            </span>
                          </div>
                        </td>
                        {seg.perStep.map((p, i) => (
                          <td key={i} className="px-2 py-2.5 text-center">
                            <div className="text-xs font-semibold text-ink">
                              {p}%
                            </div>
                            <div className="h-1 w-12 mx-auto mt-1 rounded-full bg-surface-2 overflow-hidden">
                              <div
                                className="h-full rounded-full"
                                style={{
                                  width: `${p}%`,
                                  background:
                                    p >= 60
                                      ? "var(--success)"
                                      : p >= 30
                                      ? "var(--warning)"
                                      : "var(--friction)",
                                }}
                              />
                            </div>
                          </td>
                        ))}
                        <td className="px-2 py-2.5 text-center">
                          <Badge
                            variant="outline"
                            className={cn(
                              "text-[10px]",
                              overall >= 40
                                ? "bg-success/15 text-success border-success/20"
                                : overall >= 20
                                ? "bg-warning/15 text-warning border-warning/20"
                                : "bg-friction/15 text-friction border-friction/20"
                            )}
                          >
                            {overall}%
                          </Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>

          {/* Step detail breakdown */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-warning">
                <TrendingDown className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                Biggest friction step
              </h3>
            </div>
            <div className="rounded-xl border border-friction/30 bg-friction/5 p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-semibold text-ink">
                  {biggestDropStep.name}
                </div>
                <Badge
                  variant="outline"
                  className="text-[10px] bg-friction/15 text-friction border-friction/20"
                >
                  -{biggestDropStep.dropOff}% drop
                </Badge>
              </div>
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div>
                  <div className="text-[10px] text-muted-foreground">Users</div>
                  <div className="text-sm font-semibold text-ink">
                    {formatUsers(biggestDropStep.users)}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground">Conversion</div>
                  <div className="text-sm font-semibold text-ink">
                    {biggestDropStep.conversion}%
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground">Avg time</div>
                  <div className="text-sm font-semibold text-ink">
                    {biggestDropStep.avgTime}
                  </div>
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground mt-3 leading-relaxed">
                This step accounts for the largest single-step drop in the funnel.
                Consider running a moderated usability test or A/B prototype to
                isolate the root cause before redesigning.
              </p>
            </div>
          </Card>
        </div>

        {/* Right — filters, insights, A/B test CTA */}
        <div className="space-y-4">
          {/* Filters */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Calendar className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Filters</h3>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1 block">
                  Date range
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm" className="h-8 text-xs justify-start rounded-lg" onClick={() => toast.info("Date range picker opened")}>
                    <Calendar className="mr-2 h-3 w-3" /> 2026-06-01
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 text-xs justify-start rounded-lg" onClick={() => toast.info("Date range picker opened")}>
                    <Calendar className="mr-2 h-3 w-3" /> 2026-07-01
                  </Button>
                </div>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1 block">
                  Segment
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {["All", "Mobile", "Desktop", "Tablet"].map((s, i) => (
                    <button
                      key={s}
                      onClick={() => toast.message(`Segment: ${s}`)}
                      className={cn(
                        "rounded-full border px-2.5 py-1 text-[10px] font-medium transition-all",
                        i === 0
                          ? "border-primary/30 bg-primary/10 text-ink"
                          : "border-soft text-muted-foreground hover:bg-accent/30 hover:text-ink"
                      )}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1 block">
                  Device
                </label>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="h-8 flex-1 text-xs rounded-lg" onClick={() => toast.message("Filtering by Mobile")}>
                    <Smartphone className="mr-2 h-3 w-3" /> Mobile
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 flex-1 text-xs rounded-lg" onClick={() => toast.message("Filtering by Desktop")}>
                    <Monitor className="mr-2 h-3 w-3" /> Desktop
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 flex-1 text-xs rounded-lg" onClick={() => toast.message("Filtering by Tablet")}>
                    <Tablet className="mr-2 h-3 w-3" /> Tablet
                  </Button>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full text-xs rounded-full"
                onClick={() => toast.success("Filters applied to funnel")}
              >
                Apply filters
              </Button>
            </div>
          </Card>

          {/* Insights */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Lightbulb className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                Friction insights
              </h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {frictionInsights.length}
              </Badge>
            </div>
            <div className="space-y-2">
              {frictionInsights.map((ins) => (
                <Link
                  key={ins.id}
                  href={`/insights/${ins.id}`}
                  className="block rounded-xl border border-soft p-2.5 hover:bg-accent/30 transition-colors group"
                >
                  <div className="flex items-start gap-2">
                    <div
                      className={cn(
                        "h-1.5 w-1.5 rounded-full mt-1.5 flex-shrink-0",
                        ins.severity === "critical"
                          ? "bg-friction"
                          : ins.severity === "high"
                          ? "bg-warning"
                          : ins.severity === "medium"
                          ? "bg-info"
                          : "bg-success"
                      )}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium text-ink group-hover:text-primary transition-colors line-clamp-2">
                        {ins.title}
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        Impact {ins.impact} · {ins.projectName}
                      </div>
                    </div>
                    <ChevronRight className="h-3 w-3 text-muted-foreground group-hover:text-ink flex-shrink-0 mt-1" />
                  </div>
                </Link>
              ))}
              {frictionInsights.length === 0 && (
                <div className="text-[11px] text-muted-foreground py-3 text-center">
                  No friction insights linked to this funnel yet.
                </div>
              )}
            </div>
          </Card>

          {/* A/B test CTA */}
          <Card className="rounded-2xl border-soft shadow-soft p-4 bg-gradient-to-br from-surface-2/50 to-card">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <FlaskConical className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">
                Test a fix
              </h3>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">
              Launch an A/B test targeting the biggest drop step to validate your
              fix before shipping to all users.
            </p>
            <Button
              size="sm"
              className="w-full text-xs rounded-full"
              onClick={() => toast.success("A/B test scaffolded from funnel")}
            >
              <Sparkles className="mr-2 h-3.5 w-3.5" /> Create A/B test
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
