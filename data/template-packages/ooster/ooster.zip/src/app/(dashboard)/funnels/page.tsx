"use client";

import * as React from "react";
import Link from "next/link";
import {
  Filter,
  Plus,
  Download,
  ChevronRight,
  TrendingDown,
  TrendingUp,
  Layers,
  Users,
  Activity,
  Target,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { JOURNEYS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface MockFunnel {
  id: string;
  name: string;
  project: string;
  steps: number;
  conversion: number;
  biggestDropStep: string;
  biggestDropPct: number;
  status: "active" | "completed" | "draft";
  trend: { value: number; direction: "up" | "down"; good: boolean };
}

// Derive 5 funnels — first 2 from real JOURNEYS, plus 3 mock funnels for variety
const EXTRA_FUNNELS: MockFunnel[] = [
  {
    id: "f-003",
    name: "Sign-up → Pro upgrade",
    project: "Helix Prototype",
    steps: 6,
    conversion: 18,
    biggestDropStep: "Pricing page",
    biggestDropPct: 52,
    status: "active",
    trend: { value: 5.4, direction: "up", good: true },
  },
  {
    id: "f-004",
    name: "Habit create → 7-day streak",
    project: "Cadence Mobile",
    steps: 4,
    conversion: 41,
    biggestDropStep: "Reminder setup",
    biggestDropPct: 34,
    status: "active",
    trend: { value: 2.1, direction: "up", good: true },
  },
  {
    id: "f-005",
    name: "Search → Booking confirmed",
    project: "Voyage Booking",
    steps: 5,
    conversion: 9,
    biggestDropStep: "Date selection",
    biggestDropPct: 58,
    status: "draft",
    trend: { value: 1.6, direction: "down", good: false },
  },
];

const FUNNELS: MockFunnel[] = [
  ...JOURNEYS.map((j, i) => ({
    id: `f-00${i + 1}`,
    name: j.name,
    project: j.project,
    steps: j.steps.length,
    conversion: j.completionRate,
    biggestDropStep:
      j.steps.reduce(
        (max, s) => (s.dropOff > max.dropOff ? s : max),
        j.steps[0]
      ).name,
    biggestDropPct: Math.max(...j.steps.map((s) => s.dropOff)),
    status: j.status as "active" | "completed" | "draft",
    trend:
      i === 0
        ? { value: 4.2, direction: "up" as const, good: true }
        : { value: 1.8, direction: "down" as const, good: true },
  })),
  ...EXTRA_FUNNELS,
];

const STATUS_FILTERS = [
  { label: "All statuses", value: "all" },
  { label: "Active", value: "active" },
  { label: "Completed", value: "completed" },
  { label: "Draft", value: "draft" },
];

const PROJECT_FILTERS = [
  { label: "All projects", value: "all" },
  ...Array.from(new Set(FUNNELS.map((f) => f.project))).map((p) => ({
    label: p,
    value: p,
  })),
];

const statusColor = (status: string) =>
  status === "active"
    ? "bg-success/15 text-success border-success/20"
    : status === "completed"
    ? "bg-info/15 text-info border-info/20"
    : "bg-muted text-muted-foreground border-border";

export default function FunnelsPage() {
  const [search, setSearch] = React.useState("");
  const [status, setStatus] = React.useState("all");
  const [project, setProject] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return FUNNELS.filter((f) => {
      if (search && !f.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (status !== "all" && f.status !== status) return false;
      if (project !== "all" && f.project !== project) return false;
      return true;
    });
  }, [search, status, project]);

  const clearFilters = () => {
    setSearch("");
    setStatus("all");
    setProject("all");
  };

  // KPIs
  const total = FUNNELS.length;
  const avgConversion = Math.round(
    FUNNELS.reduce((s, f) => s + f.conversion, 0) / FUNNELS.length
  );
  const activeCount = FUNNELS.filter((f) => f.status === "active").length;
  const worstDrop = Math.max(...FUNNELS.map((f) => f.biggestDropPct));

  const columns: Column<MockFunnel>[] = [
    {
      key: "name",
      header: "Funnel",
      sortable: true,
      sortAccessor: (r) => r.name,
      cell: (r) => (
        <Link href={`/funnels/${r.id}`} className="group block min-w-0">
          <div className="text-sm font-medium text-ink group-hover:text-primary transition-colors line-clamp-1">
            {r.name}
          </div>
          <div className="text-[10px] text-muted-foreground">{r.project}</div>
        </Link>
      ),
    },
    {
      key: "project",
      header: "Project",
      sortable: true,
      sortAccessor: (r) => r.project,
      hideOnMobile: true,
      cell: (r) => (
        <Badge variant="outline" className="text-[10px]">
          {r.project}
        </Badge>
      ),
    },
    {
      key: "steps",
      header: "Steps",
      sortable: true,
      sortAccessor: (r) => r.steps,
      hideOnMobile: true,
      cell: (r) => (
        <span className="text-xs text-ink font-medium">{r.steps}</span>
      ),
    },
    {
      key: "conversion",
      header: "Conversion",
      sortable: true,
      sortAccessor: (r) => r.conversion,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className="w-16 h-1.5 rounded-full bg-surface-2 overflow-hidden">
            <div
              className="h-full rounded-full"
              style={{
                width: `${r.conversion}%`,
                background:
                  r.conversion >= 30
                    ? "var(--success)"
                    : r.conversion >= 15
                    ? "var(--warning)"
                    : "var(--friction)",
              }}
            />
          </div>
          <span className="text-xs font-semibold text-ink">{r.conversion}%</span>
        </div>
      ),
    },
    {
      key: "biggestDrop",
      header: "Biggest drop",
      sortable: true,
      sortAccessor: (r) => r.biggestDropPct,
      hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <TrendingDown className="h-3 w-3 text-friction" />
          <div>
            <div className="text-[10px] text-ink font-medium truncate max-w-[140px]">
              {r.biggestDropStep}
            </div>
            <div className="text-[10px] text-friction">-{r.biggestDropPct}%</div>
          </div>
        </div>
      ),
    },
    {
      key: "trend",
      header: "Trend",
      sortable: true,
      sortAccessor: (r) => r.trend.value,
      hideOnMobile: true,
      cell: (r) => (
        <span
          className={cn(
            "inline-flex items-center gap-0.5 text-[10px] font-medium",
            r.trend.good ? "text-success" : "text-friction"
          )}
        >
          {r.trend.direction === "up" ? (
            <TrendingUp className="h-3 w-3" />
          ) : (
            <TrendingDown className="h-3 w-3" />
          )}
          {r.trend.value}%
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => (
        <Badge variant="outline" className={cn("text-[10px] capitalize", statusColor(r.status))}>
          {r.status}
        </Badge>
      ),
    },
    {
      key: "actions",
      header: "",
      width: "40px",
      cell: (r) => (
        <Link
          href={`/funnels/${r.id}`}
          className="flex items-center justify-end text-muted-foreground hover:text-ink transition-colors"
        >
          <ChevronRight className="h-4 w-4" />
        </Link>
      ),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Funnels"
        description="Conversion funnels with step-by-step drop-off analysis"
        icon={<Filter className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {FUNNELS.length} funnels tracked
          </Badge>
        }
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => toast.success("Funnels exported to CSV")}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Export
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={() => toast.message("Open funnel builder")}
            >
              <Plus className="mr-2 h-3.5 w-3.5" /> New funnel
            </Button>
          </>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Total funnels"
          value={total}
          icon={<Filter className="h-4 w-4" />}
          accent="info"
          sublabel={`${activeCount} active`}
        />
        <StatCard
          label="Avg conversion"
          value={`${avgConversion}%`}
          icon={<Target className="h-4 w-4" />}
          accent={avgConversion >= 30 ? "success" : "warning"}
          trend={{ value: 3.4, direction: "up", good: true }}
          sublabel="vs last sprint"
        />
        <StatCard
          label="Avg steps / funnel"
          value={Math.round(FUNNELS.reduce((s, f) => s + f.steps, 0) / FUNNELS.length)}
          icon={<Layers className="h-4 w-4" />}
          accent="default"
          sublabel="median 5 steps"
        />
        <StatCard
          label="Worst drop-off"
          value={`${worstDrop}%`}
          icon={<TrendingDown className="h-4 w-4" />}
          accent="friction"
          sublabel="biggest single-step loss"
        />
      </div>

      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search funnels…",
          }}
          selects={[
            {
              label: "Status",
              value: status,
              onChange: setStatus,
              options: STATUS_FILTERS,
            },
            {
              label: "Project",
              value: project,
              onChange: setProject,
              options: PROJECT_FILTERS,
            },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="table" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Filter}
          title="No funnels match your filters"
          description="Try adjusting search or filters, or create a new funnel to track conversion step-by-step."
          action={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <DataTable<MockFunnel>
          data={filtered}
          columns={columns}
          getRowId={(r) => r.id}
          onRowClick={(r) => {
            window.location.href = `/funnels/${r.id}`;
          }}
        />
      )}

      {/* Insights row */}
      <Card className="rounded-2xl border-soft shadow-soft p-4 mt-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-warning">
            <Activity className="h-4 w-4" />
          </div>
          <h3 className="text-sm font-semibold text-ink">
            Funnel insights
          </h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-xl border border-soft p-3">
            <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-1">
              <TrendingDown className="h-3 w-3 text-friction" /> Biggest overall drop
            </div>
            <div className="text-sm font-semibold text-ink">
              Date selection — 58%
            </div>
            <div className="text-[10px] text-muted-foreground mt-0.5">
              Voyage Booking · Search → Booking
            </div>
          </div>
          <div className="rounded-xl border border-soft p-3">
            <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-1">
              <TrendingUp className="h-3 w-3 text-success" /> Most improved
            </div>
            <div className="text-sm font-semibold text-ink">
              Checkout completion +19pp
            </div>
            <div className="text-[10px] text-muted-foreground mt-0.5">
              After autocomplete A/B test shipped
            </div>
          </div>
          <div className="rounded-xl border border-soft p-3">
            <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-1">
              <Users className="h-3 w-3 text-info" /> Most traffic
            </div>
            <div className="text-sm font-semibold text-ink">
              Browse → Purchase · 8.2k entries
            </div>
            <div className="text-[10px] text-muted-foreground mt-0.5">
              Northwind Checkout · 11% conversion
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
