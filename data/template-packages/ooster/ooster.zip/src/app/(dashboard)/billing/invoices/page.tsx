"use client";

import * as React from "react";
import {
  FileText,
  Download,
  Eye,
  Search,
  DollarSign,
  Clock,
  XCircle,
  ArrowLeft,
  Receipt,
  CreditCard,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { INVOICES, type Invoice } from "@/lib/data";
import Link from "next/link";
import { toast } from "sonner";

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Paid", value: "paid" },
  { label: "Pending", value: "pending" },
  { label: "Failed", value: "failed" },
  { label: "Refunded", value: "refunded" },
];

const RANGE_OPTIONS: FilterOption[] = [
  { label: "Last 30 days", value: "30d" },
  { label: "Last 90 days", value: "90d" },
  { label: "Year to date", value: "ytd" },
  { label: "All time", value: "all" },
];

export default function InvoicesPage() {
  const [search, setSearch] = React.useState("");
  const [status, setStatus] = React.useState("all");
  const [range, setRange] = React.useState("ytd");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const filtered = React.useMemo(() => {
    return INVOICES.filter((inv) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !inv.number.toLowerCase().includes(q) &&
          !inv.customer.toLowerCase().includes(q) &&
          !inv.plan.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (status !== "all" && inv.status !== status) return false;
      return true;
    });
  }, [search, status]);

  const clearFilters = () => {
    setSearch("");
    setStatus("all");
    setRange("ytd");
  };

  const totalPaidYTD = INVOICES.filter((i) => i.status === "paid").reduce(
    (acc, i) => acc + i.amount,
    0
  );
  const pendingAmount = INVOICES.filter((i) => i.status === "pending").reduce(
    (acc, i) => acc + i.amount,
    0
  );
  const failedCount = INVOICES.filter((i) => i.status === "failed").length;

  const handleDownloadAll = () => {
    toast.success("Preparing ZIP archive", {
      description: `${filtered.length} invoices will be emailed to billing@halberg.co.`,
    });
  };

  const handleDownload = (inv: Invoice) => {
    toast.success(`Downloading ${inv.number}.pdf`);
  };

  const handleView = (inv: Invoice) => {
    toast.info(`Opening ${inv.number}`, {
      description: "Invoice preview will open in a new tab.",
    });
  };

  const columns: Column<Invoice>[] = [
    {
      key: "number",
      header: "Invoice #",
      cell: (row) => (
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary flex-shrink-0">
            <Receipt className="h-3.5 w-3.5" />
          </div>
          <code className="text-[11px] font-mono text-ink">{row.number}</code>
        </div>
      ),
      sortable: true,
      sortAccessor: (row) => row.number,
    },
    {
      key: "customer",
      header: "Customer",
      cell: (row) => <span className="text-xs text-ink">{row.customer}</span>,
      sortable: true,
      sortAccessor: (row) => row.customer,
      hideOnMobile: true,
    },
    {
      key: "date",
      header: "Date",
      cell: (row) => <span className="text-[11px] text-muted-foreground">{row.date}</span>,
      sortable: true,
      sortAccessor: (row) => row.date,
    },
    {
      key: "plan",
      header: "Plan",
      cell: (row) => (
        <Badge variant="secondary" className="text-[10px]">
          {row.plan}
        </Badge>
      ),
      hideOnMobile: true,
    },
    {
      key: "amount",
      header: "Amount",
      cell: (row) => (
        <span className="text-xs font-semibold text-ink">
          ${row.amount.toLocaleString()}.00
        </span>
      ),
      sortable: true,
      sortAccessor: (row) => row.amount,
    },
    {
      key: "status",
      header: "Status",
      cell: (row) => <StatusBadge status={row.status} />,
    },
    {
      key: "method",
      header: "Payment method",
      cell: (row) => (
        <span className="text-[11px] text-muted-foreground flex items-center gap-1">
          <CreditCard className="h-3 w-3" />
          {row.method}
        </span>
      ),
      hideOnMobile: true,
    },
    {
      key: "actions",
      header: "Actions",
      cell: (row) => (
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 rounded-full"
            onClick={() => handleView(row)}
            aria-label="View invoice"
          >
            <Eye className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 rounded-full"
            onClick={() => handleDownload(row)}
            aria-label="Download invoice PDF"
          >
            <Download className="h-3.5 w-3.5" />
          </Button>
        </div>
      ),
      className: "text-right",
    },
  ];

  return (
    <div>
      <PageHeader
        title="Invoices"
        description="Download past invoices and receipts"
        icon={<FileText className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Billing", href: "/billing" },
          { label: "Invoices" },
        ]}
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="rounded-full">
              <Link href="/billing">
                <ArrowLeft className="mr-2 h-3.5 w-3.5" /> Back to billing
              </Link>
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={handleDownloadAll}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Download all
            </Button>
          </>
        }
      />

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
        <StatCard
          label="Total paid YTD"
          value={`$${totalPaidYTD.toLocaleString()}`}
          icon={<DollarSign className="h-4 w-4" />}
          accent="success"
          sublabel={`${INVOICES.filter((i) => i.status === "paid").length} invoices`}
        />
        <StatCard
          label="Pending amount"
          value={`$${pendingAmount.toLocaleString()}`}
          icon={<Clock className="h-4 w-4" />}
          accent="warning"
          sublabel="awaiting payment"
        />
        <StatCard
          label="Failed invoices"
          value={failedCount}
          icon={<XCircle className="h-4 w-4" />}
          accent="friction"
          sublabel="need attention"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search by invoice #, customer, plan…",
          }}
          selects={[
            {
              label: "Status",
              value: status,
              onChange: setStatus,
              options: STATUS_OPTIONS,
            },
            {
              label: "Date range",
              value: range,
              onChange: setRange,
              options: RANGE_OPTIONS,
            },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="table" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="No invoices found"
          description="Try adjusting your filters or date range. Invoices appear here within 24 hours of billing."
          action={{ label: "Clear filters", onClick: clearFilters }}
        />
      ) : (
        <DataTable
          data={filtered}
          columns={columns}
          pageSize={10}
          getRowId={(row) => row.id}
          emptyTitle="No invoices match"
          emptyDescription="Adjust filters or clear them to see all invoices."
        />
      )}

      {/* Footer note */}
      <Card className="rounded-2xl border-soft shadow-soft p-3 mt-4">
        <div className="flex items-start gap-2.5">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info flex-shrink-0">
            <FileText className="h-3.5 w-3.5" />
          </div>
          <div className="text-[11px] text-muted-foreground leading-relaxed">
            <span className="font-medium text-ink">Need a custom statement?</span> Download
            quarterly or annual statements from the{" "}
            <Link href="/billing" className="text-info hover:underline">
              billing overview
            </Link>{" "}
            page, or contact{" "}
            <a href="mailto:billing@ooster.io" className="text-info hover:underline">
              billing@ooster.io
            </a>{" "}
            for tax receipts and EU VAT-compliant documents.
          </div>
        </div>
      </Card>
    </div>
  );
}
