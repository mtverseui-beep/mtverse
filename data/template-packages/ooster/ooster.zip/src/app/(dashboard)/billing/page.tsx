"use client";

import * as React from "react";
import Link from "next/link";
import {
  CreditCard,
  Download,
  Check,
  ArrowUpRight,
  Users,
  FolderKanban,
  HardDrive,
  DollarSign,
  Receipt,
  Mail,
  Pencil,
  Trash2,
  Plus,
  Sparkles,
  Calendar,
  ChevronRight,
  Wallet,
  Building2,
  ShieldCheck,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { INVOICES } from "@/lib/data";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface PlanFeature {
  name: string;
  free: boolean | string;
  pro: boolean | string;
  team: boolean | string;
  enterprise: boolean | string;
}

const PLAN_COMPARISON: PlanFeature[] = [
  { name: "Projects", free: "3", pro: "15", team: "Unlimited", enterprise: "Unlimited" },
  { name: "Seats", free: "1", pro: "5", team: "20", enterprise: "50+" },
  { name: "Session replays / mo", free: "100", pro: "2,500", team: "15,000", enterprise: "Unlimited" },
  { name: "Heatmaps", free: false, pro: true, team: true, enterprise: true },
  { name: "Custom reports", free: false, pro: true, team: true, enterprise: true },
  { name: "A/B testing", free: false, pro: false, team: true, enterprise: true },
  { name: "SSO / SAML", free: false, pro: false, team: false, enterprise: true },
  { name: "Audit logs", free: false, pro: false, team: "30 days", enterprise: "Unlimited" },
  { name: "Data export", free: "CSV", pro: "CSV", team: "CSV + JSON", enterprise: "All formats" },
  { name: "Priority support", free: false, pro: false, team: true, enterprise: "Dedicated CSM" },
];

const PLAN_TIERS = [
  { name: "Free", price: "$0" },
  { name: "Pro", price: "$120" },
  { name: "Team", price: "$580" },
  { name: "Enterprise", price: "$2,400", highlight: true },
];

const PAYMENT_HISTORY = [
  { id: "p1", date: "Jun 1, 2026", amount: "$2,400.00", method: "Visa •• 4242", status: "paid" as const },
  { id: "p2", date: "May 1, 2026", amount: "$2,400.00", method: "Visa •• 4242", status: "paid" as const },
  { id: "p3", date: "Apr 1, 2026", amount: "$2,400.00", method: "Visa •• 4242", status: "paid" as const },
  { id: "p4", date: "Mar 1, 2026", amount: "$2,400.00", method: "Wire transfer", status: "paid" as const },
];

export default function BillingPage() {
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const recentInvoices = INVOICES.slice(0, 6);

  const handleUpgrade = () => {
    toast.success("Upgrade options opened", {
      description: "Compare plans and switch instantly in the subscription manager.",
    });
  };

  const handleEditPayment = () => {
    toast.info("Opening payment method editor", {
      description: "You'll be redirected to our secure payment provider (Stripe).",
    });
  };

  const handleRemovePayment = () => {
    openConfirm({
      title: "Remove this payment method?",
      description:
        "Future invoices will fail until you add a new method. We recommend adding a replacement first.",
      onConfirm: () => {
        toast.success("Payment method removed");
      },
    });
  };

  const handleDownloadStatement = () => {
    toast.success("Statement queued for download", {
      description: "Your Q2 2026 statement will be emailed to billing@halberg.co.",
    });
  };

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  return (
    <div>
      <PageHeader
        title="Billing"
        description="Manage your subscription, payment methods, and invoices"
        icon={<CreditCard className="h-5 w-5" />}
        actions={
          <Button
            asChild
            size="sm"
            className="rounded-full"
          >
            <Link href="/billing/subscription">
              <ArrowUpRight className="mr-2 h-3.5 w-3.5" /> Manage subscription
            </Link>
          </Button>
        }
      />

      {/* Current plan hero card */}
      <Card className="rounded-2xl border-soft shadow-soft p-5 mb-4 overflow-hidden relative">
        <div className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-primary/5" />
        <div className="absolute -right-6 -bottom-12 h-32 w-32 rounded-full bg-primary/5" />
        <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground flex-shrink-0">
              <Sparkles className="h-7 w-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <h2 className="text-xl font-semibold text-ink">Enterprise</h2>
                <Badge variant="outline" className="text-[10px] border-primary/30 bg-primary/10 text-ink">
                  Current plan
                </Badge>
              </div>
              <div className="flex items-baseline gap-1.5 mb-2">
                <span className="text-2xl font-bold text-ink">$2,400</span>
                <span className="text-xs text-muted-foreground">/month · billed monthly</span>
              </div>
              <div className="flex items-center gap-4 flex-wrap text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Users className="h-3.5 w-3.5" />
                  <span className="font-medium text-ink">32</span> / 50 seats
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" />
                  Renews <span className="font-medium text-ink">Aug 1, 2026</span>
                </span>
                <span className="flex items-center gap-1">
                  <CreditCard className="h-3.5 w-3.5" />
                  Visa •• 4242
                </span>
              </div>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 flex-shrink-0">
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={handleDownloadStatement}
            >
              <Download className="mr-2 h-3.5 w-3.5" /> Statement
            </Button>
            <Button
              size="sm"
              className="rounded-full"
              onClick={handleUpgrade}
            >
              <ArrowUpRight className="mr-2 h-3.5 w-3.5" /> Upgrade
            </Button>
          </div>
        </div>

        {/* Seats progress */}
        <div className="relative mt-4 pt-4 border-t border-soft">
          <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1.5">
            <span className="uppercase tracking-wide">Seat utilization</span>
            <span>
              <span className="font-medium text-ink">32</span> of 50 seats · 64% used
            </span>
          </div>
          <Progress value={64} className="h-2" />
        </div>
      </Card>

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="MRR"
          value="$2,400"
          icon={<DollarSign className="h-4 w-4" />}
          accent="success"
          sublabel="billed monthly"
        />
        <StatCard
          label="Seats used"
          value="32"
          unit="/ 50"
          icon={<Users className="h-4 w-4" />}
          accent="info"
          sublabel="18 available"
        />
        <StatCard
          label="Projects"
          value="47"
          icon={<FolderKanban className="h-4 w-4" />}
          accent="warning"
          sublabel="unlimited on Enterprise"
        />
        <StatCard
          label="Storage used"
          value="312"
          unit="GB"
          icon={<HardDrive className="h-4 w-4" />}
          accent="info"
          trend={{ value: 6, direction: "up" }}
          sublabel="of 1 TB"
        />
      </div>

      {/* Two-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column */}
        <div className="lg:col-span-2 space-y-4">
          {/* Recent invoices */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                  <Receipt className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-semibold text-ink">Recent invoices</h3>
              </div>
              <Button asChild variant="ghost" size="sm" className="text-xs">
                <Link href="/billing/invoices">
                  View all <ChevronRight className="h-3 w-3" />
                </Link>
              </Button>
            </div>
            <div className="divide-y divide-border">
              {recentInvoices.map((inv) => (
                <div
                  key={inv.id}
                  className="flex items-center justify-between gap-3 py-2.5 first:pt-0 last:pb-0"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <code className="text-[11px] font-mono text-ink">{inv.number}</code>
                      <StatusBadge status={inv.status} />
                    </div>
                    <div className="text-[10px] text-muted-foreground truncate">
                      {inv.date} · {inv.plan}
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-xs font-semibold text-ink">
                      ${inv.amount.toLocaleString()}.00
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 text-[10px] text-muted-foreground hover:text-ink px-1"
                      onClick={() => toast.success(`Downloading ${inv.number}.pdf`)}
                    >
                      <Download className="mr-1 h-3 w-3" /> PDF
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Payment method */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <CreditCard className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Payment method</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">Default</Badge>
            </div>
            <div className="rounded-xl border border-soft p-3 flex items-center gap-3">
              <div className="flex h-9 w-12 items-center justify-center rounded-md bg-primary text-primary-foreground text-[10px] font-bold tracking-wider">
                VISA
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-ink">Visa ending 4242</div>
                <div className="text-[10px] text-muted-foreground">Expires 09/2028 · Halberg Studios</div>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 rounded-full"
                  onClick={handleEditPayment}
                  aria-label="Edit payment method"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 rounded-full text-friction hover:text-friction"
                  onClick={handleRemovePayment}
                  aria-label="Remove payment method"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 rounded-full text-xs"
              onClick={() => toast.info("Add payment method", { description: "Stripe secure form will open." })}
            >
              <Plus className="mr-1.5 h-3.5 w-3.5" /> Add payment method
            </Button>
          </Card>

          {/* Billing email */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Mail className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Billing email</h3>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-medium text-ink">billing@halberg.co</div>
                <div className="text-[10px] text-muted-foreground">
                  Invoices, receipts, and renewal notices are sent here
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 rounded-full"
                onClick={() => toast.info("Edit billing email")}
                aria-label="Edit billing email"
              >
                <Pencil className="h-3.5 w-3.5" />
              </Button>
            </div>
          </Card>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Plan comparison */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Sparkles className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Plan comparison</h3>
            </div>
            <div className="grid grid-cols-5 gap-1 text-[10px] mb-2 pb-2 border-b border-soft">
              <div className="text-muted-foreground">Feature</div>
              {PLAN_TIERS.map((p) => (
                <div
                  key={p.name}
                  className={cn(
                    "text-center font-medium",
                    p.highlight ? "text-ink" : "text-muted-foreground"
                  )}
                >
                  {p.name}
                  <div className="text-[9px] font-normal text-muted-foreground">{p.price}</div>
                </div>
              ))}
            </div>
            <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
              {PLAN_COMPARISON.map((f) => (
                <div key={f.name} className="grid grid-cols-5 gap-1 text-[10px] items-center">
                  <div className="text-muted-foreground text-[10px] leading-tight">{f.name}</div>
                  <PlanCell value={f.free} highlight={false} />
                  <PlanCell value={f.pro} highlight={false} />
                  <PlanCell value={f.team} highlight={false} />
                  <PlanCell value={f.enterprise} highlight />
                </div>
              ))}
            </div>
            <Button asChild size="sm" className="w-full mt-3 rounded-full text-xs">
              <Link href="/billing/subscription">
                Compare in detail <ChevronRight className="h-3 w-3" />
              </Link>
            </Button>
          </Card>

          {/* Payment history */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <Wallet className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Payment history</h3>
            </div>
            <div className="space-y-2">
              {PAYMENT_HISTORY.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-soft p-2.5"
                >
                  <div className="min-w-0">
                    <div className="text-[11px] font-medium text-ink">{p.date}</div>
                    <div className="text-[10px] text-muted-foreground truncate">{p.method}</div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-xs font-semibold text-ink">{p.amount}</div>
                    <StatusBadge status={p.status} />
                  </div>
                </div>
              ))}
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-3 rounded-full text-xs"
              onClick={handleDownloadStatement}
            >
              <Download className="mr-1.5 h-3.5 w-3.5" /> Download statements
            </Button>
          </Card>

          {/* Billing contact */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <Building2 className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Billing contact</h3>
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Company</span>
                <span className="font-medium text-ink">Halberg Studios</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Tax ID</span>
                <span className="font-medium text-ink font-mono text-[11px]">EU-VAT 429 88 19</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Address</span>
                <span className="font-medium text-ink text-right text-[11px]">
                  Storgata 12, Oslo
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Currency</span>
                <span className="font-medium text-ink">USD</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Auto-renew</span>
                <span className="font-medium text-ink flex items-center gap-1">
                  <ShieldCheck className="h-3 w-3 text-success" />
                  Enabled
                </span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function PlanCell({ value, highlight }: { value: boolean | string; highlight: boolean }) {
  if (typeof value === "boolean") {
    return (
      <div className={cn("flex items-center justify-center", highlight && "bg-primary/5 rounded")}>
        {value ? (
          <Check className={cn("h-3 w-3", highlight ? "text-success" : "text-muted-foreground")} />
        ) : (
          <span className="text-muted-foreground/40 text-xs">—</span>
        )}
      </div>
    );
  }
  return (
    <div
      className={cn(
        "text-center text-[10px] font-medium",
        highlight ? "text-ink bg-primary/5 rounded py-0.5" : "text-muted-foreground"
      )}
    >
      {value}
    </div>
  );
}
