"use client";

import * as React from "react";
import Link from "next/link";
import {
  RefreshCw,
  Check,
  Users,
  Plus,
  Minus,
  Sparkles,
  Calendar,
  AlertTriangle,
  XCircle,
  ArrowLeft,
  Zap,
  Shield,
  Building2,
  ChevronRight,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface PlanDef {
  id: string;
  name: string;
  price: number;
  period: string;
  tagline: string;
  features: string[];
  current?: boolean;
  accent?: boolean;
}

const PLANS: PlanDef[] = [
  {
    id: "free",
    name: "Free",
    price: 0,
    period: "forever",
    tagline: "For solo designers exploring UX analytics",
    features: [
      "3 projects",
      "1 seat",
      "100 session replays / mo",
      "Basic heatmaps",
      "CSV export",
      "Community support",
    ],
  },
  {
    id: "pro",
    name: "Pro",
    price: 120,
    period: "month",
    tagline: "For small product teams getting serious about UX",
    features: [
      "15 projects",
      "5 seats",
      "2,500 session replays / mo",
      "Full heatmaps & insights",
      "Custom reports",
      "Email support",
    ],
  },
  {
    id: "team",
    name: "Team",
    price: 580,
    period: "month",
    tagline: "For growing teams running continuous research",
    features: [
      "Unlimited projects",
      "20 seats",
      "15,000 session replays / mo",
      "A/B testing",
      "Audit logs (30 days)",
      "CSV + JSON export",
      "Priority support",
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 2400,
    period: "month",
    tagline: "For orgs with security, scale, and governance needs",
    features: [
      "Everything in Team",
      "50+ seats",
      "Unlimited session replays",
      "SSO / SAML (Okta, Azure AD)",
      "Unlimited audit logs",
      "Dedicated CSM",
      "Custom data residency",
    ],
    current: true,
    accent: true,
  },
];

export default function SubscriptionPage() {
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);
  const [seats, setSeats] = React.useState(32);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const currentPlan = PLANS.find((p) => p.current)!;
  const seatMax = 50;
  const seatPrice = currentPlan.price / seatMax;

  const handleSwitch = (plan: PlanDef) => {
    if (plan.current) return;
    const direction = plan.price > currentPlan.price ? "upgrade" : "downgrade";
    toast.success(`${direction === "upgrade" ? "Upgrading" : "Switching"} to ${plan.name}`, {
      description: `New rate: $${plan.price.toLocaleString()}/mo · prorated for the current cycle`,
    });
  };

  const handleSeatChange = (delta: number) => {
    const next = Math.max(1, Math.min(seatMax, seats + delta));
    if (next === seats) return;
    setSeats(next);
    const verb = delta > 0 ? "Added" : "Removed";
    const diff = Math.abs(delta);
    toast.success(`${verb} ${diff} seat${diff === 1 ? "" : "s"}`, {
      description: `New total: ${next} seats · ${
        delta > 0 ? "+" : "-"
      }$${Math.abs(delta * seatPrice).toFixed(2)}/mo`,
    });
  };

  const handleCancel = () => {
    openConfirm({
      title: "Cancel your subscription?",
      description:
        "Your workspace will downgrade to the Free plan at the end of the current billing cycle (Aug 1, 2026). Existing projects and data are preserved but advanced features will be locked.",
      onConfirm: () => {
        toast.success("Subscription cancellation scheduled", {
          description: "Active until Aug 1, 2026 — you can revert anytime before then.",
        });
      },
    });
  };

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  return (
    <div>
      <PageHeader
        title="Subscription"
        description="Change your plan, add seats, or cancel your subscription"
        icon={<RefreshCw className="h-5 w-5" />}
        breadcrumbs={[
          { label: "Billing", href: "/billing" },
          { label: "Subscription" },
        ]}
        actions={
          <Button asChild variant="outline" size="sm" className="rounded-full">
            <Link href="/billing">
              <ArrowLeft className="mr-2 h-3.5 w-3.5" /> Back to billing
            </Link>
          </Button>
        }
      />

      {/* Current plan card */}
      <Card className="rounded-2xl border-soft shadow-soft p-5 mb-4 overflow-hidden relative">
        <div className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-primary/5" />
        <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground flex-shrink-0">
              <Sparkles className="h-7 w-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <h2 className="text-xl font-semibold text-ink">{currentPlan.name}</h2>
                <Badge variant="outline" className="text-[10px] border-primary/30 bg-primary/10 text-ink">
                  Current plan
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mb-2 max-w-md">
                {currentPlan.tagline}
              </p>
              <div className="flex items-center gap-4 flex-wrap text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" />
                  Billing cycle: <span className="font-medium text-ink">Monthly</span>
                </span>
                <span className="flex items-center gap-1">
                  <RefreshCw className="h-3.5 w-3.5" />
                  Next renewal: <span className="font-medium text-ink">Aug 1, 2026</span>
                </span>
                <span className="flex items-center gap-1">
                  <Shield className="h-3.5 w-3.5" />
                  Auto-renew: <span className="font-medium text-ink">On</span>
                </span>
              </div>
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            <div className="flex items-baseline gap-1 justify-end">
              <span className="text-3xl font-bold text-ink">
                ${currentPlan.price.toLocaleString()}
              </span>
              <span className="text-xs text-muted-foreground">/{currentPlan.period}</span>
            </div>
            <div className="text-[10px] text-muted-foreground mt-1">
              ${seatPrice.toFixed(0)}/seat · {seats} active
            </div>
          </div>
        </div>
      </Card>

      {/* Plan switcher */}
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-sm font-semibold text-ink">Switch plan</h3>
          <span className="text-[10px] text-muted-foreground">
            · changes are prorated immediately
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {PLANS.map((plan) => (
            <Card
              key={plan.id}
              className={cn(
                "rounded-2xl border-soft shadow-soft p-4 flex flex-col transition-all",
                plan.current && "border-primary/40 ring-1 ring-primary/20",
                plan.accent && !plan.current && "bg-primary/[0.02]"
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-semibold text-ink">{plan.name}</span>
                  {plan.accent && (
                    <Sparkles className="h-3.5 w-3.5 text-warning" />
                  )}
                </div>
                {plan.current && (
                  <Badge variant="secondary" className="text-[10px] bg-primary/10 text-ink">
                    Current
                  </Badge>
                )}
              </div>
              <div className="flex items-baseline gap-1 mb-1">
                <span className="text-2xl font-bold text-ink">
                  ${plan.price.toLocaleString()}
                </span>
                <span className="text-[10px] text-muted-foreground">/{plan.period}</span>
              </div>
              <p className="text-[11px] text-muted-foreground mb-3 leading-relaxed min-h-[32px]">
                {plan.tagline}
              </p>
              <div className="space-y-1.5 mb-4 flex-1">
                {plan.features.map((f) => (
                  <div key={f} className="flex items-start gap-1.5">
                    <Check
                      className={cn(
                        "h-3 w-3 flex-shrink-0 mt-0.5",
                        plan.current ? "text-success" : "text-muted-foreground"
                      )}
                    />
                    <span className="text-[10px] text-ink leading-relaxed">{f}</span>
                  </div>
                ))}
              </div>
              <Button
                size="sm"
                variant={plan.current ? "outline" : plan.accent ? "default" : "outline"}
                className="rounded-full text-xs w-full"
                disabled={plan.current}
                onClick={() => handleSwitch(plan)}
              >
                {plan.current
                  ? "Current plan"
                  : plan.price > currentPlan.price
                  ? `Upgrade to ${plan.name}`
                  : plan.price < currentPlan.price
                  ? `Downgrade to ${plan.name}`
                  : `Switch to ${plan.name}`}
              </Button>
            </Card>
          ))}
        </div>
      </div>

      {/* Seats management + Cancel subscription */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Seats management */}
        <Card className="rounded-2xl border-soft shadow-soft p-4 lg:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
              <Users className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-semibold text-ink">Manage seats</h3>
            <Badge variant="secondary" className="text-[10px] ml-auto">
              {seats} of {seatMax} used
            </Badge>
          </div>

          <div className="rounded-xl border border-soft p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-xs font-medium text-ink">Active seats</div>
                <div className="text-[10px] text-muted-foreground">
                  ${seatPrice.toFixed(0)} per seat / month
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 rounded-full"
                  onClick={() => handleSeatChange(-1)}
                  disabled={seats <= 1}
                  aria-label="Remove one seat"
                >
                  <Minus className="h-3.5 w-3.5" />
                </Button>
                <div className="flex h-9 w-14 items-center justify-center rounded-lg border border-soft bg-surface-2">
                  <span className="text-base font-semibold text-ink">{seats}</span>
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 rounded-full"
                  onClick={() => handleSeatChange(1)}
                  disabled={seats >= seatMax}
                  aria-label="Add one seat"
                >
                  <Plus className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            <Progress value={(seats / seatMax) * 100} className="h-2 mb-2" />
            <div className="flex items-center justify-between text-[10px] text-muted-foreground">
              <span>{seats} seats in use</span>
              <span>{seatMax - seats} available</span>
            </div>

            <div className="mt-4 pt-4 border-t border-soft grid grid-cols-2 gap-3">
              <div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-0.5">
                  Monthly cost
                </div>
                <div className="text-base font-semibold text-ink">
                  ${(seats * seatPrice).toLocaleString()}.00
                </div>
              </div>
              <div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-0.5">
                  Prorated today
                </div>
                <div className="text-base font-semibold text-ink">
                  +$0.00
                </div>
              </div>
            </div>

            <Button
              size="sm"
              className="w-full mt-4 rounded-full text-xs"
              onClick={() => toast.success("Seat changes saved", {
                description: `New total: ${seats} seats.`,
              })}
            >
              <Check className="mr-1.5 h-3.5 w-3.5" /> Save seat changes
            </Button>
          </div>

          <div className="mt-3 flex items-start gap-2 rounded-xl bg-info/5 border border-info/20 p-3">
            <Building2 className="h-4 w-4 text-info flex-shrink-0 mt-0.5" />
            <div className="text-[11px] text-ink leading-relaxed">
              <span className="font-medium">Need more than 50 seats?</span> Contact our sales team for
              volume pricing and custom Enterprise terms — including dedicated infrastructure,
              multi-region residency, and 24/7 support SLAs.
            </div>
          </div>
        </Card>

        {/* Cancel subscription (danger zone) */}
        <Card className="rounded-2xl border-friction/30 shadow-soft p-4">
          <div className="flex items-center gap-2 mb-4">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-friction/15 text-friction">
              <AlertTriangle className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-semibold text-ink">Danger zone</h3>
          </div>

          <div className="rounded-xl border border-friction/20 bg-friction/5 p-3 mb-4">
            <div className="flex items-center gap-2 mb-1">
              <XCircle className="h-4 w-4 text-friction" />
              <span className="text-xs font-medium text-ink">Cancel subscription</span>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Your workspace will downgrade to the Free plan at the end of the current cycle. All
              existing data is preserved, but advanced features (heatmaps, replays, reports) will be
              locked. You can resubscribe anytime.
            </p>
          </div>

          <div className="space-y-2 mb-4">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Plan remains active until</span>
              <span className="font-medium text-ink">Aug 1, 2026</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Refund eligibility</span>
              <span className="font-medium text-ink">None (mid-cycle)</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Data retention</span>
              <span className="font-medium text-ink">90 days</span>
            </div>
          </div>

          <Button
            variant="outline"
            size="sm"
            className="w-full rounded-full text-xs text-friction hover:text-friction border-friction/30 hover:bg-friction/5"
            onClick={handleCancel}
          >
            <XCircle className="mr-1.5 h-3.5 w-3.5" /> Cancel subscription
          </Button>

          <Button
            asChild
            variant="ghost"
            size="sm"
            className="w-full mt-2 text-[10px] text-muted-foreground"
          >
            <Link href="/billing">
              Talk to us first <ChevronRight className="h-3 w-3" />
            </Link>
          </Button>
        </Card>
      </div>
    </div>
  );
}
