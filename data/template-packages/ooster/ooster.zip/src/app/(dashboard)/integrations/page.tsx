"use client";

import * as React from "react";
import Link from "next/link";
import {
  Plug,
  Figma,
  Slack,
  Layers,
  SquareKanban,
  FileText,
  PieChart,
  Activity,
  Compass,
  Users,
  Fingerprint,
  BarChart3,
  PenTool,
  ListChecks,
  MessageCircle,
  Star,
  ShieldCheck,
  Check,
  Zap,
  Sparkles,
  ExternalLink,
  Settings,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { FilterBar, type FilterOption } from "@/components/common/filter-bar";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { INTEGRATIONS, type Integration } from "@/lib/data";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// Map integration icon name → lucide icon component
const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Figma,
  Slack,
  Linear: Layers,
  Jira: SquareKanban,
  Notion: FileText,
  Segment: PieChart,
  Amplitude: Activity,
  Maze: Compass,
  UserTesting: Users,
  Okta: Fingerprint,
};

// Map category → icon for stat/badge contexts
const CATEGORY_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  analytics: BarChart3,
  design: PenTool,
  "project-management": ListChecks,
  communication: MessageCircle,
  feedback: Star,
  auth: ShieldCheck,
};

const CATEGORY_OPTIONS: FilterOption[] = [
  { label: "All categories", value: "all" },
  { label: "Analytics", value: "analytics" },
  { label: "Design", value: "design" },
  { label: "Project management", value: "project-management" },
  { label: "Communication", value: "communication" },
  { label: "Feedback", value: "feedback" },
  { label: "Auth", value: "auth" },
];

const STATUS_OPTIONS: FilterOption[] = [
  { label: "All statuses", value: "all" },
  { label: "Connected", value: "connected" },
  { label: "Available", value: "available" },
  { label: "Coming soon", value: "coming-soon" },
];

function CategoryBadge({ category }: { category: string }) {
  const Icon = CATEGORY_ICON[category] ?? Plug;
  return (
    <Badge variant="secondary" className="text-[10px] capitalize gap-1">
      <Icon className="h-3 w-3" />
      {category.replace("-", " ")}
    </Badge>
  );
}

export default function IntegrationsPage() {
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const connected = INTEGRATIONS.filter((i) => i.status === "connected").length;
  const available = INTEGRATIONS.filter((i) => i.status === "available").length;
  const comingSoon = INTEGRATIONS.filter((i) => i.status === "coming-soon").length;
  const categories = new Set(INTEGRATIONS.map((i) => i.category)).size;

  const filtered = React.useMemo(() => {
    return INTEGRATIONS.filter((i) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !i.name.toLowerCase().includes(q) &&
          !i.description.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      if (category !== "all" && i.category !== category) return false;
      if (status !== "all" && i.status !== status) return false;
      return true;
    });
  }, [search, category, status]);

  const clearFilters = () => {
    setSearch("");
    setCategory("all");
    setStatus("all");
  };

  const handleConnect = (integration: Integration) => {
    toast.success(`Connecting to ${integration.name}…`, {
      description: "You'll be redirected to authorize in a moment.",
    });
  };

  return (
    <div>
      <PageHeader
        title="Integrations"
        description="Connect Ooster with your favorite design, analytics, and PM tools"
        icon={<Plug className="h-5 w-5" />}
        badge={
          <Badge variant="secondary" className="text-[10px]">
            {INTEGRATIONS.length} integrations
          </Badge>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Connected"
          value={connected}
          icon={<Check className="h-4 w-4" />}
          accent="success"
          sublabel="actively syncing"
        />
        <StatCard
          label="Available"
          value={available}
          icon={<Zap className="h-4 w-4" />}
          accent="info"
          sublabel="ready to install"
        />
        <StatCard
          label="Coming soon"
          value={comingSoon}
          icon={<Sparkles className="h-4 w-4" />}
          accent="warning"
          sublabel="on the roadmap"
        />
        <StatCard
          label="Categories"
          value={categories}
          icon={<Layers className="h-4 w-4" />}
          sublabel="across the catalog"
        />
      </div>

      {/* Filters */}
      <div className="mb-4">
        <FilterBar
          search={{
            value: search,
            onChange: setSearch,
            placeholder: "Search integrations…",
          }}
          selects={[
            {
              label: "Category",
              value: category,
              onChange: setCategory,
              options: CATEGORY_OPTIONS,
            },
            {
              label: "Status",
              value: status,
              onChange: setStatus,
              options: STATUS_OPTIONS,
            },
          ]}
          onClear={clearFilters}
        />
      </div>

      {loading ? (
        <LoadingSkeleton variant="cards" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Plug}
          title="No integrations match your filters"
          description="Try a different search term or category, or browse all available integrations."
          action={{ label: "Browse all", onClick: clearFilters }}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((integration) => {
            const Icon = ICON_MAP[integration.icon] ?? Plug;
            const isConnected = integration.status === "connected";
            const isComingSoon = integration.status === "coming-soon";
            return (
              <Card
                key={integration.id}
                className="rounded-2xl border-soft shadow-soft p-4 hover:shadow-card hover:border-primary/30 transition-all flex flex-col"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-surface-2 text-primary">
                    <Icon className="h-5 w-5" />
                  </div>
                  <StatusBadge status={integration.status} />
                </div>
                <div className="font-semibold text-sm text-ink mb-1">
                  {integration.name}
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed mb-3 line-clamp-2">
                  {integration.description}
                </p>
                <div className="mb-3">
                  <CategoryBadge category={integration.category} />
                </div>
                <div className="mt-auto pt-3 border-t border-soft flex items-center gap-2">
                  {isConnected ? (
                    <Button
                      asChild
                      size="sm"
                      variant="outline"
                      className="flex-1 rounded-full text-xs"
                    >
                      <Link href={`/integrations/${integration.id}`}>
                        <Settings className="mr-1.5 h-3.5 w-3.5" /> Configure
                      </Link>
                    </Button>
                  ) : isComingSoon ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      disabled
                      className="flex-1 rounded-full text-xs text-muted-foreground"
                    >
                      <Sparkles className="mr-1.5 h-3.5 w-3.5" /> Coming soon
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      className="flex-1 rounded-full text-xs"
                      onClick={() => handleConnect(integration)}
                    >
                      <Zap className="mr-1.5 h-3.5 w-3.5" /> Connect
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 rounded-full"
                    onClick={() =>
                      toast.info(`Opening ${integration.name} documentation`, {
                        description: "Docs will open in a new tab.",
                      })
                    }
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
