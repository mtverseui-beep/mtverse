"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Plug,
  Figma,
  Slack,
  Layers,
  SquareKanban,
  FileText,
  PieChart,
  Activity,
  Compass,
  Users,
  Fingerprint,
  BarChart3,
  PenTool,
  ListChecks,
  MessageCircle,
  Star,
  ShieldCheck,
  Share2,
  Unplug,
  ExternalLink,
  RefreshCw,
  Check,
  Clock,
  Globe,
  KeyRound,
  Mail,
  Zap,
} from "lucide-react";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/badges";
import { EmptyState } from "@/components/common/empty-state";
import { LoadingSkeleton } from "@/components/common/loading-skeleton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { INTEGRATIONS } from "@/lib/data";
import { useModals } from "@/hooks/use-modals";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Figma,
  Slack,
  Linear: Layers,
  Jira: SquareKanban,
  Notion: FileText,
  Segment: PieChart,
  Amplitude: Activity,
  Maze: Compass,
  UserTesting: Users,
  Okta: Fingerprint,
};

const CATEGORY_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  analytics: BarChart3,
  design: PenTool,
  "project-management": ListChecks,
  communication: MessageCircle,
  feedback: Star,
  auth: ShieldCheck,
};

interface Permission {
  scope: string;
  description: string;
}

const PERMISSIONS: Record<string, Permission[]> = {
  default: [
    { scope: "read:projects", description: "View all projects in your workspace" },
    { scope: "read:insights", description: "Read insights, severity, and evidence" },
    { scope: "write:reports", description: "Push generated reports to the integration" },
    { scope: "webhook:sign", description: "Sign outbound webhook payloads" },
  ],
};

interface SyncEvent {
  id: string;
  type: string;
  status: "success" | "warning" | "failed";
  detail: string;
  time: string;
}

const MOCK_SYNC_EVENTS: SyncEvent[] = [
  { id: "s1", type: "Full sync", status: "success", detail: "Imported 84 frames · 12 components", time: "2 hours ago" },
  { id: "s2", type: "Incremental", status: "success", detail: "Updated 6 screens, 2 deleted", time: "Yesterday · 14:32" },
  { id: "s3", type: "Component map", status: "warning", detail: "3 unmapped variants detected", time: "Yesterday · 09:11" },
  { id: "s4", type: "Full sync", status: "success", detail: "Imported 78 frames · 11 components", time: "2 days ago" },
  { id: "s5", type: "Auth refresh", status: "success", detail: "OAuth token rotated", time: "3 days ago" },
];

export default function IntegrationDetailPage() {
  const params = useParams<{ id: string }>();
  const integration = INTEGRATIONS.find((i) => i.id === params.id);
  const openShare = useModals((s) => s.openShare);
  const openConfirm = useModals((s) => s.openConfirm);
  const [loading, setLoading] = React.useState(true);

  // Form state (varies by integration type, default values shown)
  const [webhookUrl, setWebhookUrl] = React.useState("https://hooks.slack.com/services/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");
  const [channel, setChannel] = React.useState("ux-alerts");
  const [events, setEvents] = React.useState({
    insights: true,
    reports: true,
    heatmaps: false,
    surveys: false,
  });
  const [fileUrl, setFileUrl] = React.useState("https://www.figma.com/file/qXo2Km3Mn5b4T8oRj9kL1p/Ooster-DS");
  const [frequency, setFrequency] = React.useState("hourly");
  const [syncing, setSyncing] = React.useState(false);

  React.useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
    return <LoadingSkeleton variant="page" />;
  }

  if (!integration) {
    return (
      <EmptyState
        icon={Plug}
        title="Integration not found"
        description="This integration may have been removed, renamed, or never existed."
        action={{ label: "Back to integrations", href: "/integrations" }}
      />
    );
  }

  const Icon = ICON_MAP[integration.icon] ?? Plug;
  const CatIcon = CATEGORY_ICON[integration.category] ?? Plug;
  const isConnected = integration.status === "connected";

  const handleDisconnect = () => {
    openConfirm({
      title: `Disconnect ${integration.name}?`,
      description:
        "Ooster will stop syncing with this integration. Existing data already imported remains in your workspace.",
      onConfirm: () => {
        toast.success(`${integration.name} disconnected`);
      },
    });
  };

  const handleSyncNow = () => {
    setSyncing(true);
    toast.info(`Syncing with ${integration.name}…`, {
      description: "You can keep working — we'll notify you when it completes.",
    });
    setTimeout(() => {
      setSyncing(false);
      toast.success(`${integration.name} sync complete`, {
        description: "23 items updated, 0 errors.",
      });
    }, 1800);
  };

  const handleSaveConfig = () => {
    toast.success("Configuration saved", {
      description: `${integration.name} settings updated successfully.`,
    });
  };

  const isSlack = integration.name === "Slack";
  const isFigma = integration.name === "Figma";

  return (
    <div>
      <PageHeader
        title={integration.name}
        description={integration.description}
        breadcrumbs={[
          { label: "Integrations", href: "/integrations" },
          { label: integration.name },
        ]}
        icon={<Icon className="h-5 w-5" />}
        badge={<StatusBadge status={integration.status} />}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() =>
                openShare(`/integrations/${integration.id}`, integration.name)
              }
            >
              <Share2 className="mr-2 h-3.5 w-3.5" /> Share
            </Button>
            {isConnected && (
              <Button
                variant="outline"
                size="sm"
                className="rounded-full text-friction hover:text-friction"
                onClick={handleDisconnect}
              >
                <Unplug className="mr-2 h-3.5 w-3.5" /> Disconnect
              </Button>
            )}
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column */}
        <div className="lg:col-span-2 space-y-4">
          {/* Overview card */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-start gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-surface-2 text-primary flex-shrink-0">
                <Icon className="h-8 w-8" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <h3 className="text-base font-semibold text-ink">
                    {integration.name}
                  </h3>
                  <Badge variant="secondary" className="text-[10px] gap-1 capitalize">
                    <CatIcon className="h-3 w-3" />
                    {integration.category.replace("-", " ")}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {integration.description}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="rounded-full text-xs h-8"
                    onClick={() =>
                      toast.info(`Opening ${integration.name} website`, {
                        description: "Documentation opens in a new tab.",
                      })
                    }
                  >
                    <Globe className="mr-1.5 h-3.5 w-3.5" /> Visit website
                    <ExternalLink className="ml-1 h-3 w-3 opacity-60" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="rounded-full text-xs h-8"
                    onClick={() =>
                      toast.info("Opening API documentation")
                    }
                  >
                    <FileText className="mr-1.5 h-3.5 w-3.5" /> API docs
                  </Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Configuration form card */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-primary">
                <Zap className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Configuration</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {isSlack ? "Webhook" : isFigma ? "File link" : "OAuth"}
              </Badge>
            </div>

            <div className="space-y-4">
              {isSlack ? (
                <>
                  <div className="space-y-1.5">
                    <Label htmlFor="webhook-url" className="text-xs">Incoming webhook URL</Label>
                    <Input
                      id="webhook-url"
                      value={webhookUrl}
                      onChange={(e) => setWebhookUrl(e.target.value)}
                      className="text-xs font-mono"
                      placeholder="https://hooks.slack.com/services/…"
                    />
                    <p className="text-[10px] text-muted-foreground">
                      Create one in Slack → Apps → Incoming Webhooks.
                    </p>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="channel" className="text-xs">Default channel</Label>
                    <Select value={channel} onValueChange={setChannel}>
                      <SelectTrigger id="channel" className="h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ux-alerts">#ux-alerts</SelectItem>
                        <SelectItem value="design-review">#design-review</SelectItem>
                        <SelectItem value="engineering">#engineering</SelectItem>
                        <SelectItem value="product">#product</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Notify on events</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {[
                        { key: "insights", label: "New insights", desc: "Critical & high severity" },
                        { key: "reports", label: "Reports ready", desc: "When a report finishes generating" },
                        { key: "heatmaps", label: "Heatmap anomalies", desc: "Unusual click patterns" },
                        { key: "surveys", label: "Survey milestones", desc: "Daily response digests" },
                      ].map((e) => (
                        <label
                          key={e.key}
                          htmlFor={`evt-${e.key}`}
                          className="flex items-start gap-2.5 rounded-xl border border-soft p-2.5 cursor-pointer hover:bg-accent/30 transition-colors"
                        >
                          <Checkbox
                            id={`evt-${e.key}`}
                            checked={events[e.key as keyof typeof events]}
                            onCheckedChange={(v) =>
                              setEvents((s) => ({ ...s, [e.key]: !!v }))
                            }
                            className="mt-0.5"
                          />
                          <div className="min-w-0">
                            <div className="text-xs font-medium text-ink">{e.label}</div>
                            <div className="text-[10px] text-muted-foreground">{e.desc}</div>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                </>
              ) : isFigma ? (
                <>
                  <div className="space-y-1.5">
                    <Label htmlFor="file-url" className="text-xs">Figma file URL</Label>
                    <Input
                      id="file-url"
                      value={fileUrl}
                      onChange={(e) => setFileUrl(e.target.value)}
                      className="text-xs font-mono"
                      placeholder="https://www.figma.com/file/…"
                    />
                    <p className="text-[10px] text-muted-foreground">
                      Ooster needs "Can view" access on the file.
                    </p>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="frequency" className="text-xs">Sync frequency</Label>
                    <Select value={frequency} onValueChange={setFrequency}>
                      <SelectTrigger id="frequency" className="h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="realtime">Realtime (on file change)</SelectItem>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily at 02:00</SelectItem>
                        <SelectItem value="manual">Manual only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label htmlFor="inc-components" className="flex items-start gap-2.5 rounded-xl border border-soft p-2.5 cursor-pointer hover:bg-accent/30 transition-colors">
                      <Checkbox id="inc-components" defaultChecked className="mt-0.5" />
                      <div>
                        <div className="text-xs font-medium text-ink">Import components</div>
                        <div className="text-[10px] text-muted-foreground">Map main + variants</div>
                      </div>
                    </label>
                    <label htmlFor="inc-protos" className="flex items-start gap-2.5 rounded-xl border border-soft p-2.5 cursor-pointer hover:bg-accent/30 transition-colors">
                      <Checkbox id="inc-protos" defaultChecked className="mt-0.5" />
                      <div>
                        <div className="text-xs font-medium text-ink">Import prototypes</div>
                        <div className="text-[10px] text-muted-foreground">Flow screens & transitions</div>
                      </div>
                    </label>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-1.5">
                    <Label htmlFor="workspace" className="text-xs">Workspace slug</Label>
                    <Input id="workspace" defaultValue="halberg-studios" className="text-xs" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="token" className="text-xs">API token</Label>
                    <Input id="token" type="password" defaultValue="sk_live_xxxxxxxxxxxxxxxxxxxx" className="text-xs font-mono" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="sync-freq" className="text-xs">Sync frequency</Label>
                    <Select defaultValue="hourly">
                      <SelectTrigger id="sync-freq" className="h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="manual">Manual only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <label htmlFor="auto-tag" className="flex items-start gap-2.5 rounded-xl border border-soft p-2.5 cursor-pointer hover:bg-accent/30 transition-colors">
                      <Checkbox id="auto-tag" defaultChecked className="mt-0.5" />
                      <div>
                        <div className="text-xs font-medium text-ink">Auto-tag imported items</div>
                        <div className="text-[10px] text-muted-foreground">Apply workspace taxonomy</div>
                      </div>
                    </label>
                    <label htmlFor="dedupe" className="flex items-start gap-2.5 rounded-xl border border-soft p-2.5 cursor-pointer hover:bg-accent/30 transition-colors">
                      <Checkbox id="dedupe" defaultChecked className="mt-0.5" />
                      <div>
                        <div className="text-xs font-medium text-ink">Deduplicate on import</div>
                        <div className="text-[10px] text-muted-foreground">Match by external ID</div>
                      </div>
                    </label>
                  </div>
                </>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-soft">
                <Button
                  variant="ghost"
                  size="sm"
                  className="rounded-full text-xs"
                  onClick={() => toast.info("Configuration reset")}
                >
                  Reset
                </Button>
                <Button
                  size="sm"
                  className="rounded-full text-xs"
                  onClick={handleSaveConfig}
                >
                  <Check className="mr-1.5 h-3.5 w-3.5" /> Save configuration
                </Button>
              </div>
            </div>
          </Card>

          {/* Data sync card */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
                <RefreshCw className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Data sync</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {isConnected ? "Live" : "Not connected"}
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="rounded-xl border border-soft p-3">
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground uppercase tracking-wide mb-1">
                  <Clock className="h-3 w-3" /> Last sync
                </div>
                <div className="text-sm font-semibold text-ink">2 hours ago</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  84 items · 0 errors
                </div>
              </div>
              <div className="rounded-xl border border-soft p-3">
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground uppercase tracking-wide mb-1">
                  <Clock className="h-3 w-3" /> Next sync
                </div>
                <div className="text-sm font-semibold text-ink">in 38 min</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  Scheduled · hourly
                </div>
              </div>
            </div>

            <Button
              size="sm"
              className="w-full rounded-full"
              onClick={handleSyncNow}
              disabled={syncing || !isConnected}
            >
              <RefreshCw className={cn("mr-2 h-3.5 w-3.5", syncing && "animate-spin")} />
              {syncing ? "Syncing…" : "Sync now"}
            </Button>
          </Card>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Connection status */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-success">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Connection status</h3>
            </div>
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Status</span>
                <StatusBadge status={integration.status} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Connected since</span>
                <span className="font-medium text-ink">{integration.connectedAt ?? "—"}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Account email</span>
                <span className="font-medium text-ink flex items-center gap-1">
                  <Mail className="h-3 w-3 text-muted-foreground" />
                  admin@halberg.co
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Plan tier</span>
                <Badge variant="outline" className="text-[10px]">Enterprise</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Auth method</span>
                <span className="font-medium text-ink flex items-center gap-1">
                  <KeyRound className="h-3 w-3 text-muted-foreground" />
                  OAuth 2.0
                </span>
              </div>
            </div>
          </Card>

          {/* Permissions */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-warning">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-semibold text-ink">Permissions</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                {PERMISSIONS.default.length} scopes
              </Badge>
            </div>
            <div className="space-y-2.5">
              {PERMISSIONS.default.map((p) => (
                <div key={p.scope} className="rounded-xl border border-soft p-2.5">
                  <div className="flex items-center gap-2 mb-0.5">
                    <code className="text-[10px] font-mono text-info bg-info/10 px-1.5 py-0.5 rounded">
                      {p.scope}
                    </code>
                  </div>
                  <div className="text-[10px] text-muted-foreground leading-relaxed">
                    {p.description}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent activity */}
          <Card className="rounded-2xl border-soft shadow-soft p-4">
            <div className="flex items-center gap-2 mb-3">
              <Activity className="h-4 w-4 text-muted-foreground" />
              <h3 className="text-sm font-semibold text-ink">Recent activity</h3>
              <Badge variant="secondary" className="text-[10px] ml-auto">
                Last 7 days
              </Badge>
            </div>
            <div className="space-y-2.5">
              {MOCK_SYNC_EVENTS.map((ev) => (
                <div key={ev.id} className="flex items-start gap-2.5">
                  <div
                    className={cn(
                      "flex h-6 w-6 items-center justify-center rounded-full flex-shrink-0 mt-0.5",
                      ev.status === "success" && "bg-success/15 text-success",
                      ev.status === "warning" && "bg-warning/15 text-warning",
                      ev.status === "failed" && "bg-friction/15 text-friction"
                    )}
                  >
                    {ev.status === "success" ? (
                      <Check className="h-3 w-3" />
                    ) : ev.status === "warning" ? (
                      <Clock className="h-3 w-3" />
                    ) : (
                      <Unplug className="h-3 w-3" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-ink">{ev.type}</span>
                      <span className="text-[10px] text-muted-foreground">{ev.time}</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground leading-relaxed">
                      {ev.detail}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <Button
              asChild
              variant="ghost"
              size="sm"
              className="w-full mt-3 text-xs rounded-full"
            >
              <Link href="/audit-logs">View all activity</Link>
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
