import type { Metadata } from "next";
import Link from "next/link";
import { LockKeyhole, ArrowLeft, LogIn } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Unauthorized — 401",
  description: "You need to sign in to access this page.",
};

export default function UnauthorizedPage() {
  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      {/* Top-left wordmark */}
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Decorative concentric rings — slate-blue */}
          <svg
            className="pointer-events-none absolute -top-16 -right-16 h-48 w-48 text-info/15"
            viewBox="0 0 200 200"
            fill="none"
            aria-hidden="true"
          >
            <circle cx="100" cy="100" r="80" stroke="currentColor" strokeWidth="1.5" />
            <circle cx="100" cy="100" r="60" stroke="currentColor" strokeWidth="1.5" />
            <circle cx="100" cy="100" r="40" stroke="currentColor" strokeWidth="1.5" />
          </svg>

          <div className="relative flex flex-col items-center text-center">
            <div className="relative">
              <span className="block text-[88px] sm:text-[104px] font-bold tracking-tighter leading-none text-gradient-ink">
                401
              </span>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex h-11 w-11 items-center justify-center rounded-2xl bg-info/10 text-info ring-1 ring-info/20">
                <LockKeyhole className="h-5 w-5" />
              </div>
            </div>

            <div className="mt-6 inline-flex items-center gap-1.5 rounded-full bg-info/10 px-2.5 py-1 text-[11px] font-medium text-info">
              <span className="h-1.5 w-1.5 rounded-full bg-info" />
              Authentication required
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              You need to sign in to access this page.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              Your session may have expired, or this resource requires an
              authenticated Ooster workspace account.
            </p>

            <div className="mt-7 flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button asChild size="lg" className="rounded-full">
                <Link href="/sign-in">
                  <LogIn className="mr-1.5 h-4 w-4" /> Sign in
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                <Link href="/">
                  <ArrowLeft className="mr-1.5 h-4 w-4" /> Back to dashboard
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Need help?{" "}
          <Link href="/contact" className="text-ink hover:underline">
            Contact support
          </Link>
        </p>
      </div>
    </main>
  );
}
