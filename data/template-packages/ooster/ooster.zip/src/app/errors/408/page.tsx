"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Clock, ArrowLeft, RotateCw } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";

export default function TimeoutPage() {
  const router = useRouter();

  const handleRetry = () => {
    router.refresh();
  };

  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Pulsing ripple rings — warning/amber */}
          <svg
            className="pointer-events-none absolute -bottom-20 -right-16 h-56 w-56 text-warning/20"
            viewBox="0 0 200 200"
            fill="none"
            aria-hidden="true"
          >
            <circle cx="100" cy="100" r="20" stroke="currentColor" strokeWidth="2" />
            <circle cx="100" cy="100" r="48" stroke="currentColor" strokeWidth="1.5" opacity="0.7" />
            <circle cx="100" cy="100" r="76" stroke="currentColor" strokeWidth="1" opacity="0.45" />
            <circle cx="100" cy="100" r="96" stroke="currentColor" strokeWidth="0.8" opacity="0.25" />
          </svg>

          <div className="relative flex flex-col items-center text-center">
            <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-warning/10 text-warning ring-1 ring-warning/20">
              <Clock className="h-7 w-7" />
              {/* rotating sweep hand */}
              <span className="pointer-events-none absolute inset-0 rounded-2xl border-2 border-warning/30 border-t-warning" style={{ animation: "spin 3s linear infinite" }} />
            </div>

            <span className="mt-5 block text-[88px] sm:text-[104px] font-bold tracking-tighter leading-none text-warning">
              408
            </span>

            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-warning/10 px-2.5 py-1 text-[11px] font-medium text-warning">
              <span className="h-1.5 w-1.5 rounded-full bg-warning" />
              Request timed out
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              The request took too long to complete. Please try again.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              This can happen when a query covers a very large date range or
              when our analytics cluster is under heavy load.
            </p>

            <div className="mt-7 flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button size="lg" className="rounded-full" onClick={handleRetry}>
                <RotateCw className="mr-1.5 h-4 w-4" /> Try again
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                <Link href="/">
                  <ArrowLeft className="mr-1.5 h-4 w-4" /> Back to dashboard
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Tip: narrow your filters or{" "}
          <Link href="/contact" className="text-ink hover:underline">
            contact support
          </Link>{" "}
          if this keeps happening.
        </p>
      </div>

      <style jsx>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </main>
  );
}
