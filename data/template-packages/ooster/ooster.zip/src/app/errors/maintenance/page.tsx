import type { Metadata } from "next";
import Link from "next/link";
import { HardHat, ExternalLink, Hammer } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export const metadata: Metadata = {
  title: "Under maintenance",
  description: "Ooster is undergoing scheduled maintenance.",
};

export default function MaintenancePage() {
  // Mock progress — 62% complete
  const progress = 62;
  const startedAt = "11:30 UTC";
  const endsAt = "14:00 UTC";

  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Scaffold / blueprint grid — warning/amber */}
          <svg
            className="pointer-events-none absolute inset-0 h-full w-full text-warning/10"
            aria-hidden="true"
          >
            <defs>
              <pattern id="maint-grid" width="24" height="24" patternUnits="userSpaceOnUse">
                <path d="M 24 0 L 0 0 0 24" fill="none" stroke="currentColor" strokeWidth="1" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#maint-grid)" />
          </svg>

          <div className="relative flex flex-col items-center text-center">
            <div className="relative">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-warning/10 text-warning ring-1 ring-warning/20">
                <HardHat className="h-7 w-7" />
              </div>
              {/* hard-hat jiggle */}
              <Hammer className="pointer-events-none absolute -right-3 -top-2 h-4 w-4 text-warning/60 rotate-12" />
            </div>

            <span className="mt-5 block text-[58px] sm:text-[68px] font-bold tracking-tighter leading-none text-warning">
              Maintenance
            </span>

            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-warning/10 px-2.5 py-1 text-[11px] font-medium text-warning">
              <span className="h-1.5 w-1.5 rounded-full bg-warning animate-pulse" />
              Scheduled downtime
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              Ooster is undergoing scheduled maintenance.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              We&apos;ll be back by{" "}
              <span className="font-semibold text-ink">14:00 UTC</span>. Thanks
              for your patience while we ship improvements.
            </p>

            {/* Progress bar */}
            <div className="mt-6 w-full">
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
                <span>
                  Started {startedAt} · Ends {endsAt}
                </span>
                <span className="font-semibold text-ink tabular-nums">
                  {progress}%
                </span>
              </div>
              <Progress value={progress} className="h-2" />
              <p className="mt-2 text-[11px] text-muted-foreground">
                Migrating analytics cluster &amp; rolling out v1.1.0 schema.
              </p>
            </div>

            <div className="mt-7 flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button
                asChild
                size="lg"
                className="rounded-full"
              >
                <a
                  href="https://status.ooster.app"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <ExternalLink className="mr-1.5 h-4 w-4" /> Status page
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                <Link href="/changelog">View changelog</Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Follow{" "}
          <a
            href="https://status.ooster.app"
            className="text-ink hover:underline"
            target="_blank"
            rel="noopener noreferrer"
          >
            status.ooster.app
          </a>{" "}
          for live updates.
        </p>
      </div>
    </main>
  );
}
