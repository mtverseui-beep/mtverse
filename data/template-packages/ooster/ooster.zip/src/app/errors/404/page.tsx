import type { Metadata } from "next";
import Link from "next/link";
import { Compass, ArrowLeft, Search } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Page not found — 404",
  description: "The page you're looking for doesn't exist or has been moved.",
};

export default function NotFoundPage() {
  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Dashed orbit circles — lost compass theme */}
          <svg
            className="pointer-events-none absolute inset-0 h-full w-full text-muted-foreground/15"
            viewBox="0 0 400 400"
            fill="none"
            aria-hidden="true"
          >
            <circle cx="200" cy="200" r="160" stroke="currentColor" strokeWidth="1" strokeDasharray="3 6" />
            <circle cx="200" cy="200" r="110" stroke="currentColor" strokeWidth="1" strokeDasharray="3 6" />
            <circle cx="200" cy="200" r="60" stroke="currentColor" strokeWidth="1" strokeDasharray="3 6" />
          </svg>

          <div className="relative flex flex-col items-center text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-surface-2 text-muted-foreground ring-1 ring-border">
              <Compass className="h-7 w-7" />
            </div>

            <span className="mt-5 block text-[88px] sm:text-[104px] font-bold tracking-tighter leading-none text-gradient-ink">
              404
            </span>

            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-surface-2 px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground" />
              Lost in the void
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              The page you&apos;re looking for doesn&apos;t exist or has been moved.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              The URL may be outdated, mistyped, or the project may have been
              archived. Try searching or head back to the dashboard.
            </p>

            <div className="mt-7 flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button asChild size="lg" className="rounded-full">
                <Link href="/?search=open">
                  <Search className="mr-1.5 h-4 w-4" /> Search
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                <Link href="/">
                  <ArrowLeft className="mr-1.5 h-4 w-4" /> Back to dashboard
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Popular destinations:{" "}
          <Link href="/insights" className="text-ink hover:underline">Insights</Link>
          {" · "}
          <Link href="/heatmaps" className="text-ink hover:underline">Heatmaps</Link>
          {" · "}
          <Link href="/reports" className="text-ink hover:underline">Reports</Link>
        </p>
      </div>
    </main>
  );
}
