"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { WifiOff, RotateCw, Home } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";

export default function OfflinePage() {
  const router = useRouter();

  const handleRetry = () => {
    // Best-effort: force a fresh load of the page so the browser re-checks connectivity
    if (typeof window !== "undefined") {
      window.location.reload();
    }
  };

  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Disconnected signal waves — info/slate-blue */}
          <svg
            className="pointer-events-none absolute -top-6 -right-6 h-40 w-40 text-info/15"
            viewBox="0 0 200 200"
            fill="none"
            aria-hidden="true"
          >
            <path d="M40 100 A 60 60 0 0 1 100 40" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeDasharray="6 8" />
            <path d="M55 110 A 45 45 0 0 1 100 65" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeDasharray="6 8" />
            <path d="M70 120 A 30 30 0 0 1 100 90" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeDasharray="6 8" />
            <line x1="40" y1="160" x2="160" y2="40" stroke="var(--friction)" strokeWidth="3" strokeLinecap="round" />
          </svg>

          <div className="relative flex flex-col items-center text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-info/10 text-info ring-1 ring-info/20">
              <WifiOff className="h-7 w-7" />
            </div>

            <span className="mt-5 block text-[68px] sm:text-[80px] font-bold tracking-tighter leading-none text-gradient-ink">
              Offline
            </span>

            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-info/10 px-2.5 py-1 text-[11px] font-medium text-info">
              <span className="h-1.5 w-1.5 rounded-full bg-info" />
              No connection
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              You appear to be offline.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              Check your connection and try again. Ooster works best with a
              stable network — some data may be cached locally.
            </p>

            <div className="mt-7 flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button size="lg" className="rounded-full" onClick={handleRetry}>
                <RotateCw className="mr-1.5 h-4 w-4" /> Retry connection
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
                onClick={() => router.push("/")}
              >
                <Link href="/">
                  <Home className="mr-1.5 h-4 w-4" /> Go home
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Your recent activity is saved and will sync once you reconnect.
        </p>
      </div>
    </main>
  );
}
