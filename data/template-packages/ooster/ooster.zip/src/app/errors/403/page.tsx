"use client";

import Link from "next/link";
import { ShieldX, ArrowLeft, KeyRound } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function ForbiddenPage() {
  const handleRequestAccess = () => {
    toast.success("Access request submitted", {
      description: "Your workspace admin has been notified. You'll hear back within 24h.",
    });
  };

  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Diagonal warning stripes — friction/coral */}
          <div
            className="pointer-events-none absolute -top-10 -left-10 h-40 w-40 opacity-[0.18] rounded-2xl rotate-12"
            style={{
              backgroundImage:
                "repeating-linear-gradient(45deg, var(--friction) 0 8px, transparent 8px 16px)",
            }}
            aria-hidden="true"
          />

          <div className="relative flex flex-col items-center text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-friction/10 text-friction ring-1 ring-friction/20">
              <ShieldX className="h-7 w-7" />
            </div>

            <span className="mt-5 block text-[88px] sm:text-[104px] font-bold tracking-tighter leading-none text-friction">
              403
            </span>

            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-friction/10 px-2.5 py-1 text-[11px] font-medium text-friction">
              <span className="h-1.5 w-1.5 rounded-full bg-friction" />
              Access denied
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              You don&apos;t have permission to view this resource.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              Contact your workspace admin if you believe this is an error.
              Roles and scopes are managed in{" "}
              <Link
                href="/teams"
                className="text-ink hover:underline"
              >
                Team settings
              </Link>
              .
            </p>

            <div className="mt-7 flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button
                size="lg"
                className="rounded-full"
                onClick={handleRequestAccess}
              >
                <KeyRound className="mr-1.5 h-4 w-4" /> Request access
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                <Link href="/">
                  <ArrowLeft className="mr-1.5 h-4 w-4" /> Back to dashboard
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Error code: <span className="font-mono">FORBIDDEN_403</span>
        </p>
      </div>
    </main>
  );
}
