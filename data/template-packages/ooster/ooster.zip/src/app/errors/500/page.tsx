"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { ServerCrash, RotateCw, ArrowLeft, LifeBuoy, ExternalLink } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";

export default function ServerErrorPage() {
  const router = useRouter();

  const handleRetry = () => {
    router.refresh();
  };

  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Glitch lines — destructive/red */}
          <div className="pointer-events-none absolute inset-0 opacity-50" aria-hidden="true">
            <div className="absolute top-6 left-0 h-px w-full bg-destructive/30" />
            <div className="absolute top-7 left-2 h-px w-2/3 bg-destructive/40" />
            <div className="absolute top-9 left-8 h-px w-3/4 bg-destructive/25" />
            <div className="absolute bottom-10 right-0 h-px w-1/2 bg-destructive/20" />
            <div className="absolute bottom-8 right-4 h-px w-2/5 bg-destructive/30" />
          </div>

          <div className="relative flex flex-col items-center text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/10 text-destructive ring-1 ring-destructive/20">
              <ServerCrash className="h-7 w-7" />
            </div>

            <span className="mt-5 block text-[88px] sm:text-[104px] font-bold tracking-tighter leading-none text-destructive">
              500
            </span>

            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-destructive/10 px-2.5 py-1 text-[11px] font-medium text-destructive">
              <span className="h-1.5 w-1.5 rounded-full bg-destructive" />
              Server error
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              Something went wrong on our end.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              Our team has been notified automatically. You can retry now, check
              the status page, or reach out to support.
            </p>

            <div className="mt-7 grid grid-cols-1 sm:grid-cols-3 gap-2 w-full">
              <Button size="lg" className="rounded-full" onClick={handleRetry}>
                <RotateCw className="mr-1.5 h-4 w-4" /> Try again
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                <a
                  href="https://status.ooster.app"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <ExternalLink className="mr-1.5 h-4 w-4" /> Status page
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                <Link href="/contact">
                  <LifeBuoy className="mr-1.5 h-4 w-4" /> Contact support
                </Link>
              </Button>
            </div>

            <Button
              asChild
              variant="ghost"
              size="sm"
              className="mt-3 rounded-full text-muted-foreground"
            >
              <Link href="/">
                <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back to dashboard
              </Link>
            </Button>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Incident ID:{" "}
          <span className="font-mono">INC-{new Date().getFullYear()}-7F4A2</span>
        </p>
      </div>
    </main>
  );
}
