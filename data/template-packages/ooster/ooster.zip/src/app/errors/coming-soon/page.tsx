"use client";

import * as React from "react";
import Link from "next/link";
import { Sparkles, ArrowLeft, Bell, CheckCircle2 } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function ComingSoonPage() {
  const [email, setEmail] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const handleNotify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Please enter a valid email address.");
      return;
    }
    setSubmitting(true);
    // Mock async submission
    window.setTimeout(() => {
      setSubmitting(false);
      toast.success("You're on the list!", {
        description: `We'll email ${email} the moment this feature ships.`,
        icon: <CheckCircle2 className="h-4 w-4" />,
      });
      setEmail("");
    }, 600);
  };

  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Sparkle particles — success/emerald */}
          <svg
            className="pointer-events-none absolute inset-0 h-full w-full text-success/15"
            viewBox="0 0 400 400"
            fill="none"
            aria-hidden="true"
          >
            <path d="M60 70 l3 8 l8 3 l-8 3 l-3 8 l-3 -8 l-8 -3 l8 -3 z" fill="currentColor" />
            <path d="M330 90 l2 6 l6 2 l-6 2 l-2 6 l-2 -6 l-6 -2 l6 -2 z" fill="currentColor" />
            <path d="M340 300 l4 10 l10 4 l-10 4 l-4 10 l-4 -10 l-10 -4 l10 -4 z" fill="currentColor" />
            <path d="M50 280 l2.5 7 l7 2.5 l-7 2.5 l-2.5 7 l-2.5 -7 l-7 -2.5 l7 -2.5 z" fill="currentColor" />
            <circle cx="200" cy="50" r="2.5" fill="currentColor" />
            <circle cx="80" cy="200" r="2" fill="currentColor" />
            <circle cx="360" cy="220" r="2" fill="currentColor" />
            <circle cx="190" cy="370" r="2.5" fill="currentColor" />
          </svg>

          <div className="relative flex flex-col items-center text-center">
            <div className="relative">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-success/10 text-success ring-1 ring-success/20">
                <Sparkles className="h-7 w-7" />
              </div>
              <Sparkles className="pointer-events-none absolute -right-2 -top-1 h-4 w-4 text-success/60" />
              <Sparkles className="pointer-events-none absolute -left-2 -bottom-1 h-3 w-3 text-success/50" />
            </div>

            <span className="mt-5 block text-[58px] sm:text-[68px] font-bold tracking-tighter leading-none text-gradient-ink">
              Coming soon
            </span>

            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-success/10 px-2.5 py-1 text-[11px] font-medium text-success">
              <span className="h-1.5 w-1.5 rounded-full bg-success" />
              In development
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              This feature is coming soon.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              Get notified when it launches — we&apos;ll only email you about
              this release, nothing else.
            </p>

            {/* Email form */}
            <form
              onSubmit={handleNotify}
              className="mt-6 w-full flex flex-col sm:flex-row gap-2"
            >
              <Input
                type="email"
                inputMode="email"
                autoComplete="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11 rounded-full sm:flex-1"
                aria-label="Email address"
              />
              <Button
                type="submit"
                size="lg"
                className="rounded-full h-11"
                disabled={submitting}
              >
                <Bell className="mr-1.5 h-4 w-4" />
                {submitting ? "Subscribing…" : "Notify me"}
              </Button>
            </form>

            <div className="mt-7">
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                <Link href="/">
                  <ArrowLeft className="mr-1.5 h-4 w-4" /> Back to dashboard
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Want early access?{" "}
          <Link href="/contact" className="text-ink hover:underline">
            Join the beta program
          </Link>
        </p>
      </div>
    </main>
  );
}
