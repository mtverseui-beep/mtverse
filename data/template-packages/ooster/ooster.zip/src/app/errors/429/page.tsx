"use client";

import * as React from "react";
import Link from "next/link";
import { GaugeCircle, ArrowLeft } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";

export default function TooManyRequestsPage() {
  const [remaining, setRemaining] = React.useState(60);

  React.useEffect(() => {
    if (remaining <= 0) return;
    const id = window.setInterval(() => {
      setRemaining((r) => (r <= 0 ? 0 : r - 1));
    }, 1000);
    return () => window.clearInterval(id);
  }, [remaining]);

  // 0..100 of the gauge, where 100 = full 60s left
  const gaugePct = Math.round((remaining / 60) * 100);
  const size = 132;
  const stroke = 8;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (gaugePct / 100) * circ;

  return (
    <main className="min-h-screen bg-shell flex flex-col items-center justify-center p-4 sm:p-6 font-sans">
      <Link
        href="/"
        className="absolute top-5 left-5 sm:top-7 sm:left-8"
        aria-label="Ooster home"
      >
        <Logo size="sm" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="relative rounded-3xl bg-card border border-soft shadow-pop p-8 sm:p-10 overflow-hidden">
          {/* Decorative arc lines — friction/coral */}
          <svg
            className="pointer-events-none absolute -top-10 -right-10 h-40 w-40 text-friction/15"
            viewBox="0 0 200 200"
            fill="none"
            aria-hidden="true"
          >
            <path d="M10 100 A 90 90 0 0 1 190 100" stroke="currentColor" strokeWidth="1.5" />
            <path d="M30 100 A 70 70 0 0 1 170 100" stroke="currentColor" strokeWidth="1.5" />
            <path d="M50 100 A 50 50 0 0 1 150 100" stroke="currentColor" strokeWidth="1.5" />
          </svg>

          <div className="relative flex flex-col items-center text-center">
            <span className="block text-[80px] sm:text-[96px] font-bold tracking-tighter leading-none text-friction">
              429
            </span>

            {/* Countdown gauge */}
            <div className="relative mt-3" style={{ width: size, height: size }}>
              <svg
                className="-rotate-90"
                width={size}
                height={size}
                viewBox={`0 0 ${size} ${size}`}
              >
                <circle
                  cx={size / 2}
                  cy={size / 2}
                  r={r}
                  fill="none"
                  stroke="var(--muted)"
                  strokeWidth={stroke}
                />
                <circle
                  cx={size / 2}
                  cy={size / 2}
                  r={r}
                  fill="none"
                  stroke="var(--friction)"
                  strokeWidth={stroke}
                  strokeLinecap="round"
                  strokeDasharray={circ}
                  strokeDashoffset={offset}
                  style={{ transition: "stroke-dashoffset 1s linear" }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <GaugeCircle className="h-5 w-5 text-friction" />
                <span className="mt-1 text-2xl font-semibold text-ink tabular-nums">
                  {remaining}
                </span>
                <span className="text-[10px] text-muted-foreground">seconds</span>
              </div>
            </div>

            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-friction/10 px-2.5 py-1 text-[11px] font-medium text-friction">
              <span className="h-1.5 w-1.5 rounded-full bg-friction" />
              Rate limited
            </div>

            <h1 className="mt-4 text-lg sm:text-xl font-semibold text-ink">
              You&apos;ve made too many requests.
            </h1>
            <p className="mt-2 text-sm text-muted-foreground max-w-sm">
              Please wait{" "}
              <span className="font-semibold text-ink tabular-nums">
                {remaining}
              </span>{" "}
              {remaining === 1 ? "second" : "seconds"} before trying again.
            </p>

            <div className="mt-7 flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full"
                disabled={remaining > 0}
              >
                <Link href="/" aria-disabled={remaining > 0}>
                  <ArrowLeft className="mr-1.5 h-4 w-4" /> Back to dashboard
                </Link>
              </Button>
            </div>
          </div>
        </div>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          Repeated rate-limiting? Review your{" "}
          <Link href="/api-keys" className="text-ink hover:underline">
            API rate limits
          </Link>
          .
        </p>
      </div>
    </main>
  );
}
