import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Documentation",
  description:
    "Get started with Ooster — install the SDK, configure your workspace, and ship your first UX audit in minutes.",
};

export default function DocsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
