"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  BookOpen,
  Download,
  Settings2,
  Component,
  Palette,
  Code2,
  Rocket,
  Terminal,
  ChevronRight,
  Search,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { cn } from "@/lib/utils";

const SECTIONS = [
  { id: "getting-started", label: "Getting Started", icon: BookOpen, active: true },
  { id: "installation", label: "Installation", icon: Download },
  { id: "configuration", label: "Configuration", icon: Settings2 },
  { id: "components", label: "Components", icon: Component },
  { id: "themes", label: "Themes", icon: Palette },
  { id: "api", label: "API", icon: Code2 },
  { id: "deployment", label: "Deployment", icon: Rocket },
];

const PREREQUISITES = [
  "Node.js 20+ and pnpm 9+",
  "An Ooster workspace (sign up at ooster.app)",
  "A project API key from Settings → API Keys",
  "A deploy target (Vercel, Netlify, or self-hosted Node)",
];

const INSTALL_STEPS = [
  {
    title: "Create a workspace",
    body: "Sign up at ooster.app and create your first workspace. You'll be guided through a 60-second onboarding flow.",
  },
  {
    title: "Install the Ooster SDK",
    body: "Add the SDK to your product. It weighs 22KB gzipped and runs entirely client-side, with no PII collected by default.",
  },
  {
    title: "Generate an API key",
    body: "Head to Settings → API Keys and generate a publishable key. Use it in the SDK init below.",
  },
  {
    title: "Run your first audit",
    body: "Once the SDK is live, navigate to Projects → your project → Run audit. Results typically land within 2 minutes.",
  },
];

const CODE_SNIPPET = `// 1. Install
pnpm add @ooster/sdk

// 2. Initialize in your app entry (e.g. app/layout.tsx)
import { OosterProvider } from "@ooster/sdk";

export default function RootLayout({ children }) {
  return (
    <OosterProvider
      apiKey={process.env.NEXT_PUBLIC_OOSTER_KEY!}
      workspace="acme"
      options={{
        captureHeatmaps: true,
        captureReplays: true,
        sampleRate: 1.0,
        respectDNT: true,
      }}
    >
      {children}
    </OosterProvider>
  );
}`;

export default function DocsPage() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-soft">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[300px] w-[760px] rounded-full bg-accent/40 blur-3xl opacity-60" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20 text-center">
          <Badge variant="secondary" className="rounded-full mb-4">
            <BookOpen className="h-3 w-3" /> Documentation
          </Badge>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-ink leading-[1.05]">
            Ooster <span className="text-gradient-ink">Documentation</span>
          </h1>
          <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to install, configure, and ship with Ooster —
            from your first SDK init to enterprise deployment.
          </p>
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="mt-7 max-w-xl mx-auto relative"
          >
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search the docs… (e.g. 'configure heatmaps')"
              className="h-11 pl-9 rounded-full"
            />
          </motion.div>
        </div>
      </section>

      {/* Two-column body */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid lg:grid-cols-[260px_1fr] gap-10">
          {/* Sidebar */}
          <aside className="lg:sticky lg:top-24 lg:self-start">
            <StaggerGroup>
              <nav aria-label="Doc sections" className="space-y-1">
                {SECTIONS.map((s) => {
                  const Icon = s.icon;
                  return (
                    <StaggerItem key={s.id}>
                      <a
                        href={`#${s.id}`}
                        className={cn(
                          "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors",
                          s.active
                            ? "bg-accent/60 text-ink font-medium"
                            : "text-muted-foreground hover:text-ink hover:bg-accent/40"
                        )}
                      >
                        <Icon className="h-4 w-4" />
                        {s.label}
                      </a>
                    </StaggerItem>
                  );
                })}
              </nav>
            </StaggerGroup>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.3 }}
            >
              <Card className="mt-6 rounded-2xl border-soft shadow-soft p-4 card-hover">
                <div className="text-xs font-semibold text-ink">Need a hand?</div>
                <p className="mt-1 text-xs text-muted-foreground">
                  Our support team replies within 4 business hours.
                </p>
                <Button
                  asChild
                  size="sm"
                  variant="outline"
                  className="mt-3 w-full rounded-full"
                >
                  <Link href="/contact">Contact support</Link>
                </Button>
              </Card>
            </motion.div>
          </aside>

          {/* Main content */}
          <div className="min-w-0 max-w-3xl">
            <motion.div
              id="getting-started"
              className="scroll-mt-24"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                <Link href="/docs" className="hover:text-ink">
                  Docs
                </Link>
                <ChevronRight className="h-3 w-3" />
                <span className="text-ink font-medium">Getting Started</span>
              </div>
              <h2 className="text-3xl font-semibold tracking-tight text-ink">
                Getting Started
              </h2>
              <p className="mt-4 text-base text-muted-foreground leading-relaxed">
                Ooster is a premium UX research &amp; product analytics platform.
                This guide walks you through installing the SDK, configuring
                your workspace, and running your first UX audit in under five
                minutes.
              </p>
            </motion.div>

            {/* Code snippet — subtle scale-in */}
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <Card className="mt-8 rounded-2xl border-soft shadow-soft overflow-hidden card-hover">
                <div className="flex items-center justify-between px-4 py-2.5 border-b border-soft bg-surface-2/40">
                  <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                    <Terminal className="h-3.5 w-3.5" /> app/layout.tsx
                  </div>
                  <Badge variant="secondary" className="rounded text-[10px]">
                    TypeScript
                  </Badge>
                </div>
                <pre className="p-4 sm:p-5 overflow-x-auto text-[12.5px] leading-relaxed font-mono">
                  <code className="text-ink">{CODE_SNIPPET}</code>
                </pre>
              </Card>
            </motion.div>

            {/* Prerequisites */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              className="mt-10"
            >
              <h3 className="text-xl font-semibold text-ink">Prerequisites</h3>
              <ul className="mt-4 space-y-2">
                {PREREQUISITES.map((p) => (
                  <li
                    key={p}
                    className="flex items-start gap-2.5 text-sm text-ink"
                  >
                    <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-success shrink-0" />
                    {p}
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Install steps */}
            <StaggerGroup className="mt-10">
              <h3 className="text-xl font-semibold text-ink mb-5">
                Install in 4 steps
              </h3>
              <ol className="space-y-5">
                {INSTALL_STEPS.map((step, i) => (
                  <StaggerItem key={step.title}>
                    <li className="flex gap-4">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-semibold shrink-0">
                        {i + 1}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-ink">
                          {step.title}
                        </div>
                        <p className="mt-1 text-sm text-muted-foreground">
                          {step.body}
                        </p>
                      </div>
                    </li>
                  </StaggerItem>
                ))}
              </ol>
            </StaggerGroup>

            {/* Next steps */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <Card className="mt-12 rounded-2xl border-soft shadow-soft p-6 card-hover">
                <h3 className="text-base font-semibold text-ink">Next steps</h3>
                <div className="mt-4 grid sm:grid-cols-2 gap-3">
                  <Link
                    href="/docs#configuration"
                    className="group flex items-center justify-between rounded-xl border border-soft p-4 hover:bg-accent/40 transition-colors"
                  >
                    <div>
                      <div className="text-sm font-semibold text-ink">
                        Configuration
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Heatmaps, replays, sampling
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-0.5 transition-transform" />
                  </Link>
                  <Link
                    href="/docs#api"
                    className="group flex items-center justify-between rounded-xl border border-soft p-4 hover:bg-accent/40 transition-colors"
                  >
                    <div>
                      <div className="text-sm font-semibold text-ink">API</div>
                      <div className="text-xs text-muted-foreground">
                        REST &amp; webhooks
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-0.5 transition-transform" />
                  </Link>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>
    </motion.div>
  );
}
