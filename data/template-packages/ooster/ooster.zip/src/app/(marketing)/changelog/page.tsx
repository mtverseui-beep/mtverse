"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Tag, Calendar, GitCommit } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Change = {
  type: "New" | "Improved" | "Fixed";
  text: string;
};

type Release = {
  version: string;
  date: string;
  summary: string;
  changes: Change[];
};

const RELEASES: Release[] = [
  {
    version: "v1.0.0",
    date: "Jun 28, 2026",
    summary:
      "The 1.0 release — a refined dashboard, AI reports v2, and a new research repository.",
    changes: [
      { type: "New", text: "AI research reports with cited session evidence" },
      { type: "New", text: "Research repository with personas & segments" },
      { type: "Improved", text: "Dashboard load times cut by 38%" },
      { type: "Fixed", text: "Heatmap rendering on high-DPI mobile devices" },
    ],
  },
  {
    version: "v0.12.0",
    date: "Jun 6, 2026",
    summary: "Journeys & funnels 2.0 with cross-session path analysis.",
    changes: [
      { type: "New", text: "Cross-session journey stitching" },
      { type: "Improved", text: "Funnel comparison view now supports 4 segments" },
      { type: "Fixed", text: "Timezone drift in scheduled reports" },
    ],
  },
  {
    version: "v0.11.0",
    date: "May 14, 2026",
    summary: "Heatmap engine rewrite — 5x faster, half the memory.",
    changes: [
      { type: "New", text: "Dead-click heatmap layer" },
      { type: "Improved", text: "Heatmap render performance (5x faster)" },
      { type: "Improved", text: "Rage-click detection accuracy" },
      { type: "Fixed", text: "Scroll depth tracking on lazy-loaded lists" },
    ],
  },
  {
    version: "v0.10.0",
    date: "Apr 22, 2026",
    summary: "Session replay playback with friction scoring & clip sharing.",
    changes: [
      { type: "New", text: "Friction scoring per session (0–100)" },
      { type: "New", text: "Clip sharing with deep-link timestamps" },
      { type: "Fixed", text: "Replay seeking on Safari 17+" },
    ],
  },
  {
    version: "v0.9.0",
    date: "Mar 30, 2026",
    summary: "Audit checklist & WCAG 2.2 coverage.",
    changes: [
      { type: "New", text: "WCAG 2.2 audit checklist (52 new criteria)" },
      { type: "Improved", text: "Audit issue prioritization algorithm" },
    ],
  },
  {
    version: "v0.8.0",
    date: "Mar 4, 2026",
    summary: "Team roles, audit logs, and SSO for Pro plans.",
    changes: [
      { type: "New", text: "Granular roles: Owner, Admin, Analyst, Viewer" },
      { type: "New", text: "Workspace audit logs (exportable)" },
      { type: "Improved", text: "SSO available on Pro and above" },
      { type: "Fixed", text: "Seat count over-counting on pending invites" },
    ],
  },
  {
    version: "v0.6.0",
    date: "Feb 12, 2026",
    summary: "Experiments & A/B testing module launch.",
    changes: [
      { type: "New", text: "Experiments module with significance testing" },
      { type: "New", text: "A/B test comparison dashboard" },
      { type: "Fixed", text: "Variant assignment drift in edge cases" },
    ],
  },
  {
    version: "v0.4.0",
    date: "Jan 18, 2026",
    summary: "First public beta — heatmaps, replays, and basic UX scoring.",
    changes: [
      { type: "New", text: "Public beta launch" },
      { type: "New", text: "Click, scroll, and attention heatmaps" },
      { type: "New", text: "Session replays with event timeline" },
      { type: "Improved", text: "UX score composite formula" },
    ],
  },
];

const tagStyles: Record<Change["type"], string> = {
  New: "bg-success/10 text-success",
  Improved: "bg-info/10 text-info",
  Fixed: "bg-friction/10 text-friction",
};

// Custom slide-in-from-left variant for timeline items
const slideInLeft = {
  hidden: { opacity: 0, x: -24 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function ChangelogPage() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-soft">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[300px] w-[760px] rounded-full bg-accent/40 blur-3xl opacity-60" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20 text-center">
          <Badge variant="secondary" className="rounded-full mb-4">
            <GitCommit className="h-3 w-3" /> Changelog
          </Badge>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-ink leading-[1.05]">
            What&apos;s <span className="text-gradient-ink">new</span>
          </h1>
          <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
            Every release, every improvement, every fix — straight from the
            team that ships Ooster.
          </p>
          <div className="mt-7 flex flex-col sm:flex-row gap-3 justify-center">
            <Button asChild size="lg" className="rounded-full h-12 px-6">
              <Link href="/sign-up">
                Try the latest <ArrowRight className="ml-1.5 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full h-12 px-6"
            >
              <a
                href="https://status.ooster.app"
                target="_blank"
                rel="noopener noreferrer"
              >
                View status
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Timeline — each release slides in from the left */}
      <section className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <motion.ol
          className="relative border-l border-soft ml-2"
          initial="hidden"
          animate="visible"
          variants={{ visible: { transition: { staggerChildren: 0.08, delayChildren: 0.1 } } }}
        >
          {RELEASES.map((release, i) => (
            <motion.li
              key={release.version}
              variants={slideInLeft}
              className="relative pl-8 pb-12 last:pb-0"
            >
              {/* Timeline node */}
              <span
                className={cn(
                  "absolute -left-[7px] top-1.5 h-3.5 w-3.5 rounded-full ring-4 ring-surface",
                  i === 0 ? "bg-success" : "bg-primary"
                )}
              />
              <Card className="rounded-2xl border-soft shadow-soft p-6 card-hover">
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <Badge
                    variant={i === 0 ? "default" : "secondary"}
                    className="rounded-full font-mono"
                  >
                    {release.version}
                  </Badge>
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" /> {release.date}
                  </span>
                  {i === 0 && (
                    <Badge
                      variant="outline"
                      className="rounded-full border-success/40 text-success"
                    >
                      Latest
                    </Badge>
                  )}
                </div>

                <p className="text-sm text-muted-foreground">
                  {release.summary}
                </p>

                <ul className="mt-4 space-y-2">
                  {release.changes.map((c, j) => (
                    <li
                      key={j}
                      className="flex items-start gap-2.5 text-sm"
                    >
                      <span
                        className={cn(
                          "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium shrink-0",
                          tagStyles[c.type]
                        )}
                      >
                        <Tag className="h-2.5 w-2.5" />
                        {c.type}
                      </span>
                      <span className="text-ink">{c.text}</span>
                    </li>
                  ))}
                </ul>

                <Link
                  href="#"
                  className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-primary hover:gap-1.5 transition-all"
                >
                  Full release notes <ArrowRight className="h-3 w-3" />
                </Link>
              </Card>
            </motion.li>
          ))}
        </motion.ol>
      </section>
    </motion.div>
  );
}
