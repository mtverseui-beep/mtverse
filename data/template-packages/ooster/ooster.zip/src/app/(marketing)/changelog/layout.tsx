import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Changelog",
  description:
    "What's new in Ooster — every release, every improvement, every fix. Stay up to date as we ship.",
};

export default function ChangelogLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
