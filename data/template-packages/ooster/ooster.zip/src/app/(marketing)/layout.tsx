import Link from "next/link";
import { Logo } from "@/components/layout/logo";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const NAV_LINKS = [
  { label: "Features", href: "/features" },
  { label: "Pricing", href: "/pricing" },
  { label: "Docs", href: "/docs" },
  { label: "Changelog", href: "/changelog" },
  { label: "Contact", href: "/contact" },
];

const FOOTER_COLUMNS = [
  {
    title: "Product",
    links: [
      { label: "Features", href: "/features" },
      { label: "Pricing", href: "/pricing" },
      { label: "Changelog", href: "/changelog" },
      { label: "Roadmap", href: "/changelog" },
      { label: "Help center", href: "/help" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "/" },
      { label: "Contact", href: "/contact" },
      { label: "Careers", href: "/" },
      { label: "Blog", href: "/" },
      { label: "Brand kit", href: "/" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Documentation", href: "/docs" },
      { label: "API reference", href: "/docs" },
      { label: "Status", href: "/" },
      { label: "Community", href: "/" },
      { label: "Webinars", href: "/" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy", href: "/" },
      { label: "Terms", href: "/" },
      { label: "Security", href: "/" },
      { label: "DPA", href: "/" },
      { label: "Cookies", href: "/" },
    ],
  },
];

export default function MarketingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-surface font-sans flex flex-col">
      {/* Top nav */}
      <header className="sticky top-0 z-40 border-b border-soft bg-surface shadow-soft">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-8">
              <Link href="/" aria-label="Ooster home" className="flex items-center">
                <Logo />
              </Link>
              <nav
                className="hidden md:flex items-center gap-1"
                aria-label="Marketing"
              >
                {NAV_LINKS.map((item) => (
                  <Link
                    key={item.href + item.label}
                    href={item.href}
                    className="rounded-full px-3 py-1.5 text-sm font-medium text-muted-foreground hover:text-ink hover:bg-accent/60 transition-colors"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
            </div>

            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button
                asChild
                variant="ghost"
                size="sm"
                className="hidden sm:inline-flex rounded-full"
              >
                <Link href="/sign-in">Sign in</Link>
              </Button>
              <Button asChild size="sm" className="rounded-full">
                <Link href="/sign-up">Get started</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 animate-fade-in">{children}</main>

      {/* Footer */}
      <footer className="border-t border-soft bg-surface-2/40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-8">
            <div className="col-span-2">
              <Link href="/" aria-label="Ooster home">
                <Logo size="lg" />
              </Link>
              <p className="mt-4 text-sm text-muted-foreground max-w-xs">
                Premium UX intelligence for modern product teams. Heatmaps,
                session replays, journeys, and AI research reports — all in one
                calm dashboard.
              </p>
              <p className="mt-4 text-xs text-muted-foreground">
                © {new Date().getFullYear()} Ooster Labs. All rights reserved.
              </p>
            </div>
            {FOOTER_COLUMNS.map((col) => (
              <div key={col.title}>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-ink">
                  {col.title}
                </h3>
                <ul className="mt-3 space-y-2">
                  {col.links.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className={cn(
                          "text-sm text-muted-foreground hover:text-ink transition-colors"
                        )}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-10 pt-6 border-t border-soft flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-muted-foreground">
            <span>Crafted for product &amp; research teams worldwide.</span>
            <div className="flex items-center gap-4">
              <Link href="/docs" className="hover:text-ink">Docs</Link>
              <Link href="/changelog" className="hover:text-ink">Changelog</Link>
              <Link href="/help" className="hover:text-ink">Help</Link>
              <span className="hidden sm:inline">v1.0.0</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
