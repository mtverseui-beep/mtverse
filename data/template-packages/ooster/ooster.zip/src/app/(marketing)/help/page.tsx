"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Search,
  Rocket,
  CreditCard,
  Lightbulb,
  Flame,
  FileBarChart,
  Code2,
  ArrowRight,
  Eye,
  LifeBuoy,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  {
    icon: Rocket,
    title: "Getting Started",
    description: "Onboarding, SDK install, and your first audit.",
    articles: 24,
    color: "var(--success)",
  },
  {
    icon: CreditCard,
    title: "Account & Billing",
    description: "Plans, invoices, seats, and renewals.",
    articles: 18,
    color: "var(--info)",
  },
  {
    icon: Lightbulb,
    title: "Projects & Insights",
    description: "Managing projects, insights, and recommendations.",
    articles: 31,
    color: "var(--warning)",
  },
  {
    icon: Flame,
    title: "Heatmaps & Sessions",
    description: "Heatmap layers, replay controls, and friction scoring.",
    articles: 27,
    color: "var(--friction)",
  },
  {
    icon: FileBarChart,
    title: "Reports & Research",
    description: "AI reports, research repo, personas, and surveys.",
    articles: 22,
    color: "var(--chart-5)",
  },
  {
    icon: Code2,
    title: "API & Webhooks",
    description: "REST endpoints, webhooks, SDKs, and rate limits.",
    articles: 35,
    color: "var(--chart-6)",
  },
];

const POPULAR = [
  { title: "How to install the Ooster SDK in a Next.js app", views: "12.4K", category: "Getting Started" },
  { title: "Understanding the composite UX score formula", views: "8.9K", category: "Projects & Insights" },
  { title: "Configuring heatmap sampling and privacy", views: "7.2K", category: "Heatmaps & Sessions" },
  { title: "Inviting teammates and managing roles", views: "6.7K", category: "Account & Billing" },
  { title: "Generating your first AI research report", views: "6.1K", category: "Reports & Research" },
  { title: "Webhook payloads and signature verification", views: "5.4K", category: "API & Webhooks" },
  { title: "Why am I seeing sampled sessions?", views: "4.8K", category: "Heatmaps & Sessions" },
  { title: "Upgrading or downgrading your plan mid-cycle", views: "4.2K", category: "Account & Billing" },
];

export default function HelpPage() {
  const [query, setQuery] = React.useState("");

  const filtered = React.useMemo(() => {
    if (!query.trim()) return POPULAR;
    const q = query.toLowerCase();
    return POPULAR.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Hero with branded gradient background + search */}
      <section className="relative overflow-hidden border-b border-soft">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-surface via-surface-2/40 to-surface" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[320px] w-[820px] rounded-full bg-accent/40 blur-3xl opacity-60" />
          <div className="absolute -top-16 -right-16 h-56 w-56 rounded-full bg-info/10 blur-3xl" />
          <div className="absolute -top-10 -left-16 h-48 w-48 rounded-full bg-success/10 blur-3xl" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24 text-center">
          <Badge variant="secondary" className="rounded-full mb-4">
            <LifeBuoy className="h-3 w-3" /> Help Center
          </Badge>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-ink leading-[1.05]">
            How can we <span className="text-gradient-ink">help?</span>
          </h1>
          <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
            Search our docs, browse by category, or get in touch with support.
            Most questions are answered in under two minutes.
          </p>
          <div className="mt-8 max-w-2xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search for help… (e.g. 'reset password', 'webhook setup')"
              className="h-14 pl-12 pr-4 rounded-full text-base shadow-soft"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-xs text-muted-foreground">
            <span>Popular:</span>
            {["Install SDK", "AI reports", "Webhooks", "Upgrade plan"].map(
              (t) => (
                <button
                  key={t}
                  onClick={() => setQuery(t)}
                  className="rounded-full border border-soft px-2.5 py-1 hover:bg-accent/40 hover:text-ink transition-colors"
                >
                  {t}
                </button>
              )
            )}
          </div>
        </div>
      </section>

      {/* Category grid */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-10"
        >
          <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-ink">
            Browse by category
          </h2>
          <p className="mt-2 text-muted-foreground">
            Six categories · 157 articles · all kept up to date.
          </p>
        </motion.div>
        <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            return (
              <StaggerItem key={cat.title} className="h-full">
                <Card
                  className="group rounded-2xl border-soft shadow-soft p-6 card-hover h-full cursor-pointer"
                >
                  <div
                    className="flex h-11 w-11 items-center justify-center rounded-xl"
                    style={{
                      backgroundColor: `color-mix(in oklch, ${cat.color} 12%, transparent)`,
                      color: cat.color,
                    }}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-4 text-lg font-semibold text-ink">
                    {cat.title}
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {cat.description}
                  </p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {cat.articles} articles
                    </span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-0.5 group-hover:text-ink transition-all" />
                  </div>
                </Card>
              </StaggerItem>
            );
          })}
        </StaggerGroup>
      </section>

      {/* Popular articles */}
      <section className="border-t border-soft bg-surface-2/40">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="flex items-end justify-between mb-8 flex-wrap gap-3"
          >
            <div>
              <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-ink">
                Popular articles
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                The most-read help articles this month.
              </p>
            </div>
            <Badge variant="secondary" className="rounded-full">
              {filtered.length} results
            </Badge>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden card-hover">
            <ul className="divide-y divide-[color:var(--border)]">
              {filtered.map((a, i) => (
                <li key={a.title}>
                  <Link
                    href="#"
                    className={cn(
                      "group flex items-center gap-4 px-5 py-4 hover:bg-accent/30 transition-colors"
                    )}
                  >
                    <span className="text-sm font-mono text-muted-foreground w-6">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium text-ink truncate">
                        {a.title}
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {a.category}
                      </div>
                    </div>
                    <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Eye className="h-3 w-3" /> {a.views} views
                    </span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-0.5 group-hover:text-ink transition-all" />
                  </Link>
                </li>
              ))}
              {filtered.length === 0 && (
                <li className="px-5 py-8 text-center text-sm text-muted-foreground">
                  No articles match &ldquo;{query}&rdquo;. Try a different
                  search or{" "}
                  <Link href="/contact" className="text-primary hover:underline">
                    contact support
                  </Link>
                  .
                </li>
              )}
            </ul>
          </Card>
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        >
        <Card className="rounded-3xl border-soft shadow-soft p-8 sm:p-12 text-center card-hover">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-info/10 text-info">
            <LifeBuoy className="h-6 w-6" />
          </div>
          <h2 className="mt-4 text-2xl sm:text-3xl font-semibold tracking-tight text-ink">
            Still need help?
          </h2>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
            Our support team is available 24/5 and typically replies within 4
            hours. We&apos;re happy to help with anything — from a quick
            &ldquo;how do I…&rdquo; to enterprise architecture questions.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
            <Button asChild size="lg" className="rounded-full h-12 px-6">
              <Link href="/contact">
                Contact support <ArrowRight className="ml-1.5 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full h-12 px-6"
            >
              <Link href="/docs">Browse docs</Link>
            </Button>
          </div>
        </Card>
        </motion.div>
      </section>
    </motion.div>
  );
}
