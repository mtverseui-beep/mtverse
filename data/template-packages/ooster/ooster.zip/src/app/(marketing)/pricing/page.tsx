"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Check,
  ArrowRight,
  Sparkles,
  HelpCircle,
  Minus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { cn } from "@/lib/utils";

type Plan = {
  name: string;
  price: string;
  cadence?: string;
  description: string;
  features: string[];
  cta: string;
  highlight?: boolean;
};

const PLANS: Plan[] = [
  {
    name: "Free",
    price: "$0",
    cadence: "forever",
    description: "For solo researchers and side projects.",
    features: [
      "1 project",
      "Up to 1,000 sessions / mo",
      "Heatmaps & replays (7-day history)",
      "Basic UX scoring",
      "Community support",
      "1 seat",
    ],
    cta: "Start for free",
  },
  {
    name: "Pro",
    price: "$120",
    cadence: "/mo",
    description: "For individual practitioners who need AI reports.",
    features: [
      "5 projects",
      "Up to 50,000 sessions / mo",
      "Full heatmap suite (90-day history)",
      "AI research reports (10 / mo)",
      "Journeys & funnels",
      "Email support",
      "1 seat",
      "API access",
    ],
    cta: "Start Pro trial",
  },
  {
    name: "Team",
    price: "$580",
    cadence: "/mo",
    description: "For growing product teams that ship together.",
    features: [
      "Unlimited projects",
      "Up to 250,000 sessions / mo",
      "Unlimited heatmap history",
      "Unlimited AI reports",
      "Research repository & personas",
      "Audit logs & roles",
      "25 seats included",
      "Priority support",
      "Integrations & webhooks",
    ],
    cta: "Start Team trial",
    highlight: true,
  },
  {
    name: "Enterprise",
    price: "$2,400",
    cadence: "/mo",
    description: "For organizations with security & scale requirements.",
    features: [
      "Everything in Team, plus:",
      "Unlimited sessions",
      "SSO / SAML & SCIM",
      "Custom data residency",
      "Dedicated success manager",
      "99.99% uptime SLA",
      "Custom AI model tuning",
      "On-prem deploy option",
      "Quarterly security reviews",
    ],
    cta: "Contact sales",
  },
];

const FAQS = [
  {
    q: "Can I change plans later?",
    a: "Yes — upgrade or downgrade at any time. Changes are prorated to the day and reflected on your next invoice.",
  },
  {
    q: "What counts as a session?",
    a: "A session is a single continuous visitor engagement, capped at 30 minutes of inactivity. Sessions above your plan limit are sampled, not dropped.",
  },
  {
    q: "Do you offer annual billing?",
    a: "Yes. Annual billing gives you two months free and locks in your rate for the year. Reach out to sales for custom multi-year terms.",
  },
  {
    q: "Is my data secure?",
    a: "Ooster is SOC 2 Type II compliant, GDPR-ready, and encrypts data in transit and at rest. Enterprise plans add SSO, SAML, SCIM, and custom data residency.",
  },
  {
    q: "Can I bring my own AI model?",
    a: "Enterprise customers can connect a private OpenAI, Anthropic, or on-prem model for AI report generation. All processing can be scoped to your tenant.",
  },
  {
    q: "What happens when my trial ends?",
    a: "After 14 days, your workspace automatically moves to the Free plan. Your data is retained for 90 days so you can upgrade without losing anything.",
  },
];

type Row = {
  feature: string;
  free: string | boolean;
  pro: string | boolean;
  team: string | boolean;
  enterprise: string | boolean;
};

const COMPARISON: Row[] = [
  { feature: "Projects", free: "1", pro: "5", team: "Unlimited", enterprise: "Unlimited" },
  { feature: "Sessions / month", free: "1K", pro: "50K", team: "250K", enterprise: "Unlimited" },
  { feature: "Heatmap history", free: "7 days", pro: "90 days", team: "Unlimited", enterprise: "Unlimited" },
  { feature: "AI reports", free: false, pro: "10 / mo", team: "Unlimited", enterprise: "Unlimited" },
  { feature: "Research repository", free: false, pro: true, team: true, enterprise: true },
  { feature: "Journeys & funnels", free: false, pro: true, team: true, enterprise: true },
  { feature: "Audit logs", free: false, pro: false, team: true, enterprise: true },
  { feature: "Seats included", free: "1", pro: "1", team: "25", enterprise: "Custom" },
  { feature: "SSO / SAML / SCIM", free: false, pro: false, team: false, enterprise: true },
  { feature: "Uptime SLA", free: false, pro: false, team: "99.9%", enterprise: "99.99%" },
];

function Cell({ v }: { v: string | boolean }) {
  if (v === true)
    return <Check className="h-4 w-4 text-success mx-auto" aria-label="Included" />;
  if (v === false)
    return <Minus className="h-4 w-4 text-muted-foreground/50 mx-auto" aria-label="Not included" />;
  return <span className="text-sm text-ink">{v}</span>;
}

export default function PricingPage() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-soft">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[320px] w-[820px] rounded-full bg-accent/40 blur-3xl opacity-60" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24 text-center">
          <Badge variant="secondary" className="rounded-full mb-4">
            Pricing
          </Badge>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-ink leading-[1.05]">
            Simple, <span className="text-gradient-ink">transparent pricing</span>
          </h1>
          <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
            Start free, scale when you&apos;re ready. Every plan includes the
            full product — you only pay for volume and advanced governance.
          </p>
        </div>
      </section>

      {/* Plan cards */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <StaggerGroup className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {PLANS.map((plan) => (
            <StaggerItem key={plan.name} className="h-full">
              <Card
                className={cn(
                  "relative rounded-3xl p-6 flex flex-col h-full card-hover",
                  plan.highlight
                    ? "border-primary/40 shadow-pop ring-1 ring-primary/20 glow-ring"
                    : "border-soft shadow-soft"
                )}
              >
                {plan.highlight && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full px-3 shadow-soft">
                    <Sparkles className="h-3 w-3" /> Most popular
                  </Badge>
                )}
                <div className="text-sm font-semibold text-ink">{plan.name}</div>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className="text-4xl font-semibold tracking-tight text-ink">
                    {plan.price}
                  </span>
                  {plan.cadence && (
                    <span className="text-sm text-muted-foreground">
                      {plan.cadence}
                    </span>
                  )}
                </div>
                <p className="mt-2 text-sm text-muted-foreground min-h-[40px]">
                  {plan.description}
                </p>

                <Button
                  asChild
                  className="mt-5 rounded-full h-10"
                  variant={plan.highlight ? "default" : "outline"}
                >
                  <Link href={plan.name === "Enterprise" ? "/contact" : "/sign-up"}>
                    {plan.cta}
                  </Link>
                </Button>

                <ul className="mt-6 space-y-2.5 text-sm">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check className="mt-0.5 h-4 w-4 text-success shrink-0" />
                      <span className="text-ink">{f}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* FAQ */}
      <section className="border-t border-soft bg-surface-2/40">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
          <div className="text-center mb-10">
            <Badge variant="secondary" className="rounded-full mb-3">
              <HelpCircle className="h-3 w-3" /> FAQ
            </Badge>
            <h2 className="text-3xl font-semibold tracking-tight text-ink">
              Frequently asked questions
            </h2>
          </div>
          <Card className="rounded-2xl border-soft shadow-soft p-6 sm:p-8">
            <StaggerGroup>
              <Accordion
                type="single"
                collapsible
                className="w-full"
              >
                {FAQS.map((faq, i) => (
                  <StaggerItem key={faq.q}>
                    <AccordionItem value={`item-${i}`}>
                      <AccordionTrigger className="text-left text-base font-medium text-ink">
                        {faq.q}
                      </AccordionTrigger>
                      <AccordionContent className="text-sm text-muted-foreground">
                        {faq.a}
                      </AccordionContent>
                    </AccordionItem>
                  </StaggerItem>
                ))}
              </Accordion>
            </StaggerGroup>
          </Card>
        </div>
      </section>

      {/* Comparison table */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="text-center mb-10">
            <h2 className="text-3xl font-semibold tracking-tight text-ink">
              Compare plans in detail
            </h2>
            <p className="mt-3 text-muted-foreground">
              Every feature, side by side.
            </p>
          </div>

          <Card className="rounded-2xl border-soft shadow-soft overflow-hidden card-hover">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-soft bg-surface-2/40">
                  <th className="text-left font-semibold text-ink px-5 py-4 min-w-[220px]">
                    Feature
                  </th>
                  <th className="text-center font-semibold text-ink px-4 py-4 min-w-[110px]">
                    Free
                  </th>
                  <th className="text-center font-semibold text-ink px-4 py-4 min-w-[110px]">
                    Pro
                  </th>
                  <th className="text-center font-semibold text-ink px-4 py-4 min-w-[110px] bg-primary/5">
                    Team
                  </th>
                  <th className="text-center font-semibold text-ink px-4 py-4 min-w-[110px]">
                    Enterprise
                  </th>
                </tr>
              </thead>
              <tbody>
                {COMPARISON.map((row, i) => (
                  <tr
                    key={row.feature}
                    className={cn(
                      "border-b border-soft last:border-b-0",
                      i % 2 === 1 && "bg-surface-2/20"
                    )}
                  >
                    <td className="px-5 py-3.5 font-medium text-ink">
                      {row.feature}
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <Cell v={row.free} />
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <Cell v={row.pro} />
                    </td>
                    <td className="px-4 py-3.5 text-center bg-primary/5">
                      <Cell v={row.team} />
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <Cell v={row.enterprise} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

          <p className="mt-4 text-center text-xs text-muted-foreground inline-flex items-center justify-center gap-3 w-full">
            <span className="inline-flex items-center gap-1.5">
              <Check className="h-3 w-3 text-success" /> Included
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Minus className="h-3 w-3" /> Not included
            </span>
          </p>

          <div className="mt-10 text-center">
            <Button asChild size="lg" className="rounded-full h-12 px-6">
              <Link href="/sign-up">
                Start your free trial <ArrowRight className="ml-1.5 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </motion.div>
      </section>
    </motion.div>
  );
}
