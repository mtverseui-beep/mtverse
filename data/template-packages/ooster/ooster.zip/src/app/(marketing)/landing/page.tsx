"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight,
  PlayCircle,
  ScanSearch,
  Flame,
  PlayCircle as PlayIcon,
  Sparkles,
  Microscope,
  GitBranch,
  CheckCircle2,
  Star,
  Quote,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  StaggerGroup,
  StaggerItem,
  AnimatedNumber,
} from "@/components/common/motion";
import { ScreenMockup } from "@/components/common/screen-mockup";

const TRUSTED_BY = [
  "Northwind",
  "Lumen Labs",
  "Vertex",
  "Cobalt",
  "Maple & Co",
  "Parable",
];

const FEATURES = [
  {
    icon: ScanSearch,
    title: "UX Audits",
    description:
      "Automated heuristic & WCAG audits across every screen, with prioritized recommendations.",
  },
  {
    icon: Flame,
    title: "Heatmaps",
    description:
      "Click, scroll, attention, rage, and dead-click heatmaps layered on real session data.",
  },
  {
    icon: PlayIcon,
    title: "Session Replays",
    description:
      "Replay real user sessions with rich event timelines, filters, and friction scoring.",
  },
  {
    icon: Sparkles,
    title: "AI Reports",
    description:
      "One-click research reports — competitor, journey, executive, audit — generated with cited evidence.",
  },
  {
    icon: Microscope,
    title: "Research Repo",
    description:
      "A searchable repository of studies, interviews, surveys, personas, and segments.",
  },
  {
    icon: GitBranch,
    title: "Journeys",
    description:
      "Map real user journeys and funnels, quantify drop-off, and surface friction hotspots.",
  },
];

const STATS = [
  { label: "Researchers", value: 50, suffix: "K+", sublabel: "active monthly" },
  { label: "Insights generated", value: 2, suffix: "M+", sublabel: "across all teams" },
  { label: "Heatmaps analyzed", value: 1.2, suffix: "M+", sublabel: "last 30 days" },
  { label: "Uptime", value: 99.9, suffix: "%", sublabel: "trailing 12 months" },
];

const HERO_HEADING = ["Premium", "UX", "intelligence", "for", "modern", "product", "teams"];

const wordContainer = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.06, delayChildren: 0.1 },
  },
};
const wordItem = {
  hidden: { opacity: 0, y: 14 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function LandingPage() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* ───────────────────────── Hero ───────────────────────── */}
      <section className="relative overflow-hidden">
        {/* Branded gradient backdrop — no stock photos */}
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-surface via-surface-2/40 to-surface" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[420px] w-[820px] rounded-full bg-accent/40 blur-3xl opacity-60" />
          <div className="absolute -top-24 -right-24 h-64 w-64 rounded-full bg-success/10 blur-3xl" />
          <div className="absolute -top-16 -left-24 h-64 w-64 rounded-full bg-info/10 blur-3xl" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 sm:pt-24 lg:pt-28 pb-12 lg:pb-20">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            {/* Copy */}
            <div className="text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              >
                <Badge
                  variant="secondary"
                  className="mb-5 rounded-full px-3 py-1 text-[11px]"
                >
                  <Sparkles className="h-3 w-3 text-success" />
                  New · AI research reports v1.1
                </Badge>
              </motion.div>

              <motion.h1
                variants={wordContainer}
                initial="hidden"
                animate="visible"
                className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-ink leading-[1.05] flex flex-wrap justify-center lg:justify-start gap-x-[0.25em] gap-y-0"
                aria-label="Premium UX intelligence for modern product teams"
              >
                {HERO_HEADING.map((word, i) => (
                  <motion.span
                    key={`${word}-${i}`}
                    variants={wordItem}
                    className={i >= 4 ? "text-gradient-ink" : undefined}
                  >
                    {word}
                  </motion.span>
                ))}
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.55, ease: [0.22, 1, 0.36, 1] }}
                className="mt-5 text-base sm:text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0"
              >
                Ooster unifies heatmaps, session replays, journey &amp; funnel
                analysis, AI reports, and a research repository — in one calm,
                fast dashboard your whole team will actually use.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.65, ease: [0.22, 1, 0.36, 1] }}
                className="mt-8 flex flex-col sm:flex-row gap-3 justify-center lg:justify-start"
              >
                <Button asChild size="lg" className="rounded-full h-12 px-6">
                  <Link href="/sign-up">
                    Get started <ArrowRight className="ml-1.5 h-4 w-4" />
                  </Link>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="rounded-full h-12 px-6"
                >
                  <Link href="/features">
                    <PlayCircle className="mr-1.5 h-4 w-4" /> View demo
                  </Link>
                </Button>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.8 }}
                className="mt-7 flex items-center gap-5 justify-center lg:justify-start text-xs text-muted-foreground"
              >
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-3.5 w-3.5 text-success" /> 14-day
                  free trial
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-3.5 w-3.5 text-success" /> No credit
                  card required
                </span>
              </motion.div>
            </div>

            {/* Floating ScreenMockup hero card */}
            <motion.div
              className="relative"
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            >
              <Card className="relative rounded-3xl border-soft shadow-pop overflow-hidden card-hover">
                <div className="flex items-center justify-between px-5 sm:px-6 pt-4 pb-3 border-b border-soft bg-surface-2/60">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-friction/70" />
                    <span className="h-2.5 w-2.5 rounded-full bg-warning/70" />
                    <span className="h-2.5 w-2.5 rounded-full bg-success/70" />
                  </div>
                  <span className="text-[11px] text-muted-foreground font-mono truncate">
                    ooster.app/projects/acme-store
                  </span>
                  <Badge
                    variant="secondary"
                    className="rounded-full text-[10px]"
                  >
                    Live
                  </Badge>
                </div>
                <div className="relative h-[340px] sm:h-[380px] bg-surface">
                  <ScreenMockup variant="dashboard" />
                </div>
              </Card>

              {/* Floating mini-card */}
              <motion.div
                initial={{ opacity: 0, y: 16, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.7, ease: [0.22, 1, 0.36, 1] }}
                className="hidden sm:block absolute -bottom-5 -left-5 rounded-2xl bg-card border border-soft shadow-pop p-3 w-44"
              >
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-success/10 text-success">
                    <Sparkles className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[11px] text-muted-foreground">
                      AI report ready
                    </div>
                    <div className="text-xs font-semibold text-ink truncate">
                      Competitor audit · Acme
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ────────────────────── Trusted by ────────────────────── */}
      <section className="border-y border-soft bg-surface-2/40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.4 }}
            className="text-center text-xs uppercase tracking-wider text-muted-foreground mb-5"
          >
            Trusted by product teams at
          </motion.p>
          <StaggerGroup className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 items-center">
            {TRUSTED_BY.map((name) => (
              <StaggerItem
                key={name}
                className="text-center text-base sm:text-lg font-semibold text-muted-foreground/70 hover:text-ink transition-colors"
              >
                {name}
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* ─────────────────────── Features ─────────────────────── */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-2xl mx-auto text-center mb-12"
        >
          <Badge variant="secondary" className="rounded-full mb-3">
            One platform
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-ink">
            Everything your team needs to ship better UX
          </h2>
          <p className="mt-4 text-muted-foreground">
            Stop stitching together five tools. Ooster brings qualitative and
            quantitative UX research under one roof — with AI doing the heavy
            lifting.
          </p>
        </motion.div>

        <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <StaggerItem key={f.title}>
                <Card className="rounded-2xl border-soft shadow-soft p-6 card-hover h-full">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-surface-2 text-primary">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-4 text-lg font-semibold text-ink">
                    {f.title}
                  </h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {f.description}
                  </p>
                  <Link
                    href="/features"
                    className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary hover:gap-1.5 transition-all"
                  >
                    Learn more <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </Card>
              </StaggerItem>
            );
          })}
        </StaggerGroup>
      </section>

      {/* ─────────────────────── Stats band ───────────────────── */}
      <section className="bg-surface-2/50 border-y border-soft">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14 lg:py-16">
          <StaggerGroup className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6">
            {STATS.map((s) => (
              <StaggerItem key={s.label} className="text-center">
                <div className="text-4xl sm:text-5xl font-semibold tracking-tight text-gradient-ink">
                  <AnimatedNumber
                    value={s.value}
                    duration={1.4}
                    format={(v) => {
                      // Preserve one decimal for 99.9 / 1.2; otherwise round
                      const rounded = Math.round(v * 10) / 10;
                      return `${rounded}${s.suffix}`;
                    }}
                  />
                </div>
                <div className="mt-2 text-sm font-medium text-ink">
                  {s.label}
                </div>
                <div className="text-xs text-muted-foreground">{s.sublabel}</div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* ─────────────────────── Testimonial ──────────────────── */}
      <section className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        >
          <Card className="rounded-3xl border-soft shadow-soft p-8 sm:p-12 card-hover">
            <Quote className="h-10 w-10 text-success/40" />
            <blockquote className="mt-5 text-xl sm:text-2xl font-medium tracking-tight text-ink leading-snug">
              “Ooster cut our research synthesis time in half. The AI reports are
              genuinely useful — they cite real sessions, not vibes — and our
              designers finally trust the analytics dashboard.”
            </blockquote>
            <div className="mt-6 flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-surface-2 text-ink font-semibold">
                MA
              </div>
              <div>
                <div className="text-sm font-semibold text-ink">Maya Aronsohn</div>
                <div className="text-xs text-muted-foreground">
                  Head of UX Research · Lumen Labs
                </div>
              </div>
              <div className="ml-auto flex items-center gap-0.5 text-warning">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
            </div>
          </Card>
        </motion.div>
      </section>

      {/* ─────────────────────── CTA ──────────────────────────── */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="relative overflow-hidden rounded-3xl bg-primary text-primary-foreground p-8 sm:p-12 lg:p-16"
        >
          <div className="pointer-events-none absolute -top-24 -right-24 h-72 w-72 rounded-full bg-success/20 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-info/20 blur-3xl" />
          <div className="relative grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight">
                Start your free trial
              </h2>
              <p className="mt-3 text-primary-foreground/80 max-w-md">
                Get full access to Ooster for 14 days. Invite your team, connect
                a project, and ship your first audit on day one.
              </p>
            </div>
            <div className="lg:justify-self-end w-full lg:w-auto">
              <Card className="rounded-2xl bg-card text-card-foreground p-5 sm:p-6 w-full lg:w-80 card-hover">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">
                  Team plan · from
                </div>
                <div className="mt-1 flex items-baseline gap-1">
                  <span className="text-4xl font-semibold tracking-tight text-ink">
                    $580
                  </span>
                  <span className="text-sm text-muted-foreground">/mo</span>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  {[
                    "Up to 25 seats",
                    "Unlimited projects & heatmaps",
                    "AI reports included",
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 text-success shrink-0" />
                      <span className="text-ink">{item}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  asChild
                  className="mt-5 w-full rounded-full h-11"
                >
                  <Link href="/sign-up">
                    Start free trial <ArrowRight className="ml-1.5 h-4 w-4" />
                  </Link>
                </Button>
                <Link
                  href="/pricing"
                  className="mt-3 block text-center text-xs text-muted-foreground hover:text-ink"
                >
                  Compare all plans →
                </Link>
              </Card>
            </div>
          </div>
        </motion.div>
      </section>
    </motion.div>
  );
}
