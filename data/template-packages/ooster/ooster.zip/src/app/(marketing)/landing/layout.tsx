import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Ooster — Premium UX intelligence for modern product teams",
  description:
    "Heatmaps, session replays, journeys, funnels, AI research reports, and a research repository — all in one calm, premium dashboard built for product teams.",
};

export default function LandingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
