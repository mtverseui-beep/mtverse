import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Features",
  description:
    "Explore every Ooster feature — UX audits, heatmaps, session replays, journeys, funnels, AI reports, research repository, team management, and more.",
};

export default function FeaturesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
