"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  FolderKanban,
  Lightbulb,
  Flame,
  PlayCircle,
  GitBranch,
  Filter,
  FileBarChart,
  Microscope,
  Users,
  History,
  Settings,
  ArrowRight,
  CheckCircle2,
  ScanSearch,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";

const FEATURES = [
  {
    icon: LayoutDashboard,
    name: "Dashboard",
    description:
      "A calm command center with your aggregate UX score, friction hotspots, recent activity, and AI-curated recommendations.",
    href: "/",
    color: "var(--info)",
  },
  {
    icon: FolderKanban,
    name: "Projects",
    description:
      "Manage your portfolio of web, mobile, prototype, and design-system projects. Track UX scores, owners, and recent activity at a glance.",
    href: "/projects",
    color: "var(--primary)",
  },
  {
    icon: Lightbulb,
    name: "Insights",
    description:
      "A prioritized recommendation engine that surfaces the most impactful UX issues with confidence, evidence, and affected screens.",
    href: "/insights",
    color: "var(--warning)",
  },
  {
    icon: Flame,
    name: "Heatmaps",
    description:
      "Click, scroll, attention, rage, and dead-click heatmaps — device-aware and layered on real session data.",
    href: "/heatmaps",
    color: "var(--friction)",
  },
  {
    icon: PlayCircle,
    name: "Session Replays",
    description:
      "Replay real user sessions with rich event timelines, filters, friction scoring, and one-click clip sharing.",
    href: "/session-replays",
    color: "var(--chart-5)",
  },
  {
    icon: GitBranch,
    name: "Journeys",
    description:
      "Map real user journeys, identify common paths, and quantify friction across multi-session flows.",
    href: "/journeys",
    color: "var(--success)",
  },
  {
    icon: Filter,
    name: "Funnels",
    description:
      "Build conversion funnels with drop-off analysis, segment comparisons, and time-to-convert metrics.",
    href: "/funnels",
    color: "var(--chart-6)",
  },
  {
    icon: FileBarChart,
    name: "Reports",
    description:
      "AI-generated research reports — competitor, task-flow, journey, executive, audit, benchmark — with cited evidence.",
    href: "/reports",
    color: "var(--info)",
  },
  {
    icon: Microscope,
    name: "Research Repository",
    description:
      "A searchable knowledge base of studies, interviews, surveys, personas, and segments your whole team can reference.",
    href: "/research",
    color: "var(--chart-3)",
  },
  {
    icon: Users,
    name: "Team",
    description:
      "Invite teammates, manage roles & scopes, and see who did what with full audit logs.",
    href: "/teams",
    color: "var(--primary)",
  },
  {
    icon: History,
    name: "History",
    description:
      "A complete timeline of every analysis, report, insight, and change across your workspace.",
    href: "/history",
    color: "var(--chart-4)",
  },
  {
    icon: Settings,
    name: "Settings",
    description:
      "Workspace & account settings, billing, integrations, API keys, webhooks, and data export.",
    href: "/teams",
    color: "var(--muted-foreground)",
  },
] as const;

const ADDITIONAL = [
  { icon: ScanSearch, name: "UX Audits", text: "WCAG-aware heuristic audits across every screen." },
  { icon: Sparkles, name: "AI Synthesis", text: "Auto-summarize research into themed insights." },
] as const;

export default function FeaturesPage() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-soft">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[320px] w-[820px] rounded-full bg-accent/40 blur-3xl opacity-60" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24 text-center">
          <Badge variant="secondary" className="rounded-full mb-4">
            Features
          </Badge>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-ink leading-[1.05]">
            Everything you need to ship{" "}
            <span className="text-gradient-ink">better UX</span>
          </h1>
          <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
            Twelve tightly-integrated modules that take you from raw session
            data to prioritized, evidence-backed recommendations — without
            switching tabs.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <Button asChild size="lg" className="rounded-full h-12 px-6">
              <Link href="/sign-up">
                Start free trial <ArrowRight className="ml-1.5 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full h-12 px-6"
            >
              <Link href="/pricing">See pricing</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Feature grid */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <StaggerItem key={f.name} className="h-full">
                <Card className="group rounded-2xl border-soft shadow-soft p-6 card-hover h-full">
                  <div
                    className="flex h-11 w-11 items-center justify-center rounded-xl"
                    style={{
                      backgroundColor: `color-mix(in oklch, ${f.color} 12%, transparent)`,
                      color: f.color,
                    }}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-4 text-lg font-semibold text-ink">
                    {f.name}
                  </h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {f.description}
                  </p>
                  <Link
                    href={f.href}
                    className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-primary group-hover:gap-1.5 transition-all"
                  >
                    Learn more <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </Card>
              </StaggerItem>
            );
          })}
        </StaggerGroup>
      </section>

      {/* Bonus strip */}
      <section className="border-t border-soft bg-surface-2/40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {ADDITIONAL.map((f) => {
              const Icon = f.icon;
              return (
                <StaggerItem key={f.name}>
                  <Card className="rounded-2xl border-soft shadow-soft p-6 flex items-start gap-4 card-hover">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-success/10 text-success shrink-0">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-ink">
                        {f.name}
                      </h3>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {f.text}
                      </p>
                    </div>
                  </Card>
                </StaggerItem>
              );
            })}
          </StaggerGroup>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        >
          <Card className="rounded-3xl border-soft shadow-soft p-8 sm:p-12 text-center card-hover">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-ink">
              Ready to see Ooster in action?
            </h2>
            <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
              Spin up a workspace in 60 seconds. Invite your team. Connect a
              project and run your first audit on day one.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
              <Button asChild size="lg" className="rounded-full h-12 px-6">
                <Link href="/sign-up">
                  Get started <ArrowRight className="ml-1.5 h-4 w-4" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full h-12 px-6"
              >
                <Link href="/contact">Talk to sales</Link>
              </Button>
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 justify-center text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-success" /> 14-day trial
              </span>
              <span className="inline-flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-success" /> SOC 2 Type II
              </span>
              <span className="inline-flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-success" /> GDPR ready
              </span>
            </div>
          </Card>
        </motion.div>
      </section>
    </motion.div>
  );
}
