"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Send,
  Mail,
  Headphones,
  Newspaper,
  Clock,
  Github,
  Twitter,
  Linkedin,
  MessageSquare,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { ScreenMockup } from "@/components/common/screen-mockup";
import { toast } from "sonner";

const CONTACT_OPTIONS = [
  {
    icon: Send,
    title: "Sales",
    email: "sales@ooster.app",
    response: "Within 1 business day",
    description: "Pricing, plans, demos, and procurement.",
  },
  {
    icon: Headphones,
    title: "Support",
    email: "support@ooster.app",
    response: "Within 4 hours · 24/5",
    description: "Technical issues, bugs, and how-to questions.",
  },
  {
    icon: Newspaper,
    title: "Press",
    email: "press@ooster.app",
    response: "Within 2 business days",
    description: "Media inquiries, brand assets, and partnerships.",
  },
];

const SOCIALS = [
  { icon: Twitter, label: "Twitter / X", href: "#" },
  { icon: Github, label: "GitHub", href: "#" },
  { icon: Linkedin, label: "LinkedIn", href: "#" },
  { icon: MessageSquare, label: "Discord", href: "#" },
];

export default function ContactPage() {
  const [submitting, setSubmitting] = React.useState(false);
  const [form, setForm] = React.useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });

  const update = (k: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error("Please fill in your name, email, and message.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      toast.error("Please enter a valid email address.");
      return;
    }
    setSubmitting(true);
    window.setTimeout(() => {
      setSubmitting(false);
      toast.success("Message sent", {
        description: "We'll get back to you within one business day.",
        icon: <CheckCircle2 className="h-4 w-4" />,
      });
      setForm({ name: "", email: "", company: "", message: "" });
    }, 700);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Hero with branded gradient + floating ScreenMockup card */}
      <section className="relative overflow-hidden border-b border-soft">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-surface via-surface-2/40 to-surface" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 h-[300px] w-[760px] rounded-full bg-accent/40 blur-3xl opacity-60" />
          <div className="absolute -top-16 -right-16 h-56 w-56 rounded-full bg-info/10 blur-3xl" />
          <div className="absolute -top-10 -left-16 h-48 w-48 rounded-full bg-success/10 blur-3xl" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="grid lg:grid-cols-[1.2fr_1fr] gap-10 items-center">
            <div className="text-center lg:text-left">
              <Badge variant="secondary" className="rounded-full mb-4">
                <Mail className="h-3 w-3" /> Contact
              </Badge>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-ink leading-[1.05]">
                Get in <span className="text-gradient-ink">touch</span>
              </h1>
              <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto lg:mx-0">
                Questions about pricing, technical issues, or partnerships? We
                typically reply within one business day.
              </p>
            </div>
            <motion.div
              initial={{ opacity: 0, y: 16, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
              className="relative hidden lg:block"
            >
              <Card className="rounded-2xl border-soft shadow-pop overflow-hidden">
                <div className="relative h-64 bg-surface">
                  <ScreenMockup variant="dashboard" />
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid lg:grid-cols-[1.2fr_1fr] gap-8">
          {/* Form — slide-up on mount */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
          <Card className="rounded-3xl border-soft shadow-soft p-6 sm:p-8 card-hover">
            <h2 className="text-2xl font-semibold tracking-tight text-ink">
              Send us a message
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Tell us a little about what you need. The more context, the
              faster we can help.
            </p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Name *</Label>
                  <Input
                    id="name"
                    placeholder="Jane Doe"
                    value={form.name}
                    onChange={update("name")}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="email">Work email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="jane@company.com"
                    value={form.email}
                    onChange={update("email")}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="company">Company</Label>
                <Input
                  id="company"
                  placeholder="Acme Inc."
                  value={form.company}
                  onChange={update("company")}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="message">Message *</Label>
                <Textarea
                  id="message"
                  rows={6}
                  placeholder="Tell us what you're trying to accomplish, your team size, and any specific questions…"
                  value={form.message}
                  onChange={update("message")}
                />
              </div>

              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2">
                <p className="text-xs text-muted-foreground">
                  By submitting, you agree to our Privacy Policy.
                </p>
                <Button
                  type="submit"
                  size="lg"
                  className="rounded-full w-full sm:w-auto"
                  disabled={submitting}
                >
                  <Send className="mr-1.5 h-4 w-4" />
                  {submitting ? "Sending…" : "Send message"}
                </Button>
              </div>
            </form>
          </Card>
          </motion.div>

          {/* Right column: contact options + hours + socials */}
          <StaggerGroup className="space-y-5">
            <StaggerItem>
            <Card className="rounded-2xl border-soft shadow-soft p-6 card-hover">
              <h3 className="text-sm font-semibold text-ink">
                Contact options
              </h3>
              <div className="mt-4 space-y-4">
                {CONTACT_OPTIONS.map((opt) => {
                  const Icon = opt.icon;
                  return (
                    <div
                      key={opt.title}
                      className="flex items-start gap-3"
                    >
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-surface-2 text-primary shrink-0">
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold text-ink">
                            {opt.title}
                          </span>
                          <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                            <Clock className="h-3 w-3" /> {opt.response}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {opt.description}
                        </p>
                        <a
                          href={`mailto:${opt.email}`}
                          className="mt-1 inline-block text-xs font-medium text-primary hover:underline"
                        >
                          {opt.email}
                        </a>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
            </StaggerItem>

            <StaggerItem>
            <Card className="rounded-2xl border-soft shadow-soft p-6 card-hover">
              <h3 className="text-sm font-semibold text-ink">Office hours</h3>
              <div className="mt-3 space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Support</span>
                  <span className="text-ink">Mon–Fri · 24/5</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Sales</span>
                  <span className="text-ink">Mon–Fri · 9am–6pm UTC</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Press</span>
                  <span className="text-ink">Mon–Fri · 10am–4pm UTC</span>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
                <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
                All systems operational
              </div>
            </Card>
            </StaggerItem>

            <StaggerItem>
            <Card className="rounded-2xl border-soft shadow-soft p-6 card-hover">
              <h3 className="text-sm font-semibold text-ink">Follow along</h3>
              <p className="mt-1 text-xs text-muted-foreground">
                Product updates, research reads, and community.
              </p>
              <div className="mt-4 grid grid-cols-4 gap-2">
                {SOCIALS.map((s) => {
                  const Icon = s.icon;
                  return (
                    <a
                      key={s.label}
                      href={s.href}
                      aria-label={s.label}
                      className="flex h-11 items-center justify-center rounded-xl border border-soft text-muted-foreground hover:text-ink hover:bg-accent/40 transition-colors"
                    >
                      <Icon className="h-4 w-4" />
                    </a>
                  );
                })}
              </div>
              <Link
                href="/help"
                className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
              >
                Browse the help center →
              </Link>
            </Card>
            </StaggerItem>
          </StaggerGroup>
        </div>
      </section>
    </motion.div>
  );
}
