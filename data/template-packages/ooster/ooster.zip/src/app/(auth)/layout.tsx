import * as React from "react";
import Link from "next/link";
import { Logo, LogoMark } from "@/components/layout/logo";
import { ScoreRadar } from "@/components/charts/score-radar";
import { ShieldCheck, Zap, LineChart } from "lucide-react";
import { FloatingPreview } from "./_floating-preview";
import { ScreenMockup } from "@/components/common/screen-mockup";

const PREVIEW_RADAR = [
  { label: "Usability", value: 86, key: "usability" },
  { label: "Clarity", value: 92, key: "clarity" },
  { label: "Efficiency", value: 78, key: "efficiency" },
  { label: "Engagement", value: 84, key: "engagement" },
  { label: "Access", value: 88, key: "access" },
];

const FEATURES = [
  {
    icon: ShieldCheck,
    title: "Evidence-based findings",
    body: "Every recommendation is tied to sessions, heatmaps, and study data.",
  },
  {
    icon: Zap,
    title: "AI reports in seconds",
    body: "Generate stakeholder-ready narratives from your latest research.",
  },
  {
    icon: LineChart,
    title: "Trends that compound",
    body: "Track UX scores across releases and benchmarks against your peers.",
  },
];

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-shell font-sans">
      <div className="mx-auto min-h-screen max-w-7xl px-3 py-4 sm:px-6 sm:py-6 lg:py-8">
        <div className="overflow-hidden rounded-3xl bg-surface shadow-pop ring-1 ring-border/60">
          <div className="grid min-h-[calc(100vh-2.5rem)] lg:grid-cols-2 lg:min-h-[calc(100vh-3.5rem)]">
            {/* ---------------- Left: branded panel (hidden on mobile) ---------------- */}
            <aside className="relative hidden lg:flex flex-col justify-between p-10 xl:p-12 overflow-hidden bg-surface">
              {/* Branded background: animated dashboard UI mockup (no stock photos) */}
              <ScreenMockup variant="dashboard" className="absolute inset-0 opacity-[0.55] dark:opacity-[0.45]" />
              {/* Soft brand color washes for depth */}
              <div
                aria-hidden
                className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full opacity-30 blur-3xl"
                style={{
                  background:
                    "radial-gradient(circle, color-mix(in oklch, var(--info) 30%, transparent) 0%, transparent 70%)",
                }}
              />
              <div
                aria-hidden
                className="pointer-events-none absolute -left-20 bottom-10 h-56 w-56 rounded-full opacity-25 blur-3xl"
                style={{
                  background:
                    "radial-gradient(circle, color-mix(in oklch, var(--success) 35%, transparent) 0%, transparent 70%)",
                }}
              />

              {/* Top: logo + tagline */}
              <div className="relative">
                <Link href="/" className="inline-flex">
                  <Logo size="lg" />
                </Link>
                <div className="mt-10 max-w-md">
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-surface-2/80 px-2.5 py-1 text-[10px] font-medium text-ink border border-soft shadow-soft backdrop-blur-sm">
                    <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
                    Trusted by 1,400+ product teams
                  </span>
                  <h1 className="mt-4 text-3xl xl:text-4xl font-semibold tracking-tight text-ink leading-tight">
                    Premium UX intelligence for{" "}
                    <span className="text-muted-foreground">modern product teams</span>
                  </h1>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                    Heatmaps, session replays, journeys, funnels, and AI reports —
                    unified in one calm dashboard your whole team will actually use.
                  </p>
                </div>
              </div>

              {/* Middle: mock dashboard preview — floating */}
              <FloatingPreview>
                <div className="relative mt-10 rounded-2xl border border-soft bg-card p-5 shadow-card backdrop-blur-md">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <LogoMark size="sm" />
                      <div>
                        <div className="text-xs font-semibold text-ink">
                          Acme Insights · UX score
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          Last 30 days · all projects
                        </div>
                      </div>
                    </div>
                    <span className="inline-flex items-center gap-1 rounded-md bg-success/10 px-2 py-0.5 text-[10px] font-semibold text-success">
                      ▲ 4.2 pts
                    </span>
                  </div>

                  <div className="grid grid-cols-5 gap-4 items-center">
                    <div className="col-span-3">
                      <div className="h-44 w-full">
                        <ScoreRadar data={PREVIEW_RADAR} size={200} showLabels={false} />
                      </div>
                    </div>
                    <div className="col-span-2 space-y-2">
                      {[
                        { label: "Avg. UX score", value: "85.6", sub: "+4.2 wk/wk" },
                        { label: "Friction events", value: "128", sub: "−18% vs avg" },
                        { label: "Passing rate", value: "92%", sub: "Above target" },
                      ].map((s) => (
                        <div
                          key={s.label}
                          className="rounded-lg border border-soft bg-surface-2/60 px-2.5 py-2"
                        >
                          <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
                            {s.label}
                          </div>
                          <div className="text-base font-semibold text-ink leading-tight">
                            {s.value}
                          </div>
                          <div className="text-[9px] text-success font-medium">{s.sub}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </FloatingPreview>

              {/* Bottom: feature bullets */}
              <div className="relative mt-10 space-y-3">
                {FEATURES.map((f) => (
                  <div key={f.title} className="flex items-start gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-surface-2/80 border border-soft text-primary shadow-soft backdrop-blur-sm">
                      <f.icon className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="text-sm font-medium text-ink">{f.title}</div>
                      <div className="text-xs text-muted-foreground leading-relaxed">
                        {f.body}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </aside>

            {/* ---------------- Right: auth form content ---------------- */}
            <main className="flex flex-col">
              {/* Mobile-only top bar (since aside is hidden) */}
              <div className="lg:hidden flex items-center justify-between px-6 pt-6">
                <Link href="/" className="inline-flex">
                  <Logo />
                </Link>
              </div>
              <div className="flex flex-1 items-center justify-center px-6 py-8 sm:px-10 sm:py-12 lg:px-14 lg:py-16">
                <div className="w-full max-w-md animate-soft-enter">{children}</div>
              </div>
              <footer className="px-6 pb-6 lg:px-14 lg:pb-8">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[11px] text-muted-foreground">
                  <span>© 2026 Ooster Labs. Premium UX intelligence.</span>
                  <div className="flex items-center gap-3">
                    <Link href="/docs" className="hover:text-ink transition-colors">Docs</Link>
                    <Link href="/pricing" className="hover:text-ink transition-colors">Pricing</Link>
                    <Link href="/contact" className="hover:text-ink transition-colors">Contact</Link>
                  </div>
                </div>
              </footer>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
