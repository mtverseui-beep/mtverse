"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import {
  Users,
  Building2,
  ShieldCheck,
  Check,
  X,
  ArrowRight,
  Loader2,
  Sparkles,
  LogIn,
  UserPlus,
} from "lucide-react";
import { Logo, LogoMark } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const INVITE = {
  inviterName: "Mira Halberg",
  inviterEmail: "mira@halberg.co",
  inviterAvatarInitials: "MH",
  workspace: {
    name: "Halberg Studios",
    plan: "Team",
    seats: "8 / 12 seats used",
    color: "from-info/30 to-success/30",
  },
  role: "Researcher" as const,
  permissions: [
    { label: "Create projects & studies", allowed: true },
    { label: "Author insights", allowed: true },
    { label: "Run session replays & heatmaps", allowed: true },
    { label: "Export reports (PDF, CSV)", allowed: true },
    { label: "Invite team members", allowed: false },
    { label: "Manage billing & integrations", allowed: false },
  ],
};

export default function InviteAcceptPage() {
  const router = useRouter();
  // Mock auth state — in reality this would come from a session hook
  const [signedIn, setSignedIn] = React.useState(false);
  const [accepting, setAccepting] = React.useState(false);

  const handleAccept = () => {
    setAccepting(true);
    setTimeout(() => {
      setAccepting(false);
      toast.success("Invite accepted", {
        description: `Welcome to ${INVITE.workspace.name}.`,
      });
      router.push("/");
    }, 800);
  };

  const handleDecline = () => {
    toast.message("Invitation declined", {
      description: "You can request a new invite from the workspace owner.",
    });
    router.push("/sign-in");
  };

  const handleSignIn = () => {
    setSignedIn(true);
    toast.success("Signed in", {
      description: "You can now accept the invitation.",
    });
  };

  const handleSignUp = () => {
    router.push("/sign-up");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-3 text-center">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <div className="flex justify-center">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-success/10 px-3 py-1 text-[10px] font-medium text-success">
            <Sparkles className="h-3 w-3" /> You&apos;re invited
          </div>
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink">
            You&apos;ve been invited
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
            <span className="font-medium text-ink">{INVITE.inviterName}</span>{" "}
            invited you to join the{" "}
            <span className="font-medium text-ink">{INVITE.workspace.name}</span>{" "}
            workspace.
          </p>
        </div>
      </div>

      {/* Workspace card */}
      <Card className="rounded-2xl border-soft shadow-soft p-5 gap-4">
        <div className="flex items-center gap-3">
          <div
            className={cn(
              "flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br text-primary shadow-soft",
              INVITE.workspace.color
            )}
          >
            <Building2 className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold text-ink truncate">
                {INVITE.workspace.name}
              </h2>
              <Badge
                variant="outline"
                className="text-[9px] border-info/20 bg-info/10 text-info"
              >
                {INVITE.workspace.plan} plan
              </Badge>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mt-0.5">
              <Users className="h-3 w-3" />
              {INVITE.workspace.seats}
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-soft bg-surface-2/50 p-3 flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-semibold">
            {INVITE.inviterAvatarInitials}
          </div>
          <div className="text-[11px] leading-relaxed">
            <div className="text-ink font-medium">{INVITE.inviterName}</div>
            <div className="text-muted-foreground">
              {INVITE.inviterEmail} · invited you as {INVITE.role}
            </div>
          </div>
        </div>
      </Card>

      {/* Role preview */}
      <Card className="rounded-2xl border-soft shadow-soft p-5 gap-4">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-info">
            <ShieldCheck className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-ink">
              You&apos;ll join as {INVITE.role}
            </h3>
            <div className="text-[10px] text-muted-foreground">
              Here&apos;s what you&apos;ll be able to do
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {INVITE.permissions.map((p) => (
            <div
              key={p.label}
              className={cn(
                "flex items-start gap-2 rounded-lg border p-2.5 transition-colors",
                p.allowed
                  ? "border-success/20 bg-success/[0.04]"
                  : "border-soft bg-surface-2/40 opacity-60"
              )}
            >
              <div
                className={cn(
                  "flex h-5 w-5 items-center justify-center rounded-full flex-shrink-0 mt-0.5",
                  p.allowed
                    ? "bg-success/15 text-success"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {p.allowed ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
              </div>
              <div className="text-xs text-ink leading-snug">{p.label}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Action card */}
      <Card className="rounded-2xl border-soft shadow-soft p-6 gap-4">
        {signedIn ? (
          <>
            <div className="flex items-center gap-3 rounded-lg border border-soft bg-surface-2/40 p-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-semibold">
                {INVITE.inviterAvatarInitials}
              </div>
              <div className="text-[11px] leading-relaxed">
                <div className="text-ink font-medium">Signed in as you@halberg.co</div>
                <div className="text-muted-foreground">
                  Accepting will add you to {INVITE.workspace.name}.
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <Button
                onClick={handleAccept}
                className="flex-1 h-10 rounded-lg"
                disabled={accepting}
              >
                {accepting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Accepting…
                  </>
                ) : (
                  <>
                    Accept invite <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>
              <Button
                variant="ghost"
                onClick={handleDecline}
                className="h-10 rounded-lg text-muted-foreground"
              >
                Decline
              </Button>
            </div>
            <button
              type="button"
              onClick={() => setSignedIn(false)}
              className="block mx-auto text-[11px] text-muted-foreground hover:text-ink transition-colors"
            >
              Use a different account
            </button>
          </>
        ) : (
          <>
            <p className="text-center text-sm text-muted-foreground">
              Sign in to accept this invitation, or create a new account to join
              the workspace.
            </p>
            <div className="flex flex-col gap-2">
              <Button
                onClick={handleSignIn}
                className="w-full h-10 rounded-lg"
              >
                <LogIn className="h-4 w-4" /> Sign in to accept
              </Button>
              <Button
                variant="outline"
                onClick={handleSignUp}
                className="w-full h-10 rounded-lg"
              >
                <UserPlus className="h-4 w-4" /> Create a new account
              </Button>
            </div>
            <p className="text-center text-[11px] text-muted-foreground leading-relaxed">
              By accepting, you agree to the {INVITE.workspace.name} workspace
              terms and the Ooster{" "}
              <Link href="/terms" className="text-primary hover:underline">Terms of Service</Link>.
            </p>
          </>
        )}
      </Card>

      <div className="flex items-center justify-center gap-2 text-[11px] text-muted-foreground">
        <LogoMark size="sm" />
        <span>Powered by Ooster · Premium UX intelligence</span>
      </div>
    </div>
  );
}
