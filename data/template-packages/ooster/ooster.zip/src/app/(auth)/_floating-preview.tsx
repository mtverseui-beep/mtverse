"use client";

import * as React from "react";
import { motion } from "framer-motion";

/**
 * Wraps children with a subtle infinite floating animation.
 * Used in the auth layout's mock dashboard preview card to give the
 * branded panel a premium, alive feel.
 */
export function FloatingPreview({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      animate={{ y: [0, -8, 0] }}
      transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
    >
      {children}
    </motion.div>
  );
}
