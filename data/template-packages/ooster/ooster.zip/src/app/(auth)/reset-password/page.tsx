"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import {
  Eye,
  EyeOff,
  Lock,
  Loader2,
  ArrowRight,
  ArrowLeft,
  Check,
  X,
} from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

function strengthOf(pw: string) {
  if (!pw) return { score: 0, label: "", color: "", text: "" };
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  if (score <= 1) return { score: 1, label: "Weak", color: "bg-friction", text: "text-friction" };
  if (score <= 3) return { score: 2, label: "Medium", color: "bg-warning", text: "text-warning" };
  return { score: 3, label: "Strong", color: "bg-success", text: "text-success" };
}

const PW_HINTS = [
  { test: (p: string) => p.length >= 8, label: "At least 8 characters" },
  { test: (p: string) => /[A-Z]/.test(p) && /[a-z]/.test(p), label: "Upper & lowercase letters" },
  { test: (p: string) => /\d/.test(p), label: "A number" },
  { test: (p: string) => /[^A-Za-z0-9]/.test(p), label: "A symbol" },
];

export default function ResetPasswordPage() {
  const router = useRouter();
  const [password, setPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [errors, setErrors] = React.useState<{
    password?: string;
    confirm?: string;
  }>({});

  const strength = strengthOf(password);
  const matchState: "idle" | "match" | "mismatch" =
    !confirm ? "idle" : confirm === password ? "match" : "mismatch";

  const validate = () => {
    const next: typeof errors = {};
    if (!password) next.password = "Choose a new password.";
    else if (password.length < 8) next.password = "Use at least 8 characters.";
    if (!confirm) next.confirm = "Please confirm your password.";
    else if (confirm !== password) next.confirm = "Passwords don't match.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("Password updated", {
        description: "Sign in with your new password.",
      });
      router.push("/sign-in");
    }, 700);
  };

  return (
    <div className="space-y-6">
      <div className="space-y-3 text-center">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink">
            Set a new password
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Choose a strong password you haven&apos;t used before.
          </p>
        </div>
      </div>

      <Card className="rounded-2xl border-soft shadow-soft p-6 gap-5">
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          {/* New password */}
          <div className="space-y-1.5">
            <Label htmlFor="password" className="text-xs">
              New password
            </Label>
            <div className="relative">
              <Lock className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                placeholder="••••••••"
                className="pl-8 pr-9"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors((s) => ({ ...s, password: undefined }));
                }}
                aria-invalid={!!errors.password}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex h-6 w-6 items-center justify-center rounded-md text-muted-foreground hover:text-ink hover:bg-accent/60 transition-colors"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
            </div>

            {password && (
              <div className="space-y-1.5 pt-0.5">
                <div className="flex items-center gap-1.5">
                  <div className="flex-1 h-1.5 rounded-full bg-surface-2 overflow-hidden flex gap-0.5">
                    {[1, 2, 3].map((i) => (
                      <div
                        key={i}
                        className={cn(
                          "flex-1 rounded-full transition-colors",
                          i <= strength.score ? strength.color : "bg-transparent"
                        )}
                      />
                    ))}
                  </div>
                  <span className={cn("text-[10px] font-medium", strength.text)}>
                    {strength.label}
                  </span>
                </div>
                <ul className="grid grid-cols-2 gap-x-2 gap-y-1">
                  {PW_HINTS.map((h) => {
                    const ok = h.test(password);
                    return (
                      <li
                        key={h.label}
                        className={cn(
                          "flex items-center gap-1 text-[10px]",
                          ok ? "text-success" : "text-muted-foreground"
                        )}
                      >
                        {ok ? <Check className="h-2.5 w-2.5" /> : <X className="h-2.5 w-2.5 opacity-50" />}
                        {h.label}
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}
            {errors.password && (
              <p className="text-[11px] text-friction">{errors.password}</p>
            )}
          </div>

          {/* Confirm */}
          <div className="space-y-1.5">
            <Label htmlFor="confirm" className="text-xs">
              Confirm new password
            </Label>
            <div className="relative">
              <Lock className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="confirm"
                type={showConfirm ? "text" : "password"}
                autoComplete="new-password"
                placeholder="Re-enter your new password"
                className={cn(
                  "pl-8 pr-9",
                  matchState === "mismatch" && "border-friction focus-visible:ring-friction/30"
                )}
                value={confirm}
                onChange={(e) => {
                  setConfirm(e.target.value);
                  if (errors.confirm) setErrors((s) => ({ ...s, confirm: undefined }));
                }}
                aria-invalid={matchState === "mismatch"}
              />
              <button
                type="button"
                onClick={() => setShowConfirm((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex h-6 w-6 items-center justify-center rounded-md text-muted-foreground hover:text-ink hover:bg-accent/60 transition-colors"
                aria-label={showConfirm ? "Hide password" : "Show password"}
              >
                {showConfirm ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
            </div>
            {matchState === "match" && (
              <p className="text-[11px] text-success flex items-center gap-1">
                <Check className="h-3 w-3" /> Passwords match
              </p>
            )}
            {(matchState === "mismatch" || errors.confirm) && (
              <p className="text-[11px] text-friction flex items-center gap-1">
                <X className="h-3 w-3" />
                {errors.confirm ?? "Passwords don't match."}
              </p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full h-10 rounded-lg"
            disabled={loading || matchState === "mismatch"}
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Updating password…
              </>
            ) : (
              <>
                Update password <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </form>
      </Card>

      <p className="text-center">
        <Link
          href="/sign-in"
          className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-ink transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to sign in
        </Link>
      </p>
    </div>
  );
}
