"use client";

import * as React from "react";
import Link from "next/link";
import { toast } from "sonner";
import { Mail, Loader2, ArrowRight, ArrowLeft, CheckCircle2, RotateCw } from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

export default function ForgotPasswordPage() {
  const [email, setEmail] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [sent, setSent] = React.useState(false);
  const [error, setError] = React.useState<string | undefined>(undefined);
  const [resendIn, setResendIn] = React.useState(0);

  React.useEffect(() => {
    if (resendIn <= 0) return;
    const t = setInterval(() => setResendIn((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [resendIn]);

  const validate = () => {
    if (!email) {
      setError("Email is required.");
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Please enter a valid email address.");
      return false;
    }
    setError(undefined);
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSent(true);
      setResendIn(60);
      toast.success("Reset link sent", {
        description: `Check your inbox at ${email}.`,
      });
    }, 700);
  };

  const handleResend = () => {
    if (resendIn > 0) return;
    setResendIn(60);
    toast.success("Reset link re-sent", {
      description: `Another email is on its way to ${email}.`,
    });
  };

  if (sent) {
    return (
      <div className="space-y-6">
        <div className="space-y-3 text-center">
          <div className="flex justify-center">
            <Logo size="lg" />
          </div>
        </div>

        <Card className="rounded-2xl border-soft shadow-soft p-6 text-center space-y-4">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-success/10 text-success">
            <CheckCircle2 className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-ink">Check your email</h1>
            <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
              We sent a password reset link to{" "}
              <span className="font-medium text-ink">{email}</span>. The link expires
              in 30 minutes.
            </p>
          </div>

          <div className="rounded-lg border border-soft bg-surface-2/60 p-3 text-left">
            <div className="text-[11px] text-muted-foreground mb-1">
              Didn&apos;t receive it?
            </div>
            <ul className="text-[11px] text-muted-foreground space-y-1 leading-relaxed">
              <li>• Check your spam or promotions folder.</li>
              <li>• Verify the email address is correct.</li>
              <li>• Wait up to 60 seconds for delivery.</li>
            </ul>
          </div>

          <div className="flex flex-col gap-2">
            <Button
              type="button"
              variant="outline"
              className="w-full h-10 rounded-lg"
              onClick={handleResend}
              disabled={resendIn > 0}
            >
              {resendIn > 0 ? (
                <>
                  <RotateCw className="h-3.5 w-3.5 opacity-50" />
                  Resend in {resendIn}s
                </>
              ) : (
                <>
                  <RotateCw className="h-3.5 w-3.5" /> Resend reset link
                </>
              )}
            </Button>
            <Link
              href="/sign-in"
              className="inline-flex items-center justify-center gap-1.5 text-xs text-muted-foreground hover:text-ink transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Back to sign in
            </Link>
          </div>
        </Card>

        <p className="text-center text-[11px] text-muted-foreground">
          Wrong email?{" "}
          <button
            type="button"
            className="font-medium text-primary hover:underline"
            onClick={() => {
              setSent(false);
              setResendIn(0);
            }}
          >
            Use a different address
          </button>
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-3 text-center">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink">
            Reset your password
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Enter your work email and we&apos;ll send you a reset link.
          </p>
        </div>
      </div>

      <Card className="rounded-2xl border-soft shadow-soft p-6 gap-5">
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="email" className="text-xs">
              Work email
            </Label>
            <div className="relative">
              <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="you@company.com"
                className="pl-8"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (error) setError(undefined);
                }}
                aria-invalid={!!error}
              />
            </div>
            {error && <p className="text-[11px] text-friction">{error}</p>}
          </div>

          <Button
            type="submit"
            className="w-full h-10 rounded-lg"
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Sending reset link…
              </>
            ) : (
              <>
                Send reset link <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </form>
      </Card>

      <p className="text-center">
        <Link
          href="/sign-in"
          className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-ink transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to sign in
        </Link>
      </p>
    </div>
  );
}
