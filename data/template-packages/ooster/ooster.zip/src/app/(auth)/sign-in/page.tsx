"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  Loader2,
  ArrowRight,
  Github,
  KeyRound,
} from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card } from "@/components/ui/card";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"
      />
    </svg>
  );
}

export default function SignInPage() {
  const router = useRouter();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [remember, setRemember] = React.useState(true);
  const [loading, setLoading] = React.useState(false);
  const [errors, setErrors] = React.useState<{ email?: string; password?: string }>({});

  const validate = () => {
    const next: typeof errors = {};
    if (!email) next.email = "Email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      next.email = "Please enter a valid email address.";
    if (!password) next.password = "Password is required.";
    else if (password.length < 8) next.password = "Password must be at least 8 characters.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("Welcome back", {
        description: "Signed in to your Ooster workspace.",
      });
      router.push("/");
    }, 700);
  };

  const handleSocial = (provider: string) => {
    toast.message(`Continue with ${provider}`, {
      description: "Redirecting to provider…",
    });
    setTimeout(() => {
      toast.success(`Signed in with ${provider}`);
      router.push("/");
    }, 800);
  };

  return (
    <motion.div
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        className="space-y-3 text-center"
      >
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink">
            Welcome back
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Sign in to your Ooster workspace
          </p>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 12, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      >
      <Card className="rounded-2xl border-soft shadow-soft p-6 gap-5 card-hover">
        <StaggerGroup>
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          {/* Email */}
          <StaggerItem>
          <div className="space-y-1.5">
            <Label htmlFor="email" className="text-xs">
              Work email
            </Label>
            <div className="relative">
              <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="you@company.com"
                className="pl-8"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) setErrors((s) => ({ ...s, email: undefined }));
                }}
                aria-invalid={!!errors.email}
              />
            </div>
            {errors.email && (
              <p className="text-[11px] text-friction">{errors.email}</p>
            )}
          </div>
          </StaggerItem>

          {/* Password */}
          <StaggerItem>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="password" className="text-xs">
                Password
              </Label>
              <Link
                href="/forgot-password"
                className="text-[11px] text-primary hover:underline"
              >
                Forgot password?
              </Link>
            </div>
            <div className="relative">
              <Lock className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                placeholder="••••••••"
                className="pl-8 pr-9"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors((s) => ({ ...s, password: undefined }));
                }}
                aria-invalid={!!errors.password}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex h-6 w-6 items-center justify-center rounded-md text-muted-foreground hover:text-ink hover:bg-accent/60 transition-colors"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
            </div>
            {errors.password && (
              <p className="text-[11px] text-friction">{errors.password}</p>
            )}
          </div>
          </StaggerItem>

          {/* Remember me */}
          <StaggerItem>
          <div className="flex items-center justify-between">
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={remember}
                onCheckedChange={(v) => setRemember(v === true)}
              />
              <span className="text-xs text-muted-foreground">Remember me for 30 days</span>
            </label>
          </div>
          </StaggerItem>

          <StaggerItem>
          <Button
            type="submit"
            className="w-full h-10 rounded-lg"
            disabled={loading}
          >
            {loading ? (
              <motion.span
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="inline-flex items-center gap-2"
              >
                <Loader2 className="h-4 w-4 animate-spin" /> Signing in…
              </motion.span>
            ) : (
              <motion.span
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="inline-flex items-center gap-2"
              >
                Sign in <ArrowRight className="h-4 w-4" />
              </motion.span>
            )}
          </Button>
          </StaggerItem>
        </form>
        </StaggerGroup>

        {/* Divider */}
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-soft" />
          </div>
          <div className="relative flex justify-center">
            <span className="bg-card px-3 text-[10px] uppercase tracking-wider text-muted-foreground">
              or continue with
            </span>
          </div>
        </div>

        {/* Social — stagger in */}
        <StaggerGroup className="grid grid-cols-3 gap-2">
          <StaggerItem>
          <Button
            type="button"
            variant="outline"
            className="h-10 rounded-lg w-full"
            onClick={() => handleSocial("Google")}
          >
            <GoogleIcon className="h-4 w-4" />
            <span className="hidden sm:inline text-xs">Google</span>
          </Button>
          </StaggerItem>
          <StaggerItem>
          <Button
            type="button"
            variant="outline"
            className="h-10 rounded-lg w-full"
            onClick={() => handleSocial("GitHub")}
          >
            <Github className="h-4 w-4" />
            <span className="hidden sm:inline text-xs">GitHub</span>
          </Button>
          </StaggerItem>
          <StaggerItem>
          <Button
            type="button"
            variant="outline"
            className="h-10 rounded-lg w-full"
            onClick={() => handleSocial("SSO")}
          >
            <KeyRound className="h-4 w-4" />
            <span className="hidden sm:inline text-xs">SSO</span>
          </Button>
          </StaggerItem>
        </StaggerGroup>
      </Card>
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="text-center text-xs text-muted-foreground"
      >
        Don&apos;t have an account?{" "}
        <Link href="/sign-up" className="font-medium text-primary hover:underline">
          Sign up
        </Link>
      </motion.p>
    </motion.div>
  );
}
