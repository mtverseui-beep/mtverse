"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  User,
  Loader2,
  ArrowRight,
  Github,
  KeyRound,
  Check,
  X,
} from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card } from "@/components/ui/card";
import { StaggerGroup, StaggerItem } from "@/components/common/motion";
import { cn } from "@/lib/utils";

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
    </svg>
  );
}

function strengthOf(pw: string) {
  if (!pw) return { score: 0, label: "", color: "" };
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  if (score <= 1) return { score: 1, label: "Weak", color: "bg-friction", text: "text-friction" };
  if (score <= 3) return { score: 2, label: "Medium", color: "bg-warning", text: "text-warning" };
  return { score: 3, label: "Strong", color: "bg-success", text: "text-success" };
}

const PW_HINTS = [
  { test: (p: string) => p.length >= 8, label: "At least 8 characters" },
  { test: (p: string) => /[A-Z]/.test(p) && /[a-z]/.test(p), label: "Upper & lowercase letters" },
  { test: (p: string) => /\d/.test(p), label: "A number" },
  { test: (p: string) => /[^A-Za-z0-9]/.test(p), label: "A symbol" },
];

export default function SignUpPage() {
  const router = useRouter();
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [agree, setAgree] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [errors, setErrors] = React.useState<{
    name?: string;
    email?: string;
    password?: string;
    terms?: string;
  }>({});

  const strength = strengthOf(password);

  const validate = () => {
    const next: typeof errors = {};
    if (!name.trim()) next.name = "Please tell us your name.";
    if (!email) next.email = "Email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      next.email = "Please enter a valid email address.";
    if (!password) next.password = "Choose a password.";
    else if (password.length < 8) next.password = "Use at least 8 characters.";
    if (!agree) next.terms = "Please accept the terms to continue.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("Account created", {
        description: `Welcome aboard, ${name.split(" ")[0]}!`,
      });
      router.push("/onboarding");
    }, 800);
  };

  const handleSocial = (provider: string) => {
    toast.message(`Continue with ${provider}`, {
      description: "Redirecting to provider…",
    });
    setTimeout(() => {
      toast.success(`Account created with ${provider}`);
      router.push("/onboarding");
    }, 800);
  };

  return (
    <motion.div
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
    >
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        className="space-y-3 text-center"
      >
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink">
            Create your account
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Start turning research into decisions in minutes.
          </p>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 12, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      >
      <Card className="rounded-2xl border-soft shadow-soft p-6 gap-5 card-hover">
        <StaggerGroup>
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          {/* Name */}
          <StaggerItem>
          <div className="space-y-1.5">
            <Label htmlFor="name" className="text-xs">
              Full name
            </Label>
            <div className="relative">
              <User className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="name"
                autoComplete="name"
                placeholder="Mira Halberg"
                className="pl-8"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (errors.name) setErrors((s) => ({ ...s, name: undefined }));
                }}
                aria-invalid={!!errors.name}
              />
            </div>
            {errors.name && <p className="text-[11px] text-friction">{errors.name}</p>}
          </div>
          </StaggerItem>

          {/* Email */}
          <StaggerItem>
          <div className="space-y-1.5">
            <Label htmlFor="email" className="text-xs">
              Work email
            </Label>
            <div className="relative">
              <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="you@company.com"
                className="pl-8"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) setErrors((s) => ({ ...s, email: undefined }));
                }}
                aria-invalid={!!errors.email}
              />
            </div>
            {errors.email && <p className="text-[11px] text-friction">{errors.email}</p>}
          </div>
          </StaggerItem>

          {/* Password */}
          <StaggerItem>
          <div className="space-y-1.5">
            <Label htmlFor="password" className="text-xs">
              Password
            </Label>
            <div className="relative">
              <Lock className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                placeholder="Create a strong password"
                className="pl-8 pr-9"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors((s) => ({ ...s, password: undefined }));
                }}
                aria-invalid={!!errors.password}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex h-6 w-6 items-center justify-center rounded-md text-muted-foreground hover:text-ink hover:bg-accent/60 transition-colors"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
            </div>

            {/* Strength meter — animated width */}
            {password && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                className="space-y-1.5 pt-0.5 overflow-hidden"
              >
                <div className="flex items-center gap-1.5">
                  <div className="flex-1 h-1.5 rounded-full bg-surface-2 overflow-hidden">
                    <motion.div
                      className={cn("h-full rounded-full", strength.color)}
                      initial={{ width: 0 }}
                      animate={{ width: `${(strength.score / 3) * 100}%` }}
                      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    />
                  </div>
                  <span className={cn("text-[10px] font-medium tabular-nums", strength.text)}>
                    {strength.label}
                  </span>
                </div>
                <ul className="grid grid-cols-2 gap-x-2 gap-y-1">
                  {PW_HINTS.map((h) => {
                    const ok = h.test(password);
                    return (
                      <motion.li
                        key={h.label}
                        animate={{ opacity: 1 }}
                        className={cn(
                          "flex items-center gap-1 text-[10px]",
                          ok ? "text-success" : "text-muted-foreground"
                        )}
                      >
                        {ok ? <Check className="h-2.5 w-2.5" /> : <X className="h-2.5 w-2.5 opacity-50" />}
                        {h.label}
                      </motion.li>
                    );
                  })}
                </ul>
              </motion.div>
            )}
            {errors.password && (
              <p className="text-[11px] text-friction">{errors.password}</p>
            )}
          </div>
          </StaggerItem>

          {/* Terms */}
          <StaggerItem>
          <div className="space-y-1.5">
            <label className="flex items-start gap-2 cursor-pointer">
              <Checkbox
                checked={agree}
                onCheckedChange={(v) => {
                  setAgree(v === true);
                  if (errors.terms) setErrors((s) => ({ ...s, terms: undefined }));
                }}
                className="mt-0.5"
              />
              <span className="text-xs text-muted-foreground leading-relaxed">
                I agree to the{" "}
                <Link href="/terms" className="text-primary hover:underline">Terms of Service</Link>
                ,{" "}
                <Link href="/privacy" className="text-primary hover:underline">Privacy Policy</Link>
                , and the processing of session data for product improvement.
              </span>
            </label>
            {errors.terms && <p className="text-[11px] text-friction">{errors.terms}</p>}
          </div>
          </StaggerItem>

          <StaggerItem>
          <Button
            type="submit"
            className="w-full h-10 rounded-lg"
            disabled={loading}
          >
            {loading ? (
              <motion.span
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="inline-flex items-center gap-2"
              >
                <Loader2 className="h-4 w-4 animate-spin" /> Creating account…
              </motion.span>
            ) : (
              <motion.span
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="inline-flex items-center gap-2"
              >
                Create account <ArrowRight className="h-4 w-4" />
              </motion.span>
            )}
          </Button>
          </StaggerItem>
        </form>
        </StaggerGroup>

        {/* Divider */}
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-soft" />
          </div>
          <div className="relative flex justify-center">
            <span className="bg-card px-3 text-[10px] uppercase tracking-wider text-muted-foreground">
              or sign up with
            </span>
          </div>
        </div>

        <StaggerGroup className="grid grid-cols-3 gap-2">
          <StaggerItem>
          <Button
            type="button"
            variant="outline"
            className="h-10 rounded-lg w-full"
            onClick={() => handleSocial("Google")}
          >
            <GoogleIcon className="h-4 w-4" />
            <span className="hidden sm:inline text-xs">Google</span>
          </Button>
          </StaggerItem>
          <StaggerItem>
          <Button
            type="button"
            variant="outline"
            className="h-10 rounded-lg w-full"
            onClick={() => handleSocial("GitHub")}
          >
            <Github className="h-4 w-4" />
            <span className="hidden sm:inline text-xs">GitHub</span>
          </Button>
          </StaggerItem>
          <StaggerItem>
          <Button
            type="button"
            variant="outline"
            className="h-10 rounded-lg w-full"
            onClick={() => handleSocial("SSO")}
          >
            <KeyRound className="h-4 w-4" />
            <span className="hidden sm:inline text-xs">SSO</span>
          </Button>
          </StaggerItem>
        </StaggerGroup>
      </Card>
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="text-center text-xs text-muted-foreground"
      >
        Already have an account?{" "}
        <Link href="/sign-in" className="font-medium text-primary hover:underline">
          Sign in
        </Link>
      </motion.p>
    </motion.div>
  );
}
