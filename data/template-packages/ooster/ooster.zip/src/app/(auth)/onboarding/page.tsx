"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  ArrowRight,
  ArrowLeft,
  Loader2,
  Check,
  Sparkles,
  UserCircle2,
  FolderPlus,
  Plug,
  PartyPopper,
  Figma,
  Slack,
  CheckCircle2,
} from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const STEPS = [
  { key: "welcome", label: "Welcome", icon: Sparkles },
  { key: "profile", label: "Profile", icon: UserCircle2 },
  { key: "project", label: "First project", icon: FolderPlus },
  { key: "connect", label: "Connect tools", icon: Plug },
  { key: "done", label: "Done", icon: PartyPopper },
] as const;

type StepKey = (typeof STEPS)[number]["key"];

const ROLES = ["Researcher", "Designer", "Product Manager", "Engineer", "Founder", "Other"];
const TEAM_SIZES = ["1–5", "6–15", "16–50", "51–200", "200+"];
const PROJECT_TYPES = ["Web app", "Mobile app", "Marketing site", "Design system", "Other"];

const INTEGRATIONS = [
  {
    key: "figma",
    name: "Figma",
    desc: "Sync design files & frames for annotation",
    icon: Figma,
    color: "bg-[#A259FF]/10 text-[#A259FF]",
  },
  {
    key: "slack",
    name: "Slack",
    desc: "Send insights & alerts to channels",
    icon: Slack,
    color: "bg-[#E01E5A]/10 text-[#E01E5A]",
  },
  {
    key: "linear",
    name: "Linear",
    desc: "Convert issues & recommendations into tickets",
    icon: CheckCircle2,
    color: "bg-info/10 text-info",
  },
];

export default function OnboardingPage() {
  const router = useRouter();
  const [stepIndex, setStepIndex] = React.useState(0);
  const [loading, setLoading] = React.useState(false);

  // Profile
  const [name, setName] = React.useState("");
  const [role, setRole] = React.useState<string>("");
  const [teamSize, setTeamSize] = React.useState<string>("");

  // Project
  const [projectName, setProjectName] = React.useState("");
  const [projectType, setProjectType] = React.useState<string>("");
  const [projectDesc, setProjectDesc] = React.useState("");

  // Integrations
  const [connectTargets, setConnectTargets] = React.useState<string[]>([]);

  const step = STEPS[stepIndex].key;
  const progress = ((stepIndex + 1) / STEPS.length) * 100;

  const next = () => setStepIndex((i) => Math.min(STEPS.length - 1, i + 1));
  const back = () => setStepIndex((i) => Math.max(0, i - 1));

  const handleWelcomeNext = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      next();
    }, 400);
  };

  const handleProfileNext = () => {
    if (!name.trim()) {
      toast.error("Name required", { description: "Tell us your name to continue." });
      return;
    }
    if (!role) {
      toast.error("Role required", { description: "Pick the role that fits best." });
      return;
    }
    if (!teamSize) {
      toast.error("Team size required", { description: "Help us tailor your workspace." });
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("Profile saved");
      next();
    }, 400);
  };

  const handleProjectNext = (skip: boolean) => {
    if (!skip) {
      if (!projectName.trim()) {
        toast.error("Project name required", { description: "Give your project a name." });
        return;
      }
      if (!projectType) {
        toast.error("Project type required", { description: "Pick a project type." });
        return;
      }
    } else {
      toast.message("Skipped for now", { description: "You can create a project later." });
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      if (!skip) toast.success("Project created");
      next();
    }, 400);
  };

  const handleConnectNext = (skip: boolean) => {
    if (!skip && connectTargets.length === 0) {
      toast.message("No integrations selected", { description: "You can connect them later." });
    } else if (!skip) {
      toast.success("Integrations queued", {
        description: `${connectTargets.length} integration${connectTargets.length === 1 ? "" : "s"} ready to connect.`,
      });
    } else {
      toast.message("Skipped for now", { description: "Connect integrations anytime from Settings." });
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      next();
    }, 400);
  };

  const handleDone = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("You're all set!", {
        description: "Welcome to Ooster.",
      });
      router.push("/");
    }, 600);
  };

  const toggleIntegration = (key: string) => {
    setConnectTargets((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-3 text-center">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
      </div>

      {/* Stepper + progress */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            const isDone = i < stepIndex;
            const isCurrent = i === stepIndex;
            return (
              <React.Fragment key={s.key}>
                <button
                  type="button"
                  onClick={() => i < stepIndex && setStepIndex(i)}
                  disabled={i > stepIndex}
                  className={cn(
                    "flex flex-col items-center gap-1.5 transition-opacity",
                    i > stepIndex && "opacity-40 cursor-not-allowed"
                  )}
                >
                  <div
                    className={cn(
                      "flex h-8 w-8 items-center justify-center rounded-full border text-[11px] font-medium transition-colors",
                      isDone
                        ? "bg-success text-success-foreground border-success"
                        : isCurrent
                          ? "bg-primary text-primary-foreground border-primary shadow-soft"
                          : "bg-card text-muted-foreground border-soft"
                    )}
                  >
                    {isDone ? <Check className="h-4 w-4" /> : <Icon className="h-3.5 w-3.5" />}
                  </div>
                  <span
                    className={cn(
                      "hidden sm:block text-[10px] font-medium",
                      isCurrent ? "text-ink" : "text-muted-foreground"
                    )}
                  >
                    {s.label}
                  </span>
                </button>
                {i < STEPS.length - 1 && (
                  <div
                    className={cn(
                      "flex-1 h-0.5 rounded-full transition-colors",
                      i < stepIndex ? "bg-success" : "bg-surface-2"
                    )}
                  />
                )}
              </React.Fragment>
            );
          })}
        </div>
        <div className="h-1 rounded-full bg-surface-2 overflow-hidden">
          <motion.div
            className="h-full rounded-full bg-primary"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          />
        </div>
      </div>

      <Card className="rounded-2xl border-soft shadow-soft p-6 gap-5 card-hover">
        {/* Step content — slides in from the right on step change */}
        <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -24 }}
          transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
        >
        {/* ---------------- Step 1: Welcome ---------------- */}
        {step === "welcome" && (
          <div className="space-y-5 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-success/10 text-success">
              <Sparkles className="h-7 w-7" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold tracking-tight text-ink">
                Welcome to Ooster!
              </h1>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
                You&apos;re a few steps away from your first UX insight. Let&apos;s
                personalize your workspace, set up your first project, and connect
                the tools your team already loves.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2 max-w-sm mx-auto pt-2">
              {[
                { icon: UserCircle2, label: "Profile" },
                { icon: FolderPlus, label: "Project" },
                { icon: Plug, label: "Tools" },
              ].map((c) => (
                <div
                  key={c.label}
                  className="rounded-xl border border-soft bg-surface-2/50 p-3 text-center"
                >
                  <c.icon className="h-4 w-4 mx-auto text-primary" />
                  <div className="text-[10px] text-muted-foreground mt-1.5">
                    {c.label}
                  </div>
                </div>
              ))}
            </div>
            <Button
              onClick={handleWelcomeNext}
              className="w-full h-10 rounded-lg"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Setting up…
                </>
              ) : (
                <>
                  Get started <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
            <p className="text-[11px] text-muted-foreground">
              Takes about 2 minutes · You can skip any step
            </p>
          </div>
        )}

        {/* ---------------- Step 2: Profile ---------------- */}
        {step === "profile" && (
          <div className="space-y-5">
            <div>
              <h2 className="text-lg font-semibold text-ink">Set up your profile</h2>
              <p className="text-xs text-muted-foreground mt-1">
                Tell us a bit about yourself so we can tailor the experience.
              </p>
            </div>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="name" className="text-xs">Full name</Label>
                <Input
                  id="name"
                  placeholder="Mira Halberg"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Your role</Label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Pick the closest fit" />
                  </SelectTrigger>
                  <SelectContent>
                    {ROLES.map((r) => (
                      <SelectItem key={r} value={r}>{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Team size</Label>
                <Select value={teamSize} onValueChange={setTeamSize}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="How big is your team?" />
                  </SelectTrigger>
                  <SelectContent>
                    {TEAM_SIZES.map((s) => (
                      <SelectItem key={s} value={s}>{s} people</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center justify-between gap-2 pt-2">
              <Button variant="ghost" onClick={back} className="h-9 rounded-lg">
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              <Button
                onClick={handleProfileNext}
                className="h-9 rounded-lg"
                disabled={loading}
              >
                {loading ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Saving…</>
                ) : (
                  <>Continue <ArrowRight className="h-4 w-4" /></>
                )}
              </Button>
            </div>
          </div>
        )}

        {/* ---------------- Step 3: First project ---------------- */}
        {step === "project" && (
          <div className="space-y-5">
            <div>
              <h2 className="text-lg font-semibold text-ink">
                Create your first project
              </h2>
              <p className="text-xs text-muted-foreground mt-1">
                Projects group sessions, heatmaps, and insights together. You can
                add more later.
              </p>
            </div>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="project-name" className="text-xs">
                  Project name
                </Label>
                <Input
                  id="project-name"
                  placeholder="Acme Insights — Marketing Site"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Project type</Label>
                <Select value={projectType} onValueChange={setProjectType}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="What are you researching?" />
                  </SelectTrigger>
                  <SelectContent>
                    {PROJECT_TYPES.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="project-desc" className="text-xs">
                  Description <span className="text-muted-foreground">(optional)</span>
                </Label>
                <Textarea
                  id="project-desc"
                  placeholder="What questions are you trying to answer?"
                  className="min-h-[80px]"
                  value={projectDesc}
                  onChange={(e) => setProjectDesc(e.target.value)}
                />
              </div>
            </div>
            <div className="flex items-center justify-between gap-2 pt-2">
              <Button variant="ghost" onClick={back} className="h-9 rounded-lg">
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  onClick={() => handleProjectNext(true)}
                  className="h-9 rounded-lg"
                  disabled={loading}
                >
                  Skip for now
                </Button>
                <Button
                  onClick={() => handleProjectNext(false)}
                  className="h-9 rounded-lg"
                  disabled={loading}
                >
                  {loading ? (
                    <><Loader2 className="h-4 w-4 animate-spin" /> Creating…</>
                  ) : (
                    <>Create project <ArrowRight className="h-4 w-4" /></>
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* ---------------- Step 4: Connect tools ---------------- */}
        {step === "connect" && (
          <div className="space-y-5">
            <div>
              <h2 className="text-lg font-semibold text-ink">
                Connect your tools
              </h2>
              <p className="text-xs text-muted-foreground mt-1">
                Bring in design files, route insights to chat, and turn
                recommendations into tickets. Optional — skip and connect later.
              </p>
            </div>
            <div className="space-y-2">
              {INTEGRATIONS.map((tool) => {
                const checked = connectTargets.includes(tool.key);
                return (
                  <label
                    key={tool.key}
                    className={cn(
                      "flex items-start gap-3 rounded-xl border p-3 cursor-pointer transition-colors",
                      checked
                        ? "border-primary/40 bg-primary/[0.04]"
                        : "border-soft bg-surface-2/40 hover:bg-surface-2/70"
                    )}
                  >
                    <Checkbox
                      checked={checked}
                      onCheckedChange={() => toggleIntegration(tool.key)}
                      className="mt-0.5"
                    />
                    <div
                      className={cn(
                        "flex h-8 w-8 items-center justify-center rounded-lg flex-shrink-0",
                        tool.color
                      )}
                    >
                      <tool.icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-ink">{tool.name}</div>
                      <div className="text-[11px] text-muted-foreground leading-snug">
                        {tool.desc}
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>
            <div className="flex items-center justify-between gap-2 pt-2">
              <Button variant="ghost" onClick={back} className="h-9 rounded-lg">
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  onClick={() => handleConnectNext(true)}
                  className="h-9 rounded-lg"
                  disabled={loading}
                >
                  Skip for now
                </Button>
                <Button
                  onClick={() => handleConnectNext(false)}
                  className="h-9 rounded-lg"
                  disabled={loading}
                >
                  {loading ? (
                    <><Loader2 className="h-4 w-4 animate-spin" /> Connecting…</>
                  ) : (
                    <>Continue <ArrowRight className="h-4 w-4" /></>
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* ---------------- Step 5: Done ---------------- */}
        {step === "done" && (
          <div className="space-y-5 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-success/10 text-success">
              <PartyPopper className="h-7 w-7" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold tracking-tight text-ink">
                You&apos;re all set!
              </h1>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
                Your workspace is ready. Drop in a Figma file, run your first
                heatmap, or browse the demo insights — we&apos;ll be right here
                when you need us.
              </p>
            </div>
            <div className="rounded-xl border border-soft bg-surface-2/50 p-4 text-left space-y-2 max-w-md mx-auto">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Your setup
              </div>
              <div className="grid grid-cols-1 gap-1.5 text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Name</span>
                  <span className="text-ink font-medium">{name || "—"}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Role</span>
                  <span className="text-ink font-medium">{role || "—"}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Team size</span>
                  <span className="text-ink font-medium">{teamSize || "—"}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Project</span>
                  <span className="text-ink font-medium">{projectName || "Skipped"}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Integrations</span>
                  <span className="text-ink font-medium">
                    {connectTargets.length > 0
                      ? connectTargets
                          .map((k) => INTEGRATIONS.find((i) => i.key === k)?.name)
                          .join(", ")
                      : "Skipped"}
                  </span>
                </div>
              </div>
            </div>
            <Button
              onClick={handleDone}
              className="w-full h-10 rounded-lg"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Taking you there…
                </>
              ) : (
                <>
                  Go to dashboard <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
            <button
              type="button"
              onClick={back}
              className="text-[11px] text-muted-foreground hover:text-ink transition-colors"
            >
              <ArrowLeft className="h-3 w-3 inline" /> Back to integrations
            </button>
          </div>
        )}
        </motion.div>
        </AnimatePresence>
      </Card>
    </div>
  );
}
