"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import {
  MailCheck,
  Loader2,
  ArrowRight,
  ArrowLeft,
  RotateCw,
} from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from "@/components/ui/input-otp";

const TARGET_EMAIL = "mira@halberg.co";

export default function VerifyEmailPage() {
  const router = useRouter();
  const [value, setValue] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | undefined>(undefined);
  const [resendIn, setResendIn] = React.useState(60);

  React.useEffect(() => {
    if (resendIn <= 0) return;
    const t = setInterval(() => setResendIn((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [resendIn]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value.length !== 6) {
      setError("Please enter all 6 digits.");
      return;
    }
    setError(undefined);
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      // demo: code 123456 is "correct"
      if (value !== "123456") {
        setError("That code didn't match. Try again, or resend a new one.");
        toast.error("Verification failed", {
          description: "The code is incorrect or expired.",
        });
        return;
      }
      toast.success("Email verified", {
        description: "Your address is now confirmed.",
      });
      router.push("/onboarding");
    }, 700);
  };

  const handleResend = () => {
    if (resendIn > 0) return;
    setResendIn(60);
    setValue("");
    setError(undefined);
    toast.success("New code sent", {
      description: `A fresh 6-digit code is on its way to ${TARGET_EMAIL}.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-3 text-center">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <div className="flex justify-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-info/10 text-info">
            <MailCheck className="h-6 w-6" />
          </div>
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink">
            Verify your email
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
            We sent a 6-digit code to{" "}
            <span className="font-medium text-ink">{TARGET_EMAIL}</span>. Enter it
            below to confirm your address.
          </p>
        </div>
      </div>

      <Card className="rounded-2xl border-soft shadow-soft p-6 gap-5">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <div className="flex justify-center">
              <InputOTP
                maxLength={6}
                value={value}
                onChange={(v) => {
                  setValue(v);
                  if (error) setError(undefined);
                }}
                containerClassName="justify-center"
              >
                <InputOTPGroup>
                  <InputOTPSlot index={0} className="h-12 w-12 text-base" />
                  <InputOTPSlot index={1} className="h-12 w-12 text-base" />
                  <InputOTPSlot index={2} className="h-12 w-12 text-base" />
                </InputOTPGroup>
                <InputOTPSeparator />
                <InputOTPGroup>
                  <InputOTPSlot index={3} className="h-12 w-12 text-base" />
                  <InputOTPSlot index={4} className="h-12 w-12 text-base" />
                  <InputOTPSlot index={5} className="h-12 w-12 text-base" />
                </InputOTPGroup>
              </InputOTP>
            </div>
            {error && (
              <p className="text-center text-[11px] text-friction">{error}</p>
            )}
            <p className="text-center text-[10px] text-muted-foreground">
              Demo tip: use code{" "}
              <span className="font-mono font-semibold text-ink">123456</span>.
            </p>
          </div>

          <Button
            type="submit"
            className="w-full h-10 rounded-lg"
            disabled={loading || value.length !== 6}
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Verifying…
              </>
            ) : (
              <>
                Verify email <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </form>

        <div className="flex items-center justify-center">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-8 text-xs"
            onClick={handleResend}
            disabled={resendIn > 0}
          >
            {resendIn > 0 ? (
              <>
                <RotateCw className="h-3.5 w-3.5 opacity-50" />
                Resend code in {resendIn}s
              </>
            ) : (
              <>
                <RotateCw className="h-3.5 w-3.5" /> Resend code
              </>
            )}
          </Button>
        </div>
      </Card>

      <p className="text-center">
        <Link
          href="/sign-up"
          className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-ink transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Use a different email
        </Link>
      </p>
    </div>
  );
}
