"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import {
  ShieldCheck,
  Loader2,
  ArrowRight,
  ArrowLeft,
  KeyRound,
  LifeBuoy,
  Smartphone,
} from "lucide-react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from "@/components/ui/input-otp";

export default function TwoFactorPage() {
  const router = useRouter();
  const [mode, setMode] = React.useState<"authenticator" | "backup">("authenticator");
  const [code, setCode] = React.useState("");
  const [backup, setBackup] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | undefined>(undefined);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const value = mode === "authenticator" ? code : backup.trim();
    if (!value) {
      setError(mode === "authenticator" ? "Enter the 6-digit code." : "Enter your backup code.");
      return;
    }
    if (mode === "authenticator" && value.length !== 6) {
      setError("Please enter all 6 digits.");
      return;
    }
    setError(undefined);
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      // demo: 123456 works for authenticator, BACKUP-1234 works for backup
      const ok =
        (mode === "authenticator" && value === "123456") ||
        (mode === "backup" && value.toUpperCase().startsWith("BACKUP-"));
      if (!ok) {
        setError(mode === "authenticator" ? "That code didn't match." : "Backup code is invalid.");
        toast.error("Verification failed", {
          description: "Please try again.",
        });
        return;
      }
      toast.success("Two-factor verified", {
        description: "Welcome back to Ooster.",
      });
      router.push("/");
    }, 700);
  };

  return (
    <div className="space-y-6">
      <div className="space-y-3 text-center">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <div className="flex justify-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-info/10 text-info">
            <ShieldCheck className="h-6 w-6" />
          </div>
        </div>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-ink">
            Two-factor authentication
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
            {mode === "authenticator"
              ? "Enter the 6-digit code from your authenticator app (Authy, 1Password, Google Authenticator)."
              : "Enter one of your single-use backup codes. Each code can only be used once."}
          </p>
        </div>
      </div>

      <Card className="rounded-2xl border-soft shadow-soft p-6 gap-5">
        {/* Mode tabs */}
        <div className="flex items-center gap-1 p-1 rounded-lg bg-surface-2/60 w-fit mx-auto">
          <button
            type="button"
            onClick={() => {
              setMode("authenticator");
              setBackup("");
              setError(undefined);
            }}
            className={
              "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors " +
              (mode === "authenticator"
                ? "bg-card text-ink shadow-soft"
                : "text-muted-foreground hover:text-ink")
            }
          >
            <Smartphone className="h-3.5 w-3.5" /> Authenticator
          </button>
          <button
            type="button"
            onClick={() => {
              setMode("backup");
              setCode("");
              setError(undefined);
            }}
            className={
              "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors " +
              (mode === "backup"
                ? "bg-card text-ink shadow-soft"
                : "text-muted-foreground hover:text-ink")
            }
          >
            <KeyRound className="h-3.5 w-3.5" /> Backup code
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "authenticator" ? (
            <div className="space-y-2">
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={code}
                  onChange={(v) => {
                    setCode(v);
                    if (error) setError(undefined);
                  }}
                  containerClassName="justify-center"
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} className="h-12 w-12 text-base" />
                    <InputOTPSlot index={1} className="h-12 w-12 text-base" />
                    <InputOTPSlot index={2} className="h-12 w-12 text-base" />
                  </InputOTPGroup>
                  <InputOTPSeparator />
                  <InputOTPGroup>
                    <InputOTPSlot index={3} className="h-12 w-12 text-base" />
                    <InputOTPSlot index={4} className="h-12 w-12 text-base" />
                    <InputOTPSlot index={5} className="h-12 w-12 text-base" />
                  </InputOTPGroup>
                </InputOTP>
              </div>
              {error && (
                <p className="text-center text-[11px] text-friction">{error}</p>
              )}
              <p className="text-center text-[10px] text-muted-foreground">
                Demo tip: use code{" "}
                <span className="font-mono font-semibold text-ink">123456</span>.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              <Label htmlFor="backup" className="text-xs">
                Backup code
              </Label>
              <Input
                id="backup"
                autoComplete="one-time-code"
                placeholder="BACKUP-XXXX-XXXX"
                className="font-mono text-center tracking-wider"
                value={backup}
                onChange={(e) => {
                  setBackup(e.target.value);
                  if (error) setError(undefined);
                }}
                aria-invalid={!!error}
              />
              {error && <p className="text-[11px] text-friction">{error}</p>}
              <p className="text-[10px] text-muted-foreground">
                Codes are 16 characters, dashes included. Case insensitive.
              </p>
            </div>
          )}

          <Button
            type="submit"
            className="w-full h-10 rounded-lg"
            disabled={
              loading ||
              (mode === "authenticator" ? code.length !== 6 : !backup.trim())
            }
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Verifying…
              </>
            ) : (
              <>
                Verify & continue <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </form>

        <div className="flex flex-col items-center gap-2 pt-1">
          {mode === "authenticator" ? (
            <button
              type="button"
              onClick={() => {
                setMode("backup");
                setCode("");
                setError(undefined);
              }}
              className="text-[11px] text-primary hover:underline"
            >
              Use a backup code instead
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setMode("authenticator");
                setBackup("");
                setError(undefined);
              }}
              className="text-[11px] text-primary hover:underline"
            >
              Use the authenticator app instead
            </button>
          )}
          <Link
            href="/contact"
            className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-ink transition-colors"
          >
            <LifeBuoy className="h-3 w-3" /> Lost your device? Contact support
          </Link>
        </div>
      </Card>

      <p className="text-center">
        <Link
          href="/sign-in"
          className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-ink transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to sign in
        </Link>
      </p>
    </div>
  );
}
