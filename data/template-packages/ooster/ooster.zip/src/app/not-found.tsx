import Link from "next/link";
import { FileQuestion, Home } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-shell flex items-center justify-center p-6">
      <div className="text-center max-w-md">
        <div className="mx-auto h-14 w-14 rounded-2xl bg-surface-2 text-muted-foreground flex items-center justify-center mb-4">
          <FileQuestion className="h-7 w-7" />
        </div>
        <div className="text-4xl font-bold text-ink mb-2">404</div>
        <h2 className="text-lg font-semibold text-ink">Page not found</h2>
        <p className="text-sm text-muted-foreground mt-2 mb-5">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Button asChild>
          <Link href="/"><Home className="mr-2 h-4 w-4" /> Back to dashboard</Link>
        </Button>
      </div>
    </div>
  );
}
