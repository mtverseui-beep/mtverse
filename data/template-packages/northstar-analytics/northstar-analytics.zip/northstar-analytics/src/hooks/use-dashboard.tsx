"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { RangeKey } from "@/lib/types";

// ── Route paths ────────────────────────────────────────────────────────────────
// Single source of truth for every dashboard route. Used by the sidebar,
// command palette, profile menu, keyboard shortcuts, and overview quick links.

export type RoutePath =
  | "/"
  | "/analytics"
  | "/customers"
  | "/billing"
  | "/settings"
  | "/settings/profile"
  | "/settings/team"
  | "/settings/api-keys"
  | "/settings/notifications";

export interface RouteMeta {
  path: RoutePath;
  label: string;
  description: string;
  /** Icon component from lucide-react */
  iconKey: NavIconKey;
  /** Whether this route appears in the primary sidebar nav (false = sub-route) */
  primary: boolean;
  /** Optional badge text (e.g. unread count) */
  badge?: string;
  /** Group label for command palette grouping */
  group: "Navigate" | "Settings" | "Actions";
}

export type NavIconKey =
  | "overview"
  | "analytics"
  | "customers"
  | "billing"
  | "settings"
  | "profile"
  | "team"
  | "api-keys"
  | "notifications";

export const ROUTES: Record<RoutePath, RouteMeta> = {
  "/": {
    path: "/",
    label: "Overview",
    description: "Is everything okay?",
    iconKey: "overview",
    primary: true,
    group: "Navigate",
  },
  "/analytics": {
    path: "/analytics",
    label: "Analytics",
    description: "Revenue, funnel, plans",
    iconKey: "analytics",
    primary: true,
    group: "Navigate",
  },
  "/customers": {
    path: "/customers",
    label: "Customers",
    description: "Accounts & subscriptions",
    iconKey: "customers",
    primary: true,
    group: "Navigate",
    badge: "12",
  },
  "/billing": {
    path: "/billing",
    label: "Billing",
    description: "Plan, usage, invoices",
    iconKey: "billing",
    primary: true,
    group: "Navigate",
  },
  "/settings": {
    path: "/settings",
    label: "Settings",
    description: "Team, API keys, prefs",
    iconKey: "settings",
    primary: true,
    group: "Navigate",
  },
  "/settings/profile": {
    path: "/settings/profile",
    label: "Profile",
    description: "Your name, email, and bio",
    iconKey: "profile",
    primary: false,
    group: "Settings",
  },
  "/settings/team": {
    path: "/settings/team",
    label: "Team",
    description: "Invite teammates and roles",
    iconKey: "team",
    primary: false,
    group: "Settings",
  },
  "/settings/api-keys": {
    path: "/settings/api-keys",
    label: "API keys",
    description: "Authenticate API requests",
    iconKey: "api-keys",
    primary: false,
    group: "Settings",
  },
  "/settings/notifications": {
    path: "/settings/notifications",
    label: "Notifications",
    description: "Email and product updates",
    iconKey: "notifications",
    primary: false,
    group: "Settings",
  },
};

export const PRIMARY_ROUTES: RoutePath[] = Object.keys(ROUTES).filter(
  (p) => ROUTES[p as RoutePath].primary,
) as RoutePath[];

export const SETTINGS_SUBROUTES: RoutePath[] = [
  "/settings/profile",
  "/settings/team",
  "/settings/api-keys",
  "/settings/notifications",
];

// ---- Count-up animation hook -------------------------------------------------
// Animates a number from 0 → target over `duration` ms, with `prefers-reduced-motion` respected.

export function useCountUp(target: number, duration = 900) {
  const [value, setValue] = useState(0);
  const reducedMotion = useRef(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      reducedMotion.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    }
  }, []);

  // Animate from 0 → target on mount + when target changes.
  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    if (reducedMotion.current) {
      setValue(target);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const from = 0;
    const animate = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      // easeOutCubic
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(from + (target - from) * eased);
      if (t < 1) raf = requestAnimationFrame(animate);
    };
    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  /* eslint-enable react-hooks/set-state-in-effect */

  return value;
}

// ---- Command palette + notifications UI state --------------------------------

interface UIState {
  commandOpen: boolean;
  setCommandOpen: (v: boolean) => void;
  notifOpen: boolean;
  setNotifOpen: (v: boolean) => void;
}

const UIContext = createContext<UIState | null>(null);

export function UIProvider({ children }: { children: React.ReactNode }) {
  const [commandOpen, setCommandOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  // Global ⌘K / Ctrl+K shortcut for the command palette.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCommandOpen((v) => !v);
      }
      if (e.key === "Escape") {
        setCommandOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const value = useMemo<UIState>(() => ({ commandOpen, setCommandOpen, notifOpen, setNotifOpen }), [commandOpen, notifOpen]);
  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}

export function useUI(): UIState {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error("useUI must be used inside UIProvider");
  return ctx;
}

// ---- Range state (still client-side, persisted in sessionStorage) -----------
// Used by the Analytics page's 7D / 30D / 90D / 1Y toggle.

interface NavState {
  range: RangeKey;
  setRange: (r: RangeKey) => void;
}

const NavContext = createContext<NavState | null>(null);

const RANGE_STORAGE_KEY = "ns.dashboard.range";

const VALID_RANGES: RangeKey[] = ["7d", "30d", "90d", "1y"];

function readSessionRange(): RangeKey | null {
  if (typeof window === "undefined") return null;
  try {
    const r = window.sessionStorage.getItem(RANGE_STORAGE_KEY) as RangeKey | null;
    return r && VALID_RANGES.includes(r) ? r : null;
  } catch {
    return null;
  }
}

export function NavProvider({ children }: { children: React.ReactNode }) {
  const [range, setRangeState] = useState<RangeKey>("30d");
  const hydrated = useRef(false);

  /* eslint-disable react-hooks/set-state-in-effect */
  // One-shot hydration from sessionStorage after mount — syncs React state
  // with an external (browser) system, which is exactly what effects are for.
  useEffect(() => {
    if (hydrated.current) return;
    hydrated.current = true;
    const r = readSessionRange();
    if (r) setRangeState(r);
  }, []);
  /* eslint-enable react-hooks/set-state-in-effect */

  const setRange = useCallback((r: RangeKey) => {
    setRangeState(r);
    try {
      window.sessionStorage.setItem(RANGE_STORAGE_KEY, r);
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<NavState>(() => ({ range, setRange }), [range, setRange]);
  return <NavContext.Provider value={value}>{children}</NavContext.Provider>;
}

export function useNav(): NavState {
  const ctx = useContext(NavContext);
  if (!ctx) throw new Error("useNav must be used inside NavProvider");
  return ctx;
}

// ---- Simulated async data hook ------------------------------------------------
// Mimics a fetch() so we can exercise loading + error states on data-heavy views.

export type AsyncStatus = "idle" | "loading" | "success" | "error";

export function useSimulatedFetch<T>(factory: () => T, opts: { delay?: number; failRate?: number; deps?: unknown[] } = {}) {
  const { delay = 600, failRate = 0, deps = [] } = opts;
  const [status, setStatus] = useState<AsyncStatus>("loading");
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Keep the latest factory in a ref WITHOUT reading/writing during render.
  const factoryRef = useRef(factory);
  useEffect(() => {
    factoryRef.current = factory;
  });

  // Stringify deps so a value-change forces `load` to be re-created.
  // Reading `depsKey` inside the callback body (no-op) keeps the
  // exhaustive-deps linter satisfied — it confirms the dep is actually
  // used, not just listed to bust memoization.
  const depsKey = JSON.stringify(deps);

  const load = useCallback(() => {
    // Touch depsKey so the linter sees it as a real dependency.
    void depsKey;
    let cancelled = false;
    setStatus("loading");
    setError(null);
    const id = window.setTimeout(() => {
      if (cancelled) return;
      if (Math.random() < failRate) {
        setStatus("error");
        setError("We couldn't reach the metrics service. Please retry.");
        return;
      }
      try {
        setData(factoryRef.current());
        setStatus("success");
      } catch {
        setStatus("error");
        setError("Something went wrong while preparing this data.");
      }
    }, delay);
    return () => {
      cancelled = true;
      window.clearTimeout(id);
    };
  }, [depsKey, delay, failRate]);

  // Calling `load()` here triggers setState inside the timeout — this is the
  // standard "trigger fetch on mount + when deps change" pattern.
  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    const cancel = load();
    return cancel;
  }, [load]);
  /* eslint-enable react-hooks/set-state-in-effect */

  return { status, data, error, retry: load };
}
