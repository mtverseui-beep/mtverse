"use client";

import { useCallback, useEffect, useState } from "react";

/**
 * Shared theme hook — single source of truth for the `dark` class on <html>.
 *
 * Used by both ThemeToggle and ProfileMenu so they never disagree.
 *
 * The actual `dark` class is applied by an inline script in layout.tsx
 * before React hydrates, so the page never flashes.
 *
 * Cross-component sync: when one component toggles the theme, it dispatches
 * a `ns:theme-change` CustomEvent on `window`. Other instances listen for
 * that event and re-sync their local state from the DOM.
 */
const THEME_EVENT = "ns:theme-change";
const STORAGE_KEY = "ns.theme";

function readDarkFromDom(): boolean {
  if (typeof document === "undefined") return true;
  return document.documentElement.classList.contains("dark");
}

export function useTheme() {
  const [isDark, setIsDark] = useState(true);

  // Sync local state from the DOM (initial state set by layout script).
  // This is the canonical "subscribe to external state and update React
  // state in response" pattern that the react-hooks/set-state-in-effect
  // rule explicitly permits — but the linter can't tell, so we disable.
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setIsDark(readDarkFromDom());
  }, []);

  // Listen for cross-component theme changes.
  useEffect(() => {
    const onThemeChange = () => setIsDark(readDarkFromDom());
    window.addEventListener(THEME_EVENT, onThemeChange);
    return () => window.removeEventListener(THEME_EVENT, onThemeChange);
  }, []);

  const toggle = useCallback(() => {
    const next = !readDarkFromDom();
    document.documentElement.classList.toggle("dark", next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next ? "dark" : "light");
    } catch {
      /* ignore */
    }
    setIsDark(next);
    // Notify other components (e.g. the other theme toggle in profile menu)
    window.dispatchEvent(new CustomEvent(THEME_EVENT));
  }, []);

  return { isDark, toggle };
}
