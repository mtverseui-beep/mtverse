"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useUI } from "@/hooks/use-dashboard";

/**
 * Global keyboard shortcuts.
 *
 *   ⌘K / Ctrl+K       → toggle command palette (registered in UIProvider)
 *   ⇧⌘P / ⇧Ctrl+P     → navigate to /settings/profile
 *   ⌘B  / Ctrl+B      → navigate to /billing
 *   ⌘,  / Ctrl+,      → navigate to /settings
 *   ?                  → open support chat (demo)
 *   g h / g a / g c    → vim-style nav (g then h/a/c/b/s) for overview /
 *                        analytics / customers / billing / settings
 *
 * Shortcuts are disabled when the user is typing in an input, textarea,
 * or contenteditable element (so they don't interfere with form editing).
 *
 * ⌘K is intentionally NOT registered here — it's already in UIProvider
 * to avoid double-registration. We only register the navigation shortcuts.
 */
export function useGlobalShortcuts() {
  const router = useRouter();
  const { setCommandOpen } = useUI();

  useEffect(() => {
    let lastG = 0; // timestamp of last "g" press for vim-style nav
    const G_TIMEOUT = 700; // ms window to press the next key

    function isTypingTarget(t: EventTarget | null): boolean {
      if (!(t instanceof HTMLElement)) return false;
      const tag = t.tagName.toLowerCase();
      if (tag === "input" || tag === "textarea" || tag === "select") return true;
      if (t.isContentEditable) return true;
      // Don't trigger shortcuts when a modifier (other than cmd/ctrl for our cmd-shortcuts) is held
      return false;
    }

    function onKey(e: KeyboardEvent) {
      const cmd = e.metaKey || e.ctrlKey;

      // ⌘K is handled by UIProvider — skip to avoid double-toggle.
      if (cmd && e.key.toLowerCase() === "k") return;

      // ⌘B → /billing (BUT only when not in an input — browser may use ⌘B for bookmarks)
      if (cmd && e.key.toLowerCase() === "b" && !isTypingTarget(e.target)) {
        e.preventDefault();
        router.push("/billing");
        return;
      }

      // ⌘, → /settings (Cmd+Comma is the macOS "Preferences" convention)
      if (cmd && e.key === "," && !isTypingTarget(e.target)) {
        e.preventDefault();
        router.push("/settings");
        return;
      }

      // ⇧⌘P → /settings/profile
      if (cmd && e.shiftKey && e.key.toLowerCase() === "p" && !isTypingTarget(e.target)) {
        e.preventDefault();
        router.push("/settings/profile");
        return;
      }

      // ? → support page (real navigation, not just an event dispatch)
      if (e.key === "?" && !isTypingTarget(e.target) && !cmd) {
        e.preventDefault();
        router.push("/support");
        return;
      }

      // Vim-style "g X" navigation (no modifiers)
      if (!cmd && !e.shiftKey && !e.altKey && !isTypingTarget(e.target)) {
        const now = performance.now();
        if (e.key.toLowerCase() === "g") {
          lastG = now;
          return;
        }
        if (now - lastG < G_TIMEOUT) {
          const target: Record<string, string> = {
            h: "/",
            a: "/analytics",
            c: "/customers",
            b: "/billing",
            s: "/settings",
          };
          const path = target[e.key.toLowerCase()];
          if (path) {
            e.preventDefault();
            router.push(path);
            lastG = 0;
            return;
          }
        }
        // "k" alone opens command palette (vim-style)
        if (e.key.toLowerCase() === "k" && !cmd) {
          // Only if not typing
          if (!isTypingTarget(e.target)) {
            // Don't prevent default — let the user type "k" in search etc.
            // Only trigger if focus is on body.
            const active = document.activeElement;
            if (active === document.body || active === null) {
              e.preventDefault();
              setCommandOpen(true);
              return;
            }
          }
        }
      }
    }

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [router, setCommandOpen]);
}
