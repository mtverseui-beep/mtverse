"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  Github,
  Loader2,
  Lock,
  Mail,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { BrandMark } from "@/components/dashboard/brand-mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const HIGHLIGHTS = [
  { title: "Real-time MRR tracking", desc: "See revenue update the moment a subscription changes." },
  { title: "SOC 2 Type II + HIPAA", desc: "Enterprise-grade security, audited annually." },
  { title: "99.99% uptime SLA", desc: "Multi-region failover with a 4-hour RTO guarantee." },
];

export function SignInClient() {
  const router = useRouter();
  const [email, setEmail] = useState("avery@northstar.io");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  function submit(e?: React.FormEvent) {
    e?.preventDefault();
    const errs: Record<string, string> = {};
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errs.email = "Enter a valid work email.";
    if (password.length < 6) errs.password = "Password must be at least 6 characters.";
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setLoading(true);
    // Simulate auth call
    window.setTimeout(() => {
      setLoading(false);
      toast.success("Welcome back, Avery", { description: "Redirecting to your dashboard…" });
      router.push("/");
    }, 1100);
  }

  function sso(provider: "google" | "github" | "saml") {
    toast.info(`Redirecting to ${provider === "saml" ? "your SAML IdP" : provider + " OAuth"}…`);
    window.setTimeout(() => {
      router.push("/");
    }, 900);
  }

  return (
    <div className="min-h-screen bg-background grid lg:grid-cols-2">
      {/* Left: form column */}
      <div className="flex flex-col p-6 md:p-10">
        <Link href="/" className="flex items-center gap-2.5 cursor-pointer w-fit">
          <span className="brand-mark grid h-9 w-9 place-items-center rounded-xl text-primary-foreground">
            <BrandMark className="h-5 w-5 text-white" />
          </span>
          <div className="leading-tight">
            <p className="text-sm font-semibold text-foreground tracking-tight">Northstar</p>
            <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Analytics Cloud</p>
          </div>
        </Link>

        <div className="flex-1 flex flex-col justify-center max-w-sm w-full mx-auto py-10">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">Sign in to your workspace</h1>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Welcome back. Enter your credentials to continue.
            </p>
          </motion.div>

          {/* SSO buttons */}
          <div className="mt-6 grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              className="gap-2 h-10 cursor-pointer"
              onClick={() => sso("google")}
            >
              <GoogleIcon className="h-4 w-4" /> Google
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-2 h-10 cursor-pointer"
              onClick={() => sso("github")}
            >
              <Github className="h-4 w-4" /> GitHub
            </Button>
          </div>

          {/* Divider */}
          <div className="my-5 flex items-center gap-3">
            <div className="h-px flex-1 bg-border" />
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">or email</span>
            <div className="h-px flex-1 bg-border" />
          </div>

          {/* Email + password form */}
          <form onSubmit={submit} className="space-y-3">
            <div>
              <label htmlFor="signin-email" className="text-xs font-medium text-foreground">Work email</label>
              <div className="relative mt-1">
                <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="signin-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.com"
                  className={cn("pl-8 h-10", errors.email && "border-destructive")}
                  autoComplete="email"
                  autoFocus
                />
              </div>
              {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email}</p>}
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="signin-pw" className="text-xs font-medium text-foreground">Password</label>
                <button
                  type="button"
                  onClick={() => toast.info("Password reset link sent to your email")}
                  className="text-[11px] text-primary hover:underline cursor-pointer"
                >
                  Forgot?
                </button>
              </div>
              <div className="relative mt-1">
                <Lock className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="signin-pw"
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className={cn("pl-8 pr-9 h-10", errors.password && "border-destructive")}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer"
                  aria-label={showPw ? "Hide password" : "Show password"}
                >
                  {showPw ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
              {errors.password && <p className="mt-1 text-xs text-destructive">{errors.password}</p>}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setRemember((v) => !v)}
                className={cn(
                  "grid h-4 w-4 place-items-center rounded border transition-colors cursor-pointer",
                  remember ? "bg-primary border-primary text-primary-foreground" : "border-border bg-background",
                )}
                aria-pressed={remember}
                aria-label="Remember this device"
              >
                {remember && <CheckCircle2 className="h-3 w-3" />}
              </button>
              <label className="text-xs text-muted-foreground cursor-pointer" onClick={() => setRemember((v) => !v)}>
                Trust this device for 30 days
              </label>
            </div>

            <Button type="submit" disabled={loading} className="w-full h-10 gap-1.5 cursor-pointer">
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Signing in…
                </>
              ) : (
                <>
                  Sign in <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </form>

          {/* SAML SSO link */}
          <button
            type="button"
            onClick={() => sso("saml")}
            className="mt-3 w-full text-center text-xs text-muted-foreground hover:text-foreground cursor-pointer"
          >
            Use SAML SSO <span className="text-foreground/60">(enterprise)</span>
          </button>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            Don&apos;t have an account?{" "}
            <Link href="/signin" className="text-primary hover:underline cursor-pointer">
              Start a free trial
            </Link>
          </p>
        </div>

        <div className="text-[11px] text-muted-foreground flex items-center gap-3 flex-wrap">
          <span className="flex items-center gap-1">
            <ShieldCheck className="h-3 w-3" /> SOC 2
          </span>
          <span className="flex items-center gap-1">
            <Sparkles className="h-3 w-3" /> 14-day trial
          </span>
          <span>© 2026 Northstar Analytics</span>
        </div>
      </div>

      {/* Right: hero column — only on large screens */}
      <div className="hidden lg:block relative overflow-hidden bg-sidebar">
        <div
          aria-hidden
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(700px circle at 20% 20%, color-mix(in oklch, var(--primary) 18%, transparent), transparent 50%), radial-gradient(500px circle at 80% 80%, color-mix(in oklch, var(--chart-2) 14%, transparent), transparent 50%)",
          }}
        />
        <div aria-hidden className="absolute inset-0 bg-grid opacity-30" />

        <div className="relative h-full flex flex-col justify-center p-12 xl:p-16">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-[11px] font-medium text-primary">
              <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
              All systems operational
            </span>
            <h2 className="mt-5 text-3xl xl:text-4xl font-semibold tracking-tight text-foreground leading-tight">
              The analytics workspace<br />
              <span className="text-gradient-accent">trusted by 3,800+ SaaS teams.</span>
            </h2>
            <p className="mt-3 text-sm text-muted-foreground max-w-md">
              Track MRR, churn, and customer health in one place. Built for operators who need
              real numbers, not vanity metrics.
            </p>
          </motion.div>

          <ul className="mt-8 space-y-4 max-w-md">
            {HIGHLIGHTS.map((h, i) => (
              <motion.li
                key={h.title}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.2 + i * 0.08 }}
                className="flex items-start gap-3"
              >
                <span className="grid h-7 w-7 place-items-center rounded-md bg-primary/15 text-primary shrink-0">
                  <CheckCircle2 className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-sm font-medium text-foreground">{h.title}</p>
                  <p className="text-xs text-muted-foreground">{h.desc}</p>
                </div>
              </motion.li>
            ))}
          </ul>

          {/* Stat strip */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.5 }}
            className="mt-10 grid grid-cols-3 gap-3 max-w-md"
          >
            {[
              { v: "$2.4B+", l: "MRR tracked" },
              { v: "3,842", l: "Active teams" },
              { v: "99.99%", l: "Uptime" },
            ].map((s) => (
              <div key={s.l} className="rounded-md border border-border bg-card/60 backdrop-blur p-3">
                <p className="text-lg font-semibold tabular-nums text-foreground">{s.v}</p>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.l}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function GoogleIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1Z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z" />
      <path fill="#FBBC05" d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84Z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84C6.71 7.3 9.14 5.38 12 5.38Z" />
    </svg>
  );
}
