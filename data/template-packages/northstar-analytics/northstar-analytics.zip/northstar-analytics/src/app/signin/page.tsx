import type { Metadata } from "next";
import { SignInClient } from "./signin-client";

export const metadata: Metadata = {
  title: "Sign in — Northstar Analytics",
  description:
    "Sign in to your Northstar Analytics workspace. Email + password, Google, GitHub, or SAML SSO for enterprise plans.",
};

export default function Page() {
  return <SignInClient />;
}
