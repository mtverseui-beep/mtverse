import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

const APP_URL = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(APP_URL),
  title: {
    default: "Northstar Analytics — SaaS Dashboard",
    template: "%s",
  },
  description:
    "Production-grade SaaS analytics dashboard for tracking MRR, churn, customers, billing, and team settings.",
  applicationName: "Northstar Analytics",
  keywords: ["SaaS", "analytics", "dashboard", "MRR", "subscription", "Next.js", "churn"],
  authors: [{ name: "Northstar Analytics" }],
  creator: "Northstar Analytics",
  publisher: "Northstar Analytics",
  icons: {
    icon: [{ url: "/favicon.svg", type: "image/svg+xml" }],
    shortcut: ["/favicon.svg"],
    apple: [{ url: "/favicon.svg" }],
  },
  manifest: "/manifest.webmanifest",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: APP_URL,
    siteName: "Northstar Analytics",
    title: "Northstar Analytics — SaaS Dashboard",
    description:
      "Track MRR, churn, customers, billing, and team settings in one production-grade dashboard.",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "Northstar Analytics",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Northstar Analytics — SaaS Dashboard",
    description:
      "Track MRR, churn, customers, billing, and team settings in one production-grade dashboard.",
    images: ["/og.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0a0b" },
  ],
  width: "device-width",
  initialScale: 1,
  colorScheme: "dark light",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <head>
        {/* Apply persisted theme before first paint to avoid a flash. */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('ns.theme');var prefersLight=window.matchMedia('(prefers-color-scheme: light)').matches;var theme=t||(prefersLight?'light':'dark');document.documentElement.classList.toggle('dark',theme==='dark');}catch(e){document.documentElement.classList.add('dark');}})();`,
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster position="bottom-right" richColors closeButton />
      </body>
    </html>
  );
}
