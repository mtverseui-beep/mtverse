"use client";

import { useEffect } from "react";
import Link from "next/link";
import { AlertTriangle, RotateCcw, Home, Bug } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BrandMark } from "@/components/dashboard/brand-mark";

/**
 * Global error boundary — catches uncaught errors in any route segment
 * and shows a recoverable UI instead of a blank page.
 *
 * https://nextjs.org/docs/app/api-reference/file-conventions/error
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // In production this would forward to Sentry / your error tracker.
    console.error("[northstar] uncaught error:", error);
  }, [error]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b border-border bg-background">
        <div className="max-w-6xl mx-auto h-16 px-4 md:px-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 cursor-pointer">
            <span className="brand-mark grid h-8 w-8 place-items-center rounded-lg text-primary-foreground">
              <BrandMark className="h-4 w-4 text-white" />
            </span>
            <span className="text-sm font-semibold text-foreground">Northstar</span>
          </Link>
          <Link
            href="/signin"
            className="text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
          >
            Sign in
          </Link>
        </div>
      </header>

      <main className="flex-1 grid place-items-center px-4">
        <div className="max-w-md w-full text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-destructive/10 text-destructive mb-5">
            <AlertTriangle className="h-7 w-7" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">
            Something went wrong
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            An unexpected error occurred while rendering this page. Our team has been notified —
            you can try again, or head back to the dashboard.
          </p>

          {error.digest && (
            <p className="mt-3 text-[11px] font-mono text-muted-foreground/80">
              Error ID: {error.digest}
            </p>
          )}

          {process.env.NODE_ENV === "development" && error.message && (
            <pre className="mt-4 max-h-40 overflow-auto rounded-md border border-border bg-muted/40 p-3 text-left text-[11px] font-mono text-foreground/80">
              {error.message}
              {error.stack ? `\n\n${error.stack}` : ""}
            </pre>
          )}

          <div className="mt-6 flex items-center justify-center gap-2">
            <Button onClick={reset} className="gap-1.5 cursor-pointer">
              <RotateCcw className="h-4 w-4" /> Try again
            </Button>
            <Button variant="outline" asChild className="gap-1.5 cursor-pointer">
              <Link href="/">
                <Home className="h-4 w-4" /> Back to dashboard
              </Link>
            </Button>
          </div>

          <p className="mt-6 text-xs text-muted-foreground">
            Need to report this?{" "}
            <Link href="/support" className="text-primary hover:underline cursor-pointer inline-flex items-center gap-1">
              <Bug className="h-3 w-3" /> Contact support
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
