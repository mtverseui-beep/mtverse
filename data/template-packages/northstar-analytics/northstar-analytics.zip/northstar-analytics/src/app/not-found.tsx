import Link from "next/link";
import { Compass, Home, BookOpen, LifeBuoy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BrandMark } from "@/components/dashboard/brand-mark";

/**
 * Global 404 — shown when no route matches.
 *
 * https://nextjs.org/docs/app/api-reference/file-conventions/not-found
 */
export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b border-border bg-background">
        <div className="max-w-6xl mx-auto h-16 px-4 md:px-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 cursor-pointer">
            <span className="brand-mark grid h-8 w-8 place-items-center rounded-lg text-primary-foreground">
              <BrandMark className="h-4 w-4 text-white" />
            </span>
            <span className="text-sm font-semibold text-foreground">Northstar</span>
          </Link>
          <Link
            href="/signin"
            className="text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
          >
            Sign in
          </Link>
        </div>
      </header>

      <main className="flex-1 grid place-items-center px-4">
        <div className="max-w-lg w-full text-center">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-primary/10 text-primary mb-6">
            <Compass className="h-8 w-8" />
          </div>

          <p className="text-[11px] font-mono uppercase tracking-[0.2em] text-primary mb-2">
            404 · Not Found
          </p>
          <h1 className="text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
            We couldn&apos;t find that page
          </h1>
          <p className="mt-3 text-sm text-muted-foreground max-w-md mx-auto">
            The URL you followed may be broken, the resource may have been moved, or you may not
            have access. Try heading back to the dashboard, or browse our docs.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <Button asChild className="gap-1.5 cursor-pointer">
              <Link href="/">
                <Home className="h-4 w-4" /> Back to dashboard
              </Link>
            </Button>
            <Button variant="outline" asChild className="gap-1.5 cursor-pointer">
              <Link href="/docs">
                <BookOpen className="h-4 w-4" /> Browse docs
              </Link>
            </Button>
            <Button variant="outline" asChild className="gap-1.5 cursor-pointer">
              <Link href="/support">
                <LifeBuoy className="h-4 w-4" /> Contact support
              </Link>
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
