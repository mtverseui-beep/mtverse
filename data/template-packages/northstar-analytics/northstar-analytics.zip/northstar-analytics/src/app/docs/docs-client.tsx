"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  ChevronRight,
  Code2,
  Compass,
  CreditCard,
  GitBranch,
  Lock,
  Search,
  Terminal,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { BrandMark } from "@/components/dashboard/brand-mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface DocArticle {
  slug: string;
  title: string;
  description: string;
  category: string;
  readTime: string;
  updated: string;
}

interface DocCategory {
  id: string;
  label: string;
  icon: LucideIcon;
  color: string;
  description: string;
  articles: DocArticle[];
}

const CATEGORIES: DocCategory[] = [
  {
    id: "getting-started",
    label: "Getting Started",
    icon: Compass,
    color: "var(--chart-1)",
    description: "Set up your workspace and invite your team",
    articles: [
      { slug: "quickstart", title: "Quickstart: Ship in 5 minutes", description: "Create your first dashboard, connect a data source, and invite a teammate.", category: "Getting Started", readTime: "5 min", updated: "2026-07-28" },
      { slug: "workspace-setup", title: "Workspace setup checklist", description: "Configure your workspace name, logo, default plan, and timezone.", category: "Getting Started", readTime: "8 min", updated: "2026-07-25" },
      { slug: "invite-team", title: "Inviting teammates and roles", description: "Owner, admin, member, viewer — what each role can do.", category: "Getting Started", readTime: "4 min", updated: "2026-07-22" },
      { slug: "first-dashboard", title: "Building your first dashboard", description: "How to add KPI cards, charts, and filters to a new dashboard.", category: "Getting Started", readTime: "12 min", updated: "2026-07-20" },
    ],
  },
  {
    id: "analytics",
    label: "Analytics & Metrics",
    icon: Zap,
    color: "var(--chart-2)",
    description: "Understand MRR, churn, cohorts, and funnels",
    articles: [
      { slug: "mrr-explained", title: "MRR vs. ARR vs. GAAP revenue", description: "The three revenue metrics SaaS teams track, and when to use each.", category: "Analytics", readTime: "9 min", updated: "2026-07-30" },
      { slug: "churn-cohorts", title: "Churn vs. contraction: what's the difference?", description: "Logo churn, revenue churn, and contraction — and which one matters most.", category: "Analytics", readTime: "7 min", updated: "2026-07-29" },
      { slug: "cohort-retention", title: "Reading cohort retention charts", description: "How to interpret the cohort chart and spot retention problems early.", category: "Analytics", readTime: "11 min", updated: "2026-07-27" },
      { slug: "funnel-mapping", title: "Mapping your signup funnel", description: "Track visits → signups → activations → trials → paid conversions.", category: "Analytics", readTime: "8 min", updated: "2026-07-24" },
    ],
  },
  {
    id: "billing",
    label: "Billing & Plans",
    icon: CreditCard,
    color: "var(--chart-3)",
    description: "Manage subscriptions, invoices, and payment methods",
    articles: [
      { slug: "plan-tiers", title: "Plan tiers and limits explained", description: "Free, Starter, Pro, Scale, Enterprise — what each tier includes.", category: "Billing", readTime: "6 min", updated: "2026-07-31" },
      { slug: "proration", title: "How proration works on upgrade", description: "When you upgrade mid-cycle, we charge the difference prorated by day.", category: "Billing", readTime: "5 min", updated: "2026-07-30" },
      { slug: "invoices-pdf", title: "Downloading invoices as PDF", description: "Every invoice is downloadable as a PDF with your company's branding.", category: "Billing", readTime: "3 min", updated: "2026-07-28" },
      { slug: "stripe-migration", title: "Migrating from Stripe Billing", description: "Import your customers, subscriptions, and invoices from Stripe.", category: "Billing", readTime: "14 min", updated: "2026-07-22" },
    ],
  },
  {
    id: "api",
    label: "API & Webhooks",
    icon: Code2,
    color: "var(--chart-4)",
    description: "Programmatic access and real-time events",
    articles: [
      { slug: "api-keys", title: "Creating and rotating API keys", description: "Live vs. test keys, scopes, and how to rotate without downtime.", category: "API", readTime: "7 min", updated: "2026-07-31" },
      { slug: "rate-limits", title: "Rate limits and quotas", description: "Per-plan rate limits, the 429 backoff protocol, and how to request increases.", category: "API", readTime: "5 min", updated: "2026-07-29" },
      { slug: "webhooks", title: "Webhook signature verification", description: "Verify webhook payloads with HMAC-SHA256 to prevent spoofing.", category: "API", readTime: "10 min", updated: "2026-07-26" },
      { slug: "pagination", title: "Pagination and cursor conventions", description: "All list endpoints use cursor-based pagination. Here's how to use it.", category: "API", readTime: "4 min", updated: "2026-07-23" },
    ],
  },
  {
    id: "integrations",
    label: "Integrations",
    icon: GitBranch,
    color: "var(--chart-5)",
    description: "Connect Northstar to your stack",
    articles: [
      { slug: "stripe", title: "Stripe integration guide", description: "Sync customers, subscriptions, and invoices bi-directionally with Stripe.", category: "Integrations", readTime: "12 min", updated: "2026-07-30" },
      { slug: "slack", title: "Slack alerts and digests", description: "Get MRR milestones, churn alerts, and weekly digests in Slack.", category: "Integrations", readTime: "6 min", updated: "2026-07-28" },
      { slug: "segment", title: "Segment event tracking", description: "Forward product events from Segment to enrich customer profiles.", category: "Integrations", readTime: "9 min", updated: "2026-07-25" },
      { slug: "sso-okta", title: "SSO with Okta (SAML)", description: "Configure SAML SSO with Okta for Enterprise plans.", category: "Integrations", readTime: "11 min", updated: "2026-07-21" },
    ],
  },
  {
    id: "security",
    label: "Security & Compliance",
    icon: Lock,
    color: "var(--chart-4)",
    description: "How we protect your data",
    articles: [
      { slug: "soc2", title: "SOC 2 Type II report", description: "Our annual SOC 2 audit covers security, availability, and confidentiality.", category: "Security", readTime: "4 min", updated: "2026-07-15" },
      { slug: "data-residency", title: "Data residency options", description: "Choose US, EU, or APAC regions for data storage. Available on Scale+.", category: "Security", readTime: "6 min", updated: "2026-07-12" },
      { slug: "audit-log", title: "Reading the audit log", description: "Every privileged action is logged. Here's how to export and review it.", category: "Security", readTime: "8 min", updated: "2026-07-10" },
      { slug: "hipaa", title: "HIPAA compliance for Healthtech", description: "Sign a BAA and enable PHI mode for HIPAA-covered workloads.", category: "Security", readTime: "10 min", updated: "2026-07-08" },
    ],
  },
];

const ALL_ARTICLES = CATEGORIES.flatMap((c) => c.articles);

export function DocsClient() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("all");

  const filteredArticles = useMemo(() => {
    let list = ALL_ARTICLES;
    if (activeCategory !== "all") {
      const cat = CATEGORIES.find((c) => c.id === activeCategory);
      list = cat ? cat.articles : [];
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (a) => a.title.toLowerCase().includes(q) || a.description.toLowerCase().includes(q) || a.category.toLowerCase().includes(q),
      );
    }
    return list;
  }, [search, activeCategory]);

  return (
    <div className="min-h-screen bg-background">
      {/* Top nav */}
      <header className="border-b border-border bg-background sticky top-0 z-30">
        <div className="max-w-7xl mx-auto h-16 px-4 md:px-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 cursor-pointer">
            <span className="brand-mark grid h-8 w-8 place-items-center rounded-lg text-primary-foreground">
              <BrandMark className="h-4 w-4 text-white" />
            </span>
            <span className="text-sm font-semibold text-foreground">Northstar Docs</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link
              href="/support"
              className="text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
            >
              Support
            </Link>
            <Button size="sm" asChild className="cursor-pointer">
              <Link href="/signin">Open dashboard</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="border-b border-border bg-gradient-to-br from-primary/5 via-transparent to-transparent">
        <div className="max-w-4xl mx-auto px-4 md:px-6 py-12 md:py-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Badge variant="secondary" className="gap-1 mb-3">
              <BookOpen className="h-3 w-3" /> Documentation
            </Badge>
            <h1 className="text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
              Everything you need to know about Northstar
            </h1>
            <p className="mt-3 text-sm text-muted-foreground max-w-2xl mx-auto">
              Guides, API references, and best practices for tracking MRR, churn, and customer health
              with Northstar Analytics.
            </p>

            {/* Search bar */}
            <div className="relative mt-6 max-w-xl mx-auto">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search the docs…"
                className="pl-9 h-11 text-sm"
                autoFocus
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer text-xs"
                >
                  Clear
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      <main className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12">
        <Link href="/" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer mb-6">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to dashboard
        </Link>

        {!search && activeCategory === "all" && (
          <>
            {/* Category grid */}
            <h2 className="text-sm font-semibold text-foreground mb-3">Browse by category</h2>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 mb-12">
              {CATEGORIES.map((cat, i) => (
                <motion.button
                  key={cat.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                  onClick={() => {
                    setActiveCategory(cat.id);
                    document.getElementById("articles")?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }}
                  className="text-left rounded-lg surface-card surface-card-hover p-5 cursor-pointer"
                >
                  <span
                    className="grid h-10 w-10 place-items-center rounded-md mb-3"
                    style={{ background: `${cat.color}20`, color: cat.color }}
                  >
                    <cat.icon className="h-5 w-5" />
                  </span>
                  <p className="text-sm font-semibold text-foreground">{cat.label}</p>
                  <p className="text-xs text-muted-foreground mt-1">{cat.description}</p>
                  <p className="mt-3 text-[11px] text-primary inline-flex items-center gap-1">
                    {cat.articles.length} articles <ArrowRight className="h-3 w-3" />
                  </p>
                </motion.button>
              ))}
            </div>
          </>
        )}

        {/* Article list */}
        <div id="articles" className="grid gap-8 lg:grid-cols-[220px_1fr]">
          {/* Sidebar */}
          <aside className="lg:sticky lg:top-20 lg:self-start">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Categories</h3>
            <ul className="space-y-0.5">
              <li>
                <button
                  onClick={() => setActiveCategory("all")}
                  className={cn(
                    "flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-sm transition-colors cursor-pointer",
                    activeCategory === "all" ? "bg-primary/10 text-foreground font-medium" : "text-muted-foreground hover:bg-muted/60 hover:text-foreground",
                  )}
                >
                  <BookOpen className="h-3.5 w-3.5" /> All articles
                  <span className="ml-auto text-[10px] text-muted-foreground">{ALL_ARTICLES.length}</span>
                </button>
              </li>
              {CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => setActiveCategory(cat.id)}
                    className={cn(
                      "flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-sm transition-colors cursor-pointer",
                      activeCategory === cat.id ? "bg-primary/10 text-foreground font-medium" : "text-muted-foreground hover:bg-muted/60 hover:text-foreground",
                    )}
                  >
                    <cat.icon className="h-3.5 w-3.5" style={{ color: cat.color }} />
                    <span className="truncate">{cat.label}</span>
                    <span className="ml-auto text-[10px] text-muted-foreground">{cat.articles.length}</span>
                  </button>
                </li>
              ))}
            </ul>

            <div className="mt-6 rounded-md border border-border bg-muted/30 p-3">
              <p className="text-xs font-medium text-foreground mb-1">Need more help?</p>
              <p className="text-[11px] text-muted-foreground mb-2">Our team replies in under 4 hours.</p>
              <Button size="sm" variant="outline" asChild className="w-full cursor-pointer">
                <Link href="/support">Contact support</Link>
              </Button>
            </div>
          </aside>

          {/* Articles */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-foreground">
                {activeCategory === "all" ? "All articles" : CATEGORIES.find((c) => c.id === activeCategory)?.label}
              </h2>
              <span className="text-xs text-muted-foreground">{filteredArticles.length} articles</span>
            </div>

            {filteredArticles.length === 0 ? (
              <div className="rounded-lg surface-card p-8 text-center">
                <Search className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm font-medium text-foreground">No articles found</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Try a different search term, or{" "}
                  <Link href="/support" className="text-primary hover:underline cursor-pointer">contact support</Link>.
                </p>
              </div>
            ) : (
              <div className="grid gap-2">
                {filteredArticles.map((article, i) => {
                  const cat = CATEGORIES.find((c) => c.id === activeCategory || c.articles.includes(article));
                  const color = cat?.color ?? "var(--chart-1)";
                  return (
                    <motion.button
                      key={article.slug}
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2, delay: Math.min(i * 0.02, 0.2) }}
                      onClick={() => toast.info(`Opening "${article.title}"…`)}
                      className="text-left flex items-start gap-3 rounded-lg border border-border bg-card p-4 hover:border-foreground/20 hover:shadow-sm transition-all cursor-pointer group"
                    >
                      <span
                        className="grid h-9 w-9 place-items-center rounded-md shrink-0"
                        style={{ background: `${color}20`, color }}
                      >
                        <Terminal className="h-4 w-4" />
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                            {article.title}
                          </p>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{article.description}</p>
                        <div className="mt-2 flex items-center gap-3 text-[11px] text-muted-foreground">
                          <span className="rounded-full bg-muted px-2 py-0.5">{article.category}</span>
                          <span>{article.readTime} read</span>
                          <span>Updated {new Date(article.updated).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 mt-1 group-hover:translate-x-0.5 transition-transform" />
                    </motion.button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
