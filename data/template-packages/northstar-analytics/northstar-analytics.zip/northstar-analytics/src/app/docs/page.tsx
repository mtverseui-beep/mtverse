import type { Metadata } from "next";
import { DocsClient } from "./docs-client";

export const metadata: Metadata = {
  title: "Documentation — Northstar Analytics",
  description:
    "Guides, API references, and best practices for tracking MRR, churn, customers, and billing with Northstar Analytics. Searchable, categorized, regularly updated.",
};

export default function Page() {
  return <DocsClient />;
}
