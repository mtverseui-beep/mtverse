"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  ChevronRight,
  Clock,
  Mail,
  MessageSquare,
  Paperclip,
  Phone,
  Search,
  Send,
  Sparkles,
  Ticket,
  Zap,
} from "lucide-react";
import { BrandMark } from "@/components/dashboard/brand-mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { formatRelativeTime } from "@/lib/format";

const POPULAR_ARTICLES = [
  { id: "a1", title: "How to track MRR for usage-based pricing", category: "Analytics", views: "2.4k" },
  { id: "a2", title: "Setting up SAML SSO with Okta", category: "Setup", views: "1.8k" },
  { id: "a3", title: "Understanding churn vs. contraction", category: "Metrics", views: "1.5k" },
  { id: "a4", title: "Webhook signature verification", category: "API", views: "1.2k" },
  { id: "a5", title: "Migrating from Stripe Billing", category: "Billing", views: "980" },
  { id: "a6", title: "Cohort retention explained", category: "Analytics", views: "842" },
];

const TICKETS = [
  { id: "TKT-1042", subject: "Question about proration on Scale plan", status: "open" as const, priority: "normal" as const, updated: "2026-07-31T09:42:00Z" },
  { id: "TKT-1039", subject: "Need invoice PDF with custom PO number", status: "pending" as const, priority: "high" as const, updated: "2026-07-30T16:11:00Z" },
  { id: "TKT-1031", subject: "API rate limit increase request", status: "resolved" as const, priority: "normal" as const, updated: "2026-07-28T11:20:00Z" },
  { id: "TKT-1024", subject: "How to export customer list with MRR", status: "resolved" as const, priority: "low" as const, updated: "2026-07-25T14:00:00Z" },
];

const STATUS_META = {
  open: { label: "Open", className: "bg-success/15 text-success border-success/20" },
  pending: { label: "Awaiting reply", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  resolved: { label: "Resolved", className: "bg-muted text-muted-foreground border-border" },
};

const PRIORITY_META = {
  low: { label: "Low", className: "text-muted-foreground" },
  normal: { label: "Normal", className: "text-foreground" },
  high: { label: "High", className: "text-warning-foreground" },
  urgent: { label: "Urgent", className: "text-destructive" },
};

const CATEGORIES = [
  { icon: Zap, label: "Getting started", count: 18, color: "var(--chart-1)" },
  { icon: BookOpen, label: "Analytics & metrics", count: 42, color: "var(--chart-2)" },
  { icon: Mail, label: "Billing & plans", count: 27, color: "var(--chart-3)" },
  { icon: Ticket, label: "API & webhooks", count: 35, color: "var(--chart-4)" },
  { icon: Sparkles, label: "Integrations", count: 14, color: "var(--chart-5)" },
];

export function SupportClient() {
  const [search, setSearch] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [category, setCategory] = useState("general");
  const [priority, setPriority] = useState("normal");
  const [submitting, setSubmitting] = useState(false);

  function submitTicket(e?: React.FormEvent) {
    e?.preventDefault();
    if (subject.trim().length < 5) {
      toast.error("Subject must be at least 5 characters");
      return;
    }
    if (body.trim().length < 20) {
      toast.error("Please describe your issue in at least 20 characters");
      return;
    }
    setSubmitting(true);
    window.setTimeout(() => {
      setSubmitting(false);
      toast.success("Support ticket created", {
        description: `Ticket #TKT-${Math.floor(1000 + Math.random() * 9000)} opened. We'll reply within 4 hours.`,
      });
      setSubject("");
      setBody("");
    }, 1100);
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Top nav */}
      <header className="border-b border-border bg-background sticky top-0 z-30">
        <div className="max-w-6xl mx-auto h-16 px-4 md:px-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 cursor-pointer">
            <span className="brand-mark grid h-8 w-8 place-items-center rounded-lg text-primary-foreground">
              <BrandMark className="h-4 w-4 text-white" />
            </span>
            <span className="text-sm font-semibold text-foreground">Northstar Support</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link
              href="/docs"
              className="text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
            >
              Docs
            </Link>
            <Link
              href="/signin"
              className="text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
            >
              Sign in
            </Link>
            <Button size="sm" asChild className="cursor-pointer">
              <Link href="/signin">Open dashboard</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 md:px-6 py-8 md:py-12">
        {/* Back link */}
        <Link href="/" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer mb-6">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to dashboard
        </Link>

        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="text-center max-w-2xl mx-auto mb-12"
        >
          <h1 className="text-3xl md:text-4xl font-semibold tracking-tight text-foreground">
            How can we help?
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Search our knowledge base, browse popular articles, or open a ticket — our team replies in under 4 hours.
          </p>

          {/* Search bar */}
          <div className="relative mt-6 max-w-xl mx-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search for help articles…"
              className="pl-9 h-11 text-sm"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer text-xs"
              >
                Clear
              </button>
            )}
          </div>
        </motion.div>

        {/* Quick contact channels */}
        <div className="grid gap-3 sm:grid-cols-3 mb-12">
          {[
            { icon: MessageSquare, title: "Live chat", desc: "Mon–Fri, 8am–8pm ET", action: "Start chat", color: "var(--chart-1)" },
            { icon: Mail, title: "Email us", desc: "Reply within 4 hours", action: "Open email", color: "var(--chart-2)" },
            { icon: Phone, title: "Enterprise support", desc: "24/7 phone + Slack", action: "Book a call", color: "var(--chart-4)" },
          ].map((c, i) => (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.05 * i }}
              className="rounded-lg surface-card surface-card-hover p-4"
            >
              <span
                className="grid h-9 w-9 place-items-center rounded-md mb-3"
                style={{ background: `${c.color}20`, color: c.color }}
              >
                <c.icon className="h-4 w-4" />
              </span>
              <p className="text-sm font-medium text-foreground">{c.title}</p>
              <p className="text-xs text-muted-foreground mb-3">{c.desc}</p>
              <button
                onClick={() => toast.info(`${c.action} (demo)`)}
                className="text-xs text-primary hover:underline cursor-pointer inline-flex items-center gap-1"
              >
                {c.action} <ArrowRight className="h-3 w-3" />
              </button>
            </motion.div>
          ))}
        </div>

        {/* Categories + popular articles */}
        <div className="grid gap-8 lg:grid-cols-[280px_1fr] mb-12">
          {/* Categories */}
          <div>
            <h2 className="text-sm font-semibold text-foreground mb-3">Browse by category</h2>
            <ul className="space-y-1">
              {CATEGORIES.map((cat) => (
                <li key={cat.label}>
                  <Link
                    href="/docs"
                    className="flex items-center gap-3 rounded-md p-2.5 hover:bg-muted/60 transition-colors cursor-pointer group"
                  >
                    <span
                      className="grid h-7 w-7 place-items-center rounded-md shrink-0"
                      style={{ background: `${cat.color}20`, color: cat.color }}
                    >
                      <cat.icon className="h-3.5 w-3.5" />
                    </span>
                    <span className="flex-1 text-sm text-foreground">{cat.label}</span>
                    <span className="text-xs text-muted-foreground">{cat.count}</span>
                    <ChevronRight className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Popular articles */}
          <div>
            <h2 className="text-sm font-semibold text-foreground mb-3">Popular articles</h2>
            <div className="rounded-lg surface-card divide-y divide-border">
              {POPULAR_ARTICLES.filter((a) =>
                !search || a.title.toLowerCase().includes(search.toLowerCase()) || a.category.toLowerCase().includes(search.toLowerCase()),
              ).map((article) => (
                <Link
                  key={article.id}
                  href="/docs"
                  className="flex items-center gap-3 p-3.5 hover:bg-muted/40 transition-colors cursor-pointer group"
                >
                  <span className="grid h-9 w-9 place-items-center rounded-md bg-muted text-muted-foreground shrink-0">
                    <BookOpen className="h-4 w-4" />
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate group-hover:text-primary transition-colors">
                      {article.title}
                    </p>
                    <p className="text-xs text-muted-foreground">{article.category} · {article.views} views</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                </Link>
              ))}
              {search && POPULAR_ARTICLES.filter((a) =>
                a.title.toLowerCase().includes(search.toLowerCase()) || a.category.toLowerCase().includes(search.toLowerCase()),
              ).length === 0 && (
                <div className="p-6 text-center text-sm text-muted-foreground">
                  No articles match &quot;{search}&quot;. Try opening a ticket below.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Open ticket + ticket history */}
        <div className="grid gap-8 lg:grid-cols-2">
          {/* New ticket form */}
          <div>
            <h2 className="text-sm font-semibold text-foreground mb-3">Open a support ticket</h2>
            <form onSubmit={submitTicket} className="rounded-lg surface-card p-4 space-y-3">
              <div>
                <label htmlFor="ticket-subject" className="text-xs font-medium text-foreground">Subject</label>
                <Input
                  id="ticket-subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Brief summary of your issue"
                  className="mt-1"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-foreground">Category</label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger className="mt-1 w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="billing">Billing</SelectItem>
                      <SelectItem value="api">API / Webhooks</SelectItem>
                      <SelectItem value="bug">Bug report</SelectItem>
                      <SelectItem value="feature">Feature request</SelectItem>
                      <SelectItem value="security">Security</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs font-medium text-foreground">Priority</label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger className="mt-1 w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <label htmlFor="ticket-body" className="text-xs font-medium text-foreground">Describe your issue</label>
                <Textarea
                  id="ticket-body"
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="What were you trying to do? What happened instead? Include any error messages."
                  className="mt-1 min-h-32"
                />
                <p className="mt-1 text-[11px] text-muted-foreground">{body.length} / 2000 characters</p>
              </div>
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => toast.info("Attachment upload opened (demo)")}
                  className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground cursor-pointer"
                >
                  <Paperclip className="h-3.5 w-3.5" /> Attach screenshot
                </button>
                <Button type="submit" disabled={submitting} className="gap-1.5 cursor-pointer">
                  {submitting ? (
                    <>Submitting…</>
                  ) : (
                    <>
                      <Send className="h-3.5 w-3.5" /> Submit ticket
                    </>
                  )}
                </Button>
              </div>
            </form>
          </div>

          {/* Ticket history */}
          <div>
            <h2 className="text-sm font-semibold text-foreground mb-3">Your recent tickets</h2>
            <div className="rounded-lg surface-card divide-y divide-border">
              {TICKETS.map((t) => (
                <div key={t.id} className="p-3.5 hover:bg-muted/40 transition-colors cursor-pointer">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-[11px] text-muted-foreground">{t.id}</span>
                        <Badge variant="outline" className={cn("border text-[10px]", STATUS_META[t.status].className)}>
                          {STATUS_META[t.status].label}
                        </Badge>
                        <span className={cn("text-[10px] font-medium uppercase tracking-wider", PRIORITY_META[t.priority].className)}>
                          {PRIORITY_META[t.priority].label}
                        </span>
                      </div>
                      <p className="text-sm font-medium text-foreground truncate">{t.subject}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5 flex items-center gap-1">
                        <Clock className="h-3 w-3" /> Updated {formatRelativeTime(t.updated)}
                      </p>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 mt-1" />
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Need to escalate? Email <a href="mailto:urgent@northstar.io" className="text-primary hover:underline cursor-pointer">urgent@northstar.io</a> for urgent issues.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
