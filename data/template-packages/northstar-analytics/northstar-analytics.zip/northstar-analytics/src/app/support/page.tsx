import type { Metadata } from "next";
import { SupportClient } from "./support-client";

export const metadata: Metadata = {
  title: "Support — Northstar Analytics",
  description:
    "Search the knowledge base, browse popular articles, or open a support ticket. Our team replies in under 4 hours; enterprise plans get 24/7 Slack + phone.",
};

export default function Page() {
  return <SupportClient />;
}
