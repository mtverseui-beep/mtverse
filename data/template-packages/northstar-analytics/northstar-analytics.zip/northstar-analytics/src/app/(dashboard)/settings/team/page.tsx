import type { Metadata } from "next";
import { TeamSection } from "@/components/dashboard/settings";

export const metadata: Metadata = {
  title: "Team settings — Northstar Analytics",
  description:
    "Manage team members and their roles (Owner, Admin, Member, Viewer). Invite new teammates, revoke access, and see last-active timestamps.",
};

export default function Page() {
  return <TeamSection />;
}
