import type { Metadata } from "next";
import { NotificationsSection } from "@/components/dashboard/settings";

export const metadata: Metadata = {
  title: "Notification preferences — Northstar Analytics",
  description:
    "Choose which emails you receive: product updates, security alerts, billing reminders, weekly digest, and marketing emails.",
};

export default function Page() {
  return <NotificationsSection />;
}
