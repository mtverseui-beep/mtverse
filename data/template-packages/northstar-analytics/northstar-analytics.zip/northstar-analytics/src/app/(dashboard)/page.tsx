import type { Metadata } from "next";
import { OverviewPage } from "@/components/dashboard/overview";

export const metadata: Metadata = {
  title: "Overview — Northstar Analytics",
  description:
    "Real-time snapshot of MRR, active subscribers, churn, and conversion. Recent activity, upcoming invoices, and quick actions for daily operations.",
};

export default function Page() {
  return <OverviewPage />;
}
