import type { Metadata } from "next";
import { CustomersPage } from "@/components/dashboard/customers";

export const metadata: Metadata = {
  title: "Customers — Northstar Analytics",
  description:
    "Sortable, searchable, filterable directory of every customer account. Bulk actions, health badges, MRR, seats, plan tier, and per-customer detail drawer.",
};

export default function Page() {
  return <CustomersPage />;
}
