import { BrandMark } from "@/components/dashboard/brand-mark";

/**
 * Dashboard loading skeleton — shown while a dashboard route segment loads.
 *
 * Mirrors the dashboard shell (sidebar + topbar + content skeleton) so the
 * layout doesn't jump when the real content streams in.
 */
export default function DashboardLoading() {
  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar skeleton */}
      <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-border bg-sidebar">
        <div className="h-16 flex items-center gap-2.5 px-4 border-b border-border">
          <div className="brand-mark grid h-9 w-9 place-items-center rounded-xl">
            <BrandMark className="h-5 w-5 text-white" />
          </div>
          <div className="space-y-1.5">
            <div className="h-2.5 w-20 rounded bg-muted" />
            <div className="h-1.5 w-16 rounded bg-muted/70" />
          </div>
        </div>
        <div className="flex-1 p-3 space-y-1.5">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="flex items-center gap-2.5 rounded-md px-2.5 py-2">
              <div className="h-4 w-4 rounded bg-muted" />
              <div className="h-2.5 flex-1 rounded bg-muted" style={{ width: `${60 + (i % 3) * 20}px` }} />
            </div>
          ))}
        </div>
        <div className="p-3 border-t border-border">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-full bg-muted" />
            <div className="flex-1 space-y-1.5">
              <div className="h-2 w-20 rounded bg-muted" />
              <div className="h-1.5 w-24 rounded bg-muted/70" />
            </div>
          </div>
        </div>
      </aside>

      {/* Main column */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar skeleton */}
        <header className="h-16 flex items-center justify-between px-4 md:px-6 border-b border-border bg-background">
          <div className="flex items-center gap-3">
            <div className="h-2.5 w-32 rounded bg-muted" />
            <div className="h-4 w-px bg-border" />
            <div className="h-2.5 w-24 rounded bg-muted/70" />
          </div>
          <div className="flex items-center gap-2">
            <div className="h-8 w-64 rounded-md bg-muted" />
            <div className="h-8 w-8 rounded-md bg-muted" />
            <div className="h-8 w-8 rounded-full bg-muted" />
          </div>
        </header>

        {/* Content skeleton */}
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          {/* KPI row */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="rounded-lg surface-card p-5 space-y-3">
                <div className="h-2.5 w-24 rounded bg-muted" />
                <div className="h-7 w-28 rounded bg-muted/80" />
                <div className="h-1.5 w-32 rounded bg-muted/60" />
              </div>
            ))}
          </div>

          {/* Chart row */}
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="lg:col-span-2 rounded-lg surface-card p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="h-3 w-40 rounded bg-muted" />
                <div className="h-6 w-24 rounded bg-muted" />
              </div>
              <div className="h-64 w-full rounded bg-muted/40" />
            </div>
            <div className="rounded-lg surface-card p-5 space-y-3">
              <div className="h-3 w-32 rounded bg-muted" />
              <div className="h-64 w-full rounded bg-muted/40" />
            </div>
          </div>

          {/* Table row */}
          <div className="rounded-lg surface-card p-5 space-y-3">
            <div className="h-3 w-40 rounded bg-muted" />
            <div className="space-y-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 py-2">
                  <div className="h-4 w-4 rounded bg-muted" />
                  <div className="h-6 w-6 rounded-full bg-muted" />
                  <div className="h-2.5 flex-1 rounded bg-muted" />
                  <div className="h-2.5 w-20 rounded bg-muted/70" />
                  <div className="h-2.5 w-16 rounded bg-muted/70" />
                  <div className="h-6 w-16 rounded bg-muted/60" />
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
