"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell,
  KeyRound,
  UserCog,
  Users,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SettingsTab {
  path: string;
  label: string;
  description: string;
  icon: LucideIcon;
}

const TABS: SettingsTab[] = [
  { path: "/settings/profile", label: "Profile", description: "Your name, email, and bio", icon: UserCog },
  { path: "/settings/team", label: "Team", description: "Invite teammates and roles", icon: Users },
  { path: "/settings/api-keys", label: "API keys", description: "Authenticate API requests", icon: KeyRound },
  { path: "/settings/notifications", label: "Notifications", description: "Email and product updates", icon: Bell },
];

export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Settings</h2>
        <p className="text-sm text-muted-foreground">
          Manage your profile, team, API keys, and notification preferences.
        </p>
      </div>
      <div className="grid gap-6 lg:grid-cols-[200px_1fr]">
        {/* Settings sub-nav — sticky on desktop, horizontal scroll on mobile */}
        <nav aria-label="Settings sections" className="lg:sticky lg:top-20 lg:self-start">
          <ul className="flex gap-1 overflow-x-auto lg:flex-col lg:gap-0.5 no-scrollbar -mx-1 px-1 lg:mx-0 lg:px-0">
            {TABS.map((tab) => {
              const active = pathname === tab.path || (tab.path === "/settings/profile" && pathname === "/settings");
              const Icon = tab.icon;
              return (
                <li key={tab.path} className="shrink-0">
                  <Link
                    href={tab.path}
                    aria-current={active ? "page" : undefined}
                    className={cn(
                      "group flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors cursor-pointer",
                      "hover:bg-muted/60",
                      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                      active
                        ? "bg-primary/10 text-foreground font-medium"
                        : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    <Icon className={cn("h-4 w-4 shrink-0", active ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
                    <span className="whitespace-nowrap">{tab.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        <div className="min-w-0">{children}</div>
      </div>
    </div>
  );
}
