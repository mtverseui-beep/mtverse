import type { Metadata } from "next";
import { ProfileSection } from "@/components/dashboard/settings";

export const metadata: Metadata = {
  title: "Profile settings — Northstar Analytics",
  description:
    "Update your name, email, role, timezone, and avatar. Changes apply across the workspace immediately.",
};

export default function Page() {
  return <ProfileSection />;
}
