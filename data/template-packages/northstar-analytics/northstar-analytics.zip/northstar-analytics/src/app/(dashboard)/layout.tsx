"use client";

import { NavProvider, UIProvider } from "@/hooks/use-dashboard";
import { AppShell } from "@/components/dashboard/app-shell";
import { CommandPalette } from "@/components/dashboard/command-palette";
import { NotificationsPanel } from "@/components/dashboard/notifications";
import { useGlobalShortcuts } from "@/hooks/use-global-shortcuts";

/**
 * Dashboard layout — shared by every authenticated route.
 *
 * Provides:
 *   - UIProvider (command palette + notifications state)
 *   - NavProvider (range state for Analytics)
 *   - AppShell (sidebar + topbar + breadcrumb)
 *   - Global keyboard shortcuts (⇧⌘P, ⌘B, ⌘,, g X vim nav)
 *   - Command palette + notifications panel (rendered once here, not per-page)
 */
function GlobalShortcutsBinding() {
  // Mount the hook inside the provider tree so it can use useRouter + useUI.
  useGlobalShortcuts();
  return null;
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <UIProvider>
      <NavProvider>
        <GlobalShortcutsBinding />
        <AppShell>{children}</AppShell>
        <CommandPalette />
        <NotificationsPanel />
      </NavProvider>
    </UIProvider>
  );
}
