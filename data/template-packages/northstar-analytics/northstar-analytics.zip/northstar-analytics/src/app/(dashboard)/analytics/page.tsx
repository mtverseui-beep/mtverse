import type { Metadata } from "next";
import { AnalyticsPage } from "@/components/dashboard/analytics";

export const metadata: Metadata = {
  title: "Analytics — Northstar Analytics",
  description:
    "Deep-dive into revenue trends, MRR breakdown (new, expansion, churned), signup funnel conversion, and plan distribution across 7d / 30d / 90d / 1y ranges.",
};

export default function Page() {
  return <AnalyticsPage />;
}
