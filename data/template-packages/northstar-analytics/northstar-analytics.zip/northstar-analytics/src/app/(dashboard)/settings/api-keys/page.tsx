import type { Metadata } from "next";
import { ApiKeysSection } from "@/components/dashboard/settings";

export const metadata: Metadata = {
  title: "API keys — Northstar Analytics",
  description:
    "Create, rotate, and revoke live and test API keys. Each key carries scoped permissions (read, write, billing) and a last-used timestamp.",
};

export default function Page() {
  return <ApiKeysSection />;
}
