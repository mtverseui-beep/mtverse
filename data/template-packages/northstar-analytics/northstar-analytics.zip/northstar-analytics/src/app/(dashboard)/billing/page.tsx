import type { Metadata } from "next";
import { BillingPage } from "@/components/dashboard/billing";

export const metadata: Metadata = {
  title: "Billing — Northstar Analytics",
  description:
    "Manage your subscription plan, usage meters, payment methods (Visa / Mastercard / Amex / Discover), and invoice history with pay-now and remind-me actions.",
};

export default function Page() {
  return <BillingPage />;
}
