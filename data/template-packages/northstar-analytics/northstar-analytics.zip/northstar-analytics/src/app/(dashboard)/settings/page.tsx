import type { Metadata } from "next";
import { ProfileSection } from "@/components/dashboard/settings";

export const metadata: Metadata = {
  title: "Settings — Northstar Analytics",
  description:
    "Workspace settings: profile, team members, API keys, and notification preferences. Default landing page is your profile.",
};

export default function Page() {
  return <ProfileSection />;
}
