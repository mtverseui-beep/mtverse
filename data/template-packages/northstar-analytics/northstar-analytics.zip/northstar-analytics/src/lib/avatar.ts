/**
 * Illustrated face avatar generator — deterministic SVG.
 *
 * Produces a `data:image/svg+xml,...` URL (URL-encoded, NOT base64) for any
 * seed string. URL-encoding is more reliable than base64 across SSR/CSR
 * (no `window.btoa` vs `Buffer.from` mismatch) and renders correctly in
 * `<img>` tags, Radix Avatar, and CSS `background-image`.
 *
 * Visual style: a soft gradient background with an illustrated character —
 * face, hair, eyes, eyebrows, mouth, and optional accessories (glasses,
 * beard, earrings). Same seed always produces the same avatar.
 *
 * Inspired by Notion-style and DiceBear "notionists" / "avataaars" styles,
 * but fully self-hosted (no external API, no network dependency, works
 * offline). ~120 lines of SVG primitives.
 */

// ---------------------------------------------------------------------------
// Hashing & helpers
// ---------------------------------------------------------------------------

function hashSeed(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h | 0);
}

/** Split a hash into N independent buckets in [0, range). */
function splitHash(h: number, buckets: number, range: number): number[] {
  const out: number[] = [];
  let cur = h;
  for (let i = 0; i < buckets; i++) {
    // Mix between draws so consecutive buckets aren't correlated.
    cur = (Math.imul(cur ^ (cur >>> 13), 0x85ebca6b) + i * 0x9e3779b1) | 0;
    out.push(Math.abs(cur) % range);
  }
  return out;
}

function pick<T>(arr: readonly T[], n: number): T {
  return arr[n % arr.length];
}

// ---------------------------------------------------------------------------
// Curated palettes
// ---------------------------------------------------------------------------

// Skin tones — warm/cool variations, all soft enough to read at small sizes.
const SKIN_TONES = [
  "#fde2c4", // light warm
  "#f8d2b3", // light cool
  "#e8b890", // medium-light
  "#d49a6c", // medium
  "#b87644", // medium-deep
  "#8a4f2a", // deep
  "#6b3a1f", // deep-cool
];

// Hair colors — natural + a few accent colors for personality.
const HAIR_COLORS = [
  "#1f1b1a", // near-black
  "#2d221c", // dark brown
  "#5a3a23", // brown
  "#8a5a30", // light brown
  "#c79a52", // dirty blonde
  "#e8c97c", // blonde
  "#b8b8c4", // silver / grey
  "#9b4f3a", // auburn
  "#3a2a52", // purple-tinted
  "#2a4a6a", // blue-tinted
];

// Background gradient stops — vibrant but harmonious, avoids semantic colors.
const BG_PAIRS: ReadonlyArray<readonly [string, string]> = [
  ["#6366f1", "#8b5cf6"], // indigo → violet
  ["#0ea5e9", "#6366f1"], // sky → indigo
  ["#14b8a6", "#0ea5e9"], // teal → sky
  ["#f59e0b", "#ef4444"], // amber → red
  ["#ec4899", "#8b5cf6"], // pink → violet
  ["#10b981", "#14b8a6"], // emerald → teal
  ["#f43f5e", "#f59e0b"], // rose → amber
  ["#3b82f6", "#06b6d4"], // blue → cyan
  ["#a855f7", "#ec4899"], // purple → pink
  ["#84cc16", "#10b981"], // lime → emerald
  ["#0f766e", "#0ea5e9"], // deep teal → sky
  ["#7c3aed", "#4f46e5"], // violet → indigo
];

// Mouth shapes — pick one based on seed.
type MouthStyle = "smile" | "soft-smile" | "neutral" | "smirk";
const MOUTH_STYLES: MouthStyle[] = ["smile", "soft-smile", "neutral", "smirk"];

// Hair styles — index by number, see drawHair().
// 0 = short, 1 = bob, 2 = afro, 3 = bald, 4 = ponytail, 5 = buzz, 6 = long, 7 = bun
const HAIR_STYLES = [0, 1, 2, 3, 4, 5, 6, 7] as const;

// Eye styles — 0 = dots, 1 = round, 2 = closed (happy), 3 = lashes
const EYE_STYLES = [0, 1, 2, 3] as const;

// ---------------------------------------------------------------------------
// SVG primitives — all drawn in a 96×96 viewBox centered on (48, 52)
// (slightly below center so there's room for hair on top)
// ---------------------------------------------------------------------------

function drawBackground(bg: readonly [string, string], size: number): string {
  const [c1, c2] = bg;
  // Scale gradient coords with size.
  return `
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${c1}"/>
        <stop offset="100%" stop-color="${c2}"/>
      </linearGradient>
      <radialGradient id="spot" cx="0.7" cy="0.2" r="0.9">
        <stop offset="0%" stop-color="white" stop-opacity="0.35"/>
        <stop offset="60%" stop-color="white" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <rect width="${size}" height="${size}" fill="url(#bg)"/>
    <rect width="${size}" height="${size}" fill="url(#spot)"/>
  `;
}

function drawFace(skin: string): string {
  // Soft oval face centered at (48, 56), rx=22, ry=24.
  // Subtle cheek shading via inner ellipse with low-opacity dark overlay.
  return `
    <ellipse cx="48" cy="56" rx="22" ry="24" fill="${skin}"/>
    <ellipse cx="48" cy="56" rx="22" ry="24" fill="black" fill-opacity="0.04"/>
    <!-- ears -->
    <ellipse cx="26" cy="56" rx="4" ry="6" fill="${skin}"/>
    <ellipse cx="70" cy="56" rx="4" ry="6" fill="${skin}"/>
  `;
}

function drawHair(style: number, color: string, skin: string): string {
  // Each style is a small SVG snippet. Hair sits behind/over the top of the
  // face oval. Face top is at y≈32 (cy=56, ry=24).
  switch (style) {
    case 0: // short — top wave
      return `<path d="M 26 50 Q 28 28 48 28 Q 68 28 70 50 Q 66 38 48 36 Q 30 38 26 50 Z" fill="${color}"/>`;
    case 1: // bob — frame the face
      return `
        <path d="M 24 56 Q 22 30 48 28 Q 74 30 72 56 Q 70 44 70 50 L 70 64 Q 66 56 60 54 L 36 54 Q 30 56 26 64 L 26 50 Q 26 44 24 56 Z" fill="${color}"/>
      `;
    case 2: // afro — big rounded cloud
      return `<circle cx="48" cy="38" r="26" fill="${color}"/>
              <circle cx="28" cy="42" r="12" fill="${color}"/>
              <circle cx="68" cy="42" r="12" fill="${color}"/>
              <ellipse cx="48" cy="56" rx="22" ry="24" fill="${skin}"/>`;
    case 3: // bald — no hair, just subtle highlight
      return `<path d="M 26 50 Q 28 30 48 28 Q 68 30 70 50" stroke="${color}" stroke-opacity="0.18" stroke-width="2" fill="none"/>`;
    case 4: // ponytail — top hair + tail to the side
      return `
        <path d="M 26 50 Q 28 26 48 26 Q 68 26 70 50 Q 64 36 48 34 Q 32 36 26 50 Z" fill="${color}"/>
        <path d="M 70 48 Q 84 52 82 68 Q 80 78 72 78 Q 76 66 72 56 Q 70 52 70 48 Z" fill="${color}"/>
      `;
    case 5: // buzz — thin cap
      return `<path d="M 26 50 Q 28 30 48 30 Q 68 30 70 50 Q 60 40 48 40 Q 36 40 26 50 Z" fill="${color}" fill-opacity="0.85"/>`;
    case 6: // long — full flowing on both sides
      return `
        <path d="M 22 56 Q 20 28 48 26 Q 76 28 74 56 L 74 78 Q 70 70 68 60 L 68 50 Q 60 38 48 38 Q 36 38 28 50 L 28 60 Q 26 70 22 78 Z" fill="${color}"/>
        <ellipse cx="48" cy="56" rx="22" ry="24" fill="${skin}"/>
      `;
    case 7: // bun — top knot
      return `
        <circle cx="48" cy="20" r="9" fill="${color}"/>
        <path d="M 26 50 Q 28 30 48 30 Q 68 30 70 50 Q 60 40 48 40 Q 36 40 26 50 Z" fill="${color}"/>
      `;
    default:
      return "";
  }
}

function drawEyebrows(color: string, offsetY: number): string {
  // Two short arcs above the eyes. Color derived from hair color.
  const brow = color;
  return `
    <path d="M 36 ${46 + offsetY} Q 40 ${44 + offsetY} 44 ${46 + offsetY}" stroke="${brow}" stroke-width="1.6" stroke-linecap="round" fill="none"/>
    <path d="M 52 ${46 + offsetY} Q 56 ${44 + offsetY} 60 ${46 + offsetY}" stroke="${brow}" stroke-width="1.6" stroke-linecap="round" fill="none"/>
  `;
}

function drawEyes(style: number): string {
  // Eyes sit at y≈54, separated by ~16px. Left eye center (40,54), right (56,54).
  switch (style) {
    case 0: // dots
      return `
        <circle cx="40" cy="54" r="2" fill="#1f1b1a"/>
        <circle cx="56" cy="54" r="2" fill="#1f1b1a"/>
      `;
    case 1: // round (open eyes with iris + pupil + highlight)
      return `
        <ellipse cx="40" cy="54" rx="3.4" ry="3.8" fill="white"/>
        <ellipse cx="56" cy="54" rx="3.4" ry="3.8" fill="white"/>
        <circle cx="40" cy="54.5" r="2.2" fill="#3a2a23"/>
        <circle cx="56" cy="54.5" r="2.2" fill="#3a2a23"/>
        <circle cx="40.8" cy="53.6" r="0.7" fill="white"/>
        <circle cx="56.8" cy="53.6" r="0.7" fill="white"/>
      `;
    case 2: // closed (happy arcs)
      return `
        <path d="M 36 54 Q 40 50 44 54" stroke="#1f1b1a" stroke-width="1.6" stroke-linecap="round" fill="none"/>
        <path d="M 52 54 Q 56 50 60 54" stroke="#1f1b1a" stroke-width="1.6" stroke-linecap="round" fill="none"/>
      `;
    case 3: // lashes (feminine)
      return `
        <ellipse cx="40" cy="54" rx="3" ry="3.6" fill="white"/>
        <ellipse cx="56" cy="54" rx="3" ry="3.6" fill="white"/>
        <circle cx="40" cy="54.5" r="1.9" fill="#3a2a23"/>
        <circle cx="56" cy="54.5" r="1.9" fill="#3a2a23"/>
        <path d="M 36 51 L 35 49.5" stroke="#1f1b1a" stroke-width="0.8" stroke-linecap="round"/>
        <path d="M 40 50 L 40 48.5" stroke="#1f1b1a" stroke-width="0.8" stroke-linecap="round"/>
        <path d="M 44 51 L 45 49.5" stroke="#1f1b1a" stroke-width="0.8" stroke-linecap="round"/>
        <path d="M 52 51 L 51 49.5" stroke="#1f1b1a" stroke-width="0.8" stroke-linecap="round"/>
        <path d="M 56 50 L 56 48.5" stroke="#1f1b1a" stroke-width="0.8" stroke-linecap="round"/>
        <path d="M 60 51 L 61 49.5" stroke="#1f1b1a" stroke-width="0.8" stroke-linecap="round"/>
      `;
    default:
      return "";
  }
}

function drawNose(): string {
  // Small soft shadow under the nose bridge.
  return `<path d="M 47 58 Q 46 62 48 64 Q 50 64 49 62" stroke="black" stroke-opacity="0.18" stroke-width="1.2" stroke-linecap="round" fill="none"/>`;
}

function drawMouth(style: MouthStyle): string {
  // Mouth sits around y=68.
  switch (style) {
    case "smile":
      return `
        <path d="M 40 67 Q 48 74 56 67" stroke="#7a3b2f" stroke-width="1.8" stroke-linecap="round" fill="none"/>
        <path d="M 41 68 Q 48 73 55 68 Q 48 71 41 68 Z" fill="#c25c4f" fill-opacity="0.55"/>
      `;
    case "soft-smile":
      return `<path d="M 41 68 Q 48 71 55 68" stroke="#7a3b2f" stroke-width="1.6" stroke-linecap="round" fill="none"/>`;
    case "neutral":
      return `<path d="M 42 69 L 54 69" stroke="#7a3b2f" stroke-width="1.6" stroke-linecap="round" fill="none"/>`;
    case "smirk":
      return `<path d="M 41 69 Q 48 70 55 67" stroke="#7a3b2f" stroke-width="1.6" stroke-linecap="round" fill="none"/>`;
    default:
      return "";
  }
}

function drawBeard(color: string): string {
  // Beard wraps the lower face — drawn before mouth so mouth sits on top.
  return `
    <path d="M 28 60 Q 30 78 48 82 Q 66 78 68 60 Q 64 72 48 74 Q 32 72 28 60 Z" fill="${color}" fill-opacity="0.92"/>
  `;
}

function drawGlasses(): string {
  // Two circles connected by a bridge, with thin temples.
  return `
    <g stroke="#1f1b1a" stroke-width="1.2" fill="none">
      <circle cx="40" cy="54" r="5.5" fill="white" fill-opacity="0.18"/>
      <circle cx="56" cy="54" r="5.5" fill="white" fill-opacity="0.18"/>
      <line x1="45.5" y1="54" x2="50.5" y2="54"/>
      <line x1="34.5" y1="54" x2="28" y2="52"/>
      <line x1="61.5" y1="54" x2="68" y2="52"/>
    </g>
  `;
}

function drawEarrings(color: string): string {
  return `
    <circle cx="26" cy="62" r="1.4" fill="${color}"/>
    <circle cx="70" cy="62" r="1.4" fill="${color}"/>
  `;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function initialsFor(name: string): string {
  const cleaned = name.trim().replace(/\s+/g, " ");
  if (!cleaned) return "?";
  const parts = cleaned.split(" ");
  if (parts.length === 1) {
    const first = parts[0] ?? "";
    return first.slice(0, 2).toUpperCase();
  }
  const head = parts[0] ?? "";
  const tail = parts[parts.length - 1] ?? "";
  const headInitial = head[0] ?? "";
  const tailInitial = tail[0] ?? "";
  return (headInitial + tailInitial).toUpperCase();
}

export interface SvgAvatarOptions {
  /** Seed string (email, name, user id). Same seed = same avatar. */
  seed: string;
  /** Display name (kept for API compat — not used in the face avatar). */
  name?: string;
  /** SVG size in pixels (square). Default 96. */
  size?: number;
  /** Visual variant — kept for backward compat. All variants now produce a face. */
  variant?: "gradient" | "rings" | "bloom";
}

/**
 * Returns a `data:image/svg+xml,...` URL for a deterministic *illustrated*
 * avatar (face + hair + features). Same seed always produces the same avatar.
 *
 * URL-encoding (not base64) for SSR/CSR reliability.
 */
export function svgAvatarDataUrl({ seed, size = 96 }: SvgAvatarOptions): string {
  const h = hashSeed(seed || "anonymous");
  // 9 independent draws:
  //   [0] background pair, [1] skin tone, [2] hair color, [3] hair style,
  //   [4] eye style, [5] mouth style, [6] glasses?, [7] beard?, [8] earrings?
  const [bgIdx, skinIdx, hairIdx, hairStyleIdx, eyeIdx, mouthIdx, glassesR, beardR, earringsR] =
    splitHash(h, 9, 1024);

  const bg = pick(BG_PAIRS, bgIdx);
  const skin = pick(SKIN_TONES, skinIdx);
  const hairColor = pick(HAIR_COLORS, hairIdx);
  const hairStyle = pick(HAIR_STYLES, hairStyleIdx);
  const eyeStyle = pick(EYE_STYLES, eyeIdx);
  const mouthStyle = pick(MOUTH_STYLES, mouthIdx);

  // ~22% chance of glasses, ~25% chance of beard, ~28% chance of earrings.
  // Bald (style 3) people skip the beard to avoid weird overlaps.
  const hasGlasses = glassesR % 100 < 22;
  const hasBeard = hairStyle !== 3 && beardR % 100 < 25;
  const hasEarrings = earringsR % 100 < 28;

  // Scale the entire face group to fit `size`. We render at 96×96 viewBox
  // and let the consumer pick the rasterized size.
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 96 96">
  ${drawBackground(bg, 96)}
  ${drawHair(hairStyle, hairColor, skin)}
  ${drawFace(skin)}
  ${drawEyebrows(hairColor, hasBeard ? -1 : 0)}
  ${drawEyes(eyeStyle)}
  ${drawNose()}
  ${hasBeard ? drawBeard(hairColor) : ""}
  ${drawMouth(mouthStyle)}
  ${hasGlasses ? drawGlasses() : ""}
  ${hasEarrings ? drawEarrings("#f5b942") : ""}
</svg>`;

  const encoded = encodeURIComponent(svg)
    .replace(/'/g, "%27")
    .replace(/"/g, "%22");
  return `data:image/svg+xml,${encoded}`;
}

/**
 * Convenience: returns the data URL for a given email/name.
 * Memoized per-seed in module scope so repeated calls are cheap.
 */
const cache = new Map<string, string>();
export function avatarUrlFor(seed: string, name?: string): string {
  const key = `${seed}::${name ?? ""}`;
  const cached = cache.get(key);
  if (cached) return cached;
  const url = svgAvatarDataUrl({ seed, name });
  cache.set(key, url);
  return url;
}

/**
 * Variant helper — kept for backward compat. All variants now produce a face
 * avatar; the variant name no longer changes the visual style (it just
 * contributes to the cache key so existing callers don't need to change).
 */
export function avatarUrlForVariant(seed: string, name?: string): string {
  // Use the seed + a fixed suffix so variant callers get a different (but
  // still deterministic) avatar than non-variant callers for the same person.
  // This preserves the visual variety callers expected.
  const variantKey = `${seed}::${name ?? ""}::v2`;
  const cached = cache.get(variantKey);
  if (cached) return cached;
  // Hash a slightly different seed so the avatar differs from avatarUrlFor().
  const url = svgAvatarDataUrl({ seed: `${seed}::v2`, name });
  cache.set(variantKey, url);
  return url;
}
