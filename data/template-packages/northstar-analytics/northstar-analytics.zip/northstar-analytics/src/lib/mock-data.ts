import type {
  ApiKey,
  CommandAction,
  Customer,
  FunnelStage,
  Invoice,
  KpiSnapshot,
  NotificationItem,
  NotificationPrefs,
  PaymentMethod,
  PlanCard,
  PlanDistributionSlice,
  RangeKey,
  RevenuePoint,
  TeamMember,
  UsageMeter,
} from "./types";

// Deterministic PRNG so the dashboard renders identically on every load.
// (You can swap `mulberry32` for `Math.random` once wired to a real API.)
function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rng = mulberry32(20260731);
function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(rng() * arr.length)];
}
function between(min: number, max: number): number {
  return Math.floor(rng() * (max - min + 1)) + min;
}

// ---------------------------------------------------------------------------
// KPI snapshot
// ---------------------------------------------------------------------------

export const kpiSnapshot: KpiSnapshot = {
  mrr: 248_350,
  mrrDeltaPct: 8.4,
  activeSubscribers: 3_842,
  activeSubscribersDeltaPct: 4.2,
  churnRate: 2.1,
  churnDeltaPct: -0.6,
  conversionRate: 14.7,
  conversionDeltaPct: 1.3,
  mrrSparkline: [212, 218, 215, 224, 228, 231, 226, 234, 238, 235, 242, 239, 245, 248].map((v) => v * 1000),
};

// ---------------------------------------------------------------------------
// Revenue trend — generated per range
// ---------------------------------------------------------------------------

function buildRevenueSeries(points: number, base: number, noise: number, drift: number): RevenuePoint[] {
  const out: RevenuePoint[] = [];
  let mrr = base;
  const today = new Date("2026-07-31T00:00:00Z");
  for (let i = points - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    mrr = Math.max(50_000, mrr + drift + (rng() - 0.5) * noise);
    const newMrr = between(8_000, 16_000);
    const expansionMrr = between(2_000, 6_500);
    const churnedMrr = between(1_500, 4_500);
    out.push({
      date: d.toISOString().slice(0, 10),
      mrr: Math.round(mrr),
      newMrr,
      expansionMrr,
      churnedMrr,
    });
  }
  return out;
}

export const revenueByRange: Record<RangeKey, RevenuePoint[]> = {
  "7d": buildRevenueSeries(7, 240_000, 6_000, 1_200),
  "30d": buildRevenueSeries(30, 218_000, 9_000, 1_050),
  "90d": buildRevenueSeries(90, 192_000, 12_000, 720),
  "1y": buildRevenueSeries(52, 142_000, 18_000, 2_000), // weekly buckets for 1y
};

// ---------------------------------------------------------------------------
// Funnel & plan distribution
// ---------------------------------------------------------------------------

export const funnelStages: FunnelStage[] = [
  { stage: "Visited", count: 48_210, conversionPct: 100 },
  { stage: "Signed up", count: 9_840, conversionPct: 20.4 },
  { stage: "Activated", count: 6_120, conversionPct: 62.2 },
  { stage: "Trial started", count: 4_480, conversionPct: 73.2 },
  { stage: "Paid", count: 3_120, conversionPct: 69.6 },
];

export const planDistribution: PlanDistributionSlice[] = [
  { plan: "free", label: "Free", count: 2_410, mrr: 0, color: "var(--chart-3)" },
  { plan: "starter", label: "Starter", count: 842, mrr: 33_680, color: "var(--chart-2)" },
  { plan: "pro", label: "Pro", count: 421, mrr: 105_250, color: "var(--chart-1)" },
  { plan: "scale", label: "Scale", count: 142, mrr: 85_200, color: "var(--chart-4)" },
  { plan: "enterprise", label: "Enterprise", count: 27, mrr: 24_220, color: "var(--chart-5)" },
];

// ---------------------------------------------------------------------------
// Customers
// ---------------------------------------------------------------------------

const COMPANY_PREFIXES = ["Northwind", "Lumen", "Stratis", "Vertex", "Halcyon", "Brightline", "Cobalt", "Northstar", "Quanta", "Anchor", "Meridian", "Aster", "Pivot", "Forge", "Cedar", "Helio", "Loop", "Mosaic", "Nimbus", "Onyx", "Pinnacle", "Ravel", "Solace", "Tide", "Vantage", "Wren", "Zephyr", "Atlas", "Beacon", "Cinder"] as const;
const COMPANY_SUFFIXES = ["Labs", "AI", "Systems", "Cloud", "Health", "Data", "Biosciences", "Robotics", "Therapeutics", "Industries", "Networks", "Capital", "Studio", "Foundry", "Platform"] as const;
const FIRST_NAMES = ["Avery", "Jordan", "Maya", "Ethan", "Priya", "Noah", "Sana", "Liam", "Iris", "Cole", "Wren", "Theo", "Naomi", "Diego", "Fiona", "Hugo", "Imani", "Kai", "Lena", "Mateo", "Nina", "Oren", "Priya", "Quinn", "Rhea", "Sasha", "Tariq", "Uma", "Viktor", "Yuki"] as const;
const LAST_NAMES = ["Chen", "Patel", "Okafor", "Rivera", "Nguyen", "Andersson", "Becker", "Castellanos", "Devereux", "Ebrahimi", "Foster", "Goldberg", "Hassan", "Ivanov", "Jensen", "Kowalski", "Larsson", "Mehta", "Novak", "Okonkwo", "Park", "Quinteros", "Reyes", "Singh", "Tanaka", "Underwood", "Verma", "Wójcik", "Xu", "Younis"] as const;
const COUNTRIES = ["United States", "Canada", "United Kingdom", "Germany", "France", "Netherlands", "Sweden", "Australia", "Singapore", "Japan", "Brazil", "India", "Spain", "Ireland"] as const;
const INDUSTRIES = ["SaaS", "Fintech", "Healthtech", "E-commerce", "DevTools", "AI / ML", "EdTech", "Climate", "Media", "Logistics", "Cybersecurity"] as const;
const PLANS = ["free", "starter", "pro", "scale", "enterprise"] as const;
const PLAN_WEIGHTS = [40, 25, 20, 10, 5];
const STATUSES = ["active", "trialing", "past_due", "canceled", "churned"] as const;
const STATUS_WEIGHTS = [70, 12, 6, 7, 5];

function weightedPick<T>(arr: readonly T[], weights: number[]): T {
  const total = weights.reduce((a, b) => a + b, 0);
  let r = rng() * total;
  for (let i = 0; i < arr.length; i++) {
    r -= weights[i];
    if (r <= 0) return arr[i];
  }
  return arr[arr.length - 1];
}

const PLAN_MRR: Record<string, number> = { free: 0, starter: 39, pro: 249, scale: 599, enterprise: 8_500 };

// Self-hosted avatars — deterministic SVG data URLs generated locally.
// No external network dependency, no rate limits, works offline.
// The generator lives in `@/lib/avatar.ts`.
import { avatarUrlFor, avatarUrlForVariant } from "./avatar";
export { avatarUrlFor, avatarUrlForVariant };

const LOGO_COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function buildCustomers(n: number): Customer[] {
  const list: Customer[] = [];
  for (let i = 0; i < n; i++) {
    const plan = weightedPick(PLANS, PLAN_WEIGHTS);
    const status = weightedPick(STATUSES, STATUS_WEIGHTS);
    const mrr = PLAN_MRR[plan] * between(1, plan === "enterprise" ? 6 : plan === "scale" ? 4 : 1);
    const signupDays = between(30, 980);
    const lastSeenDays = status === "churned" || status === "canceled" ? between(40, 220) : between(0, 12);
    const signup = new Date("2026-07-31T00:00:00Z");
    signup.setDate(signup.getDate() - signupDays);
    const lastSeen = new Date("2026-07-31T00:00:00Z");
    lastSeen.setDate(lastSeen.getDate() - lastSeenDays);
    const health = status === "past_due" ? "at_risk" : status === "churned" ? "at_risk" : rng() > 0.85 ? "watch" : "healthy";
    const contactName = `${pick(FIRST_NAMES)} ${pick(LAST_NAMES)}`;
    const email = `${contactName.split(" ")[0].toLowerCase()}.${contactName.split(" ")[1].toLowerCase()}@${pick(COMPANY_PREFIXES).toLowerCase()}.${pick(["io", "com", "ai", "co", "app"])}`;
    list.push({
      id: `cus_${(100000 + i).toString(36)}`,
      company: `${pick(COMPANY_PREFIXES)} ${pick(COMPANY_SUFFIXES)}`,
      contactName,
      email,
      avatarUrl: avatarUrlForVariant(email, contactName),
      plan: plan as Customer["plan"],
      status,
      health,
      mrr,
      seats: plan === "free" ? 1 : plan === "enterprise" ? between(50, 500) : between(2, 40),
      country: pick(COUNTRIES),
      signupDate: signup.toISOString(),
      lastSeen: lastSeen.toISOString(),
      industry: pick(INDUSTRIES),
      logoColor: pick(LOGO_COLORS),
    });
  }
  return list;
}

export const customers: Customer[] = buildCustomers(247);

// ---------------------------------------------------------------------------
// Invoices
// ---------------------------------------------------------------------------

export const invoices: Invoice[] = (() => {
  const out: Invoice[] = [];
  const statuses: Invoice["status"][] = ["paid", "paid", "paid", "paid", "open", "void", "uncollectible"];
  for (let i = 0; i < 38; i++) {
    const cust = customers[i % customers.length];
    const issued = new Date("2026-07-31T00:00:00Z");
    issued.setDate(issued.getDate() - between(1, 120));
    const amount = (PLAN_MRR[cust.plan] || 39) * between(1, 4);
    out.push({
      id: `inv_${10000 + i}`,
      number: `INV-${2026}-${String(1000 + i).padStart(4, "0")}`,
      customer: cust.company,
      amount,
      currency: "USD",
      issuedAt: issued.toISOString(),
      status: statuses[Math.floor(rng() * statuses.length)],
      plan: cust.plan,
    });
  }
  return out.sort((a, b) => +new Date(b.issuedAt) - +new Date(a.issuedAt));
})();

// ---------------------------------------------------------------------------
// Plans, usage, payment methods
// ---------------------------------------------------------------------------

export const planCards: PlanCard[] = [
  {
    id: "free",
    name: "Free",
    price: 0,
    cadence: "month",
    tagline: "For exploring the product",
    features: ["1 project", "Up to 1k events / mo", "Community support", "7-day history"],
    accent: "var(--chart-3)",
    icon: "leaf",
    limits: { events: 1_000, seats: 1, apiCalls: 5_000, retention: 0.25, webhooks: 100 },
  },
  {
    id: "starter",
    name: "Starter",
    price: 39,
    cadence: "month",
    tagline: "For small teams shipping",
    features: ["5 projects", "Up to 50k events / mo", "Email support", "90-day history", "3 seats included"],
    accent: "var(--chart-2)",
    icon: "spark",
    limits: { events: 50_000, seats: 3, apiCalls: 100_000, retention: 3, webhooks: 1_000 },
  },
  {
    id: "pro",
    name: "Pro",
    price: 249,
    cadence: "month",
    tagline: "For growing SaaS companies",
    features: ["Unlimited projects", "Up to 1M events / mo", "Priority support", "13-month history", "10 seats included", "Audit log", "SSO (Google)"],
    highlighted: true,
    current: true,
    accent: "var(--chart-1)",
    icon: "rocket",
    limits: { events: 1_000_000, seats: 10, apiCalls: 2_500_000, retention: 13, webhooks: 100_000 },
  },
  {
    id: "scale",
    name: "Scale",
    price: 599,
    cadence: "month",
    tagline: "For scaling infrastructure",
    features: ["Everything in Pro", "Up to 10M events / mo", "Dedicated CSM", "SAML SSO", "25 seats included", "99.95% SLA"],
    accent: "var(--chart-4)",
    icon: "gem",
    limits: { events: 10_000_000, seats: 25, apiCalls: 25_000_000, retention: 24, webhooks: 1_000_000 },
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 8500,
    cadence: "month",
    tagline: "For regulated, large orgs",
    features: ["Unlimited events", "Custom contracts", "24/7 support", "On-prem option", "SOC 2 + HIPAA", "Unlimited seats", "Custom DPA"],
    accent: "var(--chart-5)",
    icon: "crown",
    limits: { events: 1_000_000_000, seats: 1_000, apiCalls: 1_000_000_000, retention: 60, webhooks: 100_000_000 },
  },
];

export const usageMeters: UsageMeter[] = [
  { label: "Events ingested", used: 742_310, limit: 1_000_000, unit: "events", overage: false },
  { label: "Seats", used: 8, limit: 10, unit: "seats", overage: false },
  { label: "API calls", used: 1_840_223, limit: 2_500_000, unit: "calls", overage: false },
  { label: "Data retention", used: 11, limit: 13, unit: "months", overage: false },
  { label: "Webhook deliveries", used: 96_240, limit: 100_000, unit: "deliveries", overage: true },
];

export const upcomingRenewal = {
  date: "2026-08-15",
  amount: 249,
  plan: "Pro" as const,
  cadence: "monthly" as const,
  methodLast4: "4242",
  daysUntil: 15,
};

export const paymentMethods: PaymentMethod[] = [
  { id: "pm_1", brand: "visa", last4: "4242", expMonth: 11, expYear: 2027, isDefault: true },
  { id: "pm_2", brand: "mastercard", last4: "5318", expMonth: 3, expYear: 2026, isDefault: false },
  { id: "pm_3", brand: "amex", last4: "1005", expMonth: 7, expYear: 2028, isDefault: false },
];

// ---------------------------------------------------------------------------
// Team, API keys, notification prefs
// ---------------------------------------------------------------------------

export const teamMembers: TeamMember[] = [
  { id: "tm_1", name: "Avery Chen", email: "avery.chen@northstar.io", role: "owner", lastActive: "2026-07-31T11:20:00Z", avatarColor: "var(--chart-1)", avatarUrl: avatarUrlFor("avery.chen@northstar.io", "Avery Chen") },
  { id: "tm_2", name: "Jordan Patel", email: "jordan.patel@northstar.io", role: "admin", lastActive: "2026-07-30T17:42:00Z", avatarColor: "var(--chart-2)", avatarUrl: avatarUrlFor("jordan.patel@northstar.io", "Jordan Patel") },
  { id: "tm_3", name: "Maya Okafor", email: "maya.okafor@northstar.io", role: "admin", lastActive: "2026-07-29T09:11:00Z", avatarColor: "var(--chart-4)", avatarUrl: avatarUrlFor("maya.okafor@northstar.io", "Maya Okafor") },
  { id: "tm_4", name: "Ethan Rivera", email: "ethan.rivera@northstar.io", role: "member", lastActive: "2026-07-28T14:50:00Z", avatarColor: "var(--chart-3)", avatarUrl: avatarUrlFor("ethan.rivera@northstar.io", "Ethan Rivera") },
  { id: "tm_5", name: "Priya Nguyen", email: "priya.nguyen@northstar.io", role: "member", lastActive: "2026-07-22T08:30:00Z", avatarColor: "var(--chart-5)", avatarUrl: avatarUrlFor("priya.nguyen@northstar.io", "Priya Nguyen") },
  { id: "tm_6", name: "Noah Andersson", email: "noah.andersson@northstar.io", role: "viewer", lastActive: "2026-07-15T16:05:00Z", avatarColor: "var(--chart-2)", avatarUrl: avatarUrlFor("noah.andersson@northstar.io", "Noah Andersson") },
];

// Current user (for topbar avatar + profile form)
export const currentUser = {
  name: "Avery Chen",
  email: "avery.chen@northstar.io",
  avatarUrl: avatarUrlFor("avery.chen@northstar.io", "Avery Chen"),
  initials: "AC",
  role: "Owner" as const,
};

// ---------------------------------------------------------------------------
// Notifications feed
// ---------------------------------------------------------------------------

export const notifications: NotificationItem[] = [
  { id: "n_1", kind: "billing", title: "Payment received", description: "INV-2026-1042 for $249.00 was paid by Northwind Foundry.", timestamp: "2026-07-31T10:42:00Z", read: false, actionable: true },
  { id: "n_2", kind: "alert", title: "Webhook deliveries at 96%", description: "You've used 96,240 of 100,000 monthly deliveries on the Pro plan.", timestamp: "2026-07-31T09:15:00Z", read: false, actionable: true },
  { id: "n_3", kind: "team", title: "New team member", description: "Priya Nguyen accepted your invite and joined as Member.", timestamp: "2026-07-30T17:42:00Z", read: false },
  { id: "n_4", kind: "security", title: "New API key created", description: "A new live key 'Analytics export' was created from 142.93.x.x.", timestamp: "2026-07-30T14:30:00Z", read: true },
  { id: "n_5", kind: "product", title: "v3.4.0 released", description: "Cohort retention chart, CSV exports, and 3 bug fixes.", timestamp: "2026-07-29T08:00:00Z", read: true },
  { id: "n_6", kind: "billing", title: "Upcoming renewal", description: "Your Pro plan renews on Aug 15 for $249.00.", timestamp: "2026-07-28T11:00:00Z", read: true, actionable: true },
  { id: "n_7", kind: "alert", title: "Customer at risk", description: "Helio Robotics hasn't logged in for 12 days. MRR at risk: $34,000/mo.", timestamp: "2026-07-27T16:20:00Z", read: true, actionable: true },
];

// ---------------------------------------------------------------------------
// Command palette actions
// ---------------------------------------------------------------------------

export const commandActions: CommandAction[] = [
  { id: "go-overview", label: "Go to Overview", group: "Navigate", keywords: "home dashboard", icon: "layout" },
  { id: "go-analytics", label: "Go to Analytics", group: "Navigate", keywords: "charts revenue mrr", icon: "chart" },
  { id: "go-customers", label: "Go to Customers", group: "Navigate", keywords: "accounts subscriptions", icon: "users" },
  { id: "go-billing", label: "Go to Billing", group: "Navigate", keywords: "plan invoices payment", icon: "card" },
  { id: "go-settings", label: "Go to Settings", group: "Navigate", keywords: "team api keys profile", icon: "settings" },
  { id: "add-customer", label: "Add customer", group: "Create", keywords: "new account", icon: "plus" },
  { id: "create-key", label: "Create API key", group: "Create", keywords: "token secret", icon: "key" },
  { id: "invite-member", label: "Invite teammate", group: "Create", keywords: "team member", icon: "plus" },
  { id: "export-csv", label: "Export customers CSV", group: "Actions", keywords: "download data", icon: "download" },
  { id: "toggle-theme", label: "Toggle theme", group: "Actions", keywords: "dark light mode", icon: "theme" },
  { id: "open-notifications", label: "Open notifications", group: "Actions", keywords: "alerts bell", icon: "bell" },
];

export const apiKeys: ApiKey[] = [
  { id: "key_1", name: "Production server", prefix: "ns_live_", masked: "ns_live_••••••••••••••••3a9f", createdAt: "2026-01-12T10:00:00Z", lastUsedAt: "2026-07-31T10:42:00Z", scopes: ["read", "write", "billing"] },
  { id: "key_2", name: "Staging CI", prefix: "ns_test_", masked: "ns_test_••••••••••••••••b1c2", createdAt: "2026-03-04T08:00:00Z", lastUsedAt: "2026-07-30T22:11:00Z", scopes: ["read"] },
  { id: "key_3", name: "Analytics export", prefix: "ns_live_", masked: "ns_live_••••••••••••••••77e0", createdAt: "2026-05-22T14:30:00Z", lastUsedAt: null, scopes: ["read"] },
];

export const defaultNotificationPrefs: NotificationPrefs = {
  productUpdates: true,
  securityAlerts: true,
  billingReminders: true,
  weeklyDigest: true,
  marketingEmails: false,
};
