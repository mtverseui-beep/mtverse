// Formatting helpers — pure functions, no React.

export function formatCurrency(value: number, opts: { compact?: boolean; currency?: string } = {}): string {
  const { compact = false, currency = "USD" } = opts;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    notation: compact ? "compact" : "standard",
    maximumFractionDigits: compact ? 1 : 0,
  }).format(value);
}

export function formatNumber(value: number, compact = false): string {
  return new Intl.NumberFormat("en-US", {
    notation: compact ? "compact" : "standard",
    maximumFractionDigits: 1,
  }).format(value);
}

export function formatPercent(value: number, digits = 1): string {
  return `${value > 0 ? "" : ""}${value.toFixed(digits)}%`;
}

export function formatDate(iso: string, opts: Intl.DateTimeFormatOptions = { month: "short", day: "numeric", year: "numeric" }): string {
  return new Intl.DateTimeFormat("en-US", opts).format(new Date(iso));
}

/**
 * Fixed "now" reference for relative-time formatting.
 *
 * Why: `formatRelativeTime` would otherwise call `new Date()` on every render,
 * producing different text on the server vs the client during hydration. That
 * triggers React's hydration-mismatch warning. By using a single pinned
 * timestamp (captured at module load), both server and client render the same
 * string for the same input ISO. The drift between module-load on the server
 * and module-load on the client is well under a second, which never crosses a
 * minute boundary in practice.
 *
 * The pinned timestamp is also re-used for any subsequent client-side re-renders
 * so the relative times stay stable during a session (no flicker).
 */
const PINNED_NOW = new Date("2026-07-31T12:00:00Z");

export function formatRelativeTime(iso: string, now: Date = PINNED_NOW): string {
  const then = new Date(iso).getTime();
  const diff = now.getTime() - then;
  const sec = Math.round(diff / 1000);
  const min = Math.round(sec / 60);
  const hr = Math.round(min / 60);
  const day = Math.round(hr / 24);
  if (sec < 60) return "just now";
  if (min < 60) return `${min}m ago`;
  if (hr < 24) return `${hr}h ago`;
  if (day < 30) return `${day}d ago`;
  return formatDate(iso, { month: "short", day: "numeric" });
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}
