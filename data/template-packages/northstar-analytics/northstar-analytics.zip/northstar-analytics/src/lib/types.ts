// Domain types for the SaaS analytics dashboard.
// Kept fully isolated from UI so the same shapes can be returned by a real API later.

export type Plan = "free" | "starter" | "pro" | "scale" | "enterprise";
export type CustomerStatus = "active" | "trialing" | "past_due" | "canceled" | "churned";
export type CustomerHealth = "healthy" | "watch" | "at_risk";
export type InvoiceStatus = "paid" | "open" | "void" | "uncollectible";
export type Role = "owner" | "admin" | "member" | "viewer";
export type RangeKey = "7d" | "30d" | "90d" | "1y";

export interface KpiSnapshot {
  mrr: number; // monthly recurring revenue, USD
  mrrDeltaPct: number; // WoW
  activeSubscribers: number;
  activeSubscribersDeltaPct: number;
  churnRate: number; // percentage, e.g. 2.4
  churnDeltaPct: number; // negative is good
  conversionRate: number; // trial→paid, percentage
  conversionDeltaPct: number;
  mrrSparkline: number[]; // last 14 points
}

export interface RevenuePoint {
  date: string; // ISO date
  mrr: number;
  newMrr: number;
  expansionMrr: number;
  churnedMrr: number;
}

export interface FunnelStage {
  stage: string;
  count: number;
  conversionPct: number;
}

export interface PlanDistributionSlice {
  plan: Plan;
  label: string;
  count: number;
  mrr: number;
  color: string; // css color
}

export interface Customer {
  id: string;
  company: string;
  contactName: string;
  email: string;
  avatarUrl: string;
  plan: Plan;
  status: CustomerStatus;
  health: CustomerHealth;
  mrr: number;
  seats: number;
  country: string;
  signupDate: string; // ISO
  lastSeen: string; // ISO
  industry: string;
  logoColor: string;
}

export interface Invoice {
  id: string;
  number: string;
  customer: string;
  amount: number;
  currency: string;
  issuedAt: string; // ISO
  status: InvoiceStatus;
  plan: Plan;
}

export interface PaymentMethod {
  id: string;
  brand: "visa" | "mastercard" | "amex" | "discover" | "unknown";
  last4: string;
  expMonth: number;
  expYear: number;
  isDefault: boolean;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: Role;
  lastActive: string; // ISO
  avatarColor: string;
  avatarUrl: string;
}

export interface ApiKey {
  id: string;
  name: string;
  prefix: string;
  masked: string;
  createdAt: string; // ISO
  lastUsedAt: string | null;
  scopes: string[];
}

export interface NotificationPrefs {
  productUpdates: boolean;
  securityAlerts: boolean;
  billingReminders: boolean;
  weeklyDigest: boolean;
  marketingEmails: boolean;
}

export interface UsageMeter {
  label: string;
  used: number;
  limit: number;
  unit: string;
  overage: boolean;
}

export interface PlanCard {
  id: Plan;
  name: string;
  price: number;
  cadence: "month" | "year";
  tagline: string;
  features: string[];
  highlighted?: boolean;
  current?: boolean;
  accent: string; // gradient stop
  icon: "spark" | "rocket" | "crown" | "gem" | "leaf";
  limits: {
    events: number;
    seats: number;
    apiCalls: number;
    retention: number; // months
    webhooks: number;
  };
}

export type NotificationKind = "billing" | "security" | "product" | "team" | "alert";

export interface NotificationItem {
  id: string;
  kind: NotificationKind;
  title: string;
  description: string;
  timestamp: string; // ISO
  read: boolean;
  actionable?: boolean;
}

export interface CommandAction {
  id: string;
  label: string;
  hint?: string;
  group: "Navigate" | "Create" | "Actions" | "Recent";
  keywords: string;
  icon: "layout" | "chart" | "users" | "card" | "settings" | "plus" | "key" | "download" | "theme" | "bell";
}
