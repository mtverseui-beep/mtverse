"use client";

import { AlertCircle, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCountUp } from "@/hooks/use-dashboard";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

// Skeleton block — uses shimmer sweep instead of plain pulse.
export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={cn("shimmer rounded-md bg-muted/60", className)} aria-hidden />;
}

// Generic state wrappers -------------------------------------------------------

export function LoadingState({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3" aria-busy="true" aria-live="polite">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-16 w-full" />
      ))}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div
      role="alert"
      className="flex flex-col items-center justify-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 p-8 text-center"
    >
      <AlertCircle className="h-8 w-8 text-destructive" aria-hidden />
      <p className="text-sm text-foreground/80 max-w-sm">{message}</p>
      <Button size="sm" variant="outline" onClick={onRetry} className="gap-2">
        <RotateCw className="h-3.5 w-3.5" /> Retry
      </Button>
    </div>
  );
}

export function EmptyState({ title, description, icon, action }: { title: string; description?: string; icon?: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border p-10 text-center">
      {icon && <div className="text-muted-foreground">{icon}</div>}
      <p className="text-sm font-medium text-foreground">{title}</p>
      {description && <p className="text-xs text-muted-foreground max-w-sm">{description}</p>}
      {action}
    </div>
  );
}

// Trend pill — small up/down delta with directional color
export function TrendPill({ value, suffix = "%", invertColor = false }: { value: number; suffix?: string; invertColor?: boolean }) {
  const positive = value >= 0;
  const good = invertColor ? !positive : positive;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        good ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive",
      )}
      aria-label={`${positive ? "up" : "down"} ${Math.abs(value).toFixed(1)}${suffix}`}
    >
      <span aria-hidden>{positive ? "▲" : "▼"}</span>
      {Math.abs(value).toFixed(1)}
      {suffix}
    </span>
  );
}

// ---- Animated number — counts up from 0 with eased timing -------------------

export function AnimatedNumber({
  value,
  format,
  className,
}: {
  value: number;
  format: (n: number) => string;
  className?: string;
}) {
  const animated = useCountUp(value);
  return <span className={cn("tabular-nums", className)}>{format(animated)}</span>;
}

// ---- Modern card — surface + hover lift + accent line -----------------------

export function ModernCard({
  children,
  className,
  hover = true,
  accent = false,
  as = "div",
}: {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  accent?: boolean;
  as?: "div" | "li" | "button";
}) {
  const Tag = as;
  return (
    <Tag
      className={cn(
        "surface-card rounded-lg",
        hover && "surface-card-hover cursor-pointer",
        accent && "accent-line",
        className,
      )}
    >
      {children}
    </Tag>
  );
}

// ---- Page transition — fade-up wrapper for view changes ---------------------

export function PageTransition({ children, viewId }: { children: React.ReactNode; viewId: string }) {
  return (
    <motion.div
      key={viewId}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.22, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

// ---- Staggered list item entrance ------------------------------------------

export function StaggerItem({ children, index, className }: { children: React.ReactNode; index: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.28, ease: "easeOut", delay: Math.min(index * 0.04, 0.32) }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
