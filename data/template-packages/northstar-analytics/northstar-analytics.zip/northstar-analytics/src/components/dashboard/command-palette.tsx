"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  BarChart3,
  Bell,
  CreditCard,
  Download,
  KeyRound,
  LayoutDashboard,
  Moon,
  Plus,
  Search,
  Settings as SettingsIcon,
  Users,
  type LucideIcon,
} from "lucide-react";
import { commandActions } from "@/lib/mock-data";
import type { CommandAction } from "@/lib/types";
import { useUI } from "@/hooks/use-dashboard";
import { cn } from "@/lib/utils";

const ICONS: Record<CommandAction["icon"], LucideIcon> = {
  layout: LayoutDashboard,
  chart: BarChart3,
  users: Users,
  card: CreditCard,
  settings: SettingsIcon,
  plus: Plus,
  key: KeyRound,
  download: Download,
  theme: Moon,
  bell: Bell,
};

export function CommandPalette() {
  const { commandOpen, setCommandOpen } = useUI();
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // Reset query + focus input when palette opens.
  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    if (commandOpen) {
      setQuery("");
      setActiveIndex(0);
      // micro-delay so input is mounted
      const id = window.setTimeout(() => inputRef.current?.focus(), 30);
      return () => window.clearTimeout(id);
    }
  }, [commandOpen]);
  /* eslint-enable react-hooks/set-state-in-effect */

  const filtered = useMemo(() => {
    if (!query.trim()) return commandActions;
    const q = query.toLowerCase();
    return commandActions.filter(
      (a) => a.label.toLowerCase().includes(q) || a.keywords.toLowerCase().includes(q) || a.group.toLowerCase().includes(q),
    );
  }, [query]);

  // Group actions while preserving order
  const grouped = useMemo(() => {
    const map = new Map<string, CommandAction[]>();
    filtered.forEach((a) => {
      const arr = map.get(a.group) ?? [];
      arr.push(a);
      map.set(a.group, arr);
    });
    return Array.from(map.entries());
  }, [filtered]);

  function runAction(action: CommandAction) {
    setCommandOpen(false);
    switch (action.id) {
      case "go-overview": router.push("/"); break;
      case "go-analytics": router.push("/analytics"); break;
      case "go-customers": router.push("/customers"); break;
      case "go-billing": router.push("/billing"); break;
      case "go-settings": router.push("/settings"); break;
      case "add-customer": router.push("/customers"); break;
      case "create-key": router.push("/settings/api-keys"); break;
      case "invite-member": router.push("/settings/team"); break;
      case "export-csv": router.push("/customers"); break;
      case "toggle-theme":
        document.documentElement.classList.toggle("dark");
        try {
          const isDark = document.documentElement.classList.contains("dark");
          window.localStorage.setItem("ns.theme", isDark ? "dark" : "light");
          window.dispatchEvent(new CustomEvent("ns:theme-change"));
        } catch { /* ignore */ }
        break;
      case "open-notifications":
        // Handled via custom event so NotificationsPanel can pick it up.
        window.dispatchEvent(new CustomEvent("ns:open-notifications"));
        break;
    }
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, filtered.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const action = filtered[activeIndex];
      if (action) runAction(action);
    }
  }

  // Scroll active item into view
  useEffect(() => {
    const el = listRef.current?.querySelector(`[data-idx="${activeIndex}"]`) as HTMLElement | null;
    el?.scrollIntoView({ block: "nearest" });
  }, [activeIndex]);

  // Flatten grouped actions back to a single indexed list for keyboard nav
  let flatIndex = -1;

  return (
    <AnimatePresence>
      {commandOpen && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-start justify-center pt-[12vh] px-4"
          role="dialog"
          aria-modal="true"
          aria-label="Command palette"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
        >
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setCommandOpen(false)}
            aria-hidden
          />
          <motion.div
            className="relative w-full max-w-xl surface-popover rounded-xl overflow-hidden"
            initial={{ opacity: 0, scale: 0.97, y: -8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: -8 }}
            transition={{ duration: 0.18, ease: "easeOut" }}
          >
            {/* Search input */}
            <div className="flex items-center gap-3 border-b border-border px-4">
              <Search className="h-4 w-4 text-muted-foreground shrink-0" aria-hidden />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => { setQuery(e.target.value); setActiveIndex(0); }}
                onKeyDown={onKeyDown}
                placeholder="Type a command or search…"
                aria-label="Command search"
                className="h-12 flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
              />
              <kbd className="hidden sm:inline-flex h-5 items-center rounded border border-border bg-muted px-1.5 text-[10px] font-medium text-muted-foreground">ESC</kbd>
            </div>

            {/* Results */}
            <div ref={listRef} className="max-h-[55vh] overflow-y-auto p-2">
              {filtered.length === 0 && (
                <div className="px-3 py-8 text-center text-sm text-muted-foreground">
                  No commands match &ldquo;{query}&rdquo;
                </div>
              )}
              {grouped.map(([group, actions]) => (
                <div key={group} className="mb-1.5 last:mb-0">
                  <p className="px-2.5 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{group}</p>
                  <ul role="listbox" aria-label={group}>
                    {actions.map((action) => {
                      flatIndex += 1;
                      const idx = flatIndex;
                      const Icon = ICONS[action.icon];
                      const active = idx === activeIndex;
                      return (
                        <li key={action.id} role="option" aria-selected={active} data-idx={idx}>
                          <button
                            type="button"
                            onMouseEnter={() => setActiveIndex(idx)}
                            onClick={() => runAction(action)}
                            className={cn(
                              "flex w-full items-center gap-3 rounded-md px-2.5 py-2 text-left text-sm transition-colors",
                              active ? "bg-primary/10 text-foreground" : "text-foreground/90 hover:bg-muted/60",
                            )}
                          >
                            <span className={cn("grid h-7 w-7 place-items-center rounded-md", active ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground")}>
                              <Icon className="h-3.5 w-3.5" />
                            </span>
                            <span className="flex-1 min-w-0">
                              <span className="block truncate">{action.label}</span>
                              {action.hint && <span className="block text-xs text-muted-foreground truncate">{action.hint}</span>}
                            </span>
                            {active && (
                              <kbd className="hidden sm:inline-flex h-5 items-center rounded border border-border bg-muted px-1.5 text-[10px] text-muted-foreground">↵</kbd>
                            )}
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between border-t border-border px-4 py-2 text-[11px] text-muted-foreground">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1"><kbd className="inline-flex h-4 items-center rounded border border-border bg-muted px-1 text-[10px]">↑</kbd><kbd className="inline-flex h-4 items-center rounded border border-border bg-muted px-1 text-[10px]">↓</kbd> navigate</span>
                <span className="flex items-center gap-1"><kbd className="inline-flex h-4 items-center rounded border border-border bg-muted px-1 text-[10px]">↵</kbd> select</span>
              </div>
              <span className="hidden sm:inline">Northstar Command</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
