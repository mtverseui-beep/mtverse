"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Check,
  ChevronRight,
  Crown,
  Download,
  Gem,
  Leaf,
  Loader2,
  Plus,
  Receipt,
  Rocket,
  ShieldCheck,
  Sparkles,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { invoices, paymentMethods, planCards, upcomingRenewal, usageMeters as seedMeters } from "@/lib/mock-data";
import { useSimulatedFetch } from "@/hooks/use-dashboard";
import { formatCurrency, formatDate, formatNumber } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton, ErrorState, EmptyState, StaggerItem } from "./primitives";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import type { InvoiceStatus, PaymentMethod, Plan, PlanCard, UsageMeter } from "@/lib/types";
import { CardBrandIcon, CARD_BRANDS, detectBrand, type CardBrand } from "./card-icons";

const INVOICE_STATUS_META: Record<InvoiceStatus, { label: string; className: string }> = {
  paid: { label: "Paid", className: "bg-success/15 text-success border-success/20" },
  open: { label: "Open", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  void: { label: "Void", className: "bg-muted text-muted-foreground border-border" },
  uncollectible: { label: "Failed", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

const PLAN_ICONS: Record<PlanCard["icon"], LucideIcon> = {
  leaf: Leaf,
  spark: Sparkles,
  rocket: Rocket,
  gem: Gem,
  crown: Crown,
};

function UsageMeterRow({ meter }: { meter: UsageMeter }) {
  const pct = Math.min(100, Math.round((meter.used / meter.limit) * 100));
  const tone = meter.overage ? "destructive" : pct >= 85 ? "warning" : "primary";
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <span className="text-sm text-foreground">{meter.label}</span>
        <span className="text-xs tabular-nums text-muted-foreground">
          {formatNumber(meter.used, true)} / {formatNumber(meter.limit, true)} {meter.unit}
        </span>
      </div>
      <div className="mt-1.5 flex items-center gap-2">
        <Progress
          value={pct}
          className={cn(
            "h-1.5",
            tone === "destructive" && "[&>[role=progressbar]]:bg-destructive",
            tone === "warning" && "[&>[role=progressbar]]:bg-warning",
          )}
        />
        <span
          className={cn(
            "text-[10px] tabular-nums w-9 text-right",
            tone === "destructive" ? "text-destructive" : tone === "warning" ? "text-warning" : "text-muted-foreground",
          )}
        >
          {pct}%
        </span>
      </div>
      {meter.overage && (
        <p className="mt-1 text-[11px] text-destructive">
          You&apos;ve exceeded your plan limit. Overage will be billed at $0.20/{meter.unit}.
        </p>
      )}
    </div>
  );
}

function PlanCardItem({
  plan,
  currentPlanId,
  onUpgrade,
}: {
  plan: PlanCard;
  currentPlanId: Plan;
  onUpgrade: (plan: PlanCard) => void;
}) {
  const Icon = PLAN_ICONS[plan.icon];
  const isCurrent = plan.id === currentPlanId;
  const isDowngrade = plan.price < (planCards.find((p) => p.id === currentPlanId)?.price ?? 0);

  return (
    <StaggerItem index={0}>
      <div
        className={cn(
          "relative flex flex-col rounded-lg border p-5 transition-all",
          isCurrent
            ? "border-primary bg-primary/5 shadow-lg shadow-primary/10"
            : plan.highlighted
              ? "border-primary/40 bg-card hover:border-primary/60 hover:-translate-y-0.5"
              : "border-border bg-card hover:border-foreground/20 hover:-translate-y-0.5 cursor-pointer",
        )}
        style={isCurrent ? undefined : {}}
      >
        {/* Plan icon badge */}
        <div className="flex items-start justify-between">
          <span
            className="grid h-10 w-10 place-items-center rounded-lg"
            style={{ background: `${plan.accent}20`, color: plan.accent }}
          >
            <Icon className="h-5 w-5" />
          </span>
          {isCurrent && (
            <Badge className="text-[10px]">Current plan</Badge>
          )}
          {!isCurrent && plan.highlighted && (
            <Badge variant="secondary" className="text-[10px]">Recommended</Badge>
          )}
        </div>

        <h3 className="mt-3 text-sm font-semibold text-foreground">{plan.name}</h3>
        <p className="text-xs text-muted-foreground">{plan.tagline}</p>

        <div className="mt-3 flex items-baseline gap-1">
          <span className="text-2xl font-semibold tabular-nums text-foreground">
            {plan.price === 0 ? "Free" : formatCurrency(plan.price)}
          </span>
          {plan.price > 0 && <span className="text-xs text-muted-foreground">/{plan.cadence === "year" ? "yr" : "mo"}</span>}
        </div>

        <ul className="mt-4 flex-1 space-y-2">
          {plan.features.map((f) => (
            <li key={f} className="flex items-start gap-2 text-xs text-foreground/80">
              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
              <span>{f}</span>
            </li>
          ))}
        </ul>

        <Button
          className="mt-4"
          variant={isCurrent ? "outline" : plan.highlighted ? "default" : "outline"}
          size="sm"
          disabled={isCurrent}
          onClick={() => !isCurrent && onUpgrade(plan)}
        >
          {isCurrent ? "Current plan" : isDowngrade ? "Downgrade" : `Upgrade to ${plan.name}`}
        </Button>
      </div>
    </StaggerItem>
  );
}

// ---- Plan upgrade dialog with proration calc + working state change ----------

function UpgradePlanDialog({
  target,
  current,
  open,
  onClose,
  onConfirm,
}: {
  target: PlanCard | null;
  current: PlanCard;
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
}) {
  const [phase, setPhase] = useState<"review" | "processing" | "success">("review");

  // Reset phase when target changes
  const targetId = target?.id;
  const [lastTargetId, setLastTargetId] = useState<string | null>(null);
  if (targetId && targetId !== lastTargetId) {
    setLastTargetId(targetId);
    if (phase !== "review") setPhase("review");
  }

  // Prorated charge: price difference * (days remaining in cycle / 30)
  const daysRemaining = upcomingRenewal.daysUntil;
  const priceDiff = target ? Math.max(0, target.price - current.price) : 0;
  const proration = Math.round((priceDiff * (daysRemaining / 30)) * 100) / 100;

  // Feature diff
  const addedFeatures = target ? target.features.filter((f) => !current.features.includes(f)) : [];
  const removedFeatures = target ? current.features.filter((f) => !target.features.includes(f)) : [];

  function confirm() {
    setPhase("processing");
    // Simulate API call: 1.1s processing → 1.2s success → onConfirm
    const t1 = window.setTimeout(() => setPhase("success"), 1100);
    const t2 = window.setTimeout(() => {
      onConfirm();
      setPhase("review");
    }, 1100 + 1200);
    void t1; void t2;
  }

  if (!target) return null;
  const TargetIcon = PLAN_ICONS[target.icon];

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <AnimatePresence mode="wait">
          {phase === "review" && (
            <motion.div
              key="review"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
            >
              <DialogHeader>
                <div className="flex items-center gap-3">
                  <span
                    className="grid h-10 w-10 place-items-center rounded-lg"
                    style={{ background: `${target.accent}20`, color: target.accent }}
                  >
                    <TargetIcon className="h-5 w-5" />
                  </span>
                  <div>
                    <DialogTitle>Upgrade to {target.name}</DialogTitle>
                    <DialogDescription>Review the changes before confirming</DialogDescription>
                  </div>
                </div>
              </DialogHeader>

              {/* Plan comparison */}
              <div className="mt-4 rounded-md border border-border overflow-hidden">
                <div className="grid grid-cols-2 gap-px bg-border">
                  <div className="bg-card p-3">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Current</p>
                    <p className="text-sm font-medium text-foreground">{current.name}</p>
                    <p className="text-xs text-muted-foreground">{formatCurrency(current.price)}/mo</p>
                  </div>
                  <div className="bg-card p-3">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">New</p>
                    <p className="text-sm font-medium text-foreground">{target.name}</p>
                    <p className="text-xs text-muted-foreground">{formatCurrency(target.price)}/mo</p>
                  </div>
                </div>
              </div>

              {/* Feature changes */}
              {addedFeatures.length > 0 && (
                <div className="mt-3">
                  <p className="text-xs font-medium text-foreground mb-1.5">What you&apos;ll gain</p>
                  <ul className="space-y-1">
                    {addedFeatures.map((f) => (
                      <li key={f} className="flex items-start gap-2 text-xs text-foreground/80">
                        <Check className="mt-0.5 h-3 w-3 shrink-0 text-success" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {removedFeatures.length > 0 && (
                <div className="mt-3">
                  <p className="text-xs font-medium text-foreground mb-1.5">What you&apos;ll lose</p>
                  <ul className="space-y-1">
                    {removedFeatures.map((f) => (
                      <li key={f} className="flex items-start gap-2 text-xs text-muted-foreground line-through">
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Proration */}
              <div className="mt-4 rounded-md bg-muted/60 p-3 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Plan price difference</span>
                  <span className="tabular-nums text-foreground">+{formatCurrency(priceDiff)}/mo</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Proration ({daysRemaining} days remaining)</span>
                  <span className="tabular-nums text-foreground">{formatCurrency(proration)}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">New monthly rate (starts {formatDate(upcomingRenewal.date, { month: "short", day: "numeric" })})</span>
                  <span className="tabular-nums text-foreground">{formatCurrency(target.price)}/mo</span>
                </div>
                <div className="border-t border-border pt-1.5 mt-1.5 flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">Charged today</span>
                  <span className="text-sm font-semibold tabular-nums text-foreground">{formatCurrency(proration)}</span>
                </div>
              </div>

              <DialogFooter className="mt-4">
                <Button variant="outline" onClick={onClose}>Cancel</Button>
                <Button onClick={confirm} className="gap-1.5">
                  Confirm upgrade <ChevronRight className="h-3.5 w-3.5" />
                </Button>
              </DialogFooter>
            </motion.div>
          )}

          {phase === "processing" && (
            <motion.div
              key="processing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="py-12 flex flex-col items-center gap-3"
            >
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
              <DialogTitle className="text-base">Processing upgrade…</DialogTitle>
              <DialogDescription>Charging your card and applying the new plan</DialogDescription>
            </motion.div>
          )}

          {phase === "success" && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="py-12 flex flex-col items-center gap-3"
            >
              <motion.span
                className="grid h-14 w-14 place-items-center rounded-full bg-success/15 text-success"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", damping: 12, stiffness: 200, delay: 0.1 }}
              >
                <Check className="h-7 w-7" />
              </motion.span>
              <DialogTitle className="text-base">Welcome to {target.name}!</DialogTitle>
              <DialogDescription>
                Your plan is now active. Usage limits have been updated.
              </DialogDescription>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}

function AddPaymentDialog({ open, onClose, onAdd }: { open: boolean; onClose: () => void; onAdd: (m: PaymentMethod) => void }) {
  const [card, setCard] = useState("");
  const [exp, setExp] = useState("");
  const [cvc, setCvc] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Detect brand as user types — drives the live preview icon.
  const detectedBrand: CardBrand = card ? detectBrand(card) : "unknown";

  function validate() {
    const e: Record<string, string> = {};
    const digits = card.replace(/\s+/g, "");
    if (!/^\d{15,16}$/.test(digits)) e.card = "Enter a valid 15–16 digit card number.";
    if (!/^\d{2}\/\d{2}$/.test(exp)) e.exp = "Use MM/YY format.";
    if (!/^\d{3,4}$/.test(cvc)) e.cvc = "3–4 digits.";
    const [mm, yy] = exp.split("/");
    if (mm && (Number(mm) < 1 || Number(mm) > 12)) e.exp = "Invalid month.";
    if (yy && Number(yy) < 26) e.exp = "Card is expired.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function submit() {
    if (!validate()) return;
    const digits = card.replace(/\s+/g, "");
    const [mm, yy] = exp.split("/");
    const newMethod: PaymentMethod = {
      id: `pm_${Date.now()}`,
      brand: detectedBrand,
      last4: digits.slice(-4),
      expMonth: Number(mm),
      expYear: 2000 + Number(yy),
      isDefault: false,
    };
    onAdd(newMethod);
    toast.success(`${CARD_BRANDS[detectedBrand]?.label ?? "Card"} added`);
    onClose();
    setCard(""); setExp(""); setCvc(""); setErrors({});
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add payment method</DialogTitle>
          <DialogDescription>Card details are tokenized via Stripe and never touch our servers.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <label htmlFor="card-num" className="text-xs font-medium text-foreground">Card number</label>
            <div className="relative mt-1">
              <input
                id="card-num"
                inputMode="numeric"
                autoComplete="cc-number"
                value={card}
                onChange={(e) => setCard(e.target.value.replace(/[^\d]/g, "").replace(/(.{4})/g, "$1 ").trim())}
                placeholder="4242 4242 4242 4242"
                className={cn(
                  "h-9 w-full rounded-md border bg-background pl-3 pr-16 text-sm tabular-nums cursor-text",
                  errors.card ? "border-destructive" : "border-input",
                  "focus:outline-none focus:ring-1 focus:ring-ring/40 focus:border-ring/60",
                )}
              />
              {/* Live brand preview */}
              {card && (
                <div className="absolute right-1.5 top-1/2 -translate-y-1/2">
                  <CardBrandIcon
                    brand={detectedBrand}
                    className="h-6 w-10 rounded ring-1 ring-border"
                  />
                </div>
              )}
            </div>
            {errors.card && <p className="mt-1 text-xs text-destructive">{errors.card}</p>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="card-exp" className="text-xs font-medium text-foreground">Expiry</label>
              <input
                id="card-exp"
                inputMode="numeric"
                autoComplete="cc-exp"
                value={exp}
                onChange={(e) => {
                  let v = e.target.value.replace(/[^\d]/g, "");
                  if (v.length > 2) v = v.slice(0, 2) + "/" + v.slice(0, 2);
                  setExp(v);
                }}
                placeholder="MM/YY"
                maxLength={5}
                className={cn(
                  "mt-1 h-9 w-full rounded-md border bg-background px-3 text-sm tabular-nums cursor-text",
                  errors.exp ? "border-destructive" : "border-input",
                  "focus:outline-none focus:ring-1 focus:ring-ring/40 focus:border-ring/60",
                )}
              />
              {errors.exp && <p className="mt-1 text-xs text-destructive">{errors.exp}</p>}
            </div>
            <div>
              <label htmlFor="card-cvc" className="text-xs font-medium text-foreground">CVC</label>
              <input
                id="card-cvc"
                inputMode="numeric"
                autoComplete="cc-csc"
                value={cvc}
                onChange={(e) => setCvc(e.target.value.replace(/[^\d]/g, "").slice(0, 4))}
                placeholder="123"
                className={cn(
                  "mt-1 h-9 w-full rounded-md border bg-background px-3 text-sm tabular-nums cursor-text",
                  errors.cvc ? "border-destructive" : "border-input",
                  "focus:outline-none focus:ring-1 focus:ring-ring/40 focus:border-ring/60",
                )}
              />
              {errors.cvc && <p className="mt-1 text-xs text-destructive">{errors.cvc}</p>}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="cursor-pointer">Cancel</Button>
          <Button onClick={submit} className="cursor-pointer">Add card</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PaymentMethods() {
  const [methods, setMethods] = useState(paymentMethods);
  const [adding, setAdding] = useState(false);
  const [removing, setRemoving] = useState<string | null>(null);

  return (
    <div className="rounded-lg surface-card">
      <div className="flex items-center justify-between border-b border-border p-4">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Payment methods</h3>
          <p className="text-xs text-muted-foreground">Cards used for subscription renewals</p>
        </div>
        <Button size="sm" className="gap-1.5 cursor-pointer" onClick={() => setAdding(true)}>
          <Plus className="h-3.5 w-3.5" /> Add card
        </Button>
      </div>
      <ul className="divide-y divide-border">
        {methods.map((m) => (
          <li key={m.id} className="flex items-center gap-3 p-4 hover:bg-muted/40 transition-colors">
            <CardBrandIcon
              brand={m.brand as CardBrand}
              className="h-7 w-12 rounded-md shrink-0 ring-1 ring-border"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">
                {CARD_BRANDS[m.brand as CardBrand]?.label ?? "Card"} •••• {m.last4}
                {m.isDefault && <Badge variant="secondary" className="ml-2 text-[10px]">Default</Badge>}
              </p>
              <p className="text-xs text-muted-foreground">Expires {String(m.expMonth).padStart(2, "0")}/{String(m.expYear).slice(-2)}</p>
            </div>
            <div className="flex items-center gap-1">
              {!m.isDefault && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs cursor-pointer"
                  onClick={() => {
                    setMethods((prev) => prev.map((p) => ({ ...p, isDefault: p.id === m.id })));
                    toast.success("Default payment method updated");
                  }}
                >
                  Set default
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-destructive hover:text-destructive cursor-pointer"
                onClick={() => setRemoving(m.id)}
              >
                Remove
              </Button>
            </div>
          </li>
        ))}
      </ul>

      <AddPaymentDialog
        open={adding}
        onClose={() => setAdding(false)}
        onAdd={(m) => setMethods((prev) => [...prev, m])}
      />

      <Dialog open={removing !== null} onOpenChange={(o) => !o && setRemoving(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Remove payment method?</DialogTitle>
            <DialogDescription>
              You won&apos;t be able to use this card for future renewals. Any active subscription will move to your other card on file.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRemoving(null)}>Keep</Button>
            <Button
              variant="destructive"
              onClick={() => {
                setMethods((prev) => prev.filter((p) => p.id !== removing));
                toast.success("Payment method removed");
                setRemoving(null);
              }}
            >
              Remove card
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function InvoicesList() {
  const { status, data, error, retry } = useSimulatedFetch(() => invoices, { delay: 500 });
  return (
    <div className="rounded-lg surface-card">
      <div className="flex items-center justify-between border-b border-border p-4">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Invoice history</h3>
          <p className="text-xs text-muted-foreground">Download any past invoice as PDF</p>
        </div>
      </div>
      {status === "loading" && <div className="p-4 space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>}
      {status === "error" && <div className="p-4"><ErrorState message={error ?? "Failed to load invoices"} onRetry={retry} /></div>}
      {status === "success" && data && data.length === 0 && (
        <div className="p-4"><EmptyState title="No invoices yet" description="Invoices will appear here after your first renewal." icon={<Receipt className="h-8 w-8" />} /></div>
      )}
      {status === "success" && data && data.length > 0 && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 border-b border-border">
              <tr>
                <th scope="col" className="px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Invoice</th>
                <th scope="col" className="hidden md:table-cell px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Customer</th>
                <th scope="col" className="px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Issued</th>
                <th scope="col" className="px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Status</th>
                <th scope="col" className="px-4 py-2.5 text-right text-xs font-medium uppercase tracking-wider text-muted-foreground">Amount</th>
                <th scope="col" className="w-10 px-4 py-2.5"><span className="sr-only">Download</span></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {data.slice(0, 12).map((inv) => (
                <tr key={inv.id} className="hover:bg-muted/40 transition-colors cursor-pointer">
                  <td className="px-4 py-3 font-mono text-xs text-foreground">{inv.number}</td>
                  <td className="hidden md:table-cell px-4 py-3 text-muted-foreground truncate max-w-[200px]">{inv.customer}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{formatDate(inv.issuedAt)}</td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={cn("border text-[10px]", INVOICE_STATUS_META[inv.status].className)}>
                      {INVOICE_STATUS_META[inv.status].label}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums text-foreground font-medium">{formatCurrency(inv.amount)}</td>
                  <td className="px-4 py-3 text-right">
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground cursor-pointer" aria-label={`Download ${inv.number}`} onClick={() => toast.success(`Downloading ${inv.number}.pdf`)}>
                      <Download className="h-3.5 w-3.5" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function BillingPage() {
  // The working plan state — starts on Pro, can be upgraded/downgraded
  const [currentPlanId, setCurrentPlanId] = useState<Plan>("pro");
  const [upgradeTarget, setUpgradeTarget] = useState<PlanCard | null>(null);
  const [payNowOpen, setPayNowOpen] = useState(false);
  const [remindMeOpen, setRemindMeOpen] = useState(false);

  const currentPlan = useMemo(
    () => planCards.find((p) => p.id === currentPlanId) ?? planCards[2],
    [currentPlanId],
  );

  // Recompute usage meters based on current plan
  const meters = useMemo<UsageMeter[]>(() => {
    return seedMeters.map((m) => {
      const map: Record<string, keyof PlanCard["limits"]> = {
        "Events ingested": "events",
        "Seats": "seats",
        "API calls": "apiCalls",
        "Data retention": "retention",
        "Webhook deliveries": "webhooks",
      };
      const limitKey = map[m.label];
      if (!limitKey) return m;
      const newLimit = currentPlan.limits[limitKey];
      return { ...m, limit: newLimit, overage: m.used > newLimit };
    });
  }, [currentPlan]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Billing & subscriptions</h2>
          <p className="text-sm text-muted-foreground">Manage your plan, monitor usage, and download invoices.</p>
        </div>
        <Badge variant="outline" className="gap-1.5 border-primary/30 bg-primary/5 text-primary">
          <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
          {currentPlan.name} plan active
        </Badge>
      </div>

      {/* Upcoming renewal banner */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.32 }}
        className="relative overflow-hidden rounded-lg border border-primary/30 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-5 flex flex-wrap items-center justify-between gap-4"
      >
        <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full bg-primary/10 blur-3xl pointer-events-none" aria-hidden />
        <div className="flex items-center gap-3 relative">
          <span className="grid h-10 w-10 place-items-center rounded-md bg-primary/15 text-primary">
            <Zap className="h-5 w-5" />
          </span>
          <div>
            <p className="text-sm font-medium text-foreground">Upcoming renewal</p>
            <p className="text-xs text-muted-foreground">
              {formatCurrency(currentPlan.price)} for the {currentPlan.name} plan (monthly) ·
              {" "}{formatDate(upcomingRenewal.date)} · card •••• {upcomingRenewal.methodLast4}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 relative">
          <Button variant="outline" size="sm" className="cursor-pointer" onClick={() => setRemindMeOpen(true)}>
            Remind me
          </Button>
          <Button size="sm" className="cursor-pointer" onClick={() => setPayNowOpen(true)}>Pay now</Button>
        </div>
      </motion.div>

      {/* Usage meters */}
      <div className="rounded-lg surface-card p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground">Usage this cycle</h3>
            <p className="text-xs text-muted-foreground">Resets in {upcomingRenewal.daysUntil} days · {currentPlan.name} plan</p>
          </div>
          <ShieldCheck className="h-4 w-4 text-muted-foreground" />
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {meters.map((m) => <UsageMeterRow key={m.label} meter={m} />)}
        </div>
      </div>

      {/* Plans */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Available plans</h3>
          <p className="text-xs text-muted-foreground">Click a plan to upgrade or downgrade instantly</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {planCards.map((p) => (
            <PlanCardItem key={p.id} plan={p} currentPlanId={currentPlanId} onUpgrade={(plan) => setUpgradeTarget(plan)} />
          ))}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <PaymentMethods />
        <InvoicesList />
      </div>

      <UpgradePlanDialog
        target={upgradeTarget}
        current={currentPlan}
        open={upgradeTarget !== null}
        onClose={() => setUpgradeTarget(null)}
        onConfirm={() => {
          if (upgradeTarget) {
            setCurrentPlanId(upgradeTarget.id);
            toast.success(`Plan upgraded to ${upgradeTarget.name}`, {
              description: `Your usage limits have been updated. ${formatCurrency(upgradeTarget.price)}/mo starting next cycle.`,
            });
            setUpgradeTarget(null);
          }
        }}
      />

      {/* Pay Now dialog — confirm payment with method picker */}
      <PayNowDialog
        open={payNowOpen}
        onClose={() => setPayNowOpen(false)}
        amount={currentPlan.price}
        renewalDate={upcomingRenewal.date}
        methods={paymentMethods}
      />

      {/* Remind Me dialog — schedule a renewal reminder */}
      <RemindMeDialog
        open={remindMeOpen}
        onClose={() => setRemindMeOpen(false)}
        renewalDate={upcomingRenewal.date}
      />
    </div>
  );
}

// ── Pay Now Dialog — pay renewal early with a chosen card ──────────────────────
function PayNowDialog({
  open,
  onClose,
  amount,
  renewalDate,
  methods,
}: {
  open: boolean;
  onClose: () => void;
  amount: number;
  renewalDate: string;
  methods: PaymentMethod[];
}) {
  const [selectedMethod, setSelectedMethod] = useState<string>(methods.find((m) => m.isDefault)?.id ?? methods[0]?.id ?? "");
  const [processing, setProcessing] = useState(false);

  function pay() {
    setProcessing(true);
    // Simulate a 1.2s payment processing flow
    window.setTimeout(() => {
      setProcessing(false);
      onClose();
      toast.success(`Payment of ${formatCurrency(amount)} succeeded`, {
        description: `Receipt sent to your email. Next renewal: ${formatDate(renewalDate, { month: "long", day: "numeric", year: "numeric" })}.`,
      });
    }, 1200);
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && !processing && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Pay renewal early</DialogTitle>
          <DialogDescription>
            Charge your card now for the {formatDate(renewalDate, { month: "long", day: "numeric" })} renewal.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="rounded-md bg-muted/50 p-3 flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Amount due</span>
            <span className="text-lg font-semibold tabular-nums text-foreground">{formatCurrency(amount)}</span>
          </div>
          <div>
            <label className="text-xs font-medium text-foreground">Payment method</label>
            <ul className="mt-1.5 space-y-1.5">
              {methods.map((m) => (
                <li key={m.id}>
                  <label
                    className={cn(
                      "flex items-center gap-3 rounded-md border p-2.5 cursor-pointer transition-colors",
                      selectedMethod === m.id ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40",
                    )}
                  >
                    <input
                      type="radio"
                      name="pay-method"
                      className="sr-only"
                      checked={selectedMethod === m.id}
                      onChange={() => setSelectedMethod(m.id)}
                    />
                    <CardBrandIcon brand={m.brand as CardBrand} className="h-6 w-10 rounded ring-1 ring-border" />
                    <span className="flex-1 text-sm text-foreground">
                      {CARD_BRANDS[m.brand as CardBrand]?.label ?? "Card"} •••• {m.last4}
                    </span>
                    {m.isDefault && <Badge variant="secondary" className="text-[10px]">Default</Badge>}
                  </label>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={processing} className="cursor-pointer">Cancel</Button>
          <Button onClick={pay} disabled={processing} className="gap-1.5 cursor-pointer">
            {processing ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Processing…
              </>
            ) : (
              <>Pay {formatCurrency(amount)}</>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Remind Me Dialog — schedule a renewal reminder ────────────────────────────
function RemindMeDialog({
  open,
  onClose,
  renewalDate,
}: {
  open: boolean;
  onClose: () => void;
  renewalDate: string;
}) {
  const [when, setWhen] = useState<"1d" | "3d" | "7d" | "on_day">("3d");
  const [channel, setChannel] = useState<"email" | "sms" | "both">("email");

  function schedule() {
    const labels: Record<typeof when, string> = {
      "1d": "1 day before",
      "3d": "3 days before",
      "7d": "7 days before",
      on_day: "on the renewal day",
    };
    const chan = channel === "both" ? "email + SMS" : channel;
    toast.success("Reminder scheduled", {
      description: `We'll remind you ${labels[when]} via ${chan}.`,
    });
    onClose();
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Schedule renewal reminder</DialogTitle>
          <DialogDescription>
            Get a nudge before your {formatDate(renewalDate, { month: "long", day: "numeric" })} renewal.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-medium text-foreground">When</label>
            <div className="mt-1.5 grid grid-cols-2 gap-1.5">
              {([
                { v: "1d", label: "1 day before" },
                { v: "3d", label: "3 days before" },
                { v: "7d", label: "7 days before" },
                { v: "on_day", label: "On renewal day" },
              ] as const).map((o) => (
                <button
                  key={o.v}
                  type="button"
                  onClick={() => setWhen(o.v)}
                  className={cn(
                    "rounded-md border p-2 text-xs transition-colors cursor-pointer",
                    when === o.v ? "border-primary bg-primary/5 text-foreground font-medium" : "border-border text-muted-foreground hover:bg-muted/40",
                  )}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-foreground">Notify via</label>
            <div className="mt-1.5 grid grid-cols-3 gap-1.5">
              {([
                { v: "email", label: "Email" },
                { v: "sms", label: "SMS" },
                { v: "both", label: "Both" },
              ] as const).map((o) => (
                <button
                  key={o.v}
                  type="button"
                  onClick={() => setChannel(o.v)}
                  className={cn(
                    "rounded-md border p-2 text-xs transition-colors cursor-pointer",
                    channel === o.v ? "border-primary bg-primary/5 text-foreground font-medium" : "border-border text-muted-foreground hover:bg-muted/40",
                  )}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="cursor-pointer">Cancel</Button>
          <Button onClick={schedule} className="cursor-pointer">Schedule reminder</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
