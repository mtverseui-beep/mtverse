"use client";

/**
 * Northstar brand mark — inline SVG so it inherits theme colors and stays crisp.
 * A 4-point compass star with a longer "north" ray, sitting on a soft glow ring.
 * The outer gradient box uses the `.brand-mark` utility class for the gradient
 * background + glow shadow.
 */
export function BrandMark({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      className={className}
      role="img"
      aria-label="Northstar logo"
    >
      <defs>
        <linearGradient id="ns-star" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="currentColor" stopOpacity="1" />
          <stop offset="1" stopColor="currentColor" stopOpacity="0.7" />
        </linearGradient>
      </defs>
      {/* Soft outer glow ring */}
      <circle cx="16" cy="16" r="14" fill="currentColor" opacity="0.18" />
      {/* Star body: longer top ray = north */}
      <path
        d="M16 3 L18.8 13.2 L29 16 L18.8 18.8 L16 29 L13.2 18.8 L3 16 L13.2 13.2 Z"
        fill="currentColor"
      />
      {/* Inner highlight — gives depth */}
      <path
        d="M16 7 L17.4 14.6 L25 16 L17.4 17.4 L16 25 L14.6 17.4 L7 16 L14.6 14.6 Z"
        fill="white"
        opacity="0.45"
      />
      {/* Center dot — the pole star */}
      <circle cx="16" cy="16" r="1.6" fill="oklch(0.16 0.04 158)" />
    </svg>
  );
}
