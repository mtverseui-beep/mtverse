"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  AlertTriangle,
  Bell,
  Check,
  CreditCard,
  PackageOpen,
  Shield,
  UserPlus,
  X,
  type LucideIcon,
} from "lucide-react";
import { notifications as seed } from "@/lib/mock-data";
import type { NotificationItem, NotificationKind } from "@/lib/types";
import { useUI } from "@/hooks/use-dashboard";
import { formatRelativeTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const KIND_META: Record<NotificationKind, { icon: LucideIcon; tone: string }> = {
  billing: { icon: CreditCard, tone: "bg-chart-1/15 text-chart-1" },
  security: { icon: Shield, tone: "bg-destructive/15 text-destructive" },
  product: { icon: PackageOpen, tone: "bg-chart-2/15 text-chart-2" },
  team: { icon: UserPlus, tone: "bg-chart-4/15 text-chart-4" },
  alert: { icon: AlertTriangle, tone: "bg-warning/15 text-warning-foreground" },
};

export function NotificationsPanel() {
  const { notifOpen, setNotifOpen } = useUI();
  const router = useRouter();
  const [items, setItems] = useState<NotificationItem[]>(seed);

  // Esc closes the panel
  useEffect(() => {
    if (!notifOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setNotifOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [notifOpen, setNotifOpen]);

  // Listen for "ns:open-notifications" custom event (dispatched by CommandPalette)
  useEffect(() => {
    const onOpen = () => setNotifOpen(true);
    window.addEventListener("ns:open-notifications", onOpen);
    return () => window.removeEventListener("ns:open-notifications", onOpen);
  }, [setNotifOpen]);

  // Lock body scroll when open
  useEffect(() => {
    if (notifOpen) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => { document.body.style.overflow = prev; };
    }
  }, [notifOpen]);

  const unread = items.filter((n) => !n.read).length;

  function markAll() {
    setItems((prev) => prev.map((n) => ({ ...n, read: true })));
    toast.success("All notifications marked as read");
  }
  function markOne(id: string) {
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  }

  return (
    <AnimatePresence>
      {notifOpen && (
        <div className="fixed inset-0 z-[90]" role="dialog" aria-modal="true" aria-label="Notifications">
          <motion.div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setNotifOpen(false)}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16 }}
            aria-hidden
          />
          <motion.aside
            className="absolute right-0 top-0 h-full w-full max-w-md bg-card border-l border-border flex flex-col shadow-2xl"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 280 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-border p-4">
              <div className="flex items-center gap-2">
                <span className="grid h-8 w-8 place-items-center rounded-md bg-primary/10 text-primary">
                  <Bell className="h-4 w-4" />
                </span>
                <div>
                  <h2 className="text-sm font-semibold text-foreground">Notifications</h2>
                  <p className="text-xs text-muted-foreground">
                    {unread > 0 ? `${unread} unread` : "You're all caught up"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" className="text-xs" onClick={markAll} disabled={unread === 0}>
                  Mark all read
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={() => setNotifOpen(false)} aria-label="Close notifications">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto">
              <ul className="divide-y divide-border">
                {items.map((n, i) => {
                  const meta = KIND_META[n.kind];
                  const Icon = meta.icon;
                  return (
                    <motion.li
                      key={n.id}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.22, delay: Math.min(i * 0.03, 0.2) }}
                      className={cn(
                        "relative flex gap-3 p-4 transition-colors hover:bg-muted/40 cursor-default",
                        !n.read && "bg-primary/[0.04]",
                      )}
                    >
                      {/* Unread indicator */}
                      {!n.read && (
                        <span
                          aria-hidden
                          className="absolute left-1.5 top-1/2 -translate-y-1/2 h-1.5 w-1.5 rounded-full bg-primary"
                        />
                      )}
                      <span className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-md", meta.tone)}>
                        <Icon className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-baseline justify-between gap-2">
                          <p className="text-sm font-medium text-foreground truncate">{n.title}</p>
                          <span className="shrink-0 text-[11px] text-muted-foreground">{formatRelativeTime(n.timestamp)}</span>
                        </div>
                        <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">{n.description}</p>
                        <div className="mt-2 flex items-center gap-2">
                          {n.actionable && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-6 px-2 text-[11px]"
                              onClick={() => { markOne(n.id); toast.success("Opened"); }}
                            >
                              View
                            </Button>
                          )}
                          {!n.read && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 px-2 text-[11px] text-muted-foreground"
                              onClick={() => markOne(n.id)}
                            >
                              <Check className="h-3 w-3 mr-1" /> Mark read
                            </Button>
                          )}
                        </div>
                      </div>
                    </motion.li>
                  );
                })}
              </ul>
            </div>

            {/* Footer */}
            <div className="border-t border-border p-3">
              <Button
                variant="outline"
                size="sm"
                className="w-full cursor-pointer"
                onClick={() => {
                  setNotifOpen(false);
                  router.push("/settings/notifications");
                }}
              >
                Notification preferences
              </Button>
            </div>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}
