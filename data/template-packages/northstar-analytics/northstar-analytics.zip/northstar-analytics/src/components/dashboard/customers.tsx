"use client";

import { useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Download,
  FileText,
  Mail,
  MoreHorizontal,
  Search,
  Trash2,
  Users2,
  X,
  Activity as ActivityIcon,
  Plus,
} from "lucide-react";
import { customers as seedCustomers, invoices, avatarUrlForVariant } from "@/lib/mock-data";
import type { Customer, CustomerStatus, Plan } from "@/lib/types";
import { useSimulatedFetch } from "@/hooks/use-dashboard";
import { Skeleton, ErrorState, EmptyState } from "./primitives";
import { formatDate, formatCurrency, formatNumber, formatRelativeTime, initials } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

type SortKey = "company" | "mrr" | "seats" | "signupDate" | "lastSeen";
type SortDir = "asc" | "desc";

const STATUS_META: Record<CustomerStatus, { label: string; className: string }> = {
  active: { label: "Active", className: "bg-success/15 text-success border-success/20" },
  trialing: { label: "Trialing", className: "bg-chart-3/15 text-chart-3 border-chart-3/30" },
  past_due: { label: "Past due", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  canceled: { label: "Canceled", className: "bg-muted text-muted-foreground border-border" },
  churned: { label: "Churned", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

const HEALTH_META: Record<Customer["health"], { label: string; className: string }> = {
  healthy: { label: "Healthy", className: "bg-success/15 text-success" },
  watch: { label: "Watch", className: "bg-warning/15 text-warning-foreground" },
  at_risk: { label: "At risk", className: "bg-destructive/15 text-destructive" },
};

const PLAN_LABELS: Record<Plan, string> = {
  free: "Free",
  starter: "Starter",
  pro: "Pro",
  scale: "Scale",
  enterprise: "Enterprise",
};

const PAGE_SIZE = 8;

function SortHeader({ label, active, dir, onClick }: { label: string; active: boolean; dir: SortDir; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
      aria-pressed={active}
    >
      {label}
      {active ? (
        dir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
      ) : (
        <ArrowUpDown className="h-3 w-3 opacity-0 group-hover:opacity-60" />
      )}
    </button>
  );
}

function CustomerDetailDrawer({ customer, onClose, onCancel }: { customer: Customer | null; onClose: () => void; onCancel?: (id: string) => void }) {
  const open = customer !== null;
  const [tab, setTab] = useState<"overview" | "activity" | "invoices">("overview");

  // Customer invoices (mock — match by company name)
  const custInvoices = customer
    ? invoices.filter((i) => i.customer === customer.company).slice(0, 6)
    : [];

  // Reset to first tab when customer changes
  const custId = customer?.id;
  const [lastCustId, setLastCustId] = useState<string | null>(null);
  if (custId && custId !== lastCustId) {
    setLastCustId(custId);
    if (tab !== "overview") setTab("overview");
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg gap-0 p-0 overflow-hidden">
        {customer && (
          <>
            {/* Header with real avatar */}
            <DialogHeader className="p-5 border-b border-border bg-gradient-to-br from-primary/5 to-transparent">
              <div className="flex items-start gap-3">
                <Avatar className="h-12 w-12 border border-border shrink-0">
                  <AvatarImage src={customer.avatarUrl} alt={customer.contactName} />
                  <AvatarFallback className="text-xs font-semibold" style={{ background: `${customer.logoColor}20`, color: customer.logoColor }}>
                    {initials(customer.contactName)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <DialogTitle className="text-base text-foreground truncate">{customer.company}</DialogTitle>
                  <DialogDescription className="truncate">{customer.contactName} · {customer.email}</DialogDescription>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                <Badge variant="outline" className={cn("border", STATUS_META[customer.status].className)}>
                  {STATUS_META[customer.status].label}
                </Badge>
                <Badge variant="outline" className={cn("border", HEALTH_META[customer.health].className)}>
                  {HEALTH_META[customer.health].label}
                </Badge>
                <Badge variant="secondary" className="text-[10px]">{PLAN_LABELS[customer.plan]}</Badge>
                <Badge variant="outline" className="text-[10px] border-border text-muted-foreground">{customer.industry}</Badge>
              </div>
            </DialogHeader>

            {/* Tabs */}
            <div role="tablist" aria-label="Customer details" className="flex border-b border-border">
              {([
                { id: "overview", label: "Overview" },
                { id: "activity", label: "Activity" },
                { id: "invoices", label: `Invoices (${custInvoices.length})` },
              ] as const).map((t) => (
                <button
                  key={t.id}
                  role="tab"
                  aria-selected={tab === t.id}
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "relative px-4 py-2.5 text-xs font-medium transition-colors cursor-pointer",
                    tab === t.id ? "text-foreground" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {t.label}
                  {tab === t.id && (
                    <span
                      aria-hidden
                      className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full bg-primary"
                    />
                  )}
                </button>
              ))}
            </div>

            {/* Tab content */}
            <div className="max-h-[40vh] overflow-y-auto">
              {tab === "overview" && (
                <div className="grid grid-cols-2 gap-px bg-border">
                  {[
                    { label: "MRR", value: formatCurrency(customer.mrr) },
                    { label: "Seats", value: formatNumber(customer.seats) },
                    { label: "Country", value: customer.country },
                    { label: "Industry", value: customer.industry },
                    { label: "Signed up", value: formatDate(customer.signupDate) },
                    { label: "Last seen", value: formatRelativeTime(customer.lastSeen) },
                  ].map((row) => (
                    <div key={row.label} className="bg-card p-4">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{row.label}</p>
                      <p className="mt-1 text-sm font-medium text-foreground tabular-nums">{row.value}</p>
                    </div>
                  ))}
                </div>
              )}

              {tab === "activity" && (
                <ol className="p-4 space-y-3">
                  {[
                    { ts: customer.lastSeen, label: "Last login", desc: "Signed in via web app" },
                    { ts: customer.signupDate, label: "Account created", desc: `Started on the ${PLAN_LABELS[customer.plan]} plan` },
                    { ts: new Date(new Date(customer.signupDate).getTime() + 7 * 86400000).toISOString(), label: "Trial converted", desc: `Upgraded from trial to ${PLAN_LABELS[customer.plan]}` },
                  ].map((evt, i) => (
                    <li key={i} className="flex gap-3">
                      <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-primary/10 text-primary">
                        <ActivityIcon className="h-3.5 w-3.5" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-foreground">{evt.label}</p>
                        <p className="text-xs text-muted-foreground">{evt.desc}</p>
                        <p className="text-[11px] text-muted-foreground mt-0.5">{formatRelativeTime(evt.ts)}</p>
                      </div>
                    </li>
                  ))}
                </ol>
              )}

              {tab === "invoices" && (
                <ul className="divide-y divide-border">
                  {custInvoices.length === 0 && (
                    <li className="p-6 text-center text-sm text-muted-foreground">No invoices for this customer.</li>
                  )}
                  {custInvoices.map((inv) => (
                    <li key={inv.id} className="flex items-center justify-between p-4 hover:bg-muted/40 transition-colors cursor-pointer">
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="grid h-8 w-8 place-items-center rounded-md bg-muted text-muted-foreground shrink-0">
                          <FileText className="h-3.5 w-3.5" />
                        </span>
                        <div className="min-w-0">
                          <p className="text-sm font-mono text-foreground truncate">{inv.number}</p>
                          <p className="text-xs text-muted-foreground">{formatDate(inv.issuedAt)}</p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-sm font-medium tabular-nums text-foreground">{formatCurrency(inv.amount)}</p>
                        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{inv.status}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <DialogFooter className="p-4 border-t border-border flex-row gap-2">
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 cursor-pointer"
                onClick={() => {
                  window.location.href = `mailto:${customer.email}?subject=Following up from Northstar`;
                  toast.success(`Email drafted to ${customer.email}`);
                }}
              >
                <Mail className="h-3.5 w-3.5" /> Email
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-destructive hover:text-destructive ml-auto cursor-pointer"
                onClick={() => {
                  if (onCancel) onCancel(customer.id);
                  toast.success(`Subscription canceled for ${customer.company}`);
                  onClose();
                }}
              >
                Cancel subscription
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function ConfirmBulkDelete({
  open,
  count,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  count: number;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onCancel()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Archive {count} customer{count === 1 ? "" : "s"}?</DialogTitle>
          <DialogDescription>
            This will remove them from your active list and stop all billing. The action can be reverted from the archive within 30 days.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>Keep</Button>
          <Button variant="destructive" onClick={onConfirm}>Archive</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Add Customer Dialog — real form with validation ──────────────────────────
function AddCustomerDialog({
  open,
  onClose,
  onAdd,
}: {
  open: boolean;
  onClose: () => void;
  onAdd: (c: Customer) => void;
}) {
  const [company, setCompany] = useState("");
  const [contactName, setContactName] = useState("");
  const [email, setEmail] = useState("");
  const [plan, setPlan] = useState<Plan>("starter");
  const [errors, setErrors] = useState<Record<string, string>>({});

  function reset() {
    setCompany("");
    setContactName("");
    setEmail("");
    setPlan("starter");
    setErrors({});
  }

  function validate() {
    const e: Record<string, string> = {};
    if (company.trim().length < 2) e.company = "Company name must be at least 2 characters.";
    if (contactName.trim().length < 2) e.contactName = "Contact name must be at least 2 characters.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = "Enter a valid email address.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function submit() {
    if (!validate()) return;
    const PLAN_MRR: Record<Plan, number> = { free: 0, starter: 39, pro: 249, scale: 599, enterprise: 8_500 };
    const newCustomer: Customer = {
      id: `cus_${Date.now().toString(36)}`,
      company: company.trim(),
      contactName: contactName.trim(),
      email: email.trim().toLowerCase(),
      avatarUrl: avatarUrlForVariant(email.trim().toLowerCase(), contactName.trim()),
      plan,
      status: "trialing",
      health: "healthy",
      mrr: PLAN_MRR[plan],
      seats: plan === "free" ? 1 : plan === "enterprise" ? 50 : 3,
      country: "United States",
      signupDate: new Date().toISOString(),
      lastSeen: new Date().toISOString(),
      industry: "SaaS",
      logoColor: "var(--chart-1)",
    };
    onAdd(newCustomer);
    toast.success(`${newCustomer.company} added`, {
      description: `Started a 14-day trial on the ${PLAN_LABELS[plan]} plan.`,
    });
    reset();
    onClose();
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) reset(); onClose(); }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add a new customer</DialogTitle>
          <DialogDescription>Create an account with a 14-day trial. No payment method required.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <label htmlFor="add-company" className="text-xs font-medium text-foreground">Company name</label>
            <Input
              id="add-company"
              value={company}
              onChange={(e) => setCompany(e.target.value)}
              placeholder="Acme Inc."
              className={cn("mt-1", errors.company && "border-destructive")}
              aria-invalid={!!errors.company}
              autoFocus
            />
            {errors.company && <p className="mt-1 text-xs text-destructive">{errors.company}</p>}
          </div>
          <div>
            <label htmlFor="add-contact" className="text-xs font-medium text-foreground">Primary contact</label>
            <Input
              id="add-contact"
              value={contactName}
              onChange={(e) => setContactName(e.target.value)}
              placeholder="Jane Doe"
              className={cn("mt-1", errors.contactName && "border-destructive")}
              aria-invalid={!!errors.contactName}
            />
            {errors.contactName && <p className="mt-1 text-xs text-destructive">{errors.contactName}</p>}
          </div>
          <div>
            <label htmlFor="add-email" className="text-xs font-medium text-foreground">Email</label>
            <Input
              id="add-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jane@acme.com"
              className={cn("mt-1", errors.email && "border-destructive")}
              aria-invalid={!!errors.email}
            />
            {errors.email && <p className="mt-1 text-xs text-destructive">{errors.email}</p>}
          </div>
          <div>
            <label htmlFor="add-plan" className="text-xs font-medium text-foreground">Starting plan</label>
            <Select value={plan} onValueChange={(v) => setPlan(v as Plan)}>
              <SelectTrigger id="add-plan" className="mt-1 w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="free">Free — $0/mo</SelectItem>
                <SelectItem value="starter">Starter — $39/mo</SelectItem>
                <SelectItem value="pro">Pro — $249/mo</SelectItem>
                <SelectItem value="scale">Scale — $599/mo</SelectItem>
                <SelectItem value="enterprise">Enterprise — $8,500/mo</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} className="gap-1.5">
            <Plus className="h-3.5 w-3.5" /> Add customer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── CSV export helper — triggers a real download ─────────────────────────────
function exportCustomersCsv(rows: Customer[], filename = "customers.csv") {
  const headers = ["ID", "Company", "Contact", "Email", "Plan", "Status", "Health", "MRR", "Seats", "Country", "Industry", "Signup Date", "Last Seen"];
  const escape = (v: string | number) => {
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [
    headers.join(","),
    ...rows.map((c) => [
      c.id, c.company, c.contactName, c.email, c.plan, c.status, c.health,
      c.mrr, c.seats, c.country, c.industry, c.signupDate, c.lastSeen,
    ].map(escape).join(",")),
  ];
  const csv = lines.join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function CustomersPage() {
  // Local mutable copy of the customer list so we can actually add/remove.
  const [customers, setCustomers] = useState<Customer[]>(seedCustomers);
  const { status, data, error, retry } = useSimulatedFetch<Customer[]>(() => customers, { delay: 500, deps: [customers] });

  const [search, setSearch] = useState("");
  const [planFilter, setPlanFilter] = useState<Plan | "all">("all");
  const [statusFilter, setStatusFilter] = useState<CustomerStatus | "all">("all");
  const [sortKey, setSortKey] = useState<SortKey>("mrr");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [activeCustomer, setActiveCustomer] = useState<Customer | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);

  const filtered = useMemo(() => {
    if (!data) return [];
    let list = data;
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((c) =>
        c.company.toLowerCase().includes(q) ||
        c.contactName.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q),
      );
    }
    if (planFilter !== "all") list = list.filter((c) => c.plan === planFilter);
    if (statusFilter !== "all") list = list.filter((c) => c.status === statusFilter);
    list = [...list].sort((a, b) => {
      let av: string | number = a[sortKey];
      let bv: string | number = b[sortKey];
      if (typeof av === "string" && typeof bv === "string") {
        return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
      }
      av = av as number; bv = bv as number;
      return sortDir === "asc" ? av - bv : bv - av;
    });
    return list;
  }, [data, search, planFilter, statusFilter, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageRows = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  const allOnPageSelected = pageRows.length > 0 && pageRows.every((c) => selected.has(c.id));
  const someOnPageSelected = pageRows.some((c) => selected.has(c.id));

  function toggleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "company" ? "asc" : "desc");
    }
  }

  function toggleAllOnPage() {
    setSelected((prev) => {
      const next = new Set(prev);
      if (allOnPageSelected) {
        pageRows.forEach((c) => next.delete(c.id));
      } else {
        pageRows.forEach((c) => next.add(c.id));
      }
      return next;
    });
  }

  function toggleOne(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  // Reset page when filters change
  function resetPage() {
    setPage(1);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Customers</h2>
          <p className="text-sm text-muted-foreground">{data ? `${formatNumber(filtered.length)} of ${formatNumber(data.length)} accounts` : "Loading accounts…"}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5 cursor-pointer"
            onClick={() => {
              const rows = filtered.length > 0 ? filtered : (data ?? []);
              if (rows.length === 0) {
                toast.error("No customers to export");
                return;
              }
              exportCustomersCsv(rows);
              toast.success(`Exported ${rows.length} customers to CSV`);
            }}
          >
            <Download className="h-3.5 w-3.5" /> Export CSV
          </Button>
          <Button size="sm" className="gap-1.5 cursor-pointer" onClick={() => setAddOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> Add customer
          </Button>
        </div>
      </div>

      {/* Filter bar */}
      <div className="rounded-lg surface-card p-3 flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" aria-hidden />
          <input
            type="search"
            value={search}
            onChange={(e) => { setSearch(e.target.value); resetPage(); }}
            placeholder="Search by company, name, or email…"
            aria-label="Search customers"
            className="h-9 w-full rounded-md bg-muted/60 pl-8 pr-8 text-sm text-foreground placeholder:text-muted-foreground border border-transparent focus:border-ring/60 focus:ring-1 focus:ring-ring/30 focus:bg-background focus:outline-none transition-colors"
          />
          {search && (
            <button
              onClick={() => { setSearch(""); resetPage(); }}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Clear search"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
        <Select value={planFilter} onValueChange={(v) => { setPlanFilter(v as Plan | "all"); resetPage(); }}>
          <SelectTrigger className="h-9 w-[130px]" aria-label="Filter by plan">
            <SelectValue placeholder="Plan" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All plans</SelectItem>
            <SelectItem value="free">Free</SelectItem>
            <SelectItem value="starter">Starter</SelectItem>
            <SelectItem value="pro">Pro</SelectItem>
            <SelectItem value="scale">Scale</SelectItem>
            <SelectItem value="enterprise">Enterprise</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v as CustomerStatus | "all"); resetPage(); }}>
          <SelectTrigger className="h-9 w-[140px]" aria-label="Filter by status">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="trialing">Trialing</SelectItem>
            <SelectItem value="past_due">Past due</SelectItem>
            <SelectItem value="canceled">Canceled</SelectItem>
            <SelectItem value="churned">Churned</SelectItem>
          </SelectContent>
        </Select>
        {(search || planFilter !== "all" || statusFilter !== "all") && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => { setSearch(""); setPlanFilter("all"); setStatusFilter("all"); resetPage(); }}
            className="text-xs"
          >
            Reset filters
          </Button>
        )}
      </div>

      {/* Bulk action bar */}
      {selected.size > 0 && (
        <div
          role="region"
          aria-label="Bulk actions"
          className="flex items-center justify-between gap-3 rounded-md border border-primary/30 bg-primary/5 px-4 py-2"
        >
          <p className="text-sm text-foreground">
            <span className="font-medium">{selected.size}</span> selected
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success(`Email composed for ${selected.size} customers`)}>
              <Mail className="h-3.5 w-3.5" /> Email
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 cursor-pointer"
              onClick={() => {
                const selectedRows = (data ?? []).filter((c) => selected.has(c.id));
                if (selectedRows.length === 0) {
                  toast.error("No customers selected");
                  return;
                }
                exportCustomersCsv(selectedRows, `customers-${selected.size}.csv`);
                toast.success(`Exported ${selectedRows.length} selected customers`);
              }}
            >
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 text-destructive hover:text-destructive"
              onClick={() => setConfirmOpen(true)}
            >
              <Trash2 className="h-3.5 w-3.5" /> Archive
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setSelected(new Set())}>
              Clear
            </Button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="rounded-lg surface-card overflow-hidden">
        {status === "loading" && <Skeleton className="h-96 w-full rounded-none" />}
        {status === "error" && <div className="p-6"><ErrorState message={error ?? "Failed to load customers"} onRetry={retry} /></div>}
        {status === "success" && filtered.length === 0 && (
          <div className="p-6">
            <EmptyState
              title="No customers match your filters"
              description="Try widening your search or clearing the plan/status filters."
              icon={<Users2 className="h-8 w-8" />}
              action={<Button variant="outline" size="sm" onClick={() => { setSearch(""); setPlanFilter("all"); setStatusFilter("all"); resetPage(); }}>Reset filters</Button>}
            />
          </div>
        )}
        {status === "success" && filtered.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <caption className="sr-only">Customers</caption>
              <thead className="bg-muted/40 border-b border-border">
                <tr>
                  <th scope="col" className="w-10 px-3 py-2.5">
                    <Checkbox
                      checked={allOnPageSelected ? true : someOnPageSelected ? "indeterminate" : false}
                      onCheckedChange={toggleAllOnPage}
                      aria-label="Select all on this page"
                    />
                  </th>
                  <th scope="col" className="px-3 py-2.5 text-left" aria-sort={sortKey === "company" ? (sortDir === "asc" ? "ascending" : "descending") : "none"}>
                    <SortHeader label="Company" active={sortKey === "company"} dir={sortDir} onClick={() => toggleSort("company")} />
                  </th>
                  <th scope="col" className="hidden md:table-cell px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Status</th>
                  <th scope="col" className="hidden lg:table-cell px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">Plan</th>
                  <th scope="col" className="px-3 py-2.5 text-right" aria-sort={sortKey === "mrr" ? (sortDir === "asc" ? "ascending" : "descending") : "none"}>
                    <SortHeader label="MRR" active={sortKey === "mrr"} dir={sortDir} onClick={() => toggleSort("mrr")} />
                  </th>
                  <th scope="col" className="hidden xl:table-cell px-3 py-2.5 text-right" aria-sort={sortKey === "seats" ? (sortDir === "asc" ? "ascending" : "descending") : "none"}>
                    <SortHeader label="Seats" active={sortKey === "seats"} dir={sortDir} onClick={() => toggleSort("seats")} />
                  </th>
                  <th scope="col" className="hidden lg:table-cell px-3 py-2.5 text-left" aria-sort={sortKey === "signupDate" ? (sortDir === "asc" ? "ascending" : "descending") : "none"}>
                    <SortHeader label="Signed up" active={sortKey === "signupDate"} dir={sortDir} onClick={() => toggleSort("signupDate")} />
                  </th>
                  <th scope="col" className="hidden md:table-cell px-3 py-2.5 text-left" aria-sort={sortKey === "lastSeen" ? (sortDir === "asc" ? "ascending" : "descending") : "none"}>
                    <SortHeader label="Last seen" active={sortKey === "lastSeen"} dir={sortDir} onClick={() => toggleSort("lastSeen")} />
                  </th>
                  <th scope="col" className="w-10 px-3 py-2.5"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {pageRows.map((c) => {
                  const isSelected = selected.has(c.id);
                  return (
                    <tr
                      key={c.id}
                      onClick={() => setActiveCustomer(c)}
                      className={cn(
                        "cursor-pointer transition-colors",
                        isSelected ? "bg-primary/5" : "hover:bg-muted/40",
                      )}
                    >
                      <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleOne(c.id)}
                          aria-label={`Select ${c.company}`}
                        />
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <Avatar className="h-8 w-8 border border-border shrink-0">
                            <AvatarImage src={c.avatarUrl} alt={c.contactName} />
                            <AvatarFallback className="text-[10px] font-semibold" style={{ background: `${c.logoColor}20`, color: c.logoColor }}>
                              {initials(c.contactName)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">{c.company}</p>
                            <p className="text-xs text-muted-foreground truncate">{c.contactName} · {c.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="hidden md:table-cell px-3 py-3">
                        <Badge variant="outline" className={cn("border text-[10px]", STATUS_META[c.status].className)}>
                          {STATUS_META[c.status].label}
                        </Badge>
                      </td>
                      <td className="hidden lg:table-cell px-3 py-3 text-muted-foreground">{PLAN_LABELS[c.plan]}</td>
                      <td className="px-3 py-3 text-right tabular-nums text-foreground font-medium">{formatCurrency(c.mrr)}</td>
                      <td className="hidden xl:table-cell px-3 py-3 text-right tabular-nums text-muted-foreground">{formatNumber(c.seats)}</td>
                      <td className="hidden lg:table-cell px-3 py-3 text-muted-foreground whitespace-nowrap">{formatDate(c.signupDate, { month: "short", day: "numeric", year: "numeric" })}</td>
                      <td className="hidden md:table-cell px-3 py-3 text-muted-foreground whitespace-nowrap">{formatRelativeTime(c.lastSeen)}</td>
                      <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              // Same dev-only useId instability fix as ProfileMenu —
                              // see profile-menu.tsx for full rationale.
                              suppressHydrationWarning
                              className="h-7 w-7 text-muted-foreground"
                              aria-label={`More actions for ${c.company}`}
                            >
                              <MoreHorizontal className="h-3.5 w-3.5" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuLabel className="text-xs text-muted-foreground">{c.company}</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => setActiveCustomer(c)}>View details</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => {
                              window.location.href = `mailto:${c.email}?subject=Following up from Northstar`;
                              toast.success(`Email drafted to ${c.email}`);
                            }}>Send email</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => {
                              const custInvoices = invoices.filter((i) => i.customer === c.company);
                              if (custInvoices.length === 0) {
                                toast.error(`No invoices found for ${c.company}`);
                                return;
                              }
                              toast.success(`Downloading latest invoice for ${c.company}`);
                            }}>Download invoice</DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => {
                                setCustomers((prev) => prev.map((x) => x.id === c.id ? { ...x, status: "canceled" } : x));
                                toast.success(`Subscription canceled for ${c.company}`);
                              }}
                            >
                              Cancel subscription
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {status === "success" && filtered.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border px-4 py-3">
            <p className="text-xs text-muted-foreground">
              Page {safePage} of {totalPages} · {formatNumber(filtered.length)} accounts
            </p>
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                className="h-7 w-7"
                disabled={safePage <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                aria-label="Previous page"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
              </Button>
              {Array.from({ length: totalPages }).slice(0, 7).map((_, i) => {
                const p = i + 1;
                return (
                  <Button
                    key={p}
                    variant={p === safePage ? "default" : "outline"}
                    size="icon"
                    className="h-7 w-7 text-xs"
                    onClick={() => setPage(p)}
                    aria-current={p === safePage ? "page" : undefined}
                  >
                    {p}
                  </Button>
                );
              })}
              <Button
                variant="outline"
                size="icon"
                className="h-7 w-7"
                disabled={safePage >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                aria-label="Next page"
              >
                <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        )}
      </div>

      <CustomerDetailDrawer
        customer={activeCustomer}
        onClose={() => setActiveCustomer(null)}
        onCancel={(id) => {
          setCustomers((prev) => prev.map((x) => x.id === id ? { ...x, status: "canceled" } : x));
        }}
      />
      <ConfirmBulkDelete
        open={confirmOpen}
        count={selected.size}
        onCancel={() => setConfirmOpen(false)}
        onConfirm={() => {
          // Actually remove the selected customers from local state.
          setCustomers((prev) => prev.filter((c) => !selected.has(c.id)));
          toast.success(`Archived ${selected.size} customer${selected.size === 1 ? "" : "s"}`);
          setSelected(new Set());
          setConfirmOpen(false);
        }}
      />
      <AddCustomerDialog
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onAdd={(c) => {
          setCustomers((prev) => [c, ...prev]);
          setPage(1);
        }}
      />

      {/* Health summary footer */}
      {status === "success" && data && (
        <div className="grid gap-4 sm:grid-cols-3">
          {(["healthy", "watch", "at_risk"] as const).map((h) => {
            const count = data.filter((c) => c.health === h).length;
            const pct = (count / data.length) * 100;
            return (
              <div key={h} className="rounded-lg surface-card p-4">
                <div className="flex items-center justify-between">
                  <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium", HEALTH_META[h].className)}>
                    {HEALTH_META[h].label}
                  </span>
                  <span className="text-sm tabular-nums text-muted-foreground">{formatNumber(count)}</span>
                </div>
                <div className="mt-3 h-1.5 w-full rounded-full bg-muted/60 overflow-hidden">
                  <div
                    className={cn("h-full", h === "healthy" ? "bg-success" : h === "watch" ? "bg-warning" : "bg-destructive")}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
