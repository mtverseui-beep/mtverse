"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell,
  ChevronRight,
  CreditCard,
  KeyRound,
  LayoutDashboard,
  LifeBuoy,
  Menu,
  Search,
  Settings as SettingsIcon,
  UserCog,
  Users,
  BarChart3,
  type LucideIcon,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useUI, PRIMARY_ROUTES, ROUTES, type RoutePath, type NavIconKey } from "@/hooks/use-dashboard";
import { ThemeToggle } from "./theme-toggle";
import { ProfileMenu } from "./profile-menu";
import { BrandMark } from "./brand-mark";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { currentUser } from "@/lib/mock-data";

// Map icon keys → icon components. Single source of truth.
const NAV_ICONS: Record<NavIconKey, LucideIcon> = {
  overview: LayoutDashboard,
  analytics: BarChart3,
  customers: Users,
  billing: CreditCard,
  settings: SettingsIcon,
  profile: UserCog,
  team: Users,
  "api-keys": KeyRound,
  notifications: Bell,
};

function BrandHeader() {
  return (
    <Link
      href="/"
      className="flex items-center gap-2.5 rounded-md p-1 -m-1 cursor-pointer hover:bg-sidebar-accent/40 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-sidebar"
      aria-label="Northstar home"
    >
      <span className="brand-mark grid h-9 w-9 place-items-center rounded-xl text-primary-foreground shrink-0">
        <BrandMark className="h-5 w-5 text-white" />
      </span>
      <div className="leading-tight">
        <p className="text-sm font-semibold text-foreground tracking-tight">Northstar</p>
        <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Analytics Cloud</p>
      </div>
    </Link>
  );
}

function NavItem({ path, onNavigate }: { path: RoutePath; onNavigate?: () => void }) {
  const route = ROUTES[path];
  const pathname = usePathname();
  // Active = exact match OR (for /settings) any sub-route.
  const active = pathname === path || (path === "/settings" && pathname?.startsWith("/settings"));

  const Icon = NAV_ICONS[route.iconKey];
  return (
    <Link
      href={path}
      onClick={onNavigate}
      aria-current={active ? "page" : undefined}
      className={cn(
        "nav-item group relative flex items-center gap-3 rounded-md px-3 py-2 text-sm",
        "hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-sidebar",
        active && "nav-item-active font-medium",
        !active && "text-sidebar-foreground/80",
      )}
    >
      {active && (
        <motion.span
          layoutId="nav-active-bar"
          aria-hidden
          className="absolute left-0 top-1/2 h-6 -translate-y-1/2 w-1 rounded-r-full bg-primary"
          transition={{ type: "spring", damping: 24, stiffness: 320 }}
        />
      )}
      <Icon
        className={cn(
          "h-4 w-4 shrink-0 transition-colors",
          active ? "text-primary" : "text-muted-foreground group-hover:text-foreground",
        )}
      />
      <span className="flex-1 text-left">{route.label}</span>
      {route.badge && (
        <span
          className={cn(
            "grid h-5 min-w-5 place-items-center rounded-full px-1.5 text-[10px] font-semibold",
            active
              ? "bg-primary/20 text-primary"
              : "bg-muted text-muted-foreground group-hover:bg-background/80 group-hover:text-foreground",
          )}
        >
          {route.badge}
        </span>
      )}
    </Link>
  );
}

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav aria-label="Primary" className="flex flex-col gap-1">
      <p className="px-3 pb-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/80">
        Workspace
      </p>
      {PRIMARY_ROUTES.map((path) => (
        <NavItem key={path} path={path} onNavigate={onNavigate} />
      ))}
    </nav>
  );
}

function SettingsSubNav({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  if (!pathname?.startsWith("/settings")) return null;

  const subRoutes: RoutePath[] = ["/settings/profile", "/settings/team", "/settings/api-keys", "/settings/notifications"];
  return (
    <div className="space-y-1">
      <p className="px-3 pb-2 pt-4 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/80">
        Settings
      </p>
      {subRoutes.map((path) => {
        const route = ROUTES[path];
        const Icon = NAV_ICONS[route.iconKey];
        const active = pathname === path || (path === "/settings/profile" && pathname === "/settings");
        return (
          <Link
            key={path}
            href={path}
            onClick={onNavigate}
            aria-current={active ? "page" : undefined}
            className={cn(
              "nav-item group relative flex items-center gap-3 rounded-md px-3 py-1.5 text-[13px]",
              "hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-sidebar",
              active ? "text-foreground font-medium bg-sidebar-accent/60" : "text-muted-foreground",
            )}
          >
            <Icon className={cn("h-3.5 w-3.5 shrink-0", active ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
            <span className="flex-1 text-left">{route.label}</span>
          </Link>
        );
      })}
    </div>
  );
}

function HelpButton() {
  return (
    <Link
      href="/docs"
      className="nav-item flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-xs text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-sidebar"
      aria-label="Open help & docs"
    >
      <LifeBuoy className="h-3.5 w-3.5" />
      <span className="flex-1 text-left">Help &amp; docs</span>
      <kbd className="hidden lg:inline-flex h-4 items-center rounded border border-sidebar-border bg-background/60 px-1 text-[9px] font-medium">
        ?
      </kbd>
    </Link>
  );
}

function SidebarFooter() {
  return (
    <div className="mt-auto border-t border-sidebar-border p-3">
      <Link
        href="/settings/profile"
        className="flex w-full items-center gap-3 rounded-md p-2 hover:bg-sidebar-accent/70 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-sidebar"
        aria-label="Open profile settings"
      >
        <Avatar className="h-8 w-8 border border-border">
          <AvatarImage src={currentUser.avatarUrl} alt={currentUser.name} />
          <AvatarFallback className="bg-primary/15 text-primary text-xs font-semibold">
            {currentUser.initials}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1 text-left">
          <p className="truncate text-sm font-medium text-foreground">{currentUser.name}</p>
          <p className="truncate text-xs text-muted-foreground">{currentUser.email}</p>
        </div>
        <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-primary">
          {currentUser.role}
        </span>
      </Link>
    </div>
  );
}

// Breadcrumb for the current page — gives the navbar context.
function Breadcrumb() {
  const pathname = usePathname();
  if (!pathname) return null;
  const segments = pathname.split("/").filter(Boolean);
  if (segments.length === 0) {
    return (
      <div className="flex items-center gap-2 min-w-0">
        <h1 className="text-sm font-semibold text-foreground truncate">Overview</h1>
        <span className="hidden sm:inline text-xs text-muted-foreground">·</span>
        <span className="hidden sm:inline text-xs text-muted-foreground truncate">Is everything okay?</span>
      </div>
    );
  }

  // Build crumbs from segments.
  const crumbs: { label: string; href: string }[] = [];
  let acc = "";
  for (const seg of segments) {
    acc += "/" + seg;
    const route = ROUTES[acc as RoutePath];
    if (route) {
      crumbs.push({ label: route.label, href: route.path });
    } else {
      // Unknown segment (e.g. /customers/[id]) — title-case it.
      crumbs.push({ label: seg.charAt(0).toUpperCase() + seg.slice(1), href: acc });
    }
  }

  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 min-w-0">
      <ol className="flex items-center gap-1.5 text-sm">
        {crumbs.map((c, i) => {
          const isLast = i === crumbs.length - 1;
          return (
            <li key={c.href} className="flex items-center gap-1.5 min-w-0">
              {i > 0 && <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/60 shrink-0" />}
              {isLast ? (
                <span className="font-semibold text-foreground truncate">{c.label}</span>
              ) : (
                <Link href={c.href} className="text-muted-foreground hover:text-foreground transition-colors truncate cursor-pointer">
                  {c.label}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { setCommandOpen, setNotifOpen } = useUI();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [unreadCount] = useState(3);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMobileOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [mobileOpen]);

  // Close mobile drawer on route change. We track the previous pathname and
  // only call setState when it actually changes. This is the canonical
  // "subscribe to external state (Next.js router) and update React state in
  // response" pattern that the react-hooks/set-state-in-effect rule
  // explicitly permits — but the linter can't tell, so we disable inline.
  const pathname = usePathname();
  const prevPath = useRef(pathname);
  useEffect(() => {
    if (prevPath.current !== pathname) {
      prevPath.current = pathname;
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setMobileOpen(false);
    }
  }, [pathname]);

  return (
    <div className="flex min-h-screen bg-background">
      {/* Ambient gradient backdrop — fixed so it doesn't scroll with the page */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10"
        style={{
          background:
            "radial-gradient(800px circle at 0% 0%, color-mix(in oklch, var(--primary) 8%, transparent), transparent 50%), radial-gradient(600px circle at 100% 100%, color-mix(in oklch, var(--chart-2) 6%, transparent), transparent 50%)",
        }}
      />

      {/* Desktop sidebar — solid bg-background (no glass), gradient active pill */}
      <aside
        className="bg-sidebar hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 text-sidebar-foreground border-r border-sidebar-border z-40"
        aria-label="Sidebar"
      >
        <div className="flex h-16 items-center px-4 border-b border-sidebar-border">
          <BrandHeader />
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          <NavList />
          <SettingsSubNav />
          <div className="space-y-2 pt-2">
            <p className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/80">
              Resources
            </p>
            <HelpButton />
          </div>
        </div>
        <SidebarFooter />
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Navigation">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
            aria-hidden
          />
          <motion.div
            className="bg-sidebar absolute left-0 top-0 h-full w-72 max-w-[85vw] text-sidebar-foreground border-r border-sidebar-border shadow-2xl flex flex-col"
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 280 }}
          >
            <div className="flex h-16 items-center justify-between px-4 border-b border-sidebar-border">
              <BrandHeader />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileOpen(false)}
                aria-label="Close navigation"
                className="text-muted-foreground"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-4">
              <NavList onNavigate={() => setMobileOpen(false)} />
              <SettingsSubNav onNavigate={() => setMobileOpen(false)} />
              <div className="space-y-2 pt-2">
                <HelpButton />
              </div>
            </div>
            <SidebarFooter />
          </motion.div>
        </div>
      )}

      {/* Main column */}
      <div className="flex-1 flex flex-col min-w-0 md:pl-64">
        {/* Topbar — solid bg-background (no glass), no transparency leak */}
        <header
          className={cn(
            "bg-background sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border px-4 md:px-6",
          )}
        >
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-muted-foreground"
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation"
            aria-expanded={mobileOpen}
            aria-controls="mobile-drawer"
          >
            <Menu className="h-4 w-4" />
          </Button>

          {/* Breadcrumb replaces the static page title */}
          <Breadcrumb />

          <div className="ml-auto flex items-center gap-1.5">
            {/* Command palette trigger — desktop */}
            <button
              type="button"
              onClick={() => setCommandOpen(true)}
              aria-label="Open command palette"
              className="search-input hidden sm:flex items-center gap-2 h-9 rounded-md border border-border bg-muted/40 px-2.5 text-xs text-muted-foreground hover:bg-muted hover:text-foreground transition-colors cursor-pointer"
            >
              <Search className="h-3.5 w-3.5" />
              <span className="hidden lg:inline">Search…</span>
              <kbd className="inline-flex h-5 items-center gap-0.5 rounded border border-border bg-background px-1 text-[10px] font-medium">
                ⌘K
              </kbd>
            </button>

            {/* Command palette trigger — mobile */}
            <button
              type="button"
              onClick={() => setCommandOpen(true)}
              aria-label="Open command palette"
              className="icon-btn sm:hidden h-9 w-9 grid place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground cursor-pointer"
            >
              <Search className="h-4 w-4" />
            </button>

            <div className="h-7 w-px bg-border mx-0.5 hidden sm:block" />

            <ThemeToggle />

            {/* Notifications bell */}
            <button
              type="button"
              onClick={() => setNotifOpen(true)}
              aria-label={`Notifications${unreadCount > 0 ? `, ${unreadCount} unread` : ""}`}
              className="icon-btn relative h-9 w-9 grid place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground cursor-pointer"
            >
              <Bell className="h-4 w-4" />
              {unreadCount > 0 && (
                <span
                  className="absolute top-1.5 right-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[9px] font-semibold text-primary-foreground pulse-ring"
                  aria-hidden
                >
                  {unreadCount}
                </span>
              )}
            </button>

            <div className="h-7 w-px bg-border mx-0.5 hidden sm:block" />

            {/* Profile dropdown */}
            <ProfileMenu />
          </div>
        </header>

        {/* Page content */}
        <main id="dashboard-main" className="flex-1 overflow-y-auto" tabIndex={-1}>
          <div className="mx-auto max-w-[1400px] px-4 py-6 md:px-6 md:py-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
