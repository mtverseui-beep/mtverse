"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Check, Copy, Eye, EyeOff, KeyRound, Plus, Trash2, UserCog, Users2 } from "lucide-react";
import { apiKeys, currentUser, defaultNotificationPrefs, teamMembers, avatarUrlFor } from "@/lib/mock-data";
import type { ApiKey, NotificationPrefs, Role, TeamMember } from "@/lib/types";
import { formatRelativeTime, initials } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton, ErrorState } from "./primitives";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useSimulatedFetch } from "@/hooks/use-dashboard";
import { toast } from "sonner";

const ROLE_META: Record<Role, { label: string; className: string }> = {
  owner: { label: "Owner", className: "bg-primary/15 text-primary" },
  admin: { label: "Admin", className: "bg-chart-4/15 text-chart-4" },
  member: { label: "Member", className: "bg-chart-2/15 text-chart-2" },
  viewer: { label: "Viewer", className: "bg-muted text-muted-foreground" },
};

const NOTIFICATION_FIELDS: { key: keyof NotificationPrefs; label: string; description: string }[] = [
  { key: "productUpdates", label: "Product updates", description: "New features, improvements, and changes" },
  { key: "securityAlerts", label: "Security alerts", description: "Logins, API key changes, and breaches" },
  { key: "billingReminders", label: "Billing reminders", description: "Upcoming renewals and failed payments" },
  { key: "weeklyDigest", label: "Weekly digest", description: "A Monday summary of your workspace activity" },
  { key: "marketingEmails", label: "Marketing emails", description: "Tips, case studies, and offers" },
];

function ProfileSection() {
  const [name, setName] = useState("Avery Chen");
  const [email, setEmail] = useState("avery@northstar.io");
  const [bio, setBio] = useState("Head of Growth at Northstar Analytics. Previously at Lumen and Vertex.");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [dirty, setDirty] = useState(false);

  function validate() {
    const e: Record<string, string> = {};
    if (name.trim().length < 2) e.name = "Name must be at least 2 characters.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = "Enter a valid email address.";
    if (bio.length > 280) e.bio = "Bio must be 280 characters or fewer.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function save() {
    if (!validate()) return;
    setDirty(false);
    toast.success("Profile saved");
  }

  return (
    <section className="rounded-lg surface-card p-5">
      <div className="mb-4">
        <h3 className="text-sm font-semibold text-foreground">Profile</h3>
        <p className="text-xs text-muted-foreground">How your name appears across the workspace</p>
      </div>
      <div className="flex items-center gap-4 mb-5">
        <Avatar className="h-14 w-14 border border-border">
          <AvatarImage src={currentUser.avatarUrl} alt={currentUser.name} />
          <AvatarFallback className="bg-primary/15 text-primary text-base font-semibold">{currentUser.initials}</AvatarFallback>
        </Avatar>
        <Button variant="outline" size="sm" className="cursor-pointer" onClick={() => toast.success("Avatar upload opened")}>Change avatar</Button>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="profile-name" className="text-xs font-medium text-foreground">Full name</label>
          <Input
            id="profile-name"
            value={name}
            onChange={(e) => { setName(e.target.value); setDirty(true); }}
            className={cn("mt-1", errors.name && "border-destructive focus-visible:ring-destructive")}
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? "name-err" : undefined}
          />
          {errors.name && <p id="name-err" className="mt-1 text-xs text-destructive">{errors.name}</p>}
        </div>
        <div>
          <label htmlFor="profile-email" className="text-xs font-medium text-foreground">Email</label>
          <Input
            id="profile-email"
            type="email"
            value={email}
            onChange={(e) => { setEmail(e.target.value); setDirty(true); }}
            className={cn("mt-1", errors.email && "border-destructive focus-visible:ring-destructive")}
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? "email-err" : undefined}
          />
          {errors.email && <p id="email-err" className="mt-1 text-xs text-destructive">{errors.email}</p>}
        </div>
      </div>
      <div className="mt-4">
        <label htmlFor="profile-bio" className="text-xs font-medium text-foreground">Bio</label>
        <textarea
          id="profile-bio"
          value={bio}
          onChange={(e) => { setBio(e.target.value); setDirty(true); }}
          rows={3}
          maxLength={300}
          className={cn(
            "mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm",
            errors.bio ? "border-destructive" : "border-input",
            "focus:outline-none focus:ring-2 focus:ring-ring resize-none",
          )}
          aria-invalid={!!errors.bio}
        />
        <div className="mt-1 flex items-center justify-between">
          {errors.bio ? <p className="text-xs text-destructive">{errors.bio}</p> : <span />}
          <span className={cn("text-xs tabular-nums", bio.length > 280 ? "text-destructive" : "text-muted-foreground")}>{bio.length}/280</span>
        </div>
      </div>
      <div className="mt-4 flex items-center gap-2">
        <Button size="sm" onClick={save} disabled={!dirty}>Save changes</Button>
        <Button size="sm" variant="ghost" onClick={() => { setName("Avery Chen"); setEmail("avery@northstar.io"); setBio(""); setErrors({}); setDirty(false); }}>Reset</Button>
      </div>
    </section>
  );
}

function TeamSection() {
  const { status, data, error, retry } = useSimulatedFetch<TeamMember[]>(() => teamMembers, { delay: 500 });
  const [members, setMembers] = useState<TeamMember[]>(teamMembers);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [removing, setRemoving] = useState<TeamMember | null>(null);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<Role>("member");
  const [inviteError, setInviteError] = useState("");

  // Sync fetched data into local state (so user edits persist across re-fetches).
  /* eslint-disable react-hooks/set-state-in-effect */
  useEffect(() => {
    if (status === "success" && data) setMembers(data);
  }, [status, data]);
  /* eslint-enable react-hooks/set-state-in-effect */

  function sendInvite() {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(inviteEmail)) {
      setInviteError("Enter a valid email address.");
      return;
    }
    if (members.some((m) => m.email.toLowerCase() === inviteEmail.toLowerCase())) {
      setInviteError("That person is already on the team.");
      return;
    }
    const newMember: TeamMember = {
      id: `tm_${Date.now()}`,
      name: inviteEmail.split("@")[0].replace(/[._]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
      email: inviteEmail,
      role: inviteRole,
      lastActive: new Date().toISOString(),
      avatarColor: "var(--chart-2)",
      avatarUrl: avatarUrlFor(inviteEmail, inviteEmail.split("@")[0]),
    };
    setMembers((prev) => [...prev, newMember]);
    toast.success(`Invite sent to ${inviteEmail}`);
    setInviteEmail("");
    setInviteError("");
    setInviteOpen(false);
  }

  return (
    <section className="rounded-lg surface-card">
      <div className="flex items-center justify-between border-b border-border p-4">
        <div className="flex items-center gap-2">
          <Users2 className="h-4 w-4 text-muted-foreground" />
          <div>
            <h3 className="text-sm font-semibold text-foreground">Team</h3>
            <p className="text-xs text-muted-foreground">{members.length} members · 2 seats remaining</p>
          </div>
        </div>
        <Button size="sm" className="gap-1.5" onClick={() => setInviteOpen(true)}>
          <Plus className="h-3.5 w-3.5" /> Invite
        </Button>
      </div>
      {status === "loading" && <div className="p-4 space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>}
      {status === "error" && <div className="p-4"><ErrorState message={error ?? "Failed to load team"} onRetry={retry} /></div>}
      {status === "success" && (
        <ul className="divide-y divide-border">
          {members.map((m, i) => (
            <motion.li
              key={m.id}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.22, delay: Math.min(i * 0.03, 0.18) }}
              className="flex items-center gap-3 p-4 hover:bg-muted/40 transition-colors"
            >
              <Avatar className="h-9 w-9 border border-border">
                <AvatarImage src={m.avatarUrl} alt={m.name} />
                <AvatarFallback className="text-xs font-semibold" style={{ background: `${m.avatarColor}20`, color: m.avatarColor }}>
                  {initials(m.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-foreground truncate">{m.name}</p>
                  {m.role === "owner" && (
                    <Badge variant="secondary" className="text-[9px] gap-0.5">
                      <span className="h-1 w-1 rounded-full bg-success" /> You
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground truncate">{m.email} · active {formatRelativeTime(m.lastActive)}</p>
              </div>
              <Select
                value={m.role}
                onValueChange={(v) => {
                  setMembers((prev) => prev.map((mm) => mm.id === m.id ? { ...mm, role: v as Role } : mm));
                  toast.success(`${m.name} is now ${ROLE_META[v as Role].label}`);
                }}
                disabled={m.role === "owner"}
              >
                <SelectTrigger className="h-8 w-28" aria-label={`Change role for ${m.name}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="owner" disabled>Owner</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="member">Member</SelectItem>
                  <SelectItem value="viewer">Viewer</SelectItem>
                </SelectContent>
              </Select>
              {m.role !== "owner" && (
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive cursor-pointer" aria-label={`Remove ${m.name}`} onClick={() => setRemoving(m)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              )}
            </motion.li>
          ))}
        </ul>
      )}

      {/* Invite dialog */}
      <Dialog open={inviteOpen} onOpenChange={(o) => { setInviteOpen(o); if (!o) { setInviteError(""); setInviteEmail(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Invite a teammate</DialogTitle>
            <DialogDescription>They&apos;ll receive an email invitation to join your workspace.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label htmlFor="invite-email" className="text-xs font-medium text-foreground">Email</label>
              <Input
                id="invite-email"
                type="email"
                value={inviteEmail}
                onChange={(e) => { setInviteEmail(e.target.value); setInviteError(""); }}
                placeholder="teammate@company.com"
                className={cn("mt-1", inviteError && "border-destructive focus-visible:ring-destructive")}
                aria-invalid={!!inviteError}
              />
              {inviteError && <p className="mt-1 text-xs text-destructive">{inviteError}</p>}
            </div>
            <div>
              <label htmlFor="invite-role" className="text-xs font-medium text-foreground">Role</label>
              <Select value={inviteRole} onValueChange={(v) => setInviteRole(v as Role)}>
                <SelectTrigger id="invite-role" className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin · full access</SelectItem>
                  <SelectItem value="member">Member · read + write</SelectItem>
                  <SelectItem value="viewer">Viewer · read only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setInviteOpen(false)}>Cancel</Button>
            <Button onClick={sendInvite}>Send invite</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Remove confirm */}
      <Dialog open={removing !== null} onOpenChange={(o) => !o && setRemoving(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Remove {removing?.name}?</DialogTitle>
            <DialogDescription>
              They will lose access to this workspace immediately. Their activity history will be retained.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRemoving(null)}>Keep</Button>
            <Button variant="destructive" onClick={() => {
              setMembers((prev) => prev.filter((m) => m.id !== removing?.id));
              toast.success(`${removing?.name} removed from team`);
              setRemoving(null);
            }}>Remove</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}

function ApiKeysSection() {
  const [keys, setKeys] = useState<ApiKey[]>(apiKeys);
  const [revealed, setRevealed] = useState<Record<string, string | null>>({});
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [newNameError, setNewNameError] = useState("");
  const [revoking, setRevoking] = useState<ApiKey | null>(null);

  function createKey() {
    if (newName.trim().length < 2) {
      setNewNameError("Give your key a name of at least 2 characters.");
      return;
    }
    const full = `ns_live_${Math.random().toString(36).slice(2, 18)}${Math.random().toString(36).slice(2, 18)}`;
    const newKey: ApiKey = {
      id: `key_${Date.now()}`,
      name: newName.trim(),
      prefix: "ns_live_",
      masked: `${full.slice(0, 8)}${"•".repeat(16)}${full.slice(-4)}`,
      createdAt: new Date().toISOString(),
      lastUsedAt: null,
      scopes: ["read", "write"],
    };
    setKeys((prev) => [newKey, ...prev]);
    setRevealed((prev) => ({ ...prev, [newKey.id]: full }));
    setNewName("");
    setNewNameError("");
    setCreating(false);
    toast.success("API key created");
  }

  return (
    <section className="rounded-lg surface-card">
      <div className="flex items-center justify-between border-b border-border p-4">
        <div className="flex items-center gap-2">
          <KeyRound className="h-4 w-4 text-muted-foreground" />
          <div>
            <h3 className="text-sm font-semibold text-foreground">API keys</h3>
            <p className="text-xs text-muted-foreground">Use keys to authenticate API requests</p>
          </div>
        </div>
        <Button size="sm" className="gap-1.5" onClick={() => setCreating(true)}>
          <Plus className="h-3.5 w-3.5" /> Create key
        </Button>
      </div>
      <ul className="divide-y divide-border">
        {keys.map((k) => {
          const shown = revealed[k.id];
          return (
            <li key={k.id} className="p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-foreground">{k.name}</p>
                    {k.scopes.map((s) => (
                      <Badge key={s} variant="secondary" className="text-[10px]">{s}</Badge>
                    ))}
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <code className="rounded bg-muted/60 px-2 py-1 text-xs font-mono text-foreground/90 tabular-nums">
                      {shown ?? k.masked}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-muted-foreground"
                      aria-label={shown ? "Hide key" : "Reveal key"}
                      onClick={() => setRevealed((prev) => ({ ...prev, [k.id]: prev[k.id] ? null : k.masked }))}
                    >
                      {shown ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-muted-foreground"
                      aria-label="Copy key"
                      onClick={() => { navigator.clipboard?.writeText(shown ?? k.masked); toast.success("Copied to clipboard"); }}
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Created {formatRelativeTime(k.createdAt)} · {k.lastUsedAt ? `last used ${formatRelativeTime(k.lastUsedAt)}` : "never used"}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs text-destructive hover:text-destructive"
                  onClick={() => setRevoking(k)}
                >
                  Revoke
                </Button>
              </div>
            </li>
          );
        })}
        {keys.length === 0 && (
          <li className="p-8 text-center text-sm text-muted-foreground">No API keys. Create one to get started.</li>
        )}
      </ul>

      {/* Create dialog */}
      <Dialog open={creating} onOpenChange={(o) => { setCreating(o); if (!o) { setNewName(""); setNewNameError(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Create API key</DialogTitle>
            <DialogDescription>Keys are shown only once after creation. Store them somewhere safe.</DialogDescription>
          </DialogHeader>
          <div>
            <label htmlFor="key-name" className="text-xs font-medium text-foreground">Key name</label>
            <Input
              id="key-name"
              value={newName}
              onChange={(e) => { setNewName(e.target.value); setNewNameError(""); }}
              placeholder="e.g. Production server"
              className={cn("mt-1", newNameError && "border-destructive focus-visible:ring-destructive")}
              aria-invalid={!!newNameError}
              onKeyDown={(e) => { if (e.key === "Enter") createKey(); }}
            />
            {newNameError && <p className="mt-1 text-xs text-destructive">{newNameError}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreating(false)}>Cancel</Button>
            <Button onClick={createKey}>Create key</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Revoke dialog */}
      <Dialog open={revoking !== null} onOpenChange={(o) => !o && setRevoking(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Revoke &quot;{revoking?.name}&quot;?</DialogTitle>
            <DialogDescription>
              Any service using this key will stop working immediately. This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRevoking(null)}>Keep</Button>
            <Button variant="destructive" onClick={() => {
              setKeys((prev) => prev.filter((k) => k.id !== revoking?.id));
              toast.success("API key revoked");
              setRevoking(null);
            }}>Revoke key</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}

function NotificationsSection() {
  const [prefs, setPrefs] = useState<NotificationPrefs>(defaultNotificationPrefs);

  return (
    <section className="rounded-lg surface-card p-5">
      <div className="mb-4 flex items-center gap-2">
        <UserCog className="h-4 w-4 text-muted-foreground" />
        <div>
          <h3 className="text-sm font-semibold text-foreground">Notification preferences</h3>
          <p className="text-xs text-muted-foreground">Control which emails you receive from Northstar</p>
        </div>
      </div>
      <ul className="divide-y divide-border">
        {NOTIFICATION_FIELDS.map((f) => (
          <li key={f.key} className="flex items-center justify-between py-3">
            <div className="pr-4">
              <p className="text-sm font-medium text-foreground">{f.label}</p>
              <p className="text-xs text-muted-foreground">{f.description}</p>
            </div>
            <Switch
              checked={prefs[f.key]}
              onCheckedChange={(v) => {
                setPrefs((prev) => ({ ...prev, [f.key]: v }));
                toast.success(`${f.label} ${v ? "enabled" : "disabled"}`);
              }}
              aria-label={f.label}
            />
          </li>
        ))}
      </ul>
      <div className="mt-4 flex items-center gap-2">
        <Button size="sm" onClick={() => toast.success("Preferences saved")}>Save preferences</Button>
        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
          <Check className="h-3 w-3 text-success" /> Auto-saved on toggle
        </span>
      </div>
    </section>
  );
}

export { ProfileSection, TeamSection, ApiKeysSection, NotificationsSection };

export function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Settings</h2>
        <p className="text-sm text-muted-foreground">Manage your profile, team, API keys, and notification preferences.</p>
      </div>
      <ProfileSection />
      <TeamSection />
      <ApiKeysSection />
      <NotificationsSection />
    </div>
  );
}
