/**
 * Real payment card brand icons.
 *
 * Each brand has an inline SVG component (no external dependencies).
 * Used by the Billing page's payment method list.
 *
 * SVGs are simplified but recognizable brand marks:
 *   - Visa: blue "VISA" wordmark with the iconic stripe
 *   - Mastercard: two overlapping circles (red + yellow)
 *   - Amex: blue box with "AMEX" text
 *   - Discover: orange "Discover" wordmark
 *
 * All icons inherit `currentColor` for any monochrome portions and use
 * brand-accurate colors for the colored portions.
 */

import type { SVGProps } from "react";

export type CardBrand = "visa" | "mastercard" | "amex" | "discover" | "unknown";

interface BrandMeta {
  label: string;
  /** Last-4 prefix matcher — first 1–4 digits of the card number. */
  matchers: string[];
}

export const CARD_BRANDS: Record<CardBrand, BrandMeta> = {
  visa: { label: "Visa", matchers: ["4"] },
  mastercard: { label: "Mastercard", matchers: ["51", "52", "53", "54", "55", "22", "23", "24", "25", "26", "27"] },
  amex: { label: "American Express", matchers: ["34", "37"] },
  discover: { label: "Discover", matchers: ["6011", "65", "644", "645", "646", "647", "648", "649"] },
  unknown: { label: "Card", matchers: [] },
};

export function detectBrand(cardNumber: string): CardBrand {
  const digits = cardNumber.replace(/\D/g, "");
  for (const key of Object.keys(CARD_BRANDS) as CardBrand[]) {
    if (key === "unknown") continue;
    const meta = CARD_BRANDS[key];
    if (meta.matchers.some((m) => digits.startsWith(m))) return key;
  }
  return "unknown";
}

// ── Visa ─────────────────────────────────────────────────────────────────────
// Blue oval-less wordmark with the angled "V" swoosh.
export function VisaIcon({ className = "", ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 48 32" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Visa" {...props}>
      <rect width="48" height="32" rx="4" fill="#1A1F71" />
      <path
        d="M19.6 21.5h-2.4l1.5-9h2.4l-1.5 9zM12.3 21.5l-2.3-6.5-.4 1.6c-.5 1.6-1.4 2.9-2.5 3.5l2.4-7.5h2.6l3.4 9h-2.7zM30.6 21.5c-.6.2-1.3.3-2 .3-2.5 0-4-1.3-4-3.6 0-2.8 2-4.8 5-4.8 1.4 0 2.5.3 3 .7l-.7 1.7c-.5-.2-1.1-.4-1.9-.4-1.5 0-2.6.9-2.6 2.4 0 1.4 1 2 2.2 2 .8 0 1.4-.2 1.9-.4l.6 1.7-.5.5zM38.4 21.5h-2.6l-.5-1.4h-3.3l-.5 1.4H29l3-7.7c.3-.7.7-1 1.5-1h1.6l2.3 8.7zm-3.5-3.3l-.7-2.3c-.2-.5-.3-.9-.4-1.4-.1.5-.3.9-.4 1.4l-.7 2.3h2.2z"
        fill="#fff"
      />
      <path d="M16.5 12.5h-2.6c-.7 0-1.2.4-1.5 1l-3 8h2.6l.5-1.4h3.3l.5 1.4h2.6l-2.4-9z" fill="#fff" opacity="0" />
    </svg>
  );
}

// ── Mastercard ───────────────────────────────────────────────────────────────
// Two overlapping circles: red (left) + yellow (orange) (right).
export function MastercardIcon({ className = "", ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 48 32" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Mastercard" {...props}>
      <rect width="48" height="32" rx="4" fill="#1A1F71" />
      <circle cx="20" cy="16" r="6.5" fill="#EB001B" />
      <circle cx="28" cy="16" r="6.5" fill="#F79E1B" />
      <path
        d="M24 10.5a6.5 6.5 0 010 11 6.5 6.5 0 000-11z"
        fill="#FF5F00"
      />
    </svg>
  );
}

// ── American Express ─────────────────────────────────────────────────────────
// Blue background with white "AMEX" text in a bold sans-serif.
export function AmexIcon({ className = "", ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 48 32" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="American Express" {...props}>
      <rect width="48" height="32" rx="4" fill="#2E77BB" />
      <path
        d="M9 13.5l-2 4.5h4l-2-4.5zM40 12.5h-7v7h7v-2h-4.5v-1H40v-1.5h-4.5v-1H40v-1.5zM24 12.5h-2.5l-1.5 1.5-1.5-1.5H14v7h5l1.5-1.5 1.5 1.5h3v-2l2-2v4h2.5v-7h-2.5l-2 2v-2zm-3 5.5h-1.5l-.5-1H17l-.5 1h-1v-4h1l1.5 2 1.5-2h1v4zm12-4h1.5v4h-1.5v-4z"
        fill="#fff"
      />
    </svg>
  );
}

// ── Discover ─────────────────────────────────────────────────────────────────
// Orange "Discover" wordmark with the iconic circle.
export function DiscoverIcon({ className = "", ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 48 32" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Discover" {...props}>
      <rect width="48" height="32" rx="4" fill="#fff" />
      <rect x="0" y="0" width="48" height="32" rx="4" fill="#231F20" opacity="0.05" />
      <circle cx="38" cy="16" r="6" fill="#F76B1C" />
      <path
        d="M6 14.5c0-.7.5-1.2 1.3-1.2.8 0 1.3.5 1.3 1.2 0 .7-.5 1.2-1.3 1.2-.8 0-1.3-.5-1.3-1.2zm.2 1.8h2.2v6H6.2v-6zm5-1.8c0-.4.4-.7.9-.7s.9.3.9.7-.4.7-.9.7-.9-.3-.9-.7zm.1 1.8h2.2v6h-2.2v-6zm3.5 3c0-1.9 1.4-3.2 3.3-3.2 1.3 0 2 .5 2.4 1.2l-1.5 1c-.2-.4-.5-.6-.9-.6-.6 0-1 .5-1 1.6s.4 1.6 1 1.6c.4 0 .7-.2.9-.6l1.5 1c-.4.7-1.1 1.2-2.4 1.2-1.9 0-3.3-1.3-3.3-3.2zm7.5-3h2.2v6h-2.2v-6zm0-2.5h2.2v1.7h-2.2v-1.7z"
        fill="#231F20"
      />
    </svg>
  );
}

// ── Unknown / generic card ───────────────────────────────────────────────────
// Used when the brand can't be detected.
export function UnknownCardIcon({ className = "", ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 48 32" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Card" {...props}>
      <rect width="48" height="32" rx="4" fill="#374151" />
      <rect x="4" y="6" width="40" height="20" rx="2" fill="#1F2937" />
      <rect x="8" y="11" width="8" height="6" rx="1" fill="#FBBF24" />
      <rect x="20" y="20" width="20" height="2" rx="1" fill="#9CA3AF" />
    </svg>
  );
}

// ── Brand → icon resolver ────────────────────────────────────────────────────
export function CardBrandIcon({ brand, className, ...props }: { brand: CardBrand; className?: string } & SVGProps<SVGSVGElement>) {
  switch (brand) {
    case "visa": return <VisaIcon className={className} {...props} />;
    case "mastercard": return <MastercardIcon className={className} {...props} />;
    case "amex": return <AmexIcon className={className} {...props} />;
    case "discover": return <DiscoverIcon className={className} {...props} />;
    default: return <UnknownCardIcon className={className} {...props} />;
  }
}
