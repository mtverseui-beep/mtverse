"use client";

import { Area, AreaChart, ResponsiveContainer, Tooltip, YAxis } from "recharts";
import { ArrowUpRight, DollarSign, Sparkles, Users2, Repeat, Activity, TrendingUp, Zap } from "lucide-react";
import { useRouter } from "next/navigation";
import { useSimulatedFetch } from "@/hooks/use-dashboard";
import { kpiSnapshot, customers, invoices } from "@/lib/mock-data";
import { formatCurrency, formatNumber, formatPercent, formatRelativeTime, initials } from "@/lib/format";
import { Skeleton, ErrorState, TrendPill, AnimatedNumber, ModernCard, StaggerItem } from "./primitives";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import type { KpiSnapshot } from "@/lib/types";

function Sparkline({ data, ariaLabel }: { data: number[]; ariaLabel: string }) {
  const chartData = data.map((v, i) => ({ i, v }));
  return (
    <div className="h-14 w-full" aria-label={ariaLabel} role="img">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={chartData} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="sparkGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.4} />
              <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <YAxis hide domain={["dataMin", "dataMax"]} />
          <Tooltip
            cursor={false}
            contentStyle={{
              background: "var(--popover)",
              color: "var(--popover-foreground)",
              border: "1px solid var(--border)",
              borderRadius: 8,
              fontSize: 12,
              padding: "6px 10px",
              boxShadow: "0 8px 24px -8px rgb(0 0 0 / 0.18)",
            }}
            labelFormatter={() => ""}
            formatter={(value: number) => [formatCurrency(value, { compact: true }), "MRR"]}
          />
          <Area
            type="monotone"
            dataKey="v"
            stroke="var(--primary)"
            strokeWidth={2}
            fill="url(#sparkGrad)"
            isAnimationActive
            animationDuration={600}
            dot={false}
            activeDot={{ r: 3, fill: "var(--primary)", stroke: "var(--background)", strokeWidth: 2 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function HeroMrrCard({ snapshot }: { snapshot: KpiSnapshot }) {
  return (
    <ModernCard accent className="relative overflow-hidden p-6 md:col-span-2 lg:col-span-3 !cursor-default" hover={false}>
      <div className="absolute inset-0 bg-grid opacity-[0.35] pointer-events-none" aria-hidden />
      <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full bg-primary/10 blur-3xl pointer-events-none" aria-hidden />
      <div className="relative flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Monthly recurring revenue</span>
            <Badge variant="secondary" className="gap-1 text-[10px]">
              <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" /> Live
            </Badge>
          </div>
          <div className="flex items-baseline gap-3">
            <AnimatedNumber
              value={snapshot.mrr}
              format={(n) => formatCurrency(n)}
              className="text-4xl md:text-5xl font-semibold tracking-tight text-foreground"
            />
            <TrendPill value={snapshot.mrrDeltaPct} />
          </div>
          <p className="text-sm text-muted-foreground">
            <span className="text-foreground/80">{formatCurrency(snapshot.mrrDeltaPct / 100 * snapshot.mrr, { compact: true })}</span>
            {" "}vs. previous 30 days · projected {formatCurrency(snapshot.mrr * 1.084, { compact: true })} by next month
          </p>
        </div>
        <div className="w-full md:w-72 lg:w-80">
          <Sparkline data={snapshot.mrrSparkline} ariaLabel="MRR over the last 14 days" />
        </div>
      </div>
    </ModernCard>
  );
}

function SecondaryKpi({
  label,
  value,
  format,
  delta,
  invertColor,
  icon: Icon,
  hint,
  index,
}: {
  label: string;
  value: number;
  format: (n: number) => string;
  delta: number;
  invertColor?: boolean;
  icon: React.ComponentType<{ className?: string }>;
  hint: string;
  index: number;
}) {
  return (
    <StaggerItem index={index}>
      <ModernCard accent className="p-5 !cursor-default" hover>
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</span>
          <span className="grid h-7 w-7 place-items-center rounded-md bg-primary/10 text-primary">
            <Icon className="h-3.5 w-3.5" />
          </span>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <AnimatedNumber
            value={value}
            format={format}
            className="text-2xl font-semibold tracking-tight text-foreground"
          />
          <TrendPill value={delta} invertColor={invertColor} />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">{hint}</p>
      </ModernCard>
    </StaggerItem>
  );
}

function RecentActivity() {
  const router = useRouter();
  const recent = [...customers]
    .sort((a, b) => +new Date(b.lastSeen) - +new Date(a.lastSeen))
    .slice(0, 6);
  return (
    <ModernCard hover={false} className="!cursor-default">
      <div className="flex items-center justify-between border-b border-border p-4">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Recent activity</h3>
          <p className="text-xs text-muted-foreground">Latest account updates across your workspace</p>
        </div>
        <button
          onClick={() => router.push("/customers")}
          className="text-xs text-primary hover:underline cursor-pointer"
        >
          View all
        </button>
      </div>
      <ul className="divide-y divide-border">
        {recent.map((c, i) => {
          const verb =
            c.status === "trialing" ? "started a trial" :
            c.status === "past_due" ? "has an overdue invoice" :
            c.status === "churned" ? "churned" :
            c.status === "canceled" ? "canceled their subscription" :
            "upgraded their plan";
          return (
            <motion.li
              key={c.id}
              initial={{ opacity: 0, x: -6 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.24, delay: Math.min(i * 0.04, 0.24) }}
              className="flex items-center gap-3 p-4 hover:bg-muted/40 transition-colors cursor-pointer"
            >
              <Avatar className="h-8 w-8 border border-border shrink-0">
                <AvatarImage src={c.avatarUrl} alt={c.contactName} />
                <AvatarFallback className="text-[10px] font-semibold" style={{ background: `${c.logoColor}20`, color: c.logoColor }}>
                  {initials(c.contactName)}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <p className="text-sm text-foreground truncate">
                  <span className="font-medium">{c.company}</span>{" "}
                  <span className="text-muted-foreground">{verb}</span>
                </p>
                <p className="truncate text-xs text-muted-foreground">{c.contactName} · {c.plan} plan</p>
              </div>
              <span className="shrink-0 text-xs text-muted-foreground">{formatRelativeTime(c.lastSeen)}</span>
            </motion.li>
          );
        })}
      </ul>
    </ModernCard>
  );
}

function UpcomingInvoices() {
  const upcoming = invoices.filter((i) => i.status === "open").slice(0, 5);
  return (
    <ModernCard hover={false} className="!cursor-default">
      <div className="flex items-center justify-between border-b border-border p-4">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Upcoming invoices</h3>
          <p className="text-xs text-muted-foreground">Open invoices awaiting payment</p>
        </div>
        <Badge variant="secondary" className="text-[10px]">{upcoming.length} open</Badge>
      </div>
      <ul className="divide-y divide-border">
        {upcoming.map((inv) => (
          <li key={inv.id} className="flex items-center justify-between p-4 hover:bg-muted/40 transition-colors cursor-pointer">
            <div className="min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{inv.customer}</p>
              <p className="text-xs text-muted-foreground font-mono">{inv.number} · {formatRelativeTime(inv.issuedAt)}</p>
            </div>
            <span className="text-sm font-semibold tabular-nums text-foreground">{formatCurrency(inv.amount)}</span>
          </li>
        ))}
        {upcoming.length === 0 && (
          <li className="p-6 text-center text-sm text-muted-foreground">No open invoices.</li>
        )}
      </ul>
    </ModernCard>
  );
}

const QUICK_LINKS: { label: string; hint: string; icon: typeof DollarSign; path: string }[] = [
  { label: "View analytics", hint: "Revenue & cohort breakdowns", icon: TrendingUp, path: "/analytics" },
  { label: "Manage customers", hint: "Search & filter accounts", icon: Users2, path: "/customers" },
  { label: "Upgrade plan", hint: "Scale or Enterprise", icon: Zap, path: "/billing" },
  { label: "Team settings", hint: "Invite teammates & roles", icon: Sparkles, path: "/settings/team" },
];

export function OverviewPage() {
  const { status, data, error, retry } = useSimulatedFetch<KpiSnapshot>(() => kpiSnapshot, { delay: 500, deps: [] });
  const router = useRouter();

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {status === "loading" && (
          <>
            <Skeleton className="h-44 md:col-span-2 lg:col-span-3" />
            <Skeleton className="h-44" />
            <Skeleton className="h-44" />
            <Skeleton className="h-44" />
            <Skeleton className="h-44" />
          </>
        )}
        {status === "error" && (
          <div className="md:col-span-2 lg:col-span-4">
            <ErrorState message={error ?? "Failed to load KPIs"} onRetry={retry} />
          </div>
        )}
        {status === "success" && data && (
          <>
            <HeroMrrCard snapshot={data} />
            <SecondaryKpi
              index={0}
              label="Active subscribers"
              value={data.activeSubscribers}
              format={(n) => formatNumber(Math.round(n))}
              delta={data.activeSubscribersDeltaPct}
              icon={Users2}
              hint={`${formatNumber(data.activeSubscribers + Math.round(data.activeSubscribers * 0.04))} projected next month`}
            />
            <SecondaryKpi
              index={1}
              label="Churn rate"
              value={data.churnRate}
              format={(n) => formatPercent(n)}
              delta={data.churnDeltaPct}
              invertColor
              icon={Repeat}
              hint="Below the 3% industry benchmark"
            />
            <SecondaryKpi
              index={2}
              label="Trial → paid"
              value={data.conversionRate}
              format={(n) => formatPercent(n)}
              delta={data.conversionDeltaPct}
              icon={Activity}
              hint="Up from 13.4% last month"
            />
          </>
        )}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <RecentActivity />
        </div>
        <div>
          <UpcomingInvoices />
        </div>
      </div>

      {/* Quick links — now actually navigate */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">Jump to</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {QUICK_LINKS.map((q, i) => {
            const Icon = q.icon;
            return (
              <StaggerItem key={q.label} index={i}>
                <ModernCard accent className="p-4">
                  <button
                    onClick={() => router.push(q.path)}
                    className="group flex items-center gap-3 text-left w-full cursor-pointer"
                  >
                    <span className="grid h-9 w-9 place-items-center rounded-md bg-primary/10 text-primary shrink-0">
                      <Icon className="h-4 w-4" />
                    </span>
                    <span className="flex-1 min-w-0">
                      <span className="block text-sm font-medium text-foreground">{q.label}</span>
                      <span className="block text-xs text-muted-foreground truncate">{q.hint}</span>
                    </span>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 shrink-0" />
                  </button>
                </ModernCard>
              </StaggerItem>
            );
          })}
        </div>
      </div>
    </div>
  );
}
