"use client";

import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { funnelStages, planDistribution, revenueByRange } from "@/lib/mock-data";
import { useNav, useSimulatedFetch } from "@/hooks/use-dashboard";
import type { RangeKey, RevenuePoint } from "@/lib/types";
import { Skeleton, ErrorState, EmptyState, AnimatedNumber, ModernCard, StaggerItem } from "./primitives";
import { formatCurrency, formatDate, formatNumber, formatPercent } from "@/lib/format";
import { BarChart3, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

const RANGE_LABELS: { id: RangeKey; label: string }[] = [
  { id: "7d", label: "7D" },
  { id: "30d", label: "30D" },
  { id: "90d", label: "90D" },
  { id: "1y", label: "1Y" },
];

function RangeToggle() {
  const { range, setRange } = useNav();
  return (
    <div
      role="tablist"
      aria-label="Time range"
      className="inline-flex items-center rounded-md border border-border bg-muted/40 p-0.5"
    >
      {RANGE_LABELS.map((r) => {
        const active = range === r.id;
        return (
          <button
            key={r.id}
            role="tab"
            aria-selected={active}
            onClick={() => setRange(r.id)}
            className={cn(
              "relative h-7 px-3 rounded text-xs font-medium transition-colors cursor-pointer",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              active ? "text-foreground" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {active && (
              <motion.span
                layoutId="range-active"
                className="absolute inset-0 rounded bg-background shadow-sm"
                transition={{ type: "spring", damping: 24, stiffness: 320 }}
                aria-hidden
              />
            )}
            <span className="relative z-10">{r.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function ChartCard({ title, description, action, children, index = 0 }: { title: string; description?: string; action?: React.ReactNode; children: React.ReactNode; index?: number }) {
  return (
    <StaggerItem index={index}>
      <ModernCard hover={false} className="!cursor-default">
        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-border p-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground">{title}</h3>
            {description && <p className="text-xs text-muted-foreground">{description}</p>}
          </div>
          {action}
        </div>
        <div className="p-4">{children}</div>
      </ModernCard>
    </StaggerItem>
  );
}

const tooltipStyle = {
  background: "var(--popover)",
  color: "var(--popover-foreground)",
  border: "1px solid var(--border)",
  borderRadius: 8,
  fontSize: 12,
  padding: "8px 10px",
  boxShadow: "0 8px 24px -8px rgb(0 0 0 / 0.18)",
};

function RevenueChart({ data, range }: { data: RevenuePoint[]; range: RangeKey }) {
  const xFmt = (v: string) => {
    const d = new Date(v);
    if (range === "1y") return d.toLocaleDateString("en-US", { month: "short" });
    if (range === "90d") return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  return (
    <div className="h-72 w-full" role="img" aria-label="Revenue trend chart">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="mrrGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.4} />
              <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="date"
            tickFormatter={xFmt}
            tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
            axisLine={{ stroke: "var(--border)" }}
            tickLine={false}
            minTickGap={24}
          />
          <YAxis
            tickFormatter={(v: number) => formatCurrency(v, { compact: true })}
            tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            width={56}
          />
          <Tooltip
            cursor={{ stroke: "var(--primary)", strokeDasharray: 3, strokeOpacity: 0.4 }}
            contentStyle={tooltipStyle}
            labelFormatter={(label: string) => formatDate(label, { weekday: "short", month: "short", day: "numeric", year: "numeric" })}
            formatter={(value: number, name: string) => {
              const labels: Record<string, string> = { mrr: "MRR", newMrr: "New", expansionMrr: "Expansion", churnedMrr: "Churned" };
              return [formatCurrency(value), labels[name] ?? name];
            }}
          />
          <Area
            type="monotone"
            dataKey="mrr"
            stroke="var(--primary)"
            strokeWidth={2.5}
            fill="url(#mrrGrad)"
            isAnimationActive
            animationDuration={650}
            dot={false}
            activeDot={{ r: 5, fill: "var(--primary)", stroke: "var(--background)", strokeWidth: 2 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function MrrBreakdownChart({ data, range }: { data: RevenuePoint[]; range: RangeKey }) {
  const xFmt = (v: string) => {
    const d = new Date(v);
    if (range === "1y") return d.toLocaleDateString("en-US", { month: "short" });
    if (range === "90d") return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };
  return (
    <div className="h-56 w-full" role="img" aria-label="MRR breakdown chart">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }} barCategoryGap="20%">
          <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="date" tickFormatter={xFmt} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={{ stroke: "var(--border)" }} tickLine={false} minTickGap={24} />
          <YAxis tickFormatter={(v: number) => formatCurrency(v, { compact: true })} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} width={56} />
          <Tooltip
            cursor={{ fill: "var(--muted)", opacity: 0.4 }}
            contentStyle={tooltipStyle}
            labelFormatter={(label: string) => formatDate(label, { month: "short", day: "numeric", year: "numeric" })}
            formatter={(value: number, name: string) => [formatCurrency(value), name === "newMrr" ? "New" : name === "expansionMrr" ? "Expansion" : "Churned"]}
          />
          <Legend wrapperStyle={{ fontSize: 11, color: "var(--muted-foreground)" }} formatter={(v: string) => (v === "newMrr" ? "New" : v === "expansionMrr" ? "Expansion" : "Churned")} />
          <Bar dataKey="newMrr" stackId="mrr" fill="var(--chart-1)" isAnimationActive animationDuration={500} radius={[0, 0, 0, 0]} />
          <Bar dataKey="expansionMrr" stackId="mrr" fill="var(--chart-2)" isAnimationActive animationDuration={500} radius={[0, 0, 0, 0]} />
          <Bar dataKey="churnedMrr" stackId="mrr" fill="var(--chart-5)" radius={[3, 3, 0, 0]} isAnimationActive animationDuration={500} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function FunnelChart() {
  const max = funnelStages[0].count;
  return (
    <ol className="space-y-3">
      {funnelStages.map((s, i) => {
        const widthPct = (s.count / max) * 100;
        const prevCount = i > 0 ? funnelStages[i - 1].count : max;
        const stepConv = (s.count / prevCount) * 100;
        return (
          <motion.li
            key={s.stage}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.32, delay: i * 0.06 }}
            className="space-y-1"
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-foreground">{s.stage}</span>
              <span className="tabular-nums text-muted-foreground">
                {formatNumber(s.count)} · {formatPercent(stepConv)} step
              </span>
            </div>
            <div className="h-7 w-full rounded-md bg-muted/60 overflow-hidden">
              <motion.div
                className="h-full rounded-md"
                style={{
                  background: "linear-gradient(90deg, var(--primary), color-mix(in oklch, var(--primary) 60%, var(--chart-2)))",
                }}
                initial={{ width: 0 }}
                animate={{ width: `${widthPct}%` }}
                transition={{ duration: 0.6, delay: i * 0.08, ease: "easeOut" }}
              />
            </div>
          </motion.li>
        );
      })}
    </ol>
  );
}

function PlanDistributionChart() {
  const [activePlan, setActivePlan] = useState<string | null>(null);
  const total = planDistribution.reduce((s, p) => s + p.count, 0);
  const active = activePlan ? planDistribution.find((p) => p.plan === activePlan) : null;
  return (
    <div className="flex flex-col sm:flex-row items-center gap-6">
      <div className="h-44 w-44 relative shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={planDistribution}
              dataKey="count"
              nameKey="label"
              innerRadius={48}
              outerRadius={70}
              paddingAngle={2}
              stroke="none"
              isAnimationActive
              animationDuration={600}
              onMouseEnter={(_, i) => setActivePlan(planDistribution[i].plan)}
              onMouseLeave={() => setActivePlan(null)}
            >
              {planDistribution.map((p) => (
                <Cell
                  key={p.plan}
                  fill={p.color}
                  fillOpacity={activePlan && activePlan !== p.plan ? 0.35 : 1}
                  style={{ transition: "fill-opacity 0.18s ease-out", cursor: "pointer" }}
                />
              ))}
            </Pie>
            <Tooltip
              contentStyle={tooltipStyle}
              formatter={(value: number, _name: string, item: { payload?: { label?: string; mrr?: number } }) => [
                `${formatNumber(value)} customers`,
                item?.payload?.label ?? "",
              ]}
            />
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 grid place-items-center pointer-events-none">
          <div className="text-center">
            {active ? (
              <>
                <p className="text-xl font-semibold tabular-nums text-foreground">{formatNumber(active.count, true)}</p>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{active.label}</p>
              </>
            ) : (
              <>
                <p className="text-xl font-semibold tabular-nums text-foreground">{formatNumber(total, true)}</p>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">customers</p>
              </>
            )}
          </div>
        </div>
      </div>
      <ul className="flex-1 w-full space-y-2">
        {planDistribution.map((p, i) => {
          const pct = (p.count / total) * 100;
          const isActive = activePlan === p.plan;
          return (
            <motion.li
              key={p.plan}
              initial={{ opacity: 0, x: 6 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.24, delay: i * 0.04 }}
              className={cn(
                "flex items-center gap-3 text-sm rounded-md px-2 py-1.5 transition-colors cursor-pointer",
                isActive ? "bg-muted/60" : "hover:bg-muted/40",
              )}
              onMouseEnter={() => setActivePlan(p.plan)}
              onMouseLeave={() => setActivePlan(null)}
            >
              <span className="h-2.5 w-2.5 rounded-sm shrink-0" style={{ background: p.color }} aria-hidden />
              <span className="flex-1 text-foreground">{p.label}</span>
              <span className="tabular-nums text-muted-foreground">{formatNumber(p.count)} ({formatPercent(pct, 0)})</span>
              <span className="tabular-nums text-muted-foreground w-20 text-right">{formatCurrency(p.mrr, { compact: true })}</span>
            </motion.li>
          );
        })}
      </ul>
    </div>
  );
}

export function AnalyticsPage() {
  const { range } = useNav();
  const { status, data, error, retry } = useSimulatedFetch<RevenuePoint[]>(
    () => revenueByRange[range],
    { delay: 400, deps: [range] },
  );

  const totals = useMemo(() => {
    if (!data) return { newMrr: 0, expansion: 0, churn: 0, net: 0 };
    const newMrr = data.reduce((s, d) => s + d.newMrr, 0);
    const expansion = data.reduce((s, d) => s + d.expansionMrr, 0);
    const churn = data.reduce((s, d) => s + d.churnedMrr, 0);
    return { newMrr, expansion, churn, net: newMrr + expansion - churn };
  }, [data]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Revenue analytics</h2>
          <p className="text-sm text-muted-foreground">Track how revenue moves across plans, cohorts, and time.</p>
        </div>
        <RangeToggle />
      </div>

      {/* Summary stats strip with count-up */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        {[
          { label: "New MRR", value: totals.newMrr, hint: "First-time subscriptions", tone: "text-success" },
          { label: "Expansion MRR", value: totals.expansion, hint: "Seats & upgrades", tone: "text-chart-2" },
          { label: "Churned MRR", value: -totals.churn, hint: "Lost this period", tone: "text-destructive" },
          { label: "Net new MRR", value: totals.net, hint: "After churn", tone: "text-foreground" },
        ].map((s, i) => (
          <StaggerItem key={s.label} index={i}>
            <ModernCard accent className="p-4 !cursor-default" hover>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">{s.label}</p>
              <AnimatedNumber
                value={s.value}
                format={(n) => formatCurrency(n, { compact: true })}
                className={cn("mt-1 text-xl font-semibold tabular-nums block", s.tone)}
              />
              <p className="mt-1 text-xs text-muted-foreground">{s.hint}</p>
            </ModernCard>
          </StaggerItem>
        ))}
      </div>

      {status === "loading" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-80 lg:col-span-2" />
          <Skeleton className="h-80" />
        </div>
      )}
      {status === "error" && <ErrorState message={error ?? "Failed to load revenue data"} onRetry={retry} />}
      {status === "success" && data && data.length === 0 && (
        <EmptyState
          title="No revenue data for this range"
          description="Try selecting a wider time window, or check your data pipeline."
          icon={<BarChart3 className="h-8 w-8" />}
        />
      )}
      {status === "success" && data && data.length > 0 && (
        <>
          <ChartCard index={0} title="MRR trend" description={`Monthly recurring revenue over the selected range · ${range.toUpperCase()}`}>
            <RevenueChart data={data} range={range} />
          </ChartCard>

          <div className="grid gap-4 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <ChartCard index={1} title="MRR breakdown" description="New vs expansion vs churned MRR per period">
                <MrrBreakdownChart data={data} range={range} />
              </ChartCard>
            </div>
            <ChartCard index={2} title="Conversion funnel" description="Visited → Paid, current period">
              <FunnelChart />
            </ChartCard>
          </div>

          <ChartCard index={3} title="Plan distribution" description="Hover a slice or row to highlight a plan">
            <PlanDistributionChart />
          </ChartCard>
        </>
      )}

      {/* Insights footer — no dead space */}
      {status === "success" && data && (
        <ModernCard hover={false} className="!cursor-default p-4 flex flex-wrap items-center gap-3">
          <span className="grid h-8 w-8 place-items-center rounded-md bg-primary/10 text-primary shrink-0">
            <TrendingUp className="h-4 w-4" />
          </span>
          <p className="text-sm text-foreground flex-1 min-w-0">
            <span className="font-medium">Insight:</span>{" "}
            Net MRR grew {formatPercent((totals.net / Math.max(1, totals.newMrr + totals.expansion - totals.net)) * 100, 1)} this period.
            {totals.churn > totals.expansion
              ? " Churn is outpacing expansion — consider a save campaign for at-risk accounts."
              : " Expansion is outpacing churn — momentum is healthy."}
          </p>
        </ModernCard>
      )}
    </div>
  );
}
