"use client";

import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/hooks/use-theme";

/**
 * Theme toggle — topbar icon button.
 *
 * Uses the shared `useTheme` hook so it stays in sync with the ProfileMenu's
 * theme toggle and any other component that flips the `dark` class.
 *
 * We intentionally avoid a "mounted" placeholder to keep the toggle
 * keyboard-accessible from first paint. The icon uses suppressHydrationWarning
 * because the SSR-rendered icon (Sun, matching default dark) may briefly differ
 * from the client if the user has light mode stored.
 */
export function ThemeToggle() {
  const { isDark, toggle } = useTheme();

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggle}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      aria-pressed={!isDark}
      className="icon-btn text-muted-foreground hover:text-foreground cursor-pointer"
    >
      <span suppressHydrationWarning>
        {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </span>
    </Button>
  );
}
