"use client";

import { useRouter } from "next/navigation";
import {
  ChevronDown,
  CreditCard,
  LifeBuoy,
  LogOut,
  Moon,
  Settings,
  Sun,
  User,
  Keyboard,
  BookOpen,
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useTheme } from "@/hooks/use-theme";
import { currentUser } from "@/lib/mock-data";
import { toast } from "sonner";

/**
 * Profile dropdown — opens from the avatar in the topbar.
 *
 * All items navigate via the Next.js router:
 *   - Profile      → /settings/profile
 *   - Billing      → /billing
 *   - Settings     → /settings
 *   - Help docs    → /docs
 *   - Support      → /support
 *   - Sign out     → /signin (after confirm)
 *
 * Keyboard shortcuts shown (⇧⌘P, ⌘B, ⌘,) are also globally registered
 * by `useGlobalShortcuts` in the dashboard layout — see app/(dashboard)/layout.tsx.
 */
export function ProfileMenu() {
  const router = useRouter();
  const { isDark, toggle: toggleTheme } = useTheme();
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [signOutOpen, setSignOutOpen] = useState(false);

  function goProfile() {
    router.push("/settings/profile");
  }
  function goBilling() {
    router.push("/billing");
  }
  function goSettings() {
    router.push("/settings");
  }
  function goDocs() {
    router.push("/docs");
  }
  function goSupport() {
    router.push("/support");
  }
  function signOut() {
    setSignOutOpen(false);
    toast.success("Signed out", { description: "Redirecting to sign in…" });
    window.setTimeout(() => router.push("/signin"), 600);
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            // Radix's DropdownMenuTrigger uses React 19's useId() to generate
            // the trigger's `id`. In Next.js 16 + Turbopack dev mode, useId can
            // produce different IDs on the server vs client when chunks reload
            // (intermittent, ~40% of reloads). The id is purely internal —
            // aria-controls is `undefined` while the menu is closed — so we
            // suppress the dev-only hydration warning. This is a no-op in
            // production builds (where useId is fully stable).
            suppressHydrationWarning
            className="group flex items-center gap-1.5 rounded-full p-0.5 pr-1.5 icon-btn hover:bg-muted/70 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring/40 cursor-pointer"
            aria-label="Open account menu"
          >
            <Avatar className="h-8 w-8 border border-border ring-2 ring-transparent transition group-hover:ring-primary/30">
              <AvatarImage src={currentUser.avatarUrl} alt={currentUser.name} />
              <AvatarFallback className="bg-primary/15 text-primary text-xs font-semibold">
                {currentUser.initials}
              </AvatarFallback>
            </Avatar>
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground transition-transform group-data-[state=open]:rotate-180" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align="end"
          sideOffset={8}
          className="w-64 surface-popover rounded-lg p-0 overflow-hidden"
        >
          {/* Header card */}
          <div className="flex items-center gap-3 p-3 bg-gradient-to-br from-primary/10 via-transparent to-transparent border-b border-border">
            <Avatar className="h-10 w-10 border border-border">
              <AvatarImage src={currentUser.avatarUrl} alt={currentUser.name} />
              <AvatarFallback className="bg-primary/15 text-primary text-sm font-semibold">
                {currentUser.initials}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-foreground">{currentUser.name}</p>
              <p className="truncate text-xs text-muted-foreground">{currentUser.email}</p>
            </div>
            <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-primary">
              {currentUser.role}
            </span>
          </div>

          <div className="p-1">
            <DropdownMenuLabel className="px-2 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Account
            </DropdownMenuLabel>
            <DropdownMenuGroup>
              <DropdownMenuItem
                onSelect={goProfile}
                className="gap-2.5 rounded-md px-2 py-1.5 text-sm focus:bg-muted/70 cursor-pointer"
              >
                <User className="h-4 w-4 text-muted-foreground" />
                <span>Profile</span>
                <DropdownMenuShortcut>⇧⌘P</DropdownMenuShortcut>
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={goBilling}
                className="gap-2.5 rounded-md px-2 py-1.5 text-sm focus:bg-muted/70 cursor-pointer"
              >
                <CreditCard className="h-4 w-4 text-muted-foreground" />
                <span>Billing</span>
                <DropdownMenuShortcut>⌘B</DropdownMenuShortcut>
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={goSettings}
                className="gap-2.5 rounded-md px-2 py-1.5 text-sm focus:bg-muted/70 cursor-pointer"
              >
                <Settings className="h-4 w-4 text-muted-foreground" />
                <span>Settings</span>
                <DropdownMenuShortcut>⌘,</DropdownMenuShortcut>
              </DropdownMenuItem>
            </DropdownMenuGroup>

            <DropdownMenuSeparator className="my-1" />

            <DropdownMenuLabel className="px-2 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Preferences
            </DropdownMenuLabel>
            <DropdownMenuItem
              onSelect={() => {
                toggleTheme();
                toast.success(isDark ? "Switched to light theme" : "Switched to dark theme");
              }}
              className="gap-2.5 rounded-md px-2 py-1.5 text-sm focus:bg-muted/70 cursor-pointer"
            >
              <span suppressHydrationWarning className="text-muted-foreground">
                {isDark ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              </span>
              <span suppressHydrationWarning>
                {isDark ? "Switch to light theme" : "Switch to dark theme"}
              </span>
            </DropdownMenuItem>
            <DropdownMenuItem
              onSelect={() => setShortcutsOpen(true)}
              className="gap-2.5 rounded-md px-2 py-1.5 text-sm focus:bg-muted/70 cursor-pointer"
            >
              <Keyboard className="h-4 w-4 text-muted-foreground" />
              <span>Keyboard shortcuts</span>
              <DropdownMenuShortcut>⌘K</DropdownMenuShortcut>
            </DropdownMenuItem>

            <DropdownMenuSeparator className="my-1" />

            <DropdownMenuItem
              onSelect={goDocs}
              className="gap-2.5 rounded-md px-2 py-1.5 text-sm focus:bg-muted/70 cursor-pointer"
            >
              <BookOpen className="h-4 w-4 text-muted-foreground" />
              <span>Help &amp; docs</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              onSelect={goSupport}
              className="gap-2.5 rounded-md px-2 py-1.5 text-sm focus:bg-muted/70 cursor-pointer"
            >
              <LifeBuoy className="h-4 w-4 text-muted-foreground" />
              <span>Contact support</span>
            </DropdownMenuItem>
            <DropdownMenuItem
              onSelect={() => setSignOutOpen(true)}
              className="gap-2.5 rounded-md px-2 py-1.5 text-sm focus:bg-destructive/10 focus:text-destructive text-destructive cursor-pointer"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign out</span>
            </DropdownMenuItem>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Keyboard shortcuts dialog — real reference, not just a toast */}
      <Dialog open={shortcutsOpen} onOpenChange={setShortcutsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Keyboard shortcuts</DialogTitle>
            <DialogDescription>
              Use these shortcuts to navigate Northstar faster. They work anywhere outside text inputs.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1">
            {[
              { keys: ["⌘", "K"], label: "Open command palette" },
              { keys: ["⇧", "⌘", "P"], label: "Go to Profile" },
              { keys: ["⌘", "B"], label: "Go to Billing" },
              { keys: ["⌘", ","], label: "Go to Settings" },
              { keys: ["?"], label: "Open support" },
              { keys: ["g", "h"], label: "Go to Overview (vim)" },
              { keys: ["g", "a"], label: "Go to Analytics" },
              { keys: ["g", "c"], label: "Go to Customers" },
              { keys: ["g", "b"], label: "Go to Billing" },
              { keys: ["g", "s"], label: "Go to Settings" },
              { keys: ["Esc"], label: "Close any dialog / panel" },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between rounded-md px-2 py-1.5 hover:bg-muted/50">
                <span className="text-sm text-foreground">{s.label}</span>
                <span className="flex items-center gap-0.5">
                  {s.keys.map((k, i) => (
                    <kbd key={i} className="inline-flex h-5 min-w-5 items-center justify-center rounded border border-border bg-muted px-1 text-[10px] font-medium text-foreground">
                      {k}
                    </kbd>
                  ))}
                </span>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button onClick={() => setShortcutsOpen(false)} className="cursor-pointer">Got it</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Sign out confirm */}
      <Dialog open={signOutOpen} onOpenChange={setSignOutOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Sign out?</DialogTitle>
            <DialogDescription>
              You&apos;ll need to sign back in to access your dashboard. Any unsaved drafts will be lost.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSignOutOpen(false)} className="cursor-pointer">Stay signed in</Button>
            <Button variant="destructive" onClick={signOut} className="cursor-pointer">Sign out</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
