# Northstar Analytics — SaaS Dashboard

A production-grade SaaS analytics dashboard template built with Next.js 16, TypeScript (strict), Tailwind CSS 4, shadcn/ui, and Recharts. Ships with deterministic mock data, real Next.js routes, illustrated face avatars (self-hosted SVG), and a full commercial license for use in one production project.

![Dashboard — dark mode](./marketing/screenshots/overview-dark.png)

## Screenshots

Real Playwright captures of every page in both dark and light mode live in [`marketing/screenshots/`](./marketing/screenshots/). Quick links:

| Page | Dark | Light |
|------|------|-------|
| Overview | [dark](./marketing/screenshots/overview-dark.png) | [light](./marketing/screenshots/overview-light.png) |
| Analytics | [dark](./marketing/screenshots/analytics-dark.png) | [light](./marketing/screenshots/analytics-light.png) |
| Customers | [dark](./marketing/screenshots/customers-dark.png) | [light](./marketing/screenshots/customers-light.png) |
| Billing | [dark](./marketing/screenshots/billing-dark.png) | [light](./marketing/screenshots/billing-light.png) |
| Settings — Profile | [dark](./marketing/screenshots/settings-profile-dark.png) | [light](./marketing/screenshots/settings-profile-light.png) |
| Settings — Team | [dark](./marketing/screenshots/settings-team-dark.png) | [light](./marketing/screenshots/settings-team-light.png) |
| Sign in | [dark](./marketing/screenshots/signin-dark.png) | [light](./marketing/screenshots/signin-light.png) |
| Support | [dark](./marketing/screenshots/support-dark.png) | [light](./marketing/screenshots/support-light.png) |
| Docs | [dark](./marketing/screenshots/docs-dark.png) | [light](./marketing/screenshots/docs-light.png) |

To regenerate: `bun scripts/screenshot-marketing.ts` (requires the dev server running on `:3000`).

## What's inside

- **Overview** — KPI cards (MRR, active subscribers, churn, conversion), revenue trend chart, recent activity feed, upcoming invoices, quick-action grid.
- **Analytics** — Range-toggleable revenue chart (7d / 30d / 90d / 1y), MRR breakdown (new / expansion / churned), signup funnel, plan distribution.
- **Customers** — Sortable / searchable / filterable data table with 247 deterministic customers, row selection, bulk actions, customer detail drawer, add-customer dialog.
- **Billing** — Plan cards (Free / Starter / Pro / Scale / Enterprise), usage meters, payment methods with real Visa / Mastercard / Amex / Discover card-brand SVGs (BIN-detected), invoice list with pay-now and remind-me actions.
- **Settings** — Profile, team (with role management), API keys (with rotation), notification preferences. Each section is its own route with its own metadata.
- **Auth pages** — Modern sign-in page (email + Google + GitHub + SAML SSO), support page (knowledge base + ticket form + ticket history), docs page (categorized articles with search).
- **Global** — Command palette (⌘K), keyboard shortcuts (⇧⌘P, ⌘B, ⌘,, g X vim nav), notifications panel, dark/light theme with cross-component sync, mobile-responsive sidebar drawer.

## Avatars

All avatars (current user + every customer + every team member) are **deterministic illustrated face avatars** generated locally as SVG data URLs — no external network dependency, no rate limits, works offline. Each seed produces a unique combination of:

- Gradient background (12 curated color pairs)
- Skin tone (7 tones)
- Hair color (10 colors)
- Hair style (8 styles: short, bob, afro, bald, ponytail, buzz, long, bun)
- Eye style (4 styles: dots, round, closed-happy, lashes)
- Mouth style (4 expressions: smile, soft-smile, neutral, smirk)
- Optional accessories: glasses (~22%), beard (~25%), earrings (~28%)

See [`src/lib/avatar.ts`](./src/lib/avatar.ts) for the generator.

## Tech stack

| Layer | Choice |
|-------|--------|
| Framework | Next.js 16 (App Router, Turbopack, standalone output) |
| Language | TypeScript (strict) |
| Styling | Tailwind CSS 4 + CSS variables (oklch color space) |
| UI primitives | shadcn/ui (Radix UI + CVA) |
| Icons | lucide-react |
| Charts | Recharts |
| Animations | Framer Motion |
| Notifications | Sonner |
| Fonts | Geist Sans + Geist Mono |
| Database ORM | Prisma (schema + client included; not wired to a live DB) |

## Project structure

```
src/
├── app/
│   ├── (dashboard)/         # Authenticated routes (shared layout: sidebar + topbar)
│   │   ├── page.tsx         # Overview
│   │   ├── analytics/
│   │   ├── customers/
│   │   ├── billing/
│   │   ├── settings/        # Settings root + sub-routes (profile, team, api-keys, notifications)
│   │   ├── layout.tsx       # Wraps routes with NavProvider + AppShell + CommandPalette
│   │   └── loading.tsx      # Dashboard loading skeleton
│   ├── signin/              # Modern admin sign-in (page.tsx + signin-client.tsx)
│   ├── support/             # Support / ticketing
│   ├── docs/                # Knowledge base
│   ├── error.tsx            # Global error boundary
│   ├── not-found.tsx        # Global 404
│   ├── layout.tsx           # Root layout (fonts, theme script, Toaster, SEO metadata)
│   └── globals.css          # Design tokens + utility classes
├── components/
│   ├── dashboard/           # Domain components (overview, customers, billing, etc.)
│   └── ui/                  # shadcn/ui primitives
├── hooks/                   # useTheme, useDashboard, useGlobalShortcuts, useMobile, useToast
└── lib/                     # avatar, format, mock-data, types, utils, db
```

## Getting started

```bash
# Install
bun install

# Dev
bun run dev          # http://localhost:3000

# Production build
bun run build
bun run start        # serves .next/standalone/server.js

# Lint + type check
bun run lint         # 0 errors, 0 warnings
bun run typecheck    # tsc --noEmit, clean
```

## Environment

Copy `.env.example` to `.env.local` and fill in what you need. All env vars are optional — the app ships with deterministic mock data and runs fully without them.

```bash
cp .env.example .env.local
```

Key vars: `NEXT_PUBLIC_APP_URL`, `DATABASE_URL`, `NEXTAUTH_SECRET`, `STRIPE_SECRET_KEY`, `SENTRY_DSN`.

## Production-readiness checklist

Verified post-cleanup on 2026-08-01:

- [x] TypeScript strict mode (`"strict": true` in `tsconfig.json`)
- [x] No `ignoreBuildErrors` in `next.config.ts` — TypeScript errors fail the build for real
- [x] `reactStrictMode: true`
- [x] ESLint passes clean: **0 errors, 0 warnings** (rules re-enabled: `no-explicit-any`, `no-unused-vars`, `no-non-null-assertion`, `react-hooks/exhaustive-deps`)
- [x] `tsc --noEmit` passes clean
- [x] Production build succeeds — 14 static routes + 1 dynamic (`/api`)
- [x] Global error boundary (`app/error.tsx`)
- [x] Global 404 page (`app/not-found.tsx`)
- [x] Dashboard loading skeleton (`app/(dashboard)/loading.tsx`)
- [x] SEO metadata at root (`metadataBase`, OpenGraph, Twitter cards, robots.txt, `manifest.webmanifest`)
- [x] Per-route `metadata` (title + description) on all 12 pages: dashboard routes, `/signin`, `/support`, `/docs`
- [x] Theme-color meta tags for light + dark
- [x] Web app manifest for PWA install
- [x] Self-hosted illustrated face avatars (no external image hosts, `images.remotePatterns: []`)
- [x] Real Next.js routes (not client-side view state)
- [x] Real keyboard shortcuts (globally registered, disabled in inputs)
- [x] Real payment card brand icons (Visa, MC, Amex, Discover with BIN detection)
- [x] Profile dropdown wired to real routes (`/settings/profile`, `/billing`, `/settings`, `/docs`, `/support`)
- [x] Mobile-responsive (sidebar drawer, responsive grids)
- [x] Dark/light theme with cross-component sync (no flash on load)
- [x] Accessibility: ARIA labels, keyboard nav, focus rings, semantic HTML
- [x] Standalone build output for Docker / containerized deployment
- [x] `optimizePackageImports` for `lucide-react`, `recharts`, `framer-motion`
- [x] Dependency audit complete — 18 unused packages removed from `package.json`
- [x] Commercial license included (`LICENSE` + `LICENSE-COMMERCIAL`)

## What's still mock (and where to wire real services)

This is a template — the data layer is intentionally mock so you can drop in your own backend. None of these blocks the build or the UI; they're swap-in points.

- **Data** — `src/lib/mock-data.ts` (247 customers, 38 invoices, revenue series, etc.) is deterministic and imported directly by components. Replace the exports with Prisma + Postgres calls via `src/lib/db.ts` (the Prisma client is already wired there).
- **Auth** — The sign-in page (`src/app/signin/`) simulates auth with a 1.1s delay and a toast. Wire NextAuth.js with the env vars in `.env.example` (`NEXTAUTH_SECRET`, `GOOGLE_CLIENT_ID`, etc.) — the sign-in UI is already built.
- **Payments** — Payment methods and invoices in `src/lib/mock-data.ts` are static. The card-brand detection (`src/components/dashboard/card-icons.tsx`) is real (BIN-prefix matcher); wire Stripe via `STRIPE_SECRET_KEY` to make the Add Payment / Pay Now flows hit a real backend.
- **Email** — The support ticket form (`src/app/support/`) simulates submission. Wire Resend / Postmark via `RESEND_API_KEY`.
- **Errors** — `app/error.tsx` logs to `console.error`. Forward to Sentry via `SENTRY_DSN`.

## License

This template is licensed under the **Northstar Analytics Commercial Template License, Version 1.0** — see [`LICENSE`](./LICENSE) for the summary and [`LICENSE-COMMERCIAL`](./LICENSE-COMMERCIAL) for the full legally binding terms.

Short version: you may use this template in **one (1) production project**. You may modify it. You may **not** resell, redistribute, or sublicense the source code. For additional licenses or licensing inquiries: `legal@northstar.io`.
