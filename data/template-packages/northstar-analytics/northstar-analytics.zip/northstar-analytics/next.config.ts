import type { NextConfig } from "next";

/**
 * Next.js production config.
 *
 * Notes:
 *  - `output: "standalone"` produces a self-contained `.next/standalone`
 *    bundle that can be deployed to any container (Docker, Fly.io, Railway,
 *    etc.) without `node_modules`.
 *  - `reactStrictMode: true` surfaces side-effect bugs in dev. We keep it on
 *    in production builds too — strict mode is a runtime dev-only behavior,
 *    so it has zero production overhead.
 *  - We do NOT silence TypeScript or ESLint errors in the build. If the build
 *    fails, fix the source — don't paper over it.
 */
const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: true,
  // Allow self-hosted SVG avatars (data URLs) and local static assets.
  // No remote image hosts are used.
  images: {
    remotePatterns: [],
  },
  // Experimental: faster dev compilation.
  experimental: {
    optimizePackageImports: ["lucide-react", "recharts", "framer-motion"],
  },
};

export default nextConfig;
