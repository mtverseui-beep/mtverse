import nextCoreWebVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";
import { dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const eslintConfig = [...nextCoreWebVitals, ...nextTypescript, {
  rules: {
    // ---------------------------------------------------------------
    // TypeScript rules — re-enabled for production quality.
    // ---------------------------------------------------------------
    // Allow `any` only with an explicit `eslint-disable-next-line`
    // comment justifying why. Surfaces accidental `any` in code review.
    "@typescript-eslint/no-explicit-any": "warn",
    // Warn on unused vars — fix in code, don't hide. Allow unused
    // function arguments prefixed with `_`.
    "@typescript-eslint/no-unused-vars": [
      "warn",
      {
        argsIgnorePattern: "^_",
        varsIgnorePattern: "^_",
        caughtErrorsIgnorePattern: "^_",
      },
    ],
    // Non-null assertions (`foo!.bar`) are a common source of runtime
    // null errors — surface them so we can use proper null checks.
    "@typescript-eslint/no-non-null-assertion": "warn",
    "@typescript-eslint/prefer-as-const": "off",
    "@typescript-eslint/ban-ts-comment": "off",
    "@typescript-eslint/no-unused-disable-directive": "off",

    // ---------------------------------------------------------------
    // React / hooks rules — re-enabled.
    // ---------------------------------------------------------------
    // exhaustive-deps catches missing deps in useEffect / useMemo /
    // useCallback that lead to stale-closure bugs. Warn so we can
    // review and fix rather than silently shipping bugs.
    "react-hooks/exhaustive-deps": "warn",
    "react-hooks/purity": "off",
    "react/no-unescaped-entities": "off",
    "react/display-name": "off",
    "react/prop-types": "off",
    "react-compiler/react-compiler": "off",

    // ---------------------------------------------------------------
    // Next.js rules
    // ---------------------------------------------------------------
    "@next/next/no-img-element": "off",
    "@next/next/no-html-link-for-pages": "off",

    // ---------------------------------------------------------------
    // General JavaScript rules
    // ---------------------------------------------------------------
    "prefer-const": "warn",
    "no-unused-vars": "off", // handled by @typescript-eslint/no-unused-vars
    "no-console": "off",
    "no-debugger": "warn",
    "no-empty": "off",
    "no-irregular-whitespace": "off",
    "no-case-declarations": "off",
    "no-fallthrough": "off",
    "no-mixed-spaces-and-tabs": "off",
    "no-redeclare": "off",
    "no-undef": "off",
    "no-unreachable": "warn",
    "no-useless-escape": "off",
  },
}, {
  // Only ignore actual build artifacts. Utility scripts under `scripts/`
  // are not shipped to users and are excluded from lint (they're for
  // dev-only tasks like screenshots and hydration debugging).
  ignores: [
    "node_modules/**",
    ".next/**",
    "out/**",
    "build/**",
    "dist/**",
    "next-env.d.ts",
    "scripts/**",
  ]
}];

export default eslintConfig;
