/**
 * Screenshot dashboard pages with the new illustrated avatars.
 * Verifies the avatars render correctly in real UI contexts.
 */
import { chromium } from "playwright";
import { resolve } from "node:path";

const BASE = "http://localhost:3000";

async function main() {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    deviceScaleFactor: 2,
  });
  const page = await context.newPage();

  // Collect any console errors.
  const errors: string[] = [];
  page.on("pageerror", (err) => errors.push(`PAGE ERROR: ${err.message}`));
  page.on("console", (msg) => {
    if (msg.type() === "error") errors.push(`CONSOLE ERROR: ${msg.text()}`);
  });

  const shots: Array<[string, string]> = [
    ["/", "dashboard-overview.png"],
    ["/customers", "dashboard-customers.png"],
    ["/settings/team", "dashboard-team.png"],
    ["/settings/profile", "dashboard-profile.png"],
    ["/billing", "dashboard-billing.png"],
  ];

  for (const [path, filename] of shots) {
    console.log(`Capturing ${path} → ${filename}`);
    await page.goto(`${BASE}${path}`, { waitUntil: "networkidle" });
    // Give any lazy-loaded avatars a moment to render.
    await page.waitForTimeout(800);
    await page.screenshot({
      path: resolve(import.meta.dirname, filename),
      fullPage: false,
    });
  }

  // Open the profile menu and screenshot it.
  console.log("Opening profile menu...");
  await page.goto(`${BASE}/`, { waitUntil: "networkidle" });
  await page.waitForTimeout(500);
  // Click the avatar button (aria-label="Open account menu").
  await page.click('button[aria-label="Open account menu"]');
  await page.waitForTimeout(500);
  await page.screenshot({
    path: resolve(import.meta.dirname, "dashboard-profile-menu.png"),
    fullPage: false,
  });

  await browser.close();

  if (errors.length > 0) {
    console.log("\n--- ERRORS DETECTED ---");
    for (const e of errors) console.log(e);
  } else {
    console.log("\nNo console errors detected.");
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
