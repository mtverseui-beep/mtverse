/**
 * Screenshot the avatar-preview.html file so we can visually verify the new
 * illustrated face avatars look right.
 */
import { chromium } from "playwright";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

async function main() {
  const browser = await chromium.launch();
  const page = await browser.newPage({
    viewport: { width: 1280, height: 900 },
    deviceScaleFactor: 2,
  });
  const fileUrl = pathToFileURL(resolve(import.meta.dirname, "avatar-preview.html")).href;
  await page.goto(fileUrl);
  await page.waitForLoadState("networkidle");
  await page.screenshot({
    path: resolve(import.meta.dirname, "avatar-preview.png"),
    fullPage: true,
  });
  await browser.close();
  console.log("Screenshot saved to scripts/avatar-preview.png");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
