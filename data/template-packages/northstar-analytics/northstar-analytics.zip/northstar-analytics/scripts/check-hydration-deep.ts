import { chromium } from "playwright";

async function main() {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();

  // Capture SSR HTML fully
  let ssrHtml: string | null = null;

  page.on("response", async (res) => {
    if (res.url() === "http://localhost:3000/" && res.status() === 200) {
      try {
        ssrHtml = await res.text();
      } catch (e) {
        console.error("Response capture error:", e);
      }
    }
  });

  const consoleErrors: string[] = [];
  page.on("console", (msg) => {
    if (msg.type() === "error") consoleErrors.push(msg.text());
  });

  await page.goto("http://localhost:3000/", { waitUntil: "load" });

  // Capture full client body HTML after hydration
  const clientHtml = await page.evaluate(() => {
    return document.documentElement.outerHTML;
  });

  // Find all elements with id starting with "radix-"
  const ssrRadixIds = (ssrHtml?.match(/id="(radix-[^"]+)"/g) ?? []).map((s) => s.replace(/id="([^"]+)"/, "$1"));
  const clientRadixIds = (clientHtml.match(/id="(radix-[^"]+)"/g) ?? []).map((s) => s.replace(/id="([^"]+)"/, "$1"));

  console.log("=== SSR radix IDs ===");
  console.log(JSON.stringify(ssrRadixIds, null, 2));
  console.log("");
  console.log("=== Client radix IDs ===");
  console.log(JSON.stringify(clientRadixIds, null, 2));
  console.log("");

  // Find all "ns:theme-change" related script blocks
  console.log("=== Looking for any inline script that mutates DOM ===");
  const inlineScripts = ssrHtml?.match(/<script[^>]*>[\s\S]*?<\/script>/g) ?? [];
  console.log(`Found ${inlineScripts.length} inline scripts in SSR HTML`);
  inlineScripts.forEach((s, i) => {
    if (s.length < 1000) {
      console.log(`Script ${i}: ${s.slice(0, 500)}`);
    } else {
      console.log(`Script ${i} (length=${s.length}): ${s.slice(0, 200)}...${s.slice(-200)}`);
    }
  });

  console.log("");
  console.log("=== Console errors count: " + consoleErrors.length + " ===");
  const hydrationErrors = consoleErrors.filter((e) => e.includes("hydrated") || e.includes("didn't match"));
  console.log(`Hydration errors: ${hydrationErrors.length}`);
  if (hydrationErrors.length > 0) {
    console.log("First hydration error (first 3000 chars):");
    console.log(hydrationErrors[0]!.slice(0, 3000));
  }

  await ctx.close();
  await browser.close();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
