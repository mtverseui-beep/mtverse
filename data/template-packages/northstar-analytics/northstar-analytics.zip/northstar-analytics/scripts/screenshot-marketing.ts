/**
 * Capture production-quality screenshots of every dashboard page in both
 * light and dark mode. Output goes to /marketing/screenshots/.
 *
 * Filenames follow the convention:
 *   <page>-<theme>.png
 * e.g. overview-dark.png, customers-light.png
 *
 * Run: bun scripts/screenshot-marketing.ts
 * Requires: dev server running on http://localhost:3000
 */
import { chromium } from "playwright";
import { resolve } from "node:path";
import { mkdirSync } from "node:fs";

const BASE = "http://localhost:3000";
const OUT_DIR = resolve(import.meta.dirname, "..", "marketing", "screenshots");

interface Shot {
  route: string;
  /** Sub-path on the route to scroll to / wait for before capturing. */
  waitForSelector?: string;
  /** Filename slug. */
  slug: string;
}

const SHOTS: Shot[] = [
  { route: "/", slug: "overview" },
  { route: "/analytics", slug: "analytics" },
  { route: "/customers", slug: "customers" },
  { route: "/billing", slug: "billing" },
  { route: "/settings/profile", slug: "settings-profile" },
  { route: "/settings/team", slug: "settings-team" },
  { route: "/signin", slug: "signin" },
  { route: "/support", slug: "support" },
  { route: "/docs", slug: "docs" },
];

async function setTheme(page: import("playwright").Page, theme: "dark" | "light") {
  // Toggle the theme via localStorage + reload — the inline script in
  // layout.tsx reads from localStorage on initial paint, so this gives
  // us a clean first-paint in the right theme with no flash.
  await page.addInitScript((t) => {
    try {
      window.localStorage.setItem("ns.theme", t);
    } catch {
      /* ignore */
    }
  }, theme);
}

async function main() {
  mkdirSync(OUT_DIR, { recursive: true });
  const browser = await chromium.launch();

  const errors: string[] = [];

  for (const theme of ["dark", "light"] as const) {
    const context = await browser.newContext({
      viewport: { width: 1440, height: 900 },
      deviceScaleFactor: 2,
      colorScheme: theme,
    });

    for (const shot of SHOTS) {
      const page = await context.newPage();
      page.on("pageerror", (err) => errors.push(`[${theme}/${shot.slug}] PAGE ERROR: ${err.message}`));

      // Set theme BEFORE navigating so the inline script picks it up.
      await setTheme(page, theme);
      const url = `${BASE}${shot.route}`;
      console.log(`  → ${theme}/${shot.slug}  (${url})`);
      await page.goto(url, { waitUntil: "networkidle" });
      // Wait for any lazy-loaded avatars + charts to render.
      await page.waitForTimeout(1200);

      const outPath = resolve(OUT_DIR, `${shot.slug}-${theme}.png`);
      await page.screenshot({ path: outPath, fullPage: false });
      await page.close();
    }

    await context.close();
  }

  await browser.close();

  console.log(`\nDone. Screenshots saved to ${OUT_DIR}`);
  if (errors.length > 0) {
    console.log(`\n${errors.length} errors detected:`);
    for (const e of errors) console.log(`  ${e}`);
  } else {
    console.log("No console errors detected.");
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
