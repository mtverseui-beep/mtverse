/**
 * Quick visual check: render a few sample avatars to a single HTML file
 * so we can verify the new illustrated face avatar generator looks right.
 *
 * Run with: bun /home/z/my-project/scripts/test-avatars.ts
 * Then open: /home/z/my-project/scripts/avatar-preview.html
 */
import { svgAvatarDataUrl, avatarUrlFor, avatarUrlForVariant } from "../src/lib/avatar";
import { writeFileSync } from "node:fs";
import { resolve } from "node:path";

const samples = [
  { seed: "avery.chen@northstar.io", name: "Avery Chen" },
  { seed: "jordan.patel@northstar.io", name: "Jordan Patel" },
  { seed: "maya.okafor@northstar.io", name: "Maya Okafor" },
  { seed: "ethan.rivera@northstar.io", name: "Ethan Rivera" },
  { seed: "priya.nguyen@northstar.io", name: "Priya Nguyen" },
  { seed: "noah.andersson@northstar.io", name: "Noah Andersson" },
  { seed: "customer1@example.com", name: "Test One" },
  { seed: "customer2@example.com", name: "Test Two" },
  { seed: "customer3@example.com", name: "Test Three" },
  { seed: "customer4@example.com", name: "Test Four" },
  { seed: "customer5@example.com", name: "Test Five" },
  { seed: "customer6@example.com", name: "Test Six" },
  { seed: "customer7@example.com", name: "Test Seven" },
  { seed: "customer8@example.com", name: "Test Eight" },
  { seed: "customer9@example.com", name: "Test Nine" },
  { seed: "customer10@example.com", name: "Test Ten" },
  { seed: "customer11@example.com", name: "Test Eleven" },
  { seed: "customer12@example.com", name: "Test Twelve" },
  { seed: "customer13@example.com", name: "Test Thirteen" },
  { seed: "customer14@example.com", name: "Test Fourteen" },
  { seed: "customer15@example.com", name: "Test Fifteen" },
  { seed: "customer16@example.com", name: "Test Sixteen" },
];

const cards = samples
  .map((s, i) => {
    const url = i % 2 === 0
      ? avatarUrlFor(s.seed, s.name)
      : avatarUrlForVariant(s.seed, s.name);
    return `
      <div style="display:flex;flex-direction:column;align-items:center;gap:8px;padding:12px;border-radius:8px;background:#1a1a1d;border:1px solid #2a2a2e">
        <img src="${url}" width="96" height="96" style="border-radius:50%;display:block" alt="${s.name}" />
        <div style="text-align:center">
          <div style="color:#e4e4e7;font-size:12px;font-weight:600">${s.name}</div>
          <div style="color:#71717a;font-size:10px">${i % 2 === 0 ? "avatarUrlFor" : "avatarUrlForVariant"}</div>
        </div>
      </div>
    `;
  })
  .join("");

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Avatar Preview</title>
<style>
  body { background:#0a0a0b; color:#e4e4e7; font-family: -apple-system, system-ui, sans-serif; margin:0; padding:24px }
  h1 { font-size:18px; margin:0 0 16px; font-weight:600 }
  .grid { display:grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap:12px; max-width:1200px }
</style>
</head>
<body>
  <h1>Northstar — illustrated face avatars (no initials)</h1>
  <div class="grid">${cards}</div>
</body>
</html>`;

writeFileSync(resolve(import.meta.dirname, "avatar-preview.html"), html);
console.log(`Wrote ${samples.length} avatar samples to avatar-preview.html`);
console.log("First URL preview (first 200 chars):");
console.log(svgAvatarDataUrl({ seed: "avery.chen@northstar.io", name: "Avery Chen" }).slice(0, 200) + "...");
