import { chromium } from "playwright";

async function main() {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  await ctx.addInitScript(() => {
    try { window.localStorage.setItem("ns.theme", "dark"); } catch {}
  });
  const page = await ctx.newPage();

  const consoleErrors: string[] = [];
  page.on("console", (msg) => {
    if (msg.type() === "error") consoleErrors.push(msg.text());
  });

  // Go to /customers, open dropdown, then reload
  await page.goto("http://localhost:3000/customers", { waitUntil: "load" });
  await page.click('[aria-label="Open account menu"]');
  await page.waitForTimeout(300);
  await page.keyboard.press("Escape");
  await page.waitForTimeout(300);
  await page.reload({ waitUntil: "load" });
  await page.waitForTimeout(1500);

  const hydrationErrors = consoleErrors.filter((e) => e.includes("hydrated") || e.includes("didn't match"));
  console.log(`Hydration errors: ${hydrationErrors.length}`);
  if (hydrationErrors.length > 0) {
    console.log("=== Full error ===");
    console.log(hydrationErrors[0]);
  }

  await ctx.close();
  await browser.close();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
