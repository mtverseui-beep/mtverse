import { chromium } from "playwright";

async function testRoute(url: string, theme: "dark" | "light" | null) {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();

  // Pre-seed localStorage before any page scripts run.
  if (theme) {
    await ctx.addInitScript((t) => {
      try { window.localStorage.setItem("ns.theme", t); } catch {}
    }, theme);
  }

  const page = await ctx.newPage();

  const consoleErrors: string[] = [];
  const hydrationErrors: string[] = [];
  let serverId: string | null = null;

  page.on("console", (msg) => {
    const text = msg.text();
    if (msg.type() === "error") consoleErrors.push(text);
    if (text.includes("hydrated") || text.includes("hydration") || text.includes("didn't match")) {
      hydrationErrors.push(text);
    }
  });

  page.on("pageerror", (err) => {
    consoleErrors.push(`PAGE ERROR: ${err.message}`);
  });

  // Capture the SSR HTML by intercepting the response — BEFORE hydration patches the DOM.
  page.on("response", async (res) => {
    if (res.url() === url && res.status() === 200) {
      try {
        const text = await res.text();
        const m = text.match(/aria-label="Open account menu"[^>]*id="([^"]+)"/);
        if (m) serverId = m[1] ?? null;
      } catch {}
    }
  });

  await page.goto(url, { waitUntil: "load" });
  // Capture id immediately — before any re-render
  const clientIdImmediate = await page.evaluate(() => {
    const btn = document.querySelector('[aria-label="Open account menu"]') as HTMLButtonElement | null;
    return btn?.id ?? "(not found)";
  });
  // Open then close the dropdown to trigger Radix internal state changes,
  // then re-navigate to force a fresh SSR pass and observe if id stays stable.
  try {
    await page.click('[aria-label="Open account menu"]');
    await page.waitForTimeout(300);
    await page.keyboard.press("Escape");
    await page.waitForTimeout(300);
  } catch {}
  // Now reload the page (server re-render + client hydration) — this is where
  // hydration mismatches surface.
  await page.reload({ waitUntil: "load" });
  const clientIdAfterReload = await page.evaluate(() => {
    const btn = document.querySelector('[aria-label="Open account menu"]') as HTMLButtonElement | null;
    return btn?.id ?? "(not found)";
  });
  await page.waitForTimeout(1500);
  const clientIdAfter = await page.evaluate(() => {
    const btn = document.querySelector('[aria-label="Open account menu"]') as HTMLButtonElement | null;
    return btn?.id ?? "(not found)";
  });

  await ctx.close();
  await browser.close();

  return {
    url,
    theme,
    serverId,
    clientIdImmediate,
    clientIdAfterReload,
    clientIdAfter,
    hydrationErrors,
    consoleErrors: consoleErrors.slice(0, 5),
  };
}

async function main() {
  // Final verification — all routes, all themes, with reload+interaction
  const routes = [
    "http://localhost:3000/",
    "http://localhost:3000/analytics",
    "http://localhost:3000/customers",
    "http://localhost:3000/billing",
    "http://localhost:3000/settings",
    "http://localhost:3000/settings/team",
    "http://localhost:3000/settings/profile",
    "http://localhost:3000/settings/api-keys",
    "http://localhost:3000/settings/notifications",
    "http://localhost:3000/signin",
    "http://localhost:3000/support",
    "http://localhost:3000/docs",
  ];
  let totalRoutes = 0;
  let cleanRoutes = 0;
  for (const route of routes) {
    let routeClean = true;
    for (const theme of ["dark", "light", null] as const) {
      totalRoutes++;
      const r = await testRoute(route, theme);
      if (r.hydrationErrors.length === 0) {
        cleanRoutes++;
      } else {
        routeClean = false;
        console.log(`✗  ${route}  theme=${theme ?? "none"}  — ${r.hydrationErrors.length} hydration errors`);
        console.log(`   first 500 chars: ${r.hydrationErrors[0]!.slice(0, 500)}`);
      }
    }
    if (routeClean) console.log(`✓  ${route}  (3/3 themes clean)`);
  }
  console.log(`\n=== Summary: ${cleanRoutes}/${totalRoutes} route-theme combinations had zero hydration errors ===`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
