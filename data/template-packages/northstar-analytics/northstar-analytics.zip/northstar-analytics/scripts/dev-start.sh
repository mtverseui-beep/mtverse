#!/bin/bash
# Persistent dev server launcher
cd /home/z/my-project
pkill -f "next-server" 2>/dev/null
pkill -f "next dev" 2>/dev/null
sleep 2
nohup node node_modules/.bin/next dev -p 3000 > dev.log 2>&1 &
disown
echo "Started dev server PID $!"
sleep 8
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:3000/
tail -15 dev.log
