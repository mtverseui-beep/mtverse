import { chromium } from "playwright";

async function testRoute(url: string, theme: "dark" | "light" | null, withInteraction: boolean) {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  if (theme) {
    await ctx.addInitScript((t) => {
      try { window.localStorage.setItem("ns.theme", t); } catch {}
    }, theme);
  }
  const page = await ctx.newPage();

  const consoleErrors: string[] = [];
  page.on("console", (msg) => {
    if (msg.type() === "error") consoleErrors.push(msg.text());
  });

  await page.goto(url, { waitUntil: "load" });

  if (withInteraction) {
    try {
      await page.click('[aria-label="Open account menu"]');
      await page.waitForTimeout(300);
      await page.keyboard.press("Escape");
      await page.waitForTimeout(300);
    } catch {}
    // Reload — fresh SSR + hydration
    await page.reload({ waitUntil: "load" });
    await page.waitForTimeout(1000);
  } else {
    await page.waitForTimeout(1000);
  }

  const hydrationErrors = consoleErrors.filter((e) => e.includes("hydrated") || e.includes("didn't match"));
  await ctx.close();
  await browser.close();
  return { count: hydrationErrors.length, first: hydrationErrors[0] ?? "" };
}

async function main() {
  // DEV — verify the fix works
  console.log("=== DEV (with fix): dark theme, with reload, 12 runs ===");
  let countA = 0;
  for (let i = 1; i <= 12; i++) {
    const t = await testRoute("http://localhost:3000/", "dark", true);
    if (t.count > 0) countA++;
    console.log(`  Run ${i}: hydration errors: ${t.count}`);
    if (t.count > 0) console.log(`     first 600 chars: ${t.first.slice(0, 600)}`);
  }
  console.log(`  → ${countA}/12 runs had hydration errors`);

  console.log("\n=== DEV (with fix): no theme, with reload, 12 runs ===");
  let countB = 0;
  for (let i = 1; i <= 12; i++) {
    const t = await testRoute("http://localhost:3000/", null, true);
    if (t.count > 0) countB++;
    console.log(`  Run ${i}: hydration errors: ${t.count}`);
    if (t.count > 0) console.log(`     first 600 chars: ${t.first.slice(0, 600)}`);
  }
  console.log(`  → ${countB}/12 runs had hydration errors`);

  console.log("\n=== DEV (with fix): /customers, with reload, 12 runs ===");
  let countC = 0;
  for (let i = 1; i <= 12; i++) {
    const t = await testRoute("http://localhost:3000/customers", "dark", true);
    if (t.count > 0) countC++;
    console.log(`  Run ${i}: hydration errors: ${t.count}`);
    if (t.count > 0) console.log(`     first 600 chars: ${t.first.slice(0, 600)}`);
  }
  console.log(`  → ${countC}/12 runs had hydration errors`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
