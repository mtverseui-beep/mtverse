# VoltHaus — Limited Sneakers & Streetwear Drops

A premium, production-ready Gen Z streetwear ecommerce frontend template. Limited sneakers, hoodies, graphic tees, cargo pants, jackets, caps, bags, and accessories — built around a drop-driven release model with creator capsules, lookbooks, and a full account + checkout flow.

Built on the same UI/UX, animation, and motion DNA as a bold Gen Z landing page (Lenis smooth scroll, Framer Motion, click spark, sticky glassmorphism nav, parallax hero, 3D tilt bento, magnetic hover, marquee, animated borders) — rebranded, recolored, and rebuilt as a complete ecommerce system.

## Tech stack

- **Framework**: Next.js 16 (App Router, Turbopack, standalone output)
- **Language**: TypeScript 5 (strict)
- **Styling**: Tailwind CSS 4 + tw-animate-css
- **UI library**: shadcn/ui (New York style) + Lucide icons
- **Animation**: Framer Motion 12 + Lenis 1.3 (smooth scroll)
- **State**: Zustand 5 (cart, wishlist, compare, recently-viewed, UI, toasts, search)
- **Forms**: react-hook-form + zod
- **Fonts**: Inter (sans) + JetBrains Mono (mono)
- **Package manager**: Bun

## Brand

| Token | Value |
|-------|-------|
| Name | VoltHaus |
| Background | `#0B0D10` (deep graphite) |
| Foreground | `#F7F7F8` (icy white) |
| Primary | `#00E5FF` (electric cyan) |
| Secondary | `#FF2ED1` (hot magenta) |
| Accent | `#8B5CF6` (soft purple) |
| Surface | `#14171D` (muted steel) |
| Muted | `#8A93A3` (steel grey) |
| Border | `rgba(255,255,255,0.12)` |
| Support email | `support@volthaus.co` |

All colors are defined as CSS variables in `src/app/globals.css` and exposed through Tailwind's `@theme inline` so utility classes like `bg-primary`, `text-secondary`, `border-border` work everywhere.

## Route list (70+ routes)

### Core ecommerce
- `/` — Homepage
- `/shop` — All products with filters/sort
- `/shop/[category]` — Category-filtered shop
- `/product/[slug]` — Product detail
- `/cart` — Full cart page
- `/checkout`, `/checkout/shipping`, `/checkout/payment`, `/checkout/review` — Multi-step checkout
- `/order/success`, `/order/failed`, `/order/cancelled`, `/order/[id]` — Order flow
- `/track-order` — Shipment tracking
- `/wishlist`, `/compare`, `/search`, `/recently-viewed`
- `/new-arrivals`, `/best-sellers`, `/limited-drops`, `/sale`
- `/collections`, `/collections/[slug]`
- `/sneakers`, `/streetwear`, `/accessories`
- `/gift-cards`, `/size-guide`, `/drop-calendar`, `/outfit-builder`, `/rewards`

### Account (9 routes)
- `/account`, `/account/orders`, `/account/orders/[id]`, `/account/addresses`, `/account/payment-methods`, `/account/wishlist`, `/account/rewards`, `/account/notifications`, `/account/profile`, `/account/security`

### Auth (5 routes)
- `/sign-in`, `/sign-up`, `/forgot-password`, `/reset-password`, `/verify-email`

### Content & community
- `/about`, `/our-story`, `/lookbook`, `/lookbook/[slug]`
- `/creators`, `/creators/[slug]`
- `/campaigns`, `/campaigns/[slug]`
- `/reviews`, `/blog`, `/blog/[slug]`
- `/contact`, `/help`, `/help/shipping`, `/help/returns`, `/help/orders`, `/help/payments`
- `/faq`, `/stockists`

### Legal (7 routes)
- `/privacy`, `/terms`, `/cookies`, `/accessibility`, `/refund-policy`, `/returns-policy`, `/shipping-policy`

### System (5 routes)
- `/404` (custom `not-found.tsx`), `/500` (custom `error.tsx`), `/offline`, `/maintenance`, `/coming-soon`

## File structure

```
src/
├── app/                      # Next.js App Router pages
│   ├── (70+ route folders)
│   ├── layout.tsx            # Root layout (fonts, metadata, providers)
│   ├── page.tsx              # Homepage
│   ├── globals.css           # VoltHaus color system + animations
│   ├── not-found.tsx         # Custom 404
│   └── error.tsx             # Custom 500
├── components/
│   ├── layout/               # Nav, footer, search, mobile menu, cart drawer, go-to-top, cookie banner, newsletter popup, site shell
│   ├── sections/             # Homepage sections (hero, drop countdown, carousel, bento, etc.)
│   ├── ecommerce/            # Shop, cart, wishlist, compare, search, outfit builder, gift cards
│   ├── product/              # Product card, product detail, quick view, size guide
│   ├── checkout/             # Multi-step checkout flow
│   ├── account/              # Account dashboard, orders, addresses, payment, profile, security, rewards
│   ├── auth/                 # Sign in, sign up, forgot/reset password, verify email
│   ├── content/              # About, blog, creators, campaigns, reviews, lookbook, FAQ, help center, policy layout, drop calendar grid
│   ├── motion/               # MagneticButton, TiltCard, ScrollReveal, Marquee, Parallax, AnimatedCounter, ShineBorder
│   ├── common/               # SectionHeading, BadgeVH, EmptyState, Skeletons, StarRating, Breadcrumbs, PriceDisplay, ColorSwatch, SizeSelector, QuantitySelector, TrustBadge
│   ├── ui/                   # shadcn/ui primitives
│   ├── click-spark.tsx       # Click spark canvas effect (preserved from source)
│   ├── lenis-provider.tsx    # Lenis smooth scroll provider (preserved from source)
│   └── providers.tsx         # Wraps ClickSpark + Lenis + all global overlays
├── data/                     # Typed data files
│   ├── products.ts           # 24 products with full ecommerce data
│   ├── collections.ts        # 10 collections
│   ├── creators.ts           # 6 fictional creators
│   ├── campaigns.ts          # 4 campaigns
│   ├── reviews.ts            # 12 site reviews
│   ├── blog.ts               # 6 articles
│   ├── lookbook.ts           # 8 lookbook items
│   ├── orders.ts             # 6 mock orders
│   ├── customers.ts          # 1 mock customer
│   ├── faqs.ts               # 22 FAQs
│   ├── policies.ts           # 7 policy documents
│   ├── navigation.ts         # Nav items + footer nav + announcement bar messages
│   ├── sizeGuide.ts          # 4 size guide tables
│   ├── dropCalendar.ts       # 8 drop calendar entries
│   ├── outfitBuilder.ts      # Outfit builder options
│   └── index.ts              # Barrel
├── store/                    # Zustand stores
│   ├── cart-store.ts         # Cart + saved items + coupon + gift card (localStorage persisted)
│   ├── wishlist-store.ts     # Wishlist (localStorage persisted)
│   ├── compare-store.ts      # Compare (max 4, localStorage persisted)
│   ├── recently-viewed-store.ts # Recently viewed (max 12, localStorage persisted)
│   ├── search-store.ts       # Search overlay state (session)
│   ├── ui-store.ts           # Mobile menu, mega menu, quick view, size guide, cookie banner, newsletter, filter drawer, go-to-top
│   └── toast-store.ts        # Toast notifications
├── hooks/                    # useMounted, useLocalStorage, useReducedMotion, useScrollPosition, useMediaQuery
├── types/                    # Shared TypeScript types
└── lib/                      # utils (cn helper), db (Prisma client)
```

## Setup guide

```bash
# Install dependencies
bun install

# Start dev server
bun run dev

# Production build
bun run build

# Type check
bun run typecheck

# Lint
bun run lint
```

The dev server runs on `http://localhost:3000`.

## How to customize

### Change brand colors

Edit the CSS variables in `src/app/globals.css`:

```css
:root {
  --background: #0B0D10;
  --foreground: #F7F7F8;
  --primary: #00E5FF;
  --secondary: #FF2ED1;
  --accent: #8B5CF6;
  /* ... */
}
```

All components use Tailwind utility classes (`bg-primary`, `text-secondary`, etc.) that map to these variables, so a single edit re-colors the entire site.

### Change brand name

Search and replace `VoltHaus` → `YourBrand` across `src/`. Also update:
- `src/app/layout.tsx` (metadata title, description, Open Graph)
- `public/logo.svg` and `public/icon.svg`
- `src/data/navigation.ts` (announcement bar messages)
- `src/data/policies.ts` (policy documents)
- `README.md`

### Edit products

Edit `src/data/products.ts`. Each product is a typed `Product` object. Add or remove entries — helper functions like `getProductBySlug`, `getProductsByCategory`, `getFeaturedProducts`, `getBestSellers`, `getNewArrivals`, `getOnSaleProducts`, `getRelatedProducts`, `searchProducts` will automatically pick up changes.

### Edit collections

Edit `src/data/collections.ts`. Each collection references `productSlugs` that map to entries in `products.ts`.

### Edit lookbook images

Edit `src/data/lookbook.ts`. Each item has an Unsplash image URL — replace with your own. The lookbook grid and detail pages will update automatically.

### Edit cart/wishlist data

Cart, wishlist, compare, and recently-viewed state is managed by Zustand stores in `src/store/`. These persist to localStorage automatically. To change the persistence key or behavior, edit the `persist` configuration in each store file.

### Customize animations

- **Lenis smooth scroll**: Edit `src/components/lenis-provider.tsx` — change `lerp`, `duration`, `wheelMultiplier`, `touchMultiplier`.
- **Click spark effect**: Edit `src/components/click-spark.tsx` — change `sparkColor` (currently `#00E5FF`), `sparkSize`, `sparkRadius`, `sparkCount`, `duration`.
- **Framer Motion**: Each component using motion has its own transition config. Look for `transition={{ ... }}` and `variants={{ ... }}` props.

### Customize Lenis settings

In `src/components/lenis-provider.tsx`:

```tsx
<ReactLenis
  root
  options={{
    lerp: 0.1,           // Lower = smoother/slower, higher = faster
    duration: 1.2,       // Scroll duration in seconds
    smoothWheel: true,   // Enable smooth wheel scrolling
    wheelMultiplier: 1,  // Wheel speed multiplier
    touchMultiplier: 2,  // Touch speed multiplier
    infinite: false,     // Infinite scroll
  }}
>
```

### Customize click spark color

In `src/components/providers.tsx`:

```tsx
<ClickSpark
  sparkColor="#00E5FF"  // Change to any hex color
  sparkSize={12}
  sparkRadius={20}
  sparkCount={8}
  duration={400}
  easing="ease-out"
>
```

## Deploy

The project is configured for standalone Next.js output. Build with `bun run build` and deploy the standalone server:

```bash
bun run build
bun run start
```

Deploy to Vercel, Netlify, or any Node.js host. Make sure to:
1. Set environment variables for any backend integrations (none required by default — all data is mock/localStorage)
2. Configure image domains in `next.config.ts` if you add new image sources (currently allows `images.unsplash.com`)
3. Set up a CDN for static assets if needed

## Production checklist

- [x] All 70+ routes implemented and accessible
- [x] Zero TypeScript errors (`bun run typecheck`)
- [x] Zero ESLint errors (`bun run lint`)
- [x] Zero hydration errors
- [x] Mobile-first responsive (320px → 1440px+)
- [x] All buttons functional (navigate, open modals, toast, update stores)
- [x] All forms validate
- [x] All images have alt text
- [x] SEO metadata on every page (title, description, Open Graph, Twitter, canonical)
- [x] Product schema, organization schema, website schema (JSON-LD)
- [x] Cart persists across refresh (localStorage)
- [x] Wishlist persists across refresh (localStorage)
- [x] Compare persists across refresh (localStorage)
- [x] Recently viewed persists across refresh (localStorage)
- [x] Lenis smooth scroll preserved from source
- [x] Click spark effect preserved from source
- [x] Sticky glassmorphism navigation preserved
- [x] Parallax hero preserved
- [x] 3D bento tilt cards preserved
- [x] Magnetic hover preserved
- [x] Marquee animations preserved
- [x] Reduced motion support throughout
- [x] Skip-to-content link for accessibility
- [x] ARIA labels on all interactive elements
- [x] Keyboard navigation throughout
- [x] Custom 404 and 500 error pages
- [x] Maintenance and offline pages
- [x] Cookie consent banner
- [x] Newsletter popup with session guard
- [x] No emojis, no real brand names, no lorem ipsum, no placeholder content
- [x] HD Unsplash images throughout
- [x] README documentation

## Mock coupons & gift cards

For testing the cart/checkout flow:

| Code | Effect |
|------|--------|
| `VOLTHAUS10` | 10% off |
| `DROP15` | 15% off |
| `STATIC20` | 20% off |
| `GIFT50` | $50 gift card |

## License

This is a commercial frontend template. All brand names, product names, creator names, customer names, testimonials, and order data are fictional. No real brand names (Nike, Adidas, Jordan, Supreme, Off-White, Yeezy, Palace) or copyrighted logos are used.
