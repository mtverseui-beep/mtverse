"use client";

import { useCallback, useSyncExternalStore } from "react";

/**
 * SSR-safe `matchMedia` hook.
 *
 * Returns `false` on the server and during the first client render (so markup
 * matches the server-rendered HTML), then resolves to the real media-query
 * match on mount and stays in sync when the query result changes.
 *
 * Implemented via `useSyncExternalStore` so we never call `setState`
 * synchronously inside an effect.
 *
 * @param query A CSS media query string, e.g. `"(min-width: 1024px)"`.
 */
export function useMediaQuery(query: string): boolean {
  const subscribe = useCallback(
    (callback: () => void) => {
      if (typeof window === "undefined" || !window.matchMedia) {
        return () => {};
      }
      const mql = window.matchMedia(query);
      mql.addEventListener("change", callback);
      return () => mql.removeEventListener("change", callback);
    },
    [query]
  );

  return useSyncExternalStore(
    subscribe,
    () =>
      typeof window !== "undefined" && !!window.matchMedia
        ? window.matchMedia(query).matches
        : false,
    () => false
  );
}

export default useMediaQuery;
