"use client";

import { useCallback, useSyncExternalStore } from "react";

const REDUCED_MOTION_QUERY = "(prefers-reduced-motion: reduce)";

/**
 * Subscribe to `matchMedia` for the reduced-motion query. Returns an
 * unsubscribe function.
 */
function subscribeReducedMotion(callback: () => void): () => void {
  if (typeof window === "undefined" || !window.matchMedia) return () => {};
  const mql = window.matchMedia(REDUCED_MOTION_QUERY);
  mql.addEventListener("change", callback);
  return () => mql.removeEventListener("change", callback);
}

/**
 * Returns `true` when the user has requested reduced motion via the OS /
 * browser accessibility setting. SSR-safe: returns `false` on the server.
 *
 * Implemented via `useSyncExternalStore` to avoid `setState`-in-effect and
 * guarantee a stable server/client snapshot.
 */
export function useReducedMotion(): boolean {
  const subscribe = useCallback(
    (cb: () => void) => subscribeReducedMotion(cb),
    []
  );
  return useSyncExternalStore(
    subscribe,
    () =>
      typeof window !== "undefined" && !!window.matchMedia
        ? window.matchMedia(REDUCED_MOTION_QUERY).matches
        : false,
    () => false
  );
}

export default useReducedMotion;
