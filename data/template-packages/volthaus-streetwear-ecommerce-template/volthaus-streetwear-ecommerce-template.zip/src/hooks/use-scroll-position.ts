"use client";

import { useCallback, useRef, useSyncExternalStore } from "react";

/**
 * Returns the current `window.scrollY` position, updated via
 * `requestAnimationFrame` throttling to avoid layout thrash on rapid scroll
 * events.
 *
 * SSR-safe: returns `0` until mounted.
 *
 * Implemented via `useSyncExternalStore` so the snapshot is provided by React
 * directly (no `setState`-in-effect). The `subscribe` callback uses a rAF
 * guard to coalesce rapid scroll events into a single notification per frame.
 */
function getScrollY(): number {
  return typeof window !== "undefined" ? window.scrollY : 0;
}

function getServerScrollY(): number {
  return 0;
}

export function useScrollPosition(): number {
  const frame = useRef<number | null>(null);

  const subscribe = useCallback((callback: () => void) => {
    if (typeof window === "undefined") return () => {};

    const handleScroll = () => {
      if (frame.current !== null) return;
      frame.current = window.requestAnimationFrame(() => {
        frame.current = null;
        callback();
      });
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
      if (frame.current !== null) {
        window.cancelAnimationFrame(frame.current);
        frame.current = null;
      }
    };
  }, []);

  return useSyncExternalStore(subscribe, getScrollY, getServerScrollY);
}

export default useScrollPosition;
