"use client";

import { useSyncExternalStore } from "react";

/**
 * Returns `true` only after the component has mounted on the client. Useful for
 * guarding renders that depend on localStorage-backed Zustand stores (which
 * hydrate asynchronously) to avoid hydration mismatches.
 *
 * Implemented via `useSyncExternalStore` so the server snapshot (`false`) and
 * the first client render agree, then it flips to `true` after hydration —
 * without triggering the `react-hooks/set-state-in-effect` lint rule.
 */
const emptySubscribe = (): (() => void) => () => {};

export function useMounted(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true, // client snapshot
    () => false // server snapshot
  );
}

export default useMounted;
