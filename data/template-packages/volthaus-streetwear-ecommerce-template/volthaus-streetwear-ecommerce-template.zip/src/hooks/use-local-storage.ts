"use client";

import { useCallback, useSyncExternalStore } from "react";

/**
 * Generic, SSR-safe localStorage-backed state hook implemented via
 * `useSyncExternalStore` (so no `setState`-in-effect, and cross-tab sync is
 * automatic via the `storage` event).
 *
 * - Returns `initialValue` during SSR and during the first client render (so
 *   the server-rendered HTML matches the first client render — no hydration
 *   mismatches).
 * - On the client, reads the real value from `localStorage` after hydration.
 * - Listens to the `storage` event for cross-tab synchronisation, and emits a
 *   custom notification for same-tab writes (so updates from `setValue` are
 *   observed immediately by other hook instances using the same key).
 * - Setter accepts either a plain value or an updater function, mirroring
 *   `useState` semantics.
 *
 * @param key          localStorage key
 * @param initialValue Fallback value used on the server and when storage is
 *                     empty or unreadable.
 */

// Per-key listener sets so same-tab writes can notify all subscribers.
const listeners = new Map<string, Set<() => void>>();

// Per-key cache of `{ raw, parsed }` so `getSnapshot` returns a referentially
// stable value when the underlying string hasn't changed. This is required by
// `useSyncExternalStore` — returning a fresh object each call would trigger an
// infinite re-render loop.
const snapshotCache = new Map<string, { raw: string | null; parsed: unknown }>();

function emit(key: string): void {
  const set = listeners.get(key);
  if (set) {
    set.forEach((cb) => cb());
  }
}

function subscribeToKey(key: string, callback: () => void): () => void {
  if (typeof window === "undefined") return () => {};

  let set = listeners.get(key);
  if (!set) {
    set = new Set();
    listeners.set(key, set);
  }
  set.add(callback);

  const handleStorage = (e: StorageEvent) => {
    if (e.key === key) callback();
  };
  window.addEventListener("storage", handleStorage);

  return () => {
    set?.delete(callback);
    if (set && set.size === 0) {
      listeners.delete(key);
    }
    window.removeEventListener("storage", handleStorage);
  };
}

function readSnapshot<T>(key: string, initialValue: T): T {
  let raw: string | null = null;
  try {
    raw = window.localStorage.getItem(key);
  } catch {
    // Storage may be unavailable (private mode, quota, etc.)
    return initialValue;
  }

  if (raw === null) return initialValue;

  const cached = snapshotCache.get(key);
  if (cached && cached.raw === raw) {
    return cached.parsed as T;
  }

  try {
    const parsed = JSON.parse(raw) as T;
    snapshotCache.set(key, { raw, parsed });
    return parsed;
  } catch {
    // Malformed JSON — fall back to initial value.
    return initialValue;
  }
}

export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T | ((prev: T) => T)) => void] {
  const subscribe = useCallback(
    (cb: () => void) => subscribeToKey(key, cb),
    [key]
  );

  // `initialValue` is included in the snapshot callbacks' deps so that, if the
  // caller passes a fresh value, the next snapshot reflects it. useSyncExternal
  // re-checks the snapshot each render and only re-renders if it actually
  // changed, so this is safe.
  const getSnapshot = useCallback(
    () => readSnapshot(key, initialValue),
    [key, initialValue]
  );

  const getServerSnapshot = useCallback(
    () => initialValue,
    [initialValue]
  );

  const storedValue = useSyncExternalStore(
    subscribe,
    getSnapshot,
    getServerSnapshot
  );

  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      if (typeof window === "undefined") return;
      try {
        const prev = readSnapshot(key, initialValue);
        const next =
          typeof value === "function"
            ? (value as (prev: T) => T)(prev)
            : value;
        window.localStorage.setItem(key, JSON.stringify(next));
        // Invalidate cache and notify same-tab subscribers. Cross-tab
        // subscribers are notified automatically via the `storage` event.
        snapshotCache.delete(key);
        emit(key);
      } catch {
        // Ignore write failures (private mode, quota, etc.).
      }
    },
    [key, initialValue]
  );

  return [storedValue, setValue];
}

export default useLocalStorage;
