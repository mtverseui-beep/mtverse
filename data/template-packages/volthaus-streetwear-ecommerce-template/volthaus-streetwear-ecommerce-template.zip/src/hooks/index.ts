/**
 * Barrel file re-exporting all VoltHaus hooks.
 *
 * Includes:
 * - `useMounted` — hydration guard for localStorage-backed stores.
 * - `useLocalStorage` — generic typed, SSR-safe localStorage state hook.
 * - `useReducedMotion` — `prefers-reduced-motion` media query.
 * - `useScrollPosition` — rAF-throttled scrollY.
 * - `useMediaQuery` — generic SSR-safe matchMedia.
 * - `useIsMobile` — pre-existing shadcn hook (re-exported for convenience).
 * - `useToast` / `toast` — pre-existing shadcn toast imperative API.
 */

export { useMounted } from "./use-mounted";
export { useLocalStorage } from "./use-local-storage";
export { useReducedMotion } from "./use-reduced-motion";
export { useScrollPosition } from "./use-scroll-position";
export { useMediaQuery } from "./use-media-query";

// Pre-existing shadcn hooks
export { useIsMobile } from "./use-mobile";
export { useToast, toast } from "./use-toast";
