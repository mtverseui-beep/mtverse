import type { SizeGuideTable } from "@/types";

// VoltHaus size guide
// Measurements are body-referenced where applicable and garment-referenced otherwise.

export const sizeGuideTables: SizeGuideTable[] = [
  {
    category: "Sneakers",
    unit: "cm",
    rows: [
      { size: "7", us: "7", eu: "40", uk: "6", cm: "25.0", inches: "9.8" },
      { size: "7.5", us: "7.5", eu: "40.5", uk: "6.5", cm: "25.5", inches: "10.0" },
      { size: "8", us: "8", eu: "41", uk: "7", cm: "26.0", inches: "10.2" },
      { size: "8.5", us: "8.5", eu: "42", uk: "7.5", cm: "26.5", inches: "10.4" },
      { size: "9", us: "9", eu: "42.5", uk: "8", cm: "27.0", inches: "10.6" },
      { size: "9.5", us: "9.5", eu: "43", uk: "8.5", cm: "27.5", inches: "10.8" },
      { size: "10", us: "10", eu: "44", uk: "9", cm: "28.0", inches: "11.0" },
      { size: "10.5", us: "10.5", eu: "44.5", uk: "9.5", cm: "28.5", inches: "11.2" },
      { size: "11", us: "11", eu: "45", uk: "10", cm: "29.0", inches: "11.4" },
      { size: "12", us: "12", eu: "46", uk: "11", cm: "30.0", inches: "11.8" },
    ],
  },
  {
    category: "Hoodies",
    unit: "cm",
    rows: [
      { size: "XS", us: "XS", eu: "44", uk: "34", cm: "52", inches: "20.5" },
      { size: "S", us: "S", eu: "46", uk: "36", cm: "55", inches: "21.5" },
      { size: "M", us: "M", eu: "48", uk: "38", cm: "58", inches: "22.8" },
      { size: "L", us: "L", eu: "50", uk: "40", cm: "61", inches: "24.0" },
      { size: "XL", us: "XL", eu: "52", uk: "42", cm: "64", inches: "25.2" },
      { size: "XXL", us: "XXL", eu: "54", uk: "44", cm: "67", inches: "26.4" },
      { size: "3XL", us: "3XL", eu: "56", uk: "46", cm: "70", inches: "27.5" },
    ],
  },
  {
    category: "Graphic Tees",
    unit: "cm",
    rows: [
      { size: "XS", us: "XS", eu: "44", uk: "34", cm: "48", inches: "18.9" },
      { size: "S", us: "S", eu: "46", uk: "36", cm: "51", inches: "20.1" },
      { size: "M", us: "M", eu: "48", uk: "38", cm: "54", inches: "21.3" },
      { size: "L", us: "L", eu: "50", uk: "40", cm: "57", inches: "22.4" },
      { size: "XL", us: "XL", eu: "52", uk: "42", cm: "60", inches: "23.6" },
      { size: "XXL", us: "XXL", eu: "54", uk: "44", cm: "63", inches: "24.8" },
      { size: "3XL", us: "3XL", eu: "56", uk: "46", cm: "66", inches: "26.0" },
    ],
  },
  {
    category: "Cargo Pants",
    unit: "cm",
    rows: [
      { size: "28", us: "28", eu: "44", uk: "28", cm: "73", inches: "28.7" },
      { size: "30", us: "30", eu: "46", uk: "30", cm: "76", inches: "29.9" },
      { size: "32", us: "32", eu: "48", uk: "32", cm: "81", inches: "31.9" },
      { size: "34", us: "34", eu: "50", uk: "34", cm: "86", inches: "33.9" },
      { size: "36", us: "36", eu: "52", uk: "36", cm: "91", inches: "35.8" },
      { size: "38", us: "38", eu: "54", uk: "38", cm: "96", inches: "37.8" },
      { size: "40", us: "40", eu: "56", uk: "40", cm: "101", inches: "39.8" },
    ],
  },
];

export function getSizeGuide(category: string): SizeGuideTable | undefined {
  return sizeGuideTables.find((table) => table.category === category);
}
