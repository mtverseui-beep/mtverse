import type { ProductCategory } from "@/types";

/**
 * Maps URL-safe category slugs to their display names.
 * Shared between server and client components so both can resolve
 * the same slug → category mapping without crossing the client
 * component boundary.
 */
export const CATEGORY_SLUG_MAP: Record<string, ProductCategory> = {
  sneakers: "Sneakers",
  hoodies: "Hoodies",
  "graphic-tees": "Graphic Tees",
  "cargo-pants": "Cargo Pants",
  jackets: "Jackets",
  caps: "Caps",
  bags: "Bags",
  accessories: "Accessories",
};

export const CATEGORY_SLUGS = Object.keys(CATEGORY_SLUG_MAP);

export function getCategorySlug(category: ProductCategory): string {
  const entry = Object.entries(CATEGORY_SLUG_MAP).find(([, c]) => c === category);
  return entry?.[0] ?? category.toLowerCase();
}

export function getCategoryName(slug: string): ProductCategory | undefined {
  return CATEGORY_SLUG_MAP[slug];
}
