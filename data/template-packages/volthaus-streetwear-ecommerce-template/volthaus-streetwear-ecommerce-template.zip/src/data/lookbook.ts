import type { LookbookItem } from "@/types";

// VoltHaus lookbook archive
// All image URLs reference Unsplash HD landscape assets with editorial streetwear framing.

export const lookbookItems: LookbookItem[] = [
  {
    id: "lb001",
    slug: "neon-court-milan-night",
    title: "Neon Court at the Milan Intersection",
    category: "Night",
    image:
      "https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=1600&q=80&auto=format&fit=crop",
    description:
      "A long-exposure frame from the Neon Court launch shoot, captured at two in the morning on a closed Milan street. The reflective Signal stitching on the Volt Runner 01 catches the streetlight as the cast crosses the intersection. Shot on a single prime lens with no additional lighting beyond the practicals already on the block.",
    productSlugs: ["volt-runner-01", "neon-court-low", "neon-thread-socks"],
    season: "SS26",
  },
  {
    id: "lb002",
    slug: "concrete-bloom-studio",
    title: "Concrete Bloom in Studio Halftone",
    category: "Studio",
    image:
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1600&q=80&auto=format&fit=crop",
    description:
      "A studio frame from the Concrete Bloom lookbook shot against a tonal grey wall to emphasize the halftone distortion on the floral graphic. The soft purple accent reads as a single point of color in an otherwise monochrome composition. Lighting is a single softbox keyed from camera left.",
    productSlugs: ["concrete-bloom-tee", "concrete-bloom-hoodie"],
    season: "SS26",
  },
  {
    id: "lb003",
    slug: "chrome-district-utility-row",
    title: "Chrome District on the Utility Row",
    category: "Street",
    image:
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1600&q=80&auto=format&fit=crop",
    description:
      "An editorial frame from the Chrome District campaign shot inside a decommissioned printing facility. The cargo geometry and the crossbody bag read as a single utility system against the industrial backdrop. Available skylight only, no supplemental lighting used.",
    productSlugs: ["chrome-district-cargo", "flux-crossbody-bag", "chrome-district-cap"],
    season: "FW26",
  },
  {
    id: "lb004",
    slug: "after-dark-rooftop",
    title: "After Dark on the Rooftop",
    category: "Night",
    image:
      "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=1600&q=80&auto=format&fit=crop",
    description:
      "A movement-directed frame from the After Dark campaign captured on a rooftop at the edge of the city. The windbreaker is caught mid-motion by Lara Osei with the hem vent open, showing the rebuild we made based on her feedback. Shot at a high ISO to preserve the available city glow.",
    productSlugs: ["after-dark-windbreaker", "pulse-knit-beanie", "midnight-runner-high"],
    season: "FW26",
  },
  {
    id: "lb005",
    slug: "midnight-runner-loop",
    title: "Midnight Runner on the Pre-Dawn Loop",
    category: "Street",
    image:
      "https://images.unsplash.com/photo-1483118714900-540cf339fd46?w=1600&q=80&auto=format&fit=crop",
    description:
      "A frame from the Midnight Runner lookbook shot on a pre-dawn loop through an industrial district. The tonal black-on-black palette is broken only by the magenta pull tab on the high-collar runner. The frame was captured during the wear-test phase, not the campaign shoot.",
    productSlugs: ["midnight-runner-high", "midnight-cargo-shorts"],
    season: "FW26",
  },
  {
    id: "lb006",
    slug: "signal-drop-studio-block",
    title: "Signal Drop Studio Block",
    category: "Studio",
    image:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1600&q=80&auto=format&fit=crop",
    description:
      "A studio composition from the Signal Drop capsule shot against a magenta gel backdrop to test the new color logic. The runner, the tee, and the cap are arranged as a single block to show how the colorways cross-reference. Movement direction by Lara Osei, styling by Milo Brennan.",
    productSlugs: ["signal-runner-02", "signal-drop-tee", "signal-cap"],
    season: "FW26",
  },
  {
    id: "lb007",
    slug: "static-club-editorial",
    title: "Static Club Editorial",
    category: "Editorial",
    image:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1600&q=80&auto=format&fit=crop",
    description:
      "An editorial frame from the Static Club lookbook shot in a studio with a single hard key to emphasize the overlocked seams on the heavyweight fleece. The silicone patch is positioned as the only visual marker of branding in the frame. The cast is pulled from the VoltHaus community, not from an agency.",
    productSlugs: ["static-club-hoodie", "static-club-beanie"],
    season: "SS26",
  },
  {
    id: "lb008",
    slug: "creator-capsule-process",
    title: "Creator Capsule in Process",
    category: "Editorial",
    image:
      "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1600&q=80&auto=format&fit=crop",
    description:
      "A process frame from the Creator Capsule lookbook showing the dropped shoulder in detail against a tonal background. The frame is one of twelve prototype shots that also appear in the printed zine shipped with every hoodie. The cuff and the silicone patch are both visible in the same composition.",
    productSlugs: ["creator-capsule-hoodie", "static-club-hoodie"],
    season: "FW26",
  },
];
