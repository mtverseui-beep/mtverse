import type { Campaign } from "@/types";

// VoltHaus seasonal campaign archive
// All image URLs reference Unsplash HD assets with no trademarked branding visible.

export const campaigns: Campaign[] = [
  {
    id: "cmp001",
    slug: "after-dark-fw26",
    name: "After Dark",
    season: "FW26",
    description:
      "After Dark is the closing campaign for the FW26 season and the largest outerwear capsule we have shipped to date. The film was shot across three cities over six nights with no daylight footage used in the final cut. The lookbook pairs the windbreaker program with the Midnight Runner silhouette for the first time on camera.",
    cover:
      "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=1600&q=80&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1483118714900-540cf339fd46?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1551232864-3f0890e580d9?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&q=80&auto=format&fit=crop",
    ],
    lookProductSlugs: [
      "after-dark-windbreaker",
      "midnight-runner-high",
      "pulse-knit-beanie",
    ],
    publishedAt: "2026-09-13T16:00:00Z",
  },
  {
    id: "cmp002",
    slug: "neon-court-ss26",
    name: "Neon Court",
    season: "SS26",
    description:
      "Neon Court launched the SS26 season with a court silhouette rebuilt from the ground up for warm-weather concrete. The campaign was shot on a single closed street in Milan over two nights and used only practical street lighting. The film features Kai Marchetti on camera and a cast pulled from the local skate scene.",
    cover:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1600&q=80&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1200&q=80&auto=format&fit=crop",
    ],
    lookProductSlugs: [
      "volt-runner-01",
      "neon-court-low",
      "neon-thread-socks",
    ],
    publishedAt: "2026-07-12T16:00:00Z",
  },
  {
    id: "cmp003",
    slug: "chrome-district-fw26",
    name: "Chrome District",
    season: "FW26",
    description:
      "Chrome District is the utility capsule of the FW26 season and the first VoltHaus program to use custom-milled ripstop from a single Osaka workshop. The campaign was shot inside a decommissioned printing facility and used only available light from the skylights. Every piece in the lookbook was wear-tested for six weeks before the shoot.",
    cover:
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1600&q=80&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1495121605193-b116b5b9c5fe?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=1200&q=80&auto=format&fit=crop",
    ],
    lookProductSlugs: [
      "chrome-district-cargo",
      "flux-crossbody-bag",
      "streetline-utility-vest",
    ],
    publishedAt: "2026-07-26T16:00:00Z",
  },
  {
    id: "cmp004",
    slug: "signal-drop-fw26",
    name: "Signal Drop",
    season: "FW26",
    description:
      "Signal Drop is the recurring experimental capsule of the FW26 season and the first to use the new magenta color logic across runner and tee silhouettes. The campaign was shot in a single studio session with movement direction from Lara Osei and styling by Milo Brennan. The film runs just under two minutes and is the only campaign footage from this season shot on digital.",
    cover:
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1600&q=80&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1200&q=80&auto=format&fit=crop",
    ],
    lookProductSlugs: [
      "signal-runner-02",
      "signal-drop-tee",
      "signal-cap",
    ],
    publishedAt: "2026-10-04T16:00:00Z",
  },
];
