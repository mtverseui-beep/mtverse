import type { OutfitBuilderOption } from "@/types";

// VoltHaus outfit builder options
// Each option references a real product slug from the VoltHaus catalog.

export const outfitBuilderOptions: {
  sneakers: OutfitBuilderOption[];
  hoodies: OutfitBuilderOption[];
  tees: OutfitBuilderOption[];
  pants: OutfitBuilderOption[];
  accessories: OutfitBuilderOption[];
} = {
  sneakers: [
    { type: "Sneaker", productSlug: "volt-runner-01" },
    { type: "Sneaker", productSlug: "neon-court-low" },
    { type: "Sneaker", productSlug: "midnight-runner-high" },
    { type: "Sneaker", productSlug: "signal-runner-02" },
    { type: "Sneaker", productSlug: "volt-runner-03-trail" },
  ],
  hoodies: [
    { type: "Hoodie", productSlug: "static-club-hoodie" },
    { type: "Hoodie", productSlug: "creator-capsule-hoodie" },
    { type: "Hoodie", productSlug: "concrete-bloom-hoodie" },
  ],
  tees: [
    { type: "Tee", productSlug: "concrete-bloom-tee" },
    { type: "Tee", productSlug: "archive-black-tee" },
    { type: "Tee", productSlug: "summer-blackout-tee" },
    { type: "Tee", productSlug: "signal-drop-tee" },
  ],
  pants: [
    { type: "Pants", productSlug: "chrome-district-cargo" },
    { type: "Pants", productSlug: "midnight-cargo-shorts" },
  ],
  accessories: [
    { type: "Accessory", productSlug: "signal-cap" },
    { type: "Accessory", productSlug: "chrome-district-cap" },
    { type: "Accessory", productSlug: "flux-crossbody-bag" },
    { type: "Accessory", productSlug: "pulse-knit-beanie" },
    { type: "Accessory", productSlug: "static-club-beanie" },
    { type: "Accessory", productSlug: "neon-thread-socks" },
  ],
};
