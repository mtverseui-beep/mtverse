// VoltHaus data barrel
// Re-exports every data module and its helpers from a single entry point.

export { products } from "./products";
export {
  getProductBySlug,
  getProductsByCategory,
  getProductsByCollection,
  getFeaturedProducts,
  getBestSellers,
  getNewArrivals,
  getOnSaleProducts,
  getRelatedProducts,
  getAllProductSlugs,
  searchProducts,
} from "./products";

export { collections } from "./collections";

export { creators } from "./creators";

export { campaigns } from "./campaigns";

export { reviews } from "./reviews";

export {
  blogPosts,
  getBlogPostBySlug,
  getAllBlogSlugs,
  getBlogPostsByCategory,
} from "./blog";

export { lookbookItems } from "./lookbook";

export {
  mockOrders,
  getOrderById,
  getOrderByNumber,
} from "./orders";

export { mockCustomer } from "./customers";

export { faqs, faqCategories, getFAQsByCategory } from "./faqs";

export { policies, getPolicyBySlug } from "./policies";

export {
  navItems,
  footerNav,
  announcementBarMessages,
} from "./navigation";

export { sizeGuideTables, getSizeGuide } from "./sizeGuide";

export {
  dropCalendar,
  getUpcomingDrops,
  getLiveDrops,
  getSoldOutDrops,
} from "./dropCalendar";

export { outfitBuilderOptions } from "./outfitBuilder";
