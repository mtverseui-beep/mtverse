import type { Product } from "@/types";

// VoltHaus product catalog
// All images use Unsplash HD sources. No trademarked brand logos visible.

export const products: Product[] = [
  {
    id: "p001",
    slug: "volt-runner-01",
    name: "Volt Runner 01",
    category: "Sneakers",
    collection: "Neon Court",
    collectionSlug: "neon-court",
    price: 189,
    compareAtPrice: 220,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Signal Cyan", hex: "#00E5FF" },
      { name: "After Dark", hex: "#1A1E26" }
    ],
    sizes: ["7", "7.5", "8", "8.5", "9", "9.5", "10", "10.5", "11", "12"],
    stock: 84,
    badge: "Limited",
    dropStatus: "live",
    dropDate: "2026-07-12T16:00:00Z",
    limitedQuantity: 500,
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1600&q=80&auto=format&fit=crop", alt: "Volt Runner 01 — side profile" },
      { src: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=1600&q=80&auto=format&fit=crop", alt: "Volt Runner 01 — top view" },
      { src: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1600&q=80&auto=format&fit=crop", alt: "Volt Runner 01 — back heel" },
      { src: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1600&q=80&auto=format&fit=crop", alt: "Volt Runner 01 — detail stitch" }
    ],
    description:
      "The Volt Runner 01 is the flagship silhouette of the Neon Court collection. Engineered with a lightweight knit upper, reactive foam midsole, and a translucent outsole that catches city light. Every pair ships in a collector-grade box with a numbered drop card and a spare set of signal-toned laces. Designed in our Berlin studio, manufactured in a small-batch run of 500 pairs worldwide.",
    shortDescription:
      "Flagship runner with reactive foam midsole and translucent outsole. Limited to 500 pairs.",
    materials: [
      "Engineered knit upper (recycled poly yarn)",
      "Reactive VoltFoam midsole",
      "Translucent rubber outsole",
      "Recycled polyester lining",
      "Reinforced heel counter"
    ],
    fit: "True to size. Medium width. Snug through midfoot with roomy toe box.",
    care: [
      "Spot clean with damp cloth only",
      "Do not machine wash",
      "Air dry away from direct heat",
      "Use a soft brush for outsole"
    ],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.8,
    reviewCount: 124,
    relatedProducts: ["neon-court-low", "midnight-runner-high", "nightdrop-sneaker-pack"],
    styleTags: ["runner", "lifestyle", "limited", "knit-upper"],
    featured: true,
    bestSeller: true,
    newArrival: true,
    onSale: true,
    reviews: [
      {
        id: "r1",
        author: "Marcus T.",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&q=80&auto=format&fit=crop",
        rating: 5,
        title: "Cleanest drop this year",
        body: "The fit is perfect and the translucent sole hits different at night. Box is collectors grade.",
        date: "2026-06-21",
        verified: true,
        size: "10"
      },
      {
        id: "r2",
        author: "Priya S.",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&q=80&auto=format&fit=crop",
        rating: 5,
        title: "Worth every dollar",
        body: "Lightweight, breathable, looks unreal in the cyan colorway. Got compliments all week.",
        date: "2026-06-18",
        verified: true,
        size: "8"
      }
    ],
    questions: [
      {
        id: "q1",
        author: "Devin K.",
        question: "Are these true to size or should I size up?",
        answer: "True to size for most feet. If you have a wider foot, go up half a size.",
        date: "2026-06-22"
      }
    ]
  },
  {
    id: "p002",
    slug: "neon-court-low",
    name: "Neon Court Low",
    category: "Sneakers",
    collection: "Neon Court",
    collectionSlug: "neon-court",
    price: 159,
    colors: [
      { name: "Court White", hex: "#F7F7F8" },
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Signal Cyan", hex: "#00E5FF" }
    ],
    sizes: ["6", "7", "8", "9", "10", "11", "12"],
    stock: 132,
    badge: "Best Seller",
    dropStatus: "live",
    dropDate: "2026-06-15T16:00:00Z",
    images: [
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1600&q=80&auto=format&fit=crop", alt: "Neon Court Low — side view" },
      { src: "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=1600&q=80&auto=format&fit=crop", alt: "Neon Court Low — top down" },
      { src: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=1600&q=80&auto=format&fit=crop", alt: "Neon Court Low — back heel detail" }
    ],
    description:
      "A low-top court silhouette tuned for the street. Full-grain leather upper, padded collar, and a vulcanized rubber outsole with our signature signal wave tread. Built to be worn hard and broken in beautifully.",
    shortDescription: "Low-top court silhouette in full-grain leather with signal wave tread.",
    materials: ["Full-grain leather upper", "Vulcanized rubber outsole", "Cotton terry lining", "Cotton lace set"],
    fit: "True to size. Regular width.",
    care: ["Wipe with damp cloth", "Use leather conditioner monthly", "Avoid prolonged sun exposure"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.7,
    reviewCount: 88,
    relatedProducts: ["volt-runner-01", "midnight-runner-high", "static-club-hoodie"],
    styleTags: ["court", "low-top", "leather", "everyday"],
    featured: true,
    bestSeller: true,
    newArrival: false,
    onSale: false
  },
  {
    id: "p003",
    slug: "midnight-runner-high",
    name: "Midnight Runner High",
    category: "Sneakers",
    collection: "Midnight Runner",
    collectionSlug: "midnight-runner",
    price: 215,
    colors: [
      { name: "Midnight", hex: "#0B0D10" },
      { name: "After Dark", hex: "#1A1E26" }
    ],
    sizes: ["7", "8", "9", "10", "11", "12", "13"],
    stock: 56,
    badge: "New",
    dropStatus: "live",
    dropDate: "2026-07-05T16:00:00Z",
    limitedQuantity: 300,
    images: [
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1600&q=80&auto=format&fit=crop", alt: "Midnight Runner High — side profile" },
      { src: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1600&q=80&auto=format&fit=crop", alt: "Midnight Runner High — top angle" },
      { src: "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=1600&q=80&auto=format&fit=crop", alt: "Midnight Runner High — ankle collar" }
    ],
    description:
      "A high-top runner built for after dark. Premium suede overlays, reflective piping along the eyestay, and a chunky midsole with extra cushioning. Padded ankle collar locks you in for long sessions on your feet.",
    shortDescription: "High-top runner with reflective piping and premium suede overlays.",
    materials: ["Premium suede overlays", "Ripstop nylon underlay", "Reflective piping", "EVA midsole", "Rubber outsole"],
    fit: "True to size. Snug ankle collar breaks in after a few wears.",
    care: ["Brush suede with soft brush", "Use suede protector spray", "Avoid water exposure"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.6,
    reviewCount: 47,
    relatedProducts: ["volt-runner-01", "neon-court-low", "after-dark-windbreaker"],
    styleTags: ["high-top", "runner", "suede", "reflective"],
    featured: true,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p004",
    slug: "static-club-hoodie",
    name: "Static Club Hoodie",
    category: "Hoodies",
    collection: "Static Club",
    collectionSlug: "static-club",
    price: 98,
    compareAtPrice: 120,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Court White", hex: "#F7F7F8" },
      { name: "Signal Cyan", hex: "#00E5FF" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    stock: 210,
    badge: "Sale",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1556821833-cb4bea38e069?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1600&q=80&auto=format&fit=crop", alt: "Static Club Hoodie — front" },
      { src: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=1600&q=80&auto=format&fit=crop", alt: "Static Club Hoodie — back print" },
      { src: "https://images.unsplash.com/photo-1556821833-cb4bea38e069?w=1600&q=80&auto=format&fit=crop", alt: "Static Club Hoodie — fabric detail" }
    ],
    description:
      "Heavyweight 480gsm fleece hoodie with a boxy fit, dropped shoulder, and double-lined hood. Embroidered Static Club crest on the chest and a small reflective signal tag on the sleeve. Built to layer and built to last.",
    shortDescription: "Heavyweight 480gsm fleece hoodie with embroidered Static Club crest.",
    materials: ["100% combed cotton 480gsm fleece", "Cotton drawcord with metal tips", "Embroidered chest crest", "Reflective sleeve tag"],
    fit: "Boxy oversized fit. Dropped shoulder. Size down for a regular fit.",
    care: ["Machine wash cold inside out", "Tumble dry low", "Do not bleach", "Do not iron print"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.9,
    reviewCount: 213,
    relatedProducts: ["concrete-bloom-tee", "chrome-district-cargo", "pulse-knit-beanie"],
    styleTags: ["hoodie", "heavyweight", "oversized", "fleece"],
    featured: true,
    bestSeller: true,
    newArrival: false,
    onSale: true
  },
  {
    id: "p005",
    slug: "concrete-bloom-tee",
    name: "Concrete Bloom Tee",
    category: "Graphic Tees",
    collection: "Concrete Bloom",
    collectionSlug: "concrete-bloom",
    price: 48,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Court White", hex: "#F7F7F8" },
      { name: "Soft Purple", hex: "#8B5CF6" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    stock: 320,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1600&q=80&auto=format&fit=crop", alt: "Concrete Bloom Tee — front print" },
      { src: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1600&q=80&auto=format&fit=crop", alt: "Concrete Bloom Tee — side profile" },
      { src: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=1600&q=80&auto=format&fit=crop", alt: "Concrete Bloom Tee — back blank" }
    ],
    description:
      "240gsm heavyweight cotton tee with a front plastisol print of the Concrete Bloom graphic. Boxy fit, ribbed collar, double-needle hems. The graphic is hand-illustrated by our in-house art team in Berlin.",
    shortDescription: "Heavyweight 240gsm cotton tee with hand-illustrated Concrete Bloom graphic.",
    materials: ["100% combed cotton 240gsm jersey", "Plastisol front print", "Ribbed crew collar", "Double-needle hems"],
    fit: "Boxy fit. True to size.",
    care: ["Machine wash cold inside out", "Tumble dry low", "Do not iron print", "Do not dry clean"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.7,
    reviewCount: 156,
    relatedProducts: ["static-club-hoodie", "archive-black-tee", "chrome-district-cargo"],
    styleTags: ["tee", "graphic", "heavyweight", "boxy-fit"],
    featured: false,
    bestSeller: true,
    newArrival: true,
    onSale: false
  },
  {
    id: "p006",
    slug: "chrome-district-cargo",
    name: "Chrome District Cargo",
    category: "Cargo Pants",
    collection: "Chrome District",
    collectionSlug: "chrome-district",
    price: 138,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Concrete Grey", hex: "#8A93A3" }
    ],
    sizes: ["28", "30", "32", "34", "36", "38"],
    stock: 98,
    badge: "Best Seller",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=1600&q=80&auto=format&fit=crop", alt: "Chrome District Cargo — front view" },
      { src: "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?w=1600&q=80&auto=format&fit=crop", alt: "Chrome District Cargo — pocket detail" },
      { src: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=1600&q=80&auto=format&fit=crop", alt: "Chrome District Cargo — back view" }
    ],
    description:
      "Technical cargo pants in a mid-weight ripstop with six functional pockets, articulated knees, and a tapered leg. Drawcord ankle cinch lets you switch between a clean taper and a stacked look. Heavy-duty YKK zippers throughout.",
    shortDescription: "Technical ripstop cargo with six pockets and articulated knees.",
    materials: ["100% cotton ripstop 240gsm", "YKK metal zippers", "Bar-tack reinforcement", "Drawcord ankle cinch"],
    fit: "Relaxed through thigh, tapered from knee down. True to size.",
    care: ["Machine wash cold", "Hang dry recommended", "Warm iron if needed", "Do not bleach"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.8,
    reviewCount: 92,
    relatedProducts: ["static-club-hoodie", "after-dark-windbreaker", "streetline-utility-vest"],
    styleTags: ["cargo", "ripstop", "technical", "tapered"],
    featured: true,
    bestSeller: true,
    newArrival: false,
    onSale: false
  },
  {
    id: "p007",
    slug: "after-dark-windbreaker",
    name: "After Dark Windbreaker",
    category: "Jackets",
    collection: "After Dark",
    collectionSlug: "after-dark",
    price: 168,
    colors: [
      { name: "Midnight", hex: "#0B0D10" },
      { name: "Signal Cyan", hex: "#00E5FF" }
    ],
    sizes: ["XS", "S", "M", "L", "XL"],
    stock: 74,
    badge: "Limited",
    dropStatus: "live",
    dropDate: "2026-07-19T16:00:00Z",
    limitedQuantity: 250,
    images: [
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1559551409-dadc959f76b8?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1600&q=80&auto=format&fit=crop", alt: "After Dark Windbreaker — front" },
      { src: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=1600&q=80&auto=format&fit=crop", alt: "After Dark Windbreaker — back reflective" },
      { src: "https://images.unsplash.com/photo-1559551409-dadc959f76b8?w=1600&q=80&auto=format&fit=crop", alt: "After Dark Windbreaker — hood detail" }
    ],
    description:
      "Packable windbreaker with reflective paneling along the chest and back. Water-resistant nylon shell, mesh lining, and a hidden chest pocket that doubles as a stuff sack. The reflective hits glow under streetlight for after-dark visibility.",
    shortDescription: "Water-resistant windbreaker with reflective paneling and packable stuff-sack pocket.",
    materials: ["100% nylon water-resistant shell", "Mesh lining", "Reflective heat-applied panels", "YKK Aquaguard front zip"],
    fit: "Relaxed fit. Room for layering.",
    care: ["Wipe clean with damp cloth", "Hang dry", "Do not iron", "Do not dry clean"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.7,
    reviewCount: 61,
    relatedProducts: ["chrome-district-cargo", "midnight-runner-high", "streetline-utility-vest"],
    styleTags: ["jacket", "windbreaker", "reflective", "packable"],
    featured: true,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p008",
    slug: "signal-cap",
    name: "Signal Cap",
    category: "Caps",
    collection: "Signal Drop",
    collectionSlug: "signal-drop",
    price: 42,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Court White", hex: "#F7F7F8" },
      { name: "Hot Magenta", hex: "#FF2ED1" }
    ],
    sizes: ["One Size"],
    stock: 280,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1521369909029-2afed882baee?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1517941875066-bb29a6f7c6e1?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=1600&q=80&auto=format&fit=crop", alt: "Signal Cap — front" },
      { src: "https://images.unsplash.com/photo-1521369909029-2afed882baee?w=1600&q=80&auto=format&fit=crop", alt: "Signal Cap — side profile" },
      { src: "https://images.unsplash.com/photo-1517941875066-bb29a6f7c6e1?w=1600&q=80&auto=format&fit=crop", alt: "Signal Cap — back strap" }
    ],
    description:
      "Six-panel structured cap in brushed cotton twill with an embroidered Signal crest and a custom metal closure. Pre-curved brim, sweat-wicking headband, and a small reflective hit on the back strap.",
    shortDescription: "Six-panel structured cap with embroidered Signal crest and metal closure.",
    materials: ["100% cotton twill", "Embroidered front crest", "Metal adjustable closure", "Sweat-wicking headband"],
    fit: "One size, adjustable. Fits 54-60cm head circumference.",
    care: ["Spot clean only", "Air dry", "Do not machine wash", "Reshape brim while damp if needed"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.6,
    reviewCount: 78,
    relatedProducts: ["pulse-knit-beanie", "neon-thread-socks", "flux-crossbody-bag"],
    styleTags: ["cap", "six-panel", "adjustable", "everyday"],
    featured: false,
    bestSeller: true,
    newArrival: true,
    onSale: false
  },
  {
    id: "p009",
    slug: "flux-crossbody-bag",
    name: "Flux Crossbody Bag",
    category: "Bags",
    collection: "Chrome District",
    collectionSlug: "chrome-district",
    price: 89,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Concrete Grey", hex: "#8A93A3" }
    ],
    sizes: ["One Size"],
    stock: 144,
    badge: "Best Seller",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1591561954557-26941169b49e?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1591561954557-26941169b49e?w=1600&q=80&auto=format&fit=crop", alt: "Flux Crossbody Bag — front" },
      { src: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=1600&q=80&auto=format&fit=crop", alt: "Flux Crossbody Bag — interior" },
      { src: "https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=1600&q=80&auto=format&fit=crop", alt: "Flux Crossbody Bag — strap detail" }
    ],
    description:
      "Compact crossbody bag in water-resistant 500D cordura with a magnetic flap closure and a hidden rear pocket. Adjustable webbing strap, padded back panel, and interior card slots. Fits a phone, wallet, keys, and a small camera.",
    shortDescription: "Compact 500D cordura crossbody with magnetic flap and interior card slots.",
    materials: ["500D cordura shell", "YKK metal zippers", "Magnetic flap closure", "Webbing strap with metal hardware"],
    fit: "One size. Strap adjusts from 60cm to 120cm.",
    care: ["Spot clean with damp cloth", "Air dry", "Do not bleach"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.8,
    reviewCount: 104,
    relatedProducts: ["signal-cap", "neon-thread-socks", "streetline-utility-vest"],
    styleTags: ["bag", "crossbody", "cordura", "everyday"],
    featured: false,
    bestSeller: true,
    newArrival: false,
    onSale: false
  },
  {
    id: "p010",
    slug: "neon-thread-socks",
    name: "Neon Thread Socks",
    category: "Accessories",
    collection: "Neon Court",
    collectionSlug: "neon-court",
    price: 18,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Court White", hex: "#F7F7F8" }
    ],
    sizes: ["S/M", "L/XL"],
    stock: 540,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1586350977771-2a1dfa19a7be?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1582966772680-860e372bb2cb?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1586350977771-2a1dfa19a7be?w=1600&q=80&auto=format&fit=crop", alt: "Neon Thread Socks — pair" },
      { src: "https://images.unsplash.com/photo-1582966772680-860e372bb2cb?w=1600&q=80&auto=format&fit=crop", alt: "Neon Thread Socks — detail weave" }
    ],
    description:
      "Crew-length socks knit from a combed cotton blend with a touch of elastane for stretch. Cushioned footbed, reinforced heel and toe, and a tonal Neon Court signal stripe woven into the cuff.",
    shortDescription: "Crew socks in combed cotton blend with cushioned footbed and signal stripe.",
    materials: ["78% combed cotton", "18% polyester", "4% elastane", "Reinforced heel and toe"],
    fit: "S/M fits US 6-9, L/XL fits US 9-13.",
    care: ["Machine wash cold", "Tumble dry low", "Do not bleach", "Do not iron"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.5,
    reviewCount: 41,
    relatedProducts: ["volt-runner-01", "signal-cap", "pulse-knit-beanie"],
    styleTags: ["socks", "crew", "cotton-blend", "everyday"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p011",
    slug: "creator-capsule-hoodie",
    name: "Creator Capsule Hoodie",
    category: "Hoodies",
    collection: "Creator Capsule",
    collectionSlug: "creator-capsule",
    price: 128,
    colors: [
      { name: "Soft Purple", hex: "#8B5CF6" },
      { name: "Static Black", hex: "#0B0D10" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    stock: 88,
    badge: "Members",
    dropStatus: "live",
    dropDate: "2026-07-26T16:00:00Z",
    limitedQuantity: 200,
    images: [
      "https://images.unsplash.com/photo-1620799140188-3b2a02fd9a77?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1620799140188-3b2a02fd9a77?w=1600&q=80&auto=format&fit=crop", alt: "Creator Capsule Hoodie — front" },
      { src: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1600&q=80&auto=format&fit=crop", alt: "Creator Capsule Hoodie — side" },
      { src: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=1600&q=80&auto=format&fit=crop", alt: "Creator Capsule Hoodie — back" }
    ],
    description:
      "A capsule collaboration hoodie with a screen-printed back graphic and a small woven label on the chest. Made in a limited 200-pair run for Static Club members. Premium 420gsm cotton fleece with a relaxed fit.",
    shortDescription: "420gsm cotton fleece hoodie with screen-printed back graphic. Limited to 200 pieces.",
    materials: ["100% combed cotton 420gsm fleece", "Screen-printed back graphic", "Woven chest label", "Cotton drawcord"],
    fit: "Relaxed fit. True to size.",
    care: ["Machine wash cold inside out", "Tumble dry low", "Do not iron print", "Do not dry clean"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.9,
    reviewCount: 67,
    relatedProducts: ["static-club-hoodie", "concrete-bloom-tee", "pulse-knit-beanie"],
    styleTags: ["hoodie", "creator-capsule", "limited", "screen-print"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p012",
    slug: "archive-black-tee",
    name: "Archive Black Tee",
    category: "Graphic Tees",
    collection: "Archive Reissue",
    collectionSlug: "archive-reissue",
    price: 38,
    colors: [{ name: "Static Black", hex: "#0B0D10" }],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    stock: 410,
    badge: "Best Seller",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1600&q=80&auto=format&fit=crop", alt: "Archive Black Tee — front" },
      { src: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1600&q=80&auto=format&fit=crop", alt: "Archive Black Tee — back" }
    ],
    description:
      "A clean essential tee in 220gsm combed cotton with a small embroidered VoltHaus wordmark on the left chest. The backbone of every drop, reissued every season in fresh quantities.",
    shortDescription: "220gsm combed cotton tee with embroidered VoltHaus wordmark.",
    materials: ["100% combed cotton 220gsm jersey", "Embroidered chest wordmark", "Ribbed crew collar"],
    fit: "Regular fit. True to size.",
    care: ["Machine wash cold", "Tumble dry low", "Do not bleach", "Warm iron if needed"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.6,
    reviewCount: 189,
    relatedProducts: ["concrete-bloom-tee", "static-club-hoodie", "archive-black-tee"],
    styleTags: ["tee", "essential", "regular-fit", "everyday"],
    featured: false,
    bestSeller: true,
    newArrival: false,
    onSale: false
  },
  {
    id: "p013",
    slug: "pulse-knit-beanie",
    name: "Pulse Knit Beanie",
    category: "Accessories",
    collection: "After Dark",
    collectionSlug: "after-dark",
    price: 36,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Concrete Grey", hex: "#8A93A3" },
      { name: "Hot Magenta", hex: "#FF2ED1" }
    ],
    sizes: ["One Size"],
    stock: 230,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1517941875066-bb29a6f7c6e1?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?w=1600&q=80&auto=format&fit=crop", alt: "Pulse Knit Beanie — front" },
      { src: "https://images.unsplash.com/photo-1517941875066-bb29a6f7c6e1?w=1600&q=80&auto=format&fit=crop", alt: "Pulse Knit Beanie — folded cuff" }
    ],
    description:
      "Ribbed acrylic knit beanie with a folded cuff and a small woven VoltHaus tag. Warm, stretchy, and built to hold its shape through a full season of wear.",
    shortDescription: "Ribbed acrylic knit beanie with woven VoltHaus tag.",
    materials: ["100% acrylic ribbed knit", "Woven brand tag", "Folded cuff"],
    fit: "One size. Stretch fit.",
    care: ["Hand wash cold", "Lay flat to dry", "Do not bleach", "Do not iron"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.7,
    reviewCount: 54,
    relatedProducts: ["signal-cap", "after-dark-windbreaker", "neon-thread-socks"],
    styleTags: ["beanie", "knit", "winter", "everyday"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p014",
    slug: "streetline-utility-vest",
    name: "Streetline Utility Vest",
    category: "Jackets",
    collection: "Chrome District",
    collectionSlug: "chrome-district",
    price: 148,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Concrete Grey", hex: "#8A93A3" }
    ],
    sizes: ["S", "M", "L", "XL"],
    stock: 64,
    badge: "Limited",
    dropStatus: "live",
    dropDate: "2026-08-02T16:00:00Z",
    limitedQuantity: 180,
    images: [
      "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1559551409-dadc959f76b8?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?w=1600&q=80&auto=format&fit=crop", alt: "Streetline Utility Vest — front" },
      { src: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=1600&q=80&auto=format&fit=crop", alt: "Streetline Utility Vest — pocket layout" },
      { src: "https://images.unsplash.com/photo-1559551409-dadc959f76b8?w=1600&q=80&auto=format&fit=crop", alt: "Streetline Utility Vest — back" }
    ],
    description:
      "Modular utility vest with eight functional pockets, a hidden chest zip, and adjustable side cinch. Built from a heavy 600D shell with a mesh back panel for airflow. Designed to layer over hoodies and tees.",
    shortDescription: "Modular utility vest with eight pockets and adjustable side cinch.",
    materials: ["600D poly shell", "Mesh back panel", "YKK metal zippers", "Adjustable side cinch"],
    fit: "Relaxed fit. True to size.",
    care: ["Spot clean with damp cloth", "Air dry", "Do not bleach", "Do not iron"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.7,
    reviewCount: 38,
    relatedProducts: ["chrome-district-cargo", "after-dark-windbreaker", "flux-crossbody-bag"],
    styleTags: ["vest", "utility", "modular", "technical"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p015",
    slug: "nightdrop-sneaker-pack",
    name: "Nightdrop Sneaker Pack",
    category: "Accessories",
    collection: "After Dark",
    collectionSlug: "after-dark",
    price: 28,
    colors: [{ name: "Static Black", hex: "#0B0D10" }],
    sizes: ["One Size"],
    stock: 320,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1586350977771-2a1dfa19a7be?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1600&q=80&auto=format&fit=crop", alt: "Nightdrop Sneaker Pack — full pack" },
      { src: "https://images.unsplash.com/photo-1586350977771-2a1dfa19a7be?w=1600&q=80&auto=format&fit=crop", alt: "Nightdrop Sneaker Pack — accessories" }
    ],
    description:
      "A care pack for your sneakers. Includes a 60ml signal-clean spray, a soft horsehair brush, a microfiber cloth, and a small storage pouch. Comes in a printed kraft box with the Nightdrop graphic.",
    shortDescription: "Sneaker care pack with signal-clean spray, brush, microfiber cloth, and pouch.",
    materials: ["Printed kraft box", "60ml signal-clean spray", "Horsehair brush", "Microfiber cloth", "Storage pouch"],
    fit: "One size.",
    care: ["Keep spray away from eyes", "Test spray on small area first", "Store brush dry"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.5,
    reviewCount: 33,
    relatedProducts: ["volt-runner-01", "neon-court-low", "midnight-runner-high"],
    styleTags: ["accessories", "care-pack", "everyday"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p016",
    slug: "summer-blackout-tee",
    name: "Summer Blackout Tee",
    category: "Graphic Tees",
    collection: "Summer Blackout",
    collectionSlug: "summer-blackout",
    price: 52,
    compareAtPrice: 65,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Hot Magenta", hex: "#FF2ED1" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    stock: 180,
    badge: "Sale",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=1600&q=80&auto=format&fit=crop", alt: "Summer Blackout Tee — front" },
      { src: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1600&q=80&auto=format&fit=crop", alt: "Summer Blackout Tee — back" }
    ],
    description:
      "Heavyweight 240gsm cotton tee with a Summer Blackout graphic on the back and a small chest hit on the front. Boxy fit, ribbed collar. Last call before the collection archives for good.",
    shortDescription: "Heavyweight 240gsm cotton tee with Summer Blackout graphic. Last call.",
    materials: ["100% combed cotton 240gsm jersey", "Plastisol back graphic", "Ribbed crew collar"],
    fit: "Boxy fit. True to size.",
    care: ["Machine wash cold inside out", "Tumble dry low", "Do not iron print"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.6,
    reviewCount: 72,
    relatedProducts: ["concrete-bloom-tee", "archive-black-tee", "static-club-hoodie"],
    styleTags: ["tee", "graphic", "summer", "last-call"],
    featured: false,
    bestSeller: false,
    newArrival: false,
    onSale: true
  },
  {
    id: "p017",
    slug: "signal-runner-02",
    name: "Signal Runner 02",
    category: "Sneakers",
    collection: "Signal Drop",
    collectionSlug: "signal-drop",
    price: 199,
    colors: [
      { name: "Signal Cyan", hex: "#00E5FF" },
      { name: "Static Black", hex: "#0B0D10" }
    ],
    sizes: ["7", "8", "9", "10", "11", "12"],
    stock: 110,
    badge: "New",
    dropStatus: "upcoming",
    dropDate: "2026-08-09T16:00:00Z",
    limitedQuantity: 400,
    images: [
      "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=1600&q=80&auto=format&fit=crop", alt: "Signal Runner 02 — side profile" },
      { src: "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=1600&q=80&auto=format&fit=crop", alt: "Signal Runner 02 — top down" }
    ],
    description:
      "The second drop in the Signal Runner series. Knit upper with a translucent cage overlay, full-length VoltFoam midsole, and a signal-wave outsole tread. Limited to 400 pairs. Drops August 9, 2026 at 16:00 UTC.",
    shortDescription: "Knit upper with translucent cage and full-length VoltFoam. Drops August 9.",
    materials: ["Engineered knit upper", "Translucent TPU cage", "Full-length VoltFoam midsole", "Rubber outsole"],
    fit: "True to size. Medium width.",
    care: ["Spot clean with damp cloth", "Air dry", "Do not machine wash"],
    shipping: "Ships within 1-2 business days after drop. Free express shipping on orders over $100.",
    rating: 0,
    reviewCount: 0,
    relatedProducts: ["volt-runner-01", "neon-court-low", "midnight-runner-high"],
    styleTags: ["runner", "knit", "upcoming", "limited"],
    featured: true,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p018",
    slug: "concrete-bloom-hoodie",
    name: "Concrete Bloom Hoodie",
    category: "Hoodies",
    collection: "Concrete Bloom",
    collectionSlug: "concrete-bloom",
    price: 108,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Soft Purple", hex: "#8B5CF6" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    stock: 95,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=1600&q=80&auto=format&fit=crop", alt: "Concrete Bloom Hoodie — front" },
      { src: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1600&q=80&auto=format&fit=crop", alt: "Concrete Bloom Hoodie — side" }
    ],
    description:
      "Heavyweight 440gsm fleece hoodie with a Concrete Bloom graphic embroidered on the back. Relaxed fit, dropped shoulder, double-lined hood. The graphic reinterprets our Concrete Bloom print in tonal thread.",
    shortDescription: "440gsm fleece hoodie with embroidered Concrete Bloom back graphic.",
    materials: ["100% combed cotton 440gsm fleece", "Embroidered back graphic", "Cotton drawcord", "Double-lined hood"],
    fit: "Relaxed fit. True to size.",
    care: ["Machine wash cold inside out", "Tumble dry low", "Do not iron embroidery"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.7,
    reviewCount: 45,
    relatedProducts: ["concrete-bloom-tee", "static-club-hoodie", "archive-black-tee"],
    styleTags: ["hoodie", "heavyweight", "embroidered", "relaxed"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p019",
    slug: "midnight-cargo-shorts",
    name: "Midnight Cargo Shorts",
    category: "Cargo Pants",
    collection: "Midnight Runner",
    collectionSlug: "midnight-runner",
    price: 88,
    colors: [
      { name: "Midnight", hex: "#0B0D10" },
      { name: "Concrete Grey", hex: "#8A93A3" }
    ],
    sizes: ["28", "30", "32", "34", "36", "38"],
    stock: 145,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=1600&q=80&auto=format&fit=crop", alt: "Midnight Cargo Shorts — front" },
      { src: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=1600&q=80&auto=format&fit=crop", alt: "Midnight Cargo Shorts — pocket detail" }
    ],
    description:
      "Cargo shorts in mid-weight ripstop with a 9-inch inseam, four pockets, and a relaxed thigh. Built for summer sessions and warm-city walks. Tapered leg opening with a clean finish.",
    shortDescription: "Mid-weight ripstop cargo shorts with 9-inch inseam and four pockets.",
    materials: ["100% cotton ripstop 220gsm", "YKK metal zippers", "Belt-loop waistband"],
    fit: "Relaxed through thigh. True to size.",
    care: ["Machine wash cold", "Tumble dry low", "Do not bleach"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.5,
    reviewCount: 28,
    relatedProducts: ["chrome-district-cargo", "concrete-bloom-tee", "static-club-hoodie"],
    styleTags: ["shorts", "cargo", "summer", "ripstop"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p020",
    slug: "chrome-district-cap",
    name: "Chrome District Cap",
    category: "Caps",
    collection: "Chrome District",
    collectionSlug: "chrome-district",
    price: 46,
    colors: [
      { name: "Concrete Grey", hex: "#8A93A3" },
      { name: "Static Black", hex: "#0B0D10" }
    ],
    sizes: ["One Size"],
    stock: 195,
    badge: "Best Seller",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1517941875066-bb29a6f7c6e1?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1517941875066-bb29a6f7c6e1?w=1600&q=80&auto=format&fit=crop", alt: "Chrome District Cap — front" },
      { src: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=1600&q=80&auto=format&fit=crop", alt: "Chrome District Cap — side" }
    ],
    description:
      "Unstructured 5-panel cap with a curved brim, embroidered Chrome District wordmark, and a custom metal buckle closure. Soft cotton twill with a sweat-wicking headband.",
    shortDescription: "Unstructured 5-panel cap with embroidered wordmark and metal buckle closure.",
    materials: ["100% cotton twill", "Embroidered wordmark", "Metal buckle closure"],
    fit: "One size, adjustable. Fits 54-60cm head circumference.",
    care: ["Spot clean only", "Air dry", "Do not machine wash"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.6,
    reviewCount: 51,
    relatedProducts: ["signal-cap", "flux-crossbody-bag", "neon-thread-socks"],
    styleTags: ["cap", "5-panel", "unstructured", "everyday"],
    featured: false,
    bestSeller: true,
    newArrival: false,
    onSale: false
  },
  {
    id: "p021",
    slug: "volt-runner-03-trail",
    name: "Volt Runner 03 Trail",
    category: "Sneakers",
    collection: "Signal Drop",
    collectionSlug: "signal-drop",
    price: 229,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Concrete Grey", hex: "#8A93A3" }
    ],
    sizes: ["7", "8", "9", "10", "11", "12", "13"],
    stock: 0,
    badge: "Last Call",
    dropStatus: "sold-out",
    images: [
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1600&q=80&auto=format&fit=crop", alt: "Volt Runner 03 Trail — side" },
      { src: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1600&q=80&auto=format&fit=crop", alt: "Volt Runner 03 Trail — outsole" }
    ],
    description:
      "A trail-ready runner with a lugged outsole, water-resistant upper, and a gusseted tongue. Built for the city-to-trail commute. Currently sold out, but restock notifications are open.",
    shortDescription: "Trail-ready runner with lugged outsole and water-resistant upper. Sold out.",
    materials: ["Water-resistant synthetic upper", "Lugged rubber outsole", "Gusseted tongue", "Padded ankle collar"],
    fit: "True to size. Regular width.",
    care: ["Spot clean with damp cloth", "Air dry", "Do not machine wash"],
    shipping: "Restock notifications open. Free express shipping on orders over $100.",
    rating: 4.7,
    reviewCount: 64,
    relatedProducts: ["volt-runner-01", "signal-runner-02", "midnight-runner-high"],
    styleTags: ["runner", "trail", "water-resistant", "sold-out"],
    featured: false,
    bestSeller: false,
    newArrival: false,
    onSale: false
  },
  {
    id: "p022",
    slug: "signal-drop-tee",
    name: "Signal Drop Tee",
    category: "Graphic Tees",
    collection: "Signal Drop",
    collectionSlug: "signal-drop",
    price: 44,
    colors: [
      { name: "Court White", hex: "#F7F7F8" },
      { name: "Signal Cyan", hex: "#00E5FF" }
    ],
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    stock: 260,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1600&q=80&auto=format&fit=crop", alt: "Signal Drop Tee — front" },
      { src: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=1600&q=80&auto=format&fit=crop", alt: "Signal Drop Tee — back" }
    ],
    description:
      "220gsm combed cotton tee with a front Signal Drop graphic and a small VoltHaus woven label on the hem. Boxy fit, ribbed collar. Limited print run for this drop.",
    shortDescription: "220gsm cotton tee with front Signal Drop graphic and woven hem label.",
    materials: ["100% combed cotton 220gsm jersey", "Plastisol front graphic", "Woven hem label"],
    fit: "Boxy fit. True to size.",
    care: ["Machine wash cold inside out", "Tumble dry low", "Do not iron print"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.6,
    reviewCount: 39,
    relatedProducts: ["concrete-bloom-tee", "archive-black-tee", "summer-blackout-tee"],
    styleTags: ["tee", "graphic", "boxy", "limited-print"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  },
  {
    id: "p023",
    slug: "static-club-beanie",
    name: "Static Club Beanie",
    category: "Accessories",
    collection: "Static Club",
    collectionSlug: "static-club",
    price: 32,
    compareAtPrice: 42,
    colors: [
      { name: "Static Black", hex: "#0B0D10" },
      { name: "Court White", hex: "#F7F7F8" }
    ],
    sizes: ["One Size"],
    stock: 175,
    badge: "Sale",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1517941875066-bb29a6f7c6e1?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1517941875066-bb29a6f7c6e1?w=1600&q=80&auto=format&fit=crop", alt: "Static Club Beanie — front" },
      { src: "https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?w=1600&q=80&auto=format&fit=crop", alt: "Static Club Beanie — cuff" }
    ],
    description:
      "Cuffed acrylic beanie with an embroidered Static Club patch on the front. Soft, stretchy, and warm enough for cold-city mornings without overheating indoors.",
    shortDescription: "Cuffed acrylic beanie with embroidered Static Club patch.",
    materials: ["100% acrylic knit", "Embroidered front patch", "Folded cuff"],
    fit: "One size. Stretch fit.",
    care: ["Hand wash cold", "Lay flat to dry", "Do not bleach"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.5,
    reviewCount: 47,
    relatedProducts: ["pulse-knit-beanie", "signal-cap", "chrome-district-cap"],
    styleTags: ["beanie", "knit", "winter", "sale"],
    featured: false,
    bestSeller: false,
    newArrival: false,
    onSale: true
  },
  {
    id: "p024",
    slug: "neon-court-socks",
    name: "Neon Court Socks",
    category: "Accessories",
    collection: "Neon Court",
    collectionSlug: "neon-court",
    price: 22,
    colors: [
      { name: "Court White", hex: "#F7F7F8" },
      { name: "Static Black", hex: "#0B0D10" }
    ],
    sizes: ["S/M", "L/XL"],
    stock: 380,
    badge: "New",
    dropStatus: "live",
    images: [
      "https://images.unsplash.com/photo-1582966772680-860e372bb2cb?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1586350977771-2a1dfa19a7be?w=1200&q=80&auto=format&fit=crop"
    ],
    gallery: [
      { src: "https://images.unsplash.com/photo-1582966772680-860e372bb2cb?w=1600&q=80&auto=format&fit=crop", alt: "Neon Court Socks — pair" },
      { src: "https://images.unsplash.com/photo-1586350977771-2a1dfa19a7be?w=1600&q=80&auto=format&fit=crop", alt: "Neon Court Socks — cuff detail" }
    ],
    description:
      "Ankle-length socks in a combed cotton blend with a cushioned footbed and a Neon Court signal stripe woven into the cuff. Sold as a single pair.",
    shortDescription: "Ankle-length combed cotton socks with cushioned footbed and signal stripe.",
    materials: ["78% combed cotton", "18% polyester", "4% elastane"],
    fit: "S/M fits US 6-9, L/XL fits US 9-13.",
    care: ["Machine wash cold", "Tumble dry low", "Do not bleach"],
    shipping: "Ships within 1-2 business days. Free express shipping on orders over $100.",
    rating: 4.4,
    reviewCount: 22,
    relatedProducts: ["neon-thread-socks", "volt-runner-01", "neon-court-low"],
    styleTags: ["socks", "ankle", "cotton-blend"],
    featured: false,
    bestSeller: false,
    newArrival: true,
    onSale: false
  }
];

// Helper functions
export function getProductBySlug(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((p) => p.category.toLowerCase() === category.toLowerCase());
}

export function getProductsByCollection(collectionSlug: string): Product[] {
  return products.filter((p) => p.collectionSlug === collectionSlug);
}

export function getFeaturedProducts(): Product[] {
  return products.filter((p) => p.featured);
}

export function getBestSellers(): Product[] {
  return products.filter((p) => p.bestSeller);
}

export function getNewArrivals(): Product[] {
  return products.filter((p) => p.newArrival);
}

export function getOnSaleProducts(): Product[] {
  return products.filter((p) => p.onSale);
}

export function getRelatedProducts(slug: string, limit = 4): Product[] {
  const product = getProductBySlug(slug);
  if (!product) return [];
  return product.relatedProducts
    .map((s) => getProductBySlug(s))
    .filter((p): p is Product => Boolean(p))
    .slice(0, limit);
}

export function getAllProductSlugs(): string[] {
  return products.map((p) => p.slug);
}

export function searchProducts(query: string): Product[] {
  const q = query.toLowerCase().trim();
  if (!q) return [];
  return products.filter(
    (p) =>
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.collection.toLowerCase().includes(q) ||
      p.styleTags.some((t) => t.toLowerCase().includes(q)) ||
      p.description.toLowerCase().includes(q)
  );
}
