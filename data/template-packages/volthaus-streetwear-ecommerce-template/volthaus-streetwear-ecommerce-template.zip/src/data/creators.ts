import type { Creator } from "@/types";

// VoltHaus creator roster
// All names are fictional. All images are Unsplash HD assets with no trademarked branding.

export const creators: Creator[] = [
  {
    id: "cr001",
    slug: "kai-signals",
    name: "Kai Marchetti",
    handle: "@kai.signals",
    role: "Photographer",
    bio: "Kai shoots the city at the wrong hours and develops film in a converted hotel bathroom. His work for VoltHaus centers on long-exposure light trails and the people moving under them. He has been with the roster since the second Signal Drop capsule.",
    avatar:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&q=80&auto=format&fit=crop",
    cover:
      "https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=1600&q=80&auto=format&fit=crop",
    location: "Milan, Italy",
    socials: [
      { label: "Instagram", href: "https://instagram.com/kai.signals" },
      { label: "Portfolio", href: "https://kaimarchetti.studio" },
      { label: "Mail", href: "mailto:kai@volthaus.co" },
    ],
    capsuleProductSlugs: ["signal-drop-tee", "signal-cap"],
    story:
      "Kai started photographing breakbeat parties in the early 2010s and never really left that room. His first VoltHaus commission was a single night shoot for the Neon Court launch, where he dragged a tripod across three districts and waited for the right kind of rain. The images from that night became the visual anchor of the collection and we have been sending him the new silhouettes before they hit production ever since. When he is not on assignment he is teaching a darkroom class at a community space in the Navigli.",
    followers: "84.2K",
    drops: 3,
  },
  {
    id: "cr002",
    slug: "remy-okafor",
    name: "Remy Okafor",
    handle: "@remy.cuts",
    role: "Designer",
    bio: "Remy leads pattern development at VoltHaus and rebuilt our core hoodie block from scratch for the Creator Capsule. He trained in Antwerp and spent five years in technical outerwear before pivoting to streetwear. He works out of a shared studio in Lisbon with two other pattern cutters.",
    avatar:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80&auto=format&fit=crop",
    cover:
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1600&q=80&auto=format&fit=crop",
    location: "Lisbon, Portugal",
    socials: [
      { label: "Instagram", href: "https://instagram.com/remy.cuts" },
      { label: "Studio", href: "https://remyokafor.studio" },
      { label: "Mail", href: "mailto:remy@volthaus.co" },
    ],
    capsuleProductSlugs: ["creator-capsule-hoodie"],
    story:
      "Remy approaches pattern cutting the way a structural engineer approaches a bridge. He rebuilt the Creator Capsule hoodie from the shoulder out, lowering the seam and widening the cuff after testing twelve prototypes on different body types. He keeps a notebook of every adjustment, and the printed zine that ships with the hoodie is a direct excerpt from that notebook. Before joining the VoltHaus roster he worked on technical outerwear programs in Antwerp and contributed to two long-running pattern archives that still circulate in the trade.",
    followers: "37.8K",
    drops: 1,
  },
  {
    id: "cr003",
    slug: "noa-frey",
    name: "Noa Frey",
    handle: "@noa.frey",
    role: "Skater",
    bio: "Noa skates switch and shoots the spots nobody else will. She joined the VoltHaus roster after we noticed her wearing out a pair of Volt Runner 01s in under six weeks. She films with a small crew in Berlin and contributes wear-test notes back to the design team.",
    avatar:
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&q=80&auto=format&fit=crop",
    cover:
      "https://images.unsplash.com/photo-1483118714900-540cf339fd46?w=1600&q=80&auto=format&fit=crop",
    location: "Berlin, Germany",
    socials: [
      { label: "Instagram", href: "https://instagram.com/noa.frey" },
      { label: "YouTube", href: "https://youtube.com/@noafrey" },
      { label: "Mail", href: "mailto:noa@volthaus.co" },
    ],
    capsuleProductSlugs: ["volt-runner-01", "midnight-runner-high"],
    story:
      "Noa learned to skate on the rough plazas outside the old Tempelhof terminal and she never really adapted to smooth ground. Her feedback on the Volt Runner 01 directly shaped the midsole update for the second production batch, including a thicker toecap and a slightly wider forefoot. She wears a women's 9.5, skates every day the weather allows, and posts unfiltered wear photos every Sunday. We send her new samples before they reach the wear-test team because her notes are sharper than most of our QA reports.",
    followers: "62.5K",
    drops: 2,
  },
  {
    id: "cr004",
    slug: "dev-tanaka",
    name: "Dev Tanaka",
    handle: "@dev.tanaka",
    role: "Musician",
    bio: "Dev makes slow synth records and wears the same hoodie for entire album cycles. He scored the launch film for the Midnight Runner capsule and contributed a remix to the Signal Drop teaser. He tours small rooms in Europe and Japan twice a year.",
    avatar:
      "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=600&q=80&auto=format&fit=crop",
    cover:
      "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=1600&q=80&auto=format&fit=crop",
    location: "Tokyo, Japan",
    socials: [
      { label: "Bandcamp", href: "https://devtanaka.bandcamp.com" },
      { label: "Instagram", href: "https://instagram.com/dev.tanaka" },
      { label: "Mail", href: "mailto:dev@volthaus.co" },
    ],
    capsuleProductSlugs: ["midnight-runner-high", "static-club-hoodie"],
    story:
      "Dev treats clothing the same way he treats a synth patch, build it once and tweak it slowly for years. He has worn the same Static Club hoodie on every tour since the first run and the patina on the cuffs is now part of the look. He scored the Midnight Runner launch film in a single overnight session using only hardware synths and a field recording he made outside a Tokyo train station. We released the score as a limited cassette that shipped with the first fifty pairs of the runner.",
    followers: "29.4K",
    drops: 2,
  },
  {
    id: "cr005",
    slug: "lara-osei",
    name: "Lara Osei",
    handle: "@lara.osei",
    role: "Dancer",
    bio: "Lara is a movement director working across film and stage. She choreographed the body language for the After Dark capsule campaign and helped us understand how the windbreaker behaves in motion. She trains in contemporary and house and teaches a weekly class in South London.",
    avatar:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&q=80&auto=format&fit=crop",
    cover:
      "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=1600&q=80&auto=format&fit=crop",
    location: "London, United Kingdom",
    socials: [
      { label: "Instagram", href: "https://instagram.com/lara.osei" },
      { label: "Classes", href: "https://laraosei.move" },
      { label: "Mail", href: "mailto:lara@volthaus.co" },
    ],
    capsuleProductSlugs: ["after-dark-windbreaker", "pulse-knit-beanie"],
    story:
      "Lara came to VoltHaus through a friend who was styling the After Dark shoot and needed a body that understood wind. She reblocked two of the campaign shots on the spot because the windbreaker was not moving the way she expected, and the design team rebuilt the hem vent based on her notes. She now leads movement direction on every VoltHaus film and runs a closed wear-test session for our outerwear before each launch. Her class in South London has a six-month waitlist and we sponsor two spots every cycle.",
    followers: "47.9K",
    drops: 1,
  },
  {
    id: "cr006",
    slug: "milo-brennan",
    name: "Milo Brennan",
    handle: "@milo.brennan",
    role: "Stylist",
    bio: "Milo styles the VoltHaus lookbook and contributes a recurring column on silhouette proportion to the journal. He came up through editorial styling in New York and now splits his time between editorial and consulting. He has a soft rule against wearing more than three colors at once.",
    avatar:
      "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=600&q=80&auto=format&fit=crop",
    cover:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1600&q=80&auto=format&fit=crop",
    location: "New York, United States",
    socials: [
      { label: "Instagram", href: "https://instagram.com/milo.brennan" },
      { label: "Portfolio", href: "https://milobrennan.work" },
      { label: "Mail", href: "mailto:milo@volthaus.co" },
    ],
    capsuleProductSlugs: ["chrome-district-cargo", "flux-crossbody-bag"],
    story:
      "Milo is the person who decides what goes with what in the VoltHaus lookbook and he is annoyingly right about it most of the time. He started as a fashion assistant in New York and now splits his time between editorial work and consulting for brands that take fabric seriously. He wrote the first version of our silhouette guide that ships with the Outfit Builder tool and he reviews every lookbook before it goes to layout. When he is not styling he is restoring vintage workwear in a studio that smells like beeswax.",
    followers: "55.1K",
    drops: 2,
  },
];
