import type { NavItem } from "@/types";

// VoltHaus navigation structure
// Desktop nav supports mega-menu children. Footer is grouped by section.

export const navItems: NavItem[] = [
  {
    label: "Shop",
    href: "/shop",
    description: "Browse the full VoltHaus catalog",
    children: [
      {
        label: "New Arrivals",
        href: "/shop?filter=new-arrivals",
        description: "Just landed this season",
      },
      {
        label: "Best Sellers",
        href: "/shop?filter=best-sellers",
        description: "What the community is wearing",
      },
      {
        label: "On Sale",
        href: "/shop?filter=sale",
        description: "Last call on selected pieces",
      },
      {
        label: "All Products",
        href: "/shop",
        description: "Every VoltHaus piece in one place",
      },
    ],
  },
  {
    label: "Drops",
    href: "/drops",
    description: "Live and upcoming release calendar",
    children: [
      {
        label: "Live Drops",
        href: "/drops?status=live",
        description: "Available right now",
      },
      {
        label: "Upcoming Drops",
        href: "/drops?status=upcoming",
        description: "Reserve your spot in the queue",
      },
      {
        label: "Sold Out",
        href: "/drops?status=sold-out",
        description: "Past releases and restock alerts",
      },
      {
        label: "Members Early Access",
        href: "/drops/members",
        description: "Tier-based early access windows",
        badge: "Members",
      },
    ],
  },
  {
    label: "Sneakers",
    href: "/shop?category=Sneakers",
    description: "Footwear built for the city block",
    children: [
      {
        label: "Runners",
        href: "/shop?category=Sneakers&style=runners",
        description: "Rebound-foam daily trainers",
      },
      {
        label: "Court",
        href: "/shop?category=Sneakers&style=court",
        description: "Hardwood silhouettes rebuilt for street",
      },
      {
        label: "Trail",
        href: "/shop?category=Sneakers&style=trail",
        description: "Off-grid lugged outsoles",
      },
      {
        label: "Sneaker Care",
        href: "/shop?category=Accessories&sub=sneaker-care",
        description: "Trees, sachets, and care bundles",
      },
    ],
  },
  {
    label: "Streetwear",
    href: "/shop?category=Hoodies",
    description: "Fleece, tees, cargo, and outerwear",
    children: [
      {
        label: "Hoodies",
        href: "/shop?category=Hoodies",
        description: "Heavyweight fleece program",
      },
      {
        label: "Graphic Tees",
        href: "/shop?category=Graphic+Tees",
        description: "Hand-drawn print system",
      },
      {
        label: "Cargo Pants",
        href: "/shop?category=Cargo+Pants",
        description: "Utility geometry and ripstop",
      },
      {
        label: "Jackets",
        href: "/shop?category=Jackets",
        description: "Windbreakers and utility vests",
      },
      {
        label: "Caps",
        href: "/shop?category=Caps",
        description: "Structured six-panel program",
      },
      {
        label: "Bags",
        href: "/shop?category=Bags",
        description: "Crossbody and utility carry",
      },
    ],
  },
  {
    label: "Lookbook",
    href: "/lookbook",
    description: "Seasonal editorial and street frames",
  },
  {
    label: "Creators",
    href: "/creators",
    description: "The VoltHaus roster and their capsules",
  },
];

export const footerNav: {
  shop: NavItem[];
  company: NavItem[];
  support: NavItem[];
  legal: NavItem[];
  account: NavItem[];
} = {
  shop: [
    { label: "New Arrivals", href: "/shop?filter=new-arrivals" },
    { label: "Sneakers", href: "/shop?category=Sneakers" },
    { label: "Hoodies", href: "/shop?category=Hoodies" },
    { label: "Graphic Tees", href: "/shop?category=Graphic+Tees" },
    { label: "Cargo Pants", href: "/shop?category=Cargo+Pants" },
    { label: "Accessories", href: "/shop?category=Accessories" },
  ],
  company: [
    { label: "About VoltHaus", href: "/about" },
    { label: "Creators", href: "/creators" },
    { label: "Lookbook", href: "/lookbook" },
    { label: "Journal", href: "/blog" },
    { label: "Sustainability", href: "/sustainability" },
    { label: "Careers", href: "/careers" },
  ],
  support: [
    { label: "Help Center", href: "/help" },
    { label: "FAQ", href: "/faq" },
    { label: "Contact Us", href: "/contact" },
    { label: "Order Tracking", href: "/account/orders" },
    { label: "Size Guide", href: "/size-guide" },
    { label: "Drop Calendar", href: "/drops" },
  ],
  legal: [
    { label: "Privacy Policy", href: "/policies/privacy" },
    { label: "Terms of Service", href: "/policies/terms" },
    { label: "Cookie Policy", href: "/policies/cookies" },
    { label: "Refund Policy", href: "/policies/refund-policy" },
    { label: "Returns Policy", href: "/policies/returns-policy" },
    { label: "Shipping Policy", href: "/policies/shipping-policy" },
    { label: "Accessibility", href: "/policies/accessibility" },
  ],
  account: [
    { label: "Sign In", href: "/account/login" },
    { label: "Create Account", href: "/account/register" },
    { label: "My Orders", href: "/account/orders" },
    { label: "Wishlist", href: "/account/wishlist" },
    { label: "Addresses", href: "/account/addresses" },
    { label: "Membership", href: "/account/membership" },
  ],
};

export const announcementBarMessages: string[] = [
  "Free express shipping on orders over $150",
  "Signal Drop lands October 4 — members get early access",
  "Pulse tier members get 15 minutes of drop early access",
  "After Dark capsule drops September 13",
  "Free returns within 30 days, no questions asked",
  "Members earn 1 point per dollar spent",
];
