import type { FAQ } from "@/types";

// VoltHaus FAQ knowledge base
// Answers are specific to VoltHaus policy and operations.

export const faqCategories = [
  "Orders",
  "Shipping",
  "Returns",
  "Payments",
  "Products",
  "Account",
  "Drops",
] as const;

export const faqs: FAQ[] = [
  // Orders
  {
    id: "fq001",
    category: "Orders",
    question: "How long after placing an order will I receive a confirmation?",
    answer:
      "You will receive an order confirmation email within two minutes of placing your order. If you do not see it, check your spam folder and then contact support@volthaus.co with your order number.",
  },
  {
    id: "fq002",
    category: "Orders",
    question: "Can I modify or cancel my order after it has been placed?",
    answer:
      "You can modify or cancel an order within sixty minutes of placing it by visiting the order detail page in your account. After the sixty-minute window the order moves into fulfillment and can no longer be changed.",
  },
  {
    id: "fq003",
    category: "Orders",
    question: "Why was my order split into multiple shipments?",
    answer:
      "Orders that include items from different warehouses or pre-order items may ship in separate packages. You will receive a tracking number for each shipment and you will not be charged additional shipping for the split.",
  },
  // Shipping
  {
    id: "fq004",
    category: "Shipping",
    question: "What are the shipping options and how long do they take?",
    answer:
      "Standard shipping takes three to five business days and is free on orders over $150. Express shipping takes one to two business days for a flat fee of $18. Same-day shipping is available in select cities at checkout.",
  },
  {
    id: "fq005",
    category: "Shipping",
    question: "Do you ship internationally and what about customs?",
    answer:
      "We ship to over forty countries with duties and taxes calculated at checkout. For most destinations the price you pay at checkout is the final price and you will not owe additional customs fees on delivery.",
  },
  {
    id: "fq006",
    category: "Shipping",
    question: "How do I track my shipment?",
    answer:
      "Once your order ships you will receive an email with a tracking number. You can also view live tracking from the order detail page in your account, which pulls the latest carrier updates directly.",
  },
  {
    id: "fq007",
    category: "Shipping",
    question: "What happens if my package is lost or stolen?",
    answer:
      "If your tracking shows delivered but you have not received the package, wait 24 hours and then contact support. We will open a carrier investigation and ship a replacement or issue a refund once the investigation concludes.",
  },
  // Returns
  {
    id: "fq008",
    category: "Returns",
    question: "What is your return window?",
    answer:
      "You have thirty days from delivery to return unworn items with original tags and packaging. Footwear must be tried on indoors and returned in the original box with no shipping labels affixed to the box itself.",
  },
  {
    id: "fq009",
    category: "Returns",
    question: "How do I start a return?",
    answer:
      "Visit the order detail page in your account, select the item you want to return, and choose a reason. We will email you a prepaid return label and process your refund within three business days of receiving the item.",
  },
  {
    id: "fq010",
    category: "Returns",
    question: "Can I exchange an item for a different size or color?",
    answer:
      "Exchanges are handled as a return plus a new order to guarantee inventory. Start a return for the item you have and place a new order for the size or color you want, and we will refund the original once it arrives.",
  },
  {
    id: "fq011",
    category: "Returns",
    question: "Are drop items eligible for return?",
    answer:
      "Most drop items are eligible for the standard thirty-day return. A small number of limited capsules are marked final sale on the product page and are not eligible for return unless they arrive damaged.",
  },
  // Payments
  {
    id: "fq012",
    category: "Payments",
    question: "What payment methods do you accept?",
    answer:
      "We accept Visa, Mastercard, American Express, Apple Pay, Google Pay, and PayPal. We also offer installment payments through Affirm at checkout for orders over $75.",
  },
  {
    id: "fq013",
    category: "Payments",
    question: "When is my payment method charged?",
    answer:
      "Your payment method is authorized at checkout and captured when the order ships. For pre-order items, payment is captured at the time of order to reserve your allocation of the drop.",
  },
  {
    id: "fq014",
    category: "Payments",
    question: "Is checkout secure and how do you protect my card data?",
    answer:
      "Checkout is processed through a PCI-compliant payment provider and we never store full card numbers on our servers. Card tokens are stored only with the issuing processor and never on VoltHaus infrastructure.",
  },
  // Products
  {
    id: "fq015",
    category: "Products",
    question: "How do VoltHaus sneakers fit compared to other brands?",
    answer:
      "Our sneakers fit true to size for a medium width. If you are between sizes or have a wide foot we recommend going up a half size. Each product page has a fit note from the design team and links to the full size guide.",
  },
  {
    id: "fq016",
    category: "Products",
    question: "Are your products covered by a warranty?",
    answer:
      "All VoltHaus products carry a two-year warranty against manufacturing defects. The warranty does not cover normal wear and tear, and we offer a repair credit for standard fixes during the warranty period.",
  },
  {
    id: "fq017",
    category: "Products",
    question: "Where are VoltHaus products manufactured?",
    answer:
      "Our footwear is manufactured in Portugal and our apparel is manufactured in Portugal and Turkey. Fabric sourcing is documented on each product page and our ripstop is woven in a single workshop in Osaka.",
  },
  // Account
  {
    id: "fq018",
    category: "Account",
    question: "What are the member tiers and what do they unlock?",
    answer:
      "Member tiers are Signal, Pulse, and Static. Higher tiers unlock longer early-access windows for drops, free express shipping, and an annual repair credit. Tier is calculated from your trailing twelve-month spend.",
  },
  {
    id: "fq019",
    category: "Account",
    question: "How do I reset my password?",
    answer:
      "Use the forgot password link on the sign-in page and we will email you a reset link valid for thirty minutes. If you do not receive the email, contact support and we can reset it manually after verifying your identity.",
  },
  {
    id: "fq020",
    category: "Account",
    question: "Can I merge two accounts or change my email address?",
    answer:
      "Email changes can be made from the account settings page. To merge two accounts, contact support with both email addresses and we will consolidate order history, points, and tier status into a single account.",
  },
  // Drops
  {
    id: "fq021",
    category: "Drops",
    question: "How do drops work and what is early access?",
    answer:
      "Drops release at a specific time listed on the drop calendar. Members get early access based on tier, with Signal opening one minute before public, Pulse three minutes, and Static the full fifteen minutes.",
  },
  {
    id: "fq022",
    category: "Drops",
    question: "Do you restock sold-out drop items?",
    answer:
      "Most drop items are produced in a single run and are not restocked. The Archive Reissue program occasionally brings back revised versions of past pieces, which are announced on the drop calendar and to members by email.",
  },
];

export function getFAQsByCategory(category: string): FAQ[] {
  return faqs.filter((faq) => faq.category === category);
}
