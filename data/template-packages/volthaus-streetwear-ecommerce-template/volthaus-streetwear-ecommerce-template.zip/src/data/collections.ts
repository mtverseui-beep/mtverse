import type { Collection } from "@/types";

// VoltHaus collection catalog
// All image URLs reference Unsplash HD assets with no trademarked branding visible.

export const collections: Collection[] = [
  {
    id: "c001",
    slug: "neon-court",
    name: "Neon Court",
    tagline: "Court silhouettes charged with electric colorways",
    description:
      "Neon Court reimagines the late-night basketball aesthetic with reactive cyan uppers and a translucent cage system. Built for the city block, not the hardwood, every pair is finished with reflective Signal stitching that catches streetlight at dusk. Drop one sold through in under nine minutes and the restock queue has been growing ever since.",
    cover:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=2000&q=80&auto=format&fit=crop",
    productSlugs: [
      "volt-runner-01",
      "neon-court-low",
      "neon-thread-socks",
      "neon-court-socks",
    ],
    dropDate: "2026-07-12T16:00:00Z",
    status: "live",
    theme: { primary: "#00E5FF", secondary: "#0B0D10" },
  },
  {
    id: "c002",
    slug: "midnight-runner",
    name: "Midnight Runner",
    tagline: "High-collar runners built for the 4am loop",
    description:
      "Midnight Runner is a quiet capsule for the people moving while the city sleeps. We leaned into tonal black-on-black material studies with a single magenta pull tab as the only chromatic break. The outsole uses a softer rebound foam tuned for pre-dawn concrete at low temperatures.",
    cover:
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=2000&q=80&auto=format&fit=crop",
    productSlugs: ["midnight-runner-high", "midnight-cargo-shorts"],
    dropDate: "2026-08-02T16:00:00Z",
    status: "live",
    theme: { primary: "#8B5CF6", secondary: "#0B0D10" },
  },
  {
    id: "c003",
    slug: "static-club",
    name: "Static Club",
    tagline: "Heavyweight fleece for the late-shift community",
    description:
      "Static Club is our flagship fleece program with double-brushed 480gsm cotton and overlocked seams you can feel through a jacket. The capsule was developed with a crew of night-shift creatives who wanted something that survived the studio and the corner store without looking like a uniform. A tonal silicone patch marks every member piece.",
    cover:
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=2000&q=80&auto=format&fit=crop",
    productSlugs: ["static-club-hoodie", "static-club-beanie"],
    dropDate: "2026-06-21T16:00:00Z",
    status: "live",
    theme: { primary: "#8A93A3", secondary: "#0B0D10" },
  },
  {
    id: "c004",
    slug: "concrete-bloom",
    name: "Concrete Bloom",
    tagline: "Floral graphics warped by asphalt distortion",
    description:
      "Concrete Bloom takes soft botanical line work and runs it through a halftone distortion until the petals read like spray texture. The graphic system was hand-drawn in our Berlin studio and then re-rendered in vector for crisp screen prints at scale. Every piece in the capsule pairs a tonal black base with a single soft purple accent.",
    cover:
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=2000&q=80&auto=format&fit=crop",
    productSlugs: ["concrete-bloom-tee", "concrete-bloom-hoodie"],
    dropDate: "2026-05-30T16:00:00Z",
    status: "live",
    theme: { primary: "#8B5CF6", secondary: "#14171D" },
  },
  {
    id: "c005",
    slug: "after-dark",
    name: "After Dark",
    tagline: "Outerwear engineered for the second shift",
    description:
      "After Dark is our outerwear capsule for the part of the day that nobody plans for. Windbreakers use a triple-ripstop shell with bonded seams, while the knit program leans on merino blends that hold warmth without bulk. Reflective hits are kept small and placed only where they catch headlights from behind.",
    cover:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1551232864-3f0890e580d9?w=2000&q=80&auto=format&fit=crop",
    productSlugs: [
      "after-dark-windbreaker",
      "pulse-knit-beanie",
      "nightdrop-sneaker-pack",
    ],
    dropDate: "2026-09-13T16:00:00Z",
    status: "upcoming",
    theme: { primary: "#00E5FF", secondary: "#14171D" },
  },
  {
    id: "c006",
    slug: "signal-drop",
    name: "Signal Drop",
    tagline: "High-frequency colorways on runner silhouettes",
    description:
      "Signal Drop is our recurring experimental capsule where we test new color logic and material combos before bringing them into the mainline. Each drop is numbered and limited to one production run, with no restocks once inventory clears. The cap is the marker of the capsule and rotates color every season.",
    cover:
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=2000&q=80&auto=format&fit=crop",
    productSlugs: [
      "signal-cap",
      "signal-runner-02",
      "volt-runner-03-trail",
      "signal-drop-tee",
    ],
    dropDate: "2026-10-04T16:00:00Z",
    status: "upcoming",
    theme: { primary: "#FF2ED1", secondary: "#0B0D10" },
  },
  {
    id: "c007",
    slug: "chrome-district",
    name: "Chrome District",
    tagline: "Utility cargo program with industrial hardware",
    description:
      "Chrome District is our utility capsule built around reinforced cargo geometry and a tonal grey palette. Every piece uses custom-milled ripstop with welded pocket openings and matte metal hardware sourced from a single workshop in Osaka. The crossbody bag is the spine of the program and pairs with every silhouette in the capsule.",
    cover:
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=2000&q=80&auto=format&fit=crop",
    productSlugs: [
      "chrome-district-cargo",
      "flux-crossbody-bag",
      "streetline-utility-vest",
      "chrome-district-cap",
    ],
    dropDate: "2026-07-26T16:00:00Z",
    status: "live",
    theme: { primary: "#8A93A3", secondary: "#14171D" },
  },
  {
    id: "c008",
    slug: "summer-blackout",
    name: "Summer Blackout",
    tagline: "Black-on-black summer essentials with hot magenta hits",
    description:
      "Summer Blackout is the answer to the question of what to wear when it is too hot for layers but you still want a uniform. The capsule is intentionally narrow, anchored by a single tee in three fabrications and a hot magenta signal stitch. It is built to be bought in multiples and rotated through the week.",
    cover:
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=2000&q=80&auto=format&fit=crop",
    productSlugs: ["summer-blackout-tee"],
    dropDate: "2026-06-14T16:00:00Z",
    status: "sold-out",
    theme: { primary: "#FF2ED1", secondary: "#0B0D10" },
  },
  {
    id: "c009",
    slug: "creator-capsule",
    name: "Creator Capsule",
    tagline: "A co-built hoodie program with our resident creators",
    description:
      "Creator Capsule is a single-piece collaboration program where one creator works with our pattern team from sketch to sample. The first release comes from a stylist based in Lisbon who rebuilt our core hoodie pattern with a dropped shoulder and a wider cuff. The capsule ships with a printed zine documenting the build process.",
    cover:
      "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?w=2000&q=80&auto=format&fit=crop",
    productSlugs: ["creator-capsule-hoodie"],
    dropDate: "2026-09-27T16:00:00Z",
    status: "upcoming",
    theme: { primary: "#8B5CF6", secondary: "#0B0D10" },
  },
  {
    id: "c010",
    slug: "archive-reissue",
    name: "Archive Reissue",
    tagline: "Re-cut pieces pulled from the first three VoltHaus seasons",
    description:
      "Archive Reissue is our look back at the early VoltHaus seasons, recut with upgraded fabrications and corrected patterns based on what the community told us. Each piece in the program ships with a printed tag showing the original release date and the changes made for this version. Inventory is intentionally small and will not be reprinted.",
    cover:
      "https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?w=1600&q=80&auto=format&fit=crop",
    hero:
      "https://images.unsplash.com/photo-1495121605193-b116b5b9c5fe?w=2000&q=80&auto=format&fit=crop",
    productSlugs: ["archive-black-tee"],
    dropDate: "2026-04-18T16:00:00Z",
    status: "live",
    theme: { primary: "#8A93A3", secondary: "#0B0D10" },
  },
];
