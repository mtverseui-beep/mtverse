import type { Customer } from "@/types";

// VoltHaus mock customer for the account area
// All personal details are fictional. Avatar references an Unsplash HD portrait asset.

export const mockCustomer: Customer = {
  id: "cust-001",
  name: "Alex Whitlock",
  email: "alex.whitlock@example.com",
  phone: "+1 (415) 555-0142",
  avatar:
    "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80&auto=format&fit=crop",
  memberSince: "2024-03-15",
  tier: "Pulse",
  points: 1240,
  addresses: [
    {
      id: "addr-001",
      label: "Home",
      name: "Alex Whitlock",
      line1: "412 Larkin Street",
      line2: "Apt 7B",
      city: "San Francisco",
      state: "CA",
      zip: "94102",
      country: "United States",
      isDefault: true,
    },
    {
      id: "addr-002",
      label: "Studio",
      name: "Alex Whitlock",
      line1: "98 Folsom Street",
      line2: "Suite 410",
      city: "San Francisco",
      state: "CA",
      zip: "94105",
      country: "United States",
      isDefault: false,
    },
    {
      id: "addr-003",
      label: "Brooklyn",
      name: "Alex Whitlock",
      line1: "78 Greene Street",
      line2: "Floor 3",
      city: "Brooklyn",
      state: "NY",
      zip: "11201",
      country: "United States",
      isDefault: false,
    },
  ],
  paymentMethods: [
    {
      id: "pm-001",
      brand: "Visa",
      last4: "4291",
      expiry: "08/27",
      isDefault: true,
    },
    {
      id: "pm-002",
      brand: "Mastercard",
      last4: "8842",
      expiry: "11/26",
      isDefault: false,
    },
    {
      id: "pm-003",
      brand: "Apple Pay",
      last4: "Apple Pay",
      expiry: "Apple Pay",
      isDefault: false,
    },
  ],
};
