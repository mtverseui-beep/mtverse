import type { PolicyDoc } from "@/types";

// VoltHaus policy library
// All policy content is original and specific to VoltHaus operations.

export const policies: PolicyDoc[] = [
  {
    id: "pol001",
    slug: "privacy",
    title: "Privacy Policy",
    updated: "2026-08-01",
    summary:
      "How VoltHaus collects, uses, and protects your personal information when you shop with us or interact with our content. We collect only what we need to run the business and we never sell your data.",
    sections: [
      {
        heading: "Information We Collect",
        body:
          "We collect information you provide directly, including your name, email, shipping address, and payment details when you place an order. We also collect limited behavioral data such as the pages you view and the products you add to cart, which we use to improve the site experience. We do not collect biometric data, precise location data from mobile devices, or data from third-party advertising networks beyond what is strictly necessary to measure campaign performance.",
      },
      {
        heading: "How We Use Your Information",
        body:
          "We use your information to fulfill orders, process payments, communicate about your orders, and provide member benefits tied to your account. We also use aggregated, de-identified data to analyze trends and improve our product offering. We do not use your personal data to train external machine learning models and we do not share your data with third parties for their independent marketing purposes.",
      },
      {
        heading: "Data Sharing and Partners",
        body:
          "We share your data only with the partners required to operate the business, including our payment processor, shipping carriers, and email service provider. Each partner is bound by a data processing agreement that limits how they can use your data. We do not sell your data, and we will not share your data with law enforcement except where required by a valid legal process.",
      },
      {
        heading: "Your Rights and Choices",
        body:
          "You can access, correct, export, or delete your personal data from the account settings page or by contacting support@volthaus.co. You can opt out of marketing emails at any time using the unsubscribe link in any email. If you are a resident of California or the European Union, additional rights apply and you can exercise them through the same channels.",
      },
      {
        heading: "Data Retention",
        body:
          "We retain your order data for the period required by tax and accounting law, which is generally seven years. We retain marketing preference data until you ask us to delete it. When data is no longer needed we delete it or anonymize it so that it can no longer be associated with you.",
      },
    ],
  },
  {
    id: "pol002",
    slug: "terms",
    title: "Terms of Service",
    updated: "2026-08-01",
    summary:
      "The terms that govern your use of the VoltHaus website and your purchases from us. By placing an order you agree to these terms and to our refund and shipping policies.",
    sections: [
      {
        heading: "Using the Site",
        body:
          "You may use the VoltHaus site for lawful purposes only. You agree not to attempt to disrupt the site, to use bots or scrapers to access inventory outside of normal user flows, or to resell access to your account. We may suspend or terminate accounts that violate these terms, particularly in cases of automated purchasing during drops.",
      },
      {
        heading: "Orders and Acceptance",
        body:
          "Placing an order constitutes an offer to purchase, which we accept when we ship the order. We reserve the right to refuse or cancel any order for any reason, including suspected fraudulent activity or errors in pricing. If we cancel an order we will refund the full amount within three business days and notify you by email.",
      },
      {
        heading: "Pricing and Errors",
        body:
          "We work hard to keep pricing accurate, but errors can occur. If we discover a pricing error after you place an order we will notify you and offer the option to confirm at the correct price or cancel for a full refund. We are not obligated to fulfill orders placed at an incorrect price.",
      },
      {
        heading: "Intellectual Property",
        body:
          "All content on the VoltHaus site, including product photography, copy, and graphic design, is the property of VoltHaus or its licensors. You may not reproduce, redistribute, or use our content for commercial purposes without written permission. User-generated content submitted to the site remains your property but you grant us a license to use it for marketing purposes.",
      },
      {
        heading: "Limitation of Liability",
        body:
          "VoltHaus is not liable for indirect, incidental, or consequential damages arising from your use of the site or our products. Our total liability for any claim is limited to the amount you paid for the product that gave rise to the claim. This limitation does not apply where prohibited by law.",
      },
    ],
  },
  {
    id: "pol003",
    slug: "cookies",
    title: "Cookie Policy",
    updated: "2026-08-01",
    summary:
      "How VoltHaus uses cookies and similar technologies to operate the site and measure performance. You can control cookies through your browser settings and through our consent banner.",
    sections: [
      {
        heading: "What Are Cookies",
        body:
          "Cookies are small text files stored on your device when you visit a website. We use cookies to keep you signed in, to remember the contents of your cart, and to measure how the site is used. We also use local storage for the same purposes where cookies are not available.",
      },
      {
        heading: "Categories of Cookies We Use",
        body:
          "We use strictly necessary cookies to operate the site, including session and cart cookies. We use preference cookies to remember your settings such as size and currency. We use analytics cookies to understand traffic patterns, and we use limited marketing cookies to measure the performance of our campaigns. Analytics and marketing cookies are only set after you provide consent.",
      },
      {
        heading: "Managing Cookies",
        body:
          "You can manage your cookie preferences at any time through the cookie settings link in the footer. You can also disable cookies in your browser settings, but strictly necessary cookies cannot be disabled without breaking core site functionality such as checkout.",
      },
      {
        heading: "Third-Party Cookies",
        body:
          "We use a small number of trusted third-party services that may set cookies, including our payment processor, email service provider, and analytics platform. These third parties have their own cookie policies and we encourage you to review them. We do not allow third-party advertising networks to set cookies on our site.",
      },
    ],
  },
  {
    id: "pol004",
    slug: "accessibility",
    title: "Accessibility Statement",
    updated: "2026-08-01",
    summary:
      "Our commitment to making VoltHaus usable for everyone, including people using assistive technology. We follow WCAG 2.1 AA as our baseline and test continuously with real users.",
    sections: [
      {
        heading: "Our Commitment",
        body:
          "VoltHaus is committed to making our website usable by everyone, including people who rely on screen readers, keyboard navigation, voice control, and other assistive technologies. We use the Web Content Accessibility Guidelines version 2.1 at the AA level as our baseline. We test the site continuously with both automated tools and real users who depend on assistive technology.",
      },
      {
        heading: "What We Have Done",
        body:
          "We have implemented semantic HTML throughout the site, full keyboard navigation with visible focus indicators, and alternative text for all product and editorial imagery. We have also ensured that color contrast meets WCAG AA standards across the full theme and that forms are properly labeled and announced by screen readers. Cart, checkout, and account flows have been tested end to end with assistive technology.",
      },
      {
        heading: "Known Limitations",
        body:
          "Some third-party widgets, including social embeds and certain payment flows, may not meet the same standard as the rest of the site. We are working with our vendors to address these gaps and we list known issues on a public status page. If you encounter a barrier, please contact us and we will work with you directly to complete your transaction.",
      },
      {
        heading: "How to Report an Issue",
        body:
          "If you encounter an accessibility barrier on the VoltHaus site, please email support@volthaus.co with a description of the issue and the page where it occurred. We respond to accessibility reports within two business days and we prioritize fixes based on impact. You can also contact us by phone for assistance placing an order.",
      },
    ],
  },
  {
    id: "pol005",
    slug: "refund-policy",
    title: "Refund Policy",
    updated: "2026-08-01",
    summary:
      "When and how we issue refunds, including the processing timeline and the form of the refund. Refunds are issued to the original payment method unless otherwise arranged.",
    sections: [
      {
        heading: "Eligibility for Refunds",
        body:
          "Refunds are issued for returned items that meet the criteria in our returns policy, for orders cancelled within the sixty-minute window, and for orders that we cancel due to inventory or pricing errors. Final sale items are not eligible for refunds unless they arrive damaged or defective.",
      },
      {
        heading: "Refund Processing Timeline",
        body:
          "Refunds are processed within three business days of our warehouse receiving and inspecting the returned item. The refund will appear on your original payment method within five to ten business days after processing, depending on your bank. If you do not see the refund after ten business days, contact support with your order number.",
      },
      {
        heading: "Form of Refund",
        body:
          "Refunds are issued to the original payment method. If you paid with a gift card or store credit, the refund is issued as store credit. If the original payment method is no longer available, contact support and we will arrange an alternative refund method after verifying your identity.",
      },
      {
        heading: "Partial Refunds",
        body:
          "Partial refunds may be issued for items that are returned with missing packaging, without original tags, or with signs of wear beyond what is necessary to try the item on. We will notify you before issuing a partial refund and provide photo evidence of the condition. You may dispute a partial refund decision by replying to the notification email.",
      },
    ],
  },
  {
    id: "pol006",
    slug: "returns-policy",
    title: "Returns Policy",
    updated: "2026-08-01",
    summary:
      "How to return VoltHaus products, what condition they need to be in, and how long you have to start a return. Most items are eligible for a thirty-day return window.",
    sections: [
      {
        heading: "Return Window",
        body:
          "You have thirty days from the delivery date to return eligible items. The return window is extended during the holiday season for orders placed in November and December, with specific dates posted on this page each year. Items marked final sale on the product page are not eligible for return.",
      },
      {
        heading: "Condition Requirements",
        body:
          "Returned items must be unworn, unwashed, and have all original tags attached. Footwear must be tried on indoors only and returned in the original box, which should not be used as the shipping container. Items returned in condition that does not meet these requirements may be subject to a partial refund or may be returned to you.",
      },
      {
        heading: "How to Start a Return",
        body:
          "Visit the order detail page in your account, select the item you want to return, and choose a reason from the dropdown. We will email you a prepaid return label within one business day. Drop the package at any carrier location and your refund will be processed within three business days of arrival at our warehouse.",
      },
      {
        heading: "Exchanges",
        body:
          "We do not run a formal exchange program because inventory moves too quickly to hold a size while we wait for a return. To exchange, start a return for the item you have and place a new order for the size or color you want. The refund from your return will process independently of the new order.",
      },
      {
        heading: "Damaged or Defective Items",
        body:
          "If an item arrives damaged or defective, contact support within seven days of delivery with photos of the issue. We will send a replacement at no cost or issue a full refund, and we will provide a return label for the damaged item if we need it back for inspection.",
      },
    ],
  },
  {
    id: "pol007",
    slug: "shipping-policy",
    title: "Shipping Policy",
    updated: "2026-08-01",
    summary:
      "Where we ship, how long it takes, and what it costs. Free standard shipping is included on all orders over $150 to most destinations.",
    sections: [
      {
        heading: "Shipping Destinations",
        body:
          "We ship to over forty countries across North America, Europe, Asia, and the Pacific. The list of available destinations and the calculated shipping cost are shown at checkout based on your shipping address. If your country is not listed, contact support and we may be able to arrange a manual shipment.",
      },
      {
        heading: "Shipping Methods and Timelines",
        body:
          "Standard shipping takes three to five business days and is free on orders over $150. Express shipping takes one to two business days for a flat fee of $18. Same-day shipping is available in select cities for orders placed before noon local time. Pre-order items ship on or before the date listed on the product page.",
      },
      {
        heading: "Order Processing",
        body:
          "Orders are processed within one business day of placement, excluding weekends and public holidays. Orders placed after 2pm local warehouse time may not ship until the following business day. You will receive a shipping confirmation email with a tracking number as soon as your order leaves the warehouse.",
      },
      {
        heading: "Duties and Taxes",
        body:
          "For most international destinations we calculate duties and taxes at checkout using a delivered-duty-paid model, which means the price you pay at checkout is the final price and you will not owe additional fees on delivery. For a small number of destinations we ship duties unpaid, which is clearly indicated at checkout before you complete your purchase.",
      },
      {
        heading: "Lost or Delayed Shipments",
        body:
          "If your shipment is delayed beyond the estimated delivery window, contact support and we will open a carrier investigation. If a package is confirmed lost we will ship a replacement or issue a full refund at your option. Stolen packages are handled on a case-by-case basis and may require a police report for high-value orders.",
      },
    ],
  },
];

export function getPolicyBySlug(slug: string): PolicyDoc | undefined {
  return policies.find((policy) => policy.slug === slug);
}
