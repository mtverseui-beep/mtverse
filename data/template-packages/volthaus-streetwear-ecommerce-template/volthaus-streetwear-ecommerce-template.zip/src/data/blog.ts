import type { BlogPost } from "@/types";

// VoltHaus journal
// All author names are fictional. Cover images reference Unsplash HD assets.

export const blogPosts: BlogPost[] = [
  {
    id: "bp001",
    slug: "anatomy-of-a-drop",
    title: "Anatomy of a Drop: What Actually Happens Behind the Curtain",
    excerpt:
      "A walk through the 72 hours before a VoltHaus drop goes live, from the inventory lock to the queue logic that keeps the site from collapsing. We break down what members see and what the rest of the line sees.",
    body:
      "The 72 hours before a VoltHaus drop are quieter than people expect. Inventory is locked and double-counted at the warehouse, the early-access queue is staged on a separate cluster, and the product pages go into a pre-launch state that hides the buy button until the exact drop minute. We do not run a waitlist for the general line because the queue math gets unpredictable past ten thousand concurrent users, and we would rather the site stay upright than collect emails we cannot service.\n\nThe member early-access window opens fifteen minutes before the public drop and is governed by a token-based system tied to your account tier. Signal tier gets a one-minute head start, Pulse gets three, and Static gets the full fifteen. We do not publicly publish the exact tier offsets because the goal is to reward engagement, not to create a public leaderboard. If you have ever wondered why two members seem to land the same size at the same moment, the tier system is the reason.\n\nOnce the public drop opens, the buy flow is intentionally stripped down. You cannot add more than one unit of a single SKU per size, and the cart holds inventory for ten minutes before releasing it back to the pool. We have tested longer holds and they create a hoarding problem where a small number of carts lock up the available stock. Ten minutes is the number we landed on after a year of data and it has held up across every drop since.\n\nAfter the drop, the team meets for a thirty-minute debrief where we look at sell-through by size, queue abandonment, and the number of carts that timed out without converting. Those numbers shape the next drop. If a size sells through in under ninety seconds we flag it for a possible restock, and if a size sits we ask the design team whether the silhouette needs a second colorway before we reorder.",
    cover:
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1600&q=80&auto=format&fit=crop",
    author: "Remy Okafor",
    authorAvatar:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80&auto=format&fit=crop",
    category: "Drop Culture",
    tags: ["drops", "members", "early access", "operations"],
    publishedAt: "2026-08-04T09:00:00Z",
    readTime: "6 min read",
    relatedProductSlugs: ["signal-runner-02", "signal-drop-tee"],
  },
  {
    id: "bp002",
    slug: "keeping-your-sneakers-alive",
    title: "Keeping Your Sneakers Alive: A Field-Tested Care Routine",
    excerpt:
      "A practical care routine built from wear-test notes across three VoltHaus silhouettes, covering cleaning cadence, storage, and the one brush you actually need. No hype products, just the steps that extend the life of a shoe.",
    body:
      "The single biggest factor in how long a sneaker lasts is how it dries, not how it is cleaned. Most people clean too aggressively and then dry the shoe next to a radiator, which is the worst combination you can run. A soft horsehair brush and lukewarm water with a drop of mild soap is enough for ninety percent of the dirt you will encounter, and the shoe should always air-dry at room temperature with shoe trees or stuffed paper inside to hold the shape.\n\nFor the Volt Runner 01 and Neon Court Low, the knit upper responds best to a gentle circular brush motion followed by a damp microfiber wipe-down. The midsole scuffs can be lifted with a melamine sponge cut to a small block, but you should test an inconspicuous area first because the foam can scuff if you press too hard. The translucent cage on the Neon Court Low yellows slowly over time and there is no way to fully reverse it, so storing the shoes out of direct sunlight is the best defense.\n\nStorage matters more than people think. Stacking sneakers without a shoe tree will collapse the heel counter within a season, and the original box is fine for short-term storage but traps moisture if you live somewhere humid. We recommend a breathable shelf with at least two inches of clearance between pairs and a sachet of silica gel in each shoe during the wet months. The Original VoltHaus Sneaker Pack includes a fitted shoe tree and a sachet, which is why it ships as a bundle.\n\nFinally, rotate your shoes. Wearing the same pair every day does not give the foam enough time to decompress and the upper enough time to fully dry, which is how you get premature midsole compression and persistent odor. Three pairs in rotation is the sweet spot for a daily wearer and it will easily double the usable life of each pair.",
    cover:
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1600&q=80&auto=format&fit=crop",
    author: "Noa Frey",
    authorAvatar:
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80&auto=format&fit=crop",
    category: "Sneaker Care",
    tags: ["sneakers", "care", "maintenance", "storage"],
    publishedAt: "2026-07-19T09:00:00Z",
    readTime: "7 min read",
    relatedProductSlugs: ["volt-runner-01", "neon-court-low", "nightdrop-sneaker-pack"],
  },
  {
    id: "bp003",
    slug: "three-look-rule",
    title: "The Three-Look Rule: A Practical Framework for Daily Styling",
    excerpt:
      "Milo Brennan breaks down the three-look framework he uses to style the VoltHaus lookbook and how it translates to a real closet. The goal is fewer decisions in the morning, not more options.",
    body:
      "The three-look rule is a constraint I started using on editorial shoots because the alternative was spending forty minutes on outfits that looked the same on camera. The idea is that you build three complete looks around a single anchor piece, photograph them once, and then rotate through them for the season. The anchor is usually a sneaker or an outerwear piece, and the supporting garments are chosen to make the anchor read differently each time.\n\nFor the FW26 After Dark capsule, the anchor was the After Dark Windbreaker and the three looks were a tonal black monochrome, a contrast grey-and-cyan pairing, and a layered utility look with the Streetline Utility Vest over the top. Each look uses no more than three colors and the windbreaker is the only constant. The constraint forces you to think about proportion and texture instead of just adding more garments, which is how you end up looking like a clothing rack.\n\nThe framework works in a real closet because it forces you to own fewer, better pieces. If you can build three complete looks around one anchor, you can build nine looks around three anchors and that is more than enough for a season. The trick is to choose anchors that share a color logic so the supporting garments can move between looks without clashing. VoltHaus collections are intentionally narrow for this reason, the colorways are designed to cross-reference.\n\nThe last piece is documentation. Take a phone photo of each look the first time you wear it so you can rebuild it from memory on a tired morning. I keep a folder of thirty or so looks on my phone and I never have to think about what to wear before coffee. The goal of the three-look rule is not to look styled, it is to stop thinking about clothing once you have made the initial decisions.",
    cover:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1600&q=80&auto=format&fit=crop",
    author: "Milo Brennan",
    authorAvatar:
      "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=200&q=80&auto=format&fit=crop",
    category: "Street Styling",
    tags: ["styling", "lookbook", "framework", "minimal"],
    publishedAt: "2026-09-15T09:00:00Z",
    readTime: "5 min read",
    relatedProductSlugs: ["after-dark-windbreaker", "streetline-utility-vest", "static-club-hoodie"],
  },
  {
    id: "bp004",
    slug: "kai-signals-night-shoot",
    title: "Kai Signals: A Night Shoot With the Neon Court Crew",
    excerpt:
      "A conversation with Kai Marchetti about the Milan night shoot that anchored the Neon Court launch and what it takes to photograph a sneaker in streetlight. We talk gear, weather, and waiting for the right kind of rain.",
    body:
      "The Neon Court launch film almost did not happen on the night we shot it. The forecast called for clear skies and Kai had built the entire shot list around wet pavement reflections, which meant we either waited for the next storm or we changed the concept. Kai does not change concepts, so we waited. Around two in the morning a light drizzle started and within twenty minutes the pavement on the closed street was reflective enough to shoot.\n\nKai works almost exclusively with available light and a single handheld LED panel for fill. The Neon Court shoot used a Sony body with a fast prime and a tripod for the long-exposure light trails that became the visual anchor of the campaign. He does not believe in chasing the latest gear and he has shot entire campaigns on bodies that the rest of the industry would consider outdated. The argument is that a camera you know completely is more useful than a camera with better specs that you are still learning.\n\nThe cast for the shoot was pulled from the local skate scene the day before, which is standard practice for Kai. He prefers working with people who already move naturally in the clothes rather than models who have to be coached into a posture. Most of the final frames in the lookbook were captured in the first thirty minutes of the shoot, before anyone started performing for the camera. The lesson he keeps repeating is that the best frames happen when people forget you are shooting.\n\nThe shoot wrapped at four in the morning and Kai developed the film the same day in his hotel bathroom. He scanned it overnight and delivered the final selects to the VoltHaus team by the following afternoon. The entire campaign, from casting to delivery, took less than forty-eight hours, which is a pace most studios would consider impossible. Kai would say the pace is only possible because the concept was clear before the shoot started.",
    cover:
      "https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=1600&q=80&auto=format&fit=crop",
    author: "Kai Marchetti",
    authorAvatar:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80&auto=format&fit=crop",
    category: "Creator Stories",
    tags: ["photography", "campaign", "milan", "neon-court"],
    publishedAt: "2026-07-15T09:00:00Z",
    readTime: "8 min read",
    relatedProductSlugs: ["volt-runner-01", "neon-court-low"],
  },
  {
    id: "bp005",
    slug: "fabric-with-a-future",
    title: "Fabric With a Future: How We Source for the Long Haul",
    excerpt:
      "A look at the VoltHaus material sourcing program, from the Osaka ripstop workshop to the recycled cotton blend in our heavyweight fleece. Sustainability for us means building things that do not need replacing every season.",
    body:
      "Sustainability in streetwear has become a marketing category and we are suspicious of most of it. The honest version of the conversation is that the most sustainable garment is the one you wear for five years instead of one, and the most sustainable fabric is the one that holds its shape and color long enough to make that possible. Our sourcing program is built around that single principle and it shapes every material decision we make.\n\nThe Chrome District ripstop is woven in a single workshop in Osaka that has been running the same looms since the 1970s. We chose that workshop because the fabric they produce has a documented wear life of more than a decade in commercial use, which is the benchmark we use for our utility program. The workshop operates on a closed-loop water system and sources its cotton through a cooperative that pays above market rate, but those details are secondary to the fact that the fabric itself outlasts anything we could source at scale elsewhere.\n\nThe heavyweight fleece in the Static Club program uses a recycled cotton blend with a small percentage of recycled polyester for stability. We tested a fully recycled cotton version and it bagged out at the elbows within three washes, which is the opposite of sustainable because the garment ends up in a landfill faster. The current blend holds its shape past fifty washes in our internal wear tests and we publish those results on the product page so you can verify the claims.\n\nThe last piece of the program is repair. Every VoltHaus garment comes with a repair credit that covers standard fixes like zipper replacement and seam reinforcement for the first two years. If a garment cannot be repaired we will take it back and recycle the fabric through our Osaka partner. The goal is to keep our product out of a landfill for as long as possible, and the only way we know how to do that is to build it right the first time and fix it when it breaks.",
    cover:
      "https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?w=1600&q=80&auto=format&fit=crop",
    author: "Remy Okafor",
    authorAvatar:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80&auto=format&fit=crop",
    category: "Sustainability",
    tags: ["sustainability", "materials", "sourcing", "repair"],
    publishedAt: "2026-08-28T09:00:00Z",
    readTime: "7 min read",
    relatedProductSlugs: ["chrome-district-cargo", "static-club-hoodie", "streetline-utility-vest"],
  },
  {
    id: "bp006",
    slug: "behind-the-creator-capsule",
    title: "Behind the Creator Capsule: Building a Hoodie From the Shoulder Out",
    excerpt:
      "Remy Okafor walks through the twelve prototypes that became the Creator Capsule Hoodie and why the dropped shoulder is the most contested decision in the entire program. Pattern notes, sample photos, and the zine that ships with every order.",
    body:
      "The Creator Capsule program starts with a single creator and a single garment, and the first release is a rebuilt version of our core hoodie. Remy Okafor came in with a clear thesis, which is that the standard hoodie block is wrong about the shoulder. The seam sits too high on most production hoodies and it restricts the arm when you reach forward, which is the motion you make when you are working at a desk or carrying a bag. The fix is a dropped shoulder, but a dropped shoulder changes the sleeve length and the cuff measurement, which is why most brands do not bother.\n\nThe first four prototypes were about establishing the shoulder drop. Remy started with a two-centimeter drop and worked up to four centimeters over three weeks of wear testing. The four-centimeter drop was the version that stopped restricting the arm without making the sleeve look too long, and it became the anchor for the rest of the pattern. The cuff was widened by half a centimeter to balance the visual weight of the dropped shoulder, and the body was lengthened by one centimeter to keep the proportion reading correctly when layered.\n\nThe next four prototypes were about the fabric. The standard Static Club fleece was the starting point but Remy wanted a tighter face for the Creator Capsule, so we worked with the mill to compress the surface slightly and increase the brushed interior weight. The result is a fleece that reads cleaner from the outside and feels warmer against the skin. The fabric decision delayed the capsule by six weeks, which is the kind of trade-off the Creator Capsule program is designed to allow.\n\nThe last four prototypes were about the details. The silicone patch was repositioned twice, the drawcord tips were changed from matte to brushed metal, and the interior loop was removed entirely because it kept catching on hangers. Every change is documented in the printed zine that ships with the hoodie, which is the whole point of the program. We want the wearer to understand the decisions that went into the garment, not just the marketing story around it.",
    cover:
      "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1600&q=80&auto=format&fit=crop",
    author: "Remy Okafor",
    authorAvatar:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80&auto=format&fit=crop",
    category: "Behind the Design",
    tags: ["pattern", "hoodie", "creator-capsule", "design"],
    publishedAt: "2026-09-28T09:00:00Z",
    readTime: "9 min read",
    relatedProductSlugs: ["creator-capsule-hoodie", "static-club-hoodie"],
  },
];

export function getBlogPostBySlug(slug: string): BlogPost | undefined {
  return blogPosts.find((post) => post.slug === slug);
}

export function getAllBlogSlugs(): string[] {
  return blogPosts.map((post) => post.slug);
}

export function getBlogPostsByCategory(category: string): BlogPost[] {
  return blogPosts.filter((post) => post.category === category);
}
