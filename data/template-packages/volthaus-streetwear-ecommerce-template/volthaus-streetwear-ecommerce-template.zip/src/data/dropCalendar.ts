import type { DropCalendarEntry } from "@/types";

// VoltHaus drop calendar
// Upcoming entries use future dates in 2026; live and sold-out use past dates.

export const dropCalendar: DropCalendarEntry[] = [
  {
    id: "dc001",
    productSlug: "signal-runner-02",
    productName: "Signal Runner 02",
    collection: "Signal Drop",
    date: "2026-10-04T16:00:00Z",
    time: "16:00 UTC",
    status: "upcoming",
    image:
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=1200&q=80&auto=format&fit=crop",
    category: "Sneakers",
    membersOnly: true,
  },
  {
    id: "dc002",
    productSlug: "signal-drop-tee",
    productName: "Signal Drop Tee",
    collection: "Signal Drop",
    date: "2026-10-04T16:00:00Z",
    time: "16:00 UTC",
    status: "upcoming",
    image:
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1200&q=80&auto=format&fit=crop",
    category: "Graphic Tees",
    membersOnly: true,
  },
  {
    id: "dc003",
    productSlug: "creator-capsule-hoodie",
    productName: "Creator Capsule Hoodie",
    collection: "Creator Capsule",
    date: "2026-09-27T16:00:00Z",
    time: "16:00 UTC",
    status: "upcoming",
    image:
      "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1200&q=80&auto=format&fit=crop",
    category: "Hoodies",
    membersOnly: true,
  },
  {
    id: "dc004",
    productSlug: "after-dark-windbreaker",
    productName: "After Dark Windbreaker",
    collection: "After Dark",
    date: "2026-09-13T16:00:00Z",
    time: "16:00 UTC",
    status: "upcoming",
    image:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=1200&q=80&auto=format&fit=crop",
    category: "Jackets",
    membersOnly: false,
  },
  {
    id: "dc005",
    productSlug: "volt-runner-01",
    productName: "Volt Runner 01",
    collection: "Neon Court",
    date: "2026-07-12T16:00:00Z",
    time: "16:00 UTC",
    status: "live",
    image:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&q=80&auto=format&fit=crop",
    category: "Sneakers",
    membersOnly: false,
  },
  {
    id: "dc006",
    productSlug: "chrome-district-cargo",
    productName: "Chrome District Cargo",
    collection: "Chrome District",
    date: "2026-07-26T16:00:00Z",
    time: "16:00 UTC",
    status: "live",
    image:
      "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=1200&q=80&auto=format&fit=crop",
    category: "Cargo Pants",
    membersOnly: false,
  },
  {
    id: "dc007",
    productSlug: "summer-blackout-tee",
    productName: "Summer Blackout Tee",
    collection: "Summer Blackout",
    date: "2026-06-14T16:00:00Z",
    time: "16:00 UTC",
    status: "sold-out",
    image:
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1200&q=80&auto=format&fit=crop",
    category: "Graphic Tees",
    membersOnly: false,
  },
  {
    id: "dc008",
    productSlug: "concrete-bloom-tee",
    productName: "Concrete Bloom Tee",
    collection: "Concrete Bloom",
    date: "2026-05-30T16:00:00Z",
    time: "16:00 UTC",
    status: "sold-out",
    image:
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1200&q=80&auto=format&fit=crop",
    category: "Graphic Tees",
    membersOnly: false,
  },
];

export function getUpcomingDrops(): DropCalendarEntry[] {
  return dropCalendar.filter((entry) => entry.status === "upcoming");
}

export function getLiveDrops(): DropCalendarEntry[] {
  return dropCalendar.filter((entry) => entry.status === "live");
}

export function getSoldOutDrops(): DropCalendarEntry[] {
  return dropCalendar.filter((entry) => entry.status === "sold-out");
}
