// VoltHaus shared ecommerce types

export type ProductCategory =
  | "Sneakers"
  | "Hoodies"
  | "Graphic Tees"
  | "Cargo Pants"
  | "Jackets"
  | "Caps"
  | "Bags"
  | "Accessories";

export type DropStatus = "upcoming" | "live" | "sold-out" | "restock";

export type Badge = "New" | "Limited" | "Best Seller" | "Sale" | "Members" | "Restock" | "Last Call";

export interface ProductColor {
  name: string;
  hex: string;
}

export interface ProductImage {
  src: string;
  alt: string;
}

export interface ProductReview {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  title: string;
  body: string;
  date: string;
  verified: boolean;
  size?: string;
}

export interface ProductQuestion {
  id: string;
  author: string;
  question: string;
  answer: string;
  date: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: ProductCategory;
  collection: string;
  collectionSlug: string;
  price: number;
  compareAtPrice?: number;
  colors: ProductColor[];
  sizes: string[];
  stock: number;
  badge?: Badge;
  dropStatus: DropStatus;
  dropDate?: string;
  limitedQuantity?: number;
  images: string[];
  gallery: ProductImage[];
  description: string;
  shortDescription: string;
  materials: string[];
  fit: string;
  care: string[];
  shipping: string;
  rating: number;
  reviewCount: number;
  relatedProducts: string[];
  styleTags: string[];
  featured?: boolean;
  bestSeller?: boolean;
  newArrival?: boolean;
  onSale?: boolean;
  reviews?: ProductReview[];
  questions?: ProductQuestion[];
}

export interface Collection {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  cover: string;
  hero: string;
  productSlugs: string[];
  dropDate: string;
  status: DropStatus;
  theme: {
    primary: string;
    secondary: string;
  };
}

export interface Creator {
  id: string;
  slug: string;
  name: string;
  handle: string;
  role: string;
  bio: string;
  avatar: string;
  cover: string;
  location: string;
  socials: { label: string; href: string }[];
  capsuleProductSlugs: string[];
  story: string;
  followers: string;
  drops: number;
}

export interface Campaign {
  id: string;
  slug: string;
  name: string;
  season: string;
  description: string;
  cover: string;
  gallery: string[];
  lookProductSlugs: string[];
  publishedAt: string;
}

export interface Review {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  title: string;
  body: string;
  date: string;
  productSlug: string;
  productName: string;
  verified: boolean;
}

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  body: string;
  cover: string;
  author: string;
  authorAvatar: string;
  category: string;
  tags: string[];
  publishedAt: string;
  readTime: string;
  relatedProductSlugs?: string[];
}

export interface LookbookItem {
  id: string;
  slug: string;
  title: string;
  category: string;
  image: string;
  description: string;
  productSlugs: string[];
  season: string;
}

export interface MockOrderItem {
  productId: string;
  name: string;
  slug: string;
  image: string;
  size: string;
  color: string;
  quantity: number;
  price: number;
}

export interface MockOrder {
  id: string;
  number: string;
  date: string;
  status: "Processing" | "Shipped" | "Delivered" | "Cancelled" | "Refunded";
  total: number;
  subtotal: number;
  shipping: number;
  tax: number;
  items: MockOrderItem[];
  shippingAddress: {
    name: string;
    line1: string;
    line2?: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  };
  trackingNumber?: string;
  estimatedDelivery?: string;
  timeline: { label: string; date: string; completed: boolean }[];
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar: string;
  memberSince: string;
  tier: "Signal" | "Pulse" | "Static";
  points: number;
  addresses: Address[];
  paymentMethods: PaymentMethod[];
}

export interface Address {
  id: string;
  label: string;
  name: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  isDefault: boolean;
}

export interface PaymentMethod {
  id: string;
  brand: "Visa" | "Mastercard" | "Amex" | "Apple Pay";
  last4: string;
  expiry: string;
  isDefault: boolean;
}

export interface FAQ {
  id: string;
  category: string;
  question: string;
  answer: string;
}

export interface PolicyDoc {
  id: string;
  slug: string;
  title: string;
  updated: string;
  summary: string;
  sections: { heading: string; body: string }[];
}

export interface NavItem {
  label: string;
  href: string;
  description?: string;
  children?: NavItem[];
  badge?: string;
}

export interface SizeGuideEntry {
  size: string;
  us: string;
  eu: string;
  uk: string;
  cm: string;
  inches: string;
}

export interface SizeGuideTable {
  category: ProductCategory;
  unit: "cm" | "in";
  rows: SizeGuideEntry[];
}

export interface DropCalendarEntry {
  id: string;
  productSlug: string;
  productName: string;
  collection: string;
  date: string;
  time: string;
  status: DropStatus;
  image: string;
  category: ProductCategory;
  membersOnly: boolean;
}

export interface OutfitBuilderOption {
  type: "Sneaker" | "Hoodie" | "Tee" | "Pants" | "Accessory";
  productSlug: string;
}

// Cart/Wishlist/Compare types
export interface CartItem {
  productId: string;
  slug: string;
  name: string;
  image: string;
  price: number;
  size: string;
  color: string;
  quantity: number;
  category: ProductCategory;
}

export interface WishlistItem {
  productId: string;
  slug: string;
  name: string;
  image: string;
  price: number;
  addedAt: string;
}

export interface CompareItem {
  productId: string;
  slug: string;
  name: string;
  image: string;
  price: number;
  compareAtPrice?: number;
  colors: ProductColor[];
  sizes: string[];
  materials: string[];
  fit: string;
  dropStatus: DropStatus;
  rating: number;
  reviewCount: number;
  category: ProductCategory;
}

// Toast
export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  variant: "default" | "success" | "error" | "warning";
}
