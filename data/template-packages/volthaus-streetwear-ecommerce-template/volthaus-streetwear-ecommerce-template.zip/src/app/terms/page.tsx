import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPolicyBySlug } from "@/data/policies";
import { PolicyLayout } from "@/components/content/policy-layout";

const SLUG = "terms";
const siteUrl = "https://volthaus.co";
const canonicalUrl = `${siteUrl}/terms`;

export const metadata: Metadata = {
  title: "Terms of Service",
  description:
    "The terms that govern your use of the VoltHaus website and your purchases from us, including orders, pricing, and intellectual property.",
  alternates: { canonical: canonicalUrl },
  openGraph: {
    title: "Terms of Service | VoltHaus",
    description:
      "The terms that govern your use of the VoltHaus website and your purchases from us.",
    url: canonicalUrl,
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title: "Terms of Service | VoltHaus",
    description:
      "The terms that govern your use of the VoltHaus website and your purchases.",
  },
  robots: { index: true, follow: true },
};

export default function TermsOfServicePage() {
  const policy = getPolicyBySlug(SLUG);
  if (!policy) notFound();
  return <PolicyLayout policy={policy} />;
}
