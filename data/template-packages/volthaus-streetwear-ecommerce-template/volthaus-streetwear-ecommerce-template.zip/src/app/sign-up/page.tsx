import type { Metadata } from "next";
import { AuthLayout } from "@/components/auth/auth-layout";
import { SignUpForm } from "@/components/auth/sign-up-form";

export const metadata: Metadata = {
  title: "Join the Static Club",
  description:
    "Create your VoltHaus account to unlock member-only drops, earn rewards points, and check out faster.",
  robots: { index: false, follow: false },
};

export default function SignUpPage() {
  return (
    <AuthLayout
      eyebrow="Become a member"
      title="Join the Static Club"
      description="Earn 100 bonus points when you create your account today."
    >
      <SignUpForm />
    </AuthLayout>
  );
}
