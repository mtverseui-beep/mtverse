import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPolicyBySlug } from "@/data/policies";
import { PolicyLayout } from "@/components/content/policy-layout";

const SLUG = "accessibility";
const siteUrl = "https://volthaus.co";
const canonicalUrl = `${siteUrl}/accessibility`;

export const metadata: Metadata = {
  title: "Accessibility Statement",
  description:
    "VoltHaus is committed to making our website usable by everyone. We follow WCAG 2.1 AA as our baseline and test continuously with real users.",
  alternates: { canonical: canonicalUrl },
  openGraph: {
    title: "Accessibility Statement | VoltHaus",
    description:
      "Our commitment to making VoltHaus usable for everyone, including people using assistive technology.",
    url: canonicalUrl,
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title: "Accessibility Statement | VoltHaus",
    description:
      "Our commitment to making VoltHaus usable for everyone, including people using assistive technology.",
  },
  robots: { index: true, follow: true },
};

export default function AccessibilityStatementPage() {
  const policy = getPolicyBySlug(SLUG);
  if (!policy) notFound();
  return <PolicyLayout policy={policy} />;
}
