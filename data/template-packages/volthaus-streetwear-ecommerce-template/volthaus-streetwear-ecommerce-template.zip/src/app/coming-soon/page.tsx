"use client";

import { useState, useCallback, type FormEvent } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { Rocket, ArrowRight, Home, CheckCircle2, Loader2, AlertCircle } from "lucide-react";
import { useReducedMotion } from "@/hooks";
import { useToastStore } from "@/store/toast-store";
import { cn } from "@/lib/utils";

const EMAIL_REGEX = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;

type Status = "idle" | "submitting" | "success" | "error";

export default function ComingSoonPage() {
  const reducedMotion = useReducedMotion();
  const addToast = useToastStore((s) => s.addToast);
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [validationError, setValidationError] = useState<string | null>(null);

  const validate = useCallback((value: string): string | null => {
    if (!value.trim()) return "Email is required";
    if (!EMAIL_REGEX.test(value.trim())) {
      return "Enter a valid email address";
    }
    return null;
  }, []);

  const handleSubmit = useCallback(
    async (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      const trimmed = email.trim();
      const error = validate(trimmed);
      if (error) {
        setValidationError(error);
        setStatus("error");
        return;
      }
      setValidationError(null);
      setStatus("submitting");

      // Simulate an API call. In production this would POST to /api/notify.
      try {
        await new Promise((resolve) => setTimeout(resolve, 800));
        setStatus("success");
        setEmail("");
        addToast({
          title: "You're on the list",
          description:
            "We'll email you the moment this goes live. Check your inbox to confirm.",
          variant: "success",
        });
      } catch {
        setStatus("error");
        setValidationError("Something went wrong. Please try again.");
        addToast({
          title: "Couldn't subscribe",
          description: "Please try again in a moment.",
          variant: "error",
        });
      }
    },
    [addToast, email, validate]
  );

  const containerVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 } }
    : {
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
      };

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-background text-foreground">
      {/* Background grid */}
      <div
        aria-hidden="true"
        className="grid-bg pointer-events-none absolute inset-0 opacity-40"
      />

      {/* Glow orbs */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-[18%] top-[20%] h-72 w-72 rounded-full bg-primary/20 blur-[120px] animate-pulse-glow"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-[18%] bottom-[18%] h-72 w-72 rounded-full bg-accent/20 blur-[110px] animate-pulse-glow-magenta"
      />

      {/* Top-left logo */}
      <div className="relative z-10 p-6 sm:p-8">
        <Link
          href="/"
          aria-label="VoltHaus home"
          className="inline-flex items-center gap-2 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Image
            src="/logo.svg"
            alt=""
            width={120}
            height={28}
            priority
            className="h-7 w-auto"
          />
          <span className="sr-only">VoltHaus</span>
        </Link>
      </div>

      <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-4 pb-16 pt-4 sm:px-6">
        <motion.div
          {...containerVariants}
          transition={
            reducedMotion
              ? { duration: 0 }
              : { duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }
          }
          className="w-full max-w-xl text-center"
        >
          {/* Icon medallion */}
          <motion.div
            initial={reducedMotion ? { opacity: 0 } : { scale: 0.8, opacity: 0 }}
            animate={reducedMotion ? { opacity: 1 } : { scale: 1, opacity: 1 }}
            transition={
              reducedMotion
                ? { duration: 0 }
                : { duration: 0.5, ease: "backOut", delay: 0.15 }
            }
            className="mx-auto mb-8 inline-flex h-20 w-20 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10"
          >
            <Rocket
              className="h-9 w-9 text-primary"
              aria-hidden="true"
              strokeWidth={1.75}
            />
          </motion.div>

          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-primary">
            Coming soon
          </p>

          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
            Coming soon
          </h1>

          <p className="mx-auto mt-4 max-w-md text-pretty text-sm text-muted-foreground sm:text-base">
            We&apos;re putting the final touches on this. Drop your email and
            we&apos;ll let you know when it goes live.
          </p>

          {/* Email form / success state */}
          <div className="mx-auto mt-8 max-w-md">
            {status === "success" ? (
              <div
                role="status"
                aria-live="polite"
                className="glass flex items-center gap-3 rounded-lg border border-primary/40 p-4 text-left"
              >
                <CheckCircle2
                  className="h-6 w-6 shrink-0 text-primary"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-sm font-semibold text-foreground">
                    You&apos;re on the list
                  </p>
                  <p className="text-xs text-muted-foreground">
                    We&apos;ll email you the moment this drops. Check your
                    inbox to confirm your spot.
                  </p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <div className="relative flex-1">
                    <label htmlFor="coming-soon-email" className="sr-only">
                      Email address
                    </label>
                    <input
                      id="coming-soon-email"
                      type="email"
                      inputMode="email"
                      autoComplete="email"
                      name="email"
                      placeholder="you@email.com"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (validationError) setValidationError(null);
                        if (status === "error") setStatus("idle");
                      }}
                      aria-invalid={validationError ? "true" : "false"}
                      aria-describedby={
                        validationError ? "coming-soon-email-error" : undefined
                      }
                      className={cn(
                        "w-full rounded-md border bg-card/60 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                        validationError
                          ? "border-destructive focus-visible:ring-destructive"
                          : "border-border"
                      )}
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={status === "submitting"}
                    className="btn-shine inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-70 disabled:hover:scale-100"
                  >
                    {status === "submitting" ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                        Subscribing
                      </>
                    ) : (
                      <>
                        Notify me
                        <ArrowRight className="h-4 w-4" aria-hidden="true" />
                      </>
                    )}
                  </button>
                </div>
                {validationError ? (
                  <p
                    id="coming-soon-email-error"
                    role="alert"
                    className="mt-2 flex items-center justify-center gap-1.5 text-xs text-destructive sm:justify-start"
                  >
                    <AlertIcon />
                    {validationError}
                  </p>
                ) : (
                  <p className="mt-2 text-xs text-muted-foreground/80">
                    No spam. Unsubscribe anytime. We use your email only to
                    notify you about this release.
                  </p>
                )}
              </form>
            )}
          </div>

          <div className="mt-10 border-t border-border pt-6">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
            >
              <Home className="h-3.5 w-3.5" aria-hidden="true" />
              Back to home
            </Link>
          </div>
        </motion.div>
      </main>
    </div>
  );
}

function AlertIcon() {
  return (
    <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
  );
}
