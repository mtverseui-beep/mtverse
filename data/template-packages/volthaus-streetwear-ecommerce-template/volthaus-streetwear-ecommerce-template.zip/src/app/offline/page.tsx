"use client";

import { useState, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { RefreshCw, WifiOff, ArrowRight, Home } from "lucide-react";
import { useReducedMotion } from "@/hooks";

export default function OfflinePage() {
  const reducedMotion = useReducedMotion();
  const [reloading, setReloading] = useState(false);

  const handleRetry = useCallback(() => {
    setReloading(true);
    // Defer so the spinner state can paint before the reload begins.
    if (typeof window !== "undefined") {
      window.setTimeout(() => {
        window.location.reload();
      }, 250);
    }
  }, []);

  const containerVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 } }
    : {
        initial: { opacity: 0, y: 16 },
        animate: { opacity: 1, y: 0 },
      };

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-background text-foreground">
      {/* Background grid */}
      <div
        aria-hidden="true"
        className="grid-bg pointer-events-none absolute inset-0 opacity-40"
      />
      {/* Glow orb */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/2 h-[480px] w-[480px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/10 blur-[140px]"
      />

      {/* Top-left logo */}
      <div className="relative z-10 p-6 sm:p-8">
        <Link
          href="/"
          aria-label="VoltHaus home"
          className="inline-flex items-center gap-2 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Image
            src="/logo.svg"
            alt=""
            width={120}
            height={28}
            priority
            className="h-7 w-auto"
          />
          <span className="sr-only">VoltHaus</span>
        </Link>
      </div>

      <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-4 pb-16 pt-4 sm:px-6">
        <motion.div
          {...containerVariants}
          transition={
            reducedMotion
              ? { duration: 0 }
              : { duration: 0.5, ease: [0.25, 0.4, 0.25, 1] }
          }
          className="w-full max-w-xl text-center"
        >
          {/* Icon medallion */}
          <div className="mx-auto mb-8 inline-flex h-20 w-20 items-center justify-center rounded-2xl border border-accent/30 bg-accent/10">
            <WifiOff
              className="h-9 w-9 text-accent"
              aria-hidden="true"
              strokeWidth={1.75}
            />
          </div>

          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/30 bg-accent/5 px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-accent">
            Offline
          </p>

          <h1 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl md:text-5xl">
            You&apos;re offline
          </h1>

          <p className="mx-auto mt-4 max-w-md text-pretty text-sm text-muted-foreground sm:text-base">
            VoltHaus needs a connection to load the latest drops. Check your
            network and try again.
          </p>

          <div className="mt-8 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
            <button
              type="button"
              onClick={handleRetry}
              disabled={reloading}
              className="btn-shine inline-flex items-center justify-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-70 disabled:hover:scale-100"
            >
              <RefreshCw
                className={reloading ? "h-4 w-4 animate-spin" : "h-4 w-4"}
                aria-hidden="true"
              />
              {reloading ? "Reloading" : "Try again"}
            </button>
            <Link
              href="/shop"
              className="inline-flex items-center justify-center gap-2 rounded-md border border-border bg-card/60 px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              Browse cached drops
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
          </div>

          <p className="mt-6 text-xs text-muted-foreground/80">
            Pages you&apos;ve already visited may still load from cache, but
            checkout and account actions require a live connection.
          </p>

          <div className="mt-8 border-t border-border pt-6">
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
            >
              <Home className="h-3.5 w-3.5" aria-hidden="true" />
              Back to home
            </Link>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
