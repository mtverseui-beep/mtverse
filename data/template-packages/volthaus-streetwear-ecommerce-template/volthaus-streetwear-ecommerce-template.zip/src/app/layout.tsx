import type { Metadata, Viewport } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains-mono",
  display: "swap",
});

const siteUrl = "https://volthaus.co";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "VoltHaus — Limited Sneakers & Streetwear Drops",
    template: "%s | VoltHaus",
  },
  description:
    "Shop limited sneakers, streetwear, creator capsules, accessories, and exclusive drops from VoltHaus. Built for the next street culture wave.",
  keywords: [
    "VoltHaus",
    "sneakers",
    "streetwear",
    "limited drops",
    "creator capsules",
    "hoodies",
    "urban fashion",
    "exclusive sneakers",
  ],
  authors: [{ name: "VoltHaus" }],
  creator: "VoltHaus",
  publisher: "VoltHaus",
  applicationName: "VoltHaus",
  generator: "VoltHaus",
  icons: {
    icon: "/icon.svg",
    shortcut: "/icon.svg",
    apple: "/icon.svg",
  },
  manifest: undefined,
  openGraph: {
    title: "VoltHaus — Limited Sneakers & Streetwear Drops",
    description:
      "Shop limited sneakers, streetwear, creator capsules, accessories, and exclusive drops from VoltHaus.",
    url: siteUrl,
    siteName: "VoltHaus",
    type: "website",
    locale: "en_US",
    images: [
      {
        url: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&q=80&auto=format&fit=crop",
        width: 1200,
        height: 630,
        alt: "VoltHaus drop",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "VoltHaus — Limited Sneakers & Streetwear Drops",
    description:
      "Shop limited sneakers, streetwear, creator capsules, accessories, and exclusive drops from VoltHaus.",
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&q=80&auto=format&fit=crop",
    ],
    creator: "@volthaus",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  alternates: {
    canonical: siteUrl,
  },
  category: "shopping",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#F7F8FA" },
    { media: "(prefers-color-scheme: dark)", color: "#0B0D10" },
  ],
  colorScheme: "dark light",
  width: "device-width",
  initialScale: 1,
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "VoltHaus",
  url: siteUrl,
  logo: `${siteUrl}/icon.svg`,
  description:
    "Limited sneakers and streetwear drops for the next street culture wave.",
  sameAs: [
    "https://instagram.com/volthaus",
    "https://twitter.com/volthaus",
    "https://tiktok.com/@volthaus",
    "https://youtube.com/@volthaus",
  ],
  contactPoint: {
    "@type": "ContactPoint",
    email: "support@volthaus.co",
    contactType: "customer support",
  },
};

const websiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "VoltHaus",
  url: siteUrl,
  potentialAction: {
    "@type": "SearchAction",
    target: `${siteUrl}/search?q={query}`,
    "query-input": "required name=query",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
        />
      </head>
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[10000] focus:px-4 focus:py-2 focus:bg-primary focus:text-primary-foreground focus:rounded-md focus:text-sm focus:font-semibold"
        >
          Skip to content
        </a>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
