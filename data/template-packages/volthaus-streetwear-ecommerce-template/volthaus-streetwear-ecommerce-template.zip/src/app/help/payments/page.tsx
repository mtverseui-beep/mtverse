import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  CreditCard,
  Gift,
  Lock,
  ShieldCheck,
  Tag,
} from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { HelpFaqAccordion } from "@/components/content/help-faq-accordion";
import { getFAQsByCategory } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Payments Help",
  description:
    "VoltHaus payments help — accepted payment methods, when your card is charged, checkout security, gift cards, coupons, and installment payments via Affirm.",
  alternates: { canonical: "https://volthaus.co/help/payments" },
  openGraph: {
    title: "Payments Help | VoltHaus",
    description:
      "Accepted payment methods, when your card is charged, checkout security, gift cards, and coupons.",
    url: "https://volthaus.co/help/payments",
  },
};

const PAYMENT_METHODS = [
  { label: "Visa", note: "Credit & debit" },
  { label: "Mastercard", note: "Credit & debit" },
  { label: "American Express", note: "Credit" },
  { label: "Apple Pay", note: "One-tap on iOS" },
  { label: "Google Pay", note: "One-tap on Android" },
  { label: "PayPal", note: "Account or guest" },
  { label: "Affirm", note: "Installments on orders over $75" },
];

export default function HelpPaymentsPage() {
  const faqs = getFAQsByCategory("Payments");
  return (
    <SiteShell>
      <div className="container mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Help center", href: "/help" },
            { label: "Payments" },
          ]}
          className="mb-6"
        />
        <ScrollReveal>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-primary/40 bg-primary/10 text-primary">
              <CreditCard className="h-5 w-5" aria-hidden />
            </div>
            <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
              Payments
            </p>
          </div>
          <h1 className="mt-4 text-4xl font-black tracking-tight sm:text-5xl">
            Payments <span className="text-gradient-primary">help</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Accepted payment methods, when your card is charged, checkout
            security, and how gift cards and coupons work at VoltHaus.
          </p>
        </ScrollReveal>

        {/* Accepted payment methods */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Accepted methods
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            How you can pay
          </h2>
          <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {PAYMENT_METHODS.map((m, i) => (
              <ScrollReveal key={m.label} delay={i * 0.04} as="li">
                <li className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-border bg-background text-primary">
                    <CreditCard className="h-4 w-4" aria-hidden />
                  </div>
                  <div>
                    <p className="text-sm font-bold tracking-tight text-foreground">
                      {m.label}
                    </p>
                    <p className="text-xs text-muted-foreground">{m.note}</p>
                  </div>
                </li>
              </ScrollReveal>
            ))}
          </ul>
        </div>

        {/* Security + gift cards + coupons */}
        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {[
            {
              icon: ShieldCheck,
              title: "Checkout security",
              body: "Checkout runs through a PCI-compliant provider. We never store full card numbers on VoltHaus infrastructure — only the last four and an expiry for display.",
            },
            {
              icon: Lock,
              title: "When you are charged",
              body: "Your card is authorized at checkout and captured when the order ships. Pre-order items are captured at order time to reserve your allocation of the drop.",
            },
            {
              icon: Gift,
              title: "Gift cards",
              body: "Gift cards are digital, delivered by email, and redeemable at checkout for any product. They do not expire and can be combined with coupons.",
            },
          ].map((c, i) => (
            <ScrollReveal key={c.title} delay={i * 0.06}>
              <article className="h-full rounded-2xl border border-border bg-card p-5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background text-primary">
                  <c.icon className="h-4 w-4" aria-hidden />
                </div>
                <h3 className="mt-3 text-base font-bold tracking-tight text-foreground">
                  {c.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {c.body}
                </p>
              </article>
            </ScrollReveal>
          ))}
        </div>

        {/* Coupon info */}
        <div className="mt-6 rounded-2xl border border-border bg-card p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-border bg-background text-primary">
              <Tag className="h-4 w-4" aria-hidden />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight text-foreground">
                Coupons and member discounts
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Member-tier discounts apply automatically at checkout based on
                your trailing twelve-month spend. Promo codes can be stacked
                with member discounts but not with other promo codes. If a
                coupon does not apply, check the expiration date and minimum
                order value listed in the campaign email.
              </p>
            </div>
          </div>
        </div>

        {/* FAQs */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Payments FAQs
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Common questions
          </h2>
          <div className="mt-5">
            <HelpFaqAccordion faqs={faqs} defaultValue={faqs[0]?.id} />
          </div>
        </div>

        {/* CTA */}
        <div className="mt-12 rounded-3xl border border-border bg-card p-8 sm:p-10">
          <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="max-w-xl">
              <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                Billing question?
              </p>
              <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                Contact billing support
              </h2>
              <p className="mt-3 text-sm text-muted-foreground">
                For chargebacks, failed authorizations, or refund timing,
                email support@volthaus.co or open a ticket through the
                contact page with your order number.
              </p>
            </div>
            <Link
              href="/contact"
              className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Contact billing
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
