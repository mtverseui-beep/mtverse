import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { HelpCenter } from "@/components/content/help-center";
import { faqs } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Help Center",
  description:
    "VoltHaus help center. Search popular FAQs across orders, shipping, returns, and payments. Quick links to track an order, start a return, and contact support.",
  alternates: { canonical: "https://volthaus.co/help" },
  openGraph: {
    title: "Help Center | VoltHaus",
    description:
      "Search popular FAQs and find quick links to orders, shipping, returns, and payments support.",
    url: "https://volthaus.co/help",
  },
};

const CATEGORIES = [
  {
    label: "Orders",
    description: "Confirmations, modifications, cancellations, and split shipments.",
    href: "/help/orders",
    icon: "Package" as const,
  },
  {
    label: "Shipping",
    description: "Options, delivery windows, international, tracking, lost packages.",
    href: "/help/shipping",
    icon: "Ship" as const,
  },
  {
    label: "Returns",
    description: "30-day window, prepaid labels, exchanges, refund timeline.",
    href: "/help/returns",
    icon: "RotateCcw" as const,
  },
  {
    label: "Payments",
    description: "Cards, Apple Pay, PayPal, Affirm, security, gift cards, coupons.",
    href: "/help/payments",
    icon: "CreditCard" as const,
  },
];

export default function HelpCenterPage() {
  // Popular FAQs: pick the first 6 from the catalog.
  const popularFaqs = faqs.slice(0, 6);

  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "Help center" }]} className="mb-6" />
        <ScrollReveal>
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            VoltHaus support
          </p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">
            How can we{" "}
            <span className="text-gradient-primary">help?</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Search the help center, browse popular articles, or jump straight
            to the category you need. Most replies land inside one business
            day.
          </p>
        </ScrollReveal>
        <div className="mt-10">
          <HelpCenter popularFaqs={popularFaqs} categories={CATEGORIES} />
        </div>
      </div>
    </SiteShell>
  );
}
