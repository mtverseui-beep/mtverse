import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, PackageCheck, RotateCcw, Wallet } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { HelpFaqAccordion } from "@/components/content/help-faq-accordion";
import { getFAQsByCategory } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Returns Help",
  description:
    "VoltHaus returns help — 30-day return window, prepaid labels, step-by-step return process, exchange policy, and refund timeline.",
  alternates: { canonical: "https://volthaus.co/help/returns" },
  openGraph: {
    title: "Returns Help | VoltHaus",
    description:
      "30-day return window, prepaid labels, exchange policy, and refund timeline.",
    url: "https://volthaus.co/help/returns",
  },
};

const STEPS = [
  {
    label: "Start the return",
    body: "Visit the order detail page in your account, pick the item you want to return, and choose a reason from the dropdown.",
  },
  {
    label: "Print the label",
    body: "We email you a prepaid return label within minutes. Footwear must be returned in the original box with no shipping labels affixed.",
  },
  {
    label: "Drop it off",
    body: "Bring the package to any carrier location listed in the return email. Tracking is included on every return label.",
  },
  {
    label: "Get refunded",
    body: "We process your refund within three business days of receiving the item. Funds appear on the original payment method in 5–10 days.",
  },
];

const TIMELINE = [
  { day: "Day 0", label: "Return initiated", done: true },
  { day: "Day 1–3", label: "Item in transit", done: false },
  { day: "Day 3–5", label: "Arrives at warehouse", done: false },
  { day: "Day 5–8", label: "Inspected & refunded", done: false },
  { day: "Day 8–18", label: "Funds settle on card", done: false },
];

export default function HelpReturnsPage() {
  const faqs = getFAQsByCategory("Returns");
  return (
    <SiteShell>
      <div className="container mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Help center", href: "/help" },
            { label: "Returns" },
          ]}
          className="mb-6"
        />
        <ScrollReveal>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-primary/40 bg-primary/10 text-primary">
              <RotateCcw className="h-5 w-5" aria-hidden />
            </div>
            <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
              Returns
            </p>
          </div>
          <h1 className="mt-4 text-4xl font-black tracking-tight sm:text-5xl">
            Returns <span className="text-gradient-primary">help</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            You have thirty days from delivery to return unworn items with
            original tags and packaging. Footwear must be tried on indoors.
            Limited capsules marked final sale on the product page are not
            eligible for return unless they arrive damaged.
          </p>
        </ScrollReveal>

        {/* Policy summary */}
        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {[
            {
              icon: RotateCcw,
              title: "30-day window",
              body: "From the delivery date on your tracking. Items must be unworn with original tags.",
            },
            {
              icon: PackageCheck,
              title: "Prepaid label",
              body: "We email you a return label. Drop the package at any listed carrier location.",
            },
            {
              icon: Wallet,
              title: "3-day refund",
              body: "Refund processed within three business days of the item arriving at our warehouse.",
            },
          ].map((c, i) => (
            <ScrollReveal key={c.title} delay={i * 0.06}>
              <article className="h-full rounded-2xl border border-border bg-card p-5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background text-primary">
                  <c.icon className="h-4 w-4" aria-hidden />
                </div>
                <h2 className="mt-3 text-base font-bold tracking-tight text-foreground">
                  {c.title}
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {c.body}
                </p>
              </article>
            </ScrollReveal>
          ))}
        </div>

        {/* Step-by-step return process */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            How to return
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Step-by-step return process
          </h2>
          <ol className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <ScrollReveal key={s.label} delay={i * 0.06} as="li">
                <div className="h-full rounded-2xl border border-border bg-card p-5">
                  <span className="font-mono text-2xl font-black text-primary">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h3 className="mt-3 text-base font-bold tracking-tight text-foreground">
                    {s.label}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {s.body}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </ol>
        </div>

        {/* Refund timeline visual */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Refund timeline
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            From return to refund
          </h2>
          <ol className="mt-6 space-y-3">
            {TIMELINE.map((t, i) => (
              <li
                key={t.label}
                className="flex items-center gap-4 rounded-xl border border-border bg-card p-4"
              >
                <span className="font-mono text-sm font-bold text-primary">
                  {t.day}
                </span>
                <div className="relative h-2 flex-1 overflow-hidden rounded-full bg-muted">
                  <span
                    className="absolute inset-y-0 left-0 rounded-full bg-primary/60"
                    style={{
                      width: `${((i + 1) / TIMELINE.length) * 100}%`,
                    }}
                    aria-hidden
                  />
                </div>
                <span className="text-sm font-medium text-foreground">
                  {t.label}
                </span>
              </li>
            ))}
          </ol>
        </div>

        {/* FAQs */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Returns FAQs
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Common questions
          </h2>
          <div className="mt-5">
            <HelpFaqAccordion faqs={faqs} defaultValue={faqs[0]?.id} />
          </div>
        </div>

        {/* CTA */}
        <div className="mt-12 rounded-3xl border border-border bg-card p-8 sm:p-10">
          <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="max-w-xl">
              <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                Ready to return?
              </p>
              <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                Start a return
              </h2>
              <p className="mt-3 text-sm text-muted-foreground">
                Open a return request through the contact page and we will
                email you a prepaid label within minutes.
              </p>
            </div>
            <Link
              href="/contact"
              className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Start a return
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
