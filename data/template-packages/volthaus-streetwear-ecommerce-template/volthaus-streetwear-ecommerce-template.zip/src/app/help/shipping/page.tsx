import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Globe, Ship, Truck } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { HelpFaqAccordion } from "@/components/content/help-faq-accordion";
import { getFAQsByCategory } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Shipping Help",
  description:
    "VoltHaus shipping help — domestic and international options, delivery times, tracking, and lost-package policy. Free standard shipping on orders over $150.",
  alternates: { canonical: "https://volthaus.co/help/shipping" },
  openGraph: {
    title: "Shipping Help | VoltHaus",
    description:
      "Domestic and international shipping, delivery times, tracking, and lost-package policy.",
    url: "https://volthaus.co/help/shipping",
  },
};

const RATES = [
  {
    method: "Standard",
    carrier: "National postal service",
    time: "3–5 business days",
    cost: "Free over $150 · $6 otherwise",
  },
  {
    method: "Express",
    carrier: "DHL Express",
    time: "1–2 business days",
    cost: "$18 flat",
  },
  {
    method: "Same-day",
    carrier: "Local courier",
    time: "Same day, order by 12:00",
    cost: "$24 (select cities only)",
  },
  {
    method: "International",
    carrier: "DHL Express Intl.",
    time: "3–7 business days",
    cost: "Calculated at checkout (duties included)",
  },
];

const SECTIONS = [
  {
    icon: Truck,
    title: "Domestic shipping",
    body: "All domestic orders ship from our Berlin fulfillment center. Standard shipping is free on orders over $150 and takes three to five business days. Express shipping is a flat $18 and takes one to two business days. Same-day shipping is available in Berlin, Munich, Hamburg, and Frankfurt for orders placed before noon local time.",
  },
  {
    icon: Globe,
    title: "International shipping",
    body: "We ship to over forty countries with duties and taxes calculated at checkout. For most destinations the price you pay at checkout is the final price and you will not owe additional customs fees on delivery. International shipping typically takes three to seven business days via DHL Express.",
  },
  {
    icon: Ship,
    title: "Tracking",
    body: "You will receive an email with a tracking number as soon as your order ships. Live tracking is also available from the order detail page in your account, which pulls the latest carrier updates directly. If your tracking has not updated in forty-eight hours, contact us.",
  },
];

export default function HelpShippingPage() {
  const faqs = getFAQsByCategory("Shipping");
  return (
    <SiteShell>
      <div className="container mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Help center", href: "/help" },
            { label: "Shipping" },
          ]}
          className="mb-6"
        />
        <ScrollReveal>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-primary/40 bg-primary/10 text-primary">
              <Ship className="h-5 w-5" aria-hidden />
            </div>
            <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
              Shipping
            </p>
          </div>
          <h1 className="mt-4 text-4xl font-black tracking-tight sm:text-5xl">
            Shipping <span className="text-gradient-primary">help</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Everything you need to know about how VoltHaus ships — domestic
            and international options, delivery times, tracking, and what to
            do if a package is delayed.
          </p>
        </ScrollReveal>

        {/* Sub-sections */}
        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {SECTIONS.map((s, i) => (
            <ScrollReveal key={s.title} delay={i * 0.06}>
              <article className="h-full rounded-2xl border border-border bg-card p-5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background text-primary">
                  <s.icon className="h-4 w-4" aria-hidden />
                </div>
                <h2 className="mt-3 text-base font-bold tracking-tight text-foreground">
                  {s.title}
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {s.body}
                </p>
              </article>
            </ScrollReveal>
          ))}
        </div>

        {/* Shipping rates table */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Shipping rates
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            What it costs
          </h2>
          <div className="mt-5 overflow-hidden rounded-2xl border border-border bg-card">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-border bg-background/60 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Method</th>
                  <th className="px-4 py-3 font-medium">Carrier</th>
                  <th className="px-4 py-3 font-medium">Time</th>
                  <th className="px-4 py-3 font-medium">Cost</th>
                </tr>
              </thead>
              <tbody>
                {RATES.map((r, i) => (
                  <tr
                    key={r.method}
                    className={
                      i !== RATES.length - 1 ? "border-b border-border" : ""
                    }
                  >
                    <td className="px-4 py-3 font-semibold text-foreground">
                      {r.method}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {r.carrier}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {r.time}
                    </td>
                    <td className="px-4 py-3 text-foreground">{r.cost}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQs */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Shipping FAQs
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Common questions
          </h2>
          <div className="mt-5">
            <HelpFaqAccordion faqs={faqs} defaultValue={faqs[0]?.id} />
          </div>
        </div>

        {/* CTA */}
        <div className="mt-12 rounded-3xl border border-border bg-card p-8 sm:p-10">
          <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="max-w-xl">
              <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                Still need help?
              </p>
              <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                Contact support
              </h2>
              <p className="mt-3 text-sm text-muted-foreground">
                If your tracking has not updated in forty-eight hours or your
                package arrived damaged, email support@volthaus.co or open a
                ticket through the contact page.
              </p>
            </div>
            <Link
              href="/contact"
              className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Contact support
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
