import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Package, PackageSearch, Truck } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { HelpFaqAccordion } from "@/components/content/help-faq-accordion";
import { getFAQsByCategory } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Orders Help",
  description:
    "VoltHaus orders help — order confirmations, modifications, cancellations, split shipments, status meanings, and how to track your order.",
  alternates: { canonical: "https://volthaus.co/help/orders" },
  openGraph: {
    title: "Orders Help | VoltHaus",
    description:
      "Order confirmations, modifications, cancellations, split shipments, and status meanings.",
    url: "https://volthaus.co/help/orders",
  },
};

const STATUSES = [
  {
    label: "Processing",
    body: "Order received and being prepared at the Berlin fulfillment center. You can still modify or cancel within sixty minutes of placing it.",
  },
  {
    label: "Shipped",
    body: "Order has left the warehouse and is in transit with the carrier. You will receive an email with a tracking number.",
  },
  {
    label: "Delivered",
    body: "Order has been delivered to the address on file. If you were not home, the carrier will leave a notice with next steps.",
  },
  {
    label: "Cancelled",
    body: "Order was cancelled within the sixty-minute window or by customer support. Refunds settle on the original payment method in 5–10 days.",
  },
  {
    label: "Refunded",
    body: "A full or partial refund has been issued. The amount will appear on the original payment method within 5–10 business days.",
  },
];

export default function HelpOrdersPage() {
  const faqs = getFAQsByCategory("Orders");
  return (
    <SiteShell>
      <div className="container mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Help center", href: "/help" },
            { label: "Orders" },
          ]}
          className="mb-6"
        />
        <ScrollReveal>
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-primary/40 bg-primary/10 text-primary">
              <Package className="h-5 w-5" aria-hidden />
            </div>
            <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
              Orders
            </p>
          </div>
          <h1 className="mt-4 text-4xl font-black tracking-tight sm:text-5xl">
            Orders <span className="text-gradient-primary">help</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Confirmations, modifications, cancellations, and what each order
            status actually means. Track your order live from the order
            detail page in your account.
          </p>
        </ScrollReveal>

        {/* Order status explanation */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Order statuses
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            What each status means
          </h2>
          <ul className="mt-6 grid gap-3 sm:grid-cols-2">
            {STATUSES.map((s, i) => (
              <ScrollReveal key={s.label} delay={i * 0.04} as="li">
                <li className="flex h-full items-start gap-3 rounded-2xl border border-border bg-card p-5">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-border bg-background text-primary">
                    <PackageSearch className="h-4 w-4" aria-hidden />
                  </div>
                  <div>
                    <p className="text-sm font-bold tracking-tight text-foreground">
                      {s.label}
                    </p>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                      {s.body}
                    </p>
                  </div>
                </li>
              </ScrollReveal>
            ))}
          </ul>
        </div>

        {/* FAQs */}
        <div className="mt-10">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Orders FAQs
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Common questions
          </h2>
          <div className="mt-5">
            <HelpFaqAccordion faqs={faqs} defaultValue={faqs[0]?.id} />
          </div>
        </div>

        {/* CTAs */}
        <div className="mt-12 grid gap-4 sm:grid-cols-2">
          <Link
            href="/track-order"
            className="group flex items-center justify-between gap-4 rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/40"
          >
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-primary">
                <Truck className="h-4 w-4" aria-hidden />
                Track
              </div>
              <p className="mt-2 text-lg font-bold tracking-tight text-foreground">
                Track your order
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                Live tracking from the carrier, pulled into your account.
              </p>
            </div>
            <ArrowRight
              className="h-5 w-5 text-muted-foreground transition-all group-hover:translate-x-1 group-hover:text-primary"
              aria-hidden
            />
          </Link>
          <Link
            href="/account/orders"
            className="group flex items-center justify-between gap-4 rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/40"
          >
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-primary">
                <Package className="h-4 w-4" aria-hidden />
                History
              </div>
              <p className="mt-2 text-lg font-bold tracking-tight text-foreground">
                View your orders
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                Every order, every line item, every status, in one place.
              </p>
            </div>
            <ArrowRight
              className="h-5 w-5 text-muted-foreground transition-all group-hover:translate-x-1 group-hover:text-primary"
              aria-hidden
            />
          </Link>
        </div>
      </div>
    </SiteShell>
  );
}
