import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { ProductCard } from "@/components/product";
import { ScrollReveal } from "@/components/motion";
import { getOnSaleProducts } from "@/data/products";

export const metadata: Metadata = {
  title: "Sale",
  description: "Last-call VoltHaus drops on sale. Save on sneakers, hoodies, tees, and accessories before they're archived.",
  alternates: { canonical: "https://volthaus.co/sale" },
  openGraph: {
    title: "Sale | VoltHaus",
    description: "Last-call VoltHaus drops on sale.",
    url: "https://volthaus.co/sale",
  },
};

export default function SaleRoute() {
  const products = getOnSaleProducts();
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "Sale" }]} className="mb-6" />
        <SectionHeading
          eyebrow="Last call"
          title="Sale"
          description="Save on selected VoltHaus pieces before they're archived. Final sizes, no restocks — once they're gone, they're gone."
          className="mb-8"
        />
        {products.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No active promotions right now. Check back after the next drop.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {products.map((p, i) => (
              <ScrollReveal key={p.id} delay={Math.min(i * 0.04, 0.32)}>
                <ProductCard product={p} priority={i < 4} />
              </ScrollReveal>
            ))}
          </div>
        )}
      </div>
    </SiteShell>
  );
}
