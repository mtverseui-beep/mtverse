import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import {
  Breadcrumbs,
  SectionHeading,
} from "@/components/common";
import { ProductCard } from "@/components/product";
import { ScrollReveal } from "@/components/motion";
import { getNewArrivals } from "@/data/products";

export const metadata: Metadata = {
  title: "New Arrivals",
  description: "Fresh VoltHaus drops — the latest sneakers, hoodies, tees, and accessories to hit the catalog.",
  alternates: { canonical: "https://volthaus.co/new-arrivals" },
  openGraph: {
    title: "New Arrivals | VoltHaus",
    description: "Fresh VoltHaus drops — the latest to hit the catalog.",
    url: "https://volthaus.co/new-arrivals",
  },
};

export default function NewArrivalsRoute() {
  const products = getNewArrivals();
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "New arrivals" }]} className="mb-6" />
        <SectionHeading
          eyebrow="Just landed"
          title="New arrivals"
          description="The latest drops to hit the VoltHaus catalog. Limited runs — once they're gone, they're gone."
          className="mb-8"
        />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {products.map((p, i) => (
            <ScrollReveal key={p.id} delay={Math.min(i * 0.04, 0.32)}>
              <ProductCard product={p} priority={i < 4} />
            </ScrollReveal>
          ))}
        </div>
      </div>
    </SiteShell>
  );
}
