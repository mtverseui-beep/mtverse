import type { Metadata } from "next";
import { AuthLayout } from "@/components/auth/auth-layout";
import { SignInForm } from "@/components/auth/sign-in-form";

export const metadata: Metadata = {
  title: "Sign In",
  description:
    "Sign in to your VoltHaus account to track orders, manage your wishlist, redeem rewards, and check out faster.",
  robots: { index: false, follow: false },
};

export default function SignInPage() {
  return (
    <AuthLayout
      eyebrow="Welcome back"
      title="Sign in to VoltHaus"
      description="Pick up where you left off — orders, drops, and rewards are waiting."
    >
      <SignInForm />
    </AuthLayout>
  );
}
