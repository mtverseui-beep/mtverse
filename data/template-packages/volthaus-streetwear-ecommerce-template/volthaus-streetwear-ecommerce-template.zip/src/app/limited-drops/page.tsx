import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { LimitedDropsPage } from "@/components/ecommerce/limited-drops-page";
import { products } from "@/data/products";

export const metadata: Metadata = {
  title: "Limited Drops",
  description: "Numbered, small-batch VoltHaus capsules and limited drops. Once they're gone, they're gone.",
  alternates: { canonical: "https://volthaus.co/limited-drops" },
  openGraph: {
    title: "Limited Drops | VoltHaus",
    description: "Numbered, small-batch VoltHaus capsules and limited drops.",
    url: "https://volthaus.co/limited-drops",
  },
};

export default function LimitedDropsRoute() {
  // Products with Limited badge OR dropStatus upcoming/live/restock
  const filtered = products.filter(
    (p) =>
      p.badge === "Limited" ||
      p.dropStatus === "upcoming" ||
      p.dropStatus === "live" ||
      p.dropStatus === "restock"
  );
  return (
    <SiteShell>
      <LimitedDropsPage products={filtered} />
    </SiteShell>
  );
}
