import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { ShopPage } from "@/components/ecommerce/shop-page";
import { products } from "@/data/products";

export const metadata: Metadata = {
  title: "Sneakers",
  description: "Every VoltHaus sneaker silhouette in one feed. Reactive foam midsoles, translucent outsoles, and limited runs engineered for the city block.",
  alternates: { canonical: "https://volthaus.co/sneakers" },
  openGraph: {
    title: "Sneakers | VoltHaus",
    description: "Every VoltHaus sneaker silhouette in one feed.",
    url: "https://volthaus.co/sneakers",
  },
};

export default function SneakersRoute() {
  return (
    <SiteShell>
      <ShopPage
        products={products}
        initialCategory="Sneakers"
        eyebrow="Silhouettes"
        title="Sneakers"
        description="Every VoltHaus sneaker silhouette in one feed. Reactive foam midsoles, translucent outsoles, and limited runs engineered for the city block — never the hardwood."
        breadcrumbs={[{ label: "Shop", href: "/shop" }, { label: "Sneakers" }]}
      />
    </SiteShell>
  );
}
