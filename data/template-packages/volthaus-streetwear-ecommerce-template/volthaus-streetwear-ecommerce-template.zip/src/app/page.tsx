import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import {
  BestSellersSection,
  BentoGridSection,
  CreatorCapsuleSection,
  DropCountdownSection,
  FeaturedDropCarousel,
  HeroSection,
  NewsletterSection,
  ReviewsSection,
  TrustBadgesSection,
} from "@/components/sections";

export const metadata: Metadata = {
  title: "VoltHaus — Limited Sneakers & Streetwear Drops",
  description:
    "Shop limited sneakers, streetwear, creator capsules, and exclusive drops from VoltHaus. Built for the next wave of street culture.",
  alternates: {
    canonical: "/",
  },
};

export default function HomePage() {
  return (
    <SiteShell>
      <HeroSection />
      <DropCountdownSection />
      <FeaturedDropCarousel />
      <BestSellersSection />
      <BentoGridSection />
      <CreatorCapsuleSection />
      <ReviewsSection />
      <TrustBadgesSection />
      <NewsletterSection />
    </SiteShell>
  );
}
