import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal, Marquee } from "@/components/motion";
import { CreatorGrid } from "@/components/content/creator-grid";
import { creators } from "@/data/creators";

export const metadata: Metadata = {
  title: "Creators",
  description:
    "The VoltHaus creator collective — photographers, designers, skaters, musicians, dancers, and stylists. Each capsule begins with a creator.",
  alternates: { canonical: "https://volthaus.co/creators" },
  openGraph: {
    title: "Creators | VoltHaus",
    description:
      "The VoltHaus creator collective. Each capsule begins with a creator.",
    url: "https://volthaus.co/creators",
  },
};

export default function CreatorsPage() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "Creators" }]} className="mb-6" />
        <ScrollReveal>
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            The roster
          </p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">
            The VoltHaus{" "}
            <span className="text-gradient-primary">creator collective</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Six photographers, designers, skaters, musicians, dancers, and
            stylists. Each capsule begins with a creator on this roster and
            ships with the documentation of how it was made.
          </p>
        </ScrollReveal>

        <div className="mt-10">
          <CreatorGrid />
        </div>
      </div>

      {/* Marquee of handles */}
      <section className="border-t border-border bg-background/60 py-6">
        <Marquee speed={28} className="text-foreground">
          {creators.map((c, i) => (
            <span
              key={`${c.slug}-${i}`}
              className="mx-6 inline-flex items-center gap-6 font-mono text-lg font-black tracking-[0.2em] text-foreground/70 sm:text-xl"
            >
              {c.handle.replace("@", "").toUpperCase()}
              <span
                aria-hidden
                className="h-1.5 w-1.5 rounded-full bg-secondary"
              />
            </span>
          ))}
        </Marquee>
      </section>
    </SiteShell>
  );
}
