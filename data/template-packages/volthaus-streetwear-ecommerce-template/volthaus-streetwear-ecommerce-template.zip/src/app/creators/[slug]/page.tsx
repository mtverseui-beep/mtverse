import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { CreatorDetail } from "@/components/content/creator-detail";
import { creators } from "@/data/creators";
import { getProductBySlug } from "@/data/products";
import { reviews } from "@/data/reviews";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return creators.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const creator = creators.find((c) => c.slug === slug);
  if (!creator) return { title: "Creator Not Found" };
  const url = `https://volthaus.co/creators/${creator.slug}`;
  return {
    title: `${creator.name} — ${creator.role}`,
    description: creator.bio,
    alternates: { canonical: url },
    openGraph: {
      title: `${creator.name} | VoltHaus Creators`,
      description: creator.bio,
      url,
      images: [
        {
          url: creator.cover,
          width: 1200,
          height: 630,
          alt: `${creator.name} cover image`,
        },
      ],
    },
  };
}

export default async function CreatorDetailRoute({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const creator = creators.find((c) => c.slug === slug);
  if (!creator) notFound();

  const capsuleProducts = creator.capsuleProductSlugs
    .map((s) => getProductBySlug(s))
    .filter((p): p is NonNullable<ReturnType<typeof getProductBySlug>> =>
      Boolean(p)
    );

  // Use the site-wide reviews whose productSlugs match this creator's capsule.
  const capsuleSlugs = new Set(creator.capsuleProductSlugs);
  const testimonials = reviews
    .filter((r) => capsuleSlugs.has(r.productSlug))
    .slice(0, 4);

  // Average rating from the capsule's product reviews.
  const ratingSum = capsuleProducts.reduce((s, p) => s + p.rating, 0);
  const averageRating =
    capsuleProducts.length > 0 ? ratingSum / capsuleProducts.length : 0;

  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 pt-6 sm:px-6 lg:px-8">
        <Breadcrumbs
          items={[
            { label: "Creators", href: "/creators" },
            { label: creator.name },
          ]}
          className="mb-2"
        />
        <Link
          href="/creators"
          className="inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden />
          Back to all creators
        </Link>
      </div>
      <CreatorDetail
        creator={creator}
        capsuleProducts={capsuleProducts}
        testimonials={testimonials}
        averageRating={averageRating}
      />
    </SiteShell>
  );
}
