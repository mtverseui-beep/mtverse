import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Gift, Sparkles, Mail, Clock, ShieldCheck } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { GiftCardPurchase } from "@/components/ecommerce/gift-card-purchase";

export const metadata: Metadata = {
  title: "Gift Cards",
  description:
    "Give the drop. VoltHaus gift cards never expire and ship instantly by email. Choose from $50 to $500.",
  alternates: { canonical: "https://volthaus.co/gift-cards" },
};

const DENOMINATIONS = [
  { value: 50, popular: false },
  { value: 100, popular: true },
  { value: 200, popular: false },
  { value: 500, popular: false },
];

const DESIGNS = [
  {
    id: "neon-court",
    name: "Neon Court",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80&auto=format&fit=crop",
  },
  {
    id: "static-club",
    name: "Static Club",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800&q=80&auto=format&fit=crop",
  },
  {
    id: "after-dark",
    name: "After Dark",
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80&auto=format&fit=crop",
  },
  {
    id: "chrome-district",
    name: "Chrome District",
    image: "https://images.unsplash.com/photo-1591561954557-26941169b49e?w=800&q=80&auto=format&fit=crop",
  },
];

const HOW_IT_WORKS = [
  {
    icon: Sparkles,
    title: "Pick a design",
    body: "Choose from four VoltHaus-exclusive designs inspired by our seasonal collections.",
  },
  {
    icon: Mail,
    title: "We send it instantly",
    body: "Gift cards are delivered by email immediately after purchase, with a personal message from you.",
  },
  {
    icon: Clock,
    title: "Never expires",
    body: "VoltHaus gift cards never expire. The recipient uses it whenever the right drop hits.",
  },
  {
    icon: ShieldCheck,
    title: "Secure and tracked",
    body: "All gift card balances are tracked in your account and protected by our secure checkout.",
  },
];

export default function GiftCardsPage() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Gift cards" },
          ]}
          className="mb-6"
        />

        {/* Hero */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center mb-16">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/30 text-primary text-xs font-mono uppercase tracking-wider mb-4">
              <Gift className="h-3.5 w-3.5" />
              Give the drop
            </div>
            <h1 className="text-4xl font-black tracking-tight sm:text-5xl mb-4">
              VoltHaus <span className="text-gradient-primary">Gift Cards</span>
            </h1>
            <p className="text-base text-muted-foreground mb-6">
              The cleanest way to put a VoltHaus drop in someone's hands without guessing their size. Pick a denomination, pick a design, and we'll send it instantly by email. Gift cards never expire.
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Delivered instantly by email
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                No expiration, ever
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Works on every drop, including limited releases
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Member early access applies to gift card purchases
              </li>
            </ul>
          </div>

          <div className="relative aspect-[4/3] rounded-3xl overflow-hidden border border-border bg-card">
            <Image
              src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&q=80&auto=format&fit=crop"
              alt="VoltHaus gift card"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <p className="text-xs font-mono uppercase tracking-wider text-primary mb-1">
                VoltHaus Drop Card
              </p>
              <p className="text-2xl font-black text-white">
                Any drop. Any time.
              </p>
            </div>
          </div>
        </div>

        {/* Purchase widget */}
        <div className="mb-20">
          <GiftCardPurchase denominations={DENOMINATIONS} designs={DESIGNS} />
        </div>

        {/* How it works */}
        <div className="mb-20">
          <SectionHeading
            eyebrow="How it works"
            title="From your cart to their inbox"
            description="Four steps. No friction."
            align="center"
            className="mb-10"
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {HOW_IT_WORKS.map((step) => (
              <div
                key={step.title}
                className="rounded-2xl border border-border bg-card p-6"
              >
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary mb-4">
                  <step.icon className="h-5 w-5" />
                </span>
                <h3 className="text-base font-bold mb-1">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {step.body}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto">
          <SectionHeading
            eyebrow="Gift card FAQ"
            title="Quick answers"
            align="center"
            className="mb-8"
          />
          <div className="space-y-3">
            {[
              {
                q: "Do VoltHaus gift cards expire?",
                a: "No. Gift cards never expire. The recipient can use it on any future drop, including limited releases and member-only capsules.",
              },
              {
                q: "Can I use a gift card on sale items or limited drops?",
                a: "Yes. Gift cards work on every product on the site, including sale items and limited drops, subject to availability.",
              },
              {
                q: "How is the gift card delivered?",
                a: "Immediately after purchase, we send the gift card to the recipient's email address with your personal message. You can also schedule delivery for a specific date.",
              },
              {
                q: "What if the recipient loses their gift card email?",
                a: "No problem. Contact support@volthaus.co with the order number and we'll reissue the gift card to the original email address.",
              },
              {
                q: "Can I check the balance of a gift card?",
                a: "Yes. Enter the gift card code at checkout to see the remaining balance, or contact our support team anytime.",
              },
            ].map((item) => (
              <details
                key={item.q}
                className="group rounded-xl border border-border bg-card p-5"
              >
                <summary className="flex items-center justify-between cursor-pointer list-none">
                  <span className="text-sm font-semibold">{item.q}</span>
                  <span className="text-muted-foreground transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                  {item.a}
                </p>
              </details>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-20 rounded-3xl border border-primary/30 bg-primary/5 p-8 sm:p-12 text-center">
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight mb-2">
            Not sure what to gift?
          </h2>
          <p className="text-sm text-muted-foreground mb-6 max-w-md mx-auto">
            Browse the full VoltHaus catalog and find the right drop for them.
          </p>
          <Link
            href="/shop"
            className="inline-flex items-center justify-center h-12 px-8 rounded-full bg-primary text-primary-foreground font-bold text-sm btn-shine"
          >
            Shop all drops
          </Link>
        </div>
      </div>
    </SiteShell>
  );
}
