import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Home, ShoppingBag } from "lucide-react";

export const metadata: Metadata = {
  title: "Page not found",
  description:
    "The page you are looking for does not exist or has sold out. Head back to the VoltHaus home page or shop all current drops.",
  robots: { index: false, follow: true },
};

/**
 * Global 404 fallback. Rendered for any route that does not match a known
 * segment. Kept lightweight: no SiteShell, no header, no footer, no cart.
 */
export default function NotFound() {
  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-background text-foreground">
      {/* Animated grid background */}
      <div
        aria-hidden="true"
        className="grid-bg-animated pointer-events-none absolute inset-0 opacity-50"
      />

      {/* Floating glow orbs */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-[12%] top-[18%] h-72 w-72 rounded-full bg-primary/20 blur-[110px] animate-float"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-[10%] top-[40%] h-80 w-80 rounded-full bg-secondary/20 blur-[120px] animate-float"
        style={{ animationDelay: "1.5s" }}
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-[14%] left-[44%] h-72 w-72 rounded-full bg-accent/20 blur-[110px] animate-float"
        style={{ animationDelay: "3s" }}
      />

      {/* Top-left logo */}
      <div className="relative z-10 p-6 sm:p-8">
        <Link
          href="/"
          aria-label="VoltHaus home"
          className="inline-flex items-center gap-2 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Image
            src="/logo.svg"
            alt=""
            width={120}
            height={28}
            priority
            className="h-7 w-auto"
          />
          <span className="sr-only">VoltHaus</span>
        </Link>
      </div>

      {/* Main content */}
      <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-4 pb-16 pt-4 sm:px-6">
        <div className="w-full max-w-2xl text-center">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-primary">
            Error 404
          </p>

          <h1
            className="select-none bg-gradient-to-br from-primary via-secondary to-accent bg-clip-text text-[clamp(6rem,22vw,16rem)] font-black leading-none tracking-tighter text-transparent"
            aria-label="404"
          >
            404
          </h1>

          <h2 className="mt-4 text-balance text-2xl font-bold tracking-tight text-foreground sm:text-3xl md:text-4xl">
            Page not found
          </h2>

          <p className="mx-auto mt-4 max-w-md text-pretty text-sm text-muted-foreground sm:text-base">
            The drop you&apos;re looking for doesn&apos;t exist or has sold
            out. Check the URL or head back to explore what&apos;s live right
            now.
          </p>

          <div className="mt-8 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
            <Link
              href="/"
              className="btn-shine inline-flex items-center justify-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <Home className="h-4 w-4" aria-hidden="true" />
              Back to home
            </Link>
            <Link
              href="/shop"
              className="inline-flex items-center justify-center gap-2 rounded-md border border-border bg-card/60 px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <ShoppingBag className="h-4 w-4" aria-hidden="true" />
              Shop all drops
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
          </div>

          {/* Quick links */}
          <div className="mt-10 border-t border-border pt-6">
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
              Try one of these
            </p>
            <ul className="mt-3 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm">
              <li>
                <Link
                  href="/new-arrivals"
                  className="text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
                >
                  New arrivals
                </Link>
              </li>
              <li>
                <Link
                  href="/best-sellers"
                  className="text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
                >
                  Best sellers
                </Link>
              </li>
              <li>
                <Link
                  href="/limited-drops"
                  className="text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
                >
                  Limited drops
                </Link>
              </li>
              <li>
                <Link
                  href="/collections"
                  className="text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
                >
                  Collections
                </Link>
              </li>
              <li>
                <Link
                  href="/drop-calendar"
                  className="text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
                >
                  Drop calendar
                </Link>
              </li>
              <li>
                <Link
                  href="/contact"
                  className="text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
                >
                  Contact support
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  );
}
