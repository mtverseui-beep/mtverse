import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { OutfitBuilder } from "@/components/ecommerce";

export const metadata: Metadata = {
  title: "Outfit Builder",
  description:
    "Build a complete VoltHaus look from sneakers, hoodies, tees, pants, and accessories. Mix and match drops to make it yours.",
  alternates: { canonical: "https://volthaus.co/outfit-builder" },
};

export default function OutfitBuilderPage() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Outfit builder" },
          ]}
          className="mb-6"
        />

        <div className="mb-10 max-w-2xl">
          <p className="text-xs font-mono uppercase tracking-wider text-primary mb-2">
            Style it your way
          </p>
          <h1 className="text-4xl font-black tracking-tight sm:text-5xl">
            Build Your <span className="text-gradient-primary">Drop</span>
          </h1>
          <p className="mt-3 text-base text-muted-foreground">
            Mix sneakers, hoodies, tees, pants, and accessories into a complete VoltHaus look. Add the full outfit to your cart in one tap, or start from a curated preset.
          </p>
        </div>

        <OutfitBuilder />
      </div>
    </SiteShell>
  );
}
