import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { CheckoutFlow } from "@/components/checkout/checkout-flow";

export const metadata: Metadata = {
  title: "Checkout — Shipping",
  description: "Enter your shipping address and delivery method.",
  robots: { index: false, follow: false },
};

export default function CheckoutShippingRoute() {
  return (
    <SiteShell hideFooter hideAnnouncement>
      <CheckoutFlow step="shipping" />
    </SiteShell>
  );
}
