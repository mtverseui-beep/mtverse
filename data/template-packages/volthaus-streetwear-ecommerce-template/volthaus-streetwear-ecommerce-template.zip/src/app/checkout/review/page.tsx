import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { CheckoutFlow } from "@/components/checkout/checkout-flow";

export const metadata: Metadata = {
  title: "Checkout — Review",
  description: "Review your VoltHaus order before placing it.",
  robots: { index: false, follow: false },
};

export default function CheckoutReviewRoute() {
  return (
    <SiteShell hideFooter hideAnnouncement>
      <CheckoutFlow step="review" />
    </SiteShell>
  );
}
