import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { CheckoutFlow } from "@/components/checkout/checkout-flow";

export const metadata: Metadata = {
  title: "Checkout",
  description: "Secure VoltHaus checkout. Complete your contact, shipping, and payment details to place your order.",
  alternates: { canonical: "https://volthaus.co/checkout" },
  robots: { index: false, follow: false },
};

export default function CheckoutRoute() {
  return (
    <SiteShell hideFooter hideAnnouncement>
      <CheckoutFlow step="information" />
    </SiteShell>
  );
}
