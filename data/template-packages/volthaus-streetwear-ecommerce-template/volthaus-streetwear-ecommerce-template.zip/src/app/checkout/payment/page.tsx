import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { CheckoutFlow } from "@/components/checkout/checkout-flow";

export const metadata: Metadata = {
  title: "Checkout — Payment",
  description: "Enter your payment details to complete your VoltHaus order.",
  robots: { index: false, follow: false },
};

export default function CheckoutPaymentRoute() {
  return (
    <SiteShell hideFooter hideAnnouncement>
      <CheckoutFlow step="payment" />
    </SiteShell>
  );
}
