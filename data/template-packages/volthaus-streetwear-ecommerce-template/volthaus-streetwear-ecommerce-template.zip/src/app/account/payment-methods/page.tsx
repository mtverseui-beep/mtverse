import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { PaymentMethodManager } from "@/components/account/payment-method-manager";

export const metadata: Metadata = {
  title: "Payment Methods",
  description:
    "Manage the cards and digital wallets saved to your VoltHaus account — add, edit, set defaults, and remove.",
  robots: { index: false, follow: false },
};

export default function AccountPaymentMethodsPage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Payment methods"
        description="Cards and wallets saved for one-tap checkout."
      >
        <PaymentMethodManager />
      </AccountLayout>
    </SiteShell>
  );
}
