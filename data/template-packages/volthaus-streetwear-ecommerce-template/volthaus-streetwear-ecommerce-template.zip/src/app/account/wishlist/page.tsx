import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { WishlistPage } from "@/components/ecommerce";

export const metadata: Metadata = {
  title: "Wishlist",
  description:
    "Saved VoltHaus pieces you're watching — add them to cart or remove to keep this list tight.",
  robots: { index: false, follow: false },
};

export default function AccountWishlistPage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Wishlist"
        description="Items you've saved while browsing the catalog."
      >
        <WishlistPage embedded />
      </AccountLayout>
    </SiteShell>
  );
}
