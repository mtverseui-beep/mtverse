import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import {
  CheckCircle2,
  MapPin,
  Package,
  Printer,
  Truck,
} from "lucide-react";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { BuyAgainButton } from "@/components/ecommerce";
import { PrintInvoiceButton } from "@/components/account/print-invoice-button";
import { Button } from "@/components/ui/button";
import { getOrderById, mockOrders } from "@/data/orders";
import { cn } from "@/lib/utils";

export function generateStaticParams() {
  return mockOrders.map((order) => ({ id: order.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const order = getOrderById(id);
  if (!order) {
    return { title: "Order Not Found", robots: { index: false, follow: false } };
  }
  return {
    title: `Order ${order.number}`,
    description: `Details for VoltHaus order ${order.number} placed on ${new Date(
      order.date
    ).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}.`,
    robots: { index: false, follow: false },
  };
}

const STATUS_COLOR: Record<string, string> = {
  Processing: "bg-warning/15 text-warning border-warning/40",
  Shipped: "bg-primary/15 text-primary border-primary/40",
  Delivered: "bg-success/15 text-success border-success/40",
  Cancelled: "bg-destructive/15 text-destructive border-destructive/40",
  Refunded: "bg-muted text-muted-foreground border-border",
};

export default async function AccountOrderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const order = getOrderById(id);
  if (!order) notFound();

  const hasTracking =
    order.status === "Shipped" || order.status === "Delivered";

  return (
    <SiteShell>
      <AccountLayout
        title={`Order ${order.number}`}
        description={`Placed on ${new Date(order.date).toLocaleDateString("en-US", {
          month: "long",
          day: "numeric",
          year: "numeric",
        })}`}
        breadcrumbs={[
          { label: "Account", href: "/account" },
          { label: "Orders", href: "/account/orders" },
          { label: order.number },
        ]}
        actions={
          <span
            className={cn(
              "inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide",
              STATUS_COLOR[order.status] ?? STATUS_COLOR.Refunded
            )}
          >
            {order.status}
          </span>
        }
      >
        <div className="space-y-6">
          {/* Timeline */}
          <section className="rounded-2xl border border-border bg-card p-5 sm:p-6">
            <h2 className="text-base font-bold text-foreground">Order timeline</h2>
            <ol className="mt-5 flex flex-col gap-5">
              {order.timeline.map((entry) => (
                <li
                  key={`${entry.label}-${entry.date}`}
                  className="flex items-start gap-3"
                >
                  <span
                    className={cn(
                      "inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                      entry.completed
                        ? "bg-success/15 text-success"
                        : "border border-border bg-muted/30 text-muted-foreground"
                    )}
                  >
                    {entry.label.toLowerCase().includes("shipped") ||
                    entry.label.toLowerCase().includes("delivery") ? (
                      <Truck className="h-4 w-4" />
                    ) : entry.label.toLowerCase().includes("placed") ||
                      entry.label.toLowerCase().includes("confirmed") ? (
                      <CheckCircle2 className="h-4 w-4" />
                    ) : (
                      <Package className="h-4 w-4" />
                    )}
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {entry.label}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {entry.completed
                        ? new Date(entry.date).toLocaleString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                            hour: "numeric",
                            minute: "2-digit",
                          })
                        : "Pending"}
                    </p>
                  </div>
                </li>
              ))}
            </ol>

            {hasTracking && order.trackingNumber && (
              <div className="mt-5 rounded-lg border border-border bg-background/40 p-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Tracking number
                </p>
                <p className="mt-1 font-mono text-sm text-foreground">
                  {order.trackingNumber}
                </p>
                {order.estimatedDelivery && (
                  <p className="mt-1 text-xs text-muted-foreground">
                    Estimated delivery:{" "}
                    {new Date(order.estimatedDelivery).toLocaleDateString("en-US", {
                      weekday: "long",
                      month: "short",
                      day: "numeric",
                    })}
                  </p>
                )}
                <Button asChild size="sm" variant="outline" className="mt-3">
                  <Link href="/track-order">
                    <Truck className="h-4 w-4" />
                    Track shipment
                  </Link>
                </Button>
              </div>
            )}
          </section>

          {/* Items + summary */}
          <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
            <section className="rounded-2xl border border-border bg-card p-5 sm:p-6">
              <h2 className="text-base font-bold text-foreground">Items</h2>
              <ul className="mt-4 flex flex-col divide-y divide-border">
                {order.items.map((item) => (
                  <li
                    key={`${item.productId}-${item.size}-${item.color}`}
                    className="flex gap-3 py-3"
                  >
                    <Link
                      href={`/product/${item.slug}`}
                      className="relative h-16 w-16 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                      aria-label={`View ${item.name}`}
                    >
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        sizes="64px"
                        className="object-cover"
                      />
                    </Link>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <Link
                        href={`/product/${item.slug}`}
                        className="line-clamp-2 text-sm font-semibold text-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                      <p className="text-xs text-muted-foreground">
                        Size {item.size} · {item.color} · Qty {item.quantity}
                      </p>
                    </div>
                    <span className="text-sm font-semibold text-foreground tabular-nums">
                      ${(item.price * item.quantity).toFixed(2)}
                    </span>
                  </li>
                ))}
              </ul>

              <div className="mt-5 flex flex-wrap gap-2">
                {order.status !== "Cancelled" && order.status !== "Refunded" && (
                  <BuyAgainButton items={order.items} />
                )}
                <PrintInvoiceButton orderNumber={order.number} />
                <Button asChild size="sm" variant="ghost">
                  <Link href="/account/orders">Back to orders</Link>
                </Button>
              </div>
            </section>

            <aside className="flex flex-col gap-6">
              <section className="rounded-2xl border border-border bg-card p-5 sm:p-6">
                <h2 className="text-base font-bold text-foreground">Summary</h2>
                <dl className="mt-3 flex flex-col gap-2 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Subtotal</dt>
                    <dd className="font-semibold text-foreground tabular-nums">
                      ${order.subtotal.toFixed(2)}
                    </dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Shipping</dt>
                    <dd className="font-semibold text-foreground tabular-nums">
                      {order.shipping === 0 ? "Free" : `$${order.shipping.toFixed(2)}`}
                    </dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Tax</dt>
                    <dd className="font-semibold text-foreground tabular-nums">
                      ${order.tax.toFixed(2)}
                    </dd>
                  </div>
                  <div className="mt-2 flex justify-between border-t border-border pt-2 text-base">
                    <dt className="font-bold text-foreground">Total</dt>
                    <dd className="font-black text-foreground tabular-nums">
                      ${order.total.toFixed(2)}
                    </dd>
                  </div>
                </dl>
              </section>

              <section className="rounded-2xl border border-border bg-card p-5 sm:p-6">
                <h2 className="flex items-center gap-2 text-base font-bold text-foreground">
                  <MapPin className="h-4 w-4 text-primary" aria-hidden />
                  Shipping address
                </h2>
                <div className="mt-3 text-sm text-foreground">
                  <p>{order.shippingAddress.name}</p>
                  <p className="text-muted-foreground">{order.shippingAddress.line1}</p>
                  {order.shippingAddress.line2 && (
                    <p className="text-muted-foreground">{order.shippingAddress.line2}</p>
                  )}
                  <p className="text-muted-foreground">
                    {order.shippingAddress.city}, {order.shippingAddress.state}{" "}
                    {order.shippingAddress.zip}
                  </p>
                  <p className="text-muted-foreground">{order.shippingAddress.country}</p>
                </div>
              </section>

              <p className="flex items-center justify-center gap-1.5 text-center text-[11px] text-muted-foreground">
                <Printer className="h-3 w-3" aria-hidden />
                Need a paper copy? Use the Print invoice button above.
              </p>
            </aside>
          </div>
        </div>
      </AccountLayout>
    </SiteShell>
  );
}
