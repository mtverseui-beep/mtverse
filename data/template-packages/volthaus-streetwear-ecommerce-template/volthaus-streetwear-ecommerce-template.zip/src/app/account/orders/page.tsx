import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { AccountOrders } from "@/components/account/account-orders";

export const metadata: Metadata = {
  title: "Order History",
  description:
    "Review every VoltHaus order you've placed — filter by status, search by order number, and buy again with one tap.",
  robots: { index: false, follow: false },
};

export default function AccountOrdersPage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Orders"
        description="Track and manage every VoltHaus order you've placed."
      >
        <AccountOrders />
      </AccountLayout>
    </SiteShell>
  );
}
