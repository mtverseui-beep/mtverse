import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { ProfileForm } from "@/components/account/profile-form";

export const metadata: Metadata = {
  title: "Profile",
  description:
    "Edit your VoltHaus account profile — name, email, phone, date of birth, gender, and avatar.",
  robots: { index: false, follow: false },
};

export default function AccountProfilePage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Profile"
        description="The personal details attached to your VoltHaus account."
      >
        <ProfileForm />
      </AccountLayout>
    </SiteShell>
  );
}
