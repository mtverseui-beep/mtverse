import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { AccountDashboard } from "@/components/account/account-dashboard";

export const metadata: Metadata = {
  title: "Account Dashboard",
  description:
    "Your VoltHaus account dashboard — recent orders, rewards points, wishlist, and saved addresses at a glance.",
  robots: { index: false, follow: false },
};

export default function AccountDashboardPage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Dashboard"
        description="Track your orders, rewards, and saved pieces in one place."
      >
        <AccountDashboard />
      </AccountLayout>
    </SiteShell>
  );
}
