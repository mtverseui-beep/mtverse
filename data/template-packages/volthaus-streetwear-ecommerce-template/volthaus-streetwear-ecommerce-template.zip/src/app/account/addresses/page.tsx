import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { AddressManager } from "@/components/account/address-manager";

export const metadata: Metadata = {
  title: "Saved Addresses",
  description:
    "Manage the shipping addresses saved to your VoltHaus account — add new addresses, edit existing ones, and set a default for faster checkout.",
  robots: { index: false, follow: false },
};

export default function AccountAddressesPage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Addresses"
        description="The shipping addresses we keep on file for one-tap checkout."
      >
        <AddressManager />
      </AccountLayout>
    </SiteShell>
  );
}
