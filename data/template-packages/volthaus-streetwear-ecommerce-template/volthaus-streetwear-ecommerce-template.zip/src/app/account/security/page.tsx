import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { SecurityForm } from "@/components/account/security-form";

export const metadata: Metadata = {
  title: "Security",
  description:
    "Manage your VoltHaus account security — change your password, enable two-factor authentication, review active sessions, and sign out of other devices.",
  robots: { index: false, follow: false },
};

export default function AccountSecurityPage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Security"
        description="Protect your account with a strong password, two-factor authentication, and session control."
      >
        <SecurityForm />
      </AccountLayout>
    </SiteShell>
  );
}
