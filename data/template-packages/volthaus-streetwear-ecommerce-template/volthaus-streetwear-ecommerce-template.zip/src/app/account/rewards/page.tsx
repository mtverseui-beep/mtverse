import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Gift, Sparkles } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { RewardsDashboard } from "@/components/account/rewards-dashboard";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Static Club Rewards",
  description:
    "Your VoltHaus Static Club rewards dashboard — points balance, tier progress, redemption options, and recent activity.",
  robots: { index: false, follow: false },
};

const REDEEM_OPTIONS = [
  {
    points: 500,
    reward: "$5 store credit",
    description: "Apply at checkout on any order, no minimum.",
  },
  {
    points: 1000,
    reward: "$10 store credit",
    description: "Best value for everyday redemptions.",
  },
  {
    points: 2500,
    reward: "Free shipping for 30 days",
    description: "Waive shipping on every order for a month.",
  },
  {
    points: 5000,
    reward: "Static tier upgrade",
    description: "Top-tier perks: early access, free returns, birthday gift.",
  },
];

export default function AccountRewardsPage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Static Club"
        description="Earn points on every drop, climb tiers, and unlock members-only rewards."
        actions={
          <Button asChild variant="outline" size="sm">
            <Link href="/rewards">
              View public rewards
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
        }
      >
        <div className="space-y-6">
          <RewardsDashboard />

          {/* Redeem points section */}
          <section
            aria-labelledby="redeem-heading"
            className="rounded-2xl border border-border bg-card p-5 sm:p-6"
          >
            <div className="mb-5 flex items-center gap-2">
              <Gift className="h-4 w-4 text-secondary" aria-hidden />
              <h2
                id="redeem-heading"
                className="text-base font-bold text-foreground"
              >
                Redeem your points
              </h2>
            </div>
            <ul className="grid gap-3 sm:grid-cols-2">
              {REDEEM_OPTIONS.map((option) => (
                <li
                  key={option.points}
                  className="flex items-start gap-3 rounded-xl border border-border bg-background/40 p-4"
                >
                  <span
                    aria-hidden
                    className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary/15 text-secondary"
                  >
                    <Sparkles className="h-4 w-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-baseline justify-between gap-1">
                      <p className="text-sm font-bold text-foreground">
                        {option.reward}
                      </p>
                      <p className="font-mono text-xs text-secondary">
                        {option.points.toLocaleString()} pts
                      </p>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {option.description}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-xs text-muted-foreground">
              Points are non-transferable and expire 24 months after your last
              qualifying purchase.{" "}
              <Link
                href="/privacy"
                className="font-semibold text-primary hover:underline"
              >
                Read the rewards terms
              </Link>
              .
            </p>
          </section>
        </div>
      </AccountLayout>
    </SiteShell>
  );
}
