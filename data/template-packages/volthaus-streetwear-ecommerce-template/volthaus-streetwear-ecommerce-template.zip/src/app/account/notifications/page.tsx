import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { AccountLayout } from "@/components/account/account-layout";
import { NotificationSettings } from "@/components/account/notification-settings";

export const metadata: Metadata = {
  title: "Notification Preferences",
  description:
    "Choose which VoltHaus notifications you receive — drop alerts, order updates, member early access, the newsletter, birthday gifts, and more.",
  robots: { index: false, follow: false },
};

export default function AccountNotificationsPage() {
  return (
    <SiteShell>
      <AccountLayout
        title="Notifications"
        description="Pick the alerts you want and the channels we use to reach you."
      >
        <NotificationSettings />
      </AccountLayout>
    </SiteShell>
  );
}
