import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { DropCalendarGrid } from "@/components/content/drop-calendar-grid";

export const metadata: Metadata = {
  title: "Drop Calendar",
  description:
    "Upcoming, live, and sold-out VoltHaus drops. Set reminders, add to your calendar, and never miss a release.",
  alternates: { canonical: "https://volthaus.co/drop-calendar" },
};

export default function DropCalendarPage() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Drop calendar" },
          ]}
          className="mb-6"
        />

        <div className="mb-10 max-w-2xl">
          <p className="text-xs font-mono uppercase tracking-wider text-primary mb-2">
            Mark your calendar
          </p>
          <h1 className="text-4xl font-black tracking-tight sm:text-5xl">
            Drop <span className="text-gradient-primary">Calendar</span>
          </h1>
          <p className="mt-3 text-base text-muted-foreground">
            Every VoltHaus release in one place. Filter by status, set reminders, and add to your calendar so you never miss a drop.
          </p>
        </div>

        <DropCalendarGrid />
      </div>
    </SiteShell>
  );
}
