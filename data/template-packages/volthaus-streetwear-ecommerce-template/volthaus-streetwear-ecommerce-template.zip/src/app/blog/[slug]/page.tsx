import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { BlogArticle } from "@/components/content/blog-article";
import { blogPosts, getAllBlogSlugs, getBlogPostBySlug } from "@/data/blog";
import { getProductBySlug } from "@/data/products";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return getAllBlogSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = getBlogPostBySlug(slug);
  if (!post) return { title: "Article Not Found" };
  const url = `https://volthaus.co/blog/${post.slug}`;
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: url },
    openGraph: {
      title: `${post.title} | VoltHaus Journal`,
      description: post.excerpt,
      url,
      type: "article",
      publishedTime: post.publishedAt,
      authors: [post.author],
      tags: post.tags,
      images: [
        {
          url: post.cover,
          width: 1200,
          height: 630,
          alt: post.title,
        },
      ],
    },
  };
}

export default async function BlogArticleRoute({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const post = getBlogPostBySlug(slug);
  if (!post) notFound();

  const relatedProducts = (post.relatedProductSlugs ?? [])
    .map((s) => getProductBySlug(s))
    .filter((p): p is NonNullable<ReturnType<typeof getProductBySlug>> =>
      Boolean(p)
    );

  const relatedPosts = blogPosts
    .filter((p) => p.slug !== post.slug)
    .slice(0, 3);

  return (
    <SiteShell>
      <div className="container mx-auto max-w-4xl px-4 pt-6 sm:px-6 lg:px-8">
        <Breadcrumbs
          items={[
            { label: "Journal", href: "/blog" },
            { label: post.title },
          ]}
          className="mb-2"
        />
        <Link
          href="/blog"
          className="inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden />
          Back to the journal
        </Link>
      </div>
      <BlogArticle
        post={post}
        relatedProducts={relatedProducts}
        relatedPosts={relatedPosts}
      />
    </SiteShell>
  );
}
