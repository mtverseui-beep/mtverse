import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { BlogList } from "@/components/content/blog-list";
import { blogPosts } from "@/data/blog";

export const metadata: Metadata = {
  title: "Journal",
  description:
    "The VoltHaus journal — long-form writing on drop culture, sneaker care, street styling, creator stories, sustainability, and behind-the-design notes.",
  alternates: { canonical: "https://volthaus.co/blog" },
  openGraph: {
    title: "Journal | VoltHaus",
    description:
      "Long-form writing on drop culture, sneaker care, street styling, creator stories, and behind-the-design notes.",
    url: "https://volthaus.co/blog",
  },
};

export default function BlogIndexPage() {
  const [featured, ...remaining] = blogPosts;
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "Journal" }]} className="mb-6" />
        <ScrollReveal>
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            The journal
          </p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">
            VoltHaus{" "}
            <span className="text-gradient-primary">journal</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Long-form writing on drop culture, sneaker care, street styling,
            creator stories, sustainability, and behind-the-design notes from
            the VoltHaus studio.
          </p>
        </ScrollReveal>
        <div className="mt-10">
          <BlogList featured={featured} remaining={remaining} />
        </div>
      </div>
    </SiteShell>
  );
}
