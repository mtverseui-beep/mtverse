import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { ProductCard } from "@/components/product";
import { ScrollReveal } from "@/components/motion";
import { getBestSellers } from "@/data/products";

export const metadata: Metadata = {
  title: "Best Sellers",
  description: "The VoltHaus community's most-worn pieces. Best sellers across sneakers, hoodies, tees, and accessories.",
  alternates: { canonical: "https://volthaus.co/best-sellers" },
  openGraph: {
    title: "Best Sellers | VoltHaus",
    description: "The VoltHaus community's most-worn pieces.",
    url: "https://volthaus.co/best-sellers",
  },
};

export default function BestSellersRoute() {
  const products = getBestSellers();
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "Best sellers" }]} className="mb-6" />
        <SectionHeading
          eyebrow="Community favorites"
          title="Best sellers"
          description="The pieces our community keeps coming back for. Verified-buyer favorites across every drop."
          className="mb-8"
        />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {products.map((p, i) => (
            <ScrollReveal key={p.id} delay={Math.min(i * 0.04, 0.32)}>
              <ProductCard product={p} priority={i < 4} />
            </ScrollReveal>
          ))}
        </div>
      </div>
    </SiteShell>
  );
}
