import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPolicyBySlug } from "@/data/policies";
import { PolicyLayout } from "@/components/content/policy-layout";

const SLUG = "refund-policy";
const siteUrl = "https://volthaus.co";
const canonicalUrl = `${siteUrl}/refund-policy`;

export const metadata: Metadata = {
  title: "Refund Policy",
  description:
    "When and how VoltHaus issues refunds, including the processing timeline, the form of the refund, and partial refund conditions.",
  alternates: { canonical: canonicalUrl },
  openGraph: {
    title: "Refund Policy | VoltHaus",
    description:
      "When and how VoltHaus issues refunds, including the processing timeline and the form of the refund.",
    url: canonicalUrl,
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title: "Refund Policy | VoltHaus",
    description:
      "When and how VoltHaus issues refunds, including the processing timeline.",
  },
  robots: { index: true, follow: true },
};

export default function RefundPolicyPage() {
  const policy = getPolicyBySlug(SLUG);
  if (!policy) notFound();
  return <PolicyLayout policy={policy} />;
}
