import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { WishlistPage } from "@/components/ecommerce/wishlist-page";

export const metadata: Metadata = {
  title: "Wishlist",
  description: "Saved VoltHaus drops you're watching.",
  alternates: { canonical: "https://volthaus.co/wishlist" },
  robots: { index: false, follow: false },
};

export default function WishlistRoute() {
  return (
    <SiteShell>
      <WishlistPage />
    </SiteShell>
  );
}
