import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import {
  CheckCircle2,
  MapPin,
  Package,
  Truck,
} from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { Button } from "@/components/ui/button";
import { BuyAgainButton } from "@/components/ecommerce/buy-again-button";
import { PrintInvoiceButton } from "@/components/ecommerce/print-invoice-button";
import { getOrderById, mockOrders } from "@/data/orders";
import { cn } from "@/lib/utils";

export function generateStaticParams() {
  return mockOrders.map((order) => ({ id: order.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const order = getOrderById(id);
  if (!order) return { title: "Order Not Found" };
  return {
    title: `Order ${order.number}`,
    description: `Details for VoltHaus order ${order.number}`,
    robots: { index: false, follow: false },
  };
}

const STATUS_COLOR: Record<string, string> = {
  Processing: "bg-warning/15 text-warning border-warning/40",
  Shipped: "bg-primary/15 text-primary border-primary/40",
  Delivered: "bg-success/15 text-success border-success/40",
  Cancelled: "bg-destructive/15 text-destructive border-destructive/40",
  Refunded: "bg-muted text-muted-foreground border-border",
};

export default async function OrderDetailRoute({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const order = getOrderById(id);
  if (!order) {
    return (
      <SiteShell>
        <div className="container mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ label: "Order not found" }]} className="mb-6" />
          <div className="rounded-xl border border-border bg-card p-12 text-center">
            <h1 className="text-xl font-bold text-foreground">
              Order not found
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              We couldn't find an order with that ID. It may belong to a
              different account.
            </p>
            <Button asChild className="mt-6">
              <Link href="/account/orders">View order history</Link>
            </Button>
          </div>
        </div>
      </SiteShell>
    );
  }

  const hasTracking =
    order.status === "Shipped" ||
    order.status === "Delivered";

  return (
    <SiteShell>
      <div className="container mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
        <Breadcrumbs
          items={[
            { label: "Account", href: "/account" },
            { label: "Orders", href: "/account/orders" },
            { label: order.number },
          ]}
          className="mb-6"
        />

        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-black tracking-tight text-foreground sm:text-3xl">
              Order {order.number}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Placed on{" "}
              {new Date(order.date).toLocaleDateString("en-US", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>
          <span
            className={cn(
              "inline-flex w-fit items-center rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide",
              STATUS_COLOR[order.status] ?? STATUS_COLOR.Refunded
            )}
          >
            {order.status}
          </span>
        </div>

        {/* Timeline */}
        <section className="mt-8 rounded-xl border border-border bg-card p-6">
          <h2 className="text-base font-bold text-foreground">
            Order timeline
          </h2>
          <ol className="mt-5 flex flex-col gap-5">
            {order.timeline.map((entry) => (
              <li key={`${entry.label}-${entry.date}`} className="flex items-start gap-3">
                <span
                  className={cn(
                    "inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                    entry.completed
                      ? "bg-success/15 text-success"
                      : "border border-border bg-muted/30 text-muted-foreground"
                  )}
                >
                  {entry.label.toLowerCase().includes("shipped") ||
                  entry.label.toLowerCase().includes("delivery") ? (
                    <Truck className="h-4 w-4" />
                  ) : entry.label.toLowerCase().includes("placed") ||
                    entry.label.toLowerCase().includes("confirmed") ? (
                    <CheckCircle2 className="h-4 w-4" />
                  ) : (
                    <Package className="h-4 w-4" />
                  )}
                </span>
                <div>
                  <p className="text-sm font-semibold text-foreground">
                    {entry.label}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {entry.completed
                      ? new Date(entry.date).toLocaleString("en-US", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                          hour: "numeric",
                          minute: "2-digit",
                        })
                      : "Pending"}
                  </p>
                </div>
              </li>
            ))}
          </ol>
          {hasTracking && order.trackingNumber && (
            <div className="mt-5 rounded-lg border border-border bg-background/40 p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Tracking number
              </p>
              <p className="mt-1 font-mono text-sm text-foreground">
                {order.trackingNumber}
              </p>
              {order.estimatedDelivery && (
                <p className="mt-1 text-xs text-muted-foreground">
                  Estimated delivery:{" "}
                  {new Date(order.estimatedDelivery).toLocaleDateString("en-US", {
                    weekday: "long",
                    month: "short",
                    day: "numeric",
                  })}
                </p>
              )}
              <Button asChild size="sm" variant="outline" className="mt-3">
                <Link href="/track-order">
                  <Truck className="h-4 w-4" />
                  Track shipment
                </Link>
              </Button>
            </div>
          )}
        </section>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]">
          {/* Items */}
          <section className="rounded-xl border border-border bg-card p-6">
            <h2 className="text-base font-bold text-foreground">Items</h2>
            <ul className="mt-4 flex flex-col divide-y divide-border">
              {order.items.map((item) => (
                <li key={`${item.productId}-${item.size}-${item.color}`} className="flex gap-3 py-3">
                  <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="64px"
                      className="object-cover"
                    />
                  </div>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <Link
                      href={`/product/${item.slug}`}
                      className="text-sm font-semibold text-foreground hover:text-primary"
                    >
                      {item.name}
                    </Link>
                    <p className="text-xs text-muted-foreground">
                      Size {item.size} · {item.color} · Qty {item.quantity}
                    </p>
                  </div>
                  <span className="text-sm font-semibold text-foreground tabular-nums">
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                </li>
              ))}
            </ul>

            <div className="mt-4 flex flex-wrap gap-3">
              <BuyAgainButton items={order.items} />
              <PrintInvoiceButton />
            </div>
          </section>
          <aside className="flex flex-col gap-6">
            <section className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-base font-bold text-foreground">Summary</h2>
              <dl className="mt-3 flex flex-col gap-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Subtotal</dt>
                  <dd className="font-semibold text-foreground tabular-nums">
                    ${order.subtotal.toFixed(2)}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Shipping</dt>
                  <dd className="font-semibold text-foreground tabular-nums">
                    {order.shipping === 0 ? "Free" : `$${order.shipping.toFixed(2)}`}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Tax</dt>
                  <dd className="font-semibold text-foreground tabular-nums">
                    ${order.tax.toFixed(2)}
                  </dd>
                </div>
                <div className="mt-2 border-t border-border pt-2 flex justify-between text-base">
                  <dt className="font-bold text-foreground">Total</dt>
                  <dd className="font-black text-foreground tabular-nums">
                    ${order.total.toFixed(2)}
                  </dd>
                </div>
              </dl>
            </section>

            <section className="rounded-xl border border-border bg-card p-6">
              <h2 className="flex items-center gap-2 text-base font-bold text-foreground">
                <MapPin className="h-4 w-4 text-primary" />
                Shipping address
              </h2>
              <p className="mt-3 text-sm text-foreground">
                {order.shippingAddress.name}
              </p>
              <p className="text-sm text-muted-foreground">
                {order.shippingAddress.line1}
              </p>
              {order.shippingAddress.line2 && (
                <p className="text-sm text-muted-foreground">
                  {order.shippingAddress.line2}
                </p>
              )}
              <p className="text-sm text-muted-foreground">
                {order.shippingAddress.city}, {order.shippingAddress.state}{" "}
                {order.shippingAddress.zip}
              </p>
              <p className="text-sm text-muted-foreground">
                {order.shippingAddress.country}
              </p>
            </section>
          </aside>
        </div>
      </div>
    </SiteShell>
  );
}
