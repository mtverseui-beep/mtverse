import type { Metadata } from "next";
import Link from "next/link";
import { Ban, ShoppingBag } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Order Cancelled",
  description: "Your VoltHaus order has been cancelled.",
  robots: { index: false, follow: false },
};

export default function OrderCancelledRoute() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Order cancelled" }]} className="mb-6" />

        <div className="rounded-xl border border-warning/30 bg-warning/5 p-8 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-warning/15 text-warning">
            <Ban className="h-8 w-8" />
          </div>
          <h1 className="mt-5 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Order cancelled
          </h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Your order has been cancelled and no payment was processed. Any
            authorization hold on your card will be released by your bank within
            3–5 business days.
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Button asChild className="btn-shine">
              <Link href="/shop">
                <ShoppingBag className="h-4 w-4" />
                Continue shopping
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/account/orders">View order history</Link>
            </Button>
          </div>

          <p className="mt-6 text-xs text-muted-foreground">
            Need help? Email{" "}
            <a
              href="mailto:support@volthaus.co"
              className="text-primary underline-offset-4 hover:underline"
            >
              support@volthaus.co
            </a>
            .
          </p>
        </div>
      </div>
    </SiteShell>
  );
}
