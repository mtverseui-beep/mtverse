import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { CheckCircle2, Mail, Package, Truck, Home } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { Button } from "@/components/ui/button";
import { getBestSellers } from "@/data/products";

export const metadata: Metadata = {
  title: "Order Confirmed",
  description: "Your VoltHaus order is confirmed.",
  robots: { index: false, follow: false },
};

const REWARDS_PER_DOLLAR = 1;

export default async function OrderSuccessRoute({
  searchParams,
}: {
  searchParams: Promise<{ order?: string; email?: string }>;
}) {
  const { order, email } = await searchParams;
  const orderNumber = order ?? "VH-000000";
  const emailText = email ?? "your inbox";

  // Use best-seller catalog as a representative mock of what was ordered.
  const recentItems = getBestSellers().slice(0, 2);
  const mockTotal = recentItems.reduce((s, p) => s + p.price, 0);
  const pointsEarned = Math.round(mockTotal * REWARDS_PER_DOLLAR);

  return (
    <SiteShell>
      <div className="container mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
        <Breadcrumbs
          items={[{ label: "Order confirmed" }]}
          className="mb-6"
        />

        <div className="flex flex-col items-center text-center">
          <MotionCheckmark />
          <h1 className="mt-6 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
            Order confirmed
          </h1>
          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            Thanks for joining the drop. We've sent a confirmation email with
            all the details.
          </p>
          <p className="mt-4 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-sm">
            <span className="text-muted-foreground">Confirmation #</span>
            <span className="font-mono font-bold text-foreground">
              {orderNumber}
            </span>
          </p>
          <p className="mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
            <Mail className="h-3.5 w-3.5" />
            Email confirmation sent to {emailText}
          </p>
        </div>

        {/* Order summary */}
        <div className="mt-10 rounded-xl border border-border bg-card p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-foreground">Order summary</h2>
            <span className="rounded-full bg-success/15 px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-success">
              Confirmed
            </span>
          </div>
          <ul className="mt-4 flex flex-col divide-y divide-border">
            {recentItems.map((p) => (
              <li key={p.id} className="flex gap-3 py-3">
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30">
                  <Image
                    src={p.images[0]}
                    alt={p.name}
                    fill
                    sizes="64px"
                    className="object-cover"
                  />
                </div>
                <div className="flex min-w-0 flex-1 flex-col">
                  <p className="text-sm font-semibold text-foreground">
                    {p.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {p.category}
                  </p>
                </div>
                <span className="text-sm font-semibold text-foreground tabular-nums">
                  ${p.price.toFixed(2)}
                </span>
              </li>
            ))}
          </ul>
          <div className="mt-3 border-t border-border pt-3 flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Total paid</span>
            <span className="text-base font-black text-foreground tabular-nums">
              ${mockTotal.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Timeline */}
        <div className="mt-6 rounded-xl border border-border bg-card p-6">
          <h2 className="text-base font-bold text-foreground">
            Delivery timeline
          </h2>
          <ol className="mt-4 flex flex-col gap-5">
            <TimelineStep
              icon={<CheckCircle2 className="h-5 w-5" />}
              title="Confirmed"
              description="We've received your order and payment."
              state="active"
            />
            <TimelineStep
              icon={<Package className="h-5 w-5" />}
              title="Processing"
              description="Your order is being prepared for shipment."
              state="upcoming"
            />
            <TimelineStep
              icon={<Truck className="h-5 w-5" />}
              title="Shipped"
              description="Out for delivery with the carrier."
              state="upcoming"
            />
          </ol>
        </div>

        {/* Rewards */}
        <div className="mt-6 rounded-xl border border-primary/30 bg-primary/5 p-6">
          <div className="flex items-center gap-3">
            <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <Package className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold text-foreground">
                +{pointsEarned} points earned
              </p>
              <p className="text-xs text-muted-foreground">
                Static Club points credited to your account.
              </p>
            </div>
          </div>
          <Button asChild variant="outline" size="sm" className="mt-4">
            <Link href="/rewards">View rewards</Link>
          </Button>
        </div>

        {/* CTAs */}
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Button asChild variant="outline" className="flex-1">
            <Link href="/track-order">
              <Truck className="h-4 w-4" />
              Track order
            </Link>
          </Button>
          <Button asChild className="btn-shine flex-1">
            <Link href="/shop">
              <Home className="h-4 w-4" />
              Continue shopping
            </Link>
          </Button>
        </div>
      </div>
    </SiteShell>
  );
}

function TimelineStep({
  icon,
  title,
  description,
  state,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  state: "active" | "upcoming" | "done";
}) {
  return (
    <li className="flex items-start gap-3">
      <span
        className={
          state === "active"
            ? "inline-flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground"
            : state === "done"
              ? "inline-flex h-9 w-9 items-center justify-center rounded-full bg-success/20 text-success"
              : "inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-muted/30 text-muted-foreground"
        }
      >
        {icon}
      </span>
      <div>
        <p className="text-sm font-semibold text-foreground">{title}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
    </li>
  );
}

// Inline checkmark animation — server-renderable (no hooks).
function MotionCheckmark() {
  return (
    <div className="relative flex h-20 w-20 items-center justify-center">
      <span className="absolute inset-0 rounded-full bg-success/15" />
      <span className="absolute inset-2 rounded-full bg-success/25" />
      <span className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-success text-white">
        <CheckCircle2 className="h-7 w-7" />
      </span>
    </div>
  );
}
