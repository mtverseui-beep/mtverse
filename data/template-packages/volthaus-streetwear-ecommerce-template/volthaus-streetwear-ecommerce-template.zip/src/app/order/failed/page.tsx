import type { Metadata } from "next";
import Link from "next/link";
import { AlertCircle, Mail, RotateCcw } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Payment Failed",
  description: "Your VoltHaus payment could not be processed.",
  robots: { index: false, follow: false },
};

export default function OrderFailedRoute() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Payment failed" }]} className="mb-6" />

        <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-8 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-destructive/15 text-destructive">
            <AlertCircle className="h-8 w-8" />
          </div>
          <h1 className="mt-5 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Payment failed
          </h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Your payment could not be processed. This usually happens when a
            card is declined, the billing ZIP doesn't match the bank's records,
            or the session timed out. No charge was made to your card.
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <Button asChild className="btn-shine">
              <Link href="/checkout/payment">
                <RotateCcw className="h-4 w-4" />
                Try again
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/cart">Back to cart</Link>
            </Button>
          </div>

          <div className="mt-8 rounded-lg border border-border bg-card p-4 text-left">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Need help?
            </p>
            <p className="mt-1 text-sm text-foreground">
              Email{" "}
              <a
                href="mailto:support@volthaus.co"
                className="text-primary underline-offset-4 hover:underline"
              >
                support@volthaus.co
              </a>{" "}
              with your order number and we'll help you complete the purchase
              within 24 hours.
            </p>
            <p className="mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
              <Mail className="h-3.5 w-3.5" />
              support@volthaus.co
            </p>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
