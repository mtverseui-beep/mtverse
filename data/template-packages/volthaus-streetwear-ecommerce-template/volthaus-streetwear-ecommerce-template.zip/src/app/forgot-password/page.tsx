import type { Metadata } from "next";
import { AuthLayout } from "@/components/auth/auth-layout";
import { ForgotPasswordForm } from "@/components/auth/forgot-password-form";

export const metadata: Metadata = {
  title: "Forgot Password",
  description:
    "Reset your VoltHaus account password. Enter your email and we'll send you a one-time link to choose a new password.",
  robots: { index: false, follow: false },
};

export default function ForgotPasswordPage() {
  return (
    <AuthLayout
      eyebrow="Password recovery"
      title="Forgot your password?"
      description="Enter the email tied to your VoltHaus account and we'll send a reset link."
    >
      <ForgotPasswordForm />
    </AuthLayout>
  );
}
