import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPolicyBySlug } from "@/data/policies";
import { PolicyLayout } from "@/components/content/policy-layout";

const SLUG = "cookies";
const siteUrl = "https://volthaus.co";
const canonicalUrl = `${siteUrl}/cookies`;

export const metadata: Metadata = {
  title: "Cookie Policy",
  description:
    "How VoltHaus uses cookies and similar technologies to operate the site and measure performance, and how you can control them.",
  alternates: { canonical: canonicalUrl },
  openGraph: {
    title: "Cookie Policy | VoltHaus",
    description:
      "How VoltHaus uses cookies and similar technologies to operate the site and measure performance.",
    url: canonicalUrl,
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title: "Cookie Policy | VoltHaus",
    description:
      "How VoltHaus uses cookies and similar technologies to operate the site.",
  },
  robots: { index: true, follow: true },
};

export default function CookiePolicyPage() {
  const policy = getPolicyBySlug(SLUG);
  if (!policy) notFound();
  return <PolicyLayout policy={policy} />;
}
