import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { ProductCard } from "@/components/product";
import { ScrollReveal } from "@/components/motion";
import { Button } from "@/components/ui/button";
import { collections } from "@/data/collections";
import { getProductsByCollection } from "@/data/products";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return collections.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const collection = collections.find((c) => c.slug === slug);
  if (!collection) {
    return { title: "Collection Not Found" };
  }
  const url = `https://volthaus.co/collections/${collection.slug}`;
  return {
    title: collection.name,
    description: collection.description,
    alternates: { canonical: url },
    openGraph: {
      title: `${collection.name} | VoltHaus`,
      description: collection.description,
      url,
      images: [
        {
          url: collection.cover,
          width: 1200,
          height: 630,
          alt: collection.name,
        },
      ],
    },
  };
}

export default async function CollectionDetailRoute({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const collection = collections.find((c) => c.slug === slug);
  if (!collection) {
    notFound();
  }
  const products = getProductsByCollection(collection.slug);
  const dropDate = new Date(collection.dropDate);

  return (
    <SiteShell>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0">
          <Image
            src={collection.hero}
            alt={collection.name}
            fill
            priority
            sizes="100vw"
            className="object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/30" />
        </div>
        <div className="relative container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <Breadcrumbs
            items={[
              { label: "Collections", href: "/collections" },
              { label: collection.name },
            ]}
            className="mb-6"
          />
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            {collection.tagline}
          </p>
          <h1 className="mt-2 text-4xl font-black tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            {collection.name}
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            {collection.description}
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/60 px-3 py-1">
              <span className="font-mono uppercase tracking-wider">
                Drop date
              </span>
              <span className="font-semibold text-foreground">
                {dropDate.toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/60 px-3 py-1">
              <span className="font-mono uppercase tracking-wider">
                Status
              </span>
              <span className="font-semibold text-foreground capitalize">
                {collection.status.replace("-", " ")}
              </span>
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/60 px-3 py-1">
              <span className="font-mono uppercase tracking-wider">
                Pieces
              </span>
              <span className="font-semibold text-foreground">
                {collection.productSlugs.length}
              </span>
            </span>
          </div>
        </div>
      </section>

      {/* Product grid */}
      <div className="container mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
        <SectionHeading
          eyebrow="In this capsule"
          title={`Shop ${collection.name}`}
          className="mb-8"
        />
        {products.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No products in this collection yet — check back at the drop.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {products.map((p, i) => (
              <ScrollReveal key={p.id} delay={Math.min(i * 0.04, 0.32)}>
                <ProductCard product={p} priority={i < 4} />
              </ScrollReveal>
            ))}
          </div>
        )}

        <div className="mt-12 flex flex-wrap items-center gap-3">
          <Button asChild variant="outline">
            <Link href="/collections">
              <ArrowRight className="h-4 w-4 rotate-180" />
              All collections
            </Link>
          </Button>
          <Button asChild className="btn-shine">
            <Link href="/shop">Shop all products</Link>
          </Button>
        </div>
      </div>
    </SiteShell>
  );
}
