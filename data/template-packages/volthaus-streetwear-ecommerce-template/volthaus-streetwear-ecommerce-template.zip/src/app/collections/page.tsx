import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { collections } from "@/data/collections";

export const metadata: Metadata = {
  title: "Collections",
  description: "Explore every VoltHaus collection — Neon Court, Static Club, Chrome District, and more. Limited capsules with numbered drop cards.",
  alternates: { canonical: "https://volthaus.co/collections" },
  openGraph: {
    title: "Collections | VoltHaus",
    description: "Explore every VoltHaus collection — limited capsules with numbered drop cards.",
    url: "https://volthaus.co/collections",
  },
};

export default function CollectionsRoute() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "Collections" }]} className="mb-6" />
        <SectionHeading
          eyebrow="Capsules"
          title="Collections"
          description="Every VoltHaus capsule in one place. Each collection is a small-batch program with its own material logic, color story, and drop cadence."
          className="mb-8"
        />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {collections.map((c) => {
            const isUpcoming = c.status === "upcoming";
            const isSoldOut = c.status === "sold-out";
            return (
              <Link
                key={c.id}
                href={`/collections/${c.slug}`}
                className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-colors hover:border-primary/40"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-muted/30">
                  <Image
                    src={c.cover}
                    alt={c.name}
                    fill
                    sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <span
                    className={`absolute left-3 top-3 rounded-full border px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider backdrop-blur-sm ${
                      isUpcoming
                        ? "border-secondary/50 bg-secondary/15 text-secondary"
                        : isSoldOut
                          ? "border-destructive/40 bg-destructive/15 text-destructive"
                          : "border-primary/40 bg-primary/15 text-primary"
                    }`}
                  >
                    {c.status}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <p className="text-[11px] uppercase tracking-wider text-primary">
                    {c.tagline}
                  </p>
                  <h3 className="mt-1 text-lg font-bold text-foreground group-hover:text-primary">
                    {c.name}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                    {c.description}
                  </p>
                  <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                    <span>{c.productSlugs.length} pieces</span>
                    <span className="inline-flex items-center gap-1 text-primary">
                      Shop collection
                      <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </SiteShell>
  );
}
