import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { ShopPage } from "@/components/ecommerce/shop-page";
import { products } from "@/data/products";
import type { ProductCategory } from "@/types";

export const metadata: Metadata = {
  title: "Streetwear",
  description: "VoltHaus streetwear — heavyweight hoodies, graphic tees, cargo pants, and outerwear built for the late-shift community.",
  alternates: { canonical: "https://volthaus.co/streetwear" },
  openGraph: {
    title: "Streetwear | VoltHaus",
    description: "Heavyweight hoodies, graphic tees, cargo pants, and outerwear from VoltHaus.",
    url: "https://volthaus.co/streetwear",
  },
};

// Pre-filter streetwear categories server-side; the ShopPage still allows the
// user to refine further or remove the category filter.
const STREETWEAR_CATEGORIES: ProductCategory[] = [
  "Hoodies",
  "Graphic Tees",
  "Cargo Pants",
  "Jackets",
];

export default function StreetwearRoute() {
  const streetwear = products.filter((p) =>
    STREETWEAR_CATEGORIES.includes(p.category)
  );
  return (
    <SiteShell>
      <ShopPage
        products={streetwear}
        eyebrow="Late-shift uniform"
        title="Streetwear"
        description="Heavyweight hoodies, graphic tees, cargo geometry, and outerwear built for the late-shift community. Pieces designed to survive the studio and the corner store."
        breadcrumbs={[{ label: "Shop", href: "/shop" }, { label: "Streetwear" }]}
      />
    </SiteShell>
  );
}
