import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Sparkles, Gift, Crown, Zap, TrendingUp, Users, Bell, Star } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { RewardsDashboard } from "@/components/account/rewards-dashboard";

export const metadata: Metadata = {
  title: "Static Club Rewards",
  description:
    "Earn points on every VoltHaus drop. Unlock member-only access, early drops, and exclusive pricing through the Static Club.",
  alternates: { canonical: "https://volthaus.co/rewards" },
};

const TIERS = [
  {
    name: "Signal",
    threshold: "Free to join",
    points: "0 — 999 pts",
    icon: Zap,
    color: "var(--vh-primary)",
    perks: [
      "10% off your first order",
      "Early access to public drops",
      "Member-only email alerts",
      "Birthday month gift",
    ],
  },
  {
    name: "Pulse",
    threshold: "1,000 pts",
    points: "1,000 — 4,999 pts",
    icon: TrendingUp,
    color: "var(--vh-secondary)",
    perks: [
      "Everything in Signal",
      "1 hour early access to all drops",
      "Free express shipping, no minimum",
      "Extended 60-day returns",
      "Member-only capsules",
    ],
  },
  {
    name: "Static",
    threshold: "5,000 pts",
    points: "5,000+ pts",
    icon: Crown,
    color: "var(--vh-accent)",
    perks: [
      "Everything in Pulse",
      "24 hour early access to all drops",
      "Dedicated concierge support",
      "Invitation to VoltHaus events",
      "Annual limited-edition gift",
      "Free expedited shipping",
    ],
  },
];

const EARNING_RULES = [
  { action: "Every $1 spent", points: "1 pt", icon: Sparkles },
  { action: "Refer a friend who orders", points: "100 pts", icon: Users },
  { action: "Write a verified review", points: "25 pts", icon: Star },
  { action: "Follow VoltHaus on social", points: "50 pts", icon: Bell },
  { action: "Complete your profile", points: "20 pts", icon: Gift },
];

export default function RewardsPage() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Static Club rewards" },
          ]}
          className="mb-6"
        />

        {/* Hero */}
        <div className="relative rounded-3xl border border-border bg-card overflow-hidden mb-16">
          <div className="absolute inset-0 grid-bg-animated opacity-40" />
          <div className="absolute top-0 right-0 w-80 h-80 rounded-full bg-primary/20 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-secondary/20 blur-3xl" />
          <div className="relative z-10 p-8 sm:p-12 lg:p-16 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/15 border border-primary/30 text-primary text-xs font-mono uppercase tracking-wider mb-5">
              <Sparkles className="h-3.5 w-3.5" />
              Static Club
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight mb-4">
              Get paid to <span className="text-gradient-primary">drop in.</span>
            </h1>
            <p className="text-base sm:text-lg text-muted-foreground mb-6">
              Earn points on every VoltHaus order. Unlock member-only drops, early access, and exclusive pricing as you climb the tiers.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                href="/sign-up"
                className="h-12 px-6 rounded-full bg-primary text-primary-foreground font-bold text-sm btn-shine flex items-center justify-center"
              >
                Join the club — it's free
              </Link>
              <Link
                href="/account/rewards"
                className="h-12 px-6 rounded-full border border-border hover:border-primary/60 hover:text-primary transition-colors font-bold text-sm flex items-center justify-center"
              >
                View my rewards
              </Link>
            </div>
          </div>
        </div>

        {/* Member dashboard preview */}
        <div className="mb-20">
          <RewardsDashboard />
        </div>

        {/* Tiers */}
        <div className="mb-20">
          <SectionHeading
            eyebrow="Membership tiers"
            title="Climb the ranks"
            description="Three tiers. Each one unlocks more access, more perks, more drops."
            align="center"
            className="mb-10"
          />
          <div className="grid lg:grid-cols-3 gap-4">
            {TIERS.map((tier, i) => (
              <div
                key={tier.name}
                className={`relative rounded-2xl border bg-card p-6 ${
                  i === 1 ? "border-secondary/40 lg:-translate-y-4" : "border-border"
                }`}
                style={i === 1 ? { boxShadow: "0 0 40px rgba(255, 46, 209, 0.15)" } : undefined}
              >
                {i === 1 && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider bg-secondary text-white">
                    Most popular
                  </span>
                )}
                <div className="flex items-center gap-3 mb-4">
                  <span
                    className="inline-flex h-12 w-12 items-center justify-center rounded-xl"
                    style={{ backgroundColor: `${tier.color}20`, color: tier.color }}
                  >
                    <tier.icon className="h-6 w-6" />
                  </span>
                  <div>
                    <h3 className="text-xl font-black">{tier.name}</h3>
                    <p className="text-xs text-muted-foreground">{tier.threshold}</p>
                  </div>
                </div>
                <p className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-4">
                  {tier.points}
                </p>
                <ul className="space-y-2">
                  {tier.perks.map((perk) => (
                    <li key={perk} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span
                        className="inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full mt-0.5"
                        style={{ backgroundColor: `${tier.color}20`, color: tier.color }}
                      >
                        <svg className="h-2.5 w-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                      {perk}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* How to earn */}
        <div className="mb-20">
          <SectionHeading
            eyebrow="Earning rules"
            title="Stack points fast"
            description="Five ways to earn, every single day."
            align="center"
            className="mb-10"
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {EARNING_RULES.map((rule) => (
              <div
                key={rule.action}
                className="rounded-2xl border border-border bg-card p-5 text-center"
              >
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary mb-3">
                  <rule.icon className="h-5 w-5" />
                </span>
                <p className="text-xs text-muted-foreground mb-1">{rule.action}</p>
                <p className="text-base font-black text-primary">{rule.points}</p>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto">
          <SectionHeading
            eyebrow="Rewards FAQ"
            title="Quick answers"
            align="center"
            className="mb-8"
          />
          <div className="space-y-3">
            {[
              {
                q: "How do I join the Static Club?",
                a: "Signing up for a VoltHaus account automatically enrolls you in the Static Club at the Signal tier. There's no separate signup and no fee.",
              },
              {
                q: "Do my points expire?",
                a: "Points expire 24 months after your last order. Any purchase resets the clock on your entire balance.",
              },
              {
                q: "Can I redeem points for cash?",
                a: "Points can be redeemed for VoltHaus store credit at a rate of 100 points = $1. Store credit never expires.",
              },
              {
                q: "How do tier upgrades work?",
                a: "You upgrade automatically when you cross a tier threshold. Once upgraded, you keep that tier for 12 months from the date of upgrade.",
              },
              {
                q: "What happens to my tier if I return an order?",
                a: "Returned orders deduct the original points earned. If your balance drops below your current tier threshold, you keep the tier until the 12-month renewal date.",
              },
            ].map((item) => (
              <details
                key={item.q}
                className="group rounded-xl border border-border bg-card p-5"
              >
                <summary className="flex items-center justify-between cursor-pointer list-none">
                  <span className="text-sm font-semibold">{item.q}</span>
                  <span className="text-muted-foreground transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                  {item.a}
                </p>
              </details>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-20 rounded-3xl border border-primary/30 bg-primary/5 p-8 sm:p-12 text-center">
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight mb-2">
            Ready to join the club?
          </h2>
          <p className="text-sm text-muted-foreground mb-6 max-w-md mx-auto">
            Free to join. Earn 20 points just for completing your profile.
          </p>
          <Link
            href="/sign-up"
            className="inline-flex items-center justify-center h-12 px-8 rounded-full bg-primary text-primary-foreground font-bold text-sm btn-shine"
          >
            Create your VoltHaus account
          </Link>
        </div>
      </div>
    </SiteShell>
  );
}
