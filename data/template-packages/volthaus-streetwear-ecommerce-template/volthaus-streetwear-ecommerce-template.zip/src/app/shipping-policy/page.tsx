import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPolicyBySlug } from "@/data/policies";
import { PolicyLayout } from "@/components/content/policy-layout";

const SLUG = "shipping-policy";
const siteUrl = "https://volthaus.co";
const canonicalUrl = `${siteUrl}/shipping-policy`;

export const metadata: Metadata = {
  title: "Shipping Policy",
  description:
    "Where VoltHaus ships, how long it takes, and what it costs. Free standard shipping on orders over $150 to most destinations.",
  alternates: { canonical: canonicalUrl },
  openGraph: {
    title: "Shipping Policy | VoltHaus",
    description:
      "Where VoltHaus ships, how long it takes, and what it costs. Free standard shipping on orders over $150.",
    url: canonicalUrl,
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title: "Shipping Policy | VoltHaus",
    description:
      "Where VoltHaus ships, how long it takes, and what it costs.",
  },
  robots: { index: true, follow: true },
};

export default function ShippingPolicyPage() {
  const policy = getPolicyBySlug(SLUG);
  if (!policy) notFound();
  return <PolicyLayout policy={policy} />;
}
