import type { Metadata } from "next";
import { AuthLayout } from "@/components/auth/auth-layout";
import { VerifyEmailForm } from "@/components/auth/verify-email-form";

export const metadata: Metadata = {
  title: "Verify Your Email",
  description:
    "Confirm your VoltHaus account email to unlock member-only drops, rewards, and faster checkout.",
  robots: { index: false, follow: false },
};

export default async function VerifyEmailPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>;
}) {
  const params = await searchParams;
  const token = params.token ? params.token : null;

  const title = token ? "Verifying your email" : "Verify your email";
  const description = token
    ? "We're confirming your email address with VoltHaus HQ."
    : "Enter the email tied to your account and we'll send a verification link.";

  return (
    <AuthLayout
      eyebrow="Account activation"
      title={title}
      description={description}
    >
      <VerifyEmailForm token={token} />
    </AuthLayout>
  );
}
