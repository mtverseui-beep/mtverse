import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import {
  StockistGrid,
  type Stockist,
} from "@/components/content/stockist-grid";

export const metadata: Metadata = {
  title: "Stockists",
  description:
    "Find VoltHaus in real life — flagship and partner stockist locations across Berlin, Lisbon, Milan, Tokyo, London, New York, Paris, and Amsterdam. Hours, addresses, and directions.",
  alternates: { canonical: "https://volthaus.co/stockists" },
  openGraph: {
    title: "Stockists | VoltHaus",
    description:
      "Find VoltHaus in real life — flagship and partner stockist locations across Europe, Japan, and the US.",
    url: "https://volthaus.co/stockists",
  },
};

const STOCKISTS: Stockist[] = [
  {
    name: "VoltHaus Berlin — Kreuzberg Flagship",
    city: "Berlin",
    country: "Germany",
    region: "Europe",
    address: "Oranienstraße 6, 10999 Berlin, Germany",
    hours: "Mon–Sat 11:00–20:00 · Sun closed",
    image:
      "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=1200&q=80&auto=format&fit=crop",
    flagship: true,
  },
  {
    name: "VoltHaus Lisbon — Príncipe Real Studio",
    city: "Lisbon",
    country: "Portugal",
    region: "Europe",
    address: "Rua da Escola Politécnica 42, 1250-102 Lisboa, Portugal",
    hours: "Tue–Sat 12:00–19:00 · Sun–Mon closed",
    image:
      "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=1200&q=80&auto=format&fit=crop",
    flagship: true,
  },
  {
    name: "VoltHaus Milan — Brera Pop-up",
    city: "Milan",
    country: "Italy",
    region: "Europe",
    address: "Via Solferino 11, 20121 Milano, Italy",
    hours: "Mon–Sun 10:30–20:00 (closes Dec 31)",
    image:
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&q=80&auto=format&fit=crop",
    flagship: true,
  },
  {
    name: "Signal Floor — Tokyo",
    city: "Tokyo",
    country: "Japan",
    region: "Asia",
    address: "5-1-9 Jingumae, Shibuya City, Tokyo 150-0001, Japan",
    hours: "Daily 11:00–21:00",
    image:
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200&q=80&auto=format&fit=crop",
  },
  {
    name: "Static Supply — London",
    city: "London",
    country: "United Kingdom",
    region: "Europe",
    address: "8 Redchurch Street, London E2 7DP, United Kingdom",
    hours: "Mon–Sat 11:00–19:00 · Sun 12:00–18:00",
    image:
      "https://images.unsplash.com/photo-1481437156560-3205f6a55735?w=1200&q=80&auto=format&fit=crop",
  },
  {
    name: "Neon Court NYC — SoHo",
    city: "New York",
    country: "United States",
    region: "North America",
    address: "88 Crosby Street, New York, NY 10012, United States",
    hours: "Mon–Sun 11:00–20:00",
    image:
      "https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?w=1200&q=80&auto=format&fit=crop",
  },
  {
    name: "After Dark — Paris",
    city: "Paris",
    country: "France",
    region: "Europe",
    address: "14 Rue de Turenne, 75003 Paris, France",
    hours: "Tue–Sat 11:00–19:30 · Sun–Mon closed",
    image:
      "https://images.unsplash.com/photo-1495121605193-b116b5b9c5fe?w=1200&q=80&auto=format&fit=crop",
  },
  {
    name: "Concrete Goods — Amsterdam",
    city: "Amsterdam",
    country: "Netherlands",
    region: "Europe",
    address: "Haarlemmerstraat 64, 1013 EM Amsterdam, Netherlands",
    hours: "Mon–Sat 10:00–18:30 · Sun 12:00–18:00",
    image:
      "https://images.unsplash.com/photo-1551232864-3f0890e580d9?w=1200&q=80&auto=format&fit=crop",
  },
];

export default function StockistsPage() {
  return (
    <SiteShell>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0">
          <Image
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1800&q=80&auto=format&fit=crop"
            alt="VoltHaus retail flagship interior with sneaker display"
            fill
            priority
            sizes="100vw"
            className="object-cover opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
          <div
            aria-hidden
            className="absolute -left-32 top-1/3 h-80 w-80 rounded-full bg-secondary/15 blur-3xl"
          />
        </div>
        <div className="relative container mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <Breadcrumbs items={[{ label: "Stockists" }]} className="mb-6" />
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            Offline
          </p>
          <h1 className="mt-3 max-w-3xl text-balance text-4xl font-black leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Find VoltHaus in{" "}
            <span className="text-gradient-primary">real life</span>
          </h1>
          <p className="mt-5 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Three flagship studios and five partner stockists across Europe,
            Japan, and the United States. Visit any location to see the
            current capsule in person, get fit, and pick up pieces without
            waiting for a drop.
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <Link
              href="/shop"
              className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Shop online
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
            <Link
              href="/contact"
              className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-transparent px-5 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:bg-card"
            >
              Become a stockist
            </Link>
          </div>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="container mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
        <div className="relative overflow-hidden rounded-3xl border border-border bg-card">
          <div className="relative aspect-[16/9] sm:aspect-[21/9]">
            <Image
              src="https://images.unsplash.com/photo-1505761671935-60b3a7427bad?w=1600&q=80&auto=format&fit=crop"
              alt="Map showing VoltHaus flagship and partner stockist locations across Europe, Japan, and the United States"
              fill
              sizes="100vw"
              className="object-cover opacity-70"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-card/80 via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                  Eight locations
                </p>
                <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                  Berlin · Lisbon · Milan · Tokyo · London · NYC · Paris ·
                  Amsterdam
                </h2>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stockist grid */}
      <section className="container mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8 lg:pb-16">
        <StockistGrid stockists={STOCKISTS} />
      </section>

      {/* Become a stockist CTA */}
      <section className="container mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8 lg:pb-24">
        <ScrollReveal>
          <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-8 sm:p-12">
            <div
              aria-hidden
              className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-primary/15 blur-3xl"
            />
            <div className="relative flex flex-col items-start gap-6 lg:flex-row lg:items-center lg:justify-between">
              <div className="max-w-2xl">
                <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                  Wholesale
                </p>
                <h2 className="mt-3 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
                  Become a stockist
                </h2>
                <p className="mt-3 text-sm text-muted-foreground">
                  We onboard a small number of new partners each season.
                  Submit your store details, the brands you currently carry,
                  and the VoltHaus capsules you are most interested in. We
                  review every application within ten business days.
                </p>
              </div>
              <Link
                href="/contact"
                className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Apply to stock VoltHaus
                <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
            </div>
          </div>
        </ScrollReveal>
      </section>
    </SiteShell>
  );
}
