import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, ArrowLeft, ShoppingBag } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { ProductCard } from "@/components/product";
import { ScrollReveal } from "@/components/motion";
import { lookbookItems } from "@/data/lookbook";
import { getProductBySlug } from "@/data/products";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return lookbookItems.map((i) => ({ slug: i.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const item = lookbookItems.find((i) => i.slug === slug);
  if (!item) return { title: "Lookbook Not Found" };
  const url = `https://volthaus.co/lookbook/${item.slug}`;
  return {
    title: `${item.title} — Lookbook`,
    description: item.description,
    alternates: { canonical: url },
    openGraph: {
      title: `${item.title} | VoltHaus Lookbook`,
      description: item.description,
      url,
      images: [
        {
          url: item.image,
          width: 1200,
          height: 630,
          alt: item.title,
        },
      ],
    },
  };
}

export default async function LookbookDetailRoute({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const item = lookbookItems.find((i) => i.slug === slug);
  if (!item) notFound();

  const products = item.productSlugs
    .map((s) => getProductBySlug(s))
    .filter((p): p is NonNullable<ReturnType<typeof getProductBySlug>> =>
      Boolean(p)
    );

  const related = lookbookItems
    .filter((i) => i.season === item.season && i.slug !== item.slug)
    .slice(0, 4);

  return (
    <SiteShell>
      {/* Hero image */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="relative h-[60vh] min-h-[420px] w-full sm:h-[72vh]">
          <Image
            src={item.image}
            alt={item.title}
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-background/10" />
          <div className="absolute inset-x-0 bottom-0">
            <div className="container mx-auto max-w-7xl px-4 pb-8 sm:px-6 lg:px-8 lg:pb-12">
              <Breadcrumbs
                items={[
                  { label: "Lookbook", href: "/lookbook" },
                  { label: item.title },
                ]}
                className="mb-6"
              />
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-3 py-1 text-[11px] font-mono uppercase tracking-wider text-primary">
                  {item.category}
                </span>
                <span className="inline-flex items-center rounded-full border border-border bg-background/70 px-3 py-1 text-[11px] font-mono uppercase tracking-wider text-muted-foreground backdrop-blur">
                  {item.season}
                </span>
              </div>
              <h1 className="mt-4 max-w-4xl text-balance text-3xl font-black leading-[1.1] tracking-tight text-foreground sm:text-4xl lg:text-5xl">
                {item.title}
              </h1>
            </div>
          </div>
        </div>
      </section>

      {/* Description + meta */}
      <section className="container mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
          <ScrollReveal>
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              About this look
            </p>
            <p className="mt-4 text-lg leading-relaxed text-foreground/90">
              {item.description}
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                href="/lookbook"
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-transparent px-5 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:bg-card"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden />
                All looks
              </Link>
              <a
                href="#shop-the-look"
                className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                <ShoppingBag className="h-4 w-4" aria-hidden />
                Shop the look
              </a>
            </div>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <aside className="rounded-2xl border border-border bg-card p-6">
              <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                Look details
              </p>
              <dl className="mt-4 space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">Category</dt>
                  <dd className="font-semibold text-foreground">
                    {item.category}
                  </dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">Season</dt>
                  <dd className="font-semibold text-foreground">
                    {item.season}
                  </dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">Pieces in look</dt>
                  <dd className="font-semibold text-foreground">
                    {products.length}
                  </dd>
                </div>
              </dl>
            </aside>
          </ScrollReveal>
        </div>
      </section>

      {/* Shop the look */}
      <section
        id="shop-the-look"
        className="container mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8 lg:pb-16"
      >
        <SectionHeading
          eyebrow="Shop the look"
          title={
            <>
              Pieces from{" "}
              <span className="text-gradient-primary">this frame</span>
            </>
          }
          description="Every product in this look, available to shop individually. Each piece is from a limited numbered run."
          className="mb-8"
        />
        {products.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No products linked to this look yet.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {products.map((p, i) => (
              <ScrollReveal key={p.id} delay={Math.min(i * 0.05, 0.3)}>
                <ProductCard product={p} priority={i < 4} />
              </ScrollReveal>
            ))}
          </div>
        )}
      </section>

      {/* Related looks */}
      {related.length > 0 && (
        <section className="container mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8 lg:pb-24">
          <SectionHeading
            eyebrow="More from this season"
            title={
              <>
                Related{" "}
                <span className="text-gradient-primary">looks</span>
              </>
            }
            className="mb-8"
          />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((r, i) => (
              <ScrollReveal key={r.id} delay={i * 0.06}>
                <Link
                  href={`/lookbook/${r.slug}`}
                  className="group relative block aspect-[4/5] overflow-hidden rounded-xl border border-border bg-card transition-colors hover:border-primary/40"
                >
                  <Image
                    src={r.image}
                    alt={r.title}
                    fill
                    sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-primary">
                      {r.category} · {r.season}
                    </span>
                    <p className="mt-1 text-sm font-bold tracking-tight text-foreground">
                      {r.title}
                    </p>
                    <span className="mt-2 inline-flex items-center gap-1 text-xs text-primary opacity-0 transition-opacity group-hover:opacity-100">
                      View look
                      <ArrowRight className="h-3 w-3" aria-hidden />
                    </span>
                  </div>
                </Link>
              </ScrollReveal>
            ))}
          </div>
        </section>
      )}
    </SiteShell>
  );
}
