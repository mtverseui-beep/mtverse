import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { LookbookGrid } from "@/components/content/lookbook-grid";

export const metadata: Metadata = {
  title: "FW26 Lookbook",
  description:
    "Browse the VoltHaus FW26 and SS26 lookbook — editorial street, studio, night, and editorial frames shot across Milan, Berlin, and Lisbon. Shop every look.",
  alternates: { canonical: "https://volthaus.co/lookbook" },
  openGraph: {
    title: "FW26 Lookbook | VoltHaus",
    description:
      "Editorial street, studio, night, and editorial frames shot across Milan, Berlin, and Lisbon. Shop every look.",
    url: "https://volthaus.co/lookbook",
  },
};

export default function LookbookPage() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[{ label: "Lookbook" }]}
          className="mb-6"
        />
        <ScrollReveal>
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            Visual archive
          </p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">
            FW26 <span className="text-gradient-primary">Lookbook</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Eight editorial frames from the SS26 and FW26 seasons, shot across
            Milan, Berlin, and Lisbon. Click any frame to shop the look piece
            by piece.
          </p>
        </ScrollReveal>

        <div className="mt-10">
          <LookbookGrid />
        </div>

        <ScrollReveal>
          <p className="mt-10 text-sm text-muted-foreground">
            Want the full shoot notes? Each look has its own page with the
            cast, crew, location, and the full shoppable product list. Start
            with{" "}
            <a
              href="/lookbook/neon-court-milan-night"
              className="font-medium text-primary underline-offset-4 hover:underline"
            >
              Neon Court at the Milan Intersection
            </a>{" "}
            or browse the full archive above.
          </p>
        </ScrollReveal>
      </div>
    </SiteShell>
  );
}
