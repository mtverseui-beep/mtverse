import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SiteShell } from "@/components/layout";
import { ProductDetail } from "@/components/product/product-detail";
import {
  getAllProductSlugs,
  getProductBySlug,
  getRelatedProducts,
  products,
} from "@/data/products";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return getAllProductSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = getProductBySlug(slug);
  if (!product) {
    return { title: "Product Not Found" };
  }
  const url = `https://volthaus.co/product/${product.slug}`;
  return {
    title: product.name,
    description: product.shortDescription,
    alternates: { canonical: url },
    openGraph: {
      title: `${product.name} | VoltHaus`,
      description: product.shortDescription,
      url,
      type: "website",
      images: product.images.slice(0, 1).map((src) => ({
        url: src,
        width: 1200,
        height: 630,
        alt: product.name,
      })),
    },
    twitter: {
      card: "summary_large_image",
      title: `${product.name} | VoltHaus`,
      description: product.shortDescription,
      images: product.images.slice(0, 1),
    },
  };
}

export default async function ProductRoute({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const product = getProductBySlug(slug);
  if (!product) {
    notFound();
  }
  const related = getRelatedProducts(slug, 4);
  // Recently-viewed list is computed client-side; we just provide candidates.
  const recentlyViewedCandidates = products
    .filter((p) => p.slug !== slug)
    .slice(0, 8);

  const productSchema = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    image: product.images,
    description: product.description,
    sku: product.id,
    brand: { "@type": "Brand", name: "VoltHaus" },
    category: product.category,
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: product.rating,
      reviewCount: product.reviewCount,
    },
    offers: {
      "@type": "Offer",
      price: product.price.toFixed(2),
      priceCurrency: "USD",
      availability:
        product.dropStatus === "sold-out"
          ? "https://schema.org/OutOfStock"
          : "https://schema.org/InStock",
      url: `https://volthaus.co/product/${product.slug}`,
    },
  };

  return (
    <SiteShell>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }}
      />
      <ProductDetail
        product={product}
        related={related}
        recentlyViewed={recentlyViewedCandidates}
        breadcrumbs={[
          { label: "Shop", href: "/shop" },
          { label: product.category, href: `/shop/${slugifyCategory(product.category)}` },
          { label: product.name },
        ]}
      />
    </SiteShell>
  );
}

function slugifyCategory(category: string): string {
  const map: Record<string, string> = {
    Sneakers: "sneakers",
    Hoodies: "hoodies",
    "Graphic Tees": "graphic-tees",
    "Cargo Pants": "cargo-pants",
    Jackets: "jackets",
    Caps: "caps",
    Bags: "bags",
    Accessories: "accessories",
  };
  return map[category] ?? category.toLowerCase();
}
