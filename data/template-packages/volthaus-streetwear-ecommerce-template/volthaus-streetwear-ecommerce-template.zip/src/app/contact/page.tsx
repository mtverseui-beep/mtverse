import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ChevronRight } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { ContactForm, ContactInfoCard } from "@/components/content/contact-form";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Get in touch with VoltHaus support. Mon–Fri 9–6 CET, under one business day response time. Order, returns, drop alerts, partnership, and press categories.",
  alternates: { canonical: "https://volthaus.co/contact" },
  openGraph: {
    title: "Contact | VoltHaus",
    description:
      "Get in touch with VoltHaus support. Mon–Fri 9–6 CET, under one business day response time.",
    url: "https://volthaus.co/contact",
  },
};

const QUICK_LINKS = [
  {
    label: "Track an order",
    href: "/track-order",
    description: "Live tracking from the carrier.",
  },
  {
    label: "Start a return",
    href: "/help/returns",
    description: "30-day window, prepaid label included.",
  },
  {
    label: "Drop alerts",
    href: "/drop-calendar",
    description: "See upcoming drops and set reminders.",
  },
  {
    label: "Size guide",
    href: "/size-guide",
    description: "Fit notes for every silhouette.",
  },
];

export default function ContactPage() {
  return (
    <SiteShell>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0">
          <Image
            src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1800&q=80&auto=format&fit=crop"
            alt="VoltHaus Berlin studio reception desk"
            fill
            priority
            sizes="100vw"
            className="object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
          <div
            aria-hidden
            className="absolute -right-32 top-1/3 h-80 w-80 rounded-full bg-primary/15 blur-3xl"
          />
        </div>
        <div className="relative container mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <Breadcrumbs items={[{ label: "Contact" }]} className="mb-6" />
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            We are listening
          </p>
          <h1 className="mt-3 max-w-3xl text-balance text-4xl font-black leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Get in <span className="text-gradient-primary">touch</span>
          </h1>
          <p className="mt-5 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Send us a message and we will route it to the right team. Most
            replies land inside one business day. Live drop days have a
            dedicated in-app chat with sub-fifteen-minute response.
          </p>
        </div>
      </section>

      {/* Form + info */}
      <section className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:gap-10">
          <ScrollReveal>
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              Send a message
            </p>
            <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
              We answer every email
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Fill in the form and we will get back to you from
              support@volthaus.co. Include an order number if your message is
              about a specific order.
            </p>
            <div className="mt-6">
              <ContactForm />
            </div>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <ContactInfoCard />
          </ScrollReveal>
        </div>
      </section>

      {/* Map placeholder */}
      <section className="container mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8 lg:pb-16">
        <div className="relative overflow-hidden rounded-2xl border border-border bg-card">
          <div className="relative aspect-[16/9] sm:aspect-[21/9]">
            <Image
              src="https://images.unsplash.com/photo-1524661135-423995f22d0b?w=1600&q=80&auto=format&fit=crop"
              alt="Aerial view of the Kreuzberg neighborhood in Berlin where the VoltHaus studio is located"
              fill
              sizes="100vw"
              className="object-cover opacity-70"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-background/30 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                  Studio HQ
                </p>
                <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                  Oranienstraße 6, Berlin
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Open by appointment only. Email us to schedule a visit.
                </p>
              </div>
              <a
                href="https://maps.google.com/?q=Oranienstrasse+6+Berlin"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-background/70 px-5 text-sm font-semibold text-foreground backdrop-blur transition-colors hover:border-primary/50 hover:text-primary"
              >
                Open in Maps
                <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ quick links */}
      <section className="container mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8 lg:pb-24">
        <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
          Quick links
        </p>
        <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
          Common requests
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Most messages we get fit into one of these buckets. Skip the form
          and jump straight to the right page.
        </p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {QUICK_LINKS.map((q) => (
            <Link
              key={q.href}
              href={q.href}
              className="group flex flex-col rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/40"
            >
              <h3 className="text-base font-bold tracking-tight text-foreground">
                {q.label}
              </h3>
              <p className="mt-2 flex-1 text-sm text-muted-foreground">
                {q.description}
              </p>
              <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-primary">
                Open
                <ChevronRight
                  className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1"
                  aria-hidden
                />
              </span>
            </Link>
          ))}
        </div>
      </section>
    </SiteShell>
  );
}
