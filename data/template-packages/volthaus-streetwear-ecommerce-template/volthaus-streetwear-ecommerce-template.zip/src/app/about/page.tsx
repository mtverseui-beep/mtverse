import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Boxes,
  Compass,
  Leaf,
  MapPin,
  Sparkles,
  Users,
} from "lucide-react";
import { SiteShell } from "@/components/layout";
import {
  Breadcrumbs,
  SectionHeading,
  StarRating,
} from "@/components/common";
import {
  AnimatedCounter,
  MagneticButton,
  Marquee,
  ScrollReveal,
} from "@/components/motion";

export const metadata: Metadata = {
  title: "About VoltHaus",
  description:
    "VoltHaus is a premium streetwear and sneaker studio built for the next street culture wave. Limited drops, creator-led capsules, and sustainable production across four cities.",
  alternates: { canonical: "https://volthaus.co/about" },
  openGraph: {
    title: "About VoltHaus",
    description:
      "Premium streetwear and sneaker studio built for the next street culture wave. Limited drops, creator-led capsules, and sustainable production.",
    url: "https://volthaus.co/about",
  },
};

const MISSION = [
  {
    icon: Boxes,
    title: "Limited drops",
    body: "Every VoltHaus piece is produced in a single numbered run. When a drop sells through, it sells through. No endless restocks, no overstock, no landfill filler.",
  },
  {
    icon: Sparkles,
    title: "Creator-led",
    body: "Each capsule begins with a creator — a photographer, designer, skater, or musician — and the program ships with the documentation of how it was made.",
  },
  {
    icon: Leaf,
    title: "Sustainable production",
    body: "Our ripstop is woven in a single Osaka workshop on a closed-loop water system. Heavyweight fleece uses a recycled cotton blend that holds its shape past fifty washes.",
  },
];

const TIMELINE = [
  {
    year: "2023",
    title: "VoltHaus founded",
    body: "Started in a Berlin studio apartment with three people, one sewing machine, and a single sample run of the Static Club hoodie.",
  },
  {
    year: "2024",
    title: "First public drop",
    body: "Signal Drop 01 sold through in nine minutes. The waitlist crossed ten thousand the same day and the Static Club tier was born.",
  },
  {
    year: "2025",
    title: "First flagship opens",
    body: "Flagship doors in Berlin and Lisbon open within four months of each other, doubling as wear-test labs for the design team.",
  },
  {
    year: "2026",
    title: "SS26 collection",
    body: "The largest season to date — six capsules, twenty-four products, six creators, and the first Archive Reissue program launches.",
  },
];

const STATS = [
  { value: 50, suffix: "K+", label: "Club members", icon: Users },
  { value: 200, suffix: "+", label: "Drops shipped", icon: Boxes },
  { value: 12, suffix: "", label: "Creators on roster", icon: Sparkles },
  { value: 4, suffix: "", label: "Cities with a flagship", icon: MapPin },
];

const STUDIO_IMAGE =
  "https://images.unsplash.com/photo-1554995207-c18c203602cb?w=1600&q=80&auto=format&fit=crop";

const STUDIO_IMAGE_ALT =
  "VoltHaus Berlin studio space with fabric rolls and pattern tables";

export default function AboutPage() {
  return (
    <SiteShell>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0">
          <Image
            src={STUDIO_IMAGE}
            alt={STUDIO_IMAGE_ALT}
            fill
            priority
            sizes="100vw"
            className="object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
          <div className="absolute inset-0 grid-bg opacity-30" />
        </div>
        <div className="relative container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-28">
          <Breadcrumbs items={[{ label: "About" }]} className="mb-8" />
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            About VoltHaus
          </p>
          <h1 className="mt-3 max-w-4xl text-balance text-4xl font-black leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Built for the{" "}
            <span className="text-gradient-primary">
              next street culture
            </span>{" "}
            wave
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            VoltHaus is a premium streetwear and sneaker studio with a single
            thesis: build a small number of pieces properly, release them in
            limited numbered runs, and document every decision so the wearer
            knows what they own. We are headquartered in Berlin and operate
            flagship studios in four cities.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <MagneticButton as="a" href="/rewards" variant="primary">
              Join the club
              <ArrowRight className="h-4 w-4" />
            </MagneticButton>
            <MagneticButton as="a" href="/shop" variant="outline">
              Shop the drop
            </MagneticButton>
          </div>
          <div className="mt-8 flex items-center gap-3 text-sm text-muted-foreground">
            <StarRating rating={4.8} size={16} />
            <span>4.8 average from 1,840+ verified buyers</span>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <SectionHeading
          eyebrow="What we stand for"
          title={
            <>
              Three principles that shape{" "}
              <span className="text-gradient-primary">every capsule</span>
            </>
          }
          description="Our principles are the filter we run every material, color, and silhouette decision through before it earns a place in a drop."
          className="mb-10 max-w-3xl"
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {MISSION.map((item, i) => (
            <ScrollReveal key={item.title} delay={i * 0.08}>
              <article className="group h-full rounded-2xl border border-border bg-card p-6 transition-colors duration-200 hover:border-primary/40">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-border bg-background text-primary transition-colors group-hover:border-primary/40">
                  <item.icon className="h-6 w-6" aria-hidden />
                </div>
                <h3 className="mt-5 text-lg font-bold tracking-tight text-foreground">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {item.body}
                </p>
              </article>
            </ScrollReveal>
          ))}
        </div>
      </section>

      {/* Timeline */}
      <section className="relative overflow-hidden border-y border-border bg-card/40">
        <div className="absolute inset-0 grid-bg opacity-20" aria-hidden />
        <div className="relative container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <SectionHeading
            eyebrow="The timeline"
            title={
              <>
                From studio apartment to{" "}
                <span className="text-gradient-primary">four cities</span>
              </>
            }
            description="A condensed history of how VoltHaus grew from a single sample run into a multi-city studio without losing the things that made the first drop work."
            className="mb-12 max-w-3xl"
          />
          <ol className="grid gap-6 lg:grid-cols-4">
            {TIMELINE.map((entry, i) => (
              <ScrollReveal key={entry.year} delay={i * 0.08} as="li">
                <div className="relative h-full rounded-2xl border border-border bg-background/60 p-6">
                  <div className="flex items-baseline justify-between">
                    <span className="font-mono text-3xl font-black text-primary">
                      {entry.year}
                    </span>
                    <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                      Step {i + 1}
                    </span>
                  </div>
                  <h3 className="mt-3 text-base font-bold tracking-tight text-foreground">
                    {entry.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {entry.body}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </ol>
        </div>
      </section>

      {/* Stats */}
      <section className="container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <SectionHeading
          eyebrow="By the numbers"
          title={
            <>
              The street,{" "}
              <span className="text-gradient-primary">measured</span>
            </>
          }
          description="Real numbers behind the VoltHaus community, production footprint, and creator roster as of the SS26 season."
          align="center"
          className="mb-12"
        />
        <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
          {STATS.map((stat, i) => (
            <ScrollReveal key={stat.label} delay={i * 0.06}>
              <div className="rounded-2xl border border-border bg-card p-6 text-center">
                <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full border border-primary/30 bg-primary/10 text-primary">
                  <stat.icon className="h-5 w-5" aria-hidden />
                </div>
                <div className="mt-4 text-4xl font-black tracking-tight text-foreground sm:text-5xl">
                  <AnimatedCounter
                    value={stat.value}
                    suffix={stat.suffix}
                    duration={1.8}
                  />
                </div>
                <p className="mt-1 text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  {stat.label}
                </p>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </section>

      {/* Street culture positioning */}
      <section className="relative overflow-hidden border-y border-border">
        <div className="grid gap-0 lg:grid-cols-2">
          <div className="relative min-h-[320px] overflow-hidden lg:min-h-[520px]">
            <Image
              src="https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?w=1400&q=80&auto=format&fit=crop"
              alt="Crew crossing a city intersection at night wearing VoltHaus pieces"
              fill
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-background/60 lg:to-background/30" />
          </div>
          <div className="bg-card/40 p-8 sm:p-12 lg:flex lg:items-center lg:p-16">
            <ScrollReveal className="max-w-xl">
              <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
                Where we sit
              </p>
              <h2 className="mt-3 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
                Street culture, not fashion week
              </h2>
              <div className="mt-5 space-y-4 text-base leading-relaxed text-muted-foreground">
                <p>
                  VoltHaus sits inside street culture, not above it. We are
                  built by people who wear the clothes every day, wear-test
                  every silhouette before it ships, and pull cast and crew from
                  the communities the product is actually for.
                </p>
                <p>
                  That means a Milan night shoot with a cast from the local
                  skate scene, not a casting agency. It means a capsule
                  designed by a pattern cutter who rebuilt the shoulder from
                  scratch, not styled by a committee. It means a zine ships
                  with every Creator Capsule hoodie explaining every decision
                  that went into it.
                </p>
                <p>
                  We are not trying to scale into every mall in every city. We
                  are trying to make a small number of pieces that the people
                  who care about them keep for years.
                </p>
              </div>
              <div className="mt-6 flex flex-wrap items-center gap-2">
                <Compass className="h-4 w-4 text-primary" aria-hidden />
                <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  Berlin · Lisbon · Milan · Tokyo
                </span>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Marquee of principles */}
      <section className="border-b border-border bg-background py-6">
        <Marquee speed={32} className="text-foreground">
          {[
            "LIMITED DROPS",
            "CREATOR-LED CAPSULES",
            "SUSTAINABLE PRODUCTION",
            "WEAR-TESTED",
            "NUMBERED RUNS",
            "REPAIR CREDIT",
            "MEMBER EARLY ACCESS",
          ].map((word, i) => (
            <span
              key={`${word}-${i}`}
              className="mx-6 inline-flex items-center gap-6 font-mono text-xl font-black tracking-[0.2em] text-foreground/70 sm:text-2xl"
            >
              {word}
              <span
                aria-hidden
                className="h-1.5 w-1.5 rounded-full bg-primary"
              />
            </span>
          ))}
        </Marquee>
      </section>

      {/* CTA */}
      <section className="container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <ScrollReveal>
          <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-8 sm:p-12 lg:p-16">
            <div
              aria-hidden
              className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-primary/15 blur-3xl"
            />
            <div
              aria-hidden
              className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-secondary/15 blur-3xl"
            />
            <div className="relative flex flex-col items-start gap-6 lg:flex-row lg:items-center lg:justify-between">
              <div className="max-w-2xl">
                <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
                  Get in early
                </p>
                <h2 className="mt-3 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
                  Join the Static Club
                </h2>
                <p className="mt-3 text-base text-muted-foreground">
                  Members get early access to every drop, free express shipping
                  above tier, an annual repair credit, and the members-only
                  release calendar. Membership is free — you earn your tier by
                  engaging.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <MagneticButton as="a" href="/rewards" variant="primary">
                  Join the club
                  <ArrowRight className="h-4 w-4" />
                </MagneticButton>
                <Link
                  href="/shop"
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-transparent px-5 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:bg-card focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                >
                  Shop the drop
                </Link>
              </div>
            </div>
          </div>
        </ScrollReveal>
      </section>
    </SiteShell>
  );
}
