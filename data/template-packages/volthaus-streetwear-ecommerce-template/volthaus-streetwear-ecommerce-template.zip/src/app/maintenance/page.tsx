import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { Wrench, Mail, Instagram, Twitter, Music2, Youtube } from "lucide-react";

export const metadata: Metadata = {
  title: "Under maintenance",
  description:
    "VoltHaus is undergoing scheduled maintenance. We'll be back online shortly.",
  robots: { index: false, follow: false },
};

const SOCIAL_LINKS = [
  { label: "Instagram", href: "https://instagram.com/volthaus", icon: Instagram },
  { label: "Twitter", href: "https://twitter.com/volthaus", icon: Twitter },
  { label: "TikTok", href: "https://tiktok.com/@volthaus", icon: Music2 },
  { label: "YouTube", href: "https://youtube.com/@volthaus", icon: Youtube },
];

export default function MaintenancePage() {
  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-background text-foreground">
      {/* Animated grid background */}
      <div
        aria-hidden="true"
        className="grid-bg-animated pointer-events-none absolute inset-0 opacity-50"
      />

      {/* Glow orbs */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-[15%] top-[20%] h-72 w-72 rounded-full bg-primary/15 blur-[120px] animate-pulse-glow"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-[15%] bottom-[18%] h-72 w-72 rounded-full bg-secondary/15 blur-[120px] animate-pulse-glow-magenta"
      />

      {/* Top-left logo only — no nav, no cart, no search */}
      <div className="relative z-10 p-6 sm:p-8">
        <Link
          href="/"
          aria-label="VoltHaus home"
          className="inline-flex items-center gap-2 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Image
            src="/logo.svg"
            alt=""
            width={120}
            height={28}
            priority
            className="h-7 w-auto"
          />
          <span className="sr-only">VoltHaus</span>
        </Link>
      </div>

      {/* Main message */}
      <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-4 pb-16 pt-4 sm:px-6">
        <div className="w-full max-w-2xl text-center">
          {/* Icon medallion */}
          <div className="mx-auto mb-8 inline-flex h-20 w-20 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10">
            <Wrench
              className="h-9 w-9 text-primary"
              aria-hidden="true"
              strokeWidth={1.75}
            />
          </div>

          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-primary">
            Scheduled maintenance
          </p>

          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
            We&apos;ll be right back
          </h1>

          <p className="mx-auto mt-4 max-w-md text-pretty text-sm text-muted-foreground sm:text-base">
            VoltHaus is undergoing scheduled maintenance. We&apos;ll be back
            online shortly.
          </p>

          {/* Estimated downtime */}
          <div className="mx-auto mt-8 inline-flex flex-col items-stretch gap-3 rounded-lg border border-border bg-card/60 p-5 sm:flex-row sm:items-center sm:gap-6">
            <div className="text-left sm:text-center">
              <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                Estimated downtime
              </p>
              <p className="mt-1 text-lg font-semibold text-foreground">
                Under 2 hours
              </p>
            </div>
            <span
              aria-hidden="true"
              className="hidden h-10 w-px bg-border sm:block"
            />
            <div className="text-left sm:text-center">
              <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                Window
              </p>
              <p className="mt-1 text-lg font-semibold text-foreground">
                02:00 – 04:00 UTC
              </p>
            </div>
          </div>

          {/* Support email */}
          <p className="mt-8 text-sm text-muted-foreground">
            Urgent question? Email our team at{" "}
            <a
              href="mailto:support@volthaus.co"
              className="font-medium text-primary hover:underline focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
            >
              support@volthaus.co
            </a>{" "}
            and we&apos;ll get back to you within one business day.
          </p>

          {/* Social links */}
          <div className="mt-10 border-t border-border pt-6">
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
              Stay updated
            </p>
            <ul className="mt-4 flex flex-wrap items-center justify-center gap-3">
              {SOCIAL_LINKS.map((social) => {
                const Icon = social.icon;
                return (
                  <li key={social.href}>
                    <a
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`${social.label} (opens in new tab)`}
                      className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-border bg-card/60 text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                    >
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </main>

      {/* Lock-down footer — no nav, no policy links */}
      <footer className="relative z-10 px-4 py-6 text-center sm:px-6">
        <p className="text-xs text-muted-foreground">
          &copy; {new Date().getFullYear()} VoltHaus. All rights reserved.
        </p>
      </footer>
    </div>
  );
}
