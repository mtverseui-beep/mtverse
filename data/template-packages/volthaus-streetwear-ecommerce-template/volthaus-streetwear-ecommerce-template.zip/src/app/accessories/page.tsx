import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { ShopPage } from "@/components/ecommerce/shop-page";
import { products } from "@/data/products";
import type { ProductCategory } from "@/types";

export const metadata: Metadata = {
  title: "Accessories",
  description: "VoltHaus accessories — caps, bags, beanies, socks, and small leather goods that anchor every fit. The details that finish the drop.",
  alternates: { canonical: "https://volthaus.co/accessories" },
  openGraph: {
    title: "Accessories | VoltHaus",
    description: "Caps, bags, beanies, and socks that finish every VoltHaus fit.",
    url: "https://volthaus.co/accessories",
  },
};

const ACCESSORY_CATEGORIES: ProductCategory[] = [
  "Caps",
  "Bags",
  "Accessories",
];

export default function AccessoriesRoute() {
  const accessories = products.filter((p) =>
    ACCESSORY_CATEGORIES.includes(p.category)
  );
  return (
    <SiteShell>
      <ShopPage
        products={accessories}
        eyebrow="Finish the fit"
        title="Accessories"
        description="Caps, bags, beanies, and small leather goods that finish every VoltHaus fit. The details that anchor a drop — often the first pieces to sell out."
        breadcrumbs={[{ label: "Shop", href: "/shop" }, { label: "Accessories" }]}
      />
    </SiteShell>
  );
}
