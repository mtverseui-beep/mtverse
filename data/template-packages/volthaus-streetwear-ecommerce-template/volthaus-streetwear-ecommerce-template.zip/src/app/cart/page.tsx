import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { CartPage } from "@/components/ecommerce/cart-page";
import { getBestSellers } from "@/data/products";

export const metadata: Metadata = {
  title: "Your Cart",
  description: "Review your VoltHaus cart, apply discount codes, and proceed to secure checkout.",
  alternates: { canonical: "https://volthaus.co/cart" },
  robots: { index: false, follow: false },
};

export default function CartRoute() {
  return (
    <SiteShell>
      <CartPage bestSellers={getBestSellers()} />
    </SiteShell>
  );
}
