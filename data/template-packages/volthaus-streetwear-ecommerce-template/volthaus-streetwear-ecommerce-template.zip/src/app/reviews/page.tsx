import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { ReviewsPage } from "@/components/content/reviews-page";

export const metadata: Metadata = {
  title: "Reviews",
  description:
    "The street speaks. Read verified VoltHaus buyer reviews across the catalog, filter by rating, sort, and submit your own review.",
  alternates: { canonical: "https://volthaus.co/reviews" },
  openGraph: {
    title: "Reviews | VoltHaus",
    description:
      "Verified buyer reviews across the VoltHaus catalog. Filter, sort, and submit your own.",
    url: "https://volthaus.co/reviews",
  },
};

export default function ReviewsRoute() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "Reviews" }]} className="mb-6" />
        <ScrollReveal>
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            The street speaks
          </p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">
            What the{" "}
            <span className="text-gradient-primary">community says</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Real reviews from verified VoltHaus buyers across the SS26 and FW26
            catalog. Filter by rating, toggle verified-only, and sort to find
            the reviews that matter to you.
          </p>
        </ScrollReveal>
        <div className="mt-10">
          <ReviewsPage />
        </div>
      </div>
    </SiteShell>
  );
}
