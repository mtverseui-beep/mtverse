import type { Metadata } from "next";
import { Suspense } from "react";
import { SiteShell } from "@/components/layout";
import { SearchResultsPage } from "@/components/ecommerce/search-results-page";

export const metadata: Metadata = {
  title: "Search",
  description: "Search the VoltHaus catalog — products, collections, creators, and journal entries.",
  alternates: { canonical: "https://volthaus.co/search" },
  robots: { index: false, follow: false },
};

export default function SearchRoute() {
  return (
    <SiteShell>
      <Suspense
        fallback={
          <div className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
            <p className="text-sm text-muted-foreground">Loading search…</p>
          </div>
        }
      >
        <SearchResultsPage />
      </Suspense>
    </SiteShell>
  );
}
