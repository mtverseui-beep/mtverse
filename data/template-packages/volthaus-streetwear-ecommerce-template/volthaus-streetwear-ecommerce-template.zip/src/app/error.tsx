"use client";

import { useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { AlertTriangle, Home, RefreshCw } from "lucide-react";
import { useReducedMotion } from "@/hooks";

export interface ErrorBoundaryProps {
  error: Error & { digest?: string };
  reset: () => void;
}

/**
 * Global error boundary. Rendered whenever a server or client component in
 * the route tree throws an uncaught error. Kept self-contained: no SiteShell,
 * no header, no footer, no cart, no third-party dependencies beyond what's
 * already in the project.
 */
export default function ErrorBoundary({ error, reset }: ErrorBoundaryProps) {
  const reducedMotion = useReducedMotion();

  // Surface the error to the browser console / any error monitoring that
  // might be wired into the page. This runs once per error instance.
  useEffect(() => {
    console.error("[VoltHaus] route error:", error);
  }, [error]);

  const headlineVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 } }
    : {
        initial: { opacity: 0, y: 10 },
        animate: { opacity: 1, y: 0 },
      };

  const glitchVariants = reducedMotion
    ? { initial: { opacity: 1 }, animate: { opacity: 1 } }
    : {
        initial: { opacity: 0, scale: 0.96, filter: "blur(8px)" },
        animate: {
          opacity: 1,
          scale: 1,
          filter: "blur(0px)",
        },
      };

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-background text-foreground">
      {/* Background grid */}
      <div
        aria-hidden="true"
        className="grid-bg-animated pointer-events-none absolute inset-0 opacity-40"
      />

      {/* Glow orbs */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-[15%] top-[20%] h-72 w-72 rounded-full bg-secondary/15 blur-[120px] animate-pulse-glow-magenta"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-[14%] bottom-[18%] h-72 w-72 rounded-full bg-primary/15 blur-[110px] animate-pulse-glow"
      />

      {/* Top-left logo */}
      <div className="relative z-10 p-6 sm:p-8">
        <Link
          href="/"
          aria-label="VoltHaus home"
          className="inline-flex items-center gap-2 rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Image
            src="/logo.svg"
            alt=""
            width={120}
            height={28}
            priority
            className="h-7 w-auto"
          />
          <span className="sr-only">VoltHaus</span>
        </Link>
      </div>

      {/* Main */}
      <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-4 pb-16 pt-4 sm:px-6">
        <motion.div
          {...glitchVariants}
          transition={
            reducedMotion
              ? { duration: 0 }
              : { duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }
          }
          className="w-full max-w-2xl text-center"
        >
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-secondary/30 bg-secondary/5 px-3 py-1 font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-secondary">
            <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
            Error 500
          </div>

          <h1
            className="select-none bg-gradient-to-br from-secondary via-primary to-accent bg-clip-text text-[clamp(5rem,18vw,12rem)] font-black leading-none tracking-tighter text-transparent"
            aria-label="500"
          >
            500
          </h1>

          <motion.h2
            {...headlineVariants}
            transition={
              reducedMotion
                ? { duration: 0 }
                : { duration: 0.5, ease: "easeOut", delay: 0.1 }
            }
            className="mt-4 text-balance text-2xl font-bold tracking-tight text-foreground sm:text-3xl md:text-4xl"
          >
            Something went wrong
          </motion.h2>

          <p className="mx-auto mt-4 max-w-md text-pretty text-sm text-muted-foreground sm:text-base">
            We hit an unexpected error. Our team has been notified and we are
            already looking into it.
          </p>

          {error?.digest ? (
            <p className="mt-3 font-mono text-xs text-muted-foreground/70">
              Reference: <span className="text-foreground/80">{error.digest}</span>
            </p>
          ) : null}

          <div className="mt-8 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
            <button
              type="button"
              onClick={() => reset()}
              className="btn-shine inline-flex items-center justify-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <RefreshCw className="h-4 w-4" aria-hidden="true" />
              Try again
            </button>
            <Link
              href="/"
              className="inline-flex items-center justify-center gap-2 rounded-md border border-border bg-card/60 px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <Home className="h-4 w-4" aria-hidden="true" />
              Back to home
            </Link>
          </div>

          <p className="mt-8 text-xs text-muted-foreground">
            Still stuck? Email{" "}
            <a
              href="mailto:support@volthaus.co"
              className="font-medium text-primary hover:underline focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
            >
              support@volthaus.co
            </a>{" "}
            and we&apos;ll get you sorted.
          </p>
        </motion.div>
      </main>
    </div>
  );
}
