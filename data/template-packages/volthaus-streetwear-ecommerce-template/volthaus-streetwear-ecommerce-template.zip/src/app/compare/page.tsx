import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { ComparePage } from "@/components/ecommerce/compare-page";

export const metadata: Metadata = {
  title: "Compare Products",
  description: "Compare VoltHaus products side by side — price, materials, fit, colors, sizes, and more.",
  alternates: { canonical: "https://volthaus.co/compare" },
  robots: { index: false, follow: false },
};

export default function CompareRoute() {
  return (
    <SiteShell>
      <ComparePage />
    </SiteShell>
  );
}
