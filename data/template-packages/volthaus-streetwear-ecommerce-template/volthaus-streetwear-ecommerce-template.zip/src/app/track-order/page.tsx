import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { TrackOrderForm } from "@/components/ecommerce/track-order-form";

export const metadata: Metadata = {
  title: "Track Your Order",
  description: "Track your VoltHaus order status in real time with your order number and email.",
  alternates: { canonical: "https://volthaus.co/track-order" },
};

export default function TrackOrderRoute() {
  return (
    <SiteShell>
      <TrackOrderForm />
    </SiteShell>
  );
}
