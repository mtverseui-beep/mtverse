import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPolicyBySlug } from "@/data/policies";
import { PolicyLayout } from "@/components/content/policy-layout";

const SLUG = "privacy";
const siteUrl = "https://volthaus.co";
const canonicalUrl = `${siteUrl}/privacy`;

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "How VoltHaus collects, uses, and protects your personal information when you shop with us or interact with our content. We never sell your data.",
  alternates: { canonical: canonicalUrl },
  openGraph: {
    title: "Privacy Policy | VoltHaus",
    description:
      "How VoltHaus collects, uses, and protects your personal information when you shop with us or interact with our content.",
    url: canonicalUrl,
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title: "Privacy Policy | VoltHaus",
    description:
      "How VoltHaus collects, uses, and protects your personal information.",
  },
  robots: { index: true, follow: true },
};

export default function PrivacyPolicyPage() {
  const policy = getPolicyBySlug(SLUG);
  if (!policy) notFound();
  return <PolicyLayout policy={policy} />;
}
