import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { RecentlyViewedPage } from "@/components/ecommerce/recently-viewed-page";

export const metadata: Metadata = {
  title: "Recently Viewed",
  description: "Pick up where you left off — your recently viewed VoltHaus products.",
  alternates: { canonical: "https://volthaus.co/recently-viewed" },
  robots: { index: false, follow: false },
};

export default function RecentlyViewedRoute() {
  return (
    <SiteShell>
      <RecentlyViewedPage />
    </SiteShell>
  );
}
