import type { Metadata } from "next";
import { AuthLayout } from "@/components/auth/auth-layout";
import { ResetPasswordForm } from "@/components/auth/reset-password-form";

export const metadata: Metadata = {
  title: "Reset Password",
  description:
    "Choose a new password for your VoltHaus account using the secure reset link from your email.",
  robots: { index: false, follow: false },
};

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>;
}) {
  const params = await searchParams;
  const token = params.token ? params.token : null;

  return (
    <AuthLayout
      eyebrow="Password recovery"
      title="Reset your password"
      description="Choose a strong new password to regain access to your VoltHaus account."
    >
      <ResetPasswordForm token={token} />
    </AuthLayout>
  );
}
