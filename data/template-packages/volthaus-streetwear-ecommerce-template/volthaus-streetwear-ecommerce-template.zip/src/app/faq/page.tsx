import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { FaqPage } from "@/components/content/faq-page";
import { faqs } from "@/data/faqs";

export const metadata: Metadata = {
  title: "FAQ",
  description:
    "VoltHaus FAQ — answers across orders, shipping, returns, payments, products, account, and drops. Searchable and filterable.",
  alternates: { canonical: "https://volthaus.co/faq" },
  openGraph: {
    title: "FAQ | VoltHaus",
    description:
      "Answers across orders, shipping, returns, payments, products, account, and drops.",
    url: "https://volthaus.co/faq",
  },
};

export default function FaqRoute() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "FAQ" }]} className="mb-6" />
        <ScrollReveal>
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            Help & info
          </p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">
            Frequently asked{" "}
            <span className="text-gradient-primary">questions</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            {faqs.length} answers across orders, shipping, returns, payments,
            products, account, and drops. Search the full catalog or filter by
            category.
          </p>
        </ScrollReveal>
        <div className="mt-10">
          <FaqPage />
        </div>
      </div>
    </SiteShell>
  );
}
