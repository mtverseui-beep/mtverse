import type { Metadata } from "next";
import Link from "next/link";
import { Ruler, ArrowRight } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { SizeGuideContent } from "@/components/product/size-guide-content";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Size & Fit Guide",
  description:
    "Find your fit across every VoltHaus category. Full size charts, measuring tips, and fit advice for sneakers, hoodies, tees, and cargo.",
  alternates: { canonical: "https://volthaus.co/size-guide" },
};

const FIT_TIPS = [
  {
    title: "Measure at the end of the day",
    body: "Feet swell slightly throughout the day. Measuring in the evening gives the most accurate sneaker size.",
  },
  {
    title: "Wear your typical socks",
    body: "When measuring for sneakers, wear the socks you plan to pair them with. Thick socks can add a half size.",
  },
  {
    title: "Size up for relaxed fits",
    body: "Our hoodies and tees run true to size for a regular fit. Size up one for an oversized look, size down for fitted.",
  },
  {
    title: "Check the inseam",
    body: "Cargo pants come in 30-inch and 32-inch inseams. Measure from your inner ankle to your waist seam for the right length.",
  },
];

export default function SizeGuidePage() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Size guide" },
          ]}
          className="mb-6"
        />

        <div className="mb-12 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/30 text-primary text-xs font-mono uppercase tracking-wider mb-4">
            <Ruler className="h-3.5 w-3.5" />
            Fit guide
          </div>
          <h1 className="text-4xl font-black tracking-tight sm:text-5xl mb-3">
            Size & <span className="text-gradient-primary">Fit Guide</span>
          </h1>
          <p className="text-base text-muted-foreground">
            Find your fit across every VoltHaus category. Use the charts below, then read our measuring tips to dial in the right size. If you're between sizes, size up for relaxed fits and size down for fitted looks.
          </p>
        </div>

        <SizeGuideContent />

        {/* Fit tips */}
        <div className="mt-16">
          <SectionHeading
            eyebrow="Pro tips"
            title="Get the right fit, every time"
            align="center"
            className="mb-8"
          />
          <div className="grid sm:grid-cols-2 gap-4">
            {FIT_TIPS.map((tip) => (
              <div
                key={tip.title}
                className="rounded-2xl border border-border bg-card p-5"
              >
                <h3 className="text-sm font-bold mb-2">{tip.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {tip.body}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Contact CTA */}
        <div className="mt-16 rounded-3xl border border-primary/30 bg-primary/5 p-8 sm:p-12 text-center">
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight mb-2">
            Still not sure about your size?
          </h2>
          <p className="text-sm text-muted-foreground mb-6 max-w-md mx-auto">
            Our team will help you find the right fit within 24 hours. Reach out and we'll get you sorted.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="btn-shine">
              <Link href="/contact">
                Contact support
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/help">Browse help center</Link>
            </Button>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
