import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, CalendarDays } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { ScrollReveal } from "@/components/motion";
import { campaigns } from "@/data/campaigns";

export const metadata: Metadata = {
  title: "Campaigns",
  description:
    "Every VoltHaus campaign in one place — After Dark FW26, Neon Court SS26, Chrome District FW26, and Signal Drop FW26. Editorial films, gallery frames, and shoppable looks.",
  alternates: { canonical: "https://volthaus.co/campaigns" },
  openGraph: {
    title: "Campaigns | VoltHaus",
    description:
      "Every VoltHaus campaign — editorial films, gallery frames, and shoppable looks.",
    url: "https://volthaus.co/campaigns",
  },
};

export default function CampaignsPage() {
  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Breadcrumbs items={[{ label: "Campaigns" }]} className="mb-6" />
        <ScrollReveal>
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            Visual archive
          </p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">
            VoltHaus{" "}
            <span className="text-gradient-primary">campaigns</span>
          </h1>
          <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Every seasonal campaign we have shipped, with the editorial film,
            gallery frames, and shoppable product list for each. Shot across
            Milan, Berlin, Lisbon, and Tokyo.
          </p>
        </ScrollReveal>

        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          {campaigns.map((c, i) => {
            const published = new Date(c.publishedAt);
            return (
              <ScrollReveal
                key={c.id}
                delay={i * 0.08}
                className={
                  i === 0 || i === 1 ? "" : "lg:col-span-1"
                }
              >
                <Link
                  href={`/campaigns/${c.slug}`}
                  className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card transition-colors hover:border-primary/40"
                >
                  <div className="relative aspect-[16/10] overflow-hidden bg-muted">
                    <Image
                      src={c.cover}
                      alt={c.name}
                      fill
                      sizes="(min-width: 1024px) 50vw, 100vw"
                      className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                      priority={i < 2}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent" />
                    <div className="absolute left-4 top-4 flex items-center gap-2">
                      <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary">
                        {c.season}
                      </span>
                      <span className="inline-flex items-center gap-1 rounded-full border border-border bg-background/70 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-muted-foreground backdrop-blur">
                        <CalendarDays className="h-3 w-3" aria-hidden />
                        {published.toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                          year: "numeric",
                        })}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-1 flex-col p-6 sm:p-8">
                    <h2 className="text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                      {c.name}
                    </h2>
                    <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
                      {c.description}
                    </p>
                    <div className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary">
                      View campaign
                      <ArrowRight
                        className="h-4 w-4 transition-transform group-hover:translate-x-1"
                        aria-hidden
                      />
                    </div>
                  </div>
                </Link>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </SiteShell>
  );
}
