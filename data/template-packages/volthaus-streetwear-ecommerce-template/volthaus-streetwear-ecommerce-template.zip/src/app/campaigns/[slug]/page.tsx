import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs } from "@/components/common";
import { CampaignDetail } from "@/components/content/campaign-detail";
import { campaigns } from "@/data/campaigns";
import { getProductBySlug } from "@/data/products";

type Params = { slug: string };

export function generateStaticParams(): Params[] {
  return campaigns.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const campaign = campaigns.find((c) => c.slug === slug);
  if (!campaign) return { title: "Campaign Not Found" };
  const url = `https://volthaus.co/campaigns/${campaign.slug}`;
  return {
    title: `${campaign.name} — ${campaign.season} Campaign`,
    description: campaign.description,
    alternates: { canonical: url },
    openGraph: {
      title: `${campaign.name} | VoltHaus Campaigns`,
      description: campaign.description,
      url,
      images: [
        {
          url: campaign.cover,
          width: 1200,
          height: 630,
          alt: campaign.name,
        },
      ],
    },
  };
}

export default async function CampaignDetailRoute({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const campaign = campaigns.find((c) => c.slug === slug);
  if (!campaign) notFound();

  const lookProducts = campaign.lookProductSlugs
    .map((s) => getProductBySlug(s))
    .filter((p): p is NonNullable<ReturnType<typeof getProductBySlug>> =>
      Boolean(p)
    );

  const relatedCampaigns = campaigns
    .filter((c) => c.slug !== campaign.slug)
    .slice(0, 3);

  return (
    <SiteShell>
      <div className="container mx-auto max-w-7xl px-4 pt-6 sm:px-6 lg:px-8">
        <Breadcrumbs
          items={[
            { label: "Campaigns", href: "/campaigns" },
            { label: campaign.name },
          ]}
          className="mb-2"
        />
        <Link
          href="/campaigns"
          className="inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden />
          Back to all campaigns
        </Link>
      </div>
      <CampaignDetail
        campaign={campaign}
        lookProducts={lookProducts}
        relatedCampaigns={relatedCampaigns}
      />
    </SiteShell>
  );
}
