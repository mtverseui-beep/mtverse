import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPolicyBySlug } from "@/data/policies";
import { PolicyLayout } from "@/components/content/policy-layout";

const SLUG = "returns-policy";
const siteUrl = "https://volthaus.co";
const canonicalUrl = `${siteUrl}/returns-policy`;

export const metadata: Metadata = {
  title: "Returns Policy",
  description:
    "How to return VoltHaus products, what condition they need to be in, and how long you have to start a return. Most items have a 30-day window.",
  alternates: { canonical: canonicalUrl },
  openGraph: {
    title: "Returns Policy | VoltHaus",
    description:
      "How to return VoltHaus products, what condition they need to be in, and how long you have to start a return.",
    url: canonicalUrl,
    type: "article",
  },
  twitter: {
    card: "summary_large_image",
    title: "Returns Policy | VoltHaus",
    description:
      "How to return VoltHaus products, what condition they need to be in, and the return window.",
  },
  robots: { index: true, follow: true },
};

export default function ReturnsPolicyPage() {
  const policy = getPolicyBySlug(SLUG);
  if (!policy) notFound();
  return <PolicyLayout policy={policy} />;
}
