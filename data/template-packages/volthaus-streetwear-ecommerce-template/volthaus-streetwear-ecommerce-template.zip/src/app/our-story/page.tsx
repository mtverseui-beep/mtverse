import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Quote, Sparkles } from "lucide-react";
import { SiteShell } from "@/components/layout";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { MagneticButton, ScrollReveal } from "@/components/motion";

export const metadata: Metadata = {
  title: "Our Story",
  description:
    "The origin of VoltHaus, our design philosophy, why drop culture works, and the founders behind the studio. A long-form look at how the brand was built.",
  alternates: { canonical: "https://volthaus.co/our-story" },
  openGraph: {
    title: "Our Story | VoltHaus",
    description:
      "The origin of VoltHaus, our design philosophy, and the founders behind the studio.",
    url: "https://volthaus.co/our-story",
  },
};

const PRINCIPLES = [
  {
    label: "Limited",
    title: "A single numbered run",
    body: "Every VoltHaus piece is produced once. When a drop sells through, it sells through. The Archive Reissue program occasionally brings back revised versions, but never identical reproductions. The goal is to honor the people who showed up at the drop, not to chase a continuous revenue line.",
  },
  {
    label: "Considered",
    title: "Decisions, not assumptions",
    body: "Every silhouette is wear-tested for at least six weeks before it ships. Every fabric is sourced from a documented mill with a known wear life. Every detail — a cuff, a patch, a drawcord tip — is documented in a printed zine that ships with the product. We assume the wearer wants to know.",
  },
  {
    label: "Connected",
    title: "Built with creators, not for them",
    body: "Every capsule starts with a creator on our roster. The creator sets the thesis, the design team builds the patterns, and the documentation ships with the product. There is no committee styling, no focus-grouped color logic, and no marketing-driven silhouette changes.",
  },
];

const FOUNDERS = [
  {
    name: "Anouk Verheyen",
    role: "Co-founder, Creative Director",
    quote:
      "We started VoltHaus because we could not find clothes that were both considered and current. Everything was either beautifully made and ten years behind, or current and built to last a season. We wanted the third option.",
    avatar:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80&auto=format&fit=crop",
  },
  {
    name: "Theo Marchetti",
    role: "Co-founder, Head of Production",
    quote:
      "The pattern room is where VoltHaus actually lives. The rest is just the surface. If we get the shoulder right and the fabric right, the marketing writes itself.",
    avatar:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&q=80&auto=format&fit=crop",
  },
  {
    name: "Idris Achebe",
    role: "Co-founder, Head of Community",
    quote:
      "Drop culture works when the community believes the next release will be worth showing up for. Our job is to keep earning that belief, one capsule at a time, without scaling the program past the point where it stops meaning something.",
    avatar:
      "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=400&q=80&auto=format&fit=crop",
  },
];

const PROCESS_IMAGES = [
  {
    src: "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=1200&q=80&auto=format&fit=crop",
    alt: "Pattern cutter working on a hoodie block in the Lisbon studio",
    caption: "Lisbon pattern room",
  },
  {
    src: "https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?w=1200&q=80&auto=format&fit=crop",
    alt: "Ripstop fabric rolls on the workshop shelf",
    caption: "Osaka ripstop workshop",
  },
  {
    src: "https://images.unsplash.com/photo-1551232864-3f0890e580d9?w=1200&q=80&auto=format&fit=crop",
    alt: "Editorial test shot from the After Dark campaign",
    caption: "After Dark wear-test shoot",
  },
  {
    src: "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1200&q=80&auto=format&fit=crop",
    alt: "Detail shot of the Creator Capsule hoodie cuff",
    caption: "Creator Capsule cuff detail",
  },
];

export default function OurStoryPage() {
  return (
    <SiteShell>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0">
          <Image
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1800&q=80&auto=format&fit=crop"
            alt="VoltHaus founders in the Berlin studio"
            fill
            priority
            sizes="100vw"
            className="object-cover opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/40" />
          <div
            aria-hidden
            className="absolute -right-32 top-1/4 h-80 w-80 rounded-full bg-primary/15 blur-3xl"
          />
        </div>
        <div className="relative container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-28">
          <Breadcrumbs items={[{ label: "Our story" }]} className="mb-8" />
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            Origin
          </p>
          <h1 className="mt-3 max-w-4xl text-balance text-4xl font-black leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            How VoltHaus{" "}
            <span className="text-gradient-primary">became VoltHaus</span>
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            VoltHaus began in 2023 in a one-room Berlin studio with three
            people, a single sewing machine, and a sample run of fifty
            hoodies. The first drop sold through in nine minutes. Everything
            since has been a slow, deliberate attempt to scale the studio
            without losing what made those fifty hoodies mean something.
          </p>
        </div>
      </section>

      {/* Origin story long-form */}
      <section className="container mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <ScrollReveal>
          <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
            The origin
          </p>
          <h2 className="mt-3 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
            Three friends, one sewing machine
          </h2>
          <div className="mt-6 space-y-5 text-base leading-relaxed text-muted-foreground">
            <p>
              Anouk, Theo, and Idris met on a night-shoot set in Berlin in
              2021. Anouk was styling, Theo was running pattern for a small
              production house, and Idris was photographing the cast. None of
              them were happy with the clothes on the rack. The styling was
              current but the build was throwaway, and the build that was not
              throwaway was styling ten years behind. They started trading
              notes after wrap.
            </p>
            <p>
              By the end of 2022 they had a pattern for a heavyweight hoodie
              they actually believed in, a small run of fabric from a Portuguese
              mill, and a name. VoltHaus shipped as a private link to a Slack
              channel of two hundred people in February 2023. The run sold
              through in nine minutes. The Slack kept buzzing for weeks.
            </p>
            <p>
              The three of them quit their day jobs in the spring of 2023 and
              signed a lease on a small studio space in Kreuzberg. The first
              official drop, Signal Drop 01, went live that summer with a run
              of five hundred hoodies. The waitlist crossed ten thousand the
              same afternoon and the Static Club tier was born out of the need
              to give the people who had been there from day one a real
              advantage in the queue.
            </p>
          </div>
        </ScrollReveal>
      </section>

      {/* Design philosophy */}
      <section className="relative overflow-hidden border-y border-border bg-card/40">
        <div className="absolute inset-0 grid-bg opacity-20" aria-hidden />
        <div className="relative container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <SectionHeading
            eyebrow="Design philosophy"
            title={
              <>
                Limited, Considered,{" "}
                <span className="text-gradient-primary">Connected</span>
              </>
            }
            description="Three principles that govern every decision from the pattern room to the drop calendar. When in doubt, we run the decision through all three."
            className="mb-12 max-w-3xl"
          />
          <div className="grid gap-6 lg:grid-cols-3">
            {PRINCIPLES.map((p, i) => (
              <ScrollReveal key={p.label} delay={i * 0.1}>
                <article className="flex h-full flex-col rounded-2xl border border-border bg-background/60 p-6 lg:p-8">
                  <span className="font-mono text-xs uppercase tracking-[0.24em] text-primary">
                    Principle {i + 1}
                  </span>
                  <h3 className="mt-3 text-2xl font-black tracking-tight text-foreground">
                    {p.label}
                  </h3>
                  <p className="mt-2 text-sm font-medium text-foreground/80">
                    {p.title}
                  </p>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {p.body}
                  </p>
                </article>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Drop culture explanation */}
      <section className="container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
          <ScrollReveal>
            <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
              Drop culture
            </p>
            <h2 className="mt-3 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
              Why we release the way we release
            </h2>
            <div className="mt-6 space-y-5 text-base leading-relaxed text-muted-foreground">
              <p>
                A drop is a single moment in time when a capsule becomes
                available. We do not run continuous inventory on drop items.
                Instead, we announce the drop date in advance, open early
                access for members based on tier, and release the full run at
                the same moment to everyone in the queue.
              </p>
              <p>
                The reason is not artificial scarcity. The reason is that a
                single run lets us commit to fabric, fit, and finish at a
                level continuous production cannot support. The Osaka workshop
                that weaves our ripstop cannot run a continuous program for
                us — they take six weeks per batch and they weave for other
                clients in between. A drop cadence is the only way to access
                that kind of partner.
              </p>
              <p>
                Drop culture also rewards engagement. The people who show up
                at the drop minute get the piece. The people who engage with
                the studio between drops move up in tier and get an earlier
                window. It is not a lottery and it is not a private sale. It
                is a system that returns value to the people who pay
                attention.
              </p>
            </div>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <div className="rounded-2xl border border-border bg-card p-6 lg:p-8">
              <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
                How a drop works
              </p>
              <ol className="mt-5 space-y-4">
                {[
                  {
                    step: "01",
                    title: "Announce",
                    body: "Drop date and time posted to the drop calendar and member email two weeks in advance.",
                  },
                  {
                    step: "02",
                    title: "Early access",
                    body: "Members get a tier-based head start: Signal 1 minute, Pulse 3 minutes, Static 15 minutes.",
                  },
                  {
                    step: "03",
                    title: "Public release",
                    body: "The full run opens to the public at the posted drop minute. Cart holds inventory for 10 minutes.",
                  },
                  {
                    step: "04",
                    title: "Sell-through or archive",
                    body: "If the run sells, it ships. If it sits, we debrief and decide whether the silhouette needs a second pass.",
                  },
                ].map((s) => (
                  <li key={s.step} className="flex gap-4">
                    <span className="font-mono text-lg font-black text-primary">
                      {s.step}
                    </span>
                    <div>
                      <p className="text-sm font-bold text-foreground">
                        {s.title}
                      </p>
                      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                        {s.body}
                      </p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Founder quotes */}
      <section className="relative overflow-hidden border-y border-border bg-card/40">
        <div className="absolute inset-0 grid-bg opacity-20" aria-hidden />
        <div className="relative container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <SectionHeading
            eyebrow="The founders"
            title={
              <>
                What the founders{" "}
                <span className="text-gradient-primary">actually said</span>
              </>
            }
            description="VoltHaus was started by three people who still run the studio. These are the quotes we keep on the wall."
            className="mb-12 max-w-3xl"
          />
          <div className="grid gap-6 lg:grid-cols-3">
            {FOUNDERS.map((f, i) => (
              <ScrollReveal key={f.name} delay={i * 0.1}>
                <figure className="flex h-full flex-col rounded-2xl border border-border bg-background/60 p-6 lg:p-8">
                  <Quote
                    className="h-8 w-8 text-primary/40"
                    aria-hidden
                  />
                  <blockquote className="mt-4 flex-1 text-base leading-relaxed text-foreground/90">
                    {f.quote}
                  </blockquote>
                  <figcaption className="mt-6 flex items-center gap-3 border-t border-border pt-4">
                    <Image
                      src={f.avatar}
                      alt={f.name}
                      width={40}
                      height={40}
                      className="h-10 w-10 rounded-full border border-border object-cover"
                    />
                    <div>
                      <p className="text-sm font-bold text-foreground">
                        {f.name}
                      </p>
                      <p className="text-xs text-muted-foreground">{f.role}</p>
                    </div>
                  </figcaption>
                </figure>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Behind-the-design visual section */}
      <section className="container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <SectionHeading
          eyebrow="Behind the design"
          title={
            <>
              Four rooms where the{" "}
              <span className="text-gradient-primary">work happens</span>
            </>
          }
          description="A look inside the physical spaces that produce a VoltHaus capsule — from the pattern room in Lisbon to the ripstop workshop in Osaka."
          className="mb-10 max-w-3xl"
        />
        <div className="grid gap-4 sm:grid-cols-2">
          {PROCESS_IMAGES.map((img, i) => (
            <ScrollReveal key={img.caption} delay={i * 0.06}>
              <figure className="group relative overflow-hidden rounded-2xl border border-border bg-card">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <Image
                    src={img.src}
                    alt={img.alt}
                    fill
                    sizes="(min-width: 640px) 50vw, 100vw"
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
                </div>
                <figcaption className="absolute bottom-3 left-3 right-3 flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-foreground/90">
                  <Sparkles className="h-3.5 w-3.5 text-primary" aria-hidden />
                  {img.caption}
                </figcaption>
              </figure>
            </ScrollReveal>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8 lg:pb-24">
        <ScrollReveal>
          <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-8 sm:p-12 lg:p-16">
            <div
              aria-hidden
              className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-secondary/15 blur-3xl"
            />
            <div className="relative flex flex-col items-start gap-6 lg:flex-row lg:items-center lg:justify-between">
              <div className="max-w-2xl">
                <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
                  The current capsule
                </p>
                <h2 className="mt-3 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
                  See what is shipping right now
                </h2>
                <p className="mt-3 text-base text-muted-foreground">
                  The Signal Drop capsule is live. Members still have an early
                  access window on the next two drops in the calendar. Shop the
                  current run before it sells through.
                </p>
              </div>
              <MagneticButton as="a" href="/shop" variant="primary">
                See the current drop
                <ArrowRight className="h-4 w-4" />
              </MagneticButton>
            </div>
          </div>
        </ScrollReveal>
      </section>
    </SiteShell>
  );
}
