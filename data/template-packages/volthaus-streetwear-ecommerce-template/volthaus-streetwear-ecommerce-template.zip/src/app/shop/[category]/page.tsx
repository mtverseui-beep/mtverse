import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SiteShell } from "@/components/layout";
import { ShopPage } from "@/components/ecommerce/shop-page";
import { CATEGORY_SLUG_MAP } from "@/data/category-slugs";
import { products, getProductsByCategory } from "@/data/products";

const CATEGORY_DESCRIPTIONS: Record<string, string> = {
  sneakers:
    "Every VoltHaus sneaker silhouette in one feed. Limited runs, reactive foam midsoles, and translucent outsoles engineered for the city block.",
  hoodies:
    "Heavyweight fleece programs from the Static Club and Creator Capsule lines. Double-brushed cotton, overlocked seams, tonal silicone patches.",
  "graphic-tees":
    "Graphic tees across Concrete Bloom, Summer Blackout, and Archive Reissue. Hand-drawn art re-rendered for crisp screen prints at scale.",
  "cargo-pants":
    "Utility cargo geometry with reinforced ripstop, welded pocket openings, and matte metal hardware from a single workshop in Osaka.",
  jackets:
    "Outerwear engineered for the second shift. Triple-ripstop shells, bonded seams, merino blends that hold warmth without bulk.",
  caps:
    "Six-panel and five-panel silhouettes from the Signal Drop and Chrome District capsules. Rotating color logic every season.",
  bags:
    "Crossbody and utility silhouettes built around reinforced geometry. Matte hardware, welded openings, tonal grey palettes.",
  accessories:
    "Beanies, socks, and small leather goods that anchor every VoltHaus fit. The details that finish the drop.",
};

export function generateStaticParams() {
  return Object.keys(CATEGORY_SLUG_MAP).map((slug) => ({ category: slug }));
}

export function generateMetadata({
  params,
}: {
  params: Promise<{ category: string }>;
}): Promise<Metadata> {
  return params.then(({ category }) => {
    const categoryName = CATEGORY_SLUG_MAP[category];
    if (!categoryName) {
      return { title: "Category Not Found" };
    }
    const description = CATEGORY_DESCRIPTIONS[category] ?? "";
    return {
      title: categoryName,
      description,
      alternates: {
        canonical: `https://volthaus.co/shop/${category}`,
      },
      openGraph: {
        title: `${categoryName} | VoltHaus`,
        description,
        url: `https://volthaus.co/shop/${category}`,
      },
    } as Metadata;
  });
}

export default async function CategoryRoute({
  params,
}: {
  params: Promise<{ category: string }>;
}) {
  const { category } = await params;
  const categoryName = CATEGORY_SLUG_MAP[category];
  if (!categoryName) {
    notFound();
  }

  const categoryProducts = getProductsByCategory(categoryName);
  const description =
    CATEGORY_DESCRIPTIONS[category] ??
    `Shop the ${categoryName} collection from VoltHaus.`;

  return (
    <SiteShell>
      <ShopPage
        products={products}
        initialCategory={categoryName}
        eyebrow="Category"
        title={categoryName}
        description={description}
        breadcrumbs={[
          { label: "Shop", href: "/shop" },
          { label: categoryName },
        ]}
      />
    </SiteShell>
  );
}
