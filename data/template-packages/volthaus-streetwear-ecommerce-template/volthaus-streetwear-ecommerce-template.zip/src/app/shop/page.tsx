import type { Metadata } from "next";
import { SiteShell } from "@/components/layout";
import { ShopPage, type ShopPageProps } from "@/components/ecommerce/shop-page";
import { products } from "@/data/products";

export const metadata: Metadata = {
  title: "Shop All",
  description:
    "Browse every VoltHaus silhouette, capsule, and accessory in one feed. Filter by category, size, color, and drop status to find your next grail.",
  alternates: { canonical: "https://volthaus.co/shop" },
  openGraph: {
    title: "Shop All Drops | VoltHaus",
    description:
      "Browse every VoltHaus silhouette, capsule, and accessory in one feed.",
    url: "https://volthaus.co/shop",
  },
};

export default function ShopRoute() {
  const breadcrumbs: ShopPageProps["breadcrumbs"] = [{ label: "Shop" }];
  return (
    <SiteShell>
      <ShopPage products={products} breadcrumbs={breadcrumbs} />
    </SiteShell>
  );
}
