"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { WishlistItem } from "@/types";

/**
 * Wishlist store state — persisted items + ephemeral drawer state.
 */
export interface WishlistState {
  // Persisted
  items: WishlistItem[];

  // Ephemeral (NOT persisted)
  isWishlistOpen: boolean;

  addItem: (item: WishlistItem) => void;
  removeItem: (productId: string) => void;
  hasItem: (productId: string) => boolean;
  clear: () => void;

  open: () => void;
  close: () => void;
  toggle: () => void;
}

export const WISHLIST_STORAGE_KEY = "volthaus-wishlist";

export const useWishlistStore = create<WishlistState>()(
  persist(
    (set, get) => ({
      items: [],
      isWishlistOpen: false,

      addItem: (item) =>
        set((state) => {
          if (state.items.some((i) => i.productId === item.productId)) {
            return state;
          }
          return { items: [item, ...state.items] };
        }),

      removeItem: (productId) =>
        set((state) => ({
          items: state.items.filter((i) => i.productId !== productId),
        })),

      hasItem: (productId) =>
        get().items.some((i) => i.productId === productId),

      clear: () => set({ items: [] }),

      open: () => set({ isWishlistOpen: true }),
      close: () => set({ isWishlistOpen: false }),
      toggle: () =>
        set((state) => ({ isWishlistOpen: !state.isWishlistOpen })),
    }),
    {
      name: WISHLIST_STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ items: state.items }),
      version: 1,
    }
  )
);

export default useWishlistStore;
