"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

/**
 * Maximum number of recently-viewed products kept in history.
 */
export const MAX_RECENTLY_VIEWED = 12;

/**
 * A compact product snapshot stored when a user views a PDP.
 */
export interface RecentlyViewedItem {
  productId: string;
  slug: string;
  name: string;
  image: string;
  price: number;
  viewedAt: string;
}

/**
 * Recently-viewed store state.
 */
export interface RecentlyViewedState {
  items: RecentlyViewedItem[];
  addRecent: (item: RecentlyViewedItem) => void;
  clear: () => void;
}

export const RECENTLY_VIEWED_STORAGE_KEY = "volthaus-recently-viewed";

export const useRecentlyViewedStore = create<RecentlyViewedState>()(
  persist(
    (set) => ({
      items: [],

      addRecent: (item) =>
        set((state) => {
          // Drop any existing entry for this product, then prepend the
          // refreshed snapshot. Trim to the configured max length.
          const filtered = state.items.filter(
            (i) => i.productId !== item.productId
          );
          const next = [item, ...filtered].slice(0, MAX_RECENTLY_VIEWED);
          return { items: next };
        }),

      clear: () => set({ items: [] }),
    }),
    {
      name: RECENTLY_VIEWED_STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
      version: 1,
    }
  )
);

export default useRecentlyViewedStore;
