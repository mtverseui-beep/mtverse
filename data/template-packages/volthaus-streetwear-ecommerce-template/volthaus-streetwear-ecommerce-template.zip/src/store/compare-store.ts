"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { CompareItem } from "@/types";

/**
 * Maximum number of products that can be compared side-by-side.
 */
export const MAX_COMPARE_ITEMS = 4;

/**
 * Compare store state — persisted items + ephemeral drawer state.
 */
export interface CompareState {
  // Persisted
  items: CompareItem[];

  // Ephemeral (NOT persisted)
  isCompareOpen: boolean;

  /**
   * Adds a compare item.
   * @returns `false` if the compare tray is already full or the product is
   *   already present, `true` if it was added.
   */
  addItem: (item: CompareItem) => boolean;
  removeItem: (productId: string) => void;
  hasItem: (productId: string) => boolean;
  clear: () => void;

  open: () => void;
  close: () => void;
  toggle: () => void;
}

export const COMPARE_STORAGE_KEY = "volthaus-compare";

export const useCompareStore = create<CompareState>()(
  persist(
    (set, get) => ({
      items: [],
      isCompareOpen: false,

      addItem: (item) => {
        const current = get().items;
        if (current.some((i) => i.productId === item.productId)) return false;
        if (current.length >= MAX_COMPARE_ITEMS) return false;
        set({ items: [...current, item] });
        return true;
      },

      removeItem: (productId) =>
        set((state) => ({
          items: state.items.filter((i) => i.productId !== productId),
        })),

      hasItem: (productId) =>
        get().items.some((i) => i.productId === productId),

      clear: () => set({ items: [] }),

      open: () => set({ isCompareOpen: true }),
      close: () => set({ isCompareOpen: false }),
      toggle: () =>
        set((state) => ({ isCompareOpen: !state.isCompareOpen })),
    }),
    {
      name: COMPARE_STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ items: state.items }),
      version: 1,
    }
  )
);

export default useCompareStore;
