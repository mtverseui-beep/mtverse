"use client";

import { create } from "zustand";
import type { ToastMessage } from "@/types";

/**
 * How long a toast remains on screen before auto-dismissing.
 */
const TOAST_AUTO_DISMISS_MS = 4000;

/**
 * Toast store state. Toasts auto-remove after
 * {@link TOAST_AUTO_DISMISS_MS} milliseconds via `setTimeout` scheduled in
 * `addToast`.
 */
export interface ToastState {
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, "id">) => void;
  removeToast: (id: string) => void;
  clearToasts: () => void;
}

/**
 * Generate a reasonably-unique id without pulling in a uuid dep.
 */
function generateToastId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

/**
 * Tracks pending auto-dismiss timers so `removeToast` can cancel them when a
 * toast is dismissed manually before its timeout fires.
 */
const autoDismissTimers = new Map<string, ReturnType<typeof setTimeout>>();

export const useToastStore = create<ToastState>((set, get) => ({
  toasts: [],

  addToast: (toast) => {
    const id = generateToastId();
    const next: ToastMessage = { ...toast, id };
    set((state) => ({ toasts: [...state.toasts, next] }));

    // Schedule auto-dismiss. Clear any existing timer for this id (defensive).
    if (autoDismissTimers.has(id)) {
      clearTimeout(autoDismissTimers.get(id) as ReturnType<typeof setTimeout>);
    }
    const timer = setTimeout(() => {
      autoDismissTimers.delete(id);
      get().removeToast(id);
    }, TOAST_AUTO_DISMISS_MS);
    autoDismissTimers.set(id, timer);
  },

  removeToast: (id) => {
    const timer = autoDismissTimers.get(id);
    if (timer) {
      clearTimeout(timer);
      autoDismissTimers.delete(id);
    }
    set((state) => ({
      toasts: state.toasts.filter((t) => t.id !== id),
    }));
  },

  clearToasts: () => {
    autoDismissTimers.forEach((timer) => clearTimeout(timer));
    autoDismissTimers.clear();
    set({ toasts: [] });
  },
}));

export default useToastStore;
