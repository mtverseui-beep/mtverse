"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { CartItem } from "@/types";

/**
 * Coupon shape persisted in the cart store.
 */
export interface CartCoupon {
  code: string;
  discountPercent: number;
}

/**
 * Gift card shape persisted in the cart store.
 */
export interface CartGiftCard {
  code: string;
  amount: number;
}

/**
 * Mock coupon codes accepted by `applyCoupon`.
 * `VOLTHAUS10` = 10%, `DROP15` = 15%, `STATIC20` = 20%.
 */
const MOCK_COUPONS: Record<string, number> = {
  VOLTHAUS10: 10,
  DROP15: 15,
  STATIC20: 20,
};

/**
 * Mock gift card codes accepted by `applyGiftCard`.
 * `GIFT50` = $50.
 */
const MOCK_GIFT_CARDS: Record<string, number> = {
  GIFT50: 50,
};

/**
 * Full cart store state — both persisted slices and ephemeral UI state.
 */
export interface CartState {
  // Persisted
  items: CartItem[];
  savedItems: CartItem[];
  coupon: CartCoupon | null;
  giftCard: CartGiftCard | null;
  orderNotes: string;

  // Ephemeral (NOT persisted)
  isCartOpen: boolean;

  // Cart actions
  addItem: (item: CartItem) => void;
  removeItem: (productId: string, size: string, color: string) => void;
  updateQuantity: (
    productId: string,
    size: string,
    color: string,
    quantity: number
  ) => void;
  clearCart: () => void;

  // Selector helpers
  subtotal: () => number;
  itemCount: () => number;

  // Cart drawer UI
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;

  // Save for later
  saveForLater: (productId: string, size: string, color: string) => void;
  moveToCart: (productId: string, size: string, color: string) => void;

  // Coupon
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;

  // Gift card
  applyGiftCard: (code: string) => boolean;
  removeGiftCard: () => void;

  // Notes
  setOrderNotes: (notes: string) => void;
}

/**
 * Key used for localStorage persistence.
 */
export const CART_STORAGE_KEY = "volthaus-cart";

/**
 * Helper to locate a cart line item by its identifying trio.
 */
function findIndex(
  items: CartItem[],
  productId: string,
  size: string,
  color: string
): number {
  return items.findIndex(
    (i) =>
      i.productId === productId && i.size === size && i.color === color
  );
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      // Persisted state
      items: [],
      savedItems: [],
      coupon: null,
      giftCard: null,
      orderNotes: "",

      // Ephemeral state
      isCartOpen: false,

      // ---------------- Cart actions ----------------
      addItem: (item) =>
        set((state) => {
          const idx = findIndex(
            state.items,
            item.productId,
            item.size,
            item.color
          );
          if (idx >= 0) {
            const next = [...state.items];
            next[idx] = {
              ...next[idx],
              quantity: next[idx].quantity + item.quantity,
            };
            return { items: next };
          }
          return { items: [...state.items, item] };
        }),

      removeItem: (productId, size, color) =>
        set((state) => ({
          items: state.items.filter(
            (i) =>
              !(
                i.productId === productId &&
                i.size === size &&
                i.color === color
              )
          ),
        })),

      updateQuantity: (productId, size, color, quantity) =>
        set((state) => {
          if (quantity <= 0) {
            return {
              items: state.items.filter(
                (i) =>
                  !(
                    i.productId === productId &&
                    i.size === size &&
                    i.color === color
                  )
              ),
            };
          }
          return {
            items: state.items.map((i) =>
              i.productId === productId && i.size === size && i.color === color
                ? { ...i, quantity }
                : i
            ),
          };
        }),

      clearCart: () =>
        set({
          items: [],
          savedItems: [],
          coupon: null,
          giftCard: null,
          orderNotes: "",
        }),

      // ---------------- Selector helpers ----------------
      subtotal: () => {
        const { items } = get();
        return items.reduce((sum, i) => sum + i.price * i.quantity, 0);
      },

      itemCount: () => {
        const { items } = get();
        return items.reduce((sum, i) => sum + i.quantity, 0);
      },

      // ---------------- Cart drawer ----------------
      openCart: () => set({ isCartOpen: true }),
      closeCart: () => set({ isCartOpen: false }),
      toggleCart: () => set((s) => ({ isCartOpen: !s.isCartOpen })),

      // ---------------- Save for later ----------------
      saveForLater: (productId, size, color) =>
        set((state) => {
          const idx = findIndex(state.items, productId, size, color);
          if (idx < 0) return state;
          const item = state.items[idx];
          const nextItems = state.items.filter((_, i) => i !== idx);
          // Avoid duplicating saved items
          const savedIdx = findIndex(
            state.savedItems,
            productId,
            size,
            color
          );
          const nextSaved =
            savedIdx >= 0
              ? state.savedItems.map((s, i) =>
                  i === savedIdx ? { ...s, quantity: s.quantity + item.quantity } : s
                )
              : [...state.savedItems, item];
          return { items: nextItems, savedItems: nextSaved };
        }),

      moveToCart: (productId, size, color) =>
        set((state) => {
          const idx = findIndex(state.savedItems, productId, size, color);
          if (idx < 0) return state;
          const item = state.savedItems[idx];
          const nextSaved = state.savedItems.filter((_, i) => i !== idx);
          const cartIdx = findIndex(state.items, productId, size, color);
          const nextItems =
            cartIdx >= 0
              ? state.items.map((c, i) =>
                  i === cartIdx
                    ? { ...c, quantity: c.quantity + item.quantity }
                    : c
                )
              : [...state.items, item];
          return { items: nextItems, savedItems: nextSaved };
        }),

      // ---------------- Coupon ----------------
      applyCoupon: (code) => {
        const normalized = code.trim().toUpperCase();
        const discount = MOCK_COUPONS[normalized];
        if (discount === undefined) return false;
        set({ coupon: { code: normalized, discountPercent: discount } });
        return true;
      },

      removeCoupon: () => set({ coupon: null }),

      // ---------------- Gift card ----------------
      applyGiftCard: (code) => {
        const normalized = code.trim().toUpperCase();
        const amount = MOCK_GIFT_CARDS[normalized];
        if (amount === undefined) return false;
        set({ giftCard: { code: normalized, amount } });
        return true;
      },

      removeGiftCard: () => set({ giftCard: null }),

      // ---------------- Notes ----------------
      setOrderNotes: (notes) => set({ orderNotes: notes }),
    }),
    {
      name: CART_STORAGE_KEY,
      // `createJSONStorage` only invokes the getter on the client, so accessing
      // `localStorage` here is SSR-safe.
      storage: createJSONStorage(() => localStorage),
      // Only persist data slices — never the open/closed drawer state.
      partialize: (state) => ({
        items: state.items,
        savedItems: state.savedItems,
        coupon: state.coupon,
        giftCard: state.giftCard,
        orderNotes: state.orderNotes,
      }),
      version: 1,
    }
  )
);

export default useCartStore;
