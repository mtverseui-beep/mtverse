"use client";

import { create } from "zustand";

/**
 * Maximum number of recent search terms retained.
 */
export const MAX_RECENT_SEARCHES = 8;

/**
 * Trending search terms seeded on the client. These are static suggestions
 * surfaced in the search overlay.
 */
export const DEFAULT_TRENDING_SEARCHES: string[] = [
  "Volt Runner 01",
  "Static Club Hoodie",
  "Neon Court",
  "Signal Drop",
  "Creator Capsule",
];

/**
 * Search store state — session-only (NOT persisted).
 */
export interface SearchState {
  isSearchOpen: boolean;
  query: string;
  recentSearches: string[];
  trendingSearches: string[];

  open: () => void;
  close: () => void;
  toggle: () => void;

  setQuery: (q: string) => void;
  addRecentSearch: (q: string) => void;
}

export const useSearchStore = create<SearchState>((set) => ({
  isSearchOpen: false,
  query: "",
  recentSearches: [],
  trendingSearches: [...DEFAULT_TRENDING_SEARCHES],

  open: () => set({ isSearchOpen: true }),
  close: () => set({ isSearchOpen: false, query: "" }),
  toggle: () => set((s) => ({ isSearchOpen: !s.isSearchOpen })),

  setQuery: (q) => set({ query: q }),

  addRecentSearch: (q) =>
    set((state) => {
      const trimmed = q.trim();
      if (!trimmed) return state;
      const lower = trimmed.toLowerCase();
      const filtered = state.recentSearches.filter(
        (s) => s.toLowerCase() !== lower
      );
      return {
        recentSearches: [trimmed, ...filtered].slice(0, MAX_RECENT_SEARCHES),
      };
    }),
}));

export default useSearchStore;
