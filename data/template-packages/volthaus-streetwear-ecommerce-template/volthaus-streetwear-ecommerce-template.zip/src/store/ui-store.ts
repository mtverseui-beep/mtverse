"use client";

import { create } from "zustand";

/**
 * Centralised ephemeral UI store — drawers, mega menu, modals, banners.
 *
 * None of this state is persisted; it lives only for the current session.
 */
export interface UIState {
  // Mobile menu
  isMobileMenuOpen: boolean;
  openMobileMenu: () => void;
  closeMobileMenu: () => void;
  toggleMobileMenu: () => void;

  // Mega menu (desktop nav hover)
  isMegaMenuOpen: boolean;
  megaMenuSection: string | null;
  openMegaMenu: (section: string) => void;
  closeMegaMenu: () => void;

  // Quick view modal (PDP preview from product cards)
  isQuickViewOpen: boolean;
  quickViewSlug: string | null;
  openQuickView: (slug: string) => void;
  closeQuickView: () => void;

  // Size guide modal
  isSizeGuideOpen: boolean;
  openSizeGuide: () => void;
  closeSizeGuide: () => void;

  // Cookie consent banner
  isCookieBannerOpen: boolean;
  setCookieBanner: (open: boolean) => void;

  // Newsletter modal
  isNewsletterOpen: boolean;
  openNewsletter: () => void;
  closeNewsletter: () => void;

  // Mobile filter drawer (PLP)
  isFilterDrawerOpen: boolean;
  openFilterDrawer: () => void;
  closeFilterDrawer: () => void;
  toggleFilterDrawer: () => void;

  // Scroll-to-top FAB visibility
  goToTopVisible: boolean;
  setGoToTopVisible: (visible: boolean) => void;
}

export const useUIStore = create<UIState>((set) => ({
  // Mobile menu
  isMobileMenuOpen: false,
  openMobileMenu: () => set({ isMobileMenuOpen: true }),
  closeMobileMenu: () => set({ isMobileMenuOpen: false }),
  toggleMobileMenu: () =>
    set((s) => ({ isMobileMenuOpen: !s.isMobileMenuOpen })),

  // Mega menu
  isMegaMenuOpen: false,
  megaMenuSection: null,
  openMegaMenu: (section) =>
    set({ isMegaMenuOpen: true, megaMenuSection: section }),
  closeMegaMenu: () => set({ isMegaMenuOpen: false, megaMenuSection: null }),

  // Quick view
  isQuickViewOpen: false,
  quickViewSlug: null,
  openQuickView: (slug) =>
    set({ isQuickViewOpen: true, quickViewSlug: slug }),
  closeQuickView: () => set({ isQuickViewOpen: false, quickViewSlug: null }),

  // Size guide
  isSizeGuideOpen: false,
  openSizeGuide: () => set({ isSizeGuideOpen: true }),
  closeSizeGuide: () => set({ isSizeGuideOpen: false }),

  // Cookie banner
  isCookieBannerOpen: false,
  setCookieBanner: (open) => set({ isCookieBannerOpen: open }),

  // Newsletter
  isNewsletterOpen: false,
  openNewsletter: () => set({ isNewsletterOpen: true }),
  closeNewsletter: () => set({ isNewsletterOpen: false }),

  // Filter drawer
  isFilterDrawerOpen: false,
  openFilterDrawer: () => set({ isFilterDrawerOpen: true }),
  closeFilterDrawer: () => set({ isFilterDrawerOpen: false }),
  toggleFilterDrawer: () =>
    set((s) => ({ isFilterDrawerOpen: !s.isFilterDrawerOpen })),

  // Go-to-top FAB
  goToTopVisible: false,
  setGoToTopVisible: (visible) => set({ goToTopVisible: visible }),
}));

export default useUIStore;
