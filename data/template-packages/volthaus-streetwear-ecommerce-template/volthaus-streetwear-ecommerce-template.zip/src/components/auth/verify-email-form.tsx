"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  CheckCircle2,
  Loader2,
  Mail,
  RefreshCw,
  Send,
  ShieldAlert,
} from "lucide-react";
import { useToastStore } from "@/store/toast-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export interface VerifyEmailFormProps {
  /** The verification token from the URL. When absent, renders the request
   * verification email form. */
  token: string | null;
}

export function VerifyEmailForm({ token }: VerifyEmailFormProps) {
  const router = useRouter();
  const addToast = useToastStore((s) => s.addToast);
  const [email, setEmail] = React.useState("");
  const [emailError, setEmailError] = React.useState<string | undefined>(undefined);
  const [sending, setSending] = React.useState(false);
  const [sent, setSent] = React.useState(false);
  const [verifyState, setVerifyState] = React.useState<
    "idle" | "loading" | "success" | "error"
  >(token ? "loading" : "idle");

  // Simulate verification when a token is provided.
  React.useEffect(() => {
    if (!token) return;
    setVerifyState("loading");
    const timer = window.setTimeout(() => {
      // Mock verification logic: any non-empty token succeeds.
      setVerifyState("success");
      addToast({
        title: "Email verified",
        description: "Your VoltHaus account is now fully activated.",
        variant: "success",
      });
      const redirect = window.setTimeout(() => {
        router.push("/account");
      }, 1800);
      return () => window.clearTimeout(redirect);
    }, 1400);
    return () => window.clearTimeout(timer);
  }, [token, addToast, router]);

  const handleSendLink = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!trimmed) {
      setEmailError("Email is required.");
      return;
    }
    if (!EMAIL_REGEX.test(trimmed)) {
      setEmailError("Enter a valid email address.");
      return;
    }
    setEmailError(undefined);
    setSending(true);
    window.setTimeout(() => {
      setSending(false);
      setSent(true);
      addToast({
        title: "Verification link sent",
        description: `Check ${trimmed} for your verification link.`,
        variant: "success",
      });
    }, 600);
  };

  // Token-based verification flow.
  if (token) {
    if (verifyState === "loading") {
      return (
        <div className="rounded-xl border border-border bg-card p-8 text-center">
          <span
            aria-hidden
            className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-primary/15 text-primary"
          >
            <Loader2 className="h-7 w-7 animate-spin" />
          </span>
          <h2 className="text-lg font-bold text-foreground">
            Verifying your email…
          </h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            Hang tight — we&apos;re confirming your email address with VoltHaus
            HQ. This usually takes a second.
          </p>
        </div>
      );
    }

    if (verifyState === "success") {
      return (
        <div className="space-y-6">
          <div className="rounded-xl border border-success/40 bg-success/10 p-6 text-center">
            <span
              aria-hidden
              className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-success/20 text-success"
            >
              <CheckCircle2 className="h-7 w-7" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Email verified</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              Your email is confirmed and your VoltHaus account is fully activated.
              Redirecting you to your dashboard…
            </p>
            <div className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
              <span>Redirecting…</span>
            </div>
          </div>
          <Button asChild type="button" className="w-full btn-shine">
            <Link href="/account">Go to dashboard</Link>
          </Button>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-6 text-center">
          <span
            aria-hidden
            className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-destructive/20 text-destructive"
          >
            <ShieldAlert className="h-7 w-7" />
          </span>
          <h2 className="text-lg font-bold text-foreground">
            Verification failed
          </h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            This verification link is invalid or has expired. Verification links
            are valid for 24 hours.
          </p>
        </div>
        <Button asChild type="button" className="w-full btn-shine">
          <Link href="/verify-email">Request a new link</Link>
        </Button>
        <Button asChild type="button" variant="ghost" className="w-full">
          <Link href="/sign-in">
            <ArrowLeft className="h-4 w-4" />
            Back to sign in
          </Link>
        </Button>
      </div>
    );
  }

  // No-token flow: request a verification email.
  if (sent) {
    return (
      <div className="space-y-6">
        <div className="rounded-xl border border-success/40 bg-success/10 p-6 text-center">
          <span
            aria-hidden
            className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-success/20 text-success"
          >
            <CheckCircle2 className="h-7 w-7" />
          </span>
          <h2 className="text-lg font-bold text-foreground">Check your inbox</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            We&apos;ve sent a verification link to{" "}
            <span className="font-semibold text-foreground">{email}</span>. Click
            the link in the email to activate your account.
          </p>
          <p className="mx-auto mt-3 max-w-sm text-xs text-muted-foreground">
            The link expires in 24 hours. Don&apos;t forget to check your spam
            folder.
          </p>
        </div>
        <div className="flex flex-col gap-2">
          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={() => {
              setSent(false);
              setEmail("");
            }}
          >
            <RefreshCw className="h-4 w-4" />
            Use a different email
          </Button>
          <Button asChild type="button" variant="ghost" className="w-full">
            <Link href="/sign-in">
              <ArrowLeft className="h-4 w-4" />
              Back to sign in
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSendLink} className="space-y-4" noValidate>
        <div className="grid gap-2">
          <Label htmlFor="verify-email">Email address</Label>
          <div className="relative">
            <Mail
              aria-hidden
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              id="verify-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              autoComplete="email"
              className="pl-9"
              aria-invalid={Boolean(emailError)}
              aria-describedby={emailError ? "verify-email-error" : undefined}
            />
          </div>
          {emailError && (
            <p id="verify-email-error" className="text-xs text-destructive">
              {emailError}
            </p>
          )}
          <p className="text-xs text-muted-foreground">
            Enter the email tied to your VoltHaus account. We&apos;ll send a
            one-time verification link.
          </p>
        </div>

        <Button
          type="submit"
          disabled={sending}
          className="w-full btn-shine"
          size="lg"
        >
          {sending ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Sending link…
            </>
          ) : (
            <>
              <Send className="h-4 w-4" />
              Send verification link
            </>
          )}
        </Button>
      </form>

      <Button asChild type="button" variant="ghost" className="w-full">
        <Link href="/sign-in">
          <ArrowLeft className="h-4 w-4" />
          Back to sign in
        </Link>
      </Button>

      <p className="text-center text-xs text-muted-foreground">
        Already verified?{" "}
        <Link
          href="/sign-in"
          className="font-semibold text-primary hover:underline"
        >
          Sign in
        </Link>
      </p>
    </div>
  );
}

export default VerifyEmailForm;
