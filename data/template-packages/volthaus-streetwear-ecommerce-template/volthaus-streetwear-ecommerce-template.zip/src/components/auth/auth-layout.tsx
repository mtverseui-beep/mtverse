import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { Logo } from "@/components/layout/logo";

export interface AuthLayoutProps {
  /** Auth form content rendered in the right column */
  children: React.ReactNode;
  /** Optional eyebrow shown above the form (e.g. "Welcome back") */
  eyebrow?: string;
  /** Headline shown above the form */
  title: string;
  /** Supporting description shown above the form */
  description?: string;
}

/**
 * Split-screen layout for auth pages. On md+ the left column shows a brand
 * visual (Unsplash streetwear image + VoltHaus logo + tagline). The right
 * column holds the auth form. On mobile the form is full-screen with a small
 * logo above the eyebrow.
 */
export function AuthLayout({
  children,
  eyebrow,
  title,
  description,
}: AuthLayoutProps) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Brand visual — desktop only */}
      <aside
        aria-hidden
        className="relative hidden overflow-hidden lg:block"
      >
        <Image
          src="https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1600&q=80&auto=format&fit=crop"
          alt=""
          fill
          priority
          sizes="(min-width: 1024px) 50vw, 0px"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-background/40 via-background/30 to-background/80" />
        <div className="absolute inset-0 grid-bg opacity-30" />

        {/* Logo + tagline overlay */}
        <div className="absolute inset-0 flex flex-col justify-between p-10 xl:p-14">
          <Link
            href="/"
            className="inline-flex w-fit items-center gap-2 rounded-md text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            aria-label="VoltHaus home"
          >
            <Logo height={30} />
          </Link>

          <div className="max-w-md">
            <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-primary">
              Static Club · Since 2024
            </p>
            <h2 className="mt-4 text-3xl font-black tracking-tight text-foreground xl:text-4xl">
              Drop the static.
              <br />
              Wear the signal.
            </h2>
            <p className="mt-4 text-sm leading-relaxed text-foreground/70">
              Limited sneakers, creator capsules, and streetwear drops you won't
              find anywhere else. Join the club and get early access to every
              release.
            </p>

            <ul className="mt-8 grid gap-3 text-sm text-foreground/80">
              <li className="flex items-center gap-3">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Member-only drops 24 hours early
              </li>
              <li className="flex items-center gap-3">
                <span className="h-1.5 w-1.5 rounded-full bg-secondary" />
                Earn rewards points on every order
              </li>
              <li className="flex items-center gap-3">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                Free shipping on orders over $100
              </li>
            </ul>
          </div>
        </div>
      </aside>

      {/* Form column */}
      <main className="flex min-h-screen flex-col justify-center bg-background px-4 py-10 sm:px-6 lg:px-12">
        <div className="mx-auto w-full max-w-md">
          {/* Mobile logo */}
          <Link
            href="/"
            className="mb-8 inline-flex w-fit items-center gap-2 rounded-md text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background lg:hidden"
            aria-label="VoltHaus home"
          >
            <Logo height={26} />
          </Link>

          {eyebrow && (
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-primary">
              {eyebrow}
            </p>
          )}
          <h1 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            {title}
          </h1>
          {description && (
            <p className="mt-2 text-sm text-muted-foreground">{description}</p>
          )}

          <div className="mt-8">{children}</div>
        </div>
      </main>
    </div>
  );
}

export default AuthLayout;
