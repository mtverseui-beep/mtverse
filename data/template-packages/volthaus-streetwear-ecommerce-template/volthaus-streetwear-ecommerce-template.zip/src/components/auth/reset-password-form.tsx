"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  Circle,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  ShieldAlert,
} from "lucide-react";
import { useToastStore } from "@/store/toast-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export interface ResetPasswordFormProps {
  /** The reset token from the URL. When missing or empty, the form renders an
   * invalid/expired state. */
  token: string | null;
}

interface FormState {
  password: string;
  confirm: string;
}

interface FormErrors {
  password?: string;
  confirm?: string;
}

interface Requirement {
  id: string;
  label: string;
  test: (value: string) => boolean;
}

const REQUIREMENTS: Requirement[] = [
  { id: "length", label: "At least 8 characters", test: (v) => v.length >= 8 },
  { id: "uppercase", label: "One uppercase letter", test: (v) => /[A-Z]/.test(v) },
  { id: "number", label: "One number", test: (v) => /\d/.test(v) },
  { id: "symbol", label: "One symbol (!@#$%…)", test: (v) => /[^A-Za-z0-9]/.test(v) },
];

export function ResetPasswordForm({ token }: ResetPasswordFormProps) {
  const router = useRouter();
  const addToast = useToastStore((s) => s.addToast);
  const [form, setForm] = React.useState<FormState>({
    password: "",
    confirm: "",
  });
  const [errors, setErrors] = React.useState<FormErrors>({});
  const [showPassword, setShowPassword] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const [success, setSuccess] = React.useState(false);

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  // No token in URL → render invalid/expired state.
  if (!token) {
    return (
      <div className="space-y-6">
        <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-6 text-center">
          <span
            aria-hidden
            className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-destructive/20 text-destructive"
          >
            <ShieldAlert className="h-7 w-7" />
          </span>
          <h2 className="text-lg font-bold text-foreground">
            Invalid or expired link
          </h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            This password reset link is missing, has already been used, or has
            expired. Reset links are valid for 60 minutes.
          </p>
        </div>

        <div className="flex flex-col gap-2">
          <Button asChild type="button" className="w-full btn-shine">
            <Link href="/forgot-password">Request a new link</Link>
          </Button>
          <Button asChild type="button" variant="ghost" className="w-full">
            <Link href="/sign-in">
              <ArrowLeft className="h-4 w-4" />
              Back to sign in
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const next: FormErrors = {};
    if (!form.password) {
      next.password = "Password is required.";
    } else if (!REQUIREMENTS.every((r) => r.test(form.password))) {
      next.password = "Your password doesn't meet all requirements.";
    }
    if (!form.confirm) {
      next.confirm = "Confirm your new password.";
    } else if (form.password !== form.confirm) {
      next.confirm = "Passwords don't match.";
    }
    setErrors(next);
    if (Object.values(next).some(Boolean)) return;

    setSubmitting(true);
    window.setTimeout(() => {
      setSubmitting(false);
      setSuccess(true);
      addToast({
        title: "Password reset",
        description: "You can now sign in with your new password.",
        variant: "success",
      });
      window.setTimeout(() => {
        router.push("/sign-in");
      }, 1500);
    }, 600);
  };

  if (success) {
    return (
      <div className="space-y-6">
        <div className="rounded-xl border border-success/40 bg-success/10 p-6 text-center">
          <span
            aria-hidden
            className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-success/20 text-success"
          >
            <CheckCircle2 className="h-7 w-7" />
          </span>
          <h2 className="text-lg font-bold text-foreground">Password updated</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            Your password has been reset. Redirecting you to the sign-in page…
          </p>
          <div className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
            <span>Redirecting…</span>
          </div>
        </div>
        <Button asChild type="button" variant="ghost" className="w-full">
          <Link href="/sign-in">Back to sign in now</Link>
        </Button>
      </div>
    );
  }

  const metCount = REQUIREMENTS.filter((r) => r.test(form.password)).length;

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <div className="grid gap-2">
          <Label htmlFor="reset-password">New password</Label>
          <div className="relative">
            <Lock
              aria-hidden
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              id="reset-password"
              type={showPassword ? "text" : "password"}
              value={form.password}
              onChange={(e) => update("password", e.target.value)}
              autoComplete="new-password"
              className="pl-9 pr-12"
              aria-invalid={Boolean(errors.password)}
              aria-describedby={
                errors.password ? "reset-password-error" : "reset-password-reqs"
              }
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1.5 text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </button>
          </div>
          {errors.password && (
            <p id="reset-password-error" className="text-xs text-destructive">
              {errors.password}
            </p>
          )}
          <ul
            id="reset-password-reqs"
            className="mt-2 grid gap-1.5 rounded-lg border border-border bg-muted/30 p-3"
            aria-label="Password requirements"
          >
            <li className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              {metCount}/{REQUIREMENTS.length} requirements met
            </li>
            {REQUIREMENTS.map((req) => {
              const met = req.test(form.password);
              return (
                <li
                  key={req.id}
                  className={cn(
                    "flex items-center gap-2 text-xs transition-colors",
                    met ? "text-success" : "text-muted-foreground"
                  )}
                >
                  {met ? (
                    <CheckCircle2 className="h-3.5 w-3.5 shrink-0" aria-hidden />
                  ) : (
                    <Circle className="h-3.5 w-3.5 shrink-0" aria-hidden />
                  )}
                  <span>{req.label}</span>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="reset-confirm">Confirm new password</Label>
          <div className="relative">
            <Lock
              aria-hidden
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              id="reset-confirm"
              type={showConfirm ? "text" : "password"}
              value={form.confirm}
              onChange={(e) => update("confirm", e.target.value)}
              autoComplete="new-password"
              className="pl-9 pr-12"
              aria-invalid={Boolean(errors.confirm)}
              aria-describedby={errors.confirm ? "reset-confirm-error" : undefined}
            />
            <button
              type="button"
              onClick={() => setShowConfirm((s) => !s)}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1.5 text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={showConfirm ? "Hide password" : "Show password"}
            >
              {showConfirm ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </button>
          </div>
          {errors.confirm && (
            <p id="reset-confirm-error" className="text-xs text-destructive">
              {errors.confirm}
            </p>
          )}
        </div>

        <Button
          type="submit"
          disabled={submitting}
          className="w-full btn-shine"
          size="lg"
        >
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Resetting…
            </>
          ) : (
            <>
              <CheckCircle2 className="h-4 w-4" />
              Reset password
            </>
          )}
        </Button>
      </form>

      <div className="flex items-start gap-2 rounded-lg border border-border bg-muted/30 p-3 text-xs text-muted-foreground">
        <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
        <span>
          For your security, this link can only be used once. If you need to
          reset again, request a new link.
        </span>
      </div>

      <Button asChild type="button" variant="ghost" className="w-full">
        <Link href="/sign-in">
          <ArrowLeft className="h-4 w-4" />
          Back to sign in
        </Link>
      </Button>
    </div>
  );
}

export default ResetPasswordForm;
