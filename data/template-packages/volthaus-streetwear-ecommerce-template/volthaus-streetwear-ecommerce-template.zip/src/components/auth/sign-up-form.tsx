"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlertCircle,
  Apple,
  ArrowRight,
  CheckCircle2,
  Chrome,
  Circle,
  Eye,
  EyeOff,
  Gift,
  Loader2,
  Lock,
  Mail,
  Sparkles,
  Truck,
  User,
} from "lucide-react";
import { useToastStore } from "@/store/toast-store";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

interface FormState {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  agree: boolean;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  password?: string;
  agree?: string;
}

interface Requirement {
  id: string;
  label: string;
  test: (value: string) => boolean;
}

const REQUIREMENTS: Requirement[] = [
  { id: "length", label: "At least 8 characters", test: (v) => v.length >= 8 },
  { id: "uppercase", label: "One uppercase letter", test: (v) => /[A-Z]/.test(v) },
  { id: "number", label: "One number", test: (v) => /\d/.test(v) },
  { id: "symbol", label: "One symbol (!@#$%…)", test: (v) => /[^A-Za-z0-9]/.test(v) },
];

const BENEFITS = [
  {
    icon: Sparkles,
    label: "Member-only drops 24 hours early",
  },
  {
    icon: Gift,
    label: "100 bonus points when you join",
  },
  {
    icon: Truck,
    label: "Free shipping on orders over $100",
  },
];

export function SignUpForm() {
  const router = useRouter();
  const addToast = useToastStore((s) => s.addToast);
  const [form, setForm] = React.useState<FormState>({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    agree: false,
  });
  const [errors, setErrors] = React.useState<FormErrors>({});
  const [showPassword, setShowPassword] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const [oauthLoading, setOauthLoading] = React.useState<"apple" | "google" | null>(null);

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const validate = (state: FormState): FormErrors => {
    const next: FormErrors = {};
    if (!state.firstName.trim()) next.firstName = "First name is required.";
    if (!state.lastName.trim()) next.lastName = "Last name is required.";
    if (!state.email.trim()) {
      next.email = "Email is required.";
    } else if (!EMAIL_REGEX.test(state.email)) {
      next.email = "Enter a valid email address.";
    }
    if (!state.password) {
      next.password = "Password is required.";
    } else if (!REQUIREMENTS.every((r) => r.test(state.password))) {
      next.password = "Your password doesn't meet all requirements.";
    }
    if (!state.agree) {
      next.agree = "Please accept the Terms and Privacy Policy to continue.";
    }
    return next;
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validation = validate(form);
    setErrors(validation);
    if (Object.values(validation).some(Boolean)) return;

    setSubmitting(true);
    window.setTimeout(() => {
      setSubmitting(false);
      addToast({
        title: "Welcome to the Static Club",
        description: "Your account is ready. We've added 100 bonus points.",
        variant: "success",
      });
      router.push("/account");
    }, 800);
  };

  const handleOAuth = (provider: "apple" | "google") => {
    setOauthLoading(provider);
    window.setTimeout(() => {
      setOauthLoading(null);
      addToast({
        title: `Signed up with ${provider === "apple" ? "Apple" : "Google"}`,
        description: "Your account is ready.",
        variant: "success",
      });
      router.push("/account");
    }, 700);
  };

  const metCount = REQUIREMENTS.filter((r) => r.test(form.password)).length;

  return (
    <div className="space-y-6">
      {/* Member benefits */}
      <ul className="grid gap-2 rounded-xl border border-border bg-card p-4">
        {BENEFITS.map((benefit) => {
          const Icon = benefit.icon;
          return (
            <li
              key={benefit.label}
              className="flex items-center gap-3 text-sm text-foreground"
            >
              <span
                aria-hidden
                className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary"
              >
                <Icon className="h-3.5 w-3.5" />
              </span>
              {benefit.label}
            </li>
          );
        })}
      </ul>

      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-2">
            <Label htmlFor="signup-first">First name</Label>
            <div className="relative">
              <User
                aria-hidden
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              />
              <Input
                id="signup-first"
                type="text"
                value={form.firstName}
                onChange={(e) => update("firstName", e.target.value)}
                autoComplete="given-name"
                className="pl-9"
                aria-invalid={Boolean(errors.firstName)}
                aria-describedby={errors.firstName ? "signup-first-error" : undefined}
              />
            </div>
            {errors.firstName && (
              <p id="signup-first-error" className="text-xs text-destructive">
                {errors.firstName}
              </p>
            )}
          </div>
          <div className="grid gap-2">
            <Label htmlFor="signup-last">Last name</Label>
            <Input
              id="signup-last"
              type="text"
              value={form.lastName}
              onChange={(e) => update("lastName", e.target.value)}
              autoComplete="family-name"
              aria-invalid={Boolean(errors.lastName)}
              aria-describedby={errors.lastName ? "signup-last-error" : undefined}
            />
            {errors.lastName && (
              <p id="signup-last-error" className="text-xs text-destructive">
                {errors.lastName}
              </p>
            )}
          </div>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="signup-email">Email</Label>
          <div className="relative">
            <Mail
              aria-hidden
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              id="signup-email"
              type="email"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              placeholder="you@example.com"
              autoComplete="email"
              className="pl-9"
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? "signup-email-error" : undefined}
            />
          </div>
          {errors.email && (
            <p id="signup-email-error" className="text-xs text-destructive">
              {errors.email}
            </p>
          )}
        </div>

        <div className="grid gap-2">
          <Label htmlFor="signup-password">Password</Label>
          <div className="relative">
            <Lock
              aria-hidden
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              id="signup-password"
              type={showPassword ? "text" : "password"}
              value={form.password}
              onChange={(e) => update("password", e.target.value)}
              autoComplete="new-password"
              className="pl-9 pr-12"
              aria-invalid={Boolean(errors.password)}
              aria-describedby={errors.password ? "signup-password-error" : "signup-password-reqs"}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1.5 text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </button>
          </div>
          {errors.password && (
            <p id="signup-password-error" className="text-xs text-destructive">
              {errors.password}
            </p>
          )}
          <ul
            id="signup-password-reqs"
            className="mt-2 grid gap-1.5 rounded-lg border border-border bg-muted/30 p-3"
            aria-label="Password requirements"
          >
            <li className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              {metCount}/{REQUIREMENTS.length} requirements met
            </li>
            {REQUIREMENTS.map((req) => {
              const met = req.test(form.password);
              return (
                <li
                  key={req.id}
                  className={cn(
                    "flex items-center gap-2 text-xs transition-colors",
                    met ? "text-success" : "text-muted-foreground"
                  )}
                >
                  {met ? (
                    <CheckCircle2 className="h-3.5 w-3.5 shrink-0" aria-hidden />
                  ) : (
                    <Circle className="h-3.5 w-3.5 shrink-0" aria-hidden />
                  )}
                  <span>{req.label}</span>
                </li>
              );
            })}
          </ul>
        </div>

        <div>
          <label className="flex items-start gap-2 text-sm text-muted-foreground cursor-pointer">
            <Checkbox
              id="signup-agree"
              checked={form.agree}
              onCheckedChange={(checked) => update("agree", checked === true)}
              className="mt-0.5"
              aria-invalid={Boolean(errors.agree)}
              aria-describedby={errors.agree ? "signup-agree-error" : undefined}
            />
            <span>
              I agree to the{" "}
              <Link
                href="/terms"
                className="font-semibold text-foreground underline hover:text-primary"
              >
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link
                href="/privacy"
                className="font-semibold text-foreground underline hover:text-primary"
              >
                Privacy Policy
              </Link>
              .
            </span>
          </label>
          {errors.agree && (
            <p id="signup-agree-error" className="mt-1 text-xs text-destructive">
              {errors.agree}
            </p>
          )}
        </div>

        <Button
          type="submit"
          disabled={submitting}
          className="w-full btn-shine"
          size="lg"
        >
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Creating account…
            </>
          ) : (
            <>
              Create account
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </Button>
      </form>

      <div className="relative">
        <div className="absolute inset-0 flex items-center" aria-hidden>
          <span className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center">
          <span className="bg-background px-3 text-xs uppercase tracking-wider text-muted-foreground">
            or sign up with
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Button
          type="button"
          variant="outline"
          onClick={() => handleOAuth("apple")}
          disabled={submitting || oauthLoading !== null}
        >
          {oauthLoading === "apple" ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Apple className="h-4 w-4" />
          )}
          Apple
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => handleOAuth("google")}
          disabled={submitting || oauthLoading !== null}
        >
          {oauthLoading === "google" ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Chrome className="h-4 w-4" />
          )}
          Google
        </Button>
      </div>

      <p className="text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link
          href="/sign-in"
          className="font-semibold text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
        >
          Sign in
        </Link>
      </p>

      <p className="flex items-center justify-center gap-1.5 text-center text-[11px] text-muted-foreground">
        <AlertCircle className="h-3 w-3" aria-hidden />
        Members under 16 need a guardian&apos;s permission to join.
      </p>
    </div>
  );
}

export default SignUpForm;
