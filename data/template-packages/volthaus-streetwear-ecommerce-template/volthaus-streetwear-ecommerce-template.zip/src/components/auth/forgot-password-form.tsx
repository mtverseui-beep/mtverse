"use client";

import * as React from "react";
import Link from "next/link";
import {
  ArrowLeft,
  CheckCircle2,
  Loader2,
  Mail,
  Send,
} from "lucide-react";
import { useToastStore } from "@/store/toast-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function ForgotPasswordForm() {
  const addToast = useToastStore((s) => s.addToast);
  const [email, setEmail] = React.useState("");
  const [error, setError] = React.useState<string | undefined>(undefined);
  const [submitting, setSubmitting] = React.useState(false);
  const [sent, setSent] = React.useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!trimmed) {
      setError("Email is required.");
      return;
    }
    if (!EMAIL_REGEX.test(trimmed)) {
      setError("Enter a valid email address.");
      return;
    }
    setError(undefined);
    setSubmitting(true);
    window.setTimeout(() => {
      setSubmitting(false);
      setSent(true);
      addToast({
        title: "Reset link sent",
        description: `Check ${trimmed} for instructions.`,
        variant: "success",
      });
    }, 600);
  };

  if (sent) {
    return (
      <div className="space-y-6">
        <div className="rounded-xl border border-success/40 bg-success/10 p-6 text-center">
          <span
            aria-hidden
            className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-success/20 text-success"
          >
            <CheckCircle2 className="h-7 w-7" />
          </span>
          <h2 className="text-lg font-bold text-foreground">Check your inbox</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            If an account exists for{" "}
            <span className="font-semibold text-foreground">{email}</span>, we&apos;ve
            sent a reset link. The link expires in 60 minutes.
          </p>
          <p className="mx-auto mt-3 max-w-sm text-xs text-muted-foreground">
            Didn&apos;t receive the email? Check your spam folder, then try again
            in a few minutes.
          </p>
        </div>

        <div className="flex flex-col gap-2">
          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={() => {
              setSent(false);
              setEmail("");
            }}
          >
            <Send className="h-4 w-4" />
            Try a different email
          </Button>
          <Button asChild type="button" variant="ghost" className="w-full">
            <Link href="/sign-in">
              <ArrowLeft className="h-4 w-4" />
              Back to sign in
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <div className="grid gap-2">
          <Label htmlFor="forgot-email">Email address</Label>
          <div className="relative">
            <Mail
              aria-hidden
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              id="forgot-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              autoComplete="email"
              className="pl-9"
              aria-invalid={Boolean(error)}
              aria-describedby={error ? "forgot-email-error" : undefined}
            />
          </div>
          {error && (
            <p id="forgot-email-error" className="text-xs text-destructive">
              {error}
            </p>
          )}
          <p className="text-xs text-muted-foreground">
            We&apos;ll send a one-time link to reset your password. The link
            expires in 60 minutes.
          </p>
        </div>

        <Button
          type="submit"
          disabled={submitting}
          className="w-full btn-shine"
          size="lg"
        >
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Sending link…
            </>
          ) : (
            <>
              <Send className="h-4 w-4" />
              Send reset link
            </>
          )}
        </Button>
      </form>

      <Button asChild type="button" variant="ghost" className="w-full">
        <Link href="/sign-in">
          <ArrowLeft className="h-4 w-4" />
          Back to sign in
        </Link>
      </Button>

      <p className="text-center text-xs text-muted-foreground">
        Don&apos;t have an account?{" "}
        <Link
          href="/sign-up"
          className="font-semibold text-primary hover:underline"
        >
          Join the Static Club
        </Link>
      </p>
    </div>
  );
}

export default ForgotPasswordForm;
