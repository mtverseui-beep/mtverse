// Account area component barrel.
// Note: rewards-dashboard.tsx predates this task and is re-exported here for
// convenience.

export { AccountSidebar } from "./account-sidebar";
export type { AccountSidebarProps, AccountNavItem } from "./account-sidebar";
export { ACCOUNT_NAV_ITEMS } from "./account-sidebar";

export { AccountLayout } from "./account-layout";
export type { AccountLayoutProps } from "./account-layout";

export { AccountDashboard } from "./account-dashboard";
export { AccountOrders } from "./account-orders";
export { AddressManager } from "./address-manager";
export { PaymentMethodManager } from "./payment-method-manager";
export { NotificationSettings } from "./notification-settings";
export { ProfileForm } from "./profile-form";
export { SecurityForm } from "./security-form";
export { PrintInvoiceButton } from "./print-invoice-button";
export type { PrintInvoiceButtonProps } from "./print-invoice-button";

export { RewardsDashboard } from "./rewards-dashboard";
