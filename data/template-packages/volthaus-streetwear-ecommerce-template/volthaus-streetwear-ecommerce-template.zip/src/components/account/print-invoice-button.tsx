"use client";

import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";

export interface PrintInvoiceButtonProps {
  /** Optional order number to include in the aria-label */
  orderNumber?: string;
}

/**
 * Triggers the browser print dialog. Lives in a "use client" component so we
 * can attach an onClick handler (server components cannot pass event handlers
 * to client components).
 */
export function PrintInvoiceButton({ orderNumber }: PrintInvoiceButtonProps) {
  return (
    <Button
      type="button"
      variant="outline"
      size="sm"
      onClick={() => {
        if (typeof window !== "undefined") window.print();
      }}
      aria-label={orderNumber ? `Print invoice for ${orderNumber}` : "Print invoice"}
    >
      <Printer className="h-4 w-4" />
      Print invoice
    </Button>
  );
}

export default PrintInvoiceButton;
