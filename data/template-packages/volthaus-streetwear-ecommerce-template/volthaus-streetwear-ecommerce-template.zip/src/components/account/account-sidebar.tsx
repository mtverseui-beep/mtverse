"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell,
  CreditCard,
  Heart,
  LayoutDashboard,
  MapPin,
  Package,
  ShieldCheck,
  Sparkles,
  User,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

export interface AccountNavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Optional short label used inside the mobile tab strip */
  shortLabel?: string;
}

export const ACCOUNT_NAV_ITEMS: AccountNavItem[] = [
  { label: "Dashboard", href: "/account", icon: LayoutDashboard, shortLabel: "Home" },
  { label: "Orders", href: "/account/orders", icon: Package },
  { label: "Addresses", href: "/account/addresses", icon: MapPin },
  { label: "Payment methods", href: "/account/payment-methods", icon: CreditCard, shortLabel: "Payment" },
  { label: "Wishlist", href: "/account/wishlist", icon: Heart },
  { label: "Rewards", href: "/account/rewards", icon: Sparkles },
  { label: "Notifications", href: "/account/notifications", icon: Bell, shortLabel: "Alerts" },
  { label: "Profile", href: "/account/profile", icon: User },
  { label: "Security", href: "/account/security", icon: ShieldCheck },
];

export interface AccountSidebarProps {
  /** Optional override of the active route — defaults to current pathname */
  active?: string;
}

/**
 * Account navigation sidebar. On md+ renders as a vertical nav rail. On mobile
 * it collapses into a horizontal scrollable tab strip with the active item
 * highlighted.
 */
export function AccountSidebar({ active }: AccountSidebarProps) {
  const pathname = usePathname();
  const current = active ?? pathname ?? "";

  const isActive = (href: string) => {
    if (href === "/account") return current === "/account";
    return current === href || current.startsWith(`${href}/`);
  };

  return (
    <nav aria-label="Account" className="w-full">
      {/* Desktop vertical rail */}
      <ul className="hidden md:flex md:w-60 md:flex-col md:gap-1">
        {ACCOUNT_NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const activeItem = isActive(item.href);
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                aria-current={activeItem ? "page" : undefined}
                className={cn(
                  "group flex items-center gap-3 rounded-lg border border-transparent px-3 py-2.5 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                  activeItem
                    ? "border-border bg-card text-foreground"
                    : "text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                )}
              >
                <Icon
                  aria-hidden
                  className={cn(
                    "h-4 w-4 shrink-0 transition-colors",
                    activeItem ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                  )}
                />
                <span className="truncate">{item.label}</span>
                {activeItem && (
                  <span
                    aria-hidden
                    className="ml-auto h-1.5 w-1.5 rounded-full bg-primary"
                  />
                )}
              </Link>
            </li>
          );
        })}
      </ul>

      {/* Mobile horizontal tab strip */}
      <ul className="-mx-4 flex gap-1.5 overflow-x-auto px-4 pb-1 md:hidden no-scrollbar">
        {ACCOUNT_NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const activeItem = isActive(item.href);
          return (
            <li key={item.href} className="shrink-0">
              <Link
                href={item.href}
                aria-current={activeItem ? "page" : undefined}
                className={cn(
                  "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-3.5 py-2 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                  activeItem
                    ? "border-primary bg-primary/15 text-primary"
                    : "border-border bg-card text-muted-foreground hover:text-foreground"
                )}
              >
                <Icon aria-hidden className="h-3.5 w-3.5" />
                {item.shortLabel ?? item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export default AccountSidebar;
