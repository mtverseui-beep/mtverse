"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import {
  ArrowRight,
  CreditCard,
  Heart,
  MapPin,
  Package,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { mockCustomer } from "@/data/customers";
import { mockOrders } from "@/data/orders";
import { getBestSellers } from "@/data/products";
import { useWishlistStore } from "@/store/wishlist-store";
import { useMounted } from "@/hooks";
import { AnimatedCounter } from "@/components/motion";
import { ProductCard } from "@/components/product";
import { BadgeVH } from "@/components/common";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const STATUS_COLOR: Record<string, string> = {
  Processing: "bg-warning/15 text-warning border-warning/40",
  Shipped: "bg-primary/15 text-primary border-primary/40",
  Delivered: "bg-success/15 text-success border-success/40",
  Cancelled: "bg-destructive/15 text-destructive border-destructive/40",
  Refunded: "bg-muted text-muted-foreground border-border",
};

const TIER_INFO = {
  Signal: { next: "Pulse" as const, threshold: 1000, color: "var(--vh-primary)" },
  Pulse: { next: "Static" as const, threshold: 5000, color: "var(--vh-secondary)" },
  Static: { next: null, threshold: 0, color: "var(--vh-accent)" },
};

export function AccountDashboard() {
  const mounted = useMounted();
  const wishlistItems = useWishlistStore((s) => s.items);
  const customer = mockCustomer;
  const recentOrders = mockOrders.slice(0, 3);
  const recommended = getBestSellers().slice(0, 4);

  const tierInfo = TIER_INFO[customer.tier];
  const progress = tierInfo.next
    ? Math.min(100, (customer.points / tierInfo.threshold) * 100)
    : 100;
  const pointsToNext = tierInfo.next
    ? Math.max(0, tierInfo.threshold - customer.points)
    : 0;

  interface AccountStat {
    label: string;
    value: number;
    href: string;
    icon: typeof Package;
    accent: string;
    animate?: boolean;
  }

  const stats: AccountStat[] = [
    {
      label: "Total orders",
      value: mockOrders.length,
      href: "/account/orders",
      icon: Package,
      accent: "text-primary",
    },
    {
      label: "Rewards points",
      value: customer.points,
      href: "/account/rewards",
      icon: Sparkles,
      accent: "text-secondary",
      animate: true,
    },
    {
      label: "Wishlist items",
      value: mounted ? wishlistItems.length : 0,
      href: "/account/wishlist",
      icon: Heart,
      accent: "text-accent",
    },
    {
      label: "Saved addresses",
      value: customer.addresses.length,
      href: "/account/addresses",
      icon: MapPin,
      accent: "text-success",
    },
  ];

  const firstName = customer.name.split(" ")[0] ?? customer.name;

  return (
    <div className="space-y-8">
      {/* Welcome header */}
      <section
        aria-labelledby="welcome-heading"
        className="relative overflow-hidden rounded-2xl border border-border bg-card p-6 sm:p-8"
      >
        <div
          aria-hidden
          className="absolute -top-12 -right-12 h-56 w-56 rounded-full bg-primary/20 blur-3xl"
        />
        <div
          aria-hidden
          className="absolute -bottom-16 -left-12 h-56 w-56 rounded-full bg-secondary/15 blur-3xl"
        />
        <div className="relative z-10 flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-full border border-border bg-muted">
              <Image
                src={customer.avatar}
                alt={customer.name}
                fill
                sizes="56px"
                className="object-cover"
              />
            </div>
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-primary">
                Welcome back
              </p>
              <h2
                id="welcome-heading"
                className="text-2xl font-black tracking-tight text-foreground sm:text-3xl"
              >
                {firstName}
              </h2>
              <p className="mt-1 text-xs text-muted-foreground">
                Member since{" "}
                {new Date(customer.memberSince).toLocaleDateString("en-US", {
                  month: "long",
                  year: "numeric",
                })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <BadgeVH variant="Members" label={`${customer.tier} tier`} className="px-3 py-1 text-xs" />
            <div className="rounded-full border border-border bg-background/60 px-4 py-2 text-right">
              <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                Points
              </p>
              <p className="font-mono text-lg font-black text-primary tabular-nums">
                {mounted ? (
                  <AnimatedCounter value={customer.points} duration={1.2} />
                ) : (
                  customer.points
                )}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stat cards */}
      <section aria-label="Account summary">
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Link
                key={stat.label}
                href={stat.href}
                className="group rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background sm:p-5"
              >
                <div className="flex items-center justify-between">
                  <span
                    aria-hidden
                    className={cn(
                      "inline-flex h-9 w-9 items-center justify-center rounded-lg bg-muted/60",
                      stat.accent
                    )}
                  >
                    <Icon className="h-4 w-4" />
                  </span>
                  <ArrowRight
                    aria-hidden
                    className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100"
                  />
                </div>
                <p className="mt-3 text-2xl font-black text-foreground tabular-nums sm:text-3xl">
                  {stat.animate && mounted ? (
                    <AnimatedCounter value={stat.value} duration={1} />
                  ) : (
                    stat.value
                  )}
                </p>
                <p className="mt-0.5 text-xs text-muted-foreground">{stat.label}</p>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Recent orders + tier progress */}
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <section
          aria-labelledby="recent-orders-heading"
          className="rounded-2xl border border-border bg-card p-5 sm:p-6"
        >
          <div className="mb-4 flex items-center justify-between gap-2">
            <h3
              id="recent-orders-heading"
              className="text-base font-bold text-foreground"
            >
              Recent orders
            </h3>
            <Button asChild variant="ghost" size="sm">
              <Link href="/account/orders">
                View all
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </Button>
          </div>
          <ul className="flex flex-col gap-3">
            {recentOrders.map((order) => (
              <li
                key={order.id}
                className="rounded-xl border border-border bg-background/40 p-4 transition-colors hover:border-border/80"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link
                        href={`/account/orders/${order.id}`}
                        className="font-mono text-sm font-bold text-foreground hover:text-primary"
                      >
                        {order.number}
                      </Link>
                      <span
                        className={cn(
                          "inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                          STATUS_COLOR[order.status] ?? STATUS_COLOR.Refunded
                        )}
                      >
                        {order.status}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {new Date(order.date).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}{" "}
                      · {order.items.length}{" "}
                      {order.items.length === 1 ? "item" : "items"}
                    </p>
                  </div>
                  <p className="text-sm font-bold text-foreground tabular-nums">
                    ${order.total.toFixed(2)}
                  </p>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <div className="flex -space-x-2">
                    {order.items.slice(0, 3).map((item) => (
                      <div
                        key={`${order.id}-${item.productId}-${item.size}`}
                        className="relative h-9 w-9 overflow-hidden rounded-full border-2 border-background bg-muted"
                      >
                        <Image
                          src={item.image}
                          alt={item.name}
                          fill
                          sizes="36px"
                          className="object-cover"
                        />
                      </div>
                    ))}
                  </div>
                  <Button
                    asChild
                    size="sm"
                    variant="outline"
                    className="ml-auto"
                  >
                    <Link href={`/account/orders/${order.id}`}>View order</Link>
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </section>

        {/* Tier progress (compact) */}
        <section
          aria-labelledby="tier-heading"
          className="rounded-2xl border border-border bg-card p-5 sm:p-6"
        >
          <div className="mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" aria-hidden />
            <h3 id="tier-heading" className="text-base font-bold text-foreground">
              Tier progress
            </h3>
          </div>
          <div className="space-y-4">
            <div className="flex items-baseline justify-between">
              <div>
                <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                  Current tier
                </p>
                <p className="text-2xl font-black text-foreground">{customer.tier}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                  Points
                </p>
                <p className="font-mono text-xl font-black text-primary tabular-nums">
                  {mounted ? (
                    <AnimatedCounter value={customer.points} duration={1} />
                  ) : (
                    customer.points
                  )}
                </p>
              </div>
            </div>
            <div className="relative h-2.5 rounded-full bg-muted">
              <div
                className="absolute inset-y-0 left-0 rounded-full"
                style={{
                  width: mounted ? `${progress}%` : "0%",
                  background: `linear-gradient(90deg, ${tierInfo.color}, var(--vh-primary))`,
                  transition: "width 1s ease",
                }}
                aria-hidden
              />
            </div>
            <p className="text-xs text-muted-foreground">
              {tierInfo.next
                ? `${pointsToNext.toLocaleString()} points to ${tierInfo.next} tier`
                : "Top tier unlocked"}
            </p>
            <Button asChild variant="outline" size="sm" className="w-full">
              <Link href="/account/rewards">
                <Sparkles className="h-3.5 w-3.5" />
                View rewards
              </Link>
            </Button>
          </div>
        </section>
      </div>

      {/* Recommended products */}
      <section aria-labelledby="recommended-heading">
        <div className="mb-4 flex items-end justify-between gap-2">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-primary">
              Picked for you
            </p>
            <h3
              id="recommended-heading"
              className="mt-1 text-xl font-bold text-foreground sm:text-2xl"
            >
              Recommended drops
            </h3>
          </div>
          <Button asChild variant="ghost" size="sm">
            <Link href="/shop">
              Browse all
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {recommended.map((product, i) => (
            <ProductCard key={product.id} product={product} priority={i < 2} />
          ))}
        </div>
      </section>

      {/* Quick links footer */}
      <section className="grid gap-3 sm:grid-cols-3">
        <Link
          href="/account/payment-methods"
          className="group rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <CreditCard className="h-5 w-5 text-primary" aria-hidden />
          <p className="mt-2 text-sm font-bold text-foreground">Payment methods</p>
          <p className="text-xs text-muted-foreground">Manage saved cards</p>
        </Link>
        <Link
          href="/account/security"
          className="group rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Sparkles className="h-5 w-5 text-secondary" aria-hidden />
          <p className="mt-2 text-sm font-bold text-foreground">Security</p>
          <p className="text-xs text-muted-foreground">Password & sessions</p>
        </Link>
        <Link
          href="/account/notifications"
          className="group rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <Heart className="h-5 w-5 text-accent" aria-hidden />
          <p className="mt-2 text-sm font-bold text-foreground">Notifications</p>
          <p className="text-xs text-muted-foreground">Drop & order alerts</p>
        </Link>
      </section>
    </div>
  );
}

export default AccountDashboard;
