"use client";

import * as React from "react";
import {
  MapPin,
  Pencil,
  Plus,
  Star,
  Trash2,
} from "lucide-react";
import { mockCustomer } from "@/data/customers";
import { useToastStore } from "@/store/toast-store";
import type { Address } from "@/types";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const COUNTRY_OPTIONS = [
  "United States",
  "Canada",
  "United Kingdom",
  "Germany",
  "France",
  "Japan",
  "Australia",
] as const;

interface FormState {
  label: string;
  name: string;
  line1: string;
  line2: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  isDefault: boolean;
}

const EMPTY_FORM: FormState = {
  label: "",
  name: "",
  line1: "",
  line2: "",
  city: "",
  state: "",
  zip: "",
  country: "United States",
  isDefault: false,
};

interface FormErrors {
  label?: string;
  name?: string;
  line1?: string;
  city?: string;
  state?: string;
  zip?: string;
  country?: string;
}

function validate(form: FormState): FormErrors {
  const errors: FormErrors = {};
  if (!form.label.trim()) errors.label = "Label is required (e.g. Home, Studio).";
  if (!form.name.trim()) errors.name = "Recipient name is required.";
  if (!form.line1.trim()) errors.line1 = "Street address is required.";
  if (!form.city.trim()) errors.city = "City is required.";
  if (!form.state.trim()) errors.state = "State or region is required.";
  if (!form.zip.trim()) {
    errors.zip = "Postal code is required.";
  } else if (form.zip.trim().length < 4) {
    errors.zip = "Enter a valid postal code.";
  }
  if (!form.country.trim()) errors.country = "Country is required.";
  return errors;
}

function toForm(address: Address): FormState {
  return {
    label: address.label,
    name: address.name,
    line1: address.line1,
    line2: address.line2 ?? "",
    city: address.city,
    state: address.state,
    zip: address.zip,
    country: address.country,
    isDefault: address.isDefault,
  };
}

function toAddress(form: FormState, id: string): Address {
  return {
    id,
    label: form.label.trim(),
    name: form.name.trim(),
    line1: form.line1.trim(),
    line2: form.line2.trim() || undefined,
    city: form.city.trim(),
    state: form.state.trim(),
    zip: form.zip.trim(),
    country: form.country.trim(),
    isDefault: form.isDefault,
  };
}

export function AddressManager() {
  const addToast = useToastStore((s) => s.addToast);
  const [addresses, setAddresses] = React.useState<Address[]>(mockCustomer.addresses);
  const [modalOpen, setModalOpen] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [form, setForm] = React.useState<FormState>(EMPTY_FORM);
  const [errors, setErrors] = React.useState<FormErrors>({});
  const [submitting, setSubmitting] = React.useState(false);
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const openAdd = () => {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setErrors({});
    setModalOpen(true);
  };

  const openEdit = (address: Address) => {
    setEditingId(address.id);
    setForm(toForm(address));
    setErrors({});
    setModalOpen(true);
  };

  const updateField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validation = validate(form);
    setErrors(validation);
    if (Object.values(validation).some(Boolean)) return;

    setSubmitting(true);
    // Mock async save
    window.setTimeout(() => {
      setAddresses((prev) => {
        let next: Address[];
        if (editingId) {
          next = prev.map((a) => (a.id === editingId ? toAddress(form, editingId) : a));
        } else {
          const newId = `addr-${Date.now()}`;
          next = [...prev, toAddress(form, newId)];
        }
        if (form.isDefault) {
          next = next.map((a) => ({ ...a, isDefault: a.id === (editingId ?? next[next.length - 1].id) }));
        }
        return next;
      });

      addToast({
        title: editingId ? "Address updated" : "Address added",
        description: form.isDefault
          ? `${form.label} is now your default address.`
          : `${form.label} saved to your address book.`,
        variant: "success",
      });
      setSubmitting(false);
      setModalOpen(false);
      setEditingId(null);
      setForm(EMPTY_FORM);
    }, 400);
  };

  const handleSetDefault = (id: string) => {
    setAddresses((prev) => prev.map((a) => ({ ...a, isDefault: a.id === id })));
    const addr = addresses.find((a) => a.id === id);
    addToast({
      title: "Default updated",
      description: addr ? `${addr.label} is now your default address.` : undefined,
      variant: "success",
    });
  };

  const confirmDelete = () => {
    if (!deleteId) return;
    const removed = addresses.find((a) => a.id === deleteId);
    setAddresses((prev) => {
      const filtered = prev.filter((a) => a.id !== deleteId);
      // If we removed the default and there are others, make the first default
      if (removed?.isDefault && filtered.length > 0) {
        filtered[0] = { ...filtered[0], isDefault: true };
      }
      return filtered;
    });
    addToast({
      title: "Address removed",
      description: removed ? `${removed.label} has been deleted.` : undefined,
      variant: "default",
    });
    setDeleteId(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {addresses.length} {addresses.length === 1 ? "address" : "addresses"} saved
        </p>
        <Button type="button" onClick={openAdd} className="btn-shine">
          <Plus className="h-4 w-4" />
          Add new address
        </Button>
      </div>

      {addresses.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card p-10 text-center">
          <MapPin className="mx-auto h-6 w-6 text-muted-foreground" aria-hidden />
          <h3 className="mt-3 text-base font-bold text-foreground">No addresses yet</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Add your shipping address to speed up future checkout.
          </p>
          <Button type="button" onClick={openAdd} className="mt-4 btn-shine">
            <Plus className="h-4 w-4" />
            Add address
          </Button>
        </div>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2">
          {addresses.map((address) => (
            <li
              key={address.id}
              className={cn(
                "relative flex flex-col gap-3 rounded-2xl border border-border bg-card p-5",
                address.isDefault && "border-primary/40 ring-1 ring-primary/20"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span
                    aria-hidden
                    className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15 text-primary"
                  >
                    <MapPin className="h-4 w-4" />
                  </span>
                  <div>
                    <p className="text-sm font-bold text-foreground">{address.label}</p>
                    <p className="text-[11px] uppercase tracking-wider text-muted-foreground">
                      {address.isDefault ? "Default address" : "Saved"}
                    </p>
                  </div>
                </div>
                {address.isDefault && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-primary">
                    <Star className="h-3 w-3" aria-hidden />
                    Default
                  </span>
                )}
              </div>

              <address className="not-italic text-sm leading-relaxed text-foreground">
                <p className="font-semibold">{address.name}</p>
                <p className="text-muted-foreground">{address.line1}</p>
                {address.line2 && (
                  <p className="text-muted-foreground">{address.line2}</p>
                )}
                <p className="text-muted-foreground">
                  {address.city}, {address.state} {address.zip}
                </p>
                <p className="text-muted-foreground">{address.country}</p>
              </address>

              <div className="mt-auto flex flex-wrap gap-2 pt-2">
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => openEdit(address)}
                >
                  <Pencil className="h-3.5 w-3.5" />
                  Edit
                </Button>
                {!address.isDefault && (
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => handleSetDefault(address.id)}
                  >
                    <Star className="h-3.5 w-3.5" />
                    Set as default
                  </Button>
                )}
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="ml-auto text-destructive hover:bg-destructive/10 hover:text-destructive"
                  onClick={() => setDeleteId(address.id)}
                  aria-label={`Delete ${address.label} address`}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Delete
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {/* Add / Edit modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit address" : "Add a new address"}
            </DialogTitle>
            <DialogDescription>
              {editingId
                ? "Update the details for this saved address."
                : "Save a shipping address so checkout is one tap away."}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="grid gap-4" noValidate>
            <div className="grid gap-2">
              <Label htmlFor="addr-label">Label</Label>
              <Input
                id="addr-label"
                value={form.label}
                onChange={(e) => updateField("label", e.target.value)}
                placeholder="Home, Studio, Brooklyn…"
                aria-invalid={Boolean(errors.label)}
                aria-describedby={errors.label ? "addr-label-error" : undefined}
              />
              {errors.label && (
                <p id="addr-label-error" className="text-xs text-destructive">
                  {errors.label}
                </p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="addr-name">Recipient name</Label>
              <Input
                id="addr-name"
                value={form.name}
                onChange={(e) => updateField("name", e.target.value)}
                placeholder="First and last name"
                autoComplete="name"
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? "addr-name-error" : undefined}
              />
              {errors.name && (
                <p id="addr-name-error" className="text-xs text-destructive">
                  {errors.name}
                </p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="addr-line1">Street address</Label>
              <Input
                id="addr-line1"
                value={form.line1}
                onChange={(e) => updateField("line1", e.target.value)}
                placeholder="412 Larkin Street"
                autoComplete="address-line1"
                aria-invalid={Boolean(errors.line1)}
                aria-describedby={errors.line1 ? "addr-line1-error" : undefined}
              />
              {errors.line1 && (
                <p id="addr-line1-error" className="text-xs text-destructive">
                  {errors.line1}
                </p>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="addr-line2">Apartment, suite, etc. (optional)</Label>
              <Input
                id="addr-line2"
                value={form.line2}
                onChange={(e) => updateField("line2", e.target.value)}
                placeholder="Apt 7B"
                autoComplete="address-line2"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="addr-city">City</Label>
                <Input
                  id="addr-city"
                  value={form.city}
                  onChange={(e) => updateField("city", e.target.value)}
                  placeholder="San Francisco"
                  autoComplete="address-level2"
                  aria-invalid={Boolean(errors.city)}
                  aria-describedby={errors.city ? "addr-city-error" : undefined}
                />
                {errors.city && (
                  <p id="addr-city-error" className="text-xs text-destructive">
                    {errors.city}
                  </p>
                )}
              </div>
              <div className="grid gap-2">
                <Label htmlFor="addr-state">State / Region</Label>
                <Input
                  id="addr-state"
                  value={form.state}
                  onChange={(e) => updateField("state", e.target.value)}
                  placeholder="CA"
                  autoComplete="address-level1"
                  aria-invalid={Boolean(errors.state)}
                  aria-describedby={errors.state ? "addr-state-error" : undefined}
                />
                {errors.state && (
                  <p id="addr-state-error" className="text-xs text-destructive">
                    {errors.state}
                  </p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="addr-zip">Postal code</Label>
                <Input
                  id="addr-zip"
                  value={form.zip}
                  onChange={(e) => updateField("zip", e.target.value)}
                  placeholder="94102"
                  autoComplete="postal-code"
                  inputMode="numeric"
                  aria-invalid={Boolean(errors.zip)}
                  aria-describedby={errors.zip ? "addr-zip-error" : undefined}
                />
                {errors.zip && (
                  <p id="addr-zip-error" className="text-xs text-destructive">
                    {errors.zip}
                  </p>
                )}
              </div>
              <div className="grid gap-2">
                <Label htmlFor="addr-country">Country</Label>
                <select
                  id="addr-country"
                  value={form.country}
                  onChange={(e) => updateField("country", e.target.value)}
                  className="h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm shadow-xs outline-none transition-[color,box-shadow] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]"
                  aria-invalid={Boolean(errors.country)}
                >
                  {COUNTRY_OPTIONS.map((country) => (
                    <option key={country} value={country} className="bg-card text-foreground">
                      {country}
                    </option>
                  ))}
                </select>
                {errors.country && (
                  <p className="text-xs text-destructive">{errors.country}</p>
                )}
              </div>
            </div>

            <label className="flex items-start gap-2 rounded-lg border border-border bg-muted/30 p-3 text-sm cursor-pointer">
              <Checkbox
                checked={form.isDefault}
                onCheckedChange={(checked) => updateField("isDefault", checked === true)}
                id="addr-default"
                className="mt-0.5"
              />
              <span>
                <span className="font-semibold text-foreground">Set as default</span>
                <span className="block text-xs text-muted-foreground">
                  Use this address for future orders unless you choose another.
                </span>
              </span>
            </label>

            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setModalOpen(false)}
                disabled={submitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting} className="btn-shine">
                {submitting
                  ? "Saving…"
                  : editingId
                    ? "Save changes"
                    : "Add address"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={Boolean(deleteId)} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this address?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the address from your address book. You can re-add it
              anytime. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete address
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default AddressManager;
