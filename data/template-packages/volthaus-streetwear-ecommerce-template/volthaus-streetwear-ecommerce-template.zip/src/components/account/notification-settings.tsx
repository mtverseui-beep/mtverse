"use client";

import * as React from "react";
import {
  Bell,
  Cake,
  DollarSign,
  Mail,
  PackageCheck,
  Sparkles,
  Star,
  Tag,
} from "lucide-react";
import { useToastStore } from "@/store/toast-store";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

interface NotificationPref {
  id: string;
  title: string;
  description: string;
  icon: typeof Bell;
  channels: ("email" | "sms" | "push")[];
  defaultEnabled: boolean;
}

const PREFERENCES: NotificationPref[] = [
  {
    id: "drop-alerts",
    title: "Drop alerts",
    description:
      "Get notified 15 minutes before every limited drop goes live, plus restock signals for sold-out pieces you've watched.",
    icon: Sparkles,
    channels: ["email", "push"],
    defaultEnabled: true,
  },
  {
    id: "order-updates",
    title: "Order updates",
    description:
      "Shipment confirmations, tracking milestones, and delivery notifications for every VoltHaus order you place.",
    icon: PackageCheck,
    channels: ["email", "sms"],
    defaultEnabled: true,
  },
  {
    id: "member-early-access",
    title: "Member early access",
    description:
      "Be first in line when new collections open — Pulse and Static tier members get a 24-hour head start on every drop.",
    icon: Star,
    channels: ["email", "push"],
    defaultEnabled: true,
  },
  {
    id: "newsletter",
    title: "Static Club newsletter",
    description:
      "Weekly digest of new arrivals, creator capsules, and street culture stories from the VoltHaus editorial team.",
    icon: Mail,
    channels: ["email"],
    defaultEnabled: false,
  },
  {
    id: "birthday-gift",
    title: "Birthday gift",
    description:
      "A member-exclusive birthday reward dropped into your account every year. We'll only use your birthday to send the gift.",
    icon: Cake,
    channels: ["email"],
    defaultEnabled: true,
  },
  {
    id: "price-drop-alerts",
    title: "Price drop alerts",
    description:
      "When an item on your wishlist goes on sale, we'll let you know so you can grab it before the drop sells out.",
    icon: DollarSign,
    channels: ["email", "push"],
    defaultEnabled: false,
  },
  {
    id: "review-requests",
    title: "Review requests",
    description:
      "A gentle nudge to share your thoughts on items you've owned for 30 days. Earn 25 rewards points per published review.",
    icon: Tag,
    channels: ["email"],
    defaultEnabled: true,
  },
];

const CHANNEL_LABEL: Record<"email" | "sms" | "push", string> = {
  email: "Email",
  sms: "SMS",
  push: "Push",
};

export function NotificationSettings() {
  const addToast = useToastStore((s) => s.addToast);
  const [state, setState] = React.useState<Record<string, boolean>>(() =>
    Object.fromEntries(
      PREFERENCES.map((pref) => [pref.id, pref.defaultEnabled])
    )
  );
  const [dirty, setDirty] = React.useState(false);
  const [saving, setSaving] = React.useState(false);

  const toggle = (id: string, value: boolean) => {
    setState((prev) => ({ ...prev, [id]: value }));
    setDirty(true);
  };

  const handleSave = () => {
    setSaving(true);
    window.setTimeout(() => {
      setSaving(false);
      setDirty(false);
      const enabledCount = Object.values(state).filter(Boolean).length;
      addToast({
        title: "Preferences saved",
        description: `${enabledCount} of ${PREFERENCES.length} notifications turned on.`,
        variant: "success",
      });
    }, 400);
  };

  const handleReset = () => {
    setState(
      Object.fromEntries(
        PREFERENCES.map((pref) => [pref.id, pref.defaultEnabled])
      )
    );
    setDirty(false);
    addToast({
      title: "Reset to defaults",
      description: "Your changes have been discarded.",
      variant: "default",
    });
  };

  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-border bg-card p-5 sm:p-6">
        <div className="mb-1 flex items-center gap-2">
          <Bell className="h-4 w-4 text-primary" aria-hidden />
          <h2 className="text-base font-bold text-foreground">Notification channels</h2>
        </div>
        <p className="text-sm text-muted-foreground">
          Choose how VoltHaus reaches you. SMS alerts are reserved for high-priority
          updates like order tracking and drop-start reminders.
        </p>
      </div>

      <ul className="flex flex-col gap-3">
        {PREFERENCES.map((pref) => {
          const Icon = pref.icon;
          const enabled = state[pref.id];
          return (
            <li
              key={pref.id}
              className={cn(
                "rounded-2xl border border-border bg-card p-4 sm:p-5 transition-colors",
                enabled && "border-primary/30"
              )}
            >
              <div className="flex items-start gap-4">
                <span
                  aria-hidden
                  className={cn(
                    "inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                    enabled
                      ? "bg-primary/15 text-primary"
                      : "bg-muted/60 text-muted-foreground"
                  )}
                >
                  <Icon className="h-4 w-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-foreground">{pref.title}</p>
                      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                        {pref.description}
                      </p>
                    </div>
                    <Switch
                      checked={enabled}
                      onCheckedChange={(value) => toggle(pref.id, value)}
                      aria-label={`Toggle ${pref.title}`}
                    />
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {pref.channels.map((channel) => (
                      <span
                        key={`${pref.id}-${channel}`}
                        className={cn(
                          "inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                          enabled
                            ? "border-primary/40 bg-primary/10 text-primary"
                            : "border-border bg-muted/40 text-muted-foreground"
                        )}
                      >
                        {CHANNEL_LABEL[channel]}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-muted/30 p-4">
        <p className="text-xs text-muted-foreground">
          {dirty
            ? "You have unsaved changes."
            : "All changes are saved."}
        </p>
        <div className="flex gap-2">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleReset}
            disabled={saving || !dirty}
          >
            Reset
          </Button>
          <Button
            type="button"
            size="sm"
            onClick={handleSave}
            disabled={saving || !dirty}
            className="btn-shine"
          >
            {saving ? "Saving…" : "Save preferences"}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default NotificationSettings;
