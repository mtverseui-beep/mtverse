"use client";

import * as React from "react";
import {
  CreditCard,
  Pencil,
  Plus,
  ShieldCheck,
  Star,
  Trash2,
  Wallet,
} from "lucide-react";
import { mockCustomer } from "@/data/customers";
import { useToastStore } from "@/store/toast-store";
import type { PaymentMethod } from "@/types";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const BRAND_STYLES: Record<
  PaymentMethod["brand"],
  { gradient: string; text: string; label: string; accent: string }
> = {
  Visa: {
    gradient: "linear-gradient(135deg, #00E5FF 0%, #8B5CF6 100%)",
    text: "#0B0D10",
    label: "VISA",
    accent: "text-primary",
  },
  Mastercard: {
    gradient: "linear-gradient(135deg, #FF2ED1 0%, #8B5CF6 100%)",
    text: "#FFFFFF",
    label: "MC",
    accent: "text-secondary",
  },
  Amex: {
    gradient: "linear-gradient(135deg, #22D3A6 0%, #00E5FF 100%)",
    text: "#0B0D10",
    label: "AMEX",
    accent: "text-success",
  },
  "Apple Pay": {
    gradient: "linear-gradient(135deg, #1A1E26 0%, #0B0D10 100%)",
    text: "#F7F7F8",
    label: "PAY",
    accent: "text-foreground",
  },
};

function detectBrand(cardNumber: string): PaymentMethod["brand"] {
  const cleaned = cardNumber.replace(/\s+/g, "");
  if (/^3[47]/.test(cleaned)) return "Amex";
  if (/^4/.test(cleaned)) return "Visa";
  if (/^5[1-5]/.test(cleaned)) return "Mastercard";
  return "Visa";
}

function formatCardNumber(value: string): string {
  const cleaned = value.replace(/\D/g, "").slice(0, 16);
  return cleaned.replace(/(.{4})/g, "$1 ").trim();
}

function formatExpiry(value: string): string {
  const cleaned = value.replace(/\D/g, "").slice(0, 4);
  if (cleaned.length <= 2) return cleaned;
  return `${cleaned.slice(0, 2)}/${cleaned.slice(2)}`;
}

interface FormState {
  cardNumber: string;
  expiry: string;
  cvc: string;
  nameOnCard: string;
  isDefault: boolean;
}

const EMPTY_FORM: FormState = {
  cardNumber: "",
  expiry: "",
  cvc: "",
  nameOnCard: "",
  isDefault: false,
};

interface FormErrors {
  cardNumber?: string;
  expiry?: string;
  cvc?: string;
  nameOnCard?: string;
}

function validate(form: FormState): FormErrors {
  const errors: FormErrors = {};
  const digits = form.cardNumber.replace(/\D/g, "");
  if (!digits) {
    errors.cardNumber = "Card number is required.";
  } else if (digits.length < 15 || digits.length > 16) {
    errors.cardNumber = "Enter a valid 15 or 16 digit card number.";
  }

  const expiryClean = form.expiry.replace(/\D/g, "");
  if (!expiryClean) {
    errors.expiry = "Expiry is required.";
  } else if (expiryClean.length !== 4) {
    errors.expiry = "Use MM/YY format.";
  } else {
    const month = Number(expiryClean.slice(0, 2));
    if (month < 1 || month > 12) {
      errors.expiry = "Enter a valid month (01–12).";
    }
  }

  if (!form.cvc.trim()) {
    errors.cvc = "CVC is required.";
  } else if (!/^\d{3,4}$/.test(form.cvc.trim())) {
    errors.cvc = "CVC must be 3 or 4 digits.";
  }

  if (!form.nameOnCard.trim()) {
    errors.nameOnCard = "Name on card is required.";
  }

  return errors;
}

function BrandCard({ brand, size = "lg" }: { brand: PaymentMethod["brand"]; size?: "lg" | "sm" }) {
  const style = BRAND_STYLES[brand];
  return (
    <div
      aria-hidden
      className={cn(
        "relative flex shrink-0 items-center justify-center overflow-hidden rounded-lg border border-white/10 font-mono font-black tracking-tight",
        size === "lg" ? "h-10 w-14 text-sm" : "h-8 w-12 text-[11px]"
      )}
      style={{ background: style.gradient, color: style.text }}
    >
      <span>{style.label}</span>
      {brand === "Apple Pay" && (
        <Wallet className="absolute right-1 top-1 h-3 w-3 opacity-80" aria-hidden />
      )}
    </div>
  );
}

export function PaymentMethodManager() {
  const addToast = useToastStore((s) => s.addToast);
  const [methods, setMethods] = React.useState<PaymentMethod[]>(mockCustomer.paymentMethods);
  const [modalOpen, setModalOpen] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [form, setForm] = React.useState<FormState>(EMPTY_FORM);
  const [errors, setErrors] = React.useState<FormErrors>({});
  const [submitting, setSubmitting] = React.useState(false);
  const [deleteId, setDeleteId] = React.useState<string | null>(null);

  const openAdd = () => {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setErrors({});
    setModalOpen(true);
  };

  const openEdit = (method: PaymentMethod) => {
    setEditingId(method.id);
    setForm({
      cardNumber: method.last4 === "Apple Pay" ? "" : `•••• •••• •••• ${method.last4}`,
      expiry: method.expiry === "Apple Pay" ? "" : method.expiry,
      cvc: "",
      nameOnCard: mockCustomer.name,
      isDefault: method.isDefault,
    });
    setErrors({});
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validation = validate(form);
    setErrors(validation);
    if (Object.values(validation).some(Boolean)) return;

    setSubmitting(true);
    window.setTimeout(() => {
      setMethods((prev) => {
        const digits = form.cardNumber.replace(/\D/g, "");
        const last4 = digits.slice(-4);
        const brand = detectBrand(form.cardNumber);

        let next: PaymentMethod[];
        if (editingId) {
          next = prev.map((m) =>
            m.id === editingId
              ? { ...m, last4, expiry: form.expiry, brand, isDefault: form.isDefault }
              : m
          );
        } else {
          const newId = `pm-${Date.now()}`;
          next = [...prev, { id: newId, brand, last4, expiry: form.expiry, isDefault: form.isDefault }];
        }
        if (form.isDefault) {
          const targetId = editingId ?? next[next.length - 1].id;
          next = next.map((m) => ({ ...m, isDefault: m.id === targetId }));
        }
        return next;
      });

      addToast({
        title: editingId ? "Payment method updated" : "Payment method added",
        description: `Your ${detectBrand(form.cardNumber)} card has been ${editingId ? "updated" : "saved"}.`,
        variant: "success",
      });
      setSubmitting(false);
      setModalOpen(false);
      setEditingId(null);
      setForm(EMPTY_FORM);
    }, 400);
  };

  const handleSetDefault = (id: string) => {
    setMethods((prev) => prev.map((m) => ({ ...m, isDefault: m.id === id })));
    const method = methods.find((m) => m.id === id);
    addToast({
      title: "Default updated",
      description: method
        ? `Your ${method.brand} ${method.last4 === "Apple Pay" ? "" : `ending in ${method.last4}`} is now the default.`
        : undefined,
      variant: "success",
    });
  };

  const confirmDelete = () => {
    if (!deleteId) return;
    const removed = methods.find((m) => m.id === deleteId);
    setMethods((prev) => {
      const filtered = prev.filter((m) => m.id !== deleteId);
      if (removed?.isDefault && filtered.length > 0) {
        filtered[0] = { ...filtered[0], isDefault: true };
      }
      return filtered;
    });
    addToast({
      title: "Payment method removed",
      description: removed ? `Your ${removed.brand} has been removed.` : undefined,
      variant: "default",
    });
    setDeleteId(null);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {methods.length} {methods.length === 1 ? "method" : "methods"} on file
        </p>
        <Button type="button" onClick={openAdd} className="btn-shine">
          <Plus className="h-4 w-4" />
          Add payment method
        </Button>
      </div>

      <div className="flex items-center gap-2 rounded-lg border border-border bg-muted/30 p-3 text-xs text-muted-foreground">
        <ShieldCheck className="h-4 w-4 shrink-0 text-success" aria-hidden />
        <span>
          VoltHaus never stores full card numbers or CVCs. All card data is tokenized
          and processed by our PCI-DSS compliant payment partner.
        </span>
      </div>

      {methods.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card p-10 text-center">
          <CreditCard className="mx-auto h-6 w-6 text-muted-foreground" aria-hidden />
          <h3 className="mt-3 text-base font-bold text-foreground">No payment methods</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Add a card to speed up checkout on the next drop.
          </p>
          <Button type="button" onClick={openAdd} className="mt-4 btn-shine">
            <Plus className="h-4 w-4" />
            Add card
          </Button>
        </div>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2">
          {methods.map((method) => (
            <li
              key={method.id}
              className={cn(
                "relative flex flex-col gap-4 rounded-2xl border border-border bg-card p-5",
                method.isDefault && "border-primary/40 ring-1 ring-primary/20"
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <BrandCard brand={method.brand} />
                  <div>
                    <p className="text-sm font-bold text-foreground">
                      {method.brand}
                      {method.last4 !== "Apple Pay" && ` ···· ${method.last4}`}
                    </p>
                    <p className="text-[11px] uppercase tracking-wider text-muted-foreground">
                      {method.last4 === "Apple Pay"
                        ? "Digital wallet"
                        : `Expires ${method.expiry}`}
                    </p>
                  </div>
                </div>
                {method.isDefault && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-primary">
                    <Star className="h-3 w-3" aria-hidden />
                    Default
                  </span>
                )}
              </div>

              <div className="mt-auto flex flex-wrap gap-2 pt-2">
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => openEdit(method)}
                >
                  <Pencil className="h-3.5 w-3.5" />
                  Edit
                </Button>
                {!method.isDefault && (
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => handleSetDefault(method.id)}
                  >
                    <Star className="h-3.5 w-3.5" />
                    Set as default
                  </Button>
                )}
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="ml-auto text-destructive hover:bg-destructive/10 hover:text-destructive"
                  onClick={() => setDeleteId(method.id)}
                  aria-label={`Remove ${method.brand} card`}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Remove
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {/* Add / Edit modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit payment method" : "Add a payment method"}
            </DialogTitle>
            <DialogDescription>
              {editingId
                ? "Update the details for this saved card."
                : "Save a card to your VoltHaus wallet for one-tap checkout."}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="grid gap-4" noValidate>
            <div className="grid gap-2">
              <Label htmlFor="pm-number">Card number</Label>
              <Input
                id="pm-number"
                value={form.cardNumber}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, cardNumber: formatCardNumber(e.target.value) }))
                }
                placeholder="4242 4242 4242 4242"
                inputMode="numeric"
                autoComplete="cc-number"
                aria-invalid={Boolean(errors.cardNumber)}
                aria-describedby={errors.cardNumber ? "pm-number-error" : undefined}
              />
              {errors.cardNumber && (
                <p id="pm-number-error" className="text-xs text-destructive">
                  {errors.cardNumber}
                </p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="pm-expiry">Expiry (MM/YY)</Label>
                <Input
                  id="pm-expiry"
                  value={form.expiry}
                  onChange={(e) =>
                    setForm((prev) => ({ ...prev, expiry: formatExpiry(e.target.value) }))
                  }
                  placeholder="08/27"
                  inputMode="numeric"
                  autoComplete="cc-exp"
                  aria-invalid={Boolean(errors.expiry)}
                  aria-describedby={errors.expiry ? "pm-expiry-error" : undefined}
                />
                {errors.expiry && (
                  <p id="pm-expiry-error" className="text-xs text-destructive">
                    {errors.expiry}
                  </p>
                )}
              </div>
              <div className="grid gap-2">
                <Label htmlFor="pm-cvc">CVC</Label>
                <Input
                  id="pm-cvc"
                  value={form.cvc}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      cvc: e.target.value.replace(/\D/g, "").slice(0, 4),
                    }))
                  }
                  placeholder="123"
                  inputMode="numeric"
                  autoComplete="cc-csc"
                  aria-invalid={Boolean(errors.cvc)}
                  aria-describedby={errors.cvc ? "pm-cvc-error" : undefined}
                />
                {errors.cvc && (
                  <p id="pm-cvc-error" className="text-xs text-destructive">
                    {errors.cvc}
                  </p>
                )}
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="pm-name">Name on card</Label>
              <Input
                id="pm-name"
                value={form.nameOnCard}
                onChange={(e) => setForm((prev) => ({ ...prev, nameOnCard: e.target.value }))}
                placeholder="Alex Whitlock"
                autoComplete="cc-name"
                aria-invalid={Boolean(errors.nameOnCard)}
                aria-describedby={errors.nameOnCard ? "pm-name-error" : undefined}
              />
              {errors.nameOnCard && (
                <p id="pm-name-error" className="text-xs text-destructive">
                  {errors.nameOnCard}
                </p>
              )}
            </div>

            <label className="flex items-start gap-2 rounded-lg border border-border bg-muted/30 p-3 text-sm cursor-pointer">
              <Checkbox
                checked={form.isDefault}
                onCheckedChange={(checked) =>
                  setForm((prev) => ({ ...prev, isDefault: checked === true }))
                }
                id="pm-default"
                className="mt-0.5"
              />
              <span>
                <span className="font-semibold text-foreground">Set as default</span>
                <span className="block text-xs text-muted-foreground">
                  Use this card for future orders unless you choose another.
                </span>
              </span>
            </label>

            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                onClick={() => setModalOpen(false)}
                disabled={submitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting} className="btn-shine">
                {submitting
                  ? "Saving…"
                  : editingId
                    ? "Save changes"
                    : "Add card"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={Boolean(deleteId)} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this payment method?</AlertDialogTitle>
            <AlertDialogDescription>
              This card will no longer appear at checkout. You can re-add it anytime.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Remove card
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default PaymentMethodManager;
