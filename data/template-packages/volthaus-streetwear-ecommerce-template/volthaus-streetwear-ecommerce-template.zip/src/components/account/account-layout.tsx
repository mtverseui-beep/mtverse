import * as React from "react";
import { AccountSidebar } from "@/components/account/account-sidebar";
import { Breadcrumbs } from "@/components/common";
import { cn } from "@/lib/utils";

export interface AccountLayoutProps {
  children: React.ReactNode;
  /** Page title shown in the content header */
  title: string;
  /** Optional supporting description shown beneath the title */
  description?: string;
  /** Optional breadcrumb items (defaults to Account / title) */
  breadcrumbs?: { label: string; href?: string }[];
  /** Optional content rendered on the right side of the header (e.g. CTA) */
  actions?: React.ReactNode;
  className?: string;
}

/**
 * Shared layout for all account sub-pages. Renders the AccountSidebar in a
 * sticky left column on desktop (and a horizontal tab strip on mobile) plus
 * the page title + content area.
 */
export function AccountLayout({
  children,
  title,
  description,
  breadcrumbs,
  actions,
  className,
}: AccountLayoutProps) {
  const trail =
    breadcrumbs && breadcrumbs.length > 0
      ? breadcrumbs
      : [{ label: "Account", href: "/account" }, { label: title }];

  return (
    <div
      className={cn(
        "container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12",
        className
      )}
    >
      <Breadcrumbs items={trail} className="mb-6" />

      <div className="grid gap-8 lg:grid-cols-[15rem_minmax(0,1fr)]">
        {/* Sidebar */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <AccountSidebar />
        </aside>

        {/* Content */}
        <section className="min-w-0">
          <header className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div className="min-w-0">
              <h1 className="text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                {title}
              </h1>
              {description && (
                <p className="mt-1.5 max-w-2xl text-sm text-muted-foreground">
                  {description}
                </p>
              )}
            </div>
            {actions && <div className="flex shrink-0 gap-2">{actions}</div>}
          </header>
          <div className="min-w-0">{children}</div>
        </section>
      </div>
    </div>
  );
}

export default AccountLayout;
