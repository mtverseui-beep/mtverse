"use client";

import { Sparkles, TrendingUp, Crown, Gift } from "lucide-react";
import { mockCustomer } from "@/data/customers";
import { useMounted } from "@/hooks";
import { AnimatedCounter } from "@/components/motion";

const TIER_INFO = {
  Signal: { next: "Pulse", threshold: 1000, color: "var(--vh-primary)", icon: Sparkles },
  Pulse: { next: "Static", threshold: 5000, color: "var(--vh-secondary)", icon: TrendingUp },
  Static: { next: null, threshold: 0, color: "var(--vh-accent)", icon: Crown },
};

export function RewardsDashboard() {
  const mounted = useMounted();
  const customer = mockCustomer;
  const tierInfo = TIER_INFO[customer.tier];
  const TierIcon = tierInfo.icon;
  const progress = tierInfo.next
    ? Math.min(100, (customer.points / tierInfo.threshold) * 100)
    : 100;
  const pointsToNext = tierInfo.next
    ? Math.max(0, tierInfo.threshold - customer.points)
    : 0;

  return (
    <div className="grid lg:grid-cols-[1fr_380px] gap-6">
      {/* Points + tier progress */}
      <div className="rounded-2xl border border-border bg-card p-6 sm:p-8 relative overflow-hidden">
        <div
          className="absolute top-0 right-0 w-64 h-64 rounded-full blur-3xl opacity-30"
          style={{ backgroundColor: tierInfo.color }}
        />
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <span
              className="inline-flex h-12 w-12 items-center justify-center rounded-xl"
              style={{ backgroundColor: `${tierInfo.color}20`, color: tierInfo.color }}
            >
              <TierIcon className="h-6 w-6" />
            </span>
            <div>
              <p className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                Current tier
              </p>
              <p className="text-2xl font-black">{customer.tier}</p>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-baseline justify-between mb-2">
              <p className="text-xs text-muted-foreground">Your points</p>
              {tierInfo.next && (
                <p className="text-xs text-muted-foreground">
                  {pointsToNext} pts to {tierInfo.next}
                </p>
              )}
            </div>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-4xl sm:text-5xl font-black tabular-nums">
                {mounted ? <AnimatedCounter value={customer.points} duration={1.5} /> : customer.points}
              </span>
              <span className="text-sm text-muted-foreground">pts</span>
            </div>

            <div className="relative h-2 rounded-full bg-muted overflow-hidden">
              <div
                className="absolute inset-y-0 left-0 rounded-full transition-all"
                style={{
                  width: mounted ? `${progress}%` : "0%",
                  background: `linear-gradient(90deg, ${tierInfo.color}, var(--vh-primary))`,
                }}
              />
            </div>
            <div className="flex items-center justify-between mt-2 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
              <span>{customer.tier}</span>
              {tierInfo.next ? (
                <span>{tierInfo.next} — {tierInfo.threshold.toLocaleString()} pts</span>
              ) : (
                <span>Top tier unlocked</span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-4 border-t border-border">
            <div>
              <p className="text-xs text-muted-foreground">Member since</p>
              <p className="text-sm font-bold">
                {new Date(customer.memberSince).toLocaleDateString("en-US", { month: "short", year: "numeric" })}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Store credit available</p>
              <p className="text-sm font-bold text-primary">
                ${Math.floor(customer.points / 100).toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="space-y-3">
        <div className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-3 mb-3">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <Gift className="h-4 w-4" />
            </span>
            <div>
              <p className="text-sm font-bold">Redeem for credit</p>
              <p className="text-xs text-muted-foreground">100 pts = $1 store credit</p>
            </div>
          </div>
          <button
            disabled={customer.points < 100}
            className="w-full h-10 rounded-full bg-primary text-primary-foreground font-bold text-xs btn-shine disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {customer.points >= 100
              ? `Redeem $${Math.floor(customer.points / 100)}`
              : "Need 100 pts minimum"}
          </button>
        </div>

        <div className="rounded-2xl border border-border bg-card p-5">
          <p className="text-sm font-bold mb-3">Recent activity</p>
          <ul className="space-y-2 text-xs">
            <li className="flex items-center justify-between">
              <span className="text-muted-foreground">Order VH-100042</span>
              <span className="text-success font-mono">+124 pts</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="text-muted-foreground">Wrote a review</span>
              <span className="text-success font-mono">+25 pts</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="text-muted-foreground">Referred a friend</span>
              <span className="text-success font-mono">+100 pts</span>
            </li>
            <li className="flex items-center justify-between">
              <span className="text-muted-foreground">Redeemed credit</span>
              <span className="text-muted-foreground font-mono">-500 pts</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
