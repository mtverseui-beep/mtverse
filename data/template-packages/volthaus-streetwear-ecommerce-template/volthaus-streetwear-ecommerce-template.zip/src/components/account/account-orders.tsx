"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { PackageSearch, Search } from "lucide-react";
import { mockOrders } from "@/data/orders";
import type { MockOrder } from "@/types";
import { BuyAgainButton } from "@/components/ecommerce";
import { EmptyState } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const STATUS_COLOR: Record<MockOrder["status"], string> = {
  Processing: "bg-warning/15 text-warning border-warning/40",
  Shipped: "bg-primary/15 text-primary border-primary/40",
  Delivered: "bg-success/15 text-success border-success/40",
  Cancelled: "bg-destructive/15 text-destructive border-destructive/40",
  Refunded: "bg-muted text-muted-foreground border-border",
};

type Filter = "All" | MockOrder["status"];

const FILTERS: Filter[] = [
  "All",
  "Processing",
  "Shipped",
  "Delivered",
  "Cancelled",
];

export function AccountOrders() {
  const [filter, setFilter] = React.useState<Filter>("All");
  const [query, setQuery] = React.useState("");

  const filtered = React.useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return mockOrders.filter((order) => {
      const matchesFilter = filter === "All" || order.status === filter;
      const matchesQuery =
        normalized === "" ||
        order.number.toLowerCase().includes(normalized) ||
        order.items.some((item) =>
          item.name.toLowerCase().includes(normalized)
        );
      return matchesFilter && matchesQuery;
    });
  }, [filter, query]);

  const counts = React.useMemo(() => {
    const map: Record<Filter, number> = {
      All: mockOrders.length,
      Processing: 0,
      Shipped: 0,
      Delivered: 0,
      Cancelled: 0,
      Refunded: 0,
    };
    mockOrders.forEach((order) => {
      map[order.status] += 1;
    });
    return map;
  }, []);

  return (
    <div className="space-y-5">
      {/* Search + filter bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full max-w-xs">
          <Search
            aria-hidden
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
          />
          <Input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by order number or item"
            aria-label="Search orders"
            className="pl-9"
          />
        </div>

        <div
          role="tablist"
          aria-label="Filter orders by status"
          className="-mx-4 flex gap-1.5 overflow-x-auto px-4 no-scrollbar sm:mx-0 sm:px-0"
        >
          {FILTERS.map((f) => {
            const isActive = filter === f;
            return (
              <button
                key={f}
                role="tab"
                type="button"
                aria-selected={isActive}
                onClick={() => setFilter(f)}
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3.5 py-2 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                  isActive
                    ? "border-primary bg-primary/15 text-primary"
                    : "border-border bg-card text-muted-foreground hover:text-foreground"
                )}
              >
                {f}
                <span
                  className={cn(
                    "rounded-full px-1.5 py-0.5 text-[10px] font-mono tabular-nums",
                    isActive ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
                  )}
                >
                  {counts[f]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Orders list */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={<PackageSearch className="h-6 w-6" />}
          title="No orders found"
          description="We couldn't find any orders matching this filter or search. Try adjusting your filters or check your order number."
          action={
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setFilter("All");
                setQuery("");
              }}
            >
              Clear filters
            </Button>
          }
          className="rounded-2xl border border-border bg-card"
        />
      ) : (
        <ul className="flex flex-col gap-4">
          {filtered.map((order) => (
            <li
              key={order.id}
              className="rounded-2xl border border-border bg-card p-4 sm:p-6"
            >
              <div className="flex flex-wrap items-start justify-between gap-3 border-b border-border pb-4">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link
                      href={`/account/orders/${order.id}`}
                      className="font-mono text-sm font-bold text-foreground hover:text-primary sm:text-base"
                    >
                      {order.number}
                    </Link>
                    <span
                      className={cn(
                        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                        STATUS_COLOR[order.status]
                      )}
                    >
                      {order.status}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Placed on{" "}
                    {new Date(order.date).toLocaleDateString("en-US", {
                      month: "long",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                    Total
                  </p>
                  <p className="text-base font-black text-foreground tabular-nums">
                    ${order.total.toFixed(2)}
                  </p>
                </div>
              </div>

              {/* Items */}
              <ul className="flex flex-col divide-y divide-border">
                {order.items.map((item) => (
                  <li
                    key={`${order.id}-${item.productId}-${item.size}-${item.color}`}
                    className="flex items-center gap-3 py-3"
                  >
                    <Link
                      href={`/product/${item.slug}`}
                      className="relative h-14 w-14 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                      aria-label={`View ${item.name}`}
                    >
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        sizes="56px"
                        className="object-cover"
                      />
                    </Link>
                    <div className="min-w-0 flex-1">
                      <Link
                        href={`/product/${item.slug}`}
                        className="line-clamp-1 text-sm font-semibold text-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                      <p className="text-xs text-muted-foreground">
                        Size {item.size} · {item.color} · Qty {item.quantity}
                      </p>
                    </div>
                    <p className="text-sm font-semibold text-foreground tabular-nums">
                      ${(item.price * item.quantity).toFixed(2)}
                    </p>
                  </li>
                ))}
              </ul>

              {/* Footer actions */}
              <div className="mt-4 flex flex-wrap gap-2">
                <Button asChild size="sm" variant="outline">
                  <Link href={`/account/orders/${order.id}`}>View order</Link>
                </Button>
                {order.status !== "Cancelled" && order.status !== "Refunded" && (
                  <BuyAgainButton items={order.items} />
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default AccountOrders;
