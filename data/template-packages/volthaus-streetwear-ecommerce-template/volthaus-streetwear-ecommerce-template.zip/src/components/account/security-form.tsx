"use client";

import * as React from "react";
import {
  CheckCircle2,
  Circle,
  Laptop,
  LogOut,
  ShieldCheck,
  Smartphone,
  X,
} from "lucide-react";
import { useToastStore } from "@/store/toast-store";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

interface Session {
  id: string;
  device: string;
  location: string;
  lastActive: string;
  current: boolean;
}

const INITIAL_SESSIONS: Session[] = [
  {
    id: "sess-current",
    device: "MacBook Pro · Chrome",
    location: "San Francisco, CA",
    lastActive: "Active now",
    current: true,
  },
  {
    id: "sess-ipad",
    device: "iPad Pro · Safari",
    location: "San Francisco, CA",
    lastActive: "2 hours ago",
    current: false,
  },
];

interface PasswordForm {
  current: string;
  next: string;
  confirm: string;
}

interface PasswordErrors {
  current?: string;
  next?: string;
  confirm?: string;
}

interface Requirement {
  id: string;
  label: string;
  test: (value: string) => boolean;
}

const REQUIREMENTS: Requirement[] = [
  { id: "length", label: "At least 8 characters", test: (v) => v.length >= 8 },
  { id: "uppercase", label: "One uppercase letter", test: (v) => /[A-Z]/.test(v) },
  { id: "number", label: "One number", test: (v) => /\d/.test(v) },
  { id: "symbol", label: "One symbol (!@#$%…)", test: (v) => /[^A-Za-z0-9]/.test(v) },
];

function validatePasswords(form: PasswordForm): PasswordErrors {
  const errors: PasswordErrors = {};
  if (!form.current) errors.current = "Enter your current password.";
  if (!form.next) {
    errors.next = "Enter a new password.";
  } else if (!REQUIREMENTS.every((r) => r.test(form.next))) {
    errors.next = "Your password doesn't meet all requirements.";
  }
  if (!form.confirm) {
    errors.confirm = "Confirm your new password.";
  } else if (form.next !== form.confirm) {
    errors.confirm = "Passwords don't match.";
  }
  return errors;
}

export function SecurityForm() {
  const addToast = useToastStore((s) => s.addToast);
  const [form, setForm] = React.useState<PasswordForm>({
    current: "",
    next: "",
    confirm: "",
  });
  const [errors, setErrors] = React.useState<PasswordErrors>({});
  const [saving, setSaving] = React.useState(false);
  const [showCurrent, setShowCurrent] = React.useState(false);
  const [showNext, setShowNext] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  const [twoFactor, setTwoFactor] = React.useState(false);
  const [sessions, setSessions] = React.useState<Session[]>(INITIAL_SESSIONS);
  const [signOutAllOpen, setSignOutAllOpen] = React.useState(false);

  const update = <K extends keyof PasswordForm>(key: K, value: PasswordForm[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validation = validatePasswords(form);
    setErrors(validation);
    if (Object.values(validation).some(Boolean)) return;

    setSaving(true);
    window.setTimeout(() => {
      setSaving(false);
      setForm({ current: "", next: "", confirm: "" });
      addToast({
        title: "Password updated",
        description: "Your new password is now active. Use it next time you sign in.",
        variant: "success",
      });
    }, 500);
  };

  const handleTwoFactorToggle = (value: boolean) => {
    setTwoFactor(value);
    addToast({
      title: value ? "Two-factor enabled" : "Two-factor disabled",
      description: value
        ? "We'll text a 6-digit code to your phone on every sign-in."
        : "Your account is now protected by password only.",
      variant: value ? "success" : "default",
    });
  };

  const handleRevoke = (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    addToast({
      title: "Session revoked",
      description: "That device has been signed out.",
      variant: "default",
    });
  };

  const handleSignOutAll = () => {
    setSignOutAllOpen(false);
    setSessions((prev) => prev.filter((s) => s.current));
    addToast({
      title: "Signed out everywhere",
      description: "All other devices have been logged out.",
      variant: "success",
    });
  };

  const metCount = REQUIREMENTS.filter((r) => r.test(form.next)).length;

  return (
    <div className="space-y-6">
      {/* Change password */}
      <section
        aria-labelledby="password-heading"
        className="rounded-2xl border border-border bg-card p-5 sm:p-6"
      >
        <div className="mb-5 flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-primary" aria-hidden />
          <h2 id="password-heading" className="text-base font-bold text-foreground">
            Change password
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="grid gap-4" noValidate>
          <div className="grid gap-2">
            <Label htmlFor="pwd-current">Current password</Label>
            <div className="relative">
              <Input
                id="pwd-current"
                type={showCurrent ? "text" : "password"}
                value={form.current}
                onChange={(e) => update("current", e.target.value)}
                autoComplete="current-password"
                className="pr-12"
                aria-invalid={Boolean(errors.current)}
                aria-describedby={errors.current ? "pwd-current-error" : undefined}
              />
              <button
                type="button"
                onClick={() => setShowCurrent((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded px-2 py-1 text-[11px] font-semibold uppercase text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={showCurrent ? "Hide password" : "Show password"}
              >
                {showCurrent ? "Hide" : "Show"}
              </button>
            </div>
            {errors.current && (
              <p id="pwd-current-error" className="text-xs text-destructive">
                {errors.current}
              </p>
            )}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="pwd-new">New password</Label>
            <div className="relative">
              <Input
                id="pwd-new"
                type={showNext ? "text" : "password"}
                value={form.next}
                onChange={(e) => update("next", e.target.value)}
                autoComplete="new-password"
                className="pr-12"
                aria-invalid={Boolean(errors.next)}
                aria-describedby={errors.next ? "pwd-new-error" : undefined}
              />
              <button
                type="button"
                onClick={() => setShowNext((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded px-2 py-1 text-[11px] font-semibold uppercase text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={showNext ? "Hide password" : "Show password"}
              >
                {showNext ? "Hide" : "Show"}
              </button>
            </div>
            {errors.next && (
              <p id="pwd-new-error" className="text-xs text-destructive">
                {errors.next}
              </p>
            )}
            {/* Live requirements checklist */}
            <ul
              className="mt-2 grid gap-1.5 rounded-lg border border-border bg-muted/30 p-3"
              aria-label="Password requirements"
            >
              <li className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                {metCount}/{REQUIREMENTS.length} requirements met
              </li>
              {REQUIREMENTS.map((req) => {
                const met = req.test(form.next);
                return (
                  <li
                    key={req.id}
                    className={cn(
                      "flex items-center gap-2 text-xs transition-colors",
                      met ? "text-success" : "text-muted-foreground"
                    )}
                  >
                    {met ? (
                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0" aria-hidden />
                    ) : (
                      <Circle className="h-3.5 w-3.5 shrink-0" aria-hidden />
                    )}
                    <span>{req.label}</span>
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="pwd-confirm">Confirm new password</Label>
            <div className="relative">
              <Input
                id="pwd-confirm"
                type={showConfirm ? "text" : "password"}
                value={form.confirm}
                onChange={(e) => update("confirm", e.target.value)}
                autoComplete="new-password"
                className="pr-12"
                aria-invalid={Boolean(errors.confirm)}
                aria-describedby={errors.confirm ? "pwd-confirm-error" : undefined}
              />
              <button
                type="button"
                onClick={() => setShowConfirm((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded px-2 py-1 text-[11px] font-semibold uppercase text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={showConfirm ? "Hide password" : "Show password"}
              >
                {showConfirm ? "Hide" : "Show"}
              </button>
            </div>
            {errors.confirm && (
              <p id="pwd-confirm-error" className="text-xs text-destructive">
                {errors.confirm}
              </p>
            )}
          </div>

          <div className="flex items-center justify-end gap-2">
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setForm({ current: "", next: "", confirm: "" });
                setErrors({});
              }}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={saving} className="btn-shine">
              {saving ? "Updating…" : "Update password"}
            </Button>
          </div>
        </form>
      </section>

      {/* 2FA */}
      <section
        aria-labelledby="twofa-heading"
        className="rounded-2xl border border-border bg-card p-5 sm:p-6"
      >
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Smartphone className="h-4 w-4 text-secondary" aria-hidden />
              <h2
                id="twofa-heading"
                className="text-base font-bold text-foreground"
              >
                Two-factor authentication
              </h2>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              Add a second layer of protection. We'll text a 6-digit code to your
              verified phone every time you sign in from a new device.
            </p>
            <p
              className={cn(
                "mt-3 inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wide",
                twoFactor
                  ? "border-success/40 bg-success/10 text-success"
                  : "border-border bg-muted/40 text-muted-foreground"
              )}
            >
              {twoFactor ? "Enabled" : "Disabled"}
            </p>
          </div>
          <Switch
            checked={twoFactor}
            onCheckedChange={handleTwoFactorToggle}
            aria-label="Toggle two-factor authentication"
          />
        </div>
      </section>

      {/* Active sessions */}
      <section
        aria-labelledby="sessions-heading"
        className="rounded-2xl border border-border bg-card p-5 sm:p-6"
      >
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Laptop className="h-4 w-4 text-accent" aria-hidden />
            <h2
              id="sessions-heading"
              className="text-base font-bold text-foreground"
            >
              Active sessions
            </h2>
          </div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setSignOutAllOpen(true)}
            disabled={sessions.filter((s) => !s.current).length === 0}
          >
            <LogOut className="h-3.5 w-3.5" />
            Sign out of all sessions
          </Button>
        </div>

        <ul className="flex flex-col gap-3">
          {sessions.map((session) => (
            <li
              key={session.id}
              className={cn(
                "flex items-center gap-3 rounded-xl border border-border bg-background/40 p-4",
                session.current && "border-primary/30"
              )}
            >
              <span
                aria-hidden
                className={cn(
                  "inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                  session.current
                    ? "bg-primary/15 text-primary"
                    : "bg-muted/60 text-muted-foreground"
                )}
              >
                <Laptop className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold text-foreground">
                  {session.device}
                  {session.current && (
                    <span className="ml-2 inline-flex items-center rounded-full border border-primary/40 bg-primary/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-primary">
                      This device
                    </span>
                  )}
                </p>
                <p className="text-xs text-muted-foreground">
                  {session.location} · {session.lastActive}
                </p>
              </div>
              {!session.current && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRevoke(session.id)}
                  aria-label={`Sign out of ${session.device}`}
                >
                  <X className="h-3.5 w-3.5" />
                  Revoke
                </Button>
              )}
            </li>
          ))}
        </ul>

        <p className="mt-3 text-xs text-muted-foreground">
          If you see a session you don't recognize, change your password immediately
          and contact{" "}
          <a
            href="mailto:support@volthaus.co"
            className="font-semibold text-primary hover:underline"
          >
            support@volthaus.co
          </a>
          .
        </p>
      </section>

      <AlertDialog
        open={signOutAllOpen}
        onOpenChange={setSignOutAllOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sign out of all other sessions?</AlertDialogTitle>
            <AlertDialogDescription>
              You'll be signed out of every device except the one you're using right
              now. You'll need to sign in again on those devices.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleSignOutAll}>
              Sign out everywhere
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default SecurityForm;
