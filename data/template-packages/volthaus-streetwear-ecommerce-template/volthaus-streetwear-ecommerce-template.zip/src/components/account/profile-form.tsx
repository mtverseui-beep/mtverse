"use client";

import * as React from "react";
import Image from "next/image";
import { Camera, Trash2 } from "lucide-react";
import { mockCustomer } from "@/data/customers";
import { useToastStore } from "@/store/toast-store";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const GENDER_OPTIONS = [
  "Prefer not to say",
  "Woman",
  "Man",
  "Non-binary",
  "Prefer to self-describe",
] as const;

interface FormState {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dob: string;
  gender: (typeof GENDER_OPTIONS)[number];
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  dob?: string;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function splitName(fullName: string): { first: string; last: string } {
  const parts = fullName.trim().split(/\s+/);
  return {
    first: parts[0] ?? "",
    last: parts.slice(1).join(" "),
  };
}

function validate(form: FormState): FormErrors {
  const errors: FormErrors = {};
  if (!form.firstName.trim()) errors.firstName = "First name is required.";
  if (!form.lastName.trim()) errors.lastName = "Last name is required.";
  if (!form.email.trim()) {
    errors.email = "Email is required.";
  } else if (!EMAIL_REGEX.test(form.email)) {
    errors.email = "Enter a valid email address.";
  }
  if (form.phone.trim() && form.phone.replace(/[^\d]/g, "").length < 7) {
    errors.phone = "Enter a valid phone number.";
  }
  if (form.dob) {
    const date = new Date(form.dob);
    if (Number.isNaN(date.getTime())) {
      errors.dob = "Enter a valid date.";
    } else if (date > new Date()) {
      errors.dob = "Date of birth cannot be in the future.";
    }
  }
  return errors;
}

export function ProfileForm() {
  const addToast = useToastStore((s) => s.addToast);
  const { first, last } = splitName(mockCustomer.name);
  const [avatar, setAvatar] = React.useState(mockCustomer.avatar);
  const [form, setForm] = React.useState<FormState>({
    firstName: first,
    lastName: last,
    email: mockCustomer.email,
    phone: mockCustomer.phone ?? "",
    dob: "",
    gender: "Prefer not to say",
  });
  const [errors, setErrors] = React.useState<FormErrors>({});
  const [saving, setSaving] = React.useState(false);
  const [deleteOpen, setDeleteOpen] = React.useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = React.useState(false);

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      addToast({
        title: "Invalid file",
        description: "Please choose an image file.",
        variant: "error",
      });
      return;
    }
    const url = URL.createObjectURL(file);
    setAvatar(url);
    addToast({
      title: "Avatar updated",
      description: "Your new profile picture has been set.",
      variant: "success",
    });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validation = validate(form);
    setErrors(validation);
    if (Object.values(validation).some(Boolean)) return;

    setSaving(true);
    window.setTimeout(() => {
      setSaving(false);
      addToast({
        title: "Profile saved",
        description: "Your account details have been updated.",
        variant: "success",
      });
    }, 500);
  };

  const handleDeleteAccount = () => {
    setDeleteConfirmOpen(false);
    addToast({
      title: "Account deletion requested",
      description:
        "We've sent a confirmation link to your email. The account will be deleted within 30 days.",
      variant: "warning",
    });
  };

  return (
    <div className="space-y-6">
      <form
        onSubmit={handleSubmit}
        className="rounded-2xl border border-border bg-card p-5 sm:p-6"
        noValidate
      >
        {/* Avatar */}
        <div className="flex flex-col gap-4 border-b border-border pb-6 sm:flex-row sm:items-center">
          <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-full border border-border bg-muted">
            <Image
              src={avatar}
              alt={form.firstName ? `${form.firstName} ${form.lastName}` : "Your avatar"}
              fill
              sizes="80px"
              className="object-cover"
            />
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex flex-wrap gap-2">
              <label className="inline-flex h-9 cursor-pointer items-center gap-2 rounded-md border border-input bg-background px-3 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground">
                <Camera className="h-4 w-4" aria-hidden />
                <span>Upload new photo</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="sr-only"
                  aria-label="Upload profile photo"
                />
              </label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setAvatar(mockCustomer.avatar)}
              >
                Reset
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              JPG, PNG, or WebP. Max 4 MB. Square images render best.
            </p>
          </div>
        </div>

        {/* Form fields */}
        <div className="grid gap-4 pt-6 sm:grid-cols-2">
          <div className="grid gap-2">
            <Label htmlFor="profile-first">First name</Label>
            <Input
              id="profile-first"
              value={form.firstName}
              onChange={(e) => update("firstName", e.target.value)}
              autoComplete="given-name"
              aria-invalid={Boolean(errors.firstName)}
              aria-describedby={errors.firstName ? "profile-first-error" : undefined}
            />
            {errors.firstName && (
              <p id="profile-first-error" className="text-xs text-destructive">
                {errors.firstName}
              </p>
            )}
          </div>
          <div className="grid gap-2">
            <Label htmlFor="profile-last">Last name</Label>
            <Input
              id="profile-last"
              value={form.lastName}
              onChange={(e) => update("lastName", e.target.value)}
              autoComplete="family-name"
              aria-invalid={Boolean(errors.lastName)}
              aria-describedby={errors.lastName ? "profile-last-error" : undefined}
            />
            {errors.lastName && (
              <p id="profile-last-error" className="text-xs text-destructive">
                {errors.lastName}
              </p>
            )}
          </div>
          <div className="grid gap-2 sm:col-span-2">
            <Label htmlFor="profile-email">Email address</Label>
            <Input
              id="profile-email"
              type="email"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              autoComplete="email"
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? "profile-email-error" : undefined}
            />
            {errors.email && (
              <p id="profile-email-error" className="text-xs text-destructive">
                {errors.email}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              Used for sign-in, order updates, and drop alerts.
            </p>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="profile-phone">Phone (optional)</Label>
            <Input
              id="profile-phone"
              type="tel"
              value={form.phone}
              onChange={(e) => update("phone", e.target.value)}
              autoComplete="tel"
              placeholder="+1 (415) 555-0142"
              aria-invalid={Boolean(errors.phone)}
              aria-describedby={errors.phone ? "profile-phone-error" : undefined}
            />
            {errors.phone && (
              <p id="profile-phone-error" className="text-xs text-destructive">
                {errors.phone}
              </p>
            )}
          </div>
          <div className="grid gap-2">
            <Label htmlFor="profile-dob">Date of birth (optional)</Label>
            <Input
              id="profile-dob"
              type="date"
              value={form.dob}
              onChange={(e) => update("dob", e.target.value)}
              aria-invalid={Boolean(errors.dob)}
              aria-describedby={errors.dob ? "profile-dob-error" : undefined}
            />
            {errors.dob && (
              <p id="profile-dob-error" className="text-xs text-destructive">
                {errors.dob}
              </p>
            )}
          </div>
          <div className="grid gap-2 sm:col-span-2">
            <Label htmlFor="profile-gender">Gender (optional)</Label>
            <select
              id="profile-gender"
              value={form.gender}
              onChange={(e) => update("gender", e.target.value as FormState["gender"])}
              className="h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm shadow-xs outline-none transition-[color,box-shadow] focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]"
            >
              {GENDER_OPTIONS.map((option) => (
                <option key={option} value={option} className="bg-card text-foreground">
                  {option}
                </option>
              ))}
            </select>
            <p className="text-xs text-muted-foreground">
              Used only to personalize product recommendations and sizing guidance.
            </p>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-end gap-2 border-t border-border pt-6">
          <Button
            type="button"
            variant="ghost"
            onClick={() => {
              setForm({
                firstName: first,
                lastName: last,
                email: mockCustomer.email,
                phone: mockCustomer.phone ?? "",
                dob: "",
                gender: "Prefer not to say",
              });
              setErrors({});
            }}
            disabled={saving}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={saving} className="btn-shine">
            {saving ? "Saving…" : "Save changes"}
          </Button>
        </div>
      </form>

      {/* Danger zone */}
      <section
        aria-labelledby="danger-heading"
        className="rounded-2xl border border-destructive/30 bg-destructive/5 p-5 sm:p-6"
      >
        <div className="flex items-start gap-3">
          <span
            aria-hidden
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-destructive/15 text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </span>
          <div className="min-w-0 flex-1">
            <h2
              id="danger-heading"
              className="text-base font-bold text-foreground"
            >
              Delete account
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Permanently remove your VoltHaus account, order history, saved
              addresses, and rewards points. This action cannot be undone.
            </p>
            <Button
              type="button"
              variant="outline"
              className="mt-4 border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive"
              onClick={() => setDeleteOpen(true)}
            >
              <Trash2 className="h-4 w-4" />
              Delete account
            </Button>
          </div>
        </div>
      </section>

      {/* Delete step 1: confirm */}
      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete your VoltHaus account?</DialogTitle>
            <DialogDescription>
              You're about to permanently delete your account. You'll lose access to
              your order history, saved addresses, payment methods, and {mockCustomer.points.toLocaleString()} rewards points.
              Type "DELETE" below to continue.
            </DialogDescription>
          </DialogHeader>
          <DeleteConfirmInput
            onCancel={() => setDeleteOpen(false)}
            onConfirm={() => {
              setDeleteOpen(false);
              setDeleteConfirmOpen(true);
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Delete step 2: final confirmation */}
      <AlertDialog
        open={deleteConfirmOpen}
        onOpenChange={setDeleteConfirmOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Final confirmation</AlertDialogTitle>
            <AlertDialogDescription>
              We'll send a verification link to {form.email}. Your account will be
              deactivated immediately and permanently deleted after 30 days.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteAccount}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Request deletion
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function DeleteConfirmInput({
  onCancel,
  onConfirm,
}: {
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const [value, setValue] = React.useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (value.trim().toUpperCase() === "DELETE") onConfirm();
      }}
      className="grid gap-3"
    >
      <div className="grid gap-2">
        <Label htmlFor="delete-confirm">Type DELETE to confirm</Label>
        <Input
          id="delete-confirm"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          autoComplete="off"
          aria-describedby="delete-confirm-help"
          className={cn(
            value && value.toUpperCase() !== "DELETE" && "border-destructive"
          )}
        />
        <p id="delete-confirm-help" className="text-xs text-muted-foreground">
          This is the last step before we send the deletion verification link.
        </p>
      </div>
      <DialogFooter>
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button
          type="submit"
          variant="destructive"
          disabled={value.trim().toUpperCase() !== "DELETE"}
        >
          Continue
        </Button>
      </DialogFooter>
    </form>
  );
}

export default ProfileForm;
