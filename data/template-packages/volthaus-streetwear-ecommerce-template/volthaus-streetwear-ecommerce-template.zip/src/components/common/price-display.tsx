import * as React from "react";
import { cn } from "@/lib/utils";

export interface PriceDisplayProps {
  price: number;
  /** Original price to strike through. Only shown if greater than `price`. */
  compareAtPrice?: number;
  /** ISO currency code. Default 'USD' */
  currency?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const SIZE_CLASSES: Record<NonNullable<PriceDisplayProps["size"]>, string> = {
  sm: "text-sm",
  md: "text-base",
  lg: "text-2xl",
};

const CURRENCY_SYMBOL: Record<string, string> = {
  USD: "$",
  EUR: "\u20AC",
  GBP: "\u00A3",
  JPY: "\u00A5",
  CAD: "C$",
  AUD: "A$",
};

/**
 * Price display with optional struck-through compare-at price and a
 * savings badge. Savings are shown as a percentage off (rounded).
 */
export function PriceDisplay({
  price,
  compareAtPrice,
  currency = "USD",
  size = "md",
  className,
}: PriceDisplayProps) {
  const symbol = CURRENCY_SYMBOL[currency] ?? "$";
  const hasDiscount =
    typeof compareAtPrice === "number" && compareAtPrice > price;
  const savingsPct = hasDiscount
    ? Math.round(((compareAtPrice! - price) / compareAtPrice!) * 100)
    : 0;
  const savingsAmount = hasDiscount ? compareAtPrice! - price : 0;

  return (
    <div className={cn("flex flex-wrap items-baseline gap-2", className)}>
      <span
        className={cn(
          "font-semibold text-foreground tabular-nums",
          SIZE_CLASSES[size]
        )}
      >
        {symbol}
        {price.toFixed(2)}
      </span>
      {hasDiscount && (
        <>
          <span
            className={cn(
              "text-muted-foreground line-through tabular-nums",
              size === "lg" ? "text-base" : "text-xs"
            )}
          >
            {symbol}
            {compareAtPrice!.toFixed(2)}
          </span>
          <span
            className="inline-flex items-center rounded-full bg-destructive/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-destructive"
            title={`Save ${symbol}${savingsAmount.toFixed(2)}`}
          >
            {savingsPct}% off
          </span>
        </>
      )}
    </div>
  );
}
