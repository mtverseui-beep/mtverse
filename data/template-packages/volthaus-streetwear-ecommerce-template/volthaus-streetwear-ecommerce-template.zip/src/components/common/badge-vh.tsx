import * as React from "react";
import { cn } from "@/lib/utils";
import type { Badge as BadgeVariant } from "@/types";

export type { BadgeVariant };

export interface BadgeVHProps {
  /** Badge label / variant — determines color treatment */
  variant: BadgeVariant;
  className?: string;
  /** Override the displayed text. Defaults to the variant label. */
  label?: string;
}

const VARIANT_STYLES: Record<BadgeVariant, string> = {
  New: "bg-primary/15 text-primary border border-primary/40",
  Limited:
    "bg-secondary/15 text-secondary border border-secondary/50 shadow-[0_0_18px_-4px_rgba(255,46,209,0.55)]",
  "Best Seller":
    "bg-accent/15 text-accent border border-accent/40",
  Sale: "bg-destructive/15 text-destructive border border-destructive/40",
  Members:
    "border border-primary/40 text-white bg-gradient-to-r from-primary/85 via-accent/70 to-secondary/85",
  Restock: "bg-success/15 text-success border border-success/40",
  "Last Call": "bg-warning/15 text-warning border border-warning/40",
};

/**
 * VoltHaus product badge. Each variant maps to a distinct color treatment
 * drawn from the brand palette (primary cyan, secondary magenta, accent
 * purple, destructive red, success green, warning amber).
 */
export function BadgeVH({ variant, className, label }: BadgeVHProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] backdrop-blur-sm",
        VARIANT_STYLES[variant],
        className
      )}
    >
      {label ?? variant}
    </span>
  );
}
