import * as React from "react";
import { cn } from "@/lib/utils";

export interface SectionHeadingProps {
  /** Small uppercase mono eyebrow text in primary color */
  eyebrow?: string;
  /** Main heading content */
  title: React.ReactNode;
  /** Optional description paragraph below the title */
  description?: string;
  /** Alignment. Default 'left' */
  align?: "left" | "center";
  className?: string;
}

/**
 * Section heading with optional eyebrow, title, and description.
 *
 * - Eyebrow: small uppercase mono text in primary color with a leading line.
 * - Title: bold, tracking-tight, responsive size.
 * - Description: muted, max-w-2xl.
 */
export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className,
}: SectionHeadingProps) {
  const isCenter = align === "center";

  return (
    <div
      className={cn(
        "flex flex-col gap-3",
        isCenter && "items-center text-center",
        className
      )}
    >
      {eyebrow && (
        <div
          className={cn(
            "flex items-center gap-2.5",
            isCenter && "justify-center"
          )}
        >
          <span
            aria-hidden
            className={cn("h-px w-8 bg-primary/70", isCenter && "w-6")}
          />
          <span className="font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-primary">
            {eyebrow}
          </span>
          {isCenter && <span aria-hidden className="h-px w-6 bg-primary/70" />}
        </div>
      )}
      <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-[2.75rem] lg:leading-[1.1]">
        {title}
      </h2>
      {description && (
        <p
          className={cn(
            "max-w-2xl text-base text-muted-foreground md:text-[1.05rem]",
            isCenter && "mx-auto"
          )}
        >
          {description}
        </p>
      )}
    </div>
  );
}
