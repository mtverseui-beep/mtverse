import * as React from "react";
import { cn } from "@/lib/utils";

export interface TrustBadgeProps {
  /** Icon node rendered inside a rounded square */
  icon: React.ReactNode;
  title: string;
  description?: string;
  className?: string;
}

/**
 * Trust badge — horizontal layout with an icon in a rounded square,
 * a bold title, and an optional muted description.
 *
 * Used for shipping, returns, secure payment, etc.
 */
export function TrustBadge({
  icon,
  title,
  description,
  className,
}: TrustBadgeProps) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <div
        aria-hidden
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-border bg-card text-primary"
      >
        {icon}
      </div>
      <div className="flex min-w-0 flex-col">
        <span className="text-sm font-semibold leading-tight text-foreground">
          {title}
        </span>
        {description && (
          <span className="mt-0.5 text-xs leading-snug text-muted-foreground">
            {description}
          </span>
        )}
      </div>
    </div>
  );
}
