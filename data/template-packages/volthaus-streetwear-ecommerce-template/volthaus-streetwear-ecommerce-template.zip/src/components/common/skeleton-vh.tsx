import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Single product card skeleton with shimmer.
 */
export function ProductCardSkeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl border border-border bg-card",
        className
      )}
      aria-hidden
    >
      <div className="aspect-square w-full skeleton-shimmer" />
      <div className="space-y-3 p-4">
        <div className="h-3 w-1/3 rounded skeleton-shimmer" />
        <div className="h-4 w-3/4 rounded skeleton-shimmer" />
        <div className="h-4 w-1/4 rounded skeleton-shimmer" />
        <div className="flex gap-1.5 pt-1">
          <div className="h-4 w-4 rounded-full skeleton-shimmer" />
          <div className="h-4 w-4 rounded-full skeleton-shimmer" />
          <div className="h-4 w-4 rounded-full skeleton-shimmer" />
        </div>
        <div className="h-9 w-full rounded-md skeleton-shimmer" />
      </div>
    </div>
  );
}

/**
 * Responsive grid of `count` product card skeletons.
 */
export function ProductGridSkeleton({
  count = 8,
  className,
}: {
  count?: number;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4",
        className
      )}
      aria-hidden
    >
      {Array.from({ length: count }).map((_, i) => (
        <ProductCardSkeleton key={i} />
      ))}
    </div>
  );
}

/**
 * Large hero block skeleton for landing/PLP hero sections.
 */
export function HeroSkeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "relative aspect-[16/9] w-full overflow-hidden rounded-2xl skeleton-shimmer md:aspect-[21/9]",
        className
      )}
      aria-hidden
    >
      <div className="absolute inset-0 flex flex-col justify-end gap-3 p-6 md:p-10">
        <div className="h-3 w-1/5 rounded bg-background/40" />
        <div className="h-10 w-1/2 rounded bg-background/40 md:h-14 md:w-2/5" />
        <div className="h-4 w-1/3 rounded bg-background/40 md:w-1/4" />
        <div className="mt-2 h-10 w-32 rounded bg-background/40" />
      </div>
    </div>
  );
}

/**
 * Multiple text-line skeleton. Last line is half width by default.
 */
export function TextBlockSkeleton({
  lines = 3,
  className,
}: {
  lines?: number;
  className?: string;
}) {
  return (
    <div className={cn("space-y-2", className)} aria-hidden>
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className={cn(
            "h-3 rounded skeleton-shimmer",
            i === lines - 1 ? "w-1/2" : "w-full"
          )}
        />
      ))}
    </div>
  );
}
