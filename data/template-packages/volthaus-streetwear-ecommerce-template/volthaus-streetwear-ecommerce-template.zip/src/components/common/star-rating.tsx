import * as React from "react";
import { cn } from "@/lib/utils";

export interface StarRatingProps {
  /** Rating value from 0 to 5. Values are clamped. */
  rating: number;
  /** Star icon size in pixels. Default 16 */
  size?: number;
  /** Review count to display when `showCount` is true */
  count?: number;
  /** Whether to append "(count)" after the stars. Default false */
  showCount?: boolean;
  className?: string;
  /** Word used in the aria-label after the count. Default "reviews" */
  reviewsLabel?: string;
}

type FillMode = "full" | "half" | "empty";

interface StarIconProps {
  size: number;
  fill: FillMode;
  gradientId: string;
}

function StarIcon({ size, fill, gradientId }: StarIconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      aria-hidden="true"
      focusable="false"
    >
      {fill === "half" && (
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="0">
            <stop offset="50%" stopColor="var(--vh-primary)" />
            <stop offset="50%" stopColor="transparent" />
          </linearGradient>
        </defs>
      )}
      <path
        d="M12 2.5l2.81 6.69 7.19.55-5.46 4.74 1.64 7.02L12 18.56l-6.18 3.34 1.64-7.02L2 9.74l7.19-.55L12 2.5z"
        fill={
          fill === "full"
            ? "var(--vh-primary)"
            : fill === "half"
              ? `url(#${gradientId})`
              : "transparent"
        }
        stroke="var(--vh-primary)"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/**
 * Star rating display with partial-fill support (full / half / empty).
 *
 * Renders 5 inline SVG stars. If `showCount` is true, appends "(count)"
 * in muted text. Provides a descriptive aria-label.
 */
export function StarRating({
  rating,
  size = 16,
  count,
  showCount = false,
  className,
  reviewsLabel = "reviews",
}: StarRatingProps) {
  const clamped = Math.max(0, Math.min(5, rating));
  const fullStars = Math.floor(clamped);
  const remainder = clamped - fullStars;
  const hasHalf = remainder >= 0.25 && remainder < 0.75;
  const roundedUp = remainder >= 0.75 ? 1 : 0;
  const fullCount = fullStars + roundedUp;

  const baseId = React.useId();
  const safeId = baseId.replace(/[:]/g, "");

  const stars = Array.from({ length: 5 });

  const label = `Rated ${clamped.toFixed(1)} out of 5${
    count !== undefined ? ` based on ${count} ${reviewsLabel}` : ""
  }`;

  return (
    <div
      className={cn("inline-flex items-center gap-1.5", className)}
      role="img"
      aria-label={label}
    >
      <div
        className="flex items-center"
        style={{ gap: Math.max(2, size * 0.12) }}
      >
        {stars.map((_, i) => {
          let fill: FillMode = "empty";
          if (i < fullCount) {
            fill = "full";
          } else if (i === fullCount && hasHalf) {
            fill = "half";
          }
          return (
            <StarIcon
              key={i}
              size={size}
              fill={fill}
              gradientId={`star-${safeId}-${i}`}
            />
          );
        })}
      </div>
      {showCount && count !== undefined && (
        <span className="text-xs text-muted-foreground">
          ({count.toLocaleString("en-US")})
        </span>
      )}
    </div>
  );
}
