import * as React from "react";
import Link from "next/link";
import { ChevronRight, Home } from "lucide-react";
import { cn } from "@/lib/utils";

export interface BreadcrumbItem {
  label: string;
  href?: string;
}

export interface BreadcrumbsProps {
  /** Breadcrumb trail items. The last item is rendered as the current page. */
  items: BreadcrumbItem[];
  className?: string;
  /** Show the home icon link at the start. Default true */
  showHome?: boolean;
}

/**
 * Breadcrumb navigation. Renders Home / ... / current with chevron-right
 * separators. The current item is muted; ancestors are links.
 */
export function Breadcrumbs({
  items,
  className,
  showHome = true,
}: BreadcrumbsProps) {
  return (
    <nav aria-label="Breadcrumb" className={cn(className)}>
      <ol
        className="flex flex-wrap items-center gap-1 text-sm text-muted-foreground"
        itemType="https://schema.org/BreadcrumbList"
        itemScope
      >
        {showHome && (
          <li
            className="flex items-center"
            itemProp="itemListElement"
            itemScope
            itemType="https://schema.org/ListItem"
          >
            <Link
              href="/"
              className="inline-flex items-center transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm"
              aria-label="Home"
            >
              <Home className="h-3.5 w-3.5" />
            </Link>
            <meta itemProp="position" content="1" />
          </li>
        )}
        {items.map((item, i) => {
          const isLast = i === items.length - 1;
          const position = showHome ? i + 2 : i + 1;
          return (
            <li
              key={`${item.label}-${i}`}
              className="flex items-center"
              itemProp="itemListElement"
              itemScope
              itemType="https://schema.org/ListItem"
            >
              <ChevronRight
                aria-hidden
                className="mx-1 h-3.5 w-3.5 text-muted-foreground/50"
              />
              {item.href && !isLast ? (
                <Link
                  href={item.href}
                  className="transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm"
                  itemProp="item"
                >
                  <span itemProp="name">{item.label}</span>
                </Link>
              ) : (
                <span
                  className={cn(
                    isLast
                      ? "font-medium text-foreground"
                      : "text-muted-foreground"
                  )}
                  aria-current={isLast ? "page" : undefined}
                  itemProp="name"
                >
                  {item.label}
                </span>
              )}
              <meta itemProp="position" content={String(position)} />
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
