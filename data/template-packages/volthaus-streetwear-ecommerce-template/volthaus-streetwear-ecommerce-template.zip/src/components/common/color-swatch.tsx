import * as React from "react";
import { cn } from "@/lib/utils";
import type { ProductColor } from "@/types";

export interface ColorSwatchProps {
  /** Available colors */
  colors: ProductColor[];
  /** Currently selected color name */
  value?: string;
  /** Change handler. When omitted, swatches render as display-only spans. */
  onChange?: (colorName: string) => void;
  size?: "sm" | "md";
  className?: string;
}

/**
 * Color swatch selector. Renders circular swatches filled with each color's
 * hex value. The selected swatch has a primary ring. When no `onChange` is
 * provided, swatches are non-interactive display spans.
 */
export function ColorSwatch({
  colors,
  value,
  onChange,
  size = "md",
  className,
}: ColorSwatchProps) {
  const sizeClass = size === "sm" ? "h-5 w-5" : "h-7 w-7";
  const isInteractive = typeof onChange === "function";

  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      {colors.map((color) => {
        const selected = value === color.name;
        const commonClass = cn(
          "relative inline-flex items-center justify-center rounded-full border border-white/25 transition-all",
          sizeClass,
          isInteractive &&
            "cursor-pointer hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
          selected && "ring-2 ring-primary ring-offset-2 ring-offset-background"
        );
        const style: React.CSSProperties = { backgroundColor: color.hex };

        if (!isInteractive) {
          return (
            <span
              key={color.name}
              className={commonClass}
              style={style}
              title={color.name}
              aria-label={color.name}
              role="img"
            />
          );
        }

        return (
          <button
            key={color.name}
            type="button"
            className={commonClass}
            style={style}
            title={color.name}
            aria-label={color.name}
            aria-pressed={selected}
            onClick={() => onChange!(color.name)}
          />
        );
      })}
    </div>
  );
}
