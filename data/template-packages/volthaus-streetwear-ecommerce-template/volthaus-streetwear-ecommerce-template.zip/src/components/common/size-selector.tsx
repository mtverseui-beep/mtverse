import * as React from "react";
import { cn } from "@/lib/utils";

export interface SizeSelectorProps {
  sizes: string[];
  /** Currently selected size */
  value?: string;
  /** Change handler. When omitted, buttons render display-only. */
  onChange?: (size: string) => void;
  className?: string;
  /** Label for the optional size guide link */
  sizeGuideLabel?: string;
  /** Click handler for the size guide link */
  onSizeGuideClick?: () => void;
}

/**
 * Size selector with row/wrap layout. Selected size has primary background.
 * Includes an optional "Size guide" link in the header.
 */
export function SizeSelector({
  sizes,
  value,
  onChange,
  className,
  sizeGuideLabel = "Size guide",
  onSizeGuideClick,
}: SizeSelectorProps) {
  const isInteractive = typeof onChange === "function";

  return (
    <div className={cn("flex flex-col gap-2.5", className)}>
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-foreground">
          Size{value ? `: ${value}` : ""}
        </span>
        {onSizeGuideClick && (
          <button
            type="button"
            onClick={onSizeGuideClick}
            className="text-xs text-muted-foreground underline-offset-4 transition-colors hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm"
          >
            {sizeGuideLabel}
          </button>
        )}
      </div>
      <div className="flex flex-wrap gap-2" role="group" aria-label="Size selection">
        {sizes.map((size) => {
          const selected = value === size;
          const commonClass = cn(
            "inline-flex h-10 min-w-[2.5rem] items-center justify-center rounded-md border px-3 text-sm font-medium transition-all",
            isInteractive &&
              "cursor-pointer hover:border-primary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            selected
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border bg-card text-foreground hover:bg-muted"
          );

          if (!isInteractive) {
            return (
              <span
                key={size}
                className={cn(
                  commonClass,
                  selected ? "border-primary bg-primary text-primary-foreground" : "opacity-80"
                )}
                aria-current={selected ? "true" : undefined}
              >
                {size}
              </span>
            );
          }

          return (
            <button
              key={size}
              type="button"
              className={commonClass}
              aria-label={`Size ${size}`}
              aria-pressed={selected}
              onClick={() => onChange!(size)}
            >
              {size}
            </button>
          );
        })}
      </div>
    </div>
  );
}
