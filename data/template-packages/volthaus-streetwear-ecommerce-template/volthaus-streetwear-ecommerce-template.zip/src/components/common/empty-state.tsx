import * as React from "react";
import { cn } from "@/lib/utils";

export interface EmptyStateProps {
  /** Optional icon node — rendered inside a circular surface */
  icon?: React.ReactNode;
  /** Main title text */
  title: string;
  /** Optional supporting description */
  description?: string;
  /** Optional CTA element (button, link, etc.) */
  action?: React.ReactNode;
  className?: string;
}

/**
 * Centered empty-state layout. Used for empty cart drawers, no-results
 * search states, empty wishlist, etc.
 */
export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center px-6 py-12 text-center",
        className
      )}
      role="status"
    >
      {icon && (
        <div
          aria-hidden
          className="mb-5 flex h-16 w-16 items-center justify-center rounded-full border border-border bg-muted/40 text-muted-foreground"
        >
          {icon}
        </div>
      )}
      <h3 className="text-lg font-semibold text-foreground">{title}</h3>
      {description && (
        <p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
          {description}
        </p>
      )}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}
