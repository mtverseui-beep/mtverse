import * as React from "react";
import { Minus, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

export interface QuantitySelectorProps {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  className?: string;
  /** Accessible label for the group. Default "Quantity". */
  ariaLabel?: string;
}

/**
 * Quantity stepper with minus / value / plus layout.
 * Minus is disabled at `min`, plus is disabled at `max`.
 */
export function QuantitySelector({
  value,
  onChange,
  min = 1,
  max = 99,
  className,
  ariaLabel = "Quantity",
}: QuantitySelectorProps) {
  const atMin = value <= min;
  const atMax = value >= max;

  const decrement = () => {
    if (atMin) return;
    onChange(Math.max(min, value - 1));
  };
  const increment = () => {
    if (atMax) return;
    onChange(Math.min(max, value + 1));
  };

  return (
    <div
      className={cn(
        "inline-flex h-10 items-stretch overflow-hidden rounded-md border border-border bg-card",
        className
      )}
      role="group"
      aria-label={ariaLabel}
    >
      <button
        type="button"
        onClick={decrement}
        disabled={atMin}
        aria-label="Decrease quantity"
        className={cn(
          "inline-flex w-10 items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset",
          atMin
            ? "cursor-not-allowed opacity-40"
            : "hover:bg-muted hover:text-primary"
        )}
      >
        <Minus className="h-3.5 w-3.5" />
      </button>
      <span
        className="flex min-w-[3rem] items-center justify-center border-x border-border px-2 text-sm font-semibold tabular-nums text-foreground"
        aria-live="polite"
        aria-atomic="true"
      >
        {value}
      </span>
      <button
        type="button"
        onClick={increment}
        disabled={atMax}
        aria-label="Increase quantity"
        className={cn(
          "inline-flex w-10 items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-inset",
          atMax
            ? "cursor-not-allowed opacity-40"
            : "hover:bg-muted hover:text-primary"
        )}
      >
        <Plus className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
