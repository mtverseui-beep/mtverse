"use client";

import * as React from "react";
import { CheckCircle2, Mail, Sparkles } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { useToastStore } from "@/store/toast-store";
import { cn } from "@/lib/utils";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const BENEFITS = [
  "10% off first order",
  "Early access",
  "Member-only drops",
  "Birthday gift",
];

export interface NewsletterSectionProps {
  className?: string;
}

/**
 * Newsletter / early access signup section. Full-width band with the
 * animated grid background, a headline, an email capture form, and an
 * inline success state. Member benefits listed as small chips below.
 */
export function NewsletterSection({ className }: NewsletterSectionProps) {
  const prefersReduced = useReducedMotion();
  const addToast = useToastStore((s) => s.addToast);
  const [email, setEmail] = React.useState("");
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!EMAIL_REGEX.test(email.trim())) {
      addToast({
        title: "Enter a valid email",
        description: "We need a valid email to add you to the club.",
        variant: "error",
      });
      return;
    }
    setSubmitted(true);
    addToast({
      title: "Welcome to Static Club",
      description: "Check your inbox to confirm your membership.",
      variant: "success",
    });
  };

  return (
    <section
      id="newsletter"
      aria-label="Newsletter signup"
      className={cn("relative overflow-hidden bg-background py-20 md:py-28", className)}
    >
      <div
        aria-hidden
        className="grid-bg-animated pointer-events-none absolute inset-0 opacity-50"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 h-80 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/15 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-secondary/10 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-3xl px-4 text-center sm:px-6">
        <ScrollReveal>
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1.5 text-[11px] font-mono uppercase tracking-[0.18em] text-primary">
            <motion.span
              aria-hidden
              className="h-2 w-2 rounded-full bg-primary"
              animate={
                prefersReduced
                  ? undefined
                  : { scale: [1, 1.3, 1], opacity: [1, 0.5, 1] }
              }
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            />
            Static Club
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-5xl lg:text-[3.25rem]">
            Get early access to{" "}
            <span className="text-gradient-primary">drops</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground md:text-lg">
            Join the Static Club for member-only releases, 10% off your first
            order, and early access to every drop.
          </p>

          {submitted ? (
            <div
              role="status"
              className="mx-auto mt-8 flex max-w-md items-start gap-3 rounded-xl border border-success/30 bg-success/5 p-4 text-left"
            >
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-success" />
              <div>
                <p className="text-sm font-semibold text-foreground">
                  You're in. Check your inbox to confirm.
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  We sent a confirmation link to{" "}
                  <span className="font-mono text-foreground">{email}</span>.
                  Add support@volthaus.co to your contacts to make sure future
                  drops land in your inbox.
                </p>
              </div>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              noValidate
              className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
            >
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <div className="relative flex-1">
                <Mail
                  aria-hidden
                  className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
                />
                <Input
                  id="newsletter-email"
                  type="email"
                  inputMode="email"
                  placeholder="you@volthaus.co"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="h-12 pl-10"
                  aria-label="Email address"
                />
              </div>
              <button
                type="submit"
                className="btn-shine inline-flex h-12 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                <Sparkles className="h-4 w-4" />
                Join the club
              </button>
            </form>
          )}

          <p className="mx-auto mt-4 max-w-md text-[11px] text-muted-foreground">
            By joining, you agree to receive marketing emails. Unsubscribe
            anytime. See our{" "}
            <a
              href="/policies/privacy"
              className="text-primary underline-offset-2 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              privacy policy
            </a>
            .
          </p>

          {/* Benefits */}
          <ul className="mt-8 flex flex-wrap items-center justify-center gap-2">
            {BENEFITS.map((benefit) => (
              <li
                key={benefit}
                className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/60 px-3 py-1.5 text-xs font-medium text-foreground"
              >
                <span aria-hidden className="h-1.5 w-1.5 rounded-full bg-primary" />
                {benefit}
              </li>
            ))}
          </ul>
        </ScrollReveal>
      </div>
    </section>
  );
}

export default NewsletterSection;
