"use client";

import * as React from "react";
import { Quote, Star } from "lucide-react";
import { Marquee } from "@/components/motion/marquee";
import { cn } from "@/lib/utils";

const TOP_PHRASES = [
  "Best drop of the year",
  "Fits perfect",
  "Member early access is worth it",
  "Quality is unreal",
  "Ships fast",
  "Already copped two pairs",
  "The print detail is unreal",
  "Static Club is the move",
];

const BOTTOM_PHRASES = [
  "Cleanest runner I have owned",
  "Worth every dollar",
  "Box was collectors grade",
  "Rebound foam broke in by day two",
  "The fit is on point",
  "Reactive foam feels alive",
  "Cyan colorway hits different",
  "Will buy again next drop",
];

export interface CommunityMarqueeProps {
  className?: string;
}

/**
 * Community / social proof marquee. Two horizontal rows of glass chips
 * scrolling in opposite directions. Each chip is a customer quote with a
 * small icon (quote on top, star on bottom).
 */
export function CommunityMarquee({ className }: CommunityMarqueeProps) {
  return (
    <section
      aria-label="What the community is saying"
      className={cn(
        "relative overflow-hidden border-y border-border bg-card/40 py-10 md:py-12",
        className
      )}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />
      <div className="relative z-10 mb-5 text-center">
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-primary">
          Community signal
        </p>
        <h2 className="mt-1 text-balance text-2xl font-bold tracking-tight text-foreground md:text-3xl">
          What the streets are saying
        </h2>
      </div>

      <div className="relative z-10 flex flex-col gap-4">
        <Marquee speed={36} pauseOnHover>
          {TOP_PHRASES.map((phrase, i) => (
            <Chip key={`top-${i}`} phrase={phrase} icon={<Quote className="h-3.5 w-3.5" />} />
          ))}
        </Marquee>
        <Marquee speed={42} reverse pauseOnHover>
          {BOTTOM_PHRASES.map((phrase, i) => (
            <Chip key={`bot-${i}`} phrase={phrase} icon={<Star className="h-3.5 w-3.5" />} />
          ))}
        </Marquee>
      </div>

      {/* Edge fades */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-background to-transparent"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-background to-transparent"
      />
    </section>
  );
}

interface ChipProps {
  phrase: string;
  icon: React.ReactNode;
}

function Chip({ phrase, icon }: ChipProps) {
  return (
    <span className="glass mx-2 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium text-foreground">
      <span aria-hidden className="text-primary">
        {icon}
      </span>
      {phrase}
    </span>
  );
}

export default CommunityMarquee;
