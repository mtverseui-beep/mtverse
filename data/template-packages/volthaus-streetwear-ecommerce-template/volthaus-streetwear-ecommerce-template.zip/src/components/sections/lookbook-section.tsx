"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import { lookbookItems } from "@/data/lookbook";
import { SectionHeading } from "@/components/common/section-heading";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { cn } from "@/lib/utils";

export interface LookbookSectionProps {
  className?: string;
}

/**
 * Lookbook preview. Asymmetric editorial image grid — first item spans two
 * columns, the rest fill single cells. Hover motion: scale + brightness,
 * with a title overlay and a "Shop the look" link.
 */
export function LookbookSection({ className }: LookbookSectionProps) {
  const prefersReduced = useReducedMotion();
  const items = React.useMemo(() => lookbookItems.slice(0, 5), []);

  return (
    <section
      id="lookbook"
      className={cn(
        "relative overflow-hidden bg-background py-20 md:py-28",
        className
      )}
      aria-label="Lookbook preview"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-20 top-0 h-72 w-72 rounded-full bg-secondary/10 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            eyebrow="Editorial"
            title={
              <>
                The <span className="text-gradient-primary">Lookbook</span>
              </>
            }
            description="Editorial frames from the latest VoltHaus campaigns — captured at night, in studio, and on the street. Each look links back to the pieces that built it."
          />
          <Link
            href="/lookbook"
            className="group inline-flex items-center gap-1.5 self-start rounded-md text-sm font-semibold text-primary transition-colors hover:text-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background md:self-auto"
          >
            View full lookbook
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 lg:gap-4">
            {items.map((item, i) => {
              const isFeatured = i === 0;
              return (
                <motion.article
                  key={item.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 0.6,
                    delay: i * 0.08,
                    ease: [0.25, 0.4, 0.25, 1],
                  }}
                  className={cn(
                    "group relative overflow-hidden rounded-xl border border-border bg-card",
                    isFeatured && "lg:col-span-2 lg:row-span-2"
                  )}
                >
                  <div
                    className={cn(
                      "relative w-full overflow-hidden",
                      isFeatured ? "aspect-[4/5] lg:aspect-[8/10]" : "aspect-[4/5]"
                    )}
                  >
                    <Image
                      src={item.image}
                      alt={item.title}
                      fill
                      sizes={
                        isFeatured
                          ? "(min-width: 1024px) 50vw, 100vw"
                          : "(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
                      }
                      className={cn(
                        "object-cover transition-all duration-700 ease-out",
                        !prefersReduced && "group-hover:scale-105 group-hover:brightness-110"
                      )}
                    />
                    <div
                      aria-hidden
                      className="absolute inset-0 bg-gradient-to-t from-background/85 via-background/20 to-transparent opacity-80 transition-opacity duration-300 group-hover:opacity-95"
                    />
                    <div className="absolute inset-x-0 bottom-0 flex flex-col gap-2 p-4 md:p-5">
                      <div className="flex items-center gap-2">
                        <span className="rounded-full border border-primary/40 bg-background/80 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-primary backdrop-blur">
                          {item.category}
                        </span>
                        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                          {item.season}
                        </span>
                      </div>
                      <h3
                        className={cn(
                          "font-bold tracking-tight text-foreground",
                          isFeatured ? "text-xl md:text-2xl" : "text-base md:text-lg"
                        )}
                      >
                        {item.title}
                      </h3>
                      <Link
                        href={`/lookbook/${item.slug}`}
                        className="mt-1 inline-flex w-fit items-center gap-1 rounded-md text-xs font-semibold text-primary transition-colors hover:text-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                      >
                        Shop the look
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </div>
                </motion.article>
              );
            })}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}

export default LookbookSection;