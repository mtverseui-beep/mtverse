"use client";

import * as React from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getBestSellers } from "@/data/products";
import { ProductCard } from "@/components/product/product-card";
import { SectionHeading } from "@/components/common/section-heading";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { cn } from "@/lib/utils";

const PAGE_SIZE = 4;

export interface BestSellersSectionProps {
  className?: string;
}

/**
 * Best sellers grid. Renders a SectionHeading + responsive grid of
 * ProductCards with a staggered reveal and a "Load more" affordance that
 * progressively reveals additional best-seller products.
 */
export function BestSellersSection({ className }: BestSellersSectionProps) {
  const all = React.useMemo(() => getBestSellers(), []);
  const [visibleCount, setVisibleCount] = React.useState(
    Math.min(PAGE_SIZE, all.length)
  );
  const visible = all.slice(0, visibleCount);
  const hasMore = visibleCount < all.length;

  return (
    <section
      id="best-sellers"
      className={cn("relative overflow-hidden bg-background py-20 md:py-28", className)}
      aria-label="Best sellers"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            eyebrow="Top picks"
            title={
              <>
                Best <span className="text-gradient-primary">Sellers</span>
              </>
            }
            description="The pieces the community keeps coming back to. Restocked weekly, never mass-produced."
          />
          <Link
            href="/shop?sort=best-selling"
            className="group inline-flex items-center gap-1.5 self-start rounded-md text-sm font-semibold text-primary transition-colors hover:text-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background md:self-auto"
          >
            View all
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </ScrollReveal>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4">
          {visible.map((product, i) => (
            <ScrollReveal key={product.id} delay={i * 0.06} y={30}>
              <ProductCard product={product} priority={i < 4} />
            </ScrollReveal>
          ))}
        </div>

        {hasMore && (
          <div className="mt-10 flex justify-center">
            <button
              type="button"
              onClick={() =>
                setVisibleCount((c) => Math.min(c + PAGE_SIZE, all.length))
              }
              className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-transparent px-6 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              Load more
            </button>
          </div>
        )}
      </div>
    </section>
  );
}

export default BestSellersSection;
