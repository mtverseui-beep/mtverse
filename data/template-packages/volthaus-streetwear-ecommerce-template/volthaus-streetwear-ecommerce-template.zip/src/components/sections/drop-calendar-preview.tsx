"use client";

import * as React from "react";
import Image from "next/image";
import { Bell, CalendarClock, Flame } from "lucide-react";
import { motion } from "framer-motion";
import {
  dropCalendar,
  getLiveDrops,
  getUpcomingDrops,
} from "@/data/dropCalendar";
import type { DropCalendarEntry } from "@/types";
import { SectionHeading } from "@/components/common/section-heading";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { useToastStore } from "@/store/toast-store";
import { cn } from "@/lib/utils";

export interface DropCalendarPreviewProps {
  className?: string;
}

const STATUS_STYLES: Record<
  DropCalendarEntry["status"],
  { label: string; className: string }
> = {
  upcoming: {
    label: "Upcoming",
    className: "border-primary/40 bg-primary/10 text-primary",
  },
  live: {
    label: "Live",
    className: "border-success/40 bg-success/10 text-success",
  },
  "sold-out": {
    label: "Sold out",
    className: "border-destructive/40 bg-destructive/10 text-destructive",
  },
  restock: {
    label: "Restock",
    className: "border-warning/40 bg-warning/10 text-warning",
  },
};

/**
 * Drop calendar preview. Horizontal timeline of the next 4-5 drops with
 * dates, status pills, and notify buttons. An animated timeline line
 * connects the drop nodes.
 */
export function DropCalendarPreview({ className }: DropCalendarPreviewProps) {
  const addToast = useToastStore((s) => s.addToast);

  const entries = React.useMemo(() => {
    const upcoming = getUpcomingDrops();
    const live = getLiveDrops();
    const soldOut = dropCalendar.filter((d) => d.status === "sold-out");
    return [...live, ...upcoming, ...soldOut].slice(0, 5);
  }, []);

  const handleNotify = (entry: DropCalendarEntry) => {
    addToast({
      title: "Reminder set",
      description: `We'll notify you when ${entry.productName} drops.`,
      variant: "success",
    });
  };

  return (
    <section
      id="drop-calendar"
      className={cn(
        "relative overflow-hidden bg-background py-20 md:py-28",
        className
      )}
      aria-label="Upcoming drops timeline"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-20 top-1/4 h-72 w-72 rounded-full bg-primary/10 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            eyebrow="Mark your calendar"
            title={
              <>
                Upcoming <span className="text-gradient-primary">Drops</span>
              </>
            }
            description="Every release on the VoltHaus calendar. Set reminders, lock in your size, and we'll ping you the moment it goes live."
          />
          <a
            href="/drop-calendar"
            className="group inline-flex items-center gap-1.5 self-start rounded-md text-sm font-semibold text-primary transition-colors hover:text-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background md:self-auto"
          >
            Full calendar
            <CalendarClock className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </a>
        </ScrollReveal>

        {/* Timeline */}
        <ScrollReveal delay={0.1} className="relative overflow-x-auto pb-4">
          {/* Animated timeline line — desktop only */}
          <motion.div
            aria-hidden
            className="pointer-events-none absolute left-0 right-0 top-[68px] hidden h-px md:block"
            initial={{ scaleX: 0, originX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1, ease: [0.25, 0.4, 0.25, 1] }}
            style={{
              background:
                "linear-gradient(90deg, transparent, var(--vh-primary) 20%, var(--vh-secondary) 80%, transparent)",
            }}
          />
          <div className="flex min-w-max gap-4 md:gap-6">
            {entries.map((entry, i) => {
              const date = new Date(entry.date);
              const status = STATUS_STYLES[entry.status];
              const isLive = entry.status === "live";
              return (
                <motion.article
                  key={entry.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 0.6,
                    delay: i * 0.08,
                    ease: [0.25, 0.4, 0.25, 1],
                  }}
                  className="relative flex w-[260px] shrink-0 flex-col gap-3 rounded-xl border border-border bg-card p-4 md:w-[230px]"
                >
                  {/* Date badge + status pill */}
                  <div className="flex items-start justify-between">
                    <div className="flex flex-col">
                      <span className="font-mono text-2xl font-bold leading-none text-foreground">
                        {date.toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                      <span className="mt-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                        {date.toLocaleDateString("en-US", {
                          weekday: "short",
                        })}{" "}
                        · {entry.time}
                      </span>
                    </div>
                    <span
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.14em]",
                        status.className
                      )}
                    >
                      {isLive && (
                        <Flame className="h-3 w-3" aria-hidden />
                      )}
                      {status.label}
                    </span>
                  </div>

                  {/* Thumbnail */}
                  <div className="relative aspect-[5/4] overflow-hidden rounded-lg border border-border bg-muted/30">
                    <Image
                      src={entry.image}
                      alt={entry.productName}
                      fill
                      sizes="230px"
                      className="object-cover"
                    />
                    {entry.membersOnly && (
                      <span className="absolute left-2 top-2 rounded-full border border-primary/40 bg-background/80 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-primary backdrop-blur">
                        Members
                      </span>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1">
                    <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
                      {entry.collection}
                    </p>
                    <h3 className="line-clamp-1 text-sm font-semibold text-foreground">
                      {entry.productName}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {entry.category}
                    </p>
                  </div>

                  {/* Notify */}
                  <button
                    type="button"
                    onClick={() => handleNotify(entry)}
                    disabled={entry.status === "sold-out"}
                    className={cn(
                      "inline-flex h-9 items-center justify-center gap-1.5 rounded-md px-3 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                      entry.status === "sold-out"
                        ? "cursor-not-allowed border border-border bg-muted/30 text-muted-foreground"
                        : "border border-border bg-transparent text-foreground hover:border-primary/50 hover:text-primary"
                    )}
                  >
                    <Bell className="h-3.5 w-3.5" />
                    {entry.status === "sold-out" ? "Sold out" : "Notify me"}
                  </button>
                </motion.article>
              );
            })}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}

export default DropCalendarPreview;
