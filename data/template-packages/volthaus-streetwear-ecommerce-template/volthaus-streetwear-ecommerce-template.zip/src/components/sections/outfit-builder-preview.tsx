"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Plus } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import { outfitBuilderOptions } from "@/data/outfitBuilder";
import { getProductBySlug } from "@/data/products";
import type { OutfitBuilderOption } from "@/types";
import { SectionHeading } from "@/components/common/section-heading";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { cn } from "@/lib/utils";

const SLOTS: { label: string; option: OutfitBuilderOption }[] = [
  { label: "Sneaker", option: outfitBuilderOptions.sneakers[0] },
  { label: "Hoodie", option: outfitBuilderOptions.hoodies[0] },
  { label: "Tee", option: outfitBuilderOptions.tees[0] },
  { label: "Pants", option: outfitBuilderOptions.pants[0] },
  { label: "Accessory", option: outfitBuilderOptions.accessories[0] },
];

export interface OutfitBuilderPreviewProps {
  className?: string;
}

/**
 * Outfit builder preview. Five product slots arranged in a row with a
 * connecting line visual, plus a total price summary card and a CTA into
 * the full outfit builder experience.
 */
export function OutfitBuilderPreview({ className }: OutfitBuilderPreviewProps) {
  const prefersReduced = useReducedMotion();
  const slots = React.useMemo(
    () =>
      SLOTS.map((s) => {
        const product = getProductBySlug(s.option.productSlug);
        return { ...s, product };
      }).filter((s) => s.product),
    []
  );
  const total = slots.reduce((sum, s) => sum + (s.product?.price ?? 0), 0);

  return (
    <section
      id="outfit-builder"
      className={cn(
        "relative overflow-hidden bg-background py-20 md:py-28",
        className
      )}
      aria-label="Outfit builder preview"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-secondary/10 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 max-w-2xl">
          <SectionHeading
            eyebrow="Style it your way"
            title={
              <>
                Build Your <span className="text-gradient-primary">Drop</span>
              </>
            }
            description="Mix any five pieces — sneaker, hoodie, tee, pants, accessory — and the bundle pricing is applied automatically. Save looks, share them, drop them into your cart in one tap."
          />
        </ScrollReveal>

        <div className="grid gap-6 lg:grid-cols-[1fr_320px] lg:gap-8">
          {/* Slots row */}
          <ScrollReveal
            delay={0.1}
            className="relative overflow-hidden rounded-2xl border border-border bg-card p-5 md:p-8"
          >
            {/* Connecting line — hidden on mobile */}
            <div
              aria-hidden
              className="pointer-events-none absolute left-0 right-0 top-1/2 hidden h-px -translate-y-1/2 bg-gradient-to-r from-transparent via-primary/30 to-transparent md:block"
            />
            <div className="relative grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
              {slots.map((slot, i) => (
                <motion.div
                  key={slot.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 0.5,
                    delay: i * 0.08,
                    ease: [0.25, 0.4, 0.25, 1],
                  }}
                  className="flex flex-col items-center"
                >
                  <div className="relative aspect-square w-full max-w-[140px] overflow-hidden rounded-xl border border-border bg-muted/30">
                    {slot.product && (
                      <Image
                        src={slot.product.images[0]}
                        alt={slot.product.name}
                        fill
                        sizes="(min-width: 1024px) 140px, (min-width: 640px) 33vw, 50vw"
                        className="object-cover"
                      />
                    )}
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background/90 to-transparent p-2">
                      <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-primary">
                        {slot.label}
                      </p>
                    </div>
                  </div>
                  <p className="mt-2 line-clamp-1 text-center text-xs font-medium text-foreground">
                    {slot.product?.name ?? slot.label}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    ${slot.product?.price.toFixed(0) ?? "—"}
                  </p>
                </motion.div>
              ))}
            </div>

            {/* Plus hint row */}
            <div className="mt-6 hidden items-center justify-center gap-2 text-xs text-muted-foreground md:flex">
              <Plus className="h-3.5 w-3.5" />
              Connect pieces to unlock bundle pricing
            </div>
          </ScrollReveal>

          {/* Total + CTA */}
          <ScrollReveal delay={0.2}>
            <div className="glass flex h-full flex-col justify-between rounded-2xl p-6 md:p-8">
              <div>
                <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-primary">
                  Outfit total
                </p>
                <div className="mt-2 flex items-baseline gap-2">
                  <motion.span
                    className="text-4xl font-bold text-foreground"
                    initial={prefersReduced ? undefined : { opacity: 0, y: 8 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5 }}
                  >
                    ${total.toFixed(0)}
                  </motion.span>
                  <span className="text-sm text-muted-foreground line-through">
                    ${Math.round(total * 1.1).toFixed(0)}
                  </span>
                </div>
                <p className="mt-1 text-xs text-success">
                  Save 10% with bundle pricing
                </p>
              </div>

              <div className="mt-6 space-y-3 text-xs text-muted-foreground">
                <div className="flex items-center justify-between">
                  <span>5 pieces</span>
                  <span className="text-foreground">{slots.length} / 5</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Bundle discount</span>
                  <span className="text-success">-10%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Free shipping</span>
                  <span className="text-success">Unlocked</span>
                </div>
              </div>

              <Link
                href="/outfit-builder"
                className="btn-shine mt-6 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                Build your outfit
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}

export default OutfitBuilderPreview;
