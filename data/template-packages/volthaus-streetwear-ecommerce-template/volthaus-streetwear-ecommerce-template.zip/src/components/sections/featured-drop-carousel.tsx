"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import useEmblaCarousel from "embla-carousel-react";
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Heart,
  Eye,
  ShoppingBag,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { getFeaturedProducts } from "@/data/products";
import type { Product } from "@/types";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { useUIStore } from "@/store/ui-store";
import { useWishlistStore } from "@/store/wishlist-store";
import { StarRating } from "@/components/common/star-rating";
import { ColorSwatch } from "@/components/common/color-swatch";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { cn } from "@/lib/utils";

const AUTO_ADVANCE_MS = 6000;

export interface FeaturedDropCarouselProps {
  className?: string;
}

/**
 * Featured drop carousel. Transforms the original flavor-carousel DNA into
 * a premium product showcase: large image with a per-slide accent background
 * transition, smooth slide animation, dot indicators, large mono index
 * counter, keyboard-accessible prev/next, optional auto-advance that pauses
 * on hover/focus.
 */
export function FeaturedDropCarousel({ className }: FeaturedDropCarouselProps) {
  const featured = React.useMemo(() => getFeaturedProducts().slice(0, 5), []);
  const [emblaRef, embla] = useEmblaCarousel({
    loop: true,
    align: "center",
    skipSnaps: false,
  });

  const [selected, setSelected] = React.useState(0);
  const [paused, setPaused] = React.useState(false);

  const onSelect = React.useCallback(() => {
    if (!embla) return;
    setSelected(embla.selectedScrollSnap());
  }, [embla]);

  React.useEffect(() => {
    if (!embla) return;
    embla.on("select", onSelect);
    embla.on("reInit", onSelect);
    onSelect();
  }, [embla, onSelect]);

  // Auto-advance
  React.useEffect(() => {
    if (paused || !embla || featured.length <= 1) return;
    const id = window.setInterval(() => {
      embla.scrollNext();
    }, AUTO_ADVANCE_MS);
    return () => window.clearInterval(id);
  }, [embla, paused, featured.length]);

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!embla) return;
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      embla.scrollPrev();
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      embla.scrollNext();
    }
  };

  if (featured.length === 0) return null;
  const current = featured[selected] ?? featured[0];

  return (
    <section
      className={cn("relative overflow-hidden bg-background py-20 md:py-28", className)}
      aria-label="Featured drops"
    >
      {/* Per-slide accent background transition */}
      <AnimatePresence>
        <motion.div
          key={current.id}
          aria-hidden
          className="pointer-events-none absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          style={{
            background: `radial-gradient(60% 60% at 50% 30%, ${current.colors[0]?.hex}1f, transparent 70%)`,
          }}
        />
      </AnimatePresence>
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="mb-3 inline-flex items-center gap-2.5">
              <span aria-hidden className="h-px w-8 bg-primary/70" />
              <span className="font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-primary">
                Featured drops
              </span>
            </div>
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-5xl lg:text-[3.25rem]">
              The current{" "}
              <span className="text-gradient-primary">rotation</span>
            </h2>
          </div>
          <p className="max-w-md text-sm text-muted-foreground md:text-base">
            Five flagship pieces from active collections. Each is part of a
            limited production run.
          </p>
        </ScrollReveal>

        <div
          className="relative"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocus={() => setPaused(true)}
          onBlur={() => setPaused(false)}
          onKeyDown={handleKeyDown}
          aria-roledescription="carousel"
          aria-label="Featured drops carousel"
          tabIndex={0}
        >
          {/* Carousel viewport */}
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex">
              {featured.map((product) => (
                <FeaturedSlide
                  key={product.id}
                  product={product}
                  index={featured.indexOf(product)}
                />
              ))}
            </div>
          </div>

          {/* Desktop prev / next */}
          <button
            type="button"
            onClick={() => embla?.scrollPrev()}
            aria-label="Previous slide"
            className="absolute left-0 top-1/2 z-20 hidden h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-border bg-background/80 backdrop-blur transition-colors hover:border-primary/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background md:flex"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={() => embla?.scrollNext()}
            aria-label="Next slide"
            className="absolute right-0 top-1/2 z-20 hidden h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full border border-border bg-background/80 backdrop-blur transition-colors hover:border-primary/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background md:flex"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>

        {/* Footer: counter + dots + mobile controls */}
        <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
          <div className="font-mono text-sm font-bold tracking-[0.18em] text-foreground">
            <span className="text-primary">
              {String(selected + 1).padStart(2, "0")}
            </span>
            <span className="mx-1 text-muted-foreground">/</span>
            <span className="text-muted-foreground">
              {String(featured.length).padStart(2, "0")}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => embla?.scrollPrev()}
              aria-label="Previous slide"
              className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-background/80 transition-colors hover:border-primary/50 hover:text-primary md:hidden"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-2">
              {featured.map((product, i) => (
                <button
                  key={product.id}
                  type="button"
                  onClick={() => embla?.scrollTo(i)}
                  aria-label={`Go to slide ${i + 1}`}
                  aria-current={i === selected}
                  className={cn(
                    "h-2 rounded-full transition-all duration-300",
                    i === selected
                      ? "w-8 bg-primary"
                      : "w-2 bg-muted-foreground/40 hover:bg-muted-foreground/70"
                  )}
                />
              ))}
            </div>
            <button
              type="button"
              onClick={() => embla?.scrollNext()}
              aria-label="Next slide"
              className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-background/80 transition-colors hover:border-primary/50 hover:text-primary md:hidden"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

interface FeaturedSlideProps {
  product: Product;
  index: number;
}

function FeaturedSlide({ product, index }: FeaturedSlideProps) {
  const addToast = useToastStore((s) => s.addToast);
  const addItem = useCartStore((s) => s.addItem);
  const openCart = useCartStore((s) => s.openCart);
  const openQuickView = useUIStore((s) => s.openQuickView);
  const wishlistHas = useWishlistStore((s) => s.hasItem);
  const wishlistAdd = useWishlistStore((s) => s.addItem);
  const wishlistRemove = useWishlistStore((s) => s.removeItem);
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);
  const isWishlisted = mounted && wishlistHas(product.id);

  const accent = product.colors[0]?.hex ?? "#00E5FF";

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isWishlisted) {
      wishlistRemove(product.id);
      addToast({ title: "Removed from wishlist", variant: "default" });
    } else {
      wishlistAdd({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        addedAt: new Date().toISOString(),
      });
      addToast({
        title: "Added to wishlist",
        description: product.name,
        variant: "success",
      });
    }
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (product.sizes.length === 1) {
      addItem({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        size: product.sizes[0],
        color: product.colors[0]?.name ?? "Default",
        quantity: 1,
        category: product.category,
      });
      openCart();
      addToast({
        title: "Added to cart",
        description: product.name,
        variant: "success",
      });
    } else {
      openQuickView(product.slug);
    }
  };

  return (
    <div
      className="min-w-0 flex-[0_0_100%] pl-0"
      aria-roledescription="slide"
      aria-label={`${index + 1} of ${5}: ${product.name}`}
    >
      <div className="grid gap-6 rounded-2xl border border-border bg-card/40 p-4 backdrop-blur-sm md:grid-cols-2 md:p-6 lg:gap-8 lg:p-8">
        {/* Image */}
        <div className="relative aspect-[4/3] overflow-hidden rounded-xl border border-border bg-muted/30">
          <div
            aria-hidden
            className="absolute inset-0"
            style={{
              background: `radial-gradient(60% 60% at 50% 50%, ${accent}22, transparent 70%)`,
            }}
          />
          <Image
            src={product.images[0]}
            alt={product.name}
            fill
            sizes="(min-width: 768px) 50vw, 100vw"
            className="object-cover"
          />
          <button
            type="button"
            onClick={handleWishlistToggle}
            aria-label={
              isWishlisted
                ? `Remove ${product.name} from wishlist`
                : `Add ${product.name} to wishlist`
            }
            aria-pressed={isWishlisted}
            className="absolute right-3 top-3 inline-flex h-10 w-10 items-center justify-center rounded-full border border-border bg-background/80 backdrop-blur transition-colors hover:border-secondary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Heart
              className={cn(
                "h-4 w-4 transition-colors",
                isWishlisted ? "fill-secondary text-secondary" : "text-foreground"
              )}
            />
          </button>
        </div>

        {/* Content */}
        <div className="flex flex-col justify-between gap-6">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span
                aria-hidden
                className="h-2 w-2 rounded-full"
                style={{ backgroundColor: accent }}
              />
              <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                {product.collection}
              </span>
              <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                · {product.category}
              </span>
            </div>

            <h3 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl lg:text-4xl">
              {product.name}
            </h3>

            <p className="text-sm text-muted-foreground md:text-base">
              {product.shortDescription}
            </p>

            <div className="flex items-center gap-3">
              <StarRating
                rating={product.rating}
                size={16}
                showCount
                count={product.reviewCount}
              />
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono uppercase tracking-[0.14em] text-muted-foreground">
                  Colors
                </span>
                <ColorSwatch colors={product.colors.slice(0, 4)} size="sm" />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono uppercase tracking-[0.14em] text-muted-foreground">
                  Sizes
                </span>
                <span className="text-sm font-medium text-foreground">
                  {product.sizes[0]}–{product.sizes[product.sizes.length - 1]}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-foreground">
                ${product.price.toFixed(0)}
              </span>
              {product.compareAtPrice && (
                <span className="text-sm text-muted-foreground line-through">
                  ${product.compareAtPrice.toFixed(0)}
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => openQuickView(product.slug)}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-transparent px-4 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                <Eye className="h-4 w-4" />
                View
              </button>
              <button
                type="button"
                onClick={handleQuickAdd}
                className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                <ShoppingBag className="h-4 w-4" />
                {product.sizes.length === 1 ? "Add to cart" : "Select size"}
              </button>
              <Link
                href={`/product/${product.slug}`}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md px-3 text-sm font-semibold text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                Details
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FeaturedDropCarousel;
