"use client";

import * as React from "react";
import Image from "next/image";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { Bell, Lock, Sparkles, Users } from "lucide-react";
import { getUpcomingDrops } from "@/data/dropCalendar";
import { getProductBySlug } from "@/data/products";
import { useToastStore } from "@/store/toast-store";
import { Input } from "@/components/ui/input";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { cn } from "@/lib/utils";

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

function getTimeLeft(target: Date): TimeLeft {
  const diff = Math.max(0, target.getTime() - Date.now());
  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const TIMELINE = [
  { label: "Member early access", detail: "48h before public release" },
  { label: "Public release", detail: "16:00 UTC, drop day" },
  { label: "Final call", detail: "Last 24h before sellout" },
];

const UNITS: { key: keyof TimeLeft; label: string }[] = [
  { key: "days", label: "Days" },
  { key: "hours", label: "Hours" },
  { key: "minutes", label: "Minutes" },
  { key: "seconds", label: "Seconds" },
];

export interface DropCountdownSectionProps {
  className?: string;
}

/**
 * Drop countdown section. Renders a live countdown to the next upcoming
 * VoltHaus drop, plus a waitlist form, stock bar, and release timeline.
 *
 * Honors `prefers-reduced-motion` for the digit slide transitions.
 */
export function DropCountdownSection({ className }: DropCountdownSectionProps) {
  const prefersReduced = useReducedMotion();
  const addToast = useToastStore((s) => s.addToast);

  const drop = React.useMemo(() => getUpcomingDrops()[0], []);
  const product = React.useMemo(
    () => (drop ? getProductBySlug(drop.productSlug) : undefined),
    [drop]
  );

  const targetDate = React.useMemo(
    () => (drop ? new Date(drop.date) : null),
    [drop]
  );

  // Start with a zero placeholder so the server-rendered markup matches the
  // initial client render exactly (prevents hydration mismatch caused by
  // `Date.now()` differing between server and client). The real countdown
  // is computed inside an effect after mount.
  const [timeLeft, setTimeLeft] = React.useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });
  const [email, setEmail] = React.useState("");
  const [submitted, setSubmitted] = React.useState(false);

  React.useEffect(() => {
    if (!targetDate) return;
    // Sync immediately on mount so the digits don't flash zeros.
    setTimeLeft(getTimeLeft(targetDate));
    const timer = window.setInterval(() => {
      setTimeLeft(getTimeLeft(targetDate));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [targetDate]);

  if (!drop || !targetDate || !product) return null;

  const stockTotal = product.limitedQuantity ?? 500;
  const claimed = Math.min(stockTotal, stockTotal - product.stock);
  const claimedPct = Math.min(100, Math.round((claimed / stockTotal) * 100));

  const handleNotify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!EMAIL_REGEX.test(email.trim())) {
      addToast({
        title: "Enter a valid email",
        description: "We need a valid email to notify you about the drop.",
        variant: "error",
      });
      return;
    }
    setSubmitted(true);
    addToast({
      title: "You're on the list",
      description: `We'll email ${email.trim()} when ${drop.productName} drops.`,
      variant: "success",
    });
    setEmail("");
  };

  return (
    <section
      id="drop-countdown"
      className={cn(
        "relative overflow-hidden bg-background py-20 md:py-28",
        className
      )}
      aria-label="Upcoming drop countdown"
    >
      {/* Animated grid background */}
      <div aria-hidden className="grid-bg-animated pointer-events-none absolute inset-0 opacity-50" />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 top-1/2 h-72 w-72 -translate-y-1/2 rounded-full bg-primary/10 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-32 top-0 h-72 w-72 rounded-full bg-accent/10 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 flex flex-col gap-2 text-center md:mb-14">
          <div className="inline-flex items-center justify-center gap-2 self-center rounded-full border border-primary/30 bg-primary/5 px-3 py-1.5 text-[11px] font-mono uppercase tracking-[0.18em] text-primary">
            <motion.span
              aria-hidden
              className="h-2 w-2 rounded-full bg-primary"
              animate={
                prefersReduced
                  ? undefined
                  : { scale: [1, 1.3, 1], opacity: [1, 0.5, 1] }
              }
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            />
            Next drop · {drop.collection}
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-5xl lg:text-[3.25rem]">
            Drops in{" "}
            <span className="text-gradient-primary">real time</span>
          </h2>
          <p className="mx-auto max-w-xl text-base text-muted-foreground md:text-lg">
            Limited to {stockTotal.toLocaleString("en-US")} pairs. Members get
            48-hour early access. Set your reminder below.
          </p>
        </ScrollReveal>

        <div className="grid gap-6 lg:grid-cols-[1.05fr_1fr] lg:gap-8">
          {/* Left: countdown + product preview */}
          <ScrollReveal
            delay={0.1}
            className="glass relative overflow-hidden rounded-2xl p-6 md:p-8"
          >
            {drop.membersOnly && (
              <span className="absolute right-4 top-4 inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-primary">
                <Lock className="h-3 w-3" />
                Members only
              </span>
            )}

            {/* Countdown digits */}
            <div className="mb-8 grid grid-cols-4 gap-2 sm:gap-4">
              {UNITS.map((unit) => (
                <div
                  key={unit.key}
                  className="flex flex-col items-center gap-1 rounded-xl border border-border bg-muted/40 px-2 py-4 text-center"
                >
                  <div className="relative h-12 w-full overflow-hidden text-center font-mono text-3xl font-bold tabular-nums text-foreground sm:h-14 sm:text-4xl md:text-5xl">
                    <AnimatePresence mode="popLayout" initial={false}>
                      <motion.span
                        key={timeLeft[unit.key]}
                        initial={
                          prefersReduced
                            ? { opacity: 0 }
                            : { y: 18, opacity: 0 }
                        }
                        animate={{ y: 0, opacity: 1 }}
                        exit={
                          prefersReduced
                            ? { opacity: 0 }
                            : { y: -18, opacity: 0 }
                        }
                        transition={{ duration: 0.25, ease: "easeOut" }}
                        className="absolute inset-0 flex items-center justify-center"
                      >
                        {String(timeLeft[unit.key]).padStart(2, "0")}
                      </motion.span>
                    </AnimatePresence>
                  </div>
                  <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    {unit.label}
                  </span>
                </div>
              ))}
            </div>

            {/* Product preview */}
            <div className="flex items-center gap-4 rounded-xl border border-border bg-card/40 p-3">
              <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg border border-border bg-muted/30 sm:h-24 sm:w-24">
                <Image
                  src={drop.image}
                  alt={drop.productName}
                  fill
                  sizes="96px"
                  className="object-cover"
                />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
                  {drop.collection}
                </p>
                <h3 className="line-clamp-1 text-base font-semibold text-foreground sm:text-lg">
                  {drop.productName}
                </h3>
                <p className="text-sm text-muted-foreground">
                  ${product.price.toFixed(0)} ·{" "}
                  <span className="text-foreground/80">
                    {product.category}
                  </span>
                </p>
              </div>
            </div>

            {/* Stock bar */}
            <div className="mt-5">
              <div className="mb-2 flex items-center justify-between text-xs font-medium">
                <span className="text-muted-foreground">
                  {claimed.toLocaleString("en-US")} of{" "}
                  {stockTotal.toLocaleString("en-US")} claimed
                </span>
                <span className="text-primary">{claimedPct}%</span>
              </div>
              <div
                className="h-2 w-full overflow-hidden rounded-full bg-muted"
                role="progressbar"
                aria-label="Stock claimed"
                aria-valuenow={claimedPct}
                aria-valuemin={0}
                aria-valuemax={100}
              >
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                  initial={{ width: 0 }}
                  whileInView={{ width: `${claimedPct}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1, ease: "easeOut" }}
                />
              </div>
            </div>
          </ScrollReveal>

          {/* Right: waitlist + timeline */}
          <ScrollReveal delay={0.2} className="flex flex-col gap-6">
            <div className="glass rounded-2xl p-6 md:p-8">
              <div className="mb-4 flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                <h3 className="text-lg font-semibold text-foreground">
                  Join the waitlist
                </h3>
              </div>
              <p className="mb-4 text-sm text-muted-foreground">
                Get a personal reminder 60 minutes before the drop goes live.
                Members skip the line entirely.
              </p>
              {submitted ? (
                <div
                  className="flex items-start gap-3 rounded-lg border border-success/30 bg-success/5 p-4"
                  role="status"
                >
                  <Sparkles className="mt-0.5 h-5 w-5 text-success" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      You're on the list.
                    </p>
                    <p className="text-xs text-muted-foreground">
                      We'll send a reminder to your inbox. Check spam and add
                      support@volthaus.co to your contacts.
                    </p>
                  </div>
                </div>
              ) : (
                <form
                  onSubmit={handleNotify}
                  className="flex flex-col gap-3 sm:flex-row"
                  noValidate
                >
                  <label htmlFor="waitlist-email" className="sr-only">
                    Email address
                  </label>
                  <Input
                    id="waitlist-email"
                    type="email"
                    inputMode="email"
                    placeholder="you@volthaus.co"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-11 flex-1"
                    aria-label="Email address"
                  />
                  <button
                    type="submit"
                    className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                  >
                    <Bell className="h-4 w-4" />
                    Notify me
                  </button>
                </form>
              )}
              <p className="mt-3 text-[11px] text-muted-foreground">
                By joining, you agree to receive marketing emails from
                VoltHaus. Unsubscribe anytime.
              </p>
            </div>

            {/* Release timeline */}
            <div className="glass rounded-2xl p-6 md:p-8">
              <div className="mb-4 flex items-center gap-2">
                <Users className="h-5 w-5 text-secondary" />
                <h3 className="text-lg font-semibold text-foreground">
                  Release timeline
                </h3>
              </div>
              <ol className="relative space-y-5 border-l border-border pl-5">
                {TIMELINE.map((item, i) => (
                  <li key={item.label} className="relative">
                    <span
                      aria-hidden
                      className={cn(
                        "absolute -left-[26px] top-1.5 h-3 w-3 rounded-full border-2 border-background",
                        i === 0
                          ? "bg-primary"
                          : i === 1
                            ? "bg-accent"
                            : "bg-secondary"
                      )}
                    />
                    <p className="text-sm font-semibold text-foreground">
                      {item.label}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {item.detail}
                    </p>
                  </li>
                ))}
              </ol>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}

export default DropCountdownSection;
