"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { creators } from "@/data/creators";
import { SectionHeading } from "@/components/common/section-heading";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { Marquee } from "@/components/motion/marquee";
import { cn } from "@/lib/utils";

export interface CreatorCapsuleSectionProps {
  className?: string;
}

const SCROLL_CLASSES = "no-scrollbar";

/**
 * Creator capsule section. Horizontal snap-scroll of creator cards plus
 * a marquee strip of creator handles below.
 */
export function CreatorCapsuleSection({ className }: CreatorCapsuleSectionProps) {
  const marqueeNames = React.useMemo(
    () => creators.map((c) => c.handle.replace("@", "").toUpperCase()).join(" / ") + " / ",
    []
  );

  return (
    <section
      id="creators"
      className={cn("relative overflow-hidden bg-background py-20 md:py-28", className)}
      aria-label="Creator capsules"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-20 top-1/3 h-72 w-72 rounded-full bg-accent/10 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            eyebrow="Creator-led"
            title={
              <>
                Creator <span className="text-gradient-primary">Capsules</span>
              </>
            }
            description="Six artists, athletes, and designers ship capsule collections with us every season. Each piece comes with a printed zine documenting the build process."
          />
          <Link
            href="/creators"
            className="group inline-flex items-center gap-1.5 self-start rounded-md text-sm font-semibold text-primary transition-colors hover:text-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background md:self-auto"
          >
            View all creators
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </ScrollReveal>

        {/* Snap-scroll row */}
        <ScrollReveal delay={0.1}>
          <div
            className={cn(
              "flex snap-x snap-mandatory gap-4 overflow-x-auto pb-4 sm:gap-5",
              SCROLL_CLASSES
            )}
            role="list"
          >
            {creators.map((creator) => (
              <CreatorCard key={creator.id} creator={creator} />
            ))}
          </div>
        </ScrollReveal>
      </div>

      {/* Marquee of creator handles */}
      <div className="relative z-10 mt-10 border-y border-border bg-card/30 py-4">
        <Marquee speed={32} pauseOnHover>
          <span className="px-4 font-mono text-sm font-semibold uppercase tracking-[0.2em] text-foreground">
            {marqueeNames}
          </span>
        </Marquee>
      </div>
    </section>
  );
}

interface CreatorCardProps {
  creator: (typeof creators)[number];
}

function CreatorCard({ creator }: CreatorCardProps) {
  return (
    <article
      role="listitem"
      className="group relative flex w-[78vw] shrink-0 snap-start flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40 sm:w-[42vw] lg:w-[30vw] xl:w-[22vw]"
    >
      {/* Cover */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={creator.cover}
          alt={`${creator.name} capsule cover`}
          fill
          sizes="(min-width: 1280px) 22vw, (min-width: 1024px) 30vw, (min-width: 640px) 42vw, 78vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div
          aria-hidden
          className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent"
        />
        {/* Avatar overlap */}
        <div className="absolute -bottom-6 left-5">
          <div className="relative h-16 w-16 overflow-hidden rounded-full border-2 border-card bg-muted/30">
            <Image
              src={creator.avatar}
              alt={`${creator.name} avatar`}
              fill
              sizes="64px"
              className="object-cover"
            />
          </div>
        </div>
        <span className="absolute right-3 top-3 rounded-full border border-primary/40 bg-background/80 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-primary backdrop-blur">
          {creator.drops} {creator.drops === 1 ? "drop" : "drops"}
        </span>
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col gap-3 p-5 pt-8">
        <div>
          <h3 className="text-base font-bold tracking-tight text-foreground">
            {creator.name}
          </h3>
          <p className="text-xs text-muted-foreground">
            {creator.handle} · {creator.role}
          </p>
        </div>
        <p className="line-clamp-2 text-sm text-muted-foreground">
          {creator.bio}
        </p>
        <div className="mt-1 flex items-center justify-between text-xs">
          <span className="text-muted-foreground">
            <span className="font-semibold text-foreground">{creator.followers}</span>{" "}
            followers
          </span>
          <Link
            href={`/creators/${creator.slug}`}
            className="inline-flex items-center gap-1 font-semibold text-primary transition-colors hover:text-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            aria-label={`Shop ${creator.name}'s capsule`}
          >
            Shop capsule
            <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </article>
  );
}

export default CreatorCapsuleSection;
