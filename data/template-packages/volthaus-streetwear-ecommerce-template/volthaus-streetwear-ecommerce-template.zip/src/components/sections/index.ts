/**
 * Barrel file re-exporting every VoltHaus homepage section.
 *
 * Sections are imported by `src/app/page.tsx` and assembled into the
 * homepage experience.
 */

export { HeroSection } from "./hero-section";
export type { HeroSectionProps } from "./hero-section";

export { DropCountdownSection } from "./drop-countdown-section";
export type { DropCountdownSectionProps } from "./drop-countdown-section";

export { FeaturedDropCarousel } from "./featured-drop-carousel";
export type { FeaturedDropCarouselProps } from "./featured-drop-carousel";

export { BestSellersSection } from "./best-sellers-section";
export type { BestSellersSectionProps } from "./best-sellers-section";

export { BentoGridSection } from "./bento-grid-section";
export type { BentoGridSectionProps } from "./bento-grid-section";

export { OutfitBuilderPreview } from "./outfit-builder-preview";
export type { OutfitBuilderPreviewProps } from "./outfit-builder-preview";

export { CreatorCapsuleSection } from "./creator-capsule-section";
export type { CreatorCapsuleSectionProps } from "./creator-capsule-section";

export { LookbookSection } from "./lookbook-section";
export type { LookbookSectionProps } from "./lookbook-section";

export { DropCalendarPreview } from "./drop-calendar-preview";
export type { DropCalendarPreviewProps } from "./drop-calendar-preview";

export { CommunityMarquee } from "./community-marquee";
export type { CommunityMarqueeProps } from "./community-marquee";

export { ReviewsSection } from "./reviews-section";
export type { ReviewsSectionProps } from "./reviews-section";

export { TrustBadgesSection } from "./trust-badges-section";
export type { TrustBadgesSectionProps } from "./trust-badges-section";

export { NewsletterSection } from "./newsletter-section";
export type { NewsletterSectionProps } from "./newsletter-section";
