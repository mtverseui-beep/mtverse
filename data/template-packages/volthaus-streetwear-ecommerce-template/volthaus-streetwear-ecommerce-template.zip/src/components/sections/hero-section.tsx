"use client";

import * as React from "react";
import Image from "next/image";
import {
  motion,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
  type Variants,
} from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { useLenis } from "lenis/react";
import { MagneticButton } from "@/components/motion/magnetic-button";
import { useMediaQuery } from "@/hooks";

const SPRING_CONFIG = { stiffness: 100, damping: 30, restDelta: 0.001 };

const FADE_UP_VARIANTS: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.1,
      duration: 0.8,
      ease: [0.25, 0.4, 0.25, 1],
    },
  }),
};

const SCALE_IN_VARIANTS: Variants = {
  hidden: { opacity: 0, scale: 0.85, rotate: -6 },
  visible: {
    opacity: 1,
    scale: 1,
    rotate: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 20,
      delay: 0.35,
    },
  },
};

const HERO_BADGES = [
  "Limited release",
  "Free shipping over $100",
  "New drop live",
  "Members get early access",
];

const HERO_IMAGE_URL =
  "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900&q=80&auto=format&fit=crop";

export interface HeroSectionProps {
  /** Optional className to override or extend section styles */
  className?: string;
}

/**
 * VoltHaus homepage hero.
 *
 * Matches the original source design DNA: parallax scroll on the product
 * image (y-translate via useScroll + useSpring), parallax x-translate on
 * each headline line, staggered fade-up entrance, floating glow orbs, and
 * a scroll indicator at the bottom.
 *
 * Parallax is disabled on mobile (under 768px) to prevent overlap, and all
 * motion respects `prefers-reduced-motion`.
 */
export function HeroSection({ className }: HeroSectionProps) {
  const prefersReduced = useReducedMotion();
  const isDesktop = useMediaQuery("(min-width: 768px)");
  const lenis = useLenis();

  const sectionRef = React.useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });

  // Disable parallax on mobile or when reduced motion is preferred.
  const parallaxEnabled = isDesktop && !prefersReduced;

  const rawImageY = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const imageY = useSpring(rawImageY, SPRING_CONFIG);

  const rawTextX1 = useTransform(scrollYProgress, [0, 1], [0, -80]);
  const textX1 = useSpring(rawTextX1, SPRING_CONFIG);

  const rawTextX2 = useTransform(scrollYProgress, [0, 1], [0, 80]);
  const textX2 = useSpring(rawTextX2, SPRING_CONFIG);

  const rawOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const textOpacity = useSpring(rawOpacity, SPRING_CONFIG);

  const handleScrollToDrops = React.useCallback(() => {
    if (!lenis) return;
    const target = document.getElementById("drop-countdown");
    if (target) {
      lenis.scrollTo(target, { offset: -80 });
    } else {
      lenis.scrollTo(0);
    }
  }, [lenis]);

  return (
    <section
      id="hero"
      ref={sectionRef}
      className={
        "relative flex min-h-[92vh] items-center overflow-hidden bg-background noise-overlay " +
        (className ?? "")
      }
      aria-label="VoltHaus hero"
    >
      {/* Grid background */}
      <div
        aria-hidden
        className="grid-bg pointer-events-none absolute inset-0 opacity-60"
      />

      {/* Floating glow orbs */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute left-[6%] top-[18%] h-32 w-32 rounded-full bg-primary/20 blur-3xl"
        animate={
          prefersReduced
            ? undefined
            : { x: [0, 30, 0], y: [0, -20, 0], scale: [1, 1.15, 1] }
        }
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute bottom-[14%] right-[8%] h-40 w-40 rounded-full bg-secondary/15 blur-3xl"
        animate={
          prefersReduced
            ? undefined
            : { x: [0, -40, 0], y: [0, 30, 0], scale: [1, 1.25, 1] }
        }
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-[60%] h-24 w-24 -translate-x-1/2 rounded-full bg-accent/15 blur-3xl"
        animate={
          prefersReduced
            ? undefined
            : { x: [-20, 20, -20], y: [0, -15, 0] }
        }
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-16 pt-20 sm:px-6 md:pt-24 lg:pt-28">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-8">
          {/* Text content */}
          <motion.div
            style={{ opacity: parallaxEnabled ? textOpacity : 1 }}
            className="order-2 space-y-5 lg:order-1"
          >
            {/* Eyebrow chip */}
            <motion.div
              variants={FADE_UP_VARIANTS}
              initial="hidden"
              animate="visible"
              custom={0}
              className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1.5 text-[11px] font-mono uppercase tracking-[0.18em] text-primary"
            >
              <motion.span
                aria-hidden
                className="h-2 w-2 rounded-full bg-primary"
                animate={
                  prefersReduced
                    ? undefined
                    : { scale: [1, 1.3, 1], opacity: [1, 0.6, 1] }
                }
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              />
              Limited release · Members get early access
            </motion.div>

            {/* Headline */}
            <div className="space-y-1 overflow-hidden">
              <motion.h1
                style={{ x: parallaxEnabled ? textX1 : 0 }}
                className="text-balance text-5xl font-black leading-[0.92] tracking-tighter text-foreground sm:text-6xl md:text-7xl lg:text-[5rem]"
              >
                <motion.span
                  variants={FADE_UP_VARIANTS}
                  initial="hidden"
                  animate="visible"
                  custom={1}
                  className="inline-block"
                >
                  DROP THE STATIC.
                </motion.span>
              </motion.h1>
              <motion.h1
                style={{ x: parallaxEnabled ? textX2 : 0 }}
                className="text-balance text-5xl font-black leading-[0.92] tracking-tighter sm:text-6xl md:text-7xl lg:text-[5rem]"
              >
                <motion.span
                  variants={FADE_UP_VARIANTS}
                  initial="hidden"
                  animate="visible"
                  custom={2}
                  className="text-gradient-primary inline-block"
                >
                  WEAR THE SIGNAL.
                </motion.span>
              </motion.h1>
              <motion.p
                variants={FADE_UP_VARIANTS}
                initial="hidden"
                animate="visible"
                custom={3}
                className="max-w-md pt-3 text-base text-muted-foreground sm:text-lg md:text-xl"
              >
                Limited sneakers, streetwear, and creator capsules designed for
                the next wave of street culture.
              </motion.p>
            </div>

            {/* CTA row */}
            <motion.div
              variants={FADE_UP_VARIANTS}
              initial="hidden"
              animate="visible"
              custom={4}
              className="flex flex-wrap items-center gap-3 pt-2"
            >
              <MagneticButton as="a" href="/shop" variant="primary">
                Shop the drop
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </MagneticButton>
              <MagneticButton as="a" href="/lookbook" variant="outline">
                <Sparkles className="h-4 w-4" />
                View lookbook
              </MagneticButton>
            </motion.div>

            {/* Hero badges */}
            <motion.ul
              variants={FADE_UP_VARIANTS}
              initial="hidden"
              animate="visible"
              custom={5}
              className="flex flex-wrap gap-x-5 gap-y-2 pt-4"
            >
              {HERO_BADGES.map((badge, i) => (
                <motion.li
                  key={badge}
                  className="flex items-center gap-2 text-xs font-mono text-muted-foreground"
                  initial={{ opacity: 0, x: -20 }}
                  animate={
                    prefersReduced ? { opacity: 1 } : { opacity: 1, x: 0 }
                  }
                  transition={{ delay: 0.8 + i * 0.1 }}
                >
                  <span
                    aria-hidden
                    className="h-1.5 w-1.5 rounded-full bg-primary"
                  />
                  {badge}
                </motion.li>
              ))}
            </motion.ul>
          </motion.div>

          {/* Hero image */}
          <motion.div
            style={{ y: parallaxEnabled ? imageY : 0 }}
            className="relative order-1 flex justify-center lg:order-2"
          >
            <motion.div
              variants={SCALE_IN_VARIANTS}
              initial="hidden"
              animate="visible"
              className="relative"
            >
              {/* Cyan glow behind image */}
              <motion.div
                aria-hidden
                className="absolute inset-0 scale-75 rounded-full bg-primary/30 blur-[80px]"
                animate={
                  prefersReduced
                    ? undefined
                    : { scale: [0.75, 0.9, 0.75], opacity: [0.3, 0.55, 0.3] }
                }
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              />

              <motion.div
                animate={
                  prefersReduced
                    ? undefined
                    : { y: [0, -15, 0], rotate: [0, 2, 0] }
                }
                transition={{
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="relative z-10"
              >
                <div className="relative aspect-[3/4] w-[260px] overflow-hidden rounded-2xl border border-border sm:w-[340px] md:w-[400px] lg:w-[440px]">
                  <Image
                    src={HERO_IMAGE_URL}
                    alt="Volt Runner 01 — flagship VoltHaus sneaker in Signal Cyan"
                    fill
                    priority
                    sizes="(min-width: 1024px) 440px, (min-width: 640px) 340px, 260px"
                    className="object-cover"
                  />
                  <div
                    aria-hidden
                    className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent"
                  />
                </div>

                {/* Floating product tag */}
                <motion.div
                  aria-hidden
                  className="glass absolute -bottom-4 -left-4 hidden rounded-xl px-4 py-3 sm:block"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1, duration: 0.6 }}
                >
                  <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
                    Neon Court · SS26
                  </p>
                  <p className="text-sm font-semibold text-foreground">
                    Volt Runner 01
                  </p>
                  <p className="text-xs text-muted-foreground">
                    $189 · 500 pairs worldwide
                  </p>
                </motion.div>
              </motion.div>
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.button
          type="button"
          onClick={handleScrollToDrops}
          aria-label="Scroll to next section"
          className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 md:flex"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4, duration: 0.8 }}
        >
          <motion.div
            animate={
              prefersReduced ? undefined : { y: [0, 8, 0] }
            }
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <div className="flex h-8 w-5 items-start justify-center rounded-full border-2 border-muted-foreground/40 pt-1.5">
              <motion.span
                aria-hidden
                className="h-1.5 w-1 rounded-full bg-primary"
                animate={
                  prefersReduced
                    ? undefined
                    : { y: [0, 6, 0], opacity: [1, 0.4, 1] }
                }
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
          </motion.div>
          <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
            Scroll
          </span>
        </motion.button>
      </div>
    </section>
  );
}

export default HeroSection;
