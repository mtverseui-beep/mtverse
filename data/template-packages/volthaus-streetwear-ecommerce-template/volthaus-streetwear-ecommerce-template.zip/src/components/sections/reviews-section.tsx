"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, BadgeCheck, Star } from "lucide-react";
import { reviews } from "@/data/reviews";
import { SectionHeading } from "@/components/common/section-heading";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { AnimatedCounter } from "@/components/motion/animated-counter";
import { cn } from "@/lib/utils";

const AVG_RATING = 4.8;
const TOTAL_REVIEWS = 1840;

const DISTRIBUTION: { rating: number; pct: number }[] = [
  { rating: 5, pct: 80 },
  { rating: 4, pct: 15 },
  { rating: 3, pct: 3 },
  { rating: 2, pct: 1 },
  { rating: 1, pct: 1 },
];

export interface ReviewsSectionProps {
  className?: string;
}

/**
 * Reviews section. Large rating summary card with animated total count and
 * distribution bars, plus a grid of 6 verified-review cards.
 */
export function ReviewsSection({ className }: ReviewsSectionProps) {
  const featured = React.useMemo(() => reviews.slice(0, 6), []);

  return (
    <section
      id="reviews"
      className={cn(
        "relative overflow-hidden bg-background py-20 md:py-28",
        className
      )}
      aria-label="Verified reviews"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-32 top-0 h-72 w-72 rounded-full bg-primary/10 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 max-w-2xl">
          <SectionHeading
            eyebrow="Verified reviews"
            title={
              <>
                The Street <span className="text-gradient-primary">Speaks</span>
              </>
            }
            description="Real reviews from verified buyers across every drop. No paid placements, no edited ratings."
          />
        </ScrollReveal>

        <div className="grid gap-6 lg:grid-cols-[360px_1fr] lg:gap-8">
          {/* Summary card */}
          <ScrollReveal delay={0.1}>
            <div className="glass sticky top-24 flex h-full flex-col gap-5 rounded-2xl p-6 md:p-8">
              <div className="flex items-end gap-3">
                <span className="font-mono text-5xl font-bold text-foreground md:text-6xl">
                  {AVG_RATING.toFixed(1)}
                </span>
                <div className="mb-2 flex flex-col gap-1">
                  <div className="flex">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className="h-4 w-4 fill-primary text-primary"
                        aria-hidden
                      />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    Average rating
                  </span>
                </div>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">Total reviews</p>
                <p className="font-mono text-3xl font-bold text-foreground">
                  <AnimatedCounter value={TOTAL_REVIEWS} suffix="+" />
                </p>
              </div>

              {/* Distribution bars */}
              <div className="space-y-2">
                {DISTRIBUTION.map((row) => (
                  <div
                    key={row.rating}
                    className="flex items-center gap-3 text-xs"
                  >
                    <span className="flex w-8 items-center gap-0.5 text-muted-foreground">
                      {row.rating}
                      <Star className="h-3 w-3 fill-primary text-primary" aria-hidden />
                    </span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                      <motion.div
                        className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                        initial={{ width: 0 }}
                        whileInView={{ width: `${row.pct}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                      />
                    </div>
                    <span className="w-8 text-right text-muted-foreground">
                      {row.pct}%
                    </span>
                  </div>
                ))}
              </div>

              <Link
                href="/reviews"
                className="btn-shine mt-2 inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                Write a review
                <ArrowRight className="h-4 w-4" />
              </Link>
              <p className="text-center text-[11px] text-muted-foreground">
                Verified buyers only · we never edit or remove reviews.
              </p>
            </div>
          </ScrollReveal>

          {/* Review grid */}
          <div className="grid gap-4 sm:grid-cols-2">
            {featured.map((review, i) => (
              <ScrollReveal key={review.id} delay={i * 0.06} y={30}>
                <ReviewCard review={review} />
              </ScrollReveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

interface ReviewCardProps {
  review: (typeof reviews)[number];
}

function ReviewCard({ review }: ReviewCardProps) {
  return (
    <motion.article
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className="flex h-full flex-col gap-3 rounded-xl border border-border bg-card p-5"
    >
      <div className="flex items-center gap-3">
        <div className="relative h-10 w-10 overflow-hidden rounded-full border border-border bg-muted/30">
          <Image
            src={review.avatar}
            alt={review.author}
            fill
            sizes="40px"
            className="object-cover"
          />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <p className="truncate text-sm font-semibold text-foreground">
              {review.author}
            </p>
            {review.verified && (
              <BadgeCheck className="h-3.5 w-3.5 shrink-0 text-primary" aria-label="Verified buyer" />
            )}
          </div>
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
            <span>{new Date(review.date).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}</span>
            <span aria-hidden>·</span>
            <span>{review.productName}</span>
          </div>
        </div>
      </div>

      <div className="flex" aria-label={`Rated ${review.rating} out of 5`}>
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={cn(
              "h-3.5 w-3.5",
              i < review.rating
                ? "fill-primary text-primary"
                : "text-muted-foreground/40"
            )}
            aria-hidden
          />
        ))}
      </div>

      <h3 className="text-sm font-bold text-foreground">{review.title}</h3>
      <p className="line-clamp-4 text-sm leading-relaxed text-muted-foreground">
        {review.body}
      </p>

      {review.verified && (
        <span className="mt-auto inline-flex items-center gap-1 text-[11px] font-medium text-primary">
          <BadgeCheck className="h-3 w-3" />
          Verified buyer
        </span>
      )}
    </motion.article>
  );
}

export default ReviewsSection;
