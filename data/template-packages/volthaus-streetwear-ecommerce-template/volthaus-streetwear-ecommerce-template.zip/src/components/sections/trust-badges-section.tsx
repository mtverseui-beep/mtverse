import * as React from "react";
import { Lock, RotateCcw, Sparkles, Truck } from "lucide-react";
import { TrustBadge } from "@/components/common/trust-badge";
import { cn } from "@/lib/utils";

export interface TrustBadgesSectionProps {
  className?: string;
}

const BADGES = [
  {
    icon: <Truck className="h-5 w-5" />,
    title: "Free shipping over $100",
    description: "Express shipping unlocked automatically at checkout.",
  },
  {
    icon: <RotateCcw className="h-5 w-5" />,
    title: "30-day returns",
    description: "Send it back within 30 days for a full refund.",
  },
  {
    icon: <Lock className="h-5 w-5" />,
    title: "Secure checkout",
    description: "256-bit TLS, PCI-DSS compliant, Apple Pay supported.",
  },
  {
    icon: <Sparkles className="h-5 w-5" />,
    title: "Member rewards",
    description: "Earn points, unlock tiers, get early access to every drop.",
  },
];

/**
 * Trust badges row. Four badges (shipping, returns, security, rewards)
 * rendered with the shared `TrustBadge` component. Stacks vertically on
 * mobile, horizontal row with dividers on desktop.
 */
export function TrustBadgesSection({ className }: TrustBadgesSectionProps) {
  return (
    <section
      aria-label="VoltHaus guarantees"
      className={cn(
        "border-y border-border bg-card/30 py-8 md:py-10",
        className
      )}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 lg:divide-x lg:divide-y-0 lg:divide-border">
          {BADGES.map((badge, i) => (
            <div
              key={badge.title}
              className={cn(
                "px-0 lg:px-6",
                i === 0 ? "lg:pl-0" : "",
                i === BADGES.length - 1 ? "lg:pr-0" : ""
              )}
            >
              <TrustBadge
                icon={badge.icon}
                title={badge.title}
                description={badge.description}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default TrustBadgesSection;
