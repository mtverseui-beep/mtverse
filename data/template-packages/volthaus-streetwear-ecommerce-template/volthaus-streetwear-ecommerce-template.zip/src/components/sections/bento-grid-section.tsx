"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Bell,
  CreditCard,
  Crown,
  Heart,
  Layers,
  Lock,
  Ruler,
  Sparkles,
  Star,
  Users,
  Wallet,
} from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import { TiltCard } from "@/components/motion/tilt-card";
import { ScrollReveal } from "@/components/motion/scroll-reveal";
import { useToastStore } from "@/store/toast-store";
import { useUIStore } from "@/store/ui-store";
import { cn } from "@/lib/utils";

type AccentColor = "cyan" | "magenta" | "purple";

const ACCENT_HEX: Record<AccentColor, string> = {
  cyan: "#00E5FF",
  magenta: "#FF2ED1",
  purple: "#8B5CF6",
};

const ACCENT_CLASSES: Record<AccentColor, { text: string; bg: string; border: string }> = {
  cyan: {
    text: "text-primary",
    bg: "bg-primary/15",
    border: "border-primary/40",
  },
  magenta: {
    text: "text-secondary",
    bg: "bg-secondary/15",
    border: "border-secondary/40",
  },
  purple: {
    text: "text-accent",
    bg: "bg-accent/15",
    border: "border-accent/40",
  },
};

export interface BentoGridSectionProps {
  className?: string;
}

/**
 * Bento grid section. Six feature cards in a 12-column grid layout, each
 * with 3D tilt + cursor-tracking shine via `TiltCard`, plus a unique
 * internal UI per card. Matches the original source's bento DNA.
 */
export function BentoGridSection({ className }: BentoGridSectionProps) {
  return (
    <section
      id="bento"
      className={cn("relative overflow-hidden bg-background py-20 md:py-28", className)}
      aria-label="Why VoltHaus"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 grid-bg opacity-30"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-32 top-0 h-72 w-72 rounded-full bg-accent/10 blur-3xl"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
        <ScrollReveal className="mb-10 max-w-2xl">
          <div className="mb-3 inline-flex items-center gap-2.5">
            <span aria-hidden className="h-px w-8 bg-primary/70" />
            <span className="font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-primary">
              Why VoltHaus
            </span>
          </div>
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-5xl lg:text-[3.25rem]">
            Built for the{" "}
            <span className="text-gradient-primary">drop culture</span>
          </h2>
          <p className="mt-3 text-base text-muted-foreground md:text-lg">
            Real-time drops, outfit builder, creator capsules, secure checkout,
            and a member rewards club that actually rewards you.
          </p>
        </ScrollReveal>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-12 lg:gap-5">
          {/* 1. Limited Drop Engine — wide card */}
          <ScrollReveal delay={0.05} className="lg:col-span-7">
            <DropEngineCard accent="cyan" />
          </ScrollReveal>

          {/* 2. Outfit Builder — narrow card */}
          <ScrollReveal delay={0.1} className="lg:col-span-5">
            <OutfitBuilderCard accent="magenta" />
          </ScrollReveal>

          {/* 3. Size & Fit Guide */}
          <ScrollReveal delay={0.15} className="lg:col-span-4">
            <SizeGuideCard accent="purple" />
          </ScrollReveal>

          {/* 4. Creator Capsules */}
          <ScrollReveal delay={0.2} className="lg:col-span-4">
            <CreatorCapsulesCard accent="cyan" />
          </ScrollReveal>

          {/* 5. Fast Checkout */}
          <ScrollReveal delay={0.25} className="lg:col-span-4">
            <FastCheckoutCard accent="magenta" />
          </ScrollReveal>

          {/* 6. Rewards Club — wide card */}
          <ScrollReveal delay={0.3} className="lg:col-span-12">
            <RewardsClubCard accent="purple" />
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}

// ---------------- Individual bento cards ----------------

interface BentoCardShellProps {
  accent: AccentColor;
  eyebrow: string;
  title: string;
  children: React.ReactNode;
  className?: string;
  /** Slot for a CTA rendered at the bottom of the card */
  cta?: React.ReactNode;
}

function BentoCardShell({
  accent,
  eyebrow,
  title,
  children,
  className,
  cta,
}: BentoCardShellProps) {
  const a = ACCENT_CLASSES[accent];
  const hex = ACCENT_HEX[accent];
  return (
    <TiltCard
      maxTilt={8}
      className={cn("h-full", className)}
      style={{ transformStyle: "preserve-3d" }}
    >
      <div className="group relative h-full overflow-hidden rounded-2xl border border-border bg-card p-5 md:p-6">
        {/* Animated accent border glow on hover */}
        <div
          aria-hidden
          className="pointer-events-none absolute -inset-px rounded-2xl opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          style={{
            background: `linear-gradient(135deg, ${hex}40, transparent, ${hex}40)`,
            filter: "blur(8px)",
          }}
        />

        <div className="relative z-10 flex h-full flex-col">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <p
                className={cn(
                  "font-mono text-[10px] font-semibold uppercase tracking-[0.18em]",
                  a.text
                )}
              >
                {eyebrow}
              </p>
              <h3 className="mt-1 text-lg font-bold tracking-tight text-foreground md:text-xl">
                {title}
              </h3>
            </div>
          </div>
          <div className="flex-1">{children}</div>
          {cta && <div className="mt-5">{cta}</div>}
        </div>
      </div>
    </TiltCard>
  );
}

// 1. Drop Engine
function DropEngineCard({ accent }: { accent: AccentColor }) {
  const addToast = useToastStore((s) => s.addToast);
  const prefersReduced = useReducedMotion();
  const a = ACCENT_CLASSES[accent];

  const [countdown, setCountdown] = React.useState({ d: 12, h: 4, m: 32, s: 18 });
  React.useEffect(() => {
    const id = window.setInterval(() => {
      setCountdown((c) => {
        let { d, h, m, s } = c;
        s -= 1;
        if (s < 0) { s = 59; m -= 1; }
        if (m < 0) { m = 59; h -= 1; }
        if (h < 0) { h = 23; d -= 1; }
        if (d < 0) { d = 0; h = 0; m = 0; s = 0; }
        return { d, h, m, s };
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const handleNotify = () => {
    addToast({
      title: "Subscribed to drop alerts",
      description: "We'll ping you 1 hour before the next drop goes live.",
      variant: "success",
    });
  };

  return (
    <BentoCardShell
      accent={accent}
      eyebrow="Real-time drops"
      title="Limited Drop Engine"
      cta={
        <button
          type="button"
          onClick={handleNotify}
          className={cn(
            "btn-shine inline-flex h-10 items-center justify-center gap-2 rounded-md border px-4 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            a.border,
            "bg-transparent text-foreground hover:bg-card"
          )}
        >
          <Bell className="h-4 w-4" />
          Notify me
        </button>
      }
    >
      <div className="grid grid-cols-4 gap-2">
        {[
          { label: "Days", value: countdown.d },
          { label: "Hours", value: countdown.h },
          { label: "Min", value: countdown.m },
          { label: "Sec", value: countdown.s },
        ].map((u) => (
          <div
            key={u.label}
            className="flex flex-col items-center rounded-lg border border-border bg-background/60 py-2.5"
          >
            <span className="font-mono text-2xl font-bold tabular-nums text-foreground">
              {String(u.value).padStart(2, "0")}
            </span>
            <span className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
              {u.label}
            </span>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-between rounded-lg border border-border bg-background/60 px-4 py-3">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Users className={cn("h-4 w-4", a.text)} />
          Waitlist
        </div>
        <div className="flex items-center gap-2">
          <motion.span
            aria-hidden
            className={cn("h-2 w-2 rounded-full", a.bg)}
            animate={
              prefersReduced ? undefined : { scale: [1, 1.3, 1], opacity: [1, 0.5, 1] }
            }
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          />
          <span className="text-sm font-semibold text-foreground">
            3,412 queued
          </span>
        </div>
      </div>
    </BentoCardShell>
  );
}

// 2. Outfit Builder
function OutfitBuilderCard({ accent }: { accent: AccentColor }) {
  const a = ACCENT_CLASSES[accent];
  const thumbs = [
    "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=240&q=80&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=240&q=80&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=240&q=80&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=240&q=80&auto=format&fit=crop",
  ];
  return (
    <BentoCardShell
      accent={accent}
      eyebrow="Style it your way"
      title="Outfit Builder"
      cta={
        <Link
          href="/outfit-builder"
          className={cn(
            "inline-flex h-10 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            a.text,
            "hover:underline"
          )}
        >
          Build a look
          <ArrowRight className="h-4 w-4" />
        </Link>
      }
    >
      <div className="grid grid-cols-2 gap-2">
        {thumbs.map((src, i) => (
          <div
            key={i}
            className="relative aspect-square overflow-hidden rounded-lg border border-border bg-muted/30"
          >
            <Image
              src={src}
              alt={`Outfit piece ${i + 1}`}
              fill
              sizes="120px"
              className="object-cover"
            />
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
        <Layers className={cn("h-4 w-4", a.text)} />
        Mix any 5 pieces · auto-applied bundle pricing
      </div>
    </BentoCardShell>
  );
}

// 3. Size Guide
function SizeGuideCard({ accent }: { accent: AccentColor }) {
  const a = ACCENT_CLASSES[accent];
  const openSizeGuide = useUIStore((s) => s.openSizeGuide);
  return (
    <BentoCardShell
      accent={accent}
      eyebrow="Fit first"
      title="Size & Fit Guide"
      cta={
        <button
          type="button"
          onClick={() => openSizeGuide()}
          className={cn(
            "inline-flex h-10 items-center justify-center gap-2 rounded-md border px-4 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            a.border,
            "bg-transparent text-foreground hover:bg-card"
          )}
        >
          <Ruler className="h-4 w-4" />
          Open guide
        </button>
      }
    >
      <div className="space-y-2">
        {[
          { size: "US 8", eu: "EU 41", cm: "26 cm" },
          { size: "US 9", eu: "EU 42.5", cm: "27 cm" },
          { size: "US 10", eu: "EU 44", cm: "28 cm" },
        ].map((row) => (
          <div
            key={row.size}
            className="flex items-center justify-between rounded-lg border border-border bg-background/60 px-3 py-2 text-xs"
          >
            <span className="font-semibold text-foreground">{row.size}</span>
            <span className="text-muted-foreground">{row.eu}</span>
            <span className={cn("font-mono", a.text)}>{row.cm}</span>
          </div>
        ))}
      </div>
    </BentoCardShell>
  );
}

// 4. Creator Capsules
function CreatorCapsulesCard({ accent }: { accent: AccentColor }) {
  const a = ACCENT_CLASSES[accent];
  const avatars = [
    "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&q=80&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&q=80&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=120&q=80&auto=format&fit=crop",
  ];
  return (
    <BentoCardShell
      accent={accent}
      eyebrow="Creator-led"
      title="Creator Capsules"
      cta={
        <Link
          href="/creators"
          className={cn(
            "inline-flex h-10 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            a.text,
            "hover:underline"
          )}
        >
          Meet creators
          <ArrowRight className="h-4 w-4" />
        </Link>
      }
    >
      <div className="flex items-center gap-3">
        <div className="flex -space-x-3">
          {avatars.map((src, i) => (
            <div
              key={i}
              className="relative h-12 w-12 overflow-hidden rounded-full border-2 border-card bg-muted/30"
            >
              <Image
                src={src}
                alt={`Creator ${i + 1} avatar`}
                fill
                sizes="48px"
                className="object-cover"
              />
            </div>
          ))}
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-foreground">
            6 creators · 14 capsules
          </p>
          <p className="text-xs text-muted-foreground">
            Photographers, skaters, dancers, designers.
          </p>
        </div>
      </div>
    </BentoCardShell>
  );
}

// 5. Fast Checkout
function FastCheckoutCard({ accent }: { accent: AccentColor }) {
  const a = ACCENT_CLASSES[accent];
  return (
    <BentoCardShell
      accent={accent}
      eyebrow="One-tap"
      title="Fast Checkout"
      cta={
        <Link
          href="/checkout"
          className={cn(
            "inline-flex h-10 items-center justify-center gap-2 rounded-md border px-4 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            a.border,
            "bg-transparent text-foreground hover:bg-card"
          )}
        >
          <Lock className="h-4 w-4" />
          Secure checkout
        </Link>
      }
    >
      <div className="space-y-2.5">
        <div className="flex items-center gap-3 rounded-lg border border-border bg-background/60 px-3 py-3">
          <div
            className={cn(
              "flex h-9 w-12 items-center justify-center rounded-md border",
              a.border,
              a.bg
            )}
          >
            <CreditCard className={cn("h-4 w-4", a.text)} />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground">Apple Pay</p>
            <p className="text-[11px] text-muted-foreground">
              One-tap, biometric
            </p>
          </div>
          <ArrowRight className="h-4 w-4 text-muted-foreground" />
        </div>
        <div className="flex items-center gap-3 rounded-lg border border-border bg-background/60 px-3 py-3">
          <div className="flex h-9 w-12 items-center justify-center rounded-md border border-border bg-muted/40">
            <Wallet className="h-4 w-4 text-foreground" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground">Card</p>
            <p className="text-[11px] text-muted-foreground">
              Visa · Mastercard · Amex
            </p>
          </div>
          <ArrowRight className="h-4 w-4 text-muted-foreground" />
        </div>
        <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
          <Lock className="h-3.5 w-3.5" />
          256-bit TLS · PCI-DSS compliant
        </div>
      </div>
    </BentoCardShell>
  );
}

// 6. Rewards Club
function RewardsClubCard({ accent }: { accent: AccentColor }) {
  const a = ACCENT_CLASSES[accent];
  return (
    <BentoCardShell
      accent={accent}
      eyebrow="Member rewards"
      title="Static Club"
      cta={
        <Link
          href="/rewards"
          className={cn(
            "btn-shine inline-flex h-10 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
          )}
        >
          <Crown className="h-4 w-4" />
          Join Static Club
        </Link>
      }
    >
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="sm:col-span-2">
          <div className="mb-2 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Pulse tier progress</span>
            <span className="font-mono text-foreground">1,240 / 2,000 pts</span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-muted">
            <motion.div
              className={cn("h-full rounded-full", a.bg)}
              initial={{ width: 0 }}
              whileInView={{ width: "62%" }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
          </div>
          <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
            {["Early access", "10% off first order", "Member-only drops", "Birthday gift"].map((b) => (
              <span
                key={b}
                className="inline-flex items-center gap-1 rounded-full border border-border bg-background/60 px-2.5 py-1"
              >
                <Sparkles className={cn("h-3 w-3", a.text)} />
                {b}
              </span>
            ))}
          </div>
        </div>
        <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-background/60 p-4 text-center">
          <Star className={cn("h-7 w-7", a.text)} />
          <p className="mt-1 text-sm font-semibold text-foreground">Pulse Tier</p>
          <p className="text-[11px] text-muted-foreground">
            760 pts to Static
          </p>
        </div>
      </div>
    </BentoCardShell>
  );
}

export default BentoGridSection;
