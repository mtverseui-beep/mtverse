"use client";

import type { ReactNode } from "react";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/sonner";
import ClickSpark from "@/components/click-spark";
import { LenisProvider } from "@/components/lenis-provider";
import { CartDrawer } from "@/components/ecommerce/cart-drawer";
import { SearchOverlay } from "@/components/layout/search-overlay";
import { QuickViewModal } from "@/components/product/quick-view-modal";
import { SizeGuideModal } from "@/components/product/size-guide-modal";
import { MobileMenu } from "@/components/layout/mobile-menu";
import { GoToTopButton } from "@/components/layout/go-to-top";
import { CookieBanner } from "@/components/layout/cookie-banner";
import { NewsletterPopup } from "@/components/layout/newsletter-popup";

export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="dark"
      enableSystem={false}
      disableTransitionOnChange={false}
      themes={["dark", "light"]}
    >
      <ClickSpark
        sparkColor="#00E5FF"
        sparkSize={12}
        sparkRadius={20}
        sparkCount={8}
        duration={400}
        easing="ease-out"
      >
        <LenisProvider>
          <div className="theme-transition min-h-screen flex flex-col">
            {children}
          </div>
          <CartDrawer />
          <SearchOverlay />
          <QuickViewModal />
          <SizeGuideModal />
          <MobileMenu />
          <GoToTopButton />
          <CookieBanner />
          <NewsletterPopup />
          <Toaster position="bottom-right" />
        </LenisProvider>
      </ClickSpark>
    </ThemeProvider>
  );
}
