"use client";

import * as React from "react";
import Link from "next/link";
import { Breadcrumbs, SectionHeading } from "@/components/common";
import { ProductCard } from "@/components/product";
import { ScrollReveal } from "@/components/motion";
import { Button } from "@/components/ui/button";
import type { Product } from "@/types";

export interface LimitedDropsPageProps {
  products: Product[];
}

function formatCountdown(target: string): string {
  const now = Date.now();
  const targetMs = new Date(target).getTime();
  const diff = targetMs - now;
  if (diff <= 0) return "Live now";
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  if (days > 0) return `${days}d ${hours}h ${minutes}m`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

export function LimitedDropsPage({ products }: LimitedDropsPageProps) {
  const [now, setNow] = React.useState(Date.now());
  React.useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const upcoming = products.filter((p) => p.dropStatus === "upcoming");
  const live = products.filter(
    (p) => p.dropStatus === "live" || p.dropStatus === "restock"
  );

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
      <Breadcrumbs items={[{ label: "Limited drops" }]} className="mb-6" />
      <SectionHeading
        eyebrow="Numbered runs"
        title="Limited drops"
        description="Small-batch capsules and numbered releases. Each piece ships with a collector drop card and ships in collector-grade packaging."
        className="mb-8"
      />

      {/* Upcoming countdowns */}
      {upcoming.length > 0 && (
        <section className="mb-10">
          <h2 className="mb-4 text-lg font-bold text-foreground">
            Upcoming drops
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {upcoming.map((p) => (
              <div
                key={p.id}
                className="rounded-xl border border-secondary/40 bg-secondary/5 p-4"
              >
                <p className="text-[11px] font-semibold uppercase tracking-wider text-secondary">
                  Drops in
                </p>
                <p className="mt-1 font-mono text-2xl font-black tabular-nums text-foreground">
                  {p.dropDate ? formatCountdown(p.dropDate) : "Soon"}
                </p>
                <p className="mt-2 text-sm font-semibold text-foreground">
                  {p.name}
                </p>
                <p className="text-xs text-muted-foreground">{p.collection}</p>
                <Button asChild size="sm" variant="outline" className="mt-3 w-full">
                  <Link href={`/product/${p.slug}`}>View details</Link>
                </Button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Live drops */}
      {live.length > 0 && (
        <section>
          <h2 className="mb-4 text-lg font-bold text-foreground">
            Live limited drops
          </h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {live.map((p, i) => (
              <ScrollReveal key={p.id} delay={Math.min(i * 0.04, 0.32)}>
                <ProductCard product={p} priority={i < 4} />
              </ScrollReveal>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

export default LimitedDropsPage;
