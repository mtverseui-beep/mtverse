"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  ChevronDown,
  Gift,
  Minus,
  Plus,
  ShoppingBag,
  Tag,
  Trash2,
  X,
} from "lucide-react";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { useMounted, useReducedMotion } from "@/hooks";
import { FreeShippingProgress } from "@/components/ecommerce/free-shipping-progress";
import { cn } from "@/lib/utils";
import type { CartItem } from "@/types";

const FREE_SHIPPING_THRESHOLD = 100;
const DEFAULT_SHIPPING = 9.95;
const TAX_RATE = 0.08;

function formatPrice(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(value);
}

interface CartLineProps {
  item: CartItem;
  onIncrement: () => void;
  onDecrement: () => void;
  onRemove: () => void;
  onSaveForLater: () => void;
}

function CartLine({
  item,
  onIncrement,
  onDecrement,
  onRemove,
  onSaveForLater,
}: CartLineProps) {
  return (
    <li className="flex gap-3 py-4">
      <Link
        href={`/products/${item.slug}`}
        className="group relative size-20 shrink-0 overflow-hidden rounded-md border border-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
      >
        <Image
          src={item.image}
          alt={item.name}
          fill
          sizes="80px"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </Link>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start justify-between gap-2">
          <Link
            href={`/products/${item.slug}`}
            className="line-clamp-2 text-sm font-medium text-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
          >
            {item.name}
          </Link>
          <button
            type="button"
            onClick={onRemove}
            aria-label={`Remove ${item.name}`}
            className="inline-flex size-7 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted/40 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <Trash2 className="size-4" aria-hidden="true" />
          </button>
        </div>

        <p className="mt-1 font-mono text-xs text-muted-foreground">
          {item.category}
        </p>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Size <span className="text-foreground/80">{item.size}</span>
          <span className="mx-1.5 text-border">/</span>
          Color <span className="text-foreground/80">{item.color}</span>
        </p>

        <div className="mt-2 flex items-center justify-between gap-2">
          <div className="flex items-center rounded-full border border-border">
            <button
              type="button"
              onClick={onDecrement}
              aria-label={`Decrease quantity of ${item.name}`}
              className="inline-flex size-7 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <Minus className="size-3.5" aria-hidden="true" />
            </button>
            <span
              aria-live="polite"
              aria-atomic="true"
              className="min-w-7 text-center text-sm font-medium text-foreground"
            >
              {item.quantity}
            </span>
            <button
              type="button"
              onClick={onIncrement}
              aria-label={`Increase quantity of ${item.name}`}
              className="inline-flex size-7 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <Plus className="size-3.5" aria-hidden="true" />
            </button>
          </div>

          <div className="text-right">
            <p className="text-sm font-semibold text-foreground">
              {formatPrice(item.price * item.quantity)}
            </p>
            {item.quantity > 1 ? (
              <p className="font-mono text-[10px] text-muted-foreground">
                {formatPrice(item.price)} each
              </p>
            ) : null}
          </div>
        </div>

        <button
          type="button"
          onClick={onSaveForLater}
          className="mt-2 self-start text-[11px] text-muted-foreground underline-offset-2 transition-colors hover:text-primary hover:underline focus-visible:outline-none focus-visible:underline"
        >
          Save for later
        </button>
      </div>
    </li>
  );
}

interface SavedLineProps {
  item: CartItem;
  onMoveToCart: () => void;
}

function SavedLine({ item, onMoveToCart }: SavedLineProps) {
  return (
    <li className="flex items-center gap-3 py-3">
      <div className="relative size-12 shrink-0 overflow-hidden rounded-md border border-border">
        <Image
          src={item.image}
          alt={item.name}
          fill
          sizes="48px"
          className="object-cover"
        />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm text-foreground">{item.name}</p>
        <p className="font-mono text-xs text-muted-foreground">
          {item.size} / {item.color}
        </p>
      </div>
      <button
        type="button"
        onClick={onMoveToCart}
        className="rounded-full border border-border px-3 py-1 text-xs text-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
      >
        Move to cart
      </button>
    </li>
  );
}

interface CollapsibleSectionProps {
  title: string;
  icon: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
}

function CollapsibleSection({
  title,
  icon,
  defaultOpen = false,
  children,
}: CollapsibleSectionProps) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-t border-border">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-center justify-between py-3 text-sm text-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
      >
        <span className="flex items-center gap-2">
          {icon}
          {title}
        </span>
        <ChevronDown
          className={cn(
            "size-4 text-muted-foreground transition-transform",
            open && "rotate-180"
          )}
          aria-hidden="true"
        />
      </button>
      <AnimatePresence initial={false}>
        {open ? (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.24, ease: "easeOut" }}
            className="overflow-hidden"
          >
            <div className="pb-4">{children}</div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}

export interface CartDrawerProps {
  className?: string;
}

export function CartDrawer({ className }: CartDrawerProps) {
  const isOpen = useCartStore((s) => s.isCartOpen);
  const closeCart = useCartStore((s) => s.closeCart);
  const items = useCartStore((s) => s.items);
  const savedItems = useCartStore((s) => s.savedItems);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const removeItem = useCartStore((s) => s.removeItem);
  const saveForLater = useCartStore((s) => s.saveForLater);
  const moveToCart = useCartStore((s) => s.moveToCart);
  const subtotal = useCartStore((s) => s.subtotal());
  const itemCount = useCartStore((s) => s.itemCount());
  const coupon = useCartStore((s) => s.coupon);
  const applyCoupon = useCartStore((s) => s.applyCoupon);
  const removeCoupon = useCartStore((s) => s.removeCoupon);
  const giftCard = useCartStore((s) => s.giftCard);
  const applyGiftCard = useCartStore((s) => s.applyGiftCard);
  const removeGiftCard = useCartStore((s) => s.removeGiftCard);
  const orderNotes = useCartStore((s) => s.orderNotes);
  const setOrderNotes = useCartStore((s) => s.setOrderNotes);

  const addToast = useToastStore((s) => s.addToast);

  const pathname = usePathname();
  const reducedMotion = useReducedMotion();
  const mounted = useMounted();

  const [couponInput, setCouponInput] = useState("");
  const [couponError, setCouponError] = useState<string | null>(null);
  const [giftInput, setGiftInput] = useState("");
  const [giftError, setGiftError] = useState<string | null>(null);

  // Lock body scroll when open
  useEffect(() => {
    if (!isOpen) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeCart();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, closeCart]);

  // Close on route change
  useEffect(() => {
    closeCart();
  }, [pathname, closeCart]);

  const showItems = mounted ? items : [];
  const showSaved = mounted ? savedItems : [];
  const showCount = mounted ? itemCount : 0;
  const showSubtotal = mounted ? subtotal : 0;

  const discount = coupon ? (showSubtotal * coupon.discountPercent) / 100 : 0;
  const giftCardValue = giftCard ? Math.min(giftCard.amount, showSubtotal - discount) : 0;
  const afterDiscount = Math.max(0, showSubtotal - discount);
  const shipping = afterDiscount >= FREE_SHIPPING_THRESHOLD || afterDiscount === 0 ? 0 : DEFAULT_SHIPPING;
  const tax = Math.max(0, (afterDiscount + shipping) * TAX_RATE);
  const total = Math.max(0, afterDiscount + shipping + tax - giftCardValue);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const code = couponInput.trim();
    if (!code) return;
    const ok = applyCoupon(code);
    if (ok) {
      setCouponError(null);
      setCouponInput("");
      addToast({
        title: "Coupon applied",
        description: `${coupon?.discountPercent ?? 0}% off your order.`,
        variant: "success",
      });
    } else {
      setCouponError("That code didn't work. Try VOLTHAUS10, DROP15, or STATIC20.");
    }
  };

  const handleApplyGiftCard = (e: React.FormEvent) => {
    e.preventDefault();
    const code = giftInput.trim();
    if (!code) return;
    const ok = applyGiftCard(code);
    if (ok) {
      setGiftError(null);
      setGiftInput("");
      addToast({
        title: "Gift card applied",
        description: "Your gift card balance has been applied.",
        variant: "success",
      });
    } else {
      setGiftError("That gift card code is not valid. Try GIFT50.");
    }
  };

  const handleRemoveItem = (item: CartItem) => {
    removeItem(item.productId, item.size, item.color);
    addToast({
      title: "Removed from cart",
      description: `${item.name} (${item.size}, ${item.color})`,
      variant: "default",
    });
  };

  const handleSaveForLater = (item: CartItem) => {
    saveForLater(item.productId, item.size, item.color);
    addToast({
      title: "Saved for later",
      description: item.name,
      variant: "default",
    });
  };

  const handleMoveToCart = (item: CartItem) => {
    moveToCart(item.productId, item.size, item.color);
    addToast({
      title: "Moved to cart",
      description: item.name,
      variant: "success",
    });
  };

  const panelVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
    : {
        initial: { x: "100%" },
        animate: { x: 0 },
        exit: { x: "100%" },
      };

  return (
    <AnimatePresence>
      {isOpen ? (
        <motion.div
          key="cart-drawer"
          className="fixed inset-0 z-[85]"
          aria-modal="true"
          role="dialog"
          aria-label="Shopping cart"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 bg-background/80 backdrop-blur-sm"
            onClick={closeCart}
            aria-hidden="true"
          />

          <motion.div
            {...panelVariants}
            transition={{ type: "tween", duration: 0.32, ease: "easeOut" }}
            className={cn(
              "bg-background absolute inset-y-0 right-0 flex w-full max-w-[420px] flex-col border-l border-border",
              className
            )}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div>
                <h2 className="text-sm font-semibold text-foreground">Your Cart</h2>
                <p className="font-mono text-xs text-muted-foreground">
                  {showCount} {showCount === 1 ? "item" : "items"}
                </p>
              </div>
              <button
                type="button"
                onClick={closeCart}
                aria-label="Close cart"
                className="inline-flex size-10 items-center justify-center rounded-md text-foreground transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <X className="size-5" aria-hidden="true" />
              </button>
            </div>

            {showItems.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
                <span
                  className="mb-4 inline-flex size-14 items-center justify-center rounded-full border border-border text-muted-foreground"
                  aria-hidden="true"
                >
                  <ShoppingBag className="size-6" />
                </span>
                <p className="text-sm font-medium text-foreground">
                  Your cart is empty
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Drop something in before it sells out.
                </p>
                <Link
                  href="/shop"
                  onClick={closeCart}
                  className="btn-shine mt-5 inline-flex h-10 items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                >
                  Browse drops
                </Link>
              </div>
            ) : (
              <>
                {/* Free shipping progress */}
                <div className="border-b border-border px-4 py-3">
                  <FreeShippingProgress
                    subtotal={afterDiscount}
                    threshold={FREE_SHIPPING_THRESHOLD}
                  />
                </div>

                {/* Cart lines */}
                <div className="flex-1 overflow-y-auto px-4 no-scrollbar">
                  <ul className="divide-y divide-border">
                    {showItems.map((item) => (
                      <CartLine
                        key={`${item.productId}-${item.size}-${item.color}`}
                        item={item}
                        onIncrement={() =>
                          updateQuantity(item.productId, item.size, item.color, item.quantity + 1)
                        }
                        onDecrement={() =>
                          updateQuantity(item.productId, item.size, item.color, item.quantity - 1)
                        }
                        onRemove={() => handleRemoveItem(item)}
                        onSaveForLater={() => handleSaveForLater(item)}
                      />
                    ))}
                  </ul>

                  {/* Saved for later */}
                  {showSaved.length > 0 ? (
                    <section className="border-t border-border py-4">
                      <h3 className="mb-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                        Saved for later ({showSaved.length})
                      </h3>
                      <ul className="divide-y divide-border/60">
                        {showSaved.map((item) => (
                          <SavedLine
                            key={`saved-${item.productId}-${item.size}-${item.color}`}
                            item={item}
                            onMoveToCart={() => handleMoveToCart(item)}
                          />
                        ))}
                      </ul>
                    </section>
                  ) : null}

                  {/* Collapsibles: coupon, gift card, notes */}
                  <CollapsibleSection
                    title="Coupon code"
                    icon={<Tag className="size-4 text-muted-foreground" aria-hidden="true" />}
                  >
                    {coupon ? (
                      <div className="flex items-center justify-between rounded-md border border-border bg-muted/30 px-3 py-2">
                        <div>
                          <p className="text-xs font-medium text-foreground">{coupon.code}</p>
                          <p className="font-mono text-[10px] text-primary">
                            {coupon.discountPercent}% off applied
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            removeCoupon();
                            addToast({
                              title: "Coupon removed",
                              variant: "default",
                            });
                          }}
                          className="text-xs text-muted-foreground underline-offset-2 hover:text-destructive hover:underline focus-visible:outline-none focus-visible:underline"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <form onSubmit={handleApplyCoupon} className="flex gap-2">
                        <input
                          type="text"
                          value={couponInput}
                          onChange={(e) => setCouponInput(e.target.value)}
                          placeholder="VOLTHAUS10"
                          aria-label="Coupon code"
                          className="h-9 flex-1 rounded-md border border-input bg-input/30 px-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                        />
                        <button
                          type="submit"
                          className="inline-flex h-9 items-center rounded-md bg-foreground px-4 text-sm font-medium text-background transition-colors hover:bg-primary hover:text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                        >
                          Apply
                        </button>
                      </form>
                    )}
                    {couponError ? (
                      <p className="mt-2 text-xs text-destructive" role="alert">
                        {couponError}
                      </p>
                    ) : null}
                  </CollapsibleSection>

                  <CollapsibleSection
                    title="Gift card"
                    icon={<Gift className="size-4 text-muted-foreground" aria-hidden="true" />}
                  >
                    {giftCard ? (
                      <div className="flex items-center justify-between rounded-md border border-border bg-muted/30 px-3 py-2">
                        <div>
                          <p className="text-xs font-medium text-foreground">{giftCard.code}</p>
                          <p className="font-mono text-[10px] text-primary">
                            {formatPrice(giftCard.amount)} balance
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            removeGiftCard();
                            addToast({
                              title: "Gift card removed",
                              variant: "default",
                            });
                          }}
                          className="text-xs text-muted-foreground underline-offset-2 hover:text-destructive hover:underline focus-visible:outline-none focus-visible:underline"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <form onSubmit={handleApplyGiftCard} className="flex gap-2">
                        <input
                          type="text"
                          value={giftInput}
                          onChange={(e) => setGiftInput(e.target.value)}
                          placeholder="GIFT50"
                          aria-label="Gift card code"
                          className="h-9 flex-1 rounded-md border border-input bg-input/30 px-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                        />
                        <button
                          type="submit"
                          className="inline-flex h-9 items-center rounded-md bg-foreground px-4 text-sm font-medium text-background transition-colors hover:bg-primary hover:text-primary-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                        >
                          Apply
                        </button>
                      </form>
                    )}
                    {giftError ? (
                      <p className="mt-2 text-xs text-destructive" role="alert">
                        {giftError}
                      </p>
                    ) : null}
                  </CollapsibleSection>

                  <CollapsibleSection
                    title="Order notes"
                    icon={<Tag className="size-4 text-muted-foreground" aria-hidden="true" />}
                  >
                    <textarea
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      placeholder="Add a note for the warehouse (optional)..."
                      aria-label="Order notes"
                      rows={3}
                      className="w-full resize-none rounded-md border border-input bg-input/30 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                    />
                  </CollapsibleSection>

                  {/* Summary */}
                  <div className="border-t border-border py-4">
                    <dl className="space-y-1.5 text-sm">
                      <div className="flex justify-between text-muted-foreground">
                        <dt>Subtotal</dt>
                        <dd className="font-mono text-foreground">
                          {formatPrice(showSubtotal)}
                        </dd>
                      </div>
                      {discount > 0 ? (
                        <div className="flex justify-between text-primary">
                          <dt>Coupon ({coupon?.code})</dt>
                          <dd className="font-mono">-{formatPrice(discount)}</dd>
                        </div>
                      ) : null}
                      <div className="flex justify-between text-muted-foreground">
                        <dt>Shipping</dt>
                        <dd className="font-mono text-foreground">
                          {shipping === 0 ? "Free" : formatPrice(shipping)}
                        </dd>
                      </div>
                      <div className="flex justify-between text-muted-foreground">
                        <dt>Estimated tax</dt>
                        <dd className="font-mono text-foreground">{formatPrice(tax)}</dd>
                      </div>
                      {giftCardValue > 0 ? (
                        <div className="flex justify-between text-primary">
                          <dt>Gift card</dt>
                          <dd className="font-mono">-{formatPrice(giftCardValue)}</dd>
                        </div>
                      ) : null}
                      <div className="mt-2 flex justify-between border-t border-border pt-2 text-base font-semibold text-foreground">
                        <dt>Total</dt>
                        <dd className="font-mono">{formatPrice(total)}</dd>
                      </div>
                    </dl>
                  </div>

                  <div className="space-y-2 pb-6 pt-2">
                    <Link
                      href="/checkout"
                      onClick={closeCart}
                      className="btn-shine flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                    >
                      Checkout
                      <ArrowRight className="size-4" aria-hidden="true" />
                    </Link>
                    <button
                      type="button"
                      onClick={closeCart}
                      className="w-full text-center text-xs text-muted-foreground underline-offset-2 transition-colors hover:text-foreground hover:underline focus-visible:outline-none focus-visible:underline"
                    >
                      Continue shopping
                    </button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

export default CartDrawer;
