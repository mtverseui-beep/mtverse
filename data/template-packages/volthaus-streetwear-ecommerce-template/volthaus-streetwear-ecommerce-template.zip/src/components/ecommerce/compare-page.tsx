"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { GitCompare, ShoppingBag, Star, X } from "lucide-react";
import { useCompareStore } from "@/store/compare-store";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { useMounted } from "@/hooks";
import { getProductBySlug } from "@/data/products";
import {
  Breadcrumbs,
  EmptyState,
  PriceDisplay,
  SectionHeading,
  StarRating,
} from "@/components/common";
import { Button } from "@/components/ui/button";
import type { CompareItem, ProductCategory } from "@/types";

const ATTRIBUTE_ROWS: { key: string; label: string }[] = [
  { key: "price", label: "Price" },
  { key: "dropStatus", label: "Drop status" },
  { key: "rating", label: "Rating" },
  { key: "colors", label: "Colors" },
  { key: "sizes", label: "Sizes" },
  { key: "materials", label: "Materials" },
  { key: "fit", label: "Fit" },
  { key: "category", label: "Category" },
];

export function ComparePage() {
  const mounted = useMounted();
  const items = useCompareStore((s) => s.items);
  const removeItem = useCompareStore((s) => s.removeItem);
  const clear = useCompareStore((s) => s.clear);
  const addItem = useCartStore((s) => s.addItem);
  const openCart = useCartStore((s) => s.openCart);
  const addToast = useToastStore((s) => s.addToast);

  const handleAddToCart = (item: CompareItem) => {
    const product = getProductBySlug(item.slug);
    addItem({
      productId: item.productId,
      slug: item.slug,
      name: item.name,
      image: item.image,
      price: item.price,
      size: item.sizes[0] ?? "One Size",
      color: item.colors[0]?.name ?? "Default",
      quantity: 1,
      category: (product?.category ?? "Accessories") as ProductCategory,
    });
    addToast({
      title: "Added to cart",
      description: item.name,
      variant: "success",
    });
    openCart();
  };

  if (!mounted) {
    return (
      <div className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <p className="text-sm text-muted-foreground">Loading comparison…</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
      <Breadcrumbs items={[{ label: "Compare" }]} className="mb-6" />

      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <SectionHeading
          eyebrow="Side by side"
          title="Compare products"
          description="Stack up to four products to see how they compare on price, materials, fit, and more."
          className="mb-0"
        />
        {items.length > 0 && (
          <Button
            variant="outline"
            onClick={() => {
              clear();
              addToast({ title: "Comparison cleared", variant: "default" });
            }}
          >
            Clear all
          </Button>
        )}
      </div>

      {items.length === 0 ? (
        <EmptyState
          icon={<GitCompare className="h-6 w-6" />}
          title="Nothing to compare yet"
          description="Tap the compare icon on any product card to add it here. You can compare up to four products at once."
          action={
            <Button asChild>
              <Link href="/shop">Browse drops</Link>
            </Button>
          }
        />
      ) : (
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full min-w-[640px] border-separate border-spacing-0">
            <thead>
              <tr>
                <th className="sticky left-0 z-10 w-32 bg-background p-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Attribute
                </th>
                {items.map((item) => (
                  <th key={item.productId} className="p-3 align-top">
                    <div className="relative aspect-square overflow-hidden rounded-md border border-border bg-muted/30">
                      <button
                        type="button"
                        onClick={() => {
                          removeItem(item.productId);
                          addToast({
                            title: "Removed from compare",
                            variant: "default",
                          });
                        }}
                        aria-label={`Remove ${item.name} from compare`}
                        className="absolute right-2 top-2 z-10 inline-flex h-7 w-7 items-center justify-center rounded-full border border-border bg-background/80 text-muted-foreground hover:text-destructive"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                      <Link
                        href={`/product/${item.slug}`}
                        aria-label={`View ${item.name}`}
                      >
                        <Image
                          src={item.image}
                          alt={item.name}
                          fill
                          sizes="220px"
                          className="object-cover"
                        />
                      </Link>
                    </div>
                    <Link
                      href={`/product/${item.slug}`}
                      className="mt-2 block line-clamp-1 text-sm font-semibold text-foreground hover:text-primary"
                    >
                      {item.name}
                    </Link>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ATTRIBUTE_ROWS.map((row, ri) => (
                <tr key={row.key} className={ri % 2 === 1 ? "bg-muted/10" : ""}>
                  <th
                    scope="row"
                    className="sticky left-0 z-10 bg-background p-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground"
                  >
                    {row.label}
                  </th>
                  {items.map((item) => (
                    <td key={`${item.productId}-${row.key}`} className="p-3 align-top text-sm">
                      <CompareCell item={item} attr={row.key} />
                    </td>
                  ))}
                </tr>
              ))}
              {/* Add-to-cart row */}
              <tr>
                <th className="sticky left-0 z-10 bg-background p-3" />
                {items.map((item) => (
                  <td key={`cta-${item.productId}`} className="p-3">
                    <Button
                      size="sm"
                      onClick={() => handleAddToCart(item)}
                      className="btn-shine w-full"
                    >
                      <ShoppingBag className="h-3.5 w-3.5" />
                      Add to cart
                    </Button>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function CompareCell({ item, attr }: { item: CompareItem; attr: string }) {
  switch (attr) {
    case "price":
      return <PriceDisplay price={item.price} compareAtPrice={item.compareAtPrice} size="sm" />;
    case "dropStatus":
      return (
        <span className="capitalize text-foreground">
          {item.dropStatus.replace("-", " ")}
        </span>
      );
    case "rating":
      return (
        <div className="flex items-center gap-2">
          <StarRating rating={item.rating} size={12} />
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3 w-3 fill-primary text-primary" />
            {item.rating.toFixed(1)} ({item.reviewCount})
          </span>
        </div>
      );
    case "colors":
      return (
        <div className="flex flex-wrap gap-1.5">
          {item.colors.map((c) => (
            <span
              key={c.name}
              title={c.name}
              aria-label={c.name}
              className="inline-block h-4 w-4 rounded-full border border-white/25"
              style={{ backgroundColor: c.hex }}
            />
          ))}
        </div>
      );
    case "sizes":
      return (
        <div className="flex flex-wrap gap-1 text-xs text-muted-foreground">
          {item.sizes.slice(0, 6).map((s) => (
            <span
              key={s}
              className="inline-flex h-6 min-w-6 items-center justify-center rounded border border-border px-1"
            >
              {s}
            </span>
          ))}
          {item.sizes.length > 6 && (
            <span className="text-xs">+{item.sizes.length - 6}</span>
          )}
        </div>
      );
    case "materials":
      return (
        <ul className="flex flex-col gap-1 text-xs text-muted-foreground">
          {item.materials.slice(0, 3).map((m) => (
            <li key={m} className="line-clamp-1">{m}</li>
          ))}
          {item.materials.length > 3 && (
            <li className="text-xs">+{item.materials.length - 3} more</li>
          )}
        </ul>
      );
    case "fit":
      return <span className="text-xs text-muted-foreground">{item.fit}</span>;
    case "category":
      return <span className="text-foreground">{item.category}</span>;
    default:
      return null;
  }
}

export default ComparePage;
