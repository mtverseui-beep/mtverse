"use client";

import { useState, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { RotateCcw, ShoppingBag, Check, Sparkles } from "lucide-react";
import { outfitBuilderOptions } from "@/data/outfitBuilder";
import { getProductBySlug } from "@/data/products";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { useMounted } from "@/hooks";
import { cn } from "@/lib/utils";
import type { Product } from "@/types";

type SlotKey = "sneakers" | "hoodies" | "tees" | "pants" | "accessories";

const SLOT_LABELS: Record<SlotKey, string> = {
  sneakers: "Sneaker",
  hoodies: "Hoodie",
  tees: "Tee",
  pants: "Pants",
  accessories: "Accessory",
};

const SLOT_ICONS: Record<SlotKey, string> = {
  sneakers: "S",
  hoodies: "H",
  tees: "T",
  pants: "P",
  accessories: "A",
};

export function OutfitBuilder() {
  const mounted = useMounted();
  const addItem = useCartStore((s) => s.addItem);
  const openCart = useCartStore((s) => s.openCart);
  const addToast = useToastStore((s) => s.addToast);

  const [selections, setSelections] = useState<Record<SlotKey, string | null>>({
    sneakers: null,
    hoodies: null,
    tees: null,
    pants: null,
    accessories: null,
  });

  const [activeSlot, setActiveSlot] = useState<SlotKey>("sneakers");

  const selectedProducts = useMemo(() => {
    const result: Record<SlotKey, Product | null> = {
      sneakers: null,
      hoodies: null,
      tees: null,
      pants: null,
      accessories: null,
    };
    (Object.keys(selections) as SlotKey[]).forEach((key) => {
      const slug = selections[key];
      if (slug) {
        const p = getProductBySlug(slug);
        if (p) result[key] = p;
      }
    });
    return result;
  }, [selections]);

  const totalPrice = useMemo(() => {
    return (Object.keys(selectedProducts) as SlotKey[]).reduce((sum, key) => {
      const p = selectedProducts[key];
      return sum + (p?.price ?? 0);
    }, 0);
  }, [selectedProducts]);

  const totalCompareAt = useMemo(() => {
    return (Object.keys(selectedProducts) as SlotKey[]).reduce((sum, key) => {
      const p = selectedProducts[key];
      return sum + (p?.compareAtPrice ?? p?.price ?? 0);
    }, 0);
  }, [selectedProducts]);

  const selectedCount = (Object.keys(selectedProducts) as SlotKey[]).filter(
    (k) => selectedProducts[k] !== null,
  ).length;

  const handleSelectOption = (slot: SlotKey, slug: string) => {
    setSelections((prev) => ({ ...prev, [slot]: prev[slot] === slug ? null : slug }));
  };

  const handleReset = () => {
    setSelections({
      sneakers: null,
      hoodies: null,
      tees: null,
      pants: null,
      accessories: null,
    });
    addToast({ title: "Outfit cleared", variant: "default" });
  };

  const handleAddOutfitToCart = () => {
    if (selectedCount === 0) return;
    (Object.keys(selectedProducts) as SlotKey[]).forEach((key) => {
      const p = selectedProducts[key];
      if (p) {
        addItem({
          productId: p.id,
          slug: p.slug,
          name: p.name,
          image: p.images[0] ?? "",
          price: p.price,
          size: p.sizes[0] ?? "One Size",
          color: p.colors[0]?.name ?? "Default",
          quantity: 1,
          category: p.category,
        });
      }
    });
    addToast({
      title: "Outfit added to cart",
      description: `${selectedCount} item${selectedCount > 1 ? "s" : ""} added`,
      variant: "success",
    });
    openCart();
  };

  const currentOptions = outfitBuilderOptions[activeSlot];

  return (
    <div className="grid lg:grid-cols-[1fr_380px] gap-6 lg:gap-10">
      {/* Builder */}
      <div>
        {/* Slot tabs */}
        <div className="flex flex-wrap gap-2 mb-6">
          {(Object.keys(SLOT_LABELS) as SlotKey[]).map((slot) => (
            <button
              key={slot}
              onClick={() => setActiveSlot(slot)}
              className={cn(
                "px-4 h-10 rounded-full text-xs font-mono uppercase tracking-wider border transition-all flex items-center gap-2",
                activeSlot === slot
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground",
              )}
            >
              <span
                className={cn(
                  "inline-flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold",
                  selections[slot]
                    ? "bg-success/20 text-success"
                    : activeSlot === slot
                      ? "bg-primary-foreground/20 text-primary-foreground"
                      : "bg-muted text-muted-foreground",
                )}
              >
                {selections[slot] ? <Check className="h-3 w-3" /> : SLOT_ICONS[slot]}
              </span>
              {SLOT_LABELS[slot]}
            </button>
          ))}
        </div>

        {/* Options grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <AnimatePresence mode="popLayout">
            {currentOptions.map((opt, i) => {
              const product = getProductBySlug(opt.productSlug);
              if (!product) return null;
              const isSelected = selections[activeSlot] === product.slug;
              return (
                <motion.button
                  key={product.slug}
                  layout
                  initial={{ opacity: 0, scale: 0.92 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.92 }}
                  transition={{ delay: i * 0.04, duration: 0.25 }}
                  onClick={() => handleSelectOption(activeSlot, product.slug)}
                  className={cn(
                    "group relative aspect-square rounded-xl overflow-hidden border-2 bg-card text-left transition-all",
                    isSelected
                      ? "border-primary glow-primary"
                      : "border-border hover:border-primary/40",
                  )}
                >
                  <div className="absolute inset-0">
                    <Image
                      src={product.images[0]}
                      alt={product.name}
                      fill
                      sizes="(max-width: 640px) 50vw, 33vw"
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute top-2 right-2">
                    {isSelected ? (
                      <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground">
                        <Check className="h-4 w-4" />
                      </span>
                    ) : (
                      <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-black/40 text-white opacity-0 group-hover:opacity-100 transition-opacity">
                        +
                      </span>
                    )}
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 p-3">
                    <p className="text-[10px] font-mono uppercase tracking-wider text-primary">
                      {product.collection}
                    </p>
                    <p className="text-xs font-bold text-white leading-tight line-clamp-1">
                      {product.name}
                    </p>
                    <p className="text-xs text-white/70 mt-0.5">${product.price}</p>
                  </div>
                </motion.button>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Recommended pairings */}
        <div className="mt-10 rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-bold">Recommended pairings</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-4">
            Curated outfit combinations from the VoltHaus studio. Tap a preset to load it.
          </p>
          <div className="grid sm:grid-cols-3 gap-3">
            {[
              { name: "After Dark", slugs: ["midnight-runner-high", "static-club-hoodie", "archive-black-tee", "chrome-district-cargo", "pulse-knit-beanie"] },
              { name: "Neon Court", slugs: ["volt-runner-01", "concrete-bloom-hoodie", "concrete-bloom-tee", "midnight-cargo-shorts", "signal-cap"] },
              { name: "Static Club", slugs: ["neon-court-low", "static-club-hoodie", "signal-drop-tee", "chrome-district-cargo", "flux-crossbody-bag"] },
            ].map((preset) => (
              <button
                key={preset.name}
                onClick={() => {
                  setSelections({
                    sneakers: preset.slugs[0],
                    hoodies: preset.slugs[1],
                    tees: preset.slugs[2],
                    pants: preset.slugs[3],
                    accessories: preset.slugs[4],
                  });
                  addToast({
                    title: `${preset.name} preset loaded`,
                    variant: "success",
                  });
                }}
                className="text-left p-3 rounded-lg border border-border hover:border-primary/40 transition-colors group"
              >
                <p className="text-xs font-bold mb-2 group-hover:text-primary transition-colors">
                  {preset.name}
                </p>
                <div className="flex -space-x-2">
                  {preset.slugs.slice(0, 5).map((slug) => {
                    const p = getProductBySlug(slug);
                    if (!p) return null;
                    return (
                      <div
                        key={slug}
                        className="relative h-8 w-8 rounded-full overflow-hidden border-2 border-card"
                      >
                        <Image
                          src={p.images[0]}
                          alt={p.name}
                          fill
                          sizes="32px"
                          className="object-cover"
                        />
                      </div>
                    );
                  })}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Summary */}
      <div className="lg:sticky lg:top-28 lg:self-start">
        <div className="rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-black tracking-tight">Your outfit</h2>
            <button
              onClick={handleReset}
              disabled={selectedCount === 0}
              className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <RotateCcw className="h-3 w-3" />
              Reset
            </button>
          </div>

          {/* Selected slots */}
          <div className="space-y-2 mb-6">
            {(Object.keys(SLOT_LABELS) as SlotKey[]).map((slot) => {
              const p = selectedProducts[slot];
              return (
                <div
                  key={slot}
                  className={cn(
                    "flex items-center gap-3 p-2 rounded-lg border transition-colors",
                    p ? "border-border bg-card" : "border-dashed border-border/60 bg-transparent",
                  )}
                >
                  <div className="relative h-12 w-12 shrink-0 rounded-md overflow-hidden bg-muted">
                    {p ? (
                      <Image
                        src={p.images[0]}
                        alt={p.name}
                        fill
                        sizes="48px"
                        className="object-cover"
                      />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-xs font-bold">
                        {SLOT_ICONS[slot]}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                      {SLOT_LABELS[slot]}
                    </p>
                    {p ? (
                      <>
                        <p className="text-xs font-semibold truncate">{p.name}</p>
                        <p className="text-xs text-muted-foreground">${p.price}</p>
                      </>
                    ) : (
                      <p className="text-xs text-muted-foreground italic">Select a {SLOT_LABELS[slot].toLowerCase()}</p>
                    )}
                  </div>
                  {p && (
                    <button
                      onClick={() => setSelections((prev) => ({ ...prev, [slot]: null }))}
                      className="text-muted-foreground hover:text-foreground text-sm"
                      aria-label={`Remove ${SLOT_LABELS[slot]}`}
                    >
                      ×
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Total */}
          <div className="space-y-2 pt-4 border-t border-border">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">{selectedCount} item{selectedCount === 1 ? "" : "s"}</span>
              {totalCompareAt > totalPrice && totalPrice > 0 && (
                <span className="text-xs text-muted-foreground line-through">
                  ${totalCompareAt.toFixed(2)}
                </span>
              )}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-base font-bold">Total</span>
              <span className="text-2xl font-black tabular-nums text-primary">
                ${totalPrice.toFixed(2)}
              </span>
            </div>
            {totalCompareAt > totalPrice && totalPrice > 0 && (
              <p className="text-xs text-success">
                You save ${(totalCompareAt - totalPrice).toFixed(2)} on this look
              </p>
            )}
          </div>

          {/* CTA */}
          <button
            onClick={handleAddOutfitToCart}
            disabled={selectedCount === 0}
            className="w-full mt-6 h-12 rounded-full bg-primary text-primary-foreground font-bold text-sm btn-shine flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed hover:scale-[1.02] transition-transform"
          >
            <ShoppingBag className="h-4 w-4" />
            {mounted ? (selectedCount === 0 ? "Select items to start" : `Add outfit to cart`) : "Add outfit to cart"}
          </button>

          <Link
            href="/shop"
            className="block mt-3 text-center text-xs font-mono uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors"
          >
            Browse all drops
          </Link>
        </div>

        {/* Tips */}
        <div className="mt-4 rounded-2xl border border-border bg-card p-5">
          <h3 className="text-sm font-bold mb-2">How it works</h3>
          <ol className="text-xs text-muted-foreground space-y-2 list-decimal list-inside">
            <li>Tap a slot above to start building.</li>
            <li>Pick a product from the option grid.</li>
            <li>Lock in all 5 pieces for a complete look.</li>
            <li>Add the full outfit to your cart in one tap.</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
