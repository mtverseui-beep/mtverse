"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import {
  CheckCircle2,
  Clock,
  Mail,
  Package,
  Search,
  Truck,
} from "lucide-react";
import type { MockOrder } from "@/types";
import { cn } from "@/lib/utils";
import { getOrderByNumber } from "@/data/orders";
import { useToastStore } from "@/store/toast-store";
import { Breadcrumbs, EmptyState } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function TrackOrderForm() {
  const addToast = useToastStore((s) => s.addToast);
  const [orderNumber, setOrderNumber] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [result, setResult] = React.useState<MockOrder | null | undefined>(undefined);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!orderNumber.trim()) errs.orderNumber = "Order number is required.";
    if (!EMAIL_REGEX.test(email)) errs.email = "Enter the email used at checkout.";
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    const order = getOrderByNumber(orderNumber.trim().toUpperCase());
    if (!order) {
      setResult(null);
      addToast({
        title: "No order found",
        description: "Double-check your order number and email.",
        variant: "error",
      });
      return;
    }
    setResult(order);
    addToast({
      title: "Order found",
      description: order.number,
      variant: "success",
    });
  };

  return (
    <div className="container mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8 lg:py-16">
      <Breadcrumbs items={[{ label: "Track order" }]} className="mb-6" />

      <div className="rounded-xl border border-border bg-card p-6 sm:p-8">
        <h1 className="text-2xl font-black tracking-tight text-foreground sm:text-3xl">
          Track your order
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Enter your order number and the email used at checkout to see live
          tracking updates.
        </p>

        <form
          onSubmit={handleSubmit}
          className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-end"
        >
          <div className="flex-1 space-y-1.5">
            <Label htmlFor="orderNumber" className="text-xs text-muted-foreground">
              Order number
            </Label>
            <Input
              id="orderNumber"
              type="text"
              value={orderNumber}
              onChange={(e) => setOrderNumber(e.target.value)}
              placeholder="VH-100042"
              autoComplete="off"
              aria-invalid={Boolean(errors.orderNumber)}
              className={cn(errors.orderNumber && "border-destructive")}
            />
            {errors.orderNumber && (
              <p className="text-xs text-destructive">{errors.orderNumber}</p>
            )}
          </div>
          <div className="flex-1 space-y-1.5">
            <Label htmlFor="trackEmail" className="text-xs text-muted-foreground">
              Email
            </Label>
            <Input
              id="trackEmail"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              autoComplete="email"
              aria-invalid={Boolean(errors.email)}
              className={cn(errors.email && "border-destructive")}
            />
            {errors.email && (
              <p className="text-xs text-destructive">{errors.email}</p>
            )}
          </div>
          <Button type="submit" size="lg" className="btn-shine">
            <Search className="h-4 w-4" />
            Track
          </Button>
        </form>

        <div className="mt-4 rounded-lg border border-border bg-background/40 p-3 text-xs text-muted-foreground">
          <p className="font-semibold text-foreground">Try a sample order:</p>
          <p className="mt-1">
            Order{" "}
            <button
              type="button"
              onClick={() => setOrderNumber("VH-100042")}
              className="text-primary underline-offset-4 hover:underline"
            >
              VH-100042
            </button>{" "}
            (Processing) · Order{" "}
            <button
              type="button"
              onClick={() => setOrderNumber("VH-099718")}
              className="text-primary underline-offset-4 hover:underline"
            >
              VH-099718
            </button>{" "}
            (Shipped) · Order{" "}
            <button
              type="button"
              onClick={() => setOrderNumber("VH-098245")}
              className="text-primary underline-offset-4 hover:underline"
            >
              VH-098245
            </button>{" "}
            (Delivered)
          </p>
        </div>
      </div>

      {/* Result */}
      <div className="mt-6">
        {result === null && (
          <EmptyState
            icon={<Search className="h-6 w-6" />}
            title="No order found"
            description="We couldn't find an order matching that number and email. Check your confirmation email and try again, or contact support."
            action={
              <Button asChild variant="outline">
                <Link href="/account/orders">View your orders</Link>
              </Button>
            }
          />
        )}

        {result && <OrderResult order={result} />}
      </div>
    </div>
  );
}

function OrderResult({ order }: { order: MockOrder }) {
  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-foreground">
            Order {order.number}
          </h2>
          <p className="text-sm text-muted-foreground">
            Placed on{" "}
            {new Date(order.date).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
        <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-primary">
          {order.status}
        </span>
      </div>

      {/* Progress timeline */}
      <ol className="mt-6 flex flex-col gap-5">
        {order.timeline.map((entry, i) => {
          const nextIdx = i + 1;
          const isLast = nextIdx >= order.timeline.length;
          return (
            <li key={`${entry.label}-${entry.date}`} className="relative flex items-start gap-3">
              {!isLast && (
                <span
                  aria-hidden
                  className={cn(
                    "absolute left-4 top-9 h-[calc(100%-1rem)] w-px",
                    entry.completed ? "bg-primary/60" : "bg-border"
                  )}
                />
              )}
              <span
                className={cn(
                  "inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                  entry.completed
                    ? "bg-success/15 text-success"
                    : "border border-border bg-muted/30 text-muted-foreground"
                )}
              >
                {entry.label.toLowerCase().includes("shipped") ||
                entry.label.toLowerCase().includes("delivery") ? (
                  <Truck className="h-4 w-4" />
                ) : entry.label.toLowerCase().includes("placed") ||
                  entry.label.toLowerCase().includes("confirmed") ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <Package className="h-4 w-4" />
                )}
              </span>
              <div>
                <p className="text-sm font-semibold text-foreground">
                  {entry.label}
                </p>
                <p className="text-xs text-muted-foreground">
                  {entry.completed
                    ? new Date(entry.date).toLocaleString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                        hour: "numeric",
                        minute: "2-digit",
                      })
                    : "Pending"}
                </p>
              </div>
            </li>
          );
        })}
      </ol>

      {order.trackingNumber && (
        <div className="mt-5 rounded-lg border border-border bg-background/40 p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Tracking number
          </p>
          <p className="mt-1 font-mono text-sm text-foreground">
            {order.trackingNumber}
          </p>
          {order.estimatedDelivery && (
            <p className="mt-1 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              Estimated delivery:{" "}
              {new Date(order.estimatedDelivery).toLocaleDateString("en-US", {
                weekday: "long",
                month: "short",
                day: "numeric",
              })}
            </p>
          )}
        </div>
      )}

      {/* Items */}
      <h3 className="mt-6 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
        Items in this order
      </h3>
      <ul className="mt-3 flex flex-col divide-y divide-border rounded-lg border border-border">
        {order.items.map((item) => (
          <li
            key={`${item.productId}-${item.size}-${item.color}`}
            className="flex gap-3 p-3"
          >
            <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30">
              <Image
                src={item.image}
                alt={item.name}
                fill
                sizes="56px"
                className="object-cover"
              />
            </div>
            <div className="flex min-w-0 flex-1 flex-col">
              <Link
                href={`/product/${item.slug}`}
                className="text-sm font-semibold text-foreground hover:text-primary"
              >
                {item.name}
              </Link>
              <p className="text-xs text-muted-foreground">
                Size {item.size} · {item.color} · Qty {item.quantity}
              </p>
            </div>
            <span className="text-sm font-semibold text-foreground tabular-nums">
              ${(item.price * item.quantity).toFixed(2)}
            </span>
          </li>
        ))}
      </ul>

      <div className="mt-6 flex flex-wrap gap-3">
        <Button asChild variant="outline">
          <Link href={`/order/${order.id}`}>View full order</Link>
        </Button>
        <Button asChild variant="ghost">
          <a href="mailto:support@volthaus.co">
            <Mail className="h-4 w-4" />
            Contact support
          </a>
        </Button>
      </div>
    </div>
  );
}

export default TrackOrderForm;
