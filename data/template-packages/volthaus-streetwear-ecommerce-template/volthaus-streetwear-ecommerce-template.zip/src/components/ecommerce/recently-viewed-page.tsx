"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { Clock, History, Trash2 } from "lucide-react";
import { useRecentlyViewedStore } from "@/store/recently-viewed-store";
import { useToastStore } from "@/store/toast-store";
import { useMounted } from "@/hooks";
import {
  Breadcrumbs,
  EmptyState,
  PriceDisplay,
  SectionHeading,
} from "@/components/common";
import { Button } from "@/components/ui/button";

export function RecentlyViewedPage() {
  const mounted = useMounted();
  const items = useRecentlyViewedStore((s) => s.items);
  const clear = useRecentlyViewedStore((s) => s.clear);
  const addToast = useToastStore((s) => s.addToast);

  if (!mounted) {
    return (
      <div className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <p className="text-sm text-muted-foreground">Loading history…</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
      <Breadcrumbs items={[{ label: "Recently viewed" }]} className="mb-6" />

      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <SectionHeading
          eyebrow="History"
          title="Recently viewed"
          description="Products you've explored lately. Pick up where you left off or clear the list to start fresh."
          className="mb-0"
        />
        {items.length > 0 && (
          <Button
            variant="outline"
            onClick={() => {
              clear();
              addToast({ title: "History cleared", variant: "default" });
            }}
          >
            <Trash2 className="h-4 w-4" />
            Clear all
          </Button>
        )}
      </div>

      {items.length === 0 ? (
        <EmptyState
          icon={<History className="h-6 w-6" />}
          title="No history yet"
          description="Browse a few products and they'll show up here so you can come back to them later."
          action={
            <Button asChild>
              <Link href="/shop">Browse drops</Link>
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((item) => (
            <article
              key={item.productId}
              className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card"
            >
              <Link
                href={`/product/${item.slug}`}
                className="relative aspect-square overflow-hidden bg-muted/30"
                aria-label={`View ${item.name}`}
              >
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </Link>
              <div className="flex flex-1 flex-col gap-2 p-4">
                <Link
                  href={`/product/${item.slug}`}
                  className="line-clamp-1 text-sm font-semibold text-foreground hover:text-primary"
                >
                  {item.name}
                </Link>
                <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  Viewed{" "}
                  {new Date(item.viewedAt).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </div>
                <PriceDisplay price={item.price} size="sm" />
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

export default RecentlyViewedPage;
