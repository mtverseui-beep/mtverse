"use client";

import { motion } from "framer-motion";
import { Truck } from "lucide-react";
import { useReducedMotion } from "@/hooks";
import { cn } from "@/lib/utils";

export interface FreeShippingProgressProps {
  subtotal: number;
  threshold?: number;
  className?: string;
}

function formatPrice(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
  }).format(value);
}

/**
 * Reusable free-shipping progress bar. Fills with the primary brand color as
 * the subtotal approaches the threshold.
 */
export function FreeShippingProgress({
  subtotal,
  threshold = 100,
  className,
}: FreeShippingProgressProps) {
  const reducedMotion = useReducedMotion();
  const remaining = Math.max(0, threshold - subtotal);
  const pct = threshold > 0 ? Math.min(100, (subtotal / threshold) * 100) : 100;
  const unlocked = remaining <= 0;

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex items-center justify-between gap-2 text-xs">
        <span
          className={cn(
            "flex items-center gap-1.5",
            unlocked ? "text-primary" : "text-muted-foreground"
          )}
        >
          <Truck className="size-3.5" aria-hidden="true" />
          {unlocked
            ? "You've unlocked free shipping"
            : `You're ${formatPrice(remaining)} away from free shipping`}
        </span>
        <span className="font-mono text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
          {unlocked ? "Unlocked" : `${Math.round(pct)}%`}
        </span>
      </div>
      <div
        className="relative h-1.5 w-full overflow-hidden rounded-full bg-muted/60"
        role="progressbar"
        aria-valuenow={Math.round(pct)}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="Free shipping progress"
      >
        <motion.div
          className="absolute inset-y-0 left-0 rounded-full bg-primary"
          initial={false}
          animate={{ width: `${pct}%` }}
          transition={
            reducedMotion
              ? { duration: 0 }
              : { type: "spring", stiffness: 220, damping: 28 }
          }
        />
      </div>
    </div>
  );
}

export default FreeShippingProgress;
