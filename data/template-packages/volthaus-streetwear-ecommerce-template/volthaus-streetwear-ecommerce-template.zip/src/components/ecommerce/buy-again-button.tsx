"use client";

import { RotateCcw } from "lucide-react";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { getProductBySlug } from "@/data/products";
import { Button } from "@/components/ui/button";
import type { MockOrderItem, ProductCategory } from "@/types";

export interface BuyAgainButtonProps {
  items: MockOrderItem[];
}

export function BuyAgainButton({ items }: BuyAgainButtonProps) {
  const addItem = useCartStore((s) => s.addItem);
  const openCart = useCartStore((s) => s.openCart);
  const addToast = useToastStore((s) => s.addToast);

  const handleBuyAgain = () => {
    items.forEach((item) => {
      const product = getProductBySlug(item.slug);
      addItem({
        productId: item.productId,
        slug: item.slug,
        name: item.name,
        image: item.image,
        price: item.price,
        size: item.size,
        color: item.color,
        quantity: item.quantity,
        category: (product?.category ?? "Accessories") as ProductCategory,
      });
    });
    addToast({
      title: "Items added to cart",
      description: "Your previous order is back in the bag.",
      variant: "success",
    });
    openCart();
  };

  return (
    <Button type="button" size="sm" onClick={handleBuyAgain} className="btn-shine">
      <RotateCcw className="h-4 w-4" />
      Buy again
    </Button>
  );
}

export default BuyAgainButton;
