"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronDown,
  LayoutGrid,
  List,
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";
import type { Product, ProductCategory, DropStatus } from "@/types";
import { CATEGORY_SLUG_MAP } from "@/data/category-slugs";
import { cn } from "@/lib/utils";
import { useUIStore } from "@/store/ui-store";
import { useMounted, useReducedMotion } from "@/hooks";
import {
  Breadcrumbs,
  EmptyState,
  PriceDisplay,
  ProductGridSkeleton,
  SectionHeading,
} from "@/components/common";
import { ProductCard } from "@/components/product";
import { ScrollReveal } from "@/components/motion";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export interface ShopPageProps {
  /** All catalog products to filter (defaults handled by parent). */
  products: Product[];
  /** Initial category filter (e.g. when arriving from /shop/sneakers). */
  initialCategory?: ProductCategory | null;
  /** Optional page eyebrow/title override. */
  eyebrow?: string;
  title?: string;
  description?: string;
  /** Breadcrumb items, optional. */
  breadcrumbs?: { label: string; href?: string }[];
}

type SortKey =
  | "featured"
  | "price-asc"
  | "price-desc"
  | "newest"
  | "rating"
  | "best-selling";

const CATEGORY_OPTIONS: ProductCategory[] = [
  "Sneakers",
  "Hoodies",
  "Graphic Tees",
  "Cargo Pants",
  "Jackets",
  "Caps",
  "Bags",
  "Accessories",
];

const SIZE_OPTIONS = [
  "XS",
  "S",
  "M",
  "L",
  "XL",
  "XXL",
  "7",
  "8",
  "9",
  "10",
  "11",
  "12",
];

const DROP_STATUS_OPTIONS: { value: DropStatus; label: string }[] = [
  { value: "live", label: "Live" },
  { value: "upcoming", label: "Upcoming" },
  { value: "sold-out", label: "Sold Out" },
  { value: "restock", label: "Restock" },
];

const PRICE_BUCKETS = [
  { id: "0-50", label: "Under $50", min: 0, max: 50 },
  { id: "50-100", label: "$50 to $100", min: 50, max: 100 },
  { id: "100-200", label: "$100 to $200", min: 100, max: 200 },
  { id: "200+", label: "$200 and above", min: 200, max: Infinity },
];

const PAGE_SIZE = 8;

export function ShopPage({
  products,
  initialCategory = null,
  eyebrow = "Catalog",
  title = "Shop All Drops",
  description = "Browse every VoltHaus silhouette, capsule, and accessory in one feed. Filter by category, size, color, and drop status.",
  breadcrumbs,
}: ShopPageProps) {
  const mounted = useMounted();
  const prefersReduced = useReducedMotion();
  const router = useRouter();
  const openFilterDrawer = useUIStore((s) => s.openFilterDrawer);

  // ---------------- Filter state ----------------
  const [selectedCategories, setSelectedCategories] = React.useState<
    Set<ProductCategory>
  >(initialCategory ? new Set([initialCategory]) : new Set());
  const [selectedSizes, setSelectedSizes] = React.useState<Set<string>>(
    new Set()
  );
  const [selectedColors, setSelectedColors] = React.useState<Set<string>>(
    new Set()
  );
  const [selectedPriceBuckets, setSelectedPriceBuckets] = React.useState<
    Set<string>
  >(new Set());
  const [selectedDropStatuses, setSelectedDropStatuses] = React.useState<
    Set<DropStatus>
  >(new Set());
  const [selectedCollections, setSelectedCollections] = React.useState<
    Set<string>
  >(new Set());
  const [searchValue, setSearchValue] = React.useState("");
  const [sortKey, setSortKey] = React.useState<SortKey>("featured");
  const [view, setView] = React.useState<"grid" | "list">("grid");
  const [visibleCount, setVisibleCount] = React.useState(PAGE_SIZE);

  // Reset category filter if initialCategory changes (navigation between
  // category pages).
  React.useEffect(() => {
    setSelectedCategories(
      initialCategory ? new Set([initialCategory]) : new Set()
    );
    setVisibleCount(PAGE_SIZE);
  }, [initialCategory]);

  // Available filter options derived from the product set.
  const availableCollections = React.useMemo(() => {
    const set = new Map<string, string>();
    products.forEach((p) => set.set(p.collectionSlug, p.collection));
    return Array.from(set.entries()).map(([slug, name]) => ({ slug, name }));
  }, [products]);

  const availableColors = React.useMemo(() => {
    const map = new Map<string, { name: string; hex: string }>();
    products.forEach((p) =>
      p.colors.forEach((c) => map.set(c.name, c))
    );
    return Array.from(map.values());
  }, [products]);

  // ---------------- Filtering ----------------
  const filtered = React.useMemo(() => {
    const q = searchValue.trim().toLowerCase();
    return products.filter((p) => {
      // Category
      if (
        selectedCategories.size > 0 &&
        !selectedCategories.has(p.category)
      ) {
        return false;
      }
      // Sizes
      if (
        selectedSizes.size > 0 &&
        !p.sizes.some((s) => selectedSizes.has(s))
      ) {
        return false;
      }
      // Colors
      if (
        selectedColors.size > 0 &&
        !p.colors.some((c) => selectedColors.has(c.name))
      ) {
        return false;
      }
      // Price buckets (OR within bucket, intersect with other filters)
      if (selectedPriceBuckets.size > 0) {
        const matched = Array.from(selectedPriceBuckets).some((id) => {
          const bucket = PRICE_BUCKETS.find((b) => b.id === id);
          if (!bucket) return false;
          return p.price >= bucket.min && p.price < bucket.max;
        });
        if (!matched) return false;
      }
      // Drop status
      if (
        selectedDropStatuses.size > 0 &&
        !selectedDropStatuses.has(p.dropStatus)
      ) {
        return false;
      }
      // Collection
      if (
        selectedCollections.size > 0 &&
        !selectedCollections.has(p.collectionSlug)
      ) {
        return false;
      }
      // Search
      if (q) {
        const haystack = [
          p.name,
          p.category,
          p.collection,
          p.shortDescription,
          ...p.styleTags,
        ]
          .join(" ")
          .toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [
    products,
    selectedCategories,
    selectedSizes,
    selectedColors,
    selectedPriceBuckets,
    selectedDropStatuses,
    selectedCollections,
    searchValue,
  ]);

  // ---------------- Sorting ----------------
  const sorted = React.useMemo(() => {
    const list = [...filtered];
    switch (sortKey) {
      case "price-asc":
        return list.sort((a, b) => a.price - b.price);
      case "price-desc":
        return list.sort((a, b) => b.price - a.price);
      case "newest":
        return list.sort((a, b) => {
          const ad = a.dropDate ? new Date(a.dropDate).getTime() : 0;
          const bd = b.dropDate ? new Date(b.dropDate).getTime() : 0;
          return bd - ad;
        });
      case "rating":
        return list.sort((a, b) => b.rating - a.rating);
      case "best-selling":
        return list.sort((a, b) => b.reviewCount - a.reviewCount);
      case "featured":
      default:
        return list.sort(
          (a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured))
        );
    }
  }, [filtered, sortKey]);

  // ---------------- Active filter chips ----------------
  const activeChips = React.useMemo(() => {
    const chips: { label: string; clear: () => void }[] = [];
    selectedCategories.forEach((c) =>
      chips.push({
        label: c,
        clear: () =>
          setSelectedCategories((prev) => {
            const next = new Set(prev);
            next.delete(c);
            return next;
          }),
      })
    );
    selectedSizes.forEach((s) =>
      chips.push({
        label: `Size ${s}`,
        clear: () =>
          setSelectedSizes((prev) => {
            const next = new Set(prev);
            next.delete(s);
            return next;
          }),
      })
    );
    selectedColors.forEach((c) =>
      chips.push({
        label: c,
        clear: () =>
          setSelectedColors((prev) => {
            const next = new Set(prev);
            next.delete(c);
            return next;
          }),
      })
    );
    selectedPriceBuckets.forEach((id) => {
      const bucket = PRICE_BUCKETS.find((b) => b.id === id);
      if (bucket)
        chips.push({
          label: bucket.label,
          clear: () =>
            setSelectedPriceBuckets((prev) => {
              const next = new Set(prev);
              next.delete(id);
              return next;
            }),
        });
    });
    selectedDropStatuses.forEach((s) =>
      chips.push({
        label:
          DROP_STATUS_OPTIONS.find((o) => o.value === s)?.label ?? s,
        clear: () =>
          setSelectedDropStatuses((prev) => {
            const next = new Set(prev);
            next.delete(s);
            return next;
          }),
      })
    );
    selectedCollections.forEach((slug) => {
      const c = availableCollections.find((x) => x.slug === slug);
      if (c)
        chips.push({
          label: c.name,
          clear: () =>
            setSelectedCollections((prev) => {
              const next = new Set(prev);
              next.delete(slug);
              return next;
            }),
        });
    });
    return chips;
  }, [
    selectedCategories,
    selectedSizes,
    selectedColors,
    selectedPriceBuckets,
    selectedDropStatuses,
    selectedCollections,
    availableCollections,
  ]);

  const clearAll = () => {
    setSelectedCategories(new Set());
    setSelectedSizes(new Set());
    setSelectedColors(new Set());
    setSelectedPriceBuckets(new Set());
    setSelectedDropStatuses(new Set());
    setSelectedCollections(new Set());
    setSearchValue("");
    setVisibleCount(PAGE_SIZE);
  };

  const visible = sorted.slice(0, visibleCount);
  const hasMore = visibleCount < sorted.length;

  const toggleSet = <T,>(
    setter: React.Dispatch<React.SetStateAction<Set<T>>>,
    value: T
  ) => {
    setter((prev) => {
      const next = new Set(prev);
      if (next.has(value)) next.delete(value);
      else next.add(value);
      return next;
    });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Search updates on input; submit just bumps the user back to top.
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: prefersReduced ? "auto" : "smooth" });
    }
  };

  // ---------------- Sidebar filter panel ----------------
  const FilterPanel = (
    <div className="flex flex-col gap-8">
      {/* Categories */}
      <FilterGroup label="Category">
        <div className="flex flex-col gap-2">
          {CATEGORY_OPTIONS.map((cat) => (
            <label
              key={cat}
              className="flex items-center gap-2.5 text-sm text-foreground cursor-pointer hover:text-primary transition-colors"
            >
              <Checkbox
                checked={selectedCategories.has(cat)}
                onCheckedChange={() =>
                  toggleSet(setSelectedCategories, cat)
                }
                aria-label={`Filter by ${cat}`}
              />
              <span>{cat}</span>
              <span className="ml-auto text-xs text-muted-foreground">
                {
                  products.filter((p) => p.category === cat).length
                }
              </span>
            </label>
          ))}
        </div>
      </FilterGroup>

      {/* Sizes */}
      <FilterGroup label="Size">
        <div className="grid grid-cols-4 gap-2">
          {SIZE_OPTIONS.map((size) => {
            const active = selectedSizes.has(size);
            return (
              <button
                key={size}
                type="button"
                onClick={() => toggleSet(setSelectedSizes, size)}
                aria-pressed={active}
                className={cn(
                  "h-9 rounded-md border text-xs font-medium transition-all",
                  active
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-foreground hover:border-primary/50 hover:bg-muted"
                )}
              >
                {size}
              </button>
            );
          })}
        </div>
      </FilterGroup>

      {/* Colors */}
      <FilterGroup label="Color">
        <div className="flex flex-wrap gap-2">
          {availableColors.map((color) => {
            const active = selectedColors.has(color.name);
            return (
              <button
                key={color.name}
                type="button"
                onClick={() => toggleSet(setSelectedColors, color.name)}
                aria-pressed={active}
                aria-label={`Filter by ${color.name}`}
                title={color.name}
                className={cn(
                  "h-7 w-7 rounded-full border border-white/25 transition-all hover:scale-110",
                  active &&
                    "ring-2 ring-primary ring-offset-2 ring-offset-background"
                )}
                style={{ backgroundColor: color.hex }}
              />
            );
          })}
        </div>
      </FilterGroup>

      {/* Price */}
      <FilterGroup label="Price">
        <div className="flex flex-col gap-2">
          {PRICE_BUCKETS.map((bucket) => (
            <label
              key={bucket.id}
              className="flex items-center gap-2.5 text-sm text-foreground cursor-pointer hover:text-primary transition-colors"
            >
              <Checkbox
                checked={selectedPriceBuckets.has(bucket.id)}
                onCheckedChange={() =>
                  toggleSet(setSelectedPriceBuckets, bucket.id)
                }
                aria-label={`Filter by ${bucket.label}`}
              />
              <span>{bucket.label}</span>
            </label>
          ))}
        </div>
      </FilterGroup>

      {/* Collection */}
      {availableCollections.length > 0 && (
        <FilterGroup label="Collection">
          <div className="flex flex-col gap-2 max-h-44 overflow-y-auto pr-1 no-scrollbar">
            {availableCollections.map((c) => (
              <label
                key={c.slug}
                className="flex items-center gap-2.5 text-sm text-foreground cursor-pointer hover:text-primary transition-colors"
              >
                <Checkbox
                  checked={selectedCollections.has(c.slug)}
                  onCheckedChange={() =>
                    toggleSet(setSelectedCollections, c.slug)
                  }
                  aria-label={`Filter by ${c.name}`}
                />
                <span>{c.name}</span>
              </label>
            ))}
          </div>
        </FilterGroup>
      )}

      {/* Drop status */}
      <FilterGroup label="Drop status">
        <div className="flex flex-col gap-2">
          {DROP_STATUS_OPTIONS.map((opt) => (
            <label
              key={opt.value}
              className="flex items-center gap-2.5 text-sm text-foreground cursor-pointer hover:text-primary transition-colors"
            >
              <Checkbox
                checked={selectedDropStatuses.has(opt.value)}
                onCheckedChange={() =>
                  toggleSet(setSelectedDropStatuses, opt.value)
                }
                aria-label={`Filter by ${opt.label}`}
              />
              <span>{opt.label}</span>
            </label>
          ))}
        </div>
      </FilterGroup>

      <Button
        type="button"
        variant="outline"
        onClick={clearAll}
        className="w-full"
      >
        Clear all filters
      </Button>
    </div>
  );

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
      {breadcrumbs && (
        <Breadcrumbs items={breadcrumbs} className="mb-6" />
      )}

      <SectionHeading
        eyebrow={eyebrow}
        title={title}
        description={description}
        className="mb-8"
      />

      <div className="flex flex-col gap-8 lg:flex-row lg:items-start">
        {/* Sidebar (desktop) */}
        <aside
          className="hidden w-64 shrink-0 lg:sticky lg:top-28 lg:block"
          aria-label="Product filters"
        >
          <div className="rounded-xl border border-border bg-card/60 p-5">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-foreground">
                Filters
              </h2>
              <span className="font-mono text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
                {sorted.length} results
              </span>
            </div>
            {FilterPanel}
          </div>
        </aside>

        {/* Main */}
        <div className="min-w-0 flex-1">
          {/* Toolbar */}
          <div className="mb-6 flex flex-col gap-3">
            <div className="flex flex-wrap items-center gap-3">
              <form
                onSubmit={handleSearchSubmit}
                className="relative flex-1 min-w-[200px]"
                role="search"
              >
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  placeholder="Search within results"
                  aria-label="Search within results"
                  className="pl-9"
                />
              </form>

              <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
                <SelectTrigger className="w-[180px]" aria-label="Sort products">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-asc">Price: Low to High</SelectItem>
                  <SelectItem value="price-desc">Price: High to Low</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="rating">Best rated</SelectItem>
                  <SelectItem value="best-selling">Best selling</SelectItem>
                </SelectContent>
              </Select>

              <div className="hidden sm:flex items-center rounded-md border border-border bg-card">
                <button
                  type="button"
                  onClick={() => setView("grid")}
                  aria-label="Grid view"
                  aria-pressed={view === "grid"}
                  className={cn(
                    "inline-flex h-9 w-9 items-center justify-center rounded-l-md transition-colors",
                    view === "grid"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <LayoutGrid className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setView("list")}
                  aria-label="List view"
                  aria-pressed={view === "list"}
                  className={cn(
                    "inline-flex h-9 w-9 items-center justify-center rounded-r-md transition-colors",
                    view === "list"
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <List className="h-4 w-4" />
                </button>
              </div>

              <Button
                type="button"
                variant="outline"
                className="lg:hidden"
                onClick={openFilterDrawer}
              >
                <SlidersHorizontal className="h-4 w-4" />
                Filters
                {activeChips.length > 0 && (
                  <span className="ml-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-semibold text-primary-foreground">
                    {activeChips.length}
                  </span>
                )}
              </Button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground">
              <span>
                Showing{" "}
                <span className="font-semibold text-foreground">
                  {mounted ? Math.min(visibleCount, sorted.length) : 0}
                </span>{" "}
                of{" "}
                <span className="font-semibold text-foreground">
                  {sorted.length}
                </span>{" "}
                products
              </span>
              {activeChips.length > 0 && (
                <button
                  type="button"
                  onClick={clearAll}
                  className="text-xs text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm"
                >
                  Clear all ({activeChips.length})
                </button>
              )}
            </div>

            {activeChips.length > 0 && (
              <div className="flex flex-wrap items-center gap-2">
                <AnimatePresence initial={false}>
                  {activeChips.map((chip, i) => (
                    <motion.span
                      key={`${chip.label}-${i}`}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card py-1 pl-3 pr-1.5 text-xs text-foreground"
                    >
                      {chip.label}
                      <button
                        type="button"
                        onClick={chip.clear}
                        aria-label={`Remove ${chip.label} filter`}
                        className="inline-flex h-5 w-5 items-center justify-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </motion.span>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>

          {/* Results */}
          {!mounted ? (
            <ProductGridSkeleton count={8} />
          ) : sorted.length === 0 ? (
            <EmptyState
              icon={<Search className="h-6 w-6" />}
              title="No products match your filters"
              description="Try removing some filters or searching for a different term. Our catalog rotates with every drop."
              action={
                <Button type="button" onClick={clearAll}>
                  Clear all filters
                </Button>
              }
            />
          ) : view === "grid" ? (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4">
              {visible.map((product, i) => (
                <ScrollReveal
                  key={product.id}
                  delay={Math.min(i * 0.04, 0.32)}
                >
                  <ProductCard product={product} priority={i < 4} />
                </ScrollReveal>
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {visible.map((product, i) => (
                <ScrollReveal key={product.id} delay={Math.min(i * 0.03, 0.24)}>
                  <ProductListRow product={product} />
                </ScrollReveal>
              ))}
            </div>
          )}

          {/* Load more */}
          {hasMore && (
            <div className="mt-10 flex flex-col items-center gap-3">
              <Button
                type="button"
                variant="outline"
                size="lg"
                onClick={() => setVisibleCount((c) => c + PAGE_SIZE)}
              >
                Load more products
              </Button>
              <button
                type="button"
                onClick={() => setVisibleCount(sorted.length)}
                className="text-xs text-muted-foreground underline-offset-4 hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm"
              >
                Show all {sorted.length} products
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile filter drawer (controlled by ui-store) */}
      <MobileFilterDrawer>{FilterPanel}</MobileFilterDrawer>
    </div>
  );
}

// ---------------- Internal helpers ----------------

function FilterGroup({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="border-t border-border pt-5 first:border-t-0 first:pt-0">
      <h3 className="mb-3 text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
        {label}
      </h3>
      {children}
    </div>
  );
}

function ProductListRow({ product }: { product: Product }) {
  return (
    <Link
      href={`/product/${product.slug}`}
      className="group flex flex-col gap-4 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40 sm:flex-row"
    >
      <div className="relative aspect-square w-full overflow-hidden rounded-md bg-muted/30 sm:h-32 sm:w-32 sm:shrink-0">
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          sizes="(min-width: 640px) 128px, 100vw"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="flex min-w-0 flex-1 flex-col gap-1.5">
        <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          {product.category}
        </span>
        <h3 className="text-base font-semibold text-foreground">
          {product.name}
        </h3>
        <p className="line-clamp-2 text-sm text-muted-foreground">
          {product.shortDescription}
        </p>
        <div className="mt-auto pt-1">
          <PriceDisplay
            price={product.price}
            compareAtPrice={product.compareAtPrice}
            size="md"
          />
        </div>
      </div>
      <div className="flex items-center sm:justify-end">
        <ChevronDown className="h-4 w-4 -rotate-90 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
      </div>
    </Link>
  );
}

function MobileFilterDrawer({ children }: { children: React.ReactNode }) {
  const mounted = useMounted();
  const isFilterDrawerOpen = useUIStore((s) => s.isFilterDrawerOpen);
  const closeFilterDrawer = useUIStore((s) => s.closeFilterDrawer);
  const prefersReduced = useReducedMotion();

  React.useEffect(() => {
    if (!mounted) return;
    if (isFilterDrawerOpen) {
      const original = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = original;
      };
    }
  }, [isFilterDrawerOpen, mounted]);

  React.useEffect(() => {
    if (!mounted) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isFilterDrawerOpen) closeFilterDrawer();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isFilterDrawerOpen, closeFilterDrawer, mounted]);

  if (!mounted) return null;

  return (
    <AnimatePresence>
      {isFilterDrawerOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: prefersReduced ? 0 : 0.2 }}
          className="fixed inset-0 z-[100] lg:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Filters"
        >
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={closeFilterDrawer}
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{
              type: "spring",
              stiffness: 280,
              damping: 30,
            }}
            className="absolute right-0 top-0 h-full w-full max-w-md overflow-y-auto bg-background p-5"
          >
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-sm font-semibold uppercase tracking-[0.18em] text-foreground">
                Filters
              </h2>
              <button
                type="button"
                onClick={closeFilterDrawer}
                aria-label="Close filters"
                className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-border text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            {children}
            <Button
              type="button"
              className="mt-6 w-full"
              onClick={closeFilterDrawer}
            >
              Show results
            </Button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export { CATEGORY_SLUG_MAP } from "@/data/category-slugs";
export default ShopPage;
