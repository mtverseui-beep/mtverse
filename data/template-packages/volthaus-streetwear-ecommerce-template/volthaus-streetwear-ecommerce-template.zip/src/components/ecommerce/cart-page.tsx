"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Gift,
  Lock,
  ShoppingBag,
  Tag,
  Trash2,
  Truck,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { useMounted } from "@/hooks";
import {
  Breadcrumbs,
  EmptyState,
  PriceDisplay,
  SectionHeading,
} from "@/components/common";
import { ProductCard } from "@/components/product";
import { FreeShippingProgress } from "@/components/ecommerce";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { Product } from "@/types";

export interface CartPageProps {
  bestSellers: Product[];
}

const FREE_SHIPPING_THRESHOLD = 100;
const DEFAULT_SHIPPING = 12;
const TAX_RATE = 0.08;

function formatPrice(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(value);
}

export function CartPage({ bestSellers }: CartPageProps) {
  const mounted = useMounted();
  const router = useRouter();
  const items = useCartStore((s) => s.items);
  const savedItems = useCartStore((s) => s.savedItems);
  const removeItem = useCartStore((s) => s.removeItem);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const saveForLater = useCartStore((s) => s.saveForLater);
  const moveToCart = useCartStore((s) => s.moveToCart);
  const coupon = useCartStore((s) => s.coupon);
  const applyCoupon = useCartStore((s) => s.applyCoupon);
  const removeCoupon = useCartStore((s) => s.removeCoupon);
  const giftCard = useCartStore((s) => s.giftCard);
  const applyGiftCard = useCartStore((s) => s.applyGiftCard);
  const removeGiftCard = useCartStore((s) => s.removeGiftCard);
  const orderNotes = useCartStore((s) => s.orderNotes);
  const setOrderNotes = useCartStore((s) => s.setOrderNotes);
  const addToast = useToastStore((s) => s.addToast);

  const [couponCode, setCouponCode] = React.useState("");
  const [giftCardCode, setGiftCardCode] = React.useState("");

  // Computed totals
  const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);
  const discount = coupon
    ? (subtotal * coupon.discountPercent) / 100
    : 0;
  const afterDiscount = subtotal - discount;
  const shipping =
    afterDiscount >= FREE_SHIPPING_THRESHOLD || afterDiscount === 0
      ? 0
      : DEFAULT_SHIPPING;
  const tax = afterDiscount * TAX_RATE;
  const giftCardValue = giftCard?.amount ?? 0;
  const total = Math.max(0, afterDiscount + shipping + tax - giftCardValue);

  const cartProductIds = new Set(items.map((i) => i.productId));
  const recommendations = bestSellers
    .filter((p) => !cartProductIds.has(p.id))
    .slice(0, 4);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;
    const ok = applyCoupon(couponCode);
    if (ok) {
      addToast({
        title: "Coupon applied",
        description: `${couponCode.toUpperCase()} is now active on your order.`,
        variant: "success",
      });
      setCouponCode("");
    } else {
      addToast({
        title: "Invalid coupon",
        description: "Try VOLTHAUS10, DROP15, or STATIC20.",
        variant: "error",
      });
    }
  };

  const handleApplyGiftCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!giftCardCode.trim()) return;
    const ok = applyGiftCard(giftCardCode);
    if (ok) {
      addToast({
        title: "Gift card applied",
        description: `${giftCardCode.toUpperCase()} balance added to your order.`,
        variant: "success",
      });
      setGiftCardCode("");
    } else {
      addToast({
        title: "Invalid gift card",
        description: "Try GIFT50 for a $50 balance.",
        variant: "error",
      });
    }
  };

  const handleCheckout = () => {
    if (items.length === 0) return;
    router.push("/checkout");
  };

  if (!mounted) {
    return (
      <div className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <p className="text-sm text-muted-foreground">Loading your cart…</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
      <Breadcrumbs items={[{ label: "Cart" }]} className="mb-6" />
      <SectionHeading
        eyebrow="Bag"
        title="Your cart"
        description="Review your items, apply a discount, and check out when you're ready."
        className="mb-8"
      />

      {items.length === 0 ? (
        <EmptyState
          icon={<ShoppingBag className="h-6 w-6" />}
          title="Your cart is empty"
          description="Looks like you haven't added anything yet. Browse the latest VoltHaus drops to find your next grail."
          action={
            <Button asChild>
              <Link href="/shop">Browse drops</Link>
            </Button>
          }
        />
      ) : (
        <div className="grid gap-8 lg:grid-cols-[1fr_360px] lg:items-start">
          {/* Left: items + saved + codes */}
          <div className="flex flex-col gap-8">
            {/* Free shipping progress */}
            <div className="rounded-xl border border-border bg-card/60 p-4">
              <FreeShippingProgress
                subtotal={subtotal}
                threshold={FREE_SHIPPING_THRESHOLD}
              />
            </div>

            {/* Cart lines */}
            <ul className="flex flex-col divide-y divide-border rounded-xl border border-border bg-card overflow-hidden">
              {items.map((item) => (
                <li key={`${item.productId}-${item.size}-${item.color}`} className="flex gap-4 p-4">
                  <Link
                    href={`/product/${item.slug}`}
                    className="relative h-24 w-24 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    aria-label={`View ${item.name}`}
                  >
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="96px"
                      className="object-cover"
                    />
                  </Link>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <Link
                          href={`/product/${item.slug}`}
                          className="text-sm font-semibold text-foreground hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                        >
                          {item.name}
                        </Link>
                        <p className="mt-0.5 text-xs text-muted-foreground">
                          {item.category} · Size {item.size} · {item.color}
                        </p>
                      </div>
                      <PriceDisplay price={item.price * item.quantity} size="md" />
                    </div>
                    <div className="mt-auto flex flex-wrap items-center gap-2 pt-3">
                      <div className="inline-flex h-9 items-stretch overflow-hidden rounded-md border border-border bg-background">
                        <button
                          type="button"
                          onClick={() =>
                            updateQuantity(
                              item.productId,
                              item.size,
                              item.color,
                              item.quantity - 1
                            )
                          }
                          disabled={item.quantity <= 1}
                          aria-label={`Decrease ${item.name} quantity`}
                          className="w-9 text-muted-foreground hover:text-primary disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          −
                        </button>
                        <span className="flex min-w-[2.5rem] items-center justify-center border-x border-border px-2 text-sm font-semibold tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            updateQuantity(
                              item.productId,
                              item.size,
                              item.color,
                              item.quantity + 1
                            )
                          }
                          aria-label={`Increase ${item.name} quantity`}
                          className="w-9 text-muted-foreground hover:text-primary"
                        >
                          +
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => saveForLater(item.productId, item.size, item.color)}
                        className="text-xs text-muted-foreground underline-offset-4 hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1"
                      >
                        Save for later
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          removeItem(item.productId, item.size, item.color);
                          addToast({
                            title: "Removed from cart",
                            description: item.name,
                            variant: "default",
                          });
                        }}
                        aria-label={`Remove ${item.name} from cart`}
                        className="ml-auto inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            {/* Coupon + gift card + notes */}
            <div className="grid gap-4 sm:grid-cols-2">
              <form
                onSubmit={handleApplyCoupon}
                className="rounded-xl border border-border bg-card p-4"
              >
                <div className="mb-2 flex items-center gap-2">
                  <Tag className="h-4 w-4 text-primary" />
                  <h3 className="text-sm font-semibold text-foreground">
                    Promo code
                  </h3>
                </div>
                {coupon ? (
                  <div className="flex items-center justify-between rounded-md border border-success/40 bg-success/10 px-3 py-2">
                    <div>
                      <p className="text-sm font-semibold text-success">
                        {coupon.code}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {coupon.discountPercent}% off applied
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        removeCoupon();
                        addToast({
                          title: "Coupon removed",
                          variant: "default",
                        });
                      }}
                      className="text-xs text-muted-foreground underline-offset-4 hover:text-destructive hover:underline"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <>
                    <Input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="VOLTHAUS10"
                      aria-label="Promo code"
                    />
                    <Button type="submit" variant="outline" className="mt-2 w-full">
                      Apply coupon
                    </Button>
                    <p className="mt-2 text-[11px] text-muted-foreground">
                      Try VOLTHAUS10, DROP15, or STATIC20.
                    </p>
                  </>
                )}
              </form>

              <form
                onSubmit={handleApplyGiftCard}
                className="rounded-xl border border-border bg-card p-4"
              >
                <div className="mb-2 flex items-center gap-2">
                  <Gift className="h-4 w-4 text-primary" />
                  <h3 className="text-sm font-semibold text-foreground">
                    Gift card
                  </h3>
                </div>
                {giftCard ? (
                  <div className="flex items-center justify-between rounded-md border border-success/40 bg-success/10 px-3 py-2">
                    <div>
                      <p className="text-sm font-semibold text-success">
                        {giftCard.code}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        ${giftCard.amount.toFixed(2)} balance applied
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        removeGiftCard();
                        addToast({
                          title: "Gift card removed",
                          variant: "default",
                        });
                      }}
                      className="text-xs text-muted-foreground underline-offset-4 hover:text-destructive hover:underline"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <>
                    <Input
                      type="text"
                      value={giftCardCode}
                      onChange={(e) => setGiftCardCode(e.target.value)}
                      placeholder="GIFT50"
                      aria-label="Gift card code"
                    />
                    <Button type="submit" variant="outline" className="mt-2 w-full">
                      Apply gift card
                    </Button>
                    <p className="mt-2 text-[11px] text-muted-foreground">
                      Try GIFT50 for a $50 balance.
                    </p>
                  </>
                )}
              </form>
            </div>

            {/* Order notes */}
            <div className="rounded-xl border border-border bg-card p-4">
              <h3 className="mb-2 text-sm font-semibold text-foreground">
                Order notes
              </h3>
              <Textarea
                value={orderNotes}
                onChange={(e) => setOrderNotes(e.target.value)}
                placeholder="Add a gift message, delivery instructions, or any note for our team."
                rows={3}
                aria-label="Order notes"
              />
            </div>

            {/* Saved for later */}
            {savedItems.length > 0 && (
              <section>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                  Saved for later
                </h3>
                <ul className="flex flex-col divide-y divide-border rounded-xl border border-border bg-card overflow-hidden">
                  {savedItems.map((item) => (
                    <li
                      key={`saved-${item.productId}-${item.size}-${item.color}`}
                      className="flex gap-4 p-4"
                    >
                      <Link
                        href={`/product/${item.slug}`}
                        className="relative h-20 w-20 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        aria-label={`View ${item.name}`}
                      >
                        <Image
                          src={item.image}
                          alt={item.name}
                          fill
                          sizes="80px"
                          className="object-cover"
                        />
                      </Link>
                      <div className="flex min-w-0 flex-1 flex-col">
                        <Link
                          href={`/product/${item.slug}`}
                          className="text-sm font-semibold text-foreground hover:text-primary"
                        >
                          {item.name}
                        </Link>
                        <p className="text-xs text-muted-foreground">
                          {item.category} · Size {item.size} · {item.color}
                        </p>
                        <div className="mt-auto flex items-center gap-2 pt-2">
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              moveToCart(item.productId, item.size, item.color)
                            }
                          >
                            Move to cart
                          </Button>
                          <button
                            type="button"
                            onClick={() =>
                              removeItem(item.productId, item.size, item.color)
                            }
                            className="text-xs text-muted-foreground underline-offset-4 hover:text-destructive hover:underline"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                      <PriceDisplay price={item.price} size="sm" />
                    </li>
                  ))}
                </ul>
              </section>
            )}

            {/* Recommendations */}
            {recommendations.length > 0 && (
              <section>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                  You might also like
                </h3>
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                  {recommendations.map((p) => (
                    <ProductCard key={p.id} product={p} />
                  ))}
                </div>
              </section>
            )}
          </div>

          {/* Right: order summary */}
          <aside className="lg:sticky lg:top-28">
            <div className="rounded-xl border border-border bg-card p-6">
              <h3 className="text-base font-bold text-foreground">
                Order summary
              </h3>
              <dl className="mt-4 flex flex-col gap-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Subtotal</dt>
                  <dd className="font-semibold text-foreground tabular-nums">
                    {formatPrice(subtotal)}
                  </dd>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-success">
                    <dt>Discount ({coupon?.discountPercent}%)</dt>
                    <dd className="tabular-nums">−{formatPrice(discount)}</dd>
                  </div>
                )}
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Shipping</dt>
                  <dd className="font-semibold text-foreground tabular-nums">
                    {shipping === 0 ? "Free" : formatPrice(shipping)}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Tax (estimated)</dt>
                  <dd className="font-semibold text-foreground tabular-nums">
                    {formatPrice(tax)}
                  </dd>
                </div>
                {giftCardValue > 0 && (
                  <div className="flex justify-between text-success">
                    <dt>Gift card</dt>
                    <dd className="tabular-nums">−{formatPrice(giftCardValue)}</dd>
                  </div>
                )}
                <div className="mt-2 border-t border-border pt-3 flex justify-between text-base">
                  <dt className="font-bold text-foreground">Total</dt>
                  <dd className="font-black text-foreground tabular-nums">
                    {formatPrice(total)}
                  </dd>
                </div>
              </dl>

              <Button
                type="button"
                size="lg"
                onClick={handleCheckout}
                className="btn-shine mt-5 w-full"
              >
                <Lock className="h-4 w-4" />
                Secure checkout
              </Button>
              <Link
                href="/shop"
                className="mt-3 block text-center text-xs text-muted-foreground underline-offset-4 hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
              >
                Continue shopping
              </Link>

              <div className="mt-5 flex items-center justify-center gap-2 text-[11px] text-muted-foreground">
                <Truck className="h-3.5 w-3.5 text-primary" />
                Free shipping over {formatPrice(FREE_SHIPPING_THRESHOLD)}
              </div>
              <div className="mt-2 flex flex-wrap items-center justify-center gap-1.5">
                {["Visa", "Mastercard", "Amex", "Apple Pay", "PayPal"].map(
                  (p) => (
                    <span
                      key={p}
                      className="rounded border border-border bg-background px-1.5 py-0.5 text-[10px] font-medium text-foreground"
                    >
                      {p}
                    </span>
                  )
                )}
              </div>
            </div>
          </aside>
        </div>
      )}

      {/* Mobile sticky checkout bar */}
      {mounted && items.length > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 backdrop-blur lg:hidden">
          <div className="flex items-center gap-3 p-3">
            <div className="min-w-0 flex-1">
              <p className="text-[11px] text-muted-foreground">Total</p>
              <p className="text-sm font-black text-foreground tabular-nums">
                {formatPrice(total)}
              </p>
            </div>
            <Button
              type="button"
              onClick={handleCheckout}
              className="btn-shine"
            >
              Checkout
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

export default CartPage;
