"use client";

import { useState } from "react";
import Image from "next/image";
import { Gift, Check } from "lucide-react";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { cn } from "@/lib/utils";

interface Design {
  id: string;
  name: string;
  image: string;
}

interface Denomination {
  value: number;
  popular: boolean;
}

interface GiftCardPurchaseProps {
  denominations: Denomination[];
  designs: Design[];
}

export function GiftCardPurchase({ denominations, designs }: GiftCardPurchaseProps) {
  const addItem = useCartStore((s) => s.addItem);
  const openCart = useCartStore((s) => s.openCart);
  const addToast = useToastStore((s) => s.addToast);

  const [amount, setAmount] = useState(100);
  const [designId, setDesignId] = useState(designs[0]?.id ?? "");
  const [recipientName, setRecipientName] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [message, setMessage] = useState("");
  const [scheduledDate, setScheduledDate] = useState("");

  const selectedDesign = designs.find((d) => d.id === designId) ?? designs[0];

  const handleAddToCart = () => {
    if (!recipientEmail || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(recipientEmail)) {
      addToast({ title: "Enter a valid recipient email", variant: "error" });
      return;
    }
    if (!recipientName.trim()) {
      addToast({ title: "Enter a recipient name", variant: "error" });
      return;
    }
    addItem({
      productId: `gift-card-${designId}-${amount}`,
      slug: "volthaus-gift-card",
      name: `VoltHaus Gift Card — $${amount}`,
      image: selectedDesign?.image ?? "",
      price: amount,
      size: designId,
      color: recipientEmail,
      quantity: 1,
      category: "Accessories",
    });
    addToast({
      title: "Gift card added to cart",
      description: `$${amount} — ${selectedDesign?.name ?? "VoltHaus"} design`,
      variant: "success",
    });
    openCart();
  };

  return (
    <div className="grid lg:grid-cols-[1fr_380px] gap-6 lg:gap-10">
      {/* Form */}
      <div className="space-y-8">
        {/* Amount */}
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">
            1. Choose an amount
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {denominations.map((d) => (
              <button
                key={d.value}
                onClick={() => setAmount(d.value)}
                className={cn(
                  "relative h-16 rounded-xl border-2 text-center transition-all",
                  amount === d.value
                    ? "border-primary bg-primary/10 text-foreground"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40",
                )}
              >
                {d.popular && (
                  <span className="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[10px] font-bold bg-secondary text-white">
                    Popular
                  </span>
                )}
                <span className="text-lg font-black">${d.value}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Design */}
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">
            2. Choose a design
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {designs.map((d) => (
              <button
                key={d.id}
                onClick={() => setDesignId(d.id)}
                className={cn(
                  "group relative aspect-[4/3] rounded-xl overflow-hidden border-2 transition-all",
                  designId === d.id
                    ? "border-primary glow-primary"
                    : "border-border hover:border-primary/40",
                )}
              >
                <Image
                  src={d.image}
                  alt={d.name}
                  fill
                  sizes="(max-width: 640px) 50vw, 25vw"
                  className="object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-2 left-2 right-2">
                  <p className="text-[10px] font-mono uppercase tracking-wider text-primary">
                    VoltHaus
                  </p>
                  <p className="text-xs font-bold text-white">{d.name}</p>
                </div>
                {designId === d.id && (
                  <span className="absolute top-2 right-2 inline-flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    <Check className="h-3.5 w-3.5" />
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Recipient */}
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">
            3. Recipient details
          </h2>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-muted-foreground mb-1.5">
                Recipient name
              </label>
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="Jordan Rivera"
                className="w-full h-11 px-4 rounded-lg bg-card border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1.5">
                Recipient email
              </label>
              <input
                type="email"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="jordan@email.com"
                className="w-full h-11 px-4 rounded-lg bg-card border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>
          <div className="mt-3">
            <label className="block text-xs text-muted-foreground mb-1.5">
              Personal message <span className="text-muted-foreground/60">(optional)</span>
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Happy birthday. The next drop is yours."
              rows={3}
              maxLength={200}
              className="w-full px-4 py-3 rounded-lg bg-card border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
            />
            <p className="text-right text-[10px] text-muted-foreground mt-1">
              {message.length}/200
            </p>
          </div>
          <div className="mt-3">
            <label className="block text-xs text-muted-foreground mb-1.5">
              Schedule delivery <span className="text-muted-foreground/60">(optional)</span>
            </label>
            <input
              type="date"
              value={scheduledDate}
              onChange={(e) => setScheduledDate(e.target.value)}
              min={new Date().toISOString().split("T")[0]}
              className="w-full sm:w-auto h-11 px-4 rounded-lg bg-card border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <p className="text-xs text-muted-foreground mt-1.5">
              Leave empty to deliver immediately after purchase.
            </p>
          </div>
        </div>
      </div>

      {/* Preview & summary */}
      <div className="lg:sticky lg:top-28 lg:self-start space-y-4">
        <div className="rounded-2xl border border-border bg-card p-6">
          <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-4">
            Preview
          </h2>
          <div className="relative aspect-[4/3] rounded-xl overflow-hidden border border-border bg-muted mb-4">
            {selectedDesign && (
              <Image
                src={selectedDesign.image}
                alt={selectedDesign.name}
                fill
                sizes="380px"
                className="object-cover"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
            <div className="absolute inset-0 p-5 flex flex-col justify-between">
              <div>
                <p className="text-[10px] font-mono uppercase tracking-wider text-primary">
                  VoltHaus Drop Card
                </p>
                <p className="text-xs text-white/80 mt-0.5">{selectedDesign?.name}</p>
              </div>
              <div>
                <p className="text-3xl font-black text-white tabular-nums">${amount}</p>
                <p className="text-xs text-white/60 mt-1">
                  {recipientName ? `To: ${recipientName}` : "To: Recipient name"}
                </p>
                {message && (
                  <p className="text-[10px] text-white/60 mt-2 italic line-clamp-2">
                    "{message}"
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-4 border-t border-border">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Amount</span>
              <span className="font-bold tabular-nums">${amount}.00</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Delivery</span>
              <span className="font-bold">
                {scheduledDate ? "Scheduled" : "Instant email"}
              </span>
            </div>
            <div className="flex items-center justify-between text-base font-black pt-2 border-t border-border">
              <span>Total</span>
              <span className="tabular-nums text-primary">${amount}.00</span>
            </div>
          </div>

          <button
            onClick={handleAddToCart}
            className="w-full mt-6 h-12 rounded-full bg-primary text-primary-foreground font-bold text-sm btn-shine flex items-center justify-center gap-2 hover:scale-[1.02] transition-transform"
          >
            <Gift className="h-4 w-4" />
            Add gift card to cart
          </button>
        </div>
      </div>
    </div>
  );
}
