"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { Heart, ShoppingBag, Trash2 } from "lucide-react";
import { useWishlistStore } from "@/store/wishlist-store";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { useMounted } from "@/hooks";
import { getProductBySlug } from "@/data/products";
import {
  Breadcrumbs,
  EmptyState,
  PriceDisplay,
  SectionHeading,
} from "@/components/common";
import { Button } from "@/components/ui/button";

export interface WishlistPageProps {
  /**
   * When true, skips the outer container, breadcrumbs, and section heading
   * so the component can be embedded inside another layout (e.g. the
   * AccountLayout).
   */
  embedded?: boolean;
}

export function WishlistPage({ embedded = false }: WishlistPageProps) {
  const mounted = useMounted();
  const items = useWishlistStore((s) => s.items);
  const removeItem = useWishlistStore((s) => s.removeItem);
  const clear = useWishlistStore((s) => s.clear);
  const addItem = useCartStore((s) => s.addItem);
  const openCart = useCartStore((s) => s.openCart);
  const addToast = useToastStore((s) => s.addToast);

  const handleMoveToCart = (slug: string) => {
    const product = getProductBySlug(slug);
    if (!product) return;
    if (product.sizes.length > 1) {
      // Multi-size — add default size, prompt user to refine in cart
      addItem({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        size: product.sizes[0],
        color: product.colors[0]?.name ?? "Default",
        quantity: 1,
        category: product.category,
      });
      addToast({
        title: "Added to cart",
        description: `Default size added — adjust in cart if needed.`,
        variant: "success",
      });
    } else {
      addItem({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        size: product.sizes[0] ?? "One Size",
        color: product.colors[0]?.name ?? "Default",
        quantity: 1,
        category: product.category,
      });
      addToast({
        title: "Added to cart",
        description: product.name,
        variant: "success",
      });
    }
    openCart();
  };

  const handleAddAll = () => {
    items.forEach((item) => {
      const product = getProductBySlug(item.slug);
      if (!product) return;
      addItem({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        size: product.sizes[0] ?? "One Size",
        color: product.colors[0]?.name ?? "Default",
        quantity: 1,
        category: product.category,
      });
    });
    addToast({
      title: `${items.length} items added to cart`,
      variant: "success",
    });
    openCart();
  };

  if (!mounted) {
    return (
      <div className={embedded ? "" : "container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8"}>
        <p className="text-sm text-muted-foreground">Loading your wishlist…</p>
      </div>
    );
  }

  const Wrapper: React.ElementType = embedded ? "div" : "div";
  const wrapperClassName = embedded
    ? ""
    : "container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12";

  return (
    <Wrapper className={wrapperClassName}>
      {!embedded && <Breadcrumbs items={[{ label: "Wishlist" }]} className="mb-6" />}

      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        {embedded ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <ShoppingBag className="h-4 w-4" aria-hidden />
            <span>
              {items.length} {items.length === 1 ? "item" : "items"} saved
            </span>
          </div>
        ) : (
          <SectionHeading
            eyebrow="Saved"
            title="Your wishlist"
            description="Items you've saved while browsing. Add them to cart or remove to keep this list tight."
            className="mb-0"
          />
        )}
        {items.length > 0 && (
          <div className="flex gap-2">
            <Button onClick={handleAddAll} className="btn-shine">
              <ShoppingBag className="h-4 w-4" />
              Add all to cart
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                clear();
                addToast({ title: "Wishlist cleared", variant: "default" });
              }}
            >
              Clear all
            </Button>
          </div>
        )}
      </div>

      {items.length === 0 ? (
        <EmptyState
          icon={<Heart className="h-6 w-6" />}
          title="Your wishlist is empty"
          description="Tap the heart on any product to save it here. Build a list of pieces you're watching and add them to cart when you're ready."
          action={
            <Button asChild>
              <Link href="/shop">Browse drops</Link>
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((item) => {
            const product = getProductBySlug(item.slug);
            return (
              <article
                key={item.productId}
                className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card"
              >
                <Link
                  href={`/product/${item.slug}`}
                  className="relative aspect-square overflow-hidden bg-muted/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  aria-label={`View ${item.name}`}
                >
                  <Image
                    src={item.image}
                    alt={item.name}
                    fill
                    sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </Link>
                <div className="flex flex-1 flex-col gap-2 p-4">
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
                    {product?.category ?? "Product"}
                  </span>
                  <Link
                    href={`/product/${item.slug}`}
                    className="line-clamp-1 text-sm font-semibold text-foreground hover:text-primary"
                  >
                    {item.name}
                  </Link>
                  <PriceDisplay price={item.price} size="sm" />
                  <div className="mt-2 flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => handleMoveToCart(item.slug)}
                      className="btn-shine flex-1"
                    >
                      <ShoppingBag className="h-3.5 w-3.5" />
                      Add
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      aria-label={`Remove ${item.name} from wishlist`}
                      onClick={() => {
                        removeItem(item.productId);
                        addToast({
                          title: "Removed from wishlist",
                          variant: "default",
                        });
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </Wrapper>
  );
}

export default WishlistPage;
