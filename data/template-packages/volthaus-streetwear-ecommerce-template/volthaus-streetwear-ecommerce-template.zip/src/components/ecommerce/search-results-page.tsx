"use client";

import * as React from "react";
import Link from "next/link";
import Image from "next/image";
import { useSearchParams, useRouter } from "next/navigation";
import { Search, TrendingUp, X } from "lucide-react";
import {
  searchProducts,
  products,
  collections,
  creators,
  blogPosts,
} from "@/data";
import {
  Breadcrumbs,
  EmptyState,
  PriceDisplay,
  SectionHeading,
  StarRating,
} from "@/components/common";
import { ProductCard } from "@/components/product";
import { ScrollReveal } from "@/components/motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

type SortKey = "relevance" | "price-asc" | "price-desc" | "rating";

const TRENDING_SEARCHES = [
  "Volt Runner",
  "Static Club",
  "Cargo",
  "Signal Drop",
  "Neon Court",
];

const RECENT_KEY = "volthaus-recent-searches";

export function SearchResultsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const query = searchParams.get("q") ?? "";

  const [inputValue, setInputValue] = React.useState(query);
  const [sortKey, setSortKey] = React.useState<SortKey>("relevance");
  const [recentSearches, setRecentSearches] = React.useState<string[]>([]);

  React.useEffect(() => {
    setInputValue(query);
  }, [query]);

  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(RECENT_KEY);
      if (raw) setRecentSearches(JSON.parse(raw) as string[]);
    } catch {
      /* ignore */
    }
  }, []);

  const pushRecent = (q: string) => {
    if (!q.trim()) return;
    setRecentSearches((prev) => {
      const next = [q, ...prev.filter((s) => s !== q)].slice(0, 6);
      try {
        localStorage.setItem(RECENT_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = inputValue.trim();
    if (!q) return;
    pushRecent(q);
    router.push(`/search?q=${encodeURIComponent(q)}`);
  };

  // ---------------- Search results ----------------
  const matchedProducts = React.useMemo(
    () => (query ? searchProducts(query) : []),
    [query]
  );
  const matchedCollections = React.useMemo(
    () =>
      query
        ? collections.filter(
            (c) =>
              c.name.toLowerCase().includes(query.toLowerCase()) ||
              c.tagline.toLowerCase().includes(query.toLowerCase()) ||
              c.description.toLowerCase().includes(query.toLowerCase())
          )
        : [],
    [query]
  );
  const matchedCreators = React.useMemo(
    () =>
      query
        ? creators.filter(
            (c) =>
              c.name.toLowerCase().includes(query.toLowerCase()) ||
              c.role.toLowerCase().includes(query.toLowerCase()) ||
              c.bio.toLowerCase().includes(query.toLowerCase())
          )
        : [],
    [query]
  );
  const matchedBlog = React.useMemo(
    () =>
      query
        ? blogPosts.filter(
            (b) =>
              b.title.toLowerCase().includes(query.toLowerCase()) ||
              b.excerpt.toLowerCase().includes(query.toLowerCase()) ||
              b.tags.some((t) => t.toLowerCase().includes(query.toLowerCase()))
          )
        : [],
    [query]
  );

  const sortedProducts = React.useMemo(() => {
    const list = [...matchedProducts];
    switch (sortKey) {
      case "price-asc":
        return list.sort((a, b) => a.price - b.price);
      case "price-desc":
        return list.sort((a, b) => b.price - a.price);
      case "rating":
        return list.sort((a, b) => b.rating - a.rating);
      default:
        return list;
    }
  }, [matchedProducts, sortKey]);

  const totalResults =
    matchedProducts.length +
    matchedCollections.length +
    matchedCreators.length +
    matchedBlog.length;

  return (
    <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
      <Breadcrumbs items={[{ label: "Search" }]} className="mb-6" />

      <SectionHeading
        eyebrow="Catalog"
        title={
          query ? (
            <>
              Results for <span className="text-primary">“{query}”</span>
            </>
          ) : (
            "Search the catalog"
          )
        }
        description={
          query
            ? `${totalResults} ${
                totalResults === 1 ? "result" : "results"
              } across products, collections, creators, and journal entries.`
            : "Type a product, collection, creator, or topic to search across the VoltHaus catalog."
        }
        className="mb-6"
      />

      <form onSubmit={handleSubmit} className="relative mb-6 max-w-2xl" role="search">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Search VoltHaus"
          aria-label="Search VoltHaus"
          className="pl-9 pr-9 h-11"
        />
        {inputValue && (
          <button
            type="button"
            onClick={() => setInputValue("")}
            aria-label="Clear search"
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </form>

      {!query && (
        <div className="grid gap-6 sm:grid-cols-2">
          <div className="rounded-xl border border-border bg-card p-5">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-foreground">
              <Search className="h-4 w-4 text-primary" />
              Recent searches
            </h2>
            {recentSearches.length === 0 ? (
              <p className="mt-2 text-xs text-muted-foreground">
                No recent searches yet — your history will appear here.
              </p>
            ) : (
              <div className="mt-3 flex flex-wrap gap-2">
                {recentSearches.map((s) => (
                  <Link
                    key={s}
                    href={`/search?q=${encodeURIComponent(s)}`}
                    className="inline-flex items-center rounded-full border border-border bg-background px-3 py-1 text-xs text-foreground hover:border-primary/50 hover:text-primary"
                  >
                    {s}
                  </Link>
                ))}
              </div>
            )}
          </div>
          <div className="rounded-xl border border-border bg-card p-5">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-foreground">
              <TrendingUp className="h-4 w-4 text-primary" />
              Trending searches
            </h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {TRENDING_SEARCHES.map((s) => (
                <Link
                  key={s}
                  href={`/search?q=${encodeURIComponent(s)}`}
                  className="inline-flex items-center rounded-full border border-border bg-background px-3 py-1 text-xs text-foreground hover:border-primary/50 hover:text-primary"
                >
                  {s}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      {query && totalResults === 0 && (
        <EmptyState
          icon={<Search className="h-6 w-6" />}
          title={`No results for “${query}”`}
          description="Try a different keyword or browse our catalog by category."
          action={
            <Button asChild>
              <Link href="/shop">Browse all products</Link>
            </Button>
          }
        />
      )}

      {query && totalResults > 0 && (
        <div className="mt-8 flex flex-col gap-10">
          {/* Products */}
          {sortedProducts.length > 0 && (
            <section>
              <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
                <h2 className="text-lg font-bold text-foreground">
                  Products
                  <span className="ml-2 text-sm font-normal text-muted-foreground">
                    {sortedProducts.length}
                  </span>
                </h2>
                <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
                  <SelectTrigger className="w-[180px]" aria-label="Sort products">
                    <SelectValue placeholder="Sort" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relevance">Relevance</SelectItem>
                    <SelectItem value="price-asc">Price: Low to High</SelectItem>
                    <SelectItem value="price-desc">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Best rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                {sortedProducts.map((p, i) => (
                  <ScrollReveal key={p.id} delay={Math.min(i * 0.04, 0.32)}>
                    <ProductCard product={p} priority={i < 4} />
                  </ScrollReveal>
                ))}
              </div>
            </section>
          )}

          {/* Collections */}
          {matchedCollections.length > 0 && (
            <section>
              <h2 className="mb-4 text-lg font-bold text-foreground">
                Collections
                <span className="ml-2 text-sm font-normal text-muted-foreground">
                  {matchedCollections.length}
                </span>
              </h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {matchedCollections.map((c) => (
                  <Link
                    key={c.id}
                    href={`/collections/${c.slug}`}
                    className="group relative overflow-hidden rounded-xl border border-border bg-card"
                  >
                    <div className="relative aspect-[16/10] overflow-hidden bg-muted/30">
                      <Image
                        src={c.cover}
                        alt={c.name}
                        fill
                        sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                        className="object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    </div>
                    <div className="p-4">
                      <p className="text-[11px] uppercase tracking-wider text-primary">
                        {c.tagline}
                      </p>
                      <h3 className="mt-1 text-base font-semibold text-foreground group-hover:text-primary">
                        {c.name}
                      </h3>
                      <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                        {c.description}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}

          {/* Creators */}
          {matchedCreators.length > 0 && (
            <section>
              <h2 className="mb-4 text-lg font-bold text-foreground">
                Creators
                <span className="ml-2 text-sm font-normal text-muted-foreground">
                  {matchedCreators.length}
                </span>
              </h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {matchedCreators.map((c) => (
                  <Link
                    key={c.id}
                    href={`/creators/${c.slug}`}
                    className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 hover:border-primary/40"
                  >
                    <Image
                      src={c.avatar}
                      alt={c.name}
                      width={56}
                      height={56}
                      className="h-14 w-14 rounded-full border border-border object-cover"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-foreground">
                        {c.name}
                      </p>
                      <p className="text-xs text-muted-foreground">{c.role}</p>
                      <p className="mt-0.5 text-[11px] text-muted-foreground">
                        {c.followers} followers · {c.drops} drops
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}

          {/* Journal */}
          {matchedBlog.length > 0 && (
            <section>
              <h2 className="mb-4 text-lg font-bold text-foreground">
                From the journal
                <span className="ml-2 text-sm font-normal text-muted-foreground">
                  {matchedBlog.length}
                </span>
              </h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {matchedBlog.map((b) => (
                  <Link
                    key={b.id}
                    href={`/blog/${b.slug}`}
                    className="group flex flex-col gap-3 rounded-xl border border-border bg-card p-4 hover:border-primary/40"
                  >
                    <div className="relative aspect-[16/10] overflow-hidden rounded-md bg-muted/30">
                      <Image
                        src={b.cover}
                        alt={b.title}
                        fill
                        sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                        className="object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-primary">
                        {b.category} · {b.readTime}
                      </p>
                      <h3 className="mt-1 text-sm font-semibold text-foreground group-hover:text-primary line-clamp-2">
                        {b.title}
                      </h3>
                      <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
                        {b.excerpt}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}

export default SearchResultsPage;
