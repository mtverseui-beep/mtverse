import type { ReactNode } from "react";
import { SiteHeader } from "@/components/layout/site-header";
import { Footer } from "@/components/layout/footer";

export interface SiteShellProps {
  children: ReactNode;
  hideHeader?: boolean;
  hideFooter?: boolean;
  hideAnnouncement?: boolean;
}

/**
 * Wraps page content with the site header and footer. Used on all standard
 * pages. Checkout/order pages can opt out via the hide flags.
 */
export function SiteShell({
  children,
  hideHeader = false,
  hideFooter = false,
  hideAnnouncement = false,
}: SiteShellProps) {
  return (
    <>
      {hideHeader ? null : <SiteHeader hideAnnouncement={hideAnnouncement} />}
      <main id="main-content" className="flex-1">
        {children}
      </main>
      {hideFooter ? null : <Footer />}
    </>
  );
}

export default SiteShell;
