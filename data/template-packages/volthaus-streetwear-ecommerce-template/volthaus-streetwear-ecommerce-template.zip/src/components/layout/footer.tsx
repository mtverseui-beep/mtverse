import Link from "next/link";
import { ArrowRight, Instagram, Mail, Music2, Twitter, Youtube } from "lucide-react";
import { footerNav } from "@/data/navigation";
import { Logo } from "@/components/layout/logo";
import { cn } from "@/lib/utils";
import type { NavItem } from "@/types";

interface FooterColumnProps {
  title: string;
  links: NavItem[];
}

function FooterColumn({ title, links }: FooterColumnProps) {
  return (
    <div>
      <h3 className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
        {title}
      </h3>
      <ul className="space-y-2">
        {links.map((link) => (
          <li key={link.href}>
            <Link
              href={link.href}
              className="text-sm text-foreground/80 transition-colors hover:text-primary focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

interface SocialLinkDef {
  label: string;
  href: string;
  icon: typeof Instagram;
}

const SOCIAL_LINKS: SocialLinkDef[] = [
  { label: "Instagram", href: "https://instagram.com/volthaus", icon: Instagram },
  { label: "Twitter", href: "https://twitter.com/volthaus", icon: Twitter },
  { label: "TikTok", href: "https://tiktok.com/@volthaus", icon: Music2 },
  { label: "YouTube", href: "https://youtube.com/@volthaus", icon: Youtube },
];

const MARQUEE_PHRASES = [
  "LIMITED DROPS",
  "MEMBER EARLY ACCESS",
  "FREE SHIPPING OVER $100",
  "CREATOR CAPSULES",
  "NEXT STREET CULTURE WAVE",
];

export interface FooterProps {
  className?: string;
}

export function Footer({ className }: FooterProps) {
  return (
    <footer
      className={cn(
        "mt-auto border-t border-border bg-card text-foreground",
        className
      )}
    >
      {/* CTA band */}
      <section className="relative overflow-hidden border-b border-border">
        <div
          aria-hidden="true"
          className="grid-bg pointer-events-none absolute inset-0 opacity-30"
        />
        <div className="relative mx-auto flex max-w-7xl flex-col items-start gap-6 px-4 py-12 sm:px-6 md:flex-row md:items-center md:justify-between md:py-16 lg:px-8">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary">
              VoltHaus
            </p>
            <h2 className="mt-2 max-w-xl text-3xl font-bold leading-tight text-foreground sm:text-4xl md:text-5xl">
              DROP THE STATIC.
              <br />
              <span className="text-gradient-primary">WEAR THE SIGNAL.</span>
            </h2>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link
              href="/shop"
              className="btn-shine inline-flex h-11 items-center rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              Shop the drop
            </Link>
            <Link
              href="/lookbook"
              className="inline-flex h-11 items-center gap-2 rounded-full border border-border px-6 text-sm font-semibold text-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              View lookbook
              <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>

      {/* Marquee strip */}
      <div
        className="border-b border-border bg-foreground/[0.02] py-3"
        aria-hidden="true"
      >
        <div className="flex w-full overflow-hidden">
          <div className="animate-marquee flex shrink-0 items-center gap-8 whitespace-nowrap pr-8">
            {[...MARQUEE_PHRASES, ...MARQUEE_PHRASES, ...MARQUEE_PHRASES, ...MARQUEE_PHRASES].map(
              (phrase, index) => (
                <span
                  key={`${phrase}-${index}`}
                  className="flex items-center gap-8 font-mono text-sm uppercase tracking-[0.3em] text-muted-foreground"
                >
                  {phrase}
                  <span className="text-primary" aria-hidden="true">
                    /
                  </span>
                </span>
              )
            )}
          </div>
        </div>
      </div>

      {/* Main footer columns */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-5">
          {/* Brand column */}
          <div className="col-span-2 sm:col-span-3 lg:col-span-1">
            <Link
              href="/"
              aria-label="VoltHaus home"
              className="inline-flex items-center gap-2 text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-md"
            >
              <Logo height={28} />
            </Link>
            <p className="mt-4 max-w-xs text-sm text-muted-foreground">
              Limited sneakers and streetwear drops for the next street culture wave.
              Built in Berlin, shipped worldwide.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {SOCIAL_LINKS.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="inline-flex size-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                >
                  <social.icon className="size-4" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>

          <FooterColumn title="Shop" links={footerNav.shop} />
          <FooterColumn title="Company" links={footerNav.company} />
          <FooterColumn title="Support" links={footerNav.support} />
          <FooterColumn title="Account" links={footerNav.account} />
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p>&copy; 2026 VoltHaus. All rights reserved.</p>
          <nav aria-label="Legal" className="no-scrollbar -mx-2 flex flex-wrap gap-x-4 gap-y-1 overflow-x-auto px-2">
            {footerNav.legal.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="whitespace-nowrap transition-colors hover:text-foreground focus-visible:outline-none focus-visible:underline focus-visible:underline-offset-2"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <a
            href="mailto:support@volthaus.co"
            className="inline-flex items-center gap-1.5 transition-colors hover:text-primary"
          >
            <Mail className="size-3.5" aria-hidden="true" />
            support@volthaus.co
          </a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
