"use client";

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { announcementBarMessages } from "@/data/navigation";
import { useReducedMotion } from "@/hooks";
import { cn } from "@/lib/utils";

const ROTATION_MS = 4000;

export interface AnnouncementBarProps {
  className?: string;
}

/**
 * Top rotating announcement bar. Cycles through VoltHaus messages every
 * 4 seconds with a fade + slide transition, with a "LIVE" indicator on the
 * left and a dismiss button on the right. Dismiss state is local-only.
 */
export function AnnouncementBar({ className }: AnnouncementBarProps) {
  const [index, setIndex] = useState(0);
  const [dismissed, setDismissed] = useState(false);
  const reducedMotion = useReducedMotion();

  const goNext = useCallback(() => {
    setIndex((i) => (i + 1) % announcementBarMessages.length);
  }, []);

  useEffect(() => {
    if (dismissed) return;
    const id = window.setInterval(goNext, ROTATION_MS);
    return () => window.clearInterval(id);
  }, [dismissed, goNext]);

  if (dismissed) return null;

  const message = announcementBarMessages[index] ?? announcementBarMessages[0];

  const variants = reducedMotion
    ? {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
      }
    : {
        initial: { opacity: 0, y: 8 },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0, y: -8 },
      };

  return (
    <div
      role="region"
      aria-label="Site announcements"
      className={cn(
        "bg-background relative z-[60] flex h-9 items-center justify-center overflow-hidden border-b border-border px-4 font-mono text-xs",
        className
      )}
    >
      <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
        <span className="inline-flex items-center gap-1.5">
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-60" />
            <span className="relative inline-flex size-2 rounded-full bg-primary" />
          </span>
          <span className="text-primary">LIVE</span>
        </span>
      </div>

      <div
        className="mx-auto max-w-[60vw] overflow-hidden text-center sm:max-w-md md:max-w-xl"
        aria-live="polite"
      >
        <AnimatePresence mode="wait" initial={false}>
          <motion.p
            key={index}
            {...variants}
            transition={{ duration: 0.32, ease: "easeOut" }}
            className="truncate text-foreground/90"
          >
            {message}
          </motion.p>
        </AnimatePresence>
      </div>

      <button
        type="button"
        onClick={() => setDismissed(true)}
        aria-label="Dismiss announcement"
        className="pointer-events-auto absolute inset-y-0 right-0 flex items-center pr-3 text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
      >
        <X className="size-3.5" aria-hidden="true" />
      </button>
    </div>
  );
}

export default AnnouncementBar;
