"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { useLenis } from "lenis/react";
import { ArrowUp } from "lucide-react";
import { useUIStore } from "@/store/ui-store";
import { useReducedMotion, useScrollPosition } from "@/hooks";
import { cn } from "@/lib/utils";

const VISIBILITY_THRESHOLD = 600;

export interface GoToTopButtonProps {
  className?: string;
}

/**
 * Floating scroll-to-top button. Becomes visible after the user scrolls past
 * 600px. Uses Lenis for smooth scrolling. Hidden on /checkout routes.
 */
export function GoToTopButton({ className }: GoToTopButtonProps) {
  const visible = useUIStore((s) => s.goToTopVisible);
  const setVisible = useUIStore((s) => s.setGoToTopVisible);
  const scrollY = useScrollPosition();
  const pathname = usePathname();
  const reducedMotion = useReducedMotion();
  const lenis = useLenis();

  const isCheckout = pathname.startsWith("/checkout");

  useEffect(() => {
    setVisible(scrollY > VISIBILITY_THRESHOLD && !isCheckout);
  }, [scrollY, isCheckout, setVisible]);

  const handleClick = () => {
    if (reducedMotion || !lenis) {
      window.scrollTo({ top: 0, behavior: reducedMotion ? "auto" : "smooth" });
      return;
    }
    lenis.scrollTo(0, { immediate: false });
  };

  const buttonVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
    : {
        initial: { scale: 0.6, opacity: 0 },
        animate: { scale: 1, opacity: 1 },
        exit: { scale: 0.6, opacity: 0 },
      };

  return (
    <AnimatePresence>
      {visible ? (
        <motion.button
          key="go-to-top"
          type="button"
          {...buttonVariants}
          transition={{ duration: 0.2, ease: "easeOut" }}
          onClick={handleClick}
          aria-label="Scroll to top"
          className={cn(
            "bg-card fixed bottom-6 right-6 z-40 inline-flex size-12 items-center justify-center rounded-full border border-border text-foreground shadow-lg shadow-black/40 transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            className
          )}
        >
          <ArrowUp className="size-5" aria-hidden="true" />
        </motion.button>
      ) : null}
    </AnimatePresence>
  );
}

export default GoToTopButton;
