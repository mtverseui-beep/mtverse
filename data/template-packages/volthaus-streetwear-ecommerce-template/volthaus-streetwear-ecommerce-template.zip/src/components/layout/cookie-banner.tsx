"use client";

import { useEffect } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { Cookie } from "lucide-react";
import { useUIStore } from "@/store/ui-store";
import { useReducedMotion } from "@/hooks";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "volthaus-cookie-consent";
const OPEN_DELAY_MS = 2000;

type ConsentValue = "all" | "essential";

function storeConsent(value: ConsentValue): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
      value,
      timestamp: new Date().toISOString(),
    }));
  } catch {
    // Ignore storage errors (private mode, quota).
  }
}

function readConsent(): ConsentValue | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { value?: unknown };
    if (parsed.value === "all" || parsed.value === "essential") {
      return parsed.value;
    }
    return null;
  } catch {
    return null;
  }
}

export interface CookieBannerProps {
  className?: string;
}

export function CookieBanner({ className }: CookieBannerProps) {
  const isOpen = useUIStore((s) => s.isCookieBannerOpen);
  const setOpen = useUIStore((s) => s.setCookieBanner);
  const reducedMotion = useReducedMotion();

  // Open the banner after a short delay if no prior consent is stored.
  useEffect(() => {
    if (readConsent() !== null) return;
    const id = window.setTimeout(() => setOpen(true), OPEN_DELAY_MS);
    return () => window.clearTimeout(id);
  }, [setOpen]);

  const handleAcceptAll = () => {
    storeConsent("all");
    setOpen(false);
  };

  const handleEssentialOnly = () => {
    storeConsent("essential");
    setOpen(false);
  };

  const variants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
    : {
        initial: { y: 120, opacity: 0 },
        animate: { y: 0, opacity: 1 },
        exit: { y: 120, opacity: 0 },
      };

  return (
    <AnimatePresence>
      {isOpen ? (
        <motion.div
          key="cookie-banner"
          {...variants}
          transition={{ duration: 0.32, ease: "easeOut" }}
          className={cn(
            "bg-background fixed inset-x-0 bottom-0 z-[70] border-t border-border px-4 py-4 sm:px-6",
            className
          )}
          role="region"
          aria-label="Cookie consent"
        >
          <div className="mx-auto flex max-w-7xl flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <span
                className="mt-0.5 inline-flex size-9 shrink-0 items-center justify-center rounded-full border border-border text-primary"
                aria-hidden="true"
              >
                <Cookie className="size-4" />
              </span>
              <p className="max-w-2xl text-sm text-muted-foreground">
                VoltHaus uses cookies to personalize your experience, power the
                drop queue, and remember your cart. You can read more in our{" "}
                <Link
                  href="/policies/cookies"
                  className="text-foreground underline-offset-2 hover:text-primary hover:underline"
                >
                  Cookie Policy
                </Link>
                .
              </p>
            </div>

            <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:shrink-0">
              <button
                type="button"
                onClick={handleEssentialOnly}
                className="inline-flex h-10 items-center justify-center rounded-full border border-border px-4 text-sm font-medium text-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                Essential only
              </button>
              <button
                type="button"
                onClick={handleAcceptAll}
                className="btn-shine inline-flex h-10 items-center justify-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                Accept all
              </button>
            </div>
          </div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

export default CookieBanner;
