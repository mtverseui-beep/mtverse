import { AnnouncementBar } from "@/components/layout/announcement-bar";
import { Navigation } from "@/components/layout/navigation";

export interface SiteHeaderProps {
  hideAnnouncement?: boolean;
}

/**
 * Composes the announcement bar + primary navigation. Server component — the
 * client-side behaviour lives inside the children.
 */
export function SiteHeader({ hideAnnouncement = false }: SiteHeaderProps) {
  return (
    <>
      {hideAnnouncement ? null : <AnnouncementBar />}
      <Navigation />
    </>
  );
}

export default SiteHeader;
