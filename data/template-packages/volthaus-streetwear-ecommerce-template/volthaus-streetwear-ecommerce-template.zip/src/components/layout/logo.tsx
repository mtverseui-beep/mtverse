import { cn } from "@/lib/utils";

export interface LogoProps {
  className?: string;
  /** Show the wordmark next to the mark. Default true. */
  showWordmark?: boolean;
  /** Height in pixels. Default 28. */
  height?: number;
}

/**
 * VoltHaus logo — inline SVG so `currentColor` inherits from the parent
 * element's CSS color property. This makes the wordmark automatically
 * adapt to light/dark themes.
 *
 * The V mark uses a fixed cyan→magenta gradient (brand accent) so it
 * stays vibrant in both themes. The wordmark uses currentColor.
 */
export function Logo({ className, showWordmark = true, height = 28 }: LogoProps) {
  const width = showWordmark ? (height / 48) * 240 : (height / 48) * 44;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 240 48"
      fill="none"
      role="img"
      aria-label="VoltHaus"
      className={cn("inline-block", className)}
      style={{ height: `${height}px`, width: `${width}px` }}
    >
      <defs>
        <linearGradient id="vh-logo-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#00E5FF" />
          <stop offset="100%" stopColor="#FF2ED1" />
        </linearGradient>
      </defs>
      {/* VOLT mark — lightning-inspired V */}
      <path
        d="M6 8 L20 40 L30 40 L24 28 L34 8 L27 8 L19 22 L13 8 Z"
        fill="url(#vh-logo-grad)"
      />
      <rect x="36" y="8" width="3" height="32" fill="url(#vh-logo-grad)" rx="1.5" />
      {/* Wordmark — inherits currentColor from parent */}
      {showWordmark && (
        <text
          x="50"
          y="33"
          fontFamily="Inter, system-ui, sans-serif"
          fontSize="26"
          fontWeight="900"
          letterSpacing="-0.5"
          fill="currentColor"
        >
          VoltHaus
        </text>
      )}
    </svg>
  );
}

/** Compact icon-only logo (square) for favicons, mobile, tight spaces. */
export function LogoMark({ className, height = 32 }: { className?: string; height?: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 64 64"
      fill="none"
      role="img"
      aria-label="VoltHaus"
      className={cn("inline-block", className)}
      style={{ height: `${height}px`, width: `${height}px` }}
    >
      <defs>
        <linearGradient id="vh-mark-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#00E5FF" />
          <stop offset="100%" stopColor="#FF2ED1" />
        </linearGradient>
      </defs>
      <path
        d="M10 10 L28 54 L38 54 L30 36 L42 10 L32 10 L22 28 L16 10 Z"
        fill="url(#vh-mark-grad)"
      />
      <rect x="44" y="10" width="4" height="44" fill="url(#vh-mark-grad)" rx="2" />
    </svg>
  );
}
