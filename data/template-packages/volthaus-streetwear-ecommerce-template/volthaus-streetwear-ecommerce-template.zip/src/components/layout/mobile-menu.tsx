"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ChevronDown,
  HelpCircle,
  Instagram,
  Mail,
  MapPin,
  Music2,
  Package,
  Search,
  ShieldCheck,
  ShoppingBag,
  Star,
  Truck,
  Twitter,
  User,
  X,
  Youtube,
} from "lucide-react";
import { navItems } from "@/data/navigation";
import { useUIStore } from "@/store/ui-store";
import { useReducedMotion } from "@/hooks";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

interface AccountLink {
  label: string;
  href: string;
  icon: LucideIcon;
}

interface SupportLink {
  label: string;
  href: string;
  icon: LucideIcon;
}

interface SocialLink {
  label: string;
  href: string;
  icon: LucideIcon;
}

const ACCOUNT_LINKS: AccountLink[] = [
  { label: "Sign In", href: "/account/login", icon: User },
  { label: "Orders", href: "/account/orders", icon: Package },
  { label: "Wishlist", href: "/account/wishlist", icon: Star },
  { label: "Addresses", href: "/account/addresses", icon: MapPin },
  { label: "Rewards", href: "/account/membership", icon: ShieldCheck },
];

const SUPPORT_LINKS: SupportLink[] = [
  { label: "Help", href: "/help", icon: HelpCircle },
  { label: "Contact", href: "/contact", icon: Mail },
  { label: "FAQ", href: "/faq", icon: HelpCircle },
  { label: "Track Order", href: "/account/orders", icon: Truck },
  { label: "Size Guide", href: "/size-guide", icon: ShoppingBag },
];

const SOCIAL_LINKS: SocialLink[] = [
  { label: "Instagram", href: "https://instagram.com/volthaus", icon: Instagram },
  { label: "Twitter", href: "https://twitter.com/volthaus", icon: Twitter },
  { label: "TikTok", href: "https://tiktok.com/@volthaus", icon: Music2 },
  { label: "YouTube", href: "https://youtube.com/@volthaus", icon: Youtube },
];

export interface MobileMenuProps {
  className?: string;
}

export function MobileMenu({ className }: MobileMenuProps) {
  const isOpen = useUIStore((s) => s.isMobileMenuOpen);
  const close = useUIStore((s) => s.closeMobileMenu);
  const pathname = usePathname();
  const router = useRouter();
  const reducedMotion = useReducedMotion();
  const [query, setQuery] = useState("");
  const [openAccordion, setOpenAccordion] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Lock body scroll when open
  useEffect(() => {
    if (!isOpen) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, [isOpen]);

  // Close on route change
  useEffect(() => {
    close();
  }, [pathname, close]);

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, close]);

  // Autofocus search input when opened
  useEffect(() => {
    if (!isOpen) return;
    const id = window.setTimeout(() => {
      searchInputRef.current?.focus();
    }, 250);
    return () => window.clearTimeout(id);
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = query.trim();
    if (!trimmed) return;
    router.push(`/search?q=${encodeURIComponent(trimmed)}`);
    setQuery("");
    close();
  };

  const toggleAccordion = (label: string) => {
    setOpenAccordion((current) => (current === label ? null : label));
  };

  const panelVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
    : {
        initial: { x: "100%" },
        animate: { x: 0 },
        exit: { x: "100%" },
      };

  return (
    <AnimatePresence>
      {isOpen ? (
        <motion.div
          key="mobile-menu"
          className="fixed inset-0 z-[80] lg:hidden"
          aria-modal="true"
          role="dialog"
          aria-label="Site menu"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 bg-background/80 backdrop-blur-sm"
            onClick={close}
            aria-hidden="true"
          />

          <motion.div
            {...panelVariants}
            transition={{ type: "tween", duration: 0.32, ease: "easeOut" }}
            className={cn(
              "bg-background absolute inset-y-0 right-0 flex w-full max-w-md flex-col border-l border-border",
              className
            )}
          >
            {/* Header */}
            <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-3">
              <span className="font-mono text-xs uppercase tracking-[0.2em] text-primary">
                Menu
              </span>
              <button
                type="button"
                onClick={close}
                aria-label="Close menu"
                className="inline-flex size-10 items-center justify-center rounded-md text-foreground transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <X className="size-5" aria-hidden="true" />
              </button>
            </div>

            {/* Search */}
            <div className="border-b border-border px-4 py-3">
              <form onSubmit={handleSubmit} className="relative">
                <Search
                  className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                  aria-hidden="true"
                />
                <input
                  ref={searchInputRef}
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search drops, sneakers, collections..."
                  aria-label="Search VoltHaus"
                  className="h-11 w-full rounded-md border border-input bg-input/30 pl-9 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                />
              </form>
            </div>

            {/* Scrollable body */}
            <div className="flex-1 overflow-y-auto px-4 py-4 no-scrollbar">
              <nav aria-label="Mobile primary" className="space-y-1">
                {navItems.map((item) => {
                  const hasChildren = Boolean(item.children?.length);
                  const expanded = openAccordion === item.label;
                  return (
                    <div key={item.label} className="border-b border-border/60">
                      {hasChildren ? (
                        <button
                          type="button"
                          onClick={() => toggleAccordion(item.label)}
                          aria-expanded={expanded}
                          className="flex w-full items-center justify-between py-3 text-left text-base font-medium text-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                        >
                          <span className="flex items-center gap-2">
                            {item.label}
                            {item.badge ? (
                              <span className="rounded-sm bg-primary/15 px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider text-primary">
                                {item.badge}
                              </span>
                            ) : null}
                          </span>
                          <ChevronDown
                            className={cn(
                              "size-4 transition-transform",
                              expanded && "rotate-180"
                            )}
                            aria-hidden="true"
                          />
                        </button>
                      ) : (
                        <Link
                          href={item.href}
                          onClick={close}
                          className="flex w-full items-center justify-between py-3 text-base font-medium text-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                        >
                          <span>{item.label}</span>
                        </Link>
                      )}

                      {hasChildren ? (
                        <AnimatePresence initial={false}>
                          {expanded && item.children ? (
                            <motion.ul
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.24, ease: "easeOut" }}
                              className="overflow-hidden"
                            >
                              <li>
                                <Link
                                  href={item.href}
                                  onClick={close}
                                  className="block py-2 pl-2 text-sm text-muted-foreground transition-colors hover:text-primary"
                                >
                                  View all {item.label}
                                </Link>
                              </li>
                              {item.children.map((child) => (
                                <li key={child.href}>
                                  <Link
                                    href={child.href}
                                    onClick={close}
                                    className="block py-2 pl-2 text-sm text-muted-foreground transition-colors hover:text-primary"
                                  >
                                    {child.label}
                                  </Link>
                                </li>
                              ))}
                            </motion.ul>
                          ) : null}
                        </AnimatePresence>
                      ) : null}
                    </div>
                  );
                })}
              </nav>

              {/* Account */}
              <div className="mt-6">
                <p className="mb-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Account
                </p>
                <ul className="space-y-1">
                  {ACCOUNT_LINKS.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        onClick={close}
                        className="flex items-center gap-3 rounded-md px-2 py-2.5 text-sm text-foreground transition-colors hover:bg-muted/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                      >
                        <link.icon className="size-4 text-muted-foreground" aria-hidden="true" />
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Support */}
              <div className="mt-6">
                <p className="mb-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Support
                </p>
                <ul className="space-y-1">
                  {SUPPORT_LINKS.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        onClick={close}
                        className="flex items-center gap-3 rounded-md px-2 py-2.5 text-sm text-foreground transition-colors hover:bg-muted/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                      >
                        <link.icon className="size-4 text-muted-foreground" aria-hidden="true" />
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Social */}
              <div className="mt-6">
                <p className="mb-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Follow
                </p>
                <div className="flex flex-wrap gap-2">
                  {SOCIAL_LINKS.map((link) => (
                    <a
                      key={link.label}
                      href={link.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex size-10 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                      aria-label={link.label}
                    >
                      <link.icon className="size-4" aria-hidden="true" />
                    </a>
                  ))}
                </div>
              </div>
            </div>

            {/* CTA */}
            <div className="border-t border-border p-4 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <span className="text-sm text-muted-foreground">Theme</span>
                <ThemeToggle />
              </div>
              <Link
                href="/sign-up"
                onClick={close}
                className="btn-shine flex h-12 w-full items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                Join the drop
              </Link>
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

export default MobileMenu;
