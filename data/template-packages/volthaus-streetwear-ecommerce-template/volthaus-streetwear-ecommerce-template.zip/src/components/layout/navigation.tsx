"use client";

import { useEffect, useRef, useState, Suspense } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname, useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Heart,
  Menu,
  Search,
  ShoppingBag,
  User,
} from "lucide-react";
import { navItems } from "@/data/navigation";
import { collections } from "@/data/collections";
import { useCartStore } from "@/store/cart-store";
import { useSearchStore } from "@/store/search-store";
import { useUIStore } from "@/store/ui-store";
import { useWishlistStore } from "@/store/wishlist-store";
import { useMounted, useReducedMotion, useScrollPosition } from "@/hooks";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { Logo } from "@/components/layout/logo";
import { cn } from "@/lib/utils";
import type { NavItem } from "@/types";

const SCROLL_THRESHOLD = 50;

export interface NavigationProps {
  className?: string;
}

interface NavLinkProps {
  item: NavItem;
  active: boolean;
  reducedMotion: boolean;
}

function isPathForItem(pathname: string, search: string, item: NavItem): boolean {
  // Match the deepest route segment for the nav item.
  if (item.href === "/shop") {
    return pathname === "/shop" || pathname.startsWith("/shop/");
  }
  if (item.href === "/drops") {
    return pathname === "/drops" || pathname.startsWith("/drops/");
  }
  if (item.href.startsWith("/shop?category=Sneakers")) {
    // /sneakers route OR /shop?category=Sneakers query
    return (
      pathname === "/sneakers" ||
      pathname.startsWith("/sneakers/") ||
      (pathname === "/shop" && search.includes("category=Sneakers"))
    );
  }
  if (item.href.startsWith("/shop?category=Hoodies")) {
    return (
      pathname === "/streetwear" ||
      pathname.startsWith("/streetwear/") ||
      (pathname === "/shop" && search.includes("category=Hoodies"))
    );
  }
  if (item.href === "/lookbook") {
    return pathname.startsWith("/lookbook");
  }
  if (item.href === "/creators") {
    return pathname.startsWith("/creators");
  }
  return pathname === item.href;
}

function NavLink({ item, active, reducedMotion }: NavLinkProps) {
  return (
    <Link
      href={item.href}
      className={cn(
        "group relative inline-flex items-center gap-1.5 px-2 py-2 text-sm font-medium transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
      )}
      aria-current={active ? "page" : undefined}
    >
      <span className="relative">
        {item.label}
        <span
          className={cn(
            "absolute -bottom-1 left-0 h-0.5 bg-primary transition-all duration-300",
            active ? "w-full" : "w-0 group-hover:w-full"
          )}
          aria-hidden="true"
        />
      </span>
      {item.badge ? (
        <span className="rounded-sm bg-primary/15 px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider text-primary">
          {item.badge}
        </span>
      ) : null}
      {!reducedMotion && !active ? (
        <span className="pointer-events-none absolute inset-0 -z-10 scale-95 opacity-0 transition-all duration-300 group-hover:scale-100 group-hover:opacity-100" />
      ) : null}
    </Link>
  );
}

interface MegaMenuPanelProps {
  item: NavItem;
  reducedMotion: boolean;
  onClose: () => void;
}

function MegaMenuPanel({ item, reducedMotion, onClose }: MegaMenuPanelProps) {
  const featuredCollections = collections.slice(0, 3);
  const promoCollection = collections[0];

  const variants = reducedMotion
    ? {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
      }
    : {
        initial: { opacity: 0, y: -8 },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0, y: -8 },
      };

  return (
    <motion.div
      {...variants}
      transition={{ duration: 0.22, ease: "easeOut" }}
      className="absolute inset-x-0 top-full"
      role="menu"
      aria-label={`${item.label} menu`}
    >
      <div className="solid-panel-strong border-t-2 border-primary shadow-2xl shadow-black/40">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-6 py-6 md:grid-cols-3 lg:gap-8">
          {/* Featured collections */}
          <div className="space-y-3">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Featured Collections
            </p>
            <ul className="space-y-2">
              {featuredCollections.map((collection) => (
                <li key={collection.id}>
                  <Link
                    href={`/collections/${collection.slug}`}
                    onClick={onClose}
                    className="group flex items-start gap-3 rounded-md p-2 transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                  >
                    <span
                      className="mt-1 size-2 shrink-0 rounded-full"
                      style={{ backgroundColor: collection.theme.primary }}
                      aria-hidden="true"
                    />
                    <span>
                      <span className="block text-sm font-medium text-foreground group-hover:text-primary">
                        {collection.name}
                      </span>
                      <span className="line-clamp-1 text-xs text-muted-foreground">
                        {collection.tagline}
                      </span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Category links with descriptions */}
          <div className="space-y-3">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Shop {item.label}
            </p>
            <ul className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
              {item.children?.map((child) => (
                <li key={child.href}>
                  <Link
                    href={child.href}
                    onClick={onClose}
                    className="group block rounded-md p-2 transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                  >
                    <span className="flex items-center gap-2">
                      <span className="text-sm font-medium text-foreground group-hover:text-primary">
                        {child.label}
                      </span>
                      {child.badge ? (
                        <span className="rounded-sm bg-primary/15 px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider text-primary">
                          {child.badge}
                        </span>
                      ) : null}
                    </span>
                    {child.description ? (
                      <span className="mt-0.5 block text-xs text-muted-foreground">
                        {child.description}
                      </span>
                    ) : null}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Promo card */}
          {promoCollection ? (
            <Link
              href={`/collections/${promoCollection.slug}`}
              onClick={onClose}
              className="group relative overflow-hidden rounded-lg border border-border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden">
                <Image
                  src={promoCollection.cover}
                  alt={promoCollection.name}
                  fill
                  sizes="(min-width: 768px) 320px, 100vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
              </div>
              <div className="absolute inset-x-0 bottom-0 p-3">
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-primary">
                  New Drop
                </p>
                <p className="text-sm font-semibold text-foreground">
                  {promoCollection.name}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Shop the capsule
                </p>
              </div>
            </Link>
          ) : null}
        </div>
      </div>
    </motion.div>
  );
}

export function Navigation({ className }: NavigationProps) {
  return (
    <Suspense fallback={null}>
      <NavigationInner className={className} />
    </Suspense>
  );
}

function NavigationInner({ className }: NavigationProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const search = searchParams.toString();
  const scrollY = useScrollPosition();
  const reducedMotion = useReducedMotion();
  const mounted = useMounted();

  const [openSection, setOpenSection] = useState<string | null>(null);
  const closeTimer = useRef<number | null>(null);

  const openCart = useCartStore((s) => s.openCart);
  const itemCount = useCartStore((s) => s.itemCount());
  const wishlistCount = useWishlistStore((s) => s.items.length);
  const openMobileMenu = useUIStore((s) => s.openMobileMenu);
  const openSearch = useSearchStore((s) => s.open);

  const isScrolled = scrollY > SCROLL_THRESHOLD;

  const handleEnter = (label: string) => {
    if (closeTimer.current !== null) {
      window.clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
    setOpenSection(label);
  };

  const handleLeave = () => {
    if (closeTimer.current !== null) {
      window.clearTimeout(closeTimer.current);
    }
    closeTimer.current = window.setTimeout(() => {
      setOpenSection(null);
    }, 120);
  };

  useEffect(() => {
    return () => {
      if (closeTimer.current !== null) {
        window.clearTimeout(closeTimer.current);
      }
    };
  }, []);

  const cartCount = mounted ? itemCount : 0;
  const heartCount = mounted ? wishlistCount : 0;

  const headerVariants = reducedMotion
    ? { initial: { opacity: 1 }, animate: { opacity: 1 } }
    : { initial: { y: -100, opacity: 0 }, animate: { y: 0, opacity: 1 } };

  const activeNavItem = navItems.find((item) => isPathForItem(pathname, search, item));
  const activeSection = openSection
    ? navItems.find((item) => item.label === openSection) ?? null
    : null;

  return (
    <motion.header
      {...headerVariants}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className={cn(
        "sticky top-0 z-50 w-full transition-colors duration-300",
        isScrolled
          ? "bg-background/95 backdrop-blur-md border-b border-border"
          : "border-b border-transparent bg-transparent",
        className
      )}
    >
      <nav
        aria-label="Primary"
        className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 lg:px-8"
      >
        {/* Left: mobile hamburger + logo */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={openMobileMenu}
            aria-label="Open menu"
            className="inline-flex size-10 items-center justify-center rounded-md text-foreground transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary lg:hidden"
          >
            <Menu className="size-5" aria-hidden="true" />
          </button>

          <Link
            href="/"
            aria-label="VoltHaus home"
            className="group flex items-center gap-2 text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-md"
          >
            <Logo height={26} className="transition-transform group-hover:scale-105" />
          </Link>
        </div>

        {/* Center: desktop nav */}
        <div
          className="hidden flex-1 items-center justify-center lg:flex"
          onMouseLeave={handleLeave}
        >
          <ul className="flex items-center gap-1">
            {navItems.map((item) => {
              const active = activeNavItem?.label === item.label;
              return (
                <li
                  key={item.label}
                  onMouseEnter={() =>
                    item.children?.length ? handleEnter(item.label) : undefined
                  }
                  onFocus={() =>
                    item.children?.length ? handleEnter(item.label) : undefined
                  }
                >
                  <NavLink
                    item={item}
                    active={active}
                    reducedMotion={reducedMotion}
                  />
                </li>
              );
            })}
          </ul>

          <AnimatePresence>
            {activeSection && activeSection.children?.length ? (
              <MegaMenuPanel
                item={activeSection}
                reducedMotion={reducedMotion}
                onClose={() => setOpenSection(null)}
              />
            ) : null}
          </AnimatePresence>
        </div>

        {/* Right: actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={openSearch}
            aria-label="Search"
            className="inline-flex size-10 items-center justify-center rounded-md text-foreground transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <Search className="size-5" aria-hidden="true" />
          </button>

          <Link
            href="/wishlist"
            aria-label={`Wishlist, ${heartCount} item${heartCount === 1 ? "" : "s"}`}
            className="relative inline-flex size-10 items-center justify-center rounded-md text-foreground transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <Heart className="size-5" aria-hidden="true" />
            {heartCount > 0 ? (
              <span
                aria-hidden="true"
                className="absolute -right-0.5 -top-0.5 inline-flex size-4 items-center justify-center rounded-full bg-secondary text-[10px] font-semibold text-secondary-foreground"
              >
                {heartCount > 9 ? "9+" : heartCount}
              </span>
            ) : null}
          </Link>

          <Link
            href="/account"
            aria-label="Account"
            className="hidden size-10 items-center justify-center rounded-md text-foreground transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary sm:inline-flex"
          >
            <User className="size-5" aria-hidden="true" />
          </Link>

          <ThemeToggle className="hidden sm:inline-flex" />

          <button
            type="button"
            onClick={openCart}
            aria-label={`Open cart, ${cartCount} item${cartCount === 1 ? "" : "s"}`}
            className="relative inline-flex size-10 items-center justify-center rounded-md text-foreground transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <ShoppingBag className="size-5" aria-hidden="true" />
            {cartCount > 0 ? (
              <span
                aria-hidden="true"
                className="absolute -right-0.5 -top-0.5 inline-flex size-4 items-center justify-center rounded-full bg-primary text-[10px] font-semibold text-primary-foreground"
              >
                {cartCount > 9 ? "9+" : cartCount}
              </span>
            ) : null}
          </button>

          <Link
            href="/sign-up"
            className="btn-shine ml-1 hidden h-9 items-center rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background lg:inline-flex"
          >
            Join the drop
          </Link>
        </div>
      </nav>
    </motion.header>
  );
}

export default Navigation;
