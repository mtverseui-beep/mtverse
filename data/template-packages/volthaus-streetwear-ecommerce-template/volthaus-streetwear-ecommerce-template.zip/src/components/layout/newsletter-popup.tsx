"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Mail, Sparkles, X } from "lucide-react";
import { useUIStore } from "@/store/ui-store";
import { useReducedMotion } from "@/hooks";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "volthaus-newsletter-shown";
const OPEN_DELAY_MS = 30_000;
const SUCCESS_AUTO_CLOSE_MS = 3_000;

type Status = "idle" | "submitting" | "success";

function hasBeenShown(): boolean {
  if (typeof window === "undefined") return true;
  try {
    return window.sessionStorage.getItem(STORAGE_KEY) === "1";
  } catch {
    return true;
  }
}

function markShown(): void {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(STORAGE_KEY, "1");
  } catch {
    // Ignore storage errors.
  }
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export interface NewsletterPopupProps {
  className?: string;
}

export function NewsletterPopup({ className }: NewsletterPopupProps) {
  const isOpen = useUIStore((s) => s.isNewsletterOpen);
  const openNewsletter = useUIStore((s) => s.openNewsletter);
  const closeNewsletter = useUIStore((s) => s.closeNewsletter);
  const reducedMotion = useReducedMotion();

  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);

  // Auto-open after 30s if not shown this session.
  useEffect(() => {
    if (hasBeenShown()) return;
    const id = window.setTimeout(() => {
      openNewsletter();
      markShown();
    }, OPEN_DELAY_MS);
    return () => window.clearTimeout(id);
  }, [openNewsletter]);

  // Escape to close
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeNewsletter();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, closeNewsletter]);

  // Auto-close after success
  useEffect(() => {
    if (status !== "success") return;
    const id = window.setTimeout(() => {
      closeNewsletter();
      // Reset for next time
      const resetId = window.setTimeout(() => {
        setStatus("idle");
        setEmail("");
        setError(null);
      }, 400);
      return () => window.clearTimeout(resetId);
    }, SUCCESS_AUTO_CLOSE_MS);
    return () => window.clearTimeout(id);
  }, [status, closeNewsletter]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!EMAIL_REGEX.test(trimmed)) {
      setError("Enter a valid email address.");
      return;
    }
    setError(null);
    setStatus("submitting");
    // Simulate async submission
    window.setTimeout(() => {
      setStatus("success");
    }, 600);
  };

  const handleBackdropClick = () => {
    closeNewsletter();
  };

  const handleStop = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  const backdropVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
    : { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } };

  const cardVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
    : {
        initial: { scale: 0.92, opacity: 0, y: 20 },
        animate: { scale: 1, opacity: 1, y: 0 },
        exit: { scale: 0.92, opacity: 0, y: 20 },
      };

  return (
    <AnimatePresence>
      {isOpen ? (
        <motion.div
          key="newsletter-popup"
          className="fixed inset-0 z-[95] flex items-end justify-center sm:items-center sm:p-4"
          aria-modal="true"
          role="dialog"
          aria-label="Newsletter signup"
          onClick={handleBackdropClick}
        >
          <motion.div
            {...backdropVariants}
            transition={{ duration: 0.24, ease: "easeOut" }}
            className="absolute inset-0 bg-background/80 backdrop-blur-sm"
            aria-hidden="true"
          />

          <motion.div
            {...cardVariants}
            transition={{ type: "spring", stiffness: 240, damping: 24 }}
            onClick={handleStop}
            className={cn(
              "bg-card glow-primary relative w-full max-w-md overflow-hidden rounded-t-2xl border border-primary/40 sm:rounded-2xl",
              className
            )}
          >
            {/* Decorative gradient strip */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent"
            />

            <button
              type="button"
              onClick={closeNewsletter}
              aria-label="Close newsletter signup"
              className="absolute right-3 top-3 inline-flex size-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted/40 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <X className="size-4" aria-hidden="true" />
            </button>

            <div className="px-6 py-8 sm:px-8 sm:py-10">
              {status === "success" ? (
                <div className="flex flex-col items-center text-center">
                  <span
                    className="mb-4 inline-flex size-14 items-center justify-center rounded-full bg-primary/15 text-primary"
                    aria-hidden="true"
                  >
                    <Check className="size-6" />
                  </span>
                  <h2 className="text-xl font-semibold text-foreground">
                    You&apos;re on the list
                  </h2>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Check your inbox to confirm your spot in the Static Club.
                  </p>
                </div>
              ) : (
                <>
                  <span
                    className="mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.2em] text-primary"
                  >
                    <Sparkles className="size-3" aria-hidden="true" />
                    Static Club
                  </span>
                  <h2 className="text-2xl font-semibold leading-tight text-foreground sm:text-3xl">
                    Get early access to drops
                  </h2>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Join the Static Club for member-only releases, 10% off your
                    first order, and early access to every drop.
                  </p>

                  <form onSubmit={handleSubmit} className="mt-6 space-y-3" noValidate>
                    <div className="relative">
                      <Mail
                        className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                        aria-hidden="true"
                      />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com"
                        aria-label="Email address"
                        aria-invalid={error ? "true" : "false"}
                        aria-describedby={error ? "newsletter-error" : undefined}
                        className="h-11 w-full rounded-md border border-input bg-input/30 pl-10 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                      />
                    </div>
                    {error ? (
                      <p
                        id="newsletter-error"
                        className="text-xs text-destructive"
                        role="alert"
                      >
                        {error}
                      </p>
                    ) : null}
                    <button
                      type="submit"
                      disabled={status === "submitting"}
                      className="btn-shine flex h-11 w-full items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                    >
                      {status === "submitting" ? "Joining..." : "Join"}
                    </button>
                  </form>

                  <p className="mt-3 text-center text-[11px] text-muted-foreground">
                    By joining you agree to receive VoltHaus emails. Unsubscribe anytime.
                  </p>
                </>
              )}
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

export default NewsletterPopup;
