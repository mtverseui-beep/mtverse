"use client";

import { useEffect, useMemo, useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  Clock,
  Package,
  Search as SearchIcon,
  Sparkles,
  TrendingUp,
  X,
} from "lucide-react";
import { useSearchStore } from "@/store/search-store";
import { useReducedMotion } from "@/hooks";
import { cn } from "@/lib/utils";
import { searchProducts } from "@/data/products";
import { collections } from "@/data/collections";
import { creators } from "@/data/creators";
import { blogPosts } from "@/data/blog";
import type { Product, Collection, Creator, BlogPost } from "@/types";

const POPULAR_PRODUCT_SLUGS = [
  "volt-runner-01",
  "static-club-hoodie",
  "chrome-district-cargo",
  "after-dark-windbreaker",
];

interface SearchOverlayProps {
  className?: string;
}

function formatPrice(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
  }).format(value);
}

export function SearchOverlay({ className }: SearchOverlayProps) {
  const isOpen = useSearchStore((s) => s.isSearchOpen);
  const query = useSearchStore((s) => s.query);
  const setQuery = useSearchStore((s) => s.setQuery);
  const recentSearches = useSearchStore((s) => s.recentSearches);
  const trendingSearches = useSearchStore((s) => s.trendingSearches);
  const close = useSearchStore((s) => s.close);
  const addRecentSearch = useSearchStore((s) => s.addRecentSearch);

  const pathname = usePathname();
  const router = useRouter();
  const reducedMotion = useReducedMotion();
  const inputRef = useRef<HTMLInputElement>(null);

  // Lock body scroll when open
  useEffect(() => {
    if (!isOpen) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, [isOpen]);

  // Autofocus when opened
  useEffect(() => {
    if (!isOpen) return;
    const id = window.setTimeout(() => {
      inputRef.current?.focus();
    }, 150);
    return () => window.clearTimeout(id);
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, close]);

  // Close on route change
  useEffect(() => {
    close();
  }, [pathname, close]);

  const trimmed = query.trim();
  const results = useMemo(() => {
    if (!trimmed) {
      return {
        products: [] as Product[],
        collections: [] as Collection[],
        creators: [] as Creator[],
        blogPosts: [] as BlogPost[],
      };
    }
    const lower = trimmed.toLowerCase();
    const products = searchProducts(trimmed).slice(0, 6);
    const collectionsList = collections
      .filter(
        (c) =>
          c.name.toLowerCase().includes(lower) ||
          c.tagline.toLowerCase().includes(lower)
      )
      .slice(0, 4);
    const creatorsList = creators
      .filter(
        (c) =>
          c.name.toLowerCase().includes(lower) ||
          c.role.toLowerCase().includes(lower) ||
          c.handle.toLowerCase().includes(lower)
      )
      .slice(0, 4);
    const blogList = blogPosts
      .filter(
        (b) =>
          b.title.toLowerCase().includes(lower) ||
          b.excerpt.toLowerCase().includes(lower) ||
          b.tags.some((tag) => tag.toLowerCase().includes(lower))
      )
      .slice(0, 4);
    return {
      products,
      collections: collectionsList,
      creators: creatorsList,
      blogPosts: blogList,
    };
  }, [trimmed]);

  const popularProducts = useMemo(() => {
    return POPULAR_PRODUCT_SLUGS.map((slug) =>
      searchProducts(slug).find((p) => p.slug === slug)
    ).filter((p): p is Product => Boolean(p));
  }, []);

  const overlayVariants = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
    : {
        initial: { y: "-100%" },
        animate: { y: 0 },
        exit: { y: "-100%" },
      };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trimmed) return;
    addRecentSearch(trimmed);
    router.push(`/search?q=${encodeURIComponent(trimmed)}`);
    close();
  };

  const handleSuggestionClick = (term: string) => {
    setQuery(term);
    addRecentSearch(term);
    router.push(`/search?q=${encodeURIComponent(term)}`);
    close();
  };

  const hasResults =
    trimmed &&
    (results.products.length > 0 ||
      results.collections.length > 0 ||
      results.creators.length > 0 ||
      results.blogPosts.length > 0);

  return (
    <AnimatePresence>
      {isOpen ? (
        <motion.div
          key="search-overlay"
          className="fixed inset-0 z-[90]"
          aria-modal="true"
          role="dialog"
          aria-label="Search"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 bg-background/80 backdrop-blur-sm"
            onClick={close}
            aria-hidden="true"
          />

          <motion.div
            {...overlayVariants}
            transition={{ type: "tween", duration: 0.32, ease: "easeOut" }}
            className={cn(
              "bg-background absolute inset-x-0 top-0 flex max-h-[100dvh] flex-col border-b border-border",
              className
            )}
          >
            {/* Search bar */}
            <div className="mx-auto w-full max-w-3xl px-4 pt-6 sm:px-6">
              <form onSubmit={handleSubmit} className="relative">
                <SearchIcon
                  className="pointer-events-none absolute left-3 top-1/2 size-5 -translate-y-1/2 text-muted-foreground"
                  aria-hidden="true"
                />
                <input
                  ref={inputRef}
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search drops, sneakers, collections, creators..."
                  aria-label="Search VoltHaus"
                  className="h-14 w-full rounded-md border border-input bg-input/30 pl-11 pr-12 text-base text-foreground placeholder:text-muted-foreground focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                />
                <button
                  type="button"
                  onClick={close}
                  aria-label="Close search"
                  className="absolute right-2 top-1/2 inline-flex size-10 -translate-y-1/2 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted/40 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                >
                  <X className="size-5" aria-hidden="true" />
                </button>
              </form>
            </div>

            {/* Results / suggestions */}
            <div className="mx-auto w-full max-w-3xl flex-1 overflow-y-auto px-4 pb-8 pt-4 sm:px-6 no-scrollbar">
              {!trimmed ? (
                <div className="space-y-8">
                  {/* Trending */}
                  <section>
                    <h3 className="mb-3 flex items-center gap-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                      <TrendingUp className="size-3.5 text-primary" aria-hidden="true" />
                      Trending
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {trendingSearches.map((term) => (
                        <button
                          key={term}
                          type="button"
                          onClick={() => handleSuggestionClick(term)}
                          className="rounded-full border border-border bg-muted/40 px-3 py-1.5 text-sm text-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </section>

                  {/* Recent */}
                  {recentSearches.length > 0 ? (
                    <section>
                      <h3 className="mb-3 flex items-center gap-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                        <Clock className="size-3.5 text-muted-foreground" aria-hidden="true" />
                        Recent searches
                      </h3>
                      <ul className="space-y-1">
                        {recentSearches.map((term) => (
                          <li key={term}>
                            <button
                              type="button"
                              onClick={() => handleSuggestionClick(term)}
                              className="flex w-full items-center justify-between rounded-md px-2 py-2 text-left text-sm text-foreground transition-colors hover:bg-muted/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                            >
                              <span className="flex items-center gap-2">
                                <SearchIcon className="size-4 text-muted-foreground" aria-hidden="true" />
                                {term}
                              </span>
                              <ArrowRight className="size-4 text-muted-foreground" aria-hidden="true" />
                            </button>
                          </li>
                        ))}
                      </ul>
                    </section>
                  ) : null}

                  {/* Popular products */}
                  {popularProducts.length > 0 ? (
                    <section>
                      <h3 className="mb-3 flex items-center gap-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                        <Sparkles className="size-3.5 text-secondary" aria-hidden="true" />
                        Popular right now
                      </h3>
                      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                        {popularProducts.map((product) => (
                          <li key={product.id}>
                            <Link
                              href={`/products/${product.slug}`}
                              onClick={close}
                              className="group block overflow-hidden rounded-lg border border-border transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                            >
                              <div className="relative aspect-square w-full overflow-hidden">
                                <Image
                                  src={product.images[0]}
                                  alt={product.name}
                                  fill
                                  sizes="(min-width: 640px) 25vw, 50vw"
                                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                                />
                              </div>
                              <div className="p-2">
                                <p className="truncate text-xs font-medium text-foreground">
                                  {product.name}
                                </p>
                                <p className="font-mono text-xs text-primary">
                                  {formatPrice(product.price)}
                                </p>
                              </div>
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </section>
                  ) : null}
                </div>
              ) : hasResults ? (
                <div className="space-y-8">
                  {/* Product matches */}
                  {results.products.length > 0 ? (
                    <section>
                      <h3 className="mb-3 flex items-center gap-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                        <Package className="size-3.5 text-primary" aria-hidden="true" />
                        Products ({results.products.length})
                      </h3>
                      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                        {results.products.map((product) => (
                          <li key={product.id}>
                            <Link
                              href={`/products/${product.slug}`}
                              onClick={close}
                              className="group flex items-center gap-3 rounded-md border border-border p-2 transition-colors hover:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                            >
                              <div className="relative size-14 shrink-0 overflow-hidden rounded-md">
                                <Image
                                  src={product.images[0]}
                                  alt={product.name}
                                  fill
                                  sizes="56px"
                                  className="object-cover"
                                />
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="truncate text-sm font-medium text-foreground group-hover:text-primary">
                                  {product.name}
                                </p>
                                <p className="truncate text-xs text-muted-foreground">
                                  {product.category}
                                </p>
                                <p className="font-mono text-xs text-primary">
                                  {formatPrice(product.price)}
                                </p>
                              </div>
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </section>
                  ) : null}

                  {/* Collections + creators */}
                  {(results.collections.length > 0 || results.creators.length > 0) ? (
                    <section className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                      {results.collections.length > 0 ? (
                        <div>
                          <h3 className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                            Collections
                          </h3>
                          <ul className="space-y-1">
                            {results.collections.map((collection) => (
                              <li key={collection.id}>
                                <Link
                                  href={`/collections/${collection.slug}`}
                                  onClick={close}
                                  className="flex items-center justify-between rounded-md px-2 py-2 text-sm text-foreground transition-colors hover:bg-muted/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                                >
                                  <span className="flex items-center gap-2">
                                    <span
                                      className="size-2 rounded-full"
                                      style={{ backgroundColor: collection.theme.primary }}
                                      aria-hidden="true"
                                    />
                                    {collection.name}
                                  </span>
                                  <ArrowRight className="size-4 text-muted-foreground" aria-hidden="true" />
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ) : null}

                      {results.creators.length > 0 ? (
                        <div>
                          <h3 className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                            Creators
                          </h3>
                          <ul className="space-y-1">
                            {results.creators.map((creator) => (
                              <li key={creator.id}>
                                <Link
                                  href={`/creators/${creator.slug}`}
                                  onClick={close}
                                  className="flex items-center justify-between rounded-md px-2 py-2 text-sm text-foreground transition-colors hover:bg-muted/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                                >
                                  <span className="flex items-center gap-2">
                                    <span className="relative size-6 overflow-hidden rounded-full">
                                      <Image
                                        src={creator.avatar}
                                        alt=""
                                        fill
                                        sizes="24px"
                                        className="object-cover"
                                      />
                                    </span>
                                    <span>
                                      <span className="block">{creator.name}</span>
                                      <span className="block text-xs text-muted-foreground">
                                        {creator.role}
                                      </span>
                                    </span>
                                  </span>
                                  <ArrowRight className="size-4 text-muted-foreground" aria-hidden="true" />
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ) : null}
                    </section>
                  ) : null}

                  {/* Blog matches */}
                  {results.blogPosts.length > 0 ? (
                    <section>
                      <h3 className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
                        From the Journal
                      </h3>
                      <ul className="space-y-1">
                        {results.blogPosts.map((post) => (
                          <li key={post.id}>
                            <Link
                              href={`/blog/${post.slug}`}
                              onClick={close}
                              className="flex items-center justify-between rounded-md px-2 py-2 text-sm text-foreground transition-colors hover:bg-muted/40 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                            >
                              <span className="truncate pr-3">{post.title}</span>
                              <ArrowRight className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </section>
                  ) : null}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="mb-3 inline-flex size-12 items-center justify-center rounded-full border border-border text-muted-foreground">
                    <SearchIcon className="size-5" aria-hidden="true" />
                  </div>
                  <p className="text-sm font-medium text-foreground">
                    No matches for &ldquo;{trimmed}&rdquo;
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Try a different term or browse the catalog.
                  </p>
                  <Link
                    href="/shop"
                    onClick={close}
                    className="mt-4 inline-flex h-9 items-center rounded-full border border-border px-4 text-sm text-foreground transition-colors hover:border-primary hover:text-primary"
                  >
                    Browse all products
                  </Link>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

export default SearchOverlay;
