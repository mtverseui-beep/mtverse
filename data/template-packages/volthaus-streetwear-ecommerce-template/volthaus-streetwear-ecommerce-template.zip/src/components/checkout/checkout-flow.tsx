"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Apple,
  Check,
  ChevronLeft,
  CreditCard,
  Gift,
  Lock,
  Package,
  ShieldCheck,
  ShoppingBag,
  Tag,
  Truck,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useCartStore } from "@/store/cart-store";
import { useToastStore } from "@/store/toast-store";
import { useMounted, useReducedMotion } from "@/hooks";
import { Breadcrumbs, PriceDisplay } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export interface CheckoutFlowProps {
  /** Initial step (when arriving via /checkout/shipping etc.) */
  step?: "information" | "shipping" | "payment" | "review";
}

type Step = "information" | "shipping" | "payment" | "review";

const STEP_ORDER: Step[] = ["information", "shipping", "payment", "review"];
const STEP_LABEL: Record<Step, string> = {
  information: "Information",
  shipping: "Shipping",
  payment: "Payment",
  review: "Review",
};

const FREE_SHIPPING_THRESHOLD = 100;
const DEFAULT_SHIPPING = 5;
const EXPRESS_SHIPPING = 12;
const TAX_RATE = 0.08;

function formatPrice(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(value);
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ZIP_REGEX = /^[0-9A-Za-z\s-]{3,10}$/;

export function CheckoutFlow({ step: initialStep = "information" }: CheckoutFlowProps) {
  const mounted = useMounted();
  const prefersReduced = useReducedMotion();
  const router = useRouter();
  const items = useCartStore((s) => s.items);
  const coupon = useCartStore((s) => s.coupon);
  const applyCoupon = useCartStore((s) => s.applyCoupon);
  const giftCard = useCartStore((s) => s.giftCard);
  const applyGiftCard = useCartStore((s) => s.applyGiftCard);
  const clearCart = useCartStore((s) => s.clearCart);
  const addToast = useToastStore((s) => s.addToast);

  const [step, setStep] = React.useState<Step>(initialStep);
  React.useEffect(() => {
    setStep(initialStep);
  }, [initialStep]);

  // Form state
  const [info, setInfo] = React.useState({
    email: "",
    firstName: "",
    lastName: "",
    phone: "",
    isGuest: true,
  });
  const [address, setAddress] = React.useState({
    line1: "",
    line2: "",
    city: "",
    state: "",
    zip: "",
    country: "United States",
    billingSameAsShipping: true,
  });
  const [deliveryMethod, setDeliveryMethod] = React.useState<
    "standard" | "express" | "free"
  >("standard");
  const [paymentMethod, setPaymentMethod] = React.useState<
    "card" | "apple-pay" | "paypal"
  >("card");
  const [card, setCard] = React.useState({
    number: "",
    name: "",
    expiry: "",
    cvc: "",
  });
  const [billingAddress, setBillingAddress] = React.useState({
    line1: "",
    line2: "",
    city: "",
    state: "",
    zip: "",
    country: "United States",
  });

  const [couponCode, setCouponCode] = React.useState("");
  const [giftCardCode, setGiftCardCode] = React.useState("");
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [submitting, setSubmitting] = React.useState(false);
  const [summaryOpen, setSummaryOpen] = React.useState(false);

  // Computed totals
  const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);
  const discount = coupon ? (subtotal * coupon.discountPercent) / 100 : 0;
  const afterDiscount = Math.max(0, subtotal - discount);
  const freeShippingUnlocked = afterDiscount >= FREE_SHIPPING_THRESHOLD;
  const shipping =
    deliveryMethod === "express"
      ? EXPRESS_SHIPPING
      : deliveryMethod === "free" || freeShippingUnlocked
        ? 0
        : DEFAULT_SHIPPING;
  const tax = afterDiscount * TAX_RATE;
  const giftCardValue = giftCard?.amount ?? 0;
  const total = Math.max(0, afterDiscount + shipping + tax - giftCardValue);

  // ---------------- Validation ----------------
  const validateInfo = (): boolean => {
    const e: Record<string, string> = {};
    if (!EMAIL_REGEX.test(info.email)) e.email = "Enter a valid email address.";
    if (!info.firstName.trim()) e.firstName = "First name is required.";
    if (!info.lastName.trim()) e.lastName = "Last name is required.";
    if (info.phone && info.phone.replace(/[^0-9]/g, "").length < 7)
      e.phone = "Enter a valid phone number.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const validateShipping = (): boolean => {
    const e: Record<string, string> = {};
    if (!address.line1.trim()) e.line1 = "Address is required.";
    if (!address.city.trim()) e.city = "City is required.";
    if (!address.state.trim()) e.state = "State is required.";
    if (!ZIP_REGEX.test(address.zip)) e.zip = "Enter a valid ZIP / postal code.";
    if (!address.billingSameAsShipping) {
      if (!billingAddress.line1.trim()) e.billingLine1 = "Billing address is required.";
      if (!billingAddress.city.trim()) e.billingCity = "Billing city is required.";
      if (!billingAddress.state.trim()) e.billingState = "Billing state is required.";
      if (!ZIP_REGEX.test(billingAddress.zip)) e.billingZip = "Enter a valid billing ZIP.";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const validatePayment = (): boolean => {
    if (paymentMethod !== "card") return true;
    const e: Record<string, string> = {};
    const digits = card.number.replace(/\s/g, "");
    if (digits.length < 13 || digits.length > 19)
      e.cardNumber = "Enter a valid card number.";
    if (!card.name.trim()) e.cardName = "Name on card is required.";
    if (!/^\d{2}\s*\/\s*\d{2}$/.test(card.expiry))
      e.cardExpiry = "Use MM/YY format.";
    if (!/^\d{3,4}$/.test(card.cvc)) e.cardCvc = "3 or 4 digits.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  // ---------------- Step navigation ----------------
  const goNext = () => {
    const idx = STEP_ORDER.indexOf(step);
    if (idx < STEP_ORDER.length - 1) {
      setStep(STEP_ORDER[idx + 1]);
      if (typeof window !== "undefined")
        window.scrollTo({ top: 0, behavior: prefersReduced ? "auto" : "smooth" });
    }
  };
  const goBack = () => {
    const idx = STEP_ORDER.indexOf(step);
    if (idx > 0) {
      setStep(STEP_ORDER[idx - 1]);
      if (typeof window !== "undefined")
        window.scrollTo({ top: 0, behavior: prefersReduced ? "auto" : "smooth" });
    }
  };

  const handleInfoContinue = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateInfo()) goNext();
  };
  const handleShippingContinue = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateShipping()) goNext();
  };
  const handlePaymentContinue = (e: React.FormEvent) => {
    e.preventDefault();
    if (validatePayment()) goNext();
  };

  // ---------------- Place order ----------------
  const handlePlaceOrder = async () => {
    setSubmitting(true);
    // Mock API delay
    await new Promise((resolve) => setTimeout(resolve, 1200));
    const orderNumber = `VH-${Math.floor(100000 + Math.random() * 900000)}`;
    clearCart();
    setSubmitting(false);
    addToast({
      title: "Order placed",
      description: orderNumber,
      variant: "success",
    });
    router.push(`/order/success?order=${orderNumber}&email=${encodeURIComponent(info.email)}`);
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;
    const ok = applyCoupon(couponCode);
    if (ok) {
      addToast({
        title: "Coupon applied",
        description: couponCode.toUpperCase(),
        variant: "success",
      });
      setCouponCode("");
    } else {
      addToast({
        title: "Invalid coupon",
        description: "Try VOLTHAUS10, DROP15, or STATIC20.",
        variant: "error",
      });
    }
  };

  const handleApplyGiftCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!giftCardCode.trim()) return;
    const ok = applyGiftCard(giftCardCode);
    if (ok) {
      addToast({
        title: "Gift card applied",
        description: giftCardCode.toUpperCase(),
        variant: "success",
      });
      setGiftCardCode("");
    } else {
      addToast({
        title: "Invalid gift card",
        description: "Try GIFT50 for a $50 balance.",
        variant: "error",
      });
    }
  };

  // ---------------- Empty cart guard ----------------
  if (mounted && items.length === 0) {
    return (
      <div className="container mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Checkout" }]} className="mb-6" />
        <div className="rounded-xl border border-border bg-card p-12 text-center">
          <Package className="mx-auto h-10 w-10 text-muted-foreground" />
          <h1 className="mt-4 text-xl font-bold text-foreground">
            Your cart is empty
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Add a few drops before heading to checkout.
          </p>
          <Button asChild className="mt-6">
            <Link href="/shop">Browse drops</Link>
          </Button>
        </div>
      </div>
    );
  }

  if (!mounted) {
    return (
      <div className="container mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <p className="text-sm text-muted-foreground">Loading checkout…</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-10">
      <Breadcrumbs items={[{ label: "Checkout" }]} className="mb-6" />

      {/* Stepper */}
      <nav aria-label="Checkout progress" className="mb-8">
        <ol className="flex flex-wrap items-center gap-2 text-sm">
          {STEP_ORDER.map((s, i) => {
            const isActive = s === step;
            const isDone = STEP_ORDER.indexOf(step) > i;
            return (
              <li key={s} className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (STEP_ORDER.indexOf(s) < STEP_ORDER.indexOf(step))
                      setStep(s);
                  }}
                  disabled={STEP_ORDER.indexOf(s) > STEP_ORDER.indexOf(step)}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : isDone
                        ? "bg-primary/15 text-primary hover:bg-primary/25"
                        : "bg-muted/40 text-muted-foreground"
                  )}
                  aria-current={isActive ? "step" : undefined}
                >
                  <span
                    className={cn(
                      "inline-flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold",
                      isActive
                        ? "bg-primary-foreground text-primary"
                        : isDone
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted-foreground/30 text-foreground"
                    )}
                  >
                    {isDone ? <Check className="h-3 w-3" /> : i + 1}
                  </span>
                  {STEP_LABEL[s]}
                </button>
                {i < STEP_ORDER.length - 1 && (
                  <ChevronLeft className="h-3 w-3 rotate-180 text-muted-foreground/40" />
                )}
              </li>
            );
          })}
        </ol>
      </nav>

      <div className="grid gap-8 lg:grid-cols-[1fr_380px] lg:items-start">
        {/* Form column */}
        <div className="order-2 lg:order-1">
          {step === "information" && (
            <form
              onSubmit={handleInfoContinue}
              className="rounded-xl border border-border bg-card p-6"
            >
              <h2 className="text-lg font-bold text-foreground">
                Contact information
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                We'll send your order confirmation and updates here.
              </p>
              <div className="mt-5 flex flex-col gap-4">
                <Field
                  id="email"
                  label="Email address"
                  required
                  value={info.email}
                  onChange={(v) => setInfo((s) => ({ ...s, email: v }))}
                  type="email"
                  error={errors.email}
                  autoComplete="email"
                />
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field
                    id="firstName"
                    label="First name"
                    required
                    value={info.firstName}
                    onChange={(v) => setInfo((s) => ({ ...s, firstName: v }))}
                    error={errors.firstName}
                    autoComplete="given-name"
                  />
                  <Field
                    id="lastName"
                    label="Last name"
                    required
                    value={info.lastName}
                    onChange={(v) => setInfo((s) => ({ ...s, lastName: v }))}
                    error={errors.lastName}
                    autoComplete="family-name"
                  />
                </div>
                <Field
                  id="phone"
                  label="Phone (optional)"
                  value={info.phone}
                  onChange={(v) => setInfo((s) => ({ ...s, phone: v }))}
                  type="tel"
                  error={errors.phone}
                  autoComplete="tel"
                />
              </div>
              <div className="mt-5 flex items-center justify-between gap-3">
                <Link
                  href="/sign-in"
                  className="text-xs text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                >
                  Sign in for faster checkout
                </Link>
                <label className="flex items-center gap-2 text-xs text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={info.isGuest}
                    onChange={(e) =>
                      setInfo((s) => ({ ...s, isGuest: e.target.checked }))
                    }
                    className="size-4 rounded border-border"
                  />
                  Continue as guest
                </label>
              </div>
              <div className="mt-6 flex justify-end">
                <Button type="submit" size="lg" className="btn-shine">
                  Continue to shipping
                </Button>
              </div>
            </form>
          )}

          {step === "shipping" && (
            <form
              onSubmit={handleShippingContinue}
              className="rounded-xl border border-border bg-card p-6"
            >
              <h2 className="text-lg font-bold text-foreground">
                Shipping address
              </h2>
              <div className="mt-5 flex flex-col gap-4">
                <Field
                  id="line1"
                  label="Address line 1"
                  required
                  value={address.line1}
                  onChange={(v) => setAddress((s) => ({ ...s, line1: v }))}
                  error={errors.line1}
                  autoComplete="address-line1"
                />
                <Field
                  id="line2"
                  label="Address line 2 (optional)"
                  value={address.line2}
                  onChange={(v) => setAddress((s) => ({ ...s, line2: v }))}
                  autoComplete="address-line2"
                />
                <div className="grid gap-4 sm:grid-cols-3">
                  <Field
                    id="city"
                    label="City"
                    required
                    value={address.city}
                    onChange={(v) => setAddress((s) => ({ ...s, city: v }))}
                    error={errors.city}
                    autoComplete="address-level2"
                  />
                  <Field
                    id="state"
                    label="State"
                    required
                    value={address.state}
                    onChange={(v) => setAddress((s) => ({ ...s, state: v }))}
                    error={errors.state}
                    autoComplete="address-level1"
                  />
                  <Field
                    id="zip"
                    label="ZIP"
                    required
                    value={address.zip}
                    onChange={(v) => setAddress((s) => ({ ...s, zip: v }))}
                    error={errors.zip}
                    autoComplete="postal-code"
                  />
                </div>
                <Field
                  id="country"
                  label="Country"
                  value={address.country}
                  onChange={(v) => setAddress((s) => ({ ...s, country: v }))}
                  autoComplete="country-name"
                />

                <label className="flex items-center gap-2 text-sm text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={address.billingSameAsShipping}
                    onChange={(e) =>
                      setAddress((s) => ({
                        ...s,
                        billingSameAsShipping: e.target.checked,
                      }))
                    }
                    className="size-4 rounded border-border"
                  />
                  Billing address is the same as shipping
                </label>

                {!address.billingSameAsShipping && (
                  <div className="rounded-lg border border-border p-4 space-y-4">
                    <h3 className="text-sm font-semibold text-foreground">
                      Billing address
                    </h3>
                    <Field
                      id="billingLine1"
                      label="Address line 1"
                      required
                      value={billingAddress.line1}
                      onChange={(v) =>
                        setBillingAddress((s) => ({ ...s, line1: v }))
                      }
                      error={errors.billingLine1}
                    />
                    <div className="grid gap-4 sm:grid-cols-3">
                      <Field
                        id="billingCity"
                        label="City"
                        required
                        value={billingAddress.city}
                        onChange={(v) =>
                          setBillingAddress((s) => ({ ...s, city: v }))
                        }
                        error={errors.billingCity}
                      />
                      <Field
                        id="billingState"
                        label="State"
                        required
                        value={billingAddress.state}
                        onChange={(v) =>
                          setBillingAddress((s) => ({ ...s, state: v }))
                        }
                        error={errors.billingState}
                      />
                      <Field
                        id="billingZip"
                        label="ZIP"
                        required
                        value={billingAddress.zip}
                        onChange={(v) =>
                          setBillingAddress((s) => ({ ...s, zip: v }))
                        }
                        error={errors.billingZip}
                      />
                    </div>
                  </div>
                )}

                <div>
                  <h3 className="mb-2 text-sm font-semibold text-foreground">
                    Delivery method
                  </h3>
                  <RadioGroup
                    value={deliveryMethod}
                    onValueChange={(v) =>
                      setDeliveryMethod(v as typeof deliveryMethod)
                    }
                    className="grid gap-2"
                  >
                    <DeliveryOption
                      value="standard"
                      label="Standard"
                      description="3–5 business days"
                      price={formatPrice(DEFAULT_SHIPPING)}
                      disabled={freeShippingUnlocked}
                    />
                    <DeliveryOption
                      value="express"
                      label="Express"
                      description="1–2 business days"
                      price={formatPrice(EXPRESS_SHIPPING)}
                    />
                    <DeliveryOption
                      value="free"
                      label="Free member shipping"
                      description="5–7 business days · Static Club members"
                      price="Free"
                      disabled={!freeShippingUnlocked}
                    />
                  </RadioGroup>
                  {freeShippingUnlocked && (
                    <p className="mt-2 text-xs text-success">
                      Free standard shipping unlocked — you saved {formatPrice(DEFAULT_SHIPPING)}.
                    </p>
                  )}
                </div>
              </div>
              <div className="mt-6 flex items-center justify-between">
                <Button type="button" variant="ghost" onClick={goBack}>
                  <ChevronLeft className="h-4 w-4" />
                  Back
                </Button>
                <Button type="submit" size="lg" className="btn-shine">
                  Continue to payment
                </Button>
              </div>
            </form>
          )}

          {step === "payment" && (
            <form
              onSubmit={handlePaymentContinue}
              className="rounded-xl border border-border bg-card p-6"
            >
              <h2 className="text-lg font-bold text-foreground">Payment</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                All transactions are encrypted and never stored on our servers.
              </p>

              <RadioGroup
                value={paymentMethod}
                onValueChange={(v) =>
                  setPaymentMethod(v as typeof paymentMethod)
                }
                className="mt-5 grid gap-2"
              >
                <PaymentOption
                  value="card"
                  label="Credit / debit card"
                  icon={<CreditCard className="h-4 w-4" />}
                />
                <PaymentOption
                  value="apple-pay"
                  label="Apple Pay"
                  icon={<Apple className="h-4 w-4" />}
                />
                <PaymentOption
                  value="paypal"
                  label="PayPal"
                  icon={<span className="text-xs font-bold">PP</span>}
                />
              </RadioGroup>

              {paymentMethod === "card" && (
                <div className="mt-5 flex flex-col gap-4">
                  <Field
                    id="cardNumber"
                    label="Card number"
                    required
                    value={card.number}
                    onChange={(v) => {
                      const digits = v.replace(/\D/g, "").slice(0, 19);
                      const grouped = digits.replace(/(.{4})/g, "$1 ").trim();
                      setCard((s) => ({ ...s, number: grouped }));
                    }}
                    error={errors.cardNumber}
                    placeholder="0000 0000 0000 0000"
                    inputMode="numeric"
                  />
                  <Field
                    id="cardName"
                    label="Name on card"
                    required
                    value={card.name}
                    onChange={(v) => setCard((s) => ({ ...s, name: v }))}
                    error={errors.cardName}
                  />
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field
                      id="cardExpiry"
                      label="Expiry (MM/YY)"
                      required
                      value={card.expiry}
                      onChange={(v) => {
                        const digits = v.replace(/\D/g, "").slice(0, 4);
                        const formatted = digits.length > 2
                          ? `${digits.slice(0, 2)}/${digits.slice(2)}`
                          : digits;
                        setCard((s) => ({ ...s, expiry: formatted }));
                      }}
                      error={errors.cardExpiry}
                      placeholder="MM/YY"
                      inputMode="numeric"
                    />
                    <Field
                      id="cardCvc"
                      label="CVC"
                      required
                      value={card.cvc}
                      onChange={(v) =>
                        setCard((s) => ({
                          ...s,
                          cvc: v.replace(/\D/g, "").slice(0, 4),
                        }))
                      }
                      error={errors.cardCvc}
                      placeholder="123"
                      inputMode="numeric"
                    />
                  </div>
                </div>
              )}

              {paymentMethod !== "card" && (
                <div className="mt-5 rounded-lg border border-border bg-background/40 p-4 text-sm text-muted-foreground">
                  You'll be redirected to {paymentMethod === "apple-pay" ? "Apple Pay" : "PayPal"} to complete your purchase after reviewing your order.
                </div>
              )}

              {/* Coupons + gift card */}
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <form
                  onSubmit={handleApplyCoupon}
                  className="rounded-lg border border-border p-3"
                >
                  <div className="mb-2 flex items-center gap-2 text-xs font-semibold text-foreground">
                    <Tag className="h-3.5 w-3.5 text-primary" /> Promo code
                  </div>
                  {coupon ? (
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-success">
                        {coupon.code} ({coupon.discountPercent}% off)
                      </span>
                      <span className="text-muted-foreground">Applied</span>
                    </div>
                  ) : (
                    <>
                      <Input
                        type="text"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        placeholder="VOLTHAUS10"
                        aria-label="Promo code"
                      />
                      <Button
                        type="submit"
                        variant="outline"
                        size="sm"
                        className="mt-2 w-full"
                      >
                        Apply coupon
                      </Button>
                    </>
                  )}
                </form>
                <form
                  onSubmit={handleApplyGiftCard}
                  className="rounded-lg border border-border p-3"
                >
                  <div className="mb-2 flex items-center gap-2 text-xs font-semibold text-foreground">
                    <Gift className="h-3.5 w-3.5 text-primary" /> Gift card
                  </div>
                  {giftCard ? (
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-success">
                        {giftCard.code} (${giftCard.amount.toFixed(2)})
                      </span>
                      <span className="text-muted-foreground">Applied</span>
                    </div>
                  ) : (
                    <>
                      <Input
                        type="text"
                        value={giftCardCode}
                        onChange={(e) => setGiftCardCode(e.target.value)}
                        placeholder="GIFT50"
                        aria-label="Gift card code"
                      />
                      <Button
                        type="submit"
                        variant="outline"
                        size="sm"
                        className="mt-2 w-full"
                      >
                        Apply gift card
                      </Button>
                    </>
                  )}
                </form>
              </div>

              <div className="mt-6 flex items-center justify-between">
                <Button type="button" variant="ghost" onClick={goBack}>
                  <ChevronLeft className="h-4 w-4" />
                  Back
                </Button>
                <Button type="submit" size="lg" className="btn-shine">
                  Review order
                </Button>
              </div>
            </form>
          )}

          {step === "review" && (
            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-bold text-foreground">
                Review your order
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Please confirm everything looks right before placing your order.
              </p>

              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <div className="rounded-lg border border-border p-4">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Contact
                  </h3>
                  <p className="mt-1 text-sm text-foreground">{info.email}</p>
                  {info.phone && (
                    <p className="text-sm text-muted-foreground">{info.phone}</p>
                  )}
                  <p className="text-sm text-foreground">
                    {info.firstName} {info.lastName}
                  </p>
                </div>
                <div className="rounded-lg border border-border p-4">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Shipping address
                  </h3>
                  <p className="mt-1 text-sm text-foreground">{address.line1}</p>
                  {address.line2 && (
                    <p className="text-sm text-foreground">{address.line2}</p>
                  )}
                  <p className="text-sm text-foreground">
                    {address.city}, {address.state} {address.zip}
                  </p>
                  <p className="text-sm text-foreground">{address.country}</p>
                </div>
                <div className="rounded-lg border border-border p-4">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Delivery
                  </h3>
                  <p className="mt-1 text-sm text-foreground">
                    {deliveryMethod === "express"
                      ? `Express · ${formatPrice(EXPRESS_SHIPPING)}`
                      : deliveryMethod === "free"
                        ? "Free member shipping"
                        : freeShippingUnlocked
                          ? "Standard · Free"
                          : `Standard · ${formatPrice(DEFAULT_SHIPPING)}`}
                  </p>
                </div>
                <div className="rounded-lg border border-border p-4">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Payment
                  </h3>
                  <p className="mt-1 text-sm text-foreground">
                    {paymentMethod === "card"
                      ? `Card ending ${card.number.replace(/\s/g, "").slice(-4) || "—"}`
                      : paymentMethod === "apple-pay"
                        ? "Apple Pay"
                        : "PayPal"}
                  </p>
                </div>
              </div>

              <ul className="mt-6 flex flex-col divide-y divide-border rounded-lg border border-border">
                {items.map((item) => (
                  <li
                    key={`${item.productId}-${item.size}-${item.color}`}
                    className="flex gap-3 p-3"
                  >
                    <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30">
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        sizes="64px"
                        className="object-cover"
                      />
                    </div>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <p className="text-sm font-semibold text-foreground">
                        {item.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {item.category} · Size {item.size} · {item.color}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Qty {item.quantity}
                      </p>
                    </div>
                    <PriceDisplay price={item.price * item.quantity} size="sm" />
                  </li>
                ))}
              </ul>

              <div className="mt-6 flex items-center justify-between">
                <Button type="button" variant="ghost" onClick={goBack}>
                  <ChevronLeft className="h-4 w-4" />
                  Back
                </Button>
                <Button
                  type="button"
                  size="lg"
                  onClick={handlePlaceOrder}
                  disabled={submitting}
                  className="btn-shine"
                >
                  {submitting ? (
                    <>
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground/40 border-t-primary-foreground" />
                      Placing order…
                    </>
                  ) : (
                    <>
                      <Lock className="h-4 w-4" />
                      Place order · {formatPrice(total)}
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}

          {/* Trust row */}
          <div className="mt-6 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-primary" />
              Secure SSL checkout
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Truck className="h-4 w-4 text-primary" />
              Free shipping over {formatPrice(FREE_SHIPPING_THRESHOLD)}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Package className="h-4 w-4 text-primary" />
              30-day returns
            </span>
          </div>
        </div>

        {/* Order summary column */}
        <aside className="order-1 lg:order-2 lg:sticky lg:top-28">
          {/* Mobile toggle */}
          <Button
            type="button"
            variant="outline"
            className="w-full justify-between lg:hidden"
            onClick={() => setSummaryOpen((v) => !v)}
            aria-expanded={summaryOpen}
          >
            <span>
              {summaryOpen ? "Hide" : "Show"} order summary ·{" "}
              {formatPrice(total)}
            </span>
            <ChevronLeft
              className={cn(
                "h-4 w-4 transition-transform",
                summaryOpen && "rotate-90"
              )}
            />
          </Button>

          <div
            className={cn(
              "mt-3 rounded-xl border border-border bg-card p-5",
              "lg:mt-0 lg:block",
              summaryOpen ? "block" : "hidden lg:block"
            )}
          >
            <h3 className="text-sm font-bold text-foreground">
              Order summary
            </h3>
            <ul className="mt-3 flex max-h-72 flex-col gap-3 overflow-y-auto pr-1 no-scrollbar">
              {items.map((item) => (
                <li
                  key={`${item.productId}-${item.size}-${item.color}`}
                  className="flex gap-3"
                >
                  <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-md border border-border bg-muted/30">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="56px"
                      className="object-cover"
                    />
                    <span className="absolute -right-1 -top-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                      {item.quantity}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="line-clamp-1 text-xs font-semibold text-foreground">
                      {item.name}
                    </p>
                    <p className="text-[11px] text-muted-foreground">
                      Size {item.size} · {item.color}
                    </p>
                  </div>
                  <span className="text-xs font-semibold text-foreground tabular-nums">
                    {formatPrice(item.price * item.quantity)}
                  </span>
                </li>
              ))}
            </ul>
            <dl className="mt-4 border-t border-border pt-4 flex flex-col gap-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Subtotal</dt>
                <dd className="font-semibold text-foreground tabular-nums">
                  {formatPrice(subtotal)}
                </dd>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-success">
                  <dt>Discount</dt>
                  <dd className="tabular-nums">−{formatPrice(discount)}</dd>
                </div>
              )}
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Shipping</dt>
                <dd className="font-semibold text-foreground tabular-nums">
                  {shipping === 0 ? "Free" : formatPrice(shipping)}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Tax</dt>
                <dd className="font-semibold text-foreground tabular-nums">
                  {formatPrice(tax)}
                </dd>
              </div>
              {giftCardValue > 0 && (
                <div className="flex justify-between text-success">
                  <dt>Gift card</dt>
                  <dd className="tabular-nums">−{formatPrice(giftCardValue)}</dd>
                </div>
              )}
              <div className="mt-2 border-t border-border pt-3 flex justify-between text-base">
                <dt className="font-bold text-foreground">Total</dt>
                <dd className="font-black text-foreground tabular-nums">
                  {formatPrice(total)}
                </dd>
              </div>
            </dl>
          </div>
        </aside>
      </div>
    </div>
  );
}

// ---------------- Field ----------------

interface FieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  error?: string;
  placeholder?: string;
  autoComplete?: string;
  inputMode?: "text" | "numeric" | "tel" | "email" | "url";
}

function Field({
  id,
  label,
  value,
  onChange,
  type = "text",
  required = false,
  error,
  placeholder,
  autoComplete,
  inputMode,
}: FieldProps) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id} className="text-xs font-medium text-muted-foreground">
        {label}
        {required && <span className="ml-0.5 text-destructive">*</span>}
      </Label>
      <Input
        id={id}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        autoComplete={autoComplete}
        inputMode={inputMode}
        aria-invalid={Boolean(error)}
        className={cn(error && "border-destructive")}
      />
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

// ---------------- Delivery / Payment options ----------------

function DeliveryOption({
  value,
  label,
  description,
  price,
  disabled,
}: {
  value: string;
  label: string;
  description: string;
  price: string;
  disabled?: boolean;
}) {
  return (
    <label
      className={cn(
        "flex items-center gap-3 rounded-lg border border-border p-3 transition-colors",
        disabled
          ? "opacity-50 cursor-not-allowed"
          : "cursor-pointer hover:border-primary/50"
      )}
    >
      <RadioGroupItem value={value} disabled={disabled} />
      <div className="flex-1">
        <p className="text-sm font-semibold text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <span className="text-sm font-semibold text-foreground">{price}</span>
    </label>
  );
}

function PaymentOption({
  value,
  label,
  icon,
}: {
  value: string;
  label: string;
  icon: React.ReactNode;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-border p-3 hover:border-primary/50 transition-colors">
      <RadioGroupItem value={value} />
      <span className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-primary">
        {icon}
      </span>
      <span className="text-sm font-semibold text-foreground">{label}</span>
    </label>
  );
}

export default CheckoutFlow;
