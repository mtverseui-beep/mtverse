"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

export interface MarqueeProps {
  children: React.ReactNode;
  /** Time in seconds for one full loop. Default 30 */
  speed?: number;
  /** Reverse direction. Default false */
  reverse?: boolean;
  /** Pause the animation when the cursor hovers over the marquee. Default true */
  pauseOnHover?: boolean;
  className?: string;
}

/**
 * Infinite horizontal marquee. Duplicates the children for a seamless loop
 * and uses the `vh-marquee` / `vh-marquee-reverse` CSS keyframes.
 *
 * Note: not strictly a client component (no hooks), but marked as such to
 * ensure consistent hydration of duplicated children across SSR/CSR.
 */
export function Marquee({
  children,
  speed = 30,
  reverse = false,
  pauseOnHover = true,
  className,
}: MarqueeProps) {
  const animationClass = reverse ? "animate-marquee-reverse" : "animate-marquee";

  return (
    <div
      className={cn(
        "group relative flex w-full overflow-hidden",
        className
      )}
    >
      <div
        aria-hidden={false}
        className={cn(
          "flex w-max shrink-0 items-center",
          animationClass,
          pauseOnHover && "group-hover:[animation-play-state:paused]"
        )}
        style={{ animationDuration: `${speed}s` }}
      >
        {children}
      </div>
      <div
        aria-hidden
        className={cn(
          "flex w-max shrink-0 items-center",
          animationClass,
          pauseOnHover && "group-hover:[animation-play-state:paused]"
        )}
        style={{ animationDuration: `${speed}s` }}
      >
        {children}
      </div>
    </div>
  );
}
