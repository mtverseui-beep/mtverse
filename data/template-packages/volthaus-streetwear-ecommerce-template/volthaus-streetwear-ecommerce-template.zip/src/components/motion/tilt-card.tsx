"use client";

import * as React from "react";
import {
  motion,
  useMotionTemplate,
  useMotionValue,
  useReducedMotion,
  useSpring,
  useTransform,
  type HTMLMotionProps,
} from "framer-motion";
import { cn } from "@/lib/utils";

export interface TiltCardProps extends HTMLMotionProps<"div"> {
  /** Maximum tilt in degrees. Default 12 */
  maxTilt?: number;
  /** Show the cursor-following shine overlay. Default true */
  glow?: boolean;
  /** Hover scale factor. Default 1.02 */
  scale?: number;
  /** Custom className */
  className?: string;
  /** Card content */
  children?: React.ReactNode;
}

/**
 * 3D tilt card. Tilts on the X/Y axis based on cursor position with a
 * spring-smoothed return-to-center, plus an optional cursor-tracking
 * radial shine overlay.
 *
 * Respects `prefers-reduced-motion`.
 */
export function TiltCard({
  children,
  className,
  maxTilt = 12,
  glow = true,
  scale = 1.02,
  ...props
}: TiltCardProps) {
  const prefersReduced = useReducedMotion();
  const ref = React.useRef<HTMLDivElement>(null);

  // Normalised cursor position within the card (0 - 1)
  const x = useMotionValue(0.5);
  const y = useMotionValue(0.5);

  const springConfig = React.useMemo(
    () => ({ stiffness: 300, damping: 30 }),
    []
  );
  const rotateX = useSpring(
    useTransform(y, [0, 1], [maxTilt, -maxTilt]),
    springConfig
  );
  const rotateY = useSpring(
    useTransform(x, [0, 1], [-maxTilt, maxTilt]),
    springConfig
  );

  // Shine overlay position (0% - 100%)
  const glareX = useTransform(x, [0, 1], ["0%", "100%"]);
  const glareY = useTransform(y, [0, 1], ["0%", "100%"]);
  const glareBg = useMotionTemplate`radial-gradient(circle at ${glareX} ${glareY}, rgba(0, 229, 255, 0.28), transparent 55%)`;

  const handleMouseMove = React.useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (!ref.current || prefersReduced) return;
      const rect = ref.current.getBoundingClientRect();
      x.set((e.clientX - rect.left) / rect.width);
      y.set((e.clientY - rect.top) / rect.height);
    },
    [prefersReduced, x, y]
  );

  const handleMouseLeave = React.useCallback(() => {
    x.set(0.5);
    y.set(0.5);
  }, [x, y]);

  const motionStyle = prefersReduced
    ? undefined
    : {
        rotateX,
        rotateY,
        scale,
        transformPerspective: 800,
      };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={cn(
        "group relative [transform-style:preserve-3d] will-change-transform",
        className
      )}
      style={motionStyle}
      {...props}
    >
      {children}
      {glow && !prefersReduced && (
        <motion.div
          aria-hidden
          className={cn(
            "pointer-events-none absolute inset-0 rounded-[inherit] opacity-0 transition-opacity duration-300 group-hover:opacity-100"
          )}
          style={{ background: glareBg }}
        />
      )}
    </motion.div>
  );
}
