export { MagneticButton } from "./magnetic-button";
export type { MagneticButtonProps, MagneticButtonVariant } from "./magnetic-button";

export { TiltCard } from "./tilt-card";
export type { TiltCardProps } from "./tilt-card";

export { ScrollReveal } from "./scroll-reveal";
export type { ScrollRevealProps } from "./scroll-reveal";

export { Marquee } from "./marquee";
export type { MarqueeProps } from "./marquee";

export { Parallax } from "./parallax";
export type { ParallaxProps } from "./parallax";

export { AnimatedCounter } from "./animated-counter";
export type { AnimatedCounterProps } from "./animated-counter";

export { ShineBorder } from "./shine-border";
export type { ShineBorderProps } from "./shine-border";
