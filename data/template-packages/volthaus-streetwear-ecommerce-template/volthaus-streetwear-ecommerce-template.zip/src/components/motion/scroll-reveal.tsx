"use client";

import * as React from "react";
import {
  motion,
  useInView,
  useReducedMotion,
  type Variants,
} from "framer-motion";
import { cn } from "@/lib/utils";

export interface ScrollRevealProps {
  children: React.ReactNode;
  className?: string;
  /** Animation delay in seconds */
  delay?: number;
  /** Initial Y offset to animate from. Default 40 */
  y?: number;
  /** Animate only once when scrolled into view. Default true */
  once?: boolean;
  /** Render as a different HTML element. Default 'div' */
  as?: keyof React.JSX.IntrinsicElements;
}

/**
 * Scroll-triggered reveal. Wraps children and fades+slides them into view
 * when they enter the viewport.
 *
 * Easing: `[0.25, 0.4, 0.25, 1]`, duration: 0.8s.
 *
 * Respects `prefers-reduced-motion` (renders children without animation).
 */
export function ScrollReveal({
  children,
  className,
  delay = 0,
  y = 40,
  once = true,
  as = "div",
}: ScrollRevealProps) {
  const ref = React.useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once, margin: "-80px" });
  const prefersReduced = useReducedMotion();

  const MotionTag = motion[as as "div"] as unknown as React.ElementType;

  const variants: Variants = React.useMemo(
    () => ({
      hidden: { opacity: prefersReduced ? 1 : 0, y: prefersReduced ? 0 : y },
      visible: { opacity: 1, y: 0 },
    }),
    [prefersReduced, y]
  );

  return (
    <MotionTag
      ref={ref}
      className={cn(className)}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      variants={variants}
      transition={{
        duration: 0.8,
        ease: [0.25, 0.4, 0.25, 1],
        delay,
      }}
    >
      {children}
    </MotionTag>
  );
}
