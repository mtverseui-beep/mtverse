"use client";

import * as React from "react";
import {
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
  type HTMLMotionProps,
} from "framer-motion";
import { cn } from "@/lib/utils";

export type MagneticButtonVariant =
  | "primary"
  | "secondary"
  | "outline"
  | "ghost";

const VARIANT_STYLES: Record<MagneticButtonVariant, string> = {
  primary:
    "bg-primary text-primary-foreground hover:bg-primary/90 glow-primary",
  secondary:
    "bg-secondary text-secondary-foreground hover:bg-secondary/90 glow-secondary",
  outline:
    "border border-border bg-transparent text-foreground hover:border-primary/50 hover:bg-card",
  ghost:
    "bg-transparent text-foreground hover:bg-card hover:text-primary",
};

type CommonMagneticProps = {
  /** Magnetic tracking strength (0-1). Default 0.3 */
  strength?: number;
  /** Visual variant */
  variant?: MagneticButtonVariant;
  /** Custom className */
  className?: string;
  /** Button content */
  children?: React.ReactNode;
};

type ButtonMagneticProps = CommonMagneticProps & {
  /** Render as button (default) */
  as?: "button";
} & Omit<HTMLMotionProps<"button">, "ref">;

type AnchorMagneticProps = CommonMagneticProps & {
  /** Render as anchor */
  as: "a";
} & Omit<HTMLMotionProps<"a">, "ref">;

export type MagneticButtonProps = ButtonMagneticProps | AnchorMagneticProps;

/**
 * Magnetic button — follows the cursor slightly on hover with a spring return.
 * Includes a built-in shine effect via the `.btn-shine` utility class.
 *
 * Variants: `primary` (cyan), `secondary` (magenta), `outline` (border only),
 * `ghost` (transparent).
 *
 * Polymorphic: `as="button"` (default) or `as="a"` for links.
 *
 * Respects `prefers-reduced-motion`.
 */
export function MagneticButton(props: MagneticButtonProps) {
  const {
    children,
    className,
    strength = 0.3,
    variant = "primary",
    as = "button",
    ...rest
  } = props;

  const prefersReduced = useReducedMotion();
  const buttonRef = React.useRef<HTMLButtonElement | null>(null);
  const anchorRef = React.useRef<HTMLAnchorElement | null>(null);

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const springConfig = React.useMemo(
    () => ({ stiffness: 250, damping: 18, mass: 0.5 }),
    []
  );
  const sx = useSpring(x, springConfig);
  const sy = useSpring(y, springConfig);

  const handleMouseMove = (
    e: React.MouseEvent<HTMLButtonElement | HTMLAnchorElement>
  ) => {
    if (prefersReduced) return;
    const el = (as === "a" ? anchorRef.current : buttonRef.current) as
      | HTMLElement
      | null;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    x.set((e.clientX - (rect.left + rect.width / 2)) * strength);
    y.set((e.clientY - (rect.top + rect.height / 2)) * strength);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  const computedClass = cn(
    "btn-shine relative inline-flex items-center justify-center gap-2 rounded-md px-5 py-2.5 text-sm font-semibold transition-colors duration-200",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
    "disabled:pointer-events-none disabled:opacity-50",
    VARIANT_STYLES[variant],
    className
  );

  const motionStyle = prefersReduced ? undefined : { x: sx, y: sy };

  if (as === "a") {
    const anchorProps = rest as HTMLMotionProps<"a">;
    return (
      <motion.a
        ref={anchorRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className={computedClass}
        style={motionStyle}
        {...anchorProps}
      >
        {children}
      </motion.a>
    );
  }

  const buttonProps = rest as HTMLMotionProps<"button">;
  return (
    <motion.button
      ref={buttonRef}
      type="button"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={computedClass}
      style={motionStyle}
      {...buttonProps}
    >
      {children}
    </motion.button>
  );
}
