"use client";

import * as React from "react";
import {
  motion,
  useReducedMotion,
  useScroll,
  useTransform,
} from "framer-motion";
import { cn } from "@/lib/utils";

export interface ParallaxProps {
  children: React.ReactNode;
  className?: string;
  /** Maximum Y translation range in pixels. Default 100 */
  offset?: number;
  /** Movement direction. Default 'up' */
  direction?: "up" | "down";
}

/**
 * Scroll-driven parallax wrapper. Translates children vertically as the
 * element moves through the viewport.
 *
 * - `direction="up"`: children move up slower than scroll (parallax back).
 * - `direction="down"`: children move down against scroll.
 *
 * Respects `prefers-reduced-motion`.
 */
export function Parallax({
  children,
  className,
  offset = 100,
  direction = "up",
}: ParallaxProps) {
  const ref = React.useRef<HTMLDivElement>(null);
  const prefersReduced = useReducedMotion();

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  // As element enters from bottom (progress 0) and leaves through top (progress 1),
  // translate it from `+offset` to `-offset` (up) or vice versa (down).
  const fromY = direction === "up" ? offset : -offset;
  const toY = direction === "up" ? -offset : offset;
  const y = useTransform(scrollYProgress, [0, 1], [fromY, toY]);

  return (
    <motion.div
      ref={ref}
      className={cn(className)}
      style={{ y: prefersReduced ? 0 : y }}
    >
      {children}
    </motion.div>
  );
}
