"use client";

import * as React from "react";
import { motion, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface ShineBorderProps {
  children: React.ReactNode;
  className?: string;
  /** Border gradient color. Default var(--vh-primary) */
  color?: string;
  /** Rotation duration in seconds. Default 4 */
  duration?: number;
}

/**
 * Wraps children in an animated rotating conic-gradient border.
 *
 * The gradient layer is sized 200% of the parent and rotated around its
 * center so the parent is always fully covered as it spins.
 *
 * Respects `prefers-reduced-motion` (renders a static gradient border).
 */
export function ShineBorder({
  children,
  className,
  color = "var(--vh-primary)",
  duration = 4,
}: ShineBorderProps) {
  const prefersReduced = useReducedMotion();

  return (
    <div
      className={cn(
        "relative isolate overflow-hidden rounded-xl p-[1.5px]",
        className
      )}
    >
      <motion.div
        aria-hidden
        className="pointer-events-none absolute left-[-50%] top-[-50%] h-[200%] w-[200%]"
        style={{
          background: `conic-gradient(from 0deg, transparent 0deg, ${color} 60deg, transparent 120deg, transparent 180deg, ${color} 240deg, transparent 300deg)`,
        }}
        animate={prefersReduced ? undefined : { rotate: 360 }}
        transition={{
          duration,
          repeat: prefersReduced ? 0 : Infinity,
          ease: "linear",
        }}
      />
      <div className="relative z-10 rounded-[calc(theme(borderRadius.xl)-1.5px)] bg-card">
        {children}
      </div>
    </div>
  );
}
