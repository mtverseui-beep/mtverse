"use client";

import * as React from "react";
import {
  animate,
  motion,
  useInView,
  useMotionValue,
  useReducedMotion,
} from "framer-motion";
import { cn } from "@/lib/utils";

export interface AnimatedCounterProps {
  /** Target number to count up to */
  value: number;
  /** Animation duration in seconds. Default 2 */
  duration?: number;
  /** Prefix string (e.g. "$") */
  prefix?: string;
  /** Suffix string (e.g. "+") */
  suffix?: string;
  /** Number of decimal places. Default 0 */
  decimals?: number;
  className?: string;
}

/**
 * Counts from 0 to `value` when scrolled into view.
 *
 * Uses `animate()` from framer-motion to drive a `useMotionValue` and
 * formats the displayed number with the requested decimal places.
 *
 * Respects `prefers-reduced-motion` (snaps directly to value).
 */
export function AnimatedCounter({
  value,
  duration = 2,
  prefix = "",
  suffix = "",
  decimals = 0,
  className,
}: AnimatedCounterProps) {
  const ref = React.useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  const prefersReduced = useReducedMotion();
  const motionValue = useMotionValue(0);
  const [display, setDisplay] = React.useState(
    (0).toFixed(decimals)
  );

  React.useEffect(() => {
    if (!inView) return;

    if (prefersReduced) {
      setDisplay(value.toFixed(decimals));
      return;
    }

    const controls = animate(motionValue, value, {
      duration,
      ease: "easeOut",
      onUpdate: (v) => setDisplay(v.toFixed(decimals)),
    });
    return () => controls.stop();
  }, [inView, value, duration, decimals, prefersReduced, motionValue]);

  // Format with thousands separators for whole numbers
  const formatted = React.useMemo(() => {
    if (decimals === 0) {
      return Number.parseInt(display, 10).toLocaleString("en-US");
    }
    const [intPart, decPart] = display.split(".");
    return `${Number.parseInt(intPart || "0", 10).toLocaleString("en-US")}.${decPart ?? ""}`;
  }, [display, decimals]);

  return (
    <motion.span
      ref={ref}
      className={cn("tabular-nums", className)}
      initial={{ opacity: 0 }}
      animate={{ opacity: inView ? 1 : 0 }}
      transition={{ duration: 0.3 }}
    >
      {prefix}
      {formatted}
      {suffix}
    </motion.span>
  );
}
