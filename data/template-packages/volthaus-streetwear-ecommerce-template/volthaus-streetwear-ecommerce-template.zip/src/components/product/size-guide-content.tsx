"use client";

import { useState } from "react";
import { sizeGuideTables, getSizeGuide } from "@/data/sizeGuide";
import type { ProductCategory } from "@/types";
import { cn } from "@/lib/utils";

const CATEGORY_ORDER: ProductCategory[] = [
  "Sneakers",
  "Hoodies",
  "Graphic Tees",
  "Cargo Pants",
];

export function SizeGuideContent() {
  const [activeCategory, setActiveCategory] = useState<ProductCategory>("Sneakers");
  const table = getSizeGuide(activeCategory);

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-6">
        {CATEGORY_ORDER.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={cn(
              "px-4 h-9 rounded-full text-xs font-mono uppercase tracking-wider border transition-all",
              activeCategory === cat
                ? "bg-primary text-primary-foreground border-primary"
                : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground",
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      {table && (
        <div className="overflow-x-auto no-scrollbar -mx-2">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                  Size
                </th>
                <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                  US
                </th>
                <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                  EU
                </th>
                <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                  UK
                </th>
                <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                  CM
                </th>
                <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                  IN
                </th>
              </tr>
            </thead>
            <tbody>
              {table.rows.map((row, i) => (
                <tr
                  key={row.size}
                  className={cn(
                    "border-b border-border/50 hover:bg-white/[0.03] transition-colors",
                    i % 2 === 1 && "bg-white/[0.02]",
                  )}
                >
                  <td className="px-3 py-3 font-bold">{row.size}</td>
                  <td className="px-3 py-3 text-muted-foreground">{row.us}</td>
                  <td className="px-3 py-3 text-muted-foreground">{row.eu}</td>
                  <td className="px-3 py-3 text-muted-foreground">{row.uk}</td>
                  <td className="px-3 py-3 text-muted-foreground">{row.cm}</td>
                  <td className="px-3 py-3 text-muted-foreground">{row.inches}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="mt-6 grid sm:grid-cols-2 gap-4">
        <div className="rounded-xl border border-border bg-card p-4">
          <h3 className="text-sm font-bold mb-1">How to measure</h3>
          <p className="text-xs text-muted-foreground leading-relaxed">
            For sneakers, place a ruler against a wall, stand on a piece of paper, and mark your longest toe. Measure from the wall to the mark. For apparel, measure your chest, waist, and hips against your body with a soft tape.
          </p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <h3 className="text-sm font-bold mb-1">Between sizes?</h3>
          <p className="text-xs text-muted-foreground leading-relaxed">
            For sneakers, size up if you have wider feet or plan to wear thick socks. For hoodies and tees, size up for an oversized look. For cargo pants, choose based on your waist measurement.
          </p>
        </div>
      </div>

      {/* Show all tables summary */}
      <div className="mt-10 rounded-2xl border border-border bg-card p-6">
        <h3 className="text-sm font-bold mb-3">All size tables at a glance</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {sizeGuideTables.map((t) => (
            <button
              key={t.category}
              onClick={() => setActiveCategory(t.category)}
              className={cn(
                "p-3 rounded-lg border text-left transition-all",
                activeCategory === t.category
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/40",
              )}
            >
              <p className="text-xs font-bold mb-1">{t.category}</p>
              <p className="text-[10px] text-muted-foreground">
                {t.rows.length} sizes · {t.unit}
              </p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
