"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { X } from "lucide-react";
import type { Product } from "@/types";
import { cn } from "@/lib/utils";
import { PriceDisplay } from "@/components/common/price-display";

export interface ProductCardCompactProps {
  product: Product;
  className?: string;
  /** Optional remove handler. Renders an X button on the right when provided. */
  onRemove?: () => void;
  /** Accessible label for the remove button. */
  removeLabel?: string;
}

/**
 * Compact product card used in cart drawers, recommendation rails, etc.
 * Renders a small square image, name (link), category, and price — plus an
 * optional remove button.
 */
export function ProductCardCompact({
  product,
  className,
  onRemove,
  removeLabel,
}: ProductCardCompactProps) {
  const ariaLabel = removeLabel ?? `Remove ${product.name}`;

  return (
    <div
      className={cn(
        "group flex items-center gap-3 rounded-lg border border-border bg-card p-2.5 transition-colors hover:border-primary/30",
        className
      )}
    >
      <Link
        href={`/product/${product.slug}`}
        className="relative h-16 w-16 shrink-0 overflow-hidden rounded-md bg-muted/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        aria-label={`View ${product.name}`}
      >
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          sizes="64px"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </Link>

      <div className="flex min-w-0 flex-1 flex-col gap-0.5">
        <Link
          href={`/product/${product.slug}`}
          className="line-clamp-1 text-sm font-medium text-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm"
        >
          {product.name}
        </Link>
        <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
          {product.category}
        </span>
        <PriceDisplay
          price={product.price}
          compareAtPrice={product.compareAtPrice}
          size="sm"
          className="mt-0.5"
        />
      </div>

      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          aria-label={ariaLabel}
          className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-border bg-background text-muted-foreground transition-colors hover:border-destructive/40 hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        >
          <X className="h-4 w-4" aria-hidden />
        </button>
      )}
    </div>
  );
}
