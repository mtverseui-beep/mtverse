"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertTriangle,
  Check,
  ChevronRight,
  Clock,
  CreditCard,
  GitCompare,
  Heart,
  Package,
  RefreshCcw,
  Share2,
  ShieldCheck,
  ShoppingBag,
  Truck,
  X,
} from "lucide-react";
import type { Product } from "@/types";
import { cn } from "@/lib/utils";
import { useCartStore } from "@/store/cart-store";
import { useCompareStore, MAX_COMPARE_ITEMS } from "@/store/compare-store";
import { useRecentlyViewedStore } from "@/store/recently-viewed-store";
import { useToastStore } from "@/store/toast-store";
import { useUIStore } from "@/store/ui-store";
import { useWishlistStore } from "@/store/wishlist-store";
import { useMounted, useReducedMotion, useScrollPosition } from "@/hooks";
import {
  BadgeVH,
  Breadcrumbs,
  ColorSwatch,
  PriceDisplay,
  QuantitySelector,
  SectionHeading,
  SizeSelector,
  StarRating,
  TrustBadge,
} from "@/components/common";
import { ProductCard } from "@/components/product";
import { FreeShippingProgress } from "@/components/ecommerce";
import { ScrollReveal } from "@/components/motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

export interface ProductDetailProps {
  product: Product;
  related: Product[];
  recentlyViewed: Product[];
  breadcrumbs: { label: string; href?: string }[];
}

type TabKey = "description" | "materials" | "fit" | "care" | "shipping";

const FREE_SHIPPING_THRESHOLD = 100;
const PAYMENT_BADGES = ["Visa", "Mastercard", "Amex", "Apple Pay", "PayPal"];

export function ProductDetail({
  product,
  related,
  recentlyViewed,
  breadcrumbs,
}: ProductDetailProps) {
  const mounted = useMounted();
  const prefersReduced = useReducedMotion();
  const scrollY = useScrollPosition();
  const router = useRouter();

  const addItem = useCartStore((s) => s.addItem);
  const openCart = useCartStore((s) => s.openCart);
  const openSizeGuide = useUIStore((s) => s.openSizeGuide);
  const wishlistHas = useWishlistStore((s) => s.hasItem);
  const wishlistAdd = useWishlistStore((s) => s.addItem);
  const wishlistRemove = useWishlistStore((s) => s.removeItem);
  const compareHas = useCompareStore((s) => s.hasItem);
  const compareAdd = useCompareStore((s) => s.addItem);
  const compareRemove = useCompareStore((s) => s.removeItem);
  const addRecent = useRecentlyViewedStore((s) => s.addRecent);
  const addToast = useToastStore((s) => s.addToast);

  // Local state
  const [activeImage, setActiveImage] = React.useState(0);
  const [selectedColor, setSelectedColor] = React.useState(
    product.colors[0]?.name ?? ""
  );
  const [selectedSize, setSelectedSize] = React.useState<string>("");
  const [qty, setQty] = React.useState(1);
  const [shareOpen, setShareOpen] = React.useState(false);
  const [reviewOpen, setReviewOpen] = React.useState(false);
  const [questionOpen, setQuestionOpen] = React.useState(false);

  // Push into recently-viewed on mount.
  React.useEffect(() => {
    addRecent({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      price: product.price,
      viewedAt: new Date().toISOString(),
    });
    // Reset internal state when product changes (navigations via Link keep state
    // so we explicitly re-key).
    setActiveImage(0);
    setSelectedColor(product.colors[0]?.name ?? "");
    setSelectedSize("");
    setQty(1);
  }, [product, addRecent]);

  const isWishlisted = mounted && wishlistHas(product.id);
  const isCompared = mounted && compareHas(product.id);
  const isSoldOut = product.dropStatus === "sold-out" || product.stock <= 0;
  const isUpcoming = product.dropStatus === "upcoming";
  const isLowStock = !isSoldOut && !isUpcoming && product.stock < 10;
  const showStickyBar =
    mounted && scrollY > 700 && !isUpcoming && !isSoldOut;

  const handleAddToCart = () => {
    if (isSoldOut || isUpcoming) return;
    if (!selectedSize && product.sizes.length > 1) {
      addToast({
        title: "Select a size",
        description: "Please pick your size before adding to cart.",
        variant: "warning",
      });
      return;
    }
    const size = selectedSize || product.sizes[0] || "One Size";
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      price: product.price,
      size,
      color: selectedColor,
      quantity: qty,
      category: product.category,
    });
    addToast({
      title: "Added to cart",
      description: `${product.name} — ${size}, ${selectedColor}`,
      variant: "success",
    });
    openCart();
  };

  const handleBuyNow = () => {
    if (isSoldOut || isUpcoming) return;
    if (!selectedSize && product.sizes.length > 1) {
      addToast({
        title: "Select a size",
        description: "Please pick your size before buying now.",
        variant: "warning",
      });
      return;
    }
    const size = selectedSize || product.sizes[0] || "One Size";
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      price: product.price,
      size,
      color: selectedColor,
      quantity: qty,
      category: product.category,
    });
    router.push("/checkout");
  };

  const handleWishlistToggle = () => {
    if (isWishlisted) {
      wishlistRemove(product.id);
      addToast({ title: "Removed from wishlist", variant: "default" });
    } else {
      wishlistAdd({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        addedAt: new Date().toISOString(),
      });
      addToast({
        title: "Saved to wishlist",
        description: product.name,
        variant: "success",
      });
    }
  };

  const handleCompareToggle = () => {
    if (isCompared) {
      compareRemove(product.id);
      addToast({ title: "Removed from compare", variant: "default" });
    } else {
      const added = compareAdd({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        compareAtPrice: product.compareAtPrice,
        colors: product.colors,
        sizes: product.sizes,
        materials: product.materials,
        fit: product.fit,
        dropStatus: product.dropStatus,
        rating: product.rating,
        reviewCount: product.reviewCount,
        category: product.category,
      });
      if (added) {
        addToast({
          title: "Added to compare",
          description: "View up to 4 products side by side on the compare page.",
          variant: "success",
        });
      } else {
        addToast({
          title: "Compare is full",
          description: `Max ${MAX_COMPARE_ITEMS} items. Remove one to add this.`,
          variant: "warning",
        });
      }
    }
  };

  const handleShare = async () => {
    const url =
      typeof window !== "undefined"
        ? `${window.location.origin}/product/${product.slug}`
        : `https://volthaus.co/product/${product.slug}`;
    try {
      if (navigator.share) {
        await navigator.share({
          title: product.name,
          text: product.shortDescription,
          url,
        });
      } else {
        await navigator.clipboard.writeText(url);
        addToast({
          title: "Link copied",
          description: "Share this VoltHaus drop anywhere.",
          variant: "success",
        });
      }
    } catch {
      // user dismissed share sheet
    } finally {
      setShareOpen(false);
    }
  };

  // Mock delivery estimator — 3 business days from now.
  const deliveryDate = React.useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 4);
    return d.toLocaleDateString("en-US", {
      weekday: "long",
      month: "short",
      day: "numeric",
    });
  }, []);

  const gallery = product.gallery.length
    ? product.gallery
    : product.images.map((src, i) => ({
        src,
        alt: `${product.name} view ${i + 1}`,
      }));

  return (
    <div className="container mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-10">
      <Breadcrumbs items={breadcrumbs} className="mb-6" />

      <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
        {/* ---------------- Gallery ---------------- */}
        <div className="flex flex-col gap-4">
          <div className="relative aspect-square overflow-hidden rounded-xl border border-border bg-muted/30">
            <Image
              src={gallery[activeImage]?.src ?? product.images[0]}
              alt={gallery[activeImage]?.alt ?? product.name}
              fill
              priority
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
            />
            {product.badge && (
              <div className="absolute left-4 top-4 z-10">
                <BadgeVH variant={product.badge} />
              </div>
            )}
            {(isSoldOut || isUpcoming) && (
              <div className="absolute inset-0 z-[5] flex items-center justify-center bg-background/55 backdrop-blur-[2px]">
                <span className="rounded-full border border-border bg-background/90 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-foreground">
                  {isUpcoming ? "Coming Soon" : "Sold Out"}
                </span>
              </div>
            )}
          </div>
          {gallery.length > 1 && (
            <div className="grid grid-cols-4 gap-3 sm:grid-cols-5">
              {gallery.map((img, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setActiveImage(i)}
                  aria-label={`View ${img.alt}`}
                  aria-pressed={activeImage === i}
                  className={cn(
                    "relative aspect-square overflow-hidden rounded-md border transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                    activeImage === i
                      ? "border-primary ring-1 ring-primary"
                      : "border-border opacity-70 hover:opacity-100"
                  )}
                >
                  <Image
                    src={img.src}
                    alt={img.alt}
                    fill
                    sizes="120px"
                    className="object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ---------------- Info ---------------- */}
        <div className="flex flex-col gap-5">
          <div>
            <Link
              href={`/collections/${product.collectionSlug}`}
              className="text-[11px] font-mono uppercase tracking-[0.18em] text-primary hover:underline"
            >
              {product.collection}
            </Link>
            <h1 className="mt-1 text-3xl font-black tracking-tight text-foreground sm:text-4xl">
              {product.name}
            </h1>
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <StarRating
                rating={product.rating}
                count={product.reviewCount}
                showCount
                size={16}
              />
              <a
                href="#reviews"
                className="text-xs text-muted-foreground underline-offset-4 hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm"
              >
                Write a review
              </a>
            </div>
          </div>

          <PriceDisplay
            price={product.price}
            compareAtPrice={product.compareAtPrice}
            size="lg"
          />

          <p className="text-sm leading-relaxed text-muted-foreground">
            {product.shortDescription}
          </p>

          {/* Color */}
          {product.colors.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">
                  Color:{" "}
                  <span className="text-muted-foreground">
                    {selectedColor}
                  </span>
                </span>
              </div>
              <ColorSwatch
                colors={product.colors}
                value={selectedColor}
                onChange={setSelectedColor}
              />
            </div>
          )}

          {/* Size */}
          {product.sizes.length > 0 && (
            <SizeSelector
              sizes={product.sizes}
              value={selectedSize}
              onChange={setSelectedSize}
              onSizeGuideClick={openSizeGuide}
            />
          )}

          {/* Stock + quantity */}
          <div className="flex flex-wrap items-center gap-4 text-sm">
            {isSoldOut ? (
              <span className="inline-flex items-center gap-1.5 text-destructive">
                <AlertTriangle className="h-4 w-4" />
                Sold out
              </span>
            ) : isUpcoming ? (
              <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                <Clock className="h-4 w-4" />
                Drops{" "}
                {product.dropDate
                  ? new Date(product.dropDate).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })
                  : "soon"}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-success">
                <Check className="h-4 w-4" />
                {product.stock} in stock
              </span>
            )}
            {isLowStock && (
              <span className="inline-flex items-center gap-1.5 text-warning">
                <AlertTriangle className="h-4 w-4" />
                Only {product.stock} left
              </span>
            )}
            {product.limitedQuantity && (
              <span className="inline-flex items-center gap-1.5 text-secondary">
                <Package className="h-4 w-4" />
                Limited to {product.limitedQuantity} pairs
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {!isSoldOut && !isUpcoming && (
              <QuantitySelector
                value={qty}
                onChange={setQty}
                min={1}
                max={Math.min(10, product.stock)}
                ariaLabel="Quantity"
              />
            )}
          </div>

          {/* CTA buttons */}
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button
              type="button"
              size="lg"
              onClick={handleAddToCart}
              disabled={isSoldOut || isUpcoming}
              className="btn-shine flex-1"
            >
              <ShoppingBag className="h-4 w-4" />
              {isSoldOut
                ? "Sold out"
                : isUpcoming
                  ? "Coming soon"
                  : "Add to cart"}
            </Button>
            <Button
              type="button"
              size="lg"
              variant="outline"
              onClick={handleBuyNow}
              disabled={isSoldOut || isUpcoming}
              className="flex-1"
            >
              Buy now
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleWishlistToggle}
              aria-pressed={isWishlisted}
              className="border border-border"
            >
              <Heart
                className={cn(
                  "h-4 w-4",
                  isWishlisted && "fill-secondary text-secondary"
                )}
              />
              <span className="hidden sm:inline">
                {isWishlisted ? "Saved" : "Save"}
              </span>
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleCompareToggle}
              aria-pressed={isCompared}
              className="border border-border"
            >
              <GitCompare
                className={cn(
                  "h-4 w-4",
                  isCompared && "text-primary"
                )}
              />
              <span className="hidden sm:inline">Compare</span>
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setShareOpen((v) => !v)}
              aria-expanded={shareOpen}
              className="border border-border"
            >
              <Share2 className="h-4 w-4" />
              <span className="hidden sm:inline">Share</span>
            </Button>
          </div>

          <AnimatePresence>
            {shareOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: prefersReduced ? 0 : 0.2 }}
                className="overflow-hidden"
              >
                <div className="rounded-lg border border-border bg-card p-4">
                  <p className="mb-2 text-sm font-medium text-foreground">
                    Share this drop
                  </p>
                  <div className="flex flex-wrap items-center gap-2">
                    <Input
                      readOnly
                      value={`https://volthaus.co/product/${product.slug}`}
                      className="flex-1 min-w-[200px]"
                      aria-label="Product URL"
                    />
                    <Button type="button" onClick={handleShare}>
                      Copy link
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Free shipping + delivery */}
          {!isSoldOut && !isUpcoming && (
            <div className="rounded-lg border border-border bg-card/60 p-4 space-y-3">
              <FreeShippingProgress
                subtotal={product.price * qty}
                threshold={FREE_SHIPPING_THRESHOLD}
              />
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Truck className="h-3.5 w-3.5 text-primary" />
                Order in the next few hours for delivery by{" "}
                <span className="font-semibold text-foreground">
                  {deliveryDate}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                  We accept
                </span>
                {PAYMENT_BADGES.map((p) => (
                  <span
                    key={p}
                    className="rounded border border-border bg-background px-2 py-0.5 text-[10px] font-medium text-foreground"
                  >
                    {p}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Trust badges */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <TrustBadge
              icon={<Truck className="h-4 w-4" />}
              title="Free express shipping"
              description="On orders over $100"
            />
            <TrustBadge
              icon={<RefreshCcw className="h-4 w-4" />}
              title="30-day returns"
              description="Hassle-free, no restock fee"
            />
            <TrustBadge
              icon={<ShieldCheck className="h-4 w-4" />}
              title="Authenticity guaranteed"
              description="Numbered drop card included"
            />
          </div>
        </div>
      </div>

      {/* ---------------- Tabs ---------------- */}
      <div className="mt-12">
        <Tabs defaultValue="description" className="w-full">
          <TabsList className="flex h-auto w-full flex-wrap justify-start gap-1 bg-transparent p-0">
            <TabsTrigger
              value="description"
              className="data-[selected]:bg-primary data-[selected]:text-primary-foreground"
            >
              Description
            </TabsTrigger>
            <TabsTrigger
              value="materials"
              className="data-[selected]:bg-primary data-[selected]:text-primary-foreground"
            >
              Materials
            </TabsTrigger>
            <TabsTrigger
              value="fit"
              className="data-[selected]:bg-primary data-[selected]:text-primary-foreground"
            >
              Size & Fit
            </TabsTrigger>
            <TabsTrigger
              value="care"
              className="data-[selected]:bg-primary data-[selected]:text-primary-foreground"
            >
              Care
            </TabsTrigger>
            <TabsTrigger
              value="shipping"
              className="data-[selected]:bg-primary data-[selected]:text-primary-foreground"
            >
              Shipping & Returns
            </TabsTrigger>
          </TabsList>
          <TabsContent
            value="description"
            className="mt-6 rounded-xl border border-border bg-card p-6"
          >
            <p className="text-sm leading-relaxed text-muted-foreground">
              {product.description}
            </p>
          </TabsContent>
          <TabsContent
            value="materials"
            className="mt-6 rounded-xl border border-border bg-card p-6"
          >
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              {product.materials.map((m) => (
                <li key={m} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  {m}
                </li>
              ))}
            </ul>
          </TabsContent>
          <TabsContent
            value="fit"
            className="mt-6 rounded-xl border border-border bg-card p-6"
          >
            <p className="text-sm leading-relaxed text-muted-foreground">
              {product.fit}
            </p>
            <Button
              type="button"
              variant="link"
              onClick={openSizeGuide}
              className="mt-2 h-auto p-0 text-primary"
            >
              Open the size guide
            </Button>
          </TabsContent>
          <TabsContent
            value="care"
            className="mt-6 rounded-xl border border-border bg-card p-6"
          >
            <ul className="flex flex-col gap-2 text-sm text-muted-foreground">
              {product.care.map((c) => (
                <li key={c} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  {c}
                </li>
              ))}
            </ul>
          </TabsContent>
          <TabsContent
            value="shipping"
            className="mt-6 rounded-xl border border-border bg-card p-6"
          >
            <p className="text-sm leading-relaxed text-muted-foreground">
              {product.shipping}
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Returns are accepted within 30 days of delivery in unworn
              condition with all original tags and the numbered drop card. Start
              a return from your account dashboard or email{" "}
              <a
                href="mailto:support@volthaus.co"
                className="text-primary underline-offset-4 hover:underline"
              >
                support@volthaus.co
              </a>{" "}
              with your order number.
            </p>
          </TabsContent>
        </Tabs>
      </div>

      {/* ---------------- Reviews ---------------- */}
      <section id="reviews" className="mt-16 scroll-mt-28">
        <SectionHeading
          eyebrow="Community"
          title="Reviews"
          description="Verified buyer reviews for this drop. Honest feedback from the VoltHaus community."
          className="mb-6"
        />
        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <div className="rounded-xl border border-border bg-card p-6">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-black text-foreground">
                {product.rating.toFixed(1)}
              </span>
              <span className="text-sm text-muted-foreground">/ 5</span>
            </div>
            <StarRating rating={product.rating} size={16} className="mt-2" />
            <p className="mt-2 text-xs text-muted-foreground">
              Based on {product.reviewCount.toLocaleString("en-US")} reviews
            </p>
            <Button
              type="button"
              variant="outline"
              className="mt-4 w-full"
              onClick={() => setReviewOpen(true)}
            >
              Write a review
            </Button>
          </div>
          <div className="flex flex-col gap-4">
            {product.reviews && product.reviews.length > 0 ? (
              product.reviews.map((review) => (
                <article
                  key={review.id}
                  className="rounded-xl border border-border bg-card p-5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <Image
                        src={review.avatar}
                        alt={review.author}
                        width={40}
                        height={40}
                        className="h-10 w-10 rounded-full border border-border object-cover"
                      />
                      <div>
                        <p className="text-sm font-semibold text-foreground">
                          {review.author}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          {review.verified && (
                            <span className="inline-flex items-center gap-1 text-success">
                              <Check className="h-3 w-3" /> Verified buyer
                            </span>
                          )}
                          <span>·</span>
                          <span>{review.date}</span>
                          {review.size && (
                            <>
                              <span>·</span>
                              <span>Size {review.size}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <StarRating rating={review.rating} size={14} />
                  </div>
                  <h4 className="mt-3 text-sm font-semibold text-foreground">
                    {review.title}
                  </h4>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {review.body}
                  </p>
                </article>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">
                No reviews yet. Be the first to share your experience.
              </p>
            )}
          </div>
        </div>
      </section>

      {/* ---------------- Q&A ---------------- */}
      <section id="qa" className="mt-16 scroll-mt-28">
        <SectionHeading
          eyebrow="Help"
          title="Questions & answers"
          description="Common questions from the community. Can't find what you're looking for? Ask your own."
          className="mb-6"
        />
        <div className="flex flex-col gap-4">
          {product.questions && product.questions.length > 0 ? (
            product.questions.map((q) => (
              <div
                key={q.id}
                className="rounded-xl border border-border bg-card p-5"
              >
                <p className="text-sm font-semibold text-foreground">
                  Q: {q.question}
                </p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  <span className="font-medium text-foreground">A:</span>{" "}
                  {q.answer}
                </p>
                <p className="mt-2 text-xs text-muted-foreground">
                  — {q.author}, {q.date}
                </p>
              </div>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">
              No questions yet. Be the first to ask one.
            </p>
          )}
          <Button
            type="button"
            variant="outline"
            className="self-start"
            onClick={() => setQuestionOpen(true)}
          >
            Ask a question
          </Button>
        </div>
      </section>

      {/* ---------------- Related ---------------- */}
      {related.length > 0 && (
        <section className="mt-16">
          <SectionHeading
            eyebrow="Pairs well with"
            title="Related drops"
            className="mb-6"
          />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {related.map((p, i) => (
              <ScrollReveal key={p.id} delay={Math.min(i * 0.05, 0.3)}>
                <ProductCard product={p} />
              </ScrollReveal>
            ))}
          </div>
        </section>
      )}

      {/* ---------------- Complete the look ---------------- */}
      {related.length > 0 && (
        <section className="mt-16">
          <SectionHeading
            eyebrow="Style it"
            title="Complete the look"
            description="Pieces from the studio that pair with this drop."
            className="mb-6"
          />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {related.slice(0, 4).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      {/* ---------------- Recently viewed ---------------- */}
      {mounted && recentlyViewed.length > 0 && (
        <section className="mt-16">
          <div className="mb-6 flex items-end justify-between gap-4">
            <SectionHeading
              eyebrow="History"
              title="Recently viewed"
              className="mb-0"
            />
            <Link
              href="/recently-viewed"
              className="text-xs text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm"
            >
              See all
            </Link>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
            {recentlyViewed.map((p) => (
              <div
                key={p.id}
                className="w-44 shrink-0 sm:w-56"
              >
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ---------------- Sticky mobile add-to-cart bar ---------------- */}
      <AnimatePresence>
        {showStickyBar && (
          <motion.div
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            transition={{ type: "spring", stiffness: 280, damping: 30 }}
            className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur lg:hidden"
          >
            <div className="flex items-center gap-3 p-3">
              <div className="min-w-0 flex-1">
                <p className="line-clamp-1 text-sm font-semibold text-foreground">
                  {product.name}
                </p>
                <PriceDisplay
                  price={product.price}
                  compareAtPrice={product.compareAtPrice}
                  size="sm"
                />
              </div>
              <Button
                type="button"
                onClick={handleAddToCart}
                disabled={isSoldOut || isUpcoming}
                className="btn-shine"
              >
                <ShoppingBag className="h-4 w-4" />
                Add to cart
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ---------------- Review modal ---------------- */}
      <ReviewModal
        open={reviewOpen}
        onClose={() => setReviewOpen(false)}
        productName={product.name}
      />
      <QuestionModal
        open={questionOpen}
        onClose={() => setQuestionOpen(false)}
        productName={product.name}
      />
    </div>
  );
}

// ---------------- Modals ----------------

function ReviewModal({
  open,
  onClose,
  productName,
}: {
  open: boolean;
  onClose: () => void;
  productName: string;
}) {
  const addToast = useToastStore((s) => s.addToast);
  const prefersReduced = useReducedMotion();
  const [rating, setRating] = React.useState(5);
  const [title, setTitle] = React.useState("");
  const [body, setBody] = React.useState("");

  React.useEffect(() => {
    if (!open) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, [open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) {
      addToast({
        title: "Missing fields",
        description: "Please add a title and body for your review.",
        variant: "warning",
      });
      return;
    }
    addToast({
      title: "Review submitted",
      description: "Thanks for sharing your experience with the community.",
      variant: "success",
    });
    setTitle("");
    setBody("");
    setRating(5);
    onClose();
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Write a review"
    >
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: prefersReduced ? 0 : 0.2 }}
        className="relative z-10 w-full max-w-lg rounded-2xl border border-border bg-background p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="absolute right-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-md border border-border text-muted-foreground hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <h3 className="text-lg font-bold text-foreground">Write a review</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Sharing your experience with {productName}.
        </p>
        <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-4">
          <div>
            <label className="mb-2 block text-sm font-medium text-foreground">
              Your rating
            </label>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(n)}
                  aria-label={`Rate ${n} out of 5`}
                  className="p-1"
                >
                  <StarRating rating={n <= rating ? 5 : 0} size={20} />
                </button>
              ))}
            </div>
          </div>
          <div>
            <label
              htmlFor="review-title"
              className="mb-1.5 block text-sm font-medium text-foreground"
            >
              Title
            </label>
            <Input
              id="review-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Sum up your experience"
              required
            />
          </div>
          <div>
            <label
              htmlFor="review-body"
              className="mb-1.5 block text-sm font-medium text-foreground"
            >
              Review
            </label>
            <Textarea
              id="review-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="What did you think of the fit, materials, and feel?"
              rows={4}
              required
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Submit review</Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function QuestionModal({
  open,
  onClose,
  productName,
}: {
  open: boolean;
  onClose: () => void;
  productName: string;
}) {
  const addToast = useToastStore((s) => s.addToast);
  const prefersReduced = useReducedMotion();
  const [question, setQuestion] = React.useState("");

  React.useEffect(() => {
    if (!open) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, [open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) {
      addToast({
        title: "Empty question",
        description: "Type your question before submitting.",
        variant: "warning",
      });
      return;
    }
    addToast({
      title: "Question submitted",
      description: "Our team will reply within 24 hours.",
      variant: "success",
    });
    setQuestion("");
    onClose();
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Ask a question"
    >
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: prefersReduced ? 0 : 0.2 }}
        className="relative z-10 w-full max-w-lg rounded-2xl border border-border bg-background p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="absolute right-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-md border border-border text-muted-foreground hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <h3 className="text-lg font-bold text-foreground">Ask a question</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          About {productName}.
        </p>
        <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-4">
          <div>
            <label
              htmlFor="question"
              className="mb-1.5 block text-sm font-medium text-foreground"
            >
              Your question
            </label>
            <Textarea
              id="question"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="What would you like to know about fit, materials, or care?"
              rows={4}
              required
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Submit question</Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

export default ProductDetail;
