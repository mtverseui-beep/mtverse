"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { X, Heart, ShoppingBag, Eye } from "lucide-react";
import { useUIStore } from "@/store/ui-store";
import { useCartStore } from "@/store/cart-store";
import { useWishlistStore } from "@/store/wishlist-store";
import { useToastStore } from "@/store/toast-store";
import { getProductBySlug } from "@/data/products";
import { useMounted } from "@/hooks";
import { PriceDisplay, ColorSwatch, StarRating, BadgeVH, QuantitySelector } from "@/components/common";
import type { Product } from "@/types";

function QuickViewContent({ product }: { product: Product }) {
  const closeQuickView = useUIStore((s) => s.closeQuickView);
  const addItem = useCartStore((s) => s.addItem);
  const openCart = useCartStore((s) => s.openCart);
  const wishlistItems = useWishlistStore((s) => s.items);
  const addWishlist = useWishlistStore((s) => s.addItem);
  const removeWishlist = useWishlistStore((s) => s.removeItem);
  const addToast = useToastStore((s) => s.addToast);

  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0]?.name ?? "");
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] ?? "");
  const [qty, setQty] = useState(1);
  const [activeImage, setActiveImage] = useState(0);

  const isInWishlist = wishlistItems.some((i) => i.productId === product.id);

  const handleAddToCart = () => {
    if (!selectedSize) {
      addToast({
        title: "Select a size",
        description: "Please choose a size before adding to cart.",
        variant: "warning",
      });
      return;
    }
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0] ?? "",
      price: product.price,
      size: selectedSize,
      color: selectedColor,
      quantity: qty,
      category: product.category,
    });
    addToast({
      title: "Added to cart",
      description: `${product.name} (${selectedSize}, ${selectedColor})`,
      variant: "success",
    });
    closeQuickView();
    openCart();
  };

  const handleWishlist = () => {
    if (isInWishlist) {
      removeWishlist(product.id);
      addToast({ title: "Removed from wishlist", variant: "default" });
    } else {
      addWishlist({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0] ?? "",
        price: product.price,
        addedAt: new Date().toISOString(),
      });
      addToast({ title: "Saved to wishlist", variant: "success" });
    }
  };

  return (
    <motion.div
      initial={{ scale: 0.92, opacity: 0, y: 24 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      exit={{ scale: 0.92, opacity: 0, y: 24 }}
      transition={{ type: "spring", stiffness: 280, damping: 26 }}
      className="relative z-10 w-full max-w-5xl max-h-[92vh] overflow-y-auto no-scrollbar solid-panel-strong rounded-2xl border border-border"
      onClick={(e) => e.stopPropagation()}
    >
      <button
        onClick={closeQuickView}
        aria-label="Close quick view"
        className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-muted transition-colors"
      >
        <X className="w-4 h-4" />
      </button>

      <div className="grid md:grid-cols-2 gap-0">
        <div className="relative aspect-square md:aspect-auto md:min-h-[520px] bg-muted overflow-hidden">
          <Image
            src={product.images[activeImage] ?? product.images[0]}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 100vw, 50vw"
            className="object-cover"
          />
          {product.badge && (
            <div className="absolute top-4 left-4">
              <BadgeVH variant={product.badge} />
            </div>
          )}
          {product.images.length > 1 && (
            <div className="absolute bottom-4 left-4 right-4 flex gap-2 overflow-x-auto no-scrollbar">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={`relative w-16 h-16 shrink-0 rounded-md overflow-hidden border-2 transition-colors ${
                    i === activeImage ? "border-primary" : "border-transparent opacity-60"
                  }`}
                >
                  <Image
                    src={img}
                    alt={`${product.name} view ${i + 1}`}
                    fill
                    sizes="64px"
                    className="object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="p-6 sm:p-8 flex flex-col gap-5">
          <div>
            <p className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-1">
              {product.collection}
            </p>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              {product.name}
            </h2>
            <div className="flex items-center gap-3 mt-2">
              <StarRating
                rating={product.rating}
                size={14}
                count={product.reviewCount}
                showCount
              />
            </div>
          </div>

          <PriceDisplay
            price={product.price}
            compareAtPrice={product.compareAtPrice}
            size="lg"
          />

          <p className="text-sm text-muted-foreground leading-relaxed">
            {product.shortDescription}
          </p>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                Color: <span className="text-foreground">{selectedColor}</span>
              </span>
            </div>
            <ColorSwatch
              colors={product.colors}
              value={selectedColor}
              onChange={setSelectedColor}
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                Size
              </span>
              <Link
                href={`/product/${product.slug}`}
                className="text-xs text-primary hover:underline"
              >
                Size guide
              </Link>
            </div>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedSize(s)}
                  className={`min-w-[44px] h-10 px-3 rounded-md text-sm font-medium border transition-all ${
                    s === selectedSize
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-white/12 hover:border-primary/60 hover:bg-white/5"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <QuantitySelector value={qty} onChange={setQty} min={1} max={10} />
            <span className="text-xs text-muted-foreground">
              {product.stock} in stock
            </span>
          </div>

          <div className="flex gap-3 mt-auto">
            <button
              onClick={handleAddToCart}
              disabled={product.dropStatus === "sold-out" || product.stock === 0}
              className="flex-1 h-12 rounded-full bg-primary text-primary-foreground font-bold text-sm btn-shine flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.02] transition-transform"
            >
              <ShoppingBag className="w-4 h-4" />
              {product.dropStatus === "sold-out" || product.stock === 0
                ? "Sold out"
                : "Add to cart"}
            </button>
            <button
              onClick={handleWishlist}
              aria-label="Toggle wishlist"
              className={`w-12 h-12 rounded-full border flex items-center justify-center transition-colors ${
                isInWishlist
                  ? "bg-secondary/20 border-secondary text-secondary"
                  : "border-white/12 hover:border-secondary/60 hover:bg-white/5"
              }`}
            >
              <Heart className={`w-4 h-4 ${isInWishlist ? "fill-current" : ""}`} />
            </button>
          </div>

          <Link
            href={`/product/${product.slug}`}
            className="text-center text-xs font-mono uppercase tracking-wider text-muted-foreground hover:text-primary transition-colors flex items-center justify-center gap-1"
          >
            <Eye className="w-3 h-3" />
            View full details
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

export function QuickViewModal() {
  const mounted = useMounted();
  const isQuickViewOpen = useUIStore((s) => s.isQuickViewOpen);
  const quickViewSlug = useUIStore((s) => s.quickViewSlug);
  const closeQuickView = useUIStore((s) => s.closeQuickView);

  const product = quickViewSlug ? getProductBySlug(quickViewSlug) : undefined;

  useEffect(() => {
    if (isQuickViewOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isQuickViewOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isQuickViewOpen) closeQuickView();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isQuickViewOpen, closeQuickView]);

  if (!mounted) return null;

  return (
    <AnimatePresence>
      {isQuickViewOpen && product && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6"
          onClick={closeQuickView}
        >
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
          {/* key={product.slug} ensures fresh state on each new product */}
          <QuickViewContent key={product.slug} product={product} />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
