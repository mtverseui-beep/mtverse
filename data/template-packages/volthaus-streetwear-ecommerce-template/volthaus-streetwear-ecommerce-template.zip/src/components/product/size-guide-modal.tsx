"use client";

import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { useUIStore } from "@/store/ui-store";
import { useMounted } from "@/hooks";
import { getSizeGuide } from "@/data/sizeGuide";
import { useState, useEffect } from "react";
import type { ProductCategory } from "@/types";

const categoryOrder: ProductCategory[] = [
  "Sneakers",
  "Hoodies",
  "Graphic Tees",
  "Cargo Pants",
];

export function SizeGuideModal() {
  const mounted = useMounted();
  const { isSizeGuideOpen, closeSizeGuide } = useUIStore();
  const [activeCategory, setActiveCategory] = useState<ProductCategory>("Sneakers");

  useEffect(() => {
    if (isSizeGuideOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isSizeGuideOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isSizeGuideOpen) closeSizeGuide();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isSizeGuideOpen, closeSizeGuide]);

  if (!mounted) return null;

  const table = getSizeGuide(activeCategory);

  return (
    <AnimatePresence>
      {isSizeGuideOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6"
          onClick={closeSizeGuide}
        >
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
          <motion.div
            initial={{ scale: 0.92, opacity: 0, y: 24 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.92, opacity: 0, y: 24 }}
            transition={{ type: "spring", stiffness: 280, damping: 26 }}
            className="relative z-10 w-full max-w-3xl max-h-[90vh] overflow-y-auto no-scrollbar solid-panel-strong rounded-2xl border border-border p-6 sm:p-8"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={closeSizeGuide}
              aria-label="Close size guide"
              className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center hover:bg-muted transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="mb-6">
              <p className="text-xs font-mono uppercase tracking-wider text-primary mb-2">
                Fit Guide
              </p>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
                Size & Fit Guide
              </h2>
              <p className="text-sm text-muted-foreground mt-2 max-w-lg">
                Use the charts below to find your size across categories. All measurements are in cm and inches. If you're between sizes, size up for a relaxed fit and size down for a fitted look.
              </p>
            </div>

            <div className="flex flex-wrap gap-2 mb-6">
              {categoryOrder.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 h-9 rounded-full text-xs font-mono uppercase tracking-wider border transition-all ${
                    activeCategory === cat
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-white/12 text-muted-foreground hover:border-primary/60 hover:text-foreground"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {table && (
              <div className="overflow-x-auto no-scrollbar -mx-2">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/12 text-left">
                      <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                        Size
                      </th>
                      <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                        US
                      </th>
                      <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                        EU
                      </th>
                      <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                        UK
                      </th>
                      <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                        CM
                      </th>
                      <th className="px-3 py-3 font-mono uppercase text-xs tracking-wider text-muted-foreground">
                        IN
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {table.rows.map((row, i) => (
                      <tr
                        key={row.size}
                        className={`border-b border-white/6 hover:bg-white/[0.03] transition-colors ${
                          i % 2 === 1 ? "bg-white/[0.02]" : ""
                        }`}
                      >
                        <td className="px-3 py-3 font-bold">{row.size}</td>
                        <td className="px-3 py-3 text-muted-foreground">{row.us}</td>
                        <td className="px-3 py-3 text-muted-foreground">{row.eu}</td>
                        <td className="px-3 py-3 text-muted-foreground">{row.uk}</td>
                        <td className="px-3 py-3 text-muted-foreground">{row.cm}</td>
                        <td className="px-3 py-3 text-muted-foreground">{row.inches}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-8 grid sm:grid-cols-2 gap-4">
              <div className="solid-panel rounded-xl p-4">
                <h3 className="font-bold text-sm mb-1">How to measure</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  For sneakers, measure your foot from heel to longest toe. For apparel, measure your chest, waist, and hips against your body.
                </p>
              </div>
              <div className="solid-panel rounded-xl p-4">
                <h3 className="font-bold text-sm mb-1">Need help?</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Reach out to our team at support@volthaus.co and we'll help you find the right fit within 24 hours.
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
