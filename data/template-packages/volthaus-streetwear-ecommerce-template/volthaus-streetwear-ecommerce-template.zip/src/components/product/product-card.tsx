"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import {
  AlertTriangle,
  Clock,
  Eye,
  GitCompare,
  Heart,
  ShoppingBag,
} from "lucide-react";
import type { Product } from "@/types";
import { cn } from "@/lib/utils";
import { BadgeVH } from "@/components/common/badge-vh";
import { ColorSwatch } from "@/components/common/color-swatch";
import { PriceDisplay } from "@/components/common/price-display";
import { useCartStore } from "@/store/cart-store";
import { useCompareStore } from "@/store/compare-store";
import { useToastStore } from "@/store/toast-store";
import { useUIStore } from "@/store/ui-store";
import { useWishlistStore } from "@/store/wishlist-store";

export interface ProductCardProps {
  product: Product;
  /** Prioritise the primary image (LCP). Use for above-the-fold cards. */
  priority?: boolean;
  className?: string;
}

/**
 * VoltHaus product card.
 *
 * Features:
 * - Image with hover zoom and second-image fade-in on hover.
 * - Badge (top-left) via `BadgeVH`.
 * - Wishlist + compare toggles (top-right).
 * - Quick view overlay button (bottom of image, on hover).
 * - Stretched link covers the entire card so any non-interactive click
 *   navigates to the PDP. Buttons use `pointer-events-auto` and stop
 *   propagation.
 * - Color swatches (display-only, 3 max + "+N").
 * - Drop status / sold-out overlay; low-stock indicator (<10).
 * - Quick add CTA: single-size adds to cart directly; multi-size opens
 *   the quick view modal.
 *
 * Respects `prefers-reduced-motion`.
 */
export function ProductCard({
  product,
  priority = false,
  className,
}: ProductCardProps) {
  const prefersReduced = useReducedMotion();
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);

  const openQuickView = useUIStore((s) => s.openQuickView);
  const openCart = useCartStore((s) => s.openCart);
  const addItem = useCartStore((s) => s.addItem);
  const wishlistHas = useWishlistStore((s) => s.hasItem);
  const wishlistAdd = useWishlistStore((s) => s.addItem);
  const wishlistRemove = useWishlistStore((s) => s.removeItem);
  const compareHas = useCompareStore((s) => s.hasItem);
  const compareAdd = useCompareStore((s) => s.addItem);
  const compareRemove = useCompareStore((s) => s.removeItem);
  const addToast = useToastStore((s) => s.addToast);

  const isWishlisted = mounted && wishlistHas(product.id);
  const isCompared = mounted && compareHas(product.id);

  const isSoldOut = product.dropStatus === "sold-out" || product.stock <= 0;
  const isUpcoming = product.dropStatus === "upcoming";
  const isLowStock =
    !isSoldOut && !isUpcoming && product.stock > 0 && product.stock < 10;
  const hasSingleSize = product.sizes.length === 1;
  const hasSecondImage = product.images.length > 1;

  const imageSizes = "(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw";

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isWishlisted) {
      wishlistRemove(product.id);
      addToast({ title: "Removed from wishlist", variant: "default" });
    } else {
      wishlistAdd({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        addedAt: new Date().toISOString(),
      });
      addToast({
        title: "Added to wishlist",
        description: product.name,
        variant: "success",
      });
    }
  };

  const handleCompareToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isCompared) {
      compareRemove(product.id);
      addToast({ title: "Removed from compare", variant: "default" });
    } else {
      const added = compareAdd({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        compareAtPrice: product.compareAtPrice,
        colors: product.colors,
        sizes: product.sizes,
        materials: product.materials,
        fit: product.fit,
        dropStatus: product.dropStatus,
        rating: product.rating,
        reviewCount: product.reviewCount,
        category: product.category,
      });
      if (added) {
        addToast({
          title: "Added to compare",
          description: product.name,
          variant: "success",
        });
      } else {
        addToast({
          title: "Compare is full",
          description: "Remove an item to add another.",
          variant: "warning",
        });
      }
    }
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    openQuickView(product.slug);
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isSoldOut || isUpcoming) return;
    if (hasSingleSize) {
      addItem({
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0],
        price: product.price,
        size: product.sizes[0],
        color: product.colors[0]?.name ?? "Default",
        quantity: 1,
        category: product.category,
      });
      openCart();
      addToast({
        title: "Added to cart",
        description: product.name,
        variant: "success",
      });
    } else {
      openQuickView(product.slug);
    }
  };

  return (
    <motion.article
      whileHover={prefersReduced ? undefined : { y: -4 }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-colors duration-200 hover:border-primary/40 focus-within:border-primary/40",
        className
      )}
    >
      {/* Stretched link — covers entire card, captures all non-button clicks */}
      <Link
        href={`/product/${product.slug}`}
        className="absolute inset-0 z-0"
        aria-label={`View ${product.name}`}
      />

      {/* Image area — pointer-events-none so clicks fall through to the link */}
      <div className="pointer-events-none relative aspect-square overflow-hidden bg-muted/30">
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          sizes={imageSizes}
          priority={priority}
          className={cn(
            "object-cover transition-transform duration-700 ease-out",
            !prefersReduced && "group-hover:scale-105"
          )}
        />
        {hasSecondImage && (
          <Image
            src={product.images[1]}
            alt=""
            fill
            sizes={imageSizes}
            aria-hidden
            className={cn(
              "object-cover opacity-0 transition-opacity duration-500 ease-out",
              !prefersReduced && "group-hover:opacity-100"
            )}
          />
        )}

        {/* Badge top-left */}
        {product.badge && (
          <div className="absolute left-3 top-3 z-10">
            <BadgeVH variant={product.badge} />
          </div>
        )}

        {/* Wishlist + Compare top-right — interactive */}
        <div className="pointer-events-auto absolute right-3 top-3 z-20 flex flex-col gap-2">
          <button
            type="button"
            onClick={handleWishlistToggle}
            aria-label={
              isWishlisted
                ? `Remove ${product.name} from wishlist`
                : `Add ${product.name} to wishlist`
            }
            aria-pressed={isWishlisted}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-background/80 backdrop-blur transition-colors hover:border-primary/50 hover:bg-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
          >
            <Heart
              className={cn(
                "h-4 w-4 transition-colors",
                isWishlisted
                  ? "fill-secondary text-secondary"
                  : "text-foreground"
              )}
            />
          </button>
          <button
            type="button"
            onClick={handleCompareToggle}
            aria-label={
              isCompared
                ? `Remove ${product.name} from compare`
                : `Add ${product.name} to compare`
            }
            aria-pressed={isCompared}
            className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-background/80 backdrop-blur transition-colors hover:border-primary/50 hover:bg-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
          >
            <GitCompare
              className={cn(
                "h-4 w-4 transition-colors",
                isCompared ? "text-primary" : "text-foreground"
              )}
            />
          </button>
        </div>

        {/* Drop status / sold-out overlay */}
        {(isSoldOut || isUpcoming) && (
          <div className="absolute inset-0 z-[5] flex items-center justify-center bg-background/55 backdrop-blur-[2px]">
            <span className="rounded-full border border-border bg-background/90 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-foreground">
              {isUpcoming ? "Coming Soon" : "Sold Out"}
            </span>
          </div>
        )}

        {/* Quick view button — slides up on hover */}
        {!isSoldOut && !isUpcoming && (
          <div
            className={cn(
              "pointer-events-auto absolute inset-x-0 bottom-0 z-20 flex justify-center p-3 transition-transform duration-300 ease-out",
              prefersReduced ? "translate-y-0" : "translate-y-full group-hover:translate-y-0"
            )}
          >
            <button
              type="button"
              onClick={handleQuickView}
              className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-md border border-border bg-background/90 text-sm font-medium text-foreground backdrop-blur transition-colors hover:border-primary/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <Eye className="h-4 w-4" />
              Quick view
            </button>
          </div>
        )}
      </div>

      {/* Body — pointer-events-none so clicks fall through to the link */}
      <div className="flex flex-1 flex-col gap-2 p-4 pointer-events-none">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            {product.category}
          </span>
          {isLowStock && (
            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-warning">
              <AlertTriangle className="h-3 w-3" aria-hidden />
              Only {product.stock} left
            </span>
          )}
        </div>

        <h3 className="line-clamp-1 text-base font-semibold text-foreground">
          {product.name}
        </h3>

        <PriceDisplay
          price={product.price}
          compareAtPrice={product.compareAtPrice}
          size="md"
        />

        {product.colors.length > 0 && (
          <div className="mt-1 flex items-center gap-2">
            <ColorSwatch
              colors={product.colors.slice(0, 3)}
              size="sm"
            />
            {product.colors.length > 3 && (
              <span className="text-xs text-muted-foreground">
                +{product.colors.length - 3}
              </span>
            )}
          </div>
        )}

        <div className="pointer-events-auto mt-2">
          {isUpcoming ? (
            <div
              className="inline-flex w-full items-center justify-center gap-2 rounded-md border border-border bg-muted/30 px-3 py-2 text-xs font-medium text-muted-foreground"
              aria-live="polite"
            >
              <Clock className="h-3.5 w-3.5" aria-hidden />
              Drops{" "}
              {product.dropDate
                ? new Date(product.dropDate).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })
                : "soon"}
            </div>
          ) : isSoldOut ? (
            <button
              type="button"
              disabled
              className="inline-flex w-full items-center justify-center gap-2 rounded-md border border-border bg-muted/30 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground"
            >
              Sold out
            </button>
          ) : (
            <button
              type="button"
              onClick={handleQuickAdd}
              className="btn-shine inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <ShoppingBag className="h-3.5 w-3.5" aria-hidden />
              {hasSingleSize ? "Add to cart" : "Select size"}
            </button>
          )}
        </div>
      </div>
    </motion.article>
  );
}
