"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Clock, MapPin, Store } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Stockist {
  name: string;
  city: string;
  country: string;
  region: "Europe" | "Asia" | "North America";
  address: string;
  hours: string;
  image: string;
  flagship?: boolean;
}

const REGIONS = [
  "All",
  "Europe",
  "Asia",
  "North America",
] as const;
type Region = (typeof REGIONS)[number];

/**
 * Stockist grid with a region filter. Receives the static stockist list
 * from the server page so the data stays in one place.
 */
export function StockistGrid({ stockists }: { stockists: Stockist[] }) {
  const prefersReduced = useReducedMotion();
  const [region, setRegion] = React.useState<Region>("All");

  const filtered = React.useMemo(() => {
    if (region === "All") return stockists;
    return stockists.filter((s) => s.region === region);
  }, [region, stockists]);

  return (
    <div>
      {/* Region filter */}
      <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            All locations
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Where to find us
          </h2>
        </div>
        <div
          className="no-scrollbar -mx-4 flex items-center gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0"
          role="tablist"
          aria-label="Filter stockists by region"
        >
          {REGIONS.map((r) => {
            const count =
              r === "All"
                ? stockists.length
                : stockists.filter((s) => s.region === r).length;
            const isActive = region === r;
            return (
              <button
                key={r}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-controls="stockist-grid"
                onClick={() => setRegion(r)}
                className={cn(
                  "inline-flex h-9 shrink-0 items-center gap-2 rounded-full border px-4 text-xs font-mono uppercase tracking-wider transition-colors",
                  isActive
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground"
                )}
              >
                {r}
                <span
                  className={cn(
                    "inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-bold",
                    isActive
                      ? "bg-primary-foreground/20 text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                  )}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div
        id="stockist-grid"
        className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
      >
        {filtered.map((s, i) => (
          <motion.article
            key={s.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{
              duration: 0.5,
              delay: prefersReduced ? 0 : Math.min(i * 0.05, 0.3),
              ease: [0.25, 0.4, 0.25, 1],
            }}
            className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40"
          >
            <div className="relative aspect-[16/10] overflow-hidden bg-muted">
              <Image
                src={s.image}
                alt={`${s.name} storefront`}
                fill
                sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                className={cn(
                  "object-cover transition-transform duration-700 ease-out",
                  !prefersReduced && "group-hover:scale-105"
                )}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent" />
              {s.flagship && (
                <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/15 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary backdrop-blur">
                  <Store className="h-3 w-3" aria-hidden />
                  Flagship
                </span>
              )}
            </div>
            <div className="flex flex-1 flex-col p-5">
              <p className="text-xs font-mono uppercase tracking-wider text-primary">
                {s.city}, {s.country}
              </p>
              <h3 className="mt-2 text-base font-bold tracking-tight text-foreground">
                {s.name}
              </h3>
              <p className="mt-2 flex items-start gap-1.5 text-sm text-muted-foreground">
                <MapPin
                  className="mt-0.5 h-3.5 w-3.5 shrink-0"
                  aria-hidden
                />
                {s.address}
              </p>
              <p className="mt-2 flex items-start gap-1.5 text-sm text-muted-foreground">
                <Clock
                  className="mt-0.5 h-3.5 w-3.5 shrink-0"
                  aria-hidden
                />
                {s.hours}
              </p>
              <div className="mt-auto pt-4">
                <a
                  href={`https://maps.google.com/?q=${encodeURIComponent(
                    `${s.name} ${s.address}`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-border bg-background px-4 text-xs font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary"
                >
                  Get directions
                  <ArrowRight className="h-3.5 w-3.5" aria-hidden />
                </a>
              </div>
            </div>
          </motion.article>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="rounded-2xl border border-border bg-card p-12 text-center">
          <p className="text-sm text-muted-foreground">
            No stockists in this region yet. We onboard new partners each
            season.
          </p>
        </div>
      )}

      <p className="mt-8 text-xs text-muted-foreground">
        Looking for the VoltHaus studio HQ? Visit the{" "}
        <Link
          href="/contact"
          className="font-medium text-primary hover:underline"
        >
          contact page
        </Link>{" "}
        for the Berlin studio address and appointment booking.
      </p>
    </div>
  );
}
