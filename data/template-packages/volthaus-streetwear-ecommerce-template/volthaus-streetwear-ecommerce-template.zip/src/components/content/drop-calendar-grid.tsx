"use client";

import { useState, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Bell, Calendar, Clock, Flame, Lock, Check } from "lucide-react";
import { dropCalendar, getUpcomingDrops, getLiveDrops, getSoldOutDrops } from "@/data/dropCalendar";
import { getProductBySlug } from "@/data/products";
import { useToastStore } from "@/store/toast-store";
import { cn } from "@/lib/utils";
import type { DropStatus } from "@/types";

type FilterStatus = "all" | DropStatus;

const FILTERS: { label: string; value: FilterStatus }[] = [
  { label: "All drops", value: "all" },
  { label: "Upcoming", value: "upcoming" },
  { label: "Live", value: "live" },
  { label: "Sold out", value: "sold-out" },
];

const CATEGORIES = ["All", "Sneakers", "Hoodies", "Graphic Tees", "Cargo Pants", "Jackets", "Caps", "Bags", "Accessories"];

export function DropCalendarGrid() {
  const addToast = useToastStore((s) => s.addToast);
  const [filter, setFilter] = useState<FilterStatus>("all");
  const [category, setCategory] = useState<string>("All");
  const [reminders, setReminders] = useState<Set<string>>(new Set());

  const filtered = useMemo(() => {
    let list = dropCalendar;
    if (filter !== "all") {
      list = list.filter((d) => d.status === filter);
    }
    if (category !== "All") {
      list = list.filter((d) => d.category === category);
    }
    return list;
  }, [filter, category]);

  const handleNotify = (id: string, name: string) => {
    setReminders((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
    if (!reminders.has(id)) {
      addToast({
        title: "Reminder set",
        description: `We'll notify you when ${name} drops.`,
        variant: "success",
      });
    }
  };

  const handleAddToCalendar = (name: string, date: string) => {
    addToast({
      title: "Added to calendar",
      description: `${name} on ${new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}.`,
      variant: "success",
    });
  };

  return (
    <div>
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        {FILTERS.map((f) => {
          const count =
            f.value === "all"
              ? dropCalendar.length
              : f.value === "upcoming"
                ? getUpcomingDrops().length
                : f.value === "live"
                  ? getLiveDrops().length
                  : getSoldOutDrops().length;
          return (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={cn(
                "px-4 h-9 rounded-full text-xs font-mono uppercase tracking-wider border transition-all flex items-center gap-2",
                filter === f.value
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground",
              )}
            >
              {f.label}
              <span className={cn(
                "inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-bold",
                filter === f.value ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-muted-foreground",
              )}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      <div className="flex flex-wrap items-center gap-2 mb-8 overflow-x-auto no-scrollbar pb-2">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={cn(
              "px-3 h-8 rounded-full text-xs border transition-all whitespace-nowrap",
              category === cat
                ? "bg-card text-foreground border-primary"
                : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/30",
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card p-12 text-center">
          <p className="text-sm text-muted-foreground">No drops match your filters. Try a different combination.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((drop, i) => {
            const product = getProductBySlug(drop.productSlug);
            const dropDate = new Date(drop.date);
            const hasReminder = reminders.has(drop.id);
            return (
              <motion.div
                key={drop.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: i * 0.05, duration: 0.4 }}
                className="group rounded-2xl border border-border bg-card overflow-hidden hover:border-primary/40 transition-colors"
              >
                {/* Image */}
                <Link href={product ? `/product/${product.slug}` : "/shop"} className="relative block aspect-[4/3] overflow-hidden bg-muted">
                  <Image
                    src={drop.image}
                    alt={drop.productName}
                    fill
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    className="object-cover transition-transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <div className="absolute top-3 left-3 flex flex-col gap-1.5">
                    <StatusPill status={drop.status} />
                    {drop.membersOnly && (
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider bg-accent/20 text-accent border border-accent/30">
                        <Lock className="h-2.5 w-2.5" />
                        Members
                      </span>
                    )}
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <p className="text-[10px] font-mono uppercase tracking-wider text-primary">{drop.collection}</p>
                    <p className="text-sm font-bold text-white">{drop.productName}</p>
                  </div>
                </Link>

                {/* Body */}
                <div className="p-4 space-y-3">
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1.5">
                      <Calendar className="h-3.5 w-3.5" />
                      {dropDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5" />
                      {drop.time}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    {drop.status === "upcoming" && (
                      <button
                        onClick={() => handleNotify(drop.id, drop.productName)}
                        className={cn(
                          "flex-1 h-9 rounded-full text-xs font-bold flex items-center justify-center gap-1.5 transition-colors",
                          hasReminder
                            ? "bg-success/15 text-success border border-success/30"
                            : "bg-primary text-primary-foreground hover:bg-primary/90 btn-shine",
                        )}
                      >
                        {hasReminder ? (
                          <>
                            <Check className="h-3.5 w-3.5" />
                            Reminder set
                          </>
                        ) : (
                          <>
                            <Bell className="h-3.5 w-3.5" />
                            Notify me
                          </>
                        )}
                      </button>
                    )}
                    {drop.status === "live" && product && (
                      <Link
                        href={`/product/${product.slug}`}
                        className="flex-1 h-9 rounded-full text-xs font-bold bg-primary text-primary-foreground hover:bg-primary/90 btn-shine flex items-center justify-center gap-1.5"
                      >
                        <Flame className="h-3.5 w-3.5" />
                        Shop now
                      </Link>
                    )}
                    {drop.status === "sold-out" && (
                      <button
                        onClick={() => handleNotify(drop.id, drop.productName)}
                        className="flex-1 h-9 rounded-full text-xs font-bold border border-border text-muted-foreground hover:text-foreground transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Bell className="h-3.5 w-3.5" />
                        Restock alert
                      </button>
                    )}
                    <button
                      onClick={() => handleAddToCalendar(drop.productName, drop.date)}
                      aria-label="Add to calendar"
                      className="h-9 w-9 rounded-full border border-border hover:border-primary/60 hover:text-primary transition-colors flex items-center justify-center"
                    >
                      <Calendar className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Reminder signup */}
      <div className="mt-12 rounded-2xl border border-border glass-strong p-8 text-center max-w-2xl mx-auto">
        <h3 className="text-xl font-black tracking-tight mb-2">Never miss a drop</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Get a reminder 30 minutes before every release, plus early access links for member-only drops.
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const form = e.currentTarget;
            const input = form.querySelector("input") as HTMLInputElement;
            if (input.value && /@/.test(input.value)) {
              addToast({
                title: "Subscribed to drop alerts",
                description: "Check your inbox to confirm.",
                variant: "success",
              });
              input.value = "";
            } else {
              addToast({
                title: "Enter a valid email",
                variant: "error",
              });
            }
          }}
          className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto"
        >
          <input
            type="email"
            placeholder="you@street.com"
            required
            className="flex-1 h-11 px-4 rounded-full bg-background border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <button
            type="submit"
            className="h-11 px-6 rounded-full bg-primary text-primary-foreground font-bold text-sm btn-shine"
          >
            Subscribe
          </button>
        </form>
      </div>
    </div>
  );
}

function StatusPill({ status }: { status: DropStatus }) {
  if (status === "live") {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider bg-success/20 text-success border border-success/30">
        <span className="h-1.5 w-1.5 rounded-full bg-success animate-pulse" />
        Live now
      </span>
    );
  }
  if (status === "upcoming") {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider bg-primary/20 text-primary border border-primary/30">
        Upcoming
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider bg-muted text-muted-foreground border border-border">
      Sold out
    </span>
  );
}
