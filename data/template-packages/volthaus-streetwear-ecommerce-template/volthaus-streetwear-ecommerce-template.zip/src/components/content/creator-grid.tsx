"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, MapPin, Users } from "lucide-react";
import { creators } from "@/data/creators";
import { cn } from "@/lib/utils";

const ROLES = [
  "All",
  "Photographer",
  "Designer",
  "Skater",
  "Musician",
  "Dancer",
  "Stylist",
] as const;

type Role = (typeof ROLES)[number];

/**
 * Creator grid with role filter. Each card shows the creator cover image,
 * overlapping avatar, name, handle, role, location, follower count, and a
 * "Shop capsule" CTA to the creator detail page.
 */
export function CreatorGrid() {
  const prefersReduced = useReducedMotion();
  const [role, setRole] = React.useState<Role>("All");

  const filtered = React.useMemo(() => {
    if (role === "All") return creators;
    return creators.filter((c) => c.role === role);
  }, [role]);

  return (
    <div>
      {/* Role filter */}
      <div
        className="no-scrollbar -mx-4 mb-8 flex items-center gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0"
        role="tablist"
        aria-label="Filter creators by role"
      >
        {ROLES.map((r) => {
          const count =
            r === "All"
              ? creators.length
              : creators.filter((c) => c.role === r).length;
          const isActive = role === r;
          return (
            <button
              key={r}
              type="button"
              role="tab"
              aria-selected={isActive}
              aria-controls="creator-grid"
              onClick={() => setRole(r)}
              className={cn(
                "inline-flex h-9 shrink-0 items-center gap-2 rounded-full border px-4 text-xs font-mono uppercase tracking-wider transition-colors",
                isActive
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground"
              )}
            >
              {r}
              <span
                className={cn(
                  "inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-bold",
                  isActive
                    ? "bg-primary-foreground/20 text-primary-foreground"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Grid */}
      <div
        id="creator-grid"
        className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
      >
        {filtered.map((c, i) => (
          <motion.article
            key={c.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{
              duration: 0.5,
              delay: prefersReduced ? 0 : Math.min(i * 0.06, 0.4),
              ease: [0.25, 0.4, 0.25, 1],
            }}
            className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40"
          >
            {/* Cover */}
            <Link
              href={`/creators/${c.slug}`}
              className="relative block aspect-[16/10] overflow-hidden bg-muted"
              aria-label={`View ${c.name} capsule`}
            >
              <Image
                src={c.cover}
                alt={`${c.name} cover image`}
                fill
                sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                className={cn(
                  "object-cover transition-transform duration-700 ease-out",
                  !prefersReduced && "group-hover:scale-105"
                )}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
              <span className="absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-full border border-border bg-background/70 px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider text-foreground backdrop-blur">
                {c.drops} {c.drops === 1 ? "drop" : "drops"}
              </span>
            </Link>

            {/* Avatar + identity */}
            <div className="relative -mt-10 px-5">
              <Link
                href={`/creators/${c.slug}`}
                className="block h-20 w-20 overflow-hidden rounded-2xl border-2 border-card bg-muted"
                aria-label={`View ${c.name} capsule`}
              >
                <Image
                  src={c.avatar}
                  alt={`${c.name} avatar`}
                  width={80}
                  height={80}
                  className="h-full w-full object-cover"
                />
              </Link>
            </div>

            <div className="flex flex-1 flex-col p-5 pt-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-lg font-bold tracking-tight text-foreground">
                    <Link
                      href={`/creators/${c.slug}`}
                      className="transition-colors hover:text-primary"
                    >
                      {c.name}
                    </Link>
                  </h3>
                  <p className="text-xs text-muted-foreground">{c.handle}</p>
                </div>
                <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/10 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary">
                  {c.role}
                </span>
              </div>

              <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
                {c.bio}
              </p>

              <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5" aria-hidden />
                  {c.location}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5" aria-hidden />
                  {c.followers} followers
                </span>
              </div>

              <Link
                href={`/creators/${c.slug}`}
                className="mt-5 inline-flex items-center justify-between gap-2 rounded-md border border-border bg-background/60 px-4 py-2.5 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                Shop capsule
                <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
            </div>
          </motion.article>
        ))}
      </div>
    </div>
  );
}
