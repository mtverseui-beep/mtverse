"use client";

import { useMemo, useState, useCallback, useId } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { useLenis } from "lenis/react";
import {
  ChevronDown,
  Printer,
  Mail,
  ShieldCheck,
  Clock,
  ArrowRight,
} from "lucide-react";
import { Breadcrumbs } from "@/components/common";
import { SiteShell } from "@/components/layout";
import { useReducedMotion } from "@/hooks";
import { useToastStore } from "@/store/toast-store";
import { cn } from "@/lib/utils";
import type { PolicyDoc } from "@/types";

export interface PolicyLayoutProps {
  policy: PolicyDoc;
}

/**
 * Shared layout for all VoltHaus policy / legal pages.
 *
 * Renders:
 *  - Breadcrumbs (Home / [Policy title])
 *  - Hero with title, "Last updated" date, and summary
 *  - Sticky sidebar table of contents on desktop (click-to-scroll)
 *  - Mobile dropdown TOC
 *  - Main content sections (heading + body)
 *  - "Need help?" CTA card linking to /contact
 *  - Print button (mock)
 *
 * All animations respect `prefers-reduced-motion`. Smooth scrolling is
 * delegated to the global Lenis instance when available.
 */
export function PolicyLayout({ policy }: PolicyLayoutProps) {
  const reducedMotion = useReducedMotion();
  const lenis = useLenis();
  const addToast = useToastStore((s) => s.addToast);
  const [mobileTocOpen, setMobileTocOpen] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const reactId = useId();

  const sectionIds = useMemo(
    () =>
      policy.sections.map((_, i) => `policy-section-${policy.slug}-${i}`),
    [policy.sections, policy.slug]
  );

  const handleTocClick = useCallback(
    (event: React.MouseEvent<HTMLAnchorElement>, anchor: string) => {
      event.preventDefault();
      setMobileTocOpen(false);
      const target = document.getElementById(anchor);
      if (!target) return;

      if (reducedMotion || !lenis) {
        target.scrollIntoView({
          behavior: reducedMotion ? "auto" : "smooth",
          block: "start",
        });
      } else {
        lenis.scrollTo(target, { offset: -120, duration: 1 });
      }
      setActiveId(anchor);
      // Update focus for keyboard users without forcing a visible jump.
      target.focus({ preventScroll: true });
    },
    [lenis, reducedMotion]
  );

  const handlePrint = useCallback(() => {
    addToast({
      title: "Preparing print view",
      description: `${policy.title} is being sent to your browser print dialog.`,
      variant: "default",
    });
    if (typeof window !== "undefined" && typeof window.print === "function") {
      window.print();
    }
  }, [addToast, policy.title]);

  const formattedDate = useMemo(() => {
    try {
      return new Intl.DateTimeFormat("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
        timeZone: "UTC",
      }).format(new Date(`${policy.updated}T00:00:00Z`));
    } catch {
      return policy.updated;
    }
  }, [policy.updated]);

  const breadcrumbItems = [{ label: policy.title }];

  return (
    <SiteShell>
      <article className="relative">
        {/* Background grid + glow orbs */}
        <div
          aria-hidden="true"
          className="grid-bg pointer-events-none absolute inset-0 opacity-30"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-32 left-1/2 h-[420px] w-[640px] -translate-x-1/2 rounded-full bg-primary/10 blur-[120px]"
        />

        {/* Hero */}
        <header className="relative border-b border-border">
          <div className="mx-auto max-w-7xl px-4 pb-10 pt-8 sm:px-6 md:pb-14 md:pt-12 lg:px-8">
            <Breadcrumbs items={breadcrumbItems} className="mb-8" />

            <div className="flex flex-col gap-5">
              <div className="inline-flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1.5 text-xs font-medium text-primary">
                <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
                <span className="font-mono uppercase tracking-[0.18em]">
                  Legal
                </span>
              </div>

              <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl lg:text-[4rem] lg:leading-[1.05]">
                {policy.title}
              </h1>

              <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="h-4 w-4 text-primary" aria-hidden="true" />
                  <span>Last updated: {formattedDate}</span>
                </span>
                <span
                  aria-hidden="true"
                  className="h-1 w-1 rounded-full bg-muted-foreground/40"
                />
                <span className="font-mono uppercase tracking-[0.18em] text-muted-foreground/80">
                  {policy.id.toUpperCase()}
                </span>
              </div>

              <p className="max-w-3xl text-pretty text-base text-muted-foreground md:text-lg">
                {policy.summary}
              </p>

              <div className="mt-2 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={handlePrint}
                  className="inline-flex items-center gap-2 rounded-md border border-border bg-card/60 px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                >
                  <Printer className="h-4 w-4" aria-hidden="true" />
                  Print this policy
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Body: TOC + content */}
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 md:py-14 lg:px-8">
          <div className="grid grid-cols-1 gap-10 lg:grid-cols-[260px_minmax(0,1fr)] lg:gap-14">
            {/* Sidebar TOC */}
            <aside className="lg:block">
              {/* Mobile dropdown */}
              <div className="lg:hidden">
                <button
                  type="button"
                  onClick={() => setMobileTocOpen((v) => !v)}
                  aria-expanded={mobileTocOpen}
                  aria-controls={`${reactId}-mobile-toc`}
                  className="glass flex w-full items-center justify-between rounded-lg border border-border px-4 py-3 text-left text-sm font-medium text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                >
                  <span>On this page</span>
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 text-muted-foreground transition-transform duration-200",
                      mobileTocOpen && "rotate-180"
                    )}
                    aria-hidden="true"
                  />
                </button>
                <AnimatePresence initial={false}>
                  {mobileTocOpen ? (
                    <motion.nav
                      key="mobile-toc"
                      id={`${reactId}-mobile-toc`}
                      aria-label="Table of contents"
                      initial={
                        reducedMotion
                          ? { opacity: 0 }
                          : { opacity: 0, height: 0 }
                      }
                      animate={
                        reducedMotion
                          ? { opacity: 1 }
                          : { opacity: 1, height: "auto" }
                      }
                      exit={
                        reducedMotion
                          ? { opacity: 0 }
                          : { opacity: 0, height: 0 }
                      }
                      transition={{ duration: 0.2, ease: "easeOut" }}
                      className="no-scrollbar overflow-hidden"
                    >
                      <ul className="mt-2 space-y-1 rounded-lg border border-border bg-card/40 p-3">
                        {policy.sections.map((section, i) => (
                          <li key={sectionIds[i]}>
                            <a
                              href={`#${sectionIds[i]}`}
                              onClick={(e) => handleTocClick(e, sectionIds[i])}
                              className={cn(
                                "block rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-primary/5 hover:text-primary",
                                activeId === sectionIds[i] &&
                                  "bg-primary/10 text-primary"
                              )}
                            >
                              {section.heading}
                            </a>
                          </li>
                        ))}
                      </ul>
                    </motion.nav>
                  ) : null}
                </AnimatePresence>
              </div>

              {/* Desktop sticky TOC */}
              <nav
                aria-label="Table of contents"
                className="hidden lg:sticky lg:top-28 lg:block"
              >
                <p className="mb-3 font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-muted-foreground">
                  On this page
                </p>
                <ul className="space-y-1 border-l border-border">
                  {policy.sections.map((section, i) => (
                    <li key={sectionIds[i]}>
                      <a
                        href={`#${sectionIds[i]}`}
                        onClick={(e) => handleTocClick(e, sectionIds[i])}
                        aria-current={
                          activeId === sectionIds[i] ? "true" : undefined
                        }
                        className={cn(
                          "-ml-px block border-l-2 border-transparent px-4 py-2 text-sm text-muted-foreground transition-colors hover:border-primary hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                          activeId === sectionIds[i] &&
                            "border-primary text-primary"
                        )}
                      >
                        {section.heading}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            </aside>

            {/* Main content */}
            <div className="min-w-0">
              <div className="prose-policy space-y-10">
                {policy.sections.map((section, i) => (
                  <section
                    key={sectionIds[i]}
                    id={sectionIds[i]}
                    tabIndex={-1}
                    className="scroll-mt-28 outline-none"
                    aria-labelledby={`${sectionIds[i]}-heading`}
                  >
                    <div className="mb-3 flex items-center gap-3">
                      <span
                        aria-hidden="true"
                        className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-primary"
                      >
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span
                        aria-hidden="true"
                        className="h-px flex-1 bg-gradient-to-r from-primary/40 to-transparent"
                      />
                    </div>
                    <h2
                      id={`${sectionIds[i]}-heading`}
                      className="text-balance text-2xl font-bold tracking-tight text-foreground md:text-3xl"
                    >
                      {section.heading}
                    </h2>
                    <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground md:text-[1.05rem] md:leading-relaxed">
                      {section.body}
                    </p>
                  </section>
                ))}
              </div>

              {/* Need help CTA */}
              <section
                aria-labelledby="policy-help-heading"
                className="glass relative mt-14 overflow-hidden rounded-2xl border border-border p-6 md:p-8"
              >
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-secondary/15 blur-[80px]"
                />
                <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                  <div className="max-w-xl">
                    <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-secondary/30 bg-secondary/5 px-3 py-1 text-xs font-medium text-secondary">
                      <Mail className="h-3.5 w-3.5" aria-hidden="true" />
                      <span className="font-mono uppercase tracking-[0.18em]">
                        Support
                      </span>
                    </div>
                    <h2
                      id="policy-help-heading"
                      className="text-balance text-2xl font-bold tracking-tight text-foreground md:text-3xl"
                    >
                      Need help with this policy?
                    </h2>
                    <p className="mt-2 text-sm text-muted-foreground md:text-base">
                      Our team is available Monday through Friday, 9am to 6pm
                      PT. We respond to every policy question within one
                      business day.
                    </p>
                    <a
                      href="mailto:support@volthaus.co"
                      className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                    >
                      <Mail className="h-4 w-4" aria-hidden="true" />
                      support@volthaus.co
                    </a>
                  </div>
                  <Link
                    href="/contact"
                    className="btn-shine inline-flex shrink-0 items-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                  >
                    Contact support
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </Link>
                </div>
              </section>
            </div>
          </div>
        </div>
      </article>
    </SiteShell>
  );
}

export default PolicyLayout;
