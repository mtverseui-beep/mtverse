"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { ArrowRight, ShoppingBag, X } from "lucide-react";
import { lookbookItems } from "@/data/lookbook";
import { getProductBySlug } from "@/data/products";
import type { LookbookItem } from "@/types";
import { cn } from "@/lib/utils";
import { useToastStore } from "@/store/toast-store";
import { PriceDisplay } from "@/components/common/price-display";

const FILTERS = ["All", "Street", "Editorial", "Studio", "Night"] as const;
type Filter = (typeof FILTERS)[number];

/**
 * Asymmetric editorial grid of all VoltHaus lookbook items. Filter chips by
 * category; click a card to open a modal with the image + shoppable product
 * list pulled from the item's `productSlugs`.
 *
 * Mobile collapses to a single column.
 */
export function LookbookGrid() {
  const prefersReduced = useReducedMotion();
  const [filter, setFilter] = React.useState<Filter>("All");
  const [activeSlug, setActiveSlug] = React.useState<string | null>(null);

  const filtered = React.useMemo(() => {
    if (filter === "All") return lookbookItems;
    return lookbookItems.filter((i) => i.category === filter);
  }, [filter]);

  const activeItem =
    lookbookItems.find((i) => i.slug === activeSlug) ?? null;

  // Lock body scroll while modal is open.
  React.useEffect(() => {
    if (!activeSlug) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActiveSlug(null);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [activeSlug]);

  return (
    <div>
      {/* Filter chips */}
      <div
        className="no-scrollbar -mx-4 mb-8 flex items-center gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0"
        role="tablist"
        aria-label="Filter lookbook by category"
      >
        {FILTERS.map((f) => {
          const count =
            f === "All"
              ? lookbookItems.length
              : lookbookItems.filter((i) => i.category === f).length;
          const isActive = filter === f;
          return (
            <button
              key={f}
              type="button"
              role="tab"
              aria-selected={isActive}
              aria-controls="lookbook-grid"
              onClick={() => setFilter(f)}
              className={cn(
                "inline-flex h-9 shrink-0 items-center gap-2 rounded-full border px-4 text-xs font-mono uppercase tracking-wider transition-colors",
                isActive
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground"
              )}
            >
              {f}
              <span
                className={cn(
                  "inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-bold",
                  isActive
                    ? "bg-primary-foreground/20 text-primary-foreground"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Asymmetric grid */}
      <div
        id="lookbook-grid"
        className="grid auto-rows-[240px] grid-cols-1 gap-4 sm:grid-cols-2 sm:auto-rows-[320px] lg:grid-cols-4 lg:auto-rows-[280px]"
      >
        {filtered.map((item, i) => {
          // Make the first item large on desktop for editorial feel.
          const isFeature = i === 0;
          return (
            <LookbookCard
              key={item.id}
              item={item}
              isFeature={isFeature}
              prefersReduced={prefersReduced}
              onOpen={() => setActiveSlug(item.slug)}
            />
          );
        })}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {activeItem && (
          <LookbookModal
            item={activeItem}
            onClose={() => setActiveSlug(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

interface LookbookCardProps {
  item: LookbookItem;
  isFeature: boolean;
  prefersReduced: boolean | null;
  onOpen: () => void;
}

function LookbookCard({
  item,
  isFeature,
  prefersReduced,
  onOpen,
}: LookbookCardProps) {
  return (
    <motion.button
      type="button"
      onClick={onOpen}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, ease: [0.25, 0.4, 0.25, 1] }}
      whileHover={prefersReduced ? undefined : { y: -4 }}
      className={cn(
        "group relative block overflow-hidden rounded-2xl border border-border bg-card text-left transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        isFeature && "sm:col-span-2 sm:row-span-2 lg:col-span-2 lg:row-span-2"
      )}
      aria-label={`Open lookbook item: ${item.title}`}
    >
      <Image
        src={item.image}
        alt={item.title}
        fill
        sizes={
          isFeature
            ? "(min-width: 1024px) 50vw, (min-width: 640px) 100vw, 100vw"
            : "(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
        }
        className={cn(
          "object-cover transition-transform duration-700 ease-out",
          !prefersReduced && "group-hover:scale-105"
        )}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
      <div className="absolute left-4 top-4 flex items-center gap-2">
        <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary">
          {item.category}
        </span>
        <span className="inline-flex items-center rounded-full border border-border bg-background/70 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-muted-foreground backdrop-blur">
          {item.season}
        </span>
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-5">
        <h3
          className={cn(
            "text-base font-bold tracking-tight text-foreground sm:text-lg",
            isFeature && "sm:text-xl lg:text-2xl"
          )}
        >
          {item.title}
        </h3>
        <div className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-primary opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          <ShoppingBag className="h-3.5 w-3.5" aria-hidden />
          Shop the look
        </div>
      </div>
    </motion.button>
  );
}

interface LookbookModalProps {
  item: LookbookItem;
  onClose: () => void;
}

function LookbookModal({ item, onClose }: LookbookModalProps) {
  const addToast = useToastStore((s) => s.addToast);
  const products = React.useMemo(
    () =>
      item.productSlugs
        .map((slug) => getProductBySlug(slug))
        .filter((p): p is NonNullable<typeof p> => Boolean(p)),
    [item.productSlugs]
  );

  const handleAdd = (name: string) => {
    addToast({
      title: "Added to cart",
      description: name,
      variant: "success",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 z-[100] flex items-end justify-center bg-background/80 backdrop-blur-sm sm:items-center"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`Lookbook: ${item.title}`}
    >
      <motion.div
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 40, opacity: 0 }}
        transition={{ duration: 0.3, ease: [0.25, 0.4, 0.25, 1] }}
        className="relative flex max-h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-t-2xl border border-border bg-card sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close lookbook"
          className="absolute right-4 top-4 z-10 inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-background/80 text-foreground backdrop-blur transition-colors hover:border-primary/50 hover:text-primary"
        >
          <X className="h-4 w-4" aria-hidden />
        </button>
        <div className="grid max-h-[92vh] grid-rows-[40vh_1fr] overflow-y-auto sm:grid-cols-[1.2fr_1fr] sm:grid-rows-1">
          <div className="relative min-h-[40vh] sm:min-h-[600px]">
            <Image
              src={item.image}
              alt={item.title}
              fill
              sizes="(min-width: 640px) 60vw, 100vw"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-card/60 to-transparent sm:bg-gradient-to-r" />
            <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary">
                  {item.category}
                </span>
                <span className="inline-flex items-center rounded-full border border-border bg-background/70 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-muted-foreground backdrop-blur">
                  {item.season}
                </span>
              </div>
              <h2 className="mt-2 text-xl font-black tracking-tight text-foreground sm:text-2xl">
                {item.title}
              </h2>
            </div>
          </div>
          <div className="flex flex-col gap-4 p-5 sm:p-6">
            <p className="text-sm leading-relaxed text-muted-foreground">
              {item.description}
            </p>
            <div>
              <h3 className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                Shop the look
              </h3>
              <ul className="mt-3 space-y-3">
                {products.map((p) => (
                  <li
                    key={p.id}
                    className="flex items-center gap-3 rounded-xl border border-border bg-background/60 p-2.5"
                  >
                    <Link
                      href={`/product/${p.slug}`}
                      className="relative h-14 w-14 shrink-0 overflow-hidden rounded-md bg-muted"
                      onClick={onClose}
                      aria-label={`View ${p.name}`}
                    >
                      <Image
                        src={p.images[0]}
                        alt={p.name}
                        fill
                        sizes="56px"
                        className="object-cover"
                      />
                    </Link>
                    <div className="min-w-0 flex-1">
                      <Link
                        href={`/product/${p.slug}`}
                        onClick={onClose}
                        className="line-clamp-1 text-sm font-semibold text-foreground hover:text-primary"
                      >
                        {p.name}
                      </Link>
                      <p className="text-[11px] uppercase tracking-wider text-muted-foreground">
                        {p.category}
                      </p>
                      <PriceDisplay
                        price={p.price}
                        compareAtPrice={p.compareAtPrice}
                        size="sm"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => handleAdd(p.name)}
                      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                      aria-label={`Add ${p.name} to cart`}
                    >
                      <ShoppingBag className="h-4 w-4" aria-hidden />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <Link
              href={`/lookbook/${item.slug}`}
              onClick={onClose}
              className="btn-shine mt-auto inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              View full lookbook page
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
