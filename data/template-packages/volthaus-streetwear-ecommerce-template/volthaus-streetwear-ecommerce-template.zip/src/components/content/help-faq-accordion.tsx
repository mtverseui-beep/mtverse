import type { FAQ } from "@/types";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

/**
 * FAQ accordion list. The shadcn Accordion is itself a client component,
 * so this wrapper can be rendered from server components without an
 * additional "use client" boundary.
 */
export function HelpFaqAccordion({
  faqs,
  defaultValue,
}: {
  faqs: FAQ[];
  defaultValue?: string;
}) {
  if (faqs.length === 0) {
    return (
      <p className="rounded-2xl border border-border bg-card p-6 text-sm text-muted-foreground">
        No FAQs in this category yet.{" "}
        <a
          href="/contact"
          className="font-medium text-primary hover:underline"
        >
          Contact support
        </a>{" "}
        and we will help directly.
      </p>
    );
  }
  return (
    <div className="rounded-2xl border border-border bg-card p-4 sm:p-6">
      <Accordion
        type="single"
        collapsible
        defaultValue={defaultValue}
        className="w-full"
      >
        {faqs.map((f) => (
          <AccordionItem
            key={f.id}
            value={f.id}
            className="border-b border-border last:border-b-0"
          >
            <AccordionTrigger className="text-left text-base font-semibold text-foreground hover:no-underline">
              {f.question}
            </AccordionTrigger>
            <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
              {f.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
