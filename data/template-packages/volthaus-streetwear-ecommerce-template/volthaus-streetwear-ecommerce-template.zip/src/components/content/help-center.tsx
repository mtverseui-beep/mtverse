"use client";

import * as React from "react";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  ChevronRight,
  CreditCard,
  Package,
  RotateCcw,
  Search,
  Ship,
  Sparkles,
  type LucideIcon,
} from "lucide-react";
import type { FAQ } from "@/types";
import { cn } from "@/lib/utils";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export interface HelpCategory {
  label: string;
  description: string;
  href: string;
  icon: "Package" | "Ship" | "RotateCcw" | "CreditCard";
}

const ICONS: Record<HelpCategory["icon"], LucideIcon> = {
  Package,
  Ship,
  RotateCcw,
  CreditCard,
};

interface HelpCenterProps {
  popularFaqs: FAQ[];
  categories: HelpCategory[];
}

/**
 * Help center landing body. Owns the search input and the accordion of
 * popular FAQs. Categories are passed in from the server page as plain
 * serializable data (icon names, not components).
 */
export function HelpCenter({ popularFaqs, categories }: HelpCenterProps) {
  const prefersReduced = useReducedMotion();
  const [query, setQuery] = React.useState("");

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return popularFaqs;
    return popularFaqs.filter(
      (f) =>
        f.question.toLowerCase().includes(q) ||
        f.answer.toLowerCase().includes(q)
    );
  }, [popularFaqs, query]);

  return (
    <div>
      {/* Search */}
      <div className="relative mx-auto max-w-2xl">
        <Search
          className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground"
          aria-hidden="true"
        />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for help — try 'tracking' or 'returns'"
          aria-label="Search help center"
          className="h-14 w-full rounded-full border border-border bg-card pl-12 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      {/* Quick categories */}
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {categories.map((c, i) => {
          const Icon = ICONS[c.icon];
          return (
            <motion.div
              key={c.href}
              initial={prefersReduced ? false : { opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ delay: i * 0.06, duration: 0.4, ease: "easeOut" }}
            >
              <Link
                href={c.href}
                className="group block h-full rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <span className="inline-flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  {Icon ? <Icon className="h-5 w-5" aria-hidden /> : null}
                </span>
                <h3 className="mt-4 text-base font-bold">{c.label}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{c.description}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-xs font-mono uppercase tracking-wider text-primary">
                  Open
                  <ArrowRight className="size-3" aria-hidden />
                </span>
              </Link>
            </motion.div>
          );
        })}
      </div>

      {/* Popular articles */}
      <div className="mt-12">
        <div className="flex items-center gap-2">
          <Sparkles className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-mono uppercase tracking-[0.2em] text-muted-foreground">
            Popular articles
          </h2>
        </div>
        <Accordion type="single" collapsible className="mt-4">
          {filtered.length === 0 ? (
            <p className="rounded-xl border border-border bg-card p-6 text-center text-sm text-muted-foreground">
              No articles match &ldquo;{query}&rdquo;. Try a different search or{" "}
              <Link href="/contact" className="text-primary underline-offset-2 hover:underline">
                contact support
              </Link>
              .
            </p>
          ) : (
            filtered.map((faq) => (
              <AccordionItem
                key={faq.id}
                value={faq.id}
                className="border-b border-border"
              >
                <AccordionTrigger className="py-4 text-left text-sm font-semibold hover:no-underline">
                  <span className="flex items-center gap-2 pr-4">
                    <ChevronRight
                      className="size-4 shrink-0 text-muted-foreground transition-transform"
                      aria-hidden
                    />
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="pb-4 text-sm text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))
          )}
        </Accordion>
      </div>

      {/* Bottom CTA */}
      <div className="mt-12 rounded-2xl border border-primary/30 bg-primary/5 p-6 text-center sm:p-8">
        <h2 className="text-xl font-bold sm:text-2xl">
          Still need a human?
        </h2>
        <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
          Our support team replies within one business day, Monday through Friday.
        </p>
        <Link
          href="/contact"
          className="btn-shine mt-4 inline-flex h-11 items-center justify-center rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
        >
          Contact support
        </Link>
      </div>
    </div>
  );
}
