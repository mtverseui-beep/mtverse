"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, ArrowLeft, CalendarDays, ShoppingBag } from "lucide-react";
import type { Campaign, Product } from "@/types";
import { cn } from "@/lib/utils";
import { PriceDisplay } from "@/components/common/price-display";

interface CampaignDetailProps {
  campaign: Campaign;
  lookProducts: Product[];
  relatedCampaigns: Campaign[];
}

/**
 * Client-rendered campaign detail body. Receives the campaign, shoppable
 * products, and related campaigns from the server page.
 */
export function CampaignDetail({
  campaign,
  lookProducts,
  relatedCampaigns,
}: CampaignDetailProps) {
  const prefersReduced = useReducedMotion();
  const published = new Date(campaign.publishedAt);

  return (
    <div className="pb-16">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="relative h-[60vh] min-h-[420px] w-full sm:h-[72vh]">
          <Image
            src={campaign.cover}
            alt={`${campaign.name} cover image`}
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/45 to-background/10" />
          <div className="absolute inset-x-0 bottom-0">
            <div className="container mx-auto max-w-7xl px-4 pb-8 sm:px-6 lg:px-8 lg:pb-12">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-3 py-1 text-[11px] font-mono uppercase tracking-wider text-primary">
                  {campaign.season}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full border border-border bg-background/70 px-3 py-1 text-[11px] font-mono uppercase tracking-wider text-muted-foreground backdrop-blur">
                  <CalendarDays className="h-3.5 w-3.5" aria-hidden />
                  {published.toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
              </div>
              <h1 className="mt-4 max-w-4xl text-balance text-4xl font-black leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
                {campaign.name}
              </h1>
            </div>
          </div>
        </div>
      </section>

      {/* Description */}
      <section className="container mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              About the campaign
            </p>
            <p className="mt-4 text-lg leading-relaxed text-foreground/90">
              {campaign.description}
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                href="/campaigns"
                className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-transparent px-5 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:bg-card"
              >
                <ArrowLeft className="h-4 w-4" aria-hidden />
                All campaigns
              </Link>
              <a
                href="#shop-the-look"
                className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                <ShoppingBag className="h-4 w-4" aria-hidden />
                Shop the look
              </a>
            </div>
          </motion.div>
          <motion.aside
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{
              duration: 0.6,
              delay: prefersReduced ? 0 : 0.1,
              ease: [0.25, 0.4, 0.25, 1],
            }}
            className="rounded-2xl border border-border bg-card p-6"
          >
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              Campaign details
            </p>
            <dl className="mt-4 space-y-3 text-sm">
              <div className="flex items-center justify-between border-b border-border pb-3">
                <dt className="text-muted-foreground">Season</dt>
                <dd className="font-semibold text-foreground">
                  {campaign.season}
                </dd>
              </div>
              <div className="flex items-center justify-between border-b border-border pb-3">
                <dt className="text-muted-foreground">Published</dt>
                <dd className="font-semibold text-foreground">
                  {published.toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </dd>
              </div>
              <div className="flex items-center justify-between border-b border-border pb-3">
                <dt className="text-muted-foreground">Gallery frames</dt>
                <dd className="font-semibold text-foreground">
                  {campaign.gallery.length}
                </dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">Pieces in look</dt>
                <dd className="font-semibold text-foreground">
                  {lookProducts.length}
                </dd>
              </div>
            </dl>
          </motion.aside>
        </div>
      </section>

      {/* Gallery */}
      <section className="container mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8 lg:pb-16">
        <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
          Gallery
        </p>
        <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
          Frames from the shoot
        </h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {campaign.gallery.map((src, i) => (
            <motion.figure
              key={`${src}-${i}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{
                duration: 0.5,
                delay: prefersReduced ? 0 : Math.min(i * 0.05, 0.3),
                ease: [0.25, 0.4, 0.25, 1],
              }}
              className={cn(
                "group relative overflow-hidden rounded-2xl border border-border bg-card",
                i === 0 && "sm:col-span-2 lg:col-span-2 lg:row-span-2"
              )}
            >
              <div
                className={cn(
                  "relative overflow-hidden bg-muted",
                  i === 0 ? "aspect-[16/10] lg:aspect-[16/12]" : "aspect-[4/3]"
                )}
              >
                <Image
                  src={src}
                  alt={`${campaign.name} gallery frame ${i + 1}`}
                  fill
                  sizes={
                    i === 0
                      ? "(min-width: 1024px) 66vw, 100vw"
                      : "(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                  }
                  className={cn(
                    "object-cover transition-transform duration-700 ease-out",
                    !prefersReduced && "group-hover:scale-105"
                  )}
                />
              </div>
              <figcaption className="absolute bottom-3 left-3 rounded-full border border-border bg-background/70 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-muted-foreground backdrop-blur">
                Frame {String(i + 1).padStart(2, "0")}
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </section>

      {/* Shop the look */}
      <section
        id="shop-the-look"
        className="container mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8 lg:pb-16"
      >
        <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
          Shop the look
        </p>
        <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
          Pieces from the campaign
        </h2>
        {lookProducts.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">
            No products linked to this campaign yet.
          </p>
        ) : (
          <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {lookProducts.map((p, i) => (
              <motion.article
                key={p.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{
                  duration: 0.5,
                  delay: prefersReduced ? 0 : Math.min(i * 0.05, 0.3),
                  ease: [0.25, 0.4, 0.25, 1],
                }}
                className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40"
              >
                <Link
                  href={`/product/${p.slug}`}
                  className="relative block aspect-square overflow-hidden bg-muted"
                  aria-label={`View ${p.name}`}
                >
                  <Image
                    src={p.images[0]}
                    alt={p.name}
                    fill
                    sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
                    className={cn(
                      "object-cover transition-transform duration-700 ease-out",
                      !prefersReduced && "group-hover:scale-105"
                    )}
                  />
                </Link>
                <div className="flex flex-1 flex-col gap-2 p-4">
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
                    {p.category}
                  </span>
                  <h3 className="text-sm font-bold tracking-tight text-foreground">
                    <Link
                      href={`/product/${p.slug}`}
                      className="transition-colors hover:text-primary"
                    >
                      {p.name}
                    </Link>
                  </h3>
                  <PriceDisplay
                    price={p.price}
                    compareAtPrice={p.compareAtPrice}
                    size="sm"
                  />
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </section>

      {/* Related campaigns */}
      {relatedCampaigns.length > 0 && (
        <section className="container mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8 lg:pb-24">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            More campaigns
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Related campaigns
          </h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {relatedCampaigns.map((c) => (
              <Link
                key={c.id}
                href={`/campaigns/${c.slug}`}
                className="group relative block overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-muted">
                  <Image
                    src={c.cover}
                    alt={c.name}
                    fill
                    sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent" />
                  <span className="absolute left-3 top-3 inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary">
                    {c.season}
                  </span>
                </div>
                <div className="p-5">
                  <h3 className="text-lg font-bold tracking-tight text-foreground">
                    {c.name}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">
                    {c.description}
                  </p>
                  <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
                    View campaign
                    <ArrowRight className="h-3.5 w-3.5" aria-hidden />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
