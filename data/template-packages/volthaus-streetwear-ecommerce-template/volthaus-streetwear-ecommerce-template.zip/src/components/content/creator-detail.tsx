"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  BadgeCheck,
  ExternalLink,
  Mail,
  Quote,
  Sparkles,
  Users,
} from "lucide-react";
import type { Creator, Product, Review } from "@/types";
import { cn } from "@/lib/utils";
import { StarRating } from "@/components/common/star-rating";
import { PriceDisplay } from "@/components/common/price-display";

interface CreatorDetailProps {
  creator: Creator;
  capsuleProducts: Product[];
  testimonials: Review[];
  averageRating: number;
}

const SOCIAL_ICON: Record<string, React.ComponentType<{ className?: string }>> =
  {
    Instagram: Sparkles,
    Portfolio: ExternalLink,
    Studio: ExternalLink,
    Classes: ExternalLink,
    Bandcamp: ExternalLink,
    YouTube: ExternalLink,
    Mail: Mail,
  };

/**
 * Client-rendered creator detail body. Receives the creator, capsule
 * products, mock testimonials, and average rating from the server page
 * (so the page itself can stay a server component for metadata + data
 * fetching).
 */
export function CreatorDetail({
  creator,
  capsuleProducts,
  testimonials,
  averageRating,
}: CreatorDetailProps) {
  const prefersReduced = useReducedMotion();

  return (
    <div className="pb-16">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="relative h-[44vh] min-h-[320px] w-full sm:h-[56vh]">
          <Image
            src={creator.cover}
            alt={`${creator.name} cover image`}
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-background/10" />
        </div>
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="relative -mt-16 flex flex-col gap-6 sm:-mt-20 lg:flex-row lg:items-end lg:justify-between lg:gap-10">
            <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-end">
              <div className="h-28 w-28 overflow-hidden rounded-2xl border-2 border-card bg-muted sm:h-32 sm:w-32">
                <Image
                  src={creator.avatar}
                  alt={`${creator.name} avatar`}
                  width={128}
                  height={128}
                  className="h-full w-full object-cover"
                />
              </div>
              <div>
                <p className="text-xs font-mono uppercase tracking-[0.24em] text-primary">
                  {creator.role}
                </p>
                <h1 className="mt-1 text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
                  {creator.name}
                </h1>
                <p className="mt-1 text-sm text-muted-foreground">
                  {creator.handle}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {creator.socials.map((s) => {
                const Icon = SOCIAL_ICON[s.label] ?? ExternalLink;
                const isMail = s.label === "Mail";
                return (
                  <a
                    key={s.label}
                    href={s.href}
                    aria-label={`${creator.name} ${s.label}`}
                    className="inline-flex h-10 items-center justify-center gap-2 rounded-full border border-border bg-background/70 px-4 text-xs font-medium text-foreground backdrop-blur transition-colors hover:border-primary/50 hover:text-primary"
                    {...(isMail
                      ? {}
                      : { target: "_blank", rel: "noopener noreferrer" })}
                  >
                    <Icon className="h-4 w-4" aria-hidden />
                    {s.label}
                  </a>
                );
              })}
            </div>
          </div>
          <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <Sparkles className="h-4 w-4 text-primary" aria-hidden />
              {creator.location}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Users className="h-4 w-4 text-primary" aria-hidden />
              {creator.followers} followers
            </span>
            <span className="inline-flex items-center gap-1.5">
              <BadgeCheck className="h-4 w-4 text-primary" aria-hidden />
              {creator.drops} {creator.drops === 1 ? "drop" : "drops"} with
              VoltHaus
            </span>
            <span className="inline-flex items-center gap-1.5">
              <StarRating rating={averageRating} size={14} />
              {averageRating.toFixed(1)} average
            </span>
          </div>
        </div>
      </section>

      {/* Bio + story */}
      <section className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{
              duration: 0.6,
              ease: [0.25, 0.4, 0.25, 1],
            }}
          >
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              Bio
            </p>
            <p className="mt-4 text-lg leading-relaxed text-foreground/90">
              {creator.bio}
            </p>
            <h2 className="mt-10 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
              The full story
            </h2>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              {creator.story}
            </p>
          </motion.div>

          <motion.aside
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{
              duration: 0.6,
              delay: prefersReduced ? 0 : 0.1,
              ease: [0.25, 0.4, 0.25, 1],
            }}
            className="rounded-2xl border border-border bg-card p-6 lg:p-8"
          >
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              At a glance
            </p>
            <dl className="mt-4 space-y-3 text-sm">
              <div className="flex items-center justify-between border-b border-border pb-3">
                <dt className="text-muted-foreground">Role</dt>
                <dd className="font-semibold text-foreground">
                  {creator.role}
                </dd>
              </div>
              <div className="flex items-center justify-between border-b border-border pb-3">
                <dt className="text-muted-foreground">Location</dt>
                <dd className="font-semibold text-foreground">
                  {creator.location}
                </dd>
              </div>
              <div className="flex items-center justify-between border-b border-border pb-3">
                <dt className="text-muted-foreground">Followers</dt>
                <dd className="font-semibold text-foreground">
                  {creator.followers}
                </dd>
              </div>
              <div className="flex items-center justify-between border-b border-border pb-3">
                <dt className="text-muted-foreground">Drops with VoltHaus</dt>
                <dd className="font-semibold text-foreground">
                  {creator.drops}
                </dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">Avg. capsule rating</dt>
                <dd className="font-semibold text-foreground">
                  {averageRating.toFixed(1)} / 5
                </dd>
              </div>
            </dl>
          </motion.aside>
        </div>
      </section>

      {/* Capsule grid */}
      <section className="container mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8 lg:pb-16">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              Capsule collection
            </p>
            <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
              Shop the {creator.name.split(" ")[0]} capsule
            </h2>
          </div>
          <Link
            href="/shop"
            className="text-sm font-medium text-primary hover:underline"
          >
            Shop all products
          </Link>
        </div>
        {capsuleProducts.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No capsule products available right now.
          </p>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {capsuleProducts.map((p, i) => (
              <motion.article
                key={p.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{
                  duration: 0.5,
                  delay: prefersReduced ? 0 : Math.min(i * 0.06, 0.3),
                  ease: [0.25, 0.4, 0.25, 1],
                }}
                className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40"
              >
                <Link
                  href={`/product/${p.slug}`}
                  className="relative block aspect-square overflow-hidden bg-muted"
                  aria-label={`View ${p.name}`}
                >
                  <Image
                    src={p.images[0]}
                    alt={p.name}
                    fill
                    sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                    className={cn(
                      "object-cover transition-transform duration-700 ease-out",
                      !prefersReduced && "group-hover:scale-105"
                    )}
                  />
                  {p.badge && (
                    <span className="absolute left-3 top-3 inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary">
                      {p.badge}
                    </span>
                  )}
                </Link>
                <div className="flex flex-1 flex-col gap-2 p-5">
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
                    {p.category}
                  </span>
                  <h3 className="text-base font-bold tracking-tight text-foreground">
                    <Link
                      href={`/product/${p.slug}`}
                      className="transition-colors hover:text-primary"
                    >
                      {p.name}
                    </Link>
                  </h3>
                  <PriceDisplay
                    price={p.price}
                    compareAtPrice={p.compareAtPrice}
                    size="md"
                  />
                  <Link
                    href={`/product/${p.slug}`}
                    className="btn-shine mt-3 inline-flex h-10 items-center justify-center gap-2 rounded-md bg-primary px-4 text-xs font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
                  >
                    View product
                    <ArrowRight className="h-3.5 w-3.5" aria-hidden />
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </section>

      {/* Testimonials */}
      {testimonials.length > 0 && (
        <section className="relative overflow-hidden border-y border-border bg-card/40">
          <div className="absolute inset-0 grid-bg opacity-20" aria-hidden />
          <div className="relative container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              Social proof
            </p>
            <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
              What buyers say about the capsule
            </h2>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {testimonials.map((t, i) => (
                <motion.figure
                  key={t.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{
                    duration: 0.5,
                    delay: prefersReduced ? 0 : i * 0.08,
                    ease: [0.25, 0.4, 0.25, 1],
                  }}
                  className="flex h-full flex-col rounded-2xl border border-border bg-background/60 p-6"
                >
                  <Quote className="h-7 w-7 text-primary/40" aria-hidden />
                  <StarRating rating={t.rating} size={14} className="mt-3" />
                  <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-foreground/90">
                    {t.body}
                  </blockquote>
                  <figcaption className="mt-5 flex items-center gap-3 border-t border-border pt-4">
                    <Image
                      src={t.avatar}
                      alt={t.author}
                      width={36}
                      height={36}
                      className="h-9 w-9 rounded-full border border-border object-cover"
                    />
                    <div>
                      <p className="text-sm font-semibold text-foreground">
                        {t.author}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {t.productName}
                      </p>
                    </div>
                  </figcaption>
                </motion.figure>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-8 sm:p-12">
          <div
            aria-hidden
            className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-primary/15 blur-3xl"
          />
          <div className="relative flex flex-col items-start gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-2xl">
              <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                Shop the capsule
              </p>
              <h2 className="mt-3 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                Wear what {creator.name.split(" ")[0]} built
              </h2>
              <p className="mt-3 text-sm text-muted-foreground">
                The capsule ships with a printed zine documenting every pattern
                decision. Available while the current run lasts.
              </p>
            </div>
            <Link
              href="/shop"
              className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Shop the capsule
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
