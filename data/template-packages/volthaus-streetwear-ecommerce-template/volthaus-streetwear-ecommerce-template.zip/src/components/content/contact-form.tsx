"use client";

import * as React from "react";
import {
  CheckCircle2,
  Clock,
  Mail,
  MapPin,
  MessageSquare,
  Paperclip,
  Phone,
  Send,
  Sparkles,
} from "lucide-react";
import { useToastStore } from "@/store/toast-store";
import { cn } from "@/lib/utils";

const SUBJECTS = [
  "Order",
  "Returns",
  "Drop alerts",
  "Partnership",
  "Press",
  "Other",
] as const;
type Subject = (typeof SUBJECTS)[number];

interface FormState {
  name: string;
  email: string;
  subject: Subject | "";
  message: string;
  attachment: string;
}

const INITIAL: FormState = {
  name: "",
  email: "",
  subject: "",
  message: "",
  attachment: "",
};

/**
 * Contact form with validation, attachment (mock file input), and a
 * success state that displays a generated ticket number.
 */
export function ContactForm() {
  const addToast = useToastStore((s) => s.addToast);
  const [form, setForm] = React.useState<FormState>(INITIAL);
  const [errors, setErrors] = React.useState<Partial<Record<keyof FormState, string>>>(
    {}
  );
  const [submitting, setSubmitting] = React.useState(false);
  const [ticket, setTicket] = React.useState<string | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };

  const validate = () => {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (form.name.trim().length < 2) next.name = "Enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      next.email = "Enter a valid email address.";
    if (!form.subject) next.subject = "Pick a subject.";
    if (form.message.trim().length < 20)
      next.message = "Message must be at least 20 characters.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    // Simulate a network round-trip.
    await new Promise((r) => setTimeout(r, 700));
    const generated = `VH-${Date.now().toString(36).toUpperCase().slice(-6)}`;
    setTicket(generated);
    setSubmitting(false);
    addToast({
      title: "Message sent",
      description: `Ticket ${generated} created.`,
      variant: "success",
    });
  };

  const reset = () => {
    setForm(INITIAL);
    setErrors({});
    setTicket(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  if (ticket) {
    return (
      <div className="rounded-2xl border border-success/30 bg-success/10 p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-success/15 text-success">
          <CheckCircle2 className="h-7 w-7" aria-hidden />
        </div>
        <h2 className="mt-5 text-2xl font-black tracking-tight text-foreground">
          Message received
        </h2>
        <p className="mt-3 text-sm text-muted-foreground">
          We have logged your message under ticket{" "}
          <span className="font-mono font-bold text-foreground">{ticket}</span>{" "}
          and you will hear back from support@volthaus.co within one business
          day.
        </p>
        <button
          type="button"
          onClick={reset}
          className="mt-6 inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-background px-6 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-5 rounded-2xl border border-border bg-card p-6 sm:p-8"
      noValidate
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label
            htmlFor="cf-name"
            className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
          >
            Name
          </label>
          <input
            id="cf-name"
            type="text"
            autoComplete="name"
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
            className="mt-1.5 h-11 w-full rounded-md border border-border bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            placeholder="Your full name"
            required
            aria-invalid={Boolean(errors.name)}
          />
          {errors.name && (
            <p className="mt-1 text-xs text-destructive">{errors.name}</p>
          )}
        </div>
        <div>
          <label
            htmlFor="cf-email"
            className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
          >
            Email
          </label>
          <input
            id="cf-email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            className="mt-1.5 h-11 w-full rounded-md border border-border bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            placeholder="you@street.com"
            required
            aria-invalid={Boolean(errors.email)}
          />
          {errors.email && (
            <p className="mt-1 text-xs text-destructive">{errors.email}</p>
          )}
        </div>
      </div>

      <div>
        <label
          htmlFor="cf-subject"
          className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
        >
          Subject
        </label>
        <select
          id="cf-subject"
          value={form.subject}
          onChange={(e) => update("subject", e.target.value as Subject)}
          className="mt-1.5 h-11 w-full rounded-md border border-border bg-background px-3 text-sm text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
          required
          aria-invalid={Boolean(errors.subject)}
        >
          <option value="">Select a subject</option>
          {SUBJECTS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        {errors.subject && (
          <p className="mt-1 text-xs text-destructive">{errors.subject}</p>
        )}
      </div>

      <div>
        <label
          htmlFor="cf-message"
          className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
        >
          Message
        </label>
        <textarea
          id="cf-message"
          rows={5}
          value={form.message}
          onChange={(e) => update("message", e.target.value)}
          className="mt-1.5 w-full rounded-md border border-border bg-background p-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
          placeholder="Tell us what is going on. Include an order number if relevant."
          required
          aria-invalid={Boolean(errors.message)}
        />
        <p className="mt-1 text-right text-[11px] text-muted-foreground">
          {form.message.length} characters
        </p>
        {errors.message && (
          <p className="mt-1 text-xs text-destructive">{errors.message}</p>
        )}
      </div>

      <div>
        <label
          htmlFor="cf-attachment"
          className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
        >
          Attachment (optional)
        </label>
        <div className="mt-1.5 flex items-center gap-3">
          <input
            id="cf-attachment"
            ref={fileInputRef}
            type="file"
            onChange={(e) =>
              update("attachment", e.target.files?.[0]?.name ?? "")
            }
            className="hidden"
            aria-describedby="cf-attachment-help"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex h-11 items-center gap-2 rounded-md border border-border bg-background px-4 text-sm font-medium text-foreground transition-colors hover:border-primary/50 hover:text-primary"
          >
            <Paperclip className="h-4 w-4" aria-hidden />
            Choose file
          </button>
          <span
            id="cf-attachment-help"
            className="truncate text-xs text-muted-foreground"
          >
            {form.attachment || "No file selected. JPG, PNG, or PDF up to 10 MB."}
          </span>
        </div>
      </div>

      <div className="flex items-center justify-between gap-3 border-t border-border pt-4">
        <p className="text-[11px] text-muted-foreground">
          We typically reply within one business day, Mon–Fri 9–6 CET.
        </p>
        <button
          type="submit"
          disabled={submitting}
          className={cn(
            "btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90",
            submitting && "cursor-not-allowed opacity-70"
          )}
        >
          {submitting ? (
            <>
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
              Sending…
            </>
          ) : (
            <>
              <Send className="h-4 w-4" aria-hidden />
              Send message
            </>
          )}
        </button>
      </div>
    </form>
  );
}

export function ContactInfoCard() {
  return (
    <aside className="space-y-5 rounded-2xl border border-border bg-card p-6 sm:p-8">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
          Contact info
        </p>
        <h2 className="mt-2 text-xl font-black tracking-tight text-foreground">
          Talk to a real human
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Our support team is small, in-house, and answers every message. We
          do not outsource.
        </p>
      </div>

      <ul className="space-y-3 text-sm">
        <li className="flex items-start gap-3">
          <Mail className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
          <div>
            <p className="font-semibold text-foreground">Email</p>
            <a
              href="mailto:support@volthaus.co"
              className="text-muted-foreground hover:text-primary"
            >
              support@volthaus.co
            </a>
          </div>
        </li>
        <li className="flex items-start gap-3">
          <Clock className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
          <div>
            <p className="font-semibold text-foreground">Hours</p>
            <p className="text-muted-foreground">
              Mon–Fri, 9:00–18:00 CET. Closed weekends and EU public holidays.
            </p>
          </div>
        </li>
        <li className="flex items-start gap-3">
          <MessageSquare className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
          <div>
            <p className="font-semibold text-foreground">Response time</p>
            <p className="text-muted-foreground">
              Under one business day for emails, under fifteen minutes during
              live drops via the in-app chat.
            </p>
          </div>
        </li>
        <li className="flex items-start gap-3">
          <Phone className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
          <div>
            <p className="font-semibold text-foreground">Phone (members)</p>
            <p className="text-muted-foreground">
              Static tier members get a dedicated phone line. Visible in your
              account dashboard.
            </p>
          </div>
        </li>
        <li className="flex items-start gap-3">
          <MapPin className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
          <div>
            <p className="font-semibold text-foreground">Studio</p>
            <p className="text-muted-foreground">
              VoltHaus HQ, Oranienstraße 6, 10999 Berlin, Germany
            </p>
          </div>
        </li>
        <li className="flex items-start gap-3">
          <Sparkles className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
          <div>
            <p className="font-semibold text-foreground">Social</p>
            <p className="text-muted-foreground">
              @volthaus on Instagram, X, TikTok, and YouTube.
            </p>
          </div>
        </li>
      </ul>
    </aside>
  );
}
