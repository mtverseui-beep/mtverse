"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Clock, Search, Tag } from "lucide-react";
import { blogPosts } from "@/data/blog";
import type { BlogPost } from "@/types";
import { cn } from "@/lib/utils";

/**
 * Blog index body. Server-side data fetch in page.tsx passes the featured
 * post and the remaining posts; this client component owns the search
 * input, category filter, and renders the grid.
 */
export function BlogList({
  featured,
  remaining,
}: {
  featured: BlogPost;
  remaining: BlogPost[];
}) {
  const prefersReduced = useReducedMotion();
  const [query, setQuery] = React.useState("");
  const [category, setCategory] = React.useState<string>("All");

  const categories = React.useMemo(() => {
    const set = new Set<string>();
    blogPosts.forEach((p) => set.add(p.category));
    return ["All", ...Array.from(set)];
  }, []);

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return remaining.filter((p) => {
      if (category !== "All" && p.category !== category) return false;
      if (!q) return true;
      return (
        p.title.toLowerCase().includes(q) ||
        p.excerpt.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q))
      );
    });
  }, [remaining, category, query]);

  return (
    <div>
      {/* Featured post */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-50px" }}
        transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
      >
        <Link
          href={`/blog/${featured.slug}`}
          className="group grid overflow-hidden rounded-3xl border border-border bg-card transition-colors hover:border-primary/40 lg:grid-cols-2"
        >
          <div className="relative aspect-[16/10] overflow-hidden bg-muted lg:aspect-auto">
            <Image
              src={featured.cover}
              alt={featured.title}
              fill
              priority
              sizes="(min-width: 1024px) 50vw, 100vw"
              className={cn(
                "object-cover transition-transform duration-700 ease-out",
                !prefersReduced && "group-hover:scale-105"
              )}
            />
            <span className="absolute left-4 top-4 inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/15 px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-primary backdrop-blur">
              <Tag className="h-3 w-3" aria-hidden />
              Featured
            </span>
          </div>
          <div className="flex flex-col justify-center gap-4 p-6 sm:p-8 lg:p-12">
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center rounded-full border border-border bg-background/60 px-2.5 py-0.5 font-mono uppercase tracking-wider text-primary">
                {featured.category}
              </span>
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" aria-hidden />
                {featured.readTime}
              </span>
              <span>
                {new Date(featured.publishedAt).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
              </span>
            </div>
            <h2 className="text-2xl font-black tracking-tight text-foreground sm:text-3xl lg:text-4xl">
              {featured.title}
            </h2>
            <p className="text-sm leading-relaxed text-muted-foreground sm:text-base">
              {featured.excerpt}
            </p>
            <div className="flex items-center gap-3 border-t border-border pt-4">
              <Image
                src={featured.authorAvatar}
                alt={featured.author}
                width={36}
                height={36}
                className="h-9 w-9 rounded-full border border-border object-cover"
              />
              <div className="text-xs">
                <p className="font-semibold text-foreground">
                  {featured.author}
                </p>
                <p className="text-muted-foreground">VoltHaus Journal</p>
              </div>
              <span className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-primary">
                Read article
                <ArrowRight
                  className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1"
                  aria-hidden
                />
              </span>
            </div>
          </div>
        </Link>
      </motion.div>

      {/* Search + category filter */}
      <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <input
            type="search"
            placeholder="Search the journal"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="h-11 w-full rounded-full border border-border bg-card pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            aria-label="Search the journal"
          />
        </div>
        <div
          className="no-scrollbar -mx-4 flex items-center gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0"
          role="tablist"
          aria-label="Filter journal by category"
        >
          {categories.map((c) => {
            const isActive = category === c;
            return (
              <button
                key={c}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-controls="blog-grid"
                onClick={() => setCategory(c)}
                className={cn(
                  "inline-flex h-9 shrink-0 items-center rounded-full border px-4 text-xs font-mono uppercase tracking-wider transition-colors",
                  isActive
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground"
                )}
              >
                {c}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid */}
      <div id="blog-grid" className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.length === 0 ? (
          <div className="col-span-full rounded-2xl border border-border bg-card p-12 text-center">
            <p className="text-sm text-muted-foreground">
              No articles match your search. Try a different keyword or
              category.
            </p>
          </div>
        ) : (
          filtered.map((p, i) => (
            <BlogCard key={p.id} post={p} index={i} />
          ))
        )}
      </div>
    </div>
  );
}

function BlogCard({ post, index }: { post: BlogPost; index: number }) {
  const prefersReduced = useReducedMotion();
  const date = new Date(post.publishedAt);
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{
        duration: 0.5,
        delay: prefersReduced ? 0 : Math.min(index * 0.06, 0.3),
        ease: [0.25, 0.4, 0.25, 1],
      }}
      className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40"
    >
      <Link
        href={`/blog/${post.slug}`}
        className="relative block aspect-[16/10] overflow-hidden bg-muted"
        aria-label={`Read ${post.title}`}
      >
        <Image
          src={post.cover}
          alt={post.title}
          fill
          sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
          className={cn(
            "object-cover transition-transform duration-700 ease-out",
            !prefersReduced && "group-hover:scale-105"
          )}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
        <span className="absolute left-3 top-3 inline-flex items-center rounded-full border border-border bg-background/70 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary backdrop-blur">
          {post.category}
        </span>
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3 w-3" aria-hidden />
            {post.readTime}
          </span>
          <span aria-hidden>·</span>
          <span>
            {date.toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </span>
        </div>
        <h3 className="mt-2 text-base font-bold leading-snug tracking-tight text-foreground">
          <Link
            href={`/blog/${post.slug}`}
            className="transition-colors hover:text-primary"
          >
            {post.title}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
          {post.excerpt}
        </p>
        <div className="mt-auto flex items-center gap-3 border-t border-border pt-4">
          <Image
            src={post.authorAvatar}
            alt={post.author}
            width={28}
            height={28}
            className="h-7 w-7 rounded-full border border-border object-cover"
          />
          <span className="text-xs text-muted-foreground">{post.author}</span>
          <span className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-primary opacity-0 transition-opacity group-hover:opacity-100">
            Read
            <ArrowRight className="h-3 w-3" aria-hidden />
          </span>
        </div>
      </div>
    </motion.article>
  );
}
