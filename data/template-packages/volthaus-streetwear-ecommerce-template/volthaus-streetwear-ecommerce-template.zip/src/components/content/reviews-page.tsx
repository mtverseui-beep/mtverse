"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  BadgeCheck,
  Check,
  CheckCircle2,
  Filter,
  PenLine,
  Star,
  X,
} from "lucide-react";
import { reviews as allReviews } from "@/data/reviews";
import { products } from "@/data/products";
import type { Review } from "@/types";
import { cn } from "@/lib/utils";
import { useToastStore } from "@/store/toast-store";
import { StarRating } from "@/components/common/star-rating";

type SortKey = "newest" | "highest" | "lowest";
type RatingFilter = 0 | 5 | 4 | 3 | 2 | 1;

const PAGE_SIZE = 6;

const SUMMARY = {
  average: 4.8,
  total: allReviews.length,
  distribution: [
    { stars: 5, count: 9, percent: 75 },
    { stars: 4, count: 2, percent: 17 },
    { stars: 3, count: 1, percent: 8 },
    { stars: 2, count: 0, percent: 0 },
    { stars: 1, count: 0, percent: 0 },
  ],
};

/**
 * Reviews page body. Server-side fetch from the data layer happens in the
 * page.tsx (for the summary stats), but this client component owns the
 * filters, sort, write-a-review modal, and "load more" pagination.
 */
export function ReviewsPage() {
  const prefersReduced = useReducedMotion();
  const addToast = useToastStore((s) => s.addToast);

  const [rating, setRating] = React.useState<RatingFilter>(0);
  const [verifiedOnly, setVerifiedOnly] = React.useState(false);
  const [sort, setSort] = React.useState<SortKey>("newest");
  const [visible, setVisible] = React.useState(PAGE_SIZE);
  const [modalOpen, setModalOpen] = React.useState(false);

  // Reset pagination when filters change.
  React.useEffect(() => {
    setVisible(PAGE_SIZE);
  }, [rating, verifiedOnly, sort]);

  const filtered = React.useMemo(() => {
    let list = [...allReviews];
    if (rating > 0) list = list.filter((r) => r.rating === rating);
    if (verifiedOnly) list = list.filter((r) => r.verified);
    if (sort === "newest") {
      list.sort(
        (a, b) =>
          new Date(b.date).getTime() - new Date(a.date).getTime()
      );
    } else if (sort === "highest") {
      list.sort((a, b) => b.rating - a.rating);
    } else {
      list.sort((a, b) => a.rating - b.rating);
    }
    return list;
  }, [rating, verifiedOnly, sort]);

  const visibleReviews = filtered.slice(0, visible);
  const hasMore = visible < filtered.length;

  // Lock body scroll while modal is open.
  React.useEffect(() => {
    if (!modalOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setModalOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [modalOpen]);

  const handleSubmitted = (title: string) => {
    setModalOpen(false);
    addToast({
      title: "Review submitted",
      description: `"${title}" is now in the moderation queue.`,
      variant: "success",
    });
  };

  return (
    <div>
      {/* Summary */}
      <div className="grid gap-6 lg:grid-cols-[1fr_2fr]">
        <div className="rounded-2xl border border-border bg-card p-6 lg:p-8">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Verified buyers
          </p>
          <div className="mt-3 flex items-end gap-3">
            <span className="text-5xl font-black tracking-tight text-foreground">
              {SUMMARY.average.toFixed(1)}
            </span>
            <span className="pb-1.5 text-sm text-muted-foreground">
              out of 5
            </span>
          </div>
          <StarRating rating={SUMMARY.average} size={18} className="mt-2" />
          <p className="mt-3 text-sm text-muted-foreground">
            Based on {SUMMARY.total} verified site reviews across the catalog.
            Members also submit product-specific reviews visible on each PDP.
          </p>
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            className="btn-shine mt-5 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
          >
            <PenLine className="h-4 w-4" aria-hidden />
            Write a review
          </button>
        </div>
        <div className="rounded-2xl border border-border bg-card p-6 lg:p-8">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Rating distribution
          </p>
          <ul className="mt-4 space-y-3">
            {SUMMARY.distribution.map((d) => (
              <li
                key={d.stars}
                className="flex items-center gap-3"
              >
                <span className="inline-flex w-12 items-center gap-1 text-xs text-muted-foreground">
                  {d.stars}
                  <Star className="h-3 w-3 fill-primary text-primary" aria-hidden />
                </span>
                <div
                  className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-muted"
                  role="progressbar"
                  aria-valuenow={d.percent}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-label={`${d.stars} star rating: ${d.percent}%`}
                >
                  <motion.div
                    className="absolute inset-y-0 left-0 rounded-full bg-primary"
                    initial={{ width: 0 }}
                    whileInView={{ width: `${d.percent}%` }}
                    viewport={{ once: true }}
                    transition={{
                      duration: prefersReduced ? 0.01 : 0.8,
                      ease: [0.25, 0.4, 0.25, 1],
                    }}
                  />
                </div>
                <span className="w-10 text-right text-xs tabular-nums text-muted-foreground">
                  {d.count}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Filters + sort */}
      <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" aria-hidden />
          <button
            type="button"
            onClick={() => setRating(0)}
            aria-pressed={rating === 0}
            className={cn(
              "inline-flex h-8 items-center gap-1 rounded-full border px-3 text-xs font-mono uppercase tracking-wider transition-colors",
              rating === 0
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground"
            )}
          >
            All
          </button>
          {[5, 4, 3, 2, 1].map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRating(r as RatingFilter)}
              aria-pressed={rating === r}
              className={cn(
                "inline-flex h-8 items-center gap-1 rounded-full border px-3 text-xs font-mono uppercase tracking-wider transition-colors",
                rating === r
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground"
              )}
            >
              {r}
              <Star
                className="h-3 w-3 fill-current"
                aria-hidden
              />
            </button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <label className="inline-flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
            <button
              type="button"
              role="switch"
              aria-checked={verifiedOnly}
              onClick={() => setVerifiedOnly((v) => !v)}
              className={cn(
                "relative inline-flex h-5 w-9 items-center rounded-full border transition-colors",
                verifiedOnly
                  ? "border-primary bg-primary/30"
                  : "border-border bg-muted"
              )}
            >
              <span
                className={cn(
                  "inline-block h-3.5 w-3.5 transform rounded-full bg-foreground transition-transform",
                  verifiedOnly ? "translate-x-4" : "translate-x-0.5"
                )}
              />
            </button>
            Verified only
          </label>
          <div className="inline-flex items-center gap-2">
            <label htmlFor="sort" className="text-xs text-muted-foreground">
              Sort
            </label>
            <select
              id="sort"
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              className="h-9 rounded-md border border-border bg-card px-3 text-xs font-medium text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <option value="newest">Newest</option>
              <option value="highest">Highest</option>
              <option value="lowest">Lowest</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid */}
      {visibleReviews.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-border bg-card p-12 text-center">
          <p className="text-sm text-muted-foreground">
            No reviews match your filters. Try a different combination.
          </p>
        </div>
      ) : (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {visibleReviews.map((r, i) => (
            <ReviewCard key={r.id} review={r} index={i} />
          ))}
        </div>
      )}

      {/* Load more */}
      {hasMore && (
        <div className="mt-10 flex justify-center">
          <button
            type="button"
            onClick={() => setVisible((v) => v + PAGE_SIZE)}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-border bg-transparent px-6 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:bg-card"
          >
            Load more reviews
            <span className="text-xs text-muted-foreground">
              ({filtered.length - visible} remaining)
            </span>
          </button>
        </div>
      )}

      {/* Modal */}
      <AnimatePresence>
        {modalOpen && (
          <WriteReviewModal
            onClose={() => setModalOpen(false)}
            onSubmit={handleSubmitted}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function ReviewCard({ review, index }: { review: Review; index: number }) {
  const prefersReduced = useReducedMotion();
  const date = new Date(review.date);
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{
        duration: 0.5,
        delay: prefersReduced ? 0 : Math.min(index * 0.05, 0.3),
        ease: [0.25, 0.4, 0.25, 1],
      }}
      className="flex h-full flex-col rounded-2xl border border-border bg-card p-6"
    >
      <div className="flex items-center gap-3">
        <Image
          src={review.avatar}
          alt={review.author}
          width={44}
          height={44}
          className="h-11 w-11 rounded-full border border-border object-cover"
        />
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1.5 text-sm font-bold text-foreground">
            {review.author}
            {review.verified && (
              <BadgeCheck className="h-4 w-4 text-primary" aria-hidden />
            )}
          </p>
          <p className="text-[11px] text-muted-foreground">
            {date.toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </p>
        </div>
      </div>
      <div className="mt-3">
        <StarRating rating={review.rating} size={14} />
      </div>
      <h3 className="mt-3 text-base font-bold tracking-tight text-foreground">
        {review.title}
      </h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
        {review.body}
      </p>
      <div className="mt-4 flex items-center justify-between border-t border-border pt-3">
        <Link
          href={`/product/${review.productSlug}`}
          className="text-xs font-medium text-primary hover:underline"
        >
          {review.productName}
        </Link>
        {review.verified && (
          <span className="inline-flex items-center gap-1 rounded-full border border-success/30 bg-success/10 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-success">
            <Check className="h-3 w-3" aria-hidden />
            Verified buyer
          </span>
        )}
      </div>
    </motion.article>
  );
}

interface WriteReviewModalProps {
  onClose: () => void;
  onSubmit: (title: string) => void;
}

function WriteReviewModal({ onClose, onSubmit }: WriteReviewModalProps) {
  const [productSlug, setProductSlug] = React.useState("");
  const [rating, setRating] = React.useState(0);
  const [hoverRating, setHoverRating] = React.useState(0);
  const [title, setTitle] = React.useState("");
  const [body, setBody] = React.useState("");
  const [name, setName] = React.useState("");
  const [errors, setErrors] = React.useState<Record<string, string>>({});

  const validate = () => {
    const next: Record<string, string> = {};
    if (!productSlug) next.productSlug = "Please select a product.";
    if (rating < 1 || rating > 5) next.rating = "Pick a rating from 1 to 5.";
    if (title.trim().length < 4)
      next.title = "Title must be at least 4 characters.";
    if (body.trim().length < 20)
      next.body = "Review must be at least 20 characters.";
    if (name.trim().length < 2) next.name = "Enter your name.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    onSubmit(title.trim());
    setProductSlug("");
    setRating(0);
    setTitle("");
    setBody("");
    setName("");
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 z-[100] flex items-end justify-center bg-background/80 backdrop-blur-sm sm:items-center"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Write a review"
    >
      <motion.div
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 40, opacity: 0 }}
        transition={{ duration: 0.3, ease: [0.25, 0.4, 0.25, 1] }}
        className="relative flex max-h-[92vh] w-full max-w-2xl flex-col overflow-hidden rounded-t-2xl border border-border bg-card sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border p-5">
          <div>
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              Share your experience
            </p>
            <h2 className="mt-1 text-xl font-black tracking-tight text-foreground">
              Write a review
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-background text-foreground transition-colors hover:border-primary/50 hover:text-primary"
          >
            <X className="h-4 w-4" aria-hidden />
          </button>
        </div>
        <form
          onSubmit={handleSubmit}
          className="flex-1 space-y-4 overflow-y-auto p-5"
        >
          {/* Product */}
          <div>
            <label
              htmlFor="rv-product"
              className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
            >
              Product
            </label>
            <select
              id="rv-product"
              value={productSlug}
              onChange={(e) => setProductSlug(e.target.value)}
              className="mt-1.5 h-11 w-full rounded-md border border-border bg-background px-3 text-sm text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            >
              <option value="">Select a product</option>
              {products.map((p) => (
                <option key={p.slug} value={p.slug}>
                  {p.name} — {p.category}
                </option>
              ))}
            </select>
            {errors.productSlug && (
              <p className="mt-1 text-xs text-destructive">
                {errors.productSlug}
              </p>
            )}
          </div>

          {/* Rating */}
          <div>
            <span className="block text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Rating
            </span>
            <div className="mt-1.5 flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRating(r)}
                  onMouseEnter={() => setHoverRating(r)}
                  onMouseLeave={() => setHoverRating(0)}
                  aria-label={`Set rating to ${r}`}
                  aria-pressed={rating === r}
                  className="rounded p-1 transition-transform hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                >
                  <Star
                    className={cn(
                      "h-7 w-7 transition-colors",
                      (hoverRating || rating) >= r
                        ? "fill-primary text-primary"
                        : "fill-transparent text-muted-foreground"
                    )}
                    aria-hidden
                  />
                </button>
              ))}
              <span className="ml-2 text-sm text-muted-foreground">
                {rating > 0 ? `${rating} of 5` : "Pick a rating"}
              </span>
            </div>
            {errors.rating && (
              <p className="mt-1 text-xs text-destructive">{errors.rating}</p>
            )}
          </div>

          {/* Title */}
          <div>
            <label
              htmlFor="rv-title"
              className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
            >
              Review title
            </label>
            <input
              id="rv-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={80}
              placeholder="Sum up your experience in a line"
              className="mt-1.5 h-11 w-full rounded-md border border-border bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            />
            {errors.title && (
              <p className="mt-1 text-xs text-destructive">{errors.title}</p>
            )}
          </div>

          {/* Body */}
          <div>
            <label
              htmlFor="rv-body"
              className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
            >
              Review
            </label>
            <textarea
              id="rv-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={4}
              maxLength={800}
              placeholder="What did you think of the fit, fabric, and finish? Would you recommend it?"
              className="mt-1.5 w-full rounded-md border border-border bg-background p-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            />
            <p className="mt-1 text-right text-[11px] text-muted-foreground">
              {body.length} / 800
            </p>
            {errors.body && (
              <p className="mt-1 text-xs text-destructive">{errors.body}</p>
            )}
          </div>

          {/* Name */}
          <div>
            <label
              htmlFor="rv-name"
              className="block text-xs font-medium uppercase tracking-wider text-muted-foreground"
            >
              Your name
            </label>
            <input
              id="rv-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={60}
              placeholder="Displayed publicly with your review"
              className="mt-1.5 h-11 w-full rounded-md border border-border bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
            />
            {errors.name && (
              <p className="mt-1 text-xs text-destructive">{errors.name}</p>
            )}
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-border pt-4">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-11 items-center justify-center rounded-md border border-border bg-transparent px-5 text-sm font-semibold text-foreground transition-colors hover:bg-card"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              <CheckCircle2 className="h-4 w-4" aria-hidden />
              Submit review
            </button>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Reviews are moderated within 24 hours. We only publish reviews from
            verified buyers.
          </p>
        </form>
      </motion.div>
    </motion.div>
  );
}
