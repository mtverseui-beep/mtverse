"use client";

import * as React from "react";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, HelpCircle, Search, Sparkles } from "lucide-react";
import { faqs, faqCategories } from "@/data/faqs";
import { cn } from "@/lib/utils";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

/**
 * FAQ page body. Owns the search input, category filter chips, and the
 * accordion list grouped by category.
 */
export function FaqPage() {
  const prefersReduced = useReducedMotion();
  const [query, setQuery] = React.useState("");
  const [category, setCategory] = React.useState<string>("All");

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return faqs.filter((f) => {
      if (category !== "All" && f.category !== category) return false;
      if (!q) return true;
      return (
        f.question.toLowerCase().includes(q) ||
        f.answer.toLowerCase().includes(q)
      );
    });
  }, [query, category]);

  // Group filtered FAQs by category for display.
  const grouped = React.useMemo(() => {
    const map = new Map<string, typeof faqs>();
    filtered.forEach((f) => {
      const list = map.get(f.category) ?? [];
      list.push(f);
      map.set(f.category, list);
    });
    return faqCategories
      .map((c) => ({ category: c, items: map.get(c) ?? [] }))
      .filter((g) => g.items.length > 0);
  }, [filtered]);

  return (
    <div>
      {/* Search */}
      <div className="relative mx-auto max-w-2xl">
        <Search
          className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground"
          aria-hidden
        />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search all FAQs"
          aria-label="Search all FAQs"
          className="h-14 w-full rounded-full border border-border bg-card pl-12 pr-4 text-base text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
        />
      </div>

      {/* Category filter chips */}
      <div
        className="no-scrollbar -mx-4 mt-6 flex items-center gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0"
        role="tablist"
        aria-label="Filter FAQs by category"
      >
        <button
          type="button"
          role="tab"
          aria-selected={category === "All"}
          onClick={() => setCategory("All")}
          className={cn(
            "inline-flex h-9 shrink-0 items-center rounded-full border px-4 text-xs font-mono uppercase tracking-wider transition-colors",
            category === "All"
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground"
          )}
        >
          All
        </button>
        {faqCategories.map((c) => (
          <button
            key={c}
            type="button"
            role="tab"
            aria-selected={category === c}
            onClick={() => setCategory(c)}
            className={cn(
              "inline-flex h-9 shrink-0 items-center rounded-full border px-4 text-xs font-mono uppercase tracking-wider transition-colors",
              category === c
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground"
            )}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Grouped accordions */}
      <div className="mt-10 space-y-10">
        {grouped.length === 0 ? (
          <div className="rounded-2xl border border-border bg-card p-12 text-center">
            <HelpCircle
              className="mx-auto h-8 w-8 text-muted-foreground"
              aria-hidden
            />
            <p className="mt-4 text-sm text-muted-foreground">
              No FAQs match your search. Try a different keyword, or{" "}
              <Link
                href="/contact"
                className="font-medium text-primary hover:underline"
              >
                contact support
              </Link>
              .
            </p>
          </div>
        ) : (
          grouped.map((g, i) => (
            <motion.section
              key={g.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{
                duration: 0.5,
                delay: prefersReduced ? 0 : Math.min(i * 0.05, 0.3),
                ease: [0.25, 0.4, 0.25, 1],
              }}
            >
              <div className="flex items-center gap-3">
                <Sparkles className="h-4 w-4 text-primary" aria-hidden />
                <h2 className="text-xl font-black tracking-tight text-foreground sm:text-2xl">
                  {g.category}
                </h2>
                <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  {g.items.length}{" "}
                  {g.items.length === 1 ? "question" : "questions"}
                </span>
              </div>
              <div className="mt-4 rounded-2xl border border-border bg-card p-4 sm:p-6">
                <Accordion
                  type="single"
                  collapsible
                  className="w-full"
                >
                  {g.items.map((f) => (
                    <AccordionItem
                      key={f.id}
                      value={f.id}
                      className="border-b border-border last:border-b-0"
                    >
                      <AccordionTrigger className="text-left text-base font-semibold text-foreground hover:no-underline">
                        {f.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                        {f.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </motion.section>
          ))
        )}
      </div>

      {/* CTA */}
      <div className="mt-12 rounded-3xl border border-border bg-card p-8 sm:p-10">
        <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="max-w-xl">
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              Still have questions?
            </p>
            <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
              We answer every email
            </h2>
            <p className="mt-3 text-sm text-muted-foreground">
              If you cannot find what you need here, contact support and we
              will get back to you inside one business day, Mon–Fri 9–6 CET.
            </p>
          </div>
          <Link
            href="/contact"
            className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Contact support
            <ArrowRight className="h-4 w-4" aria-hidden />
          </Link>
        </div>
      </div>
    </div>
  );
}
