"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  ArrowLeft,
  Clock,
  Link2,
  Mail,
  Tag,
} from "lucide-react";
import type { BlogPost, Product } from "@/types";
import { cn } from "@/lib/utils";
import { useToastStore } from "@/store/toast-store";

interface BlogArticleProps {
  post: BlogPost;
  relatedProducts: Product[];
  relatedPosts: BlogPost[];
}

/**
 * Client-rendered blog article body. Receives the post, related products,
 * and related posts from the server page. Owns the share buttons, the
 * inline newsletter signup, and the article body rendering.
 */
export function BlogArticle({
  post,
  relatedProducts,
  relatedPosts,
}: BlogArticleProps) {
  const prefersReduced = useReducedMotion();
  const addToast = useToastStore((s) => s.addToast);
  const [email, setEmail] = React.useState("");
  const [subscribed, setSubscribed] = React.useState(false);

  const date = new Date(post.publishedAt);

  const paragraphs = React.useMemo(
    () => post.body.split("\n\n").filter(Boolean),
    [post.body]
  );

  const handleShare = async (kind: "twitter" | "facebook" | "copy") => {
    const url =
      typeof window !== "undefined"
        ? window.location.href
        : `https://volthaus.co/blog/${post.slug}`;
    if (kind === "copy") {
      try {
        await navigator.clipboard.writeText(url);
        addToast({
          title: "Link copied",
          description: "Paste it anywhere to share the article.",
          variant: "success",
        });
      } catch {
        addToast({
          title: "Could not copy",
          description: "Copy the URL from the address bar instead.",
          variant: "error",
        });
      }
      return;
    }
    addToast({
      title:
        kind === "twitter" ? "Opening X (Twitter)" : "Opening Facebook",
      description: "Share dialog opening in a new tab.",
      variant: "default",
    });
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      addToast({
        title: "Enter a valid email",
        variant: "error",
      });
      return;
    }
    setSubscribed(true);
    addToast({
      title: "Subscribed to the journal",
      description: "Check your inbox to confirm.",
      variant: "success",
    });
    setEmail("");
  };

  return (
    <div className="pb-16">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="relative h-[44vh] min-h-[320px] w-full sm:h-[60vh]">
          <Image
            src={post.cover}
            alt={post.title}
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/55 to-background/10" />
        </div>
        <div className="container mx-auto max-w-4xl px-4 pb-10 sm:px-6 lg:px-8 lg:pb-14">
          <div className="relative -mt-24 sm:-mt-32">
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center rounded-full border border-primary/40 bg-primary/15 px-3 py-1 font-mono uppercase tracking-wider text-primary">
                {post.category}
              </span>
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" aria-hidden />
                {post.readTime}
              </span>
              <span>
                {date.toLocaleDateString("en-US", {
                  month: "long",
                  day: "numeric",
                  year: "numeric",
                })}
              </span>
            </div>
            <h1 className="mt-4 text-balance text-3xl font-black leading-[1.1] tracking-tight text-foreground sm:text-4xl lg:text-5xl">
              {post.title}
            </h1>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg">
              {post.excerpt}
            </p>
          </div>
        </div>
      </section>

      {/* Author bar */}
      <section className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border py-6">
          <div className="flex items-center gap-3">
            <Image
              src={post.authorAvatar}
              alt={post.author}
              width={44}
              height={44}
              className="h-11 w-11 rounded-full border border-border object-cover"
            />
            <div>
              <p className="text-sm font-bold text-foreground">{post.author}</p>
              <p className="text-xs text-muted-foreground">
                VoltHaus Journal · {date.toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleShare("twitter")}
              className="inline-flex h-9 items-center justify-center gap-1.5 rounded-full border border-border bg-background px-3 text-xs font-medium text-foreground transition-colors hover:border-primary/50 hover:text-primary"
              aria-label="Share on X (Twitter)"
            >
              <span aria-hidden>X</span>
            </button>
            <button
              type="button"
              onClick={() => handleShare("facebook")}
              className="inline-flex h-9 items-center justify-center gap-1.5 rounded-full border border-border bg-background px-3 text-xs font-medium text-foreground transition-colors hover:border-primary/50 hover:text-primary"
              aria-label="Share on Facebook"
            >
              <span aria-hidden>f</span>
            </button>
            <button
              type="button"
              onClick={() => handleShare("copy")}
              className="inline-flex h-9 items-center justify-center gap-1.5 rounded-full border border-border bg-background px-3 text-xs font-medium text-foreground transition-colors hover:border-primary/50 hover:text-primary"
              aria-label="Copy link"
            >
              <Link2 className="h-3.5 w-3.5" aria-hidden />
              Copy link
            </button>
          </div>
        </div>
      </section>

      {/* Body */}
      <article className="container mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
        <div className="space-y-6">
          {paragraphs.map((p, i) => (
            <motion.p
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{
                duration: 0.5,
                delay: prefersReduced ? 0 : Math.min(i * 0.04, 0.2),
                ease: [0.25, 0.4, 0.25, 1],
              }}
              className="text-base leading-relaxed text-foreground/90 sm:text-lg"
            >
              {p}
            </motion.p>
          ))}
        </div>

        {/* Tags */}
        <div className="mt-10 flex flex-wrap items-center gap-2 border-t border-border pt-6">
          <Tag className="h-4 w-4 text-muted-foreground" aria-hidden />
          {post.tags.map((tag) => (
            <Link
              key={tag}
              href={`/blog`}
              className="inline-flex items-center rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
            >
              #{tag}
            </Link>
          ))}
        </div>
      </article>

      {/* Author bio box */}
      <section className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-6 sm:flex-row sm:items-center sm:gap-6">
          <Image
            src={post.authorAvatar}
            alt={post.author}
            width={64}
            height={64}
            className="h-16 w-16 rounded-full border border-border object-cover"
          />
          <div className="flex-1">
            <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
              Written by
            </p>
            <p className="mt-1 text-lg font-bold text-foreground">
              {post.author}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              Contributor to the VoltHaus Journal covering{" "}
              {post.category.toLowerCase()} and the wider VoltHaus program.
            </p>
          </div>
          <Link
            href="/blog"
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-border bg-background px-4 text-xs font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary"
          >
            More from {post.author.split(" ")[0]}
            <ArrowRight className="h-3.5 w-3.5" aria-hidden />
          </Link>
        </div>
      </section>

      {/* Related products */}
      {relatedProducts.length > 0 && (
        <section className="container mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
          <div className="mb-6 flex items-end justify-between">
            <div>
              <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
                Mentioned in this article
              </p>
              <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
                Related products
              </h2>
            </div>
            <Link
              href="/shop"
              className="text-sm font-medium text-primary hover:underline"
            >
              Shop all
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {relatedProducts.map((p, i) => (
              <motion.article
                key={p.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{
                  duration: 0.5,
                  delay: prefersReduced ? 0 : Math.min(i * 0.05, 0.3),
                  ease: [0.25, 0.4, 0.25, 1],
                }}
                className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40"
              >
                <Link
                  href={`/product/${p.slug}`}
                  className="relative block aspect-square overflow-hidden bg-muted"
                  aria-label={`View ${p.name}`}
                >
                  <Image
                    src={p.images[0]}
                    alt={p.name}
                    fill
                    sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
                    className={cn(
                      "object-cover transition-transform duration-700 ease-out",
                      !prefersReduced && "group-hover:scale-105"
                    )}
                  />
                </Link>
                <div className="flex flex-1 flex-col gap-1 p-4">
                  <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
                    {p.category}
                  </span>
                  <h3 className="text-sm font-bold tracking-tight text-foreground">
                    <Link
                      href={`/product/${p.slug}`}
                      className="transition-colors hover:text-primary"
                    >
                      {p.name}
                    </Link>
                  </h3>
                  <p className="text-sm font-semibold text-foreground">
                    ${p.price}
                  </p>
                </div>
              </motion.article>
            ))}
          </div>
        </section>
      )}

      {/* Related articles */}
      {relatedPosts.length > 0 && (
        <section className="container mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8 lg:pb-16">
          <p className="text-xs font-mono uppercase tracking-[0.22em] text-primary">
            Keep reading
          </p>
          <h2 className="mt-2 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
            Related articles
          </h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {relatedPosts.map((p, i) => (
              <motion.article
                key={p.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{
                  duration: 0.5,
                  delay: prefersReduced ? 0 : i * 0.08,
                  ease: [0.25, 0.4, 0.25, 1],
                }}
                className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/40"
              >
                <Link
                  href={`/blog/${p.slug}`}
                  className="relative block aspect-[16/10] overflow-hidden bg-muted"
                  aria-label={`Read ${p.title}`}
                >
                  <Image
                    src={p.cover}
                    alt={p.title}
                    fill
                    sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                    className={cn(
                      "object-cover transition-transform duration-700 ease-out",
                      !prefersReduced && "group-hover:scale-105"
                    )}
                  />
                  <span className="absolute left-3 top-3 inline-flex items-center rounded-full border border-border bg-background/70 px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-wider text-primary backdrop-blur">
                    {p.category}
                  </span>
                </Link>
                <div className="flex flex-1 flex-col p-5">
                  <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                    <Clock className="h-3 w-3" aria-hidden />
                    {p.readTime}
                  </div>
                  <h3 className="mt-2 text-base font-bold tracking-tight text-foreground">
                    <Link
                      href={`/blog/${p.slug}`}
                      className="transition-colors hover:text-primary"
                    >
                      {p.title}
                    </Link>
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                    {p.excerpt}
                  </p>
                </div>
              </motion.article>
            ))}
          </div>
        </section>
      )}

      {/* Inline newsletter */}
      <section className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl border border-border bg-card p-8 sm:p-10">
          <div
            aria-hidden
            className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-primary/15 blur-3xl"
          />
          <div className="relative">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-[0.22em] text-primary">
              <Mail className="h-4 w-4" aria-hidden />
              The journal in your inbox
            </div>
            <h2 className="mt-3 text-2xl font-black tracking-tight text-foreground sm:text-3xl">
              Get one article a week, no fluff
            </h2>
            <p className="mt-3 text-sm text-muted-foreground">
              We publish a single long-form piece each week. Subscribers get it
              the morning it goes live. No marketing, no sales pushes — just
              the writing.
            </p>
            {subscribed ? (
              <div className="mt-6 flex items-center gap-3 rounded-md border border-success/30 bg-success/10 px-4 py-3 text-sm text-success">
                <span aria-hidden>✓</span>
                You are subscribed. Check your inbox to confirm.
              </div>
            ) : (
              <form
                onSubmit={handleSubscribe}
                className="mt-6 flex flex-col gap-2 sm:flex-row"
              >
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@street.com"
                  className="h-11 flex-1 rounded-md border border-border bg-background px-4 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                  aria-label="Email address"
                />
                <button
                  type="submit"
                  className="btn-shine inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
                >
                  Subscribe
                  <ArrowRight className="h-4 w-4" aria-hidden />
                </button>
              </form>
            )}
            <Link
              href="/blog"
              className="mt-5 inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              <ArrowLeft className="h-3 w-3" aria-hidden />
              Back to the journal
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
