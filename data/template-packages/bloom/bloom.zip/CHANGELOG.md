# Changelog

All notable changes to Bloom will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] — 2026-08-01

### Added

- **Overview route (`/`)** — full-bleed pannable/zoomable org chart built on `@visx/hierarchy` + `d3-hierarchy`, with curved bezier connectors, per-node collapse/expand, dot-grid canvas, coral radial glow behind the CEO node, inertial pan momentum, cursor-anchored scroll-zoom, and pinch-zoom on touch.
- **Hiring route (`/hiring`)** — `@dnd-kit` kanban (Applied / Screening / Interview / Offer / Hired), draggable candidate cards with avatar + role + days-in-stage, keyboard-accessible alternative (Tab → Space → Arrow keys → Space), live column counts, Offer-stage confirmation popover, and a validated add-candidate dialog (`react-hook-form` + `zod`).
- **People route (`/people`)** — directory table with Radix `Select` filters (department, status, location), search-as-you-type, multi-column sort with directional indicators, inline row expand (contact info + reporting-line breadcrumb + flight-risk breakdown), bulk-select with action bar (Export, Tag), and real pagination.
- **Attrition route (`/attrition`)** — animated count-up on hero figures using `tabular-nums` to prevent digit jitter, period toggle (This quarter / This year / Trailing 12mo), Recharts trend area chart, reasons breakdown bar chart, department comparison table with proportional bars, and Framer Motion scroll-reveal stagger.
- **Reviews route (`/reviews`)** — active/upcoming/completed cycle sections, expandable cycle cards with per-participant completion progress (color-coded: mint done / amber in-progress / tertiary not-started), and a request-review dialog with reviewer Combobox (Radix Popover + cmdk-style list) + Radix Calendar date picker.
- **Settings route (`/settings`)** — Profile (name, email, title, bio), Notifications (5 real Switch toggles), Appearance (light/dark theme cards + density Select), and an About section. All controls are wired to visible state changes.
- **Person detail panel** — right-side sliding panel (not a modal — the chart/table stays visible behind it), with 96px avatar, Fraunces display name, status badge, and Overview / Reviews / Notes tabs. Shared across Overview, People, and Hiring via `PersonPanelHost`.
- **⌘K command palette** — fuzzy search across all 54 employees + 8 quick navigation actions, full keyboard navigation (ArrowUp / ArrowDown / Enter / Escape), accessible combobox semantics.
- **Collapsible sidebar** — 260px expanded / 76px icon-only, persisted via `useLocalStorageBoolean` (built on `useSyncExternalStore`, no setState-in-effect), mobile drawer with focus trap and Escape-to-close.
- **Sticky header** — global search trigger, notifications Popover with unread badge, theme toggle (animated sun ↔ moon crossfade), profile menu. Glass effect on scroll.
- **Light + dark themes** — warm cream `#FFF8F0` + coral `#F0674F` in light, deep plum `#211621` + brightened coral `#FF9585` in dark. Zero flash via `next-themes`. Persisted.
- **On-brand 404** — organic sprout illustration, warm copy, link back to Overview.
- **Typed demo dataset** — 54 employees forming a valid single-root, cycle-free org tree (validated at module load with a clear error if a future edit breaks the invariant), 24 candidates in a funnel-shaped distribution, 18 months of attrition trend data, 6 weighted attrition reasons, 6 department attrition comparisons, 4 review cycles, 5 notes, 5 review entries.
- **Accessibility** — WCAG AA contrast verified for the coral accent in small-text and interactive contexts, full keyboard navigation throughout, visible focus rings (warm coral), `prefers-reduced-motion` simplifies org-chart momentum and scroll-reveal animations, every icon-only button has an `aria-label`, semantic HTML throughout.
- **README, LICENSE, CHANGELOG** — accurate feature list verified against the actual repo, clear personal/commercial license terms.

### Tech stack

- Next.js 16 (App Router, Turbopack)
- TypeScript 5 (strict)
- Tailwind CSS v4 with custom `@theme inline` design tokens
- shadcn/ui (New York) + Radix primitives
- Framer Motion
- @visx/hierarchy + d3-hierarchy
- Recharts
- @dnd-kit/core + @dnd-kit/sortable
- react-hook-form + zod
- next-themes
- lucide-react
- cmdk

### Quality

- `eslint .` passes clean with no weakened rules.
- `tsc --noEmit` passes for all Bloom code (excludes pre-existing scaffold demo files in `examples/` and `skills/`).
- Every dependency in `package.json` is actually imported and rendered.
- `reactStrictMode: true`.
