"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import type { AttritionReason } from "@/data/demo";

const PALETTE = [
  "var(--accent-coral)",
  "var(--status-brick)",
  "var(--status-amber)",
  "var(--status-lavender)",
  "var(--accent-mint)",
  "var(--text-secondary)",
];

/** Reasons breakdown — horizontal bars, ranked. */
export default function ReasonsChart({
  data,
}: {
  data: AttritionReason[];
}) {
  const sorted = [...data].sort((a, b) => b.count - a.count);
  return (
    <div className="h-[260px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={sorted}
          layout="vertical"
          margin={{ top: 0, right: 8, left: 0, bottom: 0 }}
          barCategoryGap={6}
        >
          <XAxis
            type="number"
            tick={{ fill: "var(--text-tertiary)", fontSize: 11, fontFamily: "var(--font-geist-mono)" }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v: number) => `${v}`}
          />
          <YAxis
            type="category"
            dataKey="reason"
            tick={{ fill: "var(--text-secondary)", fontSize: 11, fontFamily: "var(--font-jakarta)" }}
            tickLine={false}
            axisLine={false}
            width={110}
          />
          <Tooltip
            cursor={{ fill: "var(--surface-alt)", opacity: 0.5 }}
            contentStyle={{
              background: "var(--surface)",
              border: "1px solid var(--border-default)",
              borderRadius: "12px",
              boxShadow: "var(--shadow-md)",
              fontSize: "0.8125rem",
              color: "var(--text-primary)",
            }}
            formatter={(value: number, _name, entry) => {
              const pct = (entry?.payload as AttritionReason)?.pct;
              return [`${value} departures (${pct}%)`, "Count"];
            }}
          />
          <Bar dataKey="count" radius={[0, 4, 4, 0]}>
            {sorted.map((_, i) => (
              <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
