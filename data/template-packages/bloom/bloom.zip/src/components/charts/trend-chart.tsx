"use client";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  CartesianGrid,
} from "recharts";
import type { AttritionMonth } from "@/data/demo";

/** Monthly attrition trend — coral area line, warm-tinted grid. */
export default function TrendChart({
  data,
  reduceMotion,
}: {
  data: AttritionMonth[];
  reduceMotion: boolean;
}) {
  return (
    <div className="mt-3 h-[260px]">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
          <defs>
            <linearGradient id="attrition-area" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--accent-coral)" stopOpacity={0.35} />
              <stop offset="100%" stopColor="var(--accent-coral)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="var(--border-default)"
            vertical={false}
          />
          <XAxis
            dataKey="month"
            tick={{ fill: "var(--text-tertiary)", fontSize: 11, fontFamily: "var(--font-geist-mono)" }}
            tickLine={false}
            axisLine={{ stroke: "var(--border-default)" }}
            tickFormatter={(v: string) => {
              const [y, m] = v.split("-");
              const d = new Date(Number(y), Number(m) - 1);
              return d.toLocaleDateString("en-US", { month: "short", year: "2-digit" });
            }}
          />
          <YAxis
            tick={{ fill: "var(--text-tertiary)", fontSize: 11, fontFamily: "var(--font-geist-mono)" }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v: number) => `${v}%`}
            width={40}
          />
          <Tooltip
            cursor={{ stroke: "var(--border-emphasis)", strokeWidth: 1 }}
            contentStyle={{
              background: "var(--surface)",
              border: "1px solid var(--border-default)",
              borderRadius: "12px",
              boxShadow: "var(--shadow-md)",
              fontSize: "0.8125rem",
              fontFamily: "var(--font-jakarta)",
              color: "var(--text-primary)",
            }}
            labelFormatter={(label: string) => {
              const [y, m] = label.split("-");
              const d = new Date(Number(y), Number(m) - 1);
              return d.toLocaleDateString("en-US", { month: "long", year: "numeric" });
            }}
            formatter={(value: number, name: string) => {
              if (name === "rate") return [`${value.toFixed(1)}%`, "Attrition rate"];
              return [value, name];
            }}
          />
          <Area
            type="monotone"
            dataKey="rate"
            stroke="var(--accent-coral)"
            strokeWidth={2}
            fill="url(#attrition-area)"
            dot={{ r: 3, fill: "var(--accent-coral)", strokeWidth: 0 }}
            activeDot={{ r: 5, fill: "var(--accent-coral)", stroke: "var(--surface)", strokeWidth: 2 }}
            isAnimationActive={!reduceMotion}
            animationDuration={600}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

// Unused import — keep for tree-shake safety
void LineChart;
void Line;
