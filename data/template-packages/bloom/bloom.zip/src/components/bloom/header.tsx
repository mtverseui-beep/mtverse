"use client";

import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Bell,
  Menu,
  Command,
  CornerDownLeft,
  ArrowRight,
  User,
  Settings,
  LogOut,
  ChevronDown,
  Moon,
  Sun,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { Avatar } from "./avatar";
import { ThemeToggle } from "./theme-toggle";
import { employees, candidates, type Employee } from "@/data/demo";
import { brand } from "@/config/brand";
import { useTheme } from "next-themes";
import { toast } from "@/hooks/use-toast";

/** Sticky top bar — global search, ⌘K command palette, notifications, theme, profile. */
export function Header({ onOpenMobileNav }: { onOpenMobileNav: () => void }) {
  const router = useRouter();
  const [scrolled, setScrolled] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [unreadNotifs, setUnreadNotifs] = useState(3);

  // Glass effect on scroll — listens to the <main> scroll container, not window,
  // because the body never scrolls in the enterprise layout (AppShell uses
  // h-screen overflow-hidden and main is the only scroll container).
  useEffect(() => {
    const main = document.querySelector("main");
    if (!main) return;
    const onScroll = () => setScrolled(main.scrollTop > 8);
    onScroll();
    main.addEventListener("scroll", onScroll, { passive: true });
    return () => main.removeEventListener("scroll", onScroll);
  }, []);

  // ⌘K opens the command palette
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const go = useCallback(
    (path: string) => {
      setPaletteOpen(false);
      router.push(path);
    },
    [router]
  );

  return (
    <header
      className={cn(
        "shrink-0 z-30 h-16 transition-all duration-200",
        scrolled
          ? "border-b border-[var(--border-default)] bg-[var(--bg-base)]/85 backdrop-blur-md"
          : "border-b border-[var(--border-default)] bg-[var(--bg-base)]"
      )}
    >
      <div className="flex h-full items-center gap-3 px-4 sm:px-6">
        <button
          onClick={onOpenMobileNav}
          aria-label="Open navigation"
          className="md:hidden inline-flex h-9 w-9 items-center justify-center rounded-[8px] text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] cursor-pointer"
        >
          <Menu className="h-5 w-5" strokeWidth={1.5} />
        </button>

        {/* Search trigger */}
        <button
          onClick={() => setPaletteOpen(true)}
          className={cn(
            "group flex h-9 items-center gap-2 rounded-[8px] border border-[var(--border-default)] bg-[var(--surface)] px-3",
            "text-[var(--text-tertiary)] hover:border-[var(--border-emphasis)] hover:bg-[var(--surface-alt)] cursor-pointer transition-colors",
            "w-full max-w-md"
          )}
          aria-label="Open command palette"
        >
          <Search className="h-4 w-4" strokeWidth={1.5} />
          <span className="text-[0.875rem] flex-1 text-left">
            Search people, or jump to…
          </span>
          <kbd className="hidden sm:inline-flex items-center gap-1 rounded-[6px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1.5 h-5 text-[0.6875rem] font-data text-[var(--text-secondary)]">
            <Command className="h-3 w-3" strokeWidth={1.5} />K
          </kbd>
        </button>

        <div className="ml-auto flex items-center gap-2">
          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setNotifOpen((v) => !v)}
              aria-label="Notifications"
              aria-expanded={notifOpen}
              className="relative inline-flex h-9 w-9 items-center justify-center rounded-[8px] border border-[var(--border-default)] bg-[var(--surface)] text-[var(--text-secondary)] hover:border-[var(--border-emphasis)] hover:bg-[var(--surface-alt)] cursor-pointer transition-colors"
            >
              <Bell className="h-4 w-4" strokeWidth={1.5} />
              {unreadNotifs > 0 && (
                <span className="absolute -top-1 -right-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--accent-coral)] px-1 text-[0.625rem] font-semibold text-white font-data">
                  {unreadNotifs}
                </span>
              )}
            </button>
            <AnimatePresence>
              {notifOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setNotifOpen(false)}
                    aria-hidden="true"
                  />
                  <motion.div
                    initial={{ opacity: 0, y: -8, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -8, scale: 0.98 }}
                    transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                    className="absolute right-0 mt-2 w-[360px] max-w-[calc(100vw-2rem)] rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] shadow-warm-lg z-50 overflow-hidden"
                    role="dialog"
                    aria-label="Notifications"
                  >
                    <div className="px-4 py-3 border-b border-[var(--border-default)] flex items-center justify-between">
                      <p className="font-display text-base font-medium">Notifications</p>
                      <span className="text-[0.6875rem] font-data text-[var(--text-tertiary)]">
                        {unreadNotifs} unread
                      </span>
                    </div>
                    <ul className="max-h-[320px] overflow-y-auto py-1">
                      {notifications.map((n) => (
                        <li key={n.id}>
                          <button
                            onClick={() => {
                              setNotifOpen(false);
                              if (n.href) router.push(n.href);
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-[var(--surface-alt)] cursor-pointer transition-colors flex gap-3"
                          >
                            <span
                              className={cn(
                                "mt-1.5 inline-block h-2 w-2 shrink-0 rounded-full",
                                n.tone === "mint" && "bg-[var(--accent-mint)]",
                                n.tone === "amber" && "bg-[var(--status-amber)]",
                                n.tone === "brick" && "bg-[var(--status-brick)]"
                              )}
                              aria-hidden="true"
                            />
                            <div className="min-w-0">
                              <p className="text-[0.8125rem] text-[var(--text-primary)] leading-snug">
                                {n.title}
                              </p>
                              <p className="text-[0.6875rem] text-[var(--text-tertiary)] mt-0.5">
                                {n.time}
                              </p>
                            </div>
                          </button>
                        </li>
                      ))}
                    </ul>
                    <div className="px-4 py-2 border-t border-[var(--border-default)]">
                      <button
                        onClick={() => {
                          setUnreadNotifs(0);
                          setNotifOpen(false);
                        }}
                        disabled={unreadNotifs === 0}
                        className="text-[0.75rem] text-[var(--accent-coral)] hover:underline cursor-pointer disabled:opacity-40 disabled:no-underline disabled:cursor-not-allowed"
                      >
                        Mark all as read
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          <ThemeToggle />

          {/* Profile dropdown */}
          <ProfileDropdown />
        </div>
      </div>

      <CommandPalette
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        onNavigate={go}
      />
    </header>
  );
}

/* ------------------------- Command palette (⌘K) ------------------------- */

type CommandItem =
  | {
      kind: "person";
      id: string;
      label: string;
      sublabel: string;
      href: string;
      keywords: string;
    }
  | {
      kind: "action";
      id: string;
      label: string;
      sublabel: string;
      href: string;
      icon: "go" | "add";
    };

function buildIndex(): CommandItem[] {
  const people: CommandItem[] = employees.map((e: Employee) => ({
    kind: "person",
    id: `p-${e.id}`,
    label: e.name,
    sublabel: `${e.title} · ${e.department}`,
    href: `/people?id=${e.id}`,
    keywords: `${e.name} ${e.title} ${e.department} ${e.location}`.toLowerCase(),
  }));
  const actions: CommandItem[] = [
    {
      kind: "action",
      id: "a-overview",
      label: "Go to Overview",
      sublabel: "Org chart",
      href: "/",
      icon: "go",
    },
    {
      kind: "action",
      id: "a-hiring",
      label: "Go to Hiring",
      sublabel: "Pipeline kanban",
      href: "/hiring",
      icon: "go",
    },
    {
      kind: "action",
      id: "a-people",
      label: "Go to People",
      sublabel: "Directory",
      href: "/people",
      icon: "go",
    },
    {
      kind: "action",
      id: "a-attrition",
      label: "Go to Attrition",
      sublabel: "Analytics",
      href: "/attrition",
      icon: "go",
    },
    {
      kind: "action",
      id: "a-reviews",
      label: "Go to Reviews",
      sublabel: "Performance cycles",
      href: "/reviews",
      icon: "go",
    },
    {
      kind: "action",
      id: "a-add-emp",
      label: "Add employee",
      sublabel: "Open the add-employee form",
      href: "/people?add=1",
      icon: "add",
    },
    {
      kind: "action",
      id: "a-add-candidate",
      label: "Add candidate",
      sublabel: "Open the add-candidate form",
      href: "/hiring?add=1",
      icon: "add",
    },
    {
      kind: "action",
      id: "a-request-review",
      label: "Request review",
      sublabel: "Open the request-review form",
      href: "/reviews?request=1",
      icon: "add",
    },
  ];
  return [...actions, ...people];
}

function fuzzyMatch(query: string, item: CommandItem): boolean {
  if (!query.trim()) return true;
  const q = query.toLowerCase();
  if (item.kind === "person") {
    return (
      item.label.toLowerCase().includes(q) ||
      item.sublabel.toLowerCase().includes(q) ||
      item.keywords.includes(q)
    );
  }
  return (
    item.label.toLowerCase().includes(q) ||
    item.sublabel.toLowerCase().includes(q)
  );
}

function CommandPalette({
  open,
  onOpenChange,
  onNavigate,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onNavigate: (path: string) => void;
}) {
  const index = useMemo(() => buildIndex(), []);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-xl p-0 overflow-hidden rounded-[18px] gap-0 border-[var(--border-default)] bg-[var(--surface)]"
        aria-describedby={undefined}
      >
        <DialogTitle className="sr-only">Command palette</DialogTitle>
        <DialogDescription className="sr-only">
          Search people and quick actions across {brand.name}.
        </DialogDescription>
        {/* Render the inner content only when open — this naturally resets state
            on each open without setState-in-effect. */}
        {open && (
          <CommandPaletteInner
            index={index}
            onNavigate={onNavigate}
            onOpenChange={onOpenChange}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}

function CommandPaletteInner({
  index,
  onNavigate,
  onOpenChange,
}: {
  index: CommandItem[];
  onNavigate: (path: string) => void;
  onOpenChange: (v: boolean) => void;
}) {
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus the input on mount (no setState — just a DOM side-effect).
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const filtered = index.filter((i) => fuzzyMatch(query, i));
  const safeIndex = Math.min(activeIndex, Math.max(0, filtered.length - 1));

  // keyboard navigation
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, filtered.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const item = filtered[safeIndex];
      if (item) onNavigate(item.href);
    } else if (e.key === "Escape") {
      e.preventDefault();
      onOpenChange(false);
    }
  };

  return (
    <>
      <div className="flex items-center gap-3 border-b border-[var(--border-default)] px-4">
        <Search className="h-4 w-4 text-[var(--text-tertiary)]" strokeWidth={1.5} />
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setActiveIndex(0);
          }}
          onKeyDown={onKey}
          placeholder="Search people, or jump to…"
          className="flex-1 h-14 bg-transparent text-[0.9375rem] outline-none placeholder:text-[var(--text-tertiary)]"
          aria-label="Command palette search"
          role="combobox"
          aria-expanded="true"
          aria-controls="cmdk-list"
          aria-activedescendant={filtered[safeIndex]?.id}
        />
        <kbd className="hidden sm:inline-flex items-center rounded-[6px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1.5 h-5 text-[0.6875rem] font-data text-[var(--text-secondary)]">
          ESC
        </kbd>
      </div>
        <div
          id="cmdk-list"
          role="listbox"
          aria-label="Search results"
          className="max-h-[360px] overflow-y-auto py-2"
        >
          {filtered.length === 0 ? (
            <div className="px-4 py-10 text-center">
              <p className="text-[0.875rem] text-[var(--text-secondary)]">
                No matches for &ldquo;{query}&rdquo;
              </p>
              <p className="text-[0.75rem] text-[var(--text-tertiary)] mt-1">
                Try a name, role, or department.
              </p>
            </div>
          ) : (
            filtered.map((item, i) => {
              const isActive = i === safeIndex;
              return (
                <button
                  key={item.id}
                  id={item.id}
                  role="option"
                  aria-selected={isActive}
                  onMouseMove={() => setActiveIndex(i)}
                  onClick={() => onNavigate(item.href)}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 mx-1 rounded-[10px] py-2 cursor-pointer text-left",
                    isActive
                      ? "bg-[var(--accent-coral-soft)]"
                      : "hover:bg-[var(--surface-alt)]"
                  )}
                  style={{ width: "calc(100% - 0.5rem)" }}
                >
                  {item.kind === "person" ? (
                    <>
                      <Avatar name={item.label} seed={item.label} size="xs" />
                      <div className="min-w-0 flex-1">
                        <div className="text-[0.875rem] text-[var(--text-primary)] truncate">
                          {item.label}
                        </div>
                        <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                          {item.sublabel}
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <span
                        className={cn(
                          "inline-flex h-8 w-8 items-center justify-center rounded-[8px]",
                          item.icon === "add"
                            ? "bg-[var(--accent-coral-soft)] text-[var(--accent-coral)]"
                            : "bg-[var(--surface-alt)] text-[var(--text-secondary)]"
                        )}
                      >
                        <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.5} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="text-[0.875rem] text-[var(--text-primary)] truncate">
                          {item.label}
                        </div>
                        <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                          {item.sublabel}
                        </div>
                      </div>
                    </>
                  )}
                  {isActive && (
                    <CornerDownLeft className="h-3.5 w-3.5 text-[var(--text-tertiary)] shrink-0" strokeWidth={1.5} />
                  )}
                </button>
              );
            })
          )}
        </div>
        <div className="border-t border-[var(--border-default)] px-4 py-2 flex items-center gap-4 text-[0.6875rem] text-[var(--text-tertiary)]">
          <span className="flex items-center gap-1">
            <kbd className="rounded-[4px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1 font-data">↑</kbd>
            <kbd className="rounded-[4px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1 font-data">↓</kbd>
            navigate
          </span>
          <span className="flex items-center gap-1">
            <kbd className="rounded-[4px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1 font-data">↵</kbd>
            select
          </span>
          <span className="ml-auto">
            {candidates.length} candidates · {employees.length} people
          </span>
        </div>
    </>
  );
}

const notifications = [
  {
    id: "n1",
    title: "Priya Nair submitted the H2 review calibration",
    time: "12 minutes ago",
    tone: "mint" as const,
    href: "/reviews",
  },
  {
    id: "n2",
    title: "Sara Lindqvist flagged as flight-risk (score 28)",
    time: "2 hours ago",
    tone: "brick" as const,
    href: "/attrition",
  },
  {
    id: "n3",
    title: "2 candidates moved to Interview stage this week",
    time: "Yesterday",
    tone: "amber" as const,
    href: "/hiring",
  },
];

/* ------------------------- Profile dropdown ------------------------- */

function ProfileDropdown() {
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const [open, setOpen] = useState(false);
  const currentUser = employees[0];

  const items = [
    {
      icon: User,
      label: "View profile",
      description: "Your public profile page",
      onClick: () => {
        setOpen(false);
        router.push("/profile");
      },
    },
    {
      icon: Settings,
      label: "Settings",
      description: "Account preferences",
      onClick: () => {
        setOpen(false);
        router.push("/settings");
      },
    },
  ];

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Open profile menu"
        aria-expanded={open}
        className="inline-flex h-9 items-center gap-2 rounded-[8px] border border-[var(--border-default)] bg-[var(--surface)] pl-1 pr-2 hover:bg-[var(--surface-alt)] cursor-pointer transition-colors"
      >
        <Avatar name={currentUser.name} seed={currentUser.avatarSeed} size="xs" />
        <span className="hidden sm:inline text-[0.8125rem] font-medium text-[var(--text-primary)]">
          {currentUser.name.split(" ")[0]}
        </span>
        <ChevronDown
          className={cn(
            "h-3.5 w-3.5 text-[var(--text-tertiary)] transition-transform duration-200",
            open && "rotate-180"
          )}
          strokeWidth={1.5}
        />
      </button>
      <AnimatePresence>
        {open && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setOpen(false)}
              aria-hidden="true"
            />
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.98 }}
              transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
              className="absolute right-0 mt-2 w-[280px] rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] shadow-warm-lg z-50 overflow-hidden"
              role="dialog"
              aria-label="Profile menu"
            >
              {/* User info header */}
              <div className="flex items-center gap-3 p-4 border-b border-[var(--border-default)]">
                <Avatar
                  name={currentUser.name}
                  seed={currentUser.avatarSeed}
                  size="md"
                />
                <div className="min-w-0 flex-1">
                  <div className="text-[0.875rem] font-semibold text-[var(--text-primary)] truncate">
                    {currentUser.name}
                  </div>
                  <div className="text-[0.75rem] text-[var(--text-tertiary)] truncate">
                    {currentUser.email}
                  </div>
                </div>
              </div>

              {/* Menu items */}
              <div className="py-1">
                {items.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.label}
                      onClick={item.onClick}
                      className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[var(--surface-alt)] cursor-pointer transition-colors text-left"
                    >
                      <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] bg-[var(--surface-alt)] text-[var(--text-secondary)]">
                        <Icon className="h-4 w-4" strokeWidth={1.5} />
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="text-[0.8125rem] font-medium text-[var(--text-primary)]">
                          {item.label}
                        </div>
                        <div className="text-[0.6875rem] text-[var(--text-tertiary)]">
                          {item.description}
                        </div>
                      </div>
                    </button>
                  );
                })}

                {/* Theme toggle row */}
                <button
                  onClick={() => {
                    setTheme(theme === "dark" ? "light" : "dark");
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[var(--surface-alt)] cursor-pointer transition-colors text-left"
                >
                  <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] bg-[var(--surface-alt)] text-[var(--text-secondary)]">
                    {theme === "dark" ? (
                      <Sun className="h-4 w-4" strokeWidth={1.5} />
                    ) : (
                      <Moon className="h-4 w-4" strokeWidth={1.5} />
                    )}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="text-[0.8125rem] font-medium text-[var(--text-primary)]">
                      {theme === "dark" ? "Switch to light" : "Switch to dark"}
                    </div>
                    <div className="text-[0.6875rem] text-[var(--text-tertiary)]">
                      Theme: {theme === "dark" ? "Dark" : "Light"}
                    </div>
                  </div>
                </button>
              </div>

              {/* Sign out */}
              <div className="border-t border-[var(--border-default)] p-1">
                <button
                  onClick={() => {
                    setOpen(false);
                    toast({
                      title: "Signed out",
                      description:
                        "You've been signed out of Bloom. (Demo template — no real session.)",
                    });
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-[var(--surface-alt)] cursor-pointer transition-colors text-left rounded-[10px]"
                >
                  <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] bg-[var(--status-brick-soft)] text-[var(--status-brick)]">
                    <LogOut className="h-4 w-4" strokeWidth={1.5} />
                  </span>
                  <span className="text-[0.8125rem] font-medium text-[var(--status-brick)]">
                    Sign out
                  </span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

