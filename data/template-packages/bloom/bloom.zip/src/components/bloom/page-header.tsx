"use client";

import { type ReactNode } from "react";
import { cn } from "@/lib/utils";

/** Page header — title (Fraunces), subtitle, optional actions. */
export function PageHeader({
  title,
  subtitle,
  eyebrow,
  actions,
  className,
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  actions?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between", className)}>
      <div className="min-w-0">
        {eyebrow && <p className="eyebrow mb-2">{eyebrow}</p>}
        <h1
          className="font-display font-medium text-[var(--text-primary)] leading-tight"
          style={{
            fontSize: "clamp(1.5rem, 1.3rem + 1vw, 2.25rem)",
            letterSpacing: "-0.01em",
          }}
        >
          {title}
        </h1>
        {subtitle && (
          <p className="text-[0.9375rem] text-[var(--text-secondary)] mt-2 max-w-prose">
            {subtitle}
          </p>
        )}
      </div>
      {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
    </div>
  );
}
