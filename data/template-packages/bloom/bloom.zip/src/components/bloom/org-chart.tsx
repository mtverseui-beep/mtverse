"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
  type WheelEvent as ReactWheelEvent,
} from "react";
import { hierarchy, tree, type HierarchyPointNode } from "d3-hierarchy";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { ChevronDown, ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import { Avatar } from "./avatar";
import { StatusBadge, statusVariantForEmployee } from "./status-badge";
import { cn } from "@/lib/utils";
import { orgRoot, type Employee, type OrgNode } from "@/data/demo";

/* ------------------------------------------------------------------ *
 * Bloom Org Chart
 * ------------------------------------------------------------------ *
 * - @visx/hierarchy `tree()` for layout (top-down, with nodeSize)
 * - Curved bezier connectors (spec §3.7 — never straight right-angle)
 * - Pan (mouse-drag + touch), pinch-zoom, scroll-zoom, with inertial momentum
 * - Per-node expand/collapse
 * - Dot-grid canvas, coral radial glow behind root (spec §3.4)
 * - prefers-reduced-motion → fully expanded, no momentum
 * ------------------------------------------------------------------ */

const NODE_WIDTH = 220;
const NODE_HEIGHT = 84;
const GAP_X = 28; // horizontal gap between siblings (added to NODE_WIDTH for nodeSize[0])
const GAP_Y = 80; // vertical gap between levels (added to NODE_HEIGHT for nodeSize[1])

type LaidOutNode = HierarchyPointNode<Employee>;

/** Prune the org tree by collapsing nodes whose id is in `collapsed`. */
function pruneTree(root: OrgNode, collapsed: Set<string>): OrgNode {
  if (collapsed.has(root.id)) {
    return { ...root, reports: [] };
  }
  return {
    ...root,
    reports: root.reports.map((r) => pruneTree(r, collapsed)),
  };
}

/** Build the d3-hierarchy root and run the visx tree layout. */
function useTreeLayout(collapsed: Set<string>) {
  return useMemo(() => {
    const pruned = pruneTree(orgRoot, collapsed);
    const d3Root = hierarchy<Employee>(pruned as unknown as Employee, (d) =>
      (d as unknown as OrgNode).reports
    );
    const layout = tree<Employee>()
      .nodeSize([NODE_WIDTH + GAP_X, NODE_HEIGHT + GAP_Y])
      .separation((a, b) => (a.parent === b.parent ? 1 : 1.35));
    return layout(d3Root);
  }, [collapsed]);
}

/** Compute the bounding box of the laid-out tree. */
function useBounds(root: LaidOutNode) {
  return useMemo(() => {
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    root.descendants().forEach((n) => {
      minX = Math.min(minX, n.x - NODE_WIDTH / 2);
      maxX = Math.max(maxX, n.x + NODE_WIDTH / 2);
      minY = Math.min(minY, n.y);
      maxY = Math.max(maxY, n.y + NODE_HEIGHT);
    });
    return {
      width: maxX - minX + NODE_WIDTH,
      height: maxY - minY + NODE_HEIGHT,
      offsetX: -minX + NODE_WIDTH / 2,
      offsetY: -minY,
    };
  }, [root]);
}

type Transform = { x: number; y: number; k: number };

export function OrgChart({ onSelect }: { onSelect: (id: string) => void }) {
  const reduceMotion = useReducedMotion();
  const laidOut = useTreeLayout(/* collapsed */ useCollapsedState());
  const bounds = useBounds(laidOut);

  const containerRef = useRef<HTMLDivElement>(null);
  const [userTransform, setUserTransform] = useState<Transform | null>(null);
  const [containerSize, setContainerSize] = useState({ w: 0, h: 0 });

  // Resize observer for the canvas container
  useEffect(() => {
    if (!containerRef.current) return;
    const el = containerRef.current;
    const update = () => setContainerSize({ w: el.clientWidth, h: el.clientHeight });
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // Center the root node on first layout. We use a sentinel `null` initial
  // state to mean "uninitialized" — the centered transform is computed during
  // render from containerSize, avoiding setState-in-effect. Once the user
  // pans/zooms, userTransform is non-null and overrides the centered default.
  // Initial zoom fits ~3 levels of the tree vertically so users see context.
  const fitZoom = Math.min(
    1,
    Math.max(0.45, (containerSize.h - 120) / Math.max(bounds.height, 1))
  );
  const centeredTransform: Transform = {
    x: containerSize.w / 2 - bounds.offsetX * fitZoom,
    y: 60,
    k: fitZoom,
  };
  const transform = userTransform ?? centeredTransform;

  // Pan state — high-frequency pan data in ref (read in event handlers only),
  // isPanning in React state (read in render for transition suppression).
  const panState = useRef<{
    lastX: number;
    lastY: number;
    velocityX: number;
    velocityY: number;
    lastT: number;
  }>({ lastX: 0, lastY: 0, velocityX: 0, velocityY: 0, lastT: 0 });
  const [isPanning, setIsPanning] = useState(false);

  // Inertial momentum after pan ends
  const momentumRef = useRef<number | null>(null);
  const startMomentum = useCallback(() => {
    if (reduceMotion) return;
    if (momentumRef.current) cancelAnimationFrame(momentumRef.current);
    const tick = () => {
      const ps = panState.current;
      if (Math.abs(ps.velocityX) < 0.05 && Math.abs(ps.velocityY) < 0.05) {
        momentumRef.current = null;
        return;
      }
      setUserTransform((t) => ({
        ...(t ?? centeredTransform),
        x: (t ?? centeredTransform).x + ps.velocityX,
        y: (t ?? centeredTransform).y + ps.velocityY,
      }));
      ps.velocityX *= 0.92;
      ps.velocityY *= 0.92;
      momentumRef.current = requestAnimationFrame(tick);
    };
    momentumRef.current = requestAnimationFrame(tick);
  }, [reduceMotion, centeredTransform]);

  useEffect(() => {
    return () => {
      if (momentumRef.current) cancelAnimationFrame(momentumRef.current);
    };
  }, []);

  // Pointer events for pan (mouse + touch unified via Pointer Events)
  const onPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    // Only start pan on background, not on a node card
    if ((e.target as HTMLElement).closest("[data-node-card]")) return;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    if (momentumRef.current) cancelAnimationFrame(momentumRef.current);
    panState.current = {
      lastX: e.clientX,
      lastY: e.clientY,
      velocityX: 0,
      velocityY: 0,
      lastT: performance.now(),
    };
    setIsPanning(true);
  };

  const onPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!isPanning) return;
    const ps = panState.current;
    const dx = e.clientX - ps.lastX;
    const dy = e.clientY - ps.lastY;
    const now = performance.now();
    const dt = Math.max(1, now - ps.lastT);
    ps.velocityX = (dx / dt) * 16;
    ps.velocityY = (dy / dt) * 16;
    ps.lastX = e.clientX;
    ps.lastY = e.clientY;
    ps.lastT = now;
    setUserTransform((t) => {
      const base = t ?? centeredTransform;
      return { ...base, x: base.x + dx, y: base.y + dy };
    });
  };

  const onPointerUp = () => {
    if (!isPanning) return;
    setIsPanning(false);
    startMomentum();
  };

  // Wheel zoom (desktop)
  const onWheel = (e: ReactWheelEvent<HTMLDivElement>) => {
    e.preventDefault();
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cursorX = e.clientX - rect.left;
    const cursorY = e.clientY - rect.top;

    setUserTransform((t) => {
      const base = t ?? centeredTransform;
      const delta = -e.deltaY * 0.0015;
      const newK = Math.max(0.35, Math.min(2.2, base.k * (1 + delta)));
      const kRatio = newK / base.k;
      // zoom toward cursor
      const newX = cursorX - (cursorX - base.x) * kRatio;
      const newY = cursorY - (cursorY - base.y) * kRatio;
      return { x: newX, y: newY, k: newK };
    });
  };

  // Touch pinch-zoom
  const pinchRef = useRef<{ dist: number; midX: number; midY: number } | null>(null);
  const onTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      pinchRef.current = {
        dist: Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY),
        midX: (t1.clientX + t2.clientX) / 2,
        midY: (t1.clientY + t2.clientY) / 2,
      };
    }
  };
  const onTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2 && pinchRef.current) {
      e.preventDefault();
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      const midX = (t1.clientX + t2.clientX) / 2;
      const midY = (t1.clientY + t2.clientY) / 2;
      const el = containerRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const cx = midX - rect.left;
      const cy = midY - rect.top;
      const ratio = dist / pinchRef.current.dist;
      setUserTransform((t) => {
        const base = t ?? centeredTransform;
        const newK = Math.max(0.35, Math.min(2.2, base.k * ratio));
        const kRatio = newK / base.k;
        const newX = cx - (cx - base.x) * kRatio;
        const newY = cy - (cy - base.y) * kRatio;
        return { x: newX, y: newY, k: newK };
      });
      pinchRef.current = { dist, midX, midY };
    }
  };
  const onTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length < 2) pinchRef.current = null;
  };

  // Zoom buttons
  const zoomBy = (factor: number) => {
    setUserTransform((t) => {
      const base = t ?? centeredTransform;
      const newK = Math.max(0.35, Math.min(2.2, base.k * factor));
      const cx = containerSize.w / 2;
      const cy = containerSize.h / 2;
      const kRatio = newK / base.k;
      return {
        x: cx - (cx - base.x) * kRatio,
        y: cy - (cy - base.y) * kRatio,
        k: newK,
      };
    });
  };

  const resetView = () => {
    setUserTransform(null);
  };

  const nodes = laidOut.descendants();
  const links = laidOut.links();

  return (
    <div
      ref={containerRef}
      className="relative h-full w-full overflow-hidden org-canvas-bg touch-none cursor-grab active:cursor-grabbing"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      onPointerCancel={onPointerUp}
      onWheel={onWheel}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      role="application"
      aria-label="Organization chart. Drag to pan, scroll or pinch to zoom, click a person to view details."
    >
      {/* coral radial glow behind root (spec §3.4) */}
      <div
        className="pointer-events-none absolute z-0"
        style={{
          left: transform.x + 0 - 200,
          top: transform.y + 0 - 100,
          width: 400,
          height: 400,
          transform: `scale(${transform.k})`,
          transformOrigin: "200px 200px",
          background:
            "radial-gradient(circle, var(--accent-coral) 0%, transparent 60%)",
          opacity: 0.08,
          filter: "blur(20px)",
        }}
        aria-hidden="true"
      />

      {/* world */}
      <div
        className="absolute left-0 top-0 origin-top-left"
        style={{
          transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.k})`,
          width: bounds.width,
          height: bounds.height,
          transition: isPanning ? "none" : undefined,
        }}
      >
        {/* SVG connectors layer */}
        <svg
          className="absolute left-0 top-0 pointer-events-none"
          width={bounds.width}
          height={bounds.height}
          aria-hidden="true"
        >
          <g transform={`translate(${bounds.offsetX - NODE_WIDTH / 2}, ${bounds.offsetY})`}>
            {links.map((link) => {
              const source = link.source as LaidOutNode;
              const target = link.target as LaidOutNode;
              const sx = source.x;
              const sy = source.y + NODE_HEIGHT;
              const tx = target.x;
              const ty = target.y;
              const midY = (sy + ty) / 2;
              const d = `M ${sx} ${sy} C ${sx} ${midY} ${tx} ${midY} ${tx} ${ty}`;
              return (
                <path
                  key={`${source.data.id}-${target.data.id}`}
                  d={d}
                  fill="none"
                  strokeLinecap="round"
                  style={{
                    stroke: "var(--text-tertiary)",
                    strokeWidth: 1.5,
                    opacity: 0.55,
                  }}
                  className="transition-[stroke] duration-200"
                />
              );
            })}
          </g>
        </svg>

        {/* nodes layer */}
        <div
          className="absolute left-0 top-0"
          style={{ width: bounds.width, height: bounds.height }}
        >
          {nodes.map((n) => (
            <NodeCard
              key={n.data.id}
              node={n}
              offsetX={bounds.offsetX}
              offsetY={bounds.offsetY}
              onSelect={onSelect}
            />
          ))}
        </div>
      </div>

      {/* zoom controls */}
      <div className="absolute bottom-4 right-4 z-10 flex flex-col gap-1.5 rounded-[12px] border border-[var(--border-default)] bg-[var(--surface)] p-1.5 shadow-warm-md">
        <button
          onClick={() => zoomBy(1.2)}
          aria-label="Zoom in"
          className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)] cursor-pointer transition-colors"
        >
          <ZoomIn className="h-4 w-4" strokeWidth={1.5} />
        </button>
        <button
          onClick={() => zoomBy(1 / 1.2)}
          aria-label="Zoom out"
          className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)] cursor-pointer transition-colors"
        >
          <ZoomOut className="h-4 w-4" strokeWidth={1.5} />
        </button>
        <button
          onClick={resetView}
          aria-label="Reset view"
          className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)] cursor-pointer transition-colors"
        >
          <Maximize2 className="h-4 w-4" strokeWidth={1.5} />
        </button>
      </div>

      {/* zoom indicator */}
      <div className="absolute bottom-4 left-4 z-10 rounded-full border border-[var(--border-default)] bg-[var(--surface)] px-2.5 py-1 text-[0.6875rem] font-data text-[var(--text-secondary)] shadow-warm-sm">
        {Math.round(transform.k * 100)}%
      </div>
    </div>
  );
}

/* ------------------------------- Node card ------------------------------- */

function NodeCard({
  node,
  offsetX,
  offsetY,
  onSelect,
}: {
  node: LaidOutNode;
  offsetX: number;
  offsetY: number;
  onSelect: (id: string) => void;
}) {
  const employee = node.data;
  const isRoot = employee.managerId === null;
  const hasReports = (node.children?.length ?? 0) > 0;
  // Use the original orgRoot to check true report count (not the pruned one)
  const trueReportCount = useMemo(() => countReports(employee.id), [employee.id]);
  const collapsed = useCollapsedSet().has(employee.id);
  const reduceMotion = useReducedMotion();

  const x = node.x - NODE_WIDTH / 2 + offsetX - NODE_WIDTH / 2;
  const y = node.y + offsetY;

  return (
    <motion.div
      data-node-card
      className={cn(
        "absolute group cursor-pointer",
        "rounded-[14px] border bg-[var(--surface)] shadow-warm-sm",
        "hover:shadow-warm-md hover:-translate-y-0.5",
        "transition-[box-shadow,transform] duration-200 ease-[cubic-bezier(0.16,1,0.3,1)]",
        isRoot
          ? "border-[var(--accent-coral)]/40 ring-2 ring-[var(--accent-coral)]/15"
          : "border-[var(--border-default)]"
      )}
      style={{
        left: x,
        top: y,
        width: NODE_WIDTH,
        height: NODE_HEIGHT,
      }}
      initial={reduceMotion ? false : { opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(employee.id);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          e.stopPropagation();
          onSelect(employee.id);
        }
      }}
      tabIndex={0}
      role="button"
      aria-label={`${employee.name}, ${employee.title}. ${trueReportCount} direct reports. Press Enter to view details.`}
    >
      <div className="flex h-full items-center gap-3 p-3">
        <Avatar
          name={employee.name}
          seed={employee.avatarSeed}
          size="md"
          ring={isRoot}
          className="shrink-0"
        />
        <div className="min-w-0 flex-1">
          <div className="text-[0.8125rem] font-semibold text-[var(--text-primary)] truncate leading-tight">
            {employee.name}
          </div>
          <div className="text-[0.6875rem] text-[var(--text-secondary)] truncate mt-0.5">
            {employee.title}
          </div>
          <div className="flex items-center gap-1.5 mt-1">
            <StatusBadge
              variant={statusVariantForEmployee(employee)}
              dot={false}
              className="!py-0 !text-[0.625rem]"
            />
            {trueReportCount > 0 && (
              <span className="text-[0.625rem] text-[var(--text-tertiary)] font-data">
                {trueReportCount} {trueReportCount === 1 ? "report" : "reports"}
              </span>
            )}
          </div>
        </div>
      </div>
      {hasReports && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleCollapsed(employee.id);
          }}
          aria-label={collapsed ? `Expand ${employee.name}'s reports` : `Collapse ${employee.name}'s reports`}
          aria-expanded={!collapsed}
          className="absolute -bottom-3 left-1/2 -translate-x-1/2 inline-flex h-6 w-6 items-center justify-center rounded-full border border-[var(--border-default)] bg-[var(--surface)] shadow-warm-sm hover:bg-[var(--surface-alt)] cursor-pointer transition-colors z-10"
        >
          <motion.span
            animate={{ rotate: collapsed ? -90 : 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="inline-flex"
          >
            <ChevronDown className="h-3.5 w-3.5 text-[var(--text-secondary)]" strokeWidth={1.5} />
          </motion.span>
        </button>
      )}
    </motion.div>
  );
}

/* ----------------------- Collapsed state (module) ----------------------- */
// Module-level state — simple, deterministic, no provider needed. Persists across re-renders.

const collapsedSet = new Set<string>();
const collapsedListeners = new Set<() => void>();

function useCollapsedSet(): Set<string> {
  // Subscribe so re-render on toggle
  const [, setTick] = useState(0);
  useEffect(() => {
    const listener = () => setTick((t) => t + 1);
    collapsedListeners.add(listener);
    return () => {
      collapsedListeners.delete(listener);
    };
  }, []);
  return collapsedSet;
}

function useCollapsedState(): Set<string> {
  // Same as useCollapsedSet but used at the top of OrgChart for layout input
  return useCollapsedSet();
}

function toggleCollapsed(id: string) {
  if (collapsedSet.has(id)) {
    collapsedSet.delete(id);
  } else {
    collapsedSet.add(id);
  }
  collapsedListeners.forEach((l) => l());
}

/* ----------------------------- helpers ----------------------------- */

function countReports(id: string): number {
  // Count direct reports from the ORIGINAL orgRoot (not pruned)
  function find(node: OrgNode): OrgNode | null {
    if (node.id === id) return node;
    for (const r of node.reports) {
      const found = find(r);
      if (found) return found;
    }
    return null;
  }
  const node = find(orgRoot);
  return node?.reports.length ?? 0;
}

// Force AnimatePresence import for tree-shake safety
void AnimatePresence;
