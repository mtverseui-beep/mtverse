"use client";

import { cn } from "@/lib/utils";
import type { Employee } from "@/data/demo";

type BadgeVariant =
  | "active"
  | "on_leave"
  | "new_hire"
  | "flight_risk"
  | "neutral"
  | "coral"
  | "mint";

const variantStyles: Record<BadgeVariant, string> = {
  active:
    "bg-[var(--accent-mint-soft)] text-[var(--accent-mint)] border-transparent",
  on_leave:
    "bg-[var(--status-amber-soft)] text-[var(--status-amber)] border-transparent",
  new_hire:
    "bg-[var(--status-lavender-soft)] text-[var(--status-lavender)] border-transparent",
  flight_risk:
    "bg-[var(--status-brick-soft)] text-[var(--status-brick)] border-transparent",
  neutral:
    "bg-[var(--surface-alt)] text-[var(--text-secondary)] border-transparent",
  coral: "bg-[var(--accent-coral-soft)] text-[var(--accent-coral)] border-transparent",
  mint: "bg-[var(--accent-mint-soft)] text-[var(--accent-mint)] border-transparent",
};

const labelMap: Record<BadgeVariant, string> = {
  active: "Active",
  on_leave: "On leave",
  new_hire: "New hire",
  flight_risk: "Flight risk",
  neutral: "—",
  coral: "Coral",
  mint: "Mint",
};

export function StatusBadge({
  variant,
  label,
  className,
  dot = true,
}: {
  variant: BadgeVariant;
  label?: string;
  className?: string;
  dot?: boolean;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[0.6875rem] font-medium leading-none whitespace-nowrap",
        variantStyles[variant],
        className
      )}
    >
      {dot && (
        <span
          className={cn(
            "inline-block h-1.5 w-1.5 rounded-full",
            variant === "active" && "bg-[var(--accent-mint)]",
            variant === "on_leave" && "bg-[var(--status-amber)]",
            variant === "new_hire" && "bg-[var(--status-lavender)]",
            variant === "flight_risk" && "bg-[var(--status-brick)]",
            variant === "neutral" && "bg-[var(--text-tertiary)]",
            variant === "coral" && "bg-[var(--accent-coral)]",
            variant === "mint" && "bg-[var(--accent-mint)]"
          )}
          aria-hidden="true"
        />
      )}
      <span>{label ?? labelMap[variant]}</span>
    </span>
  );
}

/** Maps an Employee to the appropriate badge variant. */
export function statusVariantForEmployee(e: Employee): BadgeVariant {
  if (e.flightRisk >= 25) return "flight_risk";
  if (e.status === "on_leave") return "on_leave";
  if (e.status === "new_hire") return "new_hire";
  return "active";
}

/** Maps an Employee to a label that combines status + flight risk where relevant. */
export function statusLabelForEmployee(e: Employee): string {
  if (e.flightRisk >= 25) return "Flight risk";
  if (e.status === "on_leave") return "On leave";
  if (e.status === "new_hire") return "New hire";
  return "Active";
}
