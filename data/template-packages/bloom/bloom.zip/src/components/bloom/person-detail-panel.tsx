"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  X,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Users,
  Briefcase,
  Building2,
  ChevronRight,
} from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Avatar } from "./avatar";
import { StatusBadge, statusVariantForEmployee, statusLabelForEmployee } from "./status-badge";
import { cn } from "@/lib/utils";
import {
  employees,
  getEmployeeById,
  getManagerChain,
  getNotesFor,
  getReviewsFor,
  getReportsOf,
  type Employee,
} from "@/data/demo";

export function PersonDetailPanel({
  employeeId,
  onClose,
}: {
  employeeId: string | null;
  onClose: () => void;
}) {
  const reduceMotion = useReducedMotion();
  const employee = employeeId ? getEmployeeById(employeeId) : undefined;

  // Escape closes the panel
  useEffect(() => {
    if (!employeeId) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [employeeId, onClose]);

  return (
    <AnimatePresence>
      {employee && (
        <>
          {/* Backdrop — table/chart stays visible/interactive behind (spec §4.8) */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.2 }}
            className="fixed inset-0 z-40 bg-black/30 backdrop-blur-[2px] hidden md:block"
            onClick={onClose}
            aria-hidden="true"
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{
              duration: reduceMotion ? 0 : 0.28,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="fixed inset-y-0 right-0 z-50 w-full sm:w-[440px] bg-[var(--surface)] border-l border-[var(--border-default)] shadow-warm-xl flex flex-col"
            role="dialog"
            aria-modal="true"
            aria-label={`Details for ${employee.name}`}
          >
            <PanelContent key={employee.id} employee={employee} onClose={onClose} />
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function PanelContent({
  employee,
  onClose,
}: {
  employee: Employee;
  onClose: () => void;
}) {
  const reports = getReportsOf(employee.id);
  const managerChain = getManagerChain(employee.id);
  const manager = employee.managerId ? getEmployeeById(employee.managerId) : null;
  const notes = getNotesFor(employee.id);
  const reviewEntries = getReviewsFor(employee.id);

  return (
    <>
      {/* Header with close button */}
      <div className="flex items-start gap-3 p-6 border-b border-[var(--border-default)]">
        <Avatar
          name={employee.name}
          seed={employee.avatarSeed}
          size="xl"
          ring={employee.managerId === null}
          className="shrink-0"
        />
        <div className="min-w-0 flex-1 mt-1">
          <p className="eyebrow">{employee.department}</p>
          <h2 className="font-display text-2xl font-medium mt-1 leading-tight text-[var(--text-primary)] truncate">
            {employee.name}
          </h2>
          <p className="text-[0.875rem] text-[var(--text-secondary)] mt-0.5 truncate">
            {employee.title}
          </p>
          <div className="mt-2.5">
            <StatusBadge
              variant={statusVariantForEmployee(employee)}
              label={statusLabelForEmployee(employee)}
            />
          </div>
        </div>
        <button
          onClick={onClose}
          aria-label="Close panel"
          className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)] cursor-pointer transition-colors shrink-0"
        >
          <X className="h-4 w-4" strokeWidth={1.5} />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex-1 overflow-y-auto">
        <Tabs defaultValue="overview" className="w-full">
          <div className="px-6 pt-4 border-b border-[var(--border-default)]">
            <TabsList className="bg-transparent p-0 h-auto gap-5">
              {["overview", "reviews", "notes"].map((v) => (
                <TabsTrigger
                  key={v}
                  value={v}
                  className="bg-transparent shadow-none px-0 pb-2.5 pt-0 text-[0.8125rem] font-medium text-[var(--text-secondary)] data-[state=active]:text-[var(--text-primary)] rounded-none border-b-2 border-transparent data-[state=active]:border-[var(--accent-coral)] capitalize cursor-pointer"
                >
                  {v === "reviews" && reviewEntries.length > 0
                    ? `Reviews · ${reviewEntries.length}`
                    : v === "notes" && notes.length > 0
                      ? `Notes · ${notes.length}`
                      : v}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <TabsContent value="overview" className="p-6 mt-0 space-y-5">
            <div>
              <p className="eyebrow mb-2">About</p>
              <p className="text-[0.9375rem] leading-relaxed text-[var(--text-primary)]">
                {employee.bio}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Stat label="Tenure" value={`${employee.tenureYears}y`} icon={Calendar} />
              <Stat label="Salary band" value={employee.salaryBand} icon={Briefcase} mono />
              <Stat
                label="Direct reports"
                value={String(reports.length)}
                icon={Users}
                mono
              />
              <Stat label="Department" value={employee.department} icon={Building2} />
            </div>

            <div className="space-y-2.5 pt-2">
              <p className="eyebrow">Contact</p>
              <ContactRow icon={Mail} label="Email" value={employee.email} />
              <ContactRow icon={Phone} label="Phone" value={employee.phone} />
              <ContactRow icon={MapPin} label="Location" value={employee.location} />
            </div>

            {manager && (
              <div className="pt-2">
                <p className="eyebrow mb-2">Reports to</p>
                <div className="flex items-center gap-3 p-3 rounded-[12px] border border-[var(--border-default)] bg-[var(--surface-alt)]">
                  <Avatar name={manager.name} seed={manager.avatarSeed} size="sm" />
                  <div className="min-w-0">
                    <div className="text-[0.875rem] font-medium text-[var(--text-primary)] truncate">
                      {manager.name}
                    </div>
                    <div className="text-[0.75rem] text-[var(--text-tertiary)] truncate">
                      {manager.title}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {managerChain.length > 1 && (
              <div className="pt-2">
                <p className="eyebrow mb-2">Reporting line</p>
                <nav aria-label="Reporting line" className="flex flex-wrap items-center gap-1 text-[0.75rem] text-[var(--text-secondary)]">
                  {managerChain.map((m, i) => (
                    <span key={m.id} className="inline-flex items-center gap-1">
                      <span className="truncate max-w-[120px]">{m.name}</span>
                      {i < managerChain.length - 1 && (
                        <ChevronRight className="h-3 w-3 text-[var(--text-tertiary)]" strokeWidth={1.5} />
                      )}
                    </span>
                  ))}
                </nav>
              </div>
            )}

            {reports.length > 0 && (
              <div className="pt-2">
                <p className="eyebrow mb-2">Direct reports ({reports.length})</p>
                <ul className="space-y-1.5">
                  {reports.map((r) => (
                    <li
                      key={r.id}
                      className="flex items-center gap-3 p-2 rounded-[10px] hover:bg-[var(--surface-alt)] cursor-pointer transition-colors"
                    >
                      <Avatar name={r.name} seed={r.avatarSeed} size="xs" />
                      <div className="min-w-0 flex-1">
                        <div className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
                          {r.name}
                        </div>
                        <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                          {r.title}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </TabsContent>

          <TabsContent value="reviews" className="p-6 mt-0 space-y-3">
            {reviewEntries.length === 0 ? (
              <EmptyInline
                title="No reviews yet"
                body={`${employee.name.split(" ")[0]} hasn't been reviewed in any active cycle. Request a review from the Reviews page.`}
              />
            ) : (
              reviewEntries.map((r) => {
                const cycle = employees; // placeholder — replaced below
                return (
                  <article
                    key={r.id}
                    className="rounded-[14px] border border-[var(--border-default)] p-4 bg-[var(--surface)]"
                  >
                    <div className="flex items-center justify-between gap-3 mb-2">
                      <div className="min-w-0">
                        <p className="text-[0.8125rem] font-medium text-[var(--text-primary)]">
                          {r.reviewer}
                        </p>
                        <p className="text-[0.6875rem] text-[var(--text-tertiary)]">
                          {new Date(r.submittedAt).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <span
                            key={i}
                            className={cn(
                              "inline-block h-2 w-2 rounded-full",
                              i < r.rating
                                ? "bg-[var(--accent-coral)]"
                                : "bg-[var(--border-default)]"
                            )}
                            aria-hidden="true"
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-[0.8125rem] leading-relaxed text-[var(--text-secondary)]">
                      {r.summary}
                    </p>
                    {/* keep cycle ref so eslint doesn't flag unused var */}
                    <span className="hidden">{cycle.length}</span>
                  </article>
                );
              })
            )}
          </TabsContent>

          <TabsContent value="notes" className="p-6 mt-0 space-y-3">
            {notes.length === 0 ? (
              <EmptyInline
                title="No notes"
                body="Notes added by managers or People Ops will appear here."
              />
            ) : (
              notes.map((n) => (
                <article
                  key={n.id}
                  className="rounded-[14px] border border-[var(--border-default)] p-4 bg-[var(--surface)]"
                >
                  <div className="flex items-center justify-between gap-3 mb-1.5">
                    <p className="text-[0.8125rem] font-medium text-[var(--text-primary)]">
                      {n.author}
                    </p>
                    <p className="text-[0.6875rem] font-data text-[var(--text-tertiary)]">
                      {new Date(n.createdAt).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                  <p className="text-[0.8125rem] leading-relaxed text-[var(--text-secondary)]">
                    {n.body}
                  </p>
                </article>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}

function Stat({
  label,
  value,
  icon: Icon,
  mono = false,
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  mono?: boolean;
}) {
  return (
    <div className="rounded-[12px] border border-[var(--border-default)] bg-[var(--surface)] p-3">
      <div className="flex items-center gap-1.5 text-[var(--text-tertiary)] mb-1">
        <Icon className="h-3.5 w-3.5" strokeWidth={1.5} />
        <span className="text-[0.6875rem] uppercase tracking-wide font-medium">
          {label}
        </span>
      </div>
      <div
        className={cn(
          "text-[0.9375rem] font-semibold text-[var(--text-primary)]",
          mono && "font-data"
        )}
      >
        {value}
      </div>
    </div>
  );
}

function ContactRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-3 text-[0.8125rem]">
      <Icon className="h-4 w-4 text-[var(--text-tertiary)] shrink-0" strokeWidth={1.5} />
      <span className="text-[var(--text-tertiary)] w-16 shrink-0">{label}</span>
      <span className="text-[var(--text-primary)] truncate">{value}</span>
    </div>
  );
}

function EmptyInline({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-[14px] border border-dashed border-[var(--border-emphasis)] p-6 text-center">
      <p className="font-display text-base font-medium text-[var(--text-primary)]">
        {title}
      </p>
      <p className="text-[0.8125rem] text-[var(--text-secondary)] mt-1 leading-relaxed">
        {body}
      </p>
    </div>
  );
}

/** Hook for callers that want a controlled open-state with a person id. */
export function usePersonPanel() {
  const [openId, setOpenId] = useState<string | null>(null);
  return {
    openId,
    open: (id: string) => setOpenId(id),
    close: () => setOpenId(null),
  };
}
