"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { useLocalStorageBoolean } from "@/hooks/use-local-storage";
import {
  Network,
  KanbanSquare,
  Users,
  TrendingDown,
  ClipboardCheck,
  Settings,
  PanelLeftClose,
  PanelLeft,
  LogOut,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { brand } from "@/config/brand";
import { Avatar } from "./avatar";
import { employees } from "@/data/demo";
import { toast } from "@/hooks/use-toast";

const nav = [
  { href: "/", label: "Overview", icon: Network, description: "Org chart" },
  { href: "/hiring", label: "Hiring", icon: KanbanSquare, description: "Pipeline" },
  { href: "/people", label: "People", icon: Users, description: "Directory" },
  { href: "/attrition", label: "Attrition", icon: TrendingDown, description: "Analytics" },
  { href: "/reviews", label: "Reviews", icon: ClipboardCheck, description: "Cycles" },
] as const;

const COLLAPSED_KEY = "bloom-sidebar-collapsed";

export function Sidebar({
  mobileOpen,
  onCloseMobile,
}: {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useLocalStorageBoolean(COLLAPSED_KEY, false);
  const reduceMotion = useReducedMotion();

  // Close mobile drawer on route change
  useEffect(() => {
    onCloseMobile();
  }, [pathname, onCloseMobile]);

  // Escape closes mobile drawer
  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCloseMobile();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mobileOpen, onCloseMobile]);

  const currentUser = employees[0]; // Maya Okafor — bloom admin demo

  const sidebarWidth = collapsed ? 76 : 260;

  const sidebar = (
    <aside
      className={cn(
        "flex h-screen flex-col bg-[var(--surface)] border-r border-[var(--border-default)] shrink-0",
        "transition-[width] duration-300 ease-out"
      )}
      style={{
        width: sidebarWidth,
        transitionTimingFunction: reduceMotion ? "linear" : "cubic-bezier(0.16, 1, 0.3, 1)",
      }}
      aria-label="Primary navigation"
    >
      {/* Logo + wordmark */}
      <div className="flex items-center gap-3 h-16 px-4 border-b border-[var(--border-default)]">
        <Link
          href="/"
          className="flex items-center gap-2.5 group min-w-0"
          aria-label="Bloom home"
        >
          <span className="relative inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] bg-[var(--accent-coral)] shadow-warm-sm">
            {/* Bloom mark — abstract petal */}
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="none">
              <path
                d="M12 3c2.5 0 4 1.8 4 4 0-2.2 1.5-4 4-4s4 1.8 4 4c0 1.5-.8 2.8-2 3.5 1.2.7 2 2 2 3.5 0 2.2-1.5 4-4 4s-4-1.8-4-4c0 2.2-1.5 4-4 4s-4-1.8-4-4c0 2.2-1.5 4-4 4s-4-1.8-4-4c0-1.5.8-2.8 2-3.5C1.8 9.8 1 8.5 1 7c0-2.2 1.5-4 4-4s4 1.8 4 4c0-2.2 1.5-4 4-4z"
                stroke="currentColor"
                strokeWidth="1.4"
                strokeLinejoin="round"
                transform="translate(-1)"
              />
            </svg>
          </span>
          <AnimatePresence initial={false}>
            {!collapsed && (
              <motion.span
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: "auto" }}
                exit={{ opacity: 0, width: 0 }}
                transition={{ duration: reduceMotion ? 0 : 0.2, ease: [0.4, 0, 0.2, 1] }}
                className="overflow-hidden whitespace-nowrap"
              >
                <span className="block font-display text-lg leading-none font-medium text-[var(--text-primary)]">
                  {brand.name}
                </span>
                <span className="block text-[10px] leading-tight text-[var(--text-tertiary)] mt-1">
                  People Operations
                </span>
              </motion.span>
            )}
          </AnimatePresence>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1" aria-label="Main">
        <AnimatePresence initial={false}>
          {!collapsed && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: reduceMotion ? 0 : 0.18 }}
              className="eyebrow px-3 pb-2 pt-1"
            >
              Workspace
            </motion.p>
          )}
        </AnimatePresence>
        {nav.map((item) => {
          const isActive =
            item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              title={collapsed ? item.label : undefined}
              className={cn(
                "group relative flex items-center gap-3 rounded-[10px] px-3 h-10 text-[0.9375rem] font-medium",
                "transition-colors duration-200",
                collapsed && "justify-center px-0",
                isActive
                  ? "bg-[var(--accent-coral-soft)] text-[var(--accent-coral)]"
                  : "text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)]"
              )}
              aria-current={isActive ? "page" : undefined}
            >
              <span
                className={cn(
                  "inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-[8px] transition-colors",
                  isActive
                    ? "bg-[var(--accent-coral)] text-white"
                    : "text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]"
                )}
              >
                <Icon className="h-4 w-4" strokeWidth={1.5} />
              </span>
              <AnimatePresence initial={false}>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0, x: -4 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -4 }}
                    transition={{ duration: reduceMotion ? 0 : 0.18 }}
                    className="flex-1 overflow-hidden whitespace-nowrap"
                  >
                    {item.label}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          );
        })}
      </nav>

      {/* Footer: settings + profile */}
      <div className="border-t border-[var(--border-default)] p-3 space-y-1">
        <Link
          href="/settings"
          title={collapsed ? "Settings" : undefined}
          className={cn(
            "group flex items-center gap-3 rounded-[10px] px-3 h-10 text-[0.9375rem] font-medium",
            "text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)] transition-colors",
            collapsed && "justify-center px-0"
          )}
        >
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]">
            <Settings className="h-4 w-4" strokeWidth={1.5} />
          </span>
          <AnimatePresence initial={false}>
            {!collapsed && (
              <motion.span
                initial={{ opacity: 0, x: -4 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -4 }}
                transition={{ duration: reduceMotion ? 0 : 0.18 }}
                className="flex-1 overflow-hidden whitespace-nowrap"
              >
                Settings
              </motion.span>
            )}
          </AnimatePresence>
        </Link>

        <div
          className={cn(
            "flex items-center gap-3 rounded-[10px] p-2 mt-2",
            collapsed && "justify-center"
          )}
        >
          <Avatar name={currentUser.name} seed={currentUser.avatarSeed} size="xs" />
          <AnimatePresence initial={false}>
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0, x: -4 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -4 }}
                transition={{ duration: reduceMotion ? 0 : 0.18 }}
                className="flex-1 min-w-0"
              >
                <div className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
                  {currentUser.name}
                </div>
                <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                  {currentUser.title}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <AnimatePresence initial={false}>
            {!collapsed && (
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: reduceMotion ? 0 : 0.18 }}
                onClick={() => {
                  toast({
                    title: "Signed out",
                    description: "You've been signed out of Bloom. (Demo template — no real session.)",
                  });
                }}
                className="inline-flex h-7 w-7 items-center justify-center rounded-[6px] text-[var(--text-tertiary)] hover:text-[var(--text-primary)] hover:bg-[var(--surface-alt)] cursor-pointer transition-colors"
                aria-label="Sign out"
              >
                <LogOut className="h-3.5 w-3.5" strokeWidth={1.5} />
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </div>
    </aside>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <div className="hidden md:flex">
        <div className="relative">
          {sidebar}
          {/* Collapse toggle */}
          <button
            onClick={() => setCollapsed((v) => !v)}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            aria-expanded={!collapsed}
            className="absolute -right-3 top-20 z-20 inline-flex h-6 w-6 items-center justify-center rounded-full border border-[var(--border-default)] bg-[var(--surface)] shadow-warm-sm hover:bg-[var(--surface-alt)] cursor-pointer transition-colors"
          >
            {collapsed ? (
              <PanelLeft className="h-3 w-3 text-[var(--text-secondary)]" strokeWidth={1.5} />
            ) : (
              <PanelLeftClose className="h-3 w-3 text-[var(--text-secondary)]" strokeWidth={1.5} />
            )}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm md:hidden"
              onClick={onCloseMobile}
              aria-hidden="true"
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ duration: reduceMotion ? 0 : 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="fixed inset-y-0 left-0 z-50 md:hidden"
              role="dialog"
              aria-modal="true"
              aria-label="Navigation menu"
            >
              {/* Render the expanded (non-collapsed) version in the drawer */}
              <div className="flex h-full">
                <SidebarContentExpanded />
                <button
                  onClick={onCloseMobile}
                  aria-label="Close navigation"
                  className="absolute -right-12 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full bg-[var(--surface)] shadow-warm-md text-white md:hidden"
                >
                  <X className="h-4 w-4" strokeWidth={1.5} />
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

/**
 * Expanded-only sidebar for the mobile drawer — keeps things simple.
 * Same markup as `sidebar` above but always-expanded (260px).
 */
function SidebarContentExpanded() {
  const pathname = usePathname();
  const currentUser = employees[0];
  return (
    <aside className="flex h-full w-[260px] flex-col bg-[var(--surface)] border-r border-[var(--border-default)]">
      <div className="flex items-center gap-3 h-16 px-4 border-b border-[var(--border-default)]">
        <span className="relative inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] bg-[var(--accent-coral)] shadow-warm-sm">
          <svg viewBox="0 0 24 24" className="h-5 w-5 text-white" fill="none">
            <path
              d="M12 3c2.5 0 4 1.8 4 4 0-2.2 1.5-4 4-4s4 1.8 4 4c0 1.5-.8 2.8-2 3.5 1.2.7 2 2 2 3.5 0 2.2-1.5 4-4 4s-4-1.8-4-4c0 2.2-1.5 4-4 4s-4-1.8-4-4c0 2.2-1.5 4-4 4s-4-1.8-4-4c0-1.5.8-2.8 2-3.5C1.8 9.8 1 8.5 1 7c0-2.2 1.5-4 4-4s4 1.8 4 4c0-2.2 1.5-4 4-4z"
              stroke="currentColor"
              strokeWidth="1.4"
              strokeLinejoin="round"
              transform="translate(-1)"
            />
          </svg>
        </span>
        <span className="block font-display text-lg leading-none font-medium text-[var(--text-primary)]">
          {brand.name}
        </span>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <p className="eyebrow px-3 pb-2 pt-1">Workspace</p>
        {nav.map((item) => {
          const isActive =
            item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "group flex items-center gap-3 rounded-[10px] px-3 h-10 text-[0.9375rem] font-medium",
                isActive
                  ? "bg-[var(--accent-coral-soft)] text-[var(--accent-coral)]"
                  : "text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)]"
              )}
              aria-current={isActive ? "page" : undefined}
            >
              <span
                className={cn(
                  "inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-[8px]",
                  isActive
                    ? "bg-[var(--accent-coral)] text-white"
                    : "text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]"
                )}
              >
                <Icon className="h-4 w-4" strokeWidth={1.5} />
              </span>
              <span className="flex-1">{item.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-[var(--border-default)] p-3 space-y-1">
        <Link
          href="/settings"
          className="group flex items-center gap-3 rounded-[10px] px-3 h-10 text-[0.9375rem] font-medium text-[var(--text-secondary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)]"
        >
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]">
            <Settings className="h-4 w-4" strokeWidth={1.5} />
          </span>
          Settings
        </Link>
        <div className="flex items-center gap-3 rounded-[10px] p-2 mt-2">
          <Avatar name={currentUser.name} seed={currentUser.avatarSeed} size="xs" />
          <div className="flex-1 min-w-0">
            <div className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
              {currentUser.name}
            </div>
            <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
              {currentUser.title}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
