"use client";

import { type ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * Bloom empty state — soft organic blob illustration in muted brand tones.
 * Matches the warmth register everywhere else, including error/empty states.
 * (Spec §3.4 — empty states must NOT be cold/generic.)
 */
export function EmptyState({
  title,
  description,
  action,
  className,
  illustration = "leaf",
}: {
  title: string;
  description: string;
  action?: ReactNode;
  className?: string;
  illustration?: "leaf" | "sprout" | "wave" | "orbit";
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center text-center py-16 px-6",
        className
      )}
    >
      <OrganicBlob variant={illustration} />
      <h3 className="font-display text-xl font-medium text-[var(--text-primary)] mt-6">
        {title}
      </h3>
      <p className="text-[0.9375rem] text-[var(--text-secondary)] mt-2 max-w-md leading-relaxed">
        {description}
      </p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

function OrganicBlob({ variant }: { variant: "leaf" | "sprout" | "wave" | "orbit" }) {
  return (
    <svg
      width="120"
      height="120"
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="blob-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--accent-coral)" stopOpacity="0.25" />
          <stop offset="100%" stopColor="var(--status-lavender)" stopOpacity="0.15" />
        </linearGradient>
      </defs>
      {variant === "leaf" && (
        <>
          <path
            d="M30 70 Q 30 35 60 30 Q 90 35 90 70 Q 90 90 60 95 Q 30 90 30 70 Z"
            fill="url(#blob-grad)"
            stroke="var(--border-emphasis)"
            strokeWidth="1.2"
          />
          <path
            d="M60 30 Q 60 60 60 95"
            stroke="var(--accent-mint)"
            strokeWidth="1.2"
            strokeOpacity="0.5"
            fill="none"
          />
          <path
            d="M60 50 Q 70 45 75 50 M60 65 Q 70 60 80 65 M60 80 Q 70 75 78 80"
            stroke="var(--accent-mint)"
            strokeWidth="1"
            strokeOpacity="0.4"
            fill="none"
          />
        </>
      )}
      {variant === "sprout" && (
        <>
          <ellipse cx="60" cy="80" rx="35" ry="12" fill="url(#blob-grad)" />
          <path
            d="M60 80 Q 60 50 60 30"
            stroke="var(--accent-mint)"
            strokeWidth="1.5"
            fill="none"
          />
          <path
            d="M60 50 Q 45 45 40 35 Q 50 30 60 45"
            fill="url(#blob-grad)"
            stroke="var(--accent-mint)"
            strokeWidth="1.2"
          />
          <path
            d="M60 40 Q 75 35 80 25 Q 70 20 60 35"
            fill="url(#blob-grad)"
            stroke="var(--accent-mint)"
            strokeWidth="1.2"
          />
        </>
      )}
      {variant === "wave" && (
        <>
          <path
            d="M20 60 Q 35 40 50 60 Q 65 80 80 60 Q 95 40 110 60"
            stroke="var(--accent-coral)"
            strokeWidth="1.5"
            fill="none"
            strokeOpacity="0.6"
          />
          <path
            d="M20 70 Q 35 50 50 70 Q 65 90 80 70 Q 95 50 110 70"
            stroke="var(--accent-mint)"
            strokeWidth="1.5"
            fill="none"
            strokeOpacity="0.5"
          />
          <circle cx="60" cy="60" r="6" fill="var(--accent-coral)" fillOpacity="0.4" />
        </>
      )}
      {variant === "orbit" && (
        <>
          <circle cx="60" cy="60" r="14" fill="url(#blob-grad)" />
          <ellipse
            cx="60"
            cy="60"
            rx="35"
            ry="14"
            stroke="var(--accent-coral)"
            strokeWidth="1.2"
            fill="none"
            strokeOpacity="0.5"
            transform="rotate(-30 60 60)"
          />
          <ellipse
            cx="60"
            cy="60"
            rx="35"
            ry="14"
            stroke="var(--accent-mint)"
            strokeWidth="1.2"
            fill="none"
            strokeOpacity="0.5"
            transform="rotate(30 60 60)"
          />
          <circle cx="92" cy="48" r="3" fill="var(--accent-coral)" fillOpacity="0.7" />
          <circle cx="28" cy="72" r="3" fill="var(--accent-mint)" fillOpacity="0.7" />
        </>
      )}
    </svg>
  );
}

/** Bloom-shaped skeleton block — uses shimmer animation. */
export function Skeleton({ className }: { className?: string }) {
  return (
    <div className={cn("skeleton-shimmer rounded-[8px]", className)} aria-hidden="true" />
  );
}

/** Bloom-shaped error state — organic illustration + retry. */
export function ErrorState({
  title = "Something went wrong",
  description = "We couldn't load this view. Please try again.",
  onRetry,
  className,
}: {
  title?: string;
  description?: string;
  onRetry?: () => void;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center justify-center text-center py-16 px-6", className)}>
      <svg width="120" height="120" viewBox="0 0 120 120" fill="none" aria-hidden="true">
        <defs>
          <linearGradient id="err-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--status-brick)" stopOpacity="0.25" />
            <stop offset="100%" stopColor="var(--accent-coral)" stopOpacity="0.15" />
          </linearGradient>
        </defs>
        <path
          d="M30 70 Q 30 35 60 30 Q 90 35 90 70 Q 90 90 60 95 Q 30 90 30 70 Z"
          fill="url(#err-grad)"
          stroke="var(--border-emphasis)"
          strokeWidth="1.2"
        />
        <circle cx="48" cy="60" r="3" fill="var(--status-brick)" fillOpacity="0.8" />
        <circle cx="72" cy="60" r="3" fill="var(--status-brick)" fillOpacity="0.8" />
        <path
          d="M48 75 Q 60 70 72 75"
          stroke="var(--status-brick)"
          strokeWidth="1.5"
          strokeOpacity="0.6"
          fill="none"
          strokeLinecap="round"
        />
      </svg>
      <h3 className="font-display text-xl font-medium text-[var(--text-primary)] mt-6">
        {title}
      </h3>
      <p className="text-[0.9375rem] text-[var(--text-secondary)] mt-2 max-w-md leading-relaxed">
        {description}
      </p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-5 inline-flex h-9 items-center rounded-[8px] bg-[var(--accent-coral)] px-4 text-[0.8125rem] font-medium text-white hover:opacity-90 cursor-pointer transition-opacity"
        >
          Try again
        </button>
      )}
    </div>
  );
}
