"use client";

import { useState } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { useIsClient } from "@/hooks/use-is-client";

/**
 * Bloom avatar — real headshot photos, deterministic per employee.
 *
 * Uses pravatar.cc which serves a curated set of 70 real, diverse, professionally-lit
 * headshots. The seed determines which photo each person gets — same person always
 * gets the same photo (deterministic). Falls back to initials on load failure.
 *
 * Sizes follow the spec §3.6 scale:
 *   xs (24px) — table rows, kanban cards
 *   sm (32px) — list items
 *   md (48px) — org-chart node (default zoom)
 *   lg (64px) — profile card
 *   xl (96px) — person detail panel hero, profile page
 */

const sizeMap = {
  xs: 24,
  sm: 32,
  md: 48,
  lg: 64,
  xl: 96,
  "2xl": 128,
} as const;

type AvatarSize = keyof typeof sizeMap;

function initialsFrom(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

// Curated muted duotone backgrounds for the initials fallback (matches brand palette)
const fallbackPalette = [
  { from: "#F0674F", to: "#B3483D" },
  { from: "#0F8F6C", to: "#6157A6" },
  { from: "#B2740A", to: "#F0674F" },
  { from: "#6157A6", to: "#B3483D" },
  { from: "#0F8F6C", to: "#B2740A" },
  { from: "#7A6570", to: "#3D2233" },
  { from: "#F0674F", to: "#6157A6" },
  { from: "#0F8F6C", to: "#3D2233" },
];

function seedHash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export function Avatar({
  name,
  seed,
  size = "md",
  className,
  ring = false,
}: {
  name: string;
  seed: string;
  size?: AvatarSize;
  className?: string;
  ring?: boolean;
}) {
  const [failed, setFailed] = useState(false);
  const isClient = useIsClient();
  const px = sizeMap[size];
  const initials = initialsFrom(name);
  const palette = fallbackPalette[seedHash(seed) % fallbackPalette.length];
  const gradientId = `bloom-av-${seed.replace(/[^a-z0-9]/gi, "")}`;

  // pravatar.cc serves 70 real headshots. Use the hash to pick one deterministically.
  // img param accepts 1-70. Add size query param for crisp rendering on high-DPI.
  const pravatarId = (seedHash(seed) % 70) + 1;
  const src = `https://i.pravatar.cc/${px * 2}?img=${pravatarId}`;

  // SSR: render the initials fallback to avoid layout shift. On client hydration,
  // swap to the real image.
  if (!isClient || failed) {
    return (
      <span
        className={cn(
          "relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full select-none",
          ring && "ring-2 ring-[var(--accent-coral)] ring-offset-2 ring-offset-[var(--bg-base)]",
          className
        )}
        style={{ width: px, height: px }}
        aria-label={`Avatar for ${name}`}
        role="img"
      >
        <svg
          width={px}
          height={px}
          viewBox="0 0 96 96"
          xmlns="http://www.w3.org/2000/svg"
          className="absolute inset-0"
        >
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={palette.from} stopOpacity="0.9" />
              <stop offset="100%" stopColor={palette.to} stopOpacity="0.85" />
            </linearGradient>
          </defs>
          <rect width="96" height="96" fill={`url(#${gradientId})`} />
          <circle cx="48" cy="38" r="16" fill="rgba(255, 248, 240, 0.95)" />
          <path
            d="M 18 96 Q 18 64 48 64 Q 78 64 78 96 Z"
            fill="rgba(255, 248, 240, 0.95)"
          />
        </svg>
        <span
          className="relative z-10 font-semibold text-white"
          style={{ fontSize: px * 0.36 }}
        >
          {initials}
        </span>
      </span>
    );
  }

  return (
    <span
      className={cn(
        "relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full select-none bg-[var(--surface-alt)]",
        ring && "ring-2 ring-[var(--accent-coral)] ring-offset-2 ring-offset-[var(--bg-base)]",
        className
      )}
      style={{ width: px, height: px }}
      aria-label={`Avatar for ${name}`}
      role="img"
    >
      <Image
        src={src}
        alt={`Avatar for ${name}`}
        width={px}
        height={px}
        className="absolute inset-0 h-full w-full object-cover"
        onError={() => setFailed(true)}
        unoptimized
      />
    </span>
  );
}
