"use client";

import { useState, useCallback, type ReactNode } from "react";
import { PersonDetailPanel } from "./person-detail-panel";

/**
 * Hosts the PersonDetailPanel + exposes an `open(id)` callback via render-prop.
 * Wrap any page content; children get an `open` function they can call from
 * any clickable row/node/card.
 *
 * Usage:
 *   <PersonPanelHost>
 *     {({ open }) => <button onClick={() => open("e001")}>Open Maya</button>}
 *   </PersonPanelHost>
 */
export function PersonPanelHost({
  children,
}: {
  children: (api: { open: (id: string) => void }) => ReactNode;
}) {
  const [openId, setOpenId] = useState<string | null>(null);
  const open = useCallback((id: string) => setOpenId(id), []);
  const close = useCallback(() => setOpenId(null), []);

  return (
    <>
      {children({ open })}
      <PersonDetailPanel employeeId={openId} onClose={close} />
    </>
  );
}
