"use client";

import { useState, useCallback, type ReactNode } from "react";
import { Sidebar } from "./sidebar";
import { Header } from "./header";

/**
 * Bloom app shell — enterprise layout.
 *
 * Critical pattern: the root is `h-screen overflow-hidden`, so the body NEVER
 * scrolls. The sidebar is full viewport height and stays fixed. The content
 * column has its own `<main>` scroll container — only the main content scrolls,
 * the sidebar and header stay pinned. This is how every enterprise dashboard
 * (Linear, Notion, Vercel, Stripe) works.
 */
export function AppShell({ children }: { children: ReactNode }) {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const closeMobileNav = useCallback(() => setMobileNavOpen(false), []);
  const openMobileNav = useCallback(() => setMobileNavOpen(true), []);

  return (
    <div className="flex h-screen overflow-hidden bg-[var(--bg-base)] text-[var(--text-primary)]">
      <Sidebar mobileOpen={mobileNavOpen} onCloseMobile={closeMobileNav} />
      <div className="flex-1 flex flex-col min-w-0 h-screen">
        <Header onOpenMobileNav={openMobileNav} />
        <main className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}
