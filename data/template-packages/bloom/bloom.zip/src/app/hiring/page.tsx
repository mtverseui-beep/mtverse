import type { Metadata } from "next";
import { HiringClient } from "./hiring-client";

export const metadata: Metadata = {
  title: "Hiring — Pipeline",
  description:
    "A kanban view of every active candidate across Applied, Screening, Interview, Offer, and Hired stages. Drag to move, or use the keyboard.",
};

export default function HiringPage() {
  return <HiringClient />;
}
