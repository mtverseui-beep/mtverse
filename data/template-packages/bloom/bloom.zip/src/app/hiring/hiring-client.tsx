"use client";

import { useState, useMemo, useCallback } from "react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  useDraggable,
  useDroppable,
  closestCorners,
  type DragStartEvent,
  type DragEndEvent,
} from "@dnd-kit/core";
import { sortableKeyboardCoordinates } from "@dnd-kit/sortable";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { Plus, Check, X, Clock, AlertCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { PageHeader } from "@/components/bloom/page-header";
import { Avatar } from "@/components/bloom/avatar";
import { candidates as initialCandidates, type Candidate } from "@/data/demo";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

const STAGES: { id: Candidate["stage"]; label: string; accent: string }[] = [
  { id: "applied", label: "Applied", accent: "var(--text-secondary)" },
  { id: "screening", label: "Screening", accent: "var(--status-amber)" },
  { id: "interview", label: "Interview", accent: "var(--status-lavender)" },
  { id: "offer", label: "Offer", accent: "var(--accent-coral)" },
  { id: "hired", label: "Hired", accent: "var(--accent-mint)" },
];

const STAGE_ORDER: Candidate["stage"][] = ["applied", "screening", "interview", "offer", "hired"];

const addCandidateSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  roleAppliedFor: z.string().min(2, "Role is required"),
  stage: z.enum(["applied", "screening", "interview", "offer", "hired"]),
  source: z.string().min(2, "Source is required"),
});
type AddCandidateForm = z.infer<typeof addCandidateSchema>;

export function HiringClient() {
  const [candidates, setCandidates] = useState<Candidate[]>(initialCandidates);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const reduceMotion = useReducedMotion();

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 6 },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const activeCandidate = useMemo(
    () => candidates.find((c) => c.id === activeId) ?? null,
    [candidates, activeId]
  );

  const onDragStart = useCallback((e: DragStartEvent) => {
    setActiveId(String(e.active.id));
  }, []);

  const onDragEnd = useCallback(
    (e: DragEndEvent) => {
      setActiveId(null);
      const { active, over } = e;
      if (!over) return;
      const overId = String(over.id);
      // over.id can be a column id ("col:applied") or another card id
      const targetStage = overId.startsWith("col:")
        ? (overId.slice(4) as Candidate["stage"])
        : candidates.find((c) => c.id === overId)?.stage;
      if (!targetStage) return;
      const activeCard = candidates.find((c) => c.id === active.id);
      if (!activeCard || activeCard.stage === targetStage) return;

      // Offer stage confirmation (spec §3.7)
      if (targetStage === "offer") {
        const ok = window.confirm(
          `Move ${activeCard.name} to Offer stage?`
        );
        if (!ok) return;
      }

      setCandidates((prev) =>
        prev.map((c) =>
          c.id === activeCard.id
            ? { ...c, stage: targetStage, daysInStage: 0 }
            : c
        )
      );
      toast({
        title: `${activeCard.name} moved to ${STAGES.find((s) => s.id === targetStage)?.label}`,
        description: `Pipeline updated · ${activeCard.roleAppliedFor}`,
      });
    },
    [candidates]
  );

  const grouped = useMemo(() => {
    const map: Record<Candidate["stage"], Candidate[]> = {
      applied: [],
      screening: [],
      interview: [],
      offer: [],
      hired: [],
    };
    for (const c of candidates) map[c.stage].push(c);
    return map;
  }, [candidates]);

  const handleAdd = (data: AddCandidateForm) => {
    const newCandidate: Candidate = {
      id: `c${Date.now()}`,
      name: data.name,
      roleAppliedFor: data.roleAppliedFor,
      stage: data.stage,
      daysInStage: 0,
      avatarSeed: data.name.toLowerCase().replace(/\s+/g, "-"),
      source: data.source,
    };
    setCandidates((prev) => [...prev, newCandidate]);
    setAddDialogOpen(false);
    toast({
      title: `${data.name} added`,
      description: `Added to ${STAGES.find((s) => s.id === data.stage)?.label} stage`,
    });
  };

  return (
    <div className="px-6 py-6">
      <PageHeader
        eyebrow="Hiring pipeline"
        title="Pipeline"
        subtitle="Every active candidate, in one kanban view. Drag cards between stages, or use Tab + arrow keys for the keyboard equivalent."
        actions={
          <Button
            onClick={() => setAddDialogOpen(true)}
            className="bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90 rounded-[8px] h-9 cursor-pointer"
          >
            <Plus className="h-4 w-4 mr-1" strokeWidth={1.5} />
            Add candidate
          </Button>
        }
      />

      {/* Kanban board */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragStart={onDragStart}
        onDragEnd={onDragEnd}
      >
        <div className="mt-6 flex gap-4 overflow-x-auto pb-4">
          {STAGE_ORDER.map((stageId) => {
            const stage = STAGES.find((s) => s.id === stageId)!;
            const cards = grouped[stageId];
            return (
              <KanbanColumn
                key={stageId}
                stage={stage}
                cards={cards}
                onCardClick={(id) => {
                  const c = candidates.find((x) => x.id === id);
                  if (c) {
                    toast({
                      title: c.name,
                      description: `${c.roleAppliedFor} · ${c.source}`,
                    });
                  }
                }}
              />
            );
          })}
        </div>

        <DragOverlay>
          {activeCandidate ? (
            <KanbanCard
              candidate={activeCandidate}
              dragging
              reduceMotion={!!reduceMotion}
            />
          ) : null}
        </DragOverlay>
      </DndContext>

      {/* Keyboard helper bar */}
      <div className="mt-6 flex items-center gap-4 text-[0.75rem] text-[var(--text-tertiary)]">
        <span className="flex items-center gap-1.5">
          <kbd className="rounded-[4px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1.5 py-0.5 font-data">
            Tab
          </kbd>
          to focus a card
        </span>
        <span className="flex items-center gap-1.5">
          <kbd className="rounded-[4px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1.5 py-0.5 font-data">
            Space
          </kbd>
          to pick up
        </span>
        <span className="flex items-center gap-1.5">
          <kbd className="rounded-[4px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1.5 py-0.5 font-data">
            ← →
          </kbd>
          to move between stages
        </span>
        <span className="flex items-center gap-1.5">
          <kbd className="rounded-[4px] border border-[var(--border-default)] bg-[var(--surface-alt)] px-1.5 py-0.5 font-data">
            Space
          </kbd>
          to drop
        </span>
      </div>

      <AddCandidateDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onSubmit={handleAdd}
      />
    </div>
  );
}

/* ------------------------------- Column ------------------------------- */

function KanbanColumn({
  stage,
  cards,
  onCardClick,
}: {
  stage: { id: Candidate["stage"]; label: string; accent: string };
  cards: Candidate[];
  onCardClick: (id: string) => void;
}) {
  const { setNodeRef, isOver } = useDroppable({ id: `col:${stage.id}` });

  return (
    <div
      className={cn(
        "flex w-[280px] shrink-0 flex-col rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] transition-colors",
        isOver && "bg-[var(--surface-alt)] border-[var(--border-emphasis)]"
      )}
    >
      <div className="flex items-center justify-between gap-2 px-4 py-3 border-b border-[var(--border-default)]">
        <div className="flex items-center gap-2">
          <span
            className="inline-block h-2 w-2 rounded-full"
            style={{ background: stage.accent }}
            aria-hidden="true"
          />
          <span className="text-[0.8125rem] font-semibold text-[var(--text-primary)]">
            {stage.label}
          </span>
        </div>
        <span className="font-data text-[0.75rem] text-[var(--text-tertiary)] tabular-nums">
          {cards.length}
        </span>
      </div>
      <div
        ref={setNodeRef}
        className="flex-1 p-2 space-y-2 min-h-[200px]"
        aria-label={`${stage.label} column, ${cards.length} candidates`}
      >
        <AnimatePresence mode="popLayout">
          {cards.map((c) => (
            <DraggableCard
              key={c.id}
              candidate={c}
              onClick={() => onCardClick(c.id)}
            />
          ))}
        </AnimatePresence>
        {cards.length === 0 && (
          <div className="rounded-[12px] border border-dashed border-[var(--border-default)] p-6 text-center">
            <p className="text-[0.75rem] text-[var(--text-tertiary)]">
              Drop candidates here
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------- Card ------------------------------- */

function DraggableCard({
  candidate,
  onClick,
}: {
  candidate: Candidate;
  onClick: () => void;
}) {
  const reduceMotion = useReducedMotion();
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: candidate.id,
  });

  const style = transform
    ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
      }
    : undefined;

  return (
    <motion.div
      ref={setNodeRef}
      style={style}
      layout={!reduceMotion}
      initial={reduceMotion ? false : { opacity: 0, y: 6 }}
      animate={{ opacity: isDragging ? 0.4 : 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      {...attributes}
      {...listeners}
      onClick={(e) => {
        // Don't fire click if this was a drag
        if (e.detail === 0) return;
        e.stopPropagation();
        onClick();
      }}
      className={cn(
        "group rounded-[14px] border border-[var(--border-default)] bg-[var(--surface)] p-3 shadow-warm-sm",
        "hover:shadow-warm-md hover:border-[var(--border-emphasis)] cursor-grab active:cursor-grabbing",
        "transition-[box-shadow,border-color] duration-200",
        isDragging && "rotate-2 shadow-warm-lg"
      )}
      tabIndex={0}
      role="button"
      aria-label={`${candidate.name}, applied for ${candidate.roleAppliedFor}. ${candidate.daysInStage} days in ${candidate.stage} stage. Press space to pick up, arrow keys to move.`}
    >
      <div className="flex items-center gap-2.5">
        <Avatar name={candidate.name} seed={candidate.avatarSeed} size="xs" />
        <div className="min-w-0 flex-1">
          <div className="text-[0.8125rem] font-semibold text-[var(--text-primary)] truncate">
            {candidate.name}
          </div>
          <div className="text-[0.6875rem] text-[var(--text-secondary)] truncate">
            {candidate.roleAppliedFor}
          </div>
        </div>
      </div>
      <div className="mt-2 flex items-center justify-between text-[0.6875rem] text-[var(--text-tertiary)]">
        <span className="inline-flex items-center gap-1">
          <Clock className="h-3 w-3" strokeWidth={1.5} />
          <span className="font-data tabular-nums">{candidate.daysInStage}d</span>
        </span>
        <span>{candidate.source}</span>
      </div>
    </motion.div>
  );
}

function KanbanCard({
  candidate,
  dragging,
  reduceMotion,
}: {
  candidate: Candidate;
  dragging?: boolean;
  reduceMotion?: boolean;
}) {
  return (
    <div
      className={cn(
        "rounded-[14px] border border-[var(--border-emphasis)] bg-[var(--surface)] p-3 shadow-warm-lg",
        dragging && "rotate-2"
      )}
    >
      <div className="flex items-center gap-2.5">
        <Avatar name={candidate.name} seed={candidate.avatarSeed} size="xs" />
        <div className="min-w-0 flex-1">
          <div className="text-[0.8125rem] font-semibold text-[var(--text-primary)] truncate">
            {candidate.name}
          </div>
          <div className="text-[0.6875rem] text-[var(--text-secondary)] truncate">
            {candidate.roleAppliedFor}
          </div>
        </div>
      </div>
      <div className="mt-2 flex items-center justify-between text-[0.6875rem] text-[var(--text-tertiary)]">
        <span className="inline-flex items-center gap-1">
          <Clock className="h-3 w-3" strokeWidth={1.5} />
          <span className="font-data tabular-nums">{candidate.daysInStage}d</span>
        </span>
        <span>{candidate.source}</span>
      </div>
    </div>
  );
}

/* --------------------------- Add-candidate dialog --------------------------- */

function AddCandidateDialog({
  open,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSubmit: (data: AddCandidateForm) => void;
}) {
  const {
    register,
    handleSubmit,
    reset,
    setValue,
    control,
    formState: { errors, isSubmitting },
  } = useForm<AddCandidateForm>({
    resolver: zodResolver(addCandidateSchema),
    defaultValues: {
      name: "",
      roleAppliedFor: "",
      stage: "applied",
      source: "LinkedIn",
    },
  });

  const handleClose = (v: boolean) => {
    if (!v) reset();
    onOpenChange(v);
  };

  const stage = useWatch({ control, name: "stage" });

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md rounded-[18px] border-[var(--border-default)] bg-[var(--surface)]">
        <DialogHeader>
          <DialogTitle className="font-display text-xl font-medium">
            Add candidate
          </DialogTitle>
          <DialogDescription className="text-[var(--text-secondary)]">
            Create a new candidate card in the pipeline. All fields are validated.
          </DialogDescription>
        </DialogHeader>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="space-y-4 py-2"
          noValidate
        >
          <div className="space-y-1.5">
            <Label htmlFor="cand-name" className="text-[0.8125rem] font-medium">
              Full name
            </Label>
            <Input
              id="cand-name"
              {...register("name")}
              placeholder="e.g. Jordan Park"
              className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]"
              aria-invalid={!!errors.name}
            />
            {errors.name && (
              <p className="text-[0.75rem] text-[var(--status-brick)] flex items-center gap-1">
                <AlertCircle className="h-3 w-3" strokeWidth={1.5} />
                {errors.name.message}
              </p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cand-role" className="text-[0.8125rem] font-medium">
              Role applied for
            </Label>
            <Input
              id="cand-role"
              {...register("roleAppliedFor")}
              placeholder="e.g. Senior Software Engineer, Platform"
              className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]"
              aria-invalid={!!errors.roleAppliedFor}
            />
            {errors.roleAppliedFor && (
              <p className="text-[0.75rem] text-[var(--status-brick)] flex items-center gap-1">
                <AlertCircle className="h-3 w-3" strokeWidth={1.5} />
                {errors.roleAppliedFor.message}
              </p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cand-source" className="text-[0.8125rem] font-medium">
              Source
            </Label>
            <Input
              id="cand-source"
              {...register("source")}
              placeholder="LinkedIn, Referral, Careers Page…"
              className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]"
              aria-invalid={!!errors.source}
            />
            {errors.source && (
              <p className="text-[0.75rem] text-[var(--status-brick)] flex items-center gap-1">
                <AlertCircle className="h-3 w-3" strokeWidth={1.5} />
                {errors.source.message}
              </p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label className="text-[0.8125rem] font-medium">Initial stage</Label>
            <Select
              value={stage}
              onValueChange={(v) => setValue("stage", v as Candidate["stage"])}
            >
              <SelectTrigger className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]">
                {STAGE_ORDER.map((s) => (
                  <SelectItem key={s} value={s} className="capitalize">
                    {STAGES.find((x) => x.id === s)?.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter className="pt-2">
            <Button
              type="button"
              variant="ghost"
              onClick={() => handleClose(false)}
              className="rounded-[8px] cursor-pointer"
            >
              <X className="h-4 w-4 mr-1" strokeWidth={1.5} />
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90 rounded-[8px] cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <span className="mr-1 inline-block h-3 w-3 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  Adding…
                </>
              ) : (
                <>
                  <Check className="h-4 w-4 mr-1" strokeWidth={1.5} />
                  Add to pipeline
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
