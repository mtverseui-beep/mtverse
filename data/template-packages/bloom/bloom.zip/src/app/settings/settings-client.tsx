"use client";

import { useTheme } from "next-themes";
import { motion } from "framer-motion";
import { Check, User, Bell, Palette, Save, Shield, Plug, CreditCard, AlertTriangle, Lock, Key, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PageHeader } from "@/components/bloom/page-header";
import { Avatar } from "@/components/bloom/avatar";
import { brand } from "@/config/brand";
import { employees } from "@/data/demo";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { useLocalStorage } from "@/hooks/use-local-storage";

type Profile = {
  name: string;
  email: string;
  title: string;
  bio: string;
};

type Notifications = {
  emailDigest: boolean;
  reviewReminders: boolean;
  hiringUpdates: boolean;
  attritionAlerts: boolean;
  weeklyReport: boolean;
};

const DEFAULT_PROFILE: Profile = {
  name: employees[0].name,
  email: employees[0].email,
  title: employees[0].title,
  bio: employees[0].bio,
};

const DEFAULT_NOTIFICATIONS: Notifications = {
  emailDigest: true,
  reviewReminders: true,
  hiringUpdates: false,
  attritionAlerts: true,
  weeklyReport: true,
};

export function SettingsClient() {
  const { theme, setTheme } = useTheme();
  const currentUser = employees[0];

  // Persisted to localStorage — survives reloads, no backend required.
  const [profile, setProfile] = useLocalStorage<Profile>(
    "bloom-settings-profile",
    DEFAULT_PROFILE
  );
  const [notifications, setNotifications] = useLocalStorage<Notifications>(
    "bloom-settings-notifications",
    DEFAULT_NOTIFICATIONS
  );
  const [density, setDensity] = useLocalStorage<"comfortable" | "compact">(
    "bloom-settings-density",
    "comfortable"
  );

  const onToggleNotif = (key: keyof typeof notifications) => (v: boolean) =>
    setNotifications((prev) => ({ ...prev, [key]: v }));

  const onSaveProfile = () => {
    // The state is already persisted to localStorage on every keystroke via
    // useLocalStorage. This button gives a clear "saved" confirmation toast
    // so the user knows the change is durable.
    toast({
      title: "Profile saved",
      description: `Changes to ${profile.name} have been saved and will persist on reload.`,
    });
  };

  return (
    <div className="px-6 py-6 max-w-3xl">
      <PageHeader
        eyebrow="Settings"
        title="Settings"
        subtitle="Manage your profile, notifications, and the appearance of Bloom."
      />

      {/* Profile section */}
      <Section
        icon={User}
        title="Profile"
        description="Update how your name and bio appear to others in the workspace. Changes persist across reloads."
      >
        <div className="flex items-center gap-4 mb-5">
          <Avatar name={profile.name} seed={currentUser.avatarSeed} size="lg" />
          <div>
            <p className="text-[0.8125rem] font-medium text-[var(--text-primary)]">
              {profile.name}
            </p>
            <p className="text-[0.75rem] text-[var(--text-tertiary)] mt-0.5">
              Avatar is generated deterministically from the name. To change it,
              update your name above.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="set-name" className="text-[0.8125rem] font-medium">
              Full name
            </Label>
            <Input
              id="set-name"
              value={profile.name}
              onChange={(e) => setProfile((p) => ({ ...p, name: e.target.value }))}
              className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="set-email" className="text-[0.8125rem] font-medium">
              Email
            </Label>
            <Input
              id="set-email"
              type="email"
              value={profile.email}
              onChange={(e) => setProfile((p) => ({ ...p, email: e.target.value }))}
              className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]"
            />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="set-title" className="text-[0.8125rem] font-medium">
              Title
            </Label>
            <Input
              id="set-title"
              value={profile.title}
              onChange={(e) => setProfile((p) => ({ ...p, title: e.target.value }))}
              className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]"
            />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="set-bio" className="text-[0.8125rem] font-medium">
              Bio
            </Label>
            <Textarea
              id="set-bio"
              value={profile.bio}
              onChange={(e) => setProfile((p) => ({ ...p, bio: e.target.value }))}
              rows={3}
              className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)] resize-none"
            />
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <Button
            onClick={onSaveProfile}
            className="bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90 rounded-[8px] h-9 cursor-pointer"
          >
            <Save className="h-4 w-4 mr-1" strokeWidth={1.5} />
            Save profile
          </Button>
        </div>
      </Section>

      {/* Notifications section */}
      <Section
        icon={Bell}
        title="Notifications"
        description="Choose what Bloom should email you about. Changes apply immediately."
      >
        <div className="space-y-1">
          <NotifRow
            label="Email digest"
            description="A daily summary of review activity, hiring changes, and attrition alerts."
            checked={notifications.emailDigest}
            onCheckedChange={onToggleNotif("emailDigest")}
          />
          <NotifRow
            label="Review reminders"
            description="A nudge three days before any review you're assigned to is due."
            checked={notifications.reviewReminders}
            onCheckedChange={onToggleNotif("reviewReminders")}
          />
          <NotifRow
            label="Hiring updates"
            description="When a candidate moves to Offer or Hired in your department."
            checked={notifications.hiringUpdates}
            onCheckedChange={onToggleNotif("hiringUpdates")}
          />
          <NotifRow
            label="Attrition alerts"
            description="When a person's flight-risk score crosses 25."
            checked={notifications.attritionAlerts}
            onCheckedChange={onToggleNotif("attritionAlerts")}
          />
          <NotifRow
            label="Weekly report"
            description="A Monday-morning snapshot of last week's people-ops activity."
            checked={notifications.weeklyReport}
            onCheckedChange={onToggleNotif("weeklyReport")}
          />
        </div>
      </Section>

      {/* Appearance section */}
      <Section
        icon={Palette}
        title="Appearance"
        description="Switch between light and dark. Bloom remembers your choice."
      >
        <div className="grid grid-cols-2 gap-3">
          <ThemeCard
            label="Light"
            description="Warm cream — the default"
            active={theme === "light"}
            onClick={() => setTheme("light")}
            preview={
              <div className="h-16 w-full rounded-[10px] bg-[#FFF8F0] border border-[#F1E4D8] flex items-center justify-center">
                <div className="h-8 w-8 rounded-full bg-[#F0674F]" />
              </div>
            }
          />
          <ThemeCard
            label="Dark"
            description="Deep plum — fully designed"
            active={theme === "dark"}
            onClick={() => setTheme("dark")}
            preview={
              <div className="h-16 w-full rounded-[10px] bg-[#211621] border border-[#453143] flex items-center justify-center">
                <div className="h-8 w-8 rounded-full bg-[#FF9585]" />
              </div>
            }
          />
        </div>

        <div className="mt-5 space-y-1.5">
          <Label className="text-[0.8125rem] font-medium">Density</Label>
          <Select value={density} onValueChange={(v) => setDensity(v as "comfortable" | "compact")}>
            <SelectTrigger className="w-[200px] h-9 rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]">
              <SelectItem value="comfortable">Comfortable</SelectItem>
              <SelectItem value="compact">Compact</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-[0.75rem] text-[var(--text-tertiary)]">
            Compact mode tightens table padding and sidebar spacing.
          </p>
        </div>
      </Section>

      {/* Security section */}
      <Section
        icon={Shield}
        title="Security"
        description="Manage your password, two-factor authentication, and active sessions."
      >
        <div className="space-y-4">
          {/* Password */}
          <div className="flex items-center justify-between gap-4 py-3 border-b border-[var(--border-default)]">
            <div className="flex items-center gap-3 min-w-0">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] bg-[var(--surface-alt)] text-[var(--text-secondary)] shrink-0">
                <Lock className="h-4 w-4" strokeWidth={1.5} />
              </span>
              <div className="min-w-0">
                <p className="text-[0.875rem] font-medium text-[var(--text-primary)]">Password</p>
                <p className="text-[0.75rem] text-[var(--text-tertiary)]">Last changed 3 months ago</p>
              </div>
            </div>
            <Button
              variant="outline"
              className="h-8 rounded-[8px] cursor-pointer shrink-0"
              onClick={() => toast({ title: "Password reset link sent", description: "Check your email for a reset link." })}
            >
              Change password
            </Button>
          </div>

          {/* 2FA */}
          <div className="flex items-center justify-between gap-4 py-3 border-b border-[var(--border-default)]">
            <div className="flex items-center gap-3 min-w-0">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] bg-[var(--surface-alt)] text-[var(--text-secondary)] shrink-0">
                <Key className="h-4 w-4" strokeWidth={1.5} />
              </span>
              <div className="min-w-0">
                <p className="text-[0.875rem] font-medium text-[var(--text-primary)]">Two-factor authentication</p>
                <p className="text-[0.75rem] text-[var(--text-tertiary)]">
                  <span className="text-[var(--accent-mint)] font-medium">Enabled</span> · via authenticator app
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              className="h-8 rounded-[8px] cursor-pointer shrink-0"
              onClick={() => toast({ title: "2FA settings", description: "Opens the 2FA configuration flow." })}
            >
              Manage
            </Button>
          </div>

          {/* Active sessions */}
          <div className="py-3">
            <p className="text-[0.875rem] font-medium text-[var(--text-primary)] mb-2">Active sessions</p>
            <ul className="space-y-2">
              {[
                { device: "MacBook Pro · Chrome", location: "San Francisco, CA", current: true, time: "Active now" },
                { device: "iPhone 15 · Safari", location: "San Francisco, CA", current: false, time: "2 hours ago" },
              ].map((session) => (
                <li key={session.device} className="flex items-center justify-between gap-3 rounded-[10px] border border-[var(--border-default)] p-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
                        {session.device}
                      </span>
                      {session.current && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-[var(--accent-mint-soft)] text-[var(--accent-mint)] px-1.5 py-0 text-[0.625rem] font-medium">
                          <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent-mint)]" />
                          Current
                        </span>
                      )}
                    </div>
                    <div className="text-[0.6875rem] text-[var(--text-tertiary)] mt-0.5">
                      {session.location} · {session.time}
                    </div>
                  </div>
                  {!session.current && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 rounded-[6px] text-[var(--status-brick)] hover:bg-[var(--status-brick-soft)] cursor-pointer shrink-0"
                      onClick={() => toast({ title: "Session revoked", description: `Signed out of ${session.device}.` })}
                    >
                      Revoke
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      {/* Integrations section */}
      <Section
        icon={Plug}
        title="Integrations"
        description="Connect Bloom with your favorite tools. Toggles persist across reloads."
      >
        <IntegrationsGrid />
      </Section>

      {/* Billing section */}
      <Section
        icon={CreditCard}
        title="Billing"
        description="Manage your subscription, payment method, and usage."
      >
        <div className="space-y-4">
          {/* Current plan */}
          <div className="rounded-[14px] border border-[var(--accent-coral)]/30 bg-[var(--accent-coral-soft)] p-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="eyebrow text-[var(--accent-coral)]">Current plan</p>
                <p className="font-display text-xl font-medium text-[var(--text-primary)] mt-1">
                  Enterprise
                </p>
                <p className="text-[0.8125rem] text-[var(--text-secondary)] mt-1">
                  $24/user/month · 54 seats · billed annually
                </p>
              </div>
              <Button
                className="bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90 h-8 rounded-[8px] cursor-pointer shrink-0"
                onClick={() => toast({ title: "Manage plan", description: "Opens the billing portal." })}
              >
                Manage plan
              </Button>
            </div>
          </div>

          {/* Usage */}
          <div>
            <p className="text-[0.875rem] font-medium text-[var(--text-primary)] mb-3">Usage this billing cycle</p>
            <div className="space-y-3">
              <UsageBar label="Seats" used={54} total={60} format="count" />
              <UsageBar label="Storage" used={4.2} total={10} format="GB" />
              <UsageBar label="API calls" used={12400} total={25000} format="count" />
            </div>
          </div>

          {/* Payment method */}
          <div className="flex items-center justify-between gap-4 py-3 border-t border-[var(--border-default)]">
            <div className="flex items-center gap-3 min-w-0">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] bg-[var(--surface-alt)] text-[var(--text-secondary)] shrink-0">
                <CreditCard className="h-4 w-4" strokeWidth={1.5} />
              </span>
              <div className="min-w-0">
                <p className="text-[0.875rem] font-medium text-[var(--text-primary)]">Visa ending in 4242</p>
                <p className="text-[0.75rem] text-[var(--text-tertiary)]">Expires 08/2027</p>
              </div>
            </div>
            <Button
              variant="outline"
              className="h-8 rounded-[8px] cursor-pointer shrink-0"
              onClick={() => toast({ title: "Payment method", description: "Opens the Stripe payment portal." })}
            >
              Update
            </Button>
          </div>
        </div>
      </Section>

      {/* Danger zone */}
      <Section
        icon={AlertTriangle}
        title="Danger zone"
        description="Irreversible actions. Proceed with caution."
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-4 py-3 border-b border-[var(--border-default)]">
            <div className="min-w-0">
              <p className="text-[0.875rem] font-medium text-[var(--text-primary)]">Export all data</p>
              <p className="text-[0.75rem] text-[var(--text-tertiary)]">Download a ZIP of your profile, settings, and activity.</p>
            </div>
            <Button
              variant="outline"
              className="h-8 rounded-[8px] cursor-pointer shrink-0"
              onClick={() => toast({ title: "Export started", description: "You'll receive an email when the ZIP is ready." })}
            >
              <ExternalLink className="h-3.5 w-3.5 mr-1" strokeWidth={1.5} />
              Export
            </Button>
          </div>
          <div className="flex items-center justify-between gap-4 py-3">
            <div className="min-w-0">
              <p className="text-[0.875rem] font-medium text-[var(--status-brick)]">Delete account</p>
              <p className="text-[0.75rem] text-[var(--text-tertiary)]">Permanently delete your Bloom account and all associated data.</p>
            </div>
            <Button
              className="bg-[var(--status-brick)] text-white hover:bg-[var(--status-brick)]/90 h-8 rounded-[8px] cursor-pointer shrink-0"
              onClick={() => {
                if (window.confirm("Are you sure? This action cannot be undone.")) {
                  toast({ title: "Account deletion requested", description: "Contact hello@bloom.template to complete deletion." });
                }
              }}
            >
              Delete account
            </Button>
          </div>
        </div>
      </Section>

      {/* About section */}
      <Section
        icon={Check}
        title="About Bloom"
        description={`The ${brand.name} template · v1.0.0`}
      >
        <p className="text-[0.875rem] text-[var(--text-secondary)] leading-relaxed">
          {brand.name} is a premium People Operations dashboard template — org structure,
          hiring pipeline, employee directory, attrition analytics, and performance reviews.
          Tagline: <em className="text-[var(--text-primary)]">“{brand.tagline}”</em>
        </p>
        <p className="text-[0.75rem] text-[var(--text-tertiary)] mt-3">
          Support: <a href={`mailto:${brand.contactEmail}`} className="text-[var(--accent-coral)] hover:underline">{brand.contactEmail}</a>
        </p>
      </Section>
    </div>
  );
}

function Section({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="mt-6 rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] p-6"
    >
      <div className="flex items-start gap-3 mb-5">
        <span className="inline-flex h-9 w-9 items-center justify-center rounded-[10px] bg-[var(--surface-alt)] text-[var(--accent-coral)] shrink-0">
          <Icon className="h-4 w-4" strokeWidth={1.5} />
        </span>
        <div>
          <h2 className="font-display text-lg font-medium text-[var(--text-primary)]">
            {title}
          </h2>
          <p className="text-[0.8125rem] text-[var(--text-secondary)] mt-0.5">
            {description}
          </p>
        </div>
      </div>
      {children}
    </motion.section>
  );
}

function NotifRow({
  label,
  description,
  checked,
  onCheckedChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-start gap-4 py-3 border-b border-[var(--border-default)] last:border-b-0">
      <div className="flex-1 min-w-0">
        <p className="text-[0.875rem] font-medium text-[var(--text-primary)]">{label}</p>
        <p className="text-[0.75rem] text-[var(--text-secondary)] mt-0.5">{description}</p>
      </div>
      <Switch
        checked={checked}
        onCheckedChange={onCheckedChange}
        aria-label={label}
        className="data-[state=checked]:bg-[var(--accent-coral)] cursor-pointer"
      />
    </div>
  );
}

function ThemeCard({
  label,
  description,
  active,
  onClick,
  preview,
}: {
  label: string;
  description: string;
  active: boolean;
  onClick: () => void;
  preview: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "flex flex-col gap-2 rounded-[14px] border p-3 text-left cursor-pointer transition-colors",
        active
          ? "border-[var(--accent-coral)] bg-[var(--accent-coral-soft)]"
          : "border-[var(--border-default)] bg-[var(--surface)] hover:bg-[var(--surface-alt)]"
      )}
    >
      {preview}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[0.875rem] font-medium text-[var(--text-primary)]">{label}</p>
          <p className="text-[0.6875rem] text-[var(--text-tertiary)]">{description}</p>
        </div>
        {active && (
          <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-[var(--accent-coral)] text-white">
            <Check className="h-3 w-3" strokeWidth={2} />
          </span>
        )}
      </div>
    </button>
  );
}

/* ------------------------- Integrations ------------------------- */

type Integration = {
  id: string;
  name: string;
  description: string;
  icon: string; // emoji or letter
  color: string;
  connected: boolean;
};

const DEFAULT_INTEGRATIONS: Integration[] = [
  { id: "slack", name: "Slack", description: "Send review reminders and hiring updates to Slack channels.", icon: "#", color: "#611f69", connected: true },
  { id: "github", name: "GitHub", description: "Link pull requests to employees and track engineering output.", icon: "G", color: "#181717", connected: true },
  { id: "google-calendar", name: "Google Calendar", description: "Sync review cycles and time-off requests to calendars.", icon: "C", color: "#4285f4", connected: false },
  { id: "bamboohr", name: "BambooHR", description: "Two-way sync of employee data, headcount, and status changes.", icon: "B", color: "#73c41d", connected: false },
  { id: "绿洲", name: "Greenhouse", description: "Push hired candidates from Bloom's pipeline to Greenhouse onboarding.", icon: "G", color: "#00a859", connected: true },
  { id: "ldesks", name: "Lattice", description: "Sync performance review data and 360° feedback cycles.", icon: "L", color: "#3a3a3a", connected: false },
];

function IntegrationsGrid() {
  const [integrations, setIntegrations] = useLocalStorage<Integration[]>(
    "bloom-settings-integrations",
    DEFAULT_INTEGRATIONS
  );

  const toggle = (id: string) => {
    setIntegrations((prev) =>
      prev.map((i) => (i.id === id ? { ...i, connected: !i.connected } : i))
    );
    const integration = integrations.find((i) => i.id === id);
    if (integration) {
      toast({
        title: integration.connected ? `${integration.name} disconnected` : `${integration.name} connected`,
        description: integration.connected
          ? `Bloom will no longer sync with ${integration.name}.`
          : `Bloom is now syncing with ${integration.name}.`,
      });
    }
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {integrations.map((integration) => (
        <div
          key={integration.id}
          className="flex items-start gap-3 rounded-[14px] border border-[var(--border-default)] p-4"
        >
          <span
            className="inline-flex h-10 w-10 items-center justify-center rounded-[10px] text-white font-bold text-lg shrink-0"
            style={{ backgroundColor: integration.color }}
          >
            {integration.icon}
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="text-[0.875rem] font-medium text-[var(--text-primary)]">
                {integration.name}
              </p>
              {integration.connected && (
                <span className="inline-flex items-center gap-1 rounded-full bg-[var(--accent-mint-soft)] text-[var(--accent-mint)] px-1.5 py-0 text-[0.625rem] font-medium">
                  <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent-mint)]" />
                  Connected
                </span>
              )}
            </div>
            <p className="text-[0.75rem] text-[var(--text-tertiary)] mt-1 leading-relaxed">
              {integration.description}
            </p>
            <Button
              variant={integration.connected ? "outline" : "default"}
              size="sm"
              className={cn(
                "mt-3 h-7 rounded-[6px] cursor-pointer text-[0.75rem]",
                !integration.connected && "bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90"
              )}
              onClick={() => toggle(integration.id)}
            >
              {integration.connected ? "Disconnect" : "Connect"}
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ------------------------- Usage bar ------------------------- */

function UsageBar({
  label,
  used,
  total,
  format,
}: {
  label: string;
  used: number;
  total: number;
  format: "count" | "GB";
}) {
  const pct = Math.min(100, (used / total) * 100);
  const formatValue = (v: number) =>
    format === "GB" ? `${v.toFixed(1)} GB` : v.toLocaleString();

  return (
    <div>
      <div className="flex justify-between text-[0.75rem] mb-1.5">
        <span className="text-[var(--text-secondary)]">{label}</span>
        <span className="font-data text-[var(--text-tertiary)] tabular-nums">
          {formatValue(used)} / {formatValue(total)}
        </span>
      </div>
      <div className="h-1.5 rounded-full bg-[var(--surface-alt)] overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${pct}%` }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className={cn(
            "h-full rounded-full",
            pct > 85
              ? "bg-[var(--status-brick)]"
              : pct > 60
                ? "bg-[var(--status-amber)]"
                : "bg-[var(--accent-mint)]"
          )}
        />
      </div>
    </div>
  );
}
