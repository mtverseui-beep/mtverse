import type { Metadata } from "next";
import { SettingsClient } from "./settings-client";

export const metadata: Metadata = {
  title: "Settings",
  description:
    "Manage your profile, notification preferences, and the appearance of the Bloom dashboard.",
};

export default function SettingsPage() {
  return <SettingsClient />;
}
