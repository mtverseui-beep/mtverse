import type { Metadata, Viewport } from "next";
import { Fraunces, Plus_Jakarta_Sans, Geist_Mono } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { AppShell } from "@/components/bloom/app-shell";
import { Toaster } from "@/components/ui/toaster";
import { cn } from "@/lib/utils";

const fontFraunces = Fraunces({
  variable: "--font-fraunces",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  display: "swap",
});

const fontJakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const fontGeistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  weight: ["400", "500"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Bloom — Know your people, not just your headcount",
    template: "%s · Bloom",
  },
  description:
    "Bloom is a warm, human, and precise People Operations dashboard — org structure, hiring pipeline, employee directory, attrition analytics, and performance reviews.",
  keywords: [
    "HR dashboard",
    "people operations",
    "org chart",
    "HR analytics",
    "admin template",
    "Bloom",
  ],
  authors: [{ name: "Bloom" }],
  applicationName: "Bloom",
  icons: {
    icon: "/favicon.svg",
    apple: "/favicon.svg",
  },
  openGraph: {
    title: "Bloom — Know your people, not just your headcount",
    description:
      "Warm, human, precise People Operations dashboard with a real interactive org chart at its center.",
    siteName: "Bloom",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Bloom — People Operations Dashboard",
    description: "Warm, human, precise HR software that doesn't feel like HR software.",
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#FFF8F0" },
    { media: "(prefers-color-scheme: dark)", color: "#211621" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={cn(
          fontFraunces.variable,
          fontJakarta.variable,
          fontGeistMono.variable,
          "antialiased min-h-screen bg-[var(--bg-base)] text-[var(--text-primary)]"
        )}
      >
        <ThemeProvider>
          <AppShell>{children}</AppShell>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
