"use client";

import { useState, useMemo, useCallback } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  Search,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Download,
  Tag,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  X,
  Mail,
  Phone,
  MapPin,
  ChevronRight as ChevronRightIcon,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/bloom/page-header";
import { Avatar } from "@/components/bloom/avatar";
import {
  StatusBadge,
  statusVariantForEmployee,
  statusLabelForEmployee,
} from "@/components/bloom/status-badge";
import { PersonPanelHost } from "@/components/bloom/person-panel-host";
import {
  employees as allEmployees,
  type Department,
  type Employee,
  getManagerChain,
} from "@/data/demo";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

const DEPARTMENTS: Department[] = [
  "Engineering",
  "Design",
  "Sales",
  "Marketing",
  "People",
  "Finance",
];

type SortKey = "name" | "title" | "department" | "tenureYears" | "flightRisk";
type SortDir = "asc" | "desc";

const PAGE_SIZE = 10;

const DEPARTMENT_LIST: (Department | "all")[] = [
  "all",
  "Engineering",
  "Design",
  "Sales",
  "Marketing",
  "People",
  "Finance",
];
const STATUS_LIST: ("all" | "active" | "on_leave" | "new_hire")[] = [
  "all",
  "active",
  "on_leave",
  "new_hire",
];

export function PeopleClient() {
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState<Department | "all">("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "on_leave" | "new_hire">("all");
  const [locationFilter, setLocationFilter] = useState<string>("all");
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortDir, setSortDir] = useState<SortDir>("asc");
  const [page, setPage] = useState(0);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [tags, setTags] = useState<Map<string, string>>(new Map());
  const reduceMotion = useReducedMotion();

  // Build the location filter list dynamically
  const locations = useMemo(() => {
    const set = new Set<string>();
    for (const e of allEmployees) {
      // group by city — extract first part before comma
      const city = e.location.split(",")[0].trim();
      set.add(city);
    }
    return ["all", ...Array.from(set).sort()];
  }, []);

  const filtered = useMemo(() => {
    let result = allEmployees.filter((e) => {
      if (deptFilter !== "all" && e.department !== deptFilter) return false;
      if (statusFilter !== "all" && e.status !== statusFilter) return false;
      if (locationFilter !== "all" && !e.location.startsWith(locationFilter)) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        if (
          !e.name.toLowerCase().includes(q) &&
          !e.title.toLowerCase().includes(q) &&
          !e.email.toLowerCase().includes(q) &&
          !e.department.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      return true;
    });
    result = [...result].sort((a, b) => {
      const dir = sortDir === "asc" ? 1 : -1;
      const av = a[sortKey];
      const bv = b[sortKey];
      if (typeof av === "string" && typeof bv === "string") {
        return av.localeCompare(bv) * dir;
      }
      return ((av as number) - (bv as number)) * dir;
    });
    return result;
  }, [search, deptFilter, statusFilter, locationFilter, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);
  const pageRows = filtered.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const allOnPageSelected = pageRows.length > 0 && pageRows.every((r) => selectedIds.has(r.id));
  const toggleSelectAll = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allOnPageSelected) {
        for (const r of pageRows) next.delete(r.id);
      } else {
        for (const r of pageRows) next.add(r.id);
      }
      return next;
    });
  };
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const onClearFilters = () => {
    setSearch("");
    setDeptFilter("all");
    setStatusFilter("all");
    setLocationFilter("all");
    setPage(0);
  };

  const hasActiveFilters =
    search.trim() !== "" ||
    deptFilter !== "all" ||
    statusFilter !== "all" ||
    locationFilter !== "all";

  return (
    <PersonPanelHost>
      {({ open }) => (
        <div className="px-6 py-6">
          <PageHeader
            eyebrow="Employee directory"
            title="People"
            subtitle={`${allEmployees.length} people across ${DEPARTMENTS.length} departments. Filter, sort, expand a row, or open a full profile.`}
          />

          {/* filter bar */}
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[220px]">
              <Search
                className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--text-tertiary)]"
                strokeWidth={1.5}
              />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(0);
                }}
                placeholder="Search by name, title, email…"
                className="pl-9 rounded-[8px] border-[var(--border-default)] bg-[var(--surface)] h-9"
                aria-label="Search employees"
              />
            </div>
            <Select
              value={deptFilter}
              onValueChange={(v) => {
                setDeptFilter(v as Department | "all");
                setPage(0);
              }}
            >
              <SelectTrigger className="w-[160px] h-9 rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent className="rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]">
                {DEPARTMENT_LIST.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d === "all" ? "All departments" : d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={statusFilter}
              onValueChange={(v) => {
                setStatusFilter(v as typeof statusFilter);
                setPage(0);
              }}
            >
              <SelectTrigger className="w-[140px] h-9 rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]">
                {STATUS_LIST.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s === "all"
                      ? "All statuses"
                      : s === "on_leave"
                        ? "On leave"
                        : s === "new_hire"
                          ? "New hire"
                          : "Active"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={locationFilter}
              onValueChange={(v) => {
                setLocationFilter(v);
                setPage(0);
              }}
            >
              <SelectTrigger className="w-[160px] h-9 rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent className="rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]">
                {locations.map((l) => (
                  <SelectItem key={l} value={l}>
                    {l === "all" ? "All locations" : l}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {hasActiveFilters && (
              <Button
                variant="ghost"
                onClick={onClearFilters}
                className="h-9 rounded-[8px] text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
              >
                <X className="h-4 w-4 mr-1" strokeWidth={1.5} />
                Clear
              </Button>
            )}
          </div>

          {/* bulk action bar */}
          <AnimatePresence>
            {selectedIds.size > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: reduceMotion ? 0 : 0.18 }}
                className="mt-3 flex items-center gap-3 rounded-[12px] border border-[var(--accent-coral)]/30 bg-[var(--accent-coral-soft)] px-4 py-2.5"
              >
                <span className="text-[0.8125rem] font-medium text-[var(--text-primary)]">
                  <span className="font-data tabular-nums">{selectedIds.size}</span>{" "}
                  {selectedIds.size === 1 ? "person" : "people"} selected
                </span>
                <div className="ml-auto flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 rounded-[8px] cursor-pointer"
                    onClick={() => {
                      // Real CSV export — generates a downloadable file from the selection.
                      const selected = allEmployees.filter((e) => selectedIds.has(e.id));
                      const headers = ["Name", "Title", "Department", "Email", "Location", "Status", "Tenure (years)"];
                      const rows = selected.map((e) => [
                        e.name,
                        e.title,
                        e.department,
                        e.email,
                        e.location,
                        e.status,
                        e.tenureYears.toString(),
                      ]);
                      const csv = [
                        headers.join(","),
                        ...rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(",")),
                      ].join("\n");
                      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement("a");
                      a.href = url;
                      a.download = `bloom-people-export-${new Date().toISOString().slice(0, 10)}.csv`;
                      document.body.appendChild(a);
                      a.click();
                      document.body.removeChild(a);
                      URL.revokeObjectURL(url);
                      toast({
                        title: `Exported ${selected.length} ${selected.length === 1 ? "profile" : "profiles"}`,
                        description: `CSV downloaded to your device.`,
                      });
                    }}
                  >
                    <Download className="h-3.5 w-3.5 mr-1" strokeWidth={1.5} />
                    Export CSV
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 rounded-[8px] cursor-pointer"
                    onClick={() => {
                      // Real tag application — adds a visible tag badge to selected rows.
                      const ids = Array.from(selectedIds);
                      setTags((prev) => {
                        const next = new Map(prev);
                        for (const id of ids) {
                          next.set(id, "review-priority");
                        }
                        return next;
                      });
                      toast({
                        title: `Tag applied`,
                        description: `Added "review-priority" tag to ${ids.length} ${ids.length === 1 ? "person" : "people"}.`,
                      });
                      setSelectedIds(new Set());
                    }}
                  >
                    <Tag className="h-3.5 w-3.5 mr-1" strokeWidth={1.5} />
                    Tag as review-priority
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 rounded-[8px] text-[var(--text-secondary)] cursor-pointer"
                    onClick={() => setSelectedIds(new Set())}
                  >
                    Clear
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* table */}
          <div className="mt-4 rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-[0.875rem]">
                <thead>
                  <tr className="border-b border-[var(--border-default)] bg-[var(--surface-alt)]">
                    <th className="w-10 px-4 py-3">
                      <Checkbox
                        checked={allOnPageSelected}
                        onCheckedChange={toggleSelectAll}
                        aria-label="Select all on page"
                      />
                    </th>
                    <SortableTh
                      label="Name"
                      active={sortKey === "name"}
                      dir={sortDir}
                      onClick={() => toggleSort("name")}
                    />
                    <SortableTh
                      label="Title"
                      active={sortKey === "title"}
                      dir={sortDir}
                      onClick={() => toggleSort("title")}
                    />
                    <SortableTh
                      label="Dept"
                      active={sortKey === "department"}
                      dir={sortDir}
                      onClick={() => toggleSort("department")}
                    />
                    <SortableTh
                      label="Tenure"
                      active={sortKey === "tenureYears"}
                      dir={sortDir}
                      onClick={() => toggleSort("tenureYears")}
                      align="right"
                    />
                    <SortableTh
                      label="Risk"
                      active={sortKey === "flightRisk"}
                      dir={sortDir}
                      onClick={() => toggleSort("flightRisk")}
                      align="right"
                    />
                    <th className="px-4 py-3 text-left text-[0.6875rem] uppercase tracking-wide font-semibold text-[var(--text-tertiary)]">
                      Status
                    </th>
                    <th className="w-10" />
                  </tr>
                </thead>
                <tbody>
                  {pageRows.map((row) => {
                    const isSelected = selectedIds.has(row.id);
                    const isExpanded = expandedId === row.id;
                    const tag = tags.get(row.id);
                    return (
                      <RowFragment
                        key={row.id}
                        employee={row}
                        isSelected={isSelected}
                        isExpanded={isExpanded}
                        tag={tag}
                        onToggleSelect={() => toggleSelect(row.id)}
                        onToggleExpand={() =>
                          setExpandedId((v) => (v === row.id ? null : row.id))
                        }
                        onOpen={() => open(row.id)}
                        onRemoveTag={() => {
                          setTags((prev) => {
                            const next = new Map(prev);
                            next.delete(row.id);
                            return next;
                          });
                          toast({
                            title: "Tag removed",
                            description: `"review-priority" tag removed from ${row.name}.`,
                          });
                        }}
                      />
                    );
                  })}
                  {pageRows.length === 0 && (
                    <tr>
                      <td colSpan={8}>
                        <div className="py-12 text-center">
                          <p className="font-display text-lg font-medium text-[var(--text-primary)]">
                            No matches
                          </p>
                          <p className="text-[0.875rem] text-[var(--text-secondary)] mt-1">
                            Try a different search or clear the filters.
                          </p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* pagination */}
            <div className="flex items-center justify-between gap-2 border-t border-[var(--border-default)] px-4 py-3">
              <p className="text-[0.75rem] text-[var(--text-tertiary)]">
                Showing{" "}
                <span className="font-data tabular-nums text-[var(--text-secondary)]">
                  {filtered.length === 0 ? 0 : safePage * PAGE_SIZE + 1}–
                  {Math.min((safePage + 1) * PAGE_SIZE, filtered.length)}
                </span>{" "}
                of{" "}
                <span className="font-data tabular-nums text-[var(--text-secondary)]">
                  {filtered.length}
                </span>
              </p>
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 rounded-[8px] cursor-pointer"
                  disabled={safePage === 0}
                  onClick={() => setPage((p) => Math.max(0, p - 1))}
                  aria-label="Previous page"
                >
                  <ChevronLeft className="h-4 w-4" strokeWidth={1.5} />
                </Button>
                <span className="font-data text-[0.75rem] text-[var(--text-secondary)] tabular-nums px-2">
                  {safePage + 1} / {totalPages}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 rounded-[8px] cursor-pointer"
                  disabled={safePage >= totalPages - 1}
                  onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                  aria-label="Next page"
                >
                  <ChevronRight className="h-4 w-4" strokeWidth={1.5} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </PersonPanelHost>
  );
}

function SortableTh({
  label,
  active,
  dir,
  onClick,
  align = "left",
}: {
  label: string;
  active: boolean;
  dir: SortDir;
  onClick: () => void;
  align?: "left" | "right";
}) {
  return (
    <th
      className={cn(
        "px-4 py-3 text-[0.6875rem] uppercase tracking-wide font-semibold text-[var(--text-tertiary)]",
        align === "right" ? "text-right" : "text-left"
      )}
    >
      <button
        onClick={onClick}
        className={cn(
          "inline-flex items-center gap-1 cursor-pointer hover:text-[var(--text-primary)] transition-colors",
          align === "right" && "flex-row-reverse",
          active && "text-[var(--accent-coral)]"
        )}
      >
        {label}
        {active ? (
          dir === "asc" ? (
            <ArrowUp className="h-3 w-3" strokeWidth={1.5} />
          ) : (
            <ArrowDown className="h-3 w-3" strokeWidth={1.5} />
          )
        ) : (
          <ArrowUpDown className="h-3 w-3 opacity-40" strokeWidth={1.5} />
        )}
      </button>
    </th>
  );
}

function RowFragment({
  employee,
  isSelected,
  isExpanded,
  tag,
  onToggleSelect,
  onToggleExpand,
  onOpen,
  onRemoveTag,
}: {
  employee: Employee;
  isSelected: boolean;
  isExpanded: boolean;
  tag?: string;
  onToggleSelect: () => void;
  onToggleExpand: () => void;
  onOpen: () => void;
  onRemoveTag?: () => void;
}) {
  const reduceMotion = useReducedMotion();
  const managerChain = getManagerChain(employee.id);
  return (
    <>
      <tr
        className={cn(
          "border-b border-[var(--border-default)] last:border-b-0 transition-colors",
          isSelected ? "bg-[var(--accent-coral-soft)]" : "hover:bg-[var(--surface-alt)]"
        )}
      >
        <td className="px-4 py-3">
          <Checkbox
            checked={isSelected}
            onCheckedChange={onToggleSelect}
            aria-label={`Select ${employee.name}`}
          />
        </td>
        <td className="px-4 py-3">
          <div
            onClick={onOpen}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onOpen();
              }
            }}
            role="button"
            tabIndex={0}
            aria-label={`Open ${employee.name}'s profile`}
            className="flex items-center gap-2.5 text-left cursor-pointer group min-w-0"
          >
            <Avatar name={employee.name} seed={employee.avatarSeed} size="xs" />
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-medium text-[var(--text-primary)] truncate group-hover:text-[var(--accent-coral)] transition-colors">
                  {employee.name}
                </span>
                {tag && (
                  <span className="inline-flex items-center gap-0.5 shrink-0 rounded-full bg-[var(--status-amber-soft)] text-[var(--status-amber)] px-1.5 py-0 text-[0.625rem] font-medium leading-tight">
                    <Tag className="h-2.5 w-2.5" strokeWidth={2} />
                    {tag}
                    {onRemoveTag && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemoveTag();
                        }}
                        aria-label={`Remove ${tag} tag from ${employee.name}`}
                        className="ml-0.5 inline-flex h-3 w-3 items-center justify-center rounded-full hover:bg-[var(--status-amber)]/20 cursor-pointer"
                      >
                        <X className="h-2.5 w-2.5" strokeWidth={2} />
                      </button>
                    )}
                  </span>
                )}
              </div>
              <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                {employee.email}
              </div>
            </div>
          </div>
        </td>
        <td className="px-4 py-3 text-[var(--text-secondary)] truncate max-w-[240px]">
          {employee.title}
        </td>
        <td className="px-4 py-3">
          <span className="inline-flex items-center gap-1.5 text-[var(--text-secondary)]">
            <span
              className="inline-block h-2 w-2 rounded-full"
              style={{ background: deptColor(employee.department) }}
              aria-hidden="true"
            />
            {employee.department}
          </span>
        </td>
        <td className="px-4 py-3 text-right font-data tabular-nums text-[var(--text-primary)]">
          {employee.tenureYears}y
        </td>
        <td className="px-4 py-3 text-right">
          <span
            className={cn(
              "font-data tabular-nums font-medium",
              employee.flightRisk >= 25
                ? "text-[var(--status-brick)]"
                : employee.flightRisk >= 15
                  ? "text-[var(--status-amber)]"
                  : "text-[var(--text-secondary)]"
            )}
          >
            {employee.flightRisk}
          </span>
        </td>
        <td className="px-4 py-3">
          <StatusBadge
            variant={statusVariantForEmployee(employee)}
            label={statusLabelForEmployee(employee)}
          />
        </td>
        <td className="px-2 py-3">
          <button
            onClick={onToggleExpand}
            aria-label={isExpanded ? `Collapse ${employee.name} details` : `Expand ${employee.name} details`}
            aria-expanded={isExpanded}
            className="inline-flex h-7 w-7 items-center justify-center rounded-[6px] text-[var(--text-tertiary)] hover:bg-[var(--surface-alt)] hover:text-[var(--text-primary)] cursor-pointer transition-colors"
          >
            <motion.span
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: reduceMotion ? 0 : 0.18 }}
              className="inline-flex"
            >
              <ChevronDown className="h-3.5 w-3.5" strokeWidth={1.5} />
            </motion.span>
          </button>
        </td>
      </tr>
      <tr>
        <td colSpan={8} className="p-0">
          <AnimatePresence initial={false}>
            {isExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{
                  duration: reduceMotion ? 0 : 0.25,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="overflow-hidden bg-[var(--surface-alt)]"
              >
                <div className="px-4 py-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <p className="eyebrow mb-2">Contact</p>
                    <div className="space-y-1.5 text-[0.8125rem]">
                      <div className="flex items-center gap-2 text-[var(--text-secondary)]">
                        <Mail className="h-3.5 w-3.5" strokeWidth={1.5} />
                        <span>{employee.email}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[var(--text-secondary)]">
                        <Phone className="h-3.5 w-3.5" strokeWidth={1.5} />
                        <span>{employee.phone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[var(--text-secondary)]">
                        <MapPin className="h-3.5 w-3.5" strokeWidth={1.5} />
                        <span>{employee.location}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <p className="eyebrow mb-2">Reporting line</p>
                    {managerChain.length > 0 ? (
                      <nav className="flex flex-wrap items-center gap-1 text-[0.8125rem] text-[var(--text-secondary)]">
                        {managerChain.map((m, i) => (
                          <span key={m.id} className="inline-flex items-center gap-1">
                            <span>{m.name}</span>
                            {i < managerChain.length - 1 && (
                              <ChevronRightIcon className="h-3 w-3 text-[var(--text-tertiary)]" strokeWidth={1.5} />
                            )}
                          </span>
                        ))}
                      </nav>
                    ) : (
                      <p className="text-[0.8125rem] text-[var(--text-tertiary)]">
                        Reports to the board.
                      </p>
                    )}
                  </div>
                  <div>
                    <p className="eyebrow mb-2">Details</p>
                    <div className="space-y-1 text-[0.8125rem]">
                      <div className="flex justify-between text-[var(--text-secondary)]">
                        <span>Salary band</span>
                        <span className="font-data text-[var(--text-primary)]">{employee.salaryBand}</span>
                      </div>
                      <div className="flex justify-between text-[var(--text-secondary)]">
                        <span>Started</span>
                        <span className="font-data text-[var(--text-primary)]">
                          {new Date(employee.startDate).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                          })}
                        </span>
                      </div>
                      <div className="flex justify-between text-[var(--text-secondary)]">
                        <span>Flight risk</span>
                        <span
                          className={cn(
                            "font-data font-medium",
                            employee.flightRisk >= 25
                              ? "text-[var(--status-brick)]"
                              : employee.flightRisk >= 15
                                ? "text-[var(--status-amber)]"
                                : "text-[var(--accent-mint)]"
                          )}
                        >
                          {employee.flightRisk}/100
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </td>
      </tr>
    </>
  );
}

function deptColor(dept: Department): string {
  switch (dept) {
    case "Engineering":
      return "var(--accent-coral)";
    case "Design":
      return "var(--status-lavender)";
    case "Sales":
      return "var(--accent-mint)";
    case "Marketing":
      return "var(--status-amber)";
    case "People":
      return "var(--status-brick)";
    case "Finance":
      return "var(--text-secondary)";
  }
}

// helper to satisfy eslint unused import warning
void useCallback;
