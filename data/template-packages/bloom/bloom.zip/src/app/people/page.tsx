import type { Metadata } from "next";
import { PeopleClient } from "./people-client";

export const metadata: Metadata = {
  title: "People — Directory",
  description:
    "Filterable, sortable employee directory with row-level expand, bulk actions, and pagination.",
};

export default function PeoplePage() {
  return <PeopleClient />;
}
