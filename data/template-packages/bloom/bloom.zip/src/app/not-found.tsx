import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { brand } from "@/config/brand";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center bg-[var(--bg-base)]">
      <svg
        width="160"
        height="160"
        viewBox="0 0 160 160"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="notfound-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--accent-coral)" stopOpacity="0.25" />
            <stop offset="100%" stopColor="var(--status-lavender)" stopOpacity="0.15" />
          </linearGradient>
        </defs>
        {/* organic blob — matches the warmth register everywhere else */}
        <path
          d="M40 90 Q 40 50 80 45 Q 120 50 120 90 Q 120 115 80 120 Q 40 115 40 90 Z"
          fill="url(#notfound-grad)"
          stroke="var(--border-emphasis)"
          strokeWidth="1.2"
        />
        {/* a sad little sprout — the page is lost, but warm */}
        <path
          d="M80 115 Q 80 80 80 55"
          stroke="var(--accent-mint)"
          strokeWidth="1.5"
          fill="none"
        />
        <path
          d="M80 80 Q 65 75 60 65 Q 70 60 80 75"
          fill="url(#notfound-grad)"
          stroke="var(--accent-mint)"
          strokeWidth="1.2"
        />
        <path
          d="M80 70 Q 95 65 100 55 Q 90 50 80 65"
          fill="url(#notfound-grad)"
          stroke="var(--accent-mint)"
          strokeWidth="1.2"
        />
        {/* "404" floating above as text */}
        <text
          x="80"
          y="40"
          textAnchor="middle"
          fontFamily="var(--font-fraunces), serif"
          fontSize="14"
          fontWeight="500"
          fill="var(--text-tertiary)"
          letterSpacing="2"
        >
          404
        </text>
      </svg>
      <h1 className="font-display text-3xl sm:text-4xl font-medium mt-6 text-[var(--text-primary)]">
        This page wandered off.
      </h1>
      <p className="text-[0.9375rem] text-[var(--text-secondary)] mt-3 max-w-md leading-relaxed">
        The page you&rsquo;re looking for doesn&rsquo;t exist, or may have been moved. Head back to
        the {brand.name} overview to see the org chart.
      </p>
      <Link
        href="/"
        className="mt-6 inline-flex h-10 items-center gap-2 rounded-[10px] bg-[var(--accent-coral)] px-5 text-[0.875rem] font-medium text-white hover:bg-[var(--accent-coral)]/90 transition-colors cursor-pointer"
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
        Back to overview
      </Link>
    </div>
  );
}
