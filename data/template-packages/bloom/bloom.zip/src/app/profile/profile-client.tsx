"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  MapPin,
  Mail,
  Phone,
  Calendar,
  Briefcase,
  Building2,
  Users,
  Clock,
  Star,
  FileText,
  ArrowRight,
  TrendingUp,
  Award,
  Activity as ActivityIcon,
  Pencil,
  Save,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader } from "@/components/bloom/page-header";
import { Avatar } from "@/components/bloom/avatar";
import {
  StatusBadge,
  statusVariantForEmployee,
  statusLabelForEmployee,
} from "@/components/bloom/status-badge";
import {
  employees,
  getEmployeeById,
  getReportsOf,
  getManagerChain,
  getReviewsFor,
  getActivitiesFor,
  type Activity,
  type Department,
} from "@/data/demo";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

type Profile = {
  name: string;
  title: string;
  bio: string;
  location: string;
};

const DEFAULT_PROFILE: Profile = {
  name: employees[0].name,
  title: employees[0].title,
  bio: employees[0].bio,
  location: employees[0].location,
};

export function ProfileClient() {
  const router = useRouter();
  const currentUser = employees[0];
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useLocalStorage<Profile>(
    "bloom-profile-page",
    DEFAULT_PROFILE
  );

  const reports = getReportsOf(currentUser.id);
  const managerChain = getManagerChain(currentUser.id);
  const manager = currentUser.managerId ? getEmployeeById(currentUser.managerId) : null;
  const reviewEntries = getReviewsFor(currentUser.id);
  const activities = getActivitiesFor(currentUser.id);

  // Team members — same department, excluding self
  const teamMembers = employees
    .filter((e) => e.department === currentUser.department && e.id !== currentUser.id)
    .slice(0, 6);

  return (
    <div className="px-6 py-6 max-w-5xl">
      <PageHeader
        eyebrow="Profile"
        title="My Profile"
        subtitle="Your public profile page within the Bloom workspace. Update your details below — changes persist across reloads."
        actions={
          <Button
            onClick={() => setIsEditing((v) => !v)}
            className={cn(
              "h-9 rounded-[8px] cursor-pointer",
              isEditing
                ? "bg-[var(--surface-alt)] text-[var(--text-primary)] hover:bg-[var(--border-default)]"
                : "bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90"
            )}
          >
            {isEditing ? (
              <>
                <X className="h-4 w-4 mr-1" strokeWidth={1.5} />
                Cancel
              </>
            ) : (
              <>
                <Pencil className="h-4 w-4 mr-1" strokeWidth={1.5} />
                Edit profile
              </>
            )}
          </Button>
        }
      />

      {/* Cover banner + avatar */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="mt-6 rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] overflow-hidden"
      >
        {/* Cover */}
        <div className="relative h-32 sm:h-40 bg-gradient-to-br from-[var(--accent-coral)]/20 via-[var(--status-lavender)]/15 to-[var(--accent-mint)]/20">
          <div className="absolute inset-0 paper-grain opacity-40" />
        </div>

        {/* Avatar + name */}
        <div className="px-6 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4 -mt-12 sm:-mt-14">
            <div className="relative">
              <div className="rounded-full border-4 border-[var(--surface)] bg-[var(--surface)]">
                <Avatar
                  name={profile.name}
                  seed={currentUser.avatarSeed}
                  size="2xl"
                  ring
                />
              </div>
              <span className="absolute bottom-2 right-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-[var(--accent-mint)] border-2 border-[var(--surface)]">
                <span className="h-2 w-2 rounded-full bg-white" />
              </span>
            </div>
            <div className="flex-1 min-w-0 pb-1">
              {isEditing ? (
                <Input
                  value={profile.name}
                  onChange={(e) => setProfile((p) => ({ ...p, name: e.target.value }))}
                  className="font-display text-xl font-medium rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]"
                />
              ) : (
                <h1 className="font-display text-2xl sm:text-3xl font-medium text-[var(--text-primary)] leading-tight">
                  {profile.name}
                </h1>
              )}
              {isEditing ? (
                <Input
                  value={profile.title}
                  onChange={(e) => setProfile((p) => ({ ...p, title: e.target.value }))}
                  className="mt-2 text-[0.9375rem] rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]"
                />
              ) : (
                <p className="text-[0.9375rem] text-[var(--text-secondary)] mt-1">
                  {profile.title}
                </p>
              )}
              <div className="mt-2 flex items-center gap-2">
                <StatusBadge
                  variant={statusVariantForEmployee(currentUser)}
                  label={statusLabelForEmployee(currentUser)}
                />
                <span className="text-[0.75rem] text-[var(--text-tertiary)] font-data">
                  {currentUser.department}
                </span>
              </div>
            </div>
          </div>

          {/* Bio */}
          <div className="mt-6">
            {isEditing ? (
              <div className="space-y-1.5">
                <Label className="text-[0.8125rem] font-medium">Bio</Label>
                <Textarea
                  value={profile.bio}
                  onChange={(e) => setProfile((p) => ({ ...p, bio: e.target.value }))}
                  rows={3}
                  className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)] resize-none"
                />
              </div>
            ) : (
              <p className="text-[0.9375rem] leading-relaxed text-[var(--text-primary)] max-w-2xl">
                {profile.bio}
              </p>
            )}
          </div>

          {/* Quick facts */}
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
            <QuickFact
              icon={MapPin}
              label="Location"
              value={isEditing ? (
                <Input
                  value={profile.location}
                  onChange={(e) => setProfile((p) => ({ ...p, location: e.target.value }))}
                  className="h-8 text-[0.8125rem] rounded-[6px] border-[var(--border-default)] bg-[var(--surface)]"
                />
              ) : (
                profile.location
              )}
            />
            <QuickFact icon={Mail} label="Email" value={currentUser.email} />
            <QuickFact icon={Phone} label="Phone" value={currentUser.phone} />
            <QuickFact
              icon={Calendar}
              label="Started"
              value={new Date(currentUser.startDate).toLocaleDateString("en-US", {
                year: "numeric",
                month: "short",
              })}
            />
          </div>

          {/* Save button when editing */}
          {isEditing && (
            <div className="mt-4 flex justify-end gap-2">
              <Button
                variant="ghost"
                onClick={() => {
                  setProfile(DEFAULT_PROFILE);
                  setIsEditing(false);
                  toast({ title: "Changes discarded", description: "Reverted to defaults." });
                }}
                className="h-9 rounded-[8px] cursor-pointer"
              >
                Reset to defaults
              </Button>
              <Button
                onClick={() => {
                  setIsEditing(false);
                  toast({
                    title: "Profile saved",
                    description: "Your changes will persist across reloads.",
                  });
                }}
                className="bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90 h-9 rounded-[8px] cursor-pointer"
              >
                <Save className="h-4 w-4 mr-1" strokeWidth={1.5} />
                Save changes
              </Button>
            </div>
          )}
        </div>
      </motion.div>

      {/* Stats row */}
      <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          icon={Clock}
          label="Tenure"
          value={`${currentUser.tenureYears}y`}
          accent="coral"
          delay={0}
        />
        <StatCard
          icon={Users}
          label="Direct reports"
          value={String(reports.length)}
          accent="mint"
          delay={70}
        />
        <StatCard
          icon={Star}
          label="Reviews received"
          value={String(reviewEntries.length)}
          accent="lavender"
          delay={140}
        />
        <StatCard
          icon={Award}
          label="Salary band"
          value={currentUser.salaryBand}
          accent="amber"
          delay={210}
        />
      </div>

      {/* Two-column layout: activity + sidebar */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Activity feed */}
        <div className="lg:col-span-2 rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--border-default)] flex items-center gap-2">
            <ActivityIcon className="h-4 w-4 text-[var(--accent-coral)]" strokeWidth={1.5} />
            <h2 className="font-display text-lg font-medium text-[var(--text-primary)]">
              Recent activity
            </h2>
          </div>
          <ul className="divide-y divide-[var(--border-default)]">
            {activities.map((activity, i) => (
              <ActivityItem key={activity.id} activity={activity} delay={i * 60} />
            ))}
          </ul>
        </div>

        {/* Sidebar: manager + team */}
        <div className="space-y-4">
          {/* Manager */}
          {manager && (
            <div className="rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] p-5">
              <p className="eyebrow mb-3">Reports to</p>
              <button
                onClick={() => toast({ title: manager.name, description: manager.title })}
                className="flex items-center gap-3 w-full text-left cursor-pointer group"
              >
                <Avatar name={manager.name} seed={manager.avatarSeed} size="sm" />
                <div className="min-w-0">
                  <div className="text-[0.875rem] font-medium text-[var(--text-primary)] truncate group-hover:text-[var(--accent-coral)] transition-colors">
                    {manager.name}
                  </div>
                  <div className="text-[0.75rem] text-[var(--text-tertiary)] truncate">
                    {manager.title}
                  </div>
                </div>
              </button>
              {managerChain.length > 1 && (
                <div className="mt-3 pt-3 border-t border-[var(--border-default)]">
                  <p className="eyebrow mb-2">Reporting line</p>
                  <nav className="text-[0.75rem] text-[var(--text-secondary)] space-y-1">
                    {managerChain.map((m, i) => (
                      <div key={m.id} className="flex items-center gap-1.5">
                        <span className="inline-block h-1 w-1 rounded-full bg-[var(--text-tertiary)]" />
                        <span className="truncate">{m.name}</span>
                        <span className="text-[var(--text-tertiary)] text-[0.6875rem]">· {m.title}</span>
                      </div>
                    ))}
                  </nav>
                </div>
              )}
            </div>
          )}

          {/* Team */}
          <div className="rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] p-5">
            <p className="eyebrow mb-3">
              {currentUser.department} team
            </p>
            <ul className="space-y-2">
              {teamMembers.map((member) => (
                <li key={member.id}>
                  <button
                    onClick={() => toast({ title: member.name, description: member.title })}
                    className="flex items-center gap-3 w-full text-left cursor-pointer rounded-[10px] p-2 hover:bg-[var(--surface-alt)] transition-colors"
                  >
                    <Avatar name={member.name} seed={member.avatarSeed} size="xs" />
                    <div className="min-w-0 flex-1">
                      <div className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
                        {member.name}
                      </div>
                      <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                        {member.title}
                      </div>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Recent reviews */}
          {reviewEntries.length > 0 && (
            <div className="rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] p-5">
              <p className="eyebrow mb-3">Recent reviews</p>
              <ul className="space-y-3">
                {reviewEntries.slice(0, 3).map((review) => (
                  <li key={review.id} className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
                        {review.reviewer}
                      </span>
                      <div className="flex items-center gap-0.5 shrink-0">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <span
                            key={i}
                            className={cn(
                              "inline-block h-1.5 w-1.5 rounded-full",
                              i < review.rating
                                ? "bg-[var(--accent-coral)]"
                                : "bg-[var(--border-default)]"
                            )}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-[0.75rem] text-[var(--text-secondary)] leading-relaxed line-clamp-2">
                      {review.summary}
                    </p>
                    <p className="text-[0.6875rem] font-data text-[var(--text-tertiary)]">
                      {new Date(review.submittedAt).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Direct reports (if any) */}
      {reports.length > 0 && (
        <div className="mt-6 rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] overflow-hidden">
          <div className="px-5 py-4 border-b border-[var(--border-default)] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-[var(--accent-coral)]" strokeWidth={1.5} />
              <h2 className="font-display text-lg font-medium text-[var(--text-primary)]">
                Direct reports
              </h2>
              <span className="text-[0.75rem] font-data text-[var(--text-tertiary)]">
                {reports.length}
              </span>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 p-5">
            {reports.map((report) => (
              <button
                key={report.id}
                onClick={() => toast({ title: report.name, description: report.title })}
                className="flex items-center gap-3 rounded-[14px] border border-[var(--border-default)] p-3 hover:border-[var(--border-emphasis)] hover:bg-[var(--surface-alt)] cursor-pointer transition-colors text-left"
              >
                <Avatar name={report.name} seed={report.avatarSeed} size="sm" />
                <div className="min-w-0 flex-1">
                  <div className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
                    {report.name}
                  </div>
                  <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                    {report.title}
                  </div>
                </div>
                <ArrowRight className="h-3.5 w-3.5 text-[var(--text-tertiary)] shrink-0" strokeWidth={1.5} />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function QuickFact({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-2.5">
      <Icon className="h-4 w-4 text-[var(--text-tertiary)] mt-0.5 shrink-0" strokeWidth={1.5} />
      <div className="min-w-0">
        <div className="text-[0.6875rem] uppercase tracking-wide font-medium text-[var(--text-tertiary)]">
          {label}
        </div>
        <div className="text-[0.8125rem] text-[var(--text-primary)] truncate mt-0.5">
          {value}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  accent,
  delay,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  label: string;
  value: string;
  accent: "coral" | "mint" | "lavender" | "amber";
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay / 1000, ease: [0.16, 1, 0.3, 1] }}
      className="rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] p-5"
    >
      <div className="flex items-center justify-between mb-2">
        <span
          className={cn(
            "inline-flex h-8 w-8 items-center justify-center rounded-[8px]",
            accent === "coral" && "bg-[var(--accent-coral-soft)] text-[var(--accent-coral)]",
            accent === "mint" && "bg-[var(--accent-mint-soft)] text-[var(--accent-mint)]",
            accent === "lavender" && "bg-[var(--status-lavender-soft)] text-[var(--status-lavender)]",
            accent === "amber" && "bg-[var(--status-amber-soft)] text-[var(--status-amber)]"
          )}
        >
          <Icon className="h-4 w-4" strokeWidth={1.5} />
        </span>
      </div>
      <div className="font-data text-[1.5rem] font-medium tabular-nums text-[var(--text-primary)] leading-none">
        {value}
      </div>
      <div className="text-[0.75rem] text-[var(--text-tertiary)] mt-1.5">
        {label}
      </div>
    </motion.div>
  );
}

function ActivityItem({ activity, delay }: { activity: Activity; delay: number }) {
  const router = useRouter();
  const icon = activityIcon(activity.type);
  const Icon = icon.icon;
  return (
    <motion.li
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3, delay: delay / 1000 }}
    >
      <button
        onClick={() => activity.href && router.push(activity.href)}
        className="w-full flex items-start gap-3 px-5 py-3.5 hover:bg-[var(--surface-alt)] cursor-pointer transition-colors text-left"
      >
        <span
          className={cn(
            "inline-flex h-8 w-8 items-center justify-center rounded-[8px] shrink-0",
            icon.bg
          )}
        >
          <Icon className="h-4 w-4" strokeWidth={1.5} />
        </span>
        <div className="flex-1 min-w-0">
          <p className="text-[0.8125rem] text-[var(--text-primary)] leading-snug">
            {activity.message}
          </p>
          <p className="text-[0.6875rem] font-data text-[var(--text-tertiary)] mt-0.5">
            {formatRelativeTime(activity.timestamp)}
          </p>
        </div>
        {activity.href && (
          <ArrowRight className="h-3.5 w-3.5 text-[var(--text-tertiary)] shrink-0 mt-1" strokeWidth={1.5} />
        )}
      </button>
    </motion.li>
  );
}

function activityIcon(type: Activity["type"]): {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  bg: string;
} {
  switch (type) {
    case "review_submitted":
      return { icon: Star, bg: "bg-[var(--accent-coral-soft)] text-[var(--accent-coral)]" };
    case "candidate_moved":
      return { icon: Users, bg: "bg-[var(--accent-mint-soft)] text-[var(--accent-mint)]" };
    case "note_added":
      return { icon: FileText, bg: "bg-[var(--status-lavender-soft)] text-[var(--status-lavender)]" };
    case "flight_risk":
      return { icon: TrendingUp, bg: "bg-[var(--status-brick-soft)] text-[var(--status-brick)]" };
    case "cycle_started":
      return { icon: Award, bg: "bg-[var(--status-amber-soft)] text-[var(--status-amber)]" };
    case "profile_updated":
      return { icon: Pencil, bg: "bg-[var(--surface-alt)] text-[var(--text-secondary)]" };
  }
}

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const now = new Date("2025-11-15T00:00:00Z");
  const diffMs = now.getTime() - date.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} week${Math.floor(diffDays / 7) > 1 ? "s" : ""} ago`;
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}
