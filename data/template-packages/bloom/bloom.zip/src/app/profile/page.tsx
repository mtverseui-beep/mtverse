import type { Metadata } from "next";
import { ProfileClient } from "./profile-client";

export const metadata: Metadata = {
  title: "Profile",
  description:
    "Your Bloom profile — cover, avatar, bio, stats, activity feed, teams, and recent reviews.",
};

export default function ProfilePage() {
  return <ProfileClient />;
}
