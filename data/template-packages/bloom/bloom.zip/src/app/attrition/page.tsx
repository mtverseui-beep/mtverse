import type { Metadata } from "next";
import { AttritionClient } from "./attrition-client";

export const metadata: Metadata = {
  title: "Attrition — Analytics",
  description:
    "Trailing attrition rate, trend over time, top reasons, and a department-level comparison — the people-analytics view.",
};

export default function AttritionPage() {
  return <AttritionClient />;
}
