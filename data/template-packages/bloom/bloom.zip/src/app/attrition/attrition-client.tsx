"use client";

import { useState, useMemo, useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import { motion, useReducedMotion } from "framer-motion";
import { TrendingDown, Users, AlertTriangle, ArrowDownRight } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PageHeader } from "@/components/bloom/page-header";
import { Skeleton } from "@/components/bloom/empty-state";
import {
  attritionTrend,
  attritionReasons,
  departmentAttrition,
  stats,
  type DepartmentAttrition,
} from "@/data/demo";
import { cn } from "@/lib/utils";

// Recharts is dynamically imported — no layout shift on hydration (spec §3.10)
const TrendChart = dynamic(() => import("@/components/charts/trend-chart"), {
  ssr: false,
  loading: () => <Skeleton className="h-[260px] w-full rounded-[14px]" />,
});
const ReasonsChart = dynamic(() => import("@/components/charts/reasons-chart"), {
  ssr: false,
  loading: () => <Skeleton className="h-[260px] w-full rounded-[14px]" />,
});

type Period = "quarter" | "year" | "trailing12";

const PERIODS: { id: Period; label: string; months: number }[] = [
  { id: "quarter", label: "This quarter", months: 3 },
  { id: "year", label: "This year", months: 12 },
  { id: "trailing12", label: "Trailing 12mo", months: 18 },
];

export function AttritionClient() {
  const [period, setPeriod] = useState<Period>("trailing12");
  const reduceMotion = useReducedMotion();

  const trendSlice = useMemo(() => {
    const m = PERIODS.find((p) => p.id === period)?.months ?? 18;
    return attritionTrend.slice(-m);
  }, [period]);

  const heroRate = trendSlice[trendSlice.length - 1]?.rate ?? 0;
  const avgRate =
    Math.round(
      (trendSlice.reduce((s, m) => s + m.rate, 0) / trendSlice.length) * 10
    ) / 10;
  const totalDepartures = trendSlice.reduce((s, m) => s + m.departures, 0);
  const currentHeadcount = trendSlice[trendSlice.length - 1]?.headcount ?? 0;

  return (
    <div className="px-6 py-6">
      <PageHeader
        eyebrow="People analytics"
        title="Attrition"
        subtitle="Where people leave, how it trends, and why. Use the period toggle to focus on the most recent quarter, the year, or the trailing twelve months."
        actions={
          <Select value={period} onValueChange={(v) => setPeriod(v as Period)}>
            <SelectTrigger className="w-[160px] h-9 rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]">
              {PERIODS.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        }
      />

      {/* hero stat row */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <HeroCard
          label="Current attrition rate"
          value={heroRate}
          suffix="%"
          delta={heroRate - avgRate}
          icon={TrendingDown}
          accent="coral"
          delay={0}
        />
        <HeroCard
          label="Period average"
          value={avgRate}
          suffix="%"
          icon={ArrowDownRight}
          accent="neutral"
          delay={70}
        />
        <HeroCard
          label="Total departures"
          value={totalDepartures}
          icon={Users}
          accent="neutral"
          delay={140}
        />
        <HeroCard
          label="Current headcount"
          value={currentHeadcount}
          icon={Users}
          accent="mint"
          delay={210}
        />
      </div>

      {/* charts */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] p-5 paper-grain relative">
          <div className="flex items-center justify-between mb-1">
            <div>
              <p className="eyebrow">Trend</p>
              <h2 className="font-display text-lg font-medium mt-1 text-[var(--text-primary)]">
                Monthly attrition rate
              </h2>
            </div>
            <span className="text-[0.75rem] font-data text-[var(--text-tertiary)] tabular-nums">
              {trendSlice[0].month} → {trendSlice[trendSlice.length - 1].month}
            </span>
          </div>
          <TrendChart data={trendSlice} reduceMotion={!!reduceMotion} />
        </div>

        <div className="rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] p-5">
          <p className="eyebrow">Reasons</p>
          <h2 className="font-display text-lg font-medium mt-1 text-[var(--text-primary)] mb-3">
            Why people leave
          </h2>
          <ReasonsChart data={attritionReasons} />
        </div>
      </div>

      {/* department comparison table */}
      <div className="mt-6 rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] overflow-hidden">
        <div className="px-5 py-4 border-b border-[var(--border-default)] flex items-center justify-between">
          <div>
            <p className="eyebrow">By department</p>
            <h2 className="font-display text-lg font-medium mt-1 text-[var(--text-primary)]">
              Department comparison
            </h2>
          </div>
          {stats.flightRiskHigh > 0 && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--status-brick-soft)] text-[var(--status-brick)] px-2.5 py-1 text-[0.6875rem] font-medium">
              <AlertTriangle className="h-3 w-3" strokeWidth={1.5} />
              {stats.flightRiskHigh} high-risk {stats.flightRiskHigh === 1 ? "person" : "people"}
            </span>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[0.875rem]">
            <thead>
              <tr className="border-b border-[var(--border-default)] bg-[var(--surface-alt)] text-left text-[0.6875rem] uppercase tracking-wide font-semibold text-[var(--text-tertiary)]">
                <th className="px-5 py-3">Department</th>
                <th className="px-5 py-3 text-right">Headcount</th>
                <th className="px-5 py-3 text-right">Departures</th>
                <th className="px-5 py-3 text-right">Rate</th>
                <th className="px-5 py-3">Distribution</th>
              </tr>
            </thead>
            <tbody>
              {departmentAttrition.map((d, i) => (
                <DeptRow key={d.department} dept={d} delay={i * 60} />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function HeroCard({
  label,
  value,
  suffix = "",
  delta,
  icon: Icon,
  accent,
  delay,
}: {
  label: string;
  value: number;
  suffix?: string;
  delta?: number;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  accent: "coral" | "mint" | "neutral";
  delay: number;
}) {
  const reduceMotion = useReducedMotion();
  return (
    <motion.div
      initial={reduceMotion ? false : { opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1], delay: reduceMotion ? 0 : delay / 1000 }}
      className={cn(
        "rounded-[18px] border bg-[var(--surface)] p-5",
        accent === "coral"
          ? "border-[var(--accent-coral)]/30"
          : accent === "mint"
            ? "border-[var(--accent-mint)]/30"
            : "border-[var(--border-default)]"
      )}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="eyebrow">{label}</p>
          <p className="mt-2 font-data text-[1.75rem] sm:text-[2rem] leading-none font-medium tabular-nums text-[var(--text-primary)]">
            <CountUp value={value} decimals={value < 100 ? 1 : 0} reduceMotion={!!reduceMotion} />
            <span className="text-[1rem] ml-0.5">{suffix}</span>
          </p>
        </div>
        <span
          className={cn(
            "inline-flex h-8 w-8 items-center justify-center rounded-[8px]",
            accent === "coral"
              ? "bg-[var(--accent-coral-soft)] text-[var(--accent-coral)]"
              : accent === "mint"
                ? "bg-[var(--accent-mint-soft)] text-[var(--accent-mint)]"
                : "bg-[var(--surface-alt)] text-[var(--text-secondary)]"
          )}
        >
          <Icon className="h-4 w-4" strokeWidth={1.5} />
        </span>
      </div>
      {delta !== undefined && (
        <p
          className={cn(
            "mt-2 text-[0.75rem] font-data tabular-nums",
            delta > 0 ? "text-[var(--status-brick)]" : "text-[var(--accent-mint)]"
          )}
        >
          {delta > 0 ? "+" : ""}
          {delta.toFixed(1)}pp vs period average
        </p>
      )}
    </motion.div>
  );
}

/** Animated count-up — uses tabular-nums to prevent digit jitter (spec §3.2/§4.6). */
function CountUp({
  value,
  decimals = 0,
  reduceMotion = false,
  duration = 900,
}: {
  value: number;
  decimals?: number;
  reduceMotion?: boolean;
  duration?: number;
}) {
  const [display, setDisplay] = useState(reduceMotion ? value : 0);
  const rafRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);

  useEffect(() => {
    // Reduced-motion: skip animation entirely. The initial state already
    // returns `value` when reduceMotion is true (via the lazy initializer).
    if (reduceMotion) {
      return;
    }
    const animate = (t: number) => {
      if (startTimeRef.current === null) startTimeRef.current = t;
      const elapsed = t - startTimeRef.current;
      const progress = Math.min(1, elapsed / duration);
      // easeOutExpo
      const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      setDisplay(value * eased);
      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate);
      }
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      startTimeRef.current = null;
    };
  }, [value, duration, reduceMotion]);

  return <span className="tabular-nums">{display.toFixed(decimals)}</span>;
}

function DeptRow({ dept, delay }: { dept: DepartmentAttrition; delay: number }) {
  const reduceMotion = useReducedMotion();
  const maxRate = Math.max(...departmentAttrition.map((d) => d.rate), 1);
  const widthPct = (dept.rate / maxRate) * 100;

  return (
    <motion.tr
      initial={reduceMotion ? false : { opacity: 0, x: -10 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: reduceMotion ? 0 : delay / 1000 }}
      className="border-b border-[var(--border-default)] last:border-b-0 hover:bg-[var(--surface-alt)] transition-colors"
    >
      <td className="px-5 py-3.5 font-medium text-[var(--text-primary)]">
        {dept.department}
      </td>
      <td className="px-5 py-3.5 text-right font-data tabular-nums text-[var(--text-primary)]">
        {dept.headcount}
      </td>
      <td className="px-5 py-3.5 text-right font-data tabular-nums text-[var(--text-secondary)]">
        {dept.departures}
      </td>
      <td
        className={cn(
          "px-5 py-3.5 text-right font-data tabular-nums font-medium",
          dept.rate >= 15
            ? "text-[var(--status-brick)]"
            : dept.rate >= 8
              ? "text-[var(--status-amber)]"
              : "text-[var(--accent-mint)]"
        )}
      >
        {dept.rate.toFixed(1)}%
      </td>
      <td className="px-5 py-3.5">
        <div className="h-2 w-full max-w-[160px] rounded-full bg-[var(--surface-alt)] overflow-hidden">
          <motion.div
            initial={reduceMotion ? false : { width: 0 }}
            whileInView={{ width: `${widthPct}%` }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: reduceMotion ? 0 : delay / 1000 + 0.1, ease: [0.16, 1, 0.3, 1] }}
            className={cn(
              "h-full rounded-full",
              dept.rate >= 15
                ? "bg-[var(--status-brick)]"
                : dept.rate >= 8
                  ? "bg-[var(--status-amber)]"
                  : "bg-[var(--accent-mint)]"
            )}
          />
        </div>
      </td>
    </motion.tr>
  );
}
