import type { Metadata } from "next";
import { OverviewClient } from "./overview-client";

export const metadata: Metadata = {
  title: "Overview — Org Chart",
  description:
    "The full Bloom organization on one pannable, zoomable canvas. Click any person to open their detail panel.",
};

export default function OverviewPage() {
  return <OverviewClient />;
}
