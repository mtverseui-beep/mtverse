"use client";

import { OrgChart } from "@/components/bloom/org-chart";
import { PersonPanelHost } from "@/components/bloom/person-panel-host";
import { PageHeader } from "@/components/bloom/page-header";
import { Skeleton } from "@/components/bloom/empty-state";
import { stats } from "@/data/demo";
import { motion } from "framer-motion";
import { Users, Briefcase, Clock, TrendingDown } from "lucide-react";
import { useIsClient } from "@/hooks/use-is-client";

export function OverviewClient() {
  const mounted = useIsClient();

  return (
    <PersonPanelHost>
      {({ open }) => (
        <div className="flex flex-col h-full min-h-0">
          {/* slim stat strip above the canvas (spec §4.3) */}
          <div className="px-6 pt-6 pb-3 shrink-0">
            <PageHeader
              eyebrow="Org structure"
              title="Your organization at a glance"
              subtitle="Pan, zoom, and click any person to open their full profile. Collapse a manager to focus on a slice of the org."
            />
            <div className="mt-5 flex flex-wrap items-end gap-x-8 gap-y-3">
              <StatLine
                icon={Users}
                label="Total headcount"
                value={stats.totalHeadcount}
              />
              <StatLine icon={Briefcase} label="Open roles" value={stats.openRoles} />
              <StatLine
                icon={Clock}
                label="Avg. tenure"
                value={`${stats.avgTenureYears}y`}
              />
              <StatLine
                icon={TrendingDown}
                label="Trailing attrition"
                value={`${stats.trailingAttritionRate}%`}
              />
            </div>
          </div>

          {/* the canvas — the entire primary content (spec §4.3) */}
          <div className="flex-1 min-h-0 mx-6 mb-6 rounded-[18px] border border-[var(--border-default)] overflow-hidden bg-[var(--surface-alt)] relative">
            {mounted ? (
              <OrgChart onSelect={open} />
            ) : (
              <OrgChartSkeleton />
            )}
          </div>
        </div>
      )}
    </PersonPanelHost>
  );
}

function StatLine({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  label: string;
  value: string | number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className="flex items-center gap-2.5"
    >
      <span className="inline-flex h-8 w-8 items-center justify-center rounded-[8px] bg-[var(--surface-alt)] text-[var(--accent-coral)]">
        <Icon className="h-4 w-4" strokeWidth={1.5} />
      </span>
      <div>
        <div className="text-[0.6875rem] uppercase tracking-wide font-medium text-[var(--text-tertiary)]">
          {label}
        </div>
        <div className="font-data text-[1.125rem] font-medium text-[var(--text-primary)] tabular-nums">
          {value}
        </div>
      </div>
    </motion.div>
  );
}

/** Org-chart-shaped skeleton — not a generic rectangle (spec §3.7). */
function OrgChartSkeleton() {
  return (
    <div className="relative h-full w-full org-canvas-bg overflow-hidden">
      <div className="absolute left-1/2 top-12 -translate-x-1/2 flex flex-col items-center gap-6">
        <Skeleton className="h-[84px] w-[220px] rounded-[14px]" />
        <div className="flex gap-6">
          {[0, 1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-[84px] w-[220px] rounded-[14px]" />
          ))}
        </div>
        <div className="flex gap-6">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-[84px] w-[220px] rounded-[14px]" />
          ))}
        </div>
      </div>
    </div>
  );
}
