import type { Metadata } from "next";
import { ReviewsClient } from "./reviews-client";

export const metadata: Metadata = {
  title: "Reviews — Performance Cycles",
  description:
    "Active, upcoming, and completed review cycles with per-participant completion progress. Request a new review with a real form.",
};

export default function ReviewsPage() {
  return <ReviewsClient />;
}
