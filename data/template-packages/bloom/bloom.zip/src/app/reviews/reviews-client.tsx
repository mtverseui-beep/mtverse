"use client";

import { useState, useMemo } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  Plus,
  ChevronDown,
  Calendar,
  Users,
  CheckCircle2,
  Clock,
  AlertCircle,
  X,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { PageHeader } from "@/components/bloom/page-header";
import { Avatar } from "@/components/bloom/avatar";
import { StatusBadge } from "@/components/bloom/status-badge";
import {
  reviewCycles as initialCycles,
  employees,
  getEmployeeById,
  type ReviewCycle,
} from "@/data/demo";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

const requestReviewSchema = z.object({
  revieweeId: z.string().min(1, "Pick a person to review"),
  reviewerId: z.string().min(1, "Pick a reviewer"),
  cycleId: z.string().min(1, "Pick a cycle"),
  dueDate: z.date({ error: "Pick a due date" }),
});
type RequestReviewForm = z.infer<typeof requestReviewSchema>;

export function ReviewsClient() {
  const [cycles, setCycles] = useState<ReviewCycle[]>(initialCycles);
  const [expandedCycle, setExpandedCycle] = useState<string | null>(
    initialCycles[0]?.id ?? null
  );
  const [dialogOpen, setDialogOpen] = useState(false);

  const activeCycles = cycles.filter((c) => c.status === "active");
  const upcomingCycles = cycles.filter((c) => c.status === "upcoming");
  const completedCycles = cycles.filter((c) => c.status === "completed");

  return (
    <div className="px-6 py-6">
      <PageHeader
        eyebrow="Performance reviews"
        title="Review cycles"
        subtitle="Track every active, upcoming, and completed review cycle. Expand a cycle to see per-participant completion progress."
        actions={
          <Button
            onClick={() => setDialogOpen(true)}
            className="bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90 rounded-[8px] h-9 cursor-pointer"
          >
            <Plus className="h-4 w-4 mr-1" strokeWidth={1.5} />
            Request review
          </Button>
        }
      />

      <div className="mt-6 space-y-6">
        <CycleSection
          label="Active"
          cycles={activeCycles}
          expandedCycle={expandedCycle}
          onToggle={(id) =>
            setExpandedCycle((v) => (v === id ? null : id))
          }
        />
        <CycleSection
          label="Upcoming"
          cycles={upcomingCycles}
          expandedCycle={expandedCycle}
          onToggle={(id) =>
            setExpandedCycle((v) => (v === id ? null : id))
          }
        />
        <CycleSection
          label="Completed"
          cycles={completedCycles}
          expandedCycle={expandedCycle}
          onToggle={(id) =>
            setExpandedCycle((v) => (v === id ? null : id))
          }
        />
      </div>

      <RequestReviewDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        cycles={cycles}
        onSubmit={(data) => {
          // Add the reviewee to the cycle as a participant with 0% completion
          setCycles((prev) =>
            prev.map((c) =>
              c.id === data.cycleId
                ? {
                    ...c,
                    participants: [
                      ...c.participants,
                      { employeeId: data.revieweeId, completionPct: 0 },
                    ],
                  }
                : c
            )
          );
          setDialogOpen(false);
          const reviewee = getEmployeeById(data.revieweeId);
          const reviewer = getEmployeeById(data.reviewerId);
          toast({
            title: "Review requested",
            description: `${reviewer?.name ?? "Reviewer"} will review ${reviewee?.name ?? "this person"} by ${format(data.dueDate, "MMM d, yyyy")}.`,
          });
        }}
      />
    </div>
  );
}

function CycleSection({
  label,
  cycles,
  expandedCycle,
  onToggle,
}: {
  label: string;
  cycles: ReviewCycle[];
  expandedCycle: string | null;
  onToggle: (id: string) => void;
}) {
  if (cycles.length === 0) return null;
  return (
    <section>
      <div className="flex items-center gap-2 mb-3">
        <h2 className="eyebrow">{label}</h2>
        <span className="text-[0.75rem] font-data text-[var(--text-tertiary)] tabular-nums">
          {cycles.length}
        </span>
      </div>
      <div className="space-y-2">
        {cycles.map((c) => (
          <CycleCard
            key={c.id}
            cycle={c}
            expanded={expandedCycle === c.id}
            onToggle={() => onToggle(c.id)}
          />
        ))}
      </div>
    </section>
  );
}

function CycleCard({
  cycle,
  expanded,
  onToggle,
}: {
  cycle: ReviewCycle;
  expanded: boolean;
  onToggle: () => void;
}) {
  const reduceMotion = useReducedMotion();
  const completed = cycle.participants.filter((p) => p.completionPct === 100).length;
  const total = cycle.participants.length;
  const avgCompletion =
    total === 0
      ? 0
      : Math.round(
          cycle.participants.reduce((s, p) => s + p.completionPct, 0) / total
        );

  return (
    <div className="rounded-[18px] border border-[var(--border-default)] bg-[var(--surface)] overflow-hidden">
      <button
        onClick={onToggle}
        aria-expanded={expanded}
        className="w-full flex items-center gap-4 p-4 text-left cursor-pointer hover:bg-[var(--surface-alt)] transition-colors"
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-display text-base font-medium text-[var(--text-primary)] truncate">
              {cycle.name}
            </h3>
            <StatusBadge
              variant={
                cycle.status === "active"
                  ? "coral"
                  : cycle.status === "upcoming"
                    ? "new_hire"
                    : "mint"
              }
              label={
                cycle.status === "active"
                  ? "Active"
                  : cycle.status === "upcoming"
                    ? "Upcoming"
                    : "Completed"
              }
            />
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-[0.75rem] text-[var(--text-tertiary)]">
            <span className="inline-flex items-center gap-1">
              <Calendar className="h-3 w-3" strokeWidth={1.5} />
              {new Date(cycle.startDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
              {" → "}
              {new Date(cycle.endDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
            </span>
            <span className="inline-flex items-center gap-1">
              <Users className="h-3 w-3" strokeWidth={1.5} />
              <span className="font-data tabular-nums">{total}</span> participants
            </span>
            <span className="inline-flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" strokeWidth={1.5} />
              <span className="font-data tabular-nums">{completed}</span> done
            </span>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-3">
          <div className="w-32">
            <div className="flex justify-between text-[0.6875rem] text-[var(--text-tertiary)] mb-1">
              <span>Progress</span>
              <span className="font-data tabular-nums">{avgCompletion}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-[var(--surface-alt)] overflow-hidden">
              <motion.div
                initial={reduceMotion ? false : { width: 0 }}
                animate={{ width: `${avgCompletion}%` }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="h-full rounded-full bg-[var(--accent-coral)]"
              />
            </div>
          </div>
        </div>
        <motion.span
          animate={{ rotate: expanded ? 180 : 0 }}
          transition={{ duration: reduceMotion ? 0 : 0.2 }}
          className="inline-flex text-[var(--text-tertiary)] shrink-0"
        >
          <ChevronDown className="h-4 w-4" strokeWidth={1.5} />
        </motion.span>
      </button>
      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: reduceMotion ? 0 : 0.28, ease: [0.16, 1, 0.3, 1] }}
            className="overflow-hidden border-t border-[var(--border-default)] bg-[var(--surface-alt)]"
          >
            <div className="p-4">
              <p className="eyebrow mb-3">Participants</p>
              <ul className="space-y-2">
                {cycle.participants.map((p) => {
                  const emp = getEmployeeById(p.employeeId);
                  if (!emp) return null;
                  return (
                    <li
                      key={p.employeeId}
                      className="flex items-center gap-3 rounded-[12px] bg-[var(--surface)] p-3"
                    >
                      <Avatar name={emp.name} seed={emp.avatarSeed} size="xs" />
                      <div className="flex-1 min-w-0">
                        <div className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
                          {emp.name}
                        </div>
                        <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                          {emp.title}
                        </div>
                      </div>
                      <div className="w-32 sm:w-48">
                        <div className="flex justify-between text-[0.6875rem] text-[var(--text-tertiary)] mb-1">
                          <span>
                            {p.completionPct === 100 ? (
                              <span className="inline-flex items-center gap-1 text-[var(--accent-mint)]">
                                <CheckCircle2 className="h-3 w-3" strokeWidth={1.5} />
                                Done
                              </span>
                            ) : p.completionPct > 0 ? (
                              <span className="inline-flex items-center gap-1 text-[var(--status-amber)]">
                                <Clock className="h-3 w-3" strokeWidth={1.5} />
                                In progress
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[var(--text-tertiary)]">
                                <AlertCircle className="h-3 w-3" strokeWidth={1.5} />
                                Not started
                              </span>
                            )}
                          </span>
                          <span className="font-data tabular-nums">{p.completionPct}%</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-[var(--surface-alt)] overflow-hidden">
                          <div
                            className={cn(
                              "h-full rounded-full",
                              p.completionPct === 100
                                ? "bg-[var(--accent-mint)]"
                                : p.completionPct > 0
                                  ? "bg-[var(--status-amber)]"
                                  : "bg-[var(--text-tertiary)]"
                            )}
                            style={{ width: `${p.completionPct}%` }}
                          />
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function RequestReviewDialog({
  open,
  onOpenChange,
  cycles,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  cycles: ReviewCycle[];
  onSubmit: (data: RequestReviewForm) => void;
}) {
  const activeCycles = cycles.filter((c) => c.status === "active" || c.status === "upcoming");
  const {
    handleSubmit,
    setValue,
    control,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<RequestReviewForm>({
    resolver: zodResolver(requestReviewSchema),
    defaultValues: {
      revieweeId: "",
      reviewerId: "",
      cycleId: activeCycles[0]?.id ?? "",
    },
  });

  const values = useWatch({ control });

  const handleClose = (v: boolean) => {
    if (!v) reset();
    onOpenChange(v);
  };

  // Build a searchable employee list for the combobox-style picker
  const [revieweeQuery, setRevieweeQuery] = useState("");
  const [reviewerQuery, setReviewerQuery] = useState("");
  const filteredReviewees = useMemo(
    () =>
      employees.filter((e) =>
        `${e.name} ${e.title} ${e.department}`
          .toLowerCase()
          .includes(revieweeQuery.toLowerCase())
      ),
    [revieweeQuery]
  );
  const filteredReviewers = useMemo(
    () =>
      employees.filter((e) =>
        `${e.name} ${e.title} ${e.department}`
          .toLowerCase()
          .includes(reviewerQuery.toLowerCase())
      ),
    [reviewerQuery]
  );

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md rounded-[18px] border-[var(--border-default)] bg-[var(--surface)]">
        <DialogHeader>
          <DialogTitle className="font-display text-xl font-medium">
            Request a review
          </DialogTitle>
          <DialogDescription className="text-[var(--text-secondary)]">
            Assign a reviewer to a person for an active or upcoming cycle.
          </DialogDescription>
        </DialogHeader>
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="space-y-4 py-2"
          noValidate
        >
          {/* Reviewee combobox */}
          <div className="space-y-1.5">
            <Label className="text-[0.8125rem] font-medium">Person to review</Label>
            <Combobox
              value={values?.revieweeId ?? ""}
              onChange={(v) => setValue("revieweeId", v, { shouldValidate: true })}
              query={revieweeQuery}
              onQueryChange={setRevieweeQuery}
              filtered={filteredReviewees}
              placeholder="Search a person…"
              error={errors.revieweeId?.message}
            />
          </div>

          {/* Reviewer combobox */}
          <div className="space-y-1.5">
            <Label className="text-[0.8125rem] font-medium">Reviewer</Label>
            <Combobox
              value={values?.reviewerId ?? ""}
              onChange={(v) => setValue("reviewerId", v, { shouldValidate: true })}
              query={reviewerQuery}
              onQueryChange={setReviewerQuery}
              filtered={filteredReviewers}
              placeholder="Search a reviewer…"
              error={errors.reviewerId?.message}
            />
          </div>

          {/* Cycle select */}
          <div className="space-y-1.5">
            <Label className="text-[0.8125rem] font-medium">Cycle</Label>
            <Select
              value={values?.cycleId ?? ""}
              onValueChange={(v) => setValue("cycleId", v, { shouldValidate: true })}
            >
              <SelectTrigger className="rounded-[8px] border-[var(--border-default)] bg-[var(--surface)]">
                <SelectValue placeholder="Pick a cycle" />
              </SelectTrigger>
              <SelectContent className="rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]">
                {activeCycles.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.cycleId && (
              <p className="text-[0.75rem] text-[var(--status-brick)] flex items-center gap-1">
                <AlertCircle className="h-3 w-3" strokeWidth={1.5} />
                {errors.cycleId.message}
              </p>
            )}
          </div>

          {/* Due date picker (Radix calendar) */}
          <div className="space-y-1.5">
            <Label className="text-[0.8125rem] font-medium">Due date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal rounded-[8px] border-[var(--border-default)] bg-[var(--surface)] h-9 cursor-pointer",
                    !values?.dueDate && "text-[var(--text-tertiary)]"
                  )}
                >
                  <Calendar className="h-4 w-4 mr-2" strokeWidth={1.5} />
                  {(() => {
                    const due = values?.dueDate;
                    return due ? format(due, "MMM d, yyyy") : "Pick a due date";
                  })()}
                </Button>
              </PopoverTrigger>
              <PopoverContent
                className="w-auto p-0 rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]"
                align="start"
              >
                <CalendarComponent
                  mode="single"
                  selected={values?.dueDate}
                  onSelect={(d) => d && setValue("dueDate", d, { shouldValidate: true })}
                  disabled={(d) => d < new Date()}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            {errors.dueDate && (
              <p className="text-[0.75rem] text-[var(--status-brick)] flex items-center gap-1">
                <AlertCircle className="h-3 w-3" strokeWidth={1.5} />
                {errors.dueDate.message as string}
              </p>
            )}
          </div>

          <DialogFooter className="pt-2">
            <Button
              type="button"
              variant="ghost"
              onClick={() => handleClose(false)}
              className="rounded-[8px] cursor-pointer"
            >
              <X className="h-4 w-4 mr-1" strokeWidth={1.5} />
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-[var(--accent-coral)] text-white hover:bg-[var(--accent-coral)]/90 rounded-[8px] cursor-pointer"
            >
              {isSubmitting ? "Sending…" : "Send request"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/** Combobox — Radix Popover + cmdk-style list. */
function Combobox({
  value,
  onChange,
  query,
  onQueryChange,
  filtered,
  placeholder,
  error,
}: {
  value: string;
  onChange: (v: string) => void;
  query: string;
  onQueryChange: (q: string) => void;
  filtered: typeof employees;
  placeholder: string;
  error?: string;
}) {
  const [open, setOpen] = useState(false);
  const selected = employees.find((e) => e.id === value);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn(
            "w-full justify-start text-left font-normal rounded-[8px] border-[var(--border-default)] bg-[var(--surface)] h-9 cursor-pointer",
            !value && "text-[var(--text-tertiary)]",
            error && "border-[var(--status-brick)]"
          )}
        >
          {selected ? (
            <span className="inline-flex items-center gap-2">
              <Avatar name={selected.name} seed={selected.avatarSeed} size="xs" />
              <span className="text-[var(--text-primary)]">{selected.name}</span>
              <span className="text-[var(--text-tertiary)] text-[0.75rem]">· {selected.title}</span>
            </span>
          ) : (
            placeholder
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        className="w-[400px] max-w-[calc(100vw-2rem)] p-0 rounded-[12px] border-[var(--border-default)] bg-[var(--surface)]"
        align="start"
      >
        <div className="p-2 border-b border-[var(--border-default)]">
          <Input
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder="Type to search…"
            className="h-8 rounded-[6px] border-[var(--border-default)] bg-[var(--surface-alt)]"
            aria-label="Search employees"
          />
        </div>
        <div className="max-h-[240px] overflow-y-auto p-1">
          {filtered.length === 0 ? (
            <div className="px-3 py-6 text-center text-[0.8125rem] text-[var(--text-tertiary)]">
              No matches
            </div>
          ) : (
            filtered.map((e) => (
              <button
                key={e.id}
                type="button"
                onClick={() => {
                  onChange(e.id);
                  setOpen(false);
                }}
                className={cn(
                  "w-full flex items-center gap-2 px-2 py-2 rounded-[8px] text-left cursor-pointer",
                  value === e.id
                    ? "bg-[var(--accent-coral-soft)]"
                    : "hover:bg-[var(--surface-alt)]"
                )}
              >
                <Avatar name={e.name} seed={e.avatarSeed} size="xs" />
                <div className="min-w-0 flex-1">
                  <div className="text-[0.8125rem] font-medium text-[var(--text-primary)] truncate">
                    {e.name}
                  </div>
                  <div className="text-[0.6875rem] text-[var(--text-tertiary)] truncate">
                    {e.title} · {e.department}
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
