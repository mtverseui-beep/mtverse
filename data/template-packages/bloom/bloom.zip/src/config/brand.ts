/**
 * Bloom brand config — single source of truth for reskinnable identity.
 * Rebrand by editing the values below; nothing else in the app hardcodes these.
 */
export const brand = {
  name: "Bloom",
  tagline: "Know your people, not just your headcount.",
  /** Used by the og image generator, sidebar footer, and metadata. */
  description:
    "A warm, human, precise People Operations dashboard with a real interactive org chart at its center.",
  /** Year shown in footer + license metadata. */
  foundedYear: 2026,
  /** Primary support / contact shown in the Settings page. */
  contactEmail: "hello@bloom.template",
} as const;

export type Brand = typeof brand;
