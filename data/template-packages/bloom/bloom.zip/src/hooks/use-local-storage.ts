"use client";

import { useSyncExternalStore, useCallback, useRef } from "react";

/**
 * useLocalStorage — React 19-idiomatic localStorage hook for any JSON-serializable value.
 *
 * Uses `useSyncExternalStore` so the value is read on the client without
 * triggering setState-in-effect (which both hydrates cleanly and satisfies
 * the strict react-hooks/set-state-in-effect rule).
 *
 * IMPORTANT: getSnapshot must return a cached value (same reference across calls
 * if the underlying data hasn't changed) — otherwise React throws
 * "The result of getSnapshot should be cached to avoid an infinite loop".
 * We cache the last parsed JSON value in a ref and only re-parse when the
 * raw localStorage string changes.
 *
 * Returns `[value, setValue]` where setValue accepts either a value or an updater.
 */
function subscribe(callback: () => void) {
  if (typeof window === "undefined") return () => {};
  window.addEventListener("storage", callback);
  return () => window.removeEventListener("storage", callback);
}

export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (v: T | ((prev: T) => T)) => void] {
  // Cache the last raw string + parsed value so getSnapshot is referentially stable.
  const cacheRef = useRef<{ raw: string | null; parsed: T }>({
    raw: null,
    parsed: initialValue,
  });

  const getSnapshot = useCallback(() => {
    if (typeof window === "undefined") return initialValue;
    const raw = window.localStorage.getItem(key);
    if (raw === cacheRef.current.raw) {
      return cacheRef.current.parsed;
    }
    // Raw value changed — re-parse and cache.
    if (raw === null) {
      cacheRef.current = { raw: null, parsed: initialValue };
      return initialValue;
    }
    try {
      const parsed = JSON.parse(raw) as T;
      cacheRef.current = { raw, parsed };
      return parsed;
    } catch {
      cacheRef.current = { raw, parsed: initialValue };
      return initialValue;
    }
  }, [key, initialValue]);

  const value = useSyncExternalStore(
    subscribe,
    getSnapshot,
    () => initialValue // SSR snapshot
  );

  const setValue = useCallback(
    (v: T | ((prev: T) => T)) => {
      if (typeof window === "undefined") return;
      const current = window.localStorage.getItem(key);
      const prev: T =
        current === null
          ? initialValue
          : (() => {
              try {
                return JSON.parse(current) as T;
              } catch {
                return initialValue;
              }
            })();
      const next = typeof v === "function" ? (v as (p: T) => T)(prev) : v;
      const nextRaw = JSON.stringify(next);
      window.localStorage.setItem(key, nextRaw);
      // Update the cache immediately so the next getSnapshot returns the new
      // value with a stable reference.
      cacheRef.current = { raw: nextRaw, parsed: next };
      // Same-window sets don't fire a `storage` event — dispatch one manually
      // so useSyncExternalStore re-reads.
      window.dispatchEvent(
        new StorageEvent("storage", {
          key,
          newValue: nextRaw,
        })
      );
    },
    [key, initialValue]
  );

  return [value, setValue];
}

/**
 * useLocalStorageBoolean — convenience wrapper for boolean values stored as
 * "true"/"false" strings (not JSON). Booleans are primitives so referential
 * stability is automatic — no caching needed.
 */
export function useLocalStorageBoolean(
  key: string,
  initialValue: boolean
): [boolean, (v: boolean | ((prev: boolean) => boolean)) => void] {
  const value = useSyncExternalStore(
    subscribe,
    () => {
      if (typeof window === "undefined") return initialValue;
      const stored = window.localStorage.getItem(key);
      return stored === null ? initialValue : stored === "true";
    },
    () => initialValue
  );

  const setValue = useCallback(
    (v: boolean | ((prev: boolean) => boolean)) => {
      if (typeof window === "undefined") return;
      const current = window.localStorage.getItem(key);
      const prev = current === null ? initialValue : current === "true";
      const next = typeof v === "function" ? v(prev) : v;
      window.localStorage.setItem(key, String(next));
      window.dispatchEvent(
        new StorageEvent("storage", { key, newValue: String(next) })
      );
    },
    [key, initialValue]
  );

  return [value, setValue];
}


