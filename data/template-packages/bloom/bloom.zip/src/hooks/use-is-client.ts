"use client";

import { useSyncExternalStore } from "react";

/**
 * useIsClient — returns false during SSR, true on the client.
 *
 * Uses `useSyncExternalStore` so it hydrates cleanly without
 * the `react-hooks/set-state-in-effect` pattern that ESLint flags.
 *
 * Use this for any "mounted" check (theme toggles, client-only widgets,
 * localStorage reads, etc.) instead of `useState(false) + useEffect`.
 */
export function useIsClient() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );
}
