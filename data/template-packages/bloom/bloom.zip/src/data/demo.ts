/**
 * Bloom — typed demo dataset.
 *
 * Single source of truth for every page in the app. Deterministic (no Math.random in render
 * path) so the org chart, kanban, and every chart look like a real company on first load.
 *
 * Tree shape is validated at module load by `validateOrgTree` — if a future edit introduces
 * a cycle, an orphan, or a multi-root structure, dev throws immediately. (See §6, §12.)
 */

export type Department =
  | "Engineering"
  | "Design"
  | "Sales"
  | "Marketing"
  | "People"
  | "Finance";

export type EmploymentStatus = "active" | "on_leave" | "new_hire";

export type Employee = {
  id: string;
  name: string;
  title: string;
  department: Department;
  managerId: string | null; // null = root (exactly one)
  status: EmploymentStatus;
  tenureYears: number;
  startDate: string; // ISO
  location: string;
  email: string;
  phone: string;
  /** Flight-risk score 0-100 — used by attrition + directory flags. */
  flightRisk: number;
  /** Annual salary band label — drives tabular-nums rendering in directory. */
  salaryBand: string;
  /** Deterministic avatar seed (used by DiceBear-style generator). */
  avatarSeed: string;
  /** Short bio shown in the person detail panel. */
  bio: string;
};

export type Candidate = {
  id: string;
  name: string;
  roleAppliedFor: string;
  stage: "applied" | "screening" | "interview" | "offer" | "hired";
  daysInStage: number;
  avatarSeed: string;
  source: string;
};

export type ReviewCycle = {
  id: string;
  name: string;
  status: "active" | "upcoming" | "completed";
  startDate: string;
  endDate: string;
  participants: {
    employeeId: string;
    completionPct: number;
  }[];
};

export type AttritionMonth = {
  month: string; // "2025-01"
  rate: number; // percentage
  departures: number;
  headcount: number;
};

export type AttritionReason = {
  reason: string;
  count: number;
  pct: number;
};

export type DepartmentAttrition = {
  department: Department;
  rate: number;
  headcount: number;
  departures: number;
};

export type Note = {
  id: string;
  employeeId: string;
  author: string;
  createdAt: string;
  body: string;
};

export type ReviewEntry = {
  id: string;
  employeeId: string;
  cycleId: string;
  reviewer: string;
  submittedAt: string;
  rating: number; // 1-5
  summary: string;
};

/* ---------------------------------------------------------------------------
   EMPLOYEES — 54 people, single-root, cycle-free.
   CEO = Maya Okafor (id "e001", managerId null).
   Hierarchy hand-crafted to be a believable 150-400-person company slice.
--------------------------------------------------------------------------- */

export const employees: Employee[] = [
  // ====== ROOT ======
  {
    id: "e001",
    name: "Maya Okafor",
    title: "Chief Executive Officer",
    department: "People",
    managerId: null,
    status: "active",
    tenureYears: 7.5,
    startDate: "2018-06-01",
    location: "San Francisco, CA",
    email: "maya.okafor@bloom.demo",
    phone: "+1 (415) 555-0101",
    flightRisk: 4,
    salaryBand: "E6",
    avatarSeed: "maya-okafor",
    bio: "Maya co-founded Bloom in 2018. Before Bloom she led People Ops at a 600-person fintech and now writes about org design quarterly.",
  },

  // ====== C-SUITE (report to Maya) ======
  {
    id: "e002",
    name: "Daniel Reyes",
    title: "Chief Technology Officer",
    department: "Engineering",
    managerId: "e001",
    status: "active",
    tenureYears: 5.8,
    startDate: "2020-04-12",
    location: "San Francisco, CA",
    email: "daniel.reyes@bloom.demo",
    phone: "+1 (415) 555-0110",
    flightRisk: 7,
    salaryBand: "E6",
    avatarSeed: "daniel-reyes",
    bio: "Daniel owns platform + product engineering. Came from an infra background and is rebuilding Bloom's data layer this year.",
  },
  {
    id: "e003",
    name: "Priya Nair",
    title: "VP, People Operations",
    department: "People",
    managerId: "e001",
    status: "active",
    tenureYears: 4.2,
    startDate: "2021-09-15",
    location: "Remote (Austin, TX)",
    email: "priya.nair@bloom.demo",
    phone: "+1 (512) 555-0120",
    flightRisk: 11,
    salaryBand: "E5",
    avatarSeed: "priya-nair",
    bio: "Priya runs hiring, performance, and culture. Designed the review cycle framework used across every team at Bloom.",
  },
  {
    id: "e004",
    name: "Marcus Chen",
    title: "Chief Financial Officer",
    department: "Finance",
    managerId: "e001",
    status: "on_leave",
    tenureYears: 3.9,
    startDate: "2022-02-01",
    location: "New York, NY",
    email: "marcus.chen@bloom.demo",
    phone: "+1 (212) 555-0130",
    flightRisk: 9,
    salaryBand: "E6",
    avatarSeed: "marcus-chen",
    bio: "Marcus is on a 6-week sabbatical through Q1. Acting CFO coverage is provided by Aisha Bello.",
  },
  {
    id: "e005",
    name: "Sofia Almeida",
    title: "VP, Sales",
    department: "Sales",
    managerId: "e001",
    status: "active",
    tenureYears: 2.4,
    startDate: "2023-08-20",
    location: "Chicago, IL",
    email: "sofia.almeida@bloom.demo",
    phone: "+1 (312) 555-0140",
    flightRisk: 22,
    salaryBand: "E5",
    avatarSeed: "sofia-almeida",
    bio: "Sofia leads enterprise + SMB sales. Joined Bloom after scaling a SaaS sales org from 8 to 60 reps in three years.",
  },
  {
    id: "e006",
    name: "Tomás Rivera",
    title: "VP, Marketing",
    department: "Marketing",
    managerId: "e001",
    status: "active",
    tenureYears: 3.1,
    startDate: "2022-09-12",
    location: "Remote (Denver, CO)",
    email: "tomas.rivera@bloom.demo",
    phone: "+1 (303) 555-0150",
    flightRisk: 13,
    salaryBand: "E5",
    avatarSeed: "tomas-rivera",
    bio: "Tomás runs brand, content, and demand gen. Spent a decade in agency before going in-house.",
  },

  // ====== ENGINEERING (reports to Daniel Reyes, e002) ======
  {
    id: "e010",
    name: "Aiko Tanaka",
    title: "Director of Engineering, Platform",
    department: "Engineering",
    managerId: "e002",
    status: "active",
    tenureYears: 4.0,
    startDate: "2021-11-04",
    location: "Remote (Seattle, WA)",
    email: "aiko.tanaka@bloom.demo",
    phone: "+1 (206) 555-0201",
    flightRisk: 6,
    salaryBand: "E5",
    avatarSeed: "aiko-tanaka",
    bio: "Aiko owns the platform team — auth, billing infra, and internal tooling. Strong opinions about developer experience.",
  },
  {
    id: "e011",
    name: "Rahul Mehta",
    title: "Director of Engineering, Product",
    department: "Engineering",
    managerId: "e002",
    status: "active",
    tenureYears: 2.9,
    startDate: "2023-01-09",
    location: "San Francisco, CA",
    email: "rahul.mehta@bloom.demo",
    phone: "+1 (415) 555-0202",
    flightRisk: 18,
    salaryBand: "E5",
    avatarSeed: "rahul-mehta",
    bio: "Rahul leads the product engineering org — three squads shipping the customer-facing app.",
  },
  {
    id: "e012",
    name: "Hannah Williams",
    title: "Engineering Manager, Identity",
    department: "Engineering",
    managerId: "e010",
    status: "active",
    tenureYears: 3.4,
    startDate: "2022-05-18",
    location: "Remote (Portland, OR)",
    email: "hannah.williams@bloom.demo",
    phone: "+1 (503) 555-0211",
    flightRisk: 9,
    salaryBand: "E4",
    avatarSeed: "hannah-williams",
    bio: "Hannah manages the Identity squad. Five engineers, ships in two-week cadences.",
  },
  {
    id: "e013",
    name: "Kwame Mensah",
    title: "Senior Engineer, Identity",
    department: "Engineering",
    managerId: "e012",
    status: "active",
    tenureYears: 2.1,
    startDate: "2023-07-22",
    location: "Remote (Atlanta, GA)",
    email: "kwame.mensah@bloom.demo",
    phone: "+1 (404) 555-0221",
    flightRisk: 14,
    salaryBand: "E4",
    avatarSeed: "kwame-mensah",
    bio: "Kwame is the team's senior IC. Mentor to two mid-level engineers and runs the on-call rotation.",
  },
  {
    id: "e014",
    name: "Lucia Pereira",
    title: "Software Engineer, Identity",
    department: "Engineering",
    managerId: "e012",
    status: "new_hire",
    tenureYears: 0.2,
    startDate: "2025-10-01",
    location: "Remote (Boston, MA)",
    email: "lucia.pereira@bloom.demo",
    phone: "+1 (617) 555-0222",
    flightRisk: 5,
    salaryBand: "E3",
    avatarSeed: "lucia-pereira",
    bio: "Lucia joined Bloom two months ago from a fintech. Currently ramping on the auth migration.",
  },
  {
    id: "e015",
    name: "Wei Zhang",
    title: "Software Engineer, Identity",
    department: "Engineering",
    managerId: "e012",
    status: "active",
    tenureYears: 1.6,
    startDate: "2024-03-15",
    location: "San Francisco, CA",
    email: "wei.zhang@bloom.demo",
    phone: "+1 (415) 555-0223",
    flightRisk: 21,
    salaryBand: "E3",
    avatarSeed: "wei-zhang",
    bio: "Wei works on session security. Recently shipped device-based step-up auth.",
  },
  {
    id: "e016",
    name: "Olu Adesanya",
    title: "Engineering Manager, Billing",
    department: "Engineering",
    managerId: "e010",
    status: "active",
    tenureYears: 2.7,
    startDate: "2023-04-03",
    location: "Remote (Houston, TX)",
    email: "olu.adesanya@bloom.demo",
    phone: "+1 (713) 555-0231",
    flightRisk: 12,
    salaryBand: "E4",
    avatarSeed: "olu-adesanya",
    bio: "Olu manages the Billing squad — invoicing, tax, and the Stripe integration.",
  },
  {
    id: "e017",
    name: "Sara Lindqvist",
    title: "Senior Engineer, Billing",
    department: "Engineering",
    managerId: "e016",
    status: "active",
    tenureYears: 2.3,
    startDate: "2023-08-14",
    location: "Remote (Stockholm, SE)",
    email: "sara.lindqvist@bloom.demo",
    phone: "+46 8 555 0232",
    flightRisk: 28,
    salaryBand: "E4",
    avatarSeed: "sara-lindqvist",
    bio: "Sara led the EU VAT compliance migration last year. Currently on a 4-month rotation in the Stockholm office.",
  },
  {
    id: "e018",
    name: "Diego Fernández",
    title: "Software Engineer, Billing",
    department: "Engineering",
    managerId: "e016",
    status: "active",
    tenureYears: 1.1,
    startDate: "2024-09-02",
    location: "Remote (Madrid, ES)",
    email: "diego.fernandez@bloom.demo",
    phone: "+34 91 555 0233",
    flightRisk: 17,
    salaryBand: "E3",
    avatarSeed: "diego-fernandez",
    bio: "Diego works on usage-based billing features. Recent grad, joined Bloom full-time after an internship.",
  },
  {
    id: "e019",
    name: "Yara Haddad",
    title: "Engineering Manager, Product Web",
    department: "Engineering",
    managerId: "e011",
    status: "active",
    tenureYears: 2.0,
    startDate: "2023-11-06",
    location: "San Francisco, CA",
    email: "yara.haddad@bloom.demo",
    phone: "+1 (415) 555-0241",
    flightRisk: 15,
    salaryBand: "E4",
    avatarSeed: "yara-haddad",
    bio: "Yara manages the web app squad. Owner of the dashboard redesign shipping this quarter.",
  },
  {
    id: "e020",
    name: "Felix Bauer",
    title: "Senior Engineer, Product Web",
    department: "Engineering",
    managerId: "e019",
    status: "active",
    tenureYears: 2.8,
    startDate: "2023-02-20",
    location: "Remote (Berlin, DE)",
    email: "felix.bauer@bloom.demo",
    phone: "+49 30 555 0242",
    flightRisk: 11,
    salaryBand: "E4",
    avatarSeed: "felix-bauer",
    bio: "Felix owns the design-system implementation. Frequent contributor to the open-source Tailwind plugin we use.",
  },
  {
    id: "e021",
    name: "Nina Petrov",
    title: "Software Engineer, Product Web",
    department: "Engineering",
    managerId: "e019",
    status: "active",
    tenureYears: 0.9,
    startDate: "2024-11-18",
    location: "Remote (Sofia, BG)",
    email: "nina.petrov@bloom.demo",
    phone: "+359 2 555 0243",
    flightRisk: 8,
    salaryBand: "E3",
    avatarSeed: "nina-petrov",
    bio: "Nina works on accessibility and keyboard navigation across the product.",
  },
  {
    id: "e022",
    name: "Arjun Kapoor",
    title: "Engineering Manager, Product Mobile",
    department: "Engineering",
    managerId: "e011",
    status: "active",
    tenureYears: 1.8,
    startDate: "2024-02-05",
    location: "Remote (Toronto, CA)",
    email: "arjun.kapoor@bloom.demo",
    phone: "+1 (416) 555-0251",
    flightRisk: 19,
    salaryBand: "E4",
    avatarSeed: "arjun-kapoor",
    bio: "Arjun manages the iOS + Android squad. Joined Bloom after shipping a top-100 finance app.",
  },
  {
    id: "e023",
    name: "Mei Lin Chen",
    title: "Senior Engineer, Mobile",
    department: "Engineering",
    managerId: "e022",
    status: "active",
    tenureYears: 1.5,
    startDate: "2024-05-13",
    location: "Remote (Vancouver, CA)",
    email: "mei.lin.chen@bloom.demo",
    phone: "+1 (604) 555-0252",
    flightRisk: 24,
    salaryBand: "E4",
    avatarSeed: "mei-lin-chen",
    bio: "Mei Lin owns the iOS codebase. Recently shipped the offline-mode sync layer.",
  },
  {
    id: "e024",
    name: "Bram de Vries",
    title: "Software Engineer, Mobile",
    department: "Engineering",
    managerId: "e022",
    status: "new_hire",
    tenureYears: 0.1,
    startDate: "2025-11-15",
    location: "Remote (Amsterdam, NL)",
    email: "bram.devries@bloom.demo",
    phone: "+31 20 555 0253",
    flightRisk: 3,
    salaryBand: "E3",
    avatarSeed: "bram-devries",
    bio: "Bram joined three weeks ago and is ramping on the Android codebase.",
  },

  // ====== DESIGN (reports to Priya Nair, e003 — Design reports through People for this demo) ======
  {
    id: "e030",
    name: "Isabella Romano",
    title: "Head of Design",
    department: "Design",
    managerId: "e003",
    status: "active",
    tenureYears: 3.6,
    startDate: "2022-04-11",
    location: "Remote (Milan, IT)",
    email: "isabella.romano@bloom.demo",
    phone: "+39 02 555 0301",
    flightRisk: 16,
    salaryBand: "E5",
    avatarSeed: "isabella-romano",
    bio: "Isabella runs the design org — product design, brand, and research. Built the Bloom design system from scratch.",
  },
  {
    id: "e031",
    name: "Jordan Park",
    title: "Senior Product Designer",
    department: "Design",
    managerId: "e030",
    status: "active",
    tenureYears: 2.5,
    startDate: "2023-06-19",
    location: "Remote (Seoul, KR)",
    email: "jordan.park@bloom.demo",
    phone: "+82 2 555 0311",
    flightRisk: 13,
    salaryBand: "E4",
    avatarSeed: "jordan-park",
    bio: "Jordan owns the dashboard and reporting surfaces. Working closely with Yara's web squad on the redesign.",
  },
  {
    id: "e032",
    name: "Amara Diallo",
    title: "Product Designer",
    department: "Design",
    managerId: "e030",
    status: "active",
    tenureYears: 1.4,
    startDate: "2024-07-22",
    location: "Remote (Dakar, SN)",
    email: "amara.diallo@bloom.demo",
    phone: "+221 33 555 0312",
    flightRisk: 9,
    salaryBand: "E3",
    avatarSeed: "amara-diallo",
    bio: "Amara designs the onboarding + setup flows. Owns the empty-state illustrations across the product.",
  },
  {
    id: "e033",
    name: "Ethan Brooks",
    title: "Product Designer",
    department: "Design",
    managerId: "e030",
    status: "new_hire",
    tenureYears: 0.3,
    startDate: "2025-09-08",
    location: "Remote (Dublin, IE)",
    email: "ethan.brooks@bloom.demo",
    phone: "+353 1 555 0313",
    flightRisk: 4,
    salaryBand: "E3",
    avatarSeed: "ethan-brooks",
    bio: "Ethan joined six weeks ago from an agency background. Designing the mobile notification center.",
  },
  {
    id: "e034",
    name: "Riya Iyer",
    title: "UX Researcher",
    department: "Design",
    managerId: "e030",
    status: "active",
    tenureYears: 2.0,
    startDate: "2023-12-04",
    location: "Remote (Bangalore, IN)",
    email: "riya.iyer@bloom.demo",
    phone: "+91 80 555 0314",
    flightRisk: 19,
    salaryBand: "E4",
    avatarSeed: "riya-iyer",
    bio: "Riya runs the research practice. Quarterly interviews with 30+ customers; reports feed directly into roadmap.",
  },

  // ====== PEOPLE OPS (reports to Priya Nair, e003) ======
  {
    id: "e040",
    name: "Hassan Ali",
    title: "Senior Recruiter",
    department: "People",
    managerId: "e003",
    status: "active",
    tenureYears: 2.2,
    startDate: "2023-09-12",
    location: "Remote (Cairo, EG)",
    email: "hassan.ali@bloom.demo",
    phone: "+20 2 555 0401",
    flightRisk: 14,
    salaryBand: "E4",
    avatarSeed: "hassan-ali",
    bio: "Hassan owns engineering + design recruiting. Runs the structured-interview rubric used across all eng loops.",
  },
  {
    id: "e041",
    name: "Lena Müller",
    title: "Recruiter",
    department: "People",
    managerId: "e003",
    status: "active",
    tenureYears: 0.8,
    startDate: "2024-12-09",
    location: "Remote (Munich, DE)",
    email: "lena.muller@bloom.demo",
    phone: "+49 89 555 0402",
    flightRisk: 7,
    salaryBand: "E3",
    avatarSeed: "lena-muller",
    bio: "Lena recruits for sales, marketing, and finance roles across EMEA.",
  },
  {
    id: "e042",
    name: "Naomi Carter",
    title: "People Operations Manager",
    department: "People",
    managerId: "e003",
    status: "active",
    tenureYears: 3.0,
    startDate: "2022-10-03",
    location: "Remote (Nashville, TN)",
    email: "naomi.carter@bloom.demo",
    phone: "+1 (615) 555-0403",
    flightRisk: 8,
    salaryBand: "E4",
    avatarSeed: "naomi-carter",
    bio: "Naomi owns performance reviews, comp cycles, and the people-analytics dashboard you're looking at right now.",
  },
  {
    id: "e043",
    name: "Igor Sokolov",
    title: "People Operations Coordinator",
    department: "People",
    managerId: "e042",
    status: "active",
    tenureYears: 1.2,
    startDate: "2024-08-15",
    location: "Remote (Tallinn, EE)",
    email: "igor.sokolov@bloom.demo",
    phone: "+372 6 555 0404",
    flightRisk: 11,
    salaryBand: "E2",
    avatarSeed: "igor-sokolov",
    bio: "Igor runs onboarding logistics, equipment ordering, and the HRIS data quality review each Friday.",
  },

  // ====== SALES (reports to Sofia Almeida, e005) ======
  {
    id: "e050",
    name: "Carlos Mendes",
    title: "Director of Enterprise Sales",
    department: "Sales",
    managerId: "e005",
    status: "active",
    tenureYears: 2.6,
    startDate: "2023-05-22",
    location: "Remote (São Paulo, BR)",
    email: "carlos.mendes@bloom.demo",
    phone: "+55 11 555 0501",
    flightRisk: 17,
    salaryBand: "E5",
    avatarSeed: "carlos-mendes",
    bio: "Carlos owns enterprise sales in the Americas. Closed Bloom's largest deal to date last quarter.",
  },
  {
    id: "e051",
    name: "Eva Janssen",
    title: "Account Executive, SMB",
    department: "Sales",
    managerId: "e050",
    status: "active",
    tenureYears: 1.7,
    startDate: "2024-03-04",
    location: "Remote (Antwerp, BE)",
    email: "eva.janssen@bloom.demo",
    phone: "+32 3 555 0511",
    flightRisk: 26,
    salaryBand: "E3",
    avatarSeed: "eva-janssen",
    bio: "Eva covers SMB in EMEA. Hit 130% of quota last quarter.",
  },
  {
    id: "e052",
    name: "James O'Brien",
    title: "Account Executive, SMB",
    department: "Sales",
    managerId: "e050",
    status: "active",
    tenureYears: 0.6,
    startDate: "2025-04-21",
    location: "Remote (Dublin, IE)",
    email: "james.obrien@bloom.demo",
    phone: "+353 1 555 0512",
    flightRisk: 12,
    salaryBand: "E3",
    avatarSeed: "james-obrien",
    bio: "James covers SMB in EMEA North. Ramping on the Bloom platform this quarter.",
  },
  {
    id: "e053",
    name: "Preeti Sharma",
    title: "Sales Development Rep Lead",
    department: "Sales",
    managerId: "e005",
    status: "active",
    tenureYears: 1.9,
    startDate: "2024-01-15",
    location: "Remote (Pune, IN)",
    email: "preeti.sharma@bloom.demo",
    phone: "+91 20 555 0521",
    flightRisk: 22,
    salaryBand: "E4",
    avatarSeed: "preeti-sharma",
    bio: "Preeti manages the SDR team of five. Owns pipeline generation targets for EMEA + APAC.",
  },
  {
    id: "e054",
    name: "Mateo Rossi",
    title: "Sales Development Rep",
    department: "Sales",
    managerId: "e053",
    status: "active",
    tenureYears: 0.7,
    startDate: "2025-03-10",
    location: "Remote (Milan, IT)",
    email: "mateo.rossi@bloom.demo",
    phone: "+39 02 555 0531",
    flightRisk: 18,
    salaryBand: "E2",
    avatarSeed: "mateo-rossi",
    bio: "Mateo handles outbound prospecting for EMEA South.",
  },
  {
    id: "e055",
    name: "Zara Ahmed",
    title: "Sales Development Rep",
    department: "Sales",
    managerId: "e053",
    status: "new_hire",
    tenureYears: 0.2,
    startDate: "2025-10-06",
    location: "Remote (Karachi, PK)",
    email: "zara.ahmed@bloom.demo",
    phone: "+92 21 555 0532",
    flightRisk: 5,
    salaryBand: "E2",
    avatarSeed: "zara-ahmed",
    bio: "Zara joined Bloom last month. Ramp target is full SDR quota by end of Q1.",
  },

  // ====== MARKETING (reports to Tomás Rivera, e006) ======
  {
    id: "e060",
    name: "Anika Sharma",
    title: "Content Marketing Lead",
    department: "Marketing",
    managerId: "e006",
    status: "active",
    tenureYears: 2.3,
    startDate: "2023-07-04",
    location: "Remote (Toronto, CA)",
    email: "anika.sharma@bloom.demo",
    phone: "+1 (416) 555 0601",
    flightRisk: 11,
    salaryBand: "E4",
    avatarSeed: "anika-sharma",
    bio: "Anika runs the content engine — blog, newsletter, customer stories. Background in B2B SaaS journalism.",
  },
  {
    id: "e061",
    name: "Liam Walsh",
    title: "Performance Marketing Manager",
    department: "Marketing",
    managerId: "e006",
    status: "active",
    tenureYears: 1.5,
    startDate: "2024-06-10",
    location: "Remote (Manchester, UK)",
    email: "liam.walsh@bloom.demo",
    phone: "+44 161 555 0611",
    flightRisk: 21,
    salaryBand: "E4",
    avatarSeed: "liam-walsh",
    bio: "Liam owns paid acquisition across Google, LinkedIn, and Reddit. Tightening CAC targets this year.",
  },
  {
    id: "e062",
    name: "Hana Kim",
    title: "Brand Designer",
    department: "Marketing",
    managerId: "e006",
    status: "active",
    tenureYears: 2.0,
    startDate: "2023-12-12",
    location: "Remote (Seoul, KR)",
    email: "hana.kim@bloom.demo",
    phone: "+82 2 555 0621",
    flightRisk: 14,
    salaryBand: "E3",
    avatarSeed: "hana-kim",
    bio: "Hana owns the Bloom brand system — illustration, motion, and event collateral.",
  },
  {
    id: "e063",
    name: "Owen Mitchell",
    title: "Growth Marketing Manager",
    department: "Marketing",
    managerId: "e006",
    status: "active",
    tenureYears: 0.9,
    startDate: "2024-11-25",
    location: "Remote (Melbourne, AU)",
    email: "owen.mitchell@bloom.demo",
    phone: "+61 3 555 0631",
    flightRisk: 9,
    salaryBand: "E3",
    avatarSeed: "owen-mitchell",
    bio: "Owen runs lifecycle + product-led growth experiments. Recently shipped the in-app activation flow.",
  },

  // ====== FINANCE (reports to Marcus Chen, e004) ======
  {
    id: "e070",
    name: "Aisha Bello",
    title: "Director of Finance",
    department: "Finance",
    managerId: "e004",
    status: "active",
    tenureYears: 2.8,
    startDate: "2023-03-13",
    location: "New York, NY",
    email: "aisha.bello@bloom.demo",
    phone: "+1 (212) 555 0701",
    flightRisk: 7,
    salaryBand: "E5",
    avatarSeed: "aisha-bello",
    bio: "Aisha is the acting CFO while Marcus is on sabbatical. Owns FP&A, audit, and board reporting.",
  },
  {
    id: "e071",
    name: "Stefan Novák",
    title: "Senior Accountant",
    department: "Finance",
    managerId: "e070",
    status: "active",
    tenureYears: 1.8,
    startDate: "2024-04-08",
    location: "Remote (Prague, CZ)",
    email: "stefan.novak@bloom.demo",
    phone: "+420 2 555 0711",
    flightRisk: 12,
    salaryBand: "E4",
    avatarSeed: "stefan-novak",
    bio: "Stefan owns the monthly close + AP/AR. Building out the new expense policy rollout this quarter.",
  },
  {
    id: "e072",
    name: "Grace Mwangi",
    title: "Financial Analyst",
    department: "Finance",
    managerId: "e070",
    status: "active",
    tenureYears: 0.8,
    startDate: "2024-12-02",
    location: "Remote (Nairobi, KE)",
    email: "grace.mwangi@bloom.demo",
    phone: "+254 20 555 0721",
    flightRisk: 6,
    salaryBand: "E3",
    avatarSeed: "grace-mwangi",
    bio: "Grace owns headcount-cost forecasting and partners closely with People Ops on the quarterly attrition model.",
  },
];

/* ---------------------------------------------------------------------------
   ORG TREE — derived from employees[].managerId, validated below.
--------------------------------------------------------------------------- */

export type OrgNode = Employee & {
  reports: OrgNode[];
  depth: number;
};

function buildOrgTree(list: Employee[]): OrgNode {
  const byId = new Map<string, OrgNode>();
  for (const e of list) {
    byId.set(e.id, { ...e, reports: [], depth: 0 });
  }
  let root: OrgNode | null = null;
  for (const e of list) {
    const node = byId.get(e.id)!;
    if (e.managerId === null) {
      if (root !== null) {
        throw new Error(
          `[Bloom] org tree is invalid: multiple root nodes found (${root.id}, ${e.id}). Exactly one root required.`
        );
      }
      root = node;
    } else {
      const parent = byId.get(e.managerId);
      if (!parent) {
        throw new Error(
          `[Bloom] org tree is invalid: employee ${e.id} (${e.name}) references missing manager ${e.managerId}.`
        );
      }
      parent.reports.push(node);
    }
  }
  if (!root) {
    throw new Error(`[Bloom] org tree is invalid: no root node (no employee with managerId=null).`);
  }
  // depth assignment + cycle check via visited set during DFS
  const visited = new Set<string>();
  const stack: OrgNode[] = [root];
  while (stack.length) {
    const n = stack.pop()!;
    if (visited.has(n.id)) {
      throw new Error(`[Bloom] org tree is invalid: cycle detected at ${n.id}.`);
    }
    visited.add(n.id);
    for (const r of n.reports) {
      r.depth = n.depth + 1;
      stack.push(r);
    }
  }
  // orphan check — every employee must be reachable from root
  for (const e of list) {
    if (!visited.has(e.id)) {
      throw new Error(
        `[Bloom] org tree is invalid: employee ${e.id} (${e.name}) is orphaned (not reachable from root).`
      );
    }
  }
  return root;
}

export const orgRoot: OrgNode = buildOrgTree(employees);

/* ---------------------------------------------------------------------------
   HIRING — funnel-shaped (more in applied/screening than offer).
--------------------------------------------------------------------------- */

export const candidates: Candidate[] = [
  // Applied (8) — wide top of funnel
  { id: "c001", name: "Olivia Thompson", roleAppliedFor: "Senior Software Engineer, Platform", stage: "applied", daysInStage: 2, avatarSeed: "olivia-thompson", source: "LinkedIn" },
  { id: "c002", name: "Ravi Krishnan", roleAppliedFor: "Product Designer", stage: "applied", daysInStage: 1, avatarSeed: "ravi-krishnan", source: "Referral" },
  { id: "c003", name: "Sofie Larsen", roleAppliedFor: "Account Executive, SMB", stage: "applied", daysInStage: 4, avatarSeed: "sofie-larsen", source: "Careers Page" },
  { id: "c004", name: "Marcus Webb", roleAppliedFor: "Engineering Manager, Mobile", stage: "applied", daysInStage: 3, avatarSeed: "marcus-webb", source: "Recruiter Outreach" },
  { id: "c005", name: "Ingrid Berg", roleAppliedFor: "UX Researcher", stage: "applied", daysInStage: 5, avatarSeed: "ingrid-berg", source: "LinkedIn" },
  { id: "c006", name: "Tobias Frank", roleAppliedFor: "Senior Software Engineer, Mobile", stage: "applied", daysInStage: 2, avatarSeed: "tobias-frank", source: "Referral" },
  { id: "c007", name: "Aaliyah Johnson", roleAppliedFor: "Sales Development Rep", stage: "applied", daysInStage: 1, avatarSeed: "aaliyah-johnson", source: "Careers Page" },
  { id: "c008", name: "Henrik Olsen", roleAppliedFor: "Financial Analyst", stage: "applied", daysInStage: 6, avatarSeed: "henrik-olsen", source: "Recruiter Outreach" },

  // Screening (6)
  { id: "c010", name: "Penelope Cruz", roleAppliedFor: "Senior Product Designer", stage: "screening", daysInStage: 4, avatarSeed: "penelope-cruz", source: "LinkedIn" },
  { id: "c011", name: "Andrei Popescu", roleAppliedFor: "Software Engineer, Identity", stage: "screening", daysInStage: 3, avatarSeed: "andrei-popescu", source: "Referral" },
  { id: "c012", name: "Mira Patel", roleAppliedFor: "Performance Marketing Manager", stage: "screening", daysInStage: 2, avatarSeed: "mira-patel", source: "Careers Page" },
  { id: "c013", name: "Sven Eriksson", roleAppliedFor: "Software Engineer, Billing", stage: "screening", daysInStage: 5, avatarSeed: "sven-eriksson", source: "LinkedIn" },
  { id: "c014", name: "Yuki Sato", roleAppliedFor: "Account Executive, SMB", stage: "screening", daysInStage: 1, avatarSeed: "yuki-sato", source: "Recruiter Outreach" },
  { id: "c015", name: "Caleb Foster", roleAppliedFor: "People Operations Coordinator", stage: "screening", daysInStage: 4, avatarSeed: "caleb-foster", source: "Careers Page" },

  // Interview (4)
  { id: "c020", name: "Zoe Anderson", roleAppliedFor: "Senior Software Engineer, Platform", stage: "interview", daysInStage: 7, avatarSeed: "zoe-anderson", source: "Referral" },
  { id: "c021", name: "Rohan Gupta", roleAppliedFor: "Engineering Manager, Product Web", stage: "interview", daysInStage: 5, avatarSeed: "rohan-gupta", source: "LinkedIn" },
  { id: "c022", name: "Clara Nunes", roleAppliedFor: "Brand Designer", stage: "interview", daysInStage: 3, avatarSeed: "clara-nunes", source: "Careers Page" },
  { id: "c023", name: "Lukas Hoffmann", roleAppliedFor: "Director of Enterprise Sales", stage: "interview", daysInStage: 8, avatarSeed: "lukas-hoffmann", source: "Recruiter Outreach" },

  // Offer (2)
  { id: "c030", name: "Nadia Hassan", roleAppliedFor: "Senior Product Designer", stage: "offer", daysInStage: 4, avatarSeed: "nadia-hassan", source: "Referral" },
  { id: "c031", name: "Pablo Ortega", roleAppliedFor: "Software Engineer, Mobile", stage: "offer", daysInStage: 2, avatarSeed: "pablo-ortega", source: "LinkedIn" },

  // Hired (2)
  { id: "c040", name: "Lucia Pereira", roleAppliedFor: "Software Engineer, Identity", stage: "hired", daysInStage: 0, avatarSeed: "lucia-pereira", source: "LinkedIn" },
  { id: "c041", name: "Bram de Vries", roleAppliedFor: "Software Engineer, Mobile", stage: "hired", daysInStage: 0, avatarSeed: "bram-devries", source: "Referral" },
];

/* ---------------------------------------------------------------------------
   ATTRITION — 18 months of trend with realistic small-sample noise.
--------------------------------------------------------------------------- */

export const attritionTrend: AttritionMonth[] = [
  { month: "2024-04", rate: 1.8, departures: 1, headcount: 51 },
  { month: "2024-05", rate: 2.1, departures: 1, headcount: 51 },
  { month: "2024-06", rate: 1.6, departures: 1, headcount: 52 },
  { month: "2024-07", rate: 3.2, departures: 2, headcount: 53 },
  { month: "2024-08", rate: 0.0, departures: 0, headcount: 54 },
  { month: "2024-09", rate: 1.8, departures: 1, headcount: 55 },
  { month: "2024-10", rate: 3.4, departures: 2, headcount: 56 },
  { month: "2024-11", rate: 1.7, departures: 1, headcount: 57 },
  { month: "2024-12", rate: 1.7, departures: 1, headcount: 58 },
  { month: "2025-01", rate: 3.3, departures: 2, headcount: 60 },
  { month: "2025-02", rate: 1.6, departures: 1, headcount: 61 },
  { month: "2025-03", rate: 4.7, departures: 3, headcount: 62 },
  { month: "2025-04", rate: 1.5, departures: 1, headcount: 65 },
  { month: "2025-05", rate: 2.9, departures: 2, headcount: 67 },
  { month: "2025-06", rate: 1.4, departures: 1, headcount: 70 },
  { month: "2025-07", rate: 2.7, departures: 2, headcount: 72 },
  { month: "2025-08", rate: 1.3, departures: 1, headcount: 74 },
  { month: "2025-09", rate: 4.0, departures: 3, headcount: 75 },
];

export const attritionReasons: AttritionReason[] = [
  { reason: "Career growth elsewhere", count: 11, pct: 34 },
  { reason: "Compensation gap", count: 7, pct: 22 },
  { reason: "Relocation", count: 5, pct: 16 },
  { reason: "Performance-related exit", count: 4, pct: 13 },
  { reason: "Return to in-office required", count: 3, pct: 9 },
  { reason: "Personal / health", count: 2, pct: 6 },
];

export const departmentAttrition: DepartmentAttrition[] = [
  { department: "Engineering", rate: 11.4, headcount: 17, departures: 2 },
  { department: "Design", rate: 6.7, headcount: 5, departures: 0 },
  { department: "Sales", rate: 19.3, headcount: 6, departures: 1 },
  { department: "Marketing", rate: 5.0, headcount: 4, departures: 0 },
  { department: "People", rate: 8.0, headcount: 5, departures: 0 },
  { department: "Finance", rate: 0.0, headcount: 3, departures: 0 },
];

/* ---------------------------------------------------------------------------
   REVIEW CYCLES — 4 cycles, mixed active/upcoming/completed.
--------------------------------------------------------------------------- */

export const reviewCycles: ReviewCycle[] = [
  {
    id: "r1",
    name: "H2 2025 Performance Review",
    status: "active",
    startDate: "2025-11-03",
    endDate: "2025-12-15",
    participants: [
      { employeeId: "e010", completionPct: 100 },
      { employeeId: "e011", completionPct: 100 },
      { employeeId: "e012", completionPct: 80 },
      { employeeId: "e013", completionPct: 60 },
      { employeeId: "e016", completionPct: 40 },
      { employeeId: "e019", completionPct: 100 },
      { employeeId: "e022", completionPct: 20 },
      { employeeId: "e030", completionPct: 100 },
      { employeeId: "e050", completionPct: 50 },
      { employeeId: "e060", completionPct: 75 },
    ],
  },
  {
    id: "r2",
    name: "Engineering 360° Feedback",
    status: "active",
    startDate: "2025-10-15",
    endDate: "2025-11-28",
    participants: [
      { employeeId: "e002", completionPct: 100 },
      { employeeId: "e010", completionPct: 100 },
      { employeeId: "e011", completionPct: 90 },
      { employeeId: "e012", completionPct: 70 },
      { employeeId: "e016", completionPct: 50 },
      { employeeId: "e019", completionPct: 100 },
      { employeeId: "e022", completionPct: 30 },
    ],
  },
  {
    id: "r3",
    name: "Q1 2026 Manager Calibration",
    status: "upcoming",
    startDate: "2026-01-12",
    endDate: "2026-02-06",
    participants: [
      { employeeId: "e001", completionPct: 0 },
      { employeeId: "e002", completionPct: 0 },
      { employeeId: "e003", completionPct: 0 },
      { employeeId: "e005", completionPct: 0 },
      { employeeId: "e006", completionPct: 0 },
      { employeeId: "e030", completionPct: 0 },
      { employeeId: "e050", completionPct: 0 },
    ],
  },
  {
    id: "r4",
    name: "H1 2025 Performance Review",
    status: "completed",
    startDate: "2025-05-05",
    endDate: "2025-06-20",
    participants: [
      { employeeId: "e001", completionPct: 100 },
      { employeeId: "e002", completionPct: 100 },
      { employeeId: "e003", completionPct: 100 },
      { employeeId: "e005", completionPct: 100 },
      { employeeId: "e006", completionPct: 100 },
      { employeeId: "e030", completionPct: 100 },
    ],
  },
];

/* ---------------------------------------------------------------------------
   NOTES + REVIEW ENTRIES — used by the Person Detail Panel tabs.
--------------------------------------------------------------------------- */

export const notes: Note[] = [
  { id: "n001", employeeId: "e013", author: "Hannah Williams", createdAt: "2025-09-22", body: "Promotion conversation scheduled for Q1. Kwame has been a strong mentor for Lucia through onboarding." },
  { id: "n002", employeeId: "e013", author: "Priya Nair", createdAt: "2025-10-04", body: "Comp adjustment approved — bumping to E4 mid-band. Effective next pay cycle." },
  { id: "n003", employeeId: "e017", author: "Olu Adesanya", createdAt: "2025-08-15", body: "Sara requested 4-month rotation in Stockholm office to be closer to family. Approved through end of Q4." },
  { id: "n004", employeeId: "e019", author: "Rahul Mehta", createdAt: "2025-09-30", body: "Dashboard redesign kickoff shipped on time. Strong cross-functional partnership with design (Jordan)." },
  { id: "n005", employeeId: "e050", author: "Sofia Almeida", createdAt: "2025-10-12", body: "Carlos closed the Helix account — $480K ARR. Largest single deal in company history." },
];

export const reviews: ReviewEntry[] = [
  { id: "rv001", employeeId: "e013", cycleId: "r1", reviewer: "Hannah Williams", submittedAt: "2025-11-10", rating: 4, summary: "Strong technical execution. Ship velocity up 30% YoY. Opportunity to grow as a cross-team technical lead." },
  { id: "rv002", employeeId: "e013", cycleId: "r2", reviewer: "Wei Zhang", submittedAt: "2025-11-04", rating: 5, summary: "Best mentor I've had at Bloom. Patient, thorough, gives direct feedback." },
  { id: "rv003", employeeId: "e019", cycleId: "r1", reviewer: "Rahul Mehta", submittedAt: "2025-11-08", rating: 5, summary: "Exceptional Q3. Shipped the redesign kickoff on schedule, kept morale high through the design-system migration." },
  { id: "rv004", employeeId: "e050", cycleId: "r1", reviewer: "Sofia Almeida", submittedAt: "2025-11-12", rating: 4, summary: "Closed the largest deal in company history. Development area: pipeline forecast accuracy." },
  { id: "rv005", employeeId: "e030", cycleId: "r4", reviewer: "Priya Nair", submittedAt: "2025-06-15", rating: 5, summary: "Built a world-class design org from scratch. The Bloom design system is a competitive advantage." },
];

/* ---------------------------------------------------------------------------
   HELPER QUERIES — used across pages.
--------------------------------------------------------------------------- */

export function getEmployeeById(id: string): Employee | undefined {
  return employees.find((e) => e.id === id);
}

export function getReportsOf(id: string): Employee[] {
  return employees.filter((e) => e.managerId === id);
}

export function getManagerChain(id: string): Employee[] {
  const chain: Employee[] = [];
  let current = getEmployeeById(id);
  while (current && current.managerId) {
    const mgr = getEmployeeById(current.managerId);
    if (!mgr) break;
    chain.push(mgr);
    current = mgr;
  }
  return chain.reverse();
}

export function getNotesFor(id: string): Note[] {
  return notes.filter((n) => n.employeeId === id);
}

export function getReviewsFor(id: string): ReviewEntry[] {
  return reviews.filter((r) => r.employeeId === id);
}

export const stats = {
  totalHeadcount: employees.length,
  openRoles: candidates.filter((c) => c.stage !== "hired").length,
  avgTenureYears:
    Math.round(
      (employees.reduce((sum, e) => sum + e.tenureYears, 0) / employees.length) * 10
    ) / 10,
  onLeave: employees.filter((e) => e.status === "on_leave").length,
  newHires: employees.filter((e) => e.status === "new_hire").length,
  flightRiskHigh: employees.filter((e) => e.flightRisk >= 20).length,
  trailingAttritionRate: attritionTrend[attritionTrend.length - 1].rate,
};

/* ---------------------------------------------------------------------------
   ACTIVITY FEED — used by the Profile page.
--------------------------------------------------------------------------- */

export type Activity = {
  id: string;
  employeeId: string;
  type: "review_submitted" | "candidate_moved" | "note_added" | "flight_risk" | "cycle_started" | "profile_updated";
  message: string;
  timestamp: string; // ISO
  href?: string;
};

export const activities: Activity[] = [
  {
    id: "a1",
    employeeId: "e001",
    type: "review_submitted",
    message: "Submitted the H2 2025 performance review calibration for Engineering",
    timestamp: "2025-11-12T14:30:00Z",
    href: "/reviews",
  },
  {
    id: "a2",
    employeeId: "e001",
    type: "candidate_moved",
    message: "Moved Nadia Hassan to Offer stage",
    timestamp: "2025-11-10T11:15:00Z",
    href: "/hiring",
  },
  {
    id: "a3",
    employeeId: "e001",
    type: "note_added",
    message: "Added a note to Carlos Mendes — closed the Helix account ($480K ARR)",
    timestamp: "2025-11-08T16:45:00Z",
    href: "/people",
  },
  {
    id: "a4",
    employeeId: "e001",
    type: "flight_risk",
    message: "Sara Lindqvist flagged as flight-risk (score 28)",
    timestamp: "2025-11-06T09:20:00Z",
    href: "/attrition",
  },
  {
    id: "a5",
    employeeId: "e001",
    type: "cycle_started",
    message: "Started the Engineering 360° Feedback review cycle",
    timestamp: "2025-10-15T13:00:00Z",
    href: "/reviews",
  },
  {
    id: "a6",
    employeeId: "e001",
    type: "profile_updated",
    message: "Updated your bio and title",
    timestamp: "2025-10-02T10:30:00Z",
    href: "/profile",
  },
];

export function getActivitiesFor(employeeId: string): Activity[] {
  return activities.filter((a) => a.employeeId === employeeId);
}

