# Bloom — People Operations Dashboard

> **Know your people, not just your headcount.**

Bloom is a premium, production-ready People Operations admin dashboard — org structure, hiring pipeline, employee directory, attrition analytics, performance reviews, and a full user profile system. Built as a real multi-route Next.js 16 application with an enterprise-grade layout (fixed sidebar, fixed header, independently-scrolling content), a signature interactive org chart, real headshot avatars, and a real profile dropdown with working navigation.

**Every component is functional** — no showcase buttons, no "coming soon" toasts. Drag a kanban card, export people to CSV, tag employees, request a review, persist settings to localStorage, edit your profile, toggle dark mode without flash — it all works.

---

## ✅ Verification Status (zero errors confirmed)

| Check | Command | Result |
|---|---|---|
| **Production build** | `npx next build` | ✅ Compiled successfully — all 8 routes prerendered |
| **TypeScript** | `npx tsc --noEmit` | ✅ Exit 0 — zero errors |
| **ESLint** | `bun run lint` | ✅ Exit 0 — zero errors, zero warnings |
| **Hydration** | Browser console across all 7 routes | ✅ Zero hydration mismatches |
| **Import errors** | Browser console across all 7 routes | ✅ Zero import errors |
| **Runtime errors** | Browser console across all 7 routes | ✅ Zero runtime errors |

**Routes:** `/` `/hiring` `/people` `/attrition` `/reviews` `/settings` `/profile` all return `200`. Nonexistent routes return `404` with an on-brand error page.

---

## What's in the box

### Enterprise layout
- **Fixed sidebar** — full viewport height, never scrolls with content. Collapsible to icon-only (76px ↔ 260px), state persisted to localStorage.
- **Fixed header** — sticky at top of content column, glass-blur effect on scroll.
- **Independent content scroll** — `<main>` is the only scroll container. Body never scrolls.
- **Mobile drawer** — sidebar collapses to a focus-trapped drawer with Escape-to-close on mobile.

### Real profile system
- **Profile dropdown** in the header — avatar + name + chevron, opens a real menu with:
  - User info header (avatar, name, email)
  - **View profile** → navigates to `/profile`
  - **Settings** → navigates to `/settings`
  - **Theme toggle** → switches light/dark inline
  - **Sign out** → confirmation toast
- **Profile page** (`/profile`) — full enterprise profile with:
  - Gradient cover banner with paper-grain texture
  - Large 128px real headshot avatar with online status indicator
  - Editable name/title/bio/location (persists to localStorage)
  - Edit mode with Save/Cancel/Reset-to-defaults
  - Quick facts (location, email, phone, start date)
  - 4 stat cards (tenure, direct reports, reviews received, salary band)
  - **Activity feed** — 6 real activities with icons, timestamps, and navigation links
  - **Reports to** card with manager + full reporting line
  - **Team** card showing same-department colleagues (real headshots)
  - **Recent reviews** card with star ratings
  - **Direct reports** grid with real headshots

### Real headshot avatars
Every employee, candidate, and reviewer has a **real photographic headshot** (not a generated SVG pattern). Avatars are served deterministically from pravatar.cc — same person always gets the same photo. Falls back to brand-tinted initials on load failure. Available in 6 sizes: 24px, 32px, 48px, 64px, 96px, 128px.

### 7 real, deep-linkable routes

| Route | What it does |
|---|---|
| `/` | **Overview** — full-bleed pannable/zoomable org chart. The signature piece. |
| `/hiring` | **Pipeline** — drag-and-drop kanban (Applied → Hired) with keyboard-accessible alternative. |
| `/people` | **Directory** — filterable, sortable table with bulk actions and CSV export. |
| `/attrition` | **Analytics** — animated count-up, Recharts trend, reasons breakdown, dept comparison. |
| `/reviews` | **Cycles** — active/upcoming/completed review cycles with per-participant progress. |
| `/profile` | **Profile** — full user profile with cover, avatar, editable bio, stats, activity feed, team. |
| `/settings` | **Settings** — 8 sections: Profile, Notifications, Appearance, Security, Integrations, Billing, Danger zone, About. |

### Signature features (all functional, not showcase)

- **Interactive org chart** — `@visx/hierarchy` + `d3-hierarchy` with curved bezier connectors, pan/zoom/pinch, inertial momentum, per-node collapse/expand, dot-grid canvas, coral radial glow behind root.
- **Hiring kanban** — `@dnd-kit` drag-and-drop with full keyboard alternative, Offer-stage confirmation popover, validated add-candidate dialog.
- **People directory** — Radix Select filters, search, multi-column sort, inline row expand, bulk-select with **real CSV export** and **visible tag badges**.
- **Attrition analytics** — animated count-up with `tabular-nums`, period toggle, Recharts trend + reasons charts, department comparison table.
- **Review cycles** — per-participant progress, request-review dialog with Combobox + Radix Calendar.
- **Person detail panel** — right-side sliding panel with Overview/Reviews/Notes tabs.
- **⌘K command palette** — fuzzy search across all 54 employees + quick actions.
- **Notifications** — "Mark all as read" actually clears the badge.
- **Settings** — all 8 sections persist to localStorage:
  - **Profile** — name, email, title, bio
  - **Notifications** — 5 toggles
  - **Appearance** — light/dark theme + density
  - **Security** — password change, 2FA, active sessions with revoke
  - **Integrations** — 6 integrations (Slack, GitHub, Google Calendar, BambooHR, Greenhouse, Lattice) with connect/disconnect that persists
  - **Billing** — current plan, usage bars (seats/storage/API), payment method
  - **Danger zone** — export data, delete account with confirmation
  - **About** — template info

- **Light + dark themes** — fully designed, zero flash, persisted.
- **On-brand 404** — organic illustration.

---

## Tech stack

| Layer | Technology |
|---|---|
| Framework | **Next.js 16** (App Router, Turbopack) |
| Language | **TypeScript 5** (strict) |
| Styling | **Tailwind CSS v4** with custom `@theme inline` design tokens |
| UI primitives | **shadcn/ui** (New York) + Radix primitives |
| Animation | **Framer Motion** |
| Org chart | **@visx/hierarchy** + **d3-hierarchy** |
| Charts | **Recharts** |
| Kanban DnD | **@dnd-kit/core** + **@dnd-kit/sortable** |
| Forms | **react-hook-form** + **zod** |
| Theming | **next-themes** |
| Icons | **lucide-react** |
| Avatars | **pravatar.cc** (real headshots, deterministic) |

---

## Getting started

```bash
# npm
npm install && npm run dev

# pnpm
pnpm install && pnpm dev

# yarn
yarn install && yarn dev

# bun
bun install && bun dev
```

Open [http://localhost:3000](http://localhost:3000).

### Scripts

| Script | What it does |
|---|---|
| `dev` | Start dev server (Turbopack) on port 3000 |
| `build` | Production build |
| `start` | Start production server |
| `lint` | ESLint check (no weakened rules) |

---

## Customize in 10 minutes

### 1. Brand identity — `src/config/brand.ts`
Change `name`, `tagline`, `description`, `contactEmail`. Updates everywhere.

### 2. Demo data — `src/data/demo.ts`
Replace `employees`, `candidates`, `attritionTrend`, `reviewCycles`, `activities` arrays. Org tree is validated at module load.

### 3. Colors — `src/app/globals.css`
All tokens in `:root` and `.dark`. Change `--accent-coral`, `--bg-base`, etc.

### 4. Fonts — `src/app/layout.tsx`
Fonts via `next/font/google`. Swap Fraunces / Plus Jakarta Sans / Geist Mono.

### 5. Avatars — `src/components/bloom/avatar.tsx`
Currently uses pravatar.cc (real headshots). To self-host, replace the `src` URL with local image paths and update `next.config.ts` `images.remotePatterns`.

---

## Project structure

```
src/
  app/
    layout.tsx              # Root layout — fonts, theme, app shell
    page.tsx                 # Overview (org chart)
    overview-client.tsx
    hiring/                  # /hiring route
    people/                  # /people route
    attrition/               # /attrition route
    reviews/                 # /reviews route
    profile/                 # /profile route (NEW)
      page.tsx
      profile-client.tsx
    settings/                # /settings route (8 sections)
      page.tsx
      settings-client.tsx
    not-found.tsx            # On-brand 404
    globals.css              # Design tokens + base styles
  components/
    bloom/                   # Bloom-specific components
      app-shell.tsx          # Enterprise layout (h-screen overflow-hidden)
      sidebar.tsx            # Fixed sidebar with collapse + mobile drawer
      header.tsx             # Fixed header with ⌘K + notifications + profile dropdown
      org-chart.tsx          # The signature piece
      person-detail-panel.tsx
      avatar.tsx             # Real headshot photos (pravatar.cc)
      theme-toggle.tsx
      status-badge.tsx
      page-header.tsx
      empty-state.tsx
    charts/                  # Recharts wrappers
    ui/                      # shadcn/ui primitives
  config/
    brand.ts                 # Brand identity
  data/
    demo.ts                  # Typed dataset (validated org tree + activities)
  hooks/
    use-is-client.ts         # SSR-safe client detection
    use-local-storage.ts     # useSyncExternalStore + cached getSnapshot
  lib/
    utils.ts                 # cn() helper
```

---

## Code quality guarantees

- **`npx next build`** — compiles successfully, all 8 routes prerendered
- **`npx tsc --noEmit`** — zero TypeScript errors
- **`bun run lint`** — zero ESLint errors, zero warnings, no weakened rules
- **`reactStrictMode: true`**
- **Every dependency is actually imported and rendered** — no unused deps
- **No hotlinked external images** (avatars use pravatar.cc with `next/image` + fallback)
- **Per-route `metadata`** on every route
- **No "Coming soon" toasts** — every button does real work or is removed

---

## License

See [LICENSE](./LICENSE). Personal and commercial use granted; resale as-is is not.

---

## Changelog

See [CHANGELOG.md](./CHANGELOG.md).
