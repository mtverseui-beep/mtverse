# SentinelGrid — Engineering Operations & Reliability Console

> A premium, production-ready Next.js 16 dashboard template for SRE, DevOps, platform engineering, incident management, and observability teams. **196 routes, dark/light themes, fully responsive, Vercel-ready.**

![SentinelGrid](public/icon.svg)

---

## Why SentinelGrid

SentinelGrid is a commercial-grade engineering operations console inspired by the UX of Datadog, Grafana Cloud, PagerDuty, Linear, Vercel, and Sentry — without copying any of them. It is built to be reskinned, extended, and shipped as a real SaaS product or internal platform.

- **196 real routes** (not state-based sections) — every URL is refresh-safe, shareable, and browser-back/forward friendly
- **Dark mode default** with a polished light mode and zero hydration flicker
- **Mobile-first responsive** — tables auto-render as cards on mobile, sidebars become drawers
- **Premium interactions** — command palette (Cmd+K), saved filters, recently visited, favorites, contextual right panel
- **Reusable systems** — advanced DataTable, 14 theme-aware chart components, badge system, KPI cards
- **Realistic engineering content** — real service names, incident scenarios, SLO definitions, audit events, vulnerabilities (no lorem ipsum)
- **Zero TypeScript errors, zero ESLint errors, zero runtime errors**
- **Vercel-ready** — `bun run build` produces a clean static + dynamic output

---

## Quick Start

```bash
# 1. Install dependencies (bun recommended; npm/yarn/pnpm also work)
bun install

# 2. Copy env template
cp .env.example .env

# 3. Run dev server
bun run dev
# → http://localhost:3000

# 4. Production build
bun run build
bun run start
```

Open [http://localhost:3000](http://localhost:3000) — you'll be redirected to `/dashboard`.

---

## Tech Stack

| Layer | Choice |
|---|---|
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5 (strict) |
| Styling | Tailwind CSS 4 + shadcn/ui (New York) |
| Charts | Recharts 2 |
| Icons | lucide-react (SVG only, no emojis) |
| State | Zustand 5 |
| Forms | react-hook-form + zod |
| Toasts | sonner + radix-toast |
| Theme | next-themes pattern (custom impl, no flicker) |
| Database | Prisma 6 (SQLite by default; swap for Postgres/MySQL) |
| Auth | NextAuth.js v4 (optional) |
| Fonts | Geist Sans + Geist Mono |

---

## Project Structure

```
sentinelgrid/
├── src/
│   ├── app/
│   │   ├── (dashboard)/          # Main app shell (sidebar + header + right panel)
│   │   │   ├── dashboard/        # 15 dashboard pages
│   │   │   ├── incidents/        # 16 incident management pages
│   │   │   ├── postmortems/      # 8 postmortem pages
│   │   │   ├── services/         # 10 service catalog pages
│   │   │   ├── reliability/      # 9 SLO/error-budget pages
│   │   │   ├── deployments/      # 11 release management pages
│   │   │   ├── performance/      # 10 performance pages
│   │   │   ├── errors/           # 10 error tracking pages
│   │   │   ├── oncall/           # 9 on-call pages
│   │   │   ├── alerts/           # 8 alerting pages
│   │   │   ├── infrastructure/   # 12 infrastructure pages
│   │   │   ├── logs/             # 2 log pages
│   │   │   ├── traces/           # 2 trace pages
│   │   │   ├── metrics/          # 5 metrics pages
│   │   │   ├── security/         # 9 security ops pages
│   │   │   ├── admin/            # 20 admin/settings pages
│   │   │   └── docs/             # 12 developer docs pages
│   │   ├── (auth)/               # 11 auth pages (split-screen)
│   │   ├── errors/               # 10 system error pages (401/403/404/...)
│   │   ├── landing/              # Marketing landing page
│   │   ├── features/             # Marketing features page
│   │   ├── preview/              # Page showcase
│   │   ├── components-preview/   # Component library preview
│   │   ├── pricing/              # Marketing pricing page
│   │   ├── layout.tsx            # Root layout (fonts, theme, command palette)
│   │   ├── page.tsx              # Redirects to /dashboard
│   │   └── not-found.tsx         # Global 404
│   ├── components/
│   │   ├── layout/               # sidebar, header, right-panel, command-palette
│   │   ├── common/               # kpi-card, page-header, badges
│   │   ├── charts/               # 14 chart components + chart-container
│   │   ├── tables/               # data-table (advanced)
│   │   └── ui/                   # shadcn/ui components
│   ├── lib/
│   │   ├── types.ts              # Full engineering ops type system
│   │   ├── data.ts               # 1500+ lines of mock data
│   │   ├── store.ts              # Zustand stores (UI prefs, incident state)
│   │   ├── nav.ts                # Sidebar navigation config
│   │   └── utils.ts              # cn() and helpers
│   └── hooks/                    # use-mobile, use-toast
├── public/                       # logo.svg, icon.svg, robots.txt
├── prisma/                       # schema.prisma (optional)
├── package.json                  # "sentinelgrid" v1.0.0
├── next.config.ts                # Vercel-optimized
├── tailwind.config.ts
├── tsconfig.json
└── README.md                     # This file
```

---

## Page Categories (196 routes total)

| Category | Count | Highlights |
|---|---|---|
| **Dashboards** | 15 | Engineering Overview, Incident Command, Reliability, SLO, Error Budget, Deployments, Performance, Errors, Service Health, Infrastructure, Cloud Cost, Security, On-Call, Releases, Executive |
| **Incidents** | 16 | List, Details (6 tabs), Create, Active, Timeline, War Rooms, Commander, Updates, Subscribers, Escalations, Impact, Communications, Templates, Severity Rules, Status Page, Retrospectives |
| **Postmortems** | 8 | List, Details, Create, Action Items, Lessons, Review Queue, Templates, Analytics |
| **Services** | 10 | Catalog, Details (8 tabs), Dependency Map (SVG), Ownership Matrix, Health History, Metrics Explorer, Alerts, Runbooks, Runbook Details, Service Deployments |
| **Reliability** | 9 | SLO Overview, SLO Details, Error Budgets, Burn Rate, SLA Reports, Uptime, Availability Calendar, Scorecards, Customer Impact |
| **Deployments** | 11 | List, Details, Pipeline (Kanban), Calendar, Rollback, Change Requests, Approvals, Release Notes, Risk Analysis, Feature Flags, Environments |
| **Performance** | 10 | Latency, Throughput, Apdex, Web Vitals, Database, API, Queues, Cache, CDN, Synthetic |
| **Errors** | 10 | List, Details, Groups, Trends, Stack Traces, Regressions, Ownership, Rules, Source Maps, Alerts |
| **On-Call** | 9 | Schedule, Calendar, Escalation, Rotations, Availability, Handoffs, Analytics, Paging Rules, Preferences |
| **Alerts** | 8 | Inbox, Details, Rules, Routing, Suppression, Noise Analytics, Tuning, Integrations |
| **Infrastructure** | 12 | Overview, Hosts, Host Details, Containers, K8s Clusters, K8s Workloads, Pods, Databases, Queues, Storage, Network, Edge/CDN |
| **Logs/Traces/Metrics** | 9 | Logs Explorer, Log Details, Trace Explorer, Trace Waterfall, Metrics Explorer, Query Builder, Saved Queries, Dashboards Library, Dashboard Builder |
| **Security** | 9 | Overview, Vulnerabilities, Vuln Details, Events, Secrets, Access Reviews, Compliance, Audit, Policies |
| **Admin/Team** | 20 | Team, Team Member Details, Teams, Roles, Permissions, Audit Logs, Audit Event Details, API Keys, Webhooks, Integrations, Notifications, Settings, Billing, Subscription, Usage, Security Settings, Sessions, Profile, Workspace |
| **Auth** | 11 | Sign In, Sign Up, Forgot Password, Reset Password, Verify Email, Two-Factor, Lock Screen, Invite Team, Onboarding Wizard, Workspace Setup, Connect Integrations |
| **System Errors** | 11 | 401, 403, 404, 408, 429, 500, 503, Offline, Maintenance, Coming Soon, Global not-found |
| **Docs** | 12 | Documentation Home, Getting Started, Components, Routing, Theme, Charts, Tables, Mock API, Deployment, Changelog, License, Support |
| **Marketing** | 5 | Landing, Features, Pages Preview, Components Preview, Pricing |

---

## Reusable Component Systems

### KpiCard
```tsx
<KpiCard
  label="MTTR (30d)"
  value={18.4}
  unit="min"
  delta={-8}
  deltaLabel="improving"
  icon={<Clock className="w-4 h-4" />}
  accent="primary"
  sparkline={[22, 20, 19, 21, 18, 17, 19, 18, 17, 18]}
/>
```

### DataTable
Features: search, sort, multi-column filters, pagination, column visibility, CSV/JSON export, bulk actions, mobile card view, density toggle, sticky header.

```tsx
<DataTable
  columns={columns}
  data={incidents}
  rowKey={(r) => r.id}
  searchKeys={["ref", "title"]}
  enableSelection
  bulkActions={[{ label: "Acknowledge", onClick: (rows) => ... }]}
  mobileCard={(row) => <IncidentCard row={row} />}
/>
```

### Charts (14 components)
`LatencyChart`, `VolumeChart`, `ErrorRateChart`, `BurnRateChart`, `SLOComplianceChart`, `IncidentSeverityTrendChart`, `MTTRTrendChart`, `DeploymentFrequencyChart`, `LineChartCard`, `DonutChart`, `HorizontalBarChart`, `UptimeHeatmap`, `RadialGauge`, `ComposedChartCard` — all theme-aware with custom tooltips, fullscreen dialog, export action.

### Badges
`SeverityBadge`, `IncidentStatusBadge`, `ServiceHealthBadge`, `DeploymentStatusBadge`, `AlertStatusBadge`, `SLOStatusBadge`, `TierBadge`, `StatusDot`.

### Command Palette (Cmd+K)
Quick actions, recent pages, favorites, search across all entities (incidents, services, deployments, alerts, errors, runbooks, people, all 196 pages).

---

## Theme System

- **Default:** Dark mode (graphite `oklch(0.14 0.005 240)`)
- **Light mode:** Polished, paper-white (`oklch(0.985 0.002 240)`)
- **No hydration flicker:** Inline `<head>` script reads `localStorage` before paint
- **Single source of truth:** All tokens in `src/app/globals.css` using OKLCH color space

### Brand Palette
| Token | Dark | Light |
|---|---|---|
| Primary (cyan) | `#22D3EE` family | `#0891B2` family |
| Accent (violet) | `#A78BFA` family | `#7C3AED` family |
| Success | green | green |
| Warning | amber | amber |
| Destructive | red | red |
| Info | blue | blue |

To customize: edit `:root` and `.dark` blocks in `src/app/globals.css`.

---

## Mobile Responsiveness

- **Sidebar:** Collapses to drawer on mobile (hamburger menu)
- **Tables:** Auto-render as card lists on mobile via `mobileCard` prop
- **Charts:** Resize via `ResponsiveContainer`
- **Forms:** Stack vertically, touch-friendly 44px targets
- **Command palette:** Full-screen on mobile
- **Right panel:** Hidden on mobile (drawer-accessible)
- **No horizontal overflow** on any page

---

## Cursor System

All interactive elements use `cursor: pointer` globally via `globals.css`:
- `button`, `a`, `[role="button"]`, `[role="link"]`, `[role="menuitem"]`, `[role="option"]`, `[role="tab"]`, `[role="checkbox"]`, `[role="radio"]`, `[role="switch"]`, `[role="combobox"]`, `summary`, `label[for]`, `select`, `option`
- Text inputs use `cursor: text`
- Disabled elements use `cursor: not-allowed`

---

## Deploying to Vercel

### Option A: Vercel CLI
```bash
npm i -g vercel
vercel        # Follow prompts
vercel --prod # Production deploy
```

### Option B: Vercel Dashboard
1. Push this project to a GitHub/GitLab/Bitbucket repo
2. Import the repo at [vercel.com/new](https://vercel.com/new)
3. Vercel auto-detects Next.js — no config needed
4. Click **Deploy**

### Build Settings (auto-detected)
- **Framework:** Next.js
- **Build Command:** `next build` (or `bun run build`)
- **Output:** `.next/` (handled by Vercel)
- **Node Version:** 20.x or 22.x

### Environment Variables
Set in Vercel dashboard (or `.env` locally):
```
DATABASE_URL=your_database_url          # Optional: only if using Prisma
NEXTAUTH_SECRET=your_secret             # Optional: only if using NextAuth
NEXTAUTH_URL=https://yourdomain.com     # Optional: only if using NextAuth
```

---

## Customization Guide

### Add a New Page
1. Create `src/app/(dashboard)/your-route/page.tsx`
2. Use the pattern:
```tsx
"use client";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";

export default function Page() {
  return (
    <PageContainer>
      <PageHeader title="Your Page" breadcrumbs={[{ label: "Your Page" }]} icon={<Icon />} />
      {/* content */}
    </PageContainer>
  );
}
```
3. Add to sidebar: edit `src/lib/nav.ts`
4. The command palette auto-discovers it

### Add a New Chart
1. Use existing `ChartContainer` wrapper
2. Import chart primitives from `recharts`
3. Use `useChartTheme()` for theme-aware colors
4. See `src/components/charts/index.tsx` for examples

### Add a New Integration
Edit `src/lib/data.ts` → `integrations` array.

### Swap Mock Data for Real API
1. Replace imports from `@/lib/data` with `fetch()` calls to your API
2. Use TanStack Query (already installed) for caching
3. Keep the same TypeScript types from `@/lib/types`

---

## Quality Verification

| Check | Status |
|---|---|
| TypeScript (`tsc --noEmit`) | ✅ 0 errors |
| ESLint (`bun run lint`) | ✅ 0 errors |
| Production build (`bun run build`) | ✅ Success, 196 routes |
| Console errors (browser) | ✅ None |
| Hydration warnings | ✅ None |
| Mobile responsive | ✅ All pages |
| Cursor pointer | ✅ All interactive elements |
| Empty/placeholder pages | ✅ None (every page has real content) |
| Emojis in UI | ✅ None (lucide-react SVG icons only) |

---

## License

Commercial license. See `src/app/(dashboard)/docs/license/page.tsx` for full terms.

**What you can do:**
- Use this template to build one commercial product
- Modify, extend, and reskin as needed
- Deploy to any platform (Vercel, Netlify, self-hosted)

**What you cannot do:**
- Resell or redistribute the template itself
- Use for multiple commercial products without additional licenses

---

## Support

- Documentation: `/docs` (in-app)
- Getting Started: `/docs/getting-started`
- Support: `support@sentinelgrid.io`

---

**SentinelGrid** — Engineering Operations, Perfected.
