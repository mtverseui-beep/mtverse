import type { DocsNavSection } from "@/components/docs/docs-sidebar";

export const docsNavSections: DocsNavSection[] = [
  {
    title: "Get Started",
    items: [
      { label: "Overview", href: "/docs", icon: <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60" /> },
      { label: "Getting Started", href: "/docs/getting-started" },
      { label: "Changelog", href: "/docs/changelog", badge: "v1.0" },
    ],
  },
  {
    title: "Guides",
    items: [
      { label: "Components", href: "/docs/components" },
      { label: "Routing", href: "/docs/routing" },
      { label: "Theming", href: "/docs/theme" },
      { label: "Charts", href: "/docs/charts" },
      { label: "Tables", href: "/docs/tables" },
      { label: "Mock API", href: "/docs/mock-api" },
      { label: "Deployment", href: "/docs/deployment" },
    ],
  },
  {
    title: "Resources",
    items: [
      { label: "License", href: "/docs/license" },
      { label: "Support", href: "/docs/support" },
    ],
  },
];
