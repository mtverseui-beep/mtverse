"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { BookOpen } from "lucide-react";

export interface DocsNavItem {
  label: string;
  href: string;
  icon?: React.ReactNode;
  badge?: string;
}

export interface DocsNavSection {
  title: string;
  items: DocsNavItem[];
}

export function DocsSidebar({ sections, className }: { sections: DocsNavSection[]; className?: string }) {
  const pathname = usePathname();
  return (
    <aside className={cn("w-64 shrink-0 hidden lg:block", className)}>
      <div className="sticky top-6 space-y-6">
        <div className="flex items-center gap-2 px-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
            <BookOpen className="w-4 h-4" />
          </div>
          <div>
            <p className="text-sm font-semibold">Documentation</p>
            <p className="text-[11px] text-muted-foreground">v1.0.0</p>
          </div>
        </div>
        <nav className="space-y-5 max-h-[calc(100vh-8rem)] overflow-y-auto pr-2 pb-6">
          {sections.map((section) => (
            <div key={section.title} className="space-y-1.5">
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold px-3">
                {section.title}
              </p>
              <div className="space-y-0.5">
                {section.items.map((item) => {
                  const active = pathname === item.href;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        "flex items-center gap-2.5 px-3 py-1.5 rounded-md text-sm transition-colors",
                        active
                          ? "bg-primary/10 text-primary font-medium"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted/60"
                      )}
                    >
                      {item.icon && <span className="shrink-0">{item.icon}</span>}
                      <span className="flex-1 truncate">{item.label}</span>
                      {item.badge && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                          {item.badge}
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
      </div>
    </aside>
  );
}

// ============================================================================
// Code Block
// ============================================================================

export function CodeBlock({ language = "bash", code, title }: { language?: string; code: string; title?: string }) {
  return (
    <div className="rounded-lg border bg-muted/40 overflow-hidden my-4">
      <div className="flex items-center justify-between px-3 py-1.5 border-b bg-muted/60">
        <div className="flex items-center gap-1.5">
          <div className="flex gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-destructive/60" />
            <span className="w-2.5 h-2.5 rounded-full bg-warning/60" />
            <span className="w-2.5 h-2.5 rounded-full bg-success/60" />
          </div>
          <span className="text-[11px] text-muted-foreground ml-2 font-mono">
            {title || language}
          </span>
        </div>
      </div>
      <pre className="p-4 overflow-x-auto text-[13px] leading-relaxed font-mono">
        <code className="text-foreground/90">{code}</code>
      </pre>
    </div>
  );
}

// ============================================================================
// Inline Code
// ============================================================================

export function InlineCode({ children }: { children: React.ReactNode }) {
  return (
    <code className="px-1.5 py-0.5 rounded bg-muted border border-border text-[0.85em] font-mono text-foreground">
      {children}
    </code>
  );
}

// ============================================================================
// Docs Body Wrapper
// ============================================================================

export function DocsBody({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("min-w-0 max-w-3xl space-y-6", className)}>
      {children}
    </div>
  );
}

// ============================================================================
// Prose helpers
// ============================================================================

export function H1({ children }: { children: React.ReactNode }) {
  return <h1 className="text-3xl md:text-4xl font-bold tracking-tight scroll-mt-20">{children}</h1>;
}

export function H2({ children, id }: { children: React.ReactNode; id?: string }) {
  return (
    <h2 id={id} className="text-2xl font-semibold tracking-tight scroll-mt-20 pt-4 border-t border-border-subtle">
      {children}
    </h2>
  );
}

export function H3({ children, id }: { children: React.ReactNode; id?: string }) {
  return (
    <h3 id={id} className="text-lg font-semibold tracking-tight scroll-mt-20">
      {children}
    </h3>
  );
}

export function P({ children }: { children: React.ReactNode }) {
  return <p className="text-[15px] leading-7 text-muted-foreground">{children}</p>;
}

export function UL({ children }: { children: React.ReactNode }) {
  return <ul className="space-y-1.5 text-[15px] text-muted-foreground list-disc pl-5">{children}</ul>;
}

export function Lead({ children }: { children: React.ReactNode }) {
  return <p className="text-lg text-muted-foreground leading-relaxed">{children}</p>;
}

export function Callout({ title, children, variant = "default" }: { title?: string; children: React.ReactNode; variant?: "default" | "info" | "warning" }) {
  const styles = {
    default: "border-border bg-muted/40",
    info: "border-primary/30 bg-primary/5",
    warning: "border-warning/30 bg-warning/5",
  };
  return (
    <div className={cn("rounded-lg border p-4 my-4", styles[variant])}>
      {title && <p className="text-sm font-semibold mb-1">{title}</p>}
      <div className="text-sm text-muted-foreground leading-relaxed">{children}</div>
    </div>
  );
}
