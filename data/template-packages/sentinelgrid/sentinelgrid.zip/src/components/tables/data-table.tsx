"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuCheckboxItem,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import {
  ChevronLeft, ChevronRight, ChevronsUpDown, ChevronDown, ChevronUp,
  Search, SlidersHorizontal, Download, Eye, EyeOff, Columns3,
  Inbox, ArrowUpDown, X, Filter,
} from "lucide-react";
import { useUIStore } from "@/lib/store";

export interface Column<T> {
  key: string;
  header: string;
  cell: (row: T) => React.ReactNode;
  sortValue?: (row: T) => string | number;
  filterable?: boolean;
  filterOptions?: { label: string; value: string }[];
  filterFn?: (row: T, value: string) => boolean;
  sortable?: boolean;
  width?: string;
  align?: "left" | "center" | "right";
  hideOnMobile?: boolean;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  rowKey: (row: T) => string;
  searchKeys?: (keyof T | ((row: T) => string))[];
  searchPlaceholder?: string;
  pageSize?: number;
  initialSort?: { key: string; dir: "asc" | "desc" };
  enableSelection?: boolean;
  onRowClick?: (row: T) => void;
  bulkActions?: { label: string; icon?: React.ReactNode; onClick: (rows: T[]) => void; variant?: "default" | "destructive" }[];
  emptyState?: React.ReactNode;
  loading?: boolean;
  className?: string;
  // Renders the row as a card on mobile (auto-rendered)
  mobileCard?: (row: T) => React.ReactNode;
  // Sticky header
  stickyHeader?: boolean;
}

export function DataTable<T extends Record<string, any>>({
  columns, data, rowKey, searchKeys, searchPlaceholder = "Search...",
  pageSize = 10, initialSort, enableSelection, onRowClick,
  bulkActions, emptyState, loading, className, mobileCard, stickyHeader = true,
}: DataTableProps<T>) {
  const [search, setSearch] = React.useState("");
  const [sort, setSort] = React.useState<{ key: string; dir: "asc" | "desc" } | null>(initialSort || null);
  const [page, setPage] = React.useState(0);
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [columnFilters, setColumnFilters] = React.useState<Record<string, string>>({});
  const [hiddenColumns, setHiddenColumns] = React.useState<Set<string>>(new Set());
  const { density } = useUIStore();

  // Filter
  const filtered = React.useMemo(() => {
    let result = data;
    // Search
    if (search && searchKeys) {
      const q = search.toLowerCase();
      result = result.filter((row) =>
        searchKeys.some((k) => {
          const val = typeof k === "function" ? k(row) : String(row[k] ?? "");
          return val.toLowerCase().includes(q);
        })
      );
    }
    // Column filters
    Object.entries(columnFilters).forEach(([key, value]) => {
      if (!value) return;
      const col = columns.find((c) => c.key === key);
      if (col?.filterFn) {
        result = result.filter((row) => col.filterFn!(row, value));
      }
    });
    // Sort
    if (sort) {
      const col = columns.find((c) => c.key === sort.key);
      if (col?.sortValue) {
        result = [...result].sort((a, b) => {
          const av = col.sortValue!(a);
          const bv = col.sortValue!(b);
          if (av < bv) return sort.dir === "asc" ? -1 : 1;
          if (av > bv) return sort.dir === "asc" ? 1 : -1;
          return 0;
        });
      }
    }
    return result;
  }, [data, search, searchKeys, columnFilters, sort, columns]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages - 1);
  const paged = filtered.slice(currentPage * pageSize, (currentPage + 1) * pageSize);

  React.useEffect(() => { setPage(0); }, [search, columnFilters, sort]);

  function toggleSort(key: string) {
    setSort((s) => {
      if (!s || s.key !== key) return { key, dir: "asc" };
      if (s.dir === "asc") return { key, dir: "desc" };
      return null;
    });
  }

  function toggleSelected(id: string) {
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function toggleSelectAll() {
    if (selected.size === paged.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(paged.map(rowKey)));
    }
  }

  const visibleColumns = columns.filter((c) => !hiddenColumns.has(c.key));
  const hasFilters = columns.some((c) => c.filterable);
  const densityPad = density === "compact" ? "py-1.5" : density === "comfortable" ? "py-3.5" : "py-2.5";

  if (loading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-12 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className={cn("space-y-3", className)}>
      {/* Toolbar */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={searchPlaceholder}
              className="pl-8 h-9 text-sm"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Column visibility */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5">
                <Columns3 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Columns</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel className="text-xs">Toggle columns</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {columns.map((c) => (
                <DropdownMenuCheckboxItem
                  key={c.key}
                  checked={!hiddenColumns.has(c.key)}
                  onCheckedChange={(checked) => {
                    setHiddenColumns((s) => {
                      const next = new Set(s);
                      if (checked) next.delete(c.key); else next.add(c.key);
                      return next;
                    });
                  }}
                  className="text-xs"
                >
                  {c.header}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Export */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5">
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Export</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => exportCSV(visibleColumns, filtered, rowKey)}>Export as CSV</DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportJSON(filtered)}>Export as JSON</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Active column filters */}
      {hasFilters && Object.keys(columnFilters).length > 0 && (
        <div className="flex items-center gap-2 flex-wrap">
          {columns.filter((c) => c.filterable).map((c) => (
            <DropdownMenu key={c.key}>
              <DropdownMenuTrigger asChild>
                <Button
                  variant={columnFilters[c.key] ? "default" : "outline"}
                  size="sm"
                  className="h-8 text-xs gap-1.5"
                >
                  <Filter className="w-3 h-3" />
                  {c.header}
                  {columnFilters[c.key] && <span className="opacity-70">: {c.filterOptions?.find((o) => o.value === columnFilters[c.key])?.label}</span>}
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuItem onClick={() => setColumnFilters((f) => ({ ...f, [c.key]: "" }))}>
                  All
                </DropdownMenuItem>
                {c.filterOptions?.map((o) => (
                  <DropdownMenuItem
                    key={o.value}
                    onClick={() => setColumnFilters((f) => ({ ...f, [c.key]: o.value }))}
                  >
                    {o.label}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          ))}
          {Object.values(columnFilters).some((v) => v) && (
            <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => setColumnFilters({})}>
              Clear all
            </Button>
          )}
        </div>
      )}

      {/* Bulk actions bar */}
      {enableSelection && selected.size > 0 && bulkActions && (
        <div className="flex items-center gap-2 rounded-lg border bg-elevated px-3 py-2">
          <span className="text-xs font-medium">{selected.size} selected</span>
          <div className="ml-auto flex items-center gap-1">
            {bulkActions.map((a, i) => (
              <Button key={i} variant={a.variant === "destructive" ? "destructive" : "outline"} size="sm" className="h-8 text-xs gap-1.5" onClick={() => {
                const rows = filtered.filter((r) => selected.has(rowKey(r)));
                a.onClick(rows);
                setSelected(new Set());
              }}>
                {a.icon}
                {a.label}
              </Button>
            ))}
            <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => setSelected(new Set())}>
              Clear
            </Button>
          </div>
        </div>
      )}

      {/* Desktop table */}
      <div className="hidden md:block rounded-lg border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className={cn("bg-muted/40", stickyHeader && "sticky top-0 z-10")}>
              <tr>
                {enableSelection && (
                  <th className="w-10 px-3 py-2.5">
                    <Checkbox
                      checked={paged.length > 0 && selected.size === paged.length}
                      onCheckedChange={toggleSelectAll}
                      aria-label="Select all"
                    />
                  </th>
                )}
                {visibleColumns.map((c) => (
                  <th
                    key={c.key}
                    className={cn(
                      "px-3 py-2.5 text-left font-medium text-xs uppercase tracking-wider text-muted-foreground whitespace-nowrap",
                      c.align === "right" && "text-right",
                      c.align === "center" && "text-center",
                      c.sortable && "cursor-pointer hover:text-foreground"
                    )}
                    style={c.width ? { width: c.width } : undefined}
                    onClick={c.sortable ? () => toggleSort(c.key) : undefined}
                  >
                    <div className={cn("inline-flex items-center gap-1", c.align === "right" && "flex-row-reverse", c.align === "center" && "justify-center")}>
                      {c.header}
                      {c.sortable && (
                        <span className="text-muted-foreground/60">
                          {sort?.key === c.key ? (
                            sort.dir === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />
                          ) : (
                            <ArrowUpDown className="w-3 h-3" />
                          )}
                        </span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paged.length === 0 ? (
                <tr>
                  <td colSpan={visibleColumns.length + (enableSelection ? 1 : 0)} className="px-3 py-12 text-center">
                    {emptyState || <DefaultEmptyState />}
                  </td>
                </tr>
              ) : (
                paged.map((row) => {
                  const id = rowKey(row);
                  const isSelected = selected.has(id);
                  return (
                    <tr
                      key={id}
                      className={cn(
                        "border-t border-border transition-colors",
                        onRowClick && "cursor-pointer",
                        isSelected ? "bg-primary/5" : "hover:bg-muted/30"
                      )}
                      onClick={onRowClick ? () => onRowClick(row) : undefined}
                    >
                      {enableSelection && (
                        <td className="px-3 py-0" onClick={(e) => e.stopPropagation()}>
                          <div className={densityPad}>
                            <Checkbox checked={isSelected} onCheckedChange={() => toggleSelected(id)} aria-label="Select row" />
                          </div>
                        </td>
                      )}
                      {visibleColumns.map((c) => (
                        <td
                          key={c.key}
                          className={cn(
                            "px-3 text-sm",
                            densityPad,
                            c.align === "right" && "text-right",
                            c.align === "center" && "text-center"
                          )}
                        >
                          {c.cell(row)}
                        </td>
                      ))}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-2">
        {paged.length === 0 ? (
          <div className="rounded-lg border p-8 text-center">
            {emptyState || <DefaultEmptyState />}
          </div>
        ) : mobileCard ? (
          paged.map((row) => <div key={rowKey(row)}>{mobileCard(row)}</div>)
        ) : (
          paged.map((row) => (
            <button
              key={rowKey(row)}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              className="w-full text-left rounded-lg border bg-card p-3 hover:bg-muted/40 transition-colors"
            >
              <div className="space-y-1.5">
                {visibleColumns.slice(0, 4).map((c) => (
                  <div key={c.key} className="flex items-center justify-between gap-3 text-sm">
                    <span className="text-xs text-muted-foreground">{c.header}</span>
                    <span className="font-medium truncate">{c.cell(row)}</span>
                  </div>
                ))}
              </div>
            </button>
          ))
        )}
      </div>

      {/* Pagination */}
      {filtered.length > pageSize && (
        <div className="flex items-center justify-between gap-2 text-xs">
          <span className="text-muted-foreground">
            Showing {currentPage * pageSize + 1}-{Math.min((currentPage + 1) * pageSize, filtered.length)} of {filtered.length}
          </span>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" className="h-8 w-8" disabled={currentPage === 0} onClick={() => setPage(currentPage - 1)}>
              <ChevronLeft className="w-3.5 h-3.5" />
            </Button>
            <span className="text-xs tabular-nums px-2">{currentPage + 1} / {totalPages}</span>
            <Button variant="outline" size="icon" className="h-8 w-8" disabled={currentPage >= totalPages - 1} onClick={() => setPage(currentPage + 1)}>
              <ChevronRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function DefaultEmptyState() {
  return (
    <div className="flex flex-col items-center gap-2 text-muted-foreground">
      <Inbox className="w-6 h-6 opacity-50" />
      <span className="text-sm">No results found</span>
    </div>
  );
}

function exportCSV<T>(columns: Column<T>[], data: T[], rowKey: (row: T) => string) {
  const header = columns.map((c) => `"${c.header}"`).join(",");
  const rows = data.map((row) => {
    return columns.map((c) => {
      const cellContent = c.cell(row);
      // Try to extract text content from React node
      const text = typeof cellContent === "string" || typeof cellContent === "number"
        ? String(cellContent)
        : extractText(cellContent);
      return `"${text.replace(/"/g, '""')}"`;
    }).join(",");
  });
  const csv = [header, ...rows].join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "export.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function exportJSON<T>(data: T[]) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "export.json";
  a.click();
  URL.revokeObjectURL(url);
}

function extractText(node: React.ReactNode): string {
  if (node == null || typeof node === "boolean") return "";
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(extractText).join("");
  if (React.isValidElement(node)) {
    const props = node.props as { children?: React.ReactNode };
    return extractText(props.children);
  }
  return "";
}
