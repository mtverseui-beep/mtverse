"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";

interface KpiCardProps {
  label: string;
  value: string | number;
  unit?: string;
  delta?: number;
  deltaLabel?: string;
  hint?: string;
  icon?: React.ReactNode;
  accent?: "primary" | "accent" | "success" | "warning" | "destructive" | "info" | "muted";
  sparkline?: number[];
  className?: string;
}

const accentClasses: Record<NonNullable<KpiCardProps["accent"]>, string> = {
  primary: "text-primary bg-primary/10 border-primary/20",
  accent: "text-accent-foreground bg-accent border-accent/20",
  success: "text-success bg-success/10 border-success/20",
  warning: "text-warning-foreground bg-warning/10 border-warning/20",
  destructive: "text-destructive bg-destructive/10 border-destructive/20",
  info: "text-info-foreground bg-info/10 border-info/20",
  muted: "text-muted-foreground bg-muted",
};

export function KpiCard({
  label, value, unit, delta, deltaLabel, hint, icon, accent = "primary", sparkline, className,
}: KpiCardProps) {
  const isPositive = delta !== undefined && delta > 0;
  const isNegative = delta !== undefined && delta < 0;
  const isFlat = delta === 0;

  return (
    <Card className={cn("p-5 relative overflow-hidden group transition-colors hover:bg-elevated/40", className)}>
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1 min-w-0">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">{label}</p>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-semibold tracking-tight tabular-nums">{value}</span>
            {unit && <span className="text-xs text-muted-foreground font-medium">{unit}</span>}
          </div>
          {hint && <p className="text-xs text-muted-foreground mt-0.5">{hint}</p>}
        </div>
        {icon && (
          <div className={cn("shrink-0 w-9 h-9 rounded-lg flex items-center justify-center border", accentClasses[accent])}>
            {icon}
          </div>
        )}
      </div>
      {(delta !== undefined || sparkline) && (
        <div className="mt-3 flex items-center justify-between gap-2">
          {delta !== undefined && (
            <div className="flex items-center gap-1.5">
              <span
                className={cn(
                  "inline-flex items-center gap-0.5 text-xs font-medium tabular-nums",
                  isPositive && "text-success",
                  isNegative && "text-destructive",
                  isFlat && "text-muted-foreground"
                )}
              >
                {isPositive && <ArrowUpRight className="w-3 h-3" />}
                {isNegative && <ArrowDownRight className="w-3 h-3" />}
                {isFlat && <Minus className="w-3 h-3" />}
                {delta > 0 ? "+" : ""}{delta}%
              </span>
              {deltaLabel && <span className="text-[11px] text-muted-foreground">{deltaLabel}</span>}
            </div>
          )}
          {sparkline && <Sparkline data={sparkline} />}
        </div>
      )}
    </Card>
  );
}

function Sparkline({ data }: { data: number[] }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 80;
  const h = 24;
  const points = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = h - ((v - min) / range) * h;
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(" ");
  return (
    <svg width={w} height={h} className="opacity-70" aria-hidden="true">
      <polyline
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
        className="text-primary"
      />
    </svg>
  );
}
