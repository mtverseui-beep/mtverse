"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { AlertTriangle, ShieldAlert, ShieldX, Info, AlertOctagon } from "lucide-react";
import type { Severity, IncidentStatus, ServiceHealth, DeploymentStatus, AlertStatus, SLOStatus } from "@/lib/types";

// ============================================================================
// Severity Badge
// ============================================================================

const severityConfig: Record<Severity, { label: string; className: string; icon: React.ReactNode; dot: string }> = {
  critical: { label: "Critical", className: "bg-destructive/15 text-destructive border-destructive/30", icon: <ShieldX className="w-3 h-3" />, dot: "bg-destructive" },
  high: { label: "High", className: "bg-warning/15 text-warning-foreground border-warning/30", icon: <ShieldAlert className="w-3 h-3" />, dot: "bg-warning" },
  medium: { label: "Medium", className: "bg-info/15 text-info-foreground border-info/30", icon: <AlertTriangle className="w-3 h-3" />, dot: "bg-info" },
  low: { label: "Low", className: "bg-muted text-muted-foreground border-border", icon: <AlertOctagon className="w-3 h-3" />, dot: "bg-muted-foreground" },
  info: { label: "Info", className: "bg-muted text-muted-foreground border-border", icon: <Info className="w-3 h-3" />, dot: "bg-muted-foreground" },
};

export function SeverityBadge({ severity, size = "default" }: { severity: Severity; size?: "sm" | "default" }) {
  const c = severityConfig[severity];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md border font-medium uppercase tracking-wide",
        size === "sm" ? "px-1.5 py-0.5 text-[10px]" : "px-2 py-0.5 text-[11px]",
        c.className
      )}
    >
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot)} />
      {c.label}
    </span>
  );
}

// ============================================================================
// Incident Status Badge
// ============================================================================

const incidentStatusConfig: Record<IncidentStatus, { label: string; className: string }> = {
  investigating: { label: "Investigating", className: "bg-destructive/15 text-destructive border-destructive/30" },
  identified: { label: "Identified", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  monitoring: { label: "Monitoring", className: "bg-info/15 text-info-foreground border-info/30" },
  mitigated: { label: "Mitigated", className: "bg-info/15 text-info-foreground border-info/30" },
  resolved: { label: "Resolved", className: "bg-success/15 text-success border-success/30" },
  postmortem: { label: "Postmortem", className: "bg-accent text-accent-foreground border-accent/30" },
};

export function IncidentStatusBadge({ status }: { status: IncidentStatus }) {
  const c = incidentStatusConfig[status];
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium", c.className)}>
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
      {c.label}
    </span>
  );
}

// ============================================================================
// Service Health Badge
// ============================================================================

const serviceHealthConfig: Record<ServiceHealth, { label: string; className: string; dot: string }> = {
  operational: { label: "Operational", className: "bg-success/15 text-success border-success/30", dot: "bg-success" },
  degraded: { label: "Degraded", className: "bg-warning/15 text-warning-foreground border-warning/30", dot: "bg-warning" },
  partial: { label: "Partial Outage", className: "bg-destructive/15 text-destructive border-destructive/30", dot: "bg-destructive" },
  major: { label: "Major Outage", className: "bg-destructive/20 text-destructive border-destructive/40", dot: "bg-destructive" },
  maintenance: { label: "Maintenance", className: "bg-info/15 text-info-foreground border-info/30", dot: "bg-info" },
};

export function ServiceHealthBadge({ health }: { health: ServiceHealth }) {
  const c = serviceHealthConfig[health];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-[11px] font-medium", c.className)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot, health === "operational" && "animate-status-pulse")} />
      {c.label}
    </span>
  );
}

// ============================================================================
// Deployment Status Badge
// ============================================================================

const deploymentStatusConfig: Record<DeploymentStatus, { label: string; className: string }> = {
  queued: { label: "Queued", className: "bg-muted text-muted-foreground border-border" },
  in_progress: { label: "In Progress", className: "bg-info/15 text-info-foreground border-info/30" },
  rolling_out: { label: "Rolling Out", className: "bg-info/15 text-info-foreground border-info/30" },
  canary: { label: "Canary", className: "bg-accent text-accent-foreground border-accent/30" },
  succeeded: { label: "Succeeded", className: "bg-success/15 text-success border-success/30" },
  failed: { label: "Failed", className: "bg-destructive/15 text-destructive border-destructive/30" },
  rolled_back: { label: "Rolled Back", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  halted: { label: "Halted", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  approved: { label: "Approved", className: "bg-success/15 text-success border-success/30" },
  pending_approval: { label: "Pending Approval", className: "bg-warning/15 text-warning-foreground border-warning/30" },
};

export function DeploymentStatusBadge({ status }: { status: DeploymentStatus }) {
  const c = deploymentStatusConfig[status];
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium", c.className)}>
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
      {c.label}
    </span>
  );
}

// ============================================================================
// Alert Status Badge
// ============================================================================

const alertStatusConfig: Record<AlertStatus, { label: string; className: string; dot: string }> = {
  firing: { label: "Firing", className: "bg-destructive/15 text-destructive border-destructive/30", dot: "bg-destructive" },
  acknowledged: { label: "Acknowledged", className: "bg-warning/15 text-warning-foreground border-warning/30", dot: "bg-warning" },
  resolved: { label: "Resolved", className: "bg-success/15 text-success border-success/30", dot: "bg-success" },
  suppressed: { label: "Suppressed", className: "bg-muted text-muted-foreground border-border", dot: "bg-muted-foreground" },
};

export function AlertStatusBadge({ status }: { status: AlertStatus }) {
  const c = alertStatusConfig[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-[11px] font-medium", c.className)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot, status === "firing" && "animate-status-pulse")} />
      {c.label}
    </span>
  );
}

// ============================================================================
// SLO Status Badge
// ============================================================================

const sloStatusConfig: Record<SLOStatus, { label: string; className: string }> = {
  healthy: { label: "Healthy", className: "bg-success/15 text-success border-success/30" },
  at_risk: { label: "At Risk", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  breached: { label: "Breached", className: "bg-destructive/15 text-destructive border-destructive/30" },
  exhausted: { label: "Budget Exhausted", className: "bg-destructive/20 text-destructive border-destructive/40" },
};

export function SLOStatusBadge({ status }: { status: SLOStatus }) {
  const c = sloStatusConfig[status];
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium", c.className)}>
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
      {c.label}
    </span>
  );
}

// ============================================================================
// Generic Status Dot
// ============================================================================

export function StatusDot({ color = "success", pulse = false, size = "sm" }: { color?: "success" | "warning" | "destructive" | "info" | "muted" | "primary" | "accent"; pulse?: boolean; size?: "sm" | "md" }) {
  const colors = {
    success: "bg-success",
    warning: "bg-warning",
    destructive: "bg-destructive",
    info: "bg-info",
    muted: "bg-muted-foreground",
    primary: "bg-primary",
    accent: "bg-accent",
  };
  return (
    <span
      className={cn("inline-block rounded-full", colors[color], pulse && "animate-status-pulse", size === "sm" ? "w-1.5 h-1.5" : "w-2 h-2")}
      aria-hidden="true"
    />
  );
}

// ============================================================================
// Tier Badge
// ============================================================================

const tierConfig: Record<string, { label: string; className: string }> = {
  tier1: { label: "Tier 1", className: "bg-primary/15 text-primary border-primary/30" },
  tier2: { label: "Tier 2", className: "bg-accent text-accent-foreground border-accent/30" },
  tier3: { label: "Tier 3", className: "bg-muted text-muted-foreground border-border" },
  tier4: { label: "Tier 4", className: "bg-muted text-muted-foreground border-border" },
};

export function TierBadge({ tier }: { tier: string }) {
  const c = tierConfig[tier] || tierConfig.tier3;
  return (
    <span className={cn("inline-flex items-center rounded-md border px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide", c.className)}>
      {c.label}
    </span>
  );
}
