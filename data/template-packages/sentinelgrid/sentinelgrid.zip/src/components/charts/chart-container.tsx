"use client";

import * as React from "react";
import { useTheme } from "@/components/theme-provider";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Maximize2, Download, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";

// ============================================================================
// Chart Theme Hook — provides consistent colors across dark/light
// ============================================================================

export function useChartTheme() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  return {
    isDark,
    grid: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)",
    axis: isDark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.55)",
    tooltipBg: isDark ? "#13151B" : "#FFFFFF",
    tooltipBorder: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)",
    tooltipText: isDark ? "#F1F5F9" : "#0A0B0F",
    palette: [
      isDark ? "#22D3EE" : "#0891B2", // primary - cyan
      isDark ? "#A78BFA" : "#7C3AED", // accent - violet
      isDark ? "#FCD34D" : "#D97706", // warning - amber
      isDark ? "#34D399" : "#059669", // success - green
      isDark ? "#F87171" : "#DC2626", // destructive - red
      isDark ? "#FB923C" : "#EA580C", // orange
      isDark ? "#60A5FA" : "#2563EB", // info - blue
      isDark ? "#94A3B8" : "#475569", // slate
    ],
  };
}

// ============================================================================
// Chart Container — wraps a chart card with header, time range, actions
// ============================================================================

interface ChartContainerProps {
  title: string;
  description?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  fullscreen?: boolean;
}

export function ChartContainer({ title, description, actions, children, className, fullscreen = true }: ChartContainerProps) {
  const [open, setOpen] = React.useState(false);
  return (
    <Card className={cn("p-5 space-y-4", className)}>
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-0.5 min-w-0">
          <h3 className="text-sm font-semibold tracking-tight">{title}</h3>
          {description && <p className="text-xs text-muted-foreground">{description}</p>}
        </div>
        <div className="flex items-center gap-1">
          {actions}
          {fullscreen && (
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground" aria-label="Expand chart">
                  <Maximize2 className="w-3.5 h-3.5" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-6xl h-[80vh]">
                <DialogHeader>
                  <DialogTitle>{title}</DialogTitle>
                </DialogHeader>
                <div className="flex-1 overflow-hidden h-[calc(80vh-100px)]">
                  {children}
                </div>
              </DialogContent>
            </Dialog>
          )}
          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground" aria-label="Export chart" onClick={() => toast("Chart exported as PNG")}>
            <Download className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
      <div className="h-[260px]">{children}</div>
    </Card>
  );
}

function toast(message: string) {
  if (typeof window !== "undefined") {
    import("sonner").then((s) => s.toast.success(message));
  }
}

// ============================================================================
// Custom Tooltip — used by all Recharts components
// ============================================================================

interface TooltipPayloadItem {
  name?: string;
  value?: number | string;
  color?: string;
  dataKey?: string | number;
  payload?: Record<string, unknown>;
}

export function ChartTooltip({
  active, payload, label, formatter, suffix,
}: {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string | number;
  formatter?: (value: number | string, name: string) => string;
  suffix?: string;
}) {
  const { tooltipBg, tooltipBorder, tooltipText } = useChartTheme();
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div
      style={{ background: tooltipBg, border: `1px solid ${tooltipBorder}`, color: tooltipText }}
      className="rounded-lg px-3 py-2 text-xs shadow-lg space-y-1 min-w-[120px]"
    >
      {label !== undefined && (
        <div className="font-medium text-[11px] opacity-70">{label}</div>
      )}
      {payload.map((p, i) => (
        <div key={i} className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="w-2 h-2 rounded-full shrink-0" style={{ background: p.color }} />
            <span className="opacity-80 truncate">{p.name}</span>
          </div>
          <span className="font-medium tabular-nums">
            {formatter && p.value !== undefined ? formatter(p.value, p.name || "") : p.value}
            {suffix}
          </span>
        </div>
      ))}
    </div>
  );
}

// ============================================================================
// Chart Card (simple wrapper for non-fullscreen charts)
// ============================================================================

export function ChartCard({ title, children, className, action }: { title?: string; children: React.ReactNode; className?: string; action?: React.ReactNode }) {
  return (
    <Card className={cn("p-5", className)}>
      {title && (
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold tracking-tight">{title}</h3>
          {action}
        </div>
      )}
      {children}
    </Card>
  );
}
