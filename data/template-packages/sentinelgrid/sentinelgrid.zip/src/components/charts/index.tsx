"use client";

import * as React from "react";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Line, LineChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis, Cell, ReferenceLine,
  PieChart, Pie, Legend, RadialBarChart, RadialBar, ComposedChart,
} from "recharts";
import { useChartTheme, ChartTooltip, ChartContainer } from "./chart-container";
import { cn } from "@/lib/utils";

// ============================================================================
// Latency Percentile Chart
// ============================================================================

interface LatencyChartProps {
  data: { timestamp: string; p50: number; p95: number; p99: number }[];
  unit?: string;
  title?: string;
  description?: string;
}

export function LatencyChart({ data, unit = "ms", title = "Latency Percentiles", description }: LatencyChartProps) {
  const t = useChartTheme();
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id="lat-p50" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={t.palette[0]} stopOpacity={0.3} />
              <stop offset="95%" stopColor={t.palette[0]} stopOpacity={0} />
            </linearGradient>
            <linearGradient id="lat-p95" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={t.palette[1]} stopOpacity={0.3} />
              <stop offset="95%" stopColor={t.palette[1]} stopOpacity={0} />
            </linearGradient>
            <linearGradient id="lat-p99" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={t.palette[2]} stopOpacity={0.3} />
              <stop offset="95%" stopColor={t.palette[2]} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="timestamp" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} />
          <Tooltip content={<ChartTooltip suffix={unit} />} />
          <Area type="monotone" dataKey="p99" stroke={t.palette[2]} strokeWidth={1.5} fill="url(#lat-p99)" name="p99" />
          <Area type="monotone" dataKey="p95" stroke={t.palette[1]} strokeWidth={1.5} fill="url(#lat-p95)" name="p95" />
          <Area type="monotone" dataKey="p50" stroke={t.palette[0]} strokeWidth={1.5} fill="url(#lat-p50)" name="p50" />
        </AreaChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}

// ============================================================================
// Request Volume Chart
// ============================================================================

interface VolumeChartProps {
  data: { timestamp: string; value: number }[];
  color?: number;
  title?: string;
  description?: string;
  unit?: string;
}

export function VolumeChart({ data, color = 0, title = "Request Volume", description, unit }: VolumeChartProps) {
  const t = useChartTheme();
  const c = t.palette[color];
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id={`vol-${color}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={c} stopOpacity={0.35} />
              <stop offset="95%" stopColor={c} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="timestamp" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} />
          <Tooltip content={<ChartTooltip suffix={unit} />} />
          <Area type="monotone" dataKey="value" stroke={c} strokeWidth={1.75} fill={`url(#vol-${color})`} name="Volume" />
        </AreaChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}

// ============================================================================
// Error Rate Chart
// ============================================================================

export function ErrorRateChart({ data, title = "Error Rate", description }: { data: { timestamp: string; value: number }[]; title?: string; description?: string }) {
  const t = useChartTheme();
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id="err-rate" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={t.palette[4]} stopOpacity={0.35} />
              <stop offset="95%" stopColor={t.palette[4]} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="timestamp" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} tickFormatter={(v) => `${v}%`} />
          <Tooltip content={<ChartTooltip suffix="%" />} />
          <Area type="monotone" dataKey="value" stroke={t.palette[4]} strokeWidth={1.75} fill="url(#err-rate)" name="Error Rate" />
        </AreaChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}

// ============================================================================
// Burn Rate Chart
// ============================================================================

export function BurnRateChart({ data, threshold = 14.4, title = "Burn Rate", description }: { data: { timestamp: string; value: number }[]; threshold?: number; title?: string; description?: string }) {
  const t = useChartTheme();
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="timestamp" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} />
          <Tooltip content={<ChartTooltip suffix="x" />} />
          <ReferenceLine y={threshold} stroke={t.palette[4]} strokeDasharray="4 4" label={{ value: "Threshold", position: "insideTopRight", fill: t.palette[4], fontSize: 10 }} />
          <Line type="monotone" dataKey="value" stroke={t.palette[2]} strokeWidth={2} dot={false} name="Burn Rate" />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}

// ============================================================================
// SLO Compliance Chart (bar with target line)
// ============================================================================

export function SLOComplianceChart({ data, target = 99.9, title = "SLO Compliance", description }: { data: { name: string; value: number }[]; target?: number; title?: string; description?: string }) {
  const t = useChartTheme();
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="name" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} domain={[95, 100]} />
          <Tooltip content={<ChartTooltip suffix="%" />} />
          <ReferenceLine y={target} stroke={t.palette[3]} strokeDasharray="4 4" label={{ value: `Target ${target}%`, position: "insideTopRight", fill: t.palette[3], fontSize: 10 }} />
          <Bar dataKey="value" radius={[4, 4, 0, 0]} name="Compliance">
            {data.map((d, i) => (
              <Cell key={i} fill={d.value >= target ? t.palette[3] : d.value >= target - 0.5 ? t.palette[2] : t.palette[4]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}

// ============================================================================
// Incident Severity Trend (stacked bar)
// ============================================================================

export function IncidentSeverityTrendChart({ data, title = "Incident Severity Trend", description }: { data: { date: string; critical: number; high: number; medium: number; low: number }[]; title?: string; description?: string }) {
  const t = useChartTheme();
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="date" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={28} />
          <Tooltip content={<ChartTooltip />} cursor={{ fill: t.isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.04)" }} />
          <Bar dataKey="critical" stackId="a" fill={t.palette[4]} name="Critical" radius={[0, 0, 0, 0]} />
          <Bar dataKey="high" stackId="a" fill={t.palette[2]} name="High" />
          <Bar dataKey="medium" stackId="a" fill={t.palette[1]} name="Medium" />
          <Bar dataKey="low" stackId="a" fill={t.palette[7]} name="Low" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}

// ============================================================================
// MTTR / MTTD / MTTA Trend (multi-line)
// ============================================================================

export function MTTRTrendChart({ data, title = "Mean Time to Recovery", description }: { data: { date: string; mttr: number; mttd: number; mtta: number }[]; title?: string; description?: string }) {
  const t = useChartTheme();
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="date" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} unit="m" />
          <Tooltip content={<ChartTooltip suffix=" min" />} />
          <Line type="monotone" dataKey="mttr" stroke={t.palette[4]} strokeWidth={2} dot={false} name="MTTR" />
          <Line type="monotone" dataKey="mttd" stroke={t.palette[2]} strokeWidth={2} dot={false} name="MTTD" />
          <Line type="monotone" dataKey="mtta" stroke={t.palette[1]} strokeWidth={2} dot={false} name="MTTA" />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}

// ============================================================================
// Deployment Frequency Chart
// ============================================================================

export function DeploymentFrequencyChart({ data, title = "Deployment Frequency", description }: { data: { date: string; deployments: number; failures: number }[]; title?: string; description?: string }) {
  const t = useChartTheme();
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="date" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
          <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={28} />
          <Tooltip content={<ChartTooltip />} cursor={{ fill: t.isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.04)" }} />
          <Bar dataKey="deployments" fill={t.palette[0]} radius={[4, 4, 0, 0]} name="Deployments" />
          <Bar dataKey="failures" fill={t.palette[4]} radius={[4, 4, 0, 0]} name="Failures" />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}

// ============================================================================
// Simple Line Chart
// ============================================================================

export function LineChartCard({ data, dataKey = "value", color = 0, title, description, suffix, height = 260 }: { data: any[]; dataKey?: string; color?: number; title?: string; description?: string; suffix?: string; height?: number }) {
  const t = useChartTheme();
  const c = t.palette[color];
  const inner = (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
        <CartesianGrid stroke={t.grid} vertical={false} />
        <XAxis dataKey="date" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
        <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} />
        <Tooltip content={<ChartTooltip suffix={suffix} />} />
        <Line type="monotone" dataKey={dataKey} stroke={c} strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
  if (title) {
    return <ChartContainer title={title} description={description}>{inner}</ChartContainer>;
  }
  return <div style={{ height }}>{inner}</div>;
}

// ============================================================================
// Donut Chart (for severity distribution, etc.)
// ============================================================================

interface DonutChartProps {
  data: { name: string; value: number; color?: string }[];
  title?: string;
  description?: string;
  centerLabel?: string;
  centerValue?: string;
}

export function DonutChart({ data, title, description, centerLabel, centerValue }: DonutChartProps) {
  const t = useChartTheme();
  const colored = data.map((d, i) => ({ ...d, color: d.color || t.palette[i % t.palette.length] }));
  const total = data.reduce((s, d) => s + d.value, 0);
  const inner = (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie data={colored} dataKey="value" nameKey="name" innerRadius="60%" outerRadius="85%" paddingAngle={2} stroke="none">
          {colored.map((d, i) => <Cell key={i} fill={d.color} />)}
        </Pie>
        <Tooltip content={<ChartTooltip />} />
      </PieChart>
    </ResponsiveContainer>
  );
  if (!title) {
    return <div className="relative h-[260px]">{inner}{(centerLabel || centerValue) && <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
      {centerValue && <span className="text-2xl font-semibold tabular-nums">{centerValue}</span>}
      {centerLabel && <span className="text-xs text-muted-foreground">{centerLabel}</span>}
    </div>}</div>;
  }
  return (
    <ChartContainer title={title} description={description}>
      <div className="relative h-full">{inner}{(centerLabel || centerValue) && <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        {centerValue && <span className="text-2xl font-semibold tabular-nums">{centerValue}</span>}
        {centerLabel && <span className="text-xs text-muted-foreground">{centerLabel}</span>}
      </div>}</div>
    </ChartContainer>
  );
}

// ============================================================================
// Horizontal Bar Chart (top services, top errors, etc.)
// ============================================================================

export function HorizontalBarChart({ data, title, description, color = 0 }: { data: { name: string; value: number }[]; title?: string; description?: string; color?: number }) {
  const t = useChartTheme();
  const c = t.palette[color];
  const inner = (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart layout="vertical" data={data} margin={{ top: 4, right: 16, bottom: 0, left: 0 }}>
        <CartesianGrid stroke={t.grid} horizontal={false} />
        <XAxis type="number" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
        <YAxis type="category" dataKey="name" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={120} />
        <Tooltip content={<ChartTooltip />} cursor={{ fill: t.isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.04)" }} />
        <Bar dataKey="value" fill={c} radius={[0, 4, 4, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
  if (title) return <ChartContainer title={title} description={description}>{inner}</ChartContainer>;
  return <div className="h-[260px]">{inner}</div>;
}

// ============================================================================
// Uptime Calendar Heatmap (90 days)
// ============================================================================

export function UptimeHeatmap({ data, title = "Availability Calendar", description }: { data: { date: string; uptime: number; incidents: number }[]; title?: string; description?: string }) {
  const t = useChartTheme();
  function colorOf(u: number) {
    if (u >= 100) return t.palette[3];
    if (u >= 99.9) return t.palette[3] + "AA";
    if (u >= 99) return t.palette[2];
    if (u >= 95) return t.palette[5];
    return t.palette[4];
  }
  // Group by week (7-day columns)
  const weeks: typeof data[] = [];
  for (let i = 0; i < data.length; i += 7) {
    weeks.push(data.slice(i, i + 7));
  }
  return (
    <ChartContainer title={title} description={description} fullscreen={false}>
      <div className="overflow-x-auto">
        <div className="flex gap-1 min-w-[700px]">
          {weeks.map((week, wi) => (
            <div key={wi} className="flex flex-col gap-1">
              {week.map((d, di) => (
                <div
                  key={di}
                  className="w-3 h-3 rounded-sm group relative"
                  style={{ background: colorOf(d.uptime) }}
                  title={`${d.date}: ${d.uptime.toFixed(3)}% uptime, ${d.incidents} incident(s)`}
                />
              ))}
            </div>
          ))}
        </div>
        <div className="flex items-center gap-3 mt-4 text-xs text-muted-foreground">
          <span>Less</span>
          <div className="flex gap-1">
            <span className="w-3 h-3 rounded-sm" style={{ background: t.palette[4] }} />
            <span className="w-3 h-3 rounded-sm" style={{ background: t.palette[5] }} />
            <span className="w-3 h-3 rounded-sm" style={{ background: t.palette[2] }} />
            <span className="w-3 h-3 rounded-sm" style={{ background: t.palette[3] + "AA" }} />
            <span className="w-3 h-3 rounded-sm" style={{ background: t.palette[3] }} />
          </div>
          <span>More</span>
          <span className="ml-auto text-[11px]">90-day window</span>
        </div>
      </div>
    </ChartContainer>
  );
}

// ============================================================================
// Radial Gauge (single value with target)
// ============================================================================

export function RadialGauge({ value, target = 100, label, color = 0, size = 160 }: { value: number; target?: number; label?: string; color?: number; size?: number }) {
  const t = useChartTheme();
  const c = t.palette[color];
  const pct = Math.min(100, (value / target) * 100);
  const data = [{ name: "value", value: pct, fill: c }];
  return (
    <div className="flex flex-col items-center justify-center" style={{ width: size, height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadialBarChart innerRadius="70%" outerRadius="100%" data={data} startAngle={90} endAngle={-270}>
          <RadialBar background={{ fill: t.isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)" }} dataKey="value" cornerRadius={8} />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="-mt-[110px] flex flex-col items-center pointer-events-none">
        <span className="text-2xl font-semibold tabular-nums">{value}{target === 100 ? "%" : ""}</span>
        {label && <span className="text-[11px] text-muted-foreground">{label}</span>}
      </div>
    </div>
  );
}

// ============================================================================
// Composed Chart (bars + lines)
// ============================================================================

export function ComposedChartCard({ data, bars, lines, title, description, suffix }: {
  data: any[];
  bars: { key: string; name: string; color?: number }[];
  lines: { key: string; name: string; color?: number }[];
  title?: string;
  description?: string;
  suffix?: string;
}) {
  const t = useChartTheme();
  const inner = (
    <ResponsiveContainer width="100%" height="100%">
      <ComposedChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
        <CartesianGrid stroke={t.grid} vertical={false} />
        <XAxis dataKey="date" stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} />
        <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} />
        <Tooltip content={<ChartTooltip suffix={suffix} />} />
        {bars.map((b) => (
          <Bar key={b.key} dataKey={b.key} fill={t.palette[b.color ?? 0]} name={b.name} radius={[4, 4, 0, 0]} />
        ))}
        {lines.map((l) => (
          <Line key={l.key} type="monotone" dataKey={l.key} stroke={t.palette[l.color ?? 1]} strokeWidth={2} dot={false} name={l.name} />
        ))}
      </ComposedChart>
    </ResponsiveContainer>
  );
  if (title) return <ChartContainer title={title} description={description}>{inner}</ChartContainer>;
  return <div className="h-[260px]">{inner}</div>;
}
