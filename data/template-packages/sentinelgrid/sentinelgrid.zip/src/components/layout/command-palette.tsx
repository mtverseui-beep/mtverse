"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput,
  CommandItem, CommandList, CommandSeparator, CommandShortcut,
} from "@/components/ui/command";
import { useUIStore } from "@/lib/store";
import { allNavItems } from "@/lib/nav";
import { incidents, services, deployments, alerts, errors, runbooks, people } from "@/lib/data";
import * as LucideIcons from "lucide-react";
import { Search, AlertTriangle, Server, Rocket, Bell, Bug, Book, User, Clock, Star, Plus, Zap } from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { toast } from "sonner";

type IconComponent = React.ComponentType<{ className?: string }>;
function getIcon(name: string): IconComponent {
  const icon = (LucideIcons as unknown as Record<string, IconComponent>)[name];
  return icon || LucideIcons.Circle;
}

export function CommandPalette() {
  const open = useUIStore((s) => s.commandPaletteOpen);
  const setOpen = useUIStore((s) => s.setCommandPaletteOpen);
  const recentPages = useUIStore((s) => s.recentPages);
  const favorites = useUIStore((s) => s.favorites);
  const { toggleTheme } = useTheme();
  const router = useRouter();

  // Global Cmd/Ctrl+K
  React.useEffect(() => {
    function handler(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen(!open);
      }
    }
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, setOpen]);

  function navigate(href: string, title?: string) {
    setOpen(false);
    if (title) {
      useUIStore.getState().pushRecent({ href, title, visitedAt: Date.now() });
    }
    router.push(href);
  }

  function runAction(label: string, fn: () => void) {
    setOpen(false);
    fn();
    toast.success(label);
  }

  const pageItems = allNavItems.filter((i) => !i.href.includes("["));
  const favoriteItems = pageItems.filter((i) => favorites.includes(i.href));

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Search pages, incidents, services, actions..." />
      <CommandList className="max-h-[420px]">
        <CommandEmpty>No results found.</CommandEmpty>

        {/* Quick actions */}
        <CommandGroup heading="Quick Actions">
          <CommandItem onSelect={() => runAction("Create incident", () => navigate("/incidents/new"))}>
            <Plus className="mr-2 h-4 w-4" />
            <span>Create new incident</span>
            <CommandShortcut>N</CommandShortcut>
          </CommandItem>
          <CommandItem onSelect={() => runAction("Acknowledging alert", () => navigate("/alerts"))}>
            <Bell className="mr-2 h-4 w-4" />
            <span>Acknowledge next alert</span>
          </CommandItem>
          <CommandItem onSelect={() => runAction("Schedule maintenance", () => navigate("/admin/integrations"))}>
            <Server className="mr-2 h-4 w-4" />
            <span>Schedule maintenance window</span>
          </CommandItem>
          <CommandItem onSelect={() => runAction("Starting postmortem", () => navigate("/postmortems/new"))}>
            <Book className="mr-2 h-4 w-4" />
            <span>Start a postmortem</span>
          </CommandItem>
          <CommandItem onSelect={() => runAction("Creating deployment", () => navigate("/deployments"))}>
            <Rocket className="mr-2 h-4 w-4" />
            <span>Create deployment</span>
          </CommandItem>
          <CommandItem onSelect={() => runAction("Theme switched", toggleTheme)}>
            <Zap className="mr-2 h-4 w-4" />
            <span>Toggle theme</span>
            <CommandShortcut>T</CommandShortcut>
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        {/* Recent */}
        {recentPages.length > 0 && (
          <>
            <CommandGroup heading="Recently Visited">
              {recentPages.slice(0, 5).map((p) => (
                <CommandItem key={p.href} onSelect={() => navigate(p.href, p.title)}>
                  <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                  <span>{p.title}</span>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* Favorites */}
        {favoriteItems.length > 0 && (
          <>
            <CommandGroup heading="Favorites">
              {favoriteItems.slice(0, 6).map((i) => {
                const Icon = getIcon(i.icon);
                return (
                  <CommandItem key={i.href} onSelect={() => navigate(i.href, i.label)}>
                    <Star className="mr-2 h-4 w-4 text-warning-foreground" />
                    <span>{i.label}</span>
                  </CommandItem>
                );
              })}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* Incidents */}
        <CommandGroup heading="Incidents">
          {incidents.slice(0, 5).map((inc) => (
            <CommandItem key={inc.id} onSelect={() => navigate(`/incidents/${inc.id}`, inc.ref)}>
              <AlertTriangle className="mr-2 h-4 w-4 text-destructive" />
              <span className="flex-1 truncate">{inc.ref} - {inc.title}</span>
              <CommandShortcut className="text-destructive">{inc.severity}</CommandShortcut>
            </CommandItem>
          ))}
        </CommandGroup>

        {/* Services */}
        <CommandGroup heading="Services">
          {services.slice(0, 6).map((s) => (
            <CommandItem key={s.id} onSelect={() => navigate(`/services/${s.id}`, s.name)}>
              <Server className="mr-2 h-4 w-4 text-primary" />
              <span className="flex-1 truncate">{s.name}</span>
              <CommandShortcut>{s.tier}</CommandShortcut>
            </CommandItem>
          ))}
        </CommandGroup>

        {/* Deployments */}
        <CommandGroup heading="Recent Deployments">
          {deployments.slice(0, 5).map((d) => (
            <CommandItem key={d.id} onSelect={() => navigate(`/deployments/${d.id}`, d.ref)}>
              <Rocket className="mr-2 h-4 w-4 text-accent" />
              <span className="flex-1 truncate">{d.ref} - {d.version}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        {/* Alerts */}
        <CommandGroup heading="Alerts">
          {alerts.slice(0, 5).map((a) => (
            <CommandItem key={a.id} onSelect={() => navigate(`/alerts/${a.id}`, a.ref)}>
              <Bell className="mr-2 h-4 w-4 text-warning-foreground" />
              <span className="flex-1 truncate">{a.ref} - {a.message}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        {/* Errors */}
        <CommandGroup heading="Errors">
          {errors.slice(0, 5).map((e) => (
            <CommandItem key={e.id} onSelect={() => navigate(`/errors/${e.id}`, e.ref)}>
              <Bug className="mr-2 h-4 w-4 text-destructive" />
              <span className="flex-1 truncate">{e.ref} - {e.message}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        {/* Runbooks */}
        <CommandGroup heading="Runbooks">
          {runbooks.slice(0, 5).map((r) => (
            <CommandItem key={r.id} onSelect={() => navigate(`/services/runbooks/${r.id}`, r.title)}>
              <Book className="mr-2 h-4 w-4" />
              <span className="flex-1 truncate">{r.title}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        {/* People */}
        <CommandGroup heading="Team Members">
          {people.slice(0, 5).map((p) => (
            <CommandItem key={p.id} onSelect={() => navigate(`/admin/team/${p.id}`, p.name)}>
              <img src={p.avatarUrl} alt="" className="mr-2 h-4 w-4 rounded-full object-cover" />
              <span className="flex-1 truncate">{p.name}</span>
              <CommandShortcut>{p.team}</CommandShortcut>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandSeparator />

        {/* All pages */}
        <CommandGroup heading="All Pages">
          {pageItems.map((i) => {
            const Icon = getIcon(i.icon);
            return (
              <CommandItem key={i.href} onSelect={() => navigate(i.href, i.label)}>
                <Icon className="mr-2 h-4 w-4 text-muted-foreground" />
                <span className="flex-1 truncate">{i.label}</span>
                <CommandShortcut>{i.group}</CommandShortcut>
              </CommandItem>
            );
          })}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
