"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import * as LucideIcons from "lucide-react";
import { cn } from "@/lib/utils";
import { useUIStore } from "@/lib/store";
import { navGroups } from "@/lib/nav";
import { incidents, alerts, services } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { ChevronLeft, ChevronRight, Star, Clock, X } from "lucide-react";

type IconComponent = React.ComponentType<{ className?: string }>;

function getIcon(name: string): IconComponent {
  const icon = (LucideIcons as unknown as Record<string, IconComponent>)[name];
  return icon || LucideIcons.Circle;
}

function isActive(pathname: string, href: string): boolean {
  if (href === "/dashboard") return pathname === "/dashboard";
  return pathname === href || pathname.startsWith(href + "/");
}

export function Sidebar() {
  const pathname = usePathname();
  const { sidebarCollapsed, toggleSidebar, mobileSidebarOpen, setMobileSidebarOpen, recentPages, favorites, toggleFavorite } = useUIStore();

  return (
    <>
      {/* Mobile overlay */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setMobileSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      <aside
        className={cn(
          "fixed md:sticky top-0 z-50 md:z-30 h-screen bg-sidebar border-r border-sidebar-border flex flex-col shrink-0 transition-[width,transform] duration-200 ease-in-out",
          sidebarCollapsed ? "w-[68px]" : "w-[260px]",
          mobileSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        {/* Logo */}
        <div className="h-14 px-4 flex items-center gap-2.5 border-b border-sidebar-border shrink-0">
          <Link href="/dashboard" className="flex items-center gap-2.5 min-w-0" onClick={() => setMobileSidebarOpen(false)}>
            <LogoMark />
            {!sidebarCollapsed && (
              <div className="min-w-0">
                <div className="font-semibold text-sm tracking-tight leading-none">SentinelGrid</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">Engineering Operations</div>
              </div>
            )}
          </Link>
          <button
            onClick={() => setMobileSidebarOpen(false)}
            className="ml-auto md:hidden text-muted-foreground hover:text-foreground"
            aria-label="Close sidebar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <ScrollArea className="flex-1 min-h-0">
          <nav className="py-3 px-2 space-y-4">
            {/* Favorites */}
            {!sidebarCollapsed && favorites.length > 0 && (
              <NavSection label="Favorites">
                {favorites.slice(0, 6).map((href) => {
                  const item = navGroups.flatMap((g) => g.items).find((i) => i.href === href);
                  if (!item) return null;
                  const Icon = getIcon(item.icon);
                  const active = isActive(pathname, href);
                  return (
                    <NavLink key={href} href={href} active={active} icon={<Icon className="w-4 h-4" />} collapsed={false}>
                      {item.label}
                    </NavLink>
                  );
                })}
              </NavSection>
            )}

            {/* Recently visited */}
            {!sidebarCollapsed && recentPages.length > 0 && (
              <NavSection label="Recent">
                {recentPages.slice(0, 5).map((p) => {
                  const active = isActive(pathname, p.href);
                  return (
                    <NavLink key={p.href} href={p.href} active={active} icon={<Clock className="w-4 h-4" />} collapsed={false}>
                      {p.title}
                    </NavLink>
                  );
                })}
              </NavSection>
            )}

            {/* Main groups */}
            {navGroups.map((group) => {
              const visibleItems = group.items.filter((item) => {
                // Filter out detail routes that don't make sense as nav (e.g., [id])
                return !item.href.includes("[");
              });
              if (visibleItems.length === 0) return null;
              return (
                <NavSection key={group.label} label={group.label} collapsed={sidebarCollapsed}>
                  {visibleItems.map((item) => {
                    const Icon = getIcon(item.icon);
                    const active = isActive(pathname, item.href);
                    return (
                      <NavLink
                        key={item.href}
                        href={item.href}
                        active={active}
                        icon={<Icon className="w-4 h-4" />}
                        badge={item.badge}
                        badgeVariant={item.badgeVariant}
                        collapsed={sidebarCollapsed}
                        isFavorite={favorites.includes(item.href)}
                        onToggleFavorite={() => toggleFavorite(item.href)}
                        onClick={() => setMobileSidebarOpen(false)}
                      >
                        {item.label}
                      </NavLink>
                    );
                  })}
                </NavSection>
              );
            })}
          </nav>
        </ScrollArea>

        {/* User / collapse footer */}
        <div className="border-t border-sidebar-border p-2 shrink-0 space-y-1">
          <Link
            href="/admin/profile"
            onClick={() => setMobileSidebarOpen(false)}
            className={cn(
              "flex items-center gap-2.5 px-2 py-1.5 rounded-md text-sm hover:bg-sidebar-accent transition-colors",
              sidebarCollapsed && "justify-center"
            )}
          >
            <img
              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop&crop=faces"
              alt="Maya Okonkwo"
              className="w-6 h-6 rounded-full object-cover"
            />
            {!sidebarCollapsed && (
              <div className="min-w-0">
                <div className="text-xs font-medium truncate">Maya Okonkwo</div>
                <div className="text-[10px] text-muted-foreground truncate">Director, Platform Eng</div>
              </div>
            )}
          </Link>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleSidebar}
            className="w-full justify-start text-muted-foreground hover:text-foreground hidden md:flex"
          >
            {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            {!sidebarCollapsed && <span className="text-xs">Collapse</span>}
          </Button>
        </div>
      </aside>
    </>
  );
}

function NavSection({ label, children, collapsed }: { label: string; children: React.ReactNode; collapsed?: boolean }) {
  return (
    <div>
      {!collapsed && (
        <div className="px-2 mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
          {label}
        </div>
      )}
      {collapsed && <div className="h-px bg-sidebar-border mx-2 my-2" />}
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}

interface NavLinkProps {
  href: string;
  active: boolean;
  icon: React.ReactNode;
  children: React.ReactNode;
  badge?: number;
  badgeVariant?: "default" | "destructive" | "warning" | "success";
  collapsed?: boolean;
  isFavorite?: boolean;
  onToggleFavorite?: () => void;
  onClick?: () => void;
}

function NavLink({ href, active, icon, children, badge, badgeVariant = "default", collapsed, isFavorite, onToggleFavorite, onClick }: NavLinkProps) {
  const content = (
    <Link
      href={href}
      onClick={onClick}
      className={cn(
        "group flex items-center gap-2.5 px-2 py-1.5 rounded-md text-sm transition-colors relative",
        active
          ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
          : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
        collapsed && "justify-center px-0"
      )}
    >
      <span className={cn("shrink-0", active && "text-sidebar-primary")}>{icon}</span>
      {!collapsed && (
        <>
          <span className="flex-1 truncate text-[13px]">{children}</span>
          {isFavorite && (
            <button
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); onToggleFavorite?.(); }}
              className="opacity-0 group-hover:opacity-100 text-warning-foreground hover:scale-110 transition"
              aria-label="Remove favorite"
            >
              <Star className="w-3 h-3 fill-current" />
            </button>
          )}
          {badge !== undefined && badge > 0 && (
            <span
              className={cn(
                "inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-md text-[10px] font-semibold tabular-nums",
                badgeVariant === "destructive" && "bg-destructive text-destructive-foreground",
                badgeVariant === "warning" && "bg-warning text-warning-foreground",
                badgeVariant === "success" && "bg-success text-success-foreground",
                badgeVariant === "default" && "bg-sidebar-primary text-sidebar-primary-foreground"
              )}
            >
              {badge}
            </span>
          )}
        </>
      )}
      {collapsed && badge !== undefined && badge > 0 && (
        <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-destructive" />
      )}
    </Link>
  );

  if (collapsed) {
    return (
      <TooltipProvider delayDuration={150}>
        <Tooltip>
          <TooltipTrigger asChild>{content}</TooltipTrigger>
          <TooltipContent side="right" className="text-xs">
            {children}
            {badge !== undefined && badge > 0 && <span className="ml-1.5 opacity-70">({badge})</span>}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }
  return content;
}

export function LogoMark({ size = 28 }: { size?: number }) {
  return (
    <div className="shrink-0 rounded-lg overflow-hidden" style={{ width: size, height: size }}>
      <svg viewBox="0 0 64 64" width={size} height={size} className="block">
        <defs>
          <linearGradient id="sg-mark" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-mark)" fillOpacity="0.18" stroke="url(#sg-mark)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-mark)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-mark)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}
