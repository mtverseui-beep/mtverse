"use client";

import * as React from "react";
import { useUIStore } from "@/lib/store";
import { useTheme } from "@/components/theme-provider";

// Hydrates the theme from the UI store and syncs it with the DOM + ThemeProvider.
export function UIStoreHydration() {
  const theme = useUIStore((s) => s.theme);
  const setTheme = useTheme().setTheme;

  React.useEffect(() => {
    // On mount, sync store theme with DOM
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  // Bridge store -> ThemeProvider
  React.useEffect(() => {
    setTheme(theme);
  }, [theme, setTheme]);

  return null;
}
