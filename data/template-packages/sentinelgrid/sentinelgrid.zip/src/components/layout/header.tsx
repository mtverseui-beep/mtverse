"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { useUIStore } from "@/lib/store";
import { allNavItems } from "@/lib/nav";
import { people } from "@/lib/data";
import { useTheme } from "@/components/theme-provider";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import {
  Search, Bell, Sun, Moon, Menu, Plus, ChevronDown, RefreshCw, Download,
  Globe, Layers, Clock, Settings, User, LogOut, LifeBuoy, Command, ShieldAlert,
  CheckCircle2, AlertTriangle, Activity, FileText,
} from "lucide-react";
import { alerts, incidents } from "@/lib/data";
import { useRouter } from "next/navigation";

export function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const { setMobileSidebarOpen, setCommandPaletteOpen, activeEnvironment, setActiveEnvironment, activeRegion, setActiveRegion, timeRange, setTimeRange, toggleTheme } = useUIStore();
  const { theme } = useTheme();

  // Find current page info
  const currentItem = React.useMemo(() => {
    let best: typeof allNavItems[number] | undefined;
    let bestLen = 0;
    for (const item of allNavItems) {
      if (pathname === item.href || pathname.startsWith(item.href + "/")) {
        if (item.href.length > bestLen) {
          best = item;
          bestLen = item.href.length;
        }
      }
    }
    return best;
  }, [pathname]);

  // Build breadcrumbs from URL
  const breadcrumbs = React.useMemo(() => {
    const parts = pathname.split("/").filter(Boolean);
    const crumbs: { label: string; href?: string }[] = [];
    let href = "";
    for (let i = 0; i < parts.length; i++) {
      href += "/" + parts[i];
      // Find label
      const item = allNavItems.find((n) => n.href === href);
      const label = item?.label || parts[i].replace(/-/g, " ").replace(/^\w/, (c) => c.toUpperCase());
      crumbs.push({ label, href: i < parts.length - 1 ? href : undefined });
    }
    return crumbs;
  }, [pathname]);

  const firingAlerts = alerts.filter((a) => a.status === "firing");
  const activeIncidents = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");

  return (
    <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="flex items-center gap-2 px-3 md:px-6 h-14">
        {/* Mobile menu */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden h-9 w-9"
          onClick={() => setMobileSidebarOpen(true)}
          aria-label="Open sidebar"
        >
          <Menu className="w-4 h-4" />
        </Button>

        {/* Breadcrumbs */}
        <div className="hidden md:flex items-center gap-1.5 text-sm min-w-0 flex-1">
          {breadcrumbs.length === 0 ? (
            <span className="text-muted-foreground">SentinelGrid</span>
          ) : (
            breadcrumbs.map((b, i) => (
              <React.Fragment key={i}>
                {i > 0 && <span className="text-muted-foreground/40 text-xs">/</span>}
                {b.href ? (
                  <Link href={b.href} className="text-muted-foreground hover:text-foreground transition-colors truncate">
                    {b.label}
                  </Link>
                ) : (
                  <span className="font-medium text-foreground truncate">{b.label}</span>
                )}
              </React.Fragment>
            ))
          )}
        </div>

        {/* Mobile title */}
        <div className="md:hidden flex-1 min-w-0">
          <span className="text-sm font-medium truncate block">{currentItem?.label || "SentinelGrid"}</span>
        </div>

        {/* Right cluster */}
        <div className="flex items-center gap-1.5 md:gap-2 shrink-0">
          {/* Search */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCommandPaletteOpen(true)}
            className="h-9 px-2 md:px-3 text-xs gap-2 max-w-[200px] md:max-w-none"
          >
            <Search className="w-3.5 h-3.5" />
            <span className="hidden md:inline text-muted-foreground">Search...</span>
            <kbd className="hidden md:inline-flex items-center gap-0.5 text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded border border-border font-mono">
              <Command className="w-2.5 h-2.5" />K
            </kbd>
          </Button>

          {/* Environment switcher */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-9 px-2 md:px-3 text-xs gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">{activeEnvironment}</span>
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel className="text-xs">Environment</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {["production", "staging", "development", "preview"].map((env) => (
                <DropdownMenuItem key={env} onClick={() => setActiveEnvironment(env)} className="text-xs capitalize">
                  {env === activeEnvironment && <CheckCircle2 className="w-3 h-3 mr-1.5 text-success" />}
                  {env}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Region switcher */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-9 px-2 md:px-3 text-xs gap-1.5">
                <Globe className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">{activeRegion}</span>
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel className="text-xs">Region</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {["us-east-1", "us-west-2", "eu-west-1", "eu-central-1", "ap-south-1", "ap-southeast-2", "global"].map((r) => (
                <DropdownMenuItem key={r} onClick={() => setActiveRegion(r)} className="text-xs">
                  {r === activeRegion && <CheckCircle2 className="w-3 h-3 mr-1.5 text-success" />}
                  {r}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Time range */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-9 px-2 md:px-3 text-xs gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">{timeRange}</span>
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel className="text-xs">Time Range</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {["1h", "6h", "24h", "7d", "14d", "28d", "90d"].map((r) => (
                <DropdownMenuItem key={r} onClick={() => setTimeRange(r)} className="text-xs">
                  {r === timeRange && <CheckCircle2 className="w-3 h-3 mr-1.5 text-success" />}
                  {r}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Quick create */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" className="h-9 px-3 gap-1.5">
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Create</span>
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel className="text-xs">Quick Create</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => router.push("/incidents/new")} className="text-xs gap-2">
                <AlertTriangle className="w-3.5 h-3.5 text-destructive" /> New Incident
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/deployments")} className="text-xs gap-2">
                <Activity className="w-3.5 h-3.5 text-primary" /> New Deployment
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/postmortems/new")} className="text-xs gap-2">
                <FileText className="w-3.5 h-3.5 text-accent" /> New Postmortem
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/alerts/rules")} className="text-xs gap-2">
                <Bell className="w-3.5 h-3.5 text-warning-foreground" /> New Alert Rule
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/admin/api-keys")} className="text-xs gap-2">
                <Settings className="w-3.5 h-3.5" /> New API Key
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Theme toggle */}
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={toggleTheme} aria-label="Toggle theme">
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9 relative" aria-label="Notifications">
                <Bell className="w-4 h-4" />
                {firingAlerts.length > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-destructive animate-status-pulse" />
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <div className="flex items-center justify-between px-2 py-1.5">
                <DropdownMenuLabel className="text-xs p-0">Notifications</DropdownMenuLabel>
                <Button variant="ghost" size="sm" className="h-6 text-[10px]">Mark all read</Button>
              </div>
              <DropdownMenuSeparator />
              <div className="max-h-80 overflow-y-auto">
                {firingAlerts.length === 0 && activeIncidents.length === 0 ? (
                  <div className="p-4 text-center text-xs text-muted-foreground">No active notifications</div>
                ) : (
                  <>
                    {activeIncidents.map((inc) => (
                      <DropdownMenuItem key={inc.id} className="flex items-start gap-2 p-2 cursor-pointer" onClick={() => router.push(`/incidents/${inc.id}`)}>
                        <ShieldAlert className="w-3.5 h-3.5 mt-0.5 text-destructive shrink-0" />
                        <div className="min-w-0 space-y-0.5">
                          <div className="text-xs font-medium truncate">{inc.ref} - {inc.title}</div>
                          <div className="text-[10px] text-muted-foreground">Severity: {inc.severity}</div>
                        </div>
                      </DropdownMenuItem>
                    ))}
                    {firingAlerts.map((a) => (
                      <DropdownMenuItem key={a.id} className="flex items-start gap-2 p-2 cursor-pointer" onClick={() => router.push(`/alerts/${a.id}`)}>
                        <Bell className="w-3.5 h-3.5 mt-0.5 text-warning-foreground shrink-0" />
                        <div className="min-w-0 space-y-0.5">
                          <div className="text-xs font-medium truncate">{a.ref}</div>
                          <div className="text-[10px] text-muted-foreground truncate">{a.message}</div>
                        </div>
                      </DropdownMenuItem>
                    ))}
                  </>
                )}
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs justify-center text-muted-foreground" onClick={() => router.push("/alerts")}>
                View all alerts
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="h-9 w-9 rounded-full overflow-hidden border border-border hover:ring-2 hover:ring-ring transition-all" aria-label="User menu">
                <img
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&h=80&fit=crop&crop=faces"
                  alt="Maya Okonkwo"
                  className="w-full h-full object-cover"
                />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="px-2 py-1.5">
                <div className="text-sm font-medium">Maya Okonkwo</div>
                <div className="text-xs text-muted-foreground">maya@sentinelgrid.io</div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => router.push("/admin/profile")} className="text-xs gap-2">
                <User className="w-3.5 h-3.5" /> My Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/admin/settings")} className="text-xs gap-2">
                <Settings className="w-3.5 h-3.5" /> Workspace Settings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/oncall/preferences")} className="text-xs gap-2">
                <Bell className="w-3.5 h-3.5" /> On-Call Preferences
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/docs/support")} className="text-xs gap-2">
                <LifeBuoy className="w-3.5 h-3.5" /> Support
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => router.push("/sign-in")} className="text-xs gap-2 text-destructive">
                <LogOut className="w-3.5 h-3.5" /> Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}


