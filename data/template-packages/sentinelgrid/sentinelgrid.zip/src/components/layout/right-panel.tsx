"use client";

import * as React from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { useUIStore } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from "@/components/ui/sheet";
import {
  Activity, AlertTriangle, Phone, Clock, Server, User, Bell,
  ChevronRight, FileText, Zap, TrendingUp, Shield, X, Book, Globe,
} from "lucide-react";
import { incidents, alerts, services, onCallShifts, people, deployments } from "@/lib/data";
import { SeverityBadge, AlertStatusBadge, ServiceHealthBadge } from "@/components/common/badges";

// Determine which right panel to show based on the route
export function RightPanel() {
  const pathname = usePathname();
  const { rightPanelOpen, setRightPanelOpen } = useUIStore();

  const content = React.useMemo(() => <RightPanelContent pathname={pathname} />, [pathname]);

  return (
    <>
      {/* Desktop right panel */}
      <aside
        className={cn(
          "hidden lg:flex flex-col w-[320px] shrink-0 border-l border-border bg-card/50 transition-[width] duration-200 h-screen sticky top-0",
          !rightPanelOpen && "w-0 overflow-hidden border-l-0"
        )}
      >
        {rightPanelOpen && (
          <>
            <div className="h-14 border-b border-border flex items-center justify-between px-4 shrink-0">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Context Panel</span>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setRightPanelOpen(false)} aria-label="Hide panel">
                <X className="w-3.5 h-3.5" />
              </Button>
            </div>
            <ScrollArea className="flex-1">{content}</ScrollArea>
          </>
        )}
      </aside>

      {/* Mobile: hidden by default, opens as a drawer */}
      <Sheet open={false} onOpenChange={() => {}}>
        <SheetContent side="right" className="w-full sm:w-[400px]">
          <SheetHeader>
            <SheetTitle>Context Panel</SheetTitle>
          </SheetHeader>
          {content}
        </SheetContent>
      </Sheet>
    </>
  );
}

function RightPanelContent({ pathname }: { pathname: string }) {
  // Pick context based on route prefix
  if (pathname.startsWith("/incidents/")) return <IncidentContextPanel />;
  if (pathname.startsWith("/incidents")) return <IncidentsListPanel />;
  if (pathname.startsWith("/services/")) return <ServiceContextPanel />;
  if (pathname.startsWith("/services")) return <ServicesListPanel />;
  if (pathname.startsWith("/deployments/")) return <DeploymentContextPanel />;
  if (pathname.startsWith("/deployments")) return <DeploymentsListPanel />;
  if (pathname.startsWith("/errors")) return <ErrorsContextPanel />;
  if (pathname.startsWith("/oncall")) return <OnCallContextPanel />;
  if (pathname.startsWith("/alerts")) return <AlertsContextPanel />;
  if (pathname.startsWith("/admin")) return <AdminContextPanel />;
  if (pathname.startsWith("/logs") || pathname.startsWith("/traces") || pathname.startsWith("/metrics")) return <ObservabilityContextPanel />;
  if (pathname.startsWith("/security")) return <SecurityContextPanel />;
  // Default: dashboard context
  return <DashboardContextPanel />;
}

// ============================================================================
// Dashboard Context
// ============================================================================

function DashboardContextPanel() {
  const activeIncidents = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");
  const firingAlerts = alerts.filter((a) => a.status === "firing");
  const currentOnCall = onCallShifts.find((s) => {
    const now = Date.now();
    return new Date(s.start).getTime() < now && new Date(s.end).getTime() > now;
  }) || onCallShifts[0];
  const onCallUser = currentOnCall ? people.find((p) => p.id === currentOnCall.userId) : null;

  return (
    <div className="p-4 space-y-4">
      <PanelSection title="System Health" icon={<Activity className="w-3.5 h-3.5" />}>
        <div className="grid grid-cols-2 gap-2">
          <StatBox label="Services Up" value={`${services.filter((s) => s.health === "operational").length}/${services.length}`} color="success" />
          <StatBox label="Active Incidents" value={activeIncidents.length} color={activeIncidents.length > 0 ? "destructive" : "success"} />
          <StatBox label="Firing Alerts" value={firingAlerts.length} color={firingAlerts.length > 0 ? "warning" : "success"} />
          <StatBox label="MTTR (30d)" value="18.4 min" color="muted" />
        </div>
      </PanelSection>

      <PanelSection title="Current On-Call" icon={<Phone className="w-3.5 h-3.5" />}>
        {onCallUser && currentOnCall && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <img src={onCallUser.avatarUrl} alt={onCallUser.name} className="w-8 h-8 rounded-full object-cover" />
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{onCallUser.name}</div>
                <div className="text-[10px] text-muted-foreground">{currentOnCall.role} on-call</div>
              </div>
            </div>
            <div className="text-[11px] text-muted-foreground">Shift ends: {new Date(currentOnCall.end).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
            <Button asChild variant="outline" size="sm" className="w-full h-8 text-xs">
              <Link href="/oncall">View Schedule</Link>
            </Button>
          </div>
        )}
      </PanelSection>

      <PanelSection title="Recent Activity" icon={<Clock className="w-3.5 h-3.5" />}>
        <div className="space-y-2">
          {incidents.slice(0, 3).map((inc) => (
            <Link key={inc.id} href={`/incidents/${inc.id}`} className="flex items-start gap-2 p-2 rounded-md hover:bg-muted/50 transition-colors">
              <AlertTriangle className="w-3.5 h-3.5 mt-0.5 text-destructive shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-medium truncate">{inc.ref} - {inc.title}</div>
                <div className="text-[10px] text-muted-foreground">{new Date(inc.startedAt).toLocaleString()}</div>
              </div>
            </Link>
          ))}
        </div>
      </PanelSection>
    </div>
  );
}

// ============================================================================
// Incident Details Context
// ============================================================================

function IncidentContextPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Response Playbook" icon={<Book className="w-3.5 h-3.5" />}>
        <ol className="space-y-1.5 text-xs">
          {["Acknowledge within 5 min", "Assign commander", "Identify impact scope", "Post public update", "Identify root cause", "Apply mitigation", "Verify recovery", "Resolve incident", "Schedule postmortem"].map((step, i) => (
            <li key={i} className="flex items-start gap-2">
              <span className="w-4 h-4 rounded-full border border-border flex items-center justify-center text-[9px] font-medium shrink-0 mt-0.5">{i + 1}</span>
              <span>{step}</span>
            </li>
          ))}
        </ol>
      </PanelSection>

      <PanelSection title="Quick Actions" icon={<Zap className="w-3.5 h-3.5" />}>
        <div className="space-y-1.5">
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">Acknowledge</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">Escalate</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">Add Responder</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">Link Runbook</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">Update Status Page</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">Start Postmortem</Button>
        </div>
      </PanelSection>

      <PanelSection title="Resources" icon={<FileText className="w-3.5 h-3.5" />}>
        <div className="space-y-1 text-xs">
          <Link href="/services/runbooks" className="block hover:text-primary">Browse Runbooks</Link>
          <Link href="/alerts" className="block hover:text-primary">View Linked Alerts</Link>
          <Link href="/deployments" className="block hover:text-primary">Recent Deployments</Link>
          <Link href="/postmortems" className="block hover:text-primary">Past Postmortems</Link>
        </div>
      </PanelSection>
    </div>
  );
}

// ============================================================================
// Incidents List Context
// ============================================================================

function IncidentsListPanel() {
  const bySeverity = {
    critical: incidents.filter((i) => i.severity === "critical").length,
    high: incidents.filter((i) => i.severity === "high").length,
    medium: incidents.filter((i) => i.severity === "medium").length,
    low: incidents.filter((i) => i.severity === "low").length,
  };
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="By Severity" icon={<AlertTriangle className="w-3.5 h-3.5" />}>
        <div className="space-y-2">
          <SevRow label="Critical" count={bySeverity.critical} color="bg-destructive" />
          <SevRow label="High" count={bySeverity.high} color="bg-warning" />
          <SevRow label="Medium" count={bySeverity.medium} color="bg-info" />
          <SevRow label="Low" count={bySeverity.low} color="bg-muted-foreground" />
        </div>
      </PanelSection>

      <PanelSection title="SLA Performance" icon={<Clock className="w-3.5 h-3.5" />}>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between"><span className="text-muted-foreground">Avg Acknowledgement</span><span className="font-medium">3.8 min</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Avg Resolution</span><span className="font-medium">18.4 min</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">SLA Breaches (30d)</span><span className="font-medium text-destructive">2</span></div>
        </div>
      </PanelSection>
    </div>
  );
}

// ============================================================================
// Service Details Context
// ============================================================================

function ServiceContextPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Service Quick Info" icon={<Server className="w-3.5 h-3.5" />}>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between"><span className="text-muted-foreground">Tier</span><span className="font-medium">Tier 1</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Health Score</span><span className="font-medium text-success">98/100</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Uptime (30d)</span><span className="font-medium">99.992%</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Last Deploy</span><span className="font-medium">2 days ago</span></div>
        </div>
      </PanelSection>

      <PanelSection title="Ownership" icon={<User className="w-3.5 h-3.5" />}>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <img src={people[1].avatarUrl} alt="" className="w-7 h-7 rounded-full object-cover" />
            <div className="min-w-0">
              <div className="text-xs font-medium truncate">{people[1].name}</div>
              <div className="text-[10px] text-muted-foreground">Service Owner</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Server className="w-3 h-3 text-primary" />
            </div>
            <div className="min-w-0">
              <div className="text-xs font-medium truncate">Platform Engineering</div>
              <div className="text-[10px] text-muted-foreground">Owning Team</div>
            </div>
          </div>
        </div>
      </PanelSection>

      <PanelSection title="Actions" icon={<Zap className="w-3.5 h-3.5" />}>
        <div className="space-y-1.5">
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">View Logs</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">View Traces</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">View Metrics</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">Open Runbook</Button>
          <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start">Create Alert</Button>
        </div>
      </PanelSection>
    </div>
  );
}

function ServicesListPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Health Distribution" icon={<Activity className="w-3.5 h-3.5" />}>
        <div className="space-y-2">
          <SevRow label="Operational" count={services.filter((s) => s.health === "operational").length} color="bg-success" />
          <SevRow label="Degraded" count={services.filter((s) => s.health === "degraded").length} color="bg-warning" />
          <SevRow label="Partial Outage" count={services.filter((s) => s.health === "partial").length} color="bg-destructive" />
        </div>
      </PanelSection>

      <PanelSection title="Tier Distribution" icon={<Server className="w-3.5 h-3.5" />}>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between"><span className="text-muted-foreground">Tier 1 (Critical)</span><span className="font-medium">{services.filter((s) => s.tier === "tier1").length}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Tier 2 (Important)</span><span className="font-medium">{services.filter((s) => s.tier === "tier2").length}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Tier 3 (Standard)</span><span className="font-medium">{services.filter((s) => s.tier === "tier3").length}</span></div>
        </div>
      </PanelSection>
    </div>
  );
}

// ============================================================================
// Deployment Context
// ============================================================================

function DeploymentContextPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Rollout Stages" icon={<TrendingUp className="w-3.5 h-3.5" />}>
        <ol className="space-y-2">
          {["Build", "Test", "Canary 25%", "Canary 50%", "Production 100%"].map((s, i) => (
            <li key={i} className="flex items-center gap-2 text-xs">
              <span className={cn("w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-medium", i < 3 ? "bg-success/15 text-success border border-success/30" : i === 3 ? "bg-info/15 text-info-foreground border border-info/30" : "bg-muted text-muted-foreground border")}>
                {i < 3 ? "✓" : i + 1}
              </span>
              <span className={i < 3 ? "font-medium" : "text-muted-foreground"}>{s}</span>
            </li>
          ))}
        </ol>
      </PanelSection>

      <PanelSection title="Risk Assessment" icon={<Shield className="w-3.5 h-3.5" />}>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between"><span className="text-muted-foreground">Risk Score</span><span className="font-medium text-warning-foreground">68/100</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Changes</span><span className="font-medium">14 commits</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">PRs Merged</span><span className="font-medium">3</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Error Rate Δ</span><span className="font-medium text-destructive">+1.36%</span></div>
        </div>
      </PanelSection>

      <PanelSection title="Approvers" icon={<User className="w-3.5 h-3.5" />}>
        <div className="space-y-2">
          {["u13", "u3"].map((id) => {
            const p = people.find((x) => x.id === id);
            if (!p) return null;
            return (
              <div key={id} className="flex items-center gap-2">
                <img src={p.avatarUrl} alt="" className="w-6 h-6 rounded-full object-cover" />
                <span className="text-xs">{p.name}</span>
              </div>
            );
          })}
        </div>
      </PanelSection>
    </div>
  );
}

function DeploymentsListPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="DORA Metrics" icon={<TrendingUp className="w-3.5 h-3.5" />}>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between"><span className="text-muted-foreground">Deploy Frequency</span><span className="font-medium">14.2/day</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Lead Time</span><span className="font-medium">26 hours</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Change Failure</span><span className="font-medium text-warning-foreground">8.4%</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">MTTR</span><span className="font-medium">18.4 min</span></div>
        </div>
      </PanelSection>

      <PanelSection title="Recent Activity" icon={<Clock className="w-3.5 h-3.5" />}>
        <div className="space-y-2">
          {deployments.slice(0, 4).map((d) => (
            <Link key={d.id} href={`/deployments/${d.id}`} className="flex items-center gap-2 text-xs hover:text-primary">
              <span className="w-1.5 h-1.5 rounded-full bg-info shrink-0" />
              <span className="truncate flex-1">{d.ref}</span>
              <span className="text-muted-foreground">{d.version}</span>
            </Link>
          ))}
        </div>
      </PanelSection>
    </div>
  );
}

// ============================================================================
// Errors / OnCall / Alerts / Admin / Observability / Security Contexts
// ============================================================================

function ErrorsContextPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Error Summary" icon={<AlertTriangle className="w-3.5 h-3.5" />}>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between"><span className="text-muted-foreground">Open Errors</span><span className="font-medium">5</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Regressions</span><span className="font-medium text-destructive">2</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Affected Users</span><span className="font-medium">1,168</span></div>
        </div>
      </PanelSection>
      <PanelSection title="Top Services" icon={<Server className="w-3.5 h-3.5" />}>
        <div className="space-y-2">
          {services.slice(0, 4).map((s) => (
            <div key={s.id} className="flex items-center justify-between text-xs">
              <span className="truncate">{s.name}</span>
              <span className="font-medium">{s.openAlerts}</span>
            </div>
          ))}
        </div>
      </PanelSection>
    </div>
  );
}

function OnCallContextPanel() {
  const current = onCallShifts[0];
  const user = people.find((p) => p.id === current.userId);
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Currently On-Call" icon={<Phone className="w-3.5 h-3.5" />}>
        {user && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <img src={user.avatarUrl} alt="" className="w-9 h-9 rounded-full object-cover" />
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{user.name}</div>
                <div className="text-[10px] text-muted-foreground">{current.role}</div>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full h-8 text-xs">Override Shift</Button>
          </div>
        )}
      </PanelSection>
      <PanelSection title="Escalation Path" icon={<TrendingUp className="w-3.5 h-3.5" />}>
        <ol className="space-y-2 text-xs">
          <li>0 min: Primary on-call</li>
          <li>15 min: Secondary on-call</li>
          <li>30 min: Engineering Manager</li>
        </ol>
      </PanelSection>
    </div>
  );
}

function AlertsContextPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Alert Summary" icon={<Bell className="w-3.5 h-3.5" />}>
        <div className="grid grid-cols-2 gap-2">
          <StatBox label="Firing" value={alerts.filter((a) => a.status === "firing").length} color="destructive" />
          <StatBox label="Acked" value={alerts.filter((a) => a.status === "acknowledged").length} color="warning" />
          <StatBox label="Resolved" value={alerts.filter((a) => a.status === "resolved").length} color="success" />
          <StatBox label="Suppressed" value={alerts.filter((a) => a.status === "suppressed").length} color="muted" />
        </div>
      </PanelSection>
      <PanelSection title="Noise Score" icon={<Activity className="w-3.5 h-3.5" />}>
        <div className="text-xs space-y-2">
          <div className="flex justify-between"><span className="text-muted-foreground">7-day triggers</span><span className="font-medium">28</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Auto-resolved</span><span className="font-medium">19</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">False positive rate</span><span className="font-medium text-warning-foreground">32%</span></div>
        </div>
      </PanelSection>
    </div>
  );
}

function AdminContextPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Help & Resources" icon={<Book className="w-3.5 h-3.5" />}>
        <div className="space-y-1 text-xs">
          <Link href="/docs" className="block hover:text-primary">Documentation</Link>
          <Link href="/docs/getting-started" className="block hover:text-primary">Getting Started Guide</Link>
          <Link href="/docs/support" className="block hover:text-primary">Contact Support</Link>
          <Link href="/docs/changelog" className="block hover:text-primary">Changelog</Link>
        </div>
      </PanelSection>
      <PanelSection title="Recent Changes" icon={<Clock className="w-3.5 h-3.5" />}>
        <div className="space-y-2 text-xs">
          <div className="text-muted-foreground">API key "CI/CD Pipeline" last used 2 hours ago</div>
          <div className="text-muted-foreground">Webhook "Slack #incidents" delivered successfully</div>
          <div className="text-muted-foreground">Audit log: 12 events today</div>
        </div>
      </PanelSection>
    </div>
  );
}

function ObservabilityContextPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Saved Queries" icon={<FileText className="w-3.5 h-3.5" />}>
        <div className="space-y-1 text-xs">
          <div className="hover:text-primary cursor-pointer">5xx errors by service</div>
          <div className="hover:text-primary cursor-pointer">P99 latency by region</div>
          <div className="hover:text-primary cursor-pointer">Cache hit ratio trend</div>
          <div className="hover:text-primary cursor-pointer">Kafka consumer lag</div>
        </div>
      </PanelSection>
      <PanelSection title="Recent Searches" icon={<Clock className="w-3.5 h-3.5" />}>
        <div className="space-y-1 text-xs text-muted-foreground">
          <div>service:checkout-api level:error</div>
          <div>trace_id:a3f2c1b8e7d2</div>
          <div>status:5xx</div>
        </div>
      </PanelSection>
    </div>
  );
}

function SecurityContextPanel() {
  return (
    <div className="p-4 space-y-4">
      <PanelSection title="Security Posture" icon={<Shield className="w-3.5 h-3.5" />}>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between"><span className="text-muted-foreground">Open Vulns</span><span className="font-medium text-warning-foreground">4</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Critical</span><span className="font-medium text-destructive">1</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Compliance</span><span className="font-medium text-success">96%</span></div>
        </div>
      </PanelSection>
      <PanelSection title="Quick Links" icon={<Globe className="w-3.5 h-3.5" />}>
        <div className="space-y-1 text-xs">
          <Link href="/security/compliance" className="block hover:text-primary">Compliance Reports</Link>
          <Link href="/security/access-reviews" className="block hover:text-primary">Access Reviews</Link>
          <Link href="/admin/audit-logs" className="block hover:text-primary">Audit Trails</Link>
        </div>
      </PanelSection>
    </div>
  );
}

// ============================================================================
// Shared sub-components
// ============================================================================

function PanelSection({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-2.5">
        <span className="text-muted-foreground">{icon}</span>
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function StatBox({ label, value, color = "muted" }: { label: string; value: string | number; color?: "success" | "warning" | "destructive" | "info" | "muted" }) {
  const colors = {
    success: "border-success/30 text-success",
    warning: "border-warning/30 text-warning-foreground",
    destructive: "border-destructive/30 text-destructive",
    info: "border-info/30 text-info-foreground",
    muted: "border-border text-foreground",
  };
  return (
    <div className={cn("rounded-lg border p-2.5 bg-card", colors[color])}>
      <div className="text-[10px] uppercase tracking-wider opacity-80">{label}</div>
      <div className="text-lg font-semibold tabular-nums mt-0.5">{value}</div>
    </div>
  );
}

function SevRow({ label, count, color }: { label: string; count: number; color: string }) {
  return (
    <div className="flex items-center gap-2 text-xs">
      <span className={cn("w-2 h-2 rounded-full", color)} />
      <span className="flex-1 text-muted-foreground">{label}</span>
      <span className="font-medium tabular-nums">{count}</span>
    </div>
  );
}
