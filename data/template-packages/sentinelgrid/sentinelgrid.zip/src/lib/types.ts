// ============================================================================
// SentinelGrid Engineering Operations - Type System
// ============================================================================

export type ID = string;

export type Severity = "critical" | "high" | "medium" | "low" | "info";
export type IncidentStatus =
  | "investigating"
  | "identified"
  | "monitoring"
  | "resolved"
  | "postmortem"
  | "mitigated";
export type ServiceTier = "tier1" | "tier2" | "tier3" | "tier4";
export type ServiceHealth = "operational" | "degraded" | "partial" | "major" | "maintenance";
export type DeploymentStatus =
  | "queued"
  | "in_progress"
  | "rolling_out"
  | "canary"
  | "succeeded"
  | "failed"
  | "rolled_back"
  | "halted"
  | "approved"
  | "pending_approval";
export type AlertStatus = "firing" | "acknowledged" | "resolved" | "suppressed";
export type SLOStatus = "healthy" | "at_risk" | "breached" | "exhausted";
export type OnCallRole = "primary" | "secondary" | "manager" | "shadow";
export type EnvironmentName = "production" | "staging" | "development" | "preview";
export type Region =
  | "us-east-1"
  | "us-west-2"
  | "eu-west-1"
  | "eu-central-1"
  | "ap-south-1"
  | "ap-southeast-2"
  | "global";

// ============================================================================
// People & Teams
// ============================================================================

export interface Person {
  id: ID;
  name: string;
  handle: string;
  email: string;
  avatarUrl: string;
  role: string;
  team: string;
  timezone: string;
  title: string;
}

export interface Team {
  id: ID;
  name: string;
  slug: string;
  description: string;
  leadId: ID;
  memberIds: ID[];
  color: string;
  servicesOwned: ID[];
  escalationPolicyId?: ID;
}

// ============================================================================
// Services
// ============================================================================

export interface Service {
  id: ID;
  name: string;
  slug: string;
  description: string;
  tier: ServiceTier;
  teamId: ID;
  ownerId: ID;
  language: string;
  framework: string;
  repository: string;
  health: ServiceHealth;
  healthScore: number; // 0-100
  sloId?: ID;
  dependencies: ID[];
  dependents: ID[];
  openIncidents: number;
  openAlerts: number;
  lastDeployId?: ID;
  lastDeployAt: string;
  environment: EnvironmentName;
  regions: Region[];
  endpoints: number;
  requestsPerSecond: number;
  p95LatencyMs: number;
  errorRate: number;
  uptime30d: number; // percent
  runbooks: ID[];
  tier1?: boolean;
}

export interface Runbook {
  id: ID;
  title: string;
  slug: string;
  serviceId: ID;
  category: string;
  steps: { title: string; body: string }[];
  lastUpdated: string;
  authorId: ID;
  views: number;
}

// ============================================================================
// Incidents
// ============================================================================

export interface IncidentTimelineEvent {
  id: ID;
  incidentId: ID;
  timestamp: string;
  kind: "created" | "acknowledged" | "status_change" | "severity_change"
    | "note" | "public_update" | "responder_added" | "responder_removed"
    | "commander_change" | "service_added" | "deployment_linked"
    | "runbook_linked" | "alert_linked" | "resolved" | "escalated"
    | "subscriber_added" | "postmortem_started";
  authorId: ID;
  message: string;
  metadata?: Record<string, string>;
}

export interface IncidentUpdate {
  id: ID;
  incidentId: ID;
  timestamp: string;
  authorId: ID;
  audience: "internal" | "stakeholder" | "public";
  body: string;
}

export interface Incident {
  id: ID;
  ref: string; // INC-1234
  title: string;
  summary: string;
  severity: Severity;
  status: IncidentStatus;
  commanderId: ID;
  responderIds: ID[];
  serviceIds: ID[];
  startedAt: string;
  detectedAt: string;
  resolvedAt?: string;
  acknowledgedAt?: string;
  lastUpdateAt: string;
  impactedUsers: number;
  impactedRegions: Region[];
  customerImpact: string;
  rootCause?: string;
  resolution?: string;
  alertIds: ID[];
  deploymentId?: ID;
  postmortemId?: ID;
  subscriberIds: ID[];
  tags: string[];
  timeline: IncidentTimelineEvent[];
  updates: IncidentUpdate[];
  checklist: { id: ID; label: string; done: boolean }[];
  warRoomChannel?: string;
  statusPagePosted: boolean;
  responseSlaSeconds?: number;
  resolutionSlaSeconds?: number;
}

// ============================================================================
// Postmortems
// ============================================================================

export interface Postmortem {
  id: ID;
  ref: string; // PM-2024-001
  incidentId: ID;
  title: string;
  status: "draft" | "in_review" | "approved" | "published" | "archived";
  authorId: ID;
  reviewerIds: ID[];
  createdAt: string;
  publishedAt?: string;
  impactSummary: string;
  rootCause: string;
  contributingFactors: string[];
  timeline: { timestamp: string; event: string }[];
  lessons: string[];
  actionItems: PostmortemActionItem[];
  severity: Severity;
  durationHours: number;
  tags: string[];
}

export interface PostmortemActionItem {
  id: ID;
  postmortemId: ID;
  description: string;
  ownerId: ID;
  status: "todo" | "in_progress" | "done" | "cancelled";
  priority: Severity;
  dueDate: string;
  type: "detection" | "mitigation" | "prevention" | "process" | "tooling";
}

// ============================================================================
// SLO / Reliability
// ============================================================================

export interface SLO {
  id: ID;
  ref: string; // SLO-001
  name: string;
  description: string;
  serviceId: ID;
  sli: {
    metric: string;
    source: string;
    query: string;
    unit: string;
  };
  target: number; // percent, e.g. 99.9
  window: "28d" | "7d" | "90d";
  status: SLOStatus;
  current: number; // current SLI value
  errorBudget: {
    total: number; // total budget for window
    remaining: number;
    consumed: number;
    burnRate: number;
  };
  alerts: { burnRate: number; window: string; triggered: boolean }[];
  createdAt: string;
  updatedAt: string;
}

export interface UptimeRecord {
  id: ID;
  serviceId: ID;
  date: string;
  uptime: number; // percent
  incidents: number;
  downtimeSeconds: number;
}

// ============================================================================
// Deployments
// ============================================================================

export interface Deployment {
  id: ID;
  ref: string; // DEP-2024-001
  serviceId: ID;
  environment: EnvironmentName;
  region: Region;
  status: DeploymentStatus;
  strategy: "rolling" | "canary" | "blue_green" | "recreate";
  rolloutPercent: number;
  version: string;
  commitSha: string;
  commitMessage: string;
  authorId: ID;
  approverIds: ID[];
  startedAt: string;
  completedAt?: string;
  duration: number; // seconds
  riskScore: number; // 0-100
  changesCount: number;
  prIds: string[];
  previousVersion: string;
  rollbackOfId?: ID;
  notes?: string;
  stages: { name: string; status: DeploymentStatus; startedAt?: string; completedAt?: string }[];
  metrics: {
    errorRateBefore: number;
    errorRateAfter: number;
    p95LatencyBefore: number;
    p95LatencyAfter: number;
  };
  incidentsTriggered: ID[];
}

export interface ChangeRequest {
  id: ID;
  ref: string;
  title: string;
  serviceId: ID;
  type: "standard" | "normal" | "emergency";
  risk: "low" | "medium" | "high";
  status: "draft" | "in_review" | "approved" | "rejected" | "implemented";
  requesterId: ID;
  approverIds: ID[];
  plannedAt: string;
  summary: string;
}

export interface FeatureFlag {
  id: ID;
  key: string;
  name: string;
  description: string;
  serviceId: ID;
  enabled: boolean;
  rolloutPercent: number;
  environments: EnvironmentName[];
  owner: ID;
  createdAt: string;
  lastModified: string;
  variants: { name: string; weight: number }[];
}

// ============================================================================
// Errors
// ============================================================================

export interface ErrorGroup {
  id: ID;
  ref: string; // ERR-001
  message: string;
  type: string;
  stack: string;
  serviceId: ID;
  environment: EnvironmentName;
  status: "unresolved" | "resolved" | "ignored" | "in_progress";
  assigneeId?: ID;
  firstSeen: string;
  lastSeen: string;
  eventCount: number;
  userCount: number;
  releaseId?: string;
  isRegression: boolean;
  sourceMapStatus: "ok" | "missing" | "stale";
  tags: string[];
  trend: number[];
}

// ============================================================================
// Alerts
// ============================================================================

export interface AlertRule {
  id: ID;
  ref: string; // ALERT-001
  name: string;
  description: string;
  serviceId: ID;
  metric: string;
  condition: string;
  threshold: number;
  window: string;
  severity: Severity;
  enabled: boolean;
  routingId: ID;
  lastTriggeredAt?: string;
  triggerCount7d: number;
  noiseScore: number;
}

export interface AlertEvent {
  id: ID;
  ref: string; // ALR-001
  ruleId: ID;
  serviceId: ID;
  severity: Severity;
  status: AlertStatus;
  startedAt: string;
  acknowledgedAt?: string;
  acknowledgedBy?: ID;
  resolvedAt?: string;
  message: string;
  value: string;
  routedTo: ID;
  incidentId?: ID;
  dedupKey: string;
}

export interface EscalationPolicy {
  id: ID;
  name: string;
  description: string;
  rounds: {
    delayMinutes: number;
    targets: { type: "person" | "team" | "schedule"; id: ID }[];
  }[];
  repeatCount: number;
}

// ============================================================================
// On-Call
// ============================================================================

export interface OnCallShift {
  id: ID;
  userId: ID;
  teamId: ID;
  role: OnCallRole;
  start: string;
  end: string;
  isOverride?: boolean;
  notes?: string;
}

export interface OnCallSchedule {
  id: ID;
  name: string;
  teamId: ID;
  timezone: string;
  rotationType: "weekly" | "daily" | "biweekly";
  currentShiftId: ID;
  nextShiftId: ID;
  escalationPolicyId: ID;
}

// ============================================================================
// Infrastructure
// ============================================================================

export interface Host {
  id: ID;
  hostname: string;
  serviceId: ID;
  environment: EnvironmentName;
  region: Region;
  instanceType: string;
  os: string;
  status: "running" | "stopped" | "terminated" | "draining";
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  uptime: string;
  provider: "aws" | "gcp" | "azure" | "self";
}

export interface K8sCluster {
  id: ID;
  name: string;
  provider: string;
  region: Region;
  version: string;
  nodeCount: number;
  podCount: number;
  cpuUsage: number;
  memoryUsage: number;
  status: "healthy" | "warning" | "critical";
}

// ============================================================================
// Observability
// ============================================================================

export interface LogEntry {
  id: ID;
  timestamp: string;
  serviceId: ID;
  level: "trace" | "debug" | "info" | "warn" | "error" | "fatal";
  message: string;
  traceId?: string;
  spanId?: string;
  host?: string;
  fields: Record<string, string>;
}

export interface TraceSpan {
  id: ID;
  traceId: string;
  parentSpanId?: string;
  name: string;
  serviceId: ID;
  startMs: number;
  durationMs: number;
  status: "ok" | "error" | "unset";
  attributes: Record<string, string>;
}

// ============================================================================
// Security
// ============================================================================

export interface Vulnerability {
  id: ID;
  ref: string;
  cve: string;
  title: string;
  description: string;
  severity: Severity;
  cvss: number;
  assetId: ID;
  assetName: string;
  serviceId?: ID;
  status: "open" | "in_progress" | "patched" | "ignored" | "false_positive";
  discoveredAt: string;
  patchedAt?: string;
  owner: ID;
  remediation: string;
}

export interface AuditEvent {
  id: ID;
  timestamp: string;
  actorId: ID;
  action: string;
  resourceType: string;
  resourceId: string;
  metadata: Record<string, string>;
  ip: string;
  result: "success" | "failure";
}

// ============================================================================
// Admin
// ============================================================================

export interface APIKey {
  id: ID;
  name: string;
  prefix: string;
  scopes: string[];
  createdBy: ID;
  createdAt: string;
  lastUsed?: string;
  expiresAt?: string;
  revokedAt?: string;
}

export interface Webhook {
  id: ID;
  name: string;
  url: string;
  events: string[];
  enabled: boolean;
  secret: string;
  lastDelivery?: { timestamp: string; statusCode: number; durationMs: number };
  failureCount: number;
  createdBy: ID;
}

export interface Integration {
  id: ID;
  type: string;
  name: string;
  category: string;
  status: "connected" | "disconnected" | "error" | "needs_attention";
  description: string;
  lastSyncAt?: string;
  config: Record<string, string>;
  iconColor: string;
}

// ============================================================================
// Dashboarding
// ============================================================================

export interface MetricSeries {
  name: string;
  data: { timestamp: string; value: number }[];
}

export interface SavedView {
  id: ID;
  name: string;
  page: string;
  filters: Record<string, string>;
  createdAt: string;
  shared: boolean;
}

export interface NavItem {
  label: string;
  href: string;
  icon: string;
  badge?: number;
  badgeVariant?: "default" | "destructive" | "warning" | "success";
}

export interface NavGroup {
  label: string;
  items: NavItem[];
}
