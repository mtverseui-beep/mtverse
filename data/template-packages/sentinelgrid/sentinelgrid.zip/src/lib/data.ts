import type {
  Person, Team, Service, Incident, Postmortem, SLO, Deployment, AlertEvent,
  AlertRule, OnCallShift, EscalationPolicy, Host, K8sCluster, ErrorGroup,
  Vulnerability, AuditEvent, APIKey, Webhook, Integration, LogEntry,
  TraceSpan, ChangeRequest, FeatureFlag, Runbook, UptimeRecord, Region,
  EnvironmentName,
} from "@/lib/types";

// ============================================================================
// People & Teams
// ============================================================================

export const people: Person[] = [
  { id: "u1", name: "Maya Okonkwo", handle: "maya", email: "maya@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&fit=crop&crop=faces", role: "Engineering Manager", team: "Platform", timezone: "America/Los_Angeles", title: "Director, Platform Engineering" },
  { id: "u2", name: "Daniel Vargas", handle: "dvargas", email: "daniel@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&fit=crop&crop=faces", role: "Staff SRE", team: "Platform", timezone: "America/Los_Angeles", title: "Staff Site Reliability Engineer" },
  { id: "u3", name: "Priya Raman", handle: "priya", email: "priya@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&fit=crop&crop=faces", role: "Senior SRE", team: "Reliability", timezone: "Asia/Kolkata", title: "Senior Site Reliability Engineer" },
  { id: "u4", name: "Theo Lambert", handle: "theo", email: "theo@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&fit=crop&crop=faces", role: "Senior SRE", team: "Reliability", timezone: "Europe/Paris", title: "Senior Site Reliability Engineer" },
  { id: "u5", name: "Naomi Chen", handle: "naomic", email: "naomi@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=120&h=120&fit=crop&crop=faces", role: "On-Call Engineer", team: "Reliability", timezone: "Asia/Kolkata", title: "On-Call Engineer" },
  { id: "u6", name: "Marcus Anderson", handle: "marcus", email: "marcus@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&fit=crop&crop=faces", role: "Senior Backend Engineer", team: "Payments", timezone: "America/New_York", title: "Senior Backend Engineer" },
  { id: "u7", name: "Sofia Bianchi", handle: "sofia", email: "sofia@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&h=120&fit=crop&crop=faces", role: "On-Call Engineer", team: "Payments", timezone: "Europe/Rome", title: "On-Call Engineer" },
  { id: "u8", name: "Liam Walker", handle: "liamw", email: "liam@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=120&h=120&fit=crop&crop=faces", role: "Senior SRE", team: "Platform", timezone: "America/Chicago", title: "Senior Site Reliability Engineer" },
  { id: "u9", name: "Yuki Tanaka", handle: "yuki", email: "yuki@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=120&h=120&fit=crop&crop=faces", role: "Senior SRE", team: "Reliability", timezone: "Asia/Tokyo", title: "Senior Site Reliability Engineer" },
  { id: "u10", name: "Elena Petrov", handle: "elena", email: "elena@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1558898479-33c0057a5d12?w=120&h=120&fit=crop&crop=faces", role: "On-Call Engineer", team: "Platform", timezone: "Europe/Berlin", title: "On-Call Engineer" },
  { id: "u11", name: "Arjun Mehta", handle: "arjun", email: "arjun@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=120&h=120&fit=crop&crop=faces", role: "Senior SRE", team: "Reliability", timezone: "Asia/Kolkata", title: "Senior Site Reliability Engineer" },
  { id: "u12", name: "Hannah Wright", handle: "hannah", email: "hannah@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop&crop=faces", role: "Security Engineer", team: "Security", timezone: "America/Los_Angeles", title: "Senior Security Engineer" },
  { id: "u13", name: "Diego Morales", handle: "diego", email: "diego@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&fit=crop&crop=faces", role: "Engineering Manager", team: "Payments", timezone: "America/Mexico_City", title: "Director, Payments Engineering" },
  { id: "u14", name: "Anya Volkova", handle: "anya", email: "anya@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=120&h=120&fit=crop&crop=faces", role: "On-Call Engineer", team: "Security", timezone: "Europe/Moscow", title: "On-Call Security Engineer" },
  { id: "u15", name: "Caleb Foster", handle: "caleb", email: "caleb@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1545167622-3a6ac756afa4?w=120&h=120&fit=crop&crop=faces", role: "Senior Backend Engineer", team: "Platform", timezone: "America/Denver", title: "Senior Backend Engineer" },
  { id: "u16", name: "Mei Lin", handle: "meilin", email: "mei@sentinelgrid.io", avatarUrl: "https://images.unsplash.com/photo-1530785602389-07594beb8b73?w=120&h=120&fit=crop&crop=faces", role: "Senior Frontend Engineer", team: "Web", timezone: "Asia/Shanghai", title: "Senior Frontend Engineer" },
];

export function person(id: string): Person {
  return people.find((p) => p.id === id) || people[0];
}

export const teams: Team[] = [
  { id: "t1", name: "Platform Engineering", slug: "platform", description: "Owns core platform services, internal tooling, deployment infrastructure.", leadId: "u1", memberIds: ["u1","u2","u8","u10","u15"], color: "#22D3EE", servicesOwned: ["s1","s2","s7"], escalationPolicyId: "ep1" },
  { id: "t2", name: "Reliability Engineering", slug: "reliability", description: "Owns SLOs, error budgets, alerting strategy, on-call rotation, postmortem culture.", leadId: "u3", memberIds: ["u3","u4","u5","u9","u11"], color: "#A78BFA", servicesOwned: ["s3","s4","s5"], escalationPolicyId: "ep2" },
  { id: "t3", name: "Payments Engineering", slug: "payments", description: "Owns payment processing, settlement, fraud detection, billing.", leadId: "u13", memberIds: ["u6","u7","u13"], color: "#34D399", servicesOwned: ["s6","s11"], escalationPolicyId: "ep1" },
  { id: "t4", name: "Web Application", slug: "web", description: "Owns customer-facing web applications and design system.", leadId: "u16", memberIds: ["u16"], color: "#F59E0B", servicesOwned: ["s8"], escalationPolicyId: "ep2" },
  { id: "t5", name: "Security Operations", slug: "security", description: "Owns vulnerability management, compliance, security incidents.", leadId: "u12", memberIds: ["u12","u14"], color: "#F87171", servicesOwned: ["s9","s10"], escalationPolicyId: "ep3" },
];

export function team(id: string): Team | undefined {
  return teams.find((t) => t.id === id);
}

// ============================================================================
// Services
// ============================================================================

export const services: Service[] = [
  { id: "s1", name: "api-gateway", slug: "api-gateway", description: "Primary public API gateway. Routes all customer traffic, terminates TLS, applies rate limits and auth.", tier: "tier1", teamId: "t1", ownerId: "u2", language: "Go", framework: "chi", repository: "sentinelgrid/api-gateway", health: "operational", healthScore: 98, sloId: "slo1", dependencies: ["s3","s5"], dependents: ["s2","s6","s8"], openIncidents: 0, openAlerts: 2, lastDeployId: "d1", lastDeployAt: "2026-06-30T14:22:00Z", environment: "production", regions: ["us-east-1","eu-west-1","ap-south-1"], endpoints: 142, requestsPerSecond: 42500, p95LatencyMs: 38, errorRate: 0.018, uptime30d: 99.992, runbooks: ["r1","r2"], tier1: true },
  { id: "s2", name: "billing-service", slug: "billing-service", description: "Subscription billing, invoicing, tax calculation. Integrates with Stripe.", tier: "tier1", teamId: "t1", ownerId: "u15", language: "TypeScript", framework: "NestJS", repository: "sentinelgrid/billing-service", health: "degraded", healthScore: 78, sloId: "slo2", dependencies: ["s1","s11"], dependents: [], openIncidents: 1, openAlerts: 5, lastDeployId: "d2", lastDeployAt: "2026-07-01T08:15:00Z", environment: "production", regions: ["us-east-1","eu-west-1"], endpoints: 67, requestsPerSecond: 1820, p95LatencyMs: 124, errorRate: 0.21, uptime30d: 99.86, runbooks: ["r3"], tier1: true },
  { id: "s3", name: "auth-service", slug: "auth-service", description: "OAuth2 / OIDC identity provider, session management, MFA verification.", tier: "tier1", teamId: "t2", ownerId: "u4", language: "Go", framework: "gin", repository: "sentinelgrid/auth-service", health: "operational", healthScore: 96, sloId: "slo3", dependencies: ["s4"], dependents: ["s1","s2","s6","s8"], openIncidents: 0, openAlerts: 1, lastDeployId: "d3", lastDeployAt: "2026-06-29T19:40:00Z", environment: "production", regions: ["us-east-1","eu-west-1","ap-southeast-2"], endpoints: 38, requestsPerSecond: 8900, p95LatencyMs: 52, errorRate: 0.04, uptime30d: 99.97, runbooks: ["r4","r5"], tier1: true },
  { id: "s4", name: "postgres-primary", slug: "postgres-primary", description: "Primary OLTP PostgreSQL cluster, multi-AZ synchronous replication.", tier: "tier1", teamId: "t2", ownerId: "u3", language: "PostgreSQL", framework: "PostgreSQL 16", repository: "sentinelgrid/infra-postgres", health: "operational", healthScore: 99, sloId: "slo4", dependencies: [], dependents: ["s3","s5","s6","s11"], openIncidents: 0, openAlerts: 0, lastDeployId: "d4", lastDeployAt: "2026-06-22T03:00:00Z", environment: "production", regions: ["us-east-1"], endpoints: 0, requestsPerSecond: 0, p95LatencyMs: 4, errorRate: 0, uptime30d: 99.999, runbooks: ["r6"], tier1: true },
  { id: "s5", name: "redis-cluster", slug: "redis-cluster", description: "Redis 7 cluster for session cache, rate limiting, and pub/sub.", tier: "tier2", teamId: "t2", ownerId: "u9", language: "Redis", framework: "Redis 7", repository: "sentinelgrid/infra-redis", health: "operational", healthScore: 95, sloId: "slo5", dependencies: [], dependents: ["s1","s2","s6"], openIncidents: 0, openAlerts: 1, lastDeployId: "d5", lastDeployAt: "2026-06-25T11:10:00Z", environment: "production", regions: ["us-east-1","eu-west-1"], endpoints: 0, requestsPerSecond: 0, p95LatencyMs: 1, errorRate: 0, uptime30d: 99.98, runbooks: ["r7"] },
  { id: "s6", name: "checkout-api", slug: "checkout-api", description: "Payment checkout flow orchestration. Handles 3DS, retries, idempotency.", tier: "tier1", teamId: "t3", ownerId: "u6", language: "Java", framework: "Spring Boot", repository: "sentinelgrid/checkout-api", health: "partial", healthScore: 62, sloId: "slo6", dependencies: ["s1","s3","s11"], dependents: ["s8"], openIncidents: 1, openAlerts: 8, lastDeployId: "d6", lastDeployAt: "2026-07-01T22:05:00Z", environment: "production", regions: ["us-east-1","eu-west-1"], endpoints: 24, requestsPerSecond: 940, p95LatencyMs: 312, errorRate: 1.4, uptime30d: 99.62, runbooks: ["r8","r9"], tier1: true },
  { id: "s7", name: "kafka-bus", slug: "kafka-bus", description: "Kafka event bus for cross-service async communication.", tier: "tier2", teamId: "t1", ownerId: "u8", language: "Kafka", framework: "Kafka 3.7", repository: "sentinelgrid/infra-kafka", health: "operational", healthScore: 97, sloId: "slo7", dependencies: [], dependents: ["s2","s6","s11"], openIncidents: 0, openAlerts: 2, lastDeployId: "d7", lastDeployAt: "2026-06-20T16:30:00Z", environment: "production", regions: ["us-east-1","eu-west-1"], endpoints: 0, requestsPerSecond: 0, p95LatencyMs: 8, errorRate: 0, uptime30d: 99.96, runbooks: ["r10"] },
  { id: "s8", name: "web-app", slug: "web-app", description: "Customer-facing Next.js web application. SSR + ISR, multi-region.", tier: "tier2", teamId: "t4", ownerId: "u16", language: "TypeScript", framework: "Next.js 16", repository: "sentinelgrid/web-app", health: "operational", healthScore: 94, sloId: "slo8", dependencies: ["s1","s3"], dependents: [], openIncidents: 0, openAlerts: 3, lastDeployId: "d8", lastDeployAt: "2026-07-01T13:45:00Z", environment: "production", regions: ["global"], endpoints: 0, requestsPerSecond: 0, p95LatencyMs: 220, errorRate: 0.12, uptime30d: 99.91, runbooks: ["r11"] },
  { id: "s9", name: "vault", slug: "vault", description: "HashiCorp Vault for secrets management and dynamic credentials.", tier: "tier1", teamId: "t5", ownerId: "u12", language: "Vault", framework: "Vault 1.18", repository: "sentinelgrid/infra-vault", health: "operational", healthScore: 99, dependencies: [], dependents: ["s1","s2","s3","s6"], openIncidents: 0, openAlerts: 0, lastDeployId: "d9", lastDeployAt: "2026-06-15T09:00:00Z", environment: "production", regions: ["us-east-1","eu-west-1"], endpoints: 12, requestsPerSecond: 1200, p95LatencyMs: 8, errorRate: 0, uptime30d: 99.999, runbooks: ["r12"], tier1: true },
  { id: "s10", name: "authz-engine", slug: "authz-engine", description: "Policy evaluation engine for RBAC/ABAC. Open Policy Agent based.", tier: "tier2", teamId: "t5", ownerId: "u14", language: "Go", framework: "OPA", repository: "sentinelgrid/authz-engine", health: "operational", healthScore: 96, dependencies: ["s9"], dependents: ["s1","s3","s6"], openIncidents: 0, openAlerts: 1, lastDeployId: "d10", lastDeployAt: "2026-06-28T18:00:00Z", environment: "production", regions: ["us-east-1"], endpoints: 6, requestsPerSecond: 6800, p95LatencyMs: 3, errorRate: 0.001, uptime30d: 99.98, runbooks: ["r13"] },
  { id: "s11", name: "payment-ledger", slug: "payment-ledger", description: "Immutable ledger of all payment events. Append-only, double-entry.", tier: "tier1", teamId: "t3", ownerId: "u7", language: "Go", framework: "go-kit", repository: "sentinelgrid/payment-ledger", health: "operational", healthScore: 93, sloId: "slo9", dependencies: ["s4","s7"], dependents: ["s2","s6"], openIncidents: 0, openAlerts: 2, lastDeployId: "d11", lastDeployAt: "2026-06-27T15:20:00Z", environment: "production", regions: ["us-east-1"], endpoints: 18, requestsPerSecond: 320, p95LatencyMs: 84, errorRate: 0.05, uptime30d: 99.94, runbooks: ["r14"], tier1: true },
];

export function service(id: string): Service | undefined {
  return services.find((s) => s.id === id);
}

// ============================================================================
// Runbooks
// ============================================================================

export const runbooks: Runbook[] = [
  { id: "r1", title: "API Gateway 5xx Spike", slug: "api-gateway-5xx-spike", serviceId: "s1", category: "Incident Response", steps: [{ title: "Triage", body: "Check the rate of 5xx responses per upstream in Grafana. If only one upstream is failing, route investigation to its owning team." }, { title: "Mitigate", body: "If the upstream is overloaded, enable circuit breaker via the runtime config. If a bad deploy is suspected, prepare for rollback." }, { title: "Rollback", body: "Use `sg deploy rollback api-gateway --ref <last-good>` to revert to the previous stable release." }], lastUpdated: "2026-06-18", authorId: "u2", views: 184 },
  { id: "r2", title: "API Gateway Rate Limit Bypass", slug: "api-gateway-rate-limit-bypass", serviceId: "s1", category: "Security", steps: [{ title: "Identify", body: "Check Cloudflare logs for unusual patterns." }, { title: "Quarantine", body: "Add offending IPs to the denylist." }], lastUpdated: "2026-05-30", authorId: "u2", views: 92 },
  { id: "r3", title: "Billing Invoice Generation Lag", slug: "billing-invoice-lag", serviceId: "s2", category: "Performance", steps: [{ title: "Investigate", body: "Check the invoice worker queue depth in Bull Board." }, { title: "Scale", body: "Increase the worker count via `sg scale billing-worker --count=8`." }], lastUpdated: "2026-06-25", authorId: "u15", views: 56 },
  { id: "r4", title: "Auth Service Token Validation Errors", slug: "auth-token-errors", serviceId: "s3", category: "Incident Response", steps: [{ title: "Verify", body: "Check JWKS rotation status. If a rotation just happened, downstream caches may be stale." }, { title: "Purge", body: "Force JWKS cache purge across all consumers." }], lastUpdated: "2026-06-12", authorId: "u4", views: 134 },
  { id: "r5", title: "Auth Service MFA Failure", slug: "auth-mfa-failure", serviceId: "s3", category: "Incident Response", steps: [{ title: "Check", body: "Verify TOTP service availability and clock drift." }], lastUpdated: "2026-06-08", authorId: "u4", views: 41 },
  { id: "r6", title: "PostgreSQL Replication Lag", slug: "postgres-repl-lag", serviceId: "s4", category: "Database", steps: [{ title: "Diagnose", body: "Check `pg_stat_replication` for lag." }, { title: "Mitigate", body: "If lag > 5s, throttle writes via feature flag and alert DBA." }], lastUpdated: "2026-06-01", authorId: "u3", views: 78 },
  { id: "r7", title: "Redis Memory Pressure", slug: "redis-memory-pressure", serviceId: "s5", category: "Infrastructure", steps: [{ title: "Inspect", body: "Run `MEMORY STATS` on each shard." }, { title: "Evict", body: "Identify large keys and consider maxmemory-policy change." }], lastUpdated: "2026-05-22", authorId: "u9", views: 65 },
  { id: "r8", title: "Checkout 3DS Timeout", slug: "checkout-3ds-timeout", serviceId: "s6", category: "Incident Response", steps: [{ title: "Inspect", body: "Check the 3DS provider status page." }, { title: "Fallback", body: "If the provider is down, enable frictionless fallback via `checkout.fallback_3ds=true`." }], lastUpdated: "2026-06-30", authorId: "u6", views: 211 },
  { id: "r9", title: "Checkout Idempotency Conflict", slug: "checkout-idempotency-conflict", serviceId: "s6", category: "Operations", steps: [{ title: "Investigate", body: "Check the idempotency_keys table for collisions." }], lastUpdated: "2026-06-14", authorId: "u6", views: 33 },
  { id: "r10", title: "Kafka Consumer Lag", slug: "kafka-consumer-lag", serviceId: "s7", category: "Infrastructure", steps: [{ title: "Diagnose", body: "Use `kafka-consumer-groups --describe`." }, { title: "Scale", body: "Add more consumer instances or increase partition count." }], lastUpdated: "2026-05-18", authorId: "u8", views: 88 },
  { id: "r11", title: "Web App Build Failure", slug: "web-app-build-failure", serviceId: "s8", category: "Build", steps: [{ title: "Investigate", body: "Check the CI pipeline logs." }], lastUpdated: "2026-06-26", authorId: "u16", views: 27 },
  { id: "r12", title: "Vault Seal Event", slug: "vault-seal-event", serviceId: "s9", category: "Security", steps: [{ title: "Identify", body: "Check audit log for the cause of seal." }, { title: "Unseal", body: "Coordinate with security team to perform unseal ceremony." }], lastUpdated: "2026-04-30", authorId: "u12", views: 12 },
  { id: "r13", title: "AuthZ Engine Policy Drift", slug: "authz-policy-drift", serviceId: "s10", category: "Security", steps: [{ title: "Diff", body: "Compare current policies with last-known-good." }], lastUpdated: "2026-05-12", authorId: "u14", views: 19 },
  { id: "r14", title: "Payment Ledger Reconciliation Gap", slug: "payment-ledger-recon-gap", serviceId: "s11", category: "Operations", steps: [{ title: "Reconcile", body: "Run the daily reconciliation report." }, { title: "Investigate", body: "If gap > $1, escalate to payments lead." }], lastUpdated: "2026-06-10", authorId: "u7", views: 47 },
];

// ============================================================================
// SLOs
// ============================================================================

export const slos: SLO[] = [
  { id: "slo1", ref: "SLO-001", name: "API Gateway Availability", description: "99.95% of requests succeed (non-5xx).", serviceId: "s1", sli: { metric: "success_rate", source: "request_total", query: "sum(rate(request_total{status!~\"5..\"}[5m])) / sum(rate(request_total[5m]))", unit: "percent" }, target: 99.95, window: "28d", status: "healthy", current: 99.982, errorBudget: { total: 100, remaining: 86, consumed: 14, burnRate: 0.4 }, alerts: [{ burnRate: 14.4, window: "1h", triggered: false }, { burnRate: 6, window: "6h", triggered: false }], createdAt: "2026-01-01", updatedAt: "2026-06-30" },
  { id: "slo2", ref: "SLO-002", name: "Billing Service Availability", description: "99.9% of billing operations succeed.", serviceId: "s2", sli: { metric: "success_rate", source: "billing_ops_total", query: "sum(rate(billing_ops_total{status=\"ok\"}[5m])) / sum(rate(billing_ops_total[5m]))", unit: "percent" }, target: 99.9, window: "28d", status: "at_risk", current: 99.86, errorBudget: { total: 100, remaining: 28, consumed: 72, burnRate: 2.8 }, alerts: [{ burnRate: 14.4, window: "1h", triggered: false }, { burnRate: 6, window: "6h", triggered: true }], createdAt: "2026-01-01", updatedAt: "2026-07-01" },
  { id: "slo3", ref: "SLO-003", name: "Auth Service Latency", description: "99% of token validations < 100ms p99.", serviceId: "s3", sli: { metric: "latency_p99", source: "http_request_duration", query: "histogram_quantile(0.99, sum(rate(http_request_duration_bucket[5m)) by (le))", unit: "ms" }, target: 99, window: "28d", status: "healthy", current: 99.4, errorBudget: { total: 100, remaining: 92, consumed: 8, burnRate: 0.3 }, alerts: [{ burnRate: 14.4, window: "1h", triggered: false }], createdAt: "2026-01-01", updatedAt: "2026-06-30" },
  { id: "slo4", ref: "SLO-004", name: "PostgreSQL Uptime", description: "99.99% uptime for primary.", serviceId: "s4", sli: { metric: "uptime", source: "pg_up", query: "avg_over_time(pg_up[5m])", unit: "percent" }, target: 99.99, window: "28d", status: "healthy", current: 99.999, errorBudget: { total: 100, remaining: 100, consumed: 0, burnRate: 0 }, alerts: [], createdAt: "2026-01-01", updatedAt: "2026-06-30" },
  { id: "slo5", ref: "SLO-005", name: "Redis Cache Hit Ratio", description: "Cache hit ratio > 90%.", serviceId: "s5", sli: { metric: "hit_ratio", source: "redis_keys", query: "rate(redis_keyspace_hits[5m]) / (rate(redis_keyspace_hits[5m]) + rate(redis_keyspace_misses[5m]))", unit: "percent" }, target: 90, window: "28d", status: "healthy", current: 94.2, errorBudget: { total: 100, remaining: 100, consumed: 0, burnRate: 0 }, alerts: [], createdAt: "2026-01-01", updatedAt: "2026-06-30" },
  { id: "slo6", ref: "SLO-006", name: "Checkout Success Rate", description: "99.5% of checkout attempts complete successfully.", serviceId: "s6", sli: { metric: "success_rate", source: "checkout_total", query: "sum(rate(checkout_total{status=\"ok\"}[5m])) / sum(rate(checkout_total[5m]))", unit: "percent" }, target: 99.5, window: "28d", status: "breached", current: 98.6, errorBudget: { total: 100, remaining: 0, consumed: 100, burnRate: 8.4 }, alerts: [{ burnRate: 14.4, window: "1h", triggered: true }, { burnRate: 6, window: "6h", triggered: true }], createdAt: "2026-01-01", updatedAt: "2026-07-02" },
  { id: "slo7", ref: "SLO-007", name: "Kafka End-to-End Latency", description: "99% of events < 1s end-to-end.", serviceId: "s7", sli: { metric: "latency_p99", source: "kafka_consumer_lag", query: "histogram_quantile(0.99, sum(rate(kafka_consumer_lag_bucket[5m)) by (le))", unit: "seconds" }, target: 99, window: "28d", status: "healthy", current: 99.7, errorBudget: { total: 100, remaining: 95, consumed: 5, burnRate: 0.2 }, alerts: [], createdAt: "2026-01-01", updatedAt: "2026-06-30" },
  { id: "slo8", ref: "SLO-008", name: "Web App Page Load", description: "LCP < 2.5s for 95% of page views.", serviceId: "s8", sli: { metric: "lcp_p95", source: "rum_events", query: "histogram_quantile(0.95, sum(rate(web_vitals_lcp_bucket[5m)) by (le))", unit: "seconds" }, target: 95, window: "28d", status: "at_risk", current: 94.1, errorBudget: { total: 100, remaining: 38, consumed: 62, burnRate: 1.4 }, alerts: [{ burnRate: 6, window: "6h", triggered: false }], createdAt: "2026-01-01", updatedAt: "2026-07-01" },
  { id: "slo9", ref: "SLO-009", name: "Payment Ledger Integrity", description: "100% ledger entries reconcile daily.", serviceId: "s11", sli: { metric: "reconciliation_rate", source: "ledger_audit", query: "1 - (rate(ledger_unreconciled[1d]) / rate(ledger_entries[1d]))", unit: "percent" }, target: 100, window: "28d", status: "healthy", current: 100, errorBudget: { total: 100, remaining: 100, consumed: 0, burnRate: 0 }, alerts: [], createdAt: "2026-01-01", updatedAt: "2026-06-30" },
];

// ============================================================================
// Incidents
// ============================================================================

export const incidents: Incident[] = [
  {
    id: "inc1",
    ref: "INC-2841",
    title: "Checkout API elevated 5xx rate in us-east-1",
    summary: "Checkout API is returning 5xx errors at 1.4% baseline after a canary deployment. Impacting ~3% of payment attempts in us-east-1.",
    severity: "high",
    status: "investigating",
    commanderId: "u6",
    responderIds: ["u6", "u7", "u3", "u2"],
    serviceIds: ["s6", "s2"],
    startedAt: "2026-07-02T05:12:00Z",
    detectedAt: "2026-07-02T05:14:00Z",
    acknowledgedAt: "2026-07-02T05:16:00Z",
    lastUpdateAt: "2026-07-02T05:48:00Z",
    impactedUsers: 4200,
    impactedRegions: ["us-east-1"],
    customerImpact: "Approximately 3% of checkout attempts in US-East are failing with a 500 error. Retry usually succeeds on second attempt.",
    alertIds: ["al1"],
    deploymentId: "d6",
    subscriberIds: ["u1", "u13", "u16"],
    tags: ["payments", "checkout", "us-east-1", "canary"],
    timeline: [
      { id: "tl1", incidentId: "inc1", timestamp: "2026-07-02T05:12:00Z", kind: "created", authorId: "u5", message: "Incident auto-created from alert ALR-1248 (checkout 5xx > 1%)" },
      { id: "tl2", incidentId: "inc1", timestamp: "2026-07-02T05:14:00Z", kind: "alert_linked", authorId: "u5", message: "Alert ALR-1248 linked to incident" },
      { id: "tl3", incidentId: "inc1", timestamp: "2026-07-02T05:16:00Z", kind: "acknowledged", authorId: "u6", message: "Marcus Anderson acknowledged and took commander role" },
      { id: "tl4", incidentId: "inc1", timestamp: "2026-07-02T05:18:00Z", kind: "responder_added", authorId: "u6", message: "Added Sofia Bianchi (payments on-call) and Priya Raman (reliability on-call) as responders" },
      { id: "tl5", incidentId: "inc1", timestamp: "2026-07-02T05:22:00Z", kind: "service_added", authorId: "u6", message: "Added service: checkout-api, billing-service" },
      { id: "tl6", incidentId: "inc1", timestamp: "2026-07-02T05:24:00Z", kind: "deployment_linked", authorId: "u7", message: "Linked deployment DEP-2024-006 (canary v2.4.1-rc1)" },
      { id: "tl7", incidentId: "inc1", timestamp: "2026-07-02T05:31:00Z", kind: "note", authorId: "u3", message: "Internal note: error rate started climbing 4 minutes after canary rollout began. Pattern matches a known issue with the new 3DS retry logic." },
      { id: "tl8", incidentId: "inc1", timestamp: "2026-07-02T05:38:00Z", kind: "runbook_linked", authorId: "u6", message: "Linked runbook: Checkout 3DS Timeout" },
      { id: "tl9", incidentId: "inc1", timestamp: "2026-07-02T05:48:00Z", kind: "public_update", authorId: "u6", message: "Posted public update: 'We are investigating elevated checkout failures in US-East. Some payment attempts may fail. Please retry.'" },
    ],
    updates: [
      { id: "up1", incidentId: "inc1", timestamp: "2026-07-02T05:48:00Z", authorId: "u6", audience: "public", body: "We are investigating elevated checkout failures in US-East. Some payment attempts may fail. Please retry." },
      { id: "up2", incidentId: "inc1", timestamp: "2026-07-02T05:31:00Z", authorId: "u3", audience: "internal", body: "Error rate started climbing 4 minutes after canary rollout began. Pattern matches the 3DS retry issue we saw in QA last week." },
      { id: "up3", incidentId: "inc1", timestamp: "2026-07-02T05:18:00Z", authorId: "u6", audience: "stakeholder", body: "Incident commander assigned. Initial impact ~3% of US-East checkouts. War room: #inc-2841" },
    ],
    checklist: [
      { id: "ck1", label: "Acknowledge within 5 min", done: true },
      { id: "ck2", label: "Assign commander", done: true },
      { id: "ck3", label: "Identify impact scope", done: true },
      { id: "ck4", label: "Post public status update", done: true },
      { id: "ck5", label: "Identify root cause", done: false },
      { id: "ck6", label: "Apply mitigation", done: false },
      { id: "ck7", label: "Verify recovery", done: false },
      { id: "ck8", label: "Resolve incident", done: false },
      { id: "ck9", label: "Schedule postmortem", done: false },
    ],
    warRoomChannel: "#inc-2841",
    statusPagePosted: true,
    responseSlaSeconds: 240,
  },
  {
    id: "inc2",
    ref: "INC-2840",
    title: "Billing invoice generation backlog",
    summary: "Invoice generation workers are backed up; ~14k invoices pending. Customers may see delayed invoice emails.",
    severity: "medium",
    status: "monitoring",
    commanderId: "u15",
    responderIds: ["u15", "u9", "u3"],
    serviceIds: ["s2"],
    startedAt: "2026-07-01T22:30:00Z",
    detectedAt: "2026-07-01T22:42:00Z",
    acknowledgedAt: "2026-07-01T22:45:00Z",
    lastUpdateAt: "2026-07-02T04:12:00Z",
    impactedUsers: 14200,
    impactedRegions: ["us-east-1", "eu-west-1"],
    customerImpact: "Invoice emails delayed by up to 6 hours. No financial impact. Payments continue to process normally.",
    alertIds: ["al2"],
    subscriberIds: ["u1", "u13"],
    tags: ["billing", "backlog"],
    timeline: [
      { id: "tl10", incidentId: "inc2", timestamp: "2026-07-01T22:30:00Z", kind: "created", authorId: "u5", message: "Incident auto-created from alert ALR-1245 (invoice queue depth > 10k)" },
      { id: "tl11", incidentId: "inc2", timestamp: "2026-07-01T22:45:00Z", kind: "acknowledged", authorId: "u15", message: "Caleb Foster acknowledged as commander" },
      { id: "tl12", incidentId: "inc2", timestamp: "2026-07-01T23:02:00Z", kind: "note", authorId: "u15", message: "Scaled workers from 4 to 8. Queue depth dropping ~500/min." },
      { id: "tl13", incidentId: "inc2", timestamp: "2026-07-02T04:12:00Z", kind: "status_change", authorId: "u15", message: "Status changed to monitoring. Queue depth back under 1k." },
    ],
    updates: [
      { id: "up4", incidentId: "inc2", timestamp: "2026-07-02T04:12:00Z", authorId: "u15", audience: "stakeholder", body: "Queue depth back to normal levels. Monitoring for stability before resolving." },
    ],
    checklist: [
      { id: "ck10", label: "Acknowledge", done: true },
      { id: "ck11", label: "Assign commander", done: true },
      { id: "ck12", label: "Mitigate", done: true },
      { id: "ck13", label: "Verify recovery", done: true },
      { id: "ck14", label: "Resolve incident", done: false },
      { id: "ck15", label: "Schedule postmortem", done: false },
    ],
    warRoomChannel: "#inc-2840",
    statusPagePosted: false,
    responseSlaSeconds: 900,
  },
  {
    id: "inc3",
    ref: "INC-2839",
    title: "Auth service token validation errors in EU",
    summary: "Brief spike in 401 responses from auth-service in eu-west-1 due to JWKS rotation.",
    severity: "low",
    status: "resolved",
    commanderId: "u4",
    responderIds: ["u4", "u11"],
    serviceIds: ["s3"],
    startedAt: "2026-07-01T14:00:00Z",
    detectedAt: "2026-07-01T14:02:00Z",
    acknowledgedAt: "2026-07-01T14:03:00Z",
    resolvedAt: "2026-07-01T14:18:00Z",
    lastUpdateAt: "2026-07-01T14:18:00Z",
    impactedUsers: 850,
    impactedRegions: ["eu-west-1"],
    customerImpact: "Brief 18-minute window of elevated 401 errors. Users were prompted to re-authenticate. No data loss.",
    rootCause: "JWKS rotation completed but stale cache in authz-engine caused old keys to be used for validation.",
    resolution: "Purged JWKS cache. Authz-engine fetched fresh keys within 30 seconds.",
    alertIds: ["al3"],
    subscriberIds: [],
    tags: ["auth", "jwks", "eu-west-1"],
    timeline: [
      { id: "tl14", incidentId: "inc3", timestamp: "2026-07-01T14:00:00Z", kind: "created", authorId: "u5", message: "Incident created from alert ALR-1240 (auth 401 rate spike)" },
      { id: "tl15", incidentId: "inc3", timestamp: "2026-07-01T14:03:00Z", kind: "acknowledged", authorId: "u4", message: "Theo Lambert acknowledged" },
      { id: "tl16", incidentId: "inc3", timestamp: "2026-07-01T14:08:00Z", kind: "note", authorId: "u4", message: "Identified stale JWKS cache as cause" },
      { id: "tl17", incidentId: "inc3", timestamp: "2026-07-01T14:12:00Z", kind: "note", authorId: "u11", message: "Purging JWKS cache across all authz-engine instances" },
      { id: "tl18", incidentId: "inc3", timestamp: "2026-07-01T14:18:00Z", kind: "resolved", authorId: "u4", message: "401 rate back to baseline. Resolving." },
    ],
    updates: [
      { id: "up5", incidentId: "inc3", timestamp: "2026-07-01T14:18:00Z", authorId: "u4", audience: "internal", body: "Resolved. Root cause: stale JWKS cache in authz-engine." },
    ],
    checklist: [
      { id: "ck16", label: "Acknowledge", done: true },
      { id: "ck17", label: "Identify root cause", done: true },
      { id: "ck18", label: "Mitigate", done: true },
      { id: "ck19", label: "Resolve", done: true },
      { id: "ck20", label: "Postmortem required", done: false },
    ],
    warRoomChannel: "#inc-2839",
    statusPagePosted: false,
    responseSlaSeconds: 180,
    resolutionSlaSeconds: 1080,
  },
  {
    id: "inc4",
    ref: "INC-2838",
    title: "Web app slow page loads (LCP regression)",
    summary: "LCP regressed from 1.8s to 2.7s after v4.2 release. Affects SEO rankings.",
    severity: "medium",
    status: "identified",
    commanderId: "u16",
    responderIds: ["u16", "u3"],
    serviceIds: ["s8"],
    startedAt: "2026-07-01T09:00:00Z",
    detectedAt: "2026-07-01T09:30:00Z",
    acknowledgedAt: "2026-07-01T09:35:00Z",
    lastUpdateAt: "2026-07-01T18:20:00Z",
    impactedUsers: 0,
    impactedRegions: ["global"],
    customerImpact: "No functional impact, but slower page loads affect SEO ranking and user experience.",
    alertIds: ["al4"],
    subscriberIds: [],
    tags: ["web", "performance", "lcp"],
    timeline: [
      { id: "tl19", incidentId: "inc4", timestamp: "2026-07-01T09:30:00Z", kind: "created", authorId: "u5", message: "Incident created from alert ALR-1238 (LCP > 2.5s)" },
      { id: "tl20", incidentId: "inc4", timestamp: "2026-07-01T09:35:00Z", kind: "acknowledged", authorId: "u16", message: "Mei Lin acknowledged" },
      { id: "tl21", incidentId: "inc4", timestamp: "2026-07-01T10:15:00Z", kind: "deployment_linked", authorId: "u16", message: "Linked deployment DEP-2024-008 (v4.2)" },
      { id: "tl22", incidentId: "inc4", timestamp: "2026-07-01T18:20:00Z", kind: "note", authorId: "u16", message: "Identified: new hero image is 4.2MB. Need to add proper sizing + lazy loading." },
    ],
    updates: [
      { id: "up6", incidentId: "inc4", timestamp: "2026-07-01T18:20:00Z", authorId: "u16", audience: "internal", body: "Identified: new hero image is 4.2MB. Need to add proper sizing + lazy loading." },
    ],
    checklist: [
      { id: "ck21", label: "Acknowledge", done: true },
      { id: "ck22", label: "Identify root cause", done: true },
      { id: "ck23", label: "Implement fix", done: false },
      { id: "ck24", label: "Deploy fix", done: false },
      { id: "ck25", label: "Verify recovery", done: false },
    ],
    warRoomChannel: "#inc-2838",
    statusPagePosted: false,
    responseSlaSeconds: 300,
  },
];

export function incident(id: string): Incident | undefined {
  return incidents.find((i) => i.id === id);
}

// ============================================================================
// Postmortems
// ============================================================================

export const postmortems: Postmortem[] = [
  {
    id: "pm1",
    ref: "PM-2026-014",
    incidentId: "inc3",
    title: "Auth Service JWKS Cache Stale",
    status: "published",
    authorId: "u4",
    reviewerIds: ["u3", "u1"],
    createdAt: "2026-07-01T15:00:00Z",
    publishedAt: "2026-07-01T18:00:00Z",
    impactSummary: "850 EU users received 401 errors for 18 minutes during JWKS rotation. No data loss, no auth bypass.",
    rootCause: "JWKS rotation event completed at 14:00 UTC. authz-engine held a cached copy of the previous keys with TTL of 1 hour. Tokens signed with new keys were validated against old keys, causing 401 responses.",
    contributingFactors: [
      "JWKS cache TTL was set to 1h, but rotation happens every 12h with a 6h overlap window.",
      "No proactive purge of JWKS cache on rotation event.",
      "Alerting on 401 rate was set too high - threshold was 5%, spike reached only 3.2%.",
    ],
    timeline: [
      { timestamp: "2026-07-01T14:00:00Z", event: "JWKS rotation completed successfully" },
      { timestamp: "2026-07-01T14:01:00Z", event: "First 401 errors started appearing" },
      { timestamp: "2026-07-01T14:02:00Z", event: "Alert ALR-1240 triggered" },
      { timestamp: "2026-07-01T14:03:00Z", event: "Theo acknowledged incident" },
      { timestamp: "2026-07-01T14:12:00Z", event: "Cache purge executed" },
      { timestamp: "2026-07-01T14:18:00Z", event: "401 rate back to baseline" },
    ],
    lessons: [
      "JWKS rotation needs proactive cache invalidation, not just TTL expiry.",
      "Alerting thresholds should be calibrated to detect meaningful deviations, not just severe spikes.",
      "The authz-engine should fetch new keys eagerly when it encounters a kid it doesn't recognize.",
    ],
    actionItems: [
      { id: "ai1", postmortemId: "pm1", description: "Implement eager JWKS fetch on unknown kid", ownerId: "u4", status: "in_progress", priority: "high", dueDate: "2026-07-15", type: "prevention" },
      { id: "ai2", postmortemId: "pm1", description: "Add JWKS rotation event broadcast", ownerId: "u4", status: "todo", priority: "medium", dueDate: "2026-07-22", type: "detection" },
      { id: "ai3", postmortemId: "pm1", description: "Tune 401 rate alert threshold to 1.5%", ownerId: "u3", status: "done", priority: "low", dueDate: "2026-07-05", type: "detection" },
      { id: "ai4", postmortemId: "pm1", description: "Document JWKS rotation runbook", ownerId: "u4", status: "in_progress", priority: "medium", dueDate: "2026-07-19", type: "process" },
    ],
    severity: "low",
    durationHours: 0.3,
    tags: ["auth", "jwks", "cache", "rotation"],
  },
  {
    id: "pm2",
    ref: "PM-2026-013",
    incidentId: "inc_prev1",
    title: "Redis Cluster Memory Pressure Event",
    status: "published",
    authorId: "u9",
    reviewerIds: ["u3", "u1"],
    createdAt: "2026-06-25T10:00:00Z",
    publishedAt: "2026-06-26T14:00:00Z",
    impactSummary: "5-minute latency spike on cached endpoints after Redis memory reached 92%.",
    rootCause: "A misconfigured session TTL on the web app caused sessions to persist for 30 days instead of 7 days, leading to gradual memory growth.",
    contributingFactors: [
      "No memory usage alerting between 80-90% (only critical at 95%).",
      "Session TTL change was made without corresponding capacity review.",
      "eviction policy was set to no-eviction, so memory growth led to OOM errors instead of graceful eviction.",
    ],
    timeline: [
      { timestamp: "2026-06-25T08:00:00Z", event: "Memory usage crossed 80%" },
      { timestamp: "2026-06-25T09:30:00Z", event: "Memory usage crossed 90%" },
      { timestamp: "2026-06-25T09:42:00Z", event: "First OOM errors" },
      { timestamp: "2026-06-25T09:45:00Z", event: "Alert triggered" },
      { timestamp: "2026-06-25T09:50:00Z", event: "Mitigation: manual key eviction" },
      { timestamp: "2026-06-25T09:55:00Z", event: "Back to normal" },
    ],
    lessons: [
      "Session TTL changes require capacity review.",
      "Eviction policy should be allkeys-lru for session caches.",
      "Need graduated alerting at 80%, 85%, 90%.",
    ],
    actionItems: [
      { id: "ai5", postmortemId: "pm2", description: "Change eviction policy to allkeys-lru", ownerId: "u9", status: "done", priority: "high", dueDate: "2026-06-28", type: "prevention" },
      { id: "ai6", postmortemId: "pm2", description: "Add graduated memory alerting", ownerId: "u3", status: "done", priority: "medium", dueDate: "2026-06-30", type: "detection" },
      { id: "ai7", postmortemId: "pm2", description: "Add capacity review step to TTL changes", ownerId: "u3", status: "in_progress", priority: "low", dueDate: "2026-07-15", type: "process" },
    ],
    severity: "medium",
    durationHours: 0.08,
    tags: ["redis", "memory", "session", "capacity"],
  },
];

// ============================================================================
// Alerts (events + rules)
// ============================================================================

export const alertRules: AlertRule[] = [
  { id: "ar1", ref: "ALERT-001", name: "Checkout 5xx > 1%", description: "Fires when checkout-api 5xx rate exceeds 1% for 5 minutes.", serviceId: "s6", metric: "http_5xx_rate", condition: ">", threshold: 1, window: "5m", severity: "high", enabled: true, routingId: "ep1", lastTriggeredAt: "2026-07-02T05:12:00Z", triggerCount7d: 3, noiseScore: 12 },
  { id: "ar2", ref: "ALERT-002", name: "Invoice queue depth > 10k", description: "Fires when invoice worker queue depth exceeds 10k.", serviceId: "s2", metric: "queue_depth", condition: ">", threshold: 10000, window: "5m", severity: "medium", enabled: true, routingId: "ep1", lastTriggeredAt: "2026-07-01T22:42:00Z", triggerCount7d: 1, noiseScore: 4 },
  { id: "ar3", ref: "ALERT-003", name: "Auth 401 rate > 3%", description: "Fires when auth-service 401 rate exceeds 3%.", serviceId: "s3", metric: "http_401_rate", condition: ">", threshold: 3, window: "5m", severity: "low", enabled: true, routingId: "ep2", lastTriggeredAt: "2026-07-01T14:02:00Z", triggerCount7d: 1, noiseScore: 2 },
  { id: "ar4", ref: "ALERT-004", name: "Web LCP > 2.5s", description: "Fires when web-app LCP p95 exceeds 2.5s.", serviceId: "s8", metric: "lcp_p95", condition: ">", threshold: 2.5, window: "10m", severity: "medium", enabled: true, routingId: "ep2", lastTriggeredAt: "2026-07-01T09:30:00Z", triggerCount7d: 1, noiseScore: 3 },
  { id: "ar5", ref: "ALERT-005", name: "PostgreSQL replication lag > 5s", description: "Fires when PG replication lag exceeds 5 seconds.", serviceId: "s4", metric: "repl_lag", condition: ">", threshold: 5, window: "2m", severity: "high", enabled: true, routingId: "ep2", triggerCount7d: 0, noiseScore: 0 },
  { id: "ar6", ref: "ALERT-006", name: "Kafka consumer lag > 50k", description: "Fires when any consumer group lag exceeds 50k.", serviceId: "s7", metric: "consumer_lag", condition: ">", threshold: 50000, window: "5m", severity: "medium", enabled: true, routingId: "ep1", triggerCount7d: 0, noiseScore: 0 },
  { id: "ar7", ref: "ALERT-007", name: "API Gateway p99 > 200ms", description: "Fires when API gateway p99 latency exceeds 200ms.", serviceId: "s1", metric: "p99_latency", condition: ">", threshold: 200, window: "5m", severity: "medium", enabled: true, routingId: "ep1", triggerCount7d: 2, noiseScore: 8 },
  { id: "ar8", ref: "ALERT-008", name: "Redis memory > 85%", description: "Fires when Redis memory usage exceeds 85%.", serviceId: "s5", metric: "memory_usage", condition: ">", threshold: 85, window: "5m", severity: "medium", enabled: true, routingId: "ep2", triggerCount7d: 0, noiseScore: 0 },
  { id: "ar9", ref: "ALERT-009", name: "Host CPU > 90%", description: "Fires when any host CPU exceeds 90% for 10 minutes.", serviceId: "s1", metric: "cpu_usage", condition: ">", threshold: 90, window: "10m", severity: "low", enabled: false, routingId: "ep1", triggerCount7d: 12, noiseScore: 87 },
  { id: "ar10", ref: "ALERT-010", name: "Disk usage > 85%", description: "Fires when any disk usage exceeds 85%.", serviceId: "s1", metric: "disk_usage", condition: ">", threshold: 85, window: "5m", severity: "low", enabled: true, routingId: "ep1", triggerCount7d: 4, noiseScore: 21 },
];

export const alerts: AlertEvent[] = [
  { id: "al1", ref: "ALR-1248", ruleId: "ar1", serviceId: "s6", severity: "high", status: "firing", startedAt: "2026-07-02T05:12:00Z", message: "Checkout 5xx rate is 1.4% (threshold 1%)", value: "1.4%", routedTo: "ep1", incidentId: "inc1", dedupKey: "checkout-5xx-us-east-1" },
  { id: "al2", ref: "ALR-1245", ruleId: "ar2", serviceId: "s2", severity: "medium", status: "acknowledged", startedAt: "2026-07-01T22:42:00Z", acknowledgedAt: "2026-07-01T22:45:00Z", acknowledgedBy: "u15", message: "Invoice queue depth is 14,231 (threshold 10,000)", value: "14231", routedTo: "ep1", incidentId: "inc2", dedupKey: "invoice-queue-depth" },
  { id: "al3", ref: "ALR-1240", ruleId: "ar3", serviceId: "s3", severity: "low", status: "resolved", startedAt: "2026-07-01T14:02:00Z", acknowledgedAt: "2026-07-01T14:03:00Z", acknowledgedBy: "u4", resolvedAt: "2026-07-01T14:18:00Z", message: "Auth 401 rate is 3.2% (threshold 3%)", value: "3.2%", routedTo: "ep2", incidentId: "inc3", dedupKey: "auth-401-eu-west-1" },
  { id: "al4", ref: "ALR-1238", ruleId: "ar4", serviceId: "s8", severity: "medium", status: "acknowledged", startedAt: "2026-07-01T09:30:00Z", acknowledgedAt: "2026-07-01T09:35:00Z", acknowledgedBy: "u16", message: "Web LCP p95 is 2.7s (threshold 2.5s)", value: "2.7s", routedTo: "ep2", incidentId: "inc4", dedupKey: "web-lcp" },
  { id: "al5", ref: "ALR-1247", ruleId: "ar7", serviceId: "s1", severity: "medium", status: "firing", startedAt: "2026-07-02T04:55:00Z", message: "API Gateway p99 latency is 218ms (threshold 200ms)", value: "218ms", routedTo: "ep1", dedupKey: "api-gw-p99" },
  { id: "al6", ref: "ALR-1246", ruleId: "ar10", serviceId: "s1", severity: "low", status: "firing", startedAt: "2026-07-02T03:20:00Z", message: "Host db-replica-2 disk usage is 87% (threshold 85%)", value: "87%", routedTo: "ep1", dedupKey: "disk-db-replica-2" },
  { id: "al7", ref: "ALR-1244", ruleId: "ar7", serviceId: "s1", severity: "medium", status: "suppressed", startedAt: "2026-07-01T20:00:00Z", resolvedAt: "2026-07-01T20:18:00Z", message: "API Gateway p99 latency is 215ms (threshold 200ms)", value: "215ms", routedTo: "ep1", dedupKey: "api-gw-p99" },
];

// ============================================================================
// Deployments
// ============================================================================

export const deployments: Deployment[] = [
  { id: "d1", ref: "DEP-2024-118", serviceId: "s1", environment: "production", region: "us-east-1", status: "succeeded", strategy: "rolling", rolloutPercent: 100, version: "v3.8.2", commitSha: "a3f2c1b", commitMessage: "feat(gateway): add per-tenant rate limit overrides", authorId: "u2", approverIds: ["u1", "u3"], startedAt: "2026-06-30T14:22:00Z", completedAt: "2026-06-30T14:38:00Z", duration: 960, riskScore: 22, changesCount: 8, prIds: ["PR-4521", "PR-4525"], previousVersion: "v3.8.1", stages: [{ name: "build", status: "succeeded", startedAt: "2026-06-30T14:22:00Z", completedAt: "2026-06-30T14:25:00Z" }, { name: "test", status: "succeeded", startedAt: "2026-06-30T14:25:00Z", completedAt: "2026-06-30T14:30:00Z" }, { name: "deploy-canary", status: "succeeded", startedAt: "2026-06-30T14:30:00Z", completedAt: "2026-06-30T14:34:00Z" }, { name: "deploy-production", status: "succeeded", startedAt: "2026-06-30T14:34:00Z", completedAt: "2026-06-30T14:38:00Z" }], metrics: { errorRateBefore: 0.018, errorRateAfter: 0.017, p95LatencyBefore: 39, p95LatencyAfter: 38 }, incidentsTriggered: [] },
  { id: "d6", ref: "DEP-2024-122", serviceId: "s6", environment: "production", region: "us-east-1", status: "rolling_out", strategy: "canary", rolloutPercent: 25, version: "v2.4.1-rc1", commitSha: "8e7d2a1", commitMessage: "feat(checkout): new 3DS retry strategy with smart backoff", authorId: "u6", approverIds: ["u13", "u3"], startedAt: "2026-07-02T05:08:00Z", duration: 0, riskScore: 68, changesCount: 14, prIds: ["PR-4601", "PR-4602", "PR-4603"], previousVersion: "v2.4.0", stages: [{ name: "build", status: "succeeded", startedAt: "2026-07-02T05:08:00Z", completedAt: "2026-07-02T05:11:00Z" }, { name: "test", status: "succeeded", startedAt: "2026-07-02T05:11:00Z", completedAt: "2026-07-02T05:14:00Z" }, { name: "deploy-canary-25", status: "in_progress", startedAt: "2026-07-02T05:14:00Z" }, { name: "deploy-canary-50", status: "queued" }, { name: "deploy-canary-100", status: "queued" }], metrics: { errorRateBefore: 0.04, errorRateAfter: 1.4, p95LatencyBefore: 142, p95LatencyAfter: 312 }, incidentsTriggered: ["inc1"] },
  { id: "d2", ref: "DEP-2024-119", serviceId: "s2", environment: "production", region: "us-east-1", status: "succeeded", strategy: "rolling", rolloutPercent: 100, version: "v5.1.0", commitSha: "b4c3d2e", commitMessage: "feat(billing): add EU VAT rate schedule 2026", authorId: "u15", approverIds: ["u1"], startedAt: "2026-07-01T08:15:00Z", completedAt: "2026-07-01T08:32:00Z", duration: 1020, riskScore: 18, changesCount: 5, prIds: ["PR-4540"], previousVersion: "v5.0.4", stages: [{ name: "build", status: "succeeded", startedAt: "2026-07-01T08:15:00Z", completedAt: "2026-07-01T08:19:00Z" }, { name: "test", status: "succeeded", startedAt: "2026-07-01T08:19:00Z", completedAt: "2026-07-01T08:24:00Z" }, { name: "deploy-production", status: "succeeded", startedAt: "2026-07-01T08:24:00Z", completedAt: "2026-07-01T08:32:00Z" }], metrics: { errorRateBefore: 0.2, errorRateAfter: 0.21, p95LatencyBefore: 122, p95LatencyAfter: 124 }, incidentsTriggered: [] },
  { id: "d3", ref: "DEP-2024-117", serviceId: "s3", environment: "production", region: "us-east-1", status: "succeeded", strategy: "rolling", rolloutPercent: 100, version: "v1.6.0", commitSha: "c5d4e3f", commitMessage: "feat(auth): add WebAuthn support", authorId: "u4", approverIds: ["u3", "u1"], startedAt: "2026-06-29T19:40:00Z", completedAt: "2026-06-29T20:02:00Z", duration: 1320, riskScore: 35, changesCount: 22, prIds: ["PR-4501", "PR-4502"], previousVersion: "v1.5.4", stages: [{ name: "build", status: "succeeded", startedAt: "2026-06-29T19:40:00Z", completedAt: "2026-06-29T19:45:00Z" }, { name: "test", status: "succeeded", startedAt: "2026-06-29T19:45:00Z", completedAt: "2026-06-29T19:55:00Z" }, { name: "deploy-production", status: "succeeded", startedAt: "2026-06-29T19:55:00Z", completedAt: "2026-06-29T20:02:00Z" }], metrics: { errorRateBefore: 0.04, errorRateAfter: 0.04, p95LatencyBefore: 50, p95LatencyAfter: 52 }, incidentsTriggered: [] },
  { id: "d8", ref: "DEP-2024-121", serviceId: "s8", environment: "production", region: "global", status: "succeeded", strategy: "rolling", rolloutPercent: 100, version: "v4.2.0", commitSha: "d6e5f4a", commitMessage: "feat(web): new homepage hero design", authorId: "u16", approverIds: ["u1"], startedAt: "2026-07-01T13:45:00Z", completedAt: "2026-07-01T13:58:00Z", duration: 780, riskScore: 28, changesCount: 18, prIds: ["PR-4561", "PR-4562"], previousVersion: "v4.1.3", stages: [{ name: "build", status: "succeeded", startedAt: "2026-07-01T13:45:00Z", completedAt: "2026-07-01T13:48:00Z" }, { name: "test", status: "succeeded", startedAt: "2026-07-01T13:48:00Z", completedAt: "2026-07-01T13:52:00Z" }, { name: "deploy-production", status: "succeeded", startedAt: "2026-07-01T13:52:00Z", completedAt: "2026-07-01T13:58:00Z" }], metrics: { errorRateBefore: 0.12, errorRateAfter: 0.12, p95LatencyBefore: 180, p95LatencyAfter: 220 }, incidentsTriggered: ["inc4"] },
  { id: "d12", ref: "DEP-2024-115", serviceId: "s1", environment: "production", region: "us-east-1", status: "rolled_back", strategy: "canary", rolloutPercent: 10, version: "v3.8.0", commitSha: "e7f6a5b", commitMessage: "feat(gateway): add new connection pooling strategy", authorId: "u2", approverIds: ["u1", "u3"], startedAt: "2026-06-28T11:00:00Z", completedAt: "2026-06-28T11:22:00Z", duration: 1320, riskScore: 58, changesCount: 12, prIds: ["PR-4480"], previousVersion: "v3.7.9", stages: [{ name: "build", status: "succeeded" }, { name: "test", status: "succeeded" }, { name: "deploy-canary-10", status: "failed" }, { name: "rollback", status: "succeeded" }], metrics: { errorRateBefore: 0.017, errorRateAfter: 4.2, p95LatencyBefore: 39, p95LatencyAfter: 890 }, incidentsTriggered: [] },
];

export const changeRequests: ChangeRequest[] = [
  { id: "cr1", ref: "CR-2026-045", title: "Upgrade PostgreSQL 15 to 16", serviceId: "s4", type: "normal", risk: "high", status: "in_review", requesterId: "u3", approverIds: ["u1"], plannedAt: "2026-07-15T03:00:00Z", summary: "Major version upgrade with downtime window." },
  { id: "cr2", ref: "CR-2026-044", title: "Migrate auth-service to gRPC", serviceId: "s3", type: "normal", risk: "medium", status: "approved", requesterId: "u4", approverIds: ["u1", "u3"], plannedAt: "2026-07-10T05:00:00Z", summary: "Internal API migration from REST to gRPC." },
  { id: "cr3", ref: "CR-2026-043", title: "Rotate Vault root token", serviceId: "s9", type: "emergency", risk: "high", status: "implemented", requesterId: "u12", approverIds: ["u1"], plannedAt: "2026-06-25T09:00:00Z", summary: "Quarterly root token rotation." },
  { id: "cr4", ref: "CR-2026-042", title: "Add new Redis shard", serviceId: "s5", type: "standard", risk: "low", status: "implemented", requesterId: "u9", approverIds: ["u3"], plannedAt: "2026-06-22T11:00:00Z", summary: "Add shard 7 to Redis cluster." },
];

export const featureFlags: FeatureFlag[] = [
  { id: "ff1", key: "checkout.new_3ds_retry", name: "New 3DS Retry Strategy", description: "Enables smart backoff retry logic for 3DS challenges.", serviceId: "s6", enabled: true, rolloutPercent: 25, environments: ["production"], owner: "u6", createdAt: "2026-06-28T10:00:00Z", lastModified: "2026-07-02T05:08:00Z", variants: [{ name: "control", weight: 75 }, { name: "treatment", weight: 25 }] },
  { id: "ff2", key: "auth.webauthn", name: "WebAuthn Login", description: "Enables passkey-based authentication.", serviceId: "s3", enabled: true, rolloutPercent: 100, environments: ["production"], owner: "u4", createdAt: "2026-06-15T08:00:00Z", lastModified: "2026-06-29T19:55:00Z", variants: [{ name: "on", weight: 100 }] },
  { id: "ff3", key: "billing.eu_vat_2026", name: "EU VAT 2026 Schedule", description: "Uses new 2026 EU VAT rate schedule.", serviceId: "s2", enabled: true, rolloutPercent: 100, environments: ["production"], owner: "u15", createdAt: "2026-06-20T14:00:00Z", lastModified: "2026-07-01T08:32:00Z", variants: [{ name: "on", weight: 100 }] },
  { id: "ff4", key: "web.new_hero", name: "New Homepage Hero", description: "Displays the new homepage hero design.", serviceId: "s8", enabled: true, rolloutPercent: 100, environments: ["production"], owner: "u16", createdAt: "2026-06-25T16:00:00Z", lastModified: "2026-07-01T13:58:00Z", variants: [{ name: "on", weight: 100 }] },
];

// ============================================================================
// On-Call
// ============================================================================

export const escalationPolicies: EscalationPolicy[] = [
  { id: "ep1", name: "Platform - Standard", description: "Escalates from primary to secondary to manager over 30 minutes.", rounds: [{ delayMinutes: 0, targets: [{ type: "person", id: "u2" }] }, { delayMinutes: 15, targets: [{ type: "person", id: "u8" }] }, { delayMinutes: 30, targets: [{ type: "person", id: "u1" }] }], repeatCount: 1 },
  { id: "ep2", name: "Reliability - Standard", description: "Escalates from primary to secondary to manager over 30 minutes.", rounds: [{ delayMinutes: 0, targets: [{ type: "person", id: "u3" }] }, { delayMinutes: 15, targets: [{ type: "person", id: "u4" }] }, { delayMinutes: 30, targets: [{ type: "person", id: "u1" }] }], repeatCount: 1 },
  { id: "ep3", name: "Security - Critical", description: "Immediate security team escalation, manager at 5 minutes.", rounds: [{ delayMinutes: 0, targets: [{ type: "person", id: "u12" }, { type: "person", id: "u14" }] }, { delayMinutes: 5, targets: [{ type: "person", id: "u1" }] }], repeatCount: 2 },
];

export const onCallShifts: OnCallShift[] = [
  { id: "oc1", userId: "u5", teamId: "t2", role: "primary", start: "2026-07-02T00:00:00Z", end: "2026-07-02T12:00:00Z" },
  { id: "oc2", userId: "u11", teamId: "t2", role: "primary", start: "2026-07-02T12:00:00Z", end: "2026-07-03T00:00:00Z" },
  { id: "oc3", userId: "u10", teamId: "t1", role: "primary", start: "2026-07-02T00:00:00Z", end: "2026-07-02T08:00:00Z" },
  { id: "oc4", userId: "u8", teamId: "t1", role: "primary", start: "2026-07-02T08:00:00Z", end: "2026-07-02T20:00:00Z" },
  { id: "oc5", userId: "u15", teamId: "t1", role: "primary", start: "2026-07-02T20:00:00Z", end: "2026-07-03T08:00:00Z" },
  { id: "oc6", userId: "u7", teamId: "t3", role: "primary", start: "2026-07-02T00:00:00Z", end: "2026-07-02T12:00:00Z" },
  { id: "oc7", userId: "u6", teamId: "t3", role: "primary", start: "2026-07-02T12:00:00Z", end: "2026-07-03T00:00:00Z" },
  { id: "oc8", userId: "u14", teamId: "t5", role: "primary", start: "2026-07-02T00:00:00Z", end: "2026-07-03T00:00:00Z" },
];

// ============================================================================
// Infrastructure
// ============================================================================

export const hosts: Host[] = [
  { id: "h1", hostname: "api-gw-prod-us-east-1a-01", serviceId: "s1", environment: "production", region: "us-east-1", instanceType: "c6i.4xlarge", os: "Amazon Linux 2023", status: "running", cpuUsage: 42, memoryUsage: 58, diskUsage: 31, uptime: "42d 8h 14m", provider: "aws" },
  { id: "h2", hostname: "api-gw-prod-us-east-1b-02", serviceId: "s1", environment: "production", region: "us-east-1", instanceType: "c6i.4xlarge", os: "Amazon Linux 2023", status: "running", cpuUsage: 38, memoryUsage: 54, diskUsage: 30, uptime: "42d 8h 14m", provider: "aws" },
  { id: "h3", hostname: "checkout-prod-us-east-1a-01", serviceId: "s6", environment: "production", region: "us-east-1", instanceType: "m6i.2xlarge", os: "Ubuntu 22.04", status: "running", cpuUsage: 78, memoryUsage: 82, diskUsage: 45, uptime: "18d 3h 22m", provider: "aws" },
  { id: "h4", hostname: "checkout-prod-us-east-1b-02", serviceId: "s6", environment: "production", region: "us-east-1", instanceType: "m6i.2xlarge", os: "Ubuntu 22.04", status: "running", cpuUsage: 81, memoryUsage: 85, diskUsage: 47, uptime: "18d 3h 22m", provider: "aws" },
  { id: "h5", hostname: "db-primary-us-east-1a-01", serviceId: "s4", environment: "production", region: "us-east-1", instanceType: "r6i.8xlarge", os: "Amazon Linux 2023", status: "running", cpuUsage: 34, memoryUsage: 71, diskUsage: 67, uptime: "124d 11h 5m", provider: "aws" },
  { id: "h6", hostname: "db-replica-us-east-1b-02", serviceId: "s4", environment: "production", region: "us-east-1", instanceType: "r6i.8xlarge", os: "Amazon Linux 2023", status: "running", cpuUsage: 28, memoryUsage: 68, diskUsage: 87, uptime: "98d 4h 18m", provider: "aws" },
  { id: "h7", hostname: "auth-prod-eu-west-1a-01", serviceId: "s3", environment: "production", region: "eu-west-1", instanceType: "c6i.2xlarge", os: "Amazon Linux 2023", status: "running", cpuUsage: 45, memoryUsage: 51, diskUsage: 28, uptime: "67d 12h 41m", provider: "aws" },
  { id: "h8", hostname: "billing-prod-us-east-1a-01", serviceId: "s2", environment: "production", region: "us-east-1", instanceType: "m6i.xlarge", os: "Ubuntu 22.04", status: "running", cpuUsage: 56, memoryUsage: 64, diskUsage: 38, uptime: "29d 7h 11m", provider: "aws" },
  { id: "h9", hostname: "kafka-broker-01", serviceId: "s7", environment: "production", region: "us-east-1", instanceType: "r6i.4xlarge", os: "Amazon Linux 2023", status: "running", cpuUsage: 32, memoryUsage: 72, diskUsage: 58, uptime: "82d 14h 9m", provider: "aws" },
  { id: "h10", hostname: "redis-node-01", serviceId: "s5", environment: "production", region: "us-east-1", instanceType: "r6i.2xlarge", os: "Amazon Linux 2023", status: "running", cpuUsage: 22, memoryUsage: 76, diskUsage: 12, uptime: "115d 6h 28m", provider: "aws" },
];

export const k8sClusters: K8sCluster[] = [
  { id: "k1", name: "prod-us-east-1-primary", provider: "EKS", region: "us-east-1", version: "1.30", nodeCount: 48, podCount: 612, cpuUsage: 56, memoryUsage: 64, status: "healthy" },
  { id: "k2", name: "prod-eu-west-1-primary", provider: "EKS", region: "eu-west-1", version: "1.30", nodeCount: 32, podCount: 384, cpuUsage: 48, memoryUsage: 58, status: "healthy" },
  { id: "k3", name: "prod-ap-south-1-primary", provider: "EKS", region: "ap-south-1", version: "1.30", nodeCount: 18, podCount: 192, cpuUsage: 71, memoryUsage: 78, status: "warning" },
  { id: "k4", name: "staging-us-east-1", provider: "EKS", region: "us-east-1", version: "1.30", nodeCount: 8, podCount: 96, cpuUsage: 24, memoryUsage: 32, status: "healthy" },
];

// ============================================================================
// Errors
// ============================================================================

export const errors: ErrorGroup[] = [
  { id: "eg1", ref: "ERR-4821", message: "TypeError: Cannot read properties of undefined (reading 'amount')", type: "TypeError", stack: "at processCheckout (checkout.ts:142)\nat handleRequest (server.ts:78)\nat async middleware (router.ts:24)", serviceId: "s6", environment: "production", status: "unresolved", assigneeId: "u6", firstSeen: "2026-07-02T05:14:00Z", lastSeen: "2026-07-02T05:48:00Z", eventCount: 428, userCount: 312, releaseId: "v2.4.1-rc1", isRegression: true, sourceMapStatus: "ok", tags: ["checkout", "regression", "production"], trend: [0,0,2,8,24,48,84,128,182,228,294,356,402,428] },
  { id: "eg2", ref: "ERR-4820", message: "ConnectionTimeoutError: Redis connection timed out after 5000ms", type: "ConnectionTimeoutError", stack: "at RedisClient.connect (redis.js:88)\nat getCache (cache.ts:24)\nat fetchUser (user.ts:54)", serviceId: "s1", environment: "production", status: "unresolved", firstSeen: "2026-07-01T22:30:00Z", lastSeen: "2026-07-02T05:50:00Z", eventCount: 184, userCount: 0, isRegression: false, sourceMapStatus: "ok", tags: ["redis", "timeout", "production"], trend: [4,12,8,18,24,28,22,18,14,10,12,16,20,18] },
  { id: "eg3", ref: "ERR-4819", message: "ValidationError: Invalid email format in payload.email", type: "ValidationError", stack: "at validatePayload (validator.ts:42)\nat createUser (user.ts:18)", serviceId: "s3", environment: "production", status: "in_progress", assigneeId: "u4", firstSeen: "2026-06-28T14:00:00Z", lastSeen: "2026-07-02T05:45:00Z", eventCount: 1248, userCount: 856, isRegression: false, sourceMapStatus: "ok", tags: ["auth", "validation"], trend: [42,48,52,58,64,68,72,78,82,88,94,98,104,108] },
  { id: "eg4", ref: "ERR-4818", message: "OutOfMemoryError: JavaScript heap out of memory", type: "OutOfMemoryError", stack: "at processTicksAndRejections (node:internal/process/task_queues:96:5)", serviceId: "s8", environment: "production", status: "unresolved", assigneeId: "u16", firstSeen: "2026-07-01T14:00:00Z", lastSeen: "2026-07-02T05:40:00Z", eventCount: 12, userCount: 0, releaseId: "v4.2.0", isRegression: true, sourceMapStatus: "stale", tags: ["web", "memory", "regression"], trend: [0,0,0,1,2,1,2,1,1,0,1,0,1,0] },
  { id: "eg5", ref: "ERR-4817", message: "QueryTimeoutError: Postgres query timeout after 30s", type: "QueryTimeoutError", stack: "at Pool.query (pg.js:188)\nat getInvoices (invoice.ts:84)", serviceId: "s2", environment: "production", status: "resolved", assigneeId: "u15", firstSeen: "2026-07-01T22:00:00Z", lastSeen: "2026-07-02T01:30:00Z", eventCount: 84, userCount: 0, isRegression: false, sourceMapStatus: "ok", tags: ["billing", "postgres", "timeout"], trend: [12,18,24,18,12,8,4,2,0,0,0,0,0,0] },
];

// ============================================================================
// Security
// ============================================================================

export const vulnerabilities: Vulnerability[] = [
  { id: "v1", ref: "VULN-2026-045", cve: "CVE-2026-3141", title: "OpenSSL 3.2.1 Buffer Overflow", description: "A buffer overflow in OpenSSL 3.2.1 allows remote code execution via specially crafted X.509 certificates.", severity: "critical", cvss: 9.8, assetId: "h1", assetName: "api-gw-prod-us-east-1a-01", serviceId: "s1", status: "in_progress", discoveredAt: "2026-06-28T08:00:00Z", owner: "u12", remediation: "Upgrade to OpenSSL 3.2.2 or later." },
  { id: "v2", ref: "VULN-2026-044", cve: "CVE-2026-3140", title: "Log4j 2.17.0 Information Disclosure", description: "Log4j 2.17.0 has an information disclosure vulnerability in JDBC Appender.", severity: "high", cvss: 7.5, assetId: "h3", assetName: "checkout-prod-us-east-1a-01", serviceId: "s6", status: "open", discoveredAt: "2026-06-26T12:00:00Z", owner: "u6", remediation: "Upgrade to Log4j 2.17.1 or later." },
  { id: "v3", ref: "VULN-2026-043", cve: "CVE-2026-3139", title: "Node.js HTTP Request Smuggling", description: "Node.js 20.x is vulnerable to HTTP request smuggling via Content-Length parsing.", severity: "high", cvss: 7.4, assetId: "h8", assetName: "billing-prod-us-east-1a-01", serviceId: "s2", status: "patched", discoveredAt: "2026-06-22T14:00:00Z", patchedAt: "2026-06-24T10:00:00Z", owner: "u15", remediation: "Upgrade to Node.js 20.5.1 or later." },
  { id: "v4", ref: "VULN-2026-042", cve: "CVE-2026-3138", title: "PostgreSQL Privilege Escalation", description: "PostgreSQL 16.1 allows privilege escalation via crafted role assignment.", severity: "medium", cvss: 6.5, assetId: "h5", assetName: "db-primary-us-east-1a-01", serviceId: "s4", status: "open", discoveredAt: "2026-06-20T09:00:00Z", owner: "u3", remediation: "Upgrade to PostgreSQL 16.2 or later." },
  { id: "v5", ref: "VULN-2026-041", cve: "CVE-2026-3137", title: "Redis Lua Sandbox Bypass", description: "Redis 7.2.3 allows Lua sandbox bypass leading to RCE.", severity: "medium", cvss: 6.2, assetId: "h10", assetName: "redis-node-01", serviceId: "s5", status: "in_progress", discoveredAt: "2026-06-18T15:00:00Z", owner: "u9", remediation: "Upgrade to Redis 7.2.4 or later." },
];

export const auditEvents: AuditEvent[] = [
  { id: "a1", timestamp: "2026-07-02T05:48:00Z", actorId: "u6", action: "incident.update_public", resourceType: "incident", resourceId: "inc1", metadata: { audience: "public" }, ip: "10.42.18.92", result: "success" },
  { id: "a2", timestamp: "2026-07-02T05:38:00Z", actorId: "u6", action: "incident.link_runbook", resourceType: "incident", resourceId: "inc1", metadata: { runbook_id: "r8" }, ip: "10.42.18.92", result: "success" },
  { id: "a3", timestamp: "2026-07-02T05:22:00Z", actorId: "u6", action: "incident.add_service", resourceType: "incident", resourceId: "inc1", metadata: { service_id: "s6,s2" }, ip: "10.42.18.92", result: "success" },
  { id: "a4", timestamp: "2026-07-02T05:14:00Z", actorId: "u6", action: "incident.acknowledge", resourceType: "incident", resourceId: "inc1", metadata: {}, ip: "10.42.18.92", result: "success" },
  { id: "a5", timestamp: "2026-07-02T04:55:00Z", actorId: "u2", action: "alert.silence", resourceType: "alert", resourceId: "al5", metadata: { duration: "60m" }, ip: "10.42.18.14", result: "success" },
  { id: "a6", timestamp: "2026-07-02T03:20:00Z", actorId: "u3", action: "deployment.approve", resourceType: "deployment", resourceId: "d6", metadata: { version: "v2.4.1-rc1" }, ip: "10.42.18.31", result: "success" },
  { id: "a7", timestamp: "2026-07-01T22:45:00Z", actorId: "u15", action: "incident.acknowledge", resourceType: "incident", resourceId: "inc2", metadata: {}, ip: "10.42.18.65", result: "success" },
  { id: "a8", timestamp: "2026-07-01T20:18:00Z", actorId: "u2", action: "alert.suppress", resourceType: "alert_rule", resourceId: "ar7", metadata: { duration: "1h" }, ip: "10.42.18.14", result: "success" },
  { id: "a9", timestamp: "2026-07-01T18:20:00Z", actorId: "u16", action: "incident.update_internal", resourceType: "incident", resourceId: "inc4", metadata: {}, ip: "10.42.18.81", result: "success" },
  { id: "a10", timestamp: "2026-07-01T14:18:00Z", actorId: "u4", action: "incident.resolve", resourceType: "incident", resourceId: "inc3", metadata: { resolution: "JWKS cache purge" }, ip: "10.42.18.42", result: "success" },
  { id: "a11", timestamp: "2026-07-01T13:58:00Z", actorId: "u16", action: "deployment.complete", resourceType: "deployment", resourceId: "d8", metadata: { version: "v4.2.0" }, ip: "10.42.18.81", result: "success" },
  { id: "a12", timestamp: "2026-07-01T08:32:00Z", actorId: "u15", action: "deployment.complete", resourceType: "deployment", resourceId: "d2", metadata: { version: "v5.1.0" }, ip: "10.42.18.65", result: "success" },
];

// ============================================================================
// Admin
// ============================================================================

export const apiKeys: APIKey[] = [
  { id: "ak1", name: "CI/CD Pipeline", prefix: "sg_live_8f3a", scopes: ["deployments:write", "services:read"], createdBy: "u2", createdAt: "2026-01-15T10:00:00Z", lastUsed: "2026-07-02T05:14:00Z", expiresAt: "2027-01-15T10:00:00Z" },
  { id: "ak2", name: "Terraform Provisioner", prefix: "sg_live_2c9d", scopes: ["infrastructure:write", "hosts:write"], createdBy: "u3", createdAt: "2026-02-08T14:00:00Z", lastUsed: "2026-07-01T22:30:00Z", expiresAt: "2027-02-08T14:00:00Z" },
  { id: "ak3", name: "Datadog Integration", prefix: "sg_live_f1b7", scopes: ["metrics:read", "alerts:read"], createdBy: "u1", createdAt: "2026-01-20T09:00:00Z", lastUsed: "2026-07-02T05:50:00Z" },
  { id: "ak4", name: "Audit Log Export (revoked)", prefix: "sg_live_a4e2", scopes: ["audit:read"], createdBy: "u12", createdAt: "2026-03-10T11:00:00Z", lastUsed: "2026-05-15T14:00:00Z", revokedAt: "2026-06-01T09:00:00Z" },
];

export const webhooks: Webhook[] = [
  { id: "wh1", name: "Slack #incidents", url: "https://hooks.slack.com/services/T0/B0/xxx", events: ["incident.created", "incident.severity_changed", "incident.resolved"], enabled: true, secret: "whsec_***", lastDelivery: { timestamp: "2026-07-02T05:48:00Z", statusCode: 200, durationMs: 142 }, failureCount: 0, createdBy: "u1" },
  { id: "wh2", name: "PagerDuty Routing", url: "https://events.pagerduty.com/v2/enqueue", events: ["alert.firing", "alert.escalated"], enabled: true, secret: "whsec_***", lastDelivery: { timestamp: "2026-07-02T05:12:00Z", statusCode: 200, durationMs: 88 }, failureCount: 0, createdBy: "u3" },
  { id: "wh3", name: "Statuspage.io", url: "https://api.statuspage.io/v1/pages/xxx/incidents", events: ["incident.public_update", "incident.resolved"], enabled: true, secret: "whsec_***", lastDelivery: { timestamp: "2026-07-02T05:48:00Z", statusCode: 201, durationMs: 218 }, failureCount: 0, createdBy: "u1" },
  { id: "wh4", name: "Internal Analytics", url: "https://analytics.internal.sentinelgrid.io/ingest", events: ["*"], enabled: false, secret: "whsec_***", lastDelivery: { timestamp: "2026-06-15T08:00:00Z", statusCode: 500, durationMs: 5012 }, failureCount: 18, createdBy: "u1" },
];

export const integrations: Integration[] = [
  { id: "int1", type: "pagerduty", name: "PagerDuty", category: "Alerting", status: "connected", description: "Sync alerts, escalation policies, and on-call schedules with PagerDuty.", lastSyncAt: "2026-07-02T05:50:00Z", config: { subdomain: "sentinelgrid", service_id: "PD-1234" }, iconColor: "#06AC38" },
  { id: "int2", type: "slack", name: "Slack", category: "Communication", status: "connected", description: "Post incident updates, alert notifications, and on-call handoffs to Slack channels.", lastSyncAt: "2026-07-02T05:48:00Z", config: { workspace: "sentinelgrid", channels: "12" }, iconColor: "#4A154B" },
  { id: "int3", type: "datadog", name: "Datadog", category: "Observability", status: "connected", description: "Pull metrics, dashboards, and alerts from Datadog.", lastSyncAt: "2026-07-02T05:50:00Z", config: { site: "datadoghq.com", monitor_count: "142" }, iconColor: "#632CA6" },
  { id: "int4", type: "sentry", name: "Sentry", category: "Error Tracking", status: "connected", description: "Sync error groups, stack traces, and release health data.", lastSyncAt: "2026-07-02T05:45:00Z", config: { organization: "sentinelgrid", projects: "8" }, iconColor: "#362D59" },
  { id: "int5", type: "github", name: "GitHub", category: "Source Control", status: "connected", description: "Link deployments to commits, PRs, and changes.", lastSyncAt: "2026-07-02T05:14:00Z", config: { organization: "sentinelgrid", repos: "42" }, iconColor: "#181717" },
  { id: "int6", type: "gitlab", name: "GitLab", category: "Source Control", status: "disconnected", description: "Link deployments to commits and pipelines.", config: {}, iconColor: "#FC6D26" },
  { id: "int7", type: "jira", name: "Jira", category: "Project Tracking", status: "connected", description: "Sync postmortem action items with Jira issues.", lastSyncAt: "2026-07-02T05:00:00Z", config: { site: "sentinelgrid.atlassian.net", project: "OPS" }, iconColor: "#0052CC" },
  { id: "int8", type: "linear", name: "Linear", category: "Project Tracking", status: "disconnected", description: "Sync postmortem action items with Linear issues.", config: {}, iconColor: "#5E6AD2" },
  { id: "int9", type: "vercel", name: "Vercel", category: "Deployment", status: "connected", description: "Sync web-app deployments and preview environments.", lastSyncAt: "2026-07-01T13:58:00Z", config: { team: "sentinelgrid", project: "web-app" }, iconColor: "#000000" },
  { id: "int10", type: "aws_cloudwatch", name: "AWS CloudWatch", category: "Cloud Monitoring", status: "connected", description: "Pull metrics and alarms from AWS CloudWatch.", lastSyncAt: "2026-07-02T05:50:00Z", config: { region: "multi", accounts: "3" }, iconColor: "#FF4F8B" },
  { id: "int11", type: "gcp_monitoring", name: "GCP Monitoring", category: "Cloud Monitoring", status: "disconnected", description: "Pull metrics from Google Cloud Monitoring.", config: {}, iconColor: "#4285F4" },
  { id: "int12", type: "azure_monitor", name: "Azure Monitor", category: "Cloud Monitoring", status: "disconnected", description: "Pull metrics from Azure Monitor.", config: {}, iconColor: "#0078D4" },
  { id: "int13", type: "kubernetes", name: "Kubernetes", category: "Orchestration", status: "connected", description: "Sync clusters, workloads, and pod state.", lastSyncAt: "2026-07-02T05:50:00Z", config: { clusters: "4" }, iconColor: "#326CE5" },
  { id: "int14", type: "grafana", name: "Grafana", category: "Observability", status: "connected", description: "Embed Grafana dashboards and sync alert rules.", lastSyncAt: "2026-07-02T05:48:00Z", config: { url: "https://grafana.sentinelgrid.io", dashboards: "84" }, iconColor: "#F46800" },
  { id: "int15", type: "prometheus", name: "Prometheus", category: "Observability", status: "connected", description: "Query metrics and sync alert rules from Prometheus.", lastSyncAt: "2026-07-02T05:50:00Z", config: { url: "https://prom.sentinelgrid.io" }, iconColor: "#E6522C" },
  { id: "int16", type: "opsgenie", name: "Opsgenie", category: "Alerting", status: "disconnected", description: "Sync alerts and on-call schedules with Opsgenie.", config: {}, iconColor: "#172B4D" },
  { id: "int17", type: "statuspage", name: "Statuspage", category: "Communication", status: "connected", description: "Publish public status updates automatically.", lastSyncAt: "2026-07-02T05:48:00Z", config: { page_id: "sentinelgrid" }, iconColor: "#1A1A1A" },
];

// ============================================================================
// Observability samples (logs/traces - generated on demand)
// ============================================================================

export function sampleLogs(count = 50): LogEntry[] {
  const levels: LogEntry["level"][] = ["info", "info", "info", "warn", "error", "debug"];
  const messages = [
    "Request completed successfully",
    "Cache hit for user session",
    "Database query took 42ms",
    "Rate limit exceeded for client 10.42.18.x",
    "Authentication failed: invalid token",
    "Background job completed",
    "Connection pool exhausted, queueing request",
    "Retrying request after timeout",
    "Circuit breaker opened for upstream service",
    "Webhook delivery succeeded",
  ];
  const svcs = services.map((s) => s.id);
  const logs: LogEntry[] = [];
  const now = Date.now();
  for (let i = 0; i < count; i++) {
    const level = levels[Math.floor(Math.random() * levels.length)];
    const message = messages[Math.floor(Math.random() * messages.length)];
    const svc = svcs[Math.floor(Math.random() * svcs.length)];
    logs.push({
      id: `log${i}`,
      timestamp: new Date(now - i * 60000 + Math.floor(Math.random() * 30000)).toISOString(),
      serviceId: svc,
      level,
      message,
      traceId: Math.random() > 0.5 ? `trace_${Math.random().toString(36).slice(2, 14)}` : undefined,
      host: `host-${Math.floor(Math.random() * 8) + 1}`,
      fields: { method: "GET", path: "/api/v1/users", status: level === "error" ? "500" : "200" },
    });
  }
  return logs;
}

export function sampleTrace(): TraceSpan[] {
  const traceId = "trace_a3f2c1b8e7d2";
  const spans: TraceSpan[] = [
    { id: "sp1", traceId, name: "POST /api/v1/checkout", serviceId: "s1", startMs: 0, durationMs: 312, status: "ok", attributes: { "http.method": "POST", "http.url": "/api/v1/checkout" } },
    { id: "sp2", traceId, parentSpanId: "sp1", name: "auth.verify", serviceId: "s3", startMs: 4, durationMs: 18, status: "ok", attributes: { "auth.method": "Bearer" } },
    { id: "sp3", traceId, parentSpanId: "sp1", name: "checkout.process", serviceId: "s6", startMs: 28, durationMs: 248, status: "ok", attributes: { "checkout.id": "chk_8821" } },
    { id: "sp4", traceId, parentSpanId: "sp3", name: "ledger.append", serviceId: "s11", startMs: 48, durationMs: 84, status: "ok", attributes: { "ledger.entry": "led_9921" } },
    { id: "sp5", traceId, parentSpanId: "sp4", name: "postgres.insert", serviceId: "s4", startMs: 52, durationMs: 76, status: "ok", attributes: { "db.statement": "INSERT INTO ledger_entries..." } },
    { id: "sp6", traceId, parentSpanId: "sp3", name: "kafka.publish", serviceId: "s7", startMs: 140, durationMs: 12, status: "ok", attributes: { "kafka.topic": "payment.events" } },
    { id: "sp7", traceId, parentSpanId: "sp3", name: "redis.cache.set", serviceId: "s5", startMs: 156, durationMs: 4, status: "ok", attributes: { "cache.key": "checkout:chk_8821" } },
    { id: "sp8", traceId, parentSpanId: "sp1", name: "gateway.respond", serviceId: "s1", startMs: 308, durationMs: 4, status: "ok", attributes: { "http.status": "200" } },
  ];
  return spans;
}

// ============================================================================
// Uptime records (last 90 days, per service)
// ============================================================================

export function uptimeForService(serviceId: string, days = 90): UptimeRecord[] {
  const records: UptimeRecord[] = [];
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    const dayStr = date.toISOString().slice(0, 10);
    // Mostly 100% uptime, occasional 99.x
    const rand = Math.random();
    let uptime = 100;
    let incidents = 0;
    let downtime = 0;
    if (rand > 0.92) {
      incidents = 1;
      downtime = Math.floor(Math.random() * 600) + 60;
      uptime = 100 - (downtime / 86400) * 100;
    } else if (rand > 0.85) {
      incidents = 1;
      downtime = Math.floor(Math.random() * 60) + 5;
      uptime = 100 - (downtime / 86400) * 100;
    }
    records.push({ id: `up-${serviceId}-${dayStr}`, serviceId, date: dayStr, uptime, incidents, downtimeSeconds: downtime });
  }
  return records;
}

// ============================================================================
// Stats / Aggregates
// ============================================================================

export function dashboardStats() {
  return {
    activeIncidents: incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem").length,
    openAlerts: alerts.filter((a) => a.status === "firing").length,
    acknowledgedAlerts: alerts.filter((a) => a.status === "acknowledged").length,
    servicesTotal: services.length,
    servicesHealthy: services.filter((s) => s.health === "operational").length,
    servicesDegraded: services.filter((s) => s.health === "degraded" || s.health === "partial").length,
    slosTotal: slos.length,
    slosHealthy: slos.filter((s) => s.status === "healthy").length,
    slosBreached: slos.filter((s) => s.status === "breached").length,
    slosAtRisk: slos.filter((s) => s.status === "at_risk").length,
    mttr30d: 18.4, // minutes
    mttd30d: 4.2,  // minutes
    mtta30d: 3.8,  // minutes
    deploymentFreq: 14.2,
    changeFailureRate: 8.4,
    leadTimeHours: 26,
    errorBudgetConsumed: 38,
    onCallFatigueScore: 22,
    openVulnerabilities: vulnerabilities.filter((v) => v.status === "open" || v.status === "in_progress").length,
    auditEventsToday: auditEvents.length,
    apiKeysActive: apiKeys.filter((k) => !k.revokedAt).length,
    integrationsConnected: integrations.filter((i) => i.status === "connected").length,
  };
}

export function mttrTrend(): { date: string; mttr: number; mttd: number; mtta: number }[] {
  const out: { date: string; mttr: number; mttd: number; mtta: number }[] = [];
  const now = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    out.push({
      date: d.toISOString().slice(5, 10),
      mttr: 12 + Math.random() * 18,
      mttd: 2 + Math.random() * 6,
      mtta: 1.5 + Math.random() * 5,
    });
  }
  return out;
}

export function incidentVolumeTrend(): { date: string; critical: number; high: number; medium: number; low: number }[] {
  const out: { date: string; critical: number; high: number; medium: number; low: number }[] = [];
  const now = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    out.push({
      date: d.toISOString().slice(5, 10),
      critical: Math.floor(Math.random() * 2),
      high: Math.floor(Math.random() * 4) + 1,
      medium: Math.floor(Math.random() * 6) + 2,
      low: Math.floor(Math.random() * 8) + 3,
    });
  }
  return out;
}

export function deploymentFrequencyTrend(): { date: string; deployments: number; failures: number }[] {
  const out: { date: string; deployments: number; failures: number }[] = [];
  const now = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const deploys = Math.floor(Math.random() * 8) + 8;
    out.push({
      date: d.toISOString().slice(5, 10),
      deployments: deploys,
      failures: Math.floor(deploys * (0.05 + Math.random() * 0.1)),
    });
  }
  return out;
}

export function timeSeries(seed: number, points = 30, base = 50, variance = 20): { date: string; value: number }[] {
  const out: { date: string; value: number }[] = [];
  const now = new Date();
  let v = base;
  for (let i = points - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    v += (Math.sin(i * 0.4 + seed) * variance * 0.3) + (Math.random() - 0.5) * variance * 0.4;
    v = Math.max(0, v);
    out.push({ date: d.toISOString().slice(5, 10), value: Math.round(v * 10) / 10 });
  }
  return out;
}

export function multiTimeSeries(seed: number, points = 30, series: { name: string; base: number; variance: number }[]): Record<string, number | string>[] {
  const out: Record<string, number | string>[] = [];
  const now = new Date();
  const states = series.map((s) => s.base);
  for (let i = points - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const row: Record<string, number | string> = { date: d.toISOString().slice(5, 10) };
    series.forEach((s, idx) => {
      states[idx] += (Math.sin(i * 0.4 + seed + idx) * s.variance * 0.3) + (Math.random() - 0.5) * s.variance * 0.4;
      states[idx] = Math.max(0, states[idx]);
      row[s.name] = Math.round(states[idx] * 10) / 10;
    });
    out.push(row);
  }
  return out;
}

export const regions: Region[] = ["us-east-1","us-west-2","eu-west-1","eu-central-1","ap-south-1","ap-southeast-2","global"];
export const environments: EnvironmentName[] = ["production","staging","development","preview"];
