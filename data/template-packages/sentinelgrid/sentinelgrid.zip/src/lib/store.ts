"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

// ============================================================================
// Recently visited pages + favorites + saved views
// ============================================================================

interface RecentPage {
  href: string;
  title: string;
  visitedAt: number;
}

interface SavedFilter {
  id: string;
  page: string; // route path
  name: string;
  filters: Record<string, string>;
  createdAt: number;
}

interface UIState {
  // Sidebar
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (v: boolean) => void;
  toggleSidebar: () => void;

  // Mobile sidebar
  mobileSidebarOpen: boolean;
  setMobileSidebarOpen: (v: boolean) => void;

  // Right panel
  rightPanelOpen: boolean;
  setRightPanelOpen: (v: boolean) => void;

  // Command palette
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (v: boolean) => void;
  toggleCommandPalette: () => void;

  // Theme
  theme: "dark" | "light";
  setTheme: (t: "dark" | "light") => void;
  toggleTheme: () => void;

  // Environment switcher (persisted)
  activeEnvironment: string;
  setActiveEnvironment: (env: string) => void;

  // Region switcher
  activeRegion: string;
  setActiveRegion: (r: string) => void;

  // Time range
  timeRange: string;
  setTimeRange: (r: string) => void;

  // Recently visited
  recentPages: RecentPage[];
  pushRecent: (p: RecentPage) => void;
  clearRecent: () => void;

  // Favorites
  favorites: string[]; // hrefs
  toggleFavorite: (href: string) => void;
  isFavorite: (href: string) => boolean;

  // Saved filters
  savedFilters: SavedFilter[];
  saveFilter: (f: SavedFilter) => void;
  deleteFilter: (id: string) => void;

  // Density (for tables)
  density: "compact" | "normal" | "comfortable";
  setDensity: (d: "compact" | "normal" | "comfortable") => void;

  // Toast queue (Sonner handles this, but we track a counter for the header badge)
  unreadNotifications: number;
  setUnreadNotifications: (n: number) => void;
  decrementUnread: () => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set, get) => ({
      sidebarCollapsed: false,
      setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),

      mobileSidebarOpen: false,
      setMobileSidebarOpen: (v) => set({ mobileSidebarOpen: v }),

      rightPanelOpen: true,
      setRightPanelOpen: (v) => set({ rightPanelOpen: v }),

      commandPaletteOpen: false,
      setCommandPaletteOpen: (v) => set({ commandPaletteOpen: v }),
      toggleCommandPalette: () => set((s) => ({ commandPaletteOpen: !s.commandPaletteOpen })),

      theme: "dark",
      setTheme: (t) => set({ theme: t }),
      toggleTheme: () => set((s) => ({ theme: s.theme === "dark" ? "light" : "dark" })),

      activeEnvironment: "production",
      setActiveEnvironment: (env) => set({ activeEnvironment: env }),

      activeRegion: "us-east-1",
      setActiveRegion: (r) => set({ activeRegion: r }),

      timeRange: "24h",
      setTimeRange: (r) => set({ timeRange: r }),

      recentPages: [],
      pushRecent: (p) =>
        set((s) => {
          const filtered = s.recentPages.filter((r) => r.href !== p.href);
          return { recentPages: [{ ...p, visitedAt: Date.now() }, ...filtered].slice(0, 12) };
        }),
      clearRecent: () => set({ recentPages: [] }),

      favorites: [],
      toggleFavorite: (href) =>
        set((s) => ({
          favorites: s.favorites.includes(href)
            ? s.favorites.filter((f) => f !== href)
            : [...s.favorites, href],
        })),
      isFavorite: (href) => get().favorites.includes(href),

      savedFilters: [],
      saveFilter: (f) => set((s) => ({ savedFilters: [...s.savedFilters.filter((x) => x.id !== f.id), f] })),
      deleteFilter: (id) => set((s) => ({ savedFilters: s.savedFilters.filter((x) => x.id !== id) })),

      density: "normal",
      setDensity: (d) => set({ density: d }),

      unreadNotifications: 3,
      setUnreadNotifications: (n) => set({ unreadNotifications: n }),
      decrementUnread: () => set((s) => ({ unreadNotifications: Math.max(0, s.unreadNotifications - 1) })),
    }),
    {
      name: "sentinelgrid-ui",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        sidebarCollapsed: s.sidebarCollapsed,
        theme: s.theme,
        activeEnvironment: s.activeEnvironment,
        activeRegion: s.activeRegion,
        timeRange: s.timeRange,
        recentPages: s.recentPages,
        favorites: s.favorites,
        savedFilters: s.savedFilters,
        density: s.density,
      }),
    }
  )
);

// ============================================================================
// Local incident state (mock - for incident response workflow)
// ============================================================================

interface IncidentUIState {
  // Acknowledged alerts (by alert ref)
  acknowledgedAlerts: Set<string>;
  ackAlert: (ref: string) => void;
  // Resolved alerts
  resolvedAlerts: Set<string>;
  resolveAlert: (ref: string) => void;
  // Suppressed alerts
  suppressedAlerts: Set<string>;
  suppressAlert: (ref: string) => void;
}

// Zustand with Set is tricky; we'll use plain arrays in store and convert
interface IncidentUIStore {
  acknowledgedAlerts: string[];
  resolvedAlerts: string[];
  suppressedAlerts: string[];
  ackAlert: (ref: string) => void;
  resolveAlert: (ref: string) => void;
  suppressAlert: (ref: string) => void;
  isAcked: (ref: string) => boolean;
  isResolved: (ref: string) => boolean;
  isSuppressed: (ref: string) => boolean;
}

export const useIncidentStore = create<IncidentUIStore>((set, get) => ({
  acknowledgedAlerts: [],
  resolvedAlerts: [],
  suppressedAlerts: [],
  ackAlert: (ref) =>
    set((s) => ({
      acknowledgedAlerts: s.acknowledgedAlerts.includes(ref) ? s.acknowledgedAlerts : [...s.acknowledgedAlerts, ref],
    })),
  resolveAlert: (ref) =>
    set((s) => ({
      resolvedAlerts: s.resolvedAlerts.includes(ref) ? s.resolvedAlerts : [...s.resolvedAlerts, ref],
    })),
  suppressAlert: (ref) =>
    set((s) => ({
      suppressedAlerts: s.suppressedAlerts.includes(ref) ? s.suppressedAlerts : [...s.suppressedAlerts, ref],
    })),
  isAcked: (ref) => get().acknowledgedAlerts.includes(ref),
  isResolved: (ref) => get().resolvedAlerts.includes(ref),
  isSuppressed: (ref) => get().suppressedAlerts.includes(ref),
}));
