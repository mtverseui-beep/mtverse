import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";
import { CommandPalette } from "@/components/layout/command-palette";
import { UIStoreHydration } from "@/components/layout/ui-store-hydration";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "SentinelGrid - Engineering Operations Console",
    template: "%s - SentinelGrid",
  },
  description:
    "SentinelGrid is a premium engineering operations, observability, SRE, incident management, and reliability dashboard for modern platform teams.",
  keywords: [
    "SentinelGrid",
    "SRE",
    "DevOps",
    "Incident Management",
    "Observability",
    "Reliability",
    "On-Call",
    "SLO",
    "Error Budget",
  ],
  authors: [{ name: "SentinelGrid" }],
  applicationName: "SentinelGrid",
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
    ],
    shortcut: ["/icon.svg"],
    apple: ["/icon.svg"],
  },
  openGraph: {
    title: "SentinelGrid - Engineering Operations Console",
    description:
      "Premium engineering operations, observability, SRE, incident management, and reliability dashboard for modern platform teams.",
    siteName: "SentinelGrid",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SentinelGrid",
    description:
      "Premium engineering operations, observability, SRE, incident management, and reliability dashboard.",
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#0A0B0F" },
    { media: "(prefers-color-scheme: light)", color: "#FAFAFB" },
  ],
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                const stored = localStorage.getItem('sentinelgrid-theme');
                const theme = stored || 'dark';
                if (theme === 'dark') document.documentElement.classList.add('dark');
                else document.documentElement.classList.remove('dark');
              } catch (_) {
                document.documentElement.classList.add('dark');
              }
            `,
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider>
          <UIStoreHydration />
          {children}
          <CommandPalette />
          <Toaster />
          <SonnerToaster position="bottom-right" />
        </ThemeProvider>
      </body>
    </html>
  );
}
