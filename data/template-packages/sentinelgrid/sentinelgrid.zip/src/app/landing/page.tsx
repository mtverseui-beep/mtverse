"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  ArrowRight, Siren, Target, Phone, Rocket, Activity, ShieldAlert,
  CheckCircle2, Star, Menu, X,
} from "lucide-react";

const navLinks = [
  { label: "Features", href: "/features" },
  { label: "Preview", href: "/preview" },
  { label: "Components", href: "/components-preview" },
  { label: "Pricing", href: "/pricing" },
  { label: "Docs", href: "/docs" },
];

const features = [
  { icon: Siren, title: "Incident Command", description: "Run war rooms, manage timelines, and broadcast status updates from a single command center." },
  { icon: Target, title: "SLO Tracking", description: "Define error budgets, monitor burn rate, and get alerted before reliability slips." },
  { icon: Phone, title: "On-Call Management", description: "Build fair rotations, schedule handoffs, and page the right engineer at 3am." },
  { icon: Rocket, title: "Deployment Safety", description: "Approve changes, watch canaries, and roll back instantly when things go wrong." },
  { icon: Activity, title: "Observability", description: "Dashboards for latency, throughput, error rate, and web vitals out of the box." },
  { icon: ShieldAlert, title: "Security Operations", description: "Vulnerability tracking, compliance posture, audit trails, and access reviews." },
];

const stats = [
  { value: "100+", label: "Production routes" },
  { value: "50+", label: "Integrations" },
  { value: "99.99%", label: "Uptime SLA" },
  { value: "14", label: "Chart types" },
];

const logoCloud = ["Northwind", "Acme Corp", "Globex", "Initech", "Umbrella", "Stark", "Wayne", "Cyberdyne"];

const testimonials = [
  {
    quote: "SentinelGrid replaced three internal tools. Our MTTR dropped 40% in the first quarter.",
    name: "Maya Okonkwo",
    title: "Director, Platform Engineering",
    initials: "MO",
  },
  {
    quote: "The SLO and error-budget views are exactly what we needed to have productive conversations with product.",
    name: "Daniel Vargas",
    title: "Staff SRE",
    initials: "DV",
  },
  {
    quote: "We shipped our internal reliability console in two weeks instead of two quarters. Worth every dollar.",
    name: "Priya Raman",
    title: "Senior SRE",
    initials: "PR",
  },
];

const tiers = [
  {
    name: "Starter",
    price: "$49",
    period: "/mo",
    description: "For small teams getting started with reliability.",
    features: ["Up to 5 developers", "All 100+ pages", "Email support", "1-year of updates", "Dark + light themes"],
    cta: "Get Started",
    href: "/pricing",
    highlighted: false,
  },
  {
    name: "Pro",
    price: "$199",
    period: "/mo",
    description: "For growing engineering orgs that need priority support.",
    features: ["Up to 25 developers", "All 100+ pages", "Priority support (4h SLA)", "1-year of updates", "Slack community", "Custom branding"],
    cta: "Get Started",
    href: "/pricing",
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    description: "For large orgs with custom requirements.",
    features: ["Unlimited developers", "All 100+ pages", "24/7 priority support", "Lifetime updates", "Source code access", "Custom license terms"],
    cta: "Contact Sales",
    href: "/pricing",
    highlighted: false,
  },
];

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border-subtle bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <Link href="/landing" className="flex items-center gap-2">
            <svg viewBox="0 0 32 32" className="w-7 h-7" fill="none">
              <defs>
                <linearGradient id="nav-logo" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M16 2 L28 8 V18 C28 25 22 29 16 30 C10 29 4 25 4 18 V8 Z" fill="url(#nav-logo)" fillOpacity="0.16" stroke="url(#nav-logo)" strokeWidth="1.6" strokeLinejoin="round" />
              <path d="M10 13 H22 M10 16 H22 M10 19 H22" stroke="url(#nav-logo)" strokeWidth="1.4" strokeLinecap="round" />
              <path d="M14 9 V23 M18 9 V23" stroke="url(#nav-logo)" strokeWidth="1.2" strokeLinecap="round" strokeOpacity="0.55" />
              <circle cx="16" cy="16" r="1.8" fill="#22D3EE" />
            </svg>
            <span className="font-semibold text-lg tracking-tight">SentinelGrid</span>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-muted/60"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
            <Button asChild variant="ghost" size="sm">
              <Link href="/sign-in">Sign in</Link>
            </Button>
            <Button asChild size="sm" className="gap-1.5">
              <Link href="/dashboard">Get Started <ArrowRight className="w-3.5 h-3.5" /></Link>
            </Button>
          </div>

          <button
            className="md:hidden p-2 -mr-2 text-muted-foreground"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border-subtle bg-background px-4 py-4 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block px-3 py-2 text-sm text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/60"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-3 mt-3 border-t border-border-subtle flex gap-2">
              <Button asChild variant="outline" size="sm" className="flex-1">
                <Link href="/sign-in">Sign in</Link>
              </Button>
              <Button asChild size="sm" className="flex-1">
                <Link href="/dashboard">Get Started</Link>
              </Button>
            </div>
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-50" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/20 rounded-full blur-3xl opacity-20" />

        <div className="relative max-w-7xl mx-auto px-4 md:px-6 py-20 md:py-32 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/5 text-xs text-primary mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-status-pulse" />
            v1.0 released — 100+ production routes
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight text-balance">
            Engineering Operations, <br className="hidden sm:block" />
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Perfected</span>
          </h1>

          <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            The premium Next.js 16 dashboard template for incident response, SRE, observability, and reliability. Ship your engineering console in days, not quarters.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Button asChild size="lg" className="gap-2 w-full sm:w-auto">
              <Link href="/dashboard">Get Started <ArrowRight className="w-4 h-4" /></Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
              <Link href="/dashboard">Live Demo</Link>
            </Button>
          </div>

          <div className="mt-6 flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <CheckCircle2 className="w-3.5 h-3.5 text-success" />
            <span>No credit card required</span>
            <span className="mx-1">·</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-success" />
            <span>14-day refund</span>
          </div>
        </div>
      </section>

      {/* Logo cloud */}
      <section className="py-12 border-y border-border-subtle bg-muted/20">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <p className="text-center text-xs uppercase tracking-wider text-muted-foreground mb-6">
            Trusted by engineering teams at
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-4 md:gap-x-12">
            {logoCloud.map((name) => (
              <span key={name} className="text-base md:text-lg font-semibold text-muted-foreground/60 hover:text-muted-foreground transition-colors">
                {name}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary mb-2">Everything you need</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">A complete engineering operations platform</h2>
            <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">
              Six pillars of reliability work, all in one cohesive design system. No more stitching together six SaaS tools.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((feature) => (
              <Card key={feature.title} className="p-6 hover:bg-elevated/40 hover:border-primary/30 transition-all group">
                <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary mb-4 group-hover:scale-110 transition-transform">
                  <feature.icon className="w-5 h-5" />
                </div>
                <h3 className="text-base font-semibold">{feature.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats band */}
      <section className="py-16 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5 border-y border-border-subtle">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-3xl md:text-5xl font-bold tracking-tight bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  {stat.value}
                </p>
                <p className="mt-1 text-xs md:text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Product preview */}
      <section className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary mb-2">See it in action</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Built for the way teams actually work</h2>
          </div>
          <Card className="p-2 overflow-hidden bg-elevated/40 border-primary/20 shadow-2xl">
            <div className="rounded-lg overflow-hidden bg-background border border-border-subtle">
              {/* Mock browser chrome */}
              <div className="flex items-center gap-2 px-4 py-3 border-b border-border-subtle bg-muted/30">
                <div className="flex gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-destructive/60" />
                  <span className="w-3 h-3 rounded-full bg-warning/60" />
                  <span className="w-3 h-3 rounded-full bg-success/60" />
                </div>
                <div className="flex-1 max-w-md mx-auto px-3 py-1 rounded-md bg-muted text-[11px] text-muted-foreground text-center font-mono">
                  sentinelgrid.io/dashboard
                </div>
              </div>
              {/* Mock dashboard preview */}
              <div className="p-6 bg-grid">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  {[
                    { label: "Active Incidents", value: "3", color: "text-destructive" },
                    { label: "Uptime", value: "99.97%", color: "text-success" },
                    { label: "MTTR", value: "18m", color: "text-warning" },
                    { label: "SLOs Healthy", value: "42/47", color: "text-primary" },
                  ].map((kpi) => (
                    <div key={kpi.label} className="p-4 rounded-lg border border-border bg-card">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{kpi.label}</p>
                      <p className={`text-2xl font-bold mt-1 ${kpi.color}`}>{kpi.value}</p>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-2 p-4 rounded-lg border border-border bg-card h-48 flex items-end gap-1">
                    {[40, 65, 50, 80, 70, 95, 60, 75, 90, 55, 70, 85, 60, 80].map((h, i) => (
                      <div key={i} className="flex-1 bg-gradient-to-t from-primary/40 to-primary rounded-t-sm" style={{ height: `${h}%` }} />
                    ))}
                  </div>
                  <div className="p-4 rounded-lg border border-border bg-card h-48 flex items-center justify-center">
                    <div className="w-32 h-32 rounded-full border-8 border-primary/20 border-t-primary animate-spin" style={{ animationDuration: "3s" }} />
                  </div>
                </div>
              </div>
            </div>
          </Card>
          <div className="text-center mt-6">
            <Button asChild variant="outline" size="lg" className="gap-2">
              <Link href="/preview">Explore all 100+ pages <ArrowRight className="w-4 h-4" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 md:py-28 bg-muted/20 border-y border-border-subtle">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary mb-2">Loved by engineers</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">What teams are saying</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {testimonials.map((t) => (
              <Card key={t.name} className="p-6">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-sm leading-relaxed text-foreground">&ldquo;{t.quote}&rdquo;</p>
                <div className="mt-4 pt-4 border-t border-border-subtle flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-xs font-semibold text-background">
                    {t.initials}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.title}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing preview */}
      <section className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <p className="text-sm font-semibold uppercase tracking-wider text-primary mb-2">Simple pricing</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">One-time purchase, lifetime use</h2>
            <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">
              Buy once, build unlimited products. Updates included for the subscription period.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl mx-auto">
            {tiers.map((tier) => (
              <Card
                key={tier.name}
                className={`p-6 relative ${tier.highlighted ? "border-primary/40 bg-primary/5 shadow-lg shadow-primary/10" : ""}`}
              >
                {tier.highlighted && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold uppercase tracking-wider">
                    Most popular
                  </div>
                )}
                <h3 className="text-lg font-semibold">{tier.name}</h3>
                <p className="text-xs text-muted-foreground mt-1 min-h-[2.5rem]">{tier.description}</p>
                <div className="mt-4 flex items-baseline gap-1">
                  <span className="text-3xl font-bold tracking-tight">{tier.price}</span>
                  <span className="text-sm text-muted-foreground">{tier.period}</span>
                </div>
                <ul className="mt-4 space-y-2">
                  {tier.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-xs text-muted-foreground">
                      <CheckCircle2 className="w-3.5 h-3.5 text-success mt-0.5 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button asChild className="w-full mt-6" variant={tier.highlighted ? "default" : "outline"}>
                  <Link href={tier.href}>{tier.cta}</Link>
                </Button>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button asChild variant="link" size="sm" className="gap-1">
              <Link href="/pricing">See full pricing comparison <ArrowRight className="w-3.5 h-3.5" /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <Card className="relative overflow-hidden p-10 md:p-16 text-center bg-gradient-to-br from-primary/10 via-accent/10 to-primary/10 border-primary/20">
            <div className="absolute inset-0 bg-grid opacity-30" />
            <div className="relative space-y-6">
              <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-balance">
                Ship your engineering console this week.
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Stop building dashboards from scratch. Start with 100+ production routes, 14 chart types, and a design system your team will love.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <Button asChild size="lg" className="gap-2 w-full sm:w-auto">
                  <Link href="/dashboard">Get Started <ArrowRight className="w-4 h-4" /></Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
                  <Link href="/docs">Read the docs</Link>
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border-subtle bg-muted/20 mt-auto">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-12">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            <div className="col-span-2">
              <Link href="/landing" className="flex items-center gap-2 mb-3">
                <svg viewBox="0 0 32 32" className="w-6 h-6" fill="none">
                  <defs>
                    <linearGradient id="footer-logo" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                      <stop stopColor="#22D3EE" />
                      <stop offset="1" stopColor="#A78BFA" />
                    </linearGradient>
                  </defs>
                  <path d="M16 2 L28 8 V18 C28 25 22 29 16 30 C10 29 4 25 4 18 V8 Z" fill="url(#footer-logo)" fillOpacity="0.16" stroke="url(#footer-logo)" strokeWidth="1.6" strokeLinejoin="round" />
                  <circle cx="16" cy="16" r="1.8" fill="#22D3EE" />
                </svg>
                <span className="font-semibold">SentinelGrid</span>
              </Link>
              <p className="text-sm text-muted-foreground max-w-xs">
                The premium engineering operations dashboard template. Built with Next.js 16, TypeScript, and shadcn/ui.
              </p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-3">Product</p>
              <ul className="space-y-2">
                <li><Link href="/features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Features</Link></li>
                <li><Link href="/preview" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Preview</Link></li>
                <li><Link href="/components-preview" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Components</Link></li>
                <li><Link href="/pricing" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Pricing</Link></li>
              </ul>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-3">Docs</p>
              <ul className="space-y-2">
                <li><Link href="/docs" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Overview</Link></li>
                <li><Link href="/docs/getting-started" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Getting Started</Link></li>
                <li><Link href="/docs/changelog" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Changelog</Link></li>
                <li><Link href="/docs/license" className="text-sm text-muted-foreground hover:text-foreground transition-colors">License</Link></li>
              </ul>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-3">Support</p>
              <ul className="space-y-2">
                <li><Link href="/docs/support" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Contact</Link></li>
                <li><a href="mailto:support@sentinelgrid.io" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Email</a></li>
                <li><Link href="/sign-in" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Sign in</Link></li>
                <li><Link href="/sign-up" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Sign up</Link></li>
              </ul>
            </div>
          </div>
          <div className="mt-10 pt-6 border-t border-border-subtle flex flex-col md:flex-row items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">© 2024 SentinelGrid, Inc. All rights reserved.</p>
            <div className="flex gap-4 text-xs text-muted-foreground">
              <Link href="/docs/license" className="hover:text-foreground transition-colors">License</Link>
              <Link href="/docs/support" className="hover:text-foreground transition-colors">Support</Link>
              <Link href="/docs/changelog" className="hover:text-foreground transition-colors">Changelog</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
