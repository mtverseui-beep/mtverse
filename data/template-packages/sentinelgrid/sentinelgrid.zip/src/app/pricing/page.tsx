"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Check, X, ArrowRight, Menu, Sparkles } from "lucide-react";

const navLinks = [
  { label: "Features", href: "/features" },
  { label: "Preview", href: "/preview" },
  { label: "Components", href: "/components-preview" },
  { label: "Pricing", href: "/pricing" },
  { label: "Docs", href: "/docs" },
];

const tiers = [
  {
    name: "Starter",
    price: 49,
    period: "/mo",
    description: "For small teams getting started with reliability tooling.",
    features: [
      "Up to 5 developers",
      "All 100+ pages",
      "Dark + light themes",
      "Email support (1 business day)",
      "1 year of updates",
      "Use in unlimited products",
    ],
    cta: "Get Started",
    href: "/sign-up",
    highlighted: false,
  },
  {
    name: "Pro",
    price: 199,
    period: "/mo",
    description: "For growing engineering orgs that need priority support.",
    features: [
      "Up to 25 developers",
      "Everything in Starter",
      "Priority support (4h SLA)",
      "Slack community access",
      "Custom branding",
      "Source code access",
      "1 year of updates",
    ],
    cta: "Get Started",
    href: "/sign-up",
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: null,
    period: "",
    description: "For large orgs with custom requirements.",
    features: [
      "Unlimited developers",
      "Everything in Pro",
      "24/7 priority support (1h SLA)",
      "Lifetime updates",
      "Custom license terms",
      "Dedicated engineer",
      "On-prem deployment option",
    ],
    cta: "Contact Sales",
    href: "/docs/support",
    highlighted: false,
  },
];

const comparisonRows = [
  { category: "Core", feature: "All 100+ pages", starter: true, pro: true, enterprise: true },
  { category: "Core", feature: "Dark + light themes", starter: true, pro: true, enterprise: true },
  { category: "Core", feature: "Source code access", starter: false, pro: true, enterprise: true },
  { category: "Core", feature: "Use in unlimited products", starter: true, pro: true, enterprise: true },
  { category: "Core", feature: "Custom branding", starter: false, pro: true, enterprise: true },
  { category: "Developers", feature: "Licensed developers", starter: "5", pro: "25", enterprise: "Unlimited" },
  { category: "Support", feature: "Email support", starter: "1 business day", pro: "4h SLA", enterprise: "1h SLA" },
  { category: "Support", feature: "Slack community", starter: false, pro: true, enterprise: true },
  { category: "Support", feature: "Dedicated engineer", starter: false, pro: false, enterprise: true },
  { category: "Support", feature: "24/7 coverage", starter: false, pro: false, enterprise: true },
  { category: "Updates", feature: "Update period", starter: "1 year", pro: "1 year", enterprise: "Lifetime" },
  { category: "Updates", feature: "On-prem deployment", starter: false, pro: false, enterprise: true },
];

const faqs = [
  { q: "Is there a one-time purchase option?", a: "Yes. All tiers are billed annually, which works out to a one-time payment per year. You retain perpetual usage rights for the version you have at the end of your subscription." },
  { q: "What counts as a developer?", a: "A developer is anyone on your team who writes or modifies code in the SentinelGrid codebase. Designers, product managers, and QA engineers do not count toward the seat limit." },
  { q: "Can I upgrade or downgrade later?", a: "Yes. Upgrade anytime and we prorate the difference. Downgrade at the end of your current billing cycle." },
  { q: "Do you offer refunds?", a: "Yes. If SentinelGrid does not meet your needs, contact support within 14 days of purchase for a full refund." },
  { q: "What payment methods do you accept?", a: "All major credit cards, PayPal, and bank transfer for Enterprise plans." },
  { q: "Can I get an invoice?", a: "Yes. Add your company details during checkout and we email a VAT-compliant invoice. Enterprise customers can pay by PO." },
];

function Cell({ value }: { value: boolean | string }) {
  if (typeof value === "boolean") {
    return value ? (
      <Check className="w-4 h-4 text-success mx-auto" />
    ) : (
      <X className="w-4 h-4 text-muted-foreground/40 mx-auto" />
    );
  }
  return <span className="text-xs text-muted-foreground text-center block">{value}</span>;
}

export default function PricingPage() {
  const [annual, setAnnual] = React.useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border-subtle bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <Link href="/landing" className="flex items-center gap-2">
            <svg viewBox="0 0 32 32" className="w-7 h-7" fill="none">
              <defs>
                <linearGradient id="nav-logo-price" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M16 2 L28 8 V18 C28 25 22 29 16 30 C10 29 4 25 4 18 V8 Z" fill="url(#nav-logo-price)" fillOpacity="0.16" stroke="url(#nav-logo-price)" strokeWidth="1.6" strokeLinejoin="round" />
              <circle cx="16" cy="16" r="1.8" fill="#22D3EE" />
            </svg>
            <span className="font-semibold text-lg tracking-tight">SentinelGrid</span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} className={`px-3 py-2 text-sm rounded-md transition-colors ${link.href === "/pricing" ? "text-foreground bg-muted/60" : "text-muted-foreground hover:text-foreground hover:bg-muted/60"}`}>
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="hidden md:flex items-center gap-2">
            <Button asChild variant="ghost" size="sm"><Link href="/sign-in">Sign in</Link></Button>
            <Button asChild size="sm" className="gap-1.5"><Link href="/dashboard">Get Started <ArrowRight className="w-3.5 h-3.5" /></Link></Button>
          </div>
          <button className="md:hidden p-2 -mr-2 text-muted-foreground" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label="Toggle menu">
            {mobileMenuOpen ? <Menu className="w-5 h-5 rotate-90" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden py-16 md:py-20 border-b border-border-subtle">
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-primary/20 rounded-full blur-3xl opacity-20" />
        <div className="relative max-w-4xl mx-auto px-4 md:px-6 text-center">
          <Badge className="mb-4 bg-primary/15 text-primary border-primary/30">
            <Sparkles className="w-3 h-3 mr-1" /> Simple, transparent pricing
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-balance">
            One purchase. <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Unlimited products.</span>
          </h1>
          <p className="mt-5 text-lg text-muted-foreground text-pretty">
            Buy SentinelGrid once and use it in as many commercial products as you want. Updates and support are included for the subscription period.
          </p>

          {/* Billing toggle */}
          <div className="mt-8 inline-flex items-center gap-3 p-1 rounded-full border border-border bg-muted/30">
            <button
              onClick={() => setAnnual(false)}
              className={`px-4 py-1.5 rounded-full text-xs font-medium transition-colors ${!annual ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}
            >
              Monthly
            </button>
            <button
              onClick={() => setAnnual(true)}
              className={`px-4 py-1.5 rounded-full text-xs font-medium transition-colors flex items-center gap-1.5 ${annual ? "bg-background text-foreground shadow-sm" : "text-muted-foreground"}`}
            >
              Annual
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-success/15 text-success">Save 20%</span>
            </button>
          </div>
        </div>
      </section>

      {/* Tier cards */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {tiers.map((tier) => {
              const monthly = tier.price === null ? null : annual ? Math.round(tier.price * 0.8) : tier.price;
              return (
                <Card
                  key={tier.name}
                  className={`p-6 relative flex flex-col ${tier.highlighted ? "border-primary/40 bg-primary/5 shadow-lg shadow-primary/10 md:scale-105" : ""}`}
                >
                  {tier.highlighted && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold uppercase tracking-wider whitespace-nowrap">
                      Most popular
                    </div>
                  )}
                  <h3 className="text-lg font-semibold">{tier.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1 min-h-[2.5rem]">{tier.description}</p>
                  <div className="mt-5 flex items-baseline gap-1">
                    {monthly === null ? (
                      <span className="text-4xl font-bold tracking-tight">Custom</span>
                    ) : (
                      <>
                        <span className="text-4xl font-bold tracking-tight">${monthly}</span>
                        <span className="text-sm text-muted-foreground">/mo</span>
                      </>
                    )}
                  </div>
                  {annual && monthly !== null && tier.price !== null && (
                    <p className="text-[11px] text-muted-foreground mt-1">
                      Billed ${monthly * 12}/year (was ${tier.price * 12})
                    </p>
                  )}
                  <ul className="mt-5 space-y-2.5 flex-1">
                    {tier.features.map((f) => (
                      <li key={f} className="flex items-start gap-2 text-xs text-muted-foreground">
                        <Check className="w-3.5 h-3.5 text-success mt-0.5 shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Button asChild className="w-full mt-6" variant={tier.highlighted ? "default" : "outline"}>
                    <Link href={tier.href}>{tier.cta}</Link>
                  </Button>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Comparison table */}
      <section className="py-16 border-t border-border-subtle bg-muted/20">
        <div className="max-w-5xl mx-auto px-4 md:px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Compare plans</h2>
            <p className="mt-2 text-sm text-muted-foreground">Every feature, side by side.</p>
          </div>
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40">
                  <tr className="border-b border-border">
                    <th className="text-left px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Feature</th>
                    <th className="text-center px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Starter</th>
                    <th className="text-center px-4 py-3 text-xs uppercase tracking-wider text-primary font-semibold bg-primary/5">Pro</th>
                    <th className="text-center px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">Enterprise</th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonRows.map((row, i) => {
                    const showCategory = i === 0 || comparisonRows[i - 1].category !== row.category;
                    return (
                      <tr key={i} className="border-b border-border-subtle last:border-0 hover:bg-muted/30">
                        <td className="px-4 py-3">
                          {showCategory && <p className="text-[10px] uppercase tracking-wider text-primary font-semibold mb-0.5">{row.category}</p>}
                          <span className="text-sm">{row.feature}</span>
                        </td>
                        <td className="px-4 py-3 text-center"><Cell value={row.starter} /></td>
                        <td className="px-4 py-3 text-center bg-primary/5"><Cell value={row.pro} /></td>
                        <td className="px-4 py-3 text-center"><Cell value={row.enterprise} /></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16">
        <div className="max-w-3xl mx-auto px-4 md:px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Frequently asked questions</h2>
            <p className="mt-2 text-sm text-muted-foreground">Everything you need to know before you buy.</p>
          </div>
          <Accordion type="single" collapsible>
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`item-${i}`}>
                <AccordionTrigger className="text-sm font-medium text-left">{faq.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">{faq.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 border-t border-border-subtle">
        <div className="max-w-4xl mx-auto px-4 md:px-6">
          <Card className="relative overflow-hidden p-10 md:p-14 text-center bg-gradient-to-br from-primary/10 via-accent/10 to-primary/10 border-primary/20">
            <div className="absolute inset-0 bg-grid opacity-30" />
            <div className="relative space-y-5">
              <h2 className="text-2xl md:text-4xl font-bold tracking-tight text-balance">Start building today.</h2>
              <p className="text-muted-foreground max-w-xl mx-auto">14-day money-back guarantee. No questions asked.</p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <Button asChild size="lg" className="gap-2 w-full sm:w-auto">
                  <Link href="/sign-up">Get Started <ArrowRight className="w-4 h-4" /></Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
                  <Link href="/docs/support">Talk to sales</Link>
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border-subtle bg-muted/20 mt-auto">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">© 2024 SentinelGrid, Inc. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <Link href="/docs/license" className="hover:text-foreground transition-colors">License</Link>
            <Link href="/docs/support" className="hover:text-foreground transition-colors">Support</Link>
            <Link href="/docs/changelog" className="hover:text-foreground transition-colors">Changelog</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
