"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  ArrowRight, Siren, Target, Phone, Rocket, Activity, ShieldAlert,
  Check, Menu, X, Bell, Users, Clock,
} from "lucide-react";

const navLinks = [
  { label: "Features", href: "/features" },
  { label: "Preview", href: "/preview" },
  { label: "Components", href: "/components-preview" },
  { label: "Pricing", href: "/pricing" },
  { label: "Docs", href: "/docs" },
];

const featureSections = [
  {
    icon: Siren,
    title: "Incident Command Center",
    description: "Run war rooms, manage timelines, broadcast status updates, and coordinate responders from one screen.",
    bullets: [
      "Real-time incident timeline with auto-populated events",
      "War room chat with @mentions and action item tracking",
      "Public status page with subscriber notifications",
      "Severity-based escalation rules and SLA timers",
      "Pre-built incident templates for common scenarios",
    ],
    stat: "40% faster MTTR",
  },
  {
    icon: Target,
    title: "SLO & Error Budget Tracking",
    description: "Define service-level objectives, monitor burn rate, and get alerted before reliability slips.",
    bullets: [
      "Multi-window burn rate alerts (1h, 6h, 24h, 72h)",
      "Error budget remaining with projected exhaustion date",
      "Availability calendar with 90-day heatmap",
      "SLA reporting by customer tier",
      "Scorecards for executive review",
    ],
    stat: "99.99% achievable",
  },
  {
    icon: Phone,
    title: "On-Call Management",
    description: "Build fair rotations, schedule handoffs, and page the right engineer at 3am without burning out your team.",
    bullets: [
      "Timezone-aware rotation calendar",
      "Escalation policies with conditional rules",
      "Follow-the-sun schedule builder",
      "Handoff notes and shift reports",
      "On-call analytics: load balance and fatigue detection",
    ],
    stat: "30% fewer pages",
  },
  {
    icon: Rocket,
    title: "Deployment Safety",
    description: "Approve changes, watch canaries, and roll back instantly when things go wrong.",
    bullets: [
      "Pipeline view with stage-by-stage status",
      "Change requests with risk scoring and approvals",
      "Feature flag management with progressive rollouts",
      "One-click rollback to any previous deployment",
      "Deployment calendar with freeze windows",
    ],
    stat: "Zero bad deploys",
  },
  {
    icon: Activity,
    title: "Observability Dashboards",
    description: "Latency, throughput, error rate, web vitals, and database performance — all in one place.",
    bullets: [
      "p50 / p95 / p99 latency percentiles over time",
      "Throughput and error rate by endpoint",
      "Apdex score with satisfaction breakdown",
      "Web Vitals: LCP, FID, CLS, FCP, TTFB, INP",
      "Slow query log with connection pool monitoring",
    ],
    stat: "14 chart types",
  },
  {
    icon: ShieldAlert,
    title: "Security Operations",
    description: "Vulnerability tracking, compliance posture, audit trails, and access reviews.",
    bullets: [
      "CVE tracking with CVSS scoring and remediation SLAs",
      "Compliance frameworks: SOC 2, ISO 27001, PCI DSS",
      "Tamper-evident audit trail with integrity verification",
      "Quarterly access reviews with one-click revoke",
      "Policy violation detection with auto-remediation",
    ],
    stat: "Audit-ready",
  },
];

export default function FeaturesPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border-subtle bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <Link href="/landing" className="flex items-center gap-2">
            <svg viewBox="0 0 32 32" className="w-7 h-7" fill="none">
              <defs>
                <linearGradient id="nav-logo-feat" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M16 2 L28 8 V18 C28 25 22 29 16 30 C10 29 4 25 4 18 V8 Z" fill="url(#nav-logo-feat)" fillOpacity="0.16" stroke="url(#nav-logo-feat)" strokeWidth="1.6" strokeLinejoin="round" />
              <circle cx="16" cy="16" r="1.8" fill="#22D3EE" />
            </svg>
            <span className="font-semibold text-lg tracking-tight">SentinelGrid</span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-muted/60">
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="hidden md:flex items-center gap-2">
            <Button asChild variant="ghost" size="sm"><Link href="/sign-in">Sign in</Link></Button>
            <Button asChild size="sm" className="gap-1.5"><Link href="/dashboard">Get Started <ArrowRight className="w-3.5 h-3.5" /></Link></Button>
          </div>
          <button className="md:hidden p-2 -mr-2 text-muted-foreground" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label="Toggle menu">
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border-subtle bg-background px-4 py-4 space-y-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} className="block px-3 py-2 text-sm text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/60" onClick={() => setMobileMenuOpen(false)}>
                {link.label}
              </Link>
            ))}
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden py-20 md:py-28">
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-accent/20 rounded-full blur-3xl opacity-20" />
        <div className="relative max-w-4xl mx-auto px-4 md:px-6 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/5 text-xs text-primary mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-status-pulse" />
            Six pillars of engineering operations
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-balance">
            Every feature your <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">reliability team</span> needs
          </h1>
          <p className="mt-6 text-lg text-muted-foreground text-pretty">
            SentinelGrid bundles incident response, SLO tracking, on-call management, deployment safety, observability, and security operations into a single, cohesive design system.
          </p>
        </div>
      </section>

      {/* Feature sections */}
      <section className="pb-20">
        <div className="max-w-7xl mx-auto px-4 md:px-6 space-y-24">
          {featureSections.map((section, i) => {
            const reversed = i % 2 === 1;
            return (
              <div key={section.title} className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
                <div className={reversed ? "md:order-2" : ""}>
                  <div className="inline-flex items-center gap-2 mb-4">
                    <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                      <section.icon className="w-4.5 h-4.5" />
                    </div>
                    <span className="text-xs font-semibold uppercase tracking-wider text-primary">{section.stat}</span>
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-3">{section.title}</h2>
                  <p className="text-muted-foreground mb-5 leading-relaxed">{section.description}</p>
                  <ul className="space-y-2.5">
                    {section.bullets.map((b) => (
                      <li key={b} className="flex items-start gap-2.5 text-sm">
                        <Check className="w-4 h-4 text-success mt-0.5 shrink-0" />
                        <span className="text-muted-foreground">{b}</span>
                      </li>
                    ))}
                  </ul>
                  <Button asChild variant="link" className="mt-5 px-0 gap-1">
                    <Link href="/preview">Learn more <ArrowRight className="w-3.5 h-3.5" /></Link>
                  </Button>
                </div>
                <div className={reversed ? "md:order-1" : ""}>
                  <Card className="p-6 bg-elevated/40 border-primary/20 relative overflow-hidden">
                    <div className="absolute inset-0 bg-grid opacity-30" />
                    <div className="relative space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                            <section.icon className="w-4 h-4" />
                          </div>
                          <p className="text-sm font-medium">{section.title}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-success animate-status-pulse" />
                          <span className="text-[10px] text-muted-foreground">live</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        {[1, 2, 3].map((n) => (
                          <div key={n} className="p-3 rounded-lg border border-border bg-card">
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Metric {n}</p>
                            <p className="text-xl font-bold mt-1 text-primary">{["99.9%", "18m", "42"][n - 1]}</p>
                          </div>
                        ))}
                      </div>
                      <div className="p-3 rounded-lg border border-border bg-card h-32 flex items-end gap-1.5">
                        {[40, 65, 50, 80, 70, 95, 60, 75, 90, 55, 70, 85].map((h, idx) => (
                          <div key={idx} className="flex-1 bg-gradient-to-t from-primary/40 to-primary/80 rounded-t-sm" style={{ height: `${h}%` }} />
                        ))}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        <span>Updated 2 minutes ago</span>
                        <span className="ml-auto flex items-center gap-1"><Users className="w-3 h-3" /> 12 active</span>
                        <span className="flex items-center gap-1"><Bell className="w-3 h-3" /> 3 alerts</span>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 border-t border-border-subtle bg-muted/20">
        <div className="max-w-4xl mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">Ready to see it all in action?</h2>
          <p className="mt-3 text-muted-foreground">Browse all 100+ pages, or jump straight into the live demo.</p>
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Button asChild size="lg" className="gap-2 w-full sm:w-auto">
              <Link href="/dashboard">Get Started <ArrowRight className="w-4 h-4" /></Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
              <Link href="/preview">Browse pages</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border-subtle bg-muted/20 mt-auto">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">© 2024 SentinelGrid, Inc. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <Link href="/docs/license" className="hover:text-foreground transition-colors">License</Link>
            <Link href="/docs/support" className="hover:text-foreground transition-colors">Support</Link>
            <Link href="/docs/changelog" className="hover:text-foreground transition-colors">Changelog</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
