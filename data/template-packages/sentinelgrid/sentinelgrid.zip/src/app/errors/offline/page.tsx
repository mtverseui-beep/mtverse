"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Loader2, RotateCw, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border mx-auto">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-offline" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-offline)" fillOpacity="0.18" stroke="url(#sg-offline)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-offline)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-offline)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

export default function OfflinePage() {
  const router = useRouter();
  const [retrying, setRetrying] = React.useState(false);

  async function retry() {
    setRetrying(true);
    await new Promise((r) => setTimeout(r, 900));
    setRetrying(false);
    router.refresh();
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <div className="text-center space-y-6 max-w-md">
        <div className="flex justify-center">
          <LogoMark />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-center">
            <div className="size-20 rounded-full bg-muted border border-border flex items-center justify-center">
              <WifiOff className="size-10 text-muted-foreground" />
            </div>
          </div>
          <h1 className="text-xl font-semibold tracking-tight pt-2">You&apos;re offline</h1>
          <p className="text-sm text-muted-foreground leading-relaxed">
            SentinelGrid can&apos;t reach the internet. Check your network
            connection and try again.
          </p>
        </div>

        <div className="rounded-lg border border-border bg-muted/30 px-4 py-3 text-left">
          <div className="space-y-1.5 text-xs text-muted-foreground">
            <div className="flex items-center justify-between">
              <span>Network status</span>
              <span className="text-destructive font-medium">Disconnected</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Last synced</span>
              <span className="font-mono text-foreground">2 minutes ago</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Pending changes</span>
              <span className="font-mono text-foreground">0</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Button onClick={retry} disabled={retrying}>
            {retrying ? <Loader2 className="size-4 animate-spin" /> : <RotateCw className="size-4" />}
            Try again
          </Button>
        </div>

        <p className="text-xs text-muted-foreground">
          Your data is safe. Changes will sync once you reconnect.
        </p>
      </div>
    </div>
  );
}
