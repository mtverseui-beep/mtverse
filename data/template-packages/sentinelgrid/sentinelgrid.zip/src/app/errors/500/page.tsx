"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Loader2, LifeBuoy, RotateCw, ServerCrash } from "lucide-react";
import { Button } from "@/components/ui/button";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border mx-auto">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-500" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-500)" fillOpacity="0.18" stroke="url(#sg-500)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-500)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-500)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

export default function InternalServerErrorPage() {
  const router = useRouter();
  const [retrying, setRetrying] = React.useState(false);

  async function retry() {
    setRetrying(true);
    await new Promise((r) => setTimeout(r, 900));
    setRetrying(false);
    router.refresh();
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <div className="text-center space-y-6 max-w-md">
        <div className="flex justify-center">
          <LogoMark />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-center">
            <div className="relative">
              <span className="text-[120px] sm:text-[160px] font-bold tracking-tighter leading-none bg-gradient-to-br from-primary to-accent bg-clip-text text-transparent">
                500
              </span>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 size-12 rounded-full bg-destructive/10 border border-destructive/30 flex items-center justify-center">
                <ServerCrash className="size-6 text-destructive" />
              </div>
            </div>
          </div>
          <h1 className="text-xl font-semibold tracking-tight pt-4">Something went wrong</h1>
          <p className="text-sm text-muted-foreground leading-relaxed">
            An unexpected error occurred on our end. We&apos;ve been notified
            and are working to fix it.
          </p>
        </div>

        <div className="rounded-lg border border-border bg-muted/30 px-4 py-3 text-left">
          <div className="flex items-start gap-2">
            <div className="size-2 rounded-full bg-success mt-1.5 shrink-0 animate-status-pulse" />
            <p className="text-xs text-muted-foreground leading-relaxed">
              Incident <span className="font-mono text-foreground">#INC-5021</span> has
              been automatically created. Our on-call team has been paged.
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Button onClick={retry} disabled={retrying}>
            {retrying ? <Loader2 className="size-4 animate-spin" /> : <RotateCw className="size-4" />}
            Retry
          </Button>
          <Button asChild variant="outline">
            <Link href="mailto:support@sentinelgrid.io">
              <LifeBuoy className="size-4" />
              Contact support
            </Link>
          </Button>
          <Button asChild variant="ghost">
            <Link href="/dashboard">
              <ArrowLeft className="size-4" />
              Go back
            </Link>
          </Button>
        </div>

        <p className="text-xs text-muted-foreground">
          Error code: <span className="font-mono">500 INTERNAL_SERVER_ERROR</span>
        </p>
      </div>
    </div>
  );
}
