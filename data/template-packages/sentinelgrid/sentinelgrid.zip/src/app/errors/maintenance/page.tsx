"use client";

import * as React from "react";
import Link from "next/link";
import { Bell, CalendarClock, Check, ExternalLink, Hammer, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border mx-auto">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-maint" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-maint)" fillOpacity="0.18" stroke="url(#sg-maint)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-maint)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-maint)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

export default function MaintenancePage() {
  const [email, setEmail] = React.useState("");
  const [subscribed, setSubscribed] = React.useState(false);

  function subscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Enter a valid email");
      return;
    }
    setSubscribed(true);
    toast.success("Subscribed", { description: "You'll be notified when we're back." });
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background relative overflow-hidden">
      <div className="bg-grid absolute inset-0 opacity-20" aria-hidden="true" />
      <div className="text-center space-y-6 max-w-lg w-full relative z-10">
        <div className="flex justify-center">
          <LogoMark />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-center">
            <div className="size-20 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 border border-border flex items-center justify-center">
              <Hammer className="size-9 text-primary" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">We&apos;ll be back soon</h1>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
            SentinelGrid is undergoing scheduled maintenance to bring you new
            features and improvements. Thank you for your patience.
          </p>
        </div>

        <div className="rounded-lg border border-border bg-card p-4 text-left space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CalendarClock className="size-4 text-primary" />
              <span className="text-sm font-medium">Maintenance window</span>
            </div>
            <span className="text-xs font-mono text-muted-foreground">MAINT-2025-04-12</span>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-xs text-muted-foreground">Start</div>
              <div className="font-mono">Apr 12, 02:00 UTC</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">End (ETA)</div>
              <div className="font-mono">Apr 12, 04:00 UTC</div>
            </div>
          </div>
          <div className="border-t border-border pt-3 space-y-2">
            {[
              "Database migration to v4 schema",
              "Upgrade of metrics ingestion pipeline",
              "Security patching of API gateway",
            ].map((t) => (
              <div key={t} className="flex items-start gap-2 text-sm text-muted-foreground">
                <Check className="size-4 text-success shrink-0 mt-0.5" />
                {t}
              </div>
            ))}
          </div>
        </div>

        {!subscribed ? (
          <form onSubmit={subscribe} className="space-y-2 max-w-sm mx-auto">
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <Button type="submit">
                <Bell className="size-4" />
                Subscribe
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">Get notified the moment we&apos;re back online.</p>
          </form>
        ) : (
          <div className="rounded-lg border border-success/30 bg-success/5 px-4 py-3 text-sm text-success inline-flex items-center gap-2">
            <Check className="size-4" />
            Subscribed — we&apos;ll email you when service is restored.
          </div>
        )}

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <Button asChild variant="outline">
            <Link href="https://status.sentinelgrid.io" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="size-4" />
              View status page
            </Link>
          </Button>
          <div className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
            <ShieldCheck className="size-3.5 text-success" />
            All systems monitored 24/7
          </div>
        </div>
      </div>
    </div>
  );
}
