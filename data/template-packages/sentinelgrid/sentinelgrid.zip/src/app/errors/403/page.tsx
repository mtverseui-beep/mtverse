"use client";

import * as React from "react";
import Link from "next/link";
import { ArrowLeft, KeyRound, ShieldX } from "lucide-react";
import { Button } from "@/components/ui/button";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border mx-auto">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-403" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-403)" fillOpacity="0.18" stroke="url(#sg-403)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-403)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-403)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

export default function ForbiddenPage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <div className="text-center space-y-6 max-w-md">
        <div className="flex justify-center">
          <LogoMark />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-center">
            <div className="relative">
              <span className="text-[120px] sm:text-[160px] font-bold tracking-tighter leading-none bg-gradient-to-br from-primary to-accent bg-clip-text text-transparent">
                403
              </span>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 size-12 rounded-full bg-destructive/10 border border-destructive/30 flex items-center justify-center">
                <ShieldX className="size-6 text-destructive" />
              </div>
            </div>
          </div>
          <h1 className="text-xl font-semibold tracking-tight pt-4">Access denied</h1>
          <p className="text-sm text-muted-foreground leading-relaxed">
            You don&apos;t have permission to access this resource. If you
            believe this is a mistake, request access from your workspace admin.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <Button asChild>
            <Link href="/dashboard">
              <KeyRound className="size-4" />
              Request access
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/dashboard">
              <ArrowLeft className="size-4" />
              Go back
            </Link>
          </Button>
        </div>

        <p className="text-xs text-muted-foreground">
          Error code: <span className="font-mono">403 FORBIDDEN</span>
        </p>
      </div>
    </div>
  );
}
