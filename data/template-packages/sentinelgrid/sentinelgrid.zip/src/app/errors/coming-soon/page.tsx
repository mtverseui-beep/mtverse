"use client";

import * as React from "react";
import Link from "next/link";
import { ArrowLeft, Bell, Check, Loader2, Rocket, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border mx-auto">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-soon" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-soon)" fillOpacity="0.18" stroke="url(#sg-soon)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-soon)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-soon)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

export default function ComingSoonPage() {
  const [email, setEmail] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [subscribed, setSubscribed] = React.useState(false);

  async function subscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Enter a valid email");
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    setLoading(false);
    setSubscribed(true);
    toast.success("You're on the list", { description: "We'll email you when it's ready." });
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background relative overflow-hidden">
      <div className="bg-grid absolute inset-0 opacity-20" aria-hidden="true" />
      <div className="text-center space-y-6 max-w-lg w-full relative z-10">
        <div className="flex justify-center">
          <LogoMark />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-center">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              <Sparkles className="size-3.5" />
              In development
            </div>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">
            Coming{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Soon
            </span>
          </h1>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
            We&apos;re building something new. Get notified the moment it
            launches and be among the first to try it.
          </p>
        </div>

        <div className="rounded-xl border border-border bg-card p-5 text-left space-y-4">
          <div className="flex items-center gap-2">
            <Rocket className="size-5 text-primary" />
            <h2 className="text-sm font-semibold">AI-Powered Incident Triage</h2>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Automatically group, deduplicate, and prioritize incidents using
            machine learning. Get suggested responders and runbooks based on
            historical data.
          </p>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Development progress</span>
              <span className="text-muted-foreground font-mono">72%</span>
            </div>
            <Progress value={72} className="h-1.5" />
          </div>
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            {[
              { label: "Alpha", done: true },
              { label: "Beta", done: false },
              { label: "GA", done: false },
            ].map((p) => (
              <div key={p.label} className="rounded-md border border-border bg-muted/30 py-2">
                <div className={`size-4 mx-auto mb-1 rounded-full flex items-center justify-center ${p.done ? "bg-success/20 text-success" : "bg-muted text-muted-foreground"}`}>
                  {p.done ? <Check className="size-3" /> : <span className="text-[10px]">•</span>}
                </div>
                <span className={p.done ? "text-foreground font-medium" : "text-muted-foreground"}>{p.label}</span>
              </div>
            ))}
          </div>
        </div>

        {!subscribed ? (
          <form onSubmit={subscribe} className="space-y-2 max-w-sm mx-auto">
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <Button type="submit" disabled={loading}>
                {loading ? <Loader2 className="size-4 animate-spin" /> : <Bell className="size-4" />}
                Notify me
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">No spam. Unsubscribe anytime.</p>
          </form>
        ) : (
          <div className="rounded-lg border border-success/30 bg-success/5 px-4 py-3 text-sm text-success inline-flex items-center gap-2">
            <Check className="size-4" />
            You&apos;re on the list — we&apos;ll email you when it&apos;s ready.
          </div>
        )}

        <div>
          <Button asChild variant="ghost">
            <Link href="/dashboard">
              <ArrowLeft className="size-4" />
              Back to dashboard
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
