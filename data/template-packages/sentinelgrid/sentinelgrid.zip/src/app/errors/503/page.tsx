"use client";

import * as React from "react";
import Link from "next/link";
import { ArrowLeft, Bell, CloudOff, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border mx-auto">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-503" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-503)" fillOpacity="0.18" stroke="url(#sg-503)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-503)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-503)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

export default function ServiceUnavailablePage() {
  const [email, setEmail] = React.useState("");
  const [subscribed, setSubscribed] = React.useState(false);

  function subscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Enter a valid email");
      return;
    }
    setSubscribed(true);
    toast.success("Subscribed", { description: "We'll email you when service is restored." });
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <div className="text-center space-y-6 max-w-md w-full">
        <div className="flex justify-center">
          <LogoMark />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-center">
            <div className="relative">
              <span className="text-[120px] sm:text-[160px] font-bold tracking-tighter leading-none bg-gradient-to-br from-primary to-accent bg-clip-text text-transparent">
                503
              </span>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 size-12 rounded-full bg-warning/10 border border-warning/30 flex items-center justify-center">
                <CloudOff className="size-6 text-warning" />
              </div>
            </div>
          </div>
          <h1 className="text-xl font-semibold tracking-tight pt-4">Service unavailable</h1>
          <p className="text-sm text-muted-foreground leading-relaxed">
            We&apos;re performing scheduled maintenance to make SentinelGrid
            even better. We&apos;ll be back shortly.
          </p>
        </div>

        <div className="rounded-lg border border-border bg-muted/30 px-4 py-3">
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <span className="size-2 rounded-full bg-warning animate-status-pulse" />
            Estimated time remaining: <span className="font-mono font-medium text-foreground">~15 minutes</span>
          </div>
        </div>

        {!subscribed ? (
          <form onSubmit={subscribe} className="space-y-2 max-w-sm mx-auto">
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <Button type="submit">
                <Bell className="size-4" />
                Notify me
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              We&apos;ll email you the moment service is restored.
            </p>
          </form>
        ) : (
          <div className="rounded-lg border border-success/30 bg-success/5 px-4 py-3 text-sm text-success inline-flex items-center gap-2">
            <Bell className="size-4" />
            You&apos;re subscribed — we&apos;ll email you when service is restored.
          </div>
        )}

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Button asChild variant="outline">
            <Link href="https://status.sentinelgrid.io" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="size-4" />
              Status page
            </Link>
          </Button>
          <Button asChild variant="ghost">
            <Link href="/dashboard">
              <ArrowLeft className="size-4" />
              Go back
            </Link>
          </Button>
        </div>

        <p className="text-xs text-muted-foreground">
          Error code: <span className="font-mono">503 SERVICE_UNAVAILABLE</span>
        </p>
      </div>
    </div>
  );
}
