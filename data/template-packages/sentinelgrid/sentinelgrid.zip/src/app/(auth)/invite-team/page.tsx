"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, Loader2, Mail, Plus, Send, Trash2, Users, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-invite" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-invite)" fillOpacity="0.18" stroke="url(#sg-invite)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-invite)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-invite)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

interface Invite {
  id: string;
  email: string;
  role: string;
}

const ROLES = [
  { value: "owner", label: "Owner" },
  { value: "admin", label: "Admin" },
  { value: "engineer", label: "Engineer" },
  { value: "responder", label: "Responder" },
  { value: "viewer", label: "Viewer" },
];

export default function InviteTeamPage() {
  const router = useRouter();
  const [invites, setInvites] = React.useState<Invite[]>([
    { id: "i1", email: "", role: "engineer" },
    { id: "i2", email: "", role: "responder" },
  ]);
  const [message, setMessage] = React.useState(
    "Join me on SentinelGrid — we'll use it to track incidents, SLOs, and on-call rotations."
  );
  const [loading, setLoading] = React.useState(false);

  function addInvite() {
    setInvites((prev) => [...prev, { id: `i${Date.now()}`, email: "", role: "engineer" }]);
  }

  function removeInvite(id: string) {
    setInvites((prev) => (prev.length > 1 ? prev.filter((i) => i.id !== id) : prev));
  }

  function updateInvite(id: string, patch: Partial<Invite>) {
    setInvites((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  }

  async function onSend(e: React.FormEvent) {
    e.preventDefault();
    const valid = invites.filter((i) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(i.email));
    if (valid.length === 0) {
      toast.error("Add at least one valid email");
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success(`Invitations sent to ${valid.length} ${valid.length === 1 ? "person" : "people"}`);
    router.push("/onboarding");
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <div className="w-full max-w-lg space-y-6">
        <div className="flex items-center gap-3">
          <LogoMark />
          <div className="flex flex-col">
            <span className="font-semibold tracking-tight">SentinelGrid</span>
            <span className="text-xs text-muted-foreground">Onboarding · Step 2 of 3</span>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Users className="size-5 text-primary" />
            <h1 className="text-2xl font-semibold tracking-tight">Invite your team</h1>
          </div>
          <p className="text-sm text-muted-foreground">
            Bring your teammates on board. You can adjust roles and permissions later.
          </p>
        </div>

        <form onSubmit={onSend} className="space-y-5">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Email addresses</Label>
              <Button type="button" variant="ghost" size="sm" onClick={addInvite}>
                <Plus className="size-4" />
                Add another
              </Button>
            </div>
            <div className="space-y-2">
              {invites.map((inv) => (
                <div key={inv.id} className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                    <Input
                      type="email"
                      placeholder="teammate@company.com"
                      className="pl-9"
                      value={inv.email}
                      onChange={(e) => updateInvite(inv.id, { email: e.target.value })}
                    />
                  </div>
                  <Select value={inv.role} onValueChange={(v) => updateInvite(inv.id, { role: v })}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ROLES.map((r) => (
                        <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeInvite(inv.id)}
                    disabled={invites.length === 1}
                    aria-label="Remove invite"
                  >
                    {invites.length === 1 ? <X className="size-4 opacity-50" /> : <Trash2 className="size-4" />}
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="message">Personal message <span className="text-muted-foreground font-normal">(optional)</span></Label>
            <Textarea
              id="message"
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Add a personal note to your invitation…"
            />
          </div>

          <div className="flex items-center justify-between gap-3 pt-2">
            <Link href="/onboarding" className="text-sm text-muted-foreground hover:text-foreground">
              Skip for now
            </Link>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="size-4 animate-spin" />}
              <Send className="size-4" />
              Send invitations
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
