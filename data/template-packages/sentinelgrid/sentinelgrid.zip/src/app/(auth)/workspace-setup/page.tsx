"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, Building2, Check, Globe, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

function BrandPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 bg-elevated border-r border-border p-12 flex-col justify-between relative overflow-hidden">
      <div className="bg-grid absolute inset-0 opacity-30" aria-hidden="true" />
      <div className="relative z-10 space-y-2">
        <div className="flex items-center gap-2.5">
          <div className="size-9 rounded-lg overflow-hidden bg-background border border-border">
            <svg viewBox="0 0 64 64" width="36" height="36" className="block">
              <defs>
                <linearGradient id="sg-ws" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-ws)" fillOpacity="0.18" stroke="url(#sg-ws)" strokeWidth="2.5" strokeLinejoin="round" />
              <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-ws)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-ws)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
              <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
            </svg>
          </div>
          <span className="font-semibold tracking-tight">SentinelGrid</span>
        </div>
      </div>

      <div className="relative z-10 space-y-6 max-w-md">
        <div className="space-y-3">
          <h2 className="text-3xl font-semibold tracking-tight leading-tight">
            Create your workspace
          </h2>
          <p className="text-muted-foreground text-sm leading-relaxed">
            A workspace is a shared environment for your team to manage
            incidents, services, SLOs, and on-call schedules.
          </p>
        </div>
        <div className="rounded-lg border border-border bg-card/50 p-4 space-y-2">
          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">What you get</div>
          <ul className="space-y-2 text-sm">
            {[
              "Unlimited services, dashboards, and SLOs",
              "On-call rotations with escalation policies",
              "Audit logs, RBAC, and SSO (on paid plans)",
            ].map((t) => (
              <li key={t} className="flex items-start gap-2 text-muted-foreground">
                <Check className="size-4 text-success shrink-0 mt-0.5" />
                {t}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="relative z-10 text-xs text-muted-foreground">
        Need multiple workspaces? You can create more after sign-up.
      </div>
    </div>
  );
}

const TIMEZONES = [
  "UTC",
  "America/Los_Angeles",
  "America/New_York",
  "Europe/London",
  "Europe/Berlin",
  "Asia/Tokyo",
  "Australia/Sydney",
];

const REGIONS = [
  { value: "us-east-1", label: "US East (N. Virginia)" },
  { value: "us-west-2", label: "US West (Oregon)" },
  { value: "eu-west-1", label: "EU (Ireland)" },
  { value: "eu-central-1", label: "EU (Frankfurt)" },
  { value: "ap-southeast-1", label: "Asia Pacific (Singapore)" },
  { value: "ap-northeast-1", label: "Asia Pacific (Tokyo)" },
];

const PLANS = [
  { value: "free", label: "Free", price: "$0", desc: "Up to 5 users" },
  { value: "team", label: "Team", price: "$24", desc: "Per user / month" },
  { value: "business", label: "Business", price: "$48", desc: "Per user / month" },
  { value: "enterprise", label: "Enterprise", price: "Custom", desc: "Contact sales" },
];

export default function WorkspaceSetupPage() {
  const router = useRouter();
  const [name, setName] = React.useState("");
  const [slug, setSlug] = React.useState("");
  const [slugEdited, setSlugEdited] = React.useState(false);
  const [tz, setTz] = React.useState("UTC");
  const [region, setRegion] = React.useState("us-east-1");
  const [plan, setPlan] = React.useState("team");
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (!slugEdited) {
      setSlug(name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""));
    }
  }, [name, slugEdited]);

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!name) {
      toast.error("Workspace name is required");
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Workspace created", { description: `Welcome to ${name}!` });
    router.push("/dashboard");
  }

  return (
    <div className="min-h-screen flex">
      <BrandPanel />
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md space-y-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Building2 className="size-5 text-primary" />
              <h1 className="text-2xl font-semibold tracking-tight">Create workspace</h1>
            </div>
            <p className="text-sm text-muted-foreground">
              Set up a shared workspace for your team.
            </p>
          </div>

          <form onSubmit={onCreate} className="space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="name">Workspace name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Acme Inc."
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="slug">Workspace slug</Label>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground shrink-0">/</span>
                <Input
                  id="slug"
                  value={slug}
                  onChange={(e) => {
                    setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""));
                    setSlugEdited(true);
                  }}
                  placeholder="acme-inc"
                  className="flex-1"
                />
              </div>
              <p className="text-xs text-muted-foreground">Auto-generated from name. Editable.</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="tz">Default timezone</Label>
                <Select value={tz} onValueChange={setTz}>
                  <SelectTrigger id="tz" className="w-full">
                    <Globe className="size-4 mr-1.5" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TIMEZONES.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="region">Default region</Label>
                <Select value={region} onValueChange={setRegion}>
                  <SelectTrigger id="region" className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {REGIONS.map((r) => (
                      <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Plan</Label>
              <div className="grid grid-cols-2 gap-2">
                {PLANS.map((p) => (
                  <button
                    key={p.value}
                    type="button"
                    onClick={() => setPlan(p.value)}
                    className={cn(
                      "text-left rounded-lg border p-3 transition-colors",
                      plan === p.value
                        ? "border-primary bg-primary/5 ring-1 ring-primary"
                        : "border-border hover:bg-accent/40"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{p.label}</span>
                      {plan === p.value && <Check className="size-3.5 text-primary" />}
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      <span className="font-medium text-foreground">{p.price}</span> · {p.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="size-4 animate-spin" />}
              Create workspace
              {!loading && <ArrowRight className="size-4" />}
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground">
            Already have a workspace?{" "}
            <Link href="/sign-in" className="text-primary hover:underline font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
