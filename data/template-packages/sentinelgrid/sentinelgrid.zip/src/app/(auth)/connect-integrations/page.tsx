"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, Boxes, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Github,
  Slack,
  Server,
  Database,
  Cloud,
  Activity,
  Users,
  LayoutDashboard,
} from "lucide-react";
import { cn } from "@/lib/utils";

function LogoMark() {
  return (
    <div className="size-9 rounded-lg overflow-hidden bg-background border border-border">
      <svg viewBox="0 0 64 64" width="36" height="36" className="block">
        <defs>
          <linearGradient id="sg-ci" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-ci)" fillOpacity="0.18" stroke="url(#sg-ci)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-ci)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-ci)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

const INTEGRATIONS = [
  { id: "slack", name: "Slack", desc: "Route alerts and incident updates to channels", icon: Slack, color: "text-[#E01E5A]" },
  { id: "pagerduty", name: "PagerDuty", desc: "Sync on-call schedules and escalations", icon: Users, color: "text-[#06AC38]" },
  { id: "github", name: "GitHub", desc: "Link commits, PRs, and deploys to incidents", icon: Github, color: "text-foreground" },
  { id: "datadog", name: "Datadog", desc: "Pull metrics, monitors, and SLOs", icon: Activity, color: "text-[#632CA6]" },
  { id: "sentry", name: "Sentry", desc: "Surface errors and exceptions in real-time", icon: Database, color: "text-[#362D59]" },
  { id: "aws", name: "AWS", desc: "CloudWatch metrics and CloudTrail events", icon: Cloud, color: "text-[#FF9900]" },
  { id: "grafana", name: "Grafana", desc: "Embed dashboards and alert on panels", icon: LayoutDashboard, color: "text-[#F46800]" },
  { id: "prometheus", name: "Prometheus", desc: "Scrape metrics and record rules", icon: Server, color: "text-[#E6522C]" },
];

export default function ConnectIntegrationsPage() {
  const router = useRouter();
  const [connected, setConnected] = React.useState<string[]>(["slack", "github"]);
  const [loading, setLoading] = React.useState(false);

  function toggle(id: string) {
    setConnected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  async function finish() {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Setup complete", { description: "You can connect more later." });
    router.push("/dashboard");
  }

  const pct = Math.round((connected.length / INTEGRATIONS.length) * 100);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b border-border bg-elevated/50 backdrop-blur">
        <div className="max-w-4xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <LogoMark />
            <span className="font-semibold text-sm tracking-tight">SentinelGrid</span>
          </div>
          <Link href="/dashboard" className="text-xs text-muted-foreground hover:text-foreground">
            Skip for now
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-start justify-center p-6 pt-10">
        <div className="w-full max-w-3xl space-y-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Boxes className="size-5 text-primary" />
              <h1 className="text-2xl font-semibold tracking-tight">Connect your tools</h1>
            </div>
            <p className="text-sm text-muted-foreground max-w-xl">
              Connect the services your team uses to unlock alerts, metrics, and
              deployment tracking. You can change these any time in settings.
            </p>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{connected.length} of {INTEGRATIONS.length} connected</span>
                <span className="text-muted-foreground">{pct}%</span>
              </div>
              <Progress value={pct} className="h-1.5" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {INTEGRATIONS.map((it) => {
              const isConnected = connected.includes(it.id);
              return (
                <div
                  key={it.id}
                  className={cn(
                    "rounded-lg border p-4 space-y-3 transition-colors",
                    isConnected ? "border-primary/40 bg-primary/5" : "border-border bg-card"
                  )}
                >
                  <div className="flex items-start justify-between">
                    <div className="size-10 rounded-lg bg-muted border border-border flex items-center justify-center shrink-0">
                      <it.icon className={cn("size-5", it.color)} />
                    </div>
                    {isConnected && (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-success">
                        <Check className="size-3.5" />
                        Connected
                      </span>
                    )}
                  </div>
                  <div className="space-y-0.5">
                    <div className="text-sm font-medium">{it.name}</div>
                    <div className="text-xs text-muted-foreground leading-relaxed">{it.desc}</div>
                  </div>
                  <Button
                    type="button"
                    variant={isConnected ? "secondary" : "outline"}
                    size="sm"
                    className="w-full"
                    onClick={() => toggle(it.id)}
                  >
                    {isConnected ? "Disconnect" : "Connect"}
                  </Button>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-border">
            <Link href="/onboarding" className="text-sm text-muted-foreground hover:text-foreground">
              Back
            </Link>
            <div className="flex items-center gap-2">
              <Button variant="ghost" onClick={() => router.push("/dashboard")}>Skip</Button>
              <Button onClick={finish} disabled={loading}>
                {loading && <Loader2 className="size-4 animate-spin" />}
                Finish
                {!loading && <ArrowRight className="size-4" />}
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
