"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Building2,
  Check,
  Globe,
  Loader2,
  Mail,
  Plus,
  Rocket,
  Trash2,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Github,
  Slack,
  Boxes,
  Server,
  Database,
  Cloud,
  Activity,
} from "lucide-react";
import { cn } from "@/lib/utils";

function LogoMark() {
  return (
    <div className="size-9 rounded-lg overflow-hidden bg-background border border-border">
      <svg viewBox="0 0 64 64" width="36" height="36" className="block">
        <defs>
          <linearGradient id="sg-onb" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-onb)" fillOpacity="0.18" stroke="url(#sg-onb)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-onb)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-onb)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

const STEPS = ["Welcome", "Workspace", "Team", "Integrations"];

const TIMEZONES = [
  "UTC",
  "America/Los_Angeles",
  "America/New_York",
  "Europe/London",
  "Europe/Berlin",
  "Asia/Tokyo",
  "Australia/Sydney",
];

const INTEGRATIONS = [
  { id: "slack", name: "Slack", desc: "Route alerts and incident updates to channels", icon: Slack },
  { id: "github", name: "GitHub", desc: "Link commits, PRs, and deploys to incidents", icon: Github },
  { id: "datadog", name: "Datadog", desc: "Pull metrics, monitors, and SLOs", icon: Activity },
  { id: "pagerduty", name: "PagerDuty", desc: "Sync on-call schedules and escalations", icon: Users },
  { id: "aws", name: "AWS", desc: "CloudWatch metrics and CloudTrail events", icon: Cloud },
  { id: "grafana", name: "Grafana", desc: "Embed dashboards and alert on panels", icon: Boxes },
  { id: "prometheus", name: "Prometheus", desc: "Scrape metrics and record rules", icon: Server },
  { id: "pg", name: "Postgres", desc: "Query and visualize database health", icon: Database },
];

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = React.useState(0);
  const [workspaceName, setWorkspaceName] = React.useState("Acme Inc.");
  const [slug, setSlug] = React.useState("acme-inc");
  const [slugEdited, setSlugEdited] = React.useState(false);
  const [tz, setTz] = React.useState("UTC");
  const [invites, setInvites] = React.useState<string[]>(["", ""]);
  const [message, setMessage] = React.useState("Join me on SentinelGrid to track incidents and on-call.");
  const [connected, setConnected] = React.useState<string[]>([]);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (!slugEdited) {
      setSlug(workspaceName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""));
    }
  }, [workspaceName, slugEdited]);

  function next() {
    if (step === 1 && !workspaceName) {
      toast.error("Workspace name is required");
      return;
    }
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  }
  function back() {
    setStep((s) => Math.max(s - 1, 0));
  }

  async function finish() {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Workspace ready", { description: "Welcome to SentinelGrid!" });
    router.push("/dashboard");
  }

  function toggleIntegration(id: string) {
    setConnected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top bar */}
      <header className="border-b border-border bg-elevated/50 backdrop-blur">
        <div className="max-w-4xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <LogoMark />
            <span className="font-semibold text-sm tracking-tight">SentinelGrid</span>
          </div>
          <Link href="/dashboard" className="text-xs text-muted-foreground hover:text-foreground">
            Skip setup
          </Link>
        </div>
      </header>

      {/* Progress */}
      <div className="border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {STEPS.map((label, i) => (
              <React.Fragment key={label}>
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={cn(
                    "size-7 rounded-full flex items-center justify-center text-xs font-medium border shrink-0",
                    i < step && "bg-primary text-primary-foreground border-primary",
                    i === step && "bg-primary/10 text-primary border-primary",
                    i > step && "bg-muted text-muted-foreground border-border"
                  )}>
                    {i < step ? <Check className="size-3.5" /> : i + 1}
                  </div>
                  <span className={cn(
                    "text-sm hidden sm:block",
                    i === step ? "font-medium text-foreground" : "text-muted-foreground"
                  )}>
                    {label}
                  </span>
                </div>
                {i < STEPS.length - 1 && (
                  <div className={cn(
                    "flex-1 h-px mx-2 sm:mx-3",
                    i < step ? "bg-primary" : "bg-border"
                  )} />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-2xl space-y-6">
          {/* Step 1: Welcome */}
          {step === 0 && (
            <div className="text-center space-y-6">
              <div className="mx-auto size-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 border border-border flex items-center justify-center">
                <Rocket className="size-8 text-primary" />
              </div>
              <div className="space-y-2">
                <h1 className="text-3xl font-semibold tracking-tight">Welcome to SentinelGrid</h1>
                <p className="text-muted-foreground max-w-md mx-auto leading-relaxed">
                  Set up your workspace in a few quick steps. You can change all
                  of this later from settings.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left">
                {[
                  { icon: Building2, title: "Configure workspace", desc: "Name, slug, and timezone." },
                  { icon: Users, title: "Invite your team", desc: "Bring engineers on board." },
                  { icon: Boxes, title: "Connect tools", desc: "Slack, GitHub, Datadog, and more." },
                ].map((c) => (
                  <div key={c.title} className="rounded-lg border border-border bg-card p-4 space-y-1.5">
                    <c.icon className="size-5 text-primary" />
                    <div className="text-sm font-medium">{c.title}</div>
                    <div className="text-xs text-muted-foreground">{c.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Workspace */}
          {step === 1 && (
            <div className="space-y-6">
              <div className="space-y-1">
                <h1 className="text-2xl font-semibold tracking-tight">Set up your workspace</h1>
                <p className="text-sm text-muted-foreground">This is where your team will collaborate.</p>
              </div>
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="ws-name">Workspace name</Label>
                  <Input
                    id="ws-name"
                    value={workspaceName}
                    onChange={(e) => setWorkspaceName(e.target.value)}
                    placeholder="Acme Inc."
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ws-slug">Workspace URL</Label>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground shrink-0">sentinelgrid.io/</span>
                    <Input
                      id="ws-slug"
                      value={slug}
                      onChange={(e) => {
                        setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""));
                        setSlugEdited(true);
                      }}
                      placeholder="acme-inc"
                      className="flex-1"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Lowercase letters, numbers, and hyphens only.</p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="ws-tz">Default timezone</Label>
                  <Select value={tz} onValueChange={setTz}>
                    <SelectTrigger id="ws-tz" className="w-full">
                      <Globe className="size-4 mr-1.5" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TIMEZONES.map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Team */}
          {step === 2 && (
            <div className="space-y-6">
              <div className="space-y-1">
                <h1 className="text-2xl font-semibold tracking-tight">Invite your team</h1>
                <p className="text-sm text-muted-foreground">Add teammates you collaborate with.</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Email addresses</Label>
                  <Button type="button" variant="ghost" size="sm" onClick={() => setInvites((p) => [...p, ""])}>
                    <Plus className="size-4" />
                    Add
                  </Button>
                </div>
                {invites.map((inv, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                      <Input
                        type="email"
                        placeholder="teammate@company.com"
                        className="pl-9"
                        value={inv}
                        onChange={(e) => setInvites((p) => p.map((x, j) => (j === i ? e.target.value : x)))}
                      />
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => setInvites((p) => (p.length > 1 ? p.filter((_, j) => j !== i) : p))}
                      disabled={invites.length === 1}
                      aria-label="Remove invite"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                ))}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="msg">Personal message <span className="text-muted-foreground font-normal">(optional)</span></Label>
                <Textarea id="msg" rows={3} value={message} onChange={(e) => setMessage(e.target.value)} />
              </div>
            </div>
          )}

          {/* Step 4: Integrations */}
          {step === 3 && (
            <div className="space-y-6">
              <div className="space-y-1">
                <h1 className="text-2xl font-semibold tracking-tight">Connect integrations</h1>
                <p className="text-sm text-muted-foreground">
                  Connect the tools your team uses. {connected.length} of {INTEGRATIONS.length} connected.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {INTEGRATIONS.map((it) => {
                  const isConnected = connected.includes(it.id);
                  return (
                    <div
                      key={it.id}
                      className={cn(
                        "rounded-lg border p-4 flex items-start gap-3 transition-colors",
                        isConnected ? "border-primary/40 bg-primary/5" : "border-border bg-card"
                      )}
                    >
                      <div className="size-9 rounded-lg bg-muted border border-border flex items-center justify-center shrink-0">
                        <it.icon className="size-4 text-foreground" />
                      </div>
                      <div className="flex-1 min-w-0 space-y-0.5">
                        <div className="text-sm font-medium">{it.name}</div>
                        <div className="text-xs text-muted-foreground">{it.desc}</div>
                      </div>
                      <Button
                        type="button"
                        variant={isConnected ? "secondary" : "outline"}
                        size="sm"
                        onClick={() => toggleIntegration(it.id)}
                      >
                        {isConnected ? (
                          <>
                            <Check className="size-3.5" />
                            Connected
                          </>
                        ) : (
                          "Connect"
                        )}
                      </Button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <Button variant="ghost" onClick={back} disabled={step === 0}>
              Back
            </Button>
            <div className="flex items-center gap-2">
              {step < STEPS.length - 1 && (
                <Button variant="ghost" onClick={next}>Skip</Button>
              )}
              {step < STEPS.length - 1 ? (
                <Button onClick={next}>
                  Next
                  <ArrowRight className="size-4" />
                </Button>
              ) : (
                <Button onClick={finish} disabled={loading}>
                  {loading && <Loader2 className="size-4 animate-spin" />}
                  Get started
                  {!loading && <ArrowRight className="size-4" />}
                </Button>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
