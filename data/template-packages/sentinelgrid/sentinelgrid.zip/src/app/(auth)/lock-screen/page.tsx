"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Eye, EyeOff, Loader2, Lock, LogOut, Unlock } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border mx-auto">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-lock" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-lock)" fillOpacity="0.18" stroke="url(#sg-lock)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-lock)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-lock)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

export default function LockScreenPage() {
  const router = useRouter();
  const [password, setPassword] = React.useState("");
  const [show, setShow] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | undefined>();

  async function onUnlock(e: React.FormEvent) {
    e.preventDefault();
    if (!password) {
      setError("Enter your password to unlock");
      return;
    }
    setError(undefined);
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Welcome back", { description: "Session unlocked." });
    router.push("/dashboard");
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background relative overflow-hidden">
      <div className="bg-grid absolute inset-0 opacity-20" aria-hidden="true" />
      <div className="w-full max-w-sm space-y-6 relative z-10">
        <div className="flex justify-center">
          <LogoMark />
        </div>

        <div className="flex flex-col items-center text-center gap-4">
          <Avatar className="size-20 ring-4 ring-background shadow-lg">
            <AvatarImage src="" alt="Ada Lovelace" />
            <AvatarFallback className="bg-gradient-to-br from-primary/30 to-accent/30 text-foreground text-xl font-semibold">
              AL
            </AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <h1 className="text-xl font-semibold tracking-tight">Ada Lovelace</h1>
            <p className="text-sm text-muted-foreground">ada@acme.com · Engineering Lead</p>
          </div>
        </div>

        <div className="rounded-lg border border-border bg-muted/30 px-4 py-2.5 text-center">
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <Lock className="size-4 text-warning" />
            Your session is locked
          </div>
        </div>

        <form onSubmit={onUnlock} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
              <Input
                id="password"
                type={show ? "text" : "password"}
                autoComplete="current-password"
                placeholder="Enter your password"
                className="pl-9 pr-9"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                aria-invalid={!!error}
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShow((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 size-7 inline-flex items-center justify-center text-muted-foreground hover:text-foreground rounded-md hover:bg-accent"
                aria-label={show ? "Hide password" : "Show password"}
              >
                {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
            {error && <p className="text-xs text-destructive">{error}</p>}
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="size-4 animate-spin" />}
            <Unlock className="size-4" />
            Unlock
          </Button>
        </form>

        <div className="flex items-center justify-between text-xs">
          <Link href="/sign-in" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="size-3.5" />
            Back
          </Link>
          <Link href="/sign-in" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
            <LogOut className="size-3.5" />
            Sign in as different user
          </Link>
        </div>
      </div>
    </div>
  );
}
