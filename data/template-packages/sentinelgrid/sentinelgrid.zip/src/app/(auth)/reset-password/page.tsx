"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Eye, EyeOff, Loader2, Lock, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

function BrandPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 bg-elevated border-r border-border p-12 flex-col justify-between relative overflow-hidden">
      <div className="bg-grid absolute inset-0 opacity-30" aria-hidden="true" />
      <div className="relative z-10 space-y-2">
        <div className="flex items-center gap-2.5">
          <div className="size-9 rounded-lg overflow-hidden bg-background border border-border">
            <svg viewBox="0 0 64 64" width="36" height="36" className="block">
              <defs>
                <linearGradient id="sg-reset" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-reset)" fillOpacity="0.18" stroke="url(#sg-reset)" strokeWidth="2.5" strokeLinejoin="round" />
              <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-reset)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-reset)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
              <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
            </svg>
          </div>
          <span className="font-semibold tracking-tight">SentinelGrid</span>
        </div>
      </div>

      <div className="relative z-10 space-y-8 max-w-md">
        <div className="space-y-3">
          <h2 className="text-3xl font-semibold tracking-tight leading-tight">
            Choose a strong, memorable password
          </h2>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Your new password must be at least 8 characters long. For best
            security, use a mix of letters, numbers, and symbols.
          </p>
        </div>
        <ul className="space-y-2.5 text-sm">
          {[
            "At least 8 characters",
            "Mix of upper and lowercase letters",
            "At least one number",
            "At least one symbol (!@#$…)",
          ].map((t) => (
            <li key={t} className="flex items-center gap-2 text-muted-foreground">
              <Check className="size-4 text-success shrink-0" />
              {t}
            </li>
          ))}
        </ul>
      </div>

      <div className="relative z-10 text-xs text-muted-foreground">
        This link expires in 60 minutes
      </div>
    </div>
  );
}

function scorePassword(pw: string): { score: number; label: string } {
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 12) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  const c = Math.min(s, 4);
  if (pw.length === 0) return { score: 0, label: "Empty" };
  if (c <= 1) return { score: 25, label: "Weak" };
  if (c === 2) return { score: 50, label: "Fair" };
  if (c === 3) return { score: 75, label: "Good" };
  return { score: 100, label: "Strong" };
}

export default function ResetPasswordPage() {
  const router = useRouter();
  const [password, setPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [showPw, setShowPw] = React.useState(false);
  const [showCf, setShowCf] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [errors, setErrors] = React.useState<{ password?: string; confirm?: string }>({});

  const strength = scorePassword(password);

  function validate() {
    const next: typeof errors = {};
    if (!password) next.password = "Password is required";
    else if (password.length < 8) next.password = "Use at least 8 characters";
    if (!confirm) next.confirm = "Please confirm your password";
    else if (confirm !== password) next.confirm = "Passwords do not match";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Password reset", { description: "You can now sign in with your new password." });
    router.push("/sign-in");
  }

  return (
    <div className="min-h-screen flex">
      <BrandPanel />
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-6">
          <div className="space-y-2">
            <Link href="/sign-in" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
              <ArrowLeft className="size-3.5" />
              Back to sign in
            </Link>
            <h1 className="text-2xl font-semibold tracking-tight">Reset password</h1>
            <p className="text-sm text-muted-foreground">
              Choose a new password for your SentinelGrid account.
            </p>
          </div>

          <form onSubmit={onSubmit} className="space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="password">New password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="password"
                  type={showPw ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="At least 8 characters"
                  className="pl-9 pr-9"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  aria-invalid={!!errors.password}
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 size-7 inline-flex items-center justify-center text-muted-foreground hover:text-foreground rounded-md hover:bg-accent"
                  aria-label={showPw ? "Hide password" : "Show password"}
                >
                  {showPw ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
              {password.length > 0 && (
                <div className="space-y-1">
                  <Progress value={strength.score} className={cn("h-1.5",
                    strength.label === "Weak" ? "bg-destructive" :
                    strength.label === "Fair" ? "bg-warning" :
                    strength.label === "Good" ? "bg-info" :
                    strength.label === "Strong" ? "bg-success" : "bg-muted"
                  )} />
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Password strength</span>
                    <span className={
                      strength.label === "Weak" ? "text-destructive" :
                      strength.label === "Fair" ? "text-warning" :
                      strength.label === "Good" ? "text-info" :
                      strength.label === "Strong" ? "text-success" : "text-muted-foreground"
                    }>{strength.label}</span>
                  </div>
                </div>
              )}
              {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="confirm">Confirm new password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="confirm"
                  type={showCf ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="Re-enter your password"
                  className="pl-9 pr-9"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  aria-invalid={!!errors.confirm}
                />
                <button
                  type="button"
                  onClick={() => setShowCf((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 size-7 inline-flex items-center justify-center text-muted-foreground hover:text-foreground rounded-md hover:bg-accent"
                  aria-label={showCf ? "Hide password" : "Show password"}
                >
                  {showCf ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
              {errors.confirm && <p className="text-xs text-destructive">{errors.confirm}</p>}
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="size-4 animate-spin" />}
              Reset password
              {!loading && <ArrowRight className="size-4" />}
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground">
            Remember your password?{" "}
            <Link href="/sign-in" className="text-primary hover:underline font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
