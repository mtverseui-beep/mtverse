"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Eye,
  EyeOff,
  Github,
  Loader2,
  Lock,
  Mail,
  ShieldCheck,
  Activity,
  Bell,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";

function BrandPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 bg-elevated border-r border-border p-12 flex-col justify-between relative overflow-hidden">
      <div className="bg-grid absolute inset-0 opacity-30" aria-hidden="true" />
      <div className="relative z-10 space-y-2">
        <div className="flex items-center gap-2.5">
          <div className="size-9 rounded-lg overflow-hidden bg-background border border-border">
            <svg viewBox="0 0 64 64" width="36" height="36" className="block">
              <defs>
                <linearGradient id="sg-signin" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-signin)" fillOpacity="0.18" stroke="url(#sg-signin)" strokeWidth="2.5" strokeLinejoin="round" />
              <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-signin)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-signin)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
              <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
            </svg>
          </div>
          <span className="font-semibold tracking-tight">SentinelGrid</span>
        </div>
      </div>

      <div className="relative z-10 space-y-8 max-w-md">
        <div className="space-y-3">
          <h2 className="text-3xl font-semibold tracking-tight leading-tight">
            Engineering Operations &amp; Reliability Console
          </h2>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Detect incidents before users do. Track SLOs, error budgets, and
            on-call rotations from a single command center.
          </p>
        </div>
        <ul className="space-y-4">
          {[
            { icon: Activity, title: "Real-time observability", desc: "Unified metrics, logs, and traces across every service." },
            { icon: Bell, title: "Intelligent alerting", desc: "Noise-suppressed alerts routed to the right responder." },
            { icon: ShieldCheck, title: "Reliability scoring", desc: "Track SLOs and error budgets with burn-rate alerts." },
          ].map((f) => (
            <li key={f.title} className="flex items-start gap-3">
              <div className="size-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shrink-0">
                <f.icon className="size-4" />
              </div>
              <div className="space-y-0.5">
                <div className="text-sm font-medium">{f.title}</div>
                <div className="text-xs text-muted-foreground">{f.desc}</div>
              </div>
            </li>
          ))}
        </ul>
      </div>

      <div className="relative z-10 text-xs text-muted-foreground">
        Trusted by 4,000+ engineering teams worldwide
      </div>
    </div>
  );
}

export default function SignInPage() {
  const router = useRouter();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [remember, setRemember] = React.useState(true);
  const [loading, setLoading] = React.useState(false);
  const [errors, setErrors] = React.useState<{ email?: string; password?: string }>({});

  function validate() {
    const next: typeof errors = {};
    if (!email) next.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email address";
    if (!password) next.password = "Password is required";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Signed in successfully", { description: "Redirecting to your dashboard…" });
    router.push("/dashboard");
  }

  return (
    <div className="min-h-screen flex">
      <BrandPanel />
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-6">
          <div className="space-y-2">
            <h1 className="text-2xl font-semibold tracking-tight">Welcome back</h1>
            <p className="text-sm text-muted-foreground">
              Sign in to your SentinelGrid workspace to continue.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" type="button" onClick={() => toast.info("Google sign-in is a demo")}>
              <svg viewBox="0 0 24 24" className="size-4" aria-hidden="true">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1Z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.99.66-2.26 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z" />
                <path fill="#FBBC05" d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84Z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.46 2.09 14.97 1 12 1A11 11 0 0 0 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38Z" />
              </svg>
              Google
            </Button>
            <Button variant="outline" type="button" onClick={() => toast.info("GitHub sign-in is a demo")}>
              <Github className="size-4" />
              GitHub
            </Button>
          </div>

          <div className="flex items-center gap-3">
            <Separator className="flex-1" />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">or</span>
            <Separator className="flex-1" />
          </div>

          <form onSubmit={onSubmit} className="space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="email">Work email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  placeholder="you@company.com"
                  className="pl-9"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  aria-invalid={!!errors.email}
                />
              </div>
              {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link href="/forgot-password" className="text-xs text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="••••••••"
                  className="pl-9 pr-9"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  aria-invalid={!!errors.password}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 size-7 inline-flex items-center justify-center text-muted-foreground hover:text-foreground rounded-md hover:bg-accent"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
            </div>

            <div className="flex items-center gap-2">
              <Checkbox id="remember" checked={remember} onCheckedChange={(v) => setRemember(!!v)} />
              <Label htmlFor="remember" className="text-sm font-normal text-muted-foreground cursor-pointer">
                Keep me signed in for 30 days
              </Label>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="size-4 animate-spin" />}
              Sign in
              {!loading && <ArrowRight className="size-4" />}
            </Button>
          </form>

          <div className="text-center text-sm text-muted-foreground">
            <Link href="/sign-in" className="text-primary hover:underline">
              Continue with SSO
            </Link>
          </div>

          <p className="text-center text-sm text-muted-foreground">
            Don&apos;t have an account?{" "}
            <Link href="/sign-up" className="text-primary hover:underline font-medium">
              Sign up
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
