"use client";

import * as React from "react";
import Link from "next/link";
import { ArrowLeft, ArrowRight, CheckCircle2, Loader2, Mail, RotateCw } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function BrandPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 bg-elevated border-r border-border p-12 flex-col justify-between relative overflow-hidden">
      <div className="bg-grid absolute inset-0 opacity-30" aria-hidden="true" />
      <div className="relative z-10 space-y-2">
        <div className="flex items-center gap-2.5">
          <div className="size-9 rounded-lg overflow-hidden bg-background border border-border">
            <svg viewBox="0 0 64 64" width="36" height="36" className="block">
              <defs>
                <linearGradient id="sg-forgot" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-forgot)" fillOpacity="0.18" stroke="url(#sg-forgot)" strokeWidth="2.5" strokeLinejoin="round" />
              <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-forgot)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-forgot)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
              <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
            </svg>
          </div>
          <span className="font-semibold tracking-tight">SentinelGrid</span>
        </div>
      </div>

      <div className="relative z-10 space-y-8 max-w-md">
        <div className="space-y-3">
          <h2 className="text-3xl font-semibold tracking-tight leading-tight">
            Recover access to your workspace
          </h2>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Enter the email associated with your SentinelGrid account and we&apos;ll
            send you a secure link to reset your password.
          </p>
        </div>
        <div className="rounded-lg border border-border bg-card/50 p-4 space-y-2">
          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Security tip</div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Use a unique password with at least 12 characters, mixing letters,
            numbers, and symbols. Consider a password manager.
          </p>
        </div>
      </div>

      <div className="relative z-10 text-xs text-muted-foreground">
        Need help? <Link href="mailto:support@sentinelgrid.io" className="text-primary hover:underline">support@sentinelgrid.io</Link>
      </div>
    </div>
  );
}

export default function ForgotPasswordPage() {
  const [email, setEmail] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [sent, setSent] = React.useState(false);
  const [error, setError] = React.useState<string | undefined>();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) {
      setError("Email is required");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Enter a valid email address");
      return;
    }
    setError(undefined);
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    setSent(true);
  }

  async function resend() {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 600));
    setLoading(false);
    toast.success("Reset link resent", { description: `Sent to ${email}` });
  }

  return (
    <div className="min-h-screen flex">
      <BrandPanel />
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-6">
          {!sent ? (
            <>
              <div className="space-y-2">
                <Link href="/sign-in" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                  <ArrowLeft className="size-3.5" />
                  Back to sign in
                </Link>
                <h1 className="text-2xl font-semibold tracking-tight">Forgot password</h1>
                <p className="text-sm text-muted-foreground">
                  Enter your email and we&apos;ll send you a reset link.
                </p>
              </div>

              <form onSubmit={onSubmit} className="space-y-4" noValidate>
                <div className="space-y-1.5">
                  <Label htmlFor="email">Work email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                    <Input
                      id="email"
                      type="email"
                      autoComplete="email"
                      placeholder="you@company.com"
                      className="pl-9"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      aria-invalid={!!error}
                    />
                  </div>
                  {error && <p className="text-xs text-destructive">{error}</p>}
                </div>

                <Button type="submit" className="w-full" disabled={loading}>
                  {loading && <Loader2 className="size-4 animate-spin" />}
                  Send reset link
                  {!loading && <ArrowRight className="size-4" />}
                </Button>
              </form>

              <p className="text-center text-sm text-muted-foreground">
                Remember your password?{" "}
                <Link href="/sign-in" className="text-primary hover:underline font-medium">
                  Sign in
                </Link>
              </p>
            </>
          ) : (
            <div className="space-y-6 text-center">
              <div className="mx-auto size-14 rounded-full bg-success/10 border border-success/20 flex items-center justify-center text-success">
                <CheckCircle2 className="size-7" />
              </div>
              <div className="space-y-2">
                <h1 className="text-2xl font-semibold tracking-tight">Check your email</h1>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  We&apos;ve sent a password reset link to{" "}
                  <span className="font-medium text-foreground">{email}</span>.
                  The link will expire in 60 minutes.
                </p>
              </div>
              <div className="rounded-lg border border-border bg-muted/30 p-3 text-xs text-muted-foreground leading-relaxed text-left">
                Didn&apos;t receive the email? Check your spam folder or{" "}
                <button onClick={resend} disabled={loading} className="text-primary hover:underline inline-flex items-center gap-1 disabled:opacity-50">
                  {loading && <Loader2 className="size-3 animate-spin" />}
                  resend it
                  <RotateCw className="size-3" />
                </button>
                .
              </div>
              <Button asChild variant="outline" className="w-full">
                <Link href="/sign-in">
                  <ArrowLeft className="size-4" />
                  Back to sign in
                </Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
