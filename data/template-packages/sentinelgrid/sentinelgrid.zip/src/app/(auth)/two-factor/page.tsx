"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Fingerprint, KeyRound, Loader2, RotateCw, ShieldCheck, Smartphone } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from "@/components/ui/input-otp";

function LogoMark() {
  return (
    <div className="size-10 rounded-lg overflow-hidden bg-background border border-border mx-auto">
      <svg viewBox="0 0 64 64" width="40" height="40" className="block">
        <defs>
          <linearGradient id="sg-2fa" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22D3EE" />
            <stop offset="1" stopColor="#A78BFA" />
          </linearGradient>
        </defs>
        <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-2fa)" fillOpacity="0.18" stroke="url(#sg-2fa)" strokeWidth="2.5" strokeLinejoin="round" />
        <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-2fa)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-2fa)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
        <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
      </svg>
    </div>
  );
}

export default function TwoFactorPage() {
  const router = useRouter();
  const [code, setCode] = React.useState("");
  const [trust, setTrust] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [seconds, setSeconds] = React.useState(60);

  React.useEffect(() => {
    if (seconds <= 0) return;
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [seconds]);

  async function onVerify(e: React.FormEvent) {
    e.preventDefault();
    if (code.length !== 6) {
      toast.error("Enter the 6-digit code from your authenticator app");
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Verified", { description: "Taking you to your dashboard…" });
    router.push("/dashboard");
  }

  function resend() {
    if (seconds > 0) return;
    setSeconds(60);
    toast.success("New code sent", { description: "Sent to your authenticator app" });
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <div className="w-full max-w-md space-y-6">
        <div className="flex flex-col items-center text-center gap-3">
          <LogoMark />
          <div className="mx-auto size-12 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
            <Fingerprint className="size-6" />
          </div>
          <div className="space-y-1">
            <h1 className="text-2xl font-semibold tracking-tight">Two-factor authentication</h1>
            <p className="text-sm text-muted-foreground max-w-xs">
              Enter the 6-digit code from your authenticator app to continue.
            </p>
          </div>
        </div>

        <form onSubmit={onVerify} className="space-y-6">
          <div className="flex flex-col items-center">
            <InputOTP
              maxLength={6}
              value={code}
              onChange={(v) => setCode(v)}
            >
              <InputOTPGroup>
                <InputOTPSlot index={0} className="size-12 text-base" />
                <InputOTPSlot index={1} className="size-12 text-base" />
                <InputOTPSlot index={2} className="size-12 text-base" />
              </InputOTPGroup>
              <InputOTPSeparator />
              <InputOTPGroup>
                <InputOTPSlot index={3} className="size-12 text-base" />
                <InputOTPSlot index={4} className="size-12 text-base" />
                <InputOTPSlot index={5} className="size-12 text-base" />
              </InputOTPGroup>
            </InputOTP>
          </div>

          <div className="flex items-start gap-2">
            <Checkbox id="trust" checked={trust} onCheckedChange={(v) => setTrust(!!v)} className="mt-0.5" />
            <Label htmlFor="trust" className="text-sm font-normal text-muted-foreground cursor-pointer leading-relaxed">
              Trust this device for 30 days
            </Label>
          </div>

          <Button type="submit" className="w-full" disabled={loading || code.length !== 6}>
            {loading && <Loader2 className="size-4 animate-spin" />}
            <ShieldCheck className="size-4" />
            Verify &amp; continue
          </Button>
        </form>

        <div className="space-y-3 text-center">
          <div className="text-sm text-muted-foreground">
            Didn&apos;t receive the code?{" "}
            {seconds > 0 ? (
              <span className="text-foreground">Resend in {seconds}s</span>
            ) : (
              <button
                onClick={resend}
                className="text-primary hover:underline inline-flex items-center gap-1 font-medium"
              >
                <RotateCw className="size-3.5" />
                Resend code
              </button>
            )}
          </div>
          <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
            <Link href="/sign-in" className="hover:text-foreground inline-flex items-center gap-1">
              <Smartphone className="size-3.5" />
              Use SMS instead
            </Link>
            <span className="text-border">|</span>
            <Link href="/sign-in" className="hover:text-foreground inline-flex items-center gap-1">
              <KeyRound className="size-3.5" />
              Use backup code
            </Link>
            <span className="text-border">|</span>
            <Link href="/sign-in" className="hover:text-foreground inline-flex items-center gap-1">
              <ArrowLeft className="size-3.5" />
              Back
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
