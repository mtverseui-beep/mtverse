"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Mail,
  User,
  Building2,
  ShieldCheck,
  Activity,
  Bell,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

function BrandPanel() {
  return (
    <div className="hidden lg:flex lg:w-1/2 bg-elevated border-r border-border p-12 flex-col justify-between relative overflow-hidden">
      <div className="bg-grid absolute inset-0 opacity-30" aria-hidden="true" />
      <div className="relative z-10 space-y-2">
        <div className="flex items-center gap-2.5">
          <div className="size-9 rounded-lg overflow-hidden bg-background border border-border">
            <svg viewBox="0 0 64 64" width="36" height="36" className="block">
              <defs>
                <linearGradient id="sg-signup" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M32 4 L56 16 V36 C56 50 44 58 32 60 C20 58 8 50 8 36 V16 Z" fill="url(#sg-signup)" fillOpacity="0.18" stroke="url(#sg-signup)" strokeWidth="2.5" strokeLinejoin="round" />
              <path d="M20 26 H44 M20 34 H44 M20 42 H44" stroke="url(#sg-signup)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M28 18 V50 M36 18 V50" stroke="url(#sg-signup)" strokeWidth="2" strokeLinecap="round" strokeOpacity="0.55" />
              <circle cx="32" cy="34" r="3.4" fill="#22D3EE" />
            </svg>
          </div>
          <span className="font-semibold tracking-tight">SentinelGrid</span>
        </div>
      </div>

      <div className="relative z-10 space-y-8 max-w-md">
        <div className="space-y-3">
          <h2 className="text-3xl font-semibold tracking-tight leading-tight">
            Ship reliable software with confidence
          </h2>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Join thousands of SRE and platform teams using SentinelGrid to run
            their on-call, incident response, and reliability programs.
          </p>
        </div>
        <ul className="space-y-4">
          {[
            { icon: Activity, title: "Set up in minutes", desc: "Connect your stack and start tracking reliability instantly." },
            { icon: Bell, title: "On-call without the noise", desc: "Smart routing, escalation policies, and follow-the-sun." },
            { icon: ShieldCheck, title: "SOC 2 & ISO 27001", desc: "Enterprise-grade security, audit logs, and SSO included." },
          ].map((f) => (
            <li key={f.title} className="flex items-start gap-3">
              <div className="size-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shrink-0">
                <f.icon className="size-4" />
              </div>
              <div className="space-y-0.5">
                <div className="text-sm font-medium">{f.title}</div>
                <div className="text-xs text-muted-foreground">{f.desc}</div>
              </div>
            </li>
          ))}
        </ul>
      </div>

      <div className="relative z-10 text-xs text-muted-foreground">
        Free 14-day trial · No credit card required
      </div>
    </div>
  );
}

function scorePassword(pw: string): { score: number; label: string; color: string } {
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const clamped = Math.min(score, 4);
  if (pw.length === 0) return { score: 0, label: "Empty", color: "bg-muted" };
  if (clamped <= 1) return { score: 25, label: "Weak", color: "bg-destructive" };
  if (clamped === 2) return { score: 50, label: "Fair", color: "bg-warning" };
  if (clamped === 3) return { score: 75, label: "Good", color: "bg-info" };
  return { score: 100, label: "Strong", color: "bg-success" };
}

export default function SignUpPage() {
  const router = useRouter();
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [company, setCompany] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [terms, setTerms] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [errors, setErrors] = React.useState<{ name?: string; email?: string; password?: string; terms?: string }>({});

  const strength = scorePassword(password);

  function validate() {
    const next: typeof errors = {};
    if (!name) next.name = "Full name is required";
    if (!email) next.email = "Work email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email address";
    if (!password) next.password = "Password is required";
    else if (password.length < 8) next.password = "Use at least 8 characters";
    if (!terms) next.terms = "Please accept the terms to continue";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);
    toast.success("Account created", { description: "Check your email to verify your account." });
    router.push("/verify-email");
  }

  return (
    <div className="min-h-screen flex">
      <BrandPanel />
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-6">
          <div className="space-y-2">
            <h1 className="text-2xl font-semibold tracking-tight">Create your account</h1>
            <p className="text-sm text-muted-foreground">
              Start your 14-day free trial. No credit card required.
            </p>
          </div>

          <form onSubmit={onSubmit} className="space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="name">Full name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="name"
                  type="text"
                  autoComplete="name"
                  placeholder="Ada Lovelace"
                  className="pl-9"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  aria-invalid={!!errors.name}
                />
              </div>
              {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="email">Work email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  placeholder="you@company.com"
                  className="pl-9"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  aria-invalid={!!errors.email}
                />
              </div>
              {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="company">Company <span className="text-muted-foreground font-normal">(optional)</span></Label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="company"
                  type="text"
                  autoComplete="organization"
                  placeholder="Acme Inc."
                  className="pl-9"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="At least 8 characters"
                  className="pl-9 pr-9"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  aria-invalid={!!errors.password}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 size-7 inline-flex items-center justify-center text-muted-foreground hover:text-foreground rounded-md hover:bg-accent"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
              {password.length > 0 && (
                <div className="space-y-1">
                  <Progress value={strength.score} className={cn("h-1.5", strength.color)} />
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Password strength</span>
                    <span className={
                      strength.label === "Weak" ? "text-destructive" :
                      strength.label === "Fair" ? "text-warning" :
                      strength.label === "Good" ? "text-info" :
                      strength.label === "Strong" ? "text-success" : "text-muted-foreground"
                    }>{strength.label}</span>
                  </div>
                </div>
              )}
              {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
            </div>

            <div className="space-y-1.5">
              <div className="flex items-start gap-2">
                <Checkbox id="terms" checked={terms} onCheckedChange={(v) => setTerms(!!v)} className="mt-0.5" />
                <Label htmlFor="terms" className="text-sm font-normal text-muted-foreground cursor-pointer leading-relaxed">
                  I agree to the{" "}
                  <Link href="#" className="text-primary hover:underline">Terms of Service</Link>{" "}
                  and{" "}
                  <Link href="#" className="text-primary hover:underline">Privacy Policy</Link>.
                </Label>
              </div>
              {errors.terms && <p className="text-xs text-destructive">{errors.terms}</p>}
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="size-4 animate-spin" />}
              Create account
              {!loading && <ArrowRight className="size-4" />}
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link href="/sign-in" className="text-primary hover:underline font-medium">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
