"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Column, DataTable } from "@/components/tables/data-table";
import { toast } from "sonner";
import {
  Monitor, Smartphone, Tablet, LogOut, Activity, Users, Clock,
  AlertTriangle, Search, Globe, Apple, Chrome, Laptop,
} from "lucide-react";
import { people } from "@/lib/data";

interface Session {
  id: string;
  userId: string;
  device: string;
  deviceType: "desktop" | "mobile" | "tablet";
  browser: string;
  browserFamily: "chrome" | "firefox" | "safari" | "edge";
  ip: string;
  location: string;
  lastActive: string;
  current: boolean;
  suspicious: boolean;
}

const sessions: Session[] = [
  { id: "s1", userId: "u1", device: "MacBook Pro 16\"", deviceType: "desktop", browser: "Chrome 126", browserFamily: "chrome", ip: "10.42.18.10", location: "San Francisco, US", lastActive: "2026-07-02T05:48:00Z", current: true, suspicious: false },
  { id: "s2", userId: "u2", device: "ThinkPad X1 Carbon", deviceType: "desktop", browser: "Firefox 127", browserFamily: "firefox", ip: "10.42.18.14", location: "Los Angeles, US", lastActive: "2026-07-02T05:14:00Z", current: false, suspicious: false },
  { id: "s3", userId: "u3", device: "Dell XPS 15", deviceType: "desktop", browser: "Chrome 126", browserFamily: "chrome", ip: "10.42.18.31", location: "Mumbai, IN", lastActive: "2026-07-02T03:20:00Z", current: false, suspicious: false },
  { id: "s4", userId: "u12", device: "iPhone 15 Pro", deviceType: "mobile", browser: "Safari Mobile", browserFamily: "safari", ip: "10.42.18.12", location: "San Francisco, US", lastActive: "2026-07-01T22:45:00Z", current: false, suspicious: false },
  { id: "s5", userId: "u6", device: "Pixel 8", deviceType: "mobile", browser: "Chrome Mobile", browserFamily: "chrome", ip: "10.42.18.92", location: "New York, US", lastActive: "2026-07-01T20:18:00Z", current: false, suspicious: false },
  { id: "s6", userId: "u16", device: "MacBook Air M2", deviceType: "desktop", browser: "Edge 126", browserFamily: "edge", ip: "10.42.18.81", location: "Shanghai, CN", lastActive: "2026-07-01T18:20:00Z", current: false, suspicious: true },
  { id: "s7", userId: "u4", device: "iPad Pro 12.9", deviceType: "tablet", browser: "Safari 17", browserFamily: "safari", ip: "10.42.18.42", location: "Paris, FR", lastActive: "2026-07-01T13:58:00Z", current: false, suspicious: false },
  { id: "s8", userId: "u9", device: "MacBook Pro 14", deviceType: "desktop", browser: "Chrome 126", browserFamily: "chrome", ip: "10.42.18.55", location: "Tokyo, JP", lastActive: "2026-07-01T08:32:00Z", current: false, suspicious: false },
  { id: "s9", userId: "u15", device: "Unknown device", deviceType: "desktop", browser: "Unknown browser", browserFamily: "chrome", ip: "203.0.113.42", location: "Unknown (VPN)", lastActive: "2026-06-30T20:18:00Z", current: false, suspicious: true },
  { id: "s10", userId: "u8", device: "MacBook Pro 16", deviceType: "desktop", browser: "Safari 17", browserFamily: "safari", ip: "10.42.18.27", location: "Chicago, US", lastActive: "2026-06-30T14:18:00Z", current: false, suspicious: false },
  { id: "s11", userId: "u13", device: "ThinkPad T14", deviceType: "desktop", browser: "Firefox 127", browserFamily: "firefox", ip: "10.42.18.68", location: "Mexico City, MX", lastActive: "2026-06-29T09:00:00Z", current: false, suspicious: false },
  { id: "s12", userId: "u14", device: "Surface Pro 9", deviceType: "tablet", browser: "Edge 126", browserFamily: "edge", ip: "10.42.18.49", location: "Moscow, RU", lastActive: "2026-06-28T16:08:00Z", current: false, suspicious: false },
];

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

const deviceIcon: Record<Session["deviceType"], React.ReactNode> = {
  desktop: <Monitor className="w-3.5 h-3.5" />,
  mobile: <Smartphone className="w-3.5 h-3.5" />,
  tablet: <Tablet className="w-3.5 h-3.5" />,
};

const browserIcon: Record<Session["browserFamily"], React.ReactNode> = {
  chrome: <Chrome className="w-3.5 h-3.5" />,
  firefox: <Globe className="w-3.5 h-3.5" />,
  safari: <Apple className="w-3.5 h-3.5" />,
  edge: <Globe className="w-3.5 h-3.5" />,
};

const userOptions = Array.from(new Set(sessions.map((s) => s.userId))).map((id) => {
  const p = people.find((p) => p.id === id);
  return { label: p?.name || id, value: id };
});

export default function ActiveSessionsPage() {
  const totalActive = sessions.length;
  const active24h = sessions.filter((s) => timeAgo(s.lastActive).includes("m") || timeAgo(s.lastActive).includes("h")).length;
  const suspicious = sessions.filter((s) => s.suspicious).length;
  const uniqueUsers = new Set(sessions.map((s) => s.userId)).size;

  const columns: Column<Session>[] = [
    {
      key: "user", header: "User", sortable: true, sortValue: (r) => people.find((p) => p.id === r.userId)?.name || r.userId,
      filterable: true, filterOptions: userOptions, filterFn: (r, v) => r.userId === v,
      cell: (r) => {
        const user = people.find((p) => p.id === r.userId);
        return (
          <div className="flex items-center gap-2.5">
            <Avatar className="w-7 h-7 shrink-0">
              <AvatarImage src={user?.avatarUrl} alt={user?.name} />
              <AvatarFallback className="text-[10px]">{user?.name?.[0]}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="text-xs font-medium truncate">{user?.name}</div>
              <div className="text-[10px] text-muted-foreground truncate">{user?.role}</div>
            </div>
          </div>
        );
      },
    },
    {
      key: "device", header: "Device", hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <span className="shrink-0 text-muted-foreground">{deviceIcon[r.deviceType]}</span>
          <span className="text-xs truncate">{r.device}</span>
        </div>
      ),
    },
    {
      key: "browser", header: "Browser", hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <span className="shrink-0 text-muted-foreground">{browserIcon[r.browserFamily]}</span>
          <span className="text-xs">{r.browser}</span>
        </div>
      ),
    },
    {
      key: "ip", header: "IP",
      cell: (r) => (
        <span className="text-[11px] font-mono text-muted-foreground">{r.ip}</span>
      ),
    },
    {
      key: "location", header: "Location", hideOnMobile: true,
      cell: (r) => (
        <span className="text-xs inline-flex items-center gap-1">
          <Globe className="w-3 h-3 text-muted-foreground" /> {r.location}
        </span>
      ),
    },
    {
      key: "lastActive", header: "Last Active", sortable: true, sortValue: (r) => r.lastActive,
      cell: (r) => (
        <span className="text-[11px] text-muted-foreground inline-flex items-center gap-1">
          <Clock className="w-3 h-3" /> {timeAgo(r.lastActive)}
        </span>
      ),
    },
    {
      key: "current", header: "Status",
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          {r.current ? (
            <Badge variant="outline" className="text-[10px] bg-success/10 text-success border-success/30">Current</Badge>
          ) : r.suspicious ? (
            <Badge variant="outline" className="text-[10px] bg-destructive/10 text-destructive border-destructive/30 gap-1">
              <AlertTriangle className="w-3 h-3" /> Suspicious
            </Badge>
          ) : (
            <Badge variant="outline" className="text-[10px] text-muted-foreground">Active</Badge>
          )}
        </div>
      ),
    },
    {
      key: "actions", header: "", align: "right",
      cell: (r) => (
        <Button
          variant="ghost"
          size="sm"
          disabled={r.current}
          className="h-7 text-xs gap-1 text-destructive hover:text-destructive disabled:opacity-40"
          onClick={() => toast.success("Session revoked", { description: `Device signed out: ${r.device}` })}
        >
          <LogOut className="w-3 h-3" /> Revoke
        </Button>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Active Sessions"
        description="View and revoke all authenticated sessions across your workspace."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Active Sessions" }]}
        icon={<Activity className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive" onClick={() => toast.success("Revoke all other sessions", { description: "All sessions except the current one have been terminated." })}>
            <LogOut className="w-3.5 h-3.5" /> Revoke All Others
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Active" value={totalActive} icon={<Activity className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Active Users (24h)" value={active24h} hint={`${uniqueUsers} unique users`} icon={<Users className="w-4 h-4" />} accent="success" />
        <KpiCard label="Avg Session" value="4h 12m" hint="mean duration" icon={<Clock className="w-4 h-4" />} accent="info" />
        <KpiCard label="Suspicious" value={suspicious} hint="flagged for review" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="All Active Sessions"
          description="Filter by user. Click revoke to terminate a session immediately."
          action={<Button variant="outline" size="sm" className="text-xs h-8 gap-1" onClick={() => toast.info("Exporting session report")}><Search className="w-3.5 h-3.5" /> Investigate</Button>}
        />
        <DataTable
          columns={columns}
          data={sessions}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.device, (r) => r.ip, (r) => r.location, (r) => people.find((p) => p.id === r.userId)?.name || ""]}
          searchPlaceholder="Search user, device, IP, location..."
          pageSize={10}
          initialSort={{ key: "lastActive", dir: "desc" }}
          mobileCard={(r) => {
            const user = people.find((p) => p.id === r.userId);
            return (
              <div className="rounded-lg border bg-card p-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Avatar className="w-7 h-7 shrink-0">
                      <AvatarImage src={user?.avatarUrl} alt={user?.name} />
                      <AvatarFallback className="text-[10px]">{user?.name?.[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs font-medium truncate">{user?.name}</span>
                  </div>
                  {r.current ? (
                    <Badge variant="outline" className="text-[10px] bg-success/10 text-success border-success/30">Current</Badge>
                  ) : r.suspicious ? (
                    <Badge variant="outline" className="text-[10px] bg-destructive/10 text-destructive border-destructive/30">Suspicious</Badge>
                  ) : null}
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-muted-foreground">{deviceIcon[r.deviceType]}</span>
                  <span className="truncate">{r.device}</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span className="font-mono">{r.ip}</span>
                  <span>{timeAgo(r.lastActive)}</span>
                </div>
                <Button variant="ghost" size="sm" disabled={r.current} className="h-7 text-xs gap-1 w-full text-destructive hover:text-destructive disabled:opacity-40" onClick={() => toast.success("Session revoked")}>
                  <LogOut className="w-3 h-3" /> Revoke
                </Button>
              </div>
            );
          }}
        />
      </Card>
    </PageContainer>
  );
}
