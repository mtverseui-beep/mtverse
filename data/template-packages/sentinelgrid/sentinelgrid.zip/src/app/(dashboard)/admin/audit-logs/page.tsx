"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  History, Download, Filter, User, Globe, Server, Activity,
  CheckCircle2, XCircle, ChevronDown, FileJson, FileSpreadsheet, Shield,
} from "lucide-react";
import { auditEvents, people } from "@/lib/data";
import type { AuditEvent } from "@/lib/types";
import { toast } from "sonner";

// Admin-focused extended log (different mix from security/audit)
const adminLog: AuditEvent[] = [
  ...auditEvents,
  { id: "al1", timestamp: "2026-07-02T06:25:00Z", actorId: "u1", action: "workspace.settings_updated", resourceType: "workspace", resourceId: "ws-1", metadata: { key: "default_severity" }, ip: "10.42.18.10", result: "success" },
  { id: "al2", timestamp: "2026-07-02T05:50:00Z", actorId: "u12", action: "api_key.created", resourceType: "api_key", resourceId: "ak5", metadata: { name: "Audit Export" }, ip: "10.42.18.12", result: "success" },
  { id: "al3", timestamp: "2026-07-02T04:30:00Z", actorId: "u3", action: "team.member_added", resourceType: "team", resourceId: "t2", metadata: { user: "u11" }, ip: "10.42.18.31", result: "success" },
  { id: "al4", timestamp: "2026-07-01T22:18:00Z", actorId: "u1", action: "role.permissions_updated", resourceType: "role", resourceId: "r3", metadata: {}, ip: "10.42.18.10", result: "success" },
  { id: "al5", timestamp: "2026-07-01T18:45:00Z", actorId: "u12", action: "user.suspended", resourceType: "user", resourceId: "u11", metadata: { reason: "policy_violation" }, ip: "10.42.18.12", result: "success" },
  { id: "al6", timestamp: "2026-07-01T16:08:00Z", actorId: "u6", action: "webhook.created", resourceType: "webhook", resourceId: "wh5", metadata: { url: "https://hooks.example" }, ip: "10.42.18.92", result: "success" },
  { id: "al7", timestamp: "2026-07-01T11:22:00Z", actorId: "u16", action: "integration.connected", resourceType: "integration", resourceId: "int8", metadata: {}, ip: "10.42.18.81", result: "success" },
  { id: "al8", timestamp: "2026-07-01T09:50:00Z", actorId: "u3", action: "billing.plan_changed", resourceType: "subscription", resourceId: "sub-1", metadata: { plan: "Enterprise" }, ip: "10.42.18.31", result: "success" },
  { id: "al9", timestamp: "2026-06-30T20:42:00Z", actorId: "u1", action: "workspace.member_invited", resourceType: "workspace", resourceId: "ws-1", metadata: { email: "rpatel@sentinelgrid.io" }, ip: "10.42.18.10", result: "success" },
  { id: "al10", timestamp: "2026-06-30T15:32:00Z", actorId: "u12", action: "policy.created", resourceType: "policy", resourceId: "pol-8", metadata: { name: "Require MFA" }, ip: "10.42.18.12", result: "success" },
];

const actorOptions = Array.from(new Set(adminLog.map((a) => a.actorId))).map((id) => {
  const p = people.find((p) => p.id === id);
  return { label: p?.name || id, value: id };
});
const actionOptions = Array.from(new Set(adminLog.map((a) => a.action.split(".")[0]))).map((k) => ({
  label: k.charAt(0).toUpperCase() + k.slice(1),
  value: k,
}));
const resultOptions = [
  { label: "Success", value: "success" },
  { label: "Failure", value: "failure" },
];

function actionIcon(action: string) {
  if (action.includes("user") || action.includes("workspace") || action.includes("team")) return <User className="w-3.5 h-3.5" />;
  if (action.includes("api_key") || action.includes("webhook")) return <Server className="w-3.5 h-3.5" />;
  if (action.includes("integration") || action.includes("billing")) return <Activity className="w-3.5 h-3.5" />;
  if (action.includes("role") || action.includes("policy")) return <Shield className="w-3.5 h-3.5" />;
  return <History className="w-3.5 h-3.5" />;
}

export default function AuditLogsPage() {
  const total = adminLog.length;
  const success = adminLog.filter((a) => a.result === "success").length;
  const failure = adminLog.filter((a) => a.result === "failure").length;
  const uniqueActors = new Set(adminLog.map((a) => a.actorId)).size;

  const columns: Column<AuditEvent>[] = [
    {
      key: "timestamp", header: "Timestamp", sortable: true, sortValue: (r) => r.timestamp,
      cell: (r) => <span className="text-[11px] text-muted-foreground font-mono whitespace-nowrap">{new Date(r.timestamp).toLocaleString()}</span>,
    },
    {
      key: "actor", header: "Actor", sortable: true, sortValue: (r) => r.actorId,
      filterable: true, filterOptions: actorOptions, filterFn: (r, v) => r.actorId === v,
      cell: (r) => {
        const p = people.find((p) => p.id === r.actorId);
        return p ? (
          <div className="flex items-center gap-1.5">
            <img src={p.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate max-w-[120px]">{p.name}</span>
          </div>
        ) : <span className="text-xs font-mono">{r.actorId}</span>;
      },
    },
    {
      key: "action", header: "Action", sortable: true, sortValue: (r) => r.action,
      filterable: true, filterOptions: actionOptions, filterFn: (r, v) => r.action.startsWith(v),
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className="shrink-0 w-6 h-6 rounded bg-muted flex items-center justify-center text-muted-foreground">
            {actionIcon(r.action)}
          </div>
          <span className="text-xs font-mono">{r.action}</span>
        </div>
      ),
    },
    {
      key: "resource", header: "Resource", hideOnMobile: true,
      cell: (r) => (
        <div className="text-xs">
          <span className="font-mono text-[11px]">{r.resourceId}</span>
          <span className="text-[10px] text-muted-foreground ml-1.5">({r.resourceType})</span>
        </div>
      ),
    },
    {
      key: "ip", header: "IP", hideOnMobile: true,
      cell: (r) => (
        <span className="text-[11px] font-mono text-muted-foreground inline-flex items-center gap-1">
          <Globe className="w-3 h-3" />
          {r.ip}
        </span>
      ),
    },
    {
      key: "result", header: "Result",
      filterable: true, filterOptions: resultOptions, filterFn: (r, v) => r.result === v,
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded font-medium ${
          r.result === "success" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
        }`}>
          {r.result === "success" ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
          {r.result}
        </span>
      ),
    },
  ];

  function exportFormat(format: "csv" | "json") {
    toast.success(`Exported as ${format.toUpperCase()}`, { description: `${adminLog.length} entries delivered.` });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Audit Logs"
        description="Admin audit trail: workspace, member, role, and configuration changes. Distinct from security audit trails."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Audit Logs" }]}
        icon={<History className="w-5 h-5" />}
        meta={<Badge variant="outline" className="text-[10px] gap-1"><Shield className="w-3 h-3" /> Admin view</Badge>}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => exportFormat("csv")}>
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span className="hidden md:inline">CSV</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => exportFormat("json")}>
              <FileJson className="w-3.5 h-3.5" />
              <span className="hidden md:inline">JSON</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Events" value={total} icon={<History className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Successful" value={success} icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Failed" value={failure} icon={<XCircle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Unique Actors" value={uniqueActors} icon={<User className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Admin Activity Log"
          description="Filter by actor, action category, or result."
          action={
            <Button variant="outline" size="sm" className="text-xs h-8 gap-1.5" onClick={() => toast.info("Advanced filter opened")}>
              <Filter className="w-3.5 h-3.5" /> Date Range
            </Button>
          }
        />
        <DataTable
          columns={columns}
          data={adminLog}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.action, (r) => r.resourceId, (r) => r.ip]}
          searchPlaceholder="Search action, resource, IP..."
          pageSize={12}
          initialSort={{ key: "timestamp", dir: "desc" }}
          mobileCard={(r) => {
            const p = people.find((p) => p.id === r.actorId);
            return (
              <div className="rounded-lg border bg-card p-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {p && <img src={p.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />}
                    <span className="text-xs font-medium">{p?.name || r.actorId}</span>
                  </div>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${r.result === "success" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`}>
                    {r.result}
                  </span>
                </div>
                <div className="text-[11px] font-mono">{r.action}</div>
                <div className="text-[10px] text-muted-foreground font-mono">{r.resourceType} · {r.resourceId}</div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span className="font-mono">{r.ip}</span>
                  <span>{new Date(r.timestamp).toLocaleString()}</span>
                </div>
              </div>
            );
          }}
        />
      </Card>
    </PageContainer>
  );
}
