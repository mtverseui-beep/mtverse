"use client";

import * as React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  History, ArrowLeft, User, Server, Globe, Monitor, Clock,
  CheckCircle2, XCircle, Copy, Download, ChevronRight, Activity,
  ShieldAlert, FileJson, Mail, Smartphone, Network, Cpu, Database,
} from "lucide-react";
import { auditEvents, people } from "@/lib/data";
import type { AuditEvent } from "@/lib/types";

// Extended mock log: same set used by the audit-logs admin list
const extendedLog: AuditEvent[] = [
  ...auditEvents,
  { id: "al1", timestamp: "2026-07-02T06:25:00Z", actorId: "u1", action: "workspace.settings_updated", resourceType: "workspace", resourceId: "ws-1", metadata: { key: "default_severity", value: "high" }, ip: "10.42.18.10", result: "success" },
  { id: "al2", timestamp: "2026-07-02T05:50:00Z", actorId: "u12", action: "api_key.created", resourceType: "api_key", resourceId: "ak5", metadata: { name: "Audit Export", scopes: "audit:read" }, ip: "10.42.18.12", result: "success" },
  { id: "al3", timestamp: "2026-07-02T04:30:00Z", actorId: "u3", action: "team.member_added", resourceType: "team", resourceId: "t2", metadata: { user: "u11", role: "Senior SRE" }, ip: "10.42.18.31", result: "success" },
  { id: "al4", timestamp: "2026-07-01T22:18:00Z", actorId: "u1", action: "role.permissions_updated", resourceType: "role", resourceId: "r3", metadata: { permissions_added: "incidents:write" }, ip: "10.42.18.10", result: "success" },
];

function actionIcon(action: string) {
  if (action.includes("user") || action.includes("workspace") || action.includes("team")) return <User className="w-4 h-4" />;
  if (action.includes("api_key") || action.includes("webhook")) return <Cpu className="w-4 h-4" />;
  if (action.includes("integration") || action.includes("billing")) return <Activity className="w-4 h-4" />;
  if (action.includes("role") || action.includes("policy")) return <ShieldAlert className="w-4 h-4" />;
  if (action.includes("incident")) return <ShieldAlert className="w-4 h-4" />;
  if (action.includes("alert")) return <Activity className="w-4 h-4" />;
  if (action.includes("deployment")) return <Server className="w-4 h-4" />;
  return <History className="w-4 h-4" />;
}

function mockRequestPayload(e: AuditEvent): Record<string, unknown> {
  return {
    method: "POST",
    path: `/api/v1/${e.resourceType}s/${e.resourceId}/${e.action.split(".").pop()}`,
    headers: {
      "content-type": "application/json",
      "authorization": "Bearer sg_live_••••",
      "x-workspace-id": "ws_sentinelgrid_prod",
      "x-request-id": `req_${e.id}_${Math.random().toString(36).slice(2, 10)}`,
    },
    body: e.metadata,
    ip: e.ip,
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
  };
}

function mockResponsePayload(e: AuditEvent): Record<string, unknown> {
  return {
    status: e.result === "success" ? 200 : 403,
    status_text: e.result === "success" ? "OK" : "Forbidden",
    headers: {
      "x-request-id": `req_${e.id}_${Math.random().toString(36).slice(2, 10)}`,
      "x-ratelimit-remaining": "299",
    },
    body: {
      id: e.resourceId,
      type: e.resourceType,
      result: e.result,
      timestamp: e.timestamp,
      duration_ms: Math.floor(Math.random() * 400) + 40,
    },
  };
}

export default function AuditEventDetailsPage() {
  const params = useParams();
  const id = (params?.id as string) || "a1";
  const event = extendedLog.find((e) => e.id === id) || auditEvents[0] || extendedLog[0];

  const actor = people.find((p) => p.id === event.actorId);
  const related = extendedLog
    .filter((e) => e.id !== event.id && (e.actorId === event.actorId || e.resourceId === event.resourceId))
    .slice(0, 6);

  const request = mockRequestPayload(event);
  const response = mockResponsePayload(event);

  function copyJson(obj: unknown) {
    navigator.clipboard?.writeText(JSON.stringify(obj, null, 2));
    toast.success("Copied to clipboard");
  }

  return (
    <PageContainer>
      <PageHeader
        title="Audit Event Details"
        description={`Event ${event.id} · ${event.action}`}
        breadcrumbs={[
          { label: "Home", href: "/dashboard" },
          { label: "Admin", href: "/admin" },
          { label: "Audit Logs", href: "/admin/audit-logs" },
          { label: event.id },
        ]}
        icon={<History className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" asChild>
              <Link href="/admin/audit-logs"><ArrowLeft className="w-3.5 h-3.5" /> Back to logs</Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Event exported as JSON")}>
              <Download className="w-3.5 h-3.5" /> Export
            </Button>
          </>
        }
      />

      {/* Hero */}
      <Card className="p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-start gap-4">
          <div className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center border ${
            event.result === "success"
              ? "bg-success/10 border-success/20 text-success"
              : "bg-destructive/10 border-destructive/20 text-destructive"
          }`}>
            {event.result === "success" ? <CheckCircle2 className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
          </div>
          <div className="min-w-0 flex-1 space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-semibold tracking-tight font-mono">{event.action}</h2>
              <Badge
                variant="outline"
                className={`text-[10px] gap-1 ${
                  event.result === "success"
                    ? "bg-success/10 text-success border-success/30"
                    : "bg-destructive/10 text-destructive border-destructive/30"
                }`}
              >
                {event.result === "success" ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                {event.result}
              </Badge>
              <Badge variant="outline" className="text-[10px] font-mono">{event.id}</Badge>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
              <span className="inline-flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {new Date(event.timestamp).toLocaleString("en-US", { dateStyle: "full", timeStyle: "long" })}
              </span>
              <span>·</span>
              <span className="inline-flex items-center gap-1 font-mono">
                <Globe className="w-3 h-3" /> {event.ip}
              </span>
            </div>
          </div>
        </div>
        <Separator />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <HeroStat label="Event ID" value={event.id} mono />
          <HeroStat label="Action" value={event.action} mono />
          <HeroStat label="Resource Type" value={event.resourceType} mono />
          <HeroStat label="Result" value={event.result} />
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Resource details */}
        <Card className="p-6 space-y-4">
          <SectionHeading
            title="Resource Details"
            description="Target of the action."
            action={<Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => toast.info(`Searching for ${event.resourceId}`)}>Find similar <ChevronRight className="w-3 h-3" /></Button>}
          />
          <Separator />
          <div className="space-y-3">
            <DetailRow icon={<Database className="w-3.5 h-3.5" />} label="Resource Type" value={event.resourceType} mono />
            <DetailRow icon={<Server className="w-3.5 h-3.5" />} label="Resource ID" value={event.resourceId} mono />
            <DetailRow icon={<Activity className="w-3.5 h-3.5" />} label="Action" value={event.action} mono />
            <DetailRow
              icon={<CheckCircle2 className="w-3.5 h-3.5" />}
              label="Result"
              value={
                <Badge variant="outline" className={`text-[10px] gap-1 ${event.result === "success" ? "bg-success/10 text-success border-success/30" : "bg-destructive/10 text-destructive border-destructive/30"}`}>
                  {event.result}
                </Badge>
              }
            />
            {Object.keys(event.metadata).length > 0 && (
              <div className="space-y-1.5 pt-2">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Metadata</div>
                <div className="space-y-1">
                  {Object.entries(event.metadata).map(([k, v]) => (
                    <div key={k} className="flex items-center gap-2 text-xs">
                      <code className="text-[10px] text-muted-foreground font-mono">{k}:</code>
                      <code className="text-[11px] font-mono">{v}</code>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Actor details */}
        <Card className="p-6 space-y-4">
          <SectionHeading
            title="Actor Details"
            description="Who performed the action."
            action={actor && <Button variant="ghost" size="sm" className="h-7 text-xs" asChild><Link href={`/admin/team/${actor.id}`}>View profile <ChevronRight className="w-3 h-3" /></Link></Button>}
          />
          <Separator />
          {actor && (
            <div className="flex items-center gap-3 p-3 rounded-lg border">
              <Avatar className="w-12 h-12 shrink-0">
                <AvatarImage src={actor.avatarUrl} alt={actor.name} />
                <AvatarFallback>{actor.name[0]}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 space-y-0.5">
                <div className="text-sm font-medium truncate">{actor.name}</div>
                <div className="text-xs text-muted-foreground truncate">{actor.title}</div>
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                  <Badge variant="outline" className="text-[9px]">@{actor.handle}</Badge>
                  <Badge variant="outline" className="text-[9px]">{actor.team}</Badge>
                </div>
              </div>
            </div>
          )}
          <div className="space-y-3">
            <DetailRow icon={<User className="w-3.5 h-3.5" />} label="Actor ID" value={event.actorId} mono />
            {actor && <DetailRow icon={<Mail className="w-3.5 h-3.5" />} label="Email" value={actor.email} />}
            {actor && <DetailRow icon={<Globe className="w-3.5 h-3.5" />} label="Timezone" value={actor.timezone.replace(/_/g, " ")} />}
            <DetailRow icon={<Smartphone className="w-3.5 h-3.5" />} label="Source IP" value={event.ip} mono />
          </div>
        </Card>
      </div>

      {/* Request / Response */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-6 space-y-4">
          <SectionHeading
            title="Request"
            description="HTTP request as captured by the audit pipeline."
            action={<Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => copyJson(request)}><Copy className="w-3 h-3" /> Copy</Button>}
          />
          <Separator />
          <pre className="text-[11px] font-mono p-4 rounded-lg bg-muted border overflow-x-auto max-h-80 overflow-y-auto">
{JSON.stringify(request, null, 2)}
          </pre>
        </Card>
        <Card className="p-6 space-y-4">
          <SectionHeading
            title="Response"
            description="HTTP response recorded for this action."
            action={<Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => copyJson(response)}><Copy className="w-3 h-3" /> Copy</Button>}
          />
          <Separator />
          <pre className="text-[11px] font-mono p-4 rounded-lg bg-muted border overflow-x-auto max-h-80 overflow-y-auto">
{JSON.stringify(response, null, 2)}
          </pre>
        </Card>
      </div>

      {/* IP & User Agent */}
      <Card className="p-6 space-y-4">
        <SectionHeading title="Network & Client" description="IP, user agent, and geolocation." />
        <Separator />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 rounded-lg border space-y-1">
            <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
              <Network className="w-3 h-3" /> Source IP
            </div>
            <div className="text-sm font-mono">{event.ip}</div>
            <div className="text-[10px] text-muted-foreground">Internal · 10.42.18.0/24</div>
          </div>
          <div className="p-3 rounded-lg border space-y-1">
            <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
              <Globe className="w-3 h-3" /> Geolocation
            </div>
            <div className="text-sm">San Francisco, CA</div>
            <div className="text-[10px] text-muted-foreground">United States · -122.42, 37.77</div>
          </div>
          <div className="p-3 rounded-lg border space-y-1">
            <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
              <Monitor className="w-3 h-3" /> User Agent
            </div>
            <div className="text-xs font-mono truncate">Chrome 126 · macOS</div>
            <div className="text-[10px] text-muted-foreground">Mozilla/5.0 (Macintosh; ...)</div>
          </div>
        </div>
      </Card>

      {/* Related events */}
      {related.length > 0 && (
        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Related Events"
            description={`Same actor or same resource (${related.length} found)`}
            action={<Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.info("Opening related events search")}>View all <ChevronRight className="w-3 h-3" /></Button>}
          />
          <div className="space-y-1 max-h-96 overflow-y-auto pr-2 -mr-2">
            {related.map((e) => {
              const p = people.find((x) => x.id === e.actorId);
              const isSameActor = e.actorId === event.actorId;
              const isSameResource = e.resourceId === event.resourceId;
              return (
                <Link
                  key={e.id}
                  href={`/admin/audit-logs/${e.id}`}
                  className="flex items-center gap-3 p-2.5 rounded-lg border hover:border-primary/30 hover:bg-muted/30 transition-colors"
                >
                  <div className={`shrink-0 w-7 h-7 rounded-md flex items-center justify-center border ${
                    e.result === "success" ? "bg-success/10 border-success/20 text-success" : "bg-destructive/10 border-destructive/20 text-destructive"
                  }`}>
                    {actionIcon(e.action)}
                  </div>
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <code className="text-[11px] font-mono font-medium">{e.action}</code>
                      {isSameActor && <Badge variant="outline" className="text-[9px] bg-primary/10 text-primary border-primary/30">same actor</Badge>}
                      {isSameResource && <Badge variant="outline" className="text-[9px] bg-accent text-accent-foreground border-accent/30">same resource</Badge>}
                    </div>
                    <div className="text-[10px] text-muted-foreground truncate">
                      {p?.name} · {e.resourceType}/{e.resourceId} · {new Date(e.timestamp).toLocaleString()}
                    </div>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                </Link>
              );
            })}
          </div>
        </Card>
      )}
    </PageContainer>
  );
}

function HeroStat({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="p-2.5 rounded-lg border space-y-1 min-w-0">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground truncate">{label}</div>
      <div className={`text-xs font-medium truncate ${mono ? "font-mono" : ""}`}>{value}</div>
    </div>
  );
}

function DetailRow({ icon, label, value, mono }: { icon: React.ReactNode; label: string; value: React.ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-2 text-xs text-muted-foreground shrink-0">
        {icon} {label}
      </div>
      <div className={`text-xs ${mono ? "font-mono" : ""} truncate min-w-0 text-right`}>{value}</div>
    </div>
  );
}
