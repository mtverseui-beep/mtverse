"use client";

import * as React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Users, ArrowLeft, Mail, Globe, Clock, Server, Siren,
  Activity, ChevronRight, Crown, ShieldAlert, CheckSquare,
  Pencil, UserX, Phone, MessageSquare, Calendar, Zap,
} from "lucide-react";
import { people, teams, services, incidents, auditEvents, postmortems } from "@/lib/data";
import { SeverityBadge, IncidentStatusBadge, StatusDot } from "@/components/common/badges";
import { toast } from "sonner";

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export default function TeamMemberDetailsPage() {
  const params = useParams();
  const id = (params?.id as string) || people[0].id;
  const member = people.find((p) => p.id === id) || people[0];
  const team = teams.find((t) => t.name === member.team);

  // Owned services (by ownerId or team ownership)
  const ownedServices = services.filter((s) => s.ownerId === member.id || (team && s.teamId === team.id && s.ownerId === member.id)).slice(0, 5);
  // If no owned services, fall back to team's services
  const teamServices = team ? services.filter((s) => team.servicesOwned.includes(s.id)) : [];

  // Assigned incidents (as commander or responder)
  const assignedIncidents = incidents.filter((i) => i.commanderId === member.id || i.responderIds.includes(member.id)).slice(0, 5);

  // Recent activity (audit events)
  const recentActivity = auditEvents.filter((a) => a.actorId === member.id).slice(0, 6);

  // Assigned postmortem action items
  const actionItems = postmortems.flatMap((pm) => pm.actionItems).filter((a) => a.ownerId === member.id).slice(0, 5);

  // Upcoming on-call shifts (mock)
  const upcomingShifts = [
    { id: "oc1", role: "Primary", start: "2026-07-08T00:00:00Z", end: "2026-07-15T00:00:00Z", team: member.team },
    { id: "oc2", role: "Secondary", start: "2026-07-22T00:00:00Z", end: "2026-07-29T00:00:00Z", team: member.team },
    { id: "oc3", role: "Primary", start: "2026-08-05T00:00:00Z", end: "2026-08-12T00:00:00Z", team: member.team },
  ];

  return (
    <PageContainer>
      <PageHeader
        title={member.name}
        description={`${member.title} · ${member.team} team`}
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Team", href: "/admin/team" }, { label: member.name }]}
        icon={<Users className="w-5 h-5" />}
        meta={
          <div className="flex items-center gap-2 flex-wrap">
            {team && (
              <span className="inline-flex items-center gap-1.5 text-xs px-2 py-0.5 rounded-md border" style={{ borderColor: `${team.color}40`, background: `${team.color}15`, color: team.color }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: team.color }} />
                {team.name}
              </span>
            )}
            <Badge variant="outline" className="text-[10px]">{member.role}</Badge>
          </div>
        }
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/admin/team"><ArrowLeft className="w-3.5 h-3.5" /> Back</Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Edit role dialog opened")}>
              <Pencil className="w-3.5 h-3.5" /> Edit Role
            </Button>
            <Button variant="destructive" size="sm" className="gap-1.5" onClick={() => toast.error(`Remove ${member.name} from team?`, { description: "This will revoke all access immediately." })}>
              <UserX className="w-3.5 h-3.5" /> Remove
            </Button>
          </>
        }
      />

      {/* Hero card */}
      <Card className="p-5 lg:p-6">
        <div className="grid grid-cols-1 lg:grid-cols-[auto_1fr_auto] gap-6 items-start">
          <img src={member.avatarUrl} alt={member.name} className="w-24 h-24 rounded-2xl object-cover border-2 border-border" />
          <div className="space-y-3">
            <div>
              <h2 className="text-xl font-semibold tracking-tight">{member.name}</h2>
              <p className="text-sm text-muted-foreground">{member.title}</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
              <div className="flex items-center gap-2 text-xs">
                <Mail className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-muted-foreground">Email:</span>
                <span className="font-mono">{member.email}</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <Globe className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-muted-foreground">Timezone:</span>
                <span>{member.timezone}</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <Users className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-muted-foreground">Team:</span>
                <span>{member.team}</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <Crown className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-muted-foreground">Role:</span>
                <span>{member.role}</span>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2 lg:border-l lg:border-border lg:pl-6">
            <Button variant="outline" size="sm" className="gap-1.5 w-full" onClick={() => toast.info(`Composing message to ${member.name}`)}>
              <MessageSquare className="w-3.5 h-3.5" /> Message
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5 w-full" onClick={() => toast.info(`Initiating call to ${member.name}`)}>
              <Phone className="w-3.5 h-3.5" /> Call
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: owned services + assigned incidents */}
        <div className="space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Owned Services" description="Services this member owns or maintains" />
            {ownedServices.length > 0 ? (
              <div className="space-y-2">
                {ownedServices.map((s) => (
                  <Link key={s.id} href={`/services/${s.id}`} className="flex items-center gap-2.5 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors">
                    <div className="shrink-0 w-8 h-8 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                      <Server className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-mono font-medium truncate">{s.name}</div>
                      <div className="text-[10px] text-muted-foreground">{s.language} · {s.framework}</div>
                    </div>
                    <StatusDot color={s.health === "operational" ? "success" : s.health === "degraded" ? "warning" : "destructive"} pulse={s.health === "operational"} />
                  </Link>
                ))}
              </div>
            ) : teamServices.length > 0 ? (
              <div className="space-y-2">
                <p className="text-[11px] text-muted-foreground">No direct ownership. Team services:</p>
                {teamServices.slice(0, 5).map((s) => (
                  <Link key={s.id} href={`/services/${s.id}`} className="flex items-center gap-2.5 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors">
                    <div className="shrink-0 w-8 h-8 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
                      <Server className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-mono font-medium truncate">{s.name}</div>
                      <div className="text-[10px] text-muted-foreground">{s.language}</div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground py-4 text-center">No service ownership</p>
            )}
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading
              title="Assigned Incidents"
              description="As commander or responder"
              action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/incidents">View all <ChevronRight className="w-3 h-3" /></Link></Button>}
            />
            {assignedIncidents.length > 0 ? (
              <div className="space-y-2">
                {assignedIncidents.map((inc) => (
                  <Link key={inc.id} href={`/incidents/${inc.id}`} className="flex items-start gap-2.5 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors">
                    <div className="shrink-0 w-7 h-7 rounded-md bg-destructive/10 text-destructive flex items-center justify-center">
                      <Siren className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] font-mono font-medium">{inc.ref}</span>
                        <SeverityBadge severity={inc.severity} size="sm" />
                      </div>
                      <p className="text-xs mt-0.5 truncate">{inc.title}</p>
                      <div className="flex items-center gap-1 mt-0.5">
                        <IncidentStatusBadge status={inc.status} />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground py-4 text-center">No active incident assignments</p>
            )}
          </Card>
        </div>

        {/* Middle: recent activity + on-call shifts */}
        <div className="space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading
              title="Recent Activity"
              description="Audit events performed by this member"
              action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/security/audit">Audit <ChevronRight className="w-3 h-3" /></Link></Button>}
            />
            {recentActivity.length > 0 ? (
              <div className="space-y-2">
                {recentActivity.map((evt) => (
                  <div key={evt.id} className="flex items-start gap-2.5 p-2.5 rounded-lg border">
                    <div className="shrink-0 w-7 h-7 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
                      <Activity className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-[11px] font-mono">{evt.action}</div>
                      <div className="text-[10px] text-muted-foreground">{evt.resourceType} · {evt.resourceId}</div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">{new Date(evt.timestamp).toLocaleString()}</div>
                    </div>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${evt.result === "success" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`}>
                      {evt.result}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground py-4 text-center">No recent activity</p>
            )}
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Upcoming On-Call Shifts" description="Scheduled rotations" />
            <div className="space-y-2">
              {upcomingShifts.map((shift) => (
                <div key={shift.id} className="flex items-start gap-2.5 p-2.5 rounded-lg border">
                  <div className={`shrink-0 w-7 h-7 rounded-md flex items-center justify-center ${
                    shift.role === "Primary" ? "bg-destructive/10 text-destructive" :
                    shift.role === "Secondary" ? "bg-warning/10 text-warning-foreground" :
                    "bg-info/10 text-info-foreground"
                  }`}>
                    <Calendar className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-medium">{shift.role}</span>
                      <span className="text-[10px] text-muted-foreground">· {shift.team}</span>
                    </div>
                    <div className="text-[11px] text-muted-foreground mt-0.5">
                      {new Date(shift.start).toLocaleDateString()} → {new Date(shift.end).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right: action items + quick stats */}
        <div className="space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading
              title="Action Items"
              description="From postmortem action items"
              action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/postmortems/action-items">All <ChevronRight className="w-3 h-3" /></Link></Button>}
            />
            {actionItems.length > 0 ? (
              <div className="space-y-2">
                {actionItems.map((a) => (
                  <div key={a.id} className="flex items-start gap-2.5 p-2.5 rounded-lg border">
                    <div className={`shrink-0 w-7 h-7 rounded-md flex items-center justify-center ${
                      a.status === "done" ? "bg-success/10 text-success" :
                      a.status === "in_progress" ? "bg-info/10 text-info-foreground" :
                      "bg-muted text-muted-foreground"
                    }`}>
                      <CheckSquare className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs truncate">{a.description}</p>
                      <div className="flex items-center gap-1.5 mt-1">
                        <SeverityBadge severity={a.priority} size="sm" />
                        <span className="text-[10px] text-muted-foreground capitalize">{a.status.replace("_", " ")}</span>
                        <span className="text-[10px] text-muted-foreground">· due {a.dueDate}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground py-4 text-center">No open action items</p>
            )}
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Quick Stats" description="Engagement summary" />
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border p-3">
                <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                  <Siren className="w-3 h-3" /> Incidents
                </div>
                <div className="text-xl font-semibold tabular-nums mt-1">{assignedIncidents.length}</div>
                <div className="text-[10px] text-muted-foreground">assigned</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                  <Server className="w-3 h-3" /> Services
                </div>
                <div className="text-xl font-semibold tabular-nums mt-1">{ownedServices.length || teamServices.length}</div>
                <div className="text-[10px] text-muted-foreground">owned</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                  <CheckSquare className="w-3 h-3" /> Action Items
                </div>
                <div className="text-xl font-semibold tabular-nums mt-1">{actionItems.length}</div>
                <div className="text-[10px] text-muted-foreground">open</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                  <Activity className="w-3 h-3" /> Actions
                </div>
                <div className="text-xl font-semibold tabular-nums mt-1">{recentActivity.length}</div>
                <div className="text-[10px] text-muted-foreground">recent</div>
              </div>
            </div>
            <Separator />
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Last active</span>
                <span className="font-medium">{timeAgo(recentActivity[0]?.timestamp || "2026-06-15T00:00:00Z")}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Local time</span>
                <span className="font-medium font-mono">{new Date().toLocaleTimeString("en-US", { timeZone: member.timezone, hour: "2-digit", minute: "2-digit" })}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Timezone offset</span>
                <span className="font-medium">UTC{new Intl.DateTimeFormat("en-US", { timeZone: member.timezone, timeZoneName: "shortOffset" }).formatToParts(new Date()).find((p) => p.type === "timeZoneName")?.value || ""}</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
