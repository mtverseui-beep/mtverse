"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  BadgeCheck, Shield, Eye, Crown, Lock, Users, Plus, Pencil, ChevronRight,
  Server, Database, Key, Activity, Settings,
} from "lucide-react";
import { people } from "@/lib/data";
import { toast } from "sonner";

interface RoleDef {
  id: string;
  name: string;
  description: string;
  memberCount: number;
  permissionsCount: number;
  color: string;
  icon: React.ReactNode;
  isSystem?: boolean;
}

const roles: RoleDef[] = [
  { id: "r1", name: "Admin", description: "Full access to all workspace resources, settings, and member management.", memberCount: 2, permissionsCount: 48, color: "#F87171", icon: <Crown className="w-4 h-4" />, isSystem: true },
  { id: "r2", name: "Engineer", description: "Read and write access to services, deployments, and incident response tooling.", memberCount: 9, permissionsCount: 32, color: "#22D3EE", icon: <Settings className="w-4 h-4" />, isSystem: true },
  { id: "r3", name: "On-Call Engineer", description: "Acknowledges alerts, manages incidents, and triggers escalations.", memberCount: 5, permissionsCount: 24, color: "#A78BFA", icon: <Activity className="w-4 h-4" />, isSystem: true },
  { id: "r4", name: "Viewer", description: "Read-only access to dashboards, reports, and historical data.", memberCount: 12, permissionsCount: 16, color: "#34D399", icon: <Eye className="w-4 h-4" />, isSystem: true },
  { id: "r5", name: "Billing", description: "Manage subscription, payment methods, invoices, and usage reports.", memberCount: 2, permissionsCount: 8, color: "#F59E0B", icon: <BadgeCheck className="w-4 h-4" />, isSystem: true },
  { id: "r6", name: "Security", description: "Manage vulnerabilities, compliance, audit trails, and access reviews.", memberCount: 2, permissionsCount: 28, color: "#FB923C", icon: <Shield className="w-4 h-4" />, isSystem: true },
];

// Permission groups for the edit modal preview
const permissionGroups = [
  { name: "Services", icon: <Server className="w-3.5 h-3.5" />, perms: ["view", "create", "edit", "delete"] },
  { name: "Incidents", icon: <Activity className="w-3.5 h-3.5" />, perms: ["view", "create", "edit", "resolve"] },
  { name: "Deployments", icon: <Settings className="w-3.5 h-3.5" />, perms: ["view", "approve", "rollback", "promote"] },
  { name: "Databases", icon: <Database className="w-3.5 h-3.5" />, perms: ["view", "query", "export"] },
  { name: "Secrets", icon: <Key className="w-3.5 h-3.5" />, perms: ["view", "rotate", "revoke"] },
  { name: "Members", icon: <Users className="w-3.5 h-3.5" />, perms: ["view", "invite", "edit_role", "remove"] },
];

export default function RolesPage() {
  const [selectedRole, setSelectedRole] = React.useState<RoleDef | null>(null);
  const totalRoles = roles.length;
  const totalMembers = roles.reduce((s, r) => s + r.memberCount, 0);
  const systemRoles = roles.filter((r) => r.isSystem).length;
  const avgPerms = Math.round(roles.reduce((s, r) => s + r.permissionsCount, 0) / roles.length);

  return (
    <PageContainer>
      <PageHeader
        title="Roles"
        description="Workspace roles and the permissions granted to each. System roles are predefined; custom roles can be created."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Roles" }]}
        icon={<BadgeCheck className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Create role dialog opened")}>
            <Plus className="w-3.5 h-3.5" />
            New Role
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Roles" value={totalRoles} hint={`${systemRoles} system`} icon={<BadgeCheck className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Assigned Members" value={totalMembers} icon={<Users className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg Permissions" value={avgPerms} hint="per role" icon={<Lock className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Custom Roles" value={totalRoles - systemRoles} hint="user-defined" icon={<Pencil className="w-4 h-4" />} accent="success" />
      </div>

      {/* Roles grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {roles.map((r) => (
          <Card key={r.id} className="p-5 space-y-4 hover:border-primary/30 transition-colors">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-3 min-w-0">
                <div className="shrink-0 w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: `${r.color}20`, color: r.color, border: `1px solid ${r.color}40` }}>
                  {r.icon}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-semibold truncate">{r.name}</h3>
                    {r.isSystem && (
                      <Badge variant="outline" className="text-[9px] uppercase tracking-wider h-4 px-1">System</Badge>
                    )}
                  </div>
                  <p className="text-[10px] text-muted-foreground">{r.permissionsCount} permissions</p>
                </div>
              </div>
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3">{r.description}</p>

            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-md border p-2.5">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Members</div>
                <div className="text-lg font-semibold tabular-nums mt-0.5">{r.memberCount}</div>
              </div>
              <div className="rounded-md border p-2.5">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Permissions</div>
                <div className="text-lg font-semibold tabular-nums mt-0.5">{r.permissionsCount}</div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 pt-2 border-t border-border">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 h-7 text-xs gap-1"
                onClick={() => { setSelectedRole(r); toast.info(`Editing permissions for ${r.name}`); }}
              >
                <Pencil className="w-3 h-3" /> Edit Permissions
              </Button>
              {!r.isSystem && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 text-xs gap-1 text-destructive hover:text-destructive"
                  onClick={() => toast.error(`Delete role "${r.name}"?`)}
                >
                  Delete
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Permissions preview (when role selected) */}
      {selectedRole && (
        <Card className="p-5 space-y-4 border-primary/30">
          <SectionHeading
            title={`Permissions: ${selectedRole.name}`}
            description="Resource-level permission matrix for this role"
            action={
              <Button variant="ghost" size="sm" className="text-xs h-7 gap-1" onClick={() => setSelectedRole(null)}>
                Close <ChevronRight className="w-3 h-3 rotate-90" />
              </Button>
            }
          />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/40">
                <tr>
                  <th className="px-3 py-2.5 text-left text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Resource</th>
                  <th className="px-3 py-2.5 text-left text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Permissions Granted</th>
                  <th className="px-3 py-2.5 text-right text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Coverage</th>
                </tr>
              </thead>
              <tbody>
                {permissionGroups.map((g) => {
                  // Mock: each role gets a subset based on its permissionsCount
                  const granted = g.perms.slice(0, Math.ceil((selectedRole.permissionsCount / 48) * g.perms.length));
                  const pct = Math.round((granted.length / g.perms.length) * 100);
                  return (
                    <tr key={g.name} className="border-t border-border">
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">{g.icon}</span>
                          <span className="text-xs font-medium">{g.name}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-1 flex-wrap">
                          {granted.map((p) => (
                            <span key={p} className="text-[10px] px-1.5 py-0.5 rounded bg-success/15 text-success border border-success/30 font-mono">
                              {p}
                            </span>
                          ))}
                          {g.perms.slice(granted.length).map((p) => (
                            <span key={p} className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border font-mono line-through opacity-50">
                              {p}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2 justify-end">
                          <Progress value={pct} className="h-1.5 flex-1 max-w-[80px] [&_>div]:bg-primary" />
                          <span className="text-[11px] font-mono tabular-nums w-10 text-right">{pct}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="flex items-center gap-2 pt-3 border-t border-border">
            <Button size="sm" className="gap-1.5" onClick={() => toast.success(`Permissions saved for ${selectedRole.name}`)}>
              <Lock className="w-3.5 h-3.5" /> Save Changes
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setSelectedRole(null)}>
              Cancel
            </Button>
          </div>
        </Card>
      )}
    </PageContainer>
  );
}
