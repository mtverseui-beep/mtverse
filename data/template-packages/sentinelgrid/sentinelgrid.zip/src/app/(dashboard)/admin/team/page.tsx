"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Users, UserPlus, UserCheck, Crown, Mail, Clock,
  Download, ChevronRight, Globe, ShieldAlert,
} from "lucide-react";
import { people, teams } from "@/lib/data";
import type { Person } from "@/lib/types";
import { toast } from "sonner";

const teamOptions = teams.map((t) => ({ label: t.name, value: t.id }));
const roleOptions = Array.from(new Set(people.map((p) => p.role))).map((r) => ({
  label: r,
  value: r,
}));

function teamColor(t: string): string {
  return teams.find((tm) => tm.name === t)?.color || "#888888";
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

// Mock last-active timestamps based on person ID
function lastActive(id: string): string {
  const map: Record<string, string> = {
    u1: "2026-07-02T05:48:00Z", u2: "2026-07-02T05:14:00Z", u3: "2026-07-02T03:20:00Z",
    u4: "2026-07-01T22:45:00Z", u5: "2026-07-01T18:20:00Z", u6: "2026-07-02T05:48:00Z",
    u7: "2026-07-01T13:58:00Z", u8: "2026-07-01T08:32:00Z", u9: "2026-06-30T20:18:00Z",
    u10: "2026-06-30T14:18:00Z", u11: "2026-06-29T09:00:00Z", u12: "2026-07-02T04:30:00Z",
    u13: "2026-07-01T16:08:00Z", u14: "2026-06-30T11:22:00Z", u15: "2026-07-01T22:30:00Z",
    u16: "2026-07-02T05:50:00Z",
  };
  return map[id] || "2026-06-15T00:00:00Z";
}

export default function TeamMembersPage() {
  const total = people.length;
  const active = people.filter((p) => timeAgo(lastActive(p.id)).includes("m") || timeAgo(lastActive(p.id)).includes("h")).length;
  const admins = people.filter((p) => p.role.toLowerCase().includes("manager") || p.role.toLowerCase().includes("director")).length;
  const pendingInvites = 3;

  const columns: Column<Person>[] = [
    {
      key: "name", header: "Member", sortable: true, sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <img src={r.avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />
          <div className="min-w-0">
            <div className="text-xs font-medium truncate">{r.name}</div>
            <div className="text-[10px] text-muted-foreground truncate">@{r.handle}</div>
          </div>
        </div>
      ),
    },
    {
      key: "email", header: "Email", hideOnMobile: true,
      cell: (r) => (
        <span className="text-[11px] text-muted-foreground inline-flex items-center gap-1">
          <Mail className="w-3 h-3" /> {r.email}
        </span>
      ),
    },
    {
      key: "role", header: "Role", sortable: true, sortValue: (r) => r.role,
      filterable: true, filterOptions: roleOptions, filterFn: (r, v) => r.role === v,
      cell: (r) => <span className="text-xs">{r.role}</span>,
    },
    {
      key: "team", header: "Team", sortable: true, sortValue: (r) => r.team,
      filterable: true, filterOptions: teamOptions, filterFn: (r, v) => teams.find((t) => t.id === v)?.name === r.team,
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full" style={{ background: teamColor(r.team) }} />
          <span className="text-xs">{r.team}</span>
        </div>
      ),
    },
    {
      key: "timezone", header: "Timezone", hideOnMobile: true,
      cell: (r) => (
        <span className="text-[11px] text-muted-foreground inline-flex items-center gap-1">
          <Globe className="w-3 h-3" /> {r.timezone.split("/")[1].replace("_", " ")}
        </span>
      ),
    },
    {
      key: "status", header: "Status",
      cell: (r) => {
        const ago = timeAgo(lastActive(r.id));
        const isActive = ago.includes("m");
        return (
          <span className={`inline-flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded font-medium ${
            isActive ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${isActive ? "bg-success animate-status-pulse" : "bg-muted-foreground"}`} />
            {isActive ? "Online" : "Offline"}
          </span>
        );
      },
    },
    {
      key: "lastActive", header: "Last Active", sortable: true, sortValue: (r) => lastActive(r.id), hideOnMobile: true,
      cell: (r) => (
        <span className="text-[11px] text-muted-foreground inline-flex items-center gap-1">
          <Clock className="w-3 h-3" /> {timeAgo(lastActive(r.id))}
        </span>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Team Members"
        description="Manage workspace members, roles, and team assignments."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Team Members" }]}
        icon={<Users className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting team directory...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Invite sent", { description: "Invitation email delivered to recipient." })}>
              <UserPlus className="w-3.5 h-3.5" />
              Invite Member
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Members" value={total} icon={<Users className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Active Now" value={active} hint="seen in last 24h" icon={<UserCheck className="w-4 h-4" />} accent="success" />
        <KpiCard label="Admins" value={admins} hint="managers + directors" icon={<Crown className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Pending Invites" value={pendingInvites} hint="awaiting acceptance" icon={<Mail className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Member Directory"
          description="Filter by team or role. Click a member for full profile."
          action={
            <Button variant="outline" size="sm" className="text-xs h-8 gap-1.5" onClick={() => toast.info("Bulk import flow opened")}>
              <UserPlus className="w-3.5 h-3.5" /> Bulk Import
            </Button>
          }
        />
        <DataTable
          columns={columns}
          data={people}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.name, (r) => r.email, (r) => r.handle, (r) => r.role]}
          searchPlaceholder="Search name, email, role..."
          pageSize={10}
          onRowClick={(r) => { window.location.href = `/admin/team/${r.id}`; }}
          mobileCard={(r) => (
            <div className="rounded-lg border bg-card p-3 space-y-2">
              <div className="flex items-center gap-2.5">
                <img src={r.avatarUrl} alt="" className="w-9 h-9 rounded-full object-cover" />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-medium truncate">{r.name}</div>
                  <div className="text-[10px] text-muted-foreground truncate">{r.role}</div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ background: teamColor(r.team) }} />
                  {r.team}
                </div>
                <span>{timeAgo(lastActive(r.id))}</span>
              </div>
            </div>
          )}
        />
      </Card>

      {/* Pending invites banner */}
      <Card className="p-5 space-y-4 border-warning/30">
        <SectionHeading
          title="Pending Invitations"
          description="Awaiting acceptance"
          action={<Button variant="ghost" size="sm" className="text-xs h-7 gap-1">Resend all <ChevronRight className="w-3 h-3" /></Button>}
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {[
            { email: "rpatel@sentinelgrid.io", invited: "2026-07-01", role: "Senior SRE", team: "Reliability" },
            { email: "jdoe@sentinelgrid.io", invited: "2026-06-28", role: "Backend Engineer", team: "Payments" },
            { email: "kliu@sentinelgrid.io", invited: "2026-06-25", role: "Frontend Engineer", team: "Web" },
          ].map((inv, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg border">
              <div className="shrink-0 w-9 h-9 rounded-md bg-warning/10 text-warning-foreground border border-warning/20 flex items-center justify-center">
                <Mail className="w-4 h-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-medium truncate">{inv.email}</div>
                <div className="text-[10px] text-muted-foreground">{inv.role} · {inv.team}</div>
                <div className="text-[10px] text-muted-foreground">invited {inv.invited}</div>
              </div>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success("Invitation resent", { description: inv.email })}>
                Resend
              </Button>
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
