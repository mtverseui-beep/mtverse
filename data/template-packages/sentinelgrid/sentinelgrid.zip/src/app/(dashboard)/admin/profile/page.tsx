"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Column, DataTable } from "@/components/tables/data-table";
import { toast } from "sonner";
import {
  User, Palette, ShieldCheck, Bell, KeyRound, Mail, Smartphone,
  Monitor, Save, Globe, Upload, Check, Copy, Plus, Trash2, LogOut,
  Clock, Sun, Moon, Languages, Layout, Calendar,
} from "lucide-react";
import { people } from "@/lib/data";
import type { APIKey } from "@/lib/types";

const me = people[0];

interface PersonalToken {
  id: string;
  name: string;
  prefix: string;
  scopes: string[];
  created: string;
  lastUsed: string;
}

const personalTokens: PersonalToken[] = [
  { id: "pt1", name: "Local Development", prefix: "sg_pat_8f3a", scopes: ["metrics:read", "alerts:read"], created: "2026-05-12", lastUsed: "2026-07-02T05:14:00Z" },
  { id: "pt2", name: "CLI Tool", prefix: "sg_pat_2c9d", scopes: ["incidents:write"], created: "2026-04-02", lastUsed: "2026-07-01T18:22:00Z" },
];

const languages = [
  { code: "en", label: "English" },
  { code: "es", label: "Español" },
  { code: "fr", label: "Français" },
  { code: "de", label: "Deutsch" },
  { code: "ja", label: "日本語" },
  { code: "zh", label: "中文" },
];

const timezones = [
  "America/Los_Angeles", "America/Denver", "America/Chicago", "America/New_York",
  "America/Mexico_City", "Europe/London", "Europe/Paris", "Europe/Berlin",
  "Asia/Kolkata", "Asia/Shanghai", "Asia/Tokyo",
];

interface NotificationPref {
  event: string;
  description: string;
  email: boolean;
  push: boolean;
  slack: boolean;
}

const initialPrefs: NotificationPref[] = [
  { event: "Incident Created", description: "A new incident is declared in your team.", email: true, push: true, slack: true },
  { event: "Incident Severity Escalated", description: "An incident severity is raised.", email: true, push: true, slack: true },
  { event: "Incident Resolved", description: "An incident you're responding to is resolved.", email: true, push: false, slack: true },
  { event: "Alert Firing", description: "A new alert starts firing.", email: false, push: true, slack: true },
  { event: "On-Call Handoff", description: "You're going on call.", email: true, push: true, slack: false },
  { event: "Deployment Failed", description: "A deployment in your team fails.", email: false, push: false, slack: true },
  { event: "Postmortem Published", description: "A postmortem you're reviewing is published.", email: true, push: false, slack: false },
  { event: "Weekly Digest", description: "Monday morning reliability summary.", email: true, push: false, slack: false },
];

const mySessions = [
  { id: "ms1", device: "MacBook Pro 16\"", browser: "Chrome 126", ip: "10.42.18.10", location: "San Francisco, US", lastActive: "2026-07-02T05:48:00Z", current: true },
  { id: "ms2", device: "iPhone 15 Pro", browser: "Safari Mobile", ip: "10.42.18.10", location: "San Francisco, US", lastActive: "2026-07-01T22:45:00Z", current: false },
  { id: "ms3", device: "iPad Pro", browser: "Safari 17", ip: "10.42.18.10", location: "San Francisco, US", lastActive: "2026-06-28T08:30:00Z", current: false },
];

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export default function MyProfilePage() {
  const [activeTab, setActiveTab] = React.useState("personal");
  const [theme, setTheme] = React.useState("system");
  const [density, setDensity] = React.useState("comfortable");
  const [sidebarDefault, setSidebarDefault] = React.useState("expanded");
  const [timeFormat, setTimeFormat] = React.useState("24h");
  const [language, setLanguage] = React.useState("en");
  const [tz, setTz] = React.useState(me.timezone);
  const [mfaEnabled, setMfaEnabled] = React.useState(true);
  const [prefs, setPrefs] = React.useState<NotificationPref[]>(initialPrefs);

  function save(section: string) {
    toast.success(`${section} saved`, { description: "Your preferences have been updated." });
  }
  function togglePref(idx: number, channel: "email" | "push" | "slack") {
    setPrefs((prev) => prev.map((p, i) => i === idx ? { ...p, [channel]: !p[channel] } : p));
  }

  return (
    <PageContainer>
      <PageHeader
        title="My Profile"
        description="Manage your personal information, preferences, security, and notification settings."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "My Profile" }]}
        icon={<User className="w-5 h-5" />}
      />

      {/* Hero */}
      <Card className="p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none" />
        <div className="relative flex flex-col md:flex-row md:items-center gap-4">
          <Avatar className="w-20 h-20 shrink-0 border-2 border-primary/20">
            <AvatarImage src={me.avatarUrl} alt={me.name} />
            <AvatarFallback>{me.name[0]}</AvatarFallback>
          </Avatar>
          <div className="min-w-0 space-y-1 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-semibold tracking-tight">{me.name}</h2>
              <Badge variant="outline" className="text-[10px]">@{me.handle}</Badge>
            </div>
            <p className="text-sm text-muted-foreground">{me.title}</p>
            <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
              <span className="inline-flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> {me.role}</span>
              <span className="inline-flex items-center gap-1"><Globe className="w-3 h-3" /> {tz.replace(/_/g, " ")}</span>
              <span className="inline-flex items-center gap-1"><Mail className="w-3 h-3" /> {me.email}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {mfaEnabled && <Badge variant="outline" className="text-[10px] gap-1 bg-success/10 text-success border-success/30"><Check className="w-3 h-3" /> MFA on</Badge>}
            <Badge variant="outline" className="text-[10px] gap-1">{me.team}</Badge>
          </div>
        </div>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full justify-start overflow-x-auto h-auto flex-wrap">
          <TabsTrigger value="personal" className="gap-1.5"><User className="w-3.5 h-3.5" /> Personal Info</TabsTrigger>
          <TabsTrigger value="preferences" className="gap-1.5"><Palette className="w-3.5 h-3.5" /> Preferences</TabsTrigger>
          <TabsTrigger value="security" className="gap-1.5"><ShieldCheck className="w-3.5 h-3.5" /> Security</TabsTrigger>
          <TabsTrigger value="notifications" className="gap-1.5"><Bell className="w-3.5 h-3.5" /> Notifications</TabsTrigger>
          <TabsTrigger value="api" className="gap-1.5"><KeyRound className="w-3.5 h-3.5" /> API Access</TabsTrigger>
        </TabsList>

        {/* PERSONAL INFO */}
        <TabsContent value="personal" className="mt-4">
          <Card className="p-6 space-y-5">
            <SectionHeading title="Personal Information" description="Update your name, contact details, and bio." />
            <Separator />
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex flex-col items-center gap-3 shrink-0">
                <Avatar className="w-24 h-24 border-2 border-border">
                  <AvatarImage src={me.avatarUrl} alt={me.name} />
                  <AvatarFallback>{me.name[0]}</AvatarFallback>
                </Avatar>
                <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Avatar upload started")}>
                  <Upload className="w-3.5 h-3.5" /> Upload
                </Button>
                <Button variant="ghost" size="sm" className="text-xs text-destructive hover:text-destructive" onClick={() => toast.info("Avatar removed")}>
                  Remove
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 flex-1">
                <Field label="Full Name">
                  <Input defaultValue={me.name} />
                </Field>
                <Field label="Email">
                  <Input type="email" defaultValue={me.email} />
                </Field>
                <Field label="Title">
                  <Input defaultValue={me.title} />
                </Field>
                <Field label="Handle">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground font-mono">@</span>
                    <Input defaultValue={me.handle} className="font-mono" />
                  </div>
                </Field>
                <Field label="Timezone">
                  <Select value={tz} onValueChange={setTz}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent className="max-h-72">
                      {timezones.map((t) => <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Phone (optional)">
                  <Input type="tel" defaultValue="+1 (415) 555-0142" />
                </Field>
                <div className="md:col-span-2">
                  <Field label="Bio" hint="Brief description shown on your profile.">
                    <Textarea
                      defaultValue="Director of Platform Engineering. Passionate about reliability, observability, and shipping fast without breaking things."
                      className="min-h-[80px] resize-none"
                    />
                  </Field>
                </div>
              </div>
            </div>
            <SaveBar onSave={() => save("Personal info")} />
          </Card>
        </TabsContent>

        {/* PREFERENCES */}
        <TabsContent value="preferences" className="mt-4">
          <Card className="p-6 space-y-5">
            <SectionHeading title="Preferences" description="Customize appearance and locale." />
            <Separator />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <Field label="Theme" hint="Affects all devices.">
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: "light", label: "Light", icon: Sun },
                    { value: "dark", label: "Dark", icon: Moon },
                    { value: "system", label: "System", icon: Monitor },
                  ].map((opt) => {
                    const Icon = opt.icon;
                    return (
                      <button
                        key={opt.value}
                        onClick={() => { setTheme(opt.value); toast.info(`Theme set to ${opt.label}`); }}
                        className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border-2 transition-colors ${theme === opt.value ? "border-primary bg-primary/5" : "border-border hover:bg-muted/30"}`}
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-xs">{opt.label}</span>
                      </button>
                    );
                  })}
                </div>
              </Field>
              <Field label="Density" hint="Row height in tables and lists.">
                <Select value={density} onValueChange={setDensity}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="compact">Compact</SelectItem>
                    <SelectItem value="comfortable">Comfortable</SelectItem>
                    <SelectItem value="spacious">Spacious</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Sidebar Default" hint="Initial state on page load.">
                <Select value={sidebarDefault} onValueChange={setSidebarDefault}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="expanded">Expanded</SelectItem>
                    <SelectItem value="collapsed">Collapsed</SelectItem>
                    <SelectItem value="remember">Remember last</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Time Format">
                <Select value={timeFormat} onValueChange={setTimeFormat}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="12h">12-hour (1:30 PM)</SelectItem>
                    <SelectItem value="24h">24-hour (13:30)</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Date Format">
                <Select defaultValue="iso">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="iso">YYYY-MM-DD</SelectItem>
                    <SelectItem value="us">MM/DD/YYYY</SelectItem>
                    <SelectItem value="eu">DD/MM/YYYY</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Language" hint="UI language.">
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {languages.map((l) => <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
            </div>
            <SaveBar onSave={() => save("Preferences")} />
          </Card>
        </TabsContent>

        {/* SECURITY */}
        <TabsContent value="security" className="mt-4 space-y-4">
          <Card className="p-6 space-y-5">
            <SectionHeading title="Change Password" description="Use a strong, unique password." />
            <Separator />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-2xl">
              <div className="md:col-span-2">
                <Field label="Current Password">
                  <Input type="password" placeholder="••••••••••••" />
                </Field>
              </div>
              <Field label="New Password">
                <Input type="password" placeholder="••••••••••••" />
              </Field>
              <Field label="Confirm New Password">
                <Input type="password" placeholder="••••••••••••" />
              </Field>
            </div>
            <SaveBar onSave={() => save("Password")} />
          </Card>

          <Card className="p-6 space-y-5">
            <SectionHeading title="Multi-Factor Authentication" description="Add a second factor to your account." />
            <Separator />
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="shrink-0 w-9 h-9 rounded-lg bg-success/10 border border-success/20 flex items-center justify-center text-success">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-sm font-medium">TOTP Authenticator</div>
                    <div className="text-xs text-muted-foreground">Configured on 2026-02-14</div>
                  </div>
                </div>
                <Switch checked={mfaEnabled} onCheckedChange={setMfaEnabled} />
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="shrink-0 w-9 h-9 rounded-lg bg-muted border flex items-center justify-center text-muted-foreground">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-sm font-medium">WebAuthn / Security Key</div>
                    <div className="text-xs text-muted-foreground">Not configured</div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("WebAuthn setup started")}>
                  <Plus className="w-3.5 h-3.5" /> Add
                </Button>
              </div>
            </div>
          </Card>

          <Card className="p-6 space-y-4">
            <SectionHeading title="Active Sessions" description="Devices currently signed in to your account." />
            <div className="space-y-2">
              {mySessions.map((s) => (
                <div key={s.id} className="flex items-center gap-3 p-3 rounded-lg border">
                  <div className="shrink-0 w-9 h-9 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
                    {s.device.includes("iPhone") || s.device.includes("iPad") ? <Smartphone className="w-4 h-4" /> : <Monitor className="w-4 h-4" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-medium truncate">{s.device}</span>
                      {s.current && <Badge variant="outline" className="text-[9px] bg-success/10 text-success border-success/30">Current</Badge>}
                    </div>
                    <div className="text-[10px] text-muted-foreground truncate">
                      {s.browser} · {s.location} · <span className="font-mono">{s.ip}</span> · {timeAgo(s.lastActive)}
                    </div>
                  </div>
                  {!s.current && (
                    <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-destructive hover:text-destructive shrink-0" onClick={() => toast.success("Session revoked")}>
                      <LogOut className="w-3 h-3" /> Revoke
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* NOTIFICATIONS */}
        <TabsContent value="notifications" className="mt-4">
          <Card className="p-6 space-y-5">
            <SectionHeading
              title="Notification Preferences"
              description="Choose how you want to be notified for each event type."
              action={
                <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                  <Mail className="w-3 h-3" /> Email
                  <Smartphone className="w-3 h-3 ml-2" /> Push
                  <Bell className="w-3 h-3 ml-2" /> Slack
                </div>
              }
            />
            <Separator />
            <div className="space-y-1">
              {prefs.map((p, idx) => (
                <div key={p.event} className="flex flex-col md:flex-row md:items-center justify-between gap-3 py-3 border-b border-border/50 last:border-0">
                  <div className="min-w-0 space-y-0.5 flex-1">
                    <div className="text-sm font-medium">{p.event}</div>
                    <p className="text-xs text-muted-foreground">{p.description}</p>
                  </div>
                  <div className="flex items-center gap-4 shrink-0">
                    <ChannelToggle active={p.email} onClick={() => togglePref(idx, "email")} icon={<Mail className="w-3.5 h-3.5" />} label="Email" />
                    <ChannelToggle active={p.push} onClick={() => togglePref(idx, "push")} icon={<Smartphone className="w-3.5 h-3.5" />} label="Push" />
                    <ChannelToggle active={p.slack} onClick={() => togglePref(idx, "slack")} icon={<Bell className="w-3.5 h-3.5" />} label="Slack" />
                  </div>
                </div>
              ))}
            </div>
            <SaveBar onSave={() => save("Notification preferences")} />
          </Card>
        </TabsContent>

        {/* API ACCESS */}
        <TabsContent value="api" className="mt-4 space-y-4">
          <Card className="p-6 space-y-4">
            <SectionHeading
              title="Personal API Tokens"
              description="Use these tokens to authenticate with the SentinelGrid API on your behalf."
              action={
                <Button size="sm" className="gap-1.5" onClick={() => toast.success("New token created", { description: "Copy the secret now; it won't be shown again." })}>
                  <Plus className="w-3.5 h-3.5" /> Generate Token
                </Button>
              }
            />
            <div className="space-y-2">
              {personalTokens.map((t) => (
                <div key={t.id} className="flex items-center gap-3 p-3 rounded-lg border">
                  <div className="shrink-0 w-9 h-9 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="text-xs font-medium">{t.name}</div>
                    <div className="text-[10px] text-muted-foreground font-mono">{t.prefix}••••••••••••••••</div>
                    <div className="flex items-center gap-1.5 flex-wrap mt-1">
                      {t.scopes.map((s) => (
                        <Badge key={s} variant="outline" className="text-[9px] font-mono">{s}</Badge>
                      ))}
                    </div>
                  </div>
                  <div className="hidden md:block text-right text-[10px] text-muted-foreground shrink-0">
                    <div>created {t.created}</div>
                    <div>last used {timeAgo(t.lastUsed)}</div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => toast.success("Token copied to clipboard")}>
                      <Copy className="w-3 h-3" />
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs text-destructive hover:text-destructive" onClick={() => toast.success("Token revoked")}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 space-y-3">
            <SectionHeading title="API Documentation" description="Quick reference for using your tokens." />
            <Separator />
            <div className="space-y-2">
              <div className="text-xs text-muted-foreground">Authentication header:</div>
              <pre className="text-[11px] font-mono p-3 rounded-lg bg-muted border overflow-x-auto">
{`curl https://api.sentinelgrid.io/v1/incidents \\
  -H "Authorization: Bearer sg_pat_xxxxxxxx"`}
              </pre>
            </div>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => { window.open("https://docs.sentinelgrid.io", "_blank"); }}>
              View full API docs
            </Button>
          </Card>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium">{label}</Label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}

function ChannelToggle({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      title={label}
      aria-label={label}
      aria-pressed={active}
      className={`w-8 h-8 rounded-md flex items-center justify-center border transition-colors ${
        active ? "bg-primary/10 border-primary/30 text-primary" : "bg-muted border-border text-muted-foreground hover:bg-muted/70"
      }`}
    >
      {icon}
    </button>
  );
}

function SaveBar({ onSave }: { onSave: () => void }) {
  return (
    <div className="flex items-center justify-end pt-2 border-t border-border">
      <Button size="sm" className="gap-1.5" onClick={onSave}>
        <Save className="w-3.5 h-3.5" /> Save changes
      </Button>
    </div>
  );
}
