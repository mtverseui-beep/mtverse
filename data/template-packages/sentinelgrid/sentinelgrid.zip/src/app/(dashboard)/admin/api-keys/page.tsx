"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Key, Plus, Download, Copy, Trash2, ShieldCheck, AlertTriangle,
  Clock, CheckCircle2, XCircle,
} from "lucide-react";
import { apiKeys, people } from "@/lib/data";
import type { APIKey } from "@/lib/types";
import { toast } from "sonner";

const statusOptions = [
  { label: "Active", value: "active" },
  { label: "Revoked", value: "revoked" },
  { label: "Expiring soon", value: "expiring" },
];

function daysUntil(iso: string): number {
  return Math.floor((new Date(iso).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
}
function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export default function ApiKeysPage() {
  const total = apiKeys.length;
  const active = apiKeys.filter((k) => !k.revokedAt).length;
  const revoked = apiKeys.filter((k) => k.revokedAt).length;
  const expiringSoon = apiKeys.filter((k) => k.expiresAt && daysUntil(k.expiresAt) <= 30 && !k.revokedAt).length;

  const columns: Column<APIKey>[] = [
    {
      key: "name", header: "Name", sortable: true, sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <div className="shrink-0 w-8 h-8 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
            <Key className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-medium truncate">{r.name}</div>
            <div className="text-[10px] text-muted-foreground font-mono truncate">{r.prefix}...</div>
          </div>
        </div>
      ),
    },
    {
      key: "prefix", header: "Prefix", hideOnMobile: true,
      cell: (r) => <span className="text-[11px] font-mono text-muted-foreground">{r.prefix}••••</span>,
    },
    {
      key: "scopes", header: "Scopes", hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-1 flex-wrap max-w-[200px]">
          {r.scopes.slice(0, 2).map((s) => (
            <span key={s} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted border border-border">
              {s}
            </span>
          ))}
          {r.scopes.length > 2 && (
            <span className="text-[10px] text-muted-foreground">+{r.scopes.length - 2}</span>
          )}
        </div>
      ),
    },
    {
      key: "createdBy", header: "Created By", hideOnMobile: true,
      cell: (r) => {
        const p = people.find((p) => p.id === r.createdBy);
        return p ? (
          <div className="flex items-center gap-1.5">
            <img src={p.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate">{p.name.split(" ")[0]}</span>
          </div>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
    },
    {
      key: "createdAt", header: "Created", sortable: true, sortValue: (r) => r.createdAt, hideOnMobile: true,
      cell: (r) => <span className="text-[11px] text-muted-foreground">{new Date(r.createdAt).toLocaleDateString()}</span>,
    },
    {
      key: "lastUsed", header: "Last Used", sortable: true, sortValue: (r) => r.lastUsed || "",
      cell: (r) => (
        <span className="text-[11px] text-muted-foreground">
          {r.lastUsed ? timeAgo(r.lastUsed) : "never"}
        </span>
      ),
    },
    {
      key: "expiresAt", header: "Expires", sortable: true, sortValue: (r) => r.expiresAt || "",
      cell: (r) => {
        if (!r.expiresAt) return <span className="text-[11px] text-muted-foreground">no expiry</span>;
        const days = daysUntil(r.expiresAt);
        return (
          <span className={`text-[11px] ${days <= 30 ? "text-warning-foreground" : "text-muted-foreground"}`}>
            {days > 0 ? `${days}d` : "expired"}
          </span>
        );
      },
    },
    {
      key: "status", header: "Status",
      filterable: true, filterOptions: statusOptions,
      filterFn: (r, v) => {
        if (v === "active") return !r.revokedAt;
        if (v === "revoked") return !!r.revokedAt;
        if (v === "expiring") return !r.revokedAt && !!r.expiresAt && daysUntil(r.expiresAt) <= 30;
        return true;
      },
      cell: (r) => {
        if (r.revokedAt) {
          return <span className="inline-flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded font-medium bg-muted text-muted-foreground"><XCircle className="w-3 h-3" /> Revoked</span>;
        }
        const expiring = r.expiresAt && daysUntil(r.expiresAt) <= 30;
        if (expiring) {
          return <span className="inline-flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded font-medium bg-warning/15 text-warning-foreground"><AlertTriangle className="w-3 h-3" /> Expiring</span>;
        }
        return <span className="inline-flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded font-medium bg-success/15 text-success"><CheckCircle2 className="w-3 h-3" /> Active</span>;
      },
    },
    {
      key: "actions", header: "", align: "right",
      cell: (r) => (
        <div className="flex items-center gap-1 justify-end">
          <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => toast.success("API key prefix copied", { description: r.prefix })}>
            <Copy className="w-3.5 h-3.5" />
          </Button>
          {!r.revokedAt && (
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => toast.error(`Revoke API key "${r.name}"?`, { description: "This action is irreversible." })}>
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          )}
        </div>
      ),
    },
  ];

  function createKey() {
    const mockKey = "sg_live_" + Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 24);
    toast.success("API key created", {
      description: "Copy this key now — it won't be shown again.",
      duration: 8000,
    });
    setTimeout(() => {
      toast.message(mockKey, { description: "Store this securely." });
    }, 500);
  }

  return (
    <PageContainer>
      <PageHeader
        title="API Keys"
        description="Programmatic access tokens for the SentinelGrid API. Manage scope, expiration, and revocation."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "API Keys" }]}
        icon={<Key className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting API keys list...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={createKey}>
              <Plus className="w-3.5 h-3.5" />
              Create Key
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Keys" value={total} icon={<Key className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Active" value={active} icon={<ShieldCheck className="w-4 h-4" />} accent="success" />
        <KpiCard label="Revoked" value={revoked} icon={<XCircle className="w-4 h-4" />} accent="muted" />
        <KpiCard label="Expiring Soon" value={expiringSoon} hint="within 30 days" icon={<Clock className="w-4 h-4" />} accent="warning" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="API Key Inventory"
          description="Filter by status. Revoke keys to immediately invalidate access."
          action={
            <Button variant="outline" size="sm" className="text-xs h-8 gap-1.5" onClick={() => toast.info("Scope editor opened")}>
              <ShieldCheck className="w-3.5 h-3.5" /> Manage Scopes
            </Button>
          }
        />
        <DataTable
          columns={columns}
          data={apiKeys}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.name, (r) => r.prefix, (r) => r.scopes.join(" ")]}
          searchPlaceholder="Search name, prefix, scope..."
          pageSize={10}
          mobileCard={(r) => (
            <div className="rounded-lg border bg-card p-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="shrink-0 w-7 h-7 rounded bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    <Key className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-medium truncate">{r.name}</span>
                </div>
                {r.revokedAt ? (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">Revoked</span>
                ) : r.expiresAt && daysUntil(r.expiresAt) <= 30 ? (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-warning/15 text-warning-foreground">Expiring</span>
                ) : (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-success/15 text-success">Active</span>
                )}
              </div>
              <div className="text-[10px] font-mono text-muted-foreground">{r.prefix}••••</div>
              <div className="flex flex-wrap gap-1">
                {r.scopes.map((s) => (
                  <span key={s} className="text-[9px] font-mono px-1 py-0.5 rounded bg-muted border">{s}</span>
                ))}
              </div>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground pt-1 border-t border-border">
                <span>Last used: {r.lastUsed ? timeAgo(r.lastUsed) : "never"}</span>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0"><Copy className="w-3 h-3" /></Button>
                  {!r.revokedAt && <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-destructive"><Trash2 className="w-3 h-3" /></Button>}
                </div>
              </div>
            </div>
          )}
        />
      </Card>

      {/* Scopes reference */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Available Scopes" description="Permission scopes that can be granted to API keys" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { scope: "services:read", desc: "View services and their metrics" },
            { scope: "services:write", desc: "Create, update, and delete services" },
            { scope: "incidents:read", desc: "View incidents and their timelines" },
            { scope: "incidents:write", desc: "Create and update incidents" },
            { scope: "deployments:write", desc: "Trigger and approve deployments" },
            { scope: "infrastructure:write", desc: "Manage hosts and infrastructure" },
            { scope: "metrics:read", desc: "Query metrics and dashboards" },
            { scope: "alerts:read", desc: "View alert rules and active alerts" },
            { scope: "audit:read", desc: "Read audit trail entries" },
          ].map((s) => (
            <div key={s.scope} className="flex items-start gap-2 p-2.5 rounded-lg border">
              <div className="shrink-0 w-6 h-6 rounded bg-muted flex items-center justify-center text-muted-foreground">
                <Key className="w-3 h-3" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-mono font-medium">{s.scope}</div>
                <div className="text-[10px] text-muted-foreground">{s.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
