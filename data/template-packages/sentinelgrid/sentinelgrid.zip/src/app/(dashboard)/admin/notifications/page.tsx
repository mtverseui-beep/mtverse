"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Bell, Mail, MessageSquare, Smartphone, Webhook, Radio, Plus,
  CheckCircle2, XCircle, Send, Settings2, Filter, Zap, Users, ArrowRight,
} from "lucide-react";

interface Channel {
  id: string;
  name: string;
  type: "email" | "sms" | "slack" | "pagerduty" | "webhook" | "push";
  configured: boolean;
  recipients: number;
  lastDelivery: string;
  icon: React.ReactNode;
  color: string;
}

const channels: Channel[] = [
  { id: "ch1", name: "Email", type: "email", configured: true, recipients: 16, lastDelivery: "2m ago", icon: <Mail className="w-4 h-4" />, color: "#22D3EE" },
  { id: "ch2", name: "Slack #incidents", type: "slack", configured: true, recipients: 42, lastDelivery: "2m ago", icon: <MessageSquare className="w-4 h-4" />, color: "#4A154B" },
  { id: "ch3", name: "Slack #alerts", type: "slack", configured: true, recipients: 38, lastDelivery: "8m ago", icon: <MessageSquare className="w-4 h-4" />, color: "#4A154B" },
  { id: "ch4", name: "PagerDuty", type: "pagerduty", configured: true, recipients: 12, lastDelivery: "1h ago", icon: <Radio className="w-4 h-4" />, color: "#06AC38" },
  { id: "ch5", name: "Mobile Push", type: "push", configured: true, recipients: 9, lastDelivery: "12m ago", icon: <Smartphone className="w-4 h-4" />, color: "#A78BFA" },
  { id: "ch6", name: "SMS (Twilio)", type: "sms", configured: false, recipients: 0, lastDelivery: "—", icon: <Smartphone className="w-4 h-4" />, color: "#F59E0B" },
  { id: "ch7", name: "Webhook (Internal)", type: "webhook", configured: true, recipients: 1, lastDelivery: "18m ago", icon: <Webhook className="w-4 h-4" />, color: "#34D399" },
  { id: "ch8", name: "Webhook (Analytics)", type: "webhook", configured: false, recipients: 0, lastDelivery: "—", icon: <Webhook className="w-4 h-4" />, color: "#34D399" },
];

interface RoutingRule {
  id: string;
  event: string;
  condition: string;
  channels: string[];
  enabled: boolean;
}

const initialRules: RoutingRule[] = [
  { id: "r1", event: "incident.created", condition: "severity in [critical, high]", channels: ["PagerDuty", "Slack #incidents", "Email"], enabled: true },
  { id: "r2", event: "incident.created", condition: "severity in [medium, low]", channels: ["Slack #incidents", "Email"], enabled: true },
  { id: "r3", event: "alert.firing", condition: "service.tier = tier1", channels: ["PagerDuty", "Slack #alerts"], enabled: true },
  { id: "r4", event: "alert.firing", condition: "service.tier != tier1", channels: ["Slack #alerts"], enabled: true },
  { id: "r5", event: "incident.resolved", condition: "always", channels: ["Slack #incidents", "Email"], enabled: true },
  { id: "r6", event: "deployment.failed", condition: "always", channels: ["Slack #incidents"], enabled: false },
];

export default function NotificationChannelsPage() {
  const [rules, setRules] = React.useState<RoutingRule[]>(initialRules);
  const configured = channels.filter((c) => c.configured).length;
  const totalRecipients = channels.reduce((s, c) => s + c.recipients, 0);

  function toggleRule(id: string) {
    setRules((prev) => prev.map((r) => r.id === id ? { ...r, enabled: !r.enabled } : r));
  }
  function testChannel(name: string) {
    toast.success(`Test notification sent to ${name}`, { description: "If you don't receive it within 30s, check the channel configuration." });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Notification Channels"
        description="Configure outbound notification channels and routing rules. Each channel can be tested independently."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Notification Channels" }]}
        icon={<Bell className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Channel setup wizard opened")}>
            <Plus className="w-3.5 h-3.5" /> Add Channel
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="p-4 space-y-1">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Total Channels</p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-semibold tabular-nums">{channels.length}</span>
            <span className="text-xs text-muted-foreground">configured</span>
          </div>
        </Card>
        <Card className="p-4 space-y-1">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Active</p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-semibold tabular-nums text-success">{configured}</span>
            <span className="text-xs text-muted-foreground">channels</span>
          </div>
        </Card>
        <Card className="p-4 space-y-1">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Pending Setup</p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-semibold tabular-nums text-warning-foreground">{channels.length - configured}</span>
            <span className="text-xs text-muted-foreground">channels</span>
          </div>
        </Card>
        <Card className="p-4 space-y-1">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Total Recipients</p>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-semibold tabular-nums">{totalRecipients}</span>
            <span className="text-xs text-muted-foreground">across channels</span>
          </div>
        </Card>
      </div>

      {/* Channel grid */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Channels" description="Email, SMS, Slack, PagerDuty, Webhooks, and Mobile Push." />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {channels.map((c) => (
            <div key={c.id} className="p-4 rounded-lg border space-y-3 flex flex-col">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="shrink-0 w-9 h-9 rounded-lg flex items-center justify-center border"
                    style={{ background: `${c.color}20`, color: c.color, borderColor: `${c.color}40` }}
                  >
                    {c.icon}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{c.name}</div>
                    <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{c.type}</div>
                  </div>
                </div>
                {c.configured ? (
                  <Badge variant="outline" className="text-[10px] gap-1 bg-success/10 text-success border-success/30 shrink-0">
                    <CheckCircle2 className="w-3 h-3" /> Active
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-[10px] gap-1 bg-muted text-muted-foreground border-border shrink-0">
                    <XCircle className="w-3 h-3" /> Pending
                  </Badge>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div className="space-y-0.5">
                  <div className="text-muted-foreground uppercase tracking-wider">Recipients</div>
                  <div className="text-xs font-medium tabular-nums">{c.recipients}</div>
                </div>
                <div className="space-y-0.5">
                  <div className="text-muted-foreground uppercase tracking-wider">Last delivery</div>
                  <div className="text-xs font-medium">{c.lastDelivery}</div>
                </div>
              </div>
              <div className="flex items-center gap-1.5 pt-2 border-t border-border mt-auto">
                {c.configured ? (
                  <>
                    <Button variant="outline" size="sm" className="flex-1 h-7 text-xs gap-1" onClick={() => testChannel(c.name)}>
                      <Send className="w-3 h-3" /> Test
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.info(`Opening ${c.name} configuration`)}>
                      <Settings2 className="w-3 h-3" />
                    </Button>
                  </>
                ) : (
                  <Button size="sm" className="flex-1 h-7 text-xs gap-1" onClick={() => toast.success(`Setting up ${c.name}`, { description: "Configuration wizard opened." })}>
                    <Plus className="w-3 h-3" /> Configure
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Routing rules */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Notification Routing Rules"
          description="Decide which events go to which channels based on conditions."
          action={
            <Button variant="outline" size="sm" className="text-xs h-8 gap-1" onClick={() => toast.info("Rule builder opened")}>
              <Plus className="w-3.5 h-3.5" /> Add Rule
            </Button>
          }
        />
        <div className="space-y-2">
          {rules.map((r) => (
            <div key={r.id} className="flex flex-col md:flex-row md:items-center gap-3 p-3 rounded-lg border hover:bg-muted/20 transition-colors">
              <div className="flex items-start gap-3 min-w-0 flex-1">
                <div className="shrink-0 w-8 h-8 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                  <Filter className="w-3.5 h-3.5" />
                </div>
                <div className="min-w-0 space-y-1 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <code className="text-[11px] font-mono font-medium px-1.5 py-0.5 rounded bg-muted border">{r.event}</code>
                    <span className="text-[10px] text-muted-foreground">when</span>
                    <code className="text-[10px] font-mono text-muted-foreground">{r.condition}</code>
                  </div>
                  <div className="flex items-center gap-1 flex-wrap">
                    {r.channels.map((ch) => (
                      <Badge key={ch} variant="outline" className="text-[9px] gap-1">
                        <Zap className="w-2.5 h-2.5" /> {ch}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Switch checked={r.enabled} onCheckedChange={() => toggleRule(r.id)} />
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => toast.info("Opening rule editor")}>
                  <Settings2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
        <div className="flex items-center gap-2 p-3 rounded-lg border border-info/30 bg-info/5">
          <Users className="w-3.5 h-3.5 text-info-foreground shrink-0" />
          <p className="text-xs text-muted-foreground">
            Rules are evaluated top-to-bottom. All matching rules fire; there is no short-circuit. Use conditions to scope rules narrowly.
          </p>
        </div>
      </Card>

      {/* Recipient groups */}
      <Card className="p-6 space-y-4">
        <SectionHeading
          title="Recipient Groups"
          description="Reusable subscriber lists for incident communications."
          action={<Button variant="outline" size="sm" className="text-xs h-8 gap-1" onClick={() => toast.info("New group flow opened")}><Plus className="w-3.5 h-3.5" /> New Group</Button>}
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {[
            { name: "Engineering Leadership", members: 5, channels: ["Email", "Slack"] },
            { name: "Platform On-Call", members: 4, channels: ["PagerDuty", "SMS"] },
            { name: "All Engineers", members: 16, channels: ["Slack", "Email"] },
          ].map((g) => (
            <div key={g.name} className="p-4 rounded-lg border space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="text-sm font-medium truncate">{g.name}</div>
                <Button variant="ghost" size="sm" className="h-6 text-xs shrink-0" onClick={() => toast.info(`Editing ${g.name}`)}>
                  <ArrowRight className="w-3 h-3" />
                </Button>
              </div>
              <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                <Users className="w-3 h-3" /> {g.members} members
              </div>
              <div className="flex items-center gap-1 flex-wrap">
                {g.channels.map((ch) => (
                  <Badge key={ch} variant="outline" className="text-[9px]">{ch}</Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
