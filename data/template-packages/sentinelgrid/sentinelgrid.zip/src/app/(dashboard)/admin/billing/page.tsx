"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Column, DataTable } from "@/components/tables/data-table";
import { LineChartCard } from "@/components/charts";
import { toast } from "sonner";
import {
  CreditCard, Wallet, TrendingUp, DollarSign, Download, ArrowUpRight,
  Calendar, Users, Sparkles, RefreshCw,
} from "lucide-react";

interface Invoice {
  id: string;
  date: string;
  amount: number;
  status: "paid" | "pending" | "failed";
  period: string;
}

const invoices: Invoice[] = [
  { id: "INV-2026-07", date: "2026-07-01", amount: 2840.0, status: "paid", period: "Jun 2026" },
  { id: "INV-2026-06", date: "2026-06-01", amount: 2690.0, status: "paid", period: "May 2026" },
  { id: "INV-2026-05", date: "2026-05-01", amount: 2510.0, status: "paid", period: "Apr 2026" },
  { id: "INV-2026-04", date: "2026-04-01", amount: 2480.0, status: "paid", period: "Mar 2026" },
  { id: "INV-2026-03", date: "2026-03-01", amount: 2410.0, status: "paid", period: "Feb 2026" },
  { id: "INV-2026-02", date: "2026-02-01", amount: 2380.0, status: "paid", period: "Jan 2026" },
  { id: "INV-2026-01", date: "2026-01-01", amount: 2340.0, status: "paid", period: "Dec 2025" },
  { id: "INV-2025-12", date: "2025-12-01", amount: 2290.0, status: "paid", period: "Nov 2025" },
  { id: "INV-2025-11", date: "2025-11-01", amount: 2240.0, status: "paid", period: "Oct 2025" },
];

const usageData = [
  { date: "Aug", value: 1820 }, { date: "Sep", value: 1940 }, { date: "Oct", value: 2240 },
  { date: "Nov", value: 2290 }, { date: "Dec", value: 2340 }, { date: "Jan", value: 2380 },
  { date: "Feb", value: 2410 }, { date: "Mar", value: 2480 }, { date: "Apr", value: 2510 },
  { date: "May", value: 2690 }, { date: "Jun", value: 2840 }, { date: "Jul", value: 2980 },
];

const statusConfig = {
  paid: { label: "Paid", className: "bg-success/15 text-success border-success/30" },
  pending: { label: "Pending", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  failed: { label: "Failed", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

export default function BillingPage() {
  const columns: Column<Invoice>[] = [
    {
      key: "id", header: "Invoice", sortable: true, sortValue: (r) => r.id,
      cell: (r) => <span className="text-xs font-mono font-medium">{r.id}</span>,
    },
    {
      key: "date", header: "Date", sortable: true, sortValue: (r) => r.date, hideOnMobile: true,
      cell: (r) => <span className="text-xs text-muted-foreground">{new Date(r.date).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}</span>,
    },
    {
      key: "period", header: "Period", hideOnMobile: true,
      cell: (r) => <span className="text-xs">{r.period}</span>,
    },
    {
      key: "amount", header: "Amount", sortable: true, sortValue: (r) => r.amount, align: "right",
      cell: (r) => <span className="text-xs font-medium tabular-nums">${r.amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>,
    },
    {
      key: "status", header: "Status",
      filterable: true,
      filterOptions: [{ label: "Paid", value: "paid" }, { label: "Pending", value: "pending" }, { label: "Failed", value: "failed" }],
      filterFn: (r, v) => r.status === v,
      cell: (r) => {
        const s = statusConfig[r.status];
        return <Badge variant="outline" className={`text-[10px] gap-1 ${s.className}`}>{s.label}</Badge>;
      },
    },
    {
      key: "actions", header: "", align: "right",
      cell: (r) => (
        <Button
          variant="ghost"
          size="sm"
          className="h-7 text-xs gap-1"
          onClick={() => toast.success(`Downloading ${r.id}`, { description: "PDF invoice saved to your downloads." })}
        >
          <Download className="w-3 h-3" /> PDF
        </Button>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Billing"
        description="Track balance, spend, invoices, and payment methods."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Billing" }]}
        icon={<CreditCard className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Refreshing billing data...")}>
              <RefreshCw className="w-3.5 h-3.5" /> Refresh
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("All invoices exported", { description: "ZIP archive delivered." })}>
              <Download className="w-3.5 h-3.5" /> Export All
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Current Balance" value="$1,240" hint="credits available" icon={<Wallet className="w-4 h-4" />} accent="primary" />
        <KpiCard label="This Month's Spend" value="$2,840" delta={5.6} deltaLabel="vs last month" icon={<DollarSign className="w-4 h-4" />} accent="info" />
        <KpiCard label="Projected EOM" value="$2,980" delta={4.9} deltaLabel="based on usage" icon={<TrendingUp className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Payment Method" value="Visa •4242" hint="expires 09/2028" icon={<CreditCard className="w-4 h-4" />} accent="muted" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Current plan */}
        <Card className="p-6 space-y-4 lg:col-span-1">
          <SectionHeading title="Current Plan" description="Active subscription" />
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Plan</span>
              <Badge className="gap-1"><Sparkles className="w-3 h-3" /> Pro</Badge>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-semibold tracking-tight">$2,490</span>
              <span className="text-xs text-muted-foreground">/ month</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground inline-flex items-center gap-1">
                <Calendar className="w-3 h-3" /> Renews
              </span>
              <span className="font-medium">Aug 1, 2026</span>
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground inline-flex items-center gap-1">
                  <Users className="w-3 h-3" /> Seats
                </span>
                <span className="font-medium tabular-nums">14 / 20</span>
              </div>
              <Progress value={70} className="h-1.5" />
            </div>
            <Button variant="outline" size="sm" className="w-full gap-1.5" onClick={() => { window.location.href = "/admin/subscription"; }}>
              Manage Subscription <ArrowUpRight className="w-3.5 h-3.5" />
            </Button>
          </div>
        </Card>

        {/* Usage chart */}
        <Card className="p-6 space-y-4 lg:col-span-2">
          <SectionHeading
            title="Spend Trend"
            description="Last 12 months"
            action={<Badge variant="outline" className="text-[10px] gap-1 bg-success/10 text-success border-success/30"><TrendingUp className="w-3 h-3" /> +63.7% YoY</Badge>}
          />
          <LineChartCard data={usageData} dataKey="value" color={0} height={240} suffix=" USD" />
        </Card>
      </div>

      {/* Invoices */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Invoices"
          description="All historical invoices, downloadable as PDF."
          action={<Button variant="outline" size="sm" className="text-xs h-8 gap-1" onClick={() => toast.success("Exporting all invoices as ZIP")}><Download className="w-3.5 h-3.5" /> Download all</Button>}
        />
        <DataTable
          columns={columns}
          data={invoices}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.id, (r) => r.period]}
          searchPlaceholder="Search invoice number or period..."
          pageSize={8}
          initialSort={{ key: "date", dir: "desc" }}
          mobileCard={(r) => {
            const s = statusConfig[r.status];
            return (
              <div className="rounded-lg border bg-card p-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-mono font-medium">{r.id}</span>
                  <Badge variant="outline" className={`text-[10px] gap-1 ${s.className}`}>{s.label}</Badge>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{r.period}</span>
                  <span className="font-medium tabular-nums">${r.amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
                </div>
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 w-full" onClick={() => toast.success(`Downloading ${r.id}`)}>
                  <Download className="w-3 h-3" /> Download PDF
                </Button>
              </div>
            );
          }}
        />
      </Card>

      {/* Payment method */}
      <Card className="p-6 space-y-4">
        <SectionHeading title="Payment Method" description="Card charged for monthly billing." />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-lg border bg-muted/30">
          <div className="flex items-center gap-4">
            <div className="shrink-0 w-12 h-12 rounded-lg bg-foreground text-background flex items-center justify-center font-bold text-sm">
              VISA
            </div>
            <div className="space-y-0.5">
              <div className="text-sm font-medium">Visa ending in 4242</div>
              <div className="text-xs text-muted-foreground">Expires 09/2028 · Primary card</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Opening payment method editor")}>
              <CreditCard className="w-3.5 h-3.5" /> Update
            </Button>
            <Button variant="ghost" size="sm" onClick={() => toast.info("Add card flow opened")}>
              Add new
            </Button>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 rounded-lg border space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Billing Email</div>
            <div className="text-xs font-medium">billing@sentinelgrid.io</div>
          </div>
          <div className="p-3 rounded-lg border space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Billing Address</div>
            <div className="text-xs font-medium">548 Market St, San Francisco CA</div>
          </div>
          <div className="p-3 rounded-lg border space-y-1">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Tax ID</div>
            <div className="text-xs font-medium font-mono">US 84-2913847</div>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
