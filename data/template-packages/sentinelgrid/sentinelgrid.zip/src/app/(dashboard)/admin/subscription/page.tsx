"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  CreditCard, Check, Sparkles, Building2, Zap, ArrowUpRight,
  ArrowDownRight, Users, Plug, Headphones, AlertTriangle, ShieldCheck,
} from "lucide-react";

interface Plan {
  id: string;
  name: string;
  price: number;
  tagline: string;
  features: string[];
  highlight?: boolean;
  current?: boolean;
  cta: string;
  icon: React.ReactNode;
  accent: string;
}

const plans: Plan[] = [
  {
    id: "free",
    name: "Free",
    price: 0,
    tagline: "For small teams getting started with reliability.",
    features: ["3 services", "5 team members", "30-day data retention", "Community support", "1 integration"],
    cta: "Downgrade",
    icon: <Zap className="w-5 h-5" />,
    accent: "text-muted-foreground bg-muted",
  },
  {
    id: "pro",
    name: "Pro",
    price: 2490,
    tagline: "For growing engineering organizations with on-call needs.",
    features: ["Unlimited services", "20 team members", "1-year data retention", "Priority email support", "15 integrations", "On-call schedules", "SSO/SAML", "Custom domain"],
    highlight: true,
    current: true,
    cta: "Current Plan",
    icon: <Sparkles className="w-5 h-5" />,
    accent: "text-primary bg-primary/10",
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 9900,
    tagline: "For large organizations with advanced security and compliance needs.",
    features: ["Everything in Pro", "Unlimited members", "10-year retention", "24/7 dedicated support", "Unlimited integrations", "Audit log export", "RBAC + ABAC", "SLA 99.99%", "Dedicated CSM"],
    cta: "Upgrade",
    icon: <Building2 className="w-5 h-5" />,
    accent: "text-accent-foreground bg-accent",
  },
];

const featureMatrix: { category: string; rows: { label: string; values: (boolean | string)[] }[] }[] = [
  {
    category: "Core",
    rows: [
      { label: "Services", values: ["3", "Unlimited", "Unlimited"] },
      { label: "Team members", values: ["5", "20", "Unlimited"] },
      { label: "Data retention", values: ["30 days", "1 year", "10 years"] },
      { label: "Integrations", values: ["1", "15", "Unlimited"] },
    ],
  },
  {
    category: "Reliability",
    rows: [
      { label: "SLOs & error budgets", values: [true, true, true] },
      { label: "On-call schedules", values: [false, true, true] },
      { label: "Postmortems", values: [false, true, true] },
      { label: "Status page", values: [false, true, true] },
    ],
  },
  {
    category: "Security",
    rows: [
      { label: "SSO / SAML", values: [false, true, true] },
      { label: "RBAC", values: [false, true, true] },
      { label: "ABAC", values: [false, false, true] },
      { label: "Audit log export", values: [false, false, true] },
      { label: "Custom domain", values: [false, true, true] },
    ],
  },
  {
    category: "Support",
    rows: [
      { label: "Community support", values: [true, true, true] },
      { label: "Priority email support", values: [false, true, true] },
      { label: "24/7 dedicated support", values: [false, false, true] },
      { label: "Dedicated CSM", values: [false, false, true] },
      { label: "SLA", values: ["None", "99.9%", "99.99%"] },
    ],
  },
];

const addons = [
  { id: "seats", name: "Extra Seats", description: "5 additional team member seats.", price: 125, unit: "/mo", icon: Users, current: 0 },
  { id: "integrations", name: "Extra Integrations", description: "5 additional third-party integrations.", price: 95, unit: "/mo", icon: Plug, current: 0 },
  { id: "support", name: "Premium Support", description: "24/7 dedicated engineer + 1h SLA.", price: 490, unit: "/mo", icon: Headphones, current: 0 },
];

function FeatureCell({ value }: { value: boolean | string }) {
  if (typeof value === "boolean") {
    return value ? (
      <Check className="w-4 h-4 text-success mx-auto" />
    ) : (
      <span className="text-muted-foreground/40 mx-auto">—</span>
    );
  }
  return <span className="text-xs font-medium tabular-nums">{value}</span>;
}

export default function SubscriptionPage() {
  const [cancelOpen, setCancelOpen] = React.useState(false);

  return (
    <PageContainer>
      <PageHeader
        title="Subscription"
        description="Manage your plan, add-ons, and billing cycle. Upgrade or downgrade at any time."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Subscription" }]}
        icon={<CreditCard className="w-5 h-5" />}
        actions={<Button variant="outline" size="sm" className="gap-1.5" onClick={() => { window.location.href = "/admin/billing"; }}>View Billing <ArrowUpRight className="w-3.5 h-3.5" /></Button>}
      />

      {/* Current plan - large premium card */}
      <Card className="p-8 relative overflow-hidden border-primary/30">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none" />
        <div className="relative flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-4 min-w-0">
            <div className="flex items-center gap-2">
              <Badge className="gap-1"><Sparkles className="w-3 h-3" /> Current Plan</Badge>
              <Badge variant="outline" className="text-[10px] gap-1 bg-success/10 text-success border-success/30">
                <Check className="w-3 h-3" /> Active
              </Badge>
            </div>
            <div className="space-y-1">
              <h2 className="text-3xl font-semibold tracking-tight">Pro Plan</h2>
              <p className="text-sm text-muted-foreground max-w-md">For growing engineering organizations with on-call needs and SLO discipline.</p>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-semibold tabular-nums">$2,490</span>
              <span className="text-sm text-muted-foreground">/ month</span>
            </div>
            <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> 14 / 20 seats</span>
              <span className="inline-flex items-center gap-1.5"><Plug className="w-3.5 h-3.5" /> 12 / 15 integrations</span>
              <span className="inline-flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5" /> Renews Aug 1, 2026</span>
            </div>
          </div>
          <div className="flex flex-col gap-2 shrink-0">
            <Button className="gap-1.5" onClick={() => toast.success("Upgrade flow opened", { description: "You'll be migrated to Enterprise immediately." })}>
              <ArrowUpRight className="w-3.5 h-3.5" /> Upgrade to Enterprise
            </Button>
            <Button variant="outline" className="gap-1.5" onClick={() => toast.info("Plan comparison scrolled into view")}>
              Compare plans
            </Button>
          </div>
        </div>
        <Separator className="my-6" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 relative">
          {["Unlimited services", "1-year retention", "SSO/SAML", "On-call schedules"].map((f) => (
            <div key={f} className="flex items-center gap-2 text-xs">
              <Check className="w-3.5 h-3.5 text-success shrink-0" /> {f}
            </div>
          ))}
        </div>
      </Card>

      {/* Plan comparison table */}
      <Card className="p-6 space-y-5">
        <SectionHeading title="Compare Plans" description="Pick the right plan for your team size and security posture." />
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">Feature</th>
                {plans.map((p) => (
                  <th key={p.id} className="py-3 px-2 text-center min-w-[160px]">
                    <div className="flex flex-col items-center gap-1">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center border ${p.accent}`}>{p.icon}</div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-semibold">{p.name}</span>
                        {p.current && <Badge variant="outline" className="text-[9px] bg-primary/10 text-primary border-primary/30">CURRENT</Badge>}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {p.price === 0 ? "Free" : `$${p.price.toLocaleString()}/mo`}
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {featureMatrix.map((group) => (
                <React.Fragment key={group.category}>
                  <tr>
                    <td colSpan={4} className="pt-4 pb-1 px-2 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{group.category}</td>
                  </tr>
                  {group.rows.map((row) => (
                    <tr key={row.label} className="border-b border-border/50 hover:bg-muted/20">
                      <td className="py-2.5 px-2 text-xs">{row.label}</td>
                      {row.values.map((v, i) => (
                        <td key={i} className="py-2.5 px-2 text-center">
                          <FeatureCell value={v} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </React.Fragment>
              ))}
              <tr>
                <td className="py-3 px-2" />
                {plans.map((p) => (
                  <td key={p.id} className="py-3 px-2 text-center">
                    {p.current ? (
                      <Button variant="outline" size="sm" disabled className="text-xs gap-1 w-full">
                        <Check className="w-3.5 h-3.5" /> Current
                      </Button>
                    ) : plans.indexOf(p) < plans.findIndex((x) => x.current) ? (
                      <Button variant="outline" size="sm" className="text-xs gap-1 w-full" onClick={() => toast.info(`Downgrade to ${p.name}`, { description: "Effective at end of billing cycle." })}>
                        <ArrowDownRight className="w-3.5 h-3.5" /> Downgrade
                      </Button>
                    ) : (
                      <Button size="sm" className="text-xs gap-1 w-full" onClick={() => toast.success(`Upgrade to ${p.name}`, { description: "You'll be billed prorated immediately." })}>
                        <ArrowUpRight className="w-3.5 h-3.5" /> Upgrade
                      </Button>
                    )}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </Card>

      {/* Add-ons */}
      <Card className="p-6 space-y-4">
        <SectionHeading title="Add-Ons" description="Boost your plan with optional extras. Billed monthly." />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {addons.map((a) => {
            const Icon = a.icon;
            return (
              <div key={a.id} className="p-4 rounded-lg border space-y-3 flex flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div className="shrink-0 w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    <Icon className="w-4 h-4" />
                  </div>
                  {a.current > 0 && <Badge variant="outline" className="text-[10px] bg-success/10 text-success border-success/30">{a.current} active</Badge>}
                </div>
                <div className="space-y-1">
                  <h3 className="text-sm font-medium">{a.name}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{a.description}</p>
                </div>
                <div className="flex items-baseline gap-1 mt-auto">
                  <span className="text-lg font-semibold tabular-nums">${a.price}</span>
                  <span className="text-xs text-muted-foreground">{a.unit}</span>
                </div>
                <Button variant="outline" size="sm" className="text-xs gap-1" onClick={() => toast.success(`${a.name} added`, { description: `$${a.price}${a.unit} added to next invoice.` })}>
                  Add to plan
                </Button>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Danger zone */}
      <Card className="p-6 space-y-4 border-destructive/30">
        <SectionHeading
          title="Cancel Subscription"
          description="Downgrade to Free plan. Your data will be retained for 30 days before deletion."
        />
        <div className="flex items-start gap-2 p-3 rounded-lg border border-destructive/30 bg-destructive/5">
          <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground">
            Cancellation takes effect at the end of your current billing cycle (Aug 1, 2026). You will retain Pro features until then. All billable add-ons are also cancelled.
          </p>
        </div>
        <div className="flex items-center justify-end gap-2">
          {cancelOpen ? (
            <>
              <Button variant="ghost" size="sm" onClick={() => setCancelOpen(false)}>Keep my plan</Button>
              <Button variant="destructive" size="sm" className="gap-1.5" onClick={() => { setCancelOpen(false); toast.success("Subscription cancelled", { description: "Effective Aug 1, 2026. We're sorry to see you go." }); }}>
                Confirm cancellation
              </Button>
            </>
          ) : (
            <Button variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive" onClick={() => setCancelOpen(true)}>
              <AlertTriangle className="w-3.5 h-3.5" /> Cancel subscription
            </Button>
          )}
        </div>
      </Card>
    </PageContainer>
  );
}
