"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Column, DataTable } from "@/components/tables/data-table";
import { LineChartCard, DonutChart, HorizontalBarChart } from "@/components/charts";
import { toast } from "sonner";
import {
  Activity, Users, Database, Wifi, Download, TrendingUp,
  Bell, AlertTriangle, KeyRound, Plug, Cpu, HardDrive,
} from "lucide-react";

const usageTrend = [
  { date: "Aug", value: 184 }, { date: "Sep", value: 198 }, { date: "Oct", value: 224 },
  { date: "Nov", value: 231 }, { date: "Dec", value: 247 }, { date: "Jan", value: 262 },
  { date: "Feb", value: 289 }, { date: "Mar", value: 312 }, { date: "Apr", value: 348 },
  { date: "May", value: 374 }, { date: "Jun", value: 412 }, { date: "Jul", value: 458 },
];

const featureBreakdown = [
  { name: "API Calls", value: 412 },
  { name: "Logs Ingested", value: 268 },
  { name: "Traces Stored", value: 142 },
  { name: "Metrics Points", value: 98 },
  { name: "Webhooks", value: 42 },
];

interface Consumer {
  id: string;
  name: string;
  type: "service" | "user" | "api_key";
  calls: number;
  share: number;
  trend: number[];
}

const consumers: Consumer[] = [
  { id: "c1", name: "api-gateway", type: "service", calls: 18420000, share: 38.4, trend: [12, 14, 13, 15, 18, 20, 22, 24, 22, 26, 28, 30] },
  { id: "c2", name: "checkout-api", type: "service", calls: 12480000, share: 26.0, trend: [8, 9, 10, 11, 13, 14, 16, 18, 17, 19, 21, 22] },
  { id: "c3", name: "CI/CD Pipeline", type: "api_key", calls: 6840000, share: 14.3, trend: [4, 5, 5, 6, 7, 8, 9, 10, 11, 12, 12, 13] },
  { id: "c4", name: "auth-service", type: "service", calls: 4280000, share: 8.9, trend: [3, 4, 4, 4, 5, 5, 6, 7, 7, 8, 8, 9] },
  { id: "c5", name: "Datadog Integration", type: "api_key", calls: 3120000, share: 6.5, trend: [2, 3, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7] },
  { id: "c6", name: "Maya Okonkwo", type: "user", calls: 1840000, share: 3.8, trend: [1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5] },
  { id: "c7", name: "Terraform Provisioner", type: "api_key", calls: 920000, share: 1.9, trend: [1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2] },
];

const typeIcon = {
  service: <Cpu className="w-3 h-3" />,
  user: <Users className="w-3 h-3" />,
  api_key: <KeyRound className="w-3 h-3" />,
};

type QuotaAccent = "primary" | "warning" | "info" | "destructive";
const quotaAccentClasses: Record<QuotaAccent, string> = {
  primary: "bg-primary/10 text-primary border-primary/20",
  warning: "bg-warning/10 text-warning-foreground border-warning/20",
  info: "bg-info/10 text-info-foreground border-info/20",
  destructive: "bg-destructive/10 text-destructive border-destructive/20",
};
const quotas: { label: string; icon: typeof Bell; used: number; total: number; accent: QuotaAccent; unit: string }[] = [
  { label: "Alerts Sent", icon: Bell, used: 12480, total: 25000, accent: "primary", unit: "" },
  { label: "Incidents", icon: AlertTriangle, used: 47, total: 100, accent: "warning", unit: "" },
  { label: "API Keys", icon: KeyRound, used: 4, total: 50, accent: "info", unit: "" },
  { label: "Integrations", icon: Plug, used: 12, total: 15, accent: "destructive", unit: "" },
];

function formatNum(n: number): string {
  if (n >= 1e9) return (n / 1e9).toFixed(2) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
  return n.toString();
}

function MiniSpark({ data }: { data: number[] }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 60;
  const h = 18;
  const points = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / range) * h}`).join(" ");
  return (
    <svg width={w} height={h} aria-hidden="true">
      <polyline fill="none" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" points={points} className="text-primary" />
    </svg>
  );
}

export default function UsageAnalyticsPage() {
  const columns: Column<Consumer>[] = [
    {
      key: "name", header: "Consumer", sortable: true, sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <div className="shrink-0 w-7 h-7 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
            {typeIcon[r.type]}
          </div>
          <div className="min-w-0">
            <div className="text-xs font-medium truncate">{r.name}</div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{r.type.replace("_", " ")}</div>
          </div>
        </div>
      ),
    },
    {
      key: "calls", header: "API Calls", sortable: true, sortValue: (r) => r.calls, align: "right",
      cell: (r) => <span className="text-xs font-medium tabular-nums">{formatNum(r.calls)}</span>,
    },
    {
      key: "share", header: "Share", sortable: true, sortValue: (r) => r.share, align: "right", hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-2 justify-end">
          <div className="w-16 h-1.5 rounded-full bg-muted overflow-hidden">
            <div className="h-full bg-primary" style={{ width: `${r.share * 2}%` }} />
          </div>
          <span className="text-xs tabular-nums w-10 text-right">{r.share.toFixed(1)}%</span>
        </div>
      ),
    },
    {
      key: "trend", header: "12-Mo Trend", align: "center", hideOnMobile: true,
      cell: (r) => <div className="flex items-center justify-center"><MiniSpark data={r.trend} /></div>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Usage Analytics"
        description="Track consumption across API calls, users, storage, and bandwidth against your plan quotas."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Usage" }]}
        icon={<Activity className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Usage report exported", { description: "12-month CSV delivered." })}>
            <Download className="w-3.5 h-3.5" /> Export
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="API Calls (MTD)" value="4.58M" delta={11.2} deltaLabel="vs last month" icon={<Activity className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Active Users" value="14" hint="of 20 seats" icon={<Users className="w-4 h-4" />} accent="success" />
        <KpiCard label="Storage Used" value="847" unit="GB" delta={4.8} deltaLabel="of 1 TB" icon={<Database className="w-4 h-4" />} accent="info" />
        <KpiCard label="Bandwidth" value="2.4" unit="TB" delta={7.1} deltaLabel="vs last month" icon={<Wifi className="w-4 h-4" />} accent="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Usage trend */}
        <Card className="p-6 space-y-4 lg:col-span-2">
          <SectionHeading
            title="Usage Trend"
            description="API calls, last 12 months (in millions)"
            action={<Badge variant="outline" className="text-[10px] gap-1 bg-success/10 text-success border-success/30"><TrendingUp className="w-3 h-3" /> +148% YoY</Badge>}
          />
          <LineChartCard data={usageTrend} dataKey="value" color={0} height={260} suffix="M calls" />
        </Card>

        {/* Feature breakdown */}
        <Card className="p-6 space-y-4">
          <SectionHeading title="Usage by Feature" description="Distribution this month" />
          <DonutChart
            data={featureBreakdown}
            centerValue="4.58M"
            centerLabel="total calls"
          />
        </Card>
      </div>

      {/* Quota progress bars */}
      <Card className="p-6 space-y-5">
        <SectionHeading title="Quota Usage" description="Plan limits and current consumption." />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {quotas.map((q) => {
            const pct = Math.round((q.used / q.total) * 100);
            const Icon = q.icon;
            return (
              <div key={q.label} className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className={`shrink-0 w-7 h-7 rounded-md flex items-center justify-center border ${quotaAccentClasses[q.accent]}`}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-medium">{q.label}</span>
                  </div>
                  <span className="text-xs tabular-nums text-muted-foreground">
                    {formatNum(q.used)} <span className="text-muted-foreground/60">/ {formatNum(q.total)}</span>
                  </span>
                </div>
                <Progress value={pct} className="h-2" />
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>{pct}% used</span>
                  {pct >= 80 && <span className="text-warning-foreground inline-flex items-center gap-1"><AlertTriangle className="w-2.5 h-2.5" /> Approaching limit</span>}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Top consumers */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Top Consumers" description="Highest API call volumes this month." />
        <DataTable
          columns={columns}
          data={consumers}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.name]}
          searchPlaceholder="Search consumers..."
          pageSize={10}
          initialSort={{ key: "calls", dir: "desc" }}
          mobileCard={(r) => (
            <div className="rounded-lg border bg-card p-3 space-y-2">
              <div className="flex items-center gap-2">
                <div className="shrink-0 w-7 h-7 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
                  {typeIcon[r.type]}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-medium truncate">{r.name}</div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{r.type.replace("_", " ")}</div>
                </div>
                <span className="text-xs font-medium tabular-nums">{formatNum(r.calls)}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: `${r.share * 2}%` }} />
                </div>
                <span className="text-[10px] tabular-nums w-10 text-right text-muted-foreground">{r.share.toFixed(1)}%</span>
              </div>
            </div>
          )}
        />
      </Card>

      {/* Storage breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-6 space-y-4">
          <SectionHeading title="Storage by Category" description="847 GB total used" />
          <HorizontalBarChart
            data={[
              { name: "Logs", value: 348 },
              { name: "Traces", value: 214 },
              { name: "Metrics", value: 168 },
              { name: "Incident Data", value: 78 },
              { name: "Audit Logs", value: 39 },
            ]}
            color={2}
          />
        </Card>
        <Card className="p-6 space-y-4">
          <SectionHeading title="Bandwidth by Region" description="2.4 TB total this month" />
          <HorizontalBarChart
            data={[
              { name: "us-east-1", value: 1140 },
              { name: "eu-west-1", value: 680 },
              { name: "ap-south-1", value: 320 },
              { name: "us-west-2", value: 180 },
              { name: "ap-southeast-2", value: 80 },
            ]}
            color={1}
          />
        </Card>
      </div>
    </PageContainer>
  );
}
