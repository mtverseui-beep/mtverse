"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Plug, Search, Plus, CheckCircle2, XCircle, AlertTriangle,
  RefreshCw, Settings, Activity, Clock, Filter,
} from "lucide-react";
import { integrations } from "@/lib/data";
import { toast } from "sonner";

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

function statusConfig(s: string) {
  switch (s) {
    case "connected": return { label: "Connected", icon: <CheckCircle2 className="w-3 h-3" />, className: "bg-success/15 text-success border-success/30" };
    case "disconnected": return { label: "Disconnected", icon: <XCircle className="w-3 h-3" />, className: "bg-muted text-muted-foreground border-border" };
    case "error": return { label: "Error", icon: <AlertTriangle className="w-3 h-3" />, className: "bg-destructive/15 text-destructive border-destructive/30" };
    case "needs_attention": return { label: "Needs Attention", icon: <AlertTriangle className="w-3 h-3" />, className: "bg-warning/15 text-warning-foreground border-warning/30" };
    default: return { label: s, icon: <XCircle className="w-3 h-3" />, className: "bg-muted text-muted-foreground border-border" };
  }
}

function initials(name: string): string {
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
}

export default function IntegrationsPage() {
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("all");
  const [statusFilter, setStatusFilter] = React.useState("all");

  const categories = Array.from(new Set(integrations.map((i) => i.category)));

  const filtered = integrations.filter((i) => {
    if (search && !i.name.toLowerCase().includes(search.toLowerCase()) && !i.description.toLowerCase().includes(search.toLowerCase())) return false;
    if (category !== "all" && i.category !== category) return false;
    if (statusFilter !== "all" && i.status !== statusFilter) return false;
    return true;
  });

  const connected = integrations.filter((i) => i.status === "connected").length;
  const disconnected = integrations.filter((i) => i.status === "disconnected").length;
  const errorCount = integrations.filter((i) => i.status === "error").length;

  return (
    <PageContainer>
      <PageHeader
        title="Integrations Marketplace"
        description="Connect SentinelGrid to your existing tools. Browse, configure, and monitor all integrations in one place."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Integrations" }]}
        icon={<Plug className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Browse integrations catalog")}>
            <Plus className="w-3.5 h-3.5" />
            Browse Catalog
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Integrations" value={integrations.length} icon={<Plug className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Connected" value={connected} hint="active integrations" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Disconnected" value={disconnected} hint="available to connect" icon={<XCircle className="w-4 h-4" />} accent="muted" />
        <KpiCard label="Errors" value={errorCount} hint="needs attention" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search integrations..."
              className="pl-8 h-9 text-sm"
            />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1">
              <Filter className="w-3 h-3 text-muted-foreground" />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Category</span>
            </div>
            <Button variant={category === "all" ? "default" : "outline"} size="sm" className="h-7 text-xs" onClick={() => setCategory("all")}>
              All
            </Button>
            {categories.map((c) => (
              <Button key={c} variant={category === c ? "default" : "outline"} size="sm" className="h-7 text-xs" onClick={() => setCategory(c)}>
                {c}
              </Button>
            ))}
          </div>
          <div className="flex items-center gap-1">
            {["all", "connected", "disconnected"].map((s) => (
              <Button key={s} variant={statusFilter === s ? "default" : "outline"} size="sm" className="h-7 text-xs capitalize" onClick={() => setStatusFilter(s)}>
                {s}
              </Button>
            ))}
          </div>
        </div>
      </Card>

      {/* Integration grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((int) => {
          const sc = statusConfig(int.status);
          return (
            <Card key={int.id} className="p-5 space-y-4 hover:border-primary/30 transition-colors flex flex-col">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="shrink-0 w-11 h-11 rounded-lg flex items-center justify-center text-sm font-bold border"
                    style={{
                      background: `${int.iconColor}20`,
                      color: int.iconColor,
                      borderColor: `${int.iconColor}40`,
                    }}
                  >
                    {initials(int.name)}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold truncate">{int.name}</h3>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider mt-0.5">{int.category}</p>
                  </div>
                </div>
                <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded border font-medium shrink-0 ${sc.className}`}>
                  {sc.icon}
                  {sc.label}
                </span>
              </div>

              <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 flex-1">{int.description}</p>

              {/* Config summary + last sync */}
              <div className="space-y-2">
                {Object.keys(int.config).length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {Object.entries(int.config).slice(0, 3).map(([k, v]) => (
                      <span key={k} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted border border-border">
                        {k}: {v}
                      </span>
                    ))}
                  </div>
                )}
                {int.lastSyncAt && (
                  <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                    <RefreshCw className="w-2.5 h-2.5" />
                    <span>Last sync {timeAgo(int.lastSyncAt)}</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1.5 pt-3 border-t border-border">
                {int.status === "connected" ? (
                  <>
                    <Button variant="outline" size="sm" className="flex-1 h-7 text-xs gap-1" onClick={() => toast.info(`Opening configuration drawer for ${int.name}`)}>
                      <Settings className="w-3 h-3" /> Configure
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success(`Sync triggered for ${int.name}`)}>
                      <Activity className="w-3 h-3" /> Sync
                    </Button>
                  </>
                ) : (
                  <Button size="sm" className="flex-1 h-7 text-xs gap-1" onClick={() => toast.success(`Connecting to ${int.name}...`, { description: "OAuth flow started in new window." })}>
                    <Plus className="w-3 h-3" /> Connect
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <Card className="p-12">
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-xl bg-muted border flex items-center justify-center text-muted-foreground mb-3">
              <Search className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-medium">No integrations match your filters</h3>
            <p className="text-xs text-muted-foreground mt-1">Try adjusting your search or category.</p>
            <Button variant="outline" size="sm" className="mt-4 h-8 text-xs" onClick={() => { setSearch(""); setCategory("all"); setStatusFilter("all"); }}>
              Clear filters
            </Button>
          </div>
        </Card>
      )}

      {/* Sync health summary */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Sync Health Summary" description="Last sync across all connected integrations" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {integrations.filter((i) => i.status === "connected").slice(0, 6).map((int) => (
            <div key={int.id} className="flex items-center gap-2.5 p-2.5 rounded-lg border">
              <div
                className="shrink-0 w-8 h-8 rounded-md flex items-center justify-center text-[10px] font-bold"
                style={{ background: `${int.iconColor}20`, color: int.iconColor, border: `1px solid ${int.iconColor}40` }}
              >
                {initials(int.name)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-medium truncate">{int.name}</div>
                <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <Clock className="w-2.5 h-2.5" />
                  {int.lastSyncAt ? timeAgo(int.lastSyncAt) : "never"}
                </div>
              </div>
              <CheckCircle2 className="w-3.5 h-3.5 text-success shrink-0" />
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
