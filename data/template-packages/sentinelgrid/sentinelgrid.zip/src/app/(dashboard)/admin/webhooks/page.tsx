"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Webhook, Plus, Download, Activity, Zap, Clock,
  CheckCircle2, XCircle, AlertTriangle, Send, Settings, Bell,
} from "lucide-react";
import { webhooks, people } from "@/lib/data";
import type { Webhook as WebhookType } from "@/lib/types";
import { toast } from "sonner";

function maskUrl(url: string): string {
  try {
    const u = new URL(url);
    return `${u.protocol}//${u.hostname}${u.pathname.slice(0, 12)}••••`;
  } catch {
    return url.slice(0, 30) + "••••";
  }
}
function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}
function statusColor(code: number): string {
  if (code >= 200 && code < 300) return "bg-success/15 text-success";
  if (code >= 400 && code < 500) return "bg-warning/15 text-warning-foreground";
  if (code >= 500) return "bg-destructive/15 text-destructive";
  return "bg-muted text-muted-foreground";
}

export default function WebhooksPage() {
  const total = webhooks.length;
  const enabled = webhooks.filter((w) => w.enabled).length;
  const failedDeliveries = webhooks.filter((w) => w.failureCount > 0).length;
  const avgDeliveryMs = Math.round(webhooks.reduce((s, w) => s + (w.lastDelivery?.durationMs || 0), 0) / webhooks.length);

  const [hookStates, setHookStates] = React.useState<Record<string, boolean>>(
    Object.fromEntries(webhooks.map((w) => [w.id, w.enabled]))
  );

  function toggleHook(id: string, name: string, value: boolean) {
    setHookStates((s) => ({ ...s, [id]: value }));
    toast.success(`Webhook ${value ? "enabled" : "disabled"}`, { description: name });
  }

  function testHook(name: string) {
    toast.success("Test event sent", { description: `Awaiting delivery confirmation from ${name}.` });
  }

  const columns: Column<WebhookType>[] = [
    {
      key: "name", header: "Name", sortable: true, sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2.5">
          <div className={`shrink-0 w-8 h-8 rounded-md flex items-center justify-center border ${
            hookStates[r.id] ? "bg-success/10 text-success border-success/20" : "bg-muted text-muted-foreground border-border"
          }`}>
            <Webhook className="w-3.5 h-3.5" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-medium truncate">{r.name}</div>
            <div className="text-[10px] text-muted-foreground font-mono truncate">{maskUrl(r.url)}</div>
          </div>
        </div>
      ),
    },
    {
      key: "url", header: "URL", hideOnMobile: true,
      cell: (r) => <span className="text-[11px] font-mono text-muted-foreground truncate">{maskUrl(r.url)}</span>,
    },
    {
      key: "events", header: "Events", hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-1 flex-wrap max-w-[200px]">
          {r.events.slice(0, 2).map((e) => (
            <span key={e} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted border border-border">
              {e}
            </span>
          ))}
          {r.events.length > 2 && (
            <span className="text-[10px] text-muted-foreground">+{r.events.length - 2}</span>
          )}
        </div>
      ),
    },
    {
      key: "enabled", header: "Enabled",
      cell: (r) => (
        <Switch
          checked={hookStates[r.id]}
          onCheckedChange={(v) => toggleHook(r.id, r.name, v)}
          aria-label={`Toggle ${r.name}`}
        />
      ),
    },
    {
      key: "lastDelivery", header: "Last Delivery",
      cell: (r) => r.lastDelivery ? (
        <div className="flex flex-col gap-0.5">
          <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded font-mono font-medium w-fit ${statusColor(r.lastDelivery.statusCode)}`}>
            {r.lastDelivery.statusCode}
          </span>
          <span className="text-[10px] text-muted-foreground">
            {timeAgo(r.lastDelivery.timestamp)} · {r.lastDelivery.durationMs}ms
          </span>
        </div>
      ) : <span className="text-[11px] text-muted-foreground">never</span>,
    },
    {
      key: "failures", header: "Failures", sortable: true, sortValue: (r) => r.failureCount,
      cell: (r) => (
        <span className={`text-xs font-mono tabular-nums ${r.failureCount > 0 ? "text-destructive" : "text-muted-foreground"}`}>
          {r.failureCount}
        </span>
      ),
    },
    {
      key: "actions", header: "", align: "right",
      cell: (r) => (
        <div className="flex items-center gap-1 justify-end">
          <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => testHook(r.name)}>
            <Send className="w-3 h-3" /> Test
          </Button>
          <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => toast.info(`Configuring ${r.name}`)}>
            <Settings className="w-3.5 h-3.5" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Webhooks"
        description="Outgoing HTTP webhooks for system events. Manage endpoints, subscriptions, and delivery health."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Webhooks" }]}
        icon={<Webhook className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting webhook delivery history...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Create webhook dialog opened")}>
              <Plus className="w-3.5 h-3.5" />
              New Webhook
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Webhooks" value={total} icon={<Webhook className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Enabled" value={enabled} hint={`${total - enabled} disabled`} icon={<Bell className="w-4 h-4" />} accent="success" />
        <KpiCard label="Failed Deliveries" value={failedDeliveries} hint="webhooks with failures" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Avg Delivery Time" value={avgDeliveryMs} unit="ms" icon={<Clock className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Webhook Endpoints"
          description="Toggle, test, or configure each endpoint."
          action={
            <Button variant="outline" size="sm" className="text-xs h-8 gap-1.5" onClick={() => toast.info("Opening delivery log viewer")}>
              <Activity className="w-3.5 h-3.5" /> Delivery Log
            </Button>
          }
        />
        <DataTable
          columns={columns}
          data={webhooks}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.name, (r) => r.url, (r) => r.events.join(" ")]}
          searchPlaceholder="Search name, URL, event..."
          pageSize={10}
          mobileCard={(r) => (
            <div className="rounded-lg border bg-card p-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <div className={`shrink-0 w-7 h-7 rounded flex items-center justify-center ${hookStates[r.id] ? "bg-success/10 text-success" : "bg-muted text-muted-foreground"}`}>
                    <Webhook className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-medium truncate">{r.name}</span>
                </div>
                <Switch checked={hookStates[r.id]} onCheckedChange={(v) => toggleHook(r.id, r.name, v)} />
              </div>
              <div className="text-[10px] font-mono text-muted-foreground truncate">{maskUrl(r.url)}</div>
              <div className="flex flex-wrap gap-1">
                {r.events.slice(0, 3).map((e) => (
                  <span key={e} className="text-[9px] font-mono px-1 py-0.5 rounded bg-muted border">{e}</span>
                ))}
              </div>
              {r.lastDelivery && (
                <div className="flex items-center justify-between text-[10px] pt-1 border-t border-border">
                  <span className={`px-1.5 py-0.5 rounded font-mono ${statusColor(r.lastDelivery.statusCode)}`}>{r.lastDelivery.statusCode}</span>
                  <span className="text-muted-foreground">{timeAgo(r.lastDelivery.timestamp)} · {r.lastDelivery.durationMs}ms</span>
                </div>
              )}
              {r.failureCount > 0 && (
                <div className="text-[10px] text-destructive">{r.failureCount} delivery failures</div>
              )}
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" className="h-7 text-xs gap-1 flex-1" onClick={() => testHook(r.name)}>
                  <Send className="w-3 h-3" /> Test
                </Button>
                <Button variant="ghost" size="sm" className="h-7 w-7 p-0"><Settings className="w-3.5 h-3.5" /></Button>
              </div>
            </div>
          )}
        />
      </Card>

      {/* Delivery health */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-4">
          <SectionHeading title="Delivery Health" description="Last 7 days across all webhooks" />
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-md bg-success/10 text-success flex items-center justify-center">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs">Successful</span>
              </div>
              <span className="text-sm font-mono tabular-nums">1,247</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-md bg-warning/10 text-warning-foreground flex items-center justify-center">
                  <Clock className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs">Retried</span>
              </div>
              <span className="text-sm font-mono tabular-nums">23</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-md bg-destructive/10 text-destructive flex items-center justify-center">
                  <XCircle className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs">Failed</span>
              </div>
              <span className="text-sm font-mono tabular-nums">18</span>
            </div>
          </div>
          <div className="pt-3 border-t border-border">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Delivery rate</span>
              <span className="font-mono font-semibold text-success">97.1%</span>
            </div>
          </div>
        </Card>

        <Card className="p-5 space-y-4">
          <SectionHeading title="Available Events" description="Events that can trigger webhook delivery" />
          <div className="grid grid-cols-2 gap-2 max-h-[260px] overflow-y-auto pr-1">
            {[
              "incident.created", "incident.severity_changed", "incident.resolved",
              "alert.firing", "alert.escalated", "alert.resolved",
              "deployment.started", "deployment.completed", "deployment.failed",
              "slo.burn_rate_high", "slo.breached",
              "vulnerability.discovered", "vulnerability.patched",
              "audit.anomaly_detected", "team.oncall_changed",
            ].map((e) => (
              <div key={e} className="flex items-center gap-1.5 p-2 rounded border text-[10px] font-mono">
                <Zap className="w-2.5 h-2.5 text-primary shrink-0" />
                <span className="truncate">{e}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
