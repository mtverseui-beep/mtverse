"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Lock, Check, X, Save, RotateCcw, Filter,
  Server, Database, Users, Activity, Settings, Key, Shield,
  Eye, Plus, Pencil, Crown, AlertTriangle,
} from "lucide-react";
import { toast } from "sonner";

interface RoleDef {
  id: string;
  name: string;
  color: string;
}
const roles: RoleDef[] = [
  { id: "r1", name: "Admin", color: "#F87171" },
  { id: "r2", name: "Engineer", color: "#22D3EE" },
  { id: "r3", name: "On-Call", color: "#A78BFA" },
  { id: "r4", name: "Viewer", color: "#34D399" },
  { id: "r5", name: "Security", color: "#FB923C" },
  { id: "r6", name: "Billing", color: "#F59E0B" },
];

const resources = [
  { name: "Services", icon: <Server className="w-3.5 h-3.5" /> },
  { name: "Incidents", icon: <Activity className="w-3.5 h-3.5" /> },
  { name: "Deployments", icon: <Settings className="w-3.5 h-3.5" /> },
  { name: "Databases", icon: <Database className="w-3.5 h-3.5" /> },
  { name: "Secrets/Vault", icon: <Key className="w-3.5 h-3.5" /> },
  { name: "Members", icon: <Users className="w-3.5 h-3.5" /> },
  { name: "Audit Logs", icon: <Shield className="w-3.5 h-3.5" /> },
  { name: "API Keys", icon: <Key className="w-3.5 h-3.5" /> },
  { name: "Webhooks", icon: <Settings className="w-3.5 h-3.5" /> },
  { name: "Integrations", icon: <Plus className="w-3.5 h-3.5" /> },
];
const actions = ["view", "create", "edit", "delete", "admin"] as const;
type Action = (typeof actions)[number];

// Initial permission matrix (mock)
const initialMatrix: Record<string, Record<Action, boolean>> = {
  Admin: { view: true, create: true, edit: true, delete: true, admin: true },
  Engineer: { view: true, create: true, edit: true, delete: false, admin: false },
  "On-Call": { view: true, create: true, edit: true, delete: false, admin: false },
  Viewer: { view: true, create: false, edit: false, delete: false, admin: false },
  Security: { view: true, create: true, edit: false, delete: false, admin: false },
  Billing: { view: true, create: false, edit: false, delete: false, admin: false },
};

// Per-resource adjustments (mock)
function resourceMultiplier(resource: string, role: string, action: Action): boolean {
  if (resource === "Audit Logs" && role === "Security" && action === "view") return true;
  if (resource === "API Keys" && role === "Admin" && action === "admin") return true;
  if (resource === "Members" && (role === "Billing")) return action === "view";
  if (resource === "Secrets/Vault" && role === "Engineer") return action === "view";
  return initialMatrix[role]?.[action] ?? false;
}

export default function PermissionsPage() {
  const [filterRole, setFilterRole] = React.useState<string>("all");
  const [matrix, setMatrix] = React.useState<Record<string, Record<string, Record<Action, boolean>>>>(() => {
    const out: Record<string, Record<string, Record<Action, boolean>>> = {};
    resources.forEach((r) => {
      out[r.name] = {};
      roles.forEach((role) => {
        out[r.name][role.name] = {} as Record<Action, boolean>;
        actions.forEach((a) => {
          out[r.name][role.name][a] = resourceMultiplier(r.name, role.name, a);
        });
      });
    });
    return out;
  });
  const [dirty, setDirty] = React.useState(false);

  function toggle(resource: string, role: string, action: Action) {
    setMatrix((m) => ({
      ...m,
      [resource]: {
        ...m[resource],
        [role]: {
          ...m[resource][role],
          [action]: !m[resource][role][action],
        },
      },
    }));
    setDirty(true);
  }

  const visibleRoles = filterRole === "all" ? roles : roles.filter((r) => r.id === filterRole);
  const totalGranted = Object.values(matrix).reduce(
    (s, r) => s + Object.values(r).reduce((s2, a) => s2 + Object.values(a).filter(Boolean).length, 0),
    0
  );
  const totalCells = resources.length * roles.length * actions.length;
  const coverage = Math.round((totalGranted / totalCells) * 100);

  return (
    <PageContainer>
      <PageHeader
        title="Permissions Matrix"
        description="Resource-level permissions for each role. Toggle cells to grant or revoke access."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Permissions" }]}
        icon={<Lock className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => { setMatrix((m) => { const out: typeof m = {}; resources.forEach((r) => { out[r.name] = {}; roles.forEach((role) => { out[r.name][role.name] = {} as Record<Action, boolean>; actions.forEach((a) => { out[r.name][role.name][a] = resourceMultiplier(r.name, role.name, a); }); }); }); return out; }); setDirty(false); toast.info("Reverted to saved state"); }}>
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Revert</span>
            </Button>
            <Button size="sm" className="gap-1.5" disabled={!dirty} onClick={() => { setDirty(false); toast.success("Permissions saved", { description: `${totalGranted} grants across ${resources.length} resources.` }); }}>
              <Save className="w-3.5 h-3.5" />
              Save Changes
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Resources" value={resources.length} icon={<Server className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Roles" value={roles.length} icon={<Users className="w-4 h-4" />} accent="info" />
        <KpiCard label="Granted" value={totalGranted} hint={`${coverage}% of matrix`} icon={<Check className="w-4 h-4" />} accent="success" />
        <KpiCard label="Unsaved Changes" value={dirty ? "Yes" : "No"} icon={<AlertTriangle className="w-4 h-4" />} accent={dirty ? "warning" : "muted"} />
      </div>

      {/* Filter bar */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Permission Matrix"
          description="Rows are resources, columns are actions per role. Toggle a cell to grant or revoke."
          action={
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-muted-foreground" />
              <Button
                variant={filterRole === "all" ? "default" : "outline"}
                size="sm"
                className="h-7 text-xs"
                onClick={() => setFilterRole("all")}
              >
                All Roles
              </Button>
              {roles.map((r) => (
                <Button
                  key={r.id}
                  variant={filterRole === r.id ? "default" : "outline"}
                  size="sm"
                  className="h-7 text-xs gap-1"
                  onClick={() => setFilterRole(r.id)}
                >
                  <span className="w-1.5 h-1.5 rounded-full" style={{ background: r.color }} />
                  {r.name}
                </Button>
              ))}
            </div>
          }
        />

        <div className="overflow-x-auto -mx-5 px-5">
          <table className="w-full text-sm border-separate" style={{ borderSpacing: 0 }}>
            <thead>
              <tr>
                <th className="sticky left-0 z-20 bg-card px-3 py-2 text-left text-[11px] uppercase tracking-wider text-muted-foreground font-medium border-b border-border">
                  Resource
                </th>
                {visibleRoles.map((r) => (
                  <th key={r.id} colSpan={actions.length} className="px-1 py-2 text-center border-b border-l border-border">
                    <div className="flex items-center justify-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full" style={{ background: r.color }} />
                      <span className="text-[11px] font-medium">{r.name}</span>
                    </div>
                  </th>
                ))}
              </tr>
              <tr>
                <th className="sticky left-0 z-20 bg-card px-3 py-2 border-b border-border"></th>
                {visibleRoles.map((r) => (
                  actions.map((a) => (
                    <th key={`${r.id}-${a}`} className="px-1 py-1.5 text-center text-[10px] uppercase tracking-wider text-muted-foreground font-medium border-b border-l border-border/60">
                      {a}
                    </th>
                  ))
                ))}
              </tr>
            </thead>
            <tbody>
              {resources.map((res) => (
                <tr key={res.name} className="hover:bg-muted/30">
                  <td className="sticky left-0 z-10 bg-card px-3 py-2 border-b border-border">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">{res.icon}</span>
                      <span className="text-xs font-medium">{res.name}</span>
                    </div>
                  </td>
                  {visibleRoles.map((r) => (
                    actions.map((a) => {
                      const granted = matrix[res.name][r.name][a];
                      return (
                        <td key={`${res.name}-${r.id}-${a}`} className="px-1 py-1.5 text-center border-b border-l border-border/60">
                          <button
                            onClick={() => toggle(res.name, r.name, a)}
                            className={`w-6 h-6 rounded-md flex items-center justify-center border transition-colors ${
                              granted
                                ? "bg-success/15 text-success border-success/30 hover:bg-success/25"
                                : "bg-muted/50 text-muted-foreground border-border hover:bg-muted"
                            }`}
                            aria-label={`${granted ? "Revoke" : "Grant"} ${a} on ${res.name} for ${r.name}`}
                          >
                            {granted ? <Check className="w-3.5 h-3.5" /> : <X className="w-3 h-3 opacity-40" />}
                          </button>
                        </td>
                      );
                    })
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center gap-3 pt-3 border-t border-border text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-success/15 text-success border border-success/30 flex items-center justify-center">
              <Check className="w-3 h-3" />
            </span>
            Granted
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-muted/50 text-muted-foreground border border-border flex items-center justify-center">
              <X className="w-2.5 h-2.5 opacity-40" />
            </span>
            Not granted
          </span>
          <span className="ml-auto">
            Coverage: <span className="font-mono tabular-nums font-medium text-foreground">{coverage}%</span> ({totalGranted}/{totalCells})
          </span>
        </div>
      </Card>
    </PageContainer>
  );
}
