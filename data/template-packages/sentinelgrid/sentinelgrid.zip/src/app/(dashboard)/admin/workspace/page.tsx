"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import {
  Building2, Users, Server, AlertTriangle, Rocket, Plug, Activity,
  Settings, CreditCard, ShieldCheck, Bell, KeyRound, History, User,
  ChevronRight, Globe, Crown, Calendar, ArrowUpRight, Database,
} from "lucide-react";
import { people, teams, services, auditEvents } from "@/lib/data";

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

const quickLinks = [
  { label: "Workspace Settings", href: "/admin/settings", icon: Settings, description: "General, branding, auth" },
  { label: "Billing & Invoices", href: "/admin/billing", icon: CreditCard, description: "Plan, payments, history" },
  { label: "Subscription", href: "/admin/subscription", icon: Activity, description: "Plan tiers and add-ons" },
  { label: "Usage Analytics", href: "/admin/usage", icon: Database, description: "API, storage, bandwidth" },
  { label: "Security Settings", href: "/admin/security", icon: ShieldCheck, description: "MFA, SSO, IP policy" },
  { label: "Active Sessions", href: "/admin/sessions", icon: User, description: "Revoke, audit logins" },
  { label: "Notification Channels", href: "/admin/notifications", icon: Bell, description: "Email, Slack, PagerDuty" },
  { label: "Team Members", href: "/admin/team", icon: Users, description: "Invite, manage, roles" },
  { label: "API Keys", href: "/admin/api-keys", icon: KeyRound, description: "Programmatic tokens" },
  { label: "Audit Logs", href: "/admin/audit-logs", icon: History, description: "Admin activity trail" },
  { label: "Integrations", href: "/admin/integrations", icon: Plug, description: "Connect external tools" },
  { label: "Webhooks", href: "/admin/webhooks", icon: Server, description: "Outbound event delivery" },
];

const activityFeed = [
  ...auditEvents.slice(0, 8),
  { id: "ws1", timestamp: "2026-07-02T06:25:00Z", actorId: "u1", action: "workspace.settings_updated", resourceType: "workspace", resourceId: "ws-1", metadata: {}, ip: "10.42.18.10", result: "success" as const },
  { id: "ws2", timestamp: "2026-07-02T05:50:00Z", actorId: "u12", action: "api_key.created", resourceType: "api_key", resourceId: "ak5", metadata: {}, ip: "10.42.18.12", result: "success" as const },
];

function actionIcon(action: string) {
  if (action.includes("user") || action.includes("workspace") || action.includes("team")) return <Users className="w-3 h-3" />;
  if (action.includes("api_key") || action.includes("webhook")) return <KeyRound className="w-3 h-3" />;
  if (action.includes("integration") || action.includes("billing")) return <Activity className="w-3 h-3" />;
  if (action.includes("role") || action.includes("policy")) return <ShieldCheck className="w-3 h-3" />;
  if (action.includes("incident")) return <AlertTriangle className="w-3 h-3" />;
  if (action.includes("alert")) return <Bell className="w-3 h-3" />;
  if (action.includes("deployment")) return <Rocket className="w-3 h-3" />;
  return <History className="w-3 h-3" />;
}

export default function WorkspaceDashboardPage() {
  const owner = people[0];
  const members = people.length;
  const topMembers = people.slice(0, 5);

  return (
    <PageContainer>
      <PageHeader
        title="Workspace"
        description="High-level overview of your SentinelGrid workspace, with quick access to all admin categories."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Workspace" }]}
        icon={<Building2 className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" asChild>
            <Link href="/admin/settings"><Settings className="w-3.5 h-3.5" /> Manage Settings</Link>
          </Button>
        }
      />

      {/* Workspace overview */}
      <Card className="p-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none" />
        <div className="relative grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-start gap-4">
              <div className="shrink-0 w-14 h-14 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                <Building2 className="w-7 h-7" />
              </div>
              <div className="min-w-0 space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-2xl font-semibold tracking-tight">SentinelGrid</h2>
                  <Badge variant="outline" className="text-[10px] gap-1"><Crown className="w-3 h-3" /> Pro Plan</Badge>
                </div>
                <p className="text-sm text-muted-foreground">Engineering Operations & Reliability Console</p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Stat label="Plan" value="Pro" icon={<Activity className="w-3.5 h-3.5" />} />
              <Stat label="Members" value={String(members)} icon={<Users className="w-3.5 h-3.5" />} />
              <Stat label="Created" value="Jan 2024" icon={<Calendar className="w-3.5 h-3.5" />} />
              <Stat label="Region" value="us-east-1" icon={<Globe className="w-3.5 h-3.5" />} />
            </div>
          </div>
          <div className="space-y-3">
            <div className="p-3 rounded-lg border space-y-2">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Workspace Owner</div>
              <div className="flex items-center gap-2.5">
                <Avatar className="w-8 h-8 shrink-0">
                  <AvatarImage src={owner.avatarUrl} alt={owner.name} />
                  <AvatarFallback>{owner.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <div className="text-xs font-medium truncate">{owner.name}</div>
                  <div className="text-[10px] text-muted-foreground truncate">{owner.title}</div>
                </div>
              </div>
            </div>
            <div className="p-3 rounded-lg border space-y-2">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Workspace ID</div>
              <code className="text-[11px] font-mono">ws_sentinelgrid_prod</code>
            </div>
          </div>
        </div>
      </Card>

      {/* Quick stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Services" value={services.length} hint="across 5 teams" icon={<Server className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Incidents (30d)" value={7} delta={-22.4} deltaLabel="vs prior 30d" icon={<AlertTriangle className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Deployments (30d)" value={142} delta={8.1} deltaLabel="vs prior 30d" icon={<Rocket className="w-4 h-4" />} accent="success" />
        <KpiCard label="Integrations" value={12} hint="9 connected" icon={<Plug className="w-4 h-4" />} accent="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Recent activity */}
        <Card className="p-5 space-y-4 lg:col-span-2">
          <SectionHeading
            title="Recent Activity"
            description="Latest workspace admin events"
            action={<Button variant="outline" size="sm" className="text-xs h-8 gap-1" asChild><Link href="/admin/audit-logs">View all <ChevronRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="space-y-1 max-h-96 overflow-y-auto pr-2 -mr-2">
            {activityFeed.slice(0, 10).map((e) => {
              const p = people.find((x) => x.id === e.actorId);
              return (
                <div key={e.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/30 transition-colors">
                  <Avatar className="w-7 h-7 shrink-0 mt-0.5">
                    <AvatarImage src={p?.avatarUrl} alt={p?.name} />
                    <AvatarFallback className="text-[10px]">{p?.name?.[0]}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-medium truncate">{p?.name || e.actorId}</span>
                      <code className="text-[10px] font-mono text-muted-foreground">{e.action}</code>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                      <span className="font-mono">{e.resourceType}/{e.resourceId}</span>
                      <span>·</span>
                      <span>{timeAgo(e.timestamp)}</span>
                      <span>·</span>
                      <span className="font-mono">{e.ip}</span>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[9px] gap-1 bg-success/10 text-success border-success/30 shrink-0">
                    {actionIcon(e.action)} {e.result}
                  </Badge>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Team preview */}
        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Team Members"
            description={`Top 5 of ${members} total`}
            action={<Button variant="outline" size="sm" className="text-xs h-8 gap-1" asChild><Link href="/admin/team">All <ChevronRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="space-y-1">
            {topMembers.map((p) => (
              <Link
                key={p.id}
                href={`/admin/team/${p.id}`}
                className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-muted/30 transition-colors"
              >
                <Avatar className="w-7 h-7 shrink-0">
                  <AvatarImage src={p.avatarUrl} alt={p.name} />
                  <AvatarFallback className="text-[10px]">{p.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-medium truncate">{p.name}</div>
                  <div className="text-[10px] text-muted-foreground truncate">{p.role}</div>
                </div>
                <span className="w-2 h-2 rounded-full bg-success shrink-0" title="Online" />
              </Link>
            ))}
          </div>
          <Separator />
          <div className="space-y-2">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Teams</div>
            {teams.slice(0, 3).map((t) => (
              <div key={t.id} className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full" style={{ background: t.color }} />
                <span className="text-xs truncate flex-1">{t.name}</span>
                <span className="text-[10px] text-muted-foreground tabular-nums">{t.memberIds.length}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Quick links */}
      <Card className="p-6 space-y-4">
        <SectionHeading title="Admin Quick Links" description="Jump to any admin category." />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {quickLinks.map((q) => {
            const Icon = q.icon;
            return (
              <Link
                key={q.label}
                href={q.href}
                className="group flex items-center gap-3 p-3 rounded-lg border hover:border-primary/30 hover:bg-muted/30 transition-colors"
              >
                <div className="shrink-0 w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                  <Icon className="w-4 h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate">{q.label}</div>
                  <div className="text-[10px] text-muted-foreground truncate">{q.description}</div>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary shrink-0" />
              </Link>
            );
          })}
        </div>
      </Card>
    </PageContainer>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) {
  return (
    <div className="p-2.5 rounded-lg border space-y-1">
      <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
        {icon} {label}
      </div>
      <div className="text-sm font-medium truncate">{value}</div>
    </div>
  );
}
