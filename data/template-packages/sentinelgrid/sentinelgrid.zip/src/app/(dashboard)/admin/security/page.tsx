"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import {
  ShieldCheck, KeyRound, Lock, Fingerprint, Network, ScrollText,
  Save, Globe, Monitor, Smartphone, Clock, AlertTriangle, LogOut,
} from "lucide-react";
import { people } from "@/lib/data";

interface ActiveSession {
  id: string;
  userId: string;
  device: string;
  browser: string;
  ip: string;
  location: string;
  lastActive: string;
  current: boolean;
}

const sessions: ActiveSession[] = [
  { id: "s1", userId: "u1", device: "MacBook Pro 16\"", browser: "Chrome 126", ip: "10.42.18.10", location: "San Francisco, US", lastActive: "2026-07-02T05:48:00Z", current: true },
  { id: "s2", userId: "u2", device: "ThinkPad X1", browser: "Firefox 127", ip: "10.42.18.14", location: "Los Angeles, US", lastActive: "2026-07-02T05:14:00Z", current: false },
  { id: "s3", userId: "u3", device: "Dell XPS 15", browser: "Chrome 126", ip: "10.42.18.31", location: "Mumbai, IN", lastActive: "2026-07-02T03:20:00Z", current: false },
  { id: "s4", userId: "u12", device: "iPhone 15 Pro", browser: "Safari Mobile", ip: "10.42.18.12", location: "San Francisco, US", lastActive: "2026-07-01T22:45:00Z", current: false },
];

export default function SecuritySettingsPage() {
  const [passwordMin, setPasswordMin] = React.useState(14);
  const [requireUppercase, setRequireUppercase] = React.useState(true);
  const [requireNumbers, setRequireNumbers] = React.useState(true);
  const [requireSymbols, setRequireSymbols] = React.useState(true);
  const [passwordExpiry, setPasswordExpiry] = React.useState("90d");
  const [passwordHistory, setPasswordHistory] = React.useState(5);

  const [mfaRequired, setMfaRequired] = React.useState(true);
  const [mfaMethods, setMfaMethods] = React.useState({ totp: true, webauthn: true, sms: false });
  const [mfaGrace, setMfaGrace] = React.useState("24h");

  const [ssoEnabled, setSsoEnabled] = React.useState(true);
  const [jitProvisioning, setJitProvisioning] = React.useState(true);
  const [scimSync, setScimSync] = React.useState(false);

  const [apiKeyExpiry, setApiKeyExpiry] = React.useState("365d");
  const [apiKeyScopes, setApiKeyScopes] = React.useState(true);
  const [apiKeyIpBinding, setApiKeyIpBinding] = React.useState(true);

  const [ipAllowlist, setIpAllowlist] = React.useState(true);
  const [ipList, setIpList] = React.useState("10.42.0.0/16\n172.16.0.0/12");

  const [auditLogRetention, setAuditLogRetention] = React.useState("730d");
  const [auditLogIntegrity, setAuditLogIntegrity] = React.useState(true);
  const [exportApproval, setExportApproval] = React.useState(true);

  function save(section: string) {
    toast.success(`${section} settings saved`, { description: "Policy changes are now enforced across the workspace." });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Security Settings"
        description="Workspace-wide security posture: passwords, MFA, SSO, API keys, network controls, and audit logging."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Security Settings" }]}
        icon={<ShieldCheck className="w-5 h-5" />}
        meta={<Badge variant="outline" className="text-[10px] gap-1 bg-success/10 text-success border-success/30"><ShieldCheck className="w-3 h-3" /> Score: A</Badge>}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Password Policy */}
        <Card className="p-6 space-y-5">
          <SectionHeading title="Password Policy" description="Enforced for all password-based logins." />
          <Separator />
          <div className="space-y-4">
            <FieldRow label="Minimum Length" hint="Recommended: 14+ characters.">
              <Input type="number" min={8} max={128} value={passwordMin} onChange={(e) => setPasswordMin(Number(e.target.value))} className="w-24" />
            </FieldRow>
            <ToggleRow label="Require uppercase letters" checked={requireUppercase} onCheckedChange={setRequireUppercase} />
            <ToggleRow label="Require numbers" checked={requireNumbers} onCheckedChange={setRequireNumbers} />
            <ToggleRow label="Require symbols" checked={requireSymbols} onCheckedChange={setRequireSymbols} />
            <FieldRow label="Password Expiry" hint="Force rotation after this period.">
              <Select value={passwordExpiry} onValueChange={setPasswordExpiry}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="never">Never</SelectItem>
                  <SelectItem value="30d">30 days</SelectItem>
                  <SelectItem value="90d">90 days</SelectItem>
                  <SelectItem value="180d">180 days</SelectItem>
                  <SelectItem value="365d">1 year</SelectItem>
                </SelectContent>
              </Select>
            </FieldRow>
            <FieldRow label="Password History" hint="Prevent reusing last N passwords.">
              <Input type="number" min={0} max={24} value={passwordHistory} onChange={(e) => setPasswordHistory(Number(e.target.value))} className="w-24" />
            </FieldRow>
          </div>
          <SaveBar onSave={() => save("Password Policy")} />
        </Card>

        {/* MFA */}
        <Card className="p-6 space-y-5">
          <SectionHeading title="Multi-Factor Authentication" description="Second factor requirements." />
          <Separator />
          <div className="space-y-4">
            <ToggleRow label="Require MFA for all members" checked={mfaRequired} onCheckedChange={setMfaRequired} />
            <Separator />
            <div className="space-y-2">
              <Label className="text-xs font-medium">Allowed MFA Methods</Label>
              <ToggleRow label="TOTP authenticator apps" checked={mfaMethods.totp} onCheckedChange={(v) => setMfaMethods((m) => ({ ...m, totp: v }))} />
              <ToggleRow label="WebAuthn / security keys" checked={mfaMethods.webauthn} onCheckedChange={(v) => setMfaMethods((m) => ({ ...m, webauthn: v }))} />
              <ToggleRow label="SMS (not recommended)" checked={mfaMethods.sms} onCheckedChange={(v) => setMfaMethods((m) => ({ ...m, sms: v }))} />
            </div>
            <FieldRow label="Enforcement Grace Period" hint="Time given to set up MFA before enforcement.">
              <Select value={mfaGrace} onValueChange={setMfaGrace}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="immediate">Immediate</SelectItem>
                  <SelectItem value="24h">24 hours</SelectItem>
                  <SelectItem value="7d">7 days</SelectItem>
                  <SelectItem value="14d">14 days</SelectItem>
                </SelectContent>
              </Select>
            </FieldRow>
          </div>
          <SaveBar onSave={() => save("MFA")} />
        </Card>

        {/* SSO/SAML */}
        <Card className="p-6 space-y-5">
          <SectionHeading title="SSO / SAML" description="Federated identity configuration." />
          <Separator />
          <div className="space-y-4">
            <ToggleRow label="Enable SSO" checked={ssoEnabled} onCheckedChange={setSsoEnabled} />
            {ssoEnabled && (
              <>
                <FieldRow label="SAML Entity ID">
                  <Input defaultValue="https://ops.sentinelgrid.io/saml/metadata" className="font-mono" />
                </FieldRow>
                <FieldRow label="IdP Metadata URL">
                  <Input defaultValue="https://idp.sentinelgrid.io/metadata.xml" className="font-mono" />
                </FieldRow>
                <ToggleRow label="JIT provisioning" description="Auto-create accounts on first SSO login." checked={jitProvisioning} onCheckedChange={setJitProvisioning} />
                <ToggleRow label="SCIM user sync" description="Sync users and groups from IdP via SCIM 2.0." checked={scimSync} onCheckedChange={setScimSync} />
              </>
            )}
          </div>
          <SaveBar onSave={() => save("SSO/SAML")} />
        </Card>

        {/* API Key Policy */}
        <Card className="p-6 space-y-5">
          <SectionHeading title="API Key Policy" description="Rules for programmatic access tokens." />
          <Separator />
          <div className="space-y-4">
            <FieldRow label="Default Key Expiry" hint="Max lifetime for new keys.">
              <Select value={apiKeyExpiry} onValueChange={setApiKeyExpiry}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="30d">30 days</SelectItem>
                  <SelectItem value="90d">90 days</SelectItem>
                  <SelectItem value="180d">180 days</SelectItem>
                  <SelectItem value="365d">1 year</SelectItem>
                  <SelectItem value="never">Never</SelectItem>
                </SelectContent>
              </Select>
            </FieldRow>
            <ToggleRow label="Require explicit scopes" description="Keys must declare scopes at creation." checked={apiKeyScopes} onCheckedChange={setApiKeyScopes} />
            <ToggleRow label="IP binding required" description="Keys must be bound to one or more CIDRs." checked={apiKeyIpBinding} onCheckedChange={setApiKeyIpBinding} />
            <div className="p-3 rounded-lg border border-info/30 bg-info/5 flex items-start gap-2">
              <KeyRound className="w-3.5 h-3.5 text-info-foreground mt-0.5 shrink-0" />
              <p className="text-[11px] text-muted-foreground">4 active keys · 1 revoked · 1 expiring within 30 days.</p>
            </div>
          </div>
          <SaveBar onSave={() => save("API Key Policy")} />
        </Card>

        {/* IP Restrictions */}
        <Card className="p-6 space-y-5">
          <SectionHeading title="IP Restrictions" description="Network-level access controls." />
          <Separator />
          <div className="space-y-4">
            <ToggleRow label="Enable IP allowlist" description="Block dashboard/API access outside listed CIDRs." checked={ipAllowlist} onCheckedChange={setIpAllowlist} />
            {ipAllowlist && (
              <FieldRow label="Allowed CIDRs" hint="One per line. Supports IPv4 and IPv6.">
                <Textarea
                  value={ipList}
                  onChange={(e) => setIpList(e.target.value)}
                  className="min-h-[100px] font-mono text-xs resize-none"
                />
              </FieldRow>
            )}
            <div className="flex items-start gap-2 p-3 rounded-lg border border-warning/30 bg-warning/5">
              <AlertTriangle className="w-3.5 h-3.5 text-warning-foreground mt-0.5 shrink-0" />
              <p className="text-[11px] text-muted-foreground">Service-to-service traffic is unaffected. Members outside allowlist will be unable to log in.</p>
            </div>
          </div>
          <SaveBar onSave={() => save("IP Restrictions")} />
        </Card>

        {/* Audit Settings */}
        <Card className="p-6 space-y-5">
          <SectionHeading title="Audit Settings" description="Tamper-evident logging configuration." />
          <Separator />
          <div className="space-y-4">
            <FieldRow label="Audit Log Retention" hint="Compliance-critical retention period.">
              <Select value={auditLogRetention} onValueChange={setAuditLogRetention}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="365d">1 year</SelectItem>
                  <SelectItem value="730d">2 years</SelectItem>
                  <SelectItem value="1825d">5 years</SelectItem>
                  <SelectItem value="3650d">10 years</SelectItem>
                </SelectContent>
              </Select>
            </FieldRow>
            <ToggleRow label="Chain-of-custody hashing" description="Append-only hash chain for tamper detection." checked={auditLogIntegrity} onCheckedChange={setAuditLogIntegrity} />
            <ToggleRow label="Require approval to export" description="Two-person approval for audit log exports." checked={exportApproval} onCheckedChange={setExportApproval} />
          </div>
          <SaveBar onSave={() => save("Audit Settings")} />
        </Card>
      </div>

      {/* Active sessions preview */}
      <Card className="p-6 space-y-5">
        <SectionHeading
          title="Active Sessions Preview"
          description="Currently authenticated sessions across all members."
          action={<Button variant="outline" size="sm" className="gap-1.5 text-xs h-8" onClick={() => { window.location.href = "/admin/sessions"; }}>View all <LogOut className="w-3 h-3" /></Button>}
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {sessions.map((s) => {
            const user = people.find((p) => p.id === s.userId);
            return (
              <div key={s.id} className="flex items-center gap-3 p-3 rounded-lg border">
                <Avatar className="w-9 h-9 shrink-0">
                  <AvatarImage src={user?.avatarUrl} alt={user?.name} />
                  <AvatarFallback>{user?.name?.[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-medium truncate">{user?.name}</span>
                    {s.current && <Badge variant="outline" className="text-[9px] bg-success/10 text-success border-success/30">YOU</Badge>}
                  </div>
                  <div className="text-[10px] text-muted-foreground truncate flex items-center gap-1">
                    <Monitor className="w-2.5 h-2.5" /> {s.device} · {s.browser}
                  </div>
                  <div className="text-[10px] text-muted-foreground truncate flex items-center gap-1">
                    <Globe className="w-2.5 h-2.5" /> {s.location} · <span className="font-mono">{s.ip}</span>
                  </div>
                </div>
                {!s.current && (
                  <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 shrink-0" onClick={() => toast.success("Session revoked", { description: `${user?.name} will be signed out.` })}>
                    <LogOut className="w-3 h-3" /> Revoke
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </PageContainer>
  );
}

function FieldRow({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0 space-y-0.5">
        <Label className="text-xs font-medium">{label}</Label>
        {hint && <p className="text-[10px] text-muted-foreground">{hint}</p>}
      </div>
      {children}
    </div>
  );
}

function ToggleRow({ label, description, checked, onCheckedChange }: {
  label: string; description?: string; checked: boolean; onCheckedChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0 space-y-0.5">
        <Label className="text-xs font-medium">{label}</Label>
        {description && <p className="text-[10px] text-muted-foreground">{description}</p>}
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

function SaveBar({ onSave }: { onSave: () => void }) {
  return (
    <div className="flex items-center justify-end pt-2 border-t border-border">
      <Button size="sm" className="gap-1.5" onClick={onSave}>
        <Save className="w-3.5 h-3.5" /> Save
      </Button>
    </div>
  );
}
