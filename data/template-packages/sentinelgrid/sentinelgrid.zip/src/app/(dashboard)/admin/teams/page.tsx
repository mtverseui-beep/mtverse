"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Users, UsersRound, Server, Crown, Plus, ChevronRight,
} from "lucide-react";
import { people, teams, services } from "@/lib/data";
import { toast } from "sonner";

export default function TeamsPage() {
  const totalTeams = teams.length;
  const totalMembers = people.length;
  const avgSize = Math.round(totalMembers / totalTeams);
  const servicesCovered = services.length;

  return (
    <PageContainer>
      <PageHeader
        title="Teams"
        description="Organizational teams, their leads, members, and services they own."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Teams" }]}
        icon={<UsersRound className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Create team dialog opened")}>
            <Plus className="w-3.5 h-3.5" />
            New Team
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Teams" value={totalTeams} icon={<UsersRound className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Total Members" value={totalMembers} icon={<Users className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg Team Size" value={avgSize} hint="members per team" icon={<Users className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Services Covered" value={servicesCovered} hint="across all teams" icon={<Server className="w-4 h-4" />} accent="success" />
      </div>

      {/* Team cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {teams.map((t) => {
          const lead = people.find((p) => p.id === t.leadId);
          const members = t.memberIds.map((id) => people.find((p) => p.id === id)).filter(Boolean);
          const teamServices = services.filter((s) => t.servicesOwned.includes(s.id));
          const operational = teamServices.filter((s) => s.health === "operational").length;
          const healthPct = teamServices.length > 0 ? Math.round((operational / teamServices.length) * 100) : 100;

          return (
            <Card key={t.id} className="p-5 space-y-4 hover:border-primary/30 transition-colors group">
              {/* Header */}
              <div className="flex items-start gap-3">
                <div className="shrink-0 w-11 h-11 rounded-lg flex items-center justify-center text-sm font-bold" style={{ background: `${t.color}20`, color: t.color, border: `1px solid ${t.color}40` }}>
                  {t.name.split(" ").slice(0, 2).map((w) => w[0]).join("")}
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-semibold truncate">{t.name}</h3>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider mt-0.5">{t.slug}</p>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">{t.description}</p>

              {/* Lead */}
              {lead && (
                <div className="flex items-center gap-2 p-2 rounded-md bg-muted/40">
                  <img src={lead.avatarUrl} alt="" className="w-7 h-7 rounded-full object-cover" />
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] text-muted-foreground">Team Lead</div>
                    <div className="text-xs font-medium truncate">{lead.name}</div>
                  </div>
                  <Crown className="w-3.5 h-3.5 text-warning-foreground" />
                </div>
              )}

              {/* Members */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-muted-foreground">Members ({members.length})</span>
                  <span className="font-medium tabular-nums">{members.length} engineers</span>
                </div>
                <div className="flex items-center -space-x-2">
                  {members.slice(0, 6).map((m) => m && (
                    <img
                      key={m.id}
                      src={m.avatarUrl}
                      alt={m.name}
                      title={m.name}
                      className="w-7 h-7 rounded-full object-cover border-2 border-card"
                    />
                  ))}
                  {members.length > 6 && (
                    <div className="w-7 h-7 rounded-full bg-muted border-2 border-card flex items-center justify-center text-[10px] font-medium">
                      +{members.length - 6}
                    </div>
                  )}
                </div>
              </div>

              {/* Services owned */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-muted-foreground">Services ({teamServices.length})</span>
                  <span className={`font-medium ${healthPct === 100 ? "text-success" : healthPct >= 80 ? "text-warning-foreground" : "text-destructive"}`}>{healthPct}% operational</span>
                </div>
                <Progress value={healthPct} className={`h-1.5 ${healthPct === 100 ? "[&_>div]:bg-success" : healthPct >= 80 ? "[&_>div]:bg-warning" : "[&_>div]:bg-destructive"}`} />
                <div className="flex flex-wrap gap-1">
                  {teamServices.slice(0, 4).map((s) => (
                    <span key={s.id} className="inline-flex items-center text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted">
                      {s.name}
                    </span>
                  ))}
                  {teamServices.length > 4 && (
                    <span className="text-[10px] text-muted-foreground">+{teamServices.length - 4} more</span>
                  )}
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center gap-1.5 pt-3 border-t border-border">
                <Button asChild variant="outline" size="sm" className="flex-1 h-7 text-xs gap-1">
                  <Link href={`/admin/team?team=${t.id}`}>View Members <ChevronRight className="w-3 h-3" /></Link>
                </Button>
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.info(`Opening team configuration for ${t.name}`)}>
                  Configure
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Team coverage matrix */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Team Coverage Matrix" description="Service ownership and health across teams" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="px-3 py-2.5 text-left text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Team</th>
                <th className="px-3 py-2.5 text-left text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Members</th>
                <th className="px-3 py-2.5 text-left text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Services</th>
                <th className="px-3 py-2.5 text-left text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Operational</th>
                <th className="px-3 py-2.5 text-left text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Coverage</th>
              </tr>
            </thead>
            <tbody>
              {teams.map((t) => {
                const teamServices = services.filter((s) => t.servicesOwned.includes(s.id));
                const operational = teamServices.filter((s) => s.health === "operational").length;
                const pct = teamServices.length > 0 ? Math.round((operational / teamServices.length) * 100) : 100;
                return (
                  <tr key={t.id} className="border-t border-border hover:bg-muted/30">
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full" style={{ background: t.color }} />
                        <span className="text-xs font-medium">{t.name}</span>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-xs tabular-nums">{t.memberIds.length}</td>
                    <td className="px-3 py-2.5 text-xs tabular-nums">{teamServices.length}</td>
                    <td className="px-3 py-2.5 text-xs tabular-nums">{operational}/{teamServices.length}</td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2">
                        <Progress value={pct} className={`h-1.5 flex-1 ${pct === 100 ? "[&_>div]:bg-success" : pct >= 80 ? "[&_>div]:bg-warning" : "[&_>div]:bg-destructive"}`} />
                        <span className="text-[11px] font-mono tabular-nums w-10 text-right">{pct}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </PageContainer>
  );
}
