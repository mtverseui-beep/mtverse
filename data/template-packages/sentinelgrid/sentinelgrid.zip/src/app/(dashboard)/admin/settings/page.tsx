"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Settings, Palette, ShieldCheck, Bell, SlidersHorizontal,
  Upload, Check, RotateCcw, Save, ImageIcon, Link2, KeyRound,
  Moon, Mail, Smartphone, Server, Lock, Network,
} from "lucide-react";

const timezones = [
  "America/Los_Angeles", "America/Denver", "America/Chicago", "America/New_York",
  "America/Mexico_City", "Europe/London", "Europe/Paris", "Europe/Berlin",
  "Europe/Rome", "Europe/Moscow", "Asia/Kolkata", "Asia/Shanghai",
  "Asia/Tokyo", "Asia/Singapore", "Australia/Sydney",
];

const regions = ["us-east-1", "us-west-2", "eu-west-1", "eu-central-1", "ap-south-1", "ap-southeast-2", "global"];

const brandColors = [
  { name: "Electric Cyan", value: "#22D3EE" },
  { name: "Violet", value: "#A78BFA" },
  { name: "Emerald", value: "#34D399" },
  { name: "Amber", value: "#F59E0B" },
  { name: "Rose", value: "#F87171" },
  { name: "Sky", value: "#38BDF8" },
];

export default function WorkspaceSettingsPage() {
  const [activeTab, setActiveTab] = React.useState("general");
  const [primaryColor, setPrimaryColor] = React.useState("#22D3EE");
  const [ssoEnabled, setSsoEnabled] = React.useState(true);
  const [mfaRequired, setMfaRequired] = React.useState(true);
  const [quietHours, setQuietHours] = React.useState(false);
  const [logoUploaded, setLogoUploaded] = React.useState(true);

  function handleSave(section: string) {
    toast.success(`${section} settings saved`, { description: "Changes are now live for all workspace members." });
  }
  function handleReset(section: string) {
    toast.info(`${section} settings reset`, { description: "Reverted to last saved values." });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Workspace Settings"
        description="Configure workspace identity, branding, authentication, notification defaults, and data retention policies."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Admin", href: "/admin" }, { label: "Settings" }]}
        icon={<Settings className="w-5 h-5" />}
        meta={<Badge variant="outline" className="text-[10px] gap-1"><Lock className="w-3 h-3" /> Admin only</Badge>}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => handleReset("All")}>
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => handleSave("All")}>
              <Save className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Save All</span>
            </Button>
          </>
        }
      />

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full justify-start overflow-x-auto h-auto flex-wrap">
          <TabsTrigger value="general" className="gap-1.5"><SlidersHorizontal className="w-3.5 h-3.5" /> General</TabsTrigger>
          <TabsTrigger value="branding" className="gap-1.5"><Palette className="w-3.5 h-3.5" /> Branding</TabsTrigger>
          <TabsTrigger value="auth" className="gap-1.5"><ShieldCheck className="w-3.5 h-3.5" /> Authentication</TabsTrigger>
          <TabsTrigger value="notifications" className="gap-1.5"><Bell className="w-3.5 h-3.5" /> Notifications</TabsTrigger>
          <TabsTrigger value="advanced" className="gap-1.5"><SlidersHorizontal className="w-3.5 h-3.5" /> Advanced</TabsTrigger>
        </TabsList>

        {/* GENERAL */}
        <TabsContent value="general" className="space-y-6 mt-4">
          <Card className="p-6 space-y-5">
            <SectionHeading title="General" description="Core workspace identity and locale defaults." />
            <Separator />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <Field label="Workspace Name" hint="Shown across the product and in notifications.">
                <Input defaultValue="SentinelGrid" />
              </Field>
              <Field label="Workspace Slug" hint="Used in URLs and API paths. Lowercase only.">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground font-mono">/</span>
                  <Input defaultValue="sentinelgrid" className="font-mono" />
                </div>
              </Field>
              <Field label="Default Timezone" hint="Applied to dashboards, schedules, and reports.">
                <Select defaultValue="America/Los_Angeles">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent className="max-h-72">
                    {timezones.map((tz) => <SelectItem key={tz} value={tz}>{tz.replace(/_/g, " ")}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Default Region" hint="Primary deployment region for new services.">
                <Select defaultValue="us-east-1">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {regions.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Support Email" hint="Outbound 'from' address for system emails.">
                <Input type="email" defaultValue="support@sentinelgrid.io" />
              </Field>
              <Field label="Workspace Description" hint="Internal note, visible to admins only.">
                <Textarea defaultValue="Engineering Operations & Reliability Console for SentinelGrid." className="min-h-[80px] resize-none" />
              </Field>
            </div>
            <FormActions onSave={() => handleSave("General")} onReset={() => handleReset("General")} />
          </Card>
        </TabsContent>

        {/* BRANDING */}
        <TabsContent value="branding" className="space-y-6 mt-4">
          <Card className="p-6 space-y-5">
            <SectionHeading title="Branding" description="Customize logos, colors, and domain." />
            <Separator />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Field label="Logo" hint="SVG or PNG, max 512x512. Displayed in header and emails.">
                <div className="flex items-center gap-4">
                  <div className="shrink-0 w-16 h-16 rounded-lg border-2 border-dashed border-border flex items-center justify-center bg-muted/40">
                    {logoUploaded ? <ImageIcon className="w-6 h-6 text-primary" /> : <Upload className="w-5 h-5 text-muted-foreground" />}
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button variant="outline" size="sm" className="gap-1.5 w-fit" onClick={() => { setLogoUploaded(true); toast.success("Logo uploaded", { description: "logo-mark.svg · 8.2 KB" }); }}>
                      <Upload className="w-3.5 h-3.5" /> Upload
                    </Button>
                    {logoUploaded && (
                      <span className="text-[11px] text-muted-foreground inline-flex items-center gap-1">
                        <Check className="w-3 h-3 text-success" /> logo-mark.svg · 8.2 KB
                      </span>
                    )}
                  </div>
                </div>
              </Field>
              <Field label="Primary Color" hint="Used for buttons, links, and active states.">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-md border" style={{ background: primaryColor }} />
                    <Input value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} className="font-mono w-32" />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {brandColors.map((c) => (
                      <button
                        key={c.value}
                        onClick={() => { setPrimaryColor(c.value); toast.info(`Primary color set to ${c.name}`); }}
                        className="w-7 h-7 rounded-md border-2 transition-transform hover:scale-110"
                        style={{ background: c.value, borderColor: primaryColor === c.value ? "white" : "transparent" }}
                        title={c.name}
                        aria-label={c.name}
                      />
                    ))}
                  </div>
                </div>
              </Field>
              <Field label="Custom Domain" hint="Pro plan or higher. DNS verification required.">
                <div className="flex items-center gap-2 flex-wrap">
                  <Link2 className="w-4 h-4 text-muted-foreground" />
                  <Input defaultValue="ops.sentinelgrid.io" className="font-mono flex-1 min-w-[180px]" />
                  <Badge variant="outline" className="text-[10px] gap-1 bg-success/10 text-success border-success/30">
                    <Check className="w-3 h-3" /> Verified
                  </Badge>
                </div>
              </Field>
              <Field label="Email Logo URL" hint="Hosted logo used in transactional emails.">
                <Input defaultValue="https://cdn.sentinelgrid.io/brand/email-logo.png" className="font-mono" />
              </Field>
            </div>
            <FormActions onSave={() => handleSave("Branding")} onReset={() => handleReset("Branding")} />
          </Card>
        </TabsContent>

        {/* AUTHENTICATION */}
        <TabsContent value="auth" className="space-y-6 mt-4">
          <Card className="p-6 space-y-5">
            <SectionHeading title="Authentication" description="SSO, MFA, and session controls." />
            <Separator />
            <ToggleRow
              icon={<KeyRound className="w-4 h-4" />}
              title="Single Sign-On (SSO)"
              description="Allow members to authenticate via your identity provider."
              checked={ssoEnabled}
              onCheckedChange={setSsoEnabled}
            />
            {ssoEnabled && (
              <div className="ml-6 pl-4 border-l-2 border-border space-y-4">
                <Field label="SAML Entity ID" hint="Identifier sent to your IdP.">
                  <Input defaultValue="https://ops.sentinelgrid.io/saml/metadata" className="font-mono" />
                </Field>
                <Field label="IdP Metadata URL" hint="Auto-refreshes every 6 hours.">
                  <Input defaultValue="https://idp.sentinelgrid.io/metadata.xml" className="font-mono" />
                </Field>
                <Field label="IdP Certificate Fingerprint" hint="SHA-256 fingerprint of the signing certificate.">
                  <Input defaultValue="8F:3A:2C:9D:F1:B7:4E:A2" className="font-mono" />
                </Field>
              </div>
            )}
            <Separator />
            <ToggleRow
              icon={<ShieldCheck className="w-4 h-4" />}
              title="Require MFA"
              description="All members must enable multi-factor authentication."
              checked={mfaRequired}
              onCheckedChange={setMfaRequired}
            />
            <Separator />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <Field label="Session Timeout" hint="Members are logged out after this period of inactivity.">
                <Select defaultValue="8h">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1h">1 hour</SelectItem>
                    <SelectItem value="4h">4 hours</SelectItem>
                    <SelectItem value="8h">8 hours</SelectItem>
                    <SelectItem value="24h">24 hours</SelectItem>
                    <SelectItem value="7d">7 days</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Maximum Concurrent Sessions" hint="Per-member limit across devices.">
                <Input type="number" defaultValue={5} min={1} max={20} className="w-full" />
              </Field>
            </div>
            <FormActions onSave={() => handleSave("Authentication")} onReset={() => handleReset("Authentication")} />
          </Card>
        </TabsContent>

        {/* NOTIFICATIONS */}
        <TabsContent value="notifications" className="space-y-6 mt-4">
          <Card className="p-6 space-y-5">
            <SectionHeading title="Notifications" description="Default routing and timing for system notifications." />
            <Separator />
            <Field label="Default Channels" hint="Where new incidents and alerts are sent by default.">
              <div className="flex flex-wrap gap-2">
                {[
                  { icon: Mail, label: "Email", active: true },
                  { icon: Smartphone, label: "Mobile Push", active: true },
                  { icon: Server, label: "Slack", active: true },
                  { icon: Server, label: "PagerDuty", active: true },
                  { icon: Smartphone, label: "SMS", active: false },
                ].map((c) => (
                  <Badge key={c.label} variant={c.active ? "default" : "outline"} className="text-xs gap-1 px-2 py-1">
                    <c.icon className="w-3 h-3" /> {c.label}
                  </Badge>
                ))}
              </div>
            </Field>
            <Separator />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <Field label="First Escalation" hint="Time before escalating to next tier.">
                <Select defaultValue="5m">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1m">1 minute</SelectItem>
                    <SelectItem value="5m">5 minutes</SelectItem>
                    <SelectItem value="10m">10 minutes</SelectItem>
                    <SelectItem value="15m">15 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Second Escalation" hint="Time before escalating to manager.">
                <Select defaultValue="15m">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10m">10 minutes</SelectItem>
                    <SelectItem value="15m">15 minutes</SelectItem>
                    <SelectItem value="30m">30 minutes</SelectItem>
                    <SelectItem value="60m">60 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Max Escalations" hint="Maximum escalation rounds before auto-resolve.">
                <Input type="number" defaultValue={3} min={1} max={10} />
              </Field>
            </div>
            <Separator />
            <ToggleRow
              icon={<Moon className="w-4 h-4" />}
              title="Quiet Hours"
              description="Suppress non-critical notifications during off-hours."
              checked={quietHours}
              onCheckedChange={setQuietHours}
            />
            {quietHours && (
              <div className="ml-6 pl-4 border-l-2 border-border grid grid-cols-1 md:grid-cols-3 gap-4">
                <Field label="Start">
                  <Input type="time" defaultValue="22:00" />
                </Field>
                <Field label="End">
                  <Input type="time" defaultValue="07:00" />
                </Field>
                <Field label="Timezone">
                  <Select defaultValue="America/Los_Angeles">
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {timezones.slice(0, 8).map((tz) => <SelectItem key={tz} value={tz}>{tz.replace(/_/g, " ")}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </Field>
              </div>
            )}
            <FormActions onSave={() => handleSave("Notifications")} onReset={() => handleReset("Notifications")} />
          </Card>
        </TabsContent>

        {/* ADVANCED */}
        <TabsContent value="advanced" className="space-y-6 mt-4">
          <Card className="p-6 space-y-5">
            <SectionHeading title="Advanced" description="Data retention, audit log retention, and network policy." />
            <Separator />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <Field label="Data Retention" hint="How long operational data (incidents, alerts) is retained.">
                <Select defaultValue="365d">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="90d">90 days</SelectItem>
                    <SelectItem value="180d">180 days</SelectItem>
                    <SelectItem value="365d">1 year</SelectItem>
                    <SelectItem value="730d">2 years</SelectItem>
                    <SelectItem value="forever">Forever</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Audit Log Retention" hint="Compliance-critical logs. Cannot be shorter than data retention.">
                <Select defaultValue="730d">
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="365d">1 year</SelectItem>
                    <SelectItem value="730d">2 years</SelectItem>
                    <SelectItem value="1825d">5 years</SelectItem>
                    <SelectItem value="3650d">10 years</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
            </div>
            <Separator />
            <Field label="IP Allowlist" hint="One CIDR per line. Empty = allow all.">
              <Textarea
                defaultValue={`10.42.0.0/16\n172.16.0.0/12\n192.168.1.0/24`}
                className="min-h-[120px] font-mono text-xs resize-none"
              />
            </Field>
            <div className="flex items-start gap-2 p-3 rounded-lg border border-warning/30 bg-warning/5">
              <Network className="w-4 h-4 text-warning-foreground mt-0.5 shrink-0" />
              <p className="text-xs text-muted-foreground">
                When the allowlist is non-empty, all dashboard and API access from outside the listed CIDRs is blocked. Service-to-service traffic is unaffected.
              </p>
            </div>
            <FormActions onSave={() => handleSave("Advanced")} onReset={() => handleReset("Advanced")} />
          </Card>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium">{label}</Label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}

function ToggleRow({ icon, title, description, checked, onCheckedChange }: {
  icon: React.ReactNode; title: string; description: string; checked: boolean; onCheckedChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div className="flex items-start gap-3 min-w-0">
        <div className="shrink-0 w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
          {icon}
        </div>
        <div className="min-w-0 space-y-0.5">
          <h3 className="text-sm font-medium">{title}</h3>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

function FormActions({ onSave, onReset }: { onSave: () => void; onReset: () => void }) {
  return (
    <div className="flex items-center justify-end gap-2 pt-2 border-t border-border">
      <Button variant="outline" size="sm" className="gap-1.5" onClick={onReset}>
        <RotateCcw className="w-3.5 h-3.5" /> Reset
      </Button>
      <Button size="sm" className="gap-1.5" onClick={onSave}>
        <Save className="w-3.5 h-3.5" /> Save changes
      </Button>
    </div>
  );
}
