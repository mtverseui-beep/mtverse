"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ScrollText, Search, Filter, RefreshCw, Download, ChevronDown, ChevronRight,
  Bookmark, Clock, X, ExternalLink, Terminal, AlertTriangle, Info, Bug,
  AlertOctagon, Activity, Zap,
} from "lucide-react";
import { sampleLogs, services } from "@/lib/data";
import type { LogEntry } from "@/lib/types";
import { useRouter } from "next/navigation";

const levelConfig: Record<LogEntry["level"], { color: string; bg: string; dot: string; icon: React.ReactNode }> = {
  trace: { color: "text-muted-foreground", bg: "bg-muted/40 border-border", dot: "bg-muted-foreground", icon: <Activity className="w-3 h-3" /> },
  debug: { color: "text-info-foreground", bg: "bg-info/15 border-info/30", dot: "bg-info", icon: <Bug className="w-3 h-3" /> },
  info: { color: "text-primary", bg: "bg-primary/15 border-primary/30", dot: "bg-primary", icon: <Info className="w-3 h-3" /> },
  warn: { color: "text-warning-foreground", bg: "bg-warning/15 border-warning/30", dot: "bg-warning", icon: <AlertTriangle className="w-3 h-3" /> },
  error: { color: "text-destructive", bg: "bg-destructive/15 border-destructive/30", dot: "bg-destructive", icon: <AlertOctagon className="w-3 h-3" /> },
  fatal: { color: "text-destructive", bg: "bg-destructive/25 border-destructive/40", dot: "bg-destructive", icon: <AlertOctagon className="w-3 h-3" /> },
};

const savedQueries = [
  { name: "5xx errors last 1h", query: 'level:error status:5xx', count: 184 },
  { name: "checkout-service logs", query: "service:checkout-api", count: 12480 },
  { name: "Slow DB queries", query: 'message:"query took" duration:>500ms', count: 84 },
  { name: "Auth failures", query: 'service:auth-service message:"auth failed"', count: 312 },
  { name: "Kafka consumer lag", query: 'service:kafka-bus message:"lag"', count: 56 },
];

const recentSearches = [
  'level:error',
  'service:checkout-api',
  'trace_id:trace_a3f2c1b8e7d2',
  'message:"connection refused"',
  'host:host-3',
];

export default function LogsExplorerPage() {
  const router = useRouter();
  const [logs] = React.useState<LogEntry[]>(() => sampleLogs(50));
  const [search, setSearch] = React.useState("");
  const [levelFilter, setLevelFilter] = React.useState<LogEntry["level"] | "all">("all");
  const [serviceFilter, setServiceFilter] = React.useState<string>("all");
  const [timeRange, setTimeRange] = React.useState("15m");
  const [expanded, setExpanded] = React.useState<Set<string>>(new Set());
  const [activeFilters, setActiveFilters] = React.useState<string[]>([]);

  const filtered = logs.filter((l) => {
    if (levelFilter !== "all" && l.level !== levelFilter) return false;
    if (serviceFilter !== "all" && l.serviceId !== serviceFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      const svc = services.find((s) => s.id === l.serviceId)?.name ?? "";
      if (!l.message.toLowerCase().includes(q) && !svc.toLowerCase().includes(q) && !l.host?.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  function toggleExpand(id: string) {
    setExpanded((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  }

  function addFilter(filter: string) {
    if (!activeFilters.includes(filter)) setActiveFilters([...activeFilters, filter]);
  }
  function removeFilter(filter: string) {
    setActiveFilters(activeFilters.filter((f) => f !== filter));
  }

  const errorCount = logs.filter((l) => l.level === "error" || l.level === "fatal").length;
  const warnCount = logs.filter((l) => l.level === "warn").length;
  const withTrace = logs.filter((l) => l.traceId).length;

  return (
    <PageContainer wide>
      <PageHeader
        title="Logs Explorer"
        description="Real-time log streaming across all services with full-text search, severity filters, and trace ID correlation."
        breadcrumbs={[{ label: "Logs & Traces" }, { label: "Explorer" }]}
        icon={<ScrollText className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Live</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total Logs" value={logs.length} hint="in current view" icon={<ScrollText className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Errors" value={errorCount} hint="error + fatal" icon={<AlertOctagon className="w-4 h-4" />} accent={errorCount > 0 ? "destructive" : "muted"} />
        <KpiCard label="Warnings" value={warnCount} icon={<AlertTriangle className="w-4 h-4" />} accent="warning" />
        <KpiCard label="With Trace" value={withTrace} hint="linked to traces" icon={<Zap className="w-4 h-4" />} accent="info" />
      </div>

      {/* Search bar */}
      <Card className="p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search logs... (message, service, host)"
              className="pl-9 h-10 font-mono text-sm"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <div className="flex items-center gap-2">
            <select
              value={serviceFilter}
              onChange={(e) => setServiceFilter(e.target.value)}
              className="h-10 rounded-md border bg-background px-3 text-xs"
            >
              <option value="all">All Services</option>
              {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="h-10 rounded-md border bg-background px-3 text-xs"
            >
              <option value="5m">Last 5m</option>
              <option value="15m">Last 15m</option>
              <option value="1h">Last 1h</option>
              <option value="6h">Last 6h</option>
              <option value="24h">Last 24h</option>
            </select>
          </div>
        </div>

        {/* Filter chips */}
        <div className="flex items-center gap-2 flex-wrap">
          <Filter className="w-3 h-3 text-muted-foreground" />
          <button
            onClick={() => setLevelFilter("all")}
            className={`px-2 py-0.5 rounded-md text-[11px] font-medium border ${levelFilter === "all" ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border hover:bg-muted"}`}
          >All</button>
          {(Object.keys(levelConfig) as LogEntry["level"][]).map((lvl) => (
            <button
              key={lvl}
              onClick={() => setLevelFilter(lvl)}
              className={`px-2 py-0.5 rounded-md text-[11px] font-medium border inline-flex items-center gap-1 ${
                levelFilter === lvl ? levelConfig[lvl].bg : "bg-background text-muted-foreground border-border hover:bg-muted"
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${levelConfig[lvl].dot}`} />
              {lvl}
            </button>
          ))}
        </div>

        {/* Active filters */}
        {activeFilters.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-border">
            <span className="text-[11px] text-muted-foreground">Active:</span>
            {activeFilters.map((f) => (
              <Badge key={f} variant="outline" className="text-[10px] font-mono gap-1">
                {f}
                <button onClick={() => removeFilter(f)}><X className="w-2.5 h-2.5" /></button>
              </Badge>
            ))}
          </div>
        )}
      </Card>

      {/* Main content: log list + sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Log list */}
        <Card className="lg:col-span-3 p-0 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <div className="text-sm font-semibold">{filtered.length} events</div>
            <div className="text-[10px] text-muted-foreground inline-flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-success animate-status-pulse" /> Live streaming</div>
          </div>
          <ScrollArea className="h-[640px]">
            <div className="divide-y divide-border">
              {filtered.map((log) => {
                const svc = services.find((s) => s.id === log.serviceId);
                const l = levelConfig[log.level];
                const isOpen = expanded.has(log.id);
                return (
                  <div key={log.id} className={`px-4 py-2 hover:bg-muted/30 transition-colors ${log.level === "error" || log.level === "fatal" ? "bg-destructive/5" : ""}`}>
                    <div className="flex items-start gap-2">
                      <button
                        onClick={() => toggleExpand(log.id)}
                        className="mt-0.5 text-muted-foreground hover:text-foreground shrink-0"
                        aria-label={isOpen ? "Collapse" : "Expand"}
                      >
                        {isOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      </button>
                      <span className="text-[10px] font-mono text-muted-foreground tabular-nums shrink-0 mt-0.5">
                        {new Date(log.timestamp).toISOString().slice(11, 19)}
                      </span>
                      <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide border shrink-0 ${l.bg}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${l.dot}`} />{log.level}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[11px] font-mono text-primary">{svc?.name ?? log.serviceId}</span>
                          {log.host && <span className="text-[10px] text-muted-foreground font-mono">{log.host}</span>}
                          <span className="text-xs">{log.message}</span>
                        </div>
                        {isOpen && (
                          <div className="mt-2 space-y-2">
                            <div className="rounded-md border bg-muted/30 p-3">
                              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Fields</div>
                              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-[11px] font-mono">
                                {Object.entries(log.fields).map(([k, v]) => (
                                  <div key={k} className="flex items-center justify-between gap-2">
                                    <span className="text-muted-foreground">{k}:</span>
                                    <span className="font-medium">{v}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                            {log.traceId && (
                              <Link
                                href={`/traces/${log.traceId}`}
                                className="inline-flex items-center gap-1 text-[11px] text-primary hover:underline"
                              >
                                <ExternalLink className="w-3 h-3" />
                                View trace: <span className="font-mono">{log.traceId}</span>
                              </Link>
                            )}
                            <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
                              <Link href={`/logs/${log.id}`}>View full entry <ExternalLink className="w-3 h-3" /></Link>
                            </Button>
                          </div>
                        )}
                      </div>
                      {log.traceId && !isOpen && (
                        <Link href={`/traces/${log.traceId}`} className="text-[10px] text-primary font-mono shrink-0 mt-0.5 hover:underline">
                          {log.traceId.slice(0, 12)}
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })}
              {filtered.length === 0 && (
                <div className="px-4 py-12 text-center text-sm text-muted-foreground">No logs match current filters</div>
              )}
            </div>
          </ScrollArea>
        </Card>

        {/* Sidebar */}
        <div className="space-y-4">
          <Card className="p-4 space-y-3">
            <SectionHeading title="Saved Queries" description="Reusable log queries" action={<Bookmark className="w-3.5 h-3.5 text-muted-foreground" />} />
            <div className="space-y-1.5">
              {savedQueries.map((q) => (
                <button
                  key={q.name}
                  onClick={() => { setSearch(q.query); addFilter(q.query); }}
                  className="w-full text-left p-2 rounded-md hover:bg-muted/40 transition-colors"
                >
                  <div className="text-xs font-medium">{q.name}</div>
                  <div className="text-[10px] font-mono text-muted-foreground truncate">{q.query}</div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">{q.count.toLocaleString()} matches</div>
                </button>
              ))}
            </div>
          </Card>

          <Card className="p-4 space-y-3">
            <SectionHeading title="Recent Searches" description="Last queries" action={<Clock className="w-3.5 h-3.5 text-muted-foreground" />} />
            <div className="space-y-1">
              {recentSearches.map((s, i) => (
                <button
                  key={i}
                  onClick={() => setSearch(s)}
                  className="w-full text-left p-2 rounded-md hover:bg-muted/40 transition-colors text-[11px] font-mono"
                >
                  <Terminal className="w-3 h-3 inline mr-1.5 text-muted-foreground" />
                  {s}
                </button>
              ))}
            </div>
          </Card>

          <Card className="p-4 space-y-3">
            <SectionHeading title="Level Distribution" description="In current view" />
            <div className="space-y-1.5">
              {(Object.keys(levelConfig) as LogEntry["level"][]).map((lvl) => {
                const count = logs.filter((l) => l.level === lvl).length;
                const pct = Math.round((count / logs.length) * 100);
                const l = levelConfig[lvl];
                return (
                  <div key={lvl} className="flex items-center gap-2">
                    <span className={`inline-flex items-center gap-1 text-[10px] font-medium uppercase w-12 ${l.color}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${l.dot}`} />{lvl}
                    </span>
                    <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                      <div className={l.dot} style={{ width: `${pct}%`, height: "100%" }} />
                    </div>
                    <span className="text-[10px] font-mono tabular-nums w-8 text-right">{count}</span>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
