"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  ScrollText, ExternalLink, ArrowLeft, Copy, Download, AlertTriangle, Info, Bug,
  AlertOctagon, Activity, Tag, Server, Globe, Clock, Hash,
} from "lucide-react";
import { sampleLogs, services } from "@/lib/data";
import type { LogEntry } from "@/lib/types";
import { toast } from "sonner";

const levelConfig: Record<LogEntry["level"], { color: string; bg: string; dot: string; icon: React.ReactNode }> = {
  trace: { color: "text-muted-foreground", bg: "bg-muted/40 border-border", dot: "bg-muted-foreground", icon: <Activity className="w-3 h-3" /> },
  debug: { color: "text-info-foreground", bg: "bg-info/15 border-info/30", dot: "bg-info", icon: <Bug className="w-3 h-3" /> },
  info: { color: "text-primary", bg: "bg-primary/15 border-primary/30", dot: "bg-primary", icon: <Info className="w-3 h-3" /> },
  warn: { color: "text-warning-foreground", bg: "bg-warning/15 border-warning/30", dot: "bg-warning", icon: <AlertTriangle className="w-3 h-3" /> },
  error: { color: "text-destructive", bg: "bg-destructive/15 border-destructive/30", dot: "bg-destructive", icon: <AlertOctagon className="w-3 h-3" /> },
  fatal: { color: "text-destructive", bg: "bg-destructive/25 border-destructive/40", dot: "bg-destructive", icon: <AlertOctagon className="w-3 h-3" /> },
};

export default function LogDetailsPage() {
  const params = useParams();
  const id = params?.id as string | undefined;

  // Generate a stable set of logs and find by id, fallback to first
  const allLogs = React.useMemo(() => sampleLogs(50), []);
  const log = allLogs.find((l) => l.id === id) ?? allLogs[0];
  const svc = services.find((s) => s.id === log.serviceId);
  const lvl = levelConfig[log.level];

  // Related logs (same traceId)
  const relatedLogs = log.traceId ? allLogs.filter((l) => l.traceId === log.traceId && l.id !== log.id).slice(0, 6) : [];

  // Mock a complete log entry with extra fields
  const fullLog: LogEntry & { spanId?: string; extraFields: Record<string, string> } = {
    ...log,
    spanId: log.traceId ? `sp_${Math.random().toString(36).slice(2, 12)}` : undefined,
    extraFields: {
      "request_id": `req_${Math.random().toString(36).slice(2, 14)}`,
      "user_id": `usr_${Math.floor(Math.random() * 99999)}`,
      "duration_ms": String(Math.floor(Math.random() * 500) + 5),
      "status_code": log.level === "error" ? "500" : "200",
      "method": "GET",
      "path": "/api/v1/users/me",
      "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
      "ip": `10.42.18.${Math.floor(Math.random() * 254) + 1}`,
      "version": "v2.4.1",
      "commit_sha": "a1b2c3d4e5f6",
      ...log.fields,
    },
  };

  const rawJson = JSON.stringify(fullLog, null, 2);

  function copyJson() {
    navigator.clipboard.writeText(rawJson);
    toast.success("Log entry copied to clipboard");
  }

  return (
    <PageContainer>
      <PageHeader
        title="Log Entry"
        description={`From ${svc?.name ?? log.serviceId} · ${new Date(log.timestamp).toISOString()}`}
        breadcrumbs={[{ label: "Logs", href: "/logs" }, { label: log.id }]}
        icon={<ScrollText className="w-5 h-5" />}
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/logs"><ArrowLeft className="w-3.5 h-3.5" /><span className="hidden md:inline">Back</span></Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={copyJson}><Copy className="w-3.5 h-3.5" /><span className="hidden md:inline">Copy JSON</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Download</span></Button>
          </>
        }
      />

      {/* Hero */}
      <Card className="p-5">
        <div className="flex items-start gap-3 flex-wrap">
          <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium uppercase tracking-wide border ${lvl.bg}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${lvl.dot}`} />{log.level}
          </span>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium">{log.message}</div>
            <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-3 flex-wrap">
              <span className="inline-flex items-center gap-1"><Tag className="w-3 h-3" /> {svc?.name ?? log.serviceId}</span>
              <span className="inline-flex items-center gap-1"><Server className="w-3 h-3" /> {log.host ?? "—"}</span>
              <span className="inline-flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(log.timestamp).toISOString()}</span>
              {log.traceId && <span className="inline-flex items-center gap-1"><Hash className="w-3 h-3" /> <span className="font-mono">{log.traceId}</span></span>}
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: fields */}
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading title="All Fields" description="Structured fields extracted from this log entry" />
          <div className="rounded-lg border overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-muted/40">
                <tr>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Field</th>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Value</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(fullLog.extraFields).map(([k, v]) => (
                  <tr key={k} className="border-t border-border">
                    <td className="px-3 py-2 font-mono text-muted-foreground">{k}</td>
                    <td className="px-3 py-2 font-mono break-all">{v}</td>
                  </tr>
                ))}
                {log.traceId && (
                  <tr className="border-t border-border">
                    <td className="px-3 py-2 font-mono text-muted-foreground">trace_id</td>
                    <td className="px-3 py-2 font-mono">
                      <Link href={`/traces/${log.traceId}`} className="text-primary hover:underline inline-flex items-center gap-1">
                        {log.traceId} <ExternalLink className="w-3 h-3" />
                      </Link>
                    </td>
                  </tr>
                )}
                {fullLog.spanId && (
                  <tr className="border-t border-border">
                    <td className="px-3 py-2 font-mono text-muted-foreground">span_id</td>
                    <td className="px-3 py-2 font-mono">{fullLog.spanId}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <Separator />

          <SectionHeading title="Raw JSON" description="Complete unstructured log payload" />
          <pre className="rounded-lg border bg-muted/30 p-4 text-[11px] font-mono overflow-x-auto max-h-[320px]">{rawJson}</pre>
        </Card>

        {/* Right: related */}
        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Context" description="Where this log was emitted" />
            <div className="space-y-2 text-xs">
              <ContextRow icon={<Tag className="w-3 h-3" />} label="Service" value={svc?.name ?? log.serviceId} />
              <ContextRow icon={<Globe className="w-3 h-3" />} label="Region" value={svc?.regions[0] ?? "global"} />
              <ContextRow icon={<Server className="w-3 h-3" />} label="Host" value={log.host ?? "—"} mono />
              <ContextRow icon={<Clock className="w-3 h-3" />} label="Timestamp" value={new Date(log.timestamp).toISOString()} mono />
              <ContextRow icon={<Hash className="w-3 h-3" />} label="Log ID" value={log.id} mono />
            </div>
          </Card>

          {log.traceId && (
            <Card className="p-5 space-y-3">
              <SectionHeading title="Related Trace" description="View full distributed trace" />
              <Button asChild variant="default" size="sm" className="w-full gap-1.5">
                <Link href={`/traces/${log.traceId}`}>
                  <ExternalLink className="w-3.5 h-3.5" /> View trace {log.traceId.slice(0, 14)}...
                </Link>
              </Button>
              <p className="text-[11px] text-muted-foreground">See all spans and timing for this request across services.</p>
            </Card>
          )}

          <Card className="p-5 space-y-3">
            <SectionHeading title="Related Logs" description={log.traceId ? `Same trace (${relatedLogs.length})` : "No trace ID linked"} />
            {relatedLogs.length === 0 ? (
              <p className="text-[11px] text-muted-foreground">No other log entries share this trace ID.</p>
            ) : (
              <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                {relatedLogs.map((r) => {
                  const rSvc = services.find((s) => s.id === r.serviceId);
                  const rl = levelConfig[r.level];
                  return (
                    <Link
                      key={r.id}
                      href={`/logs/${r.id}`}
                      className="block p-2 rounded-md border hover:bg-muted/40 transition-colors"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`w-1.5 h-1.5 rounded-full ${rl.dot}`} />
                        <span className="text-[10px] font-mono text-muted-foreground">{new Date(r.timestamp).toISOString().slice(11, 19)}</span>
                        <span className="text-[11px] font-mono text-primary">{rSvc?.name}</span>
                      </div>
                      <div className="text-[11px] truncate">{r.message}</div>
                    </Link>
                  );
                })}
              </div>
            )}
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}

function ContextRow({ icon, label, value, mono }: { icon: React.ReactNode; label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-muted-foreground">{icon}</span>
      <span className="text-muted-foreground">{label}:</span>
      <span className={`ml-auto truncate ${mono ? "font-mono text-[11px]" : ""}`}>{value}</span>
    </div>
  );
}
