"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { DataTable, type Column } from "@/components/tables/data-table";
import { errors, services } from "@/lib/data";
import { toast } from "sonner";
import { Map, Upload, CheckCircle2, AlertTriangle, Clock, FileCode, Download } from "lucide-react";

interface SourceMapRow {
  id: string;
  serviceId: string;
  serviceName: string;
  release: string;
  status: "ok" | "missing" | "stale";
  uploadedAt: string;
  size: number;
  coverage: number;
}

// Generate source maps per service × release
const sourceMaps: SourceMapRow[] = (() => {
  const releases = ["v2.4.1-rc1", "v2.4.0", "v5.1.0", "v4.2.0", "v3.8.2", "v1.18.4"];
  const statuses: SourceMapRow["status"][] = ["ok", "ok", "ok", "ok", "missing", "stale"];
  const out: SourceMapRow[] = [];
  services.filter((s) => s.language === "TypeScript" || s.language === "Java").slice(0, 8).forEach((s, idx) => {
    releases.slice(0, 3).forEach((rel, j) => {
      const statusIdx = (idx + j) % statuses.length;
      out.push({
        id: `${s.id}-${rel}`,
        serviceId: s.id,
        serviceName: s.name,
        release: rel,
        status: statuses[statusIdx],
        uploadedAt: new Date(Date.now() - (idx + j) * 86400000).toISOString(),
        size: Math.round(120 + Math.random() * 480),
        coverage: statuses[statusIdx] === "ok" ? 90 + Math.round(Math.random() * 10) : statuses[statusIdx] === "stale" ? 60 + Math.round(Math.random() * 20) : 0,
      });
    });
  });
  return out;
})();

const statusMap: Record<SourceMapRow["status"], { label: string; cls: string; icon: React.ReactNode }> = {
  ok: { label: "OK", cls: "bg-success/15 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
  missing: { label: "Missing", cls: "bg-destructive/15 text-destructive border-destructive/30", icon: <AlertTriangle className="w-3 h-3" /> },
  stale: { label: "Stale", cls: "bg-warning/15 text-warning-foreground border-warning/30", icon: <Clock className="w-3 h-3" /> },
};

export default function SourceMapsPage() {
  const ok = sourceMaps.filter((s) => s.status === "ok").length;
  const missing = sourceMaps.filter((s) => s.status === "missing").length;
  const stale = sourceMaps.filter((s) => s.status === "stale").length;
  const coverage = Math.round(sourceMaps.reduce((s, x) => s + x.coverage, 0) / sourceMaps.length);

  const columns: Column<SourceMapRow>[] = [
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => r.serviceName,
      cell: (r) => <span className="text-xs font-medium">{r.serviceName}</span>,
    },
    {
      key: "release",
      header: "Release",
      sortable: true,
      sortValue: (r) => r.release,
      hideOnMobile: true,
      cell: (r) => <code className="text-xs font-mono">{r.release}</code>,
    },
    {
      key: "status",
      header: "Status",
      filterable: true,
      filterOptions: [
        { label: "OK", value: "ok" },
        { label: "Missing", value: "missing" },
        { label: "Stale", value: "stale" },
      ],
      filterFn: (r, v) => r.status === v,
      cell: (r) => {
        const s = statusMap[r.status];
        return (
          <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide ${s.cls}`}>
            {s.icon}
            {s.label}
          </span>
        );
      },
    },
    {
      key: "coverage",
      header: "Coverage",
      align: "right",
      sortable: true,
      sortValue: (r) => r.coverage,
      hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-2 justify-end">
          <div className="w-16"><Progress value={r.coverage} className="h-1.5" /></div>
          <span className={`text-xs tabular-nums font-medium w-8 text-right ${r.coverage >= 90 ? "text-success" : r.coverage >= 60 ? "text-warning-foreground" : "text-destructive"}`}>{r.coverage}%</span>
        </div>
      ),
    },
    {
      key: "size",
      header: "Size",
      align: "right",
      sortable: true,
      sortValue: (r) => r.size,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.size} KB</span>,
    },
    {
      key: "uploadedAt",
      header: "Uploaded",
      sortable: true,
      sortValue: (r) => r.uploadedAt,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.status === "missing" ? "—" : new Date(r.uploadedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>,
    },
    {
      key: "upload",
      header: "Action",
      align: "right",
      cell: (r) => (
        <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={(e) => { e.stopPropagation(); toast.success(`Upload form opened for ${r.serviceName} ${r.release}`); }}>
          <Upload className="w-3 h-3" /> Upload
        </Button>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Source Maps Management"
        description="Track source map uploads per service and release. Ensure stack traces are fully symbolicated for production errors."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors", href: "/errors" }, { label: "Source Maps" }]}
        icon={<Map className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Source map inventory exported")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Upload source map dialog opened")}>
              <Upload className="w-3.5 h-3.5" /> Upload Source Map
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Source Maps" value={sourceMaps.length} hint="across services × releases" icon={<FileCode className="w-4 h-4" />} accent="primary" />
        <KpiCard label="OK" value={ok} hint={`${Math.round((ok / sourceMaps.length) * 100)}% symbolicated`} icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Missing" value={missing} hint="needs upload" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Avg Coverage" value={coverage} unit="%" hint="across all maps" icon={<Map className="w-4 h-4" />} accent="info" />
      </div>

      {/* Coverage summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-4">
          <SectionHeading title="Coverage by Status" />
          <div className="mt-3 space-y-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-success" /> OK</span>
                <span className="tabular-nums font-medium">{ok} / {sourceMaps.length}</span>
              </div>
              <Progress value={(ok / sourceMaps.length) * 100} className="h-2" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="inline-flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-warning-foreground" /> Stale</span>
                <span className="tabular-nums font-medium">{stale} / {sourceMaps.length}</span>
              </div>
              <Progress value={(stale / sourceMaps.length) * 100} className="h-2" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="inline-flex items-center gap-1.5"><AlertTriangle className="w-3.5 h-3.5 text-destructive" /> Missing</span>
                <span className="tabular-nums font-medium">{missing} / {sourceMaps.length}</span>
              </div>
              <Progress value={(missing / sourceMaps.length) * 100} className="h-2" />
            </div>
          </div>
        </Card>

        <Card className="p-4 lg:col-span-2">
          <SectionHeading title="Coverage by Service" description="Average source map coverage per service" />
          <div className="mt-3 space-y-2 max-h-[200px] overflow-y-auto pr-2">
            {services.filter((s) => s.language === "TypeScript" || s.language === "Java").slice(0, 6).map((s) => {
              const maps = sourceMaps.filter((m) => m.serviceId === s.id);
              const avg = maps.length > 0 ? Math.round(maps.reduce((sum, m) => sum + m.coverage, 0) / maps.length) : 0;
              return (
                <div key={s.id} className="flex items-center gap-3">
                  <span className="text-xs font-medium w-32 truncate">{s.name}</span>
                  <div className="flex-1"><Progress value={avg} className="h-2" /></div>
                  <span className={`text-xs tabular-nums font-medium w-10 text-right ${avg >= 90 ? "text-success" : avg >= 60 ? "text-warning-foreground" : "text-destructive"}`}>{avg}%</span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading
          title="Source Map Inventory"
          description="Click Upload to attach a new source map for a service + release combination."
          action={<span className="text-[11px] text-muted-foreground">{sourceMaps.length} entries</span>}
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={sourceMaps}
            rowKey={(r) => r.id}
            searchKeys={["serviceName", "release"]}
            searchPlaceholder="Search services or releases..."
            pageSize={10}
            initialSort={{ key: "uploadedAt", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
