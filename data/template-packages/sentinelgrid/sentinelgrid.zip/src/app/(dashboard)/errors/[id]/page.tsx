"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LineChartCard } from "@/components/charts";
import { errors, services, people } from "@/lib/data";
import { toast } from "sonner";
import {
  ArrowLeft, Bug, AlertTriangle, CheckCircle2, EyeOff, UserPlus,
  Link as LinkIcon, Clock, Users, Activity, GitCommit, FileCode, History,
} from "lucide-react";

function statusBadge(status: string) {
  const map: Record<string, { label: string; cls: string }> = {
    unresolved: { label: "Unresolved", cls: "bg-destructive/15 text-destructive border-destructive/30" },
    in_progress: { label: "In Progress", cls: "bg-info/15 text-info-foreground border-info/30" },
    resolved: { label: "Resolved", cls: "bg-success/15 text-success border-success/30" },
    ignored: { label: "Ignored", cls: "bg-muted text-muted-foreground border-border" },
  };
  const c = map[status] || map.unresolved;
  return (
    <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium uppercase tracking-wide ${c.cls}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
      {c.label}
    </span>
  );
}

export default function ErrorDetailsPage() {
  const params = useParams<{ id: string }>();
  const error = errors.find((e) => e.id === params.id) ?? errors[0];
  const svc = services.find((s) => s.id === error.serviceId);
  const assignee = people.find((p) => p.id === error.assigneeId);

  // Build trend from error.trend array
  const trendData = React.useMemo(() => {
    const now = new Date();
    return error.trend.map((v, i) => {
      const d = new Date(now);
      d.setHours(d.getHours() - (error.trend.length - 1 - i));
      return {
        date: d.toISOString().slice(5, 16),
        value: v,
      };
    });
  }, [error]);

  // Mock affected users list
  const affectedUsers = React.useMemo(() => {
    return Array.from({ length: 8 }).map((_, i) => ({
      id: `au-${i}`,
      email: `user${1000 + i}@example.com`,
      events: Math.floor(Math.random() * 18) + 1,
      lastSeen: new Date(Date.now() - Math.floor(Math.random() * 3600000)).toISOString(),
    })).sort((a, b) => b.events - a.events);
  }, []);

  // Mock recent events
  const recentEvents = React.useMemo(() => {
    return Array.from({ length: 6 }).map((_, i) => ({
      id: `ev-${i}`,
      timestamp: new Date(Date.now() - i * 240000).toISOString(),
      browser: ["Chrome 126", "Safari 17", "Firefox 124", "Edge 126"][i % 4],
      os: ["macOS 14", "Windows 11", "iOS 17", "Android 14"][i % 4],
      release: error.releaseId ?? "v2.4.0",
      url: "/checkout/review",
    }));
  }, [error]);

  // Parse stack into frames
  const stackFrames = error.stack.split("\n").filter(Boolean);

  return (
    <PageContainer>
      <PageHeader
        title={error.ref}
        description={error.message}
        breadcrumbs={[
          { label: "Errors", href: "/errors" },
          { label: error.ref },
        ]}
        icon={<Bug className="w-5 h-5" />}
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/errors"><ArrowLeft className="w-3.5 h-3.5" /> Back</Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Linked to JIRA-OPS-4821")}>
              <LinkIcon className="w-3.5 h-3.5" /> Link Jira
            </Button>
          </>
        }
      />

      {/* Hero */}
      <Card className={`p-5 ${error.isRegression ? "border-destructive/30 bg-destructive/5" : "border-border"}`}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              {statusBadge(error.status)}
              <span className="inline-flex items-center rounded-md border border-border bg-muted px-2 py-0.5 text-[11px] font-mono">{error.type}</span>
              {error.isRegression && (
                <span className="inline-flex items-center gap-1 rounded-md border border-destructive/30 bg-destructive/15 px-2 py-0.5 text-[11px] font-medium text-destructive">
                  <AlertTriangle className="w-3 h-3" /> Regression
                </span>
              )}
              <span className="inline-flex items-center rounded-md border border-border px-2 py-0.5 text-[11px] text-muted-foreground">{error.environment}</span>
            </div>
            <div>
              <p className="text-sm font-mono leading-relaxed break-all">{error.message}</p>
            </div>
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><FileCode className="w-3.5 h-3.5" /> Service: <span className="text-foreground font-medium">{svc?.name ?? error.serviceId}</span></span>
              <span className="inline-flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> First seen: <span className="text-foreground font-medium">{new Date(error.firstSeen).toLocaleString()}</span></span>
              <span className="inline-flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> Last seen: <span className="text-foreground font-medium">{new Date(error.lastSeen).toLocaleString()}</span></span>
              <span className="inline-flex items-center gap-1.5"><Activity className="w-3.5 h-3.5" /> Events: <span className="text-foreground font-medium">{error.eventCount.toLocaleString()}</span></span>
              <span className="inline-flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> Users: <span className="text-foreground font-medium">{error.userCount.toLocaleString()}</span></span>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {error.tags.map((t) => (
                <span key={t} className="inline-flex items-center rounded-md border border-border bg-muted px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground">#{t}</span>
              ))}
            </div>
          </div>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Assignee</div>
              {assignee ? (
                <div className="flex items-center gap-2">
                  <Avatar className="w-7 h-7">
                    <AvatarImage src={assignee.avatarUrl} alt={assignee.name} />
                    <AvatarFallback>{assignee.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="text-xs font-medium">{assignee.name}</div>
                    <div className="text-[10px] text-muted-foreground">{assignee.role}</div>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-muted-foreground">Unassigned</div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button size="sm" variant="default" className="h-8 text-xs gap-1.5" onClick={() => toast.success(`Error ${error.ref} marked resolved`)}>
                <CheckCircle2 className="w-3.5 h-3.5" /> Resolve
              </Button>
              <Button size="sm" variant="outline" className="h-8 text-xs gap-1.5" onClick={() => toast.success(`Error ${error.ref} ignored`)}>
                <EyeOff className="w-3.5 h-3.5" /> Ignore
              </Button>
              <Button size="sm" variant="outline" className="h-8 text-xs gap-1.5" onClick={() => toast.success("Opening assign dialog")}>
                <UserPlus className="w-3.5 h-3.5" /> Assign
              </Button>
              <Button size="sm" variant="outline" className="h-8 text-xs gap-1.5" onClick={() => toast.success("Linked to JIRA-OPS-4821")}>
                <LinkIcon className="w-3.5 h-3.5" /> Jira
              </Button>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Stack trace */}
        <Card className="lg:col-span-2 p-4">
          <SectionHeading title="Stack Trace" description="Raw stack frames with file/line attribution" action={<span className="text-[11px] text-muted-foreground">source map: {error.sourceMapStatus}</span>} />
          <div className="mt-4 rounded-md bg-muted/60 border border-border overflow-hidden">
            <div className="px-3 py-2 border-b border-border bg-muted/80 flex items-center justify-between">
              <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                <FileCode className="w-3.5 h-3.5" />
                <code className="font-mono">{error.type}</code>
              </div>
              <span className="text-[10px] text-muted-foreground">{stackFrames.length} frames</span>
            </div>
            <div className="overflow-x-auto">
              <pre className="text-[11px] font-mono leading-relaxed p-3 text-muted-foreground">
                {stackFrames.map((frame, i) => (
                  <div key={i} className="flex gap-3 hover:bg-muted/40 px-1 -mx-1 rounded">
                    <span className="text-muted-foreground/60 select-none w-6 text-right">{i + 1}</span>
                    <span className="text-foreground">{frame}</span>
                  </div>
                ))}
              </pre>
            </div>
          </div>
        </Card>

        {/* Release info */}
        <Card className="p-4 flex flex-col gap-4">
          <SectionHeading title="Release Attribution" description="When this error first appeared" />
          <div className="space-y-3 flex-1">
            <div className="rounded-md border border-border p-3 space-y-1.5">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">First seen release</div>
              <div className="flex items-center gap-2">
                <GitCommit className="w-3.5 h-3.5 text-primary" />
                <code className="text-xs font-mono font-medium">{error.releaseId ?? "v2.3.8"}</code>
              </div>
              <div className="text-[10px] text-muted-foreground">{new Date(error.firstSeen).toLocaleString()}</div>
            </div>
            <div className="rounded-md border border-border p-3 space-y-1.5">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Last seen release</div>
              <div className="flex items-center gap-2">
                <GitCommit className="w-3.5 h-3.5 text-primary" />
                <code className="text-xs font-mono font-medium">{error.releaseId ?? "v2.4.1-rc1"}</code>
              </div>
              <div className="text-[10px] text-muted-foreground">{new Date(error.lastSeen).toLocaleString()}</div>
            </div>
            {error.isRegression && (
              <div className="rounded-md border border-destructive/30 bg-destructive/10 p-3 space-y-1">
                <div className="flex items-center gap-1.5 text-destructive text-xs font-medium">
                  <AlertTriangle className="w-3.5 h-3.5" /> Regression detected
                </div>
                <p className="text-[11px] text-muted-foreground">
                  This error was previously resolved and re-appeared in release <code className="font-mono">{error.releaseId ?? "v2.4.1-rc1"}</code>.
                </p>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Event frequency + affected users */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 h-[300px]">
          <SectionHeading title="Event Frequency" description="Events per hour over the last 14 hours" />
          <div className="h-[220px] mt-2">
            <LineChartCard data={trendData} suffix=" events" />
          </div>
        </Card>
        <Card className="p-4 h-[300px] flex flex-col">
          <SectionHeading title="Top Affected Users" description={`${error.userCount.toLocaleString()} total`} />
          <div className="mt-3 flex-1 overflow-y-auto max-h-[220px] space-y-1.5 pr-2">
            {affectedUsers.map((u) => (
              <div key={u.id} className="flex items-center justify-between gap-2 text-xs py-1 border-b border-border/50 last:border-0">
                <code className="font-mono text-muted-foreground truncate">{u.email}</code>
                <div className="text-right shrink-0">
                  <div className="font-medium tabular-nums">{u.events}x</div>
                  <div className="text-[10px] text-muted-foreground">{new Date(u.lastSeen).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent events */}
      <Card className="p-4 md:p-5">
        <SectionHeading title="Recent Events" description="Last 6 raw event occurrences with environment metadata" action={<History className="w-3.5 h-3.5 text-muted-foreground" />} />
        <div className="mt-4 rounded-md border border-border overflow-hidden">
          <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-muted/40 border-b border-border text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
            <div className="col-span-3">Timestamp</div>
            <div className="col-span-3">Browser</div>
            <div className="col-span-2">OS</div>
            <div className="col-span-2">Release</div>
            <div className="col-span-2">URL</div>
          </div>
          <div className="divide-y divide-border">
            {recentEvents.map((ev) => (
              <div key={ev.id} className="grid grid-cols-12 gap-2 px-3 py-2 text-[11px] hover:bg-muted/30">
                <div className="col-span-3 tabular-nums text-muted-foreground">{new Date(ev.timestamp).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" })}</div>
                <div className="col-span-3">{ev.browser}</div>
                <div className="col-span-2">{ev.os}</div>
                <div className="col-span-2"><code className="font-mono text-muted-foreground">{ev.release}</code></div>
                <div className="col-span-2"><code className="font-mono text-muted-foreground truncate">{ev.url}</code></div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
