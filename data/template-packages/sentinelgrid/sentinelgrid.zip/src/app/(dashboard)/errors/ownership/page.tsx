"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DataTable, type Column } from "@/components/tables/data-table";
import { errors, services, people, teams } from "@/lib/data";
import type { ErrorGroup } from "@/lib/types";
import { toast } from "sonner";
import { Users, UserPlus, AlertTriangle, CheckCircle2, Layers, Download } from "lucide-react";

interface OwnerRow {
  owner?: typeof people[number];
  team?: typeof teams[number];
  errors: ErrorGroup[];
  unassigned: boolean;
}

const owners: OwnerRow[] = (() => {
  const map: Record<string, ErrorGroup[]> = {};
  errors.forEach((e) => {
    const key = e.assigneeId ?? "unassigned";
    if (!map[key]) map[key] = [];
    map[key].push(e);
  });
  return Object.entries(map).map(([key, errs]) => {
    if (key === "unassigned") {
      return { errors: errs, unassigned: true };
    }
    const owner = people.find((p) => p.id === key);
    const team = owner ? teams.find((t) => t.name === owner.team || t.slug === owner.team) : undefined;
    return { owner, team, errors: errs, unassigned: false };
  }).sort((a, b) => b.errors.length - a.errors.length);
})();

const unassigned = errors.filter((e) => !e.assigneeId);

// Assignment matrix: team x errors count
const matrix: { team: typeof teams[number]; count: number; services: Set<string> }[] = teams.map((t) => {
  const teamErrors = errors.filter((e) => {
    const owner = people.find((p) => p.id === e.assigneeId);
    return owner?.team === t.name;
  });
  return {
    team: t,
    count: teamErrors.length,
    services: new Set(teamErrors.map((e) => e.serviceId)),
  };
}).sort((a, b) => b.count - a.count);

export default function ErrorOwnershipPage() {
  const router = useRouter();

  const columns: Column<ErrorGroup>[] = [
    {
      key: "ref",
      header: "Ref",
      cell: (r) => <code className="text-xs font-mono text-muted-foreground">{r.ref}</code>,
    },
    {
      key: "message",
      header: "Error",
      sortable: true,
      sortValue: (r) => r.message,
      cell: (r) => (
        <div className="min-w-0 max-w-md">
          <p className="text-xs font-medium truncate">{r.message}</p>
          <p className="text-[10px] text-muted-foreground">{services.find((s) => s.id === r.serviceId)?.name ?? r.serviceId}</p>
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      hideOnMobile: true,
      cell: (r) => {
        const map: Record<string, string> = { unresolved: "text-destructive", in_progress: "text-info-foreground", resolved: "text-success", ignored: "text-muted-foreground" };
        return <span className={`text-[11px] font-medium ${map[r.status]}`}>{r.status.replace("_", " ")}</span>;
      },
    },
    {
      key: "eventCount",
      header: "Events",
      align: "right",
      sortable: true,
      sortValue: (r) => r.eventCount,
      cell: (r) => <span className="text-xs tabular-nums font-medium">{r.eventCount.toLocaleString()}</span>,
    },
    {
      key: "assign",
      header: "Action",
      align: "right",
      cell: (r) => (
        <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={(e) => { e.stopPropagation(); toast.success(`Assignment dialog opened for ${r.ref}`); }}>
          <UserPlus className="w-3 h-3" /> Assign
        </Button>
      ),
    },
  ];

  const totalAssigned = errors.length - unassigned.length;

  return (
    <PageContainer>
      <PageHeader
        title="Error Ownership"
        description="Triage queue by owner and team. Quickly assign unassigned errors and visualize the load distribution."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors", href: "/errors" }, { label: "Ownership" }]}
        icon={<Users className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Bulk assign dialog opened")}>
              <Layers className="w-3.5 h-3.5" /> <span className="hidden md:inline">Bulk Assign</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Ownership report exported")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Assigned" value={totalAssigned} hint={`${Math.round((totalAssigned / errors.length) * 100)}% of errors`} icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Unassigned" value={unassigned.length} hint="awaiting triage" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Owners" value={owners.filter((o) => !o.unassigned).length} hint="with active assignments" icon={<Users className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Teams" value={matrix.filter((m) => m.count > 0).length} hint="owning errors" icon={<Layers className="w-4 h-4" />} accent="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* By owner */}
        <Card className="lg:col-span-2 p-4">
          <SectionHeading title="By Owner" description="Errors assigned to each engineer, sorted by load" />
          <div className="mt-3 space-y-2 max-h-[420px] overflow-y-auto pr-2">
            {owners.map((o, i) => (
              <div key={i} className="rounded-md border border-border p-3 hover:bg-muted/40 transition-colors">
                <div className="flex items-center gap-3">
                  {o.unassigned ? (
                    <div className="w-8 h-8 rounded-full bg-destructive/15 border border-destructive/30 flex items-center justify-center">
                      <AlertTriangle className="w-3.5 h-3.5 text-destructive" />
                    </div>
                  ) : o.owner ? (
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={o.owner.avatarUrl} alt={o.owner.name} />
                      <AvatarFallback>{o.owner.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                  ) : null}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-medium">{o.unassigned ? "Unassigned" : o.owner?.name ?? "Unknown"}</span>
                      <span className="text-xs tabular-nums font-medium">{o.errors.length}</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground truncate">
                      {o.unassigned ? "Needs triage" : `${o.owner?.role ?? ""} · ${o.team?.name ?? ""}`}
                    </div>
                  </div>
                </div>
                {/* Error list preview */}
                <div className="mt-2 pl-11 space-y-1">
                  {o.errors.slice(0, 3).map((e) => (
                    <button
                      key={e.id}
                      onClick={() => router.push(`/errors/${e.id}`)}
                      className="block w-full text-left text-[11px] hover:text-primary truncate"
                    >
                      <code className="font-mono text-muted-foreground">{e.ref}</code> {e.message}
                    </button>
                  ))}
                  {o.errors.length > 3 && <span className="text-[10px] text-muted-foreground">+{o.errors.length - 3} more</span>}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Assignment matrix */}
        <Card className="p-4">
          <SectionHeading title="Assignment Matrix" description="Error load by team" />
          <div className="mt-3 space-y-2 max-h-[420px] overflow-y-auto pr-2">
            {matrix.map((m) => (
              <div key={m.team.id} className="rounded-md border border-border p-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: m.team.color }} />
                  <span className="text-xs font-medium flex-1">{m.team.name}</span>
                  <span className="text-xs tabular-nums font-medium">{m.count}</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${Math.min(100, (m.count / Math.max(...matrix.map((x) => x.count), 1)) * 100)}%`, background: m.team.color }} />
                </div>
                <div className="mt-1.5 text-[10px] text-muted-foreground">
                  {m.services.size} service{m.services.size !== 1 ? "s" : ""} affected
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Unassigned list */}
      <Card className="p-4 md:p-5 border-destructive/20">
        <SectionHeading
          title="Unassigned Errors"
          description="Triage queue — assign these to the right owner."
          action={<span className="text-[11px] text-destructive">{unassigned.length} pending</span>}
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={unassigned}
            rowKey={(r) => r.id}
            searchKeys={["ref", "message", "type"]}
            searchPlaceholder="Search unassigned errors..."
            pageSize={6}
            initialSort={{ key: "eventCount", dir: "desc" }}
            onRowClick={(r) => router.push(`/errors/${r.id}`)}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
