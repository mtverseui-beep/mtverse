"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LineChartCard, HorizontalBarChart } from "@/components/charts";
import { errors, services, timeSeries } from "@/lib/data";
import type { ErrorGroup } from "@/lib/types";
import { toast } from "sonner";
import { GitCommit, AlertTriangle, Activity, TrendingUp, Download, RotateCcw } from "lucide-react";

interface RegressionRow extends ErrorGroup {
  release: string;
}

const regressions = errors.filter((e) => e.isRegression);

const regressionRows: RegressionRow[] = regressions.map((e) => ({
  ...e,
  release: e.releaseId ?? "v2.4.1-rc1",
}));

const releaseData = [
  { name: "v2.4.1-rc1", value: 428 },
  { name: "v2.4.0", value: 12 },
  { name: "v4.2.0", value: 12 },
  { name: "v5.1.0", value: 0 },
  { name: "v3.8.2", value: 0 },
];

export default function RegressionsPage() {
  const router = useRouter();
  const totalEvents = regressionRows.reduce((s, e) => s + e.eventCount, 0);

  const [regTrend] = React.useState(() => timeSeries(41, 30, 8, 4).map((d) => ({
    date: d.date,
    value: Math.round(d.value),
  })));

  const columns: Column<RegressionRow>[] = [
    {
      key: "ref",
      header: "Ref",
      cell: (r) => <code className="text-xs font-mono text-muted-foreground">{r.ref}</code>,
    },
    {
      key: "message",
      header: "Error",
      sortable: true,
      sortValue: (r) => r.message,
      cell: (r) => (
        <div className="min-w-0 max-w-md">
          <p className="text-xs font-medium truncate">{r.message}</p>
          <p className="text-[10px] text-muted-foreground">{services.find((s) => s.id === r.serviceId)?.name ?? r.serviceId} · {r.type}</p>
        </div>
      ),
    },
    {
      key: "release",
      header: "Release",
      sortable: true,
      sortValue: (r) => r.release,
      hideOnMobile: true,
      cell: (r) => (
        <span className="inline-flex items-center gap-1.5 text-xs">
          <GitCommit className="w-3 h-3 text-muted-foreground" />
          <code className="font-mono">{r.release}</code>
        </span>
      ),
    },
    {
      key: "firstSeen",
      header: "First Seen",
      sortable: true,
      sortValue: (r) => r.firstSeen,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{new Date(r.firstSeen).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>,
    },
    {
      key: "eventCount",
      header: "Events",
      align: "right",
      sortable: true,
      sortValue: (r) => r.eventCount,
      cell: (r) => <span className="text-xs tabular-nums font-medium text-destructive">{r.eventCount.toLocaleString()}</span>,
    },
    {
      key: "userCount",
      header: "Users",
      align: "right",
      sortable: true,
      sortValue: (r) => r.userCount,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.userCount.toLocaleString()}</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Release Regression Errors"
        description="Errors flagged as regressions — previously resolved issues that re-appeared in a newer release."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors", href: "/errors" }, { label: "Regressions" }]}
        icon={<GitCommit className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Rollback wizard started")}>
              <RotateCcw className="w-3.5 h-3.5" /> <span className="hidden md:inline">Rollback</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Regression report exported")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Regression Errors" value={regressionRows.length} hint="currently open" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Total Events" value={totalEvents.toLocaleString()} hint="last 24h" icon={<Activity className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Affected Releases" value={new Set(regressionRows.map((r) => r.release)).size} hint="with regressions" icon={<GitCommit className="w-4 h-4" />} accent="info" />
        <KpiCard label="Regression Rate" value="3.2" unit="%" delta={1.4} deltaLabel="vs prev week" icon={<TrendingUp className="w-4 h-4" />} accent="destructive" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 h-[320px]">
          <SectionHeading title="Regression Rate Trend" description="New regression errors per day, 30-day window" />
          <div className="h-[240px] mt-2">
            <LineChartCard data={regTrend} />
          </div>
        </Card>
        <Card className="p-4 h-[320px]">
          <SectionHeading title="Top Regressing Releases" description="Events attributed by release version" />
          <div className="h-[240px] mt-2">
            <HorizontalBarChart data={releaseData} color={4} />
          </div>
        </Card>
      </div>

      <Card className="p-4 md:p-5 border-destructive/20">
        <SectionHeading
          title="Regression Inbox"
          description="Click any row to inspect the stack trace and release attribution."
          action={<span className="text-[11px] text-destructive">{regressionRows.length} flagged</span>}
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={regressionRows}
            rowKey={(r) => r.id}
            searchKeys={["ref", "message", "type"]}
            searchPlaceholder="Search regressions..."
            pageSize={8}
            initialSort={{ key: "eventCount", dir: "desc" }}
            onRowClick={(r) => router.push(`/errors/${r.id}`)}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
