"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { errors, services } from "@/lib/data";
import type { ErrorGroup } from "@/lib/types";
import { toast } from "sonner";
import { Layers, Bug, Activity, ChevronDown, ChevronRight, Download } from "lucide-react";

interface Group {
  type: string;
  message: string;
  errors: ErrorGroup[];
}

const groups: Group[] = Object.values(
  errors.reduce<Record<string, Group>>((acc, e) => {
    const key = `${e.type}::${e.message.split(":")[0]}`;
    if (!acc[key]) acc[key] = { type: e.type, message: e.message.split(":")[0], errors: [] };
    acc[key].errors.push(e);
    return acc;
  }, {})
);

export default function ExceptionGroupsPage() {
  const router = useRouter();
  const [expanded, setExpanded] = React.useState<Set<string>>(new Set());

  function toggle(type: string) {
    setExpanded((s) => {
      const n = new Set(s);
      if (n.has(type)) n.delete(type); else n.add(type);
      return n;
    });
  }

  const totalEvents = errors.reduce((s, e) => s + e.eventCount, 0);
  const totalUsers = errors.reduce((s, e) => s + e.userCount, 0);

  const columns: Column<Group>[] = [
    {
      key: "expand",
      header: "",
      width: "40px",
      cell: (r) => (
        <button
          onClick={(e) => { e.stopPropagation(); toggle(r.type); }}
          className="text-muted-foreground hover:text-foreground"
          aria-label={expanded.has(r.type) ? "Collapse" : "Expand"}
        >
          {expanded.has(r.type) ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
        </button>
      ),
    },
    {
      key: "type",
      header: "Type",
      sortable: true,
      sortValue: (r) => r.type,
      cell: (r) => (
        <div className="min-w-0">
          <code className="text-xs font-mono font-medium">{r.type}</code>
          <p className="text-[10px] text-muted-foreground truncate max-w-md">{r.message}</p>
        </div>
      ),
    },
    {
      key: "count",
      header: "Errors",
      align: "right",
      sortable: true,
      sortValue: (r) => r.errors.length,
      cell: (r) => <span className="text-xs tabular-nums font-medium">{r.errors.length}</span>,
    },
    {
      key: "events",
      header: "Events",
      align: "right",
      sortable: true,
      sortValue: (r) => r.errors.reduce((s, e) => s + e.eventCount, 0),
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.errors.reduce((s, e) => s + e.eventCount, 0).toLocaleString()}</span>,
    },
    {
      key: "services",
      header: "Services",
      hideOnMobile: true,
      cell: (r) => {
        const svcs = Array.from(new Set(r.errors.map((e) => services.find((s) => s.id === e.serviceId)?.name ?? e.serviceId)));
        return (
          <div className="flex flex-wrap gap-1">
            {svcs.slice(0, 2).map((s) => (
              <span key={s} className="text-[10px] rounded border border-border bg-muted px-1.5 py-0.5 text-muted-foreground">{s}</span>
            ))}
            {svcs.length > 2 && <span className="text-[10px] text-muted-foreground">+{svcs.length - 2}</span>}
          </div>
        );
      },
    },
    {
      key: "lastSeen",
      header: "Last Seen",
      align: "right",
      sortable: true,
      sortValue: (r) => Math.max(...r.errors.map((e) => +new Date(e.lastSeen))),
      cell: (r) => {
        const last = new Date(Math.max(...r.errors.map((e) => +new Date(e.lastSeen))));
        return <span className="text-xs tabular-nums text-muted-foreground">{last.toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>;
      },
    },
    {
      key: "trend",
      header: "Trend",
      align: "right",
      hideOnMobile: true,
      cell: (r) => {
        // sum across errors per trend index
        const len = Math.max(...r.errors.map((e) => e.trend.length));
        const summed = Array.from({ length: len }).map((_, i) => r.errors.reduce((s, e) => s + (e.trend[i] ?? 0), 0));
        const max = Math.max(...summed, 1);
        return (
          <div className="flex items-end gap-0.5 h-6">
            {summed.map((v, i) => (
              <div key={i} className="w-1 bg-primary/70 rounded-t" style={{ height: `${Math.max(2, (v / max) * 100)}%` }} />
            ))}
          </div>
        );
      },
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Exception Groups"
        description="Errors grouped by type and root message — collapses duplicates and noisy variants into a single inbox item."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors", href: "/errors" }, { label: "Groups" }]}
        icon={<Layers className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Grouping rules exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Exception Groups" value={groups.length} hint={`from ${errors.length} raw errors`} icon={<Layers className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Total Errors" value={errors.length} hint="across all groups" icon={<Bug className="w-4 h-4" />} accent="info" />
        <KpiCard label="Total Events" value={totalEvents.toLocaleString()} hint="last 24h" icon={<Activity className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Affected Users" value={totalUsers.toLocaleString()} hint="across all groups" icon={<Activity className="w-4 h-4" />} accent="destructive" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading
          title="Exception Groups"
          description="Click a row to expand individual errors within the group. Click an inner error to open details."
          action={<span className="text-[11px] text-muted-foreground">Click expand to inspect</span>}
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={groups}
            rowKey={(r) => r.type}
            pageSize={10}
            initialSort={{ key: "events", dir: "desc" }}
            onRowClick={(r) => toggle(r.type)}
            mobileCard={(r) => (
              <Card className="p-3">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <code className="text-xs font-mono font-medium">{r.type}</code>
                  <button onClick={() => toggle(r.type)} className="text-muted-foreground">
                    {expanded.has(r.type) ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-[10px] text-muted-foreground truncate mb-2">{r.message}</p>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div><p className="text-muted-foreground">Errors</p><p className="font-medium tabular-nums">{r.errors.length}</p></div>
                  <div><p className="text-muted-foreground">Events</p><p className="font-medium tabular-nums">{r.errors.reduce((s, e) => s + e.eventCount, 0).toLocaleString()}</p></div>
                </div>
              </Card>
            )}
          />
        </div>
      </Card>

      {/* Expanded group details */}
      {Array.from(expanded).map((type) => {
        const g = groups.find((x) => x.type === type);
        if (!g) return null;
        return (
          <Card key={type} className="p-4 border-primary/20 bg-primary/5">
            <SectionHeading
              title={`Expanded: ${type}`}
              description={`${g.errors.length} errors in this group`}
              action={
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setExpanded((s) => { const n = new Set(s); n.delete(type); return n; })}>
                  Collapse
                </Button>
              }
            />
            <div className="mt-3 space-y-2">
              {g.errors.map((e) => (
                <button
                  key={e.id}
                  onClick={() => router.push(`/errors/${e.id}`)}
                  className="w-full text-left rounded-md border border-border bg-card p-3 hover:bg-muted/40 transition-colors"
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <code className="text-[10px] font-mono text-muted-foreground">{e.ref}</code>
                    <span className="text-[10px] text-muted-foreground">{new Date(e.lastSeen).toLocaleString()}</span>
                  </div>
                  <p className="text-xs font-medium truncate">{e.message}</p>
                  <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground">
                    <span>{services.find((s) => s.id === e.serviceId)?.name ?? e.serviceId}</span>
                    <span className="tabular-nums">{e.eventCount.toLocaleString()} events</span>
                    <span className="tabular-nums">{e.userCount.toLocaleString()} users</span>
                    {e.isRegression && <span className="text-destructive">regression</span>}
                  </div>
                </button>
              ))}
            </div>
          </Card>
        );
      })}
    </PageContainer>
  );
}
