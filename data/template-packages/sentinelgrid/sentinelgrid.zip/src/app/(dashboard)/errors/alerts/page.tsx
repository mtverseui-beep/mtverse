"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { DataTable, type Column } from "@/components/tables/data-table";
import { SeverityBadge, StatusDot } from "@/components/common/badges";
import { errors, services } from "@/lib/data";
import { toast } from "sonner";
import { Bell, Plus, BellRing, Activity, Mail, Slack, MessageSquare, Pencil, Download } from "lucide-react";

interface AlertRule {
  id: string;
  name: string;
  condition: string;
  threshold: string;
  channel: "slack" | "email" | "pagerduty" | "webhook";
  severity: "critical" | "high" | "medium" | "low";
  enabled: boolean;
  triggered24h: number;
  lastTriggered?: string;
}

const initialRules: AlertRule[] = [
  { id: "ar1", name: "Checkout 5xx spike", condition: "service = checkout-api AND type = 5xx_rate", threshold: "> 1% over 5m", channel: "pagerduty", severity: "critical", enabled: true, triggered24h: 2, lastTriggered: "2026-07-02T05:14:00Z" },
  { id: "ar2", name: "OOM regression alert", condition: "type = OutOfMemoryError AND isRegression = true", threshold: "≥ 1 event in 10m", channel: "pagerduty", severity: "critical", enabled: true, triggered24h: 1, lastTriggered: "2026-07-02T05:40:00Z" },
  { id: "ar3", name: "Auth token errors", condition: "service = auth-service AND status = 401", threshold: "> 100 events in 5m", channel: "slack", severity: "medium", enabled: true, triggered24h: 8, lastTriggered: "2026-07-02T05:48:00Z" },
  { id: "ar4", name: "Validation noise digest", condition: "type = ValidationError", threshold: "> 1000 events in 1h", channel: "slack", severity: "low", enabled: true, triggered24h: 3, lastTriggered: "2026-07-02T05:45:00Z" },
  { id: "ar5", name: "DB query timeout", condition: "type = QueryTimeoutError", threshold: "> 10 events in 5m", channel: "email", severity: "high", enabled: true, triggered24h: 4, lastTriggered: "2026-07-02T01:30:00Z" },
  { id: "ar6", name: "Redis connection loss", condition: "type = ConnectionTimeoutError AND service = redis-cluster", threshold: "≥ 1 event", channel: "pagerduty", severity: "high", enabled: true, triggered24h: 1, lastTriggered: "2026-07-01T22:30:00Z" },
  { id: "ar7", name: "Web app JS error surge", condition: "service = web-app AND type = ClientError", threshold: "> 50 events in 5m", channel: "slack", severity: "medium", enabled: false, triggered24h: 0 },
  { id: "ar8", name: "New error type detected", condition: "type = new", threshold: "first occurrence", channel: "email", severity: "low", enabled: true, triggered24h: 5, lastTriggered: "2026-07-02T03:18:00Z" },
];

const channelIcons: Record<AlertRule["channel"], React.ReactNode> = {
  slack: <Slack className="w-3 h-3" />,
  email: <Mail className="w-3 h-3" />,
  pagerduty: <BellRing className="w-3 h-3" />,
  webhook: <MessageSquare className="w-3 h-3" />,
};

interface AlertHistoryRow {
  id: string;
  timestamp: string;
  rule: string;
  severity: "critical" | "high" | "medium" | "low";
  channel: AlertRule["channel"];
  delivery: "delivered" | "failed" | "suppressed";
  errorRef?: string;
}

const history: AlertHistoryRow[] = [
  { id: "h1", timestamp: "2026-07-02T05:48:00Z", rule: "Auth token errors", severity: "medium", channel: "slack", delivery: "delivered" },
  { id: "h2", timestamp: "2026-07-02T05:45:00Z", rule: "Validation noise digest", severity: "low", channel: "slack", delivery: "delivered" },
  { id: "h3", timestamp: "2026-07-02T05:40:00Z", rule: "OOM regression alert", severity: "critical", channel: "pagerduty", delivery: "delivered", errorRef: "ERR-4818" },
  { id: "h4", timestamp: "2026-07-02T05:14:00Z", rule: "Checkout 5xx spike", severity: "critical", channel: "pagerduty", delivery: "delivered", errorRef: "ERR-4821" },
  { id: "h5", timestamp: "2026-07-02T03:18:00Z", rule: "New error type detected", severity: "low", channel: "email", delivery: "delivered" },
  { id: "h6", timestamp: "2026-07-02T01:30:00Z", rule: "DB query timeout", severity: "high", channel: "email", delivery: "delivered", errorRef: "ERR-4817" },
  { id: "h7", timestamp: "2026-07-01T22:30:00Z", rule: "Redis connection loss", severity: "high", channel: "pagerduty", delivery: "delivered", errorRef: "ERR-4820" },
  { id: "h8", timestamp: "2026-07-01T19:12:00Z", rule: "Web app JS error surge", severity: "medium", channel: "slack", delivery: "suppressed" },
  { id: "h9", timestamp: "2026-07-01T14:42:00Z", rule: "Validation noise digest", severity: "low", channel: "slack", delivery: "delivered" },
  { id: "h10", timestamp: "2026-07-01T09:18:00Z", rule: "Auth token errors", severity: "medium", channel: "slack", delivery: "failed" },
];

export default function ErrorAlertsPage() {
  const [rules, setRules] = React.useState(initialRules);

  function toggle(id: string) {
    setRules((r) => r.map((x) => x.id === id ? { ...x, enabled: !x.enabled } : x));
    const r = rules.find((x) => x.id === id);
    toast.success(`${r?.name} ${r?.enabled ? "disabled" : "enabled"}`);
  }

  const enabled = rules.filter((r) => r.enabled).length;
  const totalTriggers = rules.reduce((s, r) => s + r.triggered24h, 0);
  const criticalRules = rules.filter((r) => r.severity === "critical").length;

  const ruleCols: Column<AlertRule>[] = [
    {
      key: "name",
      header: "Rule",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="min-w-0 max-w-xs">
          <p className="text-xs font-medium truncate">{r.name}</p>
          <p className="text-[10px] text-muted-foreground truncate font-mono">{r.condition}</p>
        </div>
      ),
    },
    {
      key: "severity",
      header: "Severity",
      filterable: true,
      filterOptions: [
        { label: "Critical", value: "critical" },
        { label: "High", value: "high" },
        { label: "Medium", value: "medium" },
        { label: "Low", value: "low" },
      ],
      filterFn: (r, v) => r.severity === v,
      hideOnMobile: true,
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "threshold",
      header: "Threshold",
      hideOnMobile: true,
      cell: (r) => <code className="text-[11px] font-mono text-muted-foreground">{r.threshold}</code>,
    },
    {
      key: "channel",
      header: "Channel",
      hideOnMobile: true,
      cell: (r) => (
        <span className="inline-flex items-center gap-1.5 text-xs capitalize">
          {channelIcons[r.channel]}
          {r.channel}
        </span>
      ),
    },
    {
      key: "triggered24h",
      header: "Triggered (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.triggered24h,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.triggered24h > 0 ? "text-warning-foreground" : "text-muted-foreground"}`}>{r.triggered24h}</span>,
    },
    {
      key: "lastTriggered",
      header: "Last Triggered",
      align: "right",
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.lastTriggered ? new Date(r.lastTriggered).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—"}</span>,
    },
    {
      key: "enabled",
      header: "Enabled",
      align: "center",
      cell: (r) => <Switch checked={r.enabled} onCheckedChange={() => toggle(r.id)} aria-label="Toggle alert" />,
    },
    {
      key: "edit",
      header: "",
      align: "right",
      cell: (r) => (
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); toast.success(`Editing alert rule: ${r.name}`); }}>
          <Pencil className="w-3 h-3" />
        </Button>
      ),
    },
  ];

  const histCols: Column<AlertHistoryRow>[] = [
    {
      key: "timestamp",
      header: "Timestamp",
      sortable: true,
      sortValue: (r) => r.timestamp,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{new Date(r.timestamp).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" })}</span>,
    },
    {
      key: "rule",
      header: "Rule",
      cell: (r) => <span className="text-xs font-medium">{r.rule}</span>,
    },
    {
      key: "severity",
      header: "Severity",
      hideOnMobile: true,
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "channel",
      header: "Channel",
      hideOnMobile: true,
      cell: (r) => (
        <span className="inline-flex items-center gap-1.5 text-xs capitalize">
          {channelIcons[r.channel]}
          {r.channel}
        </span>
      ),
    },
    {
      key: "delivery",
      header: "Delivery",
      align: "right",
      cell: (r) => {
        const map: Record<string, { color: "success" | "destructive" | "muted"; label: string }> = {
          delivered: { color: "success", label: "Delivered" },
          failed: { color: "destructive", label: "Failed" },
          suppressed: { color: "muted", label: "Suppressed" },
        };
        const c = map[r.delivery];
        return (
          <span className="inline-flex items-center gap-1.5 text-xs">
            <StatusDot color={c.color} size="sm" />
            {c.label}
          </span>
        );
      },
    },
    {
      key: "errorRef",
      header: "Error Ref",
      align: "right",
      hideOnMobile: true,
      cell: (r) => r.errorRef ? <code className="text-xs font-mono text-muted-foreground">{r.errorRef}</code> : <span className="text-xs text-muted-foreground">—</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Error Alerts"
        description="Alert rules that fire on error patterns — distinct from metric-based alerts. Routes to Slack, email, PagerDuty, or webhooks."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors", href: "/errors" }, { label: "Alerts" }]}
        icon={<Bell className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Alert history exported")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening new alert rule form")}>
              <Plus className="w-3.5 h-3.5" /> New Alert
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Alert Rules" value={rules.length} hint={`${enabled} enabled`} icon={<Bell className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Critical Rules" value={criticalRules} hint="page on-call" icon={<BellRing className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Triggered (24h)" value={totalTriggers} hint="across all rules" icon={<Activity className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Delivery Rate" value="98.4" unit="%" hint="2 failed in last 24h" icon={<MessageSquare className="w-4 h-4" />} accent="success" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Alert Rules" description="Each rule evaluates incoming error events. Toggle to enable or disable." />
        <div className="mt-4">
          <DataTable
            columns={ruleCols}
            data={rules}
            rowKey={(r) => r.id}
            searchKeys={["name", "condition"]}
            searchPlaceholder="Search alert rules..."
            pageSize={8}
            initialSort={{ key: "triggered24h", dir: "desc" }}
          />
        </div>
      </Card>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Alert History" description="Delivery log for the last 24 hours" />
        <div className="mt-4">
          <DataTable
            columns={histCols}
            data={history}
            rowKey={(r) => r.id}
            searchKeys={["rule", "errorRef"]}
            searchPlaceholder="Search history..."
            pageSize={8}
            initialSort={{ key: "timestamp", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
