"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { DataTable, type Column } from "@/components/tables/data-table";
import { toast } from "sonner";
import { Settings, Filter, Plus, Pencil, Trash2, ArrowUp, ArrowDown, Download, GitBranch } from "lucide-react";

interface ErrorRule {
  id: string;
  name: string;
  condition: string;
  action: string;
  priority: number;
  enabled: boolean;
  matchCount: number;
  lastMatch?: string;
}

const initialRules: ErrorRule[] = [
  { id: "r1", name: "Group checkout errors by user_id", condition: "service = checkout-api AND tags contains checkout", action: "Set owner: Payments team", priority: 1, enabled: true, matchCount: 428, lastMatch: "2026-07-02T05:48:00Z" },
  { id: "r2", name: "Mark OOM as regression", condition: "type = OutOfMemoryError", action: "Flag as regression + page on-call", priority: 2, enabled: true, matchCount: 12, lastMatch: "2026-07-02T05:40:00Z" },
  { id: "r3", name: "Suppress validation noise", condition: "type = ValidationError AND message contains 'email format'", action: "Mark as ignored", priority: 3, enabled: true, matchCount: 1248, lastMatch: "2026-07-02T05:45:00Z" },
  { id: "r4", name: "Auto-assign redis timeouts", condition: "type = ConnectionTimeoutError AND service = redis-cluster", action: "Assign to u9 (Sofia Bianchi)", priority: 4, enabled: true, matchCount: 184, lastMatch: "2026-07-02T05:50:00Z" },
  { id: "r5", name: "Link DB timeouts to DBA schedule", condition: "type = QueryTimeoutError", action: "Page DBA on-call + create incident", priority: 5, enabled: true, matchCount: 84, lastMatch: "2026-07-02T01:30:00Z" },
  { id: "r6", name: "Drop browser-extension stack noise", condition: "stack matches /extension:\\/\\//", action: "Discard event", priority: 6, enabled: false, matchCount: 0 },
  { id: "r7", name: "Tag auth errors with severity", condition: "service = auth-service AND status = 401", action: "Set severity = info", priority: 7, enabled: true, matchCount: 940, lastMatch: "2026-07-02T05:48:00Z" },
  { id: "r8", name: "Group by release for regression detection", condition: "release != null", action: "Enable regression tracking", priority: 8, enabled: true, matchCount: 1840, lastMatch: "2026-07-02T05:48:00Z" },
];

export default function ErrorRulesPage() {
  const [rules, setRules] = React.useState(initialRules);

  function toggle(id: string) {
    setRules((r) => r.map((x) => x.id === id ? { ...x, enabled: !x.enabled } : x));
    const r = rules.find((x) => x.id === id);
    toast.success(`${r?.name} ${r?.enabled ? "disabled" : "enabled"}`);
  }

  function move(id: string, dir: "up" | "down") {
    setRules((rs) => {
      const idx = rs.findIndex((r) => r.id === id);
      if (idx < 0) return rs;
      const newIdx = dir === "up" ? Math.max(0, idx - 1) : Math.min(rs.length - 1, idx + 1);
      if (newIdx === idx) return rs;
      const next = [...rs];
      const [item] = next.splice(idx, 1);
      next.splice(newIdx, 0, item);
      // re-prioritize
      return next.map((r, i) => ({ ...r, priority: i + 1 }));
    });
    toast.success(`Rule ${dir === "up" ? "moved up" : "moved down"}`);
  }

  function del(id: string) {
    const r = rules.find((x) => x.id === id);
    setRules((rs) => rs.filter((x) => x.id !== id));
    toast.success(`Rule deleted: ${r?.name}`);
  }

  const enabled = rules.filter((r) => r.enabled).length;

  const columns: Column<ErrorRule>[] = [
    {
      key: "priority",
      header: "#",
      align: "center",
      width: "48px",
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.priority}</span>,
    },
    {
      key: "name",
      header: "Rule",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="min-w-0 max-w-xs">
          <p className="text-xs font-medium truncate">{r.name}</p>
          <p className="text-[10px] text-muted-foreground truncate">
            <Filter className="w-2.5 h-2.5 inline mr-1" />
            {r.condition}
          </p>
        </div>
      ),
    },
    {
      key: "action",
      header: "Action",
      hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-1.5 text-xs">
          <GitBranch className="w-3 h-3 text-muted-foreground" />
          <span className="truncate">{r.action}</span>
        </div>
      ),
    },
    {
      key: "matchCount",
      header: "Matches (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.matchCount,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums font-medium">{r.matchCount.toLocaleString()}</span>,
    },
    {
      key: "lastMatch",
      header: "Last Match",
      align: "right",
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.lastMatch ? new Date(r.lastMatch).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—"}</span>,
    },
    {
      key: "enabled",
      header: "Enabled",
      align: "center",
      cell: (r) => <Switch checked={r.enabled} onCheckedChange={() => toggle(r.id)} aria-label="Toggle rule" />,
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      cell: (r) => (
        <div className="flex items-center justify-end gap-1">
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); move(r.id, "up"); }}>
            <ArrowUp className="w-3 h-3" />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); move(r.id, "down"); }}>
            <ArrowDown className="w-3 h-3" />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); toast.success(`Editing rule: ${r.name}`); }}>
            <Pencil className="w-3 h-3" />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 hover:text-destructive" onClick={(e) => { e.stopPropagation(); del(r.id); }}>
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Error Rules"
        description="Inbox and grouping rules that automatically assign, suppress, escalate, or tag incoming error events."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors", href: "/errors" }, { label: "Rules" }]}
        icon={<Settings className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Rules exported as JSON")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening new rule form")}>
              <Plus className="w-3.5 h-3.5" /> New Rule
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Rules" value={rules.length} hint="configured" icon={<Settings className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Enabled" value={enabled} hint={`${Math.round((enabled / rules.length) * 100)}% active`} icon={<Filter className="w-4 h-4" />} accent="success" />
        <KpiCard label="Matches (24h)" value={rules.reduce((s, r) => s + r.matchCount, 0).toLocaleString()} hint="across all rules" icon={<GitBranch className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg per rule" value={Math.round(rules.reduce((s, r) => s + r.matchCount, 0) / rules.length)} hint="matches per rule" icon={<Settings className="w-4 h-4" />} accent="warning" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading
          title="Rule Chain"
          description="Rules execute in priority order. Drag using arrows to reorder. First match wins."
          action={<span className="text-[11px] text-muted-foreground">First-match-wins</span>}
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={rules}
            rowKey={(r) => r.id}
            searchKeys={["name", "condition", "action"]}
            searchPlaceholder="Search rules..."
            pageSize={10}
            initialSort={{ key: "priority", dir: "asc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
