"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { errors } from "@/lib/data";
import { toast } from "sonner";
import {
  Code, FileCode, Check, AlertTriangle, ChevronRight, Download, Copy,
} from "lucide-react";

interface ParsedFrame {
  raw: string;
  fn: string;
  file: string;
  line: number;
  col?: number;
  inApp: boolean;
  source?: string[];
}

function parseFrame(raw: string): ParsedFrame {
  // Patterns: "at fn (file:line:col)" or "at file:line:col" or "at fn (node:internal/...:line)"
  const match = raw.match(/^at\s+(?:(.+?)\s+\()?(.+?):(\d+)(?::(\d+))?\)?$/);
  if (!match) {
    return { raw, fn: raw, file: "", line: 0, inApp: false };
  }
  const [, fn, file, lineStr, colStr] = match;
  const isInternal = file?.startsWith("node:") || file?.includes("node_modules");
  return {
    raw,
    fn: fn || "<anonymous>",
    file: file || "",
    line: parseInt(lineStr || "0", 10),
    col: colStr ? parseInt(colStr, 10) : undefined,
    inApp: !isInternal,
  };
}

export default function StackTracesPage() {
  const [errorId, setErrorId] = React.useState(errors[0].id);
  const error = errors.find((e) => e.id === errorId) ?? errors[0];

  const frames = React.useMemo(() => {
    return error.stack.split("\n").filter(Boolean).map((raw) => {
      const f = parseFrame(raw);
      // Mock source lines for in-app frames
      if (f.inApp && f.line > 0) {
        f.source = [
          `  function ${f.fn}() {`,
          `    const ctx = getContext();`,
          `    if (!ctx) throw new Error("missing context");  // <- line ${f.line - 1}`,
          `    return ctx.process();                          // <- line ${f.line}`,
          `  }`,
        ];
      }
      return f;
    });
  }, [error]);

  const sourceMapOk = error.sourceMapStatus === "ok";

  function copyTrace() {
    navigator.clipboard?.writeText(error.stack);
    toast.success("Stack trace copied to clipboard");
  }

  return (
    <PageContainer>
      <PageHeader
        title="Stack Trace Viewer"
        description="Frame-by-frame inspection of error stack traces with source mapping and file/line attribution."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors", href: "/errors" }, { label: "Stack Traces" }]}
        icon={<Code className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={copyTrace}>
              <Copy className="w-3.5 h-3.5" /> <span className="hidden md:inline">Copy</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Stack trace exported")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* Error selector + source map status */}
      <Card className="p-4 flex flex-col md:flex-row md:items-center gap-4 md:justify-between">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 flex-1 min-w-0">
          <Label className="text-xs text-muted-foreground shrink-0">Error</Label>
          <Select value={errorId} onValueChange={setErrorId}>
            <SelectTrigger className="w-full md:w-[420px] h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {errors.map((e) => (
                <SelectItem key={e.id} value={e.id}>
                  <span className="font-mono text-xs">{e.ref}</span> — <span className="truncate">{e.message.slice(0, 60)}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-3">
          <div className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-medium ${sourceMapOk ? "border-success/30 bg-success/10 text-success" : "border-warning/30 bg-warning/10 text-warning-foreground"}`}>
            {sourceMapOk ? <Check className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
            Source map: {error.sourceMapStatus}
          </div>
        </div>
      </Card>

      {/* Error header */}
      <Card className="p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <div className="flex items-center gap-2">
              <code className="text-xs font-mono text-muted-foreground">{error.ref}</code>
              <span className="inline-flex items-center rounded-md border border-border bg-muted px-1.5 py-0.5 text-[10px] font-mono">{error.type}</span>
            </div>
            <p className="text-sm font-mono break-all">{error.message}</p>
            <p className="text-[11px] text-muted-foreground">
              {error.eventCount.toLocaleString()} events · {error.userCount.toLocaleString()} users · last seen {new Date(error.lastSeen).toLocaleString()}
            </p>
          </div>
        </div>
      </Card>

      {/* Stack frames */}
      <div className="space-y-3">
        {frames.map((f, i) => (
          <Card key={i} className={`overflow-hidden ${f.inApp ? "border-primary/20" : "border-border"}`}>
            {/* Frame header */}
            <div className="flex items-center gap-3 px-4 py-2.5 border-b border-border bg-muted/40">
              <span className="text-[10px] font-mono text-muted-foreground/70 w-5 text-right">{i + 1}</span>
              <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />
              <code className="text-xs font-mono font-medium">{f.fn}</code>
              {f.inApp && (
                <span className="inline-flex items-center rounded border border-primary/30 bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary">in-app</span>
              )}
              <div className="ml-auto flex items-center gap-2 text-[11px] text-muted-foreground min-w-0">
                {f.file && (
                  <span className="flex items-center gap-1 truncate">
                    <FileCode className="w-3 h-3" />
                    <code className="font-mono truncate">{f.file}</code>
                    <span className="tabular-nums">:{f.line}{f.col ? `:${f.col}` : ""}</span>
                  </span>
                )}
              </div>
            </div>
            {/* Source preview */}
            {f.source ? (
              <pre className="text-[11px] font-mono leading-relaxed p-3 overflow-x-auto bg-muted/20">
                {f.source.map((line, j) => (
                  <div key={j} className={`flex gap-3 ${j === 3 ? "bg-destructive/10 -mx-3 px-3" : ""}`}>
                    <span className="text-muted-foreground/50 select-none w-6 text-right">{f.line - 3 + j}</span>
                    <span className={j === 3 ? "text-destructive" : "text-foreground"}>{line}</span>
                  </div>
                ))}
              </pre>
            ) : (
              <div className="px-4 py-3 text-[11px] text-muted-foreground italic">
                {f.file ? "Source not available (external module)" : "Frame parsing failed"}
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Source map info */}
      <Card className="p-4">
        <SectionHeading title="Source Map Details" description="Symbolication metadata for this stack trace" />
        <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Status</p>
            <p className={`font-medium ${sourceMapOk ? "text-success" : "text-warning-foreground"}`}>{error.sourceMapStatus}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Release</p>
            <p className="font-mono">{error.releaseId ?? "—"}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Frames total</p>
            <p className="tabular-nums">{frames.length}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">In-app frames</p>
            <p className="tabular-nums">{frames.filter((f) => f.inApp).length}</p>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
