"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { ErrorRateChart, DonutChart, HorizontalBarChart } from "@/components/charts";
import { errors, services } from "@/lib/data";
import type { ErrorGroup } from "@/lib/types";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { TrendingUp, AlertTriangle, Sparkles, CheckCircle2, Download } from "lucide-react";

const errorsByService = services.slice(0, 6).map((s) => ({
  name: s.name,
  value: Math.max(2, Math.round(s.openAlerts * 8 + (s.health === "degraded" ? 80 : 12) + (s.health === "partial" ? 320 : 0))),
}));

const errorsByType = [
  { name: "TypeError", value: 428 },
  { name: "ValidationError", value: 1248 },
  { name: "ConnectionTimeoutError", value: 184 },
  { name: "OutOfMemoryError", value: 12 },
  { name: "QueryTimeoutError", value: 84 },
  { name: "Other", value: 320 },
];

export default function ErrorTrendsPage() {
  const errRateTrend = React.useMemo(() => timeSeries(31, 24, 0.62, 0.18).map((d, i) => ({
    timestamp: `${String(i).padStart(2, "0")}:00`,
    value: Number(d.value.toFixed(3)),
  })), []);

  const topErrors = [...errors].sort((a, b) => b.eventCount - a.eventCount);

  const columns: Column<ErrorGroup>[] = [
    {
      key: "ref",
      header: "Ref",
      cell: (r) => <code className="text-xs font-mono text-muted-foreground">{r.ref}</code>,
    },
    {
      key: "message",
      header: "Message",
      sortable: true,
      sortValue: (r) => r.message,
      cell: (r) => (
        <div className="min-w-0 max-w-md">
          <p className="text-xs font-medium truncate">{r.message}</p>
          <p className="text-[10px] text-muted-foreground">{services.find((s) => s.id === r.serviceId)?.name ?? r.serviceId}</p>
        </div>
      ),
    },
    {
      key: "type",
      header: "Type",
      hideOnMobile: true,
      cell: (r) => <code className="text-[11px] font-mono text-muted-foreground">{r.type}</code>,
    },
    {
      key: "eventCount",
      header: "Events",
      align: "right",
      sortable: true,
      sortValue: (r) => r.eventCount,
      cell: (r) => <span className="text-xs tabular-nums font-medium">{r.eventCount.toLocaleString()}</span>,
    },
    {
      key: "trend",
      header: "Trend",
      align: "right",
      hideOnMobile: true,
      cell: (r) => {
        const max = Math.max(...r.trend, 1);
        return (
          <div className="flex items-end gap-0.5 h-6 justify-end">
            {r.trend.map((v, i) => (
              <div key={i} className={`w-1 rounded-t ${v > 100 ? "bg-destructive" : v > 20 ? "bg-warning" : "bg-primary/60"}`} style={{ height: `${Math.max(2, (v / max) * 100)}%` }} />
            ))}
          </div>
        );
      },
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Error Trends"
        description="Aggregate error rate, distribution by service and type, and top events over the past 24 hours."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors", href: "/errors" }, { label: "Trends" }]}
        icon={<TrendingUp className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Trend report exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Error Rate" value="0.62" unit="%" delta={0.14} deltaLabel="vs prev" icon={<AlertTriangle className="w-4 h-4" />} accent="warning" sparkline={[0.42, 0.48, 0.52, 0.58, 0.6, 0.62, 0.62]} />
        <KpiCard label="Events Today" value="2,276" delta={12} deltaLabel="vs yesterday" icon={<TrendingUp className="w-4 h-4" />} accent="primary" />
        <KpiCard label="New Errors" value="3" hint="first seen today" icon={<Sparkles className="w-4 h-4" />} accent="info" />
        <KpiCard label="Resolved (24h)" value="8" delta={4} deltaLabel="vs prev day" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
      </div>

      <Card className="p-4 h-[320px]">
        <SectionHeading title="Error Rate Trend" description="Aggregate error rate across all services, 24h window" action={<span className="text-[11px] text-muted-foreground">Threshold 1.0%</span>} />
        <div className="h-[240px] mt-2">
          <ErrorRateChart data={errRateTrend} />
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-4 h-[320px]">
          <SectionHeading title="Errors by Service" description="Event count per service (24h)" />
          <div className="h-[240px] mt-2">
            <HorizontalBarChart data={errorsByService} color={4} />
          </div>
        </Card>
        <Card className="p-4 h-[320px]">
          <SectionHeading title="Errors by Type" description="Distribution of exception classes" />
          <div className="h-[240px] mt-2">
            <DonutChart data={errorsByType} centerValue="2,276" centerLabel="events" />
          </div>
        </Card>
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Top Errors by Event Count" description="Ranked by total event volume in the last 24h" />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={topErrors}
            rowKey={(r) => r.id}
            searchKeys={["ref", "message", "type"]}
            searchPlaceholder="Search errors..."
            pageSize={6}
            initialSort={{ key: "eventCount", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
