"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { errors, services, people } from "@/lib/data";
import type { ErrorGroup } from "@/lib/types";
import { toast } from "sonner";
import { Bug, AlertTriangle, Users, Activity, Download, RefreshCw, Filter } from "lucide-react";

function statusBadge(status: ErrorGroup["status"]) {
  const map: Record<string, { label: string; cls: string }> = {
    unresolved: { label: "Unresolved", cls: "bg-destructive/15 text-destructive border-destructive/30" },
    in_progress: { label: "In Progress", cls: "bg-info/15 text-info-foreground border-info/30" },
    resolved: { label: "Resolved", cls: "bg-success/15 text-success border-success/30" },
    ignored: { label: "Ignored", cls: "bg-muted text-muted-foreground border-border" },
  };
  const c = map[status];
  return (
    <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide ${c.cls}`}>
      <span className="w-1 h-1 rounded-full bg-current opacity-70" />
      {c.label}
    </span>
  );
}

function RegressionBadge({ isRegression }: { isRegression: boolean }) {
  if (!isRegression) return <span className="text-xs text-muted-foreground">—</span>;
  return (
    <span className="inline-flex items-center gap-1 rounded-md border border-destructive/30 bg-destructive/15 px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-destructive">
      <AlertTriangle className="w-2.5 h-2.5" /> Regression
    </span>
  );
}

export default function ErrorsListPage() {
  const router = useRouter();

  const open = errors.filter((e) => e.status === "unresolved" || e.status === "in_progress").length;
  const unresolved = errors.filter((e) => e.status === "unresolved").length;
  const regressions = errors.filter((e) => e.isRegression).length;
  const affectedUsers = errors.reduce((s, e) => s + e.userCount, 0);

  const columns: Column<ErrorGroup>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => <code className="text-xs font-mono text-muted-foreground">{r.ref}</code>,
    },
    {
      key: "message",
      header: "Message",
      sortable: true,
      sortValue: (r) => r.message,
      cell: (r) => (
        <div className="min-w-0 max-w-md">
          <p className="text-xs font-medium truncate">{r.message}</p>
          <p className="text-[10px] text-muted-foreground">{r.type}</p>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      filterable: true,
      filterOptions: services.map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.serviceId === v,
      hideOnMobile: true,
      cell: (r) => {
        const s = services.find((x) => x.id === r.serviceId);
        return <span className="text-xs text-muted-foreground">{s?.name ?? r.serviceId}</span>;
      },
    },
    {
      key: "status",
      header: "Status",
      filterable: true,
      filterOptions: [
        { label: "Unresolved", value: "unresolved" },
        { label: "In Progress", value: "in_progress" },
        { label: "Resolved", value: "resolved" },
        { label: "Ignored", value: "ignored" },
      ],
      filterFn: (r, v) => r.status === v,
      cell: (r) => statusBadge(r.status),
    },
    {
      key: "firstSeen",
      header: "First Seen",
      sortable: true,
      sortValue: (r) => r.firstSeen,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{new Date(r.firstSeen).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>,
    },
    {
      key: "lastSeen",
      header: "Last Seen",
      sortable: true,
      sortValue: (r) => r.lastSeen,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{new Date(r.lastSeen).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>,
    },
    {
      key: "eventCount",
      header: "Events",
      align: "right",
      sortable: true,
      sortValue: (r) => r.eventCount,
      cell: (r) => <span className="text-xs tabular-nums font-medium">{r.eventCount.toLocaleString()}</span>,
    },
    {
      key: "userCount",
      header: "Users",
      align: "right",
      sortable: true,
      sortValue: (r) => r.userCount,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.userCount.toLocaleString()}</span>,
    },
    {
      key: "isRegression",
      header: "Regression",
      filterable: true,
      filterOptions: [
        { label: "Regressions only", value: "true" },
        { label: "Non-regressions", value: "false" },
      ],
      filterFn: (r, v) => String(r.isRegression) === v,
      cell: (r) => <RegressionBadge isRegression={r.isRegression} />,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Errors List"
        description="Real-time error tracking with regression detection, release attribution, and per-event frequency trends."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Errors" }]}
        icon={<Bug className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Replaying inbox from last 24h")}>
              <RefreshCw className="w-3.5 h-3.5" /> <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Error events exported")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Open" value={open} hint={`${unresolved} unresolved`} icon={<Bug className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Unresolved" value={unresolved} hint="needs triage" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Regressions" value={regressions} hint="newly broken" icon={<Activity className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Affected Users" value={affectedUsers.toLocaleString()} hint="across all open errors" icon={<Users className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading
          title="Error Inbox"
          description="Click any row to inspect the stack trace, event frequency, and release attribution."
          action={<span className="text-[11px] text-muted-foreground">{errors.length} groups</span>}
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={errors}
            rowKey={(r) => r.id}
            searchKeys={["ref", "message", "type"]}
            searchPlaceholder="Search by ref, message, or type..."
            pageSize={10}
            initialSort={{ key: "lastSeen", dir: "desc" }}
            onRowClick={(r) => router.push(`/errors/${r.id}`)}
            mobileCard={(r) => (
              <Card className="p-3 cursor-pointer hover:bg-muted/40">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0">
                    <code className="text-[10px] font-mono text-muted-foreground">{r.ref}</code>
                    <p className="text-xs font-medium truncate">{r.message}</p>
                  </div>
                  {statusBadge(r.status)}
                </div>
                <div className="grid grid-cols-3 gap-2 text-[10px]">
                  <div>
                    <p className="text-muted-foreground">Events</p>
                    <p className="font-medium tabular-nums">{r.eventCount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Users</p>
                    <p className="font-medium tabular-nums">{r.userCount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Regression</p>
                    {r.isRegression ? <span className="text-destructive font-medium">Yes</span> : <span className="text-muted-foreground">No</span>}
                  </div>
                </div>
              </Card>
            )}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
