"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  FileText, Download, Plus, Filter, GitBranch, Sparkles, Bug, AlertOctagon,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown } from "lucide-react";
import { deployments, services, people } from "@/lib/data";
import { TierBadge } from "@/components/common/badges";
import { toast } from "sonner";

interface ChangelogItem {
  type: "feature" | "fix" | "breaking" | "improvement" | "deprecation";
  description: string;
}

interface ReleaseNote {
  deploymentId: string;
  version: string;
  serviceName: string;
  serviceId: string;
  date: string;
  authorName: string;
  authorAvatar?: string;
  summary: string;
  items: ChangelogItem[];
}

const releaseNotes: ReleaseNote[] = deployments
  .filter((d) => d.status === "succeeded" || d.status === "rolled_back")
  .map((d) => {
    const svc = services.find((s) => s.id === d.serviceId);
    const author = people.find((p) => p.id === d.authorId);
    // Generate changelog items based on commit message
    const items: ChangelogItem[] = [];
    if (d.commitMessage.startsWith("feat")) {
      items.push({ type: "feature", description: d.commitMessage.replace(/^feat\([^)]+\):\s*/, "") });
    } else if (d.commitMessage.startsWith("fix")) {
      items.push({ type: "fix", description: d.commitMessage.replace(/^fix\([^)]+\):\s*/, "") });
    }
    // Add some synthetic items
    if (d.changesCount > 10) {
      items.push({ type: "improvement", description: `Refactored ${d.changesCount} files for better maintainability` });
    }
    if (d.riskScore > 50) {
      items.push({ type: "breaking", description: "Configuration schema updated - migration required for downstream consumers" });
    }
    items.push({ type: "improvement", description: `Updated dependencies to latest patch versions` });
    if (d.status === "rolled_back") {
      items.push({ type: "deprecation", description: "This release was rolled back due to elevated error rates" });
    }
    return {
      deploymentId: d.id,
      version: d.version,
      serviceName: svc?.name ?? "unknown",
      serviceId: d.serviceId,
      date: d.startedAt,
      authorName: author?.name ?? "Unknown",
      authorAvatar: author?.avatarUrl,
      summary: d.commitMessage,
      items,
    };
  });

const typeConfig: Record<ChangelogItem["type"], { label: string; icon: React.ReactNode; className: string }> = {
  feature: { label: "Feature", icon: <Sparkles className="w-3 h-3" />, className: "bg-success/15 text-success border-success/30" },
  fix: { label: "Fix", icon: <Bug className="w-3 h-3" />, className: "bg-info/15 text-info-foreground border-info/30" },
  breaking: { label: "Breaking", icon: <AlertOctagon className="w-3 h-3" />, className: "bg-destructive/15 text-destructive border-destructive/30" },
  improvement: { label: "Improvement", icon: <GitBranch className="w-3 h-3" />, className: "bg-primary/15 text-primary border-primary/30" },
  deprecation: { label: "Deprecation", icon: <AlertOctagon className="w-3 h-3" />, className: "bg-warning/15 text-warning-foreground border-warning/30" },
};

export default function ReleaseNotesPage() {
  const [serviceFilter, setServiceFilter] = React.useState("All");
  const filtered = releaseNotes.filter((r) => serviceFilter === "All" || r.serviceId === serviceFilter);

  return (
    <PageContainer>
      <PageHeader
        title="Release Notes"
        description="Customer-facing release notes generated from deployment commits with changelog categorization."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Release Notes" }]}
        icon={<FileText className="w-5 h-5" />}
        actions={
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Filter className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">{serviceFilter === "All" ? "All services" : services.find((s) => s.id === serviceFilter)?.name}</span>
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="max-h-80 overflow-y-auto">
                <DropdownMenuItem onClick={() => setServiceFilter("All")}>All services</DropdownMenuItem>
                {services.map((s) => (
                  <DropdownMenuItem key={s.id} onClick={() => setServiceFilter(s.id)}>{s.name}</DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Release notes exported as markdown")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export MD</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New release note composer opened")}>
              <Plus className="w-3.5 h-3.5" />
              Compose
            </Button>
          </>
        }
      />

      <div className="space-y-4">
        {filtered.length === 0 ? (
          <Card className="p-12 text-center">
            <FileText className="w-8 h-8 mx-auto mb-3 text-muted-foreground opacity-50" />
            <h3 className="text-sm font-semibold">No release notes</h3>
            <p className="text-xs text-muted-foreground mt-1">No releases match the current filter.</p>
          </Card>
        ) : (
          filtered.map((note) => {
            const svc = services.find((s) => s.id === note.serviceId);
            return (
              <Card key={note.deploymentId} className="p-6 space-y-4">
                {/* Release header */}
                <div className="flex items-start justify-between gap-3 pb-3 border-b border-border">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h2 className="text-lg font-semibold">v{note.version.replace(/^v/, "")}</h2>
                      <span className="font-mono text-xs text-muted-foreground">{note.serviceName}</span>
                      {svc && <TierBadge tier={svc.tier} />}
                    </div>
                    <p className="text-sm text-muted-foreground">{note.summary}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs text-muted-foreground">{new Date(note.date).toLocaleDateString()}</div>
                    <div className="flex items-center gap-1.5 mt-1 justify-end">
                      {note.authorAvatar && <img src={note.authorAvatar} alt={note.authorName} className="w-5 h-5 rounded-full object-cover" />}
                      <span className="text-xs">{note.authorName}</span>
                    </div>
                  </div>
                </div>

                {/* Changelog items grouped by type */}
                <div className="space-y-3">
                  {(Object.keys(typeConfig) as ChangelogItem["type"][]).map((type) => {
                    const items = note.items.filter((i) => i.type === type);
                    if (items.length === 0) return null;
                    const cfg = typeConfig[type];
                    return (
                      <div key={type} className="space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${cfg.className}`}>
                            {cfg.icon}
                            {cfg.label}
                          </span>
                          <span className="text-[10px] text-muted-foreground">{items.length} item{items.length !== 1 ? "s" : ""}</span>
                        </div>
                        <ul className="space-y-1 pl-1">
                          {items.map((item, i) => (
                            <li key={i} className="text-sm flex items-start gap-2">
                              <span className="text-muted-foreground mt-1.5">·</span>
                              <span>{item.description}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    );
                  })}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-3 border-t border-border text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <GitBranch className="w-3 h-3" />
                    Released by {note.authorName}
                  </span>
                  <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success("Release note copied to clipboard")}>
                    <Download className="w-3 h-3" /> Copy as Markdown
                  </Button>
                </div>
              </Card>
            );
          })
        )}
      </div>
    </PageContainer>
  );
}
