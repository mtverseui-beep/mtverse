"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  CalendarDays, ChevronLeft, ChevronRight, Rocket, Clock,
} from "lucide-react";
import { deployments, services } from "@/lib/data";
import { DeploymentStatusBadge, TierBadge } from "@/components/common/badges";
import { toast } from "sonner";

export default function ReleaseCalendarPage() {
  const [current, setCurrent] = React.useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [selectedDay, setSelectedDay] = React.useState<string | null>(null);

  const year = current.getFullYear();
  const month = current.getMonth();
  const monthName = current.toLocaleString("default", { month: "long" });

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startWeekday = firstDay.getDay();
  const daysInMonth = lastDay.getDate();

  // Build calendar grid (6 weeks)
  const cells: (Date | null)[] = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length < 42) cells.push(null);

  // Group deployments by date
  const deploymentsByDate: Record<string, typeof deployments> = {};
  deployments.forEach((d) => {
    const dateStr = new Date(d.startedAt).toISOString().slice(0, 10);
    if (!deploymentsByDate[dateStr]) deploymentsByDate[dateStr] = [];
    deploymentsByDate[dateStr].push(d);
  });

  const today = new Date();
  const todayStr = today.toISOString().slice(0, 10);

  // Upcoming scheduled releases (next 14 days, mock)
  const upcoming = deployments
    .filter((d) => new Date(d.startedAt).getTime() >= today.getTime() - 7 * 86400000)
    .slice(0, 6);

  function prevMonth() { setCurrent(new Date(year, month - 1, 1)); setSelectedDay(null); }
  function nextMonth() { setCurrent(new Date(year, month + 1, 1)); setSelectedDay(null); }
  function goToday() { const d = new Date(); setCurrent(new Date(d.getFullYear(), d.getMonth(), 1)); setSelectedDay(null); }

  const selectedDeployments = selectedDay ? (deploymentsByDate[selectedDay] ?? []) : [];

  const totalThisMonth = Object.entries(deploymentsByDate)
    .filter(([d]) => d.startsWith(`${year}-${String(month + 1).padStart(2, "0")}`))
    .reduce((s, [, arr]) => s + arr.length, 0);

  return (
    <PageContainer>
      <PageHeader
        title="Release Calendar"
        description="Month-at-a-glance view of deployments with day-by-day markers and upcoming scheduled releases."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Calendar" }]}
        icon={<CalendarDays className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={goToday}>
              Today
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New scheduled release created")}>
              <Rocket className="w-3.5 h-3.5" />
              Schedule
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Calendar grid */}
        <Card className="lg:col-span-2 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">{monthName} {year}</h2>
              <p className="text-xs text-muted-foreground">{totalThisMonth} deployments this month</p>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={prevMonth}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={nextMonth}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
              <div key={d} className="text-center text-[10px] uppercase tracking-wider font-medium text-muted-foreground py-1">
                {d}
              </div>
            ))}
            {cells.map((date, i) => {
              if (!date) return <div key={i} className="aspect-square rounded-md bg-muted/20" />;
              const dateStr = date.toISOString().slice(0, 10);
              const dayDeploys = deploymentsByDate[dateStr] ?? [];
              const isToday = dateStr === todayStr;
              const isSelected = dateStr === selectedDay;
              const isPast = date.getTime() < today.getTime() - 86400000;
              return (
                <button
                  key={i}
                  onClick={() => setSelectedDay(dateStr)}
                  className={`aspect-square rounded-md border p-1.5 text-left flex flex-col gap-0.5 transition-colors ${
                    isSelected ? "border-primary bg-primary/10" :
                    isToday ? "border-primary/50 bg-primary/5" :
                    "border-border hover:bg-muted/40"
                  } ${isPast ? "opacity-60" : ""}`}
                >
                  <span className={`text-[10px] font-medium ${isToday ? "text-primary" : "text-muted-foreground"}`}>
                    {date.getDate()}
                  </span>
                  {dayDeploys.length > 0 && (
                    <div className="flex flex-wrap gap-0.5 mt-auto">
                      {dayDeploys.slice(0, 4).map((d) => (
                        <span
                          key={d.id}
                          className={`w-1.5 h-1.5 rounded-full ${
                            d.status === "succeeded" ? "bg-success" :
                            d.status === "failed" || d.status === "rolled_back" ? "bg-destructive" :
                            d.status === "in_progress" || d.status === "rolling_out" || d.status === "canary" ? "bg-info" :
                            "bg-muted-foreground"
                          }`}
                          title={d.ref}
                        />
                      ))}
                      {dayDeploys.length > 4 && <span className="text-[9px] text-muted-foreground">+{dayDeploys.length - 4}</span>}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </Card>

        {/* Side panel: selected day + upcoming */}
        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading
              title={selectedDay ? `Deployments on ${selectedDay}` : "Select a day"}
              description={selectedDay ? `${selectedDeployments.length} deployment(s)` : "Click any calendar day"}
            />
            <div className="space-y-2 max-h-72 overflow-y-auto">
              {!selectedDay && (
                <div className="text-center text-xs text-muted-foreground py-6">
                  <CalendarDays className="w-6 h-6 mx-auto mb-2 opacity-50" />
                  No day selected
                </div>
              )}
              {selectedDay && selectedDeployments.length === 0 && (
                <div className="text-center text-xs text-muted-foreground py-6">No deployments on this day</div>
              )}
              {selectedDeployments.map((d) => {
                const svc = services.find((s) => s.id === d.serviceId);
                return (
                  <Link key={d.id} href={`/deployments/${d.id}`} className="block p-2.5 rounded-md border hover:bg-muted/40 transition-colors">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-mono text-[11px] font-semibold">{d.ref}</span>
                      <DeploymentStatusBadge status={d.status} />
                    </div>
                    <div className="flex items-center gap-1.5">
                      {svc && <TierBadge tier={svc.tier} />}
                      <span className="text-xs truncate">{svc?.name}</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{new Date(d.startedAt).toLocaleTimeString()}</div>
                  </Link>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Upcoming Scheduled" description="Next planned releases" />
            <div className="space-y-2">
              {upcoming.length === 0 ? (
                <div className="text-center text-xs text-muted-foreground py-6">No upcoming releases</div>
              ) : upcoming.map((d) => {
                const svc = services.find((s) => s.id === d.serviceId);
                return (
                  <Link key={d.id} href={`/deployments/${d.id}`} className="flex items-center justify-between gap-2 p-2.5 rounded-md border hover:bg-muted/40">
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs font-medium truncate">{svc?.name}</span>
                      </div>
                      <div className="text-[10px] text-muted-foreground">{new Date(d.startedAt).toLocaleString()}</div>
                    </div>
                    <span className="font-mono text-[10px] text-muted-foreground">{d.version}</span>
                  </Link>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
