"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  ThumbsUp, X, Clock, ShieldAlert, GitBranch, CheckCircle2, AlertTriangle, Activity,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { deployments, services, people } from "@/lib/data";
import { DeploymentStatusBadge, TierBadge } from "@/components/common/badges";
import { toast } from "sonner";

export default function ApprovalsPage() {
  const [pending, setPending] = React.useState(deployments.filter((d) => d.status === "pending_approval"));
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [dialogMode, setDialogMode] = React.useState<"approve" | "reject">("approve");
  const [comment, setComment] = React.useState("");
  const [activeId, setActiveId] = React.useState<string | null>(null);

  const completed = deployments.filter((d) => d.status === "approved" || d.status === "succeeded").length;

  function openDialog(id: string, mode: "approve" | "reject") {
    setActiveId(id);
    setDialogMode(mode);
    setComment("");
    setDialogOpen(true);
  }

  function submitDecision() {
    if (!activeId) return;
    const dep = deployments.find((d) => d.id === activeId);
    if (dialogMode === "approve") {
      toast.success(`${dep?.ref} approved`, { description: comment || "No comment added" });
      setPending((p) => p.filter((d) => d.id !== activeId));
    } else {
      toast.error(`${dep?.ref} rejected`, { description: comment || "No reason provided" });
      setPending((p) => p.filter((d) => d.id !== activeId));
    }
    setDialogOpen(false);
    setComment("");
    setActiveId(null);
  }

  return (
    <PageContainer>
      <PageHeader
        title="Deployment Approvals"
        description="Review and approve pending deployments. High-risk changes require dual approval."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Approvals" }]}
        icon={<ThumbsUp className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Pending Approval" value={pending.length} hint="awaiting review" icon={<Clock className="w-4 h-4" />} accent="warning" />
        <KpiCard label="High-Risk Pending" value={pending.filter((d) => d.riskScore > 50).length} hint="require dual sign-off" icon={<ShieldAlert className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Approved (30d)" value={completed} hint="last 30 days" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Avg Decision Time" value="14m" hint="request → decision" icon={<Activity className="w-4 h-4" />} accent="info" />
      </div>

      {/* Pending approval list */}
      <div className="space-y-4">
        <SectionHeading title="Pending Approvals" description="Awaiting your decision" action={<span className="text-xs text-muted-foreground">{pending.length} requests</span>} />
        {pending.length === 0 ? (
          <Card className="p-12 text-center">
            <CheckCircle2 className="w-8 h-8 mx-auto mb-3 text-success opacity-70" />
            <h3 className="text-sm font-semibold">All caught up</h3>
            <p className="text-xs text-muted-foreground mt-1">No deployments waiting for approval.</p>
          </Card>
        ) : (
          pending.map((d) => {
            const svc = services.find((s) => s.id === d.serviceId);
            const author = people.find((p) => p.id === d.authorId);
            const approvers = d.approverIds.map((id) => people.find((p) => p.id === id)).filter(Boolean);
            const isHighRisk = d.riskScore > 50;
            return (
              <Card key={d.id} className={`p-5 space-y-4 ${isHighRisk ? "border-destructive/30 bg-destructive/5" : "border-warning/20"}`}>
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${isHighRisk ? "bg-destructive/15 border border-destructive/30" : "bg-warning/15 border border-warning/30"}`}>
                      {isHighRisk ? <ShieldAlert className="w-5 h-5 text-destructive" /> : <AlertTriangle className="w-5 h-5 text-warning-foreground" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <Link href={`/deployments/${d.id}`} className="font-mono text-sm font-semibold text-primary hover:underline">{d.ref}</Link>
                        <DeploymentStatusBadge status={d.status} />
                        {svc && <TierBadge tier={svc.tier} />}
                        {isHighRisk && <span className="text-[10px] uppercase tracking-wider font-semibold text-destructive bg-destructive/15 px-2 py-0.5 rounded">High Risk</span>}
                      </div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium">{svc?.name}</span>
                        <span className="text-muted-foreground">·</span>
                        <span className="font-mono text-xs">{d.version}</span>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">{d.commitMessage}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Button variant="outline" size="sm" className="gap-1.5 h-8 text-destructive hover:text-destructive" onClick={() => openDialog(d.id, "reject")}>
                      <X className="w-3.5 h-3.5" /> Reject
                    </Button>
                    <Button size="sm" className="gap-1.5 h-8" onClick={() => openDialog(d.id, "approve")}>
                      <ThumbsUp className="w-3.5 h-3.5" /> Approve
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-border text-xs">
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Risk Score</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <div className={`w-2 h-2 rounded-full ${d.riskScore > 60 ? "bg-destructive" : d.riskScore > 30 ? "bg-warning" : "bg-success"}`} />
                      <span className="font-mono font-semibold">{d.riskScore}/100</span>
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Strategy</div>
                    <div className="capitalize mt-0.5">{d.strategy.replace("_", " ")}</div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Requested By</div>
                    {author && (
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <img src={author.avatarUrl} alt={author.name} className="w-4 h-4 rounded-full object-cover" />
                        <span className="truncate">{author.name}</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Required Approvers</div>
                    <div className="flex items-center gap-1 mt-0.5">
                      {approvers.map((p) => p && (
                        <img key={p.id} src={p.avatarUrl} alt={p.name} title={p.name} className="w-4 h-4 rounded-full object-cover border border-background" />
                      ))}
                      <span className="text-[10px] text-muted-foreground">({d.approverIds.length})</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  Requested {new Date(d.startedAt).toLocaleString()} · {d.changesCount} files changed · PRs: {d.prIds.join(", ") || "none"}
                </div>
              </Card>
            );
          })
        )}
      </div>

      {/* Decision dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {dialogMode === "approve" ? <ThumbsUp className="w-4 h-4 text-success" /> : <X className="w-4 h-4 text-destructive" />}
              {dialogMode === "approve" ? "Approve Deployment" : "Reject Deployment"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-md border p-3 text-xs space-y-1">
              {activeId && (() => {
                const d = deployments.find((x) => x.id === activeId);
                const svc = services.find((s) => s.id === d?.serviceId);
                return (
                  <>
                    <div className="font-mono font-semibold">{d?.ref} · {svc?.name} · {d?.version}</div>
                    <div className="text-muted-foreground line-clamp-2">{d?.commitMessage}</div>
                  </>
                );
              })()}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="comment" className="text-xs">
                {dialogMode === "approve" ? "Approval comment (optional)" : "Reason for rejection (required)"}
              </Label>
              <Textarea
                id="comment"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder={dialogMode === "approve" ? "e.g. LGTM, low-risk changes" : "e.g. PR review not complete, missing tests"}
                className="text-sm min-h-[80px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button
              size="sm"
              variant={dialogMode === "approve" ? "default" : "destructive"}
              onClick={submitDecision}
              disabled={dialogMode === "reject" && !comment.trim()}
              className="gap-1.5"
            >
              {dialogMode === "approve" ? <ThumbsUp className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
              {dialogMode === "approve" ? "Confirm Approval" : "Confirm Rejection"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
