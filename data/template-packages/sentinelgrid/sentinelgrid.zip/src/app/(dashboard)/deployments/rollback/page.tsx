"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  RotateCcw, History, AlertTriangle, CheckCircle2, X, GitBranch,
  ChevronDown,
} from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { deployments, services, people, incidents } from "@/lib/data";
import { DeploymentStatusBadge, TierBadge } from "@/components/common/badges";
import { toast } from "sonner";

interface RollbackRecord {
  deployment: typeof deployments[number];
  reason: string;
  initiatorId: string;
  rolledBackAt: string;
  impact: string;
}

export default function RollbackCenterPage() {
  const [service, setService] = React.useState<string>("");
  const [version, setVersion] = React.useState<string>("");

  const rolledBackDeployments = deployments.filter((d) => d.status === "rolled_back" || d.status === "failed");

  // Build mock rollback history
  const rollbackHistory: RollbackRecord[] = rolledBackDeployments.map((d, i) => ({
    deployment: d,
    reason: i === 0 ? "Error rate spiked to 4.2% during 10% canary" : "Customer-facing test failures in smoke tests",
    initiatorId: d.authorId,
    rolledBackAt: d.completedAt ?? d.startedAt,
    impact: i === 0 ? "12 minutes of elevated errors, ~340 users affected" : "No customer impact - rolled back pre-production",
  }));

  // Versions for selected service
  const versions = React.useMemo(() => {
    if (!service) return [];
    return deployments
      .filter((d) => d.serviceId === service)
      .map((d) => ({ version: d.version, ref: d.ref, status: d.status }));
  }, [service]);

  function handleQuickRollback() {
    if (!service || !version) {
      toast.error("Select a service and version to rollback");
      return;
    }
    const svc = services.find((s) => s.id === service);
    toast.success(`Rollback initiated: ${svc?.name} to ${version}`);
    setService("");
    setVersion("");
  }

  return (
    <PageContainer>
      <PageHeader
        title="Rollback Center"
        description="Trigger quick rollbacks and review rollback history with impact analysis across all services."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Rollback" }]}
        icon={<RotateCcw className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Rollbacks (30d)" value={rollbackHistory.length} hint="last 30 days" icon={<RotateCcw className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Avg Time to Rollback" value="4m 12s" hint="detection → revert" icon={<History className="w-4 h-4" />} accent="info" />
        <KpiCard label="Auto-Rollbacks" value={1} hint="triggered by SLO alerts" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Successful Recoveries" value={rollbackHistory.length} hint="all stable post-rollback" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Quick Rollback form */}
        <Card className="p-5 space-y-4 border-warning/20">
          <SectionHeading title="Quick Rollback" description="Revert to a previous version" />
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="service" className="text-xs">Service</Label>
              <Select value={service} onValueChange={(v) => { setService(v); setVersion(""); }}>
                <SelectTrigger id="service" className="h-9">
                  <SelectValue placeholder="Select a service" />
                </SelectTrigger>
                <SelectContent>
                  {services.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      <span className="flex items-center gap-2">
                        <TierBadge tier={s.tier} />
                        {s.name}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="version" className="text-xs">Target Version</Label>
              <Select value={version} onValueChange={setVersion} disabled={!service}>
                <SelectTrigger id="version" className="h-9">
                  <SelectValue placeholder={service ? "Select a version" : "Select service first"} />
                </SelectTrigger>
                <SelectContent>
                  {versions.map((v) => (
                    <SelectItem key={v.version} value={v.version}>
                      <span className="flex items-center gap-2 font-mono text-xs">
                        {v.version}
                        <span className="text-[10px] text-muted-foreground">({v.ref})</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-md border border-warning/30 bg-warning/5 p-3 text-[11px] text-muted-foreground">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-3.5 h-3.5 text-warning-foreground mt-0.5 shrink-0" />
                <div>
                  <span className="font-medium text-foreground">Rollback impact:</span> All active instances of <span className="font-mono">{services.find((s) => s.id === service)?.name ?? "selected service"}</span> will be reverted to <span className="font-mono">{version || "selected version"}</span>. In-flight requests will be drained.
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1 h-9 gap-1.5" onClick={() => { setService(""); setVersion(""); }}>
                <X className="w-3.5 h-3.5" /> Clear
              </Button>
              <Button size="sm" className="flex-1 h-9 gap-1.5" variant="destructive" onClick={handleQuickRollback} disabled={!service || !version}>
                <RotateCcw className="w-3.5 h-3.5" /> Rollback Now
              </Button>
            </div>
          </div>
        </Card>

        {/* Rollback history */}
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading
            title="Rollback History"
            description="Most recent rollbacks with reasons and impact"
            action={<span className="text-xs text-muted-foreground">{rollbackHistory.length} records</span>}
          />
          <div className="space-y-3">
            {rollbackHistory.length === 0 ? (
              <div className="text-center text-xs text-muted-foreground py-8">
                <History className="w-6 h-6 mx-auto mb-2 opacity-50" />
                No rollbacks in the last 30 days
              </div>
            ) : rollbackHistory.map((r) => {
              const svc = services.find((s) => s.id === r.deployment.serviceId);
              const initiator = people.find((p) => p.id === r.initiatorId);
              return (
                <div key={r.deployment.id} className="p-4 rounded-lg border space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-md bg-warning/15 border border-warning/30 flex items-center justify-center shrink-0">
                        <RotateCcw className="w-4 h-4 text-warning-foreground" />
                      </div>
                      <div className="min-w-0">
                        <Link href={`/deployments/${r.deployment.id}`} className="font-mono text-xs font-semibold text-primary hover:underline">
                          {r.deployment.ref}
                        </Link>
                        <div className="flex items-center gap-2 mt-0.5">
                          {svc && <TierBadge tier={svc.tier} />}
                          <span className="text-sm font-medium">{svc?.name}</span>
                          <span className="text-[10px] text-muted-foreground">rolled back from</span>
                          <span className="font-mono text-xs">{r.deployment.version}</span>
                          <span className="text-[10px] text-muted-foreground">to</span>
                          <span className="font-mono text-xs">{r.deployment.previousVersion}</span>
                        </div>
                      </div>
                    </div>
                    <DeploymentStatusBadge status={r.deployment.status} />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Reason</div>
                      <div className="mt-0.5">{r.reason}</div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Impact</div>
                      <div className="mt-0.5 text-muted-foreground">{r.impact}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      {initiator && (
                        <>
                          <img src={initiator.avatarUrl} alt={initiator.name} className="w-5 h-5 rounded-full object-cover" />
                          <div>
                            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Initiator</div>
                            <div className="font-medium">{initiator.name}</div>
                          </div>
                        </>
                      )}
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Rolled Back At</div>
                      <div className="mt-0.5">{new Date(r.rolledBackAt).toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Rollback policy info */}
      <Card className="p-5 space-y-3">
        <SectionHeading title="Rollback Policy" description="Automated and manual rollback rules" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="rounded-md border p-3">
            <div className="flex items-center gap-2 mb-1">
              <AlertTriangle className="w-3.5 h-3.5 text-destructive" />
              <h4 className="text-xs font-semibold">Automatic Triggers</h4>
            </div>
            <ul className="text-[11px] text-muted-foreground space-y-1 list-disc pl-4">
              <li>Error rate &gt; 1% sustained 5m</li>
              <li>p95 latency 3x baseline for 10m</li>
              <li>SLO burn rate &gt; 14.4x (1h window)</li>
            </ul>
          </div>
          <div className="rounded-md border p-3">
            <div className="flex items-center gap-2 mb-1">
              <GitBranch className="w-3.5 h-3.5 text-info-foreground" />
              <h4 className="text-xs font-semibold">Strategy-Aware</h4>
            </div>
            <ul className="text-[11px] text-muted-foreground space-y-1 list-disc pl-4">
              <li>Canary: rollback to 0% in &lt; 30s</li>
              <li>Rolling: pause + revert in-flight batch</li>
              <li>Blue/green: instant traffic swap</li>
            </ul>
          </div>
          <div className="rounded-md border p-3">
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-success" />
              <h4 className="text-xs font-semibold">Post-Rollback</h4>
            </div>
            <ul className="text-[11px] text-muted-foreground space-y-1 list-disc pl-4">
              <li>Auto-create incident if user impact</li>
              <li>Notify on-call and author</li>
              <li>Require postmortem within 48h</li>
            </ul>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
