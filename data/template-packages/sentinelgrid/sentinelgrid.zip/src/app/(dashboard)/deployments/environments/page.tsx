"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Server, Cloud, Activity, CheckCircle2, AlertTriangle, Plus, ArrowUpRight,
} from "lucide-react";
import { services, hosts, deployments, k8sClusters } from "@/lib/data";
import { StatusDot, TierBadge } from "@/components/common/badges";
import type { EnvironmentName } from "@/lib/types";
import { toast } from "sonner";

interface EnvSummary {
  name: EnvironmentName;
  description: string;
  serviceCount: number;
  hostCount: number;
  podCount: number;
  lastDeployAt: string;
  lastDeployRef: string;
  status: "healthy" | "warning" | "critical";
  healthScore: number;
  incidents: number;
  clusterName?: string;
}

const envMeta: Record<EnvironmentName, { description: string; icon: React.ReactNode; tone: string }> = {
  production: { description: "Customer-facing environment. Tier 1 services, multi-region, strict change windows.", icon: <Cloud className="w-5 h-5" />, tone: "border-destructive/20" },
  staging: { description: "Pre-production integration. Mirrors prod topology with synthetic data.", icon: <Server className="w-5 h-5" />, tone: "border-warning/20" },
  development: { description: "Engineering workspace. Ephemeral environments per branch.", icon: <Activity className="w-5 h-5" />, tone: "border-info/20" },
  preview: { description: "Per-PR preview environments for design review and QA.", icon: <CheckCircle2 className="w-5 h-5" />, tone: "border-primary/20" },
};

export default function EnvironmentsPage() {
  const environments: EnvSummary[] = (["production", "staging", "development", "preview"] as EnvironmentName[]).map((name) => {
    const envHosts = hosts.filter((h) => h.environment === name);
    const envServices = services.filter((s) => s.environment === name || (name === "production" && s.tier === "tier1"));
    const envDeployments = deployments.filter((d) => d.environment === name);
    const latest = envDeployments.sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())[0];
    const cluster = k8sClusters.find((c) => c.name.includes(name === "production" ? "prod" : name));
    const healthScore = name === "production"
      ? Math.round(services.filter((s) => s.tier === "tier1").reduce((sum, s) => sum + s.healthScore, 0) / services.filter((s) => s.tier === "tier1").length)
      : name === "staging" ? 92 : 88;
    return {
      name,
      description: envMeta[name].description,
      serviceCount: envServices.length || (name === "production" ? services.length : Math.max(2, Math.floor(services.length / 2))),
      hostCount: envHosts.length || (name === "production" ? hosts.length : Math.max(2, Math.floor(hosts.length / 3))),
      podCount: cluster?.podCount ?? (name === "production" ? 1188 : name === "staging" ? 96 : 24),
      lastDeployAt: latest?.startedAt ?? new Date().toISOString(),
      lastDeployRef: latest?.ref ?? "—",
      status: healthScore >= 95 ? "healthy" : healthScore >= 80 ? "warning" : "critical",
      healthScore,
      incidents: name === "production" ? 1 : 0,
      clusterName: cluster?.name,
    };
  });

  const totalServices = environments.reduce((s, e) => s + e.serviceCount, 0);
  const totalHosts = environments.reduce((s, e) => s + e.hostCount, 0);
  const healthyEnvs = environments.filter((e) => e.status === "healthy").length;
  const avgHealth = Math.round(environments.reduce((s, e) => s + e.healthScore, 0) / environments.length);

  return (
    <PageContainer>
      <PageHeader
        title="Environments"
        description="Health and topology summary for each environment, from production through preview."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Environments" }]}
        icon={<Server className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("New environment provisioning started")}>
            <Plus className="w-3.5 h-3.5" />
            New Environment
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Environments" value={environments.length} hint="across all tiers" icon={<Server className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Total Services" value={totalServices} hint="across all envs" icon={<Activity className="w-4 h-4" />} accent="info" />
        <KpiCard label="Total Hosts" value={totalHosts} hint="running instances" icon={<Cloud className="w-4 h-4" />} accent="success" />
        <KpiCard label="Avg Health" value={`${avgHealth}/100`} hint={`${healthyEnvs} of ${environments.length} healthy`} icon={<CheckCircle2 className="w-4 h-4" />} accent={avgHealth >= 90 ? "success" : "warning"} />
      </div>

      {/* Environment cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {environments.map((env) => {
          const meta = envMeta[env.name];
          const statusColor = env.status === "healthy" ? "success" : env.status === "warning" ? "warning" : "destructive";
          return (
            <Card key={env.name} className={`p-5 space-y-4 border-l-4 ${meta.tone} border-l-${statusColor}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 bg-${statusColor}/15 border border-${statusColor}/30 text-${statusColor}`}>
                    {meta.icon}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className="text-sm font-semibold capitalize">{env.name}</h3>
                      <StatusDot color={statusColor} pulse={env.status !== "healthy"} size="md" />
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-2">{env.description}</p>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Health</div>
                  <div className={`text-2xl font-bold tabular-nums ${env.status === "healthy" ? "text-success" : env.status === "warning" ? "text-warning-foreground" : "text-destructive"}`}>
                    {env.healthScore}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-3">
                <div className="rounded-md border p-2.5">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Services</div>
                  <div className="text-lg font-semibold tabular-nums">{env.serviceCount}</div>
                </div>
                <div className="rounded-md border p-2.5">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Hosts</div>
                  <div className="text-lg font-semibold tabular-nums">{env.hostCount}</div>
                </div>
                <div className="rounded-md border p-2.5">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Pods</div>
                  <div className="text-lg font-semibold tabular-nums">{env.podCount}</div>
                </div>
                <div className="rounded-md border p-2.5">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Incidents</div>
                  <div className={`text-lg font-semibold tabular-nums ${env.incidents > 0 ? "text-destructive" : "text-success"}`}>{env.incidents}</div>
                </div>
              </div>

              <div className="space-y-2 pt-3 border-t border-border">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Last deployment</span>
                  <span className="font-mono">{new Date(env.lastDeployAt).toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Reference</span>
                  <span className="font-mono text-primary">{env.lastDeployRef}</span>
                </div>
                {env.clusterName && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Cluster</span>
                    <span className="font-mono text-[11px]">{env.clusterName}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 pt-2">
                <Button asChild variant="outline" size="sm" className="flex-1 h-8 text-xs gap-1.5">
                  <Link href={`/deployments?env=${env.name}`}>
                    <Activity className="w-3 h-3" /> View Deployments
                  </Link>
                </Button>
                <Button asChild variant="ghost" size="sm" className="h-8 text-xs gap-1">
                  <Link href="/services">
                    Services <ArrowUpRight className="w-3 h-3" />
                  </Link>
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Environment health summary */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Environment Health Summary" description="Comparative posture across environments" />
        <div className="space-y-3">
          {environments.map((env) => {
            const statusColor = env.status === "healthy" ? "success" : env.status === "warning" ? "warning" : "destructive";
            return (
              <div key={env.name} className="grid grid-cols-12 gap-3 items-center">
                <div className="col-span-3 flex items-center gap-2 min-w-0">
                  <StatusDot color={statusColor} pulse={env.status !== "healthy"} />
                  <span className="text-sm font-medium capitalize truncate">{env.name}</span>
                </div>
                <div className="col-span-6">
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className={env.status === "healthy" ? "bg-success" : env.status === "warning" ? "bg-warning" : "bg-destructive"}
                      style={{ width: `${env.healthScore}%` }}
                    />
                  </div>
                </div>
                <div className="col-span-3 text-right">
                  <span className={`font-mono text-sm font-semibold ${env.status === "healthy" ? "text-success" : env.status === "warning" ? "text-warning-foreground" : "text-destructive"}`}>
                    {env.healthScore}/100
                  </span>
                  <span className="text-[10px] text-muted-foreground ml-2">{env.serviceCount} services</span>
                </div>
              </div>
            );
          })}
        </div>
        <div className="grid grid-cols-3 gap-3 pt-3 border-t border-border">
          <div className="text-center">
            <div className="text-2xl font-bold text-success tabular-nums">{environments.filter((e) => e.status === "healthy").length}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Healthy</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-warning-foreground tabular-nums">{environments.filter((e) => e.status === "warning").length}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Warning</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-destructive tabular-nums">{environments.filter((e) => e.status === "critical").length}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Critical</div>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
