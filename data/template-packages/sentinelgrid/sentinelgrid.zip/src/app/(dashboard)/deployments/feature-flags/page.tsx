"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Flag, ToggleRight, Percent, Clock, Plus, Download, Settings2, Users,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { featureFlags, services, people } from "@/lib/data";
import { TierBadge } from "@/components/common/badges";
import type { FeatureFlag } from "@/lib/types";
import { toast } from "sonner";

interface FlagRow extends FeatureFlag {
  serviceName: string;
  ownerName: string;
  ownerAvatar?: string;
}

export default function FeatureFlagsPage() {
  const [flags, setFlags] = React.useState<FeatureFlag[]>(featureFlags);
  const [editFlag, setEditFlag] = React.useState<FlagRow | null>(null);
  const [editRollout, setEditRollout] = React.useState<number>(100);

  const rows: FlagRow[] = flags.map((f) => {
    const svc = services.find((s) => s.id === f.serviceId);
    const owner = people.find((p) => p.id === f.owner);
    return {
      ...f,
      serviceName: svc?.name ?? "—",
      ownerName: owner?.name ?? "—",
      ownerAvatar: owner?.avatarUrl,
    };
  });

  const enabled = flags.filter((f) => f.enabled).length;
  const avgRollout = Math.round(flags.reduce((s, f) => s + f.rolloutPercent, 0) / flags.length);
  const now = Date.now();
  const recentlyModified = flags.filter((f) => (now - new Date(f.lastModified).getTime()) < 7 * 86400000).length;

  function toggleFlag(id: string, enabled: boolean) {
    setFlags((prev) => prev.map((f) => f.id === id ? { ...f, enabled, lastModified: new Date().toISOString() } : f));
    const flag = flags.find((f) => f.id === id);
    toast.success(`${flag?.name} ${enabled ? "enabled" : "disabled"}`, { description: flag?.key });
  }

  function openEdit(row: FlagRow) {
    setEditFlag(row);
    setEditRollout(row.rolloutPercent);
  }

  function saveEdit() {
    if (!editFlag) return;
    setFlags((prev) => prev.map((f) => f.id === editFlag.id ? { ...f, rolloutPercent: editRollout, lastModified: new Date().toISOString() } : f));
    toast.success(`${editFlag.name} rollout updated to ${editRollout}%`);
    setEditFlag(null);
  }

  const columns: Column<FlagRow>[] = [
    {
      key: "key",
      header: "Key",
      sortable: true,
      sortValue: (r) => r.key,
      cell: (r) => (
        <div className="min-w-0">
          <div className="font-mono text-xs font-semibold">{r.key}</div>
          <div className="text-[10px] text-muted-foreground line-clamp-1">{r.description}</div>
        </div>
      ),
    },
    {
      key: "name",
      header: "Name",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => <span className="text-sm font-medium">{r.name}</span>,
      hideOnMobile: true,
    },
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => r.serviceName,
      cell: (r) => {
        const svc = services.find((s) => s.id === r.serviceId);
        return (
          <div className="flex items-center gap-2">
            <span className="text-xs">{r.serviceName}</span>
            {svc && <TierBadge tier={svc.tier} />}
          </div>
        );
      },
      filterable: true,
      filterOptions: services.map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.serviceId === v,
      hideOnMobile: true,
    },
    {
      key: "enabled",
      header: "Enabled",
      cell: (r) => (
        <Switch
          checked={r.enabled}
          onCheckedChange={(checked) => toggleFlag(r.id, checked)}
          aria-label={`Toggle ${r.name}`}
        />
      ),
    },
    {
      key: "rolloutPercent",
      header: "Rollout",
      sortable: true,
      sortValue: (r) => r.rolloutPercent,
      cell: (r) => (
        <div className="w-24 space-y-1">
          <span className={`font-mono text-xs font-semibold ${r.rolloutPercent === 100 ? "text-success" : r.rolloutPercent > 0 ? "text-warning-foreground" : "text-muted-foreground"}`}>
            {r.rolloutPercent}%
          </span>
          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className={r.rolloutPercent === 100 ? "bg-success" : "bg-warning"}
              style={{ width: `${r.rolloutPercent}%` }}
            />
          </div>
        </div>
      ),
      align: "right",
    },
    {
      key: "environments",
      header: "Environments",
      cell: (r) => (
        <div className="flex items-center gap-1 flex-wrap">
          {r.environments.map((e) => (
            <span key={e} className="text-[10px] px-1.5 py-0.5 rounded border border-border text-muted-foreground capitalize">{e}</span>
          ))}
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "owner",
      header: "Owner",
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          {r.ownerAvatar && <img src={r.ownerAvatar} alt={r.ownerName} className="w-5 h-5 rounded-full object-cover" />}
          <span className="text-xs truncate hidden md:inline">{r.ownerName}</span>
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "lastModified",
      header: "Last Modified",
      sortable: true,
      sortValue: (r) => r.lastModified,
      cell: (r) => <span className="text-xs text-muted-foreground">{new Date(r.lastModified).toLocaleDateString()}</span>,
      hideOnMobile: true,
    },
    {
      key: "actions",
      header: "",
      cell: (r) => (
        <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={(e) => { e.stopPropagation(); openEdit(r); }} aria-label="Edit flag">
          <Settings2 className="w-3.5 h-3.5" />
        </Button>
      ),
      align: "right",
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Feature Flags"
        description="Toggle features on or off, control rollout percentages, and manage environments across all services."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Feature Flags" }]}
        icon={<Flag className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New flag composer opened")}>
              <Plus className="w-3.5 h-3.5" />
              New Flag
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Flags" value={flags.length} hint="across all services" icon={<Flag className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Enabled" value={enabled} hint={`${Math.round((enabled / flags.length) * 100)}% of total`} icon={<ToggleRight className="w-4 h-4" />} accent="success" />
        <KpiCard label="Avg Rollout" value={`${avgRollout}%`} hint="across enabled flags" icon={<Percent className="w-4 h-4" />} accent="info" />
        <KpiCard label="Recently Modified" value={recentlyModified} hint="in last 7 days" icon={<Clock className="w-4 h-4" />} accent="warning" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="All Feature Flags"
          description="Toggle the switch to enable/disable. Click settings to edit rollout."
          action={<span className="text-xs text-muted-foreground">{flags.length} flags</span>}
        />
        <DataTable
          columns={columns}
          data={rows}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.key, (r) => r.name, (r) => r.serviceName, (r) => r.description]}
          searchPlaceholder="Search by key, name, service..."
          pageSize={10}
          onRowClick={(r) => openEdit(r)}
        />
      </Card>

      {/* Edit modal */}
      <Dialog open={!!editFlag} onOpenChange={(open) => !open && setEditFlag(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Feature Flag</DialogTitle>
          </DialogHeader>
          {editFlag && (
            <div className="space-y-4">
              <div className="rounded-md border p-3 space-y-1">
                <div className="font-mono text-xs font-semibold">{editFlag.key}</div>
                <div className="text-sm font-medium">{editFlag.name}</div>
                <div className="text-[11px] text-muted-foreground">{editFlag.description}</div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="rollout" className="text-xs">Rollout Percentage</Label>
                  <span className="font-mono text-sm font-semibold tabular-nums">{editRollout}%</span>
                </div>
                <Slider
                  id="rollout"
                  value={[editRollout]}
                  onValueChange={(v) => setEditRollout(v[0])}
                  min={0}
                  max={100}
                  step={5}
                  className="w-full"
                />
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>0% (off)</span>
                  <span>50% (half)</span>
                  <span>100% (full)</span>
                </div>
              </div>

              {/* Variants */}
              {editFlag.variants.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-xs">Variants</Label>
                  <div className="space-y-1.5">
                    {editFlag.variants.map((v) => (
                      <div key={v.name} className="flex items-center justify-between p-2 rounded-md border text-xs">
                        <span className="font-mono">{v.name}</span>
                        <span className="font-mono tabular-nums">{v.weight}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Service</div>
                  <div>{editFlag.serviceName}</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Owner</div>
                  <div className="flex items-center gap-1.5">
                    {editFlag.ownerAvatar && <img src={editFlag.ownerAvatar} alt="" className="w-4 h-4 rounded-full object-cover" />}
                    {editFlag.ownerName}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Environments</div>
                  <div className="flex items-center gap-1 mt-0.5">
                    {editFlag.environments.map((e) => (
                      <span key={e} className="text-[10px] px-1.5 py-0.5 rounded border border-border capitalize">{e}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Created</div>
                  <div>{new Date(editFlag.createdAt).toLocaleDateString()}</div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setEditFlag(null)}>Cancel</Button>
            <Button size="sm" onClick={saveEdit} className="gap-1.5">
              <Users className="w-3.5 h-3.5" /> Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
