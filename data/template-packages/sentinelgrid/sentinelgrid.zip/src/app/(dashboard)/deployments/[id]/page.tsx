"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Rocket, ArrowLeft, GitCommit, GitPullRequest, CheckCircle2, XCircle, Clock,
  AlertTriangle, RotateCcw, Pause, ThumbsUp, Activity, TrendingUp, TrendingDown,
  Users,
} from "lucide-react";
import { deployments, services, people, incidents } from "@/lib/data";
import { DeploymentStatusBadge, TierBadge, SeverityBadge, IncidentStatusBadge } from "@/components/common/badges";
import { toast } from "sonner";

const STAGE_STATUS_ICON = {
  succeeded: <CheckCircle2 className="w-3.5 h-3.5 text-success" />,
  failed: <XCircle className="w-3.5 h-3.5 text-destructive" />,
  in_progress: <Clock className="w-3.5 h-3.5 text-info-foreground animate-spin" style={{ animationDuration: "3s" }} />,
  queued: <Clock className="w-3.5 h-3.5 text-muted-foreground" />,
  rolling_out: <Activity className="w-3.5 h-3.5 text-info-foreground" />,
  canary: <Activity className="w-3.5 h-3.5 text-accent-foreground" />,
  halted: <AlertTriangle className="w-3.5 h-3.5 text-warning-foreground" />,
  rolled_back: <RotateCcw className="w-3.5 h-3.5 text-warning-foreground" />,
  approved: <ThumbsUp className="w-3.5 h-3.5 text-success" />,
  pending_approval: <Clock className="w-3.5 h-3.5 text-warning-foreground" />,
};

export default function DeploymentDetailsPage() {
  const params = useParams<{ id: string }>();
  const deployment = deployments.find((d) => d.id === params.id) ?? deployments[0];
  const svc = services.find((s) => s.id === deployment.serviceId);
  const author = people.find((p) => p.id === deployment.authorId);
  const approvers = deployment.approverIds.map((id) => people.find((p) => p.id === id)).filter(Boolean);
  const linkedIncidents = deployment.incidentsTriggered
    .map((id) => incidents.find((i) => i.id === id))
    .filter(Boolean);

  const errDelta = deployment.metrics.errorRateAfter - deployment.metrics.errorRateBefore;
  const p95Delta = deployment.metrics.p95LatencyAfter - deployment.metrics.p95LatencyBefore;
  const errWorse = errDelta > 0;
  const p95Worse = p95Delta > 0;

  const inProgress = ["in_progress", "rolling_out", "canary", "queued", "pending_approval"].includes(deployment.status);

  return (
    <PageContainer>
      <PageHeader
        title={deployment.ref}
        description={deployment.commitMessage}
        breadcrumbs={[
          { label: "Deployments", href: "/deployments" },
          { label: deployment.ref },
        ]}
        icon={<Rocket className="w-5 h-5" />}
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/deployments"><ArrowLeft className="w-3.5 h-3.5" /> Back</Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Deployment halted")}>
              <Pause className="w-3.5 h-3.5" /> Halt
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive" onClick={() => toast.success("Rollback initiated")}>
              <RotateCcw className="w-3.5 h-3.5" /> Rollback
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Deployment approved")}>
              <ThumbsUp className="w-3.5 h-3.5" /> Approve
            </Button>
          </>
        }
      />

      {/* Hero */}
      <Card className="p-6 space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Service</div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm font-medium">{svc?.name}</span>
              {svc && <TierBadge tier={svc.tier} />}
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Version</div>
            <div className="font-mono text-sm mt-1">{deployment.version}</div>
            <div className="text-[10px] text-muted-foreground">prev: {deployment.previousVersion}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Status</div>
            <div className="mt-1"><DeploymentStatusBadge status={deployment.status} /></div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Environment</div>
            <div className="text-sm font-medium mt-1 capitalize">{deployment.environment}</div>
            <div className="text-[10px] text-muted-foreground">{deployment.region}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Strategy</div>
            <div className="text-sm font-medium capitalize mt-1">{deployment.strategy.replace("_", " ")}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Risk Score</div>
            <div className="flex items-center gap-2 mt-1">
              <div className={`w-2 h-2 rounded-full ${deployment.riskScore > 60 ? "bg-destructive" : deployment.riskScore > 30 ? "bg-warning" : "bg-success"}`} />
              <span className="font-mono text-sm font-semibold">{deployment.riskScore}/100</span>
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Started</div>
            <div className="text-xs mt-1">{new Date(deployment.startedAt).toLocaleString()}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Duration</div>
            <div className="font-mono text-sm mt-1">
              {deployment.duration > 0 ? `${Math.floor(deployment.duration / 60)}m ${deployment.duration % 60}s` : "in flight"}
            </div>
          </div>
        </div>

        {/* Rollout progress */}
        {inProgress && (
          <div className="space-y-2 pt-4 border-t border-border">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium">Rollout Progress</span>
              <span className="font-mono tabular-nums">{deployment.rolloutPercent}%</span>
            </div>
            <Progress value={deployment.rolloutPercent} className="h-2" />
          </div>
        )}
      </Card>

      {/* Pipeline visualization */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Pipeline" description="Stage-by-stage execution status" />
        <div className="flex items-stretch gap-2 overflow-x-auto pb-2">
          {deployment.stages.map((stage, i) => (
            <React.Fragment key={i}>
              <div className="flex flex-col items-center min-w-[140px] gap-2 p-3 rounded-lg border bg-card">
                <div className="flex items-center gap-1.5">
                  {STAGE_STATUS_ICON[stage.status as keyof typeof STAGE_STATUS_ICON] ?? <Clock className="w-3.5 h-3.5 text-muted-foreground" />}
                  <span className="text-xs font-medium">{stage.name}</span>
                </div>
                <div className={`text-[10px] uppercase tracking-wider font-semibold ${
                  stage.status === "succeeded" ? "text-success" :
                  stage.status === "failed" ? "text-destructive" :
                  stage.status === "in_progress" || stage.status === "rolling_out" ? "text-info-foreground" :
                  stage.status === "queued" ? "text-muted-foreground" :
                  "text-muted-foreground"
                }`}>
                  {stage.status.replace("_", " ")}
                </div>
                {stage.startedAt && (
                  <div className="text-[9px] text-muted-foreground text-center">
                    {new Date(stage.startedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    {stage.completedAt && (
                      <div>→ {new Date(stage.completedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
                    )}
                  </div>
                )}
              </div>
              {i < deployment.stages.length - 1 && (
                <div className="flex items-center text-muted-foreground">
                  <div className={`w-6 h-px ${deployment.stages[i].status === "succeeded" ? "bg-success" : "bg-border"}`} />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Commit info */}
        <Card className="p-5 space-y-4">
          <SectionHeading title="Commit" description="Source revision details" />
          <div className="space-y-3">
            <div className="flex items-start gap-2">
              <GitCommit className="w-4 h-4 text-primary mt-0.5 shrink-0" />
              <div className="min-w-0">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">SHA</div>
                <div className="font-mono text-sm">{deployment.commitSha}</div>
              </div>
            </div>
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Message</div>
              <p className="text-xs font-mono bg-muted rounded-md p-2.5">{deployment.commitMessage}</p>
            </div>
            {author && (
              <div className="flex items-center gap-2 pt-1">
                <img src={author.avatarUrl} alt={author.name} className="w-6 h-6 rounded-full object-cover" />
                <div>
                  <div className="text-xs font-medium">{author.name}</div>
                  <div className="text-[10px] text-muted-foreground">{author.title}</div>
                </div>
              </div>
            )}
            {deployment.prIds.length > 0 && (
              <div className="space-y-1.5 pt-2 border-t border-border">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Linked PRs</div>
                {deployment.prIds.map((pr) => (
                  <a key={pr} href="#" className="flex items-center gap-1.5 text-xs text-primary hover:underline" onClick={(e) => { e.preventDefault(); toast.success(`Opening ${pr}`); }}>
                    <GitPullRequest className="w-3 h-3" /> {pr}
                  </a>
                ))}
              </div>
            )}
          </div>
        </Card>

        {/* Approvers */}
        <Card className="p-5 space-y-4">
          <SectionHeading title="Approvers" description="Required sign-offs" />
          <div className="space-y-2">
            {approvers.map((p) => p && (
              <div key={p.id} className="flex items-center justify-between gap-2 p-2.5 rounded-md border">
                <div className="flex items-center gap-2 min-w-0">
                  <img src={p.avatarUrl} alt={p.name} className="w-6 h-6 rounded-full object-cover" />
                  <div className="min-w-0">
                    <div className="text-xs font-medium truncate">{p.name}</div>
                    <div className="text-[10px] text-muted-foreground">{p.title}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-[10px] text-success">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Approved</span>
                </div>
              </div>
            ))}
            {approvers.length === 0 && (
              <div className="text-center text-xs text-muted-foreground py-4">No approvers required</div>
            )}
          </div>
          <div className="text-[10px] text-muted-foreground pt-2 border-t border-border flex items-center gap-1.5">
            <Users className="w-3 h-3" /> {deployment.changesCount} files changed
          </div>
        </Card>

        {/* Metrics comparison */}
        <Card className="p-5 space-y-4">
          <SectionHeading title="Metrics Comparison" description="Before vs after deployment" />
          <div className="space-y-3">
            <div className="rounded-lg border p-3 space-y-2">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Error Rate</div>
              <div className="flex items-center justify-between">
                <div className="flex items-baseline gap-2">
                  <span className="text-xs text-muted-foreground">Before:</span>
                  <span className="font-mono text-sm">{deployment.metrics.errorRateBefore}%</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-xs text-muted-foreground">After:</span>
                  <span className={`font-mono text-sm font-semibold ${errWorse ? "text-destructive" : "text-success"}`}>{deployment.metrics.errorRateAfter}%</span>
                </div>
              </div>
              <div className={`flex items-center justify-end gap-1 text-xs ${errWorse ? "text-destructive" : "text-success"}`}>
                {errWorse ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                <span className="font-mono">{errDelta > 0 ? "+" : ""}{errDelta.toFixed(3)}%</span>
              </div>
            </div>
            <div className="rounded-lg border p-3 space-y-2">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">p95 Latency</div>
              <div className="flex items-center justify-between">
                <div className="flex items-baseline gap-2">
                  <span className="text-xs text-muted-foreground">Before:</span>
                  <span className="font-mono text-sm">{deployment.metrics.p95LatencyBefore}ms</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-xs text-muted-foreground">After:</span>
                  <span className={`font-mono text-sm font-semibold ${p95Worse ? "text-destructive" : "text-success"}`}>{deployment.metrics.p95LatencyAfter}ms</span>
                </div>
              </div>
              <div className={`flex items-center justify-end gap-1 text-xs ${p95Worse ? "text-destructive" : "text-success"}`}>
                {p95Worse ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                <span className="font-mono">{p95Delta > 0 ? "+" : ""}{p95Delta}ms</span>
              </div>
            </div>
            <div className="rounded-lg border p-3 space-y-2 bg-muted/30">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Health Verdict</div>
              <div className={`text-sm font-semibold ${errWorse || p95Worse ? "text-warning-foreground" : "text-success"}`}>
                {errWorse || p95Worse ? "Regression detected" : "Healthy - no regressions"}
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Linked incidents */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Linked Incidents"
          description="Incidents triggered by this deployment"
          action={<span className="text-xs text-muted-foreground">{linkedIncidents.length} linked</span>}
        />
        <div className="space-y-2">
          {linkedIncidents.length === 0 ? (
            <div className="text-center text-xs text-muted-foreground py-6">
              <CheckCircle2 className="w-6 h-6 mx-auto mb-2 opacity-50 text-success" />
              No incidents triggered by this deployment
            </div>
          ) : linkedIncidents.map((inc) => inc && (
            <Link key={inc.id} href={`/incidents/${inc.id}`} className="flex items-center justify-between gap-3 p-3 rounded-md border hover:bg-muted/40 transition-colors">
              <div className="flex items-center gap-3 min-w-0">
                <SeverityBadge severity={inc.severity} size="sm" />
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{inc.title}</div>
                  <div className="text-[10px] text-muted-foreground">{inc.ref} · {new Date(inc.startedAt).toLocaleString()}</div>
                </div>
              </div>
              <IncidentStatusBadge status={inc.status} />
            </Link>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
