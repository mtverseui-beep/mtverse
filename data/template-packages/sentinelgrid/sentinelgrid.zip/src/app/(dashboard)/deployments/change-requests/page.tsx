"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  FileText, Clock, CheckCircle2, XCircle, Plus, Download, GitPullRequest,
  Calendar, AlertTriangle,
} from "lucide-react";
import { changeRequests, services, people } from "@/lib/data";
import { TierBadge } from "@/components/common/badges";
import type { ChangeRequest } from "@/lib/types";
import { toast } from "sonner";

const typeConfig: Record<ChangeRequest["type"], { label: string; className: string }> = {
  standard: { label: "Standard", className: "bg-muted text-muted-foreground border-border" },
  normal: { label: "Normal", className: "bg-info/15 text-info-foreground border-info/30" },
  emergency: { label: "Emergency", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

const riskConfig: Record<ChangeRequest["risk"], { label: string; className: string }> = {
  low: { label: "Low", className: "bg-success/15 text-success border-success/30" },
  medium: { label: "Medium", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  high: { label: "High", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

const statusConfig: Record<ChangeRequest["status"], { label: string; className: string }> = {
  draft: { label: "Draft", className: "bg-muted text-muted-foreground border-border" },
  in_review: { label: "In Review", className: "bg-info/15 text-info-foreground border-info/30" },
  approved: { label: "Approved", className: "bg-success/15 text-success border-success/30" },
  rejected: { label: "Rejected", className: "bg-destructive/15 text-destructive border-destructive/30" },
  implemented: { label: "Implemented", className: "bg-success/15 text-success border-success/30" },
};

function TypeBadge({ type }: { type: ChangeRequest["type"] }) {
  const c = typeConfig[type];
  return <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium ${c.className}`}>{c.label}</span>;
}
function RiskBadge({ risk }: { risk: ChangeRequest["risk"] }) {
  const c = riskConfig[risk];
  return <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium ${c.className}`}>{c.label}</span>;
}
function StatusBadge({ status }: { status: ChangeRequest["status"] }) {
  const c = statusConfig[status];
  return <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium ${c.className}`}><span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />{c.label}</span>;
}

export default function ChangeRequestsPage() {
  const pending = changeRequests.filter((c) => c.status === "in_review" || c.status === "draft").length;
  const approved = changeRequests.filter((c) => c.status === "approved").length;
  const implemented = changeRequests.filter((c) => c.status === "implemented").length;
  const rejected = changeRequests.filter((c) => c.status === "rejected").length;

  const columns: Column<ChangeRequest>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => <span className="font-mono text-xs font-semibold text-primary">{r.ref}</span>,
    },
    {
      key: "title",
      header: "Title",
      sortable: true,
      sortValue: (r) => r.title,
      cell: (r) => (
        <div className="min-w-0">
          <div className="text-sm font-medium truncate max-w-md">{r.title}</div>
          <div className="text-[10px] text-muted-foreground line-clamp-1">{r.summary}</div>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => services.find((s) => s.id === r.serviceId)?.name ?? "",
      cell: (r) => {
        const svc = services.find((s) => s.id === r.serviceId);
        return (
          <div className="flex items-center gap-2">
            <span className="text-xs">{svc?.name ?? "—"}</span>
            {svc && <TierBadge tier={svc.tier} />}
          </div>
        );
      },
      filterable: true,
      filterOptions: services.map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.serviceId === v,
      hideOnMobile: true,
    },
    {
      key: "type",
      header: "Type",
      cell: (r) => <TypeBadge type={r.type} />,
      filterable: true,
      filterOptions: [
        { label: "Standard", value: "standard" },
        { label: "Normal", value: "normal" },
        { label: "Emergency", value: "emergency" },
      ],
      filterFn: (r, v) => r.type === (v as ChangeRequest["type"]),
      hideOnMobile: true,
    },
    {
      key: "risk",
      header: "Risk",
      cell: (r) => <RiskBadge risk={r.risk} />,
      filterable: true,
      filterOptions: [
        { label: "Low", value: "low" },
        { label: "Medium", value: "medium" },
        { label: "High", value: "high" },
      ],
      filterFn: (r, v) => r.risk === (v as ChangeRequest["risk"]),
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => <StatusBadge status={r.status} />,
      filterable: true,
      filterOptions: [
        { label: "Draft", value: "draft" },
        { label: "In Review", value: "in_review" },
        { label: "Approved", value: "approved" },
        { label: "Rejected", value: "rejected" },
        { label: "Implemented", value: "implemented" },
      ],
      filterFn: (r, v) => r.status === (v as ChangeRequest["status"]),
    },
    {
      key: "requester",
      header: "Requester",
      cell: (r) => {
        const requester = people.find((p) => p.id === r.requesterId);
        return requester ? (
          <div className="flex items-center gap-1.5">
            <img src={requester.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate hidden md:inline">{requester.name}</span>
          </div>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
      hideOnMobile: true,
    },
    {
      key: "plannedAt",
      header: "Planned",
      sortable: true,
      sortValue: (r) => r.plannedAt,
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <Calendar className="w-3 h-3 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">{new Date(r.plannedAt).toLocaleDateString()}</span>
        </div>
      ),
      hideOnMobile: true,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Change Requests"
        description="Formal change management workflow with risk assessment, approval gates, and implementation tracking."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Change Requests" }]}
        icon={<FileText className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New change request form opened")}>
              <Plus className="w-3.5 h-3.5" />
              New CR
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Pending Review" value={pending} hint="awaiting approval" icon={<Clock className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Approved" value={approved} hint="ready to implement" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Implemented" value={implemented} hint="completed changes" icon={<GitPullRequest className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Rejected" value={rejected} hint="last 30 days" icon={<XCircle className="w-4 h-4" />} accent="destructive" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="All Change Requests"
          description="Filter by type, risk, or status to find what you need"
          action={<span className="text-xs text-muted-foreground">{changeRequests.length} requests</span>}
        />
        <DataTable
          columns={columns}
          data={changeRequests}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.ref, (r) => r.title, (r) => services.find((s) => s.id === r.serviceId)?.name ?? ""]}
          searchPlaceholder="Search by ref, title, service..."
          pageSize={10}
          initialSort={{ key: "plannedAt", dir: "asc" }}
        />
      </Card>

      {/* Emergency changes summary */}
      <Card className="p-5 space-y-3 border-destructive/20">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-destructive" />
          <h3 className="text-sm font-semibold">Emergency Change Window</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {changeRequests.filter((c) => c.type === "emergency").map((c) => {
            const svc = services.find((s) => s.id === c.serviceId);
            const requester = people.find((p) => p.id === c.requesterId);
            return (
              <div key={c.id} className="rounded-md border border-destructive/30 bg-destructive/5 p-3">
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="font-mono text-xs font-semibold">{c.ref}</span>
                  <StatusBadge status={c.status} />
                </div>
                <div className="text-sm font-medium">{c.title}</div>
                <div className="text-[11px] text-muted-foreground mt-1">
                  {svc?.name} · {requester?.name} · {new Date(c.plannedAt).toLocaleString()}
                </div>
              </div>
            );
          })}
          {changeRequests.filter((c) => c.type === "emergency").length === 0 && (
            <div className="col-span-2 text-center text-xs text-muted-foreground py-4">No emergency changes</div>
          )}
        </div>
      </Card>
    </PageContainer>
  );
}
