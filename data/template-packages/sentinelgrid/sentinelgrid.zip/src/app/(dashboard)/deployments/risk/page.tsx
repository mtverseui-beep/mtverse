"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  AlertTriangle, TrendingUp, TrendingDown, Activity, Download, ShieldAlert,
  FileWarning, GitBranch, Code2, TestTube, Users,
} from "lucide-react";
import { Pie, PieChart, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { useChartTheme, ChartTooltip } from "@/components/charts/chart-container";
import { deployments, services, people } from "@/lib/data";
import { TierBadge } from "@/components/common/badges";
import { toast } from "sonner";

interface RiskFactor {
  factor: string;
  description: string;
  icon: React.ReactNode;
  weight: number;
  avgContribution: number;
}

export default function RiskAnalysisPage() {
  const t = useChartTheme();

  const avgRisk = Math.round(deployments.reduce((s, d) => s + d.riskScore, 0) / deployments.length);
  const highRisk = deployments.filter((d) => d.riskScore > 50).length;
  const failed = deployments.filter((d) => d.status === "failed" || d.status === "rolled_back").length;
  const changeFailureRate = Math.round((failed / deployments.length) * 100);

  // Risk distribution
  const low = deployments.filter((d) => d.riskScore <= 30).length;
  const medium = deployments.filter((d) => d.riskScore > 30 && d.riskScore <= 60).length;
  const high = deployments.filter((d) => d.riskScore > 60).length;
  const distribution = [
    { name: "Low (0-30)", value: low, color: t.palette[3] },
    { name: "Medium (31-60)", value: medium, color: t.palette[2] },
    { name: "High (> 60)", value: high, color: t.palette[4] },
  ];

  // Risk trend (last 12 deploys)
  const trend = [...deployments].slice(0, 12).map((d) => ({ ref: d.ref, score: d.riskScore }));

  // Risk factors
  const riskFactors: RiskFactor[] = [
    { factor: "Change Size", description: "Lines of code / files changed", icon: <Code2 className="w-4 h-4" />, weight: 30, avgContribution: Math.round(deployments.reduce((s, d) => s + Math.min(d.changesCount * 2, 30), 0) / deployments.length) },
    { factor: "Files Touched", description: "Number of distinct files modified", icon: <GitBranch className="w-4 h-4" />, weight: 20, avgContribution: Math.round(deployments.reduce((s, d) => s + Math.min(d.changesCount, 20), 0) / deployments.length) },
    { factor: "Test Coverage Delta", description: "Tests added vs removed", icon: <TestTube className="w-4 h-4" />, weight: 15, avgContribution: 8 },
    { factor: "Author Experience", description: "Author's history with service", icon: <Users className="w-4 h-4" />, weight: 15, avgContribution: 6 },
    { factor: "Production Hour", description: "Deploy during peak traffic", icon: <Activity className="w-4 h-4" />, weight: 10, avgContribution: 4 },
    { factor: "Dependency Changes", description: "External library version bumps", icon: <FileWarning className="w-4 h-4" />, weight: 10, avgContribution: 3 },
  ];

  // Top risky services
  const serviceRisk = services.map((svc) => {
    const svcDeploys = deployments.filter((d) => d.serviceId === svc.id);
    const avgScore = svcDeploys.length > 0 ? Math.round(svcDeploys.reduce((s, d) => s + d.riskScore, 0) / svcDeploys.length) : 0;
    const maxScore = svcDeploys.length > 0 ? Math.max(...svcDeploys.map((d) => d.riskScore)) : 0;
    return { service: svc, avgScore, maxScore, count: svcDeploys.length };
  }).filter((s) => s.count > 0).sort((a, b) => b.avgScore - a.avgScore);

  return (
    <PageContainer>
      <PageHeader
        title="Deployment Risk Analysis"
        description="Composite risk scoring across recent deployments with factor breakdown and per-service risk posture."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Risk Analysis" }]}
        icon={<ShieldAlert className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Risk report exported")}>
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Avg Risk Score" value={avgRisk} unit="/ 100" hint={`across ${deployments.length} deploys`} icon={<Activity className="w-4 h-4" />} accent={avgRisk > 50 ? "destructive" : "warning"} />
        <KpiCard label="High-Risk Deploys" value={highRisk} hint="score > 50" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Change Failure Rate" value={`${changeFailureRate}%`} delta={-3} deltaLabel="vs last 30d" icon={<TrendingDown className="w-4 h-4" />} accent={changeFailureRate > 10 ? "destructive" : "success"} />
        <KpiCard label="Risk Trend" value={avgRisk > 40 ? "Rising" : "Stable"} hint="vs prev period" icon={<TrendingUp className="w-4 h-4" />} accent={avgRisk > 40 ? "warning" : "success"} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Risk distribution donut */}
        <Card className="p-5 space-y-4">
          <SectionHeading title="Risk Distribution" description="By score band" />
          <div className="h-[220px] relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={distribution} dataKey="value" nameKey="name" innerRadius="55%" outerRadius="85%" paddingAngle={2} stroke="none">
                  {distribution.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-2xl font-semibold tabular-nums">{deployments.length}</span>
              <span className="text-xs text-muted-foreground">total deploys</span>
            </div>
          </div>
          <div className="space-y-1.5">
            {distribution.map((d) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                  <span>{d.name}</span>
                </div>
                <span className="font-mono tabular-nums">{d.value} ({Math.round((d.value / deployments.length) * 100)}%)</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Risk trend */}
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading title="Risk Trend" description="Risk score per deployment (most recent 12)" />
          <div className="space-y-2">
            {trend.map((d, i) => {
              const score = d.score;
              const color = score > 60 ? "text-destructive" : score > 30 ? "text-warning-foreground" : "text-success";
              const bg = score > 60 ? "bg-destructive" : score > 30 ? "bg-warning" : "bg-success";
              return (
                <div key={i} className="flex items-center gap-3">
                  <span className="font-mono text-[11px] text-muted-foreground w-24 truncate shrink-0">{d.ref}</span>
                  <div className="flex-1 h-3 rounded-full bg-muted overflow-hidden">
                    <div className={`h-full ${bg}`} style={{ width: `${score}%` }} />
                  </div>
                  <span className={`font-mono text-xs font-semibold tabular-nums w-8 text-right ${color}`}>{score}</span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Risk factors table */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Risk Factors"
          description="Factors that contribute to composite risk scoring"
          action={<span className="text-xs text-muted-foreground">weighted model</span>}
        />
        <div className="overflow-x-auto -mx-2">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Factor</th>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Description</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Weight</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Avg Contribution</th>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground w-32">Distribution</th>
              </tr>
            </thead>
            <tbody>
              {riskFactors.map((f) => (
                <tr key={f.factor} className="border-t border-border hover:bg-muted/30">
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">{f.icon}</div>
                      <span className="text-sm font-medium">{f.factor}</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-xs text-muted-foreground">{f.description}</td>
                  <td className="px-3 py-2.5 text-right">
                    <span className="font-mono text-xs font-semibold">{f.weight}%</span>
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <span className="font-mono text-xs tabular-nums">{f.avgContribution}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className="bg-primary" style={{ width: `${(f.avgContribution / f.weight) * 100}%` }} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Top risky services */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Top Risky Services"
          description="Services with highest average risk scores"
          action={<span className="text-xs text-muted-foreground">{serviceRisk.length} services with deploys</span>}
        />
        <div className="space-y-2">
          {serviceRisk.slice(0, 8).map((s, i) => (
            <Link
              key={s.service.id}
              href={`/services/${s.service.id}`}
              className="flex items-center justify-between gap-3 p-3 rounded-md border hover:bg-muted/40 transition-colors"
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center shrink-0 ${
                  i === 0 ? "bg-destructive/20 text-destructive" : i === 1 ? "bg-warning/20 text-warning-foreground" : "bg-muted text-muted-foreground"
                }`}>{i + 1}</span>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium truncate">{s.service.name}</span>
                    <TierBadge tier={s.service.tier} />
                  </div>
                  <div className="text-[10px] text-muted-foreground">{s.count} deployments · max score {s.maxScore}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <div className="w-24">
                  <div className="flex items-center justify-between text-[10px] mb-0.5">
                    <span className="text-muted-foreground">Avg</span>
                    <span className={`font-mono font-semibold ${s.avgScore > 60 ? "text-destructive" : s.avgScore > 30 ? "text-warning-foreground" : "text-success"}`}>{s.avgScore}</span>
                  </div>
                  <Progress
                    value={s.avgScore}
                    className={`h-1.5 ${s.avgScore > 60 ? "bg-destructive/20" : s.avgScore > 30 ? "bg-warning/20" : "bg-success/20"}`}
                  />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
