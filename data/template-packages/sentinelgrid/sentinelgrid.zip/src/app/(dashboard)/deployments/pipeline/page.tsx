"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Rocket, GitBranch, Clock, Users, AlertCircle,
} from "lucide-react";
import { deployments, services, people } from "@/lib/data";
import { DeploymentStatusBadge, TierBadge } from "@/components/common/badges";
import type { Deployment, DeploymentStatus } from "@/lib/types";
import { toast } from "sonner";

const COLUMNS: { key: string; title: string; statuses: DeploymentStatus[]; tone: string }[] = [
  { key: "queued", title: "Queued", statuses: ["queued"], tone: "border-l-muted-foreground/40" },
  { key: "building", title: "Building", statuses: ["in_progress"], tone: "border-l-info" },
  { key: "testing", title: "Testing", statuses: [], tone: "border-l-accent" },
  { key: "pending_approval", title: "Pending Approval", statuses: ["pending_approval"], tone: "border-l-warning" },
  { key: "rolling_out", title: "Rolling Out", statuses: ["rolling_out", "canary"], tone: "border-l-info" },
  { key: "completed", title: "Completed", statuses: ["succeeded"], tone: "border-l-success" },
  { key: "failed", title: "Failed", statuses: ["failed", "rolled_back", "halted"], tone: "border-l-destructive" },
];

function deploymentColumn(d: Deployment): number {
  if (d.status === "queued") return 0;
  if (d.status === "in_progress") {
    // Check stages to determine if building or testing
    const stage = d.stages.find((s) => s.status === "in_progress" || s.status === "queued");
    if (stage?.name.startsWith("test")) return 2;
    return 1;
  }
  if (d.status === "pending_approval") return 3;
  if (["rolling_out", "canary"].includes(d.status)) return 4;
  if (d.status === "succeeded") return 5;
  return 6; // failed, rolled_back, halted
}

export default function PipelinePage() {
  const columns = COLUMNS.map((c, idx) => ({
    ...c,
    deployments: deployments.filter((d) => deploymentColumn(d) === idx),
  }));

  const total = deployments.length;
  const inFlight = columns.slice(0, 5).reduce((s, c) => s + c.deployments.length, 0);
  const completed = columns[5].deployments.length;
  const failed = columns[6].deployments.length;

  return (
    <PageContainer wide>
      <PageHeader
        title="Release Pipeline"
        description="Kanban-style board showing all deployments across stages, from queue through completion."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "Pipeline" }]}
        icon={<GitBranch className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Pipeline refreshed")}>
              <Clock className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New deployment queued")}>
              <Rocket className="w-3.5 h-3.5" />
              New Deploy
            </Button>
          </>
        }
      />

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Total in Pipeline</div>
          <div className="text-2xl font-bold tabular-nums">{total}</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">In Flight</div>
          <div className="text-2xl font-bold tabular-nums text-info-foreground">{inFlight}</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Completed</div>
          <div className="text-2xl font-bold tabular-nums text-success">{completed}</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Failed / Rolled Back</div>
          <div className="text-2xl font-bold tabular-nums text-destructive">{failed}</div>
        </Card>
      </div>

      {/* Kanban board */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-7 gap-3">
        {columns.map((col) => (
          <div key={col.key} className={`rounded-lg border bg-card border-l-4 ${col.tone} min-h-[400px] flex flex-col`}>
            <div className="p-3 border-b border-border">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold uppercase tracking-wider">{col.title}</h3>
                <span className="text-[10px] font-mono bg-muted px-1.5 py-0.5 rounded">{col.deployments.length}</span>
              </div>
            </div>
            <div className="p-2 space-y-2 flex-1 overflow-y-auto max-h-[600px]">
              {col.deployments.length === 0 ? (
                <div className="text-center text-[10px] text-muted-foreground py-6">No deployments</div>
              ) : col.deployments.map((d) => {
                const svc = services.find((s) => s.id === d.serviceId);
                const author = people.find((p) => p.id === d.authorId);
                return (
                  <Link
                    key={d.id}
                    href={`/deployments/${d.id}`}
                    className="block p-3 rounded-md border bg-card hover:bg-muted/40 hover:border-primary/30 transition-colors"
                  >
                    <div className="flex items-center justify-between gap-1 mb-1.5">
                      <span className="font-mono text-[11px] font-semibold">{d.ref}</span>
                      <DeploymentStatusBadge status={d.status} />
                    </div>
                    <div className="flex items-center gap-1.5 mb-1">
                      {svc && <TierBadge tier={svc.tier} />}
                      <span className="text-xs font-medium truncate">{svc?.name}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mb-1">
                      <GitBranch className="w-2.5 h-2.5" />
                      <span className="font-mono truncate">{d.version}</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground line-clamp-2 mb-2">{d.commitMessage}</p>
                    {author && (
                      <div className="flex items-center justify-between text-[10px]">
                        <div className="flex items-center gap-1">
                          <img src={author.avatarUrl} alt={author.name} className="w-4 h-4 rounded-full object-cover" />
                          <span className="text-muted-foreground truncate">{author.name.split(" ")[0]}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <div className={`w-1.5 h-1.5 rounded-full ${d.riskScore > 60 ? "bg-destructive" : d.riskScore > 30 ? "bg-warning" : "bg-success"}`} />
                          <span className="text-muted-foreground tabular-nums">{d.riskScore}</span>
                        </div>
                      </div>
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Notes */}
      <Card className="p-5 space-y-2">
        <div className="flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-info-foreground mt-0.5 shrink-0" />
          <div className="text-xs text-muted-foreground">
            <span className="font-medium text-foreground">Pipeline visualization.</span> Cards are visually organized by stage based on deployment status and pipeline progress. Drag-and-drop is not enabled; use the <Link href="/deployments/approvals" className="text-primary hover:underline">approvals</Link> page to advance deployments through review gates, or click any card to view details.
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
