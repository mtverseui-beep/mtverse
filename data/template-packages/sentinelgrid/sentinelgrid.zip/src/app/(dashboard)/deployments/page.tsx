"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Rocket, CheckCircle2, AlertTriangle, Clock, Plus, Download, GitBranch,
  RotateCcw, Activity,
} from "lucide-react";
import { deployments, services, people } from "@/lib/data";
import { DeploymentStatusBadge, TierBadge } from "@/components/common/badges";
import type { Deployment, EnvironmentName } from "@/lib/types";
import { toast } from "sonner";

export default function DeploymentsListPage() {
  const today = new Date();
  const todayCount = deployments.filter((d) => {
    const ds = new Date(d.startedAt);
    return (today.getTime() - ds.getTime()) < 24 * 60 * 60 * 1000;
  }).length;
  const inFlight = deployments.filter((d) =>
    ["queued", "in_progress", "rolling_out", "canary", "pending_approval"].includes(d.status)
  ).length;
  const successful = deployments.filter((d) => d.status === "succeeded").length;
  const successRate = Math.round((successful / deployments.length) * 100);
  const avgDuration = Math.round(
    deployments.filter((d) => d.duration > 0).reduce((s, d) => s + d.duration, 0) /
    deployments.filter((d) => d.duration > 0).length / 60
  );

  const columns: Column<Deployment>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => (
        <Link href={`/deployments/${r.id}`} className="font-mono text-xs font-semibold text-primary hover:underline">
          {r.ref}
        </Link>
      ),
    },
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => services.find((s) => s.id === r.serviceId)?.name ?? "",
      cell: (r) => {
        const svc = services.find((s) => s.id === r.serviceId);
        return (
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">{svc?.name ?? "—"}</span>
            {svc && <TierBadge tier={svc.tier} />}
          </div>
        );
      },
      filterable: true,
      filterOptions: services.map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.serviceId === v,
    },
    {
      key: "version",
      header: "Version",
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <GitBranch className="w-3 h-3 text-muted-foreground" />
          <span className="font-mono text-xs">{r.version}</span>
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "environment",
      header: "Environment",
      sortable: true,
      sortValue: (r) => r.environment,
      cell: (r) => <span className="text-xs capitalize">{r.environment}</span>,
      filterable: true,
      filterOptions: ["production", "staging", "development", "preview"].map((e) => ({ label: e, value: e })),
      filterFn: (r, v) => r.environment === (v as EnvironmentName),
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => <DeploymentStatusBadge status={r.status} />,
      filterable: true,
      filterOptions: [
        { label: "Queued", value: "queued" },
        { label: "In Progress", value: "in_progress" },
        { label: "Rolling Out", value: "rolling_out" },
        { label: "Canary", value: "canary" },
        { label: "Succeeded", value: "succeeded" },
        { label: "Failed", value: "failed" },
        { label: "Rolled Back", value: "rolled_back" },
        { label: "Halted", value: "halted" },
        { label: "Pending Approval", value: "pending_approval" },
      ],
      filterFn: (r, v) => r.status === (v as Deployment["status"]),
    },
    {
      key: "strategy",
      header: "Strategy",
      sortable: true,
      sortValue: (r) => r.strategy,
      cell: (r) => <span className="text-xs capitalize">{r.strategy.replace("_", " ")}</span>,
      hideOnMobile: true,
    },
    {
      key: "riskScore",
      header: "Risk",
      sortable: true,
      sortValue: (r) => r.riskScore,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${r.riskScore > 60 ? "bg-destructive" : r.riskScore > 30 ? "bg-warning" : "bg-success"}`} />
          <span className="text-xs tabular-nums">{r.riskScore}</span>
        </div>
      ),
      align: "right",
      hideOnMobile: true,
    },
    {
      key: "startedAt",
      header: "Started",
      sortable: true,
      sortValue: (r) => r.startedAt,
      cell: (r) => <span className="text-xs text-muted-foreground">{new Date(r.startedAt).toLocaleString()}</span>,
      hideOnMobile: true,
    },
    {
      key: "duration",
      header: "Duration",
      sortable: true,
      sortValue: (r) => r.duration,
      cell: (r) => (
        <span className="text-xs tabular-nums">
          {r.duration > 0 ? `${Math.floor(r.duration / 60)}m ${r.duration % 60}s` : "—"}
        </span>
      ),
      align: "right",
    },
    {
      key: "author",
      header: "Author",
      cell: (r) => {
        const author = people.find((p) => p.id === r.authorId);
        return author ? (
          <div className="flex items-center gap-1.5">
            <img src={author.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate hidden md:inline">{author.name}</span>
          </div>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
      hideOnMobile: true,
    },
  ];

  function handleRollback(rows: Deployment[]) {
    toast.success(`Rollback initiated for ${rows.length} deployment(s)`);
  }
  function handleExport(rows: Deployment[]) {
    toast.success(`Exported ${rows.length} deployment(s) as CSV`);
  }

  return (
    <PageContainer>
      <PageHeader
        title="Deployments"
        description="Full deployment history across all services and environments with risk, duration, and status tracking."
        breadcrumbs={[{ label: "Deployments", href: "/deployments" }, { label: "All" }]}
        icon={<Rocket className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("New deployment wizard opened")}>
              <Plus className="w-3.5 h-3.5" />
              Trigger Deploy
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Deploys (24h)" value={todayCount} delta={15} deltaLabel="vs yesterday" icon={<Rocket className="w-4 h-4" />} accent="primary" sparkline={[8, 12, 10, 14, 11, 13, 15, 12, 14, 13]} />
        <KpiCard label="In-Flight" value={inFlight} hint="rolling out now" icon={<Activity className="w-4 h-4" />} accent="info" />
        <KpiCard label="Success Rate (7d)" value={`${successRate}%`} delta={2} deltaLabel="last 7 days" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Avg Duration" value={`${avgDuration}m`} delta={-12} deltaLabel="faster" icon={<Clock className="w-4 h-4" />} accent="info" sparkline={[18, 17, 16, 18, 15, 14, 16, 15, 14, 13]} />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="All Deployments"
          description="Use filters to narrow by status, environment, or service"
          action={<span className="text-xs text-muted-foreground">{deployments.length} deployments</span>}
        />
        <DataTable
          columns={columns}
          data={deployments}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.ref, (r) => r.version, (r) => services.find((s) => s.id === r.serviceId)?.name ?? "", (r) => r.commitMessage]}
          searchPlaceholder="Search by ref, version, service, commit..."
          pageSize={10}
          initialSort={{ key: "startedAt", dir: "desc" }}
          enableSelection
          bulkActions={[
            { label: "Rollback", icon: <RotateCcw className="w-3.5 h-3.5" />, onClick: handleRollback, variant: "destructive" },
            { label: "Export", icon: <Download className="w-3.5 h-3.5" />, onClick: handleExport },
          ]}
          onRowClick={(r) => { window.location.href = `/deployments/${r.id}`; }}
        />
      </Card>
    </PageContainer>
  );
}
