"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { SeverityBadge } from "@/components/common/badges";
import { postmortems, people, incidents } from "@/lib/data";
import { toast } from "sonner";
import {
  Inbox, CheckCircle2, AlertCircle, Clock, FileText, UserPlus,
  Check, X, Eye, ChevronRight, Mail, MessageSquare,
} from "lucide-react";

export default function PostmortemReviewPage() {
  const router = useRouter();
  const [queue, setQueue] = React.useState(postmortems.filter((p) => p.status === "in_review" || p.status === "draft"));

  function approve(id: string) {
    setQueue((q) => q.filter((p) => p.id !== id));
    toast.success("Postmortem approved");
  }
  function requestChanges(id: string) {
    setQueue((q) => q.filter((p) => p.id !== id));
    toast.info("Changes requested");
  }
  function reject(id: string) {
    setQueue((q) => q.filter((p) => p.id !== id));
    toast.error("Postmortem rejected");
  }

  const pendingCount = queue.length;
  const avgTimeInReview = 1.8; // mock days
  const reviewersNeeded = queue.filter((p) => p.reviewerIds.length < 2).length;

  return (
    <PageContainer>
      <PageHeader
        title="Review Queue"
        description="Postmortems awaiting review. Approve, request changes, or reject each submission."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Postmortems", href: "/postmortems" }, { label: "Review" }]}
        icon={<Inbox className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Pending Review" value={pendingCount} hint="Awaiting reviewers" icon={<Inbox className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Avg Time in Review" value={avgTimeInReview} unit="d" hint="From submission to decision" icon={<Clock className="w-4 h-4" />} accent="info" />
        <KpiCard label="Need Reviewers" value={reviewersNeeded} hint="Less than 2 assigned" icon={<UserPlus className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Approved (30d)" value={4} hint="Recently published" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
      </div>

      {queue.length === 0 ? (
        <Card>
          <EmptyState
            icon={<CheckCircle2 className="w-5 h-5" />}
            title="Queue is clear"
            description="No postmortems are awaiting review. Great work!"
            action={<Button asChild size="sm"><Link href="/postmortems">View all postmortems</Link></Button>}
          />
        </Card>
      ) : (
        <div className="space-y-4">
          {queue.map((pm) => {
            const inc = incidents.find((i) => i.id === pm.incidentId);
            const author = people.find((p) => p.id === pm.authorId);
            const reviewers = pm.reviewerIds.map((rid) => people.find((p) => p.id === rid)).filter(Boolean);
            const needsReviewers = reviewers.length < 2;
            return (
              <Card key={pm.id} className="p-5 border-l-4 border-l-warning/60">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2 space-y-3">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-mono font-semibold text-muted-foreground">{pm.ref}</span>
                      <SeverityBadge severity={pm.severity} size="sm" />
                      <Badge variant="outline" className="text-[10px] capitalize gap-1"><AlertCircle className="w-2.5 h-2.5" /> {pm.status.replace(/_/g, " ")}</Badge>
                      <span className="text-[11px] text-muted-foreground ml-auto">Submitted {new Date(pm.createdAt).toLocaleDateString()}</span>
                    </div>
                    <h3 className="text-base font-semibold">{pm.title}</h3>
                    <p className="text-xs text-muted-foreground line-clamp-2">{pm.impactSummary}</p>
                    <div className="rounded-md bg-muted/30 border p-2.5">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Root Cause (preview)</div>
                      <p className="text-xs line-clamp-3">{pm.rootCause}</p>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                      <span>{pm.actionItems.length} action items</span>
                      <span>{pm.contributingFactors.length} contributing factors</span>
                      <span>{pm.lessons.length} lessons</span>
                      <span>{pm.timeline.length} timeline events</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="rounded-lg border p-3">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Author</div>
                      {author && (
                        <div className="flex items-center gap-2">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={author.avatarUrl} />
                            <AvatarFallback>{author.name[0]}</AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <div className="text-xs font-medium truncate">{author.name}</div>
                            <div className="text-[10px] text-muted-foreground truncate">{author.title}</div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="rounded-lg border p-3">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Reviewers ({reviewers.length})</div>
                        {needsReviewers && <Badge className="text-[10px] h-4 bg-destructive/15 text-destructive border-destructive/30">Need more</Badge>}
                      </div>
                      <div className="space-y-1.5">
                        {reviewers.map((r) => (
                          <div key={r!.id} className="flex items-center gap-2">
                            <Avatar className="w-6 h-6"><AvatarImage src={r!.avatarUrl} /><AvatarFallback>{r!.name[0]}</AvatarFallback></Avatar>
                            <span className="text-xs truncate flex-1">{r!.name}</span>
                            <Badge variant="outline" className="text-[10px] h-4 bg-warning/10 text-warning-foreground">Pending</Badge>
                          </div>
                        ))}
                        {reviewers.length === 0 && <p className="text-[11px] text-muted-foreground">No reviewers assigned.</p>}
                      </div>
                      <Button variant="ghost" size="sm" className="w-full h-7 text-xs gap-1 mt-2" onClick={() => toast.info("Add reviewer dialog")}>
                        <UserPlus className="w-3 h-3" /> Add Reviewer
                      </Button>
                    </div>

                    <Separator />

                    <div className="space-y-1.5">
                      <Button asChild variant="outline" size="sm" className="w-full h-8 text-xs gap-1.5">
                        <Link href={`/postmortems/${pm.id}`}><Eye className="w-3 h-3" /> Review Document</Link>
                      </Button>
                      <div className="grid grid-cols-3 gap-1.5">
                        <Button size="sm" variant="outline" className="h-8 text-xs gap-1 text-destructive hover:text-destructive" onClick={() => reject(pm.id)}>
                          <X className="w-3 h-3" /> Reject
                        </Button>
                        <Button size="sm" variant="outline" className="h-8 text-xs gap-1 text-warning-foreground" onClick={() => requestChanges(pm.id)}>
                          <AlertCircle className="w-3 h-3" /> Changes
                        </Button>
                        <Button size="sm" className="h-8 text-xs gap-1 bg-success text-success-foreground hover:bg-success/90" onClick={() => approve(pm.id)}>
                          <Check className="w-3 h-3" /> Approve
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </PageContainer>
  );
}
