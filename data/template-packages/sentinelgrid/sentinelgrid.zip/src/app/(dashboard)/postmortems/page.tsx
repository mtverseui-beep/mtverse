"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { DataTable, type Column } from "@/components/tables/data-table";
import { SeverityBadge } from "@/components/common/badges";
import { postmortems, people, incidents } from "@/lib/data";
import type { Postmortem } from "@/lib/types";
import { toast } from "sonner";
import {
  FileText, Plus, CheckCircle2, Clock, TrendingUp, Download,
  ChevronRight, Eye, CheckCheck, XCircle, AlertCircle, Archive,
} from "lucide-react";

const statusConfig: Record<Postmortem["status"], { label: string; className: string; icon: React.ReactNode }> = {
  draft: { label: "Draft", className: "bg-muted text-muted-foreground border-border", icon: <FileText className="w-3 h-3" /> },
  in_review: { label: "In Review", className: "bg-warning/15 text-warning-foreground border-warning/30", icon: <AlertCircle className="w-3 h-3" /> },
  approved: { label: "Approved", className: "bg-info/15 text-info-foreground border-info/30", icon: <CheckCheck className="w-3 h-3" /> },
  published: { label: "Published", className: "bg-success/15 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
  archived: { label: "Archived", className: "bg-muted text-muted-foreground border-border", icon: <Archive className="w-3 h-3" /> },
};

export default function PostmortemsListPage() {
  const router = useRouter();

  const inReview = postmortems.filter((p) => p.status === "in_review").length;
  const published = postmortems.filter((p) => p.status === "published").length;

  // Avg action item completion
  const allActions = postmortems.flatMap((p) => p.actionItems);
  const completed = allActions.filter((a) => a.status === "done").length;
  const avgCompletion = allActions.length > 0 ? Math.round((completed / allActions.length) * 100) : 0;

  function getIncident(id: string) {
    return incidents.find((i) => i.id === id);
  }

  function actionProgress(pm: Postmortem) {
    if (pm.actionItems.length === 0) return 0;
    const done = pm.actionItems.filter((a) => a.status === "done").length;
    return Math.round((done / pm.actionItems.length) * 100);
  }

  const columns: Column<Postmortem>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      width: "130px",
      sortValue: (r) => r.ref,
      cell: (r) => (
        <Link href={`/postmortems/${r.id}`} className="text-xs font-mono font-semibold text-primary hover:underline">
          {r.ref}
        </Link>
      ),
    },
    {
      key: "title",
      header: "Title",
      sortable: true,
      sortValue: (r) => r.title,
      cell: (r) => (
        <div className="min-w-0">
          <Link href={`/postmortems/${r.id}`} className="text-sm font-medium hover:underline line-clamp-1">
            {r.title}
          </Link>
          <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{r.impactSummary}</p>
        </div>
      ),
    },
    {
      key: "incident",
      header: "Incident",
      hideOnMobile: true,
      cell: (r) => {
        const inc = getIncident(r.incidentId);
        return inc ? (
          <Link href={`/incidents/${inc.id}`} className="text-xs font-mono text-primary hover:underline">{inc.ref}</Link>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
    },
    {
      key: "severity",
      header: "Severity",
      sortable: true,
      filterable: true,
      sortValue: (r) => ({ critical: 0, high: 1, medium: 2, low: 3, info: 4 }[r.severity]),
      filterOptions: [
        { label: "Critical", value: "critical" },
        { label: "High", value: "high" },
        { label: "Medium", value: "medium" },
        { label: "Low", value: "low" },
      ],
      filterFn: (r, v) => r.severity === v,
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "author",
      header: "Author",
      hideOnMobile: true,
      cell: (r) => {
        const a = people.find((p) => p.id === r.authorId);
        if (!a) return <span className="text-xs text-muted-foreground">—</span>;
        return (
          <div className="flex items-center gap-1.5">
            <img src={a.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate">{a.name}</span>
          </div>
        );
      },
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      filterable: true,
      sortValue: (r) => r.status,
      filterOptions: [
        { label: "Draft", value: "draft" },
        { label: "In Review", value: "in_review" },
        { label: "Approved", value: "approved" },
        { label: "Published", value: "published" },
        { label: "Archived", value: "archived" },
      ],
      filterFn: (r, v) => r.status === v,
      cell: (r) => {
        const s = statusConfig[r.status];
        return <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium ${s.className}`}>{s.icon} {s.label}</span>;
      },
    },
    {
      key: "publishedAt",
      header: "Published",
      sortable: true,
      hideOnMobile: true,
      sortValue: (r) => r.publishedAt ? new Date(r.publishedAt).getTime() : 0,
      cell: (r) => (
        <span className="text-xs text-muted-foreground">
          {r.publishedAt ? new Date(r.publishedAt).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" }) : "—"}
        </span>
      ),
    },
    {
      key: "actionItems",
      header: "Action Items",
      sortable: true,
      align: "right",
      width: "180px",
      sortValue: (r) => actionProgress(r),
      cell: (r) => {
        const total = r.actionItems.length;
        const done = r.actionItems.filter((a) => a.status === "done").length;
        const pct = actionProgress(r);
        return (
          <div className="flex items-center gap-1.5 justify-end">
            <Progress value={pct} className="w-14 h-1.5" />
            <span className="text-[11px] tabular-nums text-muted-foreground">{done}/{total}</span>
          </div>
        );
      },
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Postmortems"
        description="Blameless postmortems for resolved incidents. Each captures root cause, contributing factors, lessons learned, and action items."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Postmortems" }]}
        icon={<FileText className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => router.push("/postmortems/new")}>
              <Plus className="w-3.5 h-3.5" /> New Postmortem
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Postmortems" value={postmortems.length} hint="All time" icon={<FileText className="w-4 h-4" />} accent="primary" />
        <KpiCard label="In Review" value={inReview} hint="Awaiting reviewers" icon={<AlertCircle className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Published" value={published} hint="Approved & shared" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Action Item Completion" value={`${avgCompletion}%`} hint={`${completed}/${allActions.length} action items done`} icon={<TrendingUp className="w-4 h-4" />} accent="info" delta={6} deltaLabel="vs last quarter" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading
          title="All Postmortems"
          description="Click a row to view the full postmortem document"
          action={<Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1"><span className="inline-flex items-center gap-1">Review queue <ChevronRight className="w-3 h-3" /></span></Button>}
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={postmortems}
            rowKey={(r) => r.id}
            searchKeys={["ref", "title", "impactSummary"]}
            searchPlaceholder="Search by ref, title, or summary..."
            pageSize={10}
            initialSort={{ key: "publishedAt", dir: "desc" }}
            onRowClick={(r) => router.push(`/postmortems/${r.id}`)}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
