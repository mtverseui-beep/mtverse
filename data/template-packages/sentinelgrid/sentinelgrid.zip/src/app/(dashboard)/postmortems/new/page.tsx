"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { SeverityBadge } from "@/components/common/badges";
import { incidents, people } from "@/lib/data";
import { toast } from "sonner";
import {
  FileText, ArrowLeft, Plus, X, Save, Send, AlertTriangle,
  ShieldAlert, Info, Check,
} from "lucide-react";

const sevConfig = [
  { value: "critical", label: "Critical", icon: ShieldAlert },
  { value: "high", label: "High", icon: AlertTriangle },
  { value: "medium", label: "Medium", icon: Info },
  { value: "low", label: "Low", icon: AlertTriangle },
] as const;

export default function NewPostmortemPage() {
  const router = useRouter();
  // Filter to incidents that are resolved (postmortem candidates)
  const candidates = incidents.filter((i) => i.status === "resolved");
  const [title, setTitle] = React.useState("");
  const [incidentId, setIncidentId] = React.useState(candidates[0]?.id ?? incidents[0].id);
  const [authorId, setAuthorId] = React.useState("u1");
  const [summary, setSummary] = React.useState("");
  const [rootCause, setRootCause] = React.useState("");
  const [factors, setFactors] = React.useState<string[]>([""]);
  const [severity, setSeverity] = React.useState<"critical" | "high" | "medium" | "low">("medium");

  const selectedIncident = incidents.find((i) => i.id === incidentId);

  function setFactor(idx: number, val: string) {
    setFactors((p) => p.map((f, i) => (i === idx ? val : f)));
  }
  function addFactor() {
    setFactors((p) => [...p, ""]);
  }
  function removeFactor(idx: number) {
    setFactors((p) => p.filter((_, i) => i !== idx));
  }

  function saveDraft() {
    if (!title.trim()) {
      toast.error("Title is required");
      return;
    }
    toast.success("Draft saved");
    setTimeout(() => router.push("/postmortems"), 500);
  }
  function submitForReview() {
    if (!title.trim()) {
      toast.error("Title is required");
      return;
    }
    if (!rootCause.trim()) {
      toast.error("Root cause is required");
      return;
    }
    toast.success("Submitted for review");
    setTimeout(() => router.push("/postmortems/review"), 500);
  }

  return (
    <PageContainer>
      <PageHeader
        title="Create Postmortem"
        description="Document the root cause, contributing factors, and lessons learned from a resolved incident."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Postmortems", href: "/postmortems" }, { label: "New" }]}
        icon={<FileText className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => router.push("/postmortems")}>
            <ArrowLeft className="w-3.5 h-3.5" /> Cancel
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Basics" description="Title and linked incident" />
            <div className="space-y-3">
              <div>
                <Label htmlFor="title" className="text-xs">Title <span className="text-destructive">*</span></Label>
                <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Auth Service JWKS Cache Stale" className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="incident" className="text-xs">Linked incident <span className="text-destructive">*</span></Label>
                <select id="incident" value={incidentId} onChange={(e) => setIncidentId(e.target.value)} className="mt-1.5 w-full rounded-md border bg-background px-3 py-2 text-sm">
                  {incidents.map((i) => <option key={i.id} value={i.id}>{i.ref} — {i.title}</option>)}
                </select>
              </div>
              <div>
                <Label className="text-xs">Severity</Label>
                <div className="flex items-center gap-1.5 mt-1.5">
                  {sevConfig.map((s) => {
                    const Icon = s.icon;
                    const active = severity === s.value;
                    return (
                      <button key={s.value} onClick={() => setSeverity(s.value)} className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border text-xs ${active ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}>
                        <Icon className={`w-3 h-3 ${active ? "text-primary" : "text-muted-foreground"}`} />
                        {s.label}
                        {active && <Check className="w-3 h-3 text-primary ml-1" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Impact Summary" description="What happened, who was affected" />
            <Textarea
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="Describe the customer-visible impact, scope, and duration..."
              rows={4}
              className="text-sm"
            />
            {selectedIncident && (
              <div className="rounded-md border bg-muted/30 p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">From incident</div>
                <p className="text-xs">{selectedIncident.customerImpact}</p>
              </div>
            )}
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Root Cause" description="The underlying technical cause" />
            <Textarea
              value={rootCause}
              onChange={(e) => setRootCause(e.target.value)}
              placeholder="Describe the technical root cause — be specific about what failed and why..."
              rows={5}
              className="text-sm"
            />
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading
              title="Contributing Factors"
              description="Conditions that allowed the incident to occur or worsen"
              action={<Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={addFactor}><Plus className="w-3 h-3" /> Add</Button>}
            />
            <div className="space-y-2">
              {factors.map((f, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div className="w-6 h-6 rounded-full bg-warning/15 text-warning-foreground border border-warning/30 flex items-center justify-center text-[10px] font-semibold shrink-0 mt-1.5">
                    {i + 1}
                  </div>
                  <Textarea value={f} onChange={(e) => setFactor(i, e.target.value)} placeholder="Describe a contributing factor..." rows={2} className="text-sm flex-1" />
                  {factors.length > 1 && (
                    <Button variant="ghost" size="sm" className="mt-1.5 h-8 w-8 p-0 text-muted-foreground hover:text-destructive" onClick={() => removeFactor(i)}>
                      <X className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Author" description="Who is writing this postmortem" />
            <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1 custom-scroll">
              {people.slice(0, 8).map((p) => {
                const active = authorId === p.id;
                return (
                  <button key={p.id} onClick={() => setAuthorId(p.id)} className={`w-full flex items-center gap-2.5 p-2 rounded-md border text-left transition-colors ${active ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}>
                    <img src={p.avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium truncate">{p.name}</div>
                      <div className="text-[11px] text-muted-foreground truncate">{p.title}</div>
                    </div>
                    {active && <Check className="w-3.5 h-3.5 text-primary" />}
                  </button>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Summary" description="Review before saving" />
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Title</span>
                <span className="font-medium truncate ml-2 max-w-[160px]">{title || "—"}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Incident</span>
                <span className="font-mono text-[11px]">{selectedIncident?.ref ?? "—"}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Severity</span>
                <SeverityBadge severity={severity} size="sm" />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Factors</span>
                <span className="font-medium tabular-nums">{factors.filter(Boolean).length}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Author</span>
                <span className="font-medium truncate ml-2 max-w-[160px]">{people.find((p) => p.id === authorId)?.name ?? "—"}</span>
              </div>
            </div>
            <Separator />
            <div className="flex flex-col gap-2">
              <Button variant="outline" className="w-full gap-1.5" onClick={saveDraft}>
                <Save className="w-3.5 h-3.5" /> Save as Draft
              </Button>
              <Button className="w-full gap-1.5" onClick={submitForReview}>
                <Send className="w-3.5 h-3.5" /> Submit for Review
              </Button>
            </div>
          </Card>

          <Card className="p-4 bg-muted/30 border-dashed">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
              <div className="text-xs text-muted-foreground leading-relaxed">
                Keep it blameless. Focus on systems and processes, not individuals. Assume everyone did the best they could with the information available.
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
