"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { SeverityBadge } from "@/components/common/badges";
import { postmortems, people, incidents } from "@/lib/data";
import {
  Lightbulb, Search, BookOpen, Filter, ChevronRight, Tag,
  Database, Server, Cloud, Lock, Rocket, Activity, GitBranch,
} from "lucide-react";

// Curated theme mapping
const themeConfig: Record<string, { label: string; icon: React.ReactNode; className: string }> = {
  caching: { label: "Caching", icon: <Database className="w-3.5 h-3.5" />, className: "bg-primary/15 text-primary border-primary/30" },
  deployments: { label: "Deployments", icon: <Rocket className="w-3.5 h-3.5" />, className: "bg-accent text-accent-foreground border-accent/30" },
  dependencies: { label: "Dependencies", icon: <GitBranch className="w-3.5 h-3.5" />, className: "bg-info/15 text-info-foreground border-info/30" },
  infrastructure: { label: "Infrastructure", icon: <Server className="w-3.5 h-3.5" />, className: "bg-warning/15 text-warning-foreground border-warning/30" },
  cloud: { label: "Cloud Provider", icon: <Cloud className="w-3.5 h-3.5" />, className: "bg-success/15 text-success border-success/30" },
  security: { label: "Security", icon: <Lock className="w-3.5 h-3.5" />, className: "bg-destructive/15 text-destructive border-destructive/30" },
  performance: { label: "Performance", icon: <Activity className="w-3.5 h-3.5" />, className: "bg-info/15 text-info-foreground border-info/30" },
  process: { label: "Process", icon: <BookOpen className="w-3.5 h-3.5" />, className: "bg-muted text-muted-foreground border-border" },
};

// Classify each lesson into a theme based on keywords
function classifyLesson(text: string): string {
  const t = text.toLowerCase();
  if (/cache|ttl|jwks|evict|redis/.test(t)) return "caching";
  if (/deploy|rollout|canary|release|version/.test(t)) return "deployments";
  if (/dependency|upstream|third.?party|vendor|library/.test(t)) return "dependencies";
  if (/host|node|kubernetes|kube|infrastructure|capacity|memory|cpu/.test(t)) return "infrastructure";
  if (/aws|gcp|azure|cloud|region|provider/.test(t)) return "cloud";
  if (/security|auth|token|key|secret|vulnerab|cve/.test(t)) return "security";
  if (/latency|p95|p99|throughput|performance|slow|apdex/.test(t)) return "performance";
  return "process";
}

interface LessonEntry {
  id: string;
  text: string;
  theme: string;
  postmortemId: string;
  postmortemRef: string;
  postmortemTitle: string;
  incidentId: string;
  severity: any;
}

export default function LessonsLearnedPage() {
  const [search, setSearch] = React.useState("");
  const [activeTheme, setActiveTheme] = React.useState<string>("all");

  const allLessons = React.useMemo<LessonEntry[]>(() => {
    return postmortems.flatMap((p) =>
      p.lessons.map((l, i) => {
        const inc = incidents.find((x) => x.id === p.incidentId);
        return {
          id: `${p.id}-l${i}`,
          text: l,
          theme: classifyLesson(l),
          postmortemId: p.id,
          postmortemRef: p.ref,
          postmortemTitle: p.title,
          incidentId: p.incidentId,
          severity: inc?.severity ?? p.severity,
        };
      })
    );
  }, []);

  const filtered = allLessons.filter((l) => {
    if (activeTheme !== "all" && l.theme !== activeTheme) return false;
    if (search && !l.text.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  // Theme distribution
  const themeCounts = Object.keys(themeConfig).map((t) => ({
    theme: t,
    count: allLessons.filter((l) => l.theme === t).length,
  })).sort((a, b) => b.count - a.count);

  return (
    <PageContainer>
      <PageHeader
        title="Lessons Learned"
        description="Curated library of lessons extracted from all published postmortems, categorized by theme for easy discovery."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Postmortems", href: "/postmortems" }, { label: "Lessons" }]}
        icon={<Lightbulb className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Lessons" value={allLessons.length} hint="Across all postmortems" icon={<Lightbulb className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Themes" value={Object.keys(themeConfig).length} hint="Distinct categories" icon={<Tag className="w-4 h-4" />} accent="accent" />
        <KpiCard label="Most Common Theme" value={themeCounts[0]?.count ?? 0} hint={themeCounts[0] ? themeConfig[themeCounts[0].theme].label : "—"} icon={<Filter className="w-4 h-4" />} accent="info" />
        <KpiCard label="Source Postmortems" value={postmortems.length} hint="Contributing documents" icon={<BookOpen className="w-4 h-4" />} accent="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2 space-y-4">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search lessons..." className="pl-8 h-9 text-sm" />
            </div>
          </div>

          {filtered.length === 0 ? (
            <EmptyState icon={<Lightbulb className="w-5 h-5" />} title="No lessons match" description="Try a different search or theme." />
          ) : (
            <div className="space-y-2 max-h-[760px] overflow-y-auto pr-1 custom-scroll">
              {filtered.map((l) => {
                const tc = themeConfig[l.theme];
                return (
                  <div key={l.id} className="rounded-lg border p-4 hover:bg-elevated/30 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shrink-0">
                        <Lightbulb className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
                          <Badge className={`text-[10px] gap-1 ${tc.className}`}>{tc.icon} {tc.label}</Badge>
                          <SeverityBadge severity={l.severity} size="sm" />
                          <Link href={`/postmortems/${l.postmortemId}`} className="text-[10px] font-mono text-primary hover:underline ml-auto">{l.postmortemRef}</Link>
                        </div>
                        <p className="text-sm text-foreground leading-relaxed">{l.text}</p>
                        <Link href={`/postmortems/${l.postmortemId}`} className="text-[11px] text-muted-foreground hover:text-foreground mt-1.5 inline-block">
                          From: {l.postmortemTitle}
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Themes" description="Filter by category" />
            <div className="space-y-1.5">
              <button
                onClick={() => setActiveTheme("all")}
                className={`w-full flex items-center justify-between p-2 rounded-md border text-left transition-colors ${activeTheme === "all" ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}
              >
                <span className="text-xs font-medium flex items-center gap-1.5"><Filter className="w-3 h-3" /> All themes</span>
                <Badge variant="outline" className="text-[10px] h-4 tabular-nums">{allLessons.length}</Badge>
              </button>
              {themeCounts.map((t) => {
                const tc = themeConfig[t.theme];
                const active = activeTheme === t.theme;
                return (
                  <button
                    key={t.theme}
                    onClick={() => setActiveTheme(t.theme)}
                    className={`w-full flex items-center justify-between p-2 rounded-md border text-left transition-colors ${active ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}
                  >
                    <span className="text-xs font-medium flex items-center gap-1.5">{tc.icon} {tc.label}</span>
                    <Badge variant="outline" className="text-[10px] h-4 tabular-nums">{t.count}</Badge>
                  </button>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Theme Distribution" description="Where do our lessons cluster?" />
            <div className="space-y-2">
              {themeCounts.map((t) => {
                const tc = themeConfig[t.theme];
                const pct = allLessons.length > 0 ? Math.round((t.count / allLessons.length) * 100) : 0;
                return (
                  <div key={t.theme}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-medium flex items-center gap-1">{tc.icon} {tc.label}</span>
                      <span className="text-muted-foreground tabular-nums">{t.count} ({pct}%)</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className={`h-full ${tc.className.split(" ").find((c) => c.startsWith("bg-"))}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
