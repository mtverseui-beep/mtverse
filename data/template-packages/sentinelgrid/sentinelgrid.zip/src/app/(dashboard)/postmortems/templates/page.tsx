"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  FileText, ShieldAlert, Database, Truck, Gauge, Globe,
  Plus, Eye, Copy, FileCheck2, ListChecks, Lightbulb,
  ClipboardList, Search,
} from "lucide-react";

interface Template {
  id: string;
  name: string;
  description: string;
  category: "Standard" | "Security" | "Data" | "Vendor" | "Capacity" | "Customer-Facing";
  icon: React.ReactNode;
  accent: string;
  sections: { title: string; description: string }[];
  estTime: string;
  usageCount: number;
  fields: string[];
}

const templates: Template[] = [
  {
    id: "tpl-standard",
    name: "Standard Postmortem",
    description: "Default blameless postmortem template for most production incidents. Covers impact, root cause, contributing factors, action items, and lessons learned.",
    category: "Standard",
    icon: <FileText className="w-5 h-5" />,
    accent: "primary",
    estTime: "30-45 min",
    usageCount: 142,
    sections: [
      { title: "Impact Summary", description: "User-facing and business impact with quantified metrics." },
      { title: "Root Cause", description: "The technical reason the incident occurred." },
      { title: "Contributing Factors", description: "Conditions that amplified or enabled the failure." },
      { title: "Action Items", description: "Concrete, owned, dated remediation tasks." },
      { title: "Lessons Learned", description: "What went well, what didn't, what to change." },
    ],
    fields: ["Incident Ref", "Severity", "Duration", "Commander", "Responders", "Customer Impact"],
  },
  {
    id: "tpl-security",
    name: "Security Incident",
    description: "Structured postmortem for security breaches, vulnerability exploits, and access-control failures. Includes blast radius and detection gaps.",
    category: "Security",
    icon: <ShieldAlert className="w-5 h-5" />,
    accent: "destructive",
    estTime: "60-90 min",
    usageCount: 18,
    sections: [
      { title: "Impact Summary", description: "Affected systems, accounts, data, and security boundaries." },
      { title: "Root Cause", description: "Vector, exploited weakness, and entry point." },
      { title: "Contributing Factors", description: "Detection gaps, misconfigurations, missing controls." },
      { title: "Action Items", description: "Remediation, hardening, and detection improvements." },
      { title: "Lessons Learned", description: "Threat model gaps, control failures, and process changes." },
    ],
    fields: ["CVE / Vector", "Blast Radius", "Data Classes", "Detection Time", "Containment Time", "IR Lead"],
  },
  {
    id: "tpl-data",
    name: "Data Incident",
    description: "Postmortem for data loss, corruption, consistency violations, or migration failures. Focuses on data integrity and recovery.",
    category: "Data",
    icon: <Database className="w-5 h-5" />,
    accent: "info",
    estTime: "45-60 min",
    usageCount: 23,
    sections: [
      { title: "Impact Summary", description: "Records affected, scope of corruption or loss." },
      { title: "Root Cause", description: "Schema, query, or migration failure mechanism." },
      { title: "Contributing Factors", description: "Missing constraints, lack of validation, backup gaps." },
      { title: "Action Items", description: "Recovery, integrity checks, and prevention controls." },
      { title: "Lessons Learned", description: "Data-handling and migration process improvements." },
    ],
    fields: ["Records Affected", "Data Classes", "Recovery Time", "Backup Status", "Migration Ref", "DBA Lead"],
  },
  {
    id: "tpl-vendor",
    name: "Vendor-Caused",
    description: "Postmortem template for incidents caused by third-party provider outages, API changes, or upstream regressions.",
    category: "Vendor",
    icon: <Truck className="w-5 h-5" />,
    accent: "warning",
    estTime: "30-45 min",
    usageCount: 31,
    sections: [
      { title: "Impact Summary", description: "Customer impact caused by the vendor failure." },
      { title: "Root Cause", description: "Vendor-side issue and the dependency path." },
      { title: "Contributing Factors", description: "Single-vendor dependency, no fallback, no circuit breaker." },
      { title: "Action Items", description: "Mitigation, fallback strategy, vendor SLA review." },
      { title: "Lessons Learned", description: "Vendor risk management and dependency isolation." },
    ],
    fields: ["Vendor", "Vendor Incident Ref", "Dependency Path", "Fallback Available", "Vendor SLA", "Owner"],
  },
  {
    id: "tpl-capacity",
    name: "Capacity Event",
    description: "Postmortem for saturation, throttling, or scaling failures. Includes load analysis and capacity planning follow-ups.",
    category: "Capacity",
    icon: <Gauge className="w-5 h-5" />,
    accent: "accent",
    estTime: "45-60 min",
    usageCount: 27,
    sections: [
      { title: "Impact Summary", description: "Degraded performance, throttling, or outage duration." },
      { title: "Root Cause", description: "Bottleneck resource and triggering load pattern." },
      { title: "Contributing Factors", description: "Missing autoscaling, capacity review, or alert thresholds." },
      { title: "Action Items", description: "Capacity scaling, alert tuning, headroom targets." },
      { title: "Lessons Learned", description: "Capacity planning and load testing improvements." },
    ],
    fields: ["Peak Load", "Saturation Point", "Auto-scaling Status", "Headroom %", "Trigger Pattern", "Capacity Owner"],
  },
  {
    id: "tpl-customer",
    name: "Customer-Facing Outage",
    description: "External-impact postmortem requiring executive review, customer communication log, and SLA-credit considerations.",
    category: "Customer-Facing",
    icon: <Globe className="w-5 h-5" />,
    accent: "destructive",
    estTime: "60-90 min",
    usageCount: 12,
    sections: [
      { title: "Impact Summary", description: "External duration, affected regions, customer count, SLA breach." },
      { title: "Root Cause", description: "The trigger and propagation path of the customer-visible failure." },
      { title: "Contributing Factors", description: "Single points of failure, slow detection, escalation delay." },
      { title: "Action Items", description: "Prevention, faster detection, communication automation." },
      { title: "Lessons Learned", description: "Status-page process, customer comms, executive review." },
    ],
    fields: ["External Duration", "Customer Count", "Regions", "SLA Breach", "Status Page Refs", "Exec Sponsor"],
  },
];

const categoryConfig: Record<Template["category"], { className: string; icon: React.ReactNode }> = {
  "Standard": { className: "bg-primary/15 text-primary border-primary/30", icon: <FileText className="w-3 h-3" /> },
  "Security": { className: "bg-destructive/15 text-destructive border-destructive/30", icon: <ShieldAlert className="w-3 h-3" /> },
  "Data": { className: "bg-info/15 text-info-foreground border-info/30", icon: <Database className="w-3 h-3" /> },
  "Vendor": { className: "bg-warning/15 text-warning-foreground border-warning/30", icon: <Truck className="w-3 h-3" /> },
  "Capacity": { className: "bg-accent text-accent-foreground border-accent/30", icon: <Gauge className="w-3 h-3" /> },
  "Customer-Facing": { className: "bg-destructive/20 text-destructive border-destructive/40", icon: <Globe className="w-3 h-3" /> },
};

const accentBg: Record<string, string> = {
  primary: "bg-primary/10 border-primary/20 text-primary",
  destructive: "bg-destructive/10 border-destructive/20 text-destructive",
  info: "bg-info/10 border-info/20 text-info-foreground",
  warning: "bg-warning/10 border-warning/20 text-warning-foreground",
  accent: "bg-accent/10 border-accent/20 text-accent-foreground",
};

const sectionIcons: React.ReactNode[] = [
  <ClipboardList key="0" className="w-3.5 h-3.5" />,
  <Search key="1" className="w-3.5 h-3.5" />,
  <ListChecks key="2" className="w-3.5 h-3.5" />,
  <FileCheck2 key="3" className="w-3.5 h-3.5" />,
  <Lightbulb key="4" className="w-3.5 h-3.5" />,
];

export default function PostmortemTemplatesPage() {
  const [activeCategory, setActiveCategory] = React.useState<string>("All");
  const categories = ["All", "Standard", "Security", "Data", "Vendor", "Capacity", "Customer-Facing"];
  const filtered = activeCategory === "All" ? templates : templates.filter((t) => t.category === activeCategory);

  function handleUse(tpl: Template) {
    toast.success(`Template "${tpl.name}" applied`, {
      description: `Started a new postmortem draft with ${tpl.sections.length} sections.`,
    });
  }

  function handlePreview(tpl: Template) {
    toast.info(`Previewing "${tpl.name}"`, {
      description: `Estimated time to complete: ${tpl.estTime}.`,
    });
  }

  function handleDuplicate(tpl: Template) {
    toast.success(`Duplicated "${tpl.name}"`, {
      description: "A copy has been added to your team templates.",
    });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Postmortem Templates"
        description="Reusable blameless postmortem structures tailored by incident class. Pick a template to start a new draft with predefined sections."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Postmortems", href: "/postmortems" }, { label: "Templates" }]}
        icon={<FileText className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening template editor")}>
            <Plus className="w-3.5 h-3.5" /> New Template
          </Button>
        }
      />

      {/* Category filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setActiveCategory(c)}
            className={`px-3 py-1.5 rounded-md text-xs font-medium border transition-colors ${
              activeCategory === c
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card text-muted-foreground border-border hover:bg-muted/50"
            }`}
          >
            {c}
          </button>
        ))}
        <div className="ml-auto text-xs text-muted-foreground self-center">
          {filtered.length} of {templates.length} templates
        </div>
      </div>

      {/* Template grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((tpl) => {
          const cat = categoryConfig[tpl.category];
          return (
            <Card key={tpl.id} className="p-5 flex flex-col gap-4 transition-all hover:shadow-md hover:border-primary/30">
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0">
                  <div className={`shrink-0 w-10 h-10 rounded-lg flex items-center justify-center border ${accentBg[tpl.accent]}`}>
                    {tpl.icon}
                  </div>
                  <div className="min-w-0 space-y-1">
                    <h3 className="text-sm font-semibold leading-tight">{tpl.name}</h3>
                    <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${cat.className}`}>
                      {cat.icon}
                      {tpl.category}
                    </span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-muted-foreground line-clamp-3 leading-relaxed">
                {tpl.description}
              </p>

              {/* Sections preview */}
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Sections preview</p>
                <div className="space-y-1 max-h-44 overflow-y-auto pr-1">
                  {tpl.sections.map((s, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs">
                      <span className="shrink-0 mt-0.5 text-primary">{sectionIcons[i % sectionIcons.length]}</span>
                      <div className="min-w-0">
                        <p className="font-medium leading-tight">{s.title}</p>
                        <p className="text-[11px] text-muted-foreground line-clamp-1">{s.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Metadata footer */}
              <div className="flex items-center gap-3 text-[11px] text-muted-foreground pt-2 border-t border-border">
                <span className="inline-flex items-center gap-1">
                  <Gauge className="w-3 h-3" />
                  {tpl.estTime}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  {tpl.usageCount} uses
                </span>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 mt-auto">
                <Button size="sm" className="gap-1.5 flex-1" onClick={() => handleUse(tpl)}>
                  <Plus className="w-3.5 h-3.5" /> Use Template
                </Button>
                <Button size="sm" variant="outline" className="gap-1.5" onClick={() => handlePreview(tpl)}>
                  <Eye className="w-3.5 h-3.5" />
                  <span className="sr-only">Preview</span>
                </Button>
                <Button size="sm" variant="outline" className="gap-1.5" onClick={() => handleDuplicate(tpl)}>
                  <Copy className="w-3.5 h-3.5" />
                  <span className="sr-only">Duplicate</span>
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Bottom guidance card */}
      <Card className="p-5">
        <SectionHeading
          title="Standard Section Definitions"
          description="Every SentinelGrid postmortem template includes these five core sections to ensure consistent blameless review."
        />
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          {[
            { i: <ClipboardList className="w-4 h-4" />, t: "Impact", d: "Quantified user & business impact" },
            { i: <Search className="w-4 h-4" />, t: "Root Cause", d: "Technical reason the incident occurred" },
            { i: <ListChecks className="w-4 h-4" />, t: "Contributing Factors", d: "Conditions that amplified the failure" },
            { i: <FileCheck2 className="w-4 h-4" />, t: "Action Items", d: "Owned, dated remediation tasks" },
            { i: <Lightbulb className="w-4 h-4" />, t: "Lessons", d: "What went well, what didn't" },
          ].map((s, i) => (
            <div key={i} className="rounded-lg border border-border p-3 space-y-1.5">
              <div className="w-7 h-7 rounded-md bg-primary/10 text-primary flex items-center justify-center">{s.i}</div>
              <p className="text-xs font-semibold">{s.t}</p>
              <p className="text-[11px] text-muted-foreground leading-relaxed">{s.d}</p>
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
