"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  LineChartCard, DonutChart, HorizontalBarChart,
} from "@/components/charts";
import { SeverityBadge } from "@/components/common/badges";
import { postmortems, people } from "@/lib/data";
import { toast } from "sonner";
import {
  BarChart3, FileText, Clock, CheckCircle2, RotateCcw,
  Download, TrendingUp, AlertTriangle, Users, ListChecks,
  Activity, Calendar, ChevronRight,
} from "lucide-react";

// Mock trend: postmortems per month (last 12 months)
const monthlyTrend = [
  { date: "Aug", value: 4 },
  { date: "Sep", value: 6 },
  { date: "Oct", value: 5 },
  { date: "Nov", value: 8 },
  { date: "Dec", value: 7 },
  { date: "Jan", value: 9 },
  { date: "Feb", value: 6 },
  { date: "Mar", value: 11 },
  { date: "Apr", value: 8 },
  { date: "May", value: 10 },
  { date: "Jun", value: 12 },
  { date: "Jul", value: 7 },
];

// Common root cause categories
const rootCauseData = [
  { name: "Config Change", value: 11, color: "#22D3EE" },
  { name: "Deploy", value: 9, color: "#A78BFA" },
  { name: "Dependency", value: 7, color: "#34D399" },
  { name: "Capacity", value: 5, color: "#F59E0B" },
  { name: "Bug", value: 4, color: "#F87171" },
  { name: "Third-Party", value: 3, color: "#94A3B8" },
];

// Action item status distribution template (values computed at render)
const actionStatusTemplate = [
  { name: "Done", color: "#34D399" },
  { name: "In Progress", color: "#22D3EE" },
  { name: "Todo", color: "#F59E0B" },
  { name: "Cancelled", color: "#94A3B8" },
];

// Repeat root cause rate (mock: months where same root cause category repeated)
const repeatByMonth = [
  { date: "Aug", value: 0 },
  { date: "Sep", value: 1 },
  { date: "Oct", value: 0 },
  { date: "Nov", value: 2 },
  { date: "Dec", value: 1 },
  { date: "Jan", value: 2 },
  { date: "Feb", value: 1 },
  { date: "Mar", value: 3 },
  { date: "Apr", value: 2 },
  { date: "May", value: 3 },
  { date: "Jun", value: 2 },
  { date: "Jul", value: 1 },
];

export default function PostmortemAnalyticsPage() {
  // Build action item ownership distribution
  const ownership: Record<string, number> = {};
  const statusCounts: Record<string, number> = { done: 0, in_progress: 0, todo: 0, cancelled: 0 };
  postmortems.forEach((p) => {
    p.actionItems.forEach((a) => {
      const person = people.find((x) => x.id === a.ownerId);
      const key = person?.name || "Unassigned";
      ownership[key] = (ownership[key] || 0) + 1;
      statusCounts[a.status] = (statusCounts[a.status] || 0) + 1;
    });
  });
  const ownershipBars = Object.entries(ownership)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);

  const actionStatusData = actionStatusTemplate.map((t) => {
    const value =
      t.name === "Done" ? statusCounts.done
      : t.name === "In Progress" ? statusCounts.in_progress
      : t.name === "Todo" ? statusCounts.todo
      : statusCounts.cancelled;
    return { ...t, value };
  });

  const totalActions = postmortems.flatMap((p) => p.actionItems).length;
  const completedActions = statusCounts.done;
  const completionRate = totalActions > 0 ? Math.round((completedActions / totalActions) * 100) : 0;

  // Avg time to publish (mock: createdAt -> publishedAt)
  const publishedPMs = postmortems.filter((p) => p.publishedAt);
  const avgPublishHours = publishedPMs.length > 0
    ? Math.round(publishedPMs.reduce((sum, p) => {
        const diff = new Date(p.publishedAt!).getTime() - new Date(p.createdAt).getTime();
        return sum + diff / (1000 * 60 * 60);
      }, 0) / publishedPMs.length * 10) / 10
    : 0;

  // Repeat root cause rate (mock)
  const repeatRate = 28;

  // Recent postmortems with action item status
  const recentPMs = [...postmortems]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  return (
    <PageContainer>
      <PageHeader
        title="Postmortem Analytics"
        description="Trends, root cause patterns, and action item follow-through across all blameless postmortems."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Postmortems", href: "/postmortems" }, { label: "Analytics" }]}
        icon={<BarChart3 className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Last 12 months</span>
            </Button>
          </>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Postmortems (30d)"
          value={7}
          delta={16}
          deltaLabel="vs prev 30d"
          icon={<FileText className="w-4 h-4" />}
          accent="primary"
          hint={`${postmortems.length} all time`}
        />
        <KpiCard
          label="Avg Time to Publish"
          value={avgPublishHours}
          unit="hrs"
          delta={-12}
          deltaLabel="vs last quarter"
          icon={<Clock className="w-4 h-4" />}
          accent="info"
          hint="From incident resolution"
        />
        <KpiCard
          label="Action Item Completion"
          value={`${completionRate}%`}
          delta={6}
          deltaLabel="vs last quarter"
          icon={<CheckCircle2 className="w-4 h-4" />}
          accent="success"
          hint={`${completedActions}/${totalActions} done`}
        />
        <KpiCard
          label="Repeat Root Cause Rate"
          value={`${repeatRate}%`}
          delta={-4}
          deltaLabel="vs last quarter"
          icon={<RotateCcw className="w-4 h-4" />}
          accent="warning"
          hint="Same category as prior 90d"
        />
      </div>

      {/* Trend + Donut row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-4 lg:col-span-2">
          <SectionHeading
            title="Postmortems per Month"
            description="Volume of postmortems authored over the last 12 months"
            action={<TrendingUp className="w-4 h-4 text-success" />}
          />
          <div className="mt-4 h-[280px]">
            <LineChartCard
              data={monthlyTrend}
              dataKey="value"
              color={0}
              height={280}
            />
          </div>
        </Card>
        <Card className="p-4">
          <SectionHeading
            title="Root Cause Categories"
            description="Distribution across recent postmortems"
          />
          <div className="mt-2 h-[280px]">
            <DonutChart
              data={rootCauseData}
              centerValue={String(rootCauseData.reduce((s, d) => s + d.value, 0))}
              centerLabel="total PMs"
            />
          </div>
        </Card>
      </div>

      {/* Repeat root cause trend + Action status row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-4 lg:col-span-2">
          <SectionHeading
            title="Repeat Root Cause Incidents"
            description="Months where the same root cause category recurred within 90 days"
            action={<AlertTriangle className="w-4 h-4 text-warning" />}
          />
          <div className="mt-4 h-[240px]">
            <LineChartCard
              data={repeatByMonth}
              dataKey="value"
              color={4}
              height={240}
            />
          </div>
        </Card>
        <Card className="p-4">
          <SectionHeading
            title="Action Items by Status"
            description={`${totalActions} total across all PMs`}
          />
          <div className="mt-4 space-y-3">
            {actionStatusData.map((s) => {
              const pct = totalActions > 0 ? Math.round((s.value / totalActions) * 100) : 0;
              return (
                <div key={s.name} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium">{s.name}</span>
                    <span className="text-muted-foreground tabular-nums">{s.value} ({pct}%)</span>
                  </div>
                  <Progress value={pct} className="h-1.5" />
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Action item ownership distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <SectionHeading
            title="Action Item Ownership"
            description="Top owners by open action item count"
            action={<Users className="w-4 h-4 text-muted-foreground" />}
          />
          <div className="mt-4 h-[300px]">
            <HorizontalBarChart
              data={ownershipBars}
              color={2}
            />
          </div>
        </Card>

        {/* Recent postmortems with action progress */}
        <Card className="p-4">
          <SectionHeading
            title="Recent Postmortems"
            description="Latest 5 postmortems with action item progress"
            action={
              <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
                <Link href="/postmortems">
                  View all <ChevronRight className="w-3 h-3" />
                </Link>
              </Button>
            }
          />
          <div className="mt-4 space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {recentPMs.map((pm) => {
              const author = people.find((p) => p.id === pm.authorId);
              const done = pm.actionItems.filter((a) => a.status === "done").length;
              const pct = pm.actionItems.length > 0 ? Math.round((done / pm.actionItems.length) * 100) : 0;
              return (
                <Link
                  key={pm.id}
                  href={`/postmortems/${pm.id}`}
                  className="block rounded-lg border border-border p-3 hover:bg-muted/40 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[11px] font-mono text-primary">{pm.ref}</span>
                        <SeverityBadge severity={pm.severity} size="sm" />
                      </div>
                      <p className="text-xs font-medium line-clamp-1">{pm.title}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        {author?.name} - {new Date(pm.createdAt).toLocaleDateString([], { month: "short", day: "numeric" })}
                      </p>
                    </div>
                    <div className="shrink-0 text-right space-y-1">
                      <div className="flex items-center gap-1.5 justify-end">
                        <Progress value={pct} className="w-12 h-1.5" />
                        <span className="text-[11px] tabular-nums text-muted-foreground">{done}/{pm.actionItems.length}</span>
                      </div>
                      <div className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
                        <ListChecks className="w-3 h-3" />
                        {pct}%
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Top recurring root causes summary */}
      <Card className="p-4">
        <SectionHeading
          title="Root Cause Heatmap"
          description="Frequency and recurrence of root cause categories across the last 12 months"
          action={<Activity className="w-4 h-4 text-muted-foreground" />}
        />
        <div className="mt-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {rootCauseData.map((rc) => (
            <div key={rc.name} className="rounded-lg border border-border p-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="w-2 h-2 rounded-full" style={{ background: rc.color }} />
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Category</span>
              </div>
              <p className="text-xs font-semibold leading-tight">{rc.name}</p>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-semibold tabular-nums">{rc.value}</span>
                <span className="text-[10px] text-muted-foreground">occurrences</span>
              </div>
              <Progress value={Math.round((rc.value / rootCauseData.reduce((s, d) => s + d.value, 0)) * 100)} className="h-1" />
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
