"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DataTable, type Column } from "@/components/tables/data-table";
import { SeverityBadge } from "@/components/common/badges";
import { postmortems, people } from "@/lib/data";
import type { PostmortemActionItem } from "@/lib/types";
import { toast } from "sonner";
import {
  CheckSquare, Circle, Clock, XCircle, CheckCircle2, AlertTriangle,
  Calendar, User, Target, ListChecks, Eye, ShieldAlert, TrendingUp,
} from "lucide-react";

const statusConfig: Record<PostmortemActionItem["status"], { label: string; className: string; icon: React.ReactNode; pct: number }> = {
  todo: { label: "To Do", className: "bg-muted text-muted-foreground border-border", icon: <Circle className="w-3 h-3" />, pct: 0 },
  in_progress: { label: "In Progress", className: "bg-info/15 text-info-foreground border-info/30", icon: <Clock className="w-3 h-3" />, pct: 50 },
  done: { label: "Done", className: "bg-success/15 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" />, pct: 100 },
  cancelled: { label: "Cancelled", className: "bg-muted text-muted-foreground border-border", icon: <XCircle className="w-3 h-3" />, pct: 100 },
};

const typeIcon: Record<PostmortemActionItem["type"], React.ReactNode> = {
  detection: <Eye className="w-3 h-3" />,
  mitigation: <ShieldAlert className="w-3 h-3" />,
  prevention: <CheckCircle2 className="w-3 h-3" />,
  process: <ListChecks className="w-3 h-3" />,
  tooling: <Target className="w-3 h-3" />,
};

export default function ActionItemsPage() {
  const [items, setItems] = React.useState<PostmortemActionItem[]>(() =>
    postmortems.flatMap((p) => p.actionItems.map((a) => ({ ...a, postmortemRef: p.ref, postmortemTitle: p.title })))
  );

  function cycleStatus(id: string) {
    setItems((prev) => prev.map((a) => {
      if (a.id !== id) return a;
      const cycle: PostmortemActionItem["status"][] = ["todo", "in_progress", "done", "cancelled"];
      return { ...a, status: cycle[(cycle.indexOf(a.status) + 1) % cycle.length] };
    }));
    toast.success("Status updated");
  }

  const total = items.length;
  const done = items.filter((a) => a.status === "done").length;
  const inProgress = items.filter((a) => a.status === "in_progress").length;
  const overdue = items.filter((a) => a.status !== "done" && a.status !== "cancelled" && new Date(a.dueDate) < new Date("2026-07-10")).length;
  const completionRate = total > 0 ? Math.round((done / total) * 100) : 0;

  const columns: Column<PostmortemActionItem & { postmortemRef?: string; postmortemTitle?: string }>[] = [
    {
      key: "status",
      header: "Status",
      sortable: true,
      filterable: true,
      width: "120px",
      sortValue: (r) => r.status,
      filterOptions: [
        { label: "To Do", value: "todo" },
        { label: "In Progress", value: "in_progress" },
        { label: "Done", value: "done" },
        { label: "Cancelled", value: "cancelled" },
      ],
      filterFn: (r, v) => r.status === v,
      cell: (r) => {
        const s = statusConfig[r.status];
        return (
          <button onClick={() => cycleStatus(r.id)} className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium ${s.className}`}>
            {s.icon} {s.label}
          </button>
        );
      },
    },
    {
      key: "description",
      header: "Action Item",
      sortable: true,
      sortValue: (r) => r.description,
      cell: (r) => (
        <div className="min-w-0">
          <div className={`text-sm font-medium line-clamp-1 ${r.status === "done" || r.status === "cancelled" ? "text-muted-foreground line-through" : ""}`}>
            {r.description}
          </div>
          <div className="text-[11px] text-muted-foreground mt-0.5">
            <Link href={`/postmortems/${r.postmortemId}`} className="font-mono text-primary hover:underline">{r.postmortemRef}</Link>
            {" — "}
            <span className="line-clamp-1">{r.postmortemTitle}</span>
          </div>
        </div>
      ),
    },
    {
      key: "type",
      header: "Type",
      sortable: true,
      filterable: true,
      hideOnMobile: true,
      sortValue: (r) => r.type,
      filterOptions: [
        { label: "Detection", value: "detection" },
        { label: "Mitigation", value: "mitigation" },
        { label: "Prevention", value: "prevention" },
        { label: "Process", value: "process" },
        { label: "Tooling", value: "tooling" },
      ],
      filterFn: (r, v) => r.type === v,
      cell: (r) => <Badge variant="outline" className="text-[10px] capitalize gap-1">{typeIcon[r.type]} {r.type}</Badge>,
    },
    {
      key: "priority",
      header: "Priority",
      sortable: true,
      filterable: true,
      hideOnMobile: true,
      sortValue: (r) => ({ critical: 0, high: 1, medium: 2, low: 3 }[r.priority]),
      filterOptions: [
        { label: "Critical", value: "critical" },
        { label: "High", value: "high" },
        { label: "Medium", value: "medium" },
        { label: "Low", value: "low" },
      ],
      filterFn: (r, v) => r.priority === v,
      cell: (r) => <SeverityBadge severity={r.priority} size="sm" />,
    },
    {
      key: "owner",
      header: "Owner",
      hideOnMobile: true,
      cell: (r) => {
        const o = people.find((p) => p.id === r.ownerId);
        if (!o) return <span className="text-xs text-muted-foreground">—</span>;
        return (
          <div className="flex items-center gap-1.5">
            <Avatar className="w-6 h-6">
              <AvatarImage src={o.avatarUrl} />
              <AvatarFallback>{o.name[0]}</AvatarFallback>
            </Avatar>
            <span className="text-xs truncate">{o.name}</span>
          </div>
        );
      },
    },
    {
      key: "dueDate",
      header: "Due Date",
      sortable: true,
      align: "right",
      sortValue: (r) => new Date(r.dueDate).getTime(),
      cell: (r) => {
        const isOverdue = r.status !== "done" && r.status !== "cancelled" && new Date(r.dueDate) < new Date("2026-07-10");
        return (
          <span className={`text-xs tabular-nums ${isOverdue ? "text-destructive font-semibold" : "text-muted-foreground"}`}>
            {new Date(r.dueDate).toLocaleDateString([], { month: "short", day: "numeric" })}
            {isOverdue && <AlertTriangle className="w-3 h-3 inline ml-1" />}
          </span>
        );
      },
    },
  ];

  // Type distribution
  const typeDistribution = (["detection", "mitigation", "prevention", "process", "tooling"] as const).map((t) => ({
    name: t.charAt(0).toUpperCase() + t.slice(1),
    value: items.filter((i) => i.type === t).length,
  }));

  return (
    <PageContainer>
      <PageHeader
        title="Action Items Tracker"
        description="All action items across all postmortems. Click a status to cycle through states."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Postmortems", href: "/postmortems" }, { label: "Action Items" }]}
        icon={<CheckSquare className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Action Items" value={total} hint="Across all postmortems" icon={<CheckSquare className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Completed" value={done} hint={`${completionRate}% completion rate`} icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="In Progress" value={inProgress} hint="Currently being worked" icon={<Clock className="w-4 h-4" />} accent="info" />
        <KpiCard label="Overdue" value={overdue} hint="Past due date" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <SectionHeading
            title="All Action Items"
            description="Click status to cycle, click ref to view postmortem"
          />
          <div className="mt-4">
            <DataTable
              columns={columns}
              data={items}
              rowKey={(r) => r.id}
              searchKeys={["description", (r) => {
                const pm = postmortems.find((p) => p.id === r.postmortemId);
                return `${pm?.ref || ""} ${pm?.title || ""}`;
              }]}
              searchPlaceholder="Search action items..."
              pageSize={12}
              initialSort={{ key: "dueDate", dir: "asc" }}
            />
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Completion Progress" description="Across all action items" />
            <div className="flex items-center justify-center">
              <div className="relative w-32 h-32">
                <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                  <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" strokeWidth="8" className="text-muted" />
                  <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" strokeWidth="8" strokeDasharray={`${2 * Math.PI * 42}`} strokeDashoffset={`${2 * Math.PI * 42 * (1 - completionRate / 100)}`} strokeLinecap="round" className="text-success transition-all" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold tabular-nums">{completionRate}%</span>
                  <span className="text-[10px] text-muted-foreground">complete</span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-center pt-2">
              <div className="rounded-md border p-2">
                <div className="text-lg font-semibold tabular-nums text-success">{done}</div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Done</div>
              </div>
              <div className="rounded-md border p-2">
                <div className="text-lg font-semibold tabular-nums text-info">{inProgress}</div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">In Progress</div>
              </div>
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="By Type" description="Distribution of action items" />
            <div className="space-y-2">
              {typeDistribution.map((t) => {
                const pct = total > 0 ? Math.round((t.value / total) * 100) : 0;
                return (
                  <div key={t.name}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-medium">{t.name}</span>
                      <span className="text-muted-foreground tabular-nums">{t.value} ({pct}%)</span>
                    </div>
                    <Progress value={pct} className="h-1.5" />
                  </div>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Top Owners" description="Most action items assigned" />
            <div className="space-y-2">
              {Object.entries(items.reduce((acc, i) => { acc[i.ownerId] = (acc[i.ownerId] ?? 0) + 1; return acc; }, {} as Record<string, number>))
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5)
                .map(([id, count]) => {
                  const p = people.find((x) => x.id === id);
                  if (!p) return null;
                  return (
                    <div key={id} className="flex items-center gap-2">
                      <Avatar className="w-6 h-6"><AvatarImage src={p.avatarUrl} /><AvatarFallback>{p.name[0]}</AvatarFallback></Avatar>
                      <span className="text-xs truncate flex-1">{p.name}</span>
                      <Badge variant="outline" className="text-[10px] h-5 tabular-nums">{count}</Badge>
                    </div>
                  );
                })}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}


