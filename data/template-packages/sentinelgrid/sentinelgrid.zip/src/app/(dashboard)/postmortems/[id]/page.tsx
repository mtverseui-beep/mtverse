"use client";

import * as React from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { SeverityBadge } from "@/components/common/badges";
import { postmortems, people, incidents } from "@/lib/data";
import type { PostmortemActionItem } from "@/lib/types";
import { toast } from "sonner";
import {
  FileText, ArrowLeft, Clock, CheckCircle2, Circle, AlertTriangle,
  BookOpen, Lightbulb, ChevronRight, ShieldAlert, Eye, Send,
  CheckCheck, XCircle, Calendar, User, Plus, Target, ListChecks,
} from "lucide-react";

const actionStatusConfig: Record<PostmortemActionItem["status"], { label: string; className: string; icon: React.ReactNode }> = {
  todo: { label: "To Do", className: "bg-muted text-muted-foreground border-border", icon: <Circle className="w-3 h-3" /> },
  in_progress: { label: "In Progress", className: "bg-info/15 text-info-foreground border-info/30", icon: <Clock className="w-3 h-3" /> },
  done: { label: "Done", className: "bg-success/15 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
  cancelled: { label: "Cancelled", className: "bg-muted text-muted-foreground border-border line-through", icon: <XCircle className="w-3 h-3" /> },
};

const actionTypeIcon: Record<PostmortemActionItem["type"], React.ReactNode> = {
  detection: <Eye className="w-3 h-3" />,
  mitigation: <ShieldAlert className="w-3 h-3" />,
  prevention: <CheckCircle2 className="w-3 h-3" />,
  process: <ListChecks className="w-3 h-3" />,
  tooling: <Target className="w-3 h-3" />,
};

const statusConfig: Record<string, { label: string; className: string; icon: React.ReactNode }> = {
  draft: { label: "Draft", className: "bg-muted text-muted-foreground border-border", icon: <FileText className="w-3 h-3" /> },
  in_review: { label: "In Review", className: "bg-warning/15 text-warning-foreground border-warning/30", icon: <AlertTriangle className="w-3 h-3" /> },
  approved: { label: "Approved", className: "bg-info/15 text-info-foreground border-info/30", icon: <CheckCheck className="w-3 h-3" /> },
  published: { label: "Published", className: "bg-success/15 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
  archived: { label: "Archived", className: "bg-muted text-muted-foreground border-border", icon: <FileText className="w-3 h-3" /> },
};

const severityColor: Record<string, string> = {
  critical: "border-l-destructive",
  high: "border-l-warning",
  medium: "border-l-info",
  low: "border-l-muted-foreground",
};

export default function PostmortemDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const id = (params?.id as string) || "pm1";
  const pm = postmortems.find((p) => p.id === id) || postmortems[0];
  const incident = incidents.find((i) => i.id === pm.incidentId);
  const author = people.find((p) => p.id === pm.authorId);
  const reviewers = pm.reviewerIds.map((rid) => people.find((p) => p.id === rid)).filter(Boolean);
  const [actionItems, setActionItems] = React.useState(pm.actionItems);

  function cycleStatus(itemId: string) {
    setActionItems((prev) => prev.map((a) => {
      if (a.id !== itemId) return a;
      const cycle: PostmortemActionItem["status"][] = ["todo", "in_progress", "done", "cancelled"];
      const idx = cycle.indexOf(a.status);
      const next = cycle[(idx + 1) % cycle.length];
      return { ...a, status: next };
    }));
    toast.success("Action item updated");
  }

  const done = actionItems.filter((a) => a.status === "done").length;
  const completionPct = actionItems.length > 0 ? Math.round((done / actionItems.length) * 100) : 0;
  const status = statusConfig[pm.status];

  return (
    <PageContainer wide>
      <PageHeader
        title={pm.title}
        description={`Postmortem for ${incident?.ref ?? pm.incidentId} · ${incident?.title ?? ""}`}
        breadcrumbs={[
          { label: "Home", href: "/dashboard" },
          { label: "Postmortems", href: "/postmortems" },
          { label: pm.ref },
        ]}
        icon={<FileText className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => router.push("/postmortems")}>
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Back</span>
            </Button>
            {pm.status === "in_review" || pm.status === "draft" ? (
              <Button size="sm" className="gap-1.5" onClick={() => toast.success("Postmortem submitted for review")}>
                <Send className="w-3.5 h-3.5" /> Submit for Review
              </Button>
            ) : pm.status === "approved" ? (
              <Button size="sm" className="gap-1.5" onClick={() => toast.success("Postmortem published")}>
                <CheckCircle2 className="w-3.5 h-3.5" /> Publish
              </Button>
            ) : (
              <Button asChild size="sm" variant="outline" className="gap-1.5">
                <Link href={`/incidents/${pm.incidentId}`}>View Incident <ChevronRight className="w-3.5 h-3.5" /></Link>
              </Button>
            )}
          </>
        }
        meta={
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-mono text-muted-foreground">{pm.ref}</span>
            <SeverityBadge severity={pm.severity} size="sm" />
            <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium ${status.className}`}>{status.icon} {status.label}</span>
          </div>
        }
      />

      {/* Hero banner */}
      <Card className={`p-5 border-l-4 ${severityColor[pm.severity]} bg-gradient-to-r from-muted/40 to-transparent`}>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Incident</div>
            {incident && <Link href={`/incidents/${incident.id}`} className="text-sm font-mono font-semibold text-primary hover:underline">{incident.ref}</Link>}
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Severity</div>
            <SeverityBadge severity={pm.severity} size="sm" />
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Duration</div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-sm font-semibold tabular-nums">{pm.durationHours}h</span>
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Author</div>
            <div className="text-sm font-medium">{author?.name ?? "—"}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Created</div>
            <div className="text-sm font-medium">{new Date(pm.createdAt).toLocaleDateString()}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Published</div>
            <div className="text-sm font-medium">{pm.publishedAt ? new Date(pm.publishedAt).toLocaleDateString() : "—"}</div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
        <div className="xl:col-span-3 space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Impact Summary" description="What happened, who was affected, and how severely" />
            <p className="text-sm text-foreground leading-relaxed">{pm.impactSummary}</p>
            {incident && (
              <div className="rounded-md border border-destructive/30 bg-destructive/5 p-3 mt-2">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-destructive shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs font-medium text-destructive">Customer Impact Statement</div>
                    <p className="text-xs text-foreground mt-1">{incident.customerImpact}</p>
                  </div>
                </div>
              </div>
            )}
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Root Cause" description="The underlying technical cause" />
            <p className="text-sm text-foreground leading-relaxed">{pm.rootCause}</p>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Contributing Factors" description="Conditions that allowed the incident to occur or worsen" />
            <ul className="space-y-2">
              {pm.contributingFactors.map((f, i) => (
                <li key={i} className="flex items-start gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-warning/15 text-warning-foreground border border-warning/30 flex items-center justify-center text-[10px] font-semibold shrink-0 mt-0.5">
                    {i + 1}
                  </div>
                  <p className="text-sm text-foreground leading-relaxed">{f}</p>
                </li>
              ))}
            </ul>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Timeline" description="Key events during the incident" />
            <div className="space-y-1">
              {pm.timeline.map((t, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="relative flex flex-col items-center">
                    <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                    {i < pm.timeline.length - 1 && <div className="w-px flex-1 bg-border" style={{ minHeight: "24px" }} />}
                  </div>
                  <div className="flex-1 min-w-0 pb-3">
                    <div className="text-[11px] text-muted-foreground">{new Date(t.timestamp).toLocaleString()}</div>
                    <p className="text-sm text-foreground mt-0.5">{t.event}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Lessons Learned" description="What we learned from this incident" />
            <ul className="space-y-2">
              {pm.lessons.map((l, i) => (
                <li key={i} className="flex items-start gap-2.5 p-2.5 rounded-md border bg-muted/20">
                  <Lightbulb className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-sm text-foreground leading-relaxed">{l}</p>
                </li>
              ))}
            </ul>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading
              title="Action Items"
              description={`${done} of ${actionItems.length} completed`}
              action={
                <div className="flex items-center gap-2">
                  <Progress value={completionPct} className="w-24 h-1.5" />
                  <span className="text-xs tabular-nums text-muted-foreground">{completionPct}%</span>
                </div>
              }
            />
            <div className="space-y-1.5">
              {actionItems.map((a) => {
                const owner = people.find((p) => p.id === a.ownerId);
                const s = actionStatusConfig[a.status];
                return (
                  <div key={a.id} className="rounded-lg border p-3 hover:bg-elevated/30 transition-colors">
                    <div className="flex items-start gap-3">
                      <button onClick={() => cycleStatus(a.id)} className="mt-0.5 shrink-0">
                        {a.status === "done" ? <CheckCircle2 className="w-4 h-4 text-success" /> : a.status === "cancelled" ? <XCircle className="w-4 h-4 text-muted-foreground" /> : <Circle className="w-4 h-4 text-muted-foreground" />}
                      </button>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${a.status === "done" || a.status === "cancelled" ? "text-muted-foreground line-through" : "text-foreground"}`}>{a.description}</p>
                        <div className="flex items-center gap-1.5 flex-wrap mt-2">
                          <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${s.className}`}>{s.icon} {s.label}</span>
                          <Badge variant="outline" className="text-[10px] h-5 capitalize gap-1">{actionTypeIcon[a.type]} {a.type}</Badge>
                          <SeverityBadge severity={a.priority} size="sm" />
                          {owner && (
                            <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
                              <img src={owner.avatarUrl} alt="" className="w-4 h-4 rounded-full object-cover" />
                              {owner.name}
                            </span>
                          )}
                          <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground ml-auto">
                            <Calendar className="w-3 h-3" /> Due {a.dueDate}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
              <button className="w-full flex items-center gap-2 p-2 rounded-lg border border-dashed hover:bg-muted/40 text-muted-foreground text-xs">
                <Plus className="w-3.5 h-3.5" /> Add action item
              </button>
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Tags" description="Classification tags" />
            <div className="flex flex-wrap gap-1">
              {pm.tags.map((t) => (
                <Badge key={t} variant="outline" className="text-[10px] px-1.5 h-5">#{t}</Badge>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-4 space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-muted-foreground" /> Author
            </h3>
            {author && (
              <div className="flex items-center gap-3">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={author.avatarUrl} />
                  <AvatarFallback>{author.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">{author.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{author.title}</div>
                </div>
              </div>
            )}
          </Card>

          <Card className="p-4 space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-muted-foreground" /> Reviewers ({reviewers.length})
            </h3>
            <div className="space-y-1.5">
              {reviewers.map((r) => (
                <div key={r!.id} className="flex items-center gap-2">
                  <Avatar className="w-7 h-7">
                    <AvatarImage src={r!.avatarUrl} />
                    <AvatarFallback>{r!.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium truncate">{r!.name}</div>
                    <div className="text-[10px] text-muted-foreground truncate">{r!.title}</div>
                  </div>
                  <Badge variant="outline" className="text-[10px] h-4 bg-success/10 text-success">Approved</Badge>
                </div>
              ))}
            </div>
            <Button size="sm" variant="outline" className="w-full h-8 text-xs gap-1.5" onClick={() => toast.info("Add reviewer dialog")}>
              <Plus className="w-3 h-3" /> Add Reviewer
            </Button>
          </Card>

          {incident && (
            <Card className="p-4 space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-muted-foreground" /> Linked Incident
              </h3>
              <Link href={`/incidents/${incident.id}`} className="block p-2 rounded-md border hover:bg-muted/40 transition-colors">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-[10px] font-mono text-muted-foreground">{incident.ref}</span>
                  <SeverityBadge severity={incident.severity} size="sm" />
                </div>
                <div className="text-xs font-medium line-clamp-1">{incident.title}</div>
                <div className="text-[10px] text-muted-foreground mt-1">Duration: {incident.resolutionSlaSeconds ? Math.round(incident.resolutionSlaSeconds / 60) : "—"} min</div>
              </Link>
            </Card>
          )}

          <Card className="p-4 space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-muted-foreground" /> Quick Actions
            </h3>
            <div className="space-y-1.5">
              <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start gap-1.5" onClick={() => toast.info("Opened in editor")}>
                <FileText className="w-3 h-3" /> Edit Postmortem
              </Button>
              <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start gap-1.5" onClick={() => toast.success("Link copied")}>
                <BookOpen className="w-3 h-3" /> Copy Share Link
              </Button>
              <Button variant="outline" size="sm" className="w-full h-8 text-xs justify-start gap-1.5" onClick={() => toast.success("Exported as PDF")}>
                <FileText className="w-3 h-3" /> Export as PDF
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
