"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { DocsSidebar, CodeBlock, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { Palette, ArrowRight, ArrowLeft, Sun, Moon } from "lucide-react";

const sectionNav = [
  { id: "color-tokens", label: "Color Tokens" },
  { id: "dark-light", label: "Dark & Light Mode" },
  { id: "css-variables", label: "CSS Variables" },
  { id: "custom-palette", label: "Custom Palette" },
];

const swatches = [
  { name: "background", token: "--background", light: "oklch(0.985 0.002 240)", dark: "oklch(0.14 0.005 240)" },
  { name: "card", token: "--card", light: "oklch(1 0 0)", dark: "oklch(0.18 0.006 240)" },
  { name: "primary", token: "--primary", light: "oklch(0.62 0.13 200)", dark: "oklch(0.78 0.13 195)" },
  { name: "accent", token: "--accent", light: "oklch(0.96 0.015 280)", dark: "oklch(0.28 0.04 290)" },
  { name: "success", token: "--success", light: "oklch(0.6 0.13 150)", dark: "oklch(0.72 0.15 155)" },
  { name: "warning", token: "--warning", light: "oklch(0.7 0.16 75)", dark: "oklch(0.78 0.16 75)" },
  { name: "destructive", token: "--destructive", light: "oklch(0.58 0.22 25)", dark: "oklch(0.68 0.21 22)" },
  { name: "info", token: "--info", light: "oklch(0.6 0.12 230)", dark: "oklch(0.72 0.13 230)" },
  { name: "border", token: "--border", light: "oklch(0.9 0.005 240)", dark: "oklch(1 0 0 / 8%)" },
  { name: "muted-foreground", token: "--muted-foreground", light: "oklch(0.5 0.01 240)", dark: "oklch(0.66 0.008 240)" },
];

const chartSwatches = [
  { name: "chart-1", token: "--chart-1", hex: "#22D3EE" },
  { name: "chart-2", token: "--chart-2", hex: "#A78BFA" },
  { name: "chart-3", token: "--chart-3", hex: "#F59E0B" },
  { name: "chart-4", token: "--chart-4", hex: "#34D399" },
  { name: "chart-5", token: "--chart-5", hex: "#F87171" },
  { name: "chart-6", token: "--chart-6", hex: "#FB923C" },
  { name: "chart-7", token: "--chart-7", hex: "#60A5FA" },
  { name: "chart-8", token: "--chart-8", hex: "#71717A" },
];

export default function ThemeGuidePage() {
  const [dark, setDark] = React.useState(true);
  React.useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [dark]);

  return (
    <PageContainer wide>
      <PageHeader
        title="Theme Customization"
        description="Customize colors, dark mode tokens, and build your brand palette."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Theme" }]}
        icon={<Palette className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">{s.label}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody>
          <H1>Theme Customization</H1>
          <Lead>SentinelGrid uses CSS variables defined with <InlineCode>oklch()</InlineCode> color space for perceptually uniform lightness. Dark mode is the default and is toggled by adding the <InlineCode>.dark</InlineCode> class to <InlineCode>&lt;html&gt;</InlineCode>.</Lead>

          {/* Live theme toggle demo */}
          <Card className="p-5 my-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {dark ? <Moon className="w-5 h-5 text-primary" /> : <Sun className="w-5 h-5 text-primary" />}
              <div>
                <p className="text-sm font-medium">{dark ? "Dark mode" : "Light mode"} active</p>
                <p className="text-xs text-muted-foreground">Toggle to see tokens swap in real time.</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Label htmlFor="theme-toggle" className="text-xs text-muted-foreground">Light</Label>
              <Switch id="theme-toggle" checked={dark} onCheckedChange={setDark} />
              <Label htmlFor="theme-toggle" className="text-xs text-muted-foreground">Dark</Label>
            </div>
          </Card>

          <H2 id="color-tokens">Color Tokens</H2>
          <P>SentinelGrid defines semantic color tokens (background, card, primary, etc.) plus status tokens (success, warning, destructive, info) and an eight-color chart palette. Each token has a light and a dark variant.</P>
          <Card className="my-4 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-2 font-semibold">Token</th>
                    <th className="text-left px-4 py-2 font-semibold">Variable</th>
                    <th className="text-left px-4 py-2 font-semibold">Light</th>
                    <th className="text-left px-4 py-2 font-semibold">Dark</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-subtle">
                  {swatches.map((s) => (
                    <tr key={s.name}>
                      <td className="px-4 py-2 font-medium text-xs">{s.name}</td>
                      <td className="px-4 py-2 font-mono text-xs text-muted-foreground">{s.token}</td>
                      <td className="px-4 py-2">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded border" style={{ background: s.light }} />
                          <span className="text-[10px] font-mono text-muted-foreground">{s.light}</span>
                        </div>
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded border" style={{ background: s.dark }} />
                          <span className="text-[10px] font-mono text-muted-foreground">{s.dark}</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <H3>Chart palette</H3>
          <P>The chart palette is indexed 1–8 and used by every chart wrapper. Colors are tuned for accessibility in both themes.</P>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 my-4">
            {chartSwatches.map((c) => (
              <Card key={c.name} className="p-3">
                <div className="w-full h-12 rounded-md" style={{ background: c.hex }} />
                <p className="text-xs font-medium mt-2">{c.name}</p>
                <p className="text-[10px] font-mono text-muted-foreground">{c.token}</p>
                <p className="text-[10px] font-mono text-muted-foreground">{c.hex}</p>
              </Card>
            ))}
          </div>

          <H2 id="dark-light">Dark & Light Mode</H2>
          <P>Theme state is stored in <InlineCode>localStorage</InlineCode> under <InlineCode>sentinelgrid-theme</InlineCode>. A blocking inline script in the root layout applies the class before hydration to prevent a flash of incorrect theme.</P>
          <CodeBlock language="tsx" title="src/app/layout.tsx (inline script)" code={`<script
  dangerouslySetInnerHTML={{
    __html: \`
      try {
        const stored = localStorage.getItem('sentinelgrid-theme');
        const theme = stored || 'dark';
        if (theme === 'dark') document.documentElement.classList.add('dark');
        else document.documentElement.classList.remove('dark');
      } catch (_) {
        document.documentElement.classList.add('dark');
      }
    \`,
  }}
/>`} />
          <P>To toggle themes, use the <InlineCode>next-themes</InlineCode> package (already wired in the root layout) or manipulate the class directly:</P>
          <CodeBlock language="tsx" title="Theme toggle button" code={`"use client";
import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";

export function ThemeToggle() {
  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => document.documentElement.classList.toggle("dark")}
    >
      <Sun className="w-4 h-4 dark:hidden" />
      <Moon className="w-4 h-4 hidden dark:block" />
    </Button>
  );
}`} />

          <H2 id="css-variables">CSS Variables</H2>
          <P>Variables live in <InlineCode>globals.css</InlineCode> under the <InlineCode>:root</InlineCode> (light) and <InlineCode>.dark</InlineCode> selectors. Tailwind v4 maps them through the <InlineCode>@theme inline</InlineCode> block so utilities like <InlineCode>bg-primary</InlineCode> resolve correctly.</P>
          <CodeBlock language="css" title="src/app/globals.css (excerpt)" code={`@theme inline {
  --color-primary: var(--primary);
  --color-background: var(--background);
  --color-card: var(--card);
  /* ... */
}

:root {
  --primary: oklch(0.62 0.13 200);
}

.dark {
  --primary: oklch(0.78 0.13 195);
}`} />

          <H2 id="custom-palette">Adding a Custom Palette</H2>
          <P>To rebrand SentinelGrid, replace the primary and accent OKLCH values in both <InlineCode>:root</InlineCode> and <InlineCode>.dark</InlineCode>. Keep the lightness similar so contrast ratios are preserved.</P>
          <CodeBlock language="css" title="Rebranding to a green primary" code={`:root {
  --primary: oklch(0.6 0.15 150);   /* was cyan */
}
.dark {
  --primary: oklch(0.72 0.16 155);  /* was cyan */
  --sidebar-primary: oklch(0.72 0.16 155);
}`} />
          <Callout variant="info" title="OKLCH primer">
            <InlineCode>oklch(L C H)</InlineCode> stands for lightness, chroma, hue. Hue is in degrees (0–360), so swapping from cyan (200) to violet (290) is a single number change. Lightness stays at 0.62 in light mode and 0.78 in dark mode for consistency.
          </Callout>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/routing"><ArrowLeft className="w-4 h-4 mr-1.5" />Routing</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/charts">Next: Charts Guide<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
