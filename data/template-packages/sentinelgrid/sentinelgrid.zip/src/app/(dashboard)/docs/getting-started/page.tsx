"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DocsSidebar, CodeBlock, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { Rocket, ArrowRight, ArrowLeft, Check, Terminal, Folder, FileText, Database, Lightbulb, Zap } from "lucide-react";

const sectionNav = [
  { id: "installation", label: "Installation" },
  { id: "project-structure", label: "Project Structure" },
  { id: "running-dev-server", label: "Running Dev Server" },
  { id: "first-page", label: "First Page" },
  { id: "adding-data", label: "Adding Data" },
];

export default function GettingStartedPage() {
  return (
    <PageContainer wide>
      <PageHeader
        title="Getting Started"
        description="Install SentinelGrid, run the dev server, and ship your first engineering ops page."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Getting Started" }]}
        icon={<Rocket className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody>
          <H1>Getting Started</H1>
          <Lead>
            SentinelGrid is a production-ready Next.js 16 template for engineering operations, observability, and incident response. This guide walks you through installation, the project structure, and shipping your first page in under five minutes.
          </Lead>

          <H2 id="installation">Installation</H2>
          <P>
            SentinelGrid ships as a complete Next.js project. Clone the repository, install dependencies, and you are ready to go. The project uses <InlineCode>bun</InlineCode> by default but works with any modern package manager.
          </P>
          <CodeBlock language="bash" title="Terminal" code={`# Clone the template
git clone https://github.com/sentinelgrid/sentinelgrid.git my-console
cd my-console

# Install dependencies
bun install

# Initialize the database (SQLite via Prisma)
bun run db:push

# Start the dev server
bun run dev`} />
          <Callout variant="info" title="Requirements">
            Node.js 20+, Bun 1.0+ (or npm/yarn/pnpm), and Git. The project targets Next.js 16 with Turbopack enabled.
          </Callout>

          <H3>Verify your install</H3>
          <P>Open the preview panel and you should see the SentinelGrid dashboard load with the default dark theme. The sidebar contains every route the template ships with.</P>

          <H2 id="project-structure">Project Structure</H2>
          <P>SentinelGrid uses the Next.js App Router with route groups to separate concerns. Here is the high-level layout:</P>
          <CodeBlock language="text" title="Directory layout" code={`src/
├── app/
│   ├── (dashboard)/         # Dashboard shell (sidebar + header)
│   │   ├── dashboard/       # Engineering overview + sub-dashboards
│   │   ├── incidents/       # Incident management
│   │   ├── services/        # Service catalog
│   │   ├── reliability/     # SLOs, error budgets, uptime
│   │   ├── deployments/     # Release management
│   │   ├── docs/            # This documentation site
│   │   └── admin/           # Admin & settings
│   ├── (auth)/              # Sign in, sign up, onboarding
│   ├── landing/             # Public marketing pages
│   ├── errors/              # 401, 403, 404, 500, 503, ...
│   ├── layout.tsx           # Root layout, fonts, ThemeProvider
│   └── page.tsx             # Redirects to /dashboard
├── components/
│   ├── charts/              # Theme-aware Recharts wrappers
│   ├── tables/              # DataTable system
│   ├── common/              # KpiCard, badges, page-header
│   ├── layout/              # Sidebar, header, right-panel
│   └── ui/                  # shadcn/ui primitives
├── lib/
│   ├── data.ts              # In-memory mock data layer
│   ├── types.ts             # Domain types
│   ├── nav.ts               # Sidebar navigation config
│   └── store.ts             # Zustand UI stores`} />
          <Callout variant="default" title="Convention">
            Route groups in parentheses like <InlineCode>(dashboard)</InlineCode> do not appear in the URL but let you share layouts. This keeps the dashboard shell isolated from public marketing routes.
          </Callout>

          <H2 id="running-dev-server">Running the Dev Server</H2>
          <P>The dev server runs on port 3000 with Turbopack for fast HMR. The sandbox auto-starts the server for you, but here are the commands you will use locally:</P>
          <CodeBlock language="bash" title="npm scripts" code={`bun run dev          # Start dev server with Turbopack
bun run lint         # Run ESLint
bun run db:push      # Push Prisma schema to SQLite
bun run db:studio    # Open Prisma Studio`} />
          <Callout variant="warning" title="Port 3000 only">
            The sandbox exposes a single port externally. If you spin up mini-services (e.g., a websocket service), use the gateway query parameter <InlineCode>?XTransformPort=3030</InlineCode> instead of a direct localhost URL.
          </Callout>

          <H2 id="first-page">Your First Page</H2>
          <P>Every dashboard page follows the same pattern: <InlineCode>PageContainer</InlineCode> for spacing, <InlineCode>PageHeader</InlineCode> for the title and breadcrumbs, then content cards.</P>
          <CodeBlock language="tsx" title="src/app/(dashboard)/my-team/page.tsx" code={`"use client";

import { PageContainer, PageHeader } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Users } from "lucide-react";

export default function MyTeamPage() {
  return (
    <PageContainer>
      <PageHeader
        title="My Team"
        description="Manage your engineering team."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "My Team" }]}
        icon={<Users className="w-5 h-5" />}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Members" value={12} icon={<Users className="w-4 h-4" />} />
      </div>
      <Card className="p-6">
        <p className="text-sm text-muted-foreground">Team details go here.</p>
      </Card>
    </PageContainer>
  );
}`} />
          <P>Add the new route to <InlineCode>src/lib/nav.ts</InlineCode> so it appears in the sidebar:</P>
          <CodeBlock language="ts" title="src/lib/nav.ts" code={`{
  label: "My Team",
  href: "/my-team",
  icon: "Users",
}`} />

          <H2 id="adding-data">Adding Data</H2>
          <P>
            SentinelGrid ships with an in-memory mock data layer at <InlineCode>src/lib/data.ts</InlineCode>. To add a new domain entity, define a type in <InlineCode>src/lib/types.ts</InlineCode>, then export a typed array from <InlineCode>data.ts</InlineCode>.
          </P>
          <CodeBlock language="ts" title="src/lib/types.ts" code={`export interface Deployment {
  id: string;
  serviceId: string;
  version: string;
  status: "succeeded" | "failed" | "rolling_out" | "rolled_back";
  startedAt: string;
  endedAt?: string;
  authorId: string;
}`} />
          <CodeBlock language="ts" title="src/lib/data.ts" code={`export const deployments: Deployment[] = [
  {
    id: "d1",
    serviceId: "s1",
    version: "v2.14.0",
    status: "succeeded",
    startedAt: "2024-09-12T10:00:00Z",
    endedAt: "2024-09-12T10:04:32Z",
    authorId: "u2",
  },
  // ...
];`} />
          <Callout variant="info" title="Tip">
            Use the <InlineCode>person(id)</InlineCode> and <InlineCode>team(id)</InlineCode> helpers to resolve references without writing joins. The mock layer is intentionally simple so you can swap it for a real API later.
          </Callout>

          {/* Steps recap */}
          <Card className="p-6 bg-muted/30">
            <div className="flex items-center gap-2 mb-4">
              <Check className="w-4 h-4 text-success" />
              <h3 className="text-sm font-semibold">You are ready</h3>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2"><Check className="w-3.5 h-3.5 text-success mt-0.5 shrink-0" />Project installed and dev server running</li>
              <li className="flex items-start gap-2"><Check className="w-3.5 h-3.5 text-success mt-0.5 shrink-0" />Understand the route group layout</li>
              <li className="flex items-start gap-2"><Check className="w-3.5 h-3.5 text-success mt-0.5 shrink-0" />Created your first dashboard page</li>
              <li className="flex items-start gap-2"><Check className="w-3.5 h-3.5 text-success mt-0.5 shrink-0" />Added mock data for a new domain entity</li>
            </ul>
          </Card>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs"><ArrowLeft className="w-4 h-4 mr-1.5" />Back to overview</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/components">Next: Component Guide<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
