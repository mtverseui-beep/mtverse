"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { DocsSidebar, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { Scale, ArrowRight, ArrowLeft, Check, X, FileText } from "lucide-react";

const sectionNav = [
  { id: "summary", label: "License Summary" },
  { id: "can-do", label: "What You Can Do" },
  { id: "cannot-do", label: "What You Cannot Do" },
  { id: "full-license", label: "Full License" },
  { id: "faq", label: "FAQ" },
];

const faqs = [
  {
    q: "Can I use SentinelGrid for a commercial product?",
    a: "Yes. The commercial license permits use of SentinelGrid in unlimited commercial products, internal tools, and customer-facing applications, for up to the licensed number of developers.",
  },
  {
    q: "Can I modify the source code?",
    a: "Yes. You can modify, extend, and fork the source code for your own use. Modified versions remain covered by this license and may not be redistributed or resold.",
  },
  {
    q: "Can I resell SentinelGrid as a template?",
    a: "No. Reselling, redistributing, or sublicensing SentinelGrid (or a derivative) as a standalone product is strictly prohibited. The license grants usage rights, not redistribution rights.",
  },
  {
    q: "How many developers does a single license cover?",
    a: "The standard commercial license covers up to 5 developers. For larger teams, purchase additional seats or upgrade to the Enterprise tier which covers unlimited developers within one organization.",
  },
  {
    q: "Do I need to attribute SentinelGrid in my product?",
    a: "No attribution is required in production. We do ask that you keep the copyright notice in source code files.",
  },
  {
    q: "What happens if I cancel my subscription?",
    a: "You retain perpetual usage rights for the version of SentinelGrid you have downloaded under the license, including any fixes released during your subscription period. New versions require an active subscription.",
  },
  {
    q: "Is there a refund policy?",
    a: "Yes. If SentinelGrid does not meet your needs, contact support within 14 days of purchase for a full refund.",
  },
];

export default function LicensePage() {
  return (
    <PageContainer wide>
      <PageHeader
        title="License"
        description="Commercial license terms for SentinelGrid."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "License" }]}
        icon={<Scale className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">{s.label}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody className="max-w-3xl">
          <H1>License</H1>
          <Lead>SentinelGrid is released under a commercial license. This page summarizes what you can and cannot do, followed by the full license text and an FAQ.</Lead>

          <H2 id="summary">License Summary</H2>
          <P>
            SentinelGrid is licensed on a per-developer basis. Purchasing a license grants you the right to use SentinelGrid in unlimited commercial and internal projects, modify the source, and distribute the resulting applications to your customers. You may not resell or redistribute SentinelGrid itself as a template, theme, or starter kit.
          </P>
          <Callout variant="info" title="Quick summary">
            Buy once, build unlimited products. Modify freely. No redistribution. No resale.
          </Callout>

          <H2 id="can-do">What You Can Do</H2>
          <Card className="my-4 p-5 border-success/30 bg-success/5">
            <ul className="space-y-2.5">
              {[
                "Use SentinelGrid in unlimited commercial products, internal tools, and customer-facing apps",
                "Modify, extend, and fork the source code for your own use",
                "Distribute applications built on SentinelGrid to your customers",
                "Use SentinelGrid in private repositories",
                "Use SentinelGrid in production with no attribution required",
                "Access the source code in full",
                "Receive updates and bug fixes during your subscription period",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-success mt-0.5 shrink-0" />
                  <span className="text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </Card>

          <H2 id="cannot-do">What You Cannot Do</H2>
          <Card className="my-4 p-5 border-destructive/30 bg-destructive/5">
            <ul className="space-y-2.5">
              {[
                "Resell, redistribute, or sublicense SentinelGrid as a standalone product, template, or starter kit",
                "Publish SentinelGrid (or a derivative) to a public template marketplace",
                "Share your license key with developers outside the licensed seat count",
                "Use SentinelGrid to build a competing product template or theme",
                "Remove or alter copyright notices in source code files",
                "Use SentinelGrid beyond the licensed developer count without purchasing additional seats",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <X className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
                  <span className="text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </Card>

          <H2 id="full-license">Full License Text</H2>
          <Card className="my-4 p-6 bg-muted/30">
            <div className="flex items-center gap-2 mb-4">
              <FileText className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">SentinelGrid Commercial License Agreement</h3>
            </div>
            <div className="prose prose-sm max-w-none space-y-3 text-sm text-muted-foreground leading-relaxed font-mono">
              <p><strong>Version 1.0 — September 12, 2024</strong></p>
              <p>
                This Commercial License Agreement ("Agreement") is a legal agreement between you (either an individual or a single entity, "Licensee") and SentinelGrid, Inc. ("Licensor") for the software product SentinelGrid ("Software"), which includes source code, documentation, and associated media.
              </p>
              <p><strong>1. Grant of License.</strong> Subject to the terms of this Agreement, Licensor grants Licensee a non-exclusive, non-transferable, worldwide, perpetual license to install, use, modify, and distribute the Software as part of Licensee's own applications ("Licensee Products"), for up to the number of developers specified on the license purchase receipt.</p>
              <p><strong>2. Modifications.</strong> Licensee may modify the Software to create derivative works for use in Licensee Products. All derivative works remain subject to this Agreement and may not be redistributed or resold except as embedded in Licensee Products.</p>
              <p><strong>3. Restrictions.</strong> Licensee may not: (a) resell, sublicense, rent, lease, or distribute the Software as a standalone product, template, theme, or starter kit; (b) publish the Software, or any derivative, to a public marketplace, code-sharing site, or open-source repository; (c) use the Software beyond the licensed number of developers; (d) remove or alter any copyright or proprietary notices in the Software.</p>
              <p><strong>4. Intellectual Property.</strong> The Software is licensed, not sold. Licensor retains all right, title, and interest in and to the Software, including all intellectual property rights. This Agreement does not grant Licensee any rights to Licensor's trademarks or trade names.</p>
              <p><strong>5. Updates.</strong> During the active subscription period, Licensee is entitled to receive updates, bug fixes, and new versions of the Software at no additional cost. Upon subscription expiration, Licensee retains perpetual usage rights for the last version downloaded but loses access to future updates.</p>
              <p><strong>6. Support.</strong> Licensor provides support via email and community channels. Response time and priority levels depend on the purchased tier (Starter, Pro, or Enterprise) as described on the pricing page.</p>
              <p><strong>7. Warranty Disclaimer.</strong> The Software is provided "AS IS" without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall Licensor be liable for any claim, damages, or other liability arising from the use of the Software.</p>
              <p><strong>8. Limitation of Liability.</strong> In no event shall Licensor's total liability exceed the amount paid by Licensee for the Software in the twelve (12) months preceding the claim.</p>
              <p><strong>9. Termination.</strong> This Agreement terminates automatically if Licensee breaches any of its terms. Upon termination, Licensee must cease all use of the Software and destroy all copies.</p>
              <p><strong>10. Governing Law.</strong> This Agreement shall be governed by the laws of the State of California, without regard to its conflict of law provisions.</p>
              <p><strong>11. Entire Agreement.</strong> This Agreement constitutes the entire agreement between the parties and supersedes all prior or contemporaneous understandings.</p>
              <p className="text-xs pt-2">Copyright (c) 2024 SentinelGrid, Inc. All rights reserved.</p>
            </div>
          </Card>

          <H2 id="faq">Frequently Asked Questions</H2>
          <Accordion type="single" collapsible className="my-4">
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`item-${i}`}>
                <AccordionTrigger className="text-sm font-medium text-left">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <Callout variant="default" title="Need a custom license?">
            For enterprise-wide deployment, multi-organization usage, or bespoke terms, contact <InlineCode>sales@sentinelgrid.io</InlineCode> for a custom agreement.
          </Callout>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/changelog"><ArrowLeft className="w-4 h-4 mr-1.5" />Changelog</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/support">Next: Support<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
