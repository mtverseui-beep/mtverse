"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DocsSidebar, InlineCode, H1, Lead, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { RefreshCw, ArrowRight, ArrowLeft, Sparkles, Wrench, Bug, Rocket } from "lucide-react";

interface ChangelogEntry {
  version: string;
  date: string;
  tag: "stable" | "beta" | "alpha";
  sections: {
    New?: string[];
    Improved?: string[];
    Fixed?: string[];
  };
}

const entries: ChangelogEntry[] = [
  {
    version: "1.0.0",
    date: "September 12, 2024",
    tag: "stable",
    sections: {
      New: [
        "100+ production-ready routes across dashboards, incidents, reliability, deployments, performance, errors, infrastructure, security, and admin",
        "Engineering Overview dashboard with 15 KPIs, real-time charts, and team pulse",
        "Incident Command Center with timeline, war rooms, severity rules, and subscriber management",
        "SLO and error-budget system with burn-rate alerts and availability calendar",
        "Deployment pipeline view with approvals, change requests, and rollback",
        "Postmortem workflow with action items, analytics, and lessons learned",
        "Service catalog with ownership, dependencies, runbooks, and per-service metrics",
        "On-call management with rotations, handoffs, paging rules, and availability",
        "Admin workspace with team, roles, permissions matrix, API keys, webhooks, and integrations marketplace",
        "Premium marketing landing, features, preview, components-preview, and pricing pages",
        "Documentation site with 12 guides and changelog",
      ],
      Improved: [
        "Dark mode is now the default with refined OKLCH color tokens for both themes",
        "ChartContainer adds fullscreen dialog and PNG export to every chart",
        "DataTable gains column visibility dropdown and bulk action bar",
        "Mobile cards auto-render for every table on small viewports",
        "Command palette (Cmd+K) with fuzzy search across every route",
      ],
      Fixed: [
        "Flash of incorrect theme on first paint (blocking inline script in root layout)",
        "Sidebar nav scroller now respects safe-area insets on iOS",
        "Toaster stacking order on small screens",
      ],
    },
  },
  {
    version: "0.9.0",
    date: "August 28, 2024",
    tag: "beta",
    sections: {
      New: [
        "Auth flows: sign in, sign up, forgot password, reset password, verify email, two-factor, lock screen",
        "Onboarding wizard (4 steps: Welcome, Workspace, Team, Integrations)",
        "Error pages: 401, 403, 404, 408, 429, 500, 503, offline, maintenance, coming soon",
        "Admin billing, subscription, usage, security, sessions, profile, notifications, audit logs",
        "Settings workspace with 5 tabs (General, Branding, Authentication, Notifications, Advanced)",
      ],
      Improved: [
        "Sidebar collapses to icon-only mode on smaller viewports",
        "Right panel shows contextual activity feed per route",
        "Breadcrumbs auto-derive from sidebar nav config",
        "Theme tokens migrated to OKLCH color space",
      ],
      Fixed: [
        "Hover state leak on disabled buttons",
        "Tooltip clipping inside scroll areas",
        "Drawer focus trap now restores focus to trigger",
      ],
    },
  },
  {
    version: "0.5.0",
    date: "July 15, 2024",
    tag: "alpha",
    sections: {
      New: [
        "Initial project scaffold with Next.js 16 App Router and Turbopack",
        "shadcn/ui component library (New York style) wired with Tailwind v4",
        "Brand identity: SentinelGrid, hexagonal shield logo, cyan + violet palette",
        "First 30 dashboard pages covering incidents, services, deployments, and reliability",
        "Mock data layer with 26 typed entities",
        "Theme-aware chart system (10 wrappers) and DataTable with all features",
      ],
      Improved: [
        "Color tokens defined for both light and dark themes",
        "Fonts: Geist Sans + Geist Mono via next/font",
      ],
      Fixed: [],
    },
  },
];

const tagConfig = {
  stable: { label: "Stable", className: "bg-success/15 text-success border-success/30" },
  beta: { label: "Beta", className: "bg-info/15 text-info-foreground border-info/30" },
  alpha: { label: "Alpha", className: "bg-warning/15 text-warning-foreground border-warning/30" },
};

const sectionIcons = {
  New: Sparkles,
  Improved: Wrench,
  Fixed: Bug,
};

const sectionColors = {
  New: "text-success",
  Improved: "text-info-foreground",
  Fixed: "text-warning-foreground",
};

export default function ChangelogPage() {
  return (
    <PageContainer wide>
      <PageHeader
        title="Changelog"
        description="What's new in SentinelGrid."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Changelog" }]}
        icon={<RefreshCw className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <DocsBody className="max-w-3xl">
          <H1>Changelog</H1>
          <Lead>All notable changes to SentinelGrid are documented here. Versions follow semantic versioning.</Lead>

          <div className="relative mt-8 pl-6 border-l border-border">
            {entries.map((entry, i) => {
              const TagIcon = entry.tag === "stable" ? Rocket : entry.tag === "beta" ? Wrench : Sparkles;
              return (
                <div key={entry.version} className="relative pb-10 last:pb-0">
                  {/* Timeline dot */}
                  <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-background border-2 border-primary flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                  </div>

                  <Card className="p-6">
                    <div className="flex items-start justify-between gap-3 mb-4 flex-wrap">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h2 className="text-xl font-semibold tracking-tight">v{entry.version}</h2>
                          <Badge variant="outline" className={tagConfig[entry.tag].className}>
                            <TagIcon className="w-3 h-3 mr-1" />
                            {tagConfig[entry.tag].label}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{entry.date}</p>
                      </div>
                      {i === 0 && (
                        <Badge className="bg-primary/15 text-primary border-primary/30">Latest</Badge>
                      )}
                    </div>

                    <div className="space-y-5">
                      {(Object.keys(entry.sections) as Array<keyof typeof entry.sections>).map((sectionKey) => {
                        const items = entry.sections[sectionKey];
                        if (!items || items.length === 0) return null;
                        const Icon = sectionIcons[sectionKey];
                        return (
                          <div key={sectionKey}>
                            <div className="flex items-center gap-2 mb-2">
                              <Icon className={`w-3.5 h-3.5 ${sectionColors[sectionKey]}`} />
                              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                                {sectionKey}
                              </h3>
                            </div>
                            <ul className="space-y-1.5">
                              {items.map((item, idx) => (
                                <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                                  <span className="w-1 h-1 rounded-full bg-muted-foreground/50 mt-2 shrink-0" />
                                  <span className="leading-relaxed">{item}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        );
                      })}
                    </div>
                  </Card>
                </div>
              );
            })}
          </div>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/deployment"><ArrowLeft className="w-4 h-4 mr-1.5" />Deployment</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/license">Next: License<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
