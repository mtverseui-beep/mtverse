"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DocsSidebar, CodeBlock, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { Route, ArrowRight, ArrowLeft, Folder, FileText, Layers, RefreshCw, AlertTriangle } from "lucide-react";

const sectionNav = [
  { id: "app-router", label: "App Router" },
  { id: "route-groups", label: "Route Groups" },
  { id: "dynamic-routes", label: "Dynamic Routes" },
  { id: "layouts", label: "Layouts" },
  { id: "loading-states", label: "Loading States" },
  { id: "error-boundaries", label: "Error Boundaries" },
];

export default function RoutingGuidePage() {
  return (
    <PageContainer wide>
      <PageHeader
        title="Routing Guide"
        description="Master Next.js 16 App Router patterns used throughout SentinelGrid."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Routing" }]}
        icon={<Route className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">{s.label}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody>
          <H1>Routing Guide</H1>
          <Lead>SentinelGrid uses the Next.js 16 App Router. Every route is a folder with a <InlineCode>page.tsx</InlineCode>, layouts are shared via route groups, and dynamic segments use the <InlineCode>[id]</InlineCode> syntax.</Lead>

          <H2 id="app-router">App Router Fundamentals</H2>
          <P>The App Router is file-system based. Each folder under <InlineCode>app/</InlineCode> maps to a URL segment. A folder becomes a route when it contains a <InlineCode>page.tsx</InlineCode> file.</P>
          <CodeBlock language="text" title="App Router mapping" code={`app/
├── page.tsx                  →  /
├── dashboard/
│   ├── page.tsx              →  /dashboard
│   └── incident-command/
│       └── page.tsx          →  /dashboard/incident-command
└── incidents/
    ├── page.tsx              →  /incidents
    └── [id]/
        └── page.tsx          →  /incidents/INC-123`} />

          <H2 id="route-groups">Route Groups</H2>
          <P>Route groups use parentheses (<InlineCode>(name)</InlineCode>) to organize routes without affecting the URL. SentinelGrid uses three:</P>
          <UL>
            <li><InlineCode>(dashboard)</InlineCode> — every authenticated app page shares the sidebar + header shell</li>
            <li><InlineCode>(auth)</InlineCode> — sign in, sign up, onboarding, password reset</li>
            <li><InlineCode>(marketing)</InlineCode> — landing, features, pricing (not used in this template; marketing pages live at top-level routes instead)</li>
          </UL>
          <CodeBlock language="tsx" title="src/app/(dashboard)/layout.tsx" code={`"use client";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 overflow-y-auto">
          <div className="animate-fade-up">{children}</div>
        </main>
      </div>
      <RightPanel />
    </div>
  );
}`} />
          <Callout variant="info" title="Why route groups?">
            Because <InlineCode>(dashboard)</InlineCode> does not appear in the URL, the route <InlineCode>/(dashboard)/incidents/page.tsx</InlineCode> resolves to <InlineCode>/incidents</InlineCode>, not <InlineCode>/dashboard/incidents</InlineCode>. This keeps URLs clean while still sharing a layout.
          </Callout>

          <H2 id="dynamic-routes">Dynamic Routes</H2>
          <P>Dynamic segments are created by wrapping a folder name in square brackets: <InlineCode>[id]</InlineCode>. Access the param with the <InlineCode>useParams()</InlineCode> hook on the client.</P>
          <CodeBlock language="tsx" title="src/app/(dashboard)/incidents/[id]/page.tsx" code={`"use client";
import { useParams } from "next/navigation";
import { incidents } from "@/lib/data";

export default function IncidentDetailPage() {
  const params = useParams<{ id: string }>();
  const incident = incidents.find((i) => i.id === params.id) ?? incidents[0];
  return (
    <PageContainer>
      <PageHeader title={incident.title} />
      {/* ... */}
    </PageContainer>
  );
}`} />
          <P>For detail pages, always provide a graceful fallback when the ID is missing or invalid. SentinelGrid detail pages fall back to the first entity so the preview never breaks.</P>

          <H2 id="layouts">Layouts</H2>
          <P>Layouts wrap child pages and preserve state across navigations. The root layout in <InlineCode>app/layout.tsx</InlineCode> loads fonts, mounts <InlineCode>ThemeProvider</InlineCode>, and registers global toasters.</P>
          <CodeBlock language="tsx" title="src/app/layout.tsx (excerpt)" code={`export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={\`\${geistSans.variable} \${geistMono.variable} antialiased\`}>
        <ThemeProvider>
          <UIStoreHydration />
          {children}
          <CommandPalette />
          <Toaster />
          <SonnerToaster position="bottom-right" />
        </ThemeProvider>
      </body>
    </html>
  );
}`} />
          <P>Nested layouts compose automatically. A page at <InlineCode>/(dashboard)/admin/team/[id]/page.tsx</InlineCode> renders inside three layouts: root, dashboard, and any layout in the <InlineCode>admin</InlineCode> folder.</P>

          <H2 id="loading-states">Loading States</H2>
          <P>Add a <InlineCode>loading.tsx</InlineCode> file alongside any <InlineCode>page.tsx</InlineCode> to show a fallback during route transitions or async server work. SentinelGrid provides a reusable <InlineCode>PageSkeleton</InlineCode> component.</P>
          <CodeBlock language="tsx" title="src/app/(dashboard)/incidents/loading.tsx" code={`import { PageContainer, PageSkeleton } from "@/components/common/page-header";

export default function Loading() {
  return (
    <PageContainer>
      <PageSkeleton cards={4} />
    </PageContainer>
  );
}`} />

          <H2 id="error-boundaries">Error Boundaries</H2>
          <P>An <InlineCode>error.tsx</InlineCode> file catches unhandled errors in any route segment. It must be a client component and accept <InlineCode>error</InlineCode> and <InlineCode>reset</InlineCode> props.</P>
          <CodeBlock language="tsx" title="src/app/(dashboard)/error.tsx" code={`"use client";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 px-6 text-center">
      <AlertTriangle className="w-10 h-10 text-destructive mb-4" />
      <h2 className="text-lg font-semibold">Something went wrong</h2>
      <p className="text-sm text-muted-foreground mt-1 max-w-md">{error.message}</p>
      <Button onClick={reset} className="mt-4">Try again</Button>
    </div>
  );
}`} />
          <Callout variant="warning" title="Global 404">
            SentinelGrid ships a global <InlineCode>not-found.tsx</InlineCode> at the root that renders a branded 404 for unmatched routes. You can also add route-specific <InlineCode>not-found.tsx</InlineCode> files for finer control.
          </Callout>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/components"><ArrowLeft className="w-4 h-4 mr-1.5" />Components</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/theme">Next: Theme Guide<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
