"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DocsSidebar, CodeBlock, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { Database, ArrowRight, ArrowLeft, Boxes, RefreshCw, Store, Server } from "lucide-react";

const sectionNav = [
  { id: "overview", label: "Overview" },
  { id: "data-layer", label: "Data Layer" },
  { id: "adding-entities", label: "Adding Entities" },
  { id: "swapping-real-api", label: "Swapping for Real API" },
  { id: "zustand-stores", label: "Zustand Stores" },
];

export default function MockApiGuidePage() {
  return (
    <PageContainer wide>
      <PageHeader
        title="Mock API Guide"
        description="Understand the in-memory data layer and how to swap it for real APIs."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Mock API" }]}
        icon={<Database className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">{s.label}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody>
          <H1>Mock API Guide</H1>
          <Lead>SentinelGrid ships with a complete in-memory data layer so you can prototype every page without a backend. When you are ready, swap the imports for real API calls — the page components do not need to change.</Lead>

          <H2 id="overview">Overview</H2>
          <P>The mock data layer lives in <InlineCode>src/lib/data.ts</InlineCode>. It exports typed arrays for every domain entity (incidents, services, deployments, alerts, etc.) plus a few helper functions for time-series generation.</P>
          <Card className="my-4 p-5">
            <p className="text-xs uppercase tracking-wider text-muted-foreground mb-3">What lives in data.ts</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
              {[
                "people", "teams", "services", "incidents", "postmortems",
                "slos", "deployments", "alerts", "alertRules", "onCallShifts",
                "escalationPolicies", "hosts", "k8sClusters", "errorGroups",
                "vulnerabilities", "auditEvents", "apiKeys", "webhooks",
                "integrations", "logEntries", "traceSpans", "changeRequests",
                "featureFlags", "runbooks", "uptimeRecords", "regions",
              ].map((n) => (
                <div key={n} className="flex items-center gap-1.5 text-xs">
                  <span className="w-1 h-1 rounded-full bg-primary" />
                  <code className="font-mono text-muted-foreground">{n}</code>
                </div>
              ))}
            </div>
          </Card>

          <H2 id="data-layer">The Data Layer</H2>
          <P>Each export is a typed array. Types are defined in <InlineCode>src/lib/types.ts</InlineCode> and imported into both <InlineCode>data.ts</InlineCode> and your page components. This means the TypeScript compiler catches shape mismatches at build time.</P>
          <CodeBlock language="ts" title="src/lib/types.ts (excerpt)" code={`export interface Incident {
  id: string;
  title: string;
  severity: "critical" | "high" | "medium" | "low" | "info";
  status: "investigating" | "identified" | "monitoring" | "mitigated" | "resolved" | "postmortem";
  serviceId: string;
  startedAt: string;
  resolvedAt?: string;
  commanderId: string;
  responderIds: string[];
  summary: string;
}`} />
          <CodeBlock language="ts" title="src/lib/data.ts (excerpt)" code={`export const incidents: Incident[] = [
  {
    id: "INC-2024-0912-01",
    title: "Payment gateway timeouts in EU region",
    severity: "critical",
    status: "investigating",
    serviceId: "s6",
    startedAt: "2024-09-12T08:14:00Z",
    commanderId: "u2",
    responderIds: ["u6", "u7"],
    summary: "Elevated 5xx responses from payments-eu cluster.",
  },
  // ... 30+ more
];`} />
          <P>Helper functions resolve foreign-key references without joins:</P>
          <CodeBlock language="ts" title="Helpers" code={`export function person(id: string): Person {
  return people.find((p) => p.id === id) ?? people[0];
}

export function team(id: string): Team | undefined {
  return teams.find((t) => t.id === id);
}

export function dashboardStats(): DashboardStats { /* ... */ }`} />

          <H2 id="adding-entities">Adding a New Entity</H2>
          <P>To add a new domain entity, follow these three steps:</P>
          <UL>
            <li><strong>1. Define the type</strong> in <InlineCode>src/lib/types.ts</InlineCode>.</li>
            <li><strong>2. Export a typed array</strong> from <InlineCode>src/lib/data.ts</InlineCode>.</li>
            <li><strong>3. Import and use it</strong> in your page component.</li>
          </UL>
          <CodeBlock language="ts" title="Adding a Runbook entity" code={`// 1. types.ts
export interface Runbook {
  id: string;
  title: string;
  serviceId: string;
  steps: string[];
  lastUpdated: string;
}

// 2. data.ts
export const runbooks: Runbook[] = [
  { id: "rb1", title: "Restart payment worker", serviceId: "s6", steps: ["..."], lastUpdated: "2024-09-01" },
];

// 3. your page
import { runbooks } from "@/lib/data";
const myRunbooks = runbooks.filter((r) => r.serviceId === "s6");`} />

          <H2 id="swapping-real-api">Swapping for a Real API</H2>
          <P>The pattern is to introduce a thin <InlineCode>api/</InlineCode> module that mirrors the shape of the mock exports. Pages import from <InlineCode>api/</InlineCode> instead of <InlineCode>data.ts</InlineCode>, so the swap is a one-line change per file.</P>
          <CodeBlock language="ts" title="src/lib/api/incidents.ts" code={`// Real implementation (server component or route handler)
import type { Incident } from "@/lib/types";

export async function getIncidents(): Promise<Incident[]> {
  const res = await fetch(\`\${process.env.API_URL}/incidents\`, {
    headers: { Authorization: \`Bearer \${process.env.API_TOKEN}\` },
    next: { revalidate: 30 },
  });
  if (!res.ok) throw new Error("Failed to load incidents");
  return res.json();
}`} />
          <Callout variant="info" title="Next.js fetch">
            Next.js 16 extends the native <InlineCode>fetch</InlineCode> with caching options. Use <InlineCode>next: {`{ revalidate: 30 }`}</InlineCode> for ISR-style caching, or <InlineCode>cache: "no-store"</InlineCode> for always-fresh data.
          </Callout>
          <P>For server components, fetch directly. For client components, create a Route Handler at <InlineCode>app/api/incidents/route.ts</InlineCode> and call it with <InlineCode>fetch("/api/incidents")</InlineCode> from the client.</P>

          <H2 id="zustand-stores">Zustand Stores</H2>
          <P>Client-side UI preferences live in <InlineCode>src/lib/store.ts</InlineCode> as Zustand stores. The store is hydrated from <InlineCode>localStorage</InlineCode> on mount via the <InlineCode>UIStoreHydration</InlineCode> component in the root layout.</P>
          <CodeBlock language="ts" title="src/lib/store.ts (excerpt)" code={`import { create } from "zustand";
import { persist } from "zustand/middleware";

interface UIState {
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  recentPages: { href: string; title: string; visitedAt: number }[];
  pushRecent: (page: { href: string; title: string; visitedAt: number }) => void;
  savedFilters: Record<string, unknown>;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      recentPages: [],
      pushRecent: (page) =>
        set((s) => ({
          recentPages: [page, ...s.recentPages.filter((p) => p.href !== page.href)].slice(0, 10),
        })),
      savedFilters: {},
    }),
    { name: "sentinelgrid-ui" }
  )
);`} />
          <Callout variant="default" title="Why Zustand?">
            Zustand keeps client state outside React's tree, so it survives route transitions without prop drilling. The <InlineCode>persist</InlineCode> middleware syncs to <InlineCode>localStorage</InlineCode> automatically.
          </Callout>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/tables"><ArrowLeft className="w-4 h-4 mr-1.5" />Tables</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/deployment">Next: Deployment Guide<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
