"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { DocsSidebar, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { toast } from "sonner";
import { LifeBuoy, ArrowRight, ArrowLeft, Mail, MessageSquare, Headphones, Clock, Send, BookOpen, RefreshCw, Scale } from "lucide-react";

const sectionNav = [
  { id: "contact-options", label: "Contact Options" },
  { id: "hours", label: "Support Hours" },
  { id: "ticket", label: "Submit a Ticket" },
  { id: "faq", label: "FAQ" },
  { id: "links", label: "Documentation Links" },
];

const contactOptions = [
  {
    icon: Mail,
    title: "Email Support",
    description: "Best for general questions, billing, and non-urgent issues. We respond within one business day.",
    detail: "support@sentinelgrid.io",
    tier: "All plans",
    tierColor: "bg-muted text-muted-foreground",
  },
  {
    icon: MessageSquare,
    title: "Slack Community",
    description: "Join 2,000+ engineers in our community Slack. Get help from peers and the SentinelGrid team.",
    detail: "sentinelgrid.slack.com",
    tier: "All plans",
    tierColor: "bg-muted text-muted-foreground",
  },
  {
    icon: Headphones,
    title: "Priority Support",
    description: "Dedicated Slack channel, 4-hour response SLA, and scheduled video calls with the engineering team.",
    detail: "priority@sentinelgrid.io",
    tier: "Pro & Enterprise",
    tierColor: "bg-primary/15 text-primary",
  },
];

const faqs = [
  {
    q: "What is the response time for email support?",
    a: "We respond to all email inquiries within one business day (Monday–Friday, 9am–6pm Pacific). Priority support customers receive a 4-hour response SLA during the same window.",
  },
  {
    q: "Do you offer phone support?",
    a: "Phone support is available for Enterprise customers. Pro and Starter customers can schedule video calls via priority support for complex issues.",
  },
  {
    q: "How do I report a bug?",
    a: "Submit a ticket using the form below with reproduction steps, expected behavior, and actual behavior. Including screenshots or screen recordings speeds up resolution significantly.",
  },
  {
    q: "Can I request a feature?",
    a: "Absolutely. Submit feature requests via the ticket form or post in the #feature-requests channel in Slack. We ship a new release every two weeks and prioritize community-requested features.",
  },
  {
    q: "Is there a status page?",
    a: "Yes. Visit status.sentinelgrid.io for real-time uptime, scheduled maintenance windows, and historical incident history.",
  },
  {
    q: "How do I cancel my subscription?",
    a: "Email billing@sentinelgrid.io from the address associated with your account. Cancellations take effect at the end of the current billing cycle.",
  },
];

const docLinks = [
  { label: "Getting Started", href: "/docs/getting-started", icon: BookOpen },
  { label: "Changelog", href: "/docs/changelog", icon: RefreshCw },
  { label: "License", href: "/docs/license", icon: Scale },
  { label: "Deployment Guide", href: "/docs/deployment", icon: LifeBuoy },
];

export default function SupportPage() {
  const [subject, setSubject] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [priority, setPriority] = React.useState("normal");
  const [message, setMessage] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!subject.trim() || !email.trim() || !message.trim()) {
      toast.error("Please fill in all required fields.");
      return;
    }
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      toast.success("Ticket submitted", {
        description: `We'll respond to ${email} within one business day.`,
      });
      setSubject("");
      setEmail("");
      setMessage("");
      setPriority("normal");
    }, 800);
  }

  return (
    <PageContainer wide>
      <PageHeader
        title="Support"
        description="Get help from the SentinelGrid team."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Support" }]}
        icon={<LifeBuoy className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <DocsBody className="max-w-3xl">
          <H1>Support</H1>
          <Lead>We are here to help. Reach out via email, join our community Slack, or submit a ticket below. Enterprise customers have access to priority support with dedicated engineers.</Lead>

          <H2 id="contact-options">Contact Options</H2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-4">
            {contactOptions.map((opt) => (
              <Card key={opt.title} className="p-5 flex flex-col">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    <opt.icon className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] font-medium uppercase tracking-wide px-1.5 py-0.5 rounded ${opt.tierColor}`}>
                    {opt.tier}
                  </span>
                </div>
                <h3 className="text-sm font-semibold">{opt.title}</h3>
                <p className="text-xs text-muted-foreground mt-1 flex-1">{opt.description}</p>
                <p className="text-xs font-mono text-primary mt-3 truncate">{opt.detail}</p>
              </Card>
            ))}
          </div>

          <H2 id="hours">Support Hours</H2>
          <Card className="my-4 p-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Standard</p>
                  <p className="text-xs text-muted-foreground">Mon–Fri, 9am–6pm Pacific</p>
                  <p className="text-xs text-muted-foreground mt-1">1 business day response</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Headphones className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Priority (Pro)</p>
                  <p className="text-xs text-muted-foreground">Mon–Fri, 24h coverage</p>
                  <p className="text-xs text-muted-foreground mt-1">4-hour response SLA</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <LifeBuoy className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Enterprise</p>
                  <p className="text-xs text-muted-foreground">24/7/365 coverage</p>
                  <p className="text-xs text-muted-foreground mt-1">1-hour response SLA</p>
                </div>
              </div>
            </div>
          </Card>

          <H2 id="ticket">Submit a Ticket</H2>
          <P>Use the form below for bug reports, feature requests, or general inquiries. Required fields are marked with an asterisk.</P>
          <Card className="my-4 p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger id="priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low — General question</SelectItem>
                      <SelectItem value="normal">Normal — Bug or feature request</SelectItem>
                      <SelectItem value="high">High — Production impact</SelectItem>
                      <SelectItem value="urgent">Urgent — Critical outage</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="subject">Subject *</Label>
                <Input
                  id="subject"
                  placeholder="Brief summary of your issue"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="message">Message *</Label>
                <Textarea
                  id="message"
                  placeholder="Describe your issue, including reproduction steps, expected behavior, and actual behavior. Include screenshots if possible."
                  rows={6}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  required
                />
              </div>
              <div className="flex items-center justify-between gap-3 pt-2">
                <p className="text-xs text-muted-foreground">
                  We respond within 1 business day. For urgent production issues, mark priority as Urgent.
                </p>
                <Button type="submit" disabled={submitting} className="gap-1.5">
                  {submitting ? (
                    <>Submitting...</>
                  ) : (
                    <>Submit Ticket <Send className="w-3.5 h-3.5" /></>
                  )}
                </Button>
              </div>
            </form>
          </Card>

          <H2 id="faq">FAQ</H2>
          <Accordion type="single" collapsible className="my-4">
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`item-${i}`}>
                <AccordionTrigger className="text-sm font-medium text-left">{faq.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">{faq.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <H2 id="links">Documentation Links</H2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 my-4">
            {docLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <Card className="p-4 hover:bg-elevated/40 transition-colors group h-full">
                  <link.icon className="w-4 h-4 text-primary mb-2" />
                  <p className="text-sm font-medium group-hover:text-primary transition-colors">{link.label}</p>
                  <p className="text-[10px] text-muted-foreground mt-1 font-mono">{link.href}</p>
                </Card>
              </Link>
            ))}
          </div>

          <Callout variant="info" title="Status page">
            For real-time uptime and incident history, visit <InlineCode>status.sentinelgrid.io</InlineCode>. Subscribe to RSS or email alerts for outage notifications.
          </Callout>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/license"><ArrowLeft className="w-4 h-4 mr-1.5" />License</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs">Back to overview<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
