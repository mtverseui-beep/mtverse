"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { SeverityBadge, IncidentStatusBadge } from "@/components/common/badges";
import { DocsSidebar, CodeBlock, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { Table as TableIcon, ArrowRight, ArrowLeft, Search, SlidersHorizontal, Download, Columns3, Smartphone } from "lucide-react";
import { incidents } from "@/lib/data";
import type { Incident } from "@/lib/types";
import { toast } from "sonner";

const sectionNav = [
  { id: "overview", label: "Overview" },
  { id: "features", label: "Features" },
  { id: "live-example", label: "Live Example" },
  { id: "column-config", label: "Column Config" },
  { id: "mobile-cards", label: "Mobile Cards" },
  { id: "bulk-actions", label: "Bulk Actions" },
];

const columns: Column<Incident>[] = [
  {
    key: "id",
    header: "ID",
    cell: (row) => <span className="font-mono text-xs text-primary">{row.id}</span>,
    sortable: true,
    sortValue: (row) => row.id,
    width: "w-24",
  },
  {
    key: "title",
    header: "Title",
    cell: (row) => <span className="font-medium text-sm truncate block max-w-xs">{row.title}</span>,
    sortable: true,
    sortValue: (row) => row.title,
  },
  {
    key: "severity",
    header: "Severity",
    cell: (row) => <SeverityBadge severity={row.severity} />,
    sortable: true,
    sortValue: (row) => row.severity,
    filterable: true,
    filterOptions: [
      { label: "Critical", value: "critical" },
      { label: "High", value: "high" },
      { label: "Medium", value: "medium" },
      { label: "Low", value: "low" },
    ],
    filterFn: (row, value) => row.severity === value,
    hideOnMobile: true,
  },
  {
    key: "status",
    header: "Status",
    cell: (row) => <IncidentStatusBadge status={row.status} />,
    sortable: true,
    sortValue: (row) => row.status,
    filterable: true,
    filterOptions: [
      { label: "Investigating", value: "investigating" },
      { label: "Identified", value: "identified" },
      { label: "Monitoring", value: "monitoring" },
      { label: "Resolved", value: "resolved" },
    ],
    filterFn: (row, value) => row.status === value,
  },
  {
    key: "service",
    header: "Service",
    cell: (row) => <span className="text-xs text-muted-foreground">{row.serviceIds.join(", ")}</span>,
    hideOnMobile: true,
  },
];

const mobileCard = (row: Incident) => (
  <div className="p-3 space-y-1">
    <div className="flex items-center justify-between">
      <span className="font-mono text-xs text-primary">{row.id}</span>
      <SeverityBadge severity={row.severity} size="sm" />
    </div>
    <p className="text-sm font-medium truncate">{row.title}</p>
    <div className="flex items-center gap-2">
      <IncidentStatusBadge status={row.status} />
    </div>
  </div>
);

const features = [
  { icon: Search, title: "Search", desc: "Client-side fuzzy search across any subset of keys." },
  { icon: SlidersHorizontal, title: "Filter", desc: "Per-column filter dropdowns with custom predicates." },
  { icon: Columns3, title: "Column visibility", desc: "Show or hide columns via a dropdown checklist." },
  { icon: Download, title: "Export", desc: "Bulk actions can trigger CSV, JSON, or custom export flows." },
  { icon: TableIcon, title: "Sortable", desc: "Click any header to toggle asc/desc. Initial sort supported." },
  { icon: Smartphone, title: "Mobile cards", desc: "Rows automatically render as cards on small viewports." },
];

export default function TablesGuidePage() {
  return (
    <PageContainer wide>
      <PageHeader
        title="Table System Guide"
        description="Feature-complete DataTable with search, sort, filter, export, and bulk actions."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Tables" }]}
        icon={<TableIcon className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">{s.label}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody className="max-w-4xl">
          <H1>Table System Guide</H1>
          <Lead>The <InlineCode>DataTable</InlineCode> component handles every table use case in SentinelGrid: search, sort, filter, pagination, column visibility, bulk actions, and automatic mobile-card rendering — all from a single column config.</Lead>

          <H2 id="overview">Overview</H2>
          <P>The DataTable is fully generic over your row type. You pass a <InlineCode>columns</InlineCode> array and a <InlineCode>data</InlineCode> array, plus optional callbacks for row clicks and bulk actions. Everything else — search box, filter dropdowns, sort headers, pagination — is built in.</P>

          <H2 id="features">Features</H2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 my-4">
            {features.map((f) => (
              <Card key={f.title} className="p-4">
                <f.icon className="w-4 h-4 text-primary mb-2" />
                <p className="text-sm font-semibold">{f.title}</p>
                <p className="text-xs text-muted-foreground mt-1">{f.desc}</p>
              </Card>
            ))}
          </div>

          <H2 id="live-example">Live Example</H2>
          <P>Below is a DataTable wired to the mock incidents dataset. Try searching, sorting by clicking headers, filtering severity or status, paginating, and resizing the browser to see mobile cards kick in.</P>
          <Card className="p-4 my-4">
            <DataTable
              columns={columns}
              data={incidents.slice(0, 25)}
              rowKey={(row) => row.id}
              searchKeys={["id", "title", (row) => row.serviceIds.join(" ")]}
              searchPlaceholder="Search incidents..."
              pageSize={8}
              enableSelection
              onRowClick={(row) => toast.info(`Opening ${row.id}`)}
              mobileCard={mobileCard}
              bulkActions={[
                { label: "Export CSV", icon: <Download className="w-3.5 h-3.5" />, onClick: (rows) => toast.success(`Exported ${rows.length} rows`) },
                { label: "Acknowledge", onClick: (rows) => toast.success(`Acknowledged ${rows.length} incidents`) },
              ]}
            />
          </Card>

          <H2 id="column-config">Column Configuration</H2>
          <P>Each column is defined by a config object. The <InlineCode>cell</InlineCode> function returns JSX, <InlineCode>sortValue</InlineCode> enables sorting, and <InlineCode>filterable</InlineCode> + <InlineCode>filterFn</InlineCode> enable the filter dropdown.</P>
          <CodeBlock language="tsx" title="Column definition" code={`const columns: Column<Incident>[] = [
  {
    key: "id",
    header: "ID",
    cell: (row) => <span className="font-mono text-xs">{row.id}</span>,
    sortable: true,
    sortValue: (row) => row.id,
    width: "w-24",
  },
  {
    key: "severity",
    header: "Severity",
    cell: (row) => <SeverityBadge severity={row.severity} />,
    sortable: true,
    sortValue: (row) => row.severity,
    filterable: true,
    filterOptions: [
      { label: "Critical", value: "critical" },
      { label: "High", value: "high" },
    ],
    filterFn: (row, value) => row.severity === value,
    hideOnMobile: true,
  },
];`} />

          <H3>DataTable props</H3>
          <Card className="my-4 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-2 font-semibold">Prop</th>
                    <th className="text-left px-4 py-2 font-semibold">Type</th>
                    <th className="text-left px-4 py-2 font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-subtle">
                  {[
                    { p: "columns", t: "Column<T>[]", d: "Column definitions" },
                    { p: "data", t: "T[]", d: "Rows to render" },
                    { p: "rowKey", t: "(row: T) => string", d: "Stable key extractor" },
                    { p: "searchKeys", t: "(keyof T)[]", d: "Keys included in client-side search" },
                    { p: "pageSize", t: "number", d: "Rows per page (default 10)" },
                    { p: "enableSelection", t: "boolean", d: "Show checkbox column" },
                    { p: "onRowClick", t: "(row: T) => void", d: "Row click handler" },
                    { p: "bulkActions", t: "BulkAction[]", d: "Actions shown when rows are selected" },
                    { p: "mobileCard", t: "(row: T) => ReactNode", d: "Custom card render for mobile" },
                    { p: "stickyHeader", t: "boolean", d: "Sticky table header (default true)" },
                  ].map((row) => (
                    <tr key={row.p}>
                      <td className="px-4 py-2 font-mono text-xs text-primary">{row.p}</td>
                      <td className="px-4 py-2 font-mono text-xs text-muted-foreground">{row.t}</td>
                      <td className="px-4 py-2 text-xs text-muted-foreground">{row.d}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <H2 id="mobile-cards">Mobile Cards</H2>
          <P>On viewports below the <InlineCode>md</InlineCode> breakpoint, the table body is replaced with a vertical card list. Provide a <InlineCode>mobileCard</InlineCode> render function to control the layout. Columns marked <InlineCode>hideOnMobile: true</InlineCode> are hidden in the table view but can still appear in your card.</P>
          <CodeBlock language="tsx" title="Mobile card" code={`const mobileCard = (row: Incident) => (
  <div className="p-3 space-y-1">
    <div className="flex items-center justify-between">
      <span className="font-mono text-xs text-primary">{row.id}</span>
      <SeverityBadge severity={row.severity} size="sm" />
    </div>
    <p className="text-sm font-medium truncate">{row.title}</p>
    <IncidentStatusBadge status={row.status} />
  </div>
);

<DataTable columns={columns} data={data} rowKey={(r) => r.id} mobileCard={mobileCard} />`} />

          <H2 id="bulk-actions">Bulk Actions</H2>
          <P>When <InlineCode>enableSelection</InlineCode> is true and at least one row is checked, a bulk action bar appears above the table. Pass an array of actions; each receives the selected rows.</P>
          <CodeBlock language="tsx" title="Bulk actions" code={`<DataTable
  columns={columns}
  data={data}
  rowKey={(r) => r.id}
  enableSelection
  bulkActions={[
    { label: "Export CSV", icon: <Download className="w-3.5 h-3.5" />, onClick: (rows) => exportCsv(rows) },
    { label: "Acknowledge", onClick: (rows) => acknowledge(rows) },
    { label: "Close", onClick: (rows) => closeIncidents(rows), variant: "destructive" },
  ]}
/>`} />
          <Callout variant="info" title="Pagination">
            Pagination is built-in with configurable <InlineCode>pageSize</InlineCode>. The footer shows the current range and total count, plus prev/next controls.
          </Callout>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/charts"><ArrowLeft className="w-4 h-4 mr-1.5" />Charts</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/mock-api">Next: Mock API Guide<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
