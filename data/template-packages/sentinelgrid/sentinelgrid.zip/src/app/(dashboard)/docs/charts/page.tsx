"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DocsSidebar, CodeBlock, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import {
  LatencyChart, VolumeChart, ErrorRateChart, DonutChart, HorizontalBarChart,
  MTTRTrendChart, RadialGauge, ComposedChartCard, LineChartCard,
} from "@/components/charts";
import { timeSeries, multiTimeSeries, mttrTrend } from "@/lib/data";
import { BarChart3, ArrowRight, ArrowLeft, Activity, Gauge, Target, TrendingUp, Maximize2, Download } from "lucide-react";

const sectionNav = [
  { id: "overview", label: "Overview" },
  { id: "available-charts", label: "Available Charts" },
  { id: "when-to-use", label: "When to Use Each" },
  { id: "theme-tokens", label: "Theme Tokens" },
  { id: "custom-tooltips", label: "Custom Tooltips" },
  { id: "fullscreen", label: "Fullscreen Mode" },
];

const chartsList = [
  { name: "LatencyChart", type: "Area", use: "p50/p95/p99 latency over time" },
  { name: "VolumeChart", type: "Area", use: "Request volume or single-metric trends" },
  { name: "ErrorRateChart", type: "Area", use: "Error rate with % axis" },
  { name: "BurnRateChart", type: "Line", use: "SLO burn rate with threshold reference" },
  { name: "SLOComplianceChart", type: "Bar", use: "SLO compliance by service with target line" },
  { name: "IncidentSeverityTrendChart", type: "Stacked Bar", use: "Incident counts by severity over time" },
  { name: "MTTRTrendChart", type: "Multi-Line", use: "MTTR / MTTD / MTTA trends" },
  { name: "DeploymentFrequencyChart", type: "Bar", use: "Deployment count + failures" },
  { name: "LineChartCard", type: "Line", use: "Simple single-series line chart" },
  { name: "DonutChart", type: "Donut", use: "Distribution by category with center label" },
  { name: "HorizontalBarChart", type: "Horizontal Bar", use: "Top-N rankings" },
  { name: "UptimeHeatmap", type: "Heatmap", use: "90-day availability calendar" },
  { name: "RadialGauge", type: "Radial", use: "Single value with target" },
  { name: "ComposedChartCard", type: "Composed", use: "Bars + lines on the same axis" },
];

export default function ChartsGuidePage() {
  const latencyData = multiTimeSeries(2, 24, [
    { name: "p50", base: 35, variance: 8 },
    { name: "p95", base: 120, variance: 30 },
    { name: "p99", base: 280, variance: 60 },
  ]).map((d) => ({ timestamp: String(d.date), p50: Number(d.p50), p95: Number(d.p95), p99: Number(d.p99) }));
  const volumeData = timeSeries(2, 24, 1200, 400).map((d) => ({ timestamp: String(d.date), value: d.value }));
  const errorData = timeSeries(2, 24, 0.8, 0.4).map((d) => ({ timestamp: String(d.date), value: d.value }));
  const donutData = [
    { name: "Critical", value: 5 },
    { name: "High", value: 12 },
    { name: "Medium", value: 28 },
    { name: "Low", value: 47 },
  ];
  const barData = [
    { name: "api-gateway", value: 99.98 },
    { name: "payments", value: 99.91 },
    { name: "auth", value: 99.85 },
    { name: "search", value: 99.62 },
    { name: "notifications", value: 98.74 },
  ];
  const mttrData = mttrTrend();
  const composedData = timeSeries(2, 14, 800, 200).map((d, i) => ({
    date: d.date,
    deployments: Math.floor(d.value / 100),
    failures: Math.max(0, Math.floor(d.value / 1000) - (i % 3 === 0 ? 1 : 0)),
    errorRate: Number((d.value / 5000).toFixed(2)),
  }));

  return (
    <PageContainer wide>
      <PageHeader
        title="Chart System Guide"
        description="Theme-aware chart wrappers with custom tooltips and fullscreen mode."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Charts" }]}
        icon={<BarChart3 className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">{s.label}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody className="max-w-4xl">
          <H1>Chart System Guide</H1>
          <Lead>SentinelGrid ships 14 chart wrappers built on Recharts. Every chart reads theme tokens via the <InlineCode>useChartTheme()</InlineCode> hook, so colors, gridlines, axes, and tooltips automatically adapt to dark/light mode.</Lead>

          <H2 id="overview">Overview</H2>
          <P>Charts live in <InlineCode>components/charts/</InlineCode>. Each chart is a thin wrapper around a Recharts primitive plus the shared <InlineCode>ChartContainer</InlineCode>, which provides the card chrome, header, fullscreen dialog, and PNG export button.</P>
          <CodeBlock language="tsx" title="Anatomy of a chart component" code={`export function LatencyChart({ data, title, description }: LatencyChartProps) {
  const t = useChartTheme();
  return (
    <ChartContainer title={title} description={description}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <CartesianGrid stroke={t.grid} vertical={false} />
          <XAxis dataKey="timestamp" stroke={t.axis} fontSize={11} />
          <YAxis stroke={t.axis} fontSize={11} />
          <Tooltip content={<ChartTooltip suffix="ms" />} />
          <Area dataKey="p99" stroke={t.palette[2]} />
        </AreaChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}`} />

          <H2 id="available-charts">Available Charts</H2>
          <Card className="my-4 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-2 font-semibold">Component</th>
                    <th className="text-left px-4 py-2 font-semibold">Type</th>
                    <th className="text-left px-4 py-2 font-semibold">When to use</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-subtle">
                  {chartsList.map((c) => (
                    <tr key={c.name}>
                      <td className="px-4 py-2 font-mono text-xs text-primary">{c.name}</td>
                      <td className="px-4 py-2 text-xs text-muted-foreground">{c.type}</td>
                      <td className="px-4 py-2 text-xs text-muted-foreground">{c.use}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <H2 id="when-to-use">When to Use Each</H2>
          <UL>
            <li>Use <strong>Area charts</strong> for cumulative trends like latency or volume — the gradient fill communicates magnitude.</li>
            <li>Use <strong>Bar charts</strong> for discrete comparisons (deployments per day, compliance per service).</li>
            <li>Use <strong>Line charts</strong> for trends where the gradient fill would be noise (burn rate, MTTR).</li>
            <li>Use <strong>Donut charts</strong> for parts-of-whole distributions with 4 or fewer segments.</li>
            <li>Use <strong>Horizontal bar charts</strong> for top-N rankings with long labels (service names).</li>
            <li>Use <strong>Radial gauges</strong> for single KPIs with a target (SLO compliance, saturation).</li>
            <li>Use <strong>Heatmaps</strong> for calendar-style availability over a long window.</li>
          </UL>

          <H2 id="theme-tokens">Theme Tokens</H2>
          <P>The <InlineCode>useChartTheme()</InlineCode> hook returns an object with everything a chart needs: an 8-color palette, grid color, axis color, and tooltip styling. Colors swap automatically when the theme changes.</P>
          <CodeBlock language="tsx" title="useChartTheme return value" code={`const t = useChartTheme();
// {
//   isDark: boolean,
//   grid: "rgba(255,255,255,0.06)",
//   axis: "rgba(255,255,255,0.45)",
//   tooltipBg: "#13151B",
//   tooltipBorder: "rgba(255,255,255,0.08)",
//   tooltipText: "#F1F5F9",
//   palette: ["#22D3EE", "#A78BFA", "#FCD34D", "#34D399", "#F87171", "#FB923C", "#60A5FA", "#94A3B8"]
// }`} />

          <H2 id="custom-tooltips">Custom Tooltips</H2>
          <P>The <InlineCode>ChartTooltip</InlineCode> component handles the most common case: a label plus key/value rows with a colored dot. Pass a <InlineCode>suffix</InlineCode> for unit-aware formatting, or a <InlineCode>formatter</InlineCode> for fully custom rendering.</P>
          <CodeBlock language="tsx" title="Tooltip with suffix and formatter" code={`<Tooltip content={<ChartTooltip suffix="ms" />} />

<Tooltip content={
  <ChartTooltip formatter={(value, name) => \`\${name}: \${Number(value).toFixed(1)}%\`} />
} />`} />

          <H2 id="fullscreen">Fullscreen Mode & Export</H2>
          <P>Every chart renders inside a <InlineCode>ChartContainer</InlineCode> that adds two action buttons in the top-right: a fullscreen toggle (opens the chart in a <InlineCode>Dialog</InlineCode> at 80% viewport height) and a PNG export button.</P>
          <CodeBlock language="tsx" title="Disabling fullscreen" code={`<UptimeHeatmap data={data} fullscreen={false} />`} />

          {/* Live examples */}
          <H2>Live Examples</H2>
          <P>Below are four chart wrappers rendering real mock data. Try the fullscreen and export buttons — they work out of the box.</P>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 my-4">
            <LatencyChart data={latencyData} title="Latency Percentiles" description="p50 / p95 / p99 over 24 hours" />
            <VolumeChart data={volumeData} title="Request Volume" description="Requests per minute" />
            <ErrorRateChart data={errorData} title="Error Rate" description="5xx responses as % of total" />
            <DonutChart data={donutData} title="Incidents by Severity" description="Last 30 days" centerValue="92" centerLabel="incidents" />
            <HorizontalBarChart data={barData} title="Top Services by Uptime" description="30-day rolling" color={3} />
            <MTTRTrendChart data={mttrData} title="MTTR / MTTD / MTTA" description="Weekly trend in minutes" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
            <Card className="p-5 flex flex-col items-center justify-center">
              <p className="text-sm font-semibold mb-3">RadialGauge — SLO Compliance</p>
              <RadialGauge value={99.4} target={100} label="of 99.9% target" color={3} size={160} />
            </Card>
            <ComposedChartCard
              data={composedData}
              bars={[{ key: "deployments", name: "Deploys", color: 0 }]}
              lines={[{ key: "errorRate", name: "Error %", color: 4 }]}
              title="Deployments vs Error Rate"
              description="Composed chart example"
            />
          </div>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/theme"><ArrowLeft className="w-4 h-4 mr-1.5" />Theme</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/tables">Next: Tables Guide<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
