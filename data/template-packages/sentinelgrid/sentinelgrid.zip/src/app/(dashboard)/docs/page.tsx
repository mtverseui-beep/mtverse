"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { docsNavSections } from "@/components/docs/docs-nav";
import {
  Search, ArrowRight, BookOpen, Rocket, Route, Palette, BarChart3,
  Table, Database, Server, RefreshCw, Scale, LifeBuoy, Clock,
} from "lucide-react";

const categories = [
  {
    title: "Getting Started",
    description: "Install, configure, and launch your first SentinelGrid instance.",
    href: "/docs/getting-started",
    icon: Rocket,
    items: ["Installation", "Project structure", "Dev server", "First page", "Adding data"],
  },
  {
    title: "Components",
    description: "Reusable UI primitives built on shadcn/ui with engineering-grade defaults.",
    href: "/docs/components",
    icon: BookOpen,
    items: ["KpiCard", "Badges", "Charts", "DataTable", "Forms", "Overlays"],
  },
  {
    title: "Routing",
    description: "Master Next.js 16 App Router patterns used throughout SentinelGrid.",
    href: "/docs/routing",
    icon: Route,
    items: ["Route groups", "Dynamic routes", "Layouts", "Loading", "Error boundaries"],
  },
  {
    title: "Theme",
    description: "Customize colors, dark mode tokens, and build your brand palette.",
    href: "/docs/theme",
    icon: Palette,
    items: ["Color tokens", "Dark mode", "CSS variables", "Custom palette"],
  },
  {
    title: "Charts",
    description: "Theme-aware chart wrappers with custom tooltips and fullscreen mode.",
    href: "/docs/charts",
    icon: BarChart3,
    items: ["Latency", "Volume", "Donut", "Bar", "Radial", "Composed"],
  },
  {
    title: "Tables",
    description: "Feature-complete DataTable with search, sort, filter, export and bulk actions.",
    href: "/docs/tables",
    icon: Table,
    items: ["Search & sort", "Filter", "Pagination", "Column visibility", "Mobile cards"],
  },
  {
    title: "Mock API",
    description: "Understand the in-memory data layer and how to swap it for real APIs.",
    href: "/docs/mock-api",
    icon: Database,
    items: ["Data layer", "Adding entities", "Swapping for real API", "Zustand stores"],
  },
  {
    title: "Deployment",
    description: "Ship to Vercel, Docker, or your own infrastructure with confidence.",
    href: "/docs/deployment",
    icon: Server,
    items: ["Build steps", "Environment variables", "Vercel", "Docker", "Custom domain"],
  },
];

const popularArticles = [
  { title: "Configuring SLOs and error budgets", href: "/docs/components", category: "Guides", readTime: "8 min" },
  { title: "Building a custom dashboard view", href: "/docs/routing", category: "Guides", readTime: "12 min" },
  { title: "Adding a new chart type", href: "/docs/charts", category: "Charts", readTime: "6 min" },
  { title: "Theming dark and light mode", href: "/docs/theme", category: "Theme", readTime: "10 min" },
  { title: "Wiring DataTable to a real backend", href: "/docs/tables", category: "Tables", readTime: "9 min" },
  { title: "Deploying to Vercel", href: "/docs/deployment", category: "Deploy", readTime: "5 min" },
];

const quickLinks = [
  { label: "Changelog", href: "/docs/changelog", icon: RefreshCw, hint: "v1.0.0 released today" },
  { label: "License", href: "/docs/license", icon: Scale, hint: "Commercial license terms" },
  { label: "Support", href: "/docs/support", icon: LifeBuoy, hint: "Email, Slack, priority" },
];

export default function DocsHomePage() {
  const [query, setQuery] = React.useState("");
  const filteredCategories = React.useMemo(() => {
    if (!query.trim()) return categories;
    const q = query.toLowerCase();
    return categories.filter((c) =>
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.items.some((i) => i.toLowerCase().includes(q))
    );
  }, [query]);

  return (
    <PageContainer wide>
      <PageHeader
        title="SentinelGrid Documentation"
        description="Everything you need to ship reliable engineering operations tooling."
        breadcrumbs={[{ label: "Docs" }]}
        icon={<BookOpen className="w-5 h-5" />}
      />

      {/* Hero search */}
      <Card className="relative overflow-hidden p-8 md:p-12 bg-grid">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        <div className="relative space-y-4 max-w-2xl">
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight">
            What do you want to build?
          </h2>
          <p className="text-muted-foreground">
            Search guides, components, and reference docs. Press <kbd className="px-1.5 py-0.5 rounded bg-muted border border-border text-[11px] font-mono">/</kbd> to focus.
          </p>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search documentation..."
              className="pl-10 h-11 bg-background/80 backdrop-blur"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {["Installation", "SLOs", "Dark mode", "Charts", "Deployment"].map((tag) => (
              <button
                key={tag}
                onClick={() => setQuery(tag)}
                className="px-2.5 py-1 rounded-md text-xs bg-muted hover:bg-muted/70 border border-border text-muted-foreground hover:text-foreground transition-colors"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </Card>

      {/* Category grid */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Browse by category</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCategories.map((cat) => (
            <Link key={cat.title} href={cat.href}>
              <Card className="p-5 h-full hover:bg-elevated/40 hover:border-primary/30 transition-all group">
                <div className="flex items-start gap-3">
                  <div className="shrink-0 w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    <cat.icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <h4 className="text-sm font-semibold group-hover:text-primary transition-colors">{cat.title}</h4>
                      <ArrowRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{cat.description}</p>
                  </div>
                </div>
                <ul className="mt-3 space-y-1">
                  {cat.items.slice(0, 4).map((item) => (
                    <li key={item} className="text-xs text-muted-foreground/80 flex items-center gap-1.5">
                      <span className="w-1 h-1 rounded-full bg-muted-foreground/40" />
                      {item}
                    </li>
                  ))}
                </ul>
              </Card>
            </Link>
          ))}
        </div>
        {filteredCategories.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <p className="text-sm">No results for &ldquo;{query}&rdquo;</p>
            <Button variant="ghost" size="sm" className="mt-2" onClick={() => setQuery("")}>
              Clear search
            </Button>
          </div>
        )}
      </section>

      {/* Two-column: popular + quick */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Popular articles</h3>
          <div className="divide-y divide-border-subtle">
            {popularArticles.map((article) => (
              <Link
                key={article.title}
                href={article.href}
                className="flex items-center justify-between py-3 group"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium group-hover:text-primary transition-colors truncate">{article.title}</p>
                  <div className="flex items-center gap-2 mt-0.5 text-xs text-muted-foreground">
                    <span className="px-1.5 py-0.5 rounded bg-muted">{article.category}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{article.readTime}</span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </Link>
            ))}
          </div>
        </Card>
        <Card className="p-6">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Quick links</h3>
          <div className="space-y-3">
            {quickLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors group"
              >
                <link.icon className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium group-hover:text-primary transition-colors">{link.label}</p>
                  <p className="text-xs text-muted-foreground">{link.hint}</p>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity mt-1" />
              </Link>
            ))}
          </div>
        </Card>
      </div>

      {/* Still need help */}
      <Card className="p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
        <div>
          <h3 className="text-base font-semibold">Still need help?</h3>
          <p className="text-sm text-muted-foreground mt-0.5">Our support team is available around the clock.</p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline" size="sm">
            <Link href="/docs/support">Contact support</Link>
          </Button>
          <Button asChild size="sm">
            <Link href="/docs/getting-started">Get started</Link>
          </Button>
        </div>
      </Card>
    </PageContainer>
  );
}
