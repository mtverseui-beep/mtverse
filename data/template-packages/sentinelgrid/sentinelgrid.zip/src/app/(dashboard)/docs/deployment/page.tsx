"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DocsSidebar, CodeBlock, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import { Server, ArrowRight, ArrowLeft, Rocket, Container, Globe, Key, Terminal, CheckCircle2 } from "lucide-react";

const sectionNav = [
  { id: "build-steps", label: "Build Steps" },
  { id: "env-vars", label: "Environment Variables" },
  { id: "vercel", label: "Vercel Deployment" },
  { id: "docker", label: "Docker Deployment" },
  { id: "custom-domain", label: "Custom Domain" },
];

export default function DeploymentGuidePage() {
  return (
    <PageContainer wide>
      <PageHeader
        title="Deployment Guide"
        description="Ship SentinelGrid to Vercel, Docker, or your own infrastructure."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Deployment" }]}
        icon={<Server className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">{s.label}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody>
          <H1>Deployment Guide</H1>
          <Lead>SentinelGrid is a standard Next.js 16 app, so it deploys anywhere Next.js runs. This guide covers Vercel (one-click), Docker (self-hosted), and custom domain setup.</Lead>

          <H2 id="build-steps">Build Steps</H2>
          <P>Build the production bundle locally to verify everything compiles before deploying:</P>
          <CodeBlock language="bash" title="Production build" code={`# Install dependencies
bun install

# Run linters
bun run lint

# Push Prisma schema
bun run db:push

# Build the production bundle
bun run build

# Start the production server (port 3000)
bun run start`} />
          <Callout variant="warning" title="Database">
            SentinelGrid ships with SQLite by default. For production, switch the Prisma datasource to Postgres or MySQL by updating <InlineCode>prisma/schema.prisma</InlineCode> and the <InlineCode>DATABASE_URL</InlineCode> environment variable.
          </Callout>

          <H2 id="env-vars">Environment Variables</H2>
          <P>SentinelGrid reads the following environment variables. Copy <InlineCode>.env.example</InlineCode> to <InlineCode>.env</InlineCode> and fill in the values.</P>
          <CodeBlock language="bash" title=".env" code={`# Database
DATABASE_URL="file:./prisma/dev.db"

# Auth (NextAuth.js)
NEXTAUTH_URL="https://your-domain.com"
NEXTAUTH_SECRET="generate-with-openssl-rand-base64-32"

# OAuth providers (optional)
GITHUB_CLIENT_ID=""
GITHUB_CLIENT_SECRET=""
GOOGLE_CLIENT_ID=""
GOOGLE_CLIENT_SECRET=""

# External API (when swapping mock data for real backend)
API_URL="https://api.your-domain.com"
API_TOKEN=""

# Observability
SENTRY_DSN=""
VERCEL_ANALYTICS_ID=""`} />
          <Card className="my-4 p-5">
            <div className="flex items-center gap-2 mb-3">
              <Key className="w-4 h-4 text-primary" />
              <p className="text-sm font-semibold">Required for production</p>
            </div>
            <ul className="space-y-1.5 text-sm text-muted-foreground">
              <li><InlineCode>DATABASE_URL</InlineCode> — Postgres connection string recommended</li>
              <li><InlineCode>NEXTAUTH_SECRET</InlineCode> — Generate with <InlineCode>openssl rand -base64 32</InlineCode></li>
              <li><InlineCode>NEXTAUTH_URL</InlineCode> — Your canonical production URL</li>
            </ul>
          </Card>

          <H2 id="vercel">Vercel Deployment</H2>
          <P>Vercel is the recommended deployment target. The Next.js runtime is tuned for the Vercel edge network, and the dashboard preview deployments are perfect for staging.</P>
          <CodeBlock language="bash" title="CLI deployment" code={`# Install the Vercel CLI
npm i -g vercel

# Log in
vercel login

# Deploy from the project root
vercel

# Promote to production
vercel --prod`} />
          <P>Or connect the repository on the Vercel dashboard and enable auto-deploys on push to <InlineCode>main</InlineCode>.</P>
          <Callout variant="info" title="Vercel + Prisma">
            Add a build command that runs <InlineCode>prisma generate</InlineCode> before <InlineCode>next build</InlineCode>. Vercel will pick up the <InlineCode>postinstall</InlineCode> script in <InlineCode>package.json</InlineCode> automatically if you add <InlineCode>{`"postinstall": "prisma generate"`}</InlineCode>.
          </Callout>

          <H2 id="docker">Docker Deployment</H2>
          <P>SentinelGrid ships with a multi-stage Dockerfile optimized for the Next.js standalone output. Build and run with:</P>
          <CodeBlock language="dockerfile" title="Dockerfile" code={`# ---- Dependencies ----
FROM node:20-alpine AS deps
WORKDIR /app
COPY package*.json ./
RUN npm ci

# ---- Build ----
FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npx prisma generate
RUN npm run build

# ---- Runner ----
FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/prisma ./prisma
EXPOSE 3000
ENV PORT=3000
CMD ["node", "server.js"]`} />
          <CodeBlock language="bash" title="Build and run" code={`# Build the image
docker build -t sentinelgrid .

# Run on port 3000 with env file
docker run -p 3000:3000 --env-file .env --name sentinelgrid sentinelgrid`} />
          <Callout variant="default" title="Standalone output">
            Enable standalone output in <InlineCode>next.config.ts</InlineCode>: <InlineCode>{`output: "standalone"`}</InlineCode>. This bundles only the files needed to run the server, shrinking the image to ~150MB.
          </Callout>

          <H2 id="custom-domain">Custom Domain</H2>
          <P>On Vercel, navigate to Project Settings &rarr; Domains and add your domain. Vercel handles SSL certificate provisioning automatically.</P>
          <P>For self-hosted deployments, terminate TLS with Caddy, Nginx, or your load balancer. SentinelGrid ships with a sample Caddyfile:</P>
          <CodeBlock language="text" title="Caddyfile" code={`your-domain.com {
  reverse_proxy localhost:3000
  encode gzip zstd
  header {
    Strict-Transport-Security "max-age=31536000; includeSubDomains"
    X-Content-Type-Options nosniff
    X-Frame-Options DENY
  }
}`} />

          {/* Checklist */}
          <H2>Pre-Deployment Checklist</H2>
          <Card className="my-4 p-5 bg-muted/30">
            <ul className="space-y-2 text-sm text-muted-foreground">
              {[
                "Lint passes (bun run lint)",
                "Production build succeeds (bun run build)",
                "DATABASE_URL points to production database",
                "NEXTAUTH_SECRET is set and >= 32 chars",
                "OAuth providers configured (if used)",
                "CSP headers and HSTS enabled",
                "Error tracking (Sentry) wired up",
                "Analytics (Vercel Analytics) enabled",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-success mt-0.5 shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </Card>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/mock-api"><ArrowLeft className="w-4 h-4 mr-1.5" />Mock API</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/changelog">Next: Changelog<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
