"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { KpiCard } from "@/components/common/kpi-card";
import { SeverityBadge, IncidentStatusBadge, ServiceHealthBadge, DeploymentStatusBadge, AlertStatusBadge, SLOStatusBadge, TierBadge } from "@/components/common/badges";
import { DocsSidebar, CodeBlock, InlineCode, H1, H2, H3, P, UL, Lead, Callout, DocsBody } from "@/components/docs/docs-sidebar";
import { docsNavSections } from "@/components/docs/docs-nav";
import {
  BookOpen, ArrowRight, ArrowLeft, Users, Activity, Zap, Bell, ShieldAlert, Target,
  Rocket, Gauge, CheckCircle2, AlertTriangle,
} from "lucide-react";

const sectionNav = [
  { id: "overview", label: "Overview" },
  { id: "kpi-card", label: "KpiCard" },
  { id: "badges", label: "Badges" },
  { id: "charts-preview", label: "Charts Preview" },
  { id: "props-table", label: "Props Reference" },
];

export default function ComponentsGuidePage() {
  return (
    <PageContainer wide>
      <PageHeader
        title="Component Guide"
        description="Reusable UI primitives built on shadcn/ui with engineering-grade defaults."
        breadcrumbs={[{ label: "Docs", href: "/docs" }, { label: "Components" }]}
        icon={<BookOpen className="w-5 h-5" />}
      />
      <div className="flex gap-8">
        <DocsSidebar sections={docsNavSections} />
        <div className="hidden xl:block w-48 shrink-0">
          <div className="sticky top-6">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">On this page</p>
            <ul className="space-y-1.5">
              {sectionNav.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="text-xs text-muted-foreground hover:text-foreground transition-colors block py-0.5">{s.label}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <DocsBody>
          <H1>Component Guide</H1>
          <Lead>SentinelGrid ships a curated set of components tailored for engineering operations dashboards. Every component is theme-aware, fully typed, and mobile-responsive.</Lead>

          <H2 id="overview">Overview</H2>
          <P>Components live in three directories:</P>
          <UL>
            <li><InlineCode>components/ui/</InlineCode> — shadcn/ui primitives (Button, Card, Dialog, etc.)</li>
            <li><InlineCode>components/common/</InlineCode> — SentinelGrid-specific building blocks (KpiCard, badges, page-header)</li>
            <li><InlineCode>components/charts/</InlineCode> and <InlineCode>components/tables/</InlineCode> — data visualization wrappers</li>
          </UL>

          <H2 id="kpi-card">KpiCard</H2>
          <P>The KpiCard is the workhorse of every dashboard. It renders a label, large value, optional delta with directional arrow, sparkline, and an accent-colored icon.</P>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 my-4">
            <KpiCard label="Active Incidents" value={3} delta={-2} deltaLabel="vs last week" icon={<ShieldAlert className="w-4 h-4" />} accent="destructive" />
            <KpiCard label="Uptime" value="99.97" unit="%" delta={0.02} deltaLabel="30d" icon={<Activity className="w-4 h-4" />} accent="success" />
            <KpiCard label="Avg MTTR" value="18" unit="min" delta={-5} deltaLabel="vs target" icon={<Zap className="w-4 h-4" />} accent="warning" />
            <KpiCard label="SLOs Healthy" value="42/47" icon={<Target className="w-4 h-4" />} accent="primary" hint="5 at risk" />
          </div>
          <CodeBlock language="tsx" title="KpiCard usage" code={`<KpiCard
  label="Active Incidents"
  value={3}
  delta={-2}
  deltaLabel="vs last week"
  icon={<ShieldAlert className="w-4 h-4" />}
  accent="destructive"
/>`} />

          <H2 id="badges">Badges</H2>
          <P>SentinelGrid provides a family of typed badges for every domain status. Each badge accepts the literal type from <InlineCode>lib/types.ts</InlineCode>, ensuring invalid states are caught at build time.</P>
          <Card className="p-5 my-4 space-y-4">
            <div>
              <p className="text-xs text-muted-foreground mb-2">SeverityBadge</p>
              <div className="flex flex-wrap gap-2">
                <SeverityBadge severity="critical" />
                <SeverityBadge severity="high" />
                <SeverityBadge severity="medium" />
                <SeverityBadge severity="low" />
                <SeverityBadge severity="info" />
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-2">IncidentStatusBadge</p>
              <div className="flex flex-wrap gap-2">
                <IncidentStatusBadge status="investigating" />
                <IncidentStatusBadge status="identified" />
                <IncidentStatusBadge status="monitoring" />
                <IncidentStatusBadge status="resolved" />
                <IncidentStatusBadge status="postmortem" />
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-2">ServiceHealthBadge</p>
              <div className="flex flex-wrap gap-2">
                <ServiceHealthBadge health="operational" />
                <ServiceHealthBadge health="degraded" />
                <ServiceHealthBadge health="partial" />
                <ServiceHealthBadge health="major" />
                <ServiceHealthBadge health="maintenance" />
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-2">DeploymentStatusBadge</p>
              <div className="flex flex-wrap gap-2">
                <DeploymentStatusBadge status="in_progress" />
                <DeploymentStatusBadge status="rolling_out" />
                <DeploymentStatusBadge status="canary" />
                <DeploymentStatusBadge status="succeeded" />
                <DeploymentStatusBadge status="failed" />
                <DeploymentStatusBadge status="rolled_back" />
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-2">AlertStatusBadge / SLOStatusBadge / TierBadge</p>
              <div className="flex flex-wrap gap-2">
                <AlertStatusBadge status="firing" />
                <AlertStatusBadge status="acknowledged" />
                <AlertStatusBadge status="resolved" />
                <AlertStatusBadge status="suppressed" />
                <SLOStatusBadge status="healthy" />
                <SLOStatusBadge status="at_risk" />
                <SLOStatusBadge status="breached" />
                <TierBadge tier="tier1" />
                <TierBadge tier="tier2" />
                <TierBadge tier="tier3" />
              </div>
            </div>
          </Card>
          <CodeBlock language="tsx" title="Badge usage" code={`<SeverityBadge severity="critical" />
<IncidentStatusBadge status="investigating" />
<ServiceHealthBadge health="operational" />
<DeploymentStatusBadge status="succeeded" />
<AlertStatusBadge status="firing" />
<SLOStatusBadge status="breached" />
<TierBadge tier="tier1" />`} />

          <H2 id="charts-preview">Charts Preview</H2>
          <P>All chart wrappers live in <InlineCode>components/charts/</InlineCode> and read theme tokens from <InlineCode>useChartTheme()</InlineCode>. See the <Link href="/docs/charts" className="text-primary hover:underline">Charts Guide</Link> for full details.</P>
          <Card className="p-5 my-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { name: "LatencyChart", icon: Activity, color: "bg-chart-1" },
                { name: "VolumeChart", icon: Gauge, color: "bg-chart-2" },
                { name: "ErrorRateChart", icon: AlertTriangle, color: "bg-chart-5" },
                { name: "DonutChart", icon: Target, color: "bg-chart-4" },
                { name: "HorizontalBarChart", icon: Zap, color: "bg-chart-3" },
                { name: "MTTRTrendChart", icon: Rocket, color: "bg-chart-6" },
                { name: "RadialGauge", icon: Bell, color: "bg-chart-7" },
                { name: "ComposedChart", icon: Users, color: "bg-chart-8" },
              ].map((c) => (
                <div key={c.name} className="p-3 rounded-lg border bg-muted/30">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${c.color}`} />
                    <c.icon className="w-3.5 h-3.5 text-muted-foreground" />
                  </div>
                  <p className="text-xs font-medium mt-2">{c.name}</p>
                </div>
              ))}
            </div>
          </Card>

          <H2 id="props-table">Props Reference</H2>

          <H3>KpiCard</H3>
          <Card className="my-4 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-2 font-semibold">Prop</th>
                    <th className="text-left px-4 py-2 font-semibold">Type</th>
                    <th className="text-left px-4 py-2 font-semibold">Default</th>
                    <th className="text-left px-4 py-2 font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-subtle">
                  {[
                    { p: "label", t: "string", d: "—", desc: "Uppercase label above the value" },
                    { p: "value", t: "string | number", d: "—", desc: "Primary metric value" },
                    { p: "unit", t: "string", d: "—", desc: "Optional unit suffix (e.g. %, ms)" },
                    { p: "delta", t: "number", d: "—", desc: "Percent change. Positive = green, negative = red" },
                    { p: "deltaLabel", t: "string", d: "—", desc: "Context for the delta (e.g. vs last week)" },
                    { p: "accent", t: "primary | accent | success | warning | destructive | info | muted", d: "primary", desc: "Color of the icon container" },
                    { p: "icon", t: "ReactNode", d: "—", desc: "Lucide icon to render in the accent box" },
                    { p: "sparkline", t: "number[]", d: "—", desc: "Mini trend chart on the right" },
                    { p: "hint", t: "string", d: "—", desc: "Secondary text under the value" },
                  ].map((row) => (
                    <tr key={row.p}>
                      <td className="px-4 py-2 font-mono text-xs text-primary">{row.p}</td>
                      <td className="px-4 py-2 font-mono text-xs text-muted-foreground">{row.t}</td>
                      <td className="px-4 py-2 font-mono text-xs text-muted-foreground">{row.d}</td>
                      <td className="px-4 py-2 text-xs text-muted-foreground">{row.desc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <H3>SeverityBadge</H3>
          <Card className="my-4 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-2 font-semibold">Prop</th>
                    <th className="text-left px-4 py-2 font-semibold">Type</th>
                    <th className="text-left px-4 py-2 font-semibold">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-subtle">
                  <tr><td className="px-4 py-2 font-mono text-xs text-primary">severity</td><td className="px-4 py-2 font-mono text-xs text-muted-foreground">"critical" | "high" | "medium" | "low" | "info"</td><td className="px-4 py-2 text-xs text-muted-foreground">Severity level to render</td></tr>
                  <tr><td className="px-4 py-2 font-mono text-xs text-primary">size</td><td className="px-4 py-2 font-mono text-xs text-muted-foreground">"default" | "sm"</td><td className="px-4 py-2 text-xs text-muted-foreground">Compact size for inline use</td></tr>
                </tbody>
              </table>
            </div>
          </Card>

          <Callout variant="info" title="Type safety">
            The badge components import their union types from <InlineCode>lib/types.ts</InlineCode>. This means a typo like <InlineCode>{`status="supressd"`}</InlineCode> fails at compile time instead of silently rendering an empty badge.
          </Callout>

          {/* Footer nav */}
          <div className="flex items-center justify-between pt-6 border-t border-border-subtle">
            <Button asChild variant="ghost" size="sm">
              <Link href="/docs/getting-started"><ArrowLeft className="w-4 h-4 mr-1.5" />Getting Started</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/docs/routing">Next: Routing Guide<ArrowRight className="w-4 h-4 ml-1.5" /></Link>
            </Button>
          </div>
        </DocsBody>
      </div>
    </PageContainer>
  );
}
