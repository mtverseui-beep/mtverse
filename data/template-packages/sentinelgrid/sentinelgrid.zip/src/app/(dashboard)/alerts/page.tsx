"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { SeverityBadge, AlertStatusBadge } from "@/components/common/badges";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Bell, BellRing, CheckCircle2, XCircle, Ban, Inbox, Download, RefreshCw,
  Filter, AlertOctagon,
} from "lucide-react";
import { alerts, alertRules, services, people, escalationPolicies } from "@/lib/data";
import { useIncidentStore } from "@/lib/store";
import { toast } from "sonner";
import type { AlertEvent, AlertStatus } from "@/lib/types";

const tabs: { key: AlertStatus | "all"; label: string }[] = [
  { key: "all", label: "All" },
  { key: "firing", label: "Firing" },
  { key: "acknowledged", label: "Acknowledged" },
  { key: "resolved", label: "Resolved" },
  { key: "suppressed", label: "Suppressed" },
];

export default function AlertsInboxPage() {
  const router = useRouter();
  const { isAcked, isResolved, isSuppressed, ackAlert, resolveAlert, suppressAlert } = useIncidentStore();
  const [activeTab, setActiveTab] = React.useState<AlertStatus | "all">("all");

  // Compute effective status (combining base status with store overrides)
  function effectiveStatus(a: AlertEvent): AlertStatus {
    if (isSuppressed(a.ref)) return "suppressed";
    if (isResolved(a.ref)) return "resolved";
    if (isAcked(a.ref)) return "acknowledged";
    return a.status;
  }

  const enriched = alerts.map((a) => ({ ...a, effStatus: effectiveStatus(a) }));
  const filtered = activeTab === "all" ? enriched : enriched.filter((a) => a.effStatus === activeTab);

  const firingCount = enriched.filter((a) => a.effStatus === "firing").length;
  const ackCount = enriched.filter((a) => a.effStatus === "acknowledged").length;
  const resolvedCount = enriched.filter((a) => a.effStatus === "resolved").length;
  const suppressedCount = enriched.filter((a) => a.effStatus === "suppressed").length;

  function handleAck(a: AlertEvent) {
    ackAlert(a.ref);
    toast.success(`Alert ${a.ref} acknowledged`, { description: "You are now responsible for this alert." });
  }
  function handleResolve(a: AlertEvent) {
    resolveAlert(a.ref);
    toast.success(`Alert ${a.ref} resolved`, { description: "Marked as resolved and removed from active queue." });
  }
  function handleSuppress(a: AlertEvent) {
    suppressAlert(a.ref);
    toast.success(`Alert ${a.ref} suppressed`, { description: "Notifications muted for this dedup key." });
  }

  const cols: Column<typeof enriched[number]>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => <code className="text-[11px] font-mono text-muted-foreground">{r.ref}</code>,
    },
    {
      key: "rule",
      header: "Rule",
      cell: (r) => {
        const rule = alertRules.find((ar) => ar.id === r.ruleId);
        return (
          <div className="min-w-0 max-w-xs">
            <p className="text-xs font-medium truncate">{rule?.name ?? r.ruleId}</p>
            <p className="text-[10px] text-muted-foreground truncate">{r.message}</p>
          </div>
        );
      },
    },
    {
      key: "service",
      header: "Service",
      filterable: true,
      filterOptions: services.map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.serviceId === v,
      hideOnMobile: true,
      cell: (r) => {
        const s = services.find((x) => x.id === r.serviceId);
        return <span className="text-xs">{s?.name ?? r.serviceId}</span>;
      },
    },
    {
      key: "severity",
      header: "Severity",
      filterable: true,
      filterOptions: [
        { label: "Critical", value: "critical" },
        { label: "High", value: "high" },
        { label: "Medium", value: "medium" },
        { label: "Low", value: "low" },
      ],
      filterFn: (r, v) => r.severity === v,
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "status",
      header: "Status",
      filterable: true,
      filterOptions: [
        { label: "Firing", value: "firing" },
        { label: "Acknowledged", value: "acknowledged" },
        { label: "Resolved", value: "resolved" },
        { label: "Suppressed", value: "suppressed" },
      ],
      filterFn: (r, v) => r.effStatus === v,
      cell: (r) => <AlertStatusBadge status={r.effStatus} />,
    },
    {
      key: "startedAt",
      header: "Started",
      align: "right",
      sortable: true,
      sortValue: (r) => r.startedAt,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{new Date(r.startedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>,
    },
    {
      key: "value",
      header: "Value",
      align: "right",
      hideOnMobile: true,
      cell: (r) => <code className="text-xs font-mono">{r.value}</code>,
    },
    {
      key: "routedTo",
      header: "Routed To",
      hideOnMobile: true,
      cell: (r) => {
        const ep = escalationPolicies.find((e) => e.id === r.routedTo);
        return (
          <span className="text-xs font-mono text-muted-foreground">{ep?.name ?? r.routedTo}</span>
        );
      },
    },
    {
      key: "actions",
      header: "Actions",
      align: "right",
      cell: (r) => (
        <div className="flex items-center gap-0.5 justify-end" onClick={(e) => e.stopPropagation()}>
          {r.effStatus === "firing" && (
            <Button size="icon" variant="ghost" className="h-7 w-7 text-warning-foreground" aria-label="Acknowledge" onClick={() => handleAck(r)}>
              <CheckCircle2 className="w-3.5 h-3.5" />
            </Button>
          )}
          {r.effStatus !== "resolved" && (
            <Button size="icon" variant="ghost" className="h-7 w-7 text-success" aria-label="Resolve" onClick={() => handleResolve(r)}>
              <XCircle className="w-3.5 h-3.5" />
            </Button>
          )}
          {r.effStatus !== "suppressed" && r.effStatus !== "resolved" && (
            <Button size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground" aria-label="Suppress" onClick={() => handleSuppress(r)}>
              <Ban className="w-3.5 h-3.5" />
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Alerts Inbox"
        description="Triage and act on firing alerts. Acknowledge, resolve, or suppress — actions persist for the session."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Alerts" }]}
        icon={<BellRing className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Alerts refreshed")}>
              <RefreshCw className="w-3.5 h-3.5" /> <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Alerts exported as CSV")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Firing" value={firingCount} hint="needs attention" icon={<Bell className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Acknowledged" value={ackCount} hint="in progress" icon={<CheckCircle2 className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Resolved (24h)" value={resolvedCount} hint="closed today" icon={<XCircle className="w-4 h-4" />} accent="success" />
        <KpiCard label="Suppressed" value={suppressedCount} hint="muted" icon={<Ban className="w-4 h-4" />} accent="muted" />
      </div>

      {/* Filter tabs */}
      <Card className="p-2">
        <div className="flex items-center gap-1 overflow-x-auto">
          {tabs.map((t) => {
            const count = t.key === "all" ? enriched.length : enriched.filter((a) => a.effStatus === t.key).length;
            return (
              <button
                key={t.key}
                onClick={() => setActiveTab(t.key)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                  activeTab === t.key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                {t.label}
                <span className={`text-[10px] px-1.5 rounded-full ${activeTab === t.key ? "bg-primary-foreground/20" : "bg-muted"}`}>{count}</span>
              </button>
            );
          })}
        </div>
      </Card>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Alert Inbox" description="Click a row to view full alert details and timeline" />
        <div className="mt-4">
          <DataTable
            columns={cols}
            data={filtered}
            rowKey={(r) => r.id}
            searchKeys={["ref", "message"]}
            searchPlaceholder="Search alerts by ref or message..."
            pageSize={10}
            initialSort={{ key: "startedAt", dir: "desc" }}
            onRowClick={(r) => router.push(`/alerts/${r.id}`)}
            mobileCard={(r) => (
              <button
                onClick={() => router.push(`/alerts/${r.id}`)}
                className="w-full text-left rounded-lg border bg-card p-3 hover:bg-muted/40"
              >
                <div className="flex items-center gap-2 mb-2">
                  <code className="text-[10px] font-mono text-muted-foreground">{r.ref}</code>
                  <SeverityBadge severity={r.severity} size="sm" />
                  <AlertStatusBadge status={r.effStatus} />
                </div>
                <p className="text-xs font-medium truncate mb-1">{r.message}</p>
                <p className="text-[10px] text-muted-foreground">
                  {services.find(s => s.id === r.serviceId)?.name} · {new Date(r.startedAt).toLocaleString()}
                </p>
              </button>
            )}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
