"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SeverityBadge } from "@/components/common/badges";
import {
  SlidersHorizontal, Plus, Check, ArrowRight, TrendingDown, Lightbulb, Activity,
  Gauge, Zap, Target, Bell,
} from "lucide-react";
import { alertRules, services } from "@/lib/data";
import { toast } from "sonner";

interface TuningOpportunity {
  id: string;
  ruleId: string;
  ruleRef: string;
  ruleName: string;
  serviceName: string;
  severity: "critical" | "high" | "medium" | "low";
  currentThreshold: string;
  suggestedThreshold: string;
  currentWindow: string;
  suggestedWindow: string;
  triggerCount7d: number;
  noiseScore: number;
  expectedReduction: string;
  rationale: string;
  applied?: boolean;
}

const opportunities: TuningOpportunity[] = [
  {
    id: "to1",
    ruleId: "ar9",
    ruleRef: "ALERT-009",
    ruleName: "Host CPU > 90%",
    serviceName: "api-gateway",
    severity: "low",
    currentThreshold: "> 90%",
    suggestedThreshold: "> 95%",
    currentWindow: "10m",
    suggestedWindow: "30m",
    triggerCount7d: 12,
    noiseScore: 87,
    expectedReduction: "-10 alerts/week",
    rationale: "CPU spikes during backups are transient. Tighter threshold and longer window filter expected noise.",
  },
  {
    id: "to2",
    ruleId: "ar10",
    ruleRef: "ALERT-010",
    ruleName: "Disk usage > 85%",
    serviceName: "api-gateway",
    severity: "low",
    currentThreshold: "> 85%",
    suggestedThreshold: "> 90%",
    currentWindow: "5m",
    suggestedWindow: "15m",
    triggerCount7d: 4,
    noiseScore: 21,
    expectedReduction: "-3 alerts/week",
    rationale: "Disk usage growth is gradual. Higher threshold with sustained window avoids premature alerts.",
  },
  {
    id: "to3",
    ruleId: "ar7",
    ruleRef: "ALERT-007",
    ruleName: "API Gateway p99 > 200ms",
    serviceName: "api-gateway",
    severity: "medium",
    currentThreshold: "> 200ms",
    suggestedThreshold: "> 250ms",
    currentWindow: "5m",
    suggestedWindow: "10m",
    triggerCount7d: 2,
    noiseScore: 8,
    expectedReduction: "-1 alert/week",
    rationale: "p99 latency has natural variance. Slightly higher threshold and longer window reduce false positives.",
  },
  {
    id: "to4",
    ruleId: "ar1",
    ruleRef: "ALERT-001",
    ruleName: "Checkout 5xx > 1%",
    serviceName: "checkout-api",
    severity: "high",
    currentThreshold: "> 1%",
    suggestedThreshold: "> 1.5%",
    currentWindow: "5m",
    suggestedWindow: "5m",
    triggerCount7d: 3,
    noiseScore: 12,
    expectedReduction: "-1 alert/week",
    rationale: "Current 1% threshold triggers during normal traffic jitter. 1.5% retains sensitivity to real outages.",
  },
];

export default function TuningPage() {
  const [applied, setApplied] = React.useState<Set<string>>(new Set());

  function applyTuning(id: string) {
    setApplied((s) => new Set([...s, id]));
    const opp = opportunities.find((o) => o.id === id);
    toast.success("Tuning applied", {
      description: `${opp?.ruleName}: threshold ${opp?.currentThreshold} → ${opp?.suggestedThreshold}`,
    });
  }
  function applyAll() {
    setApplied(new Set(opportunities.map((o) => o.id)));
    toast.success("All tuning suggestions applied", { description: `${opportunities.length} rules updated.` });
  }

  const totalReduction = "-15 alerts/week";
  const appliedCount = applied.size;
  const totalOpportunities = opportunities.length;

  return (
    <PageContainer>
      <PageHeader
        title="Alert Tuning"
        description="Apply data-driven threshold and window recommendations to reduce noise while preserving signal."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Alerts", href: "/alerts" }, { label: "Tuning" }]}
        icon={<SlidersHorizontal className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={applyAll} disabled={appliedCount === totalOpportunities}>
            <Check className="w-3.5 h-3.5" /> <span className="hidden md:inline">Apply All</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Opportunities" value={totalOpportunities} hint={`${appliedCount} applied`} icon={<Lightbulb className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Expected Reduction" value={totalReduction} hint="if all applied" icon={<TrendingDown className="w-4 h-4" />} accent="success" />
        <KpiCard label="Avg Noise Score" value={Math.round(opportunities.reduce((s, o) => s + o.noiseScore, 0) / opportunities.length)} hint="of candidates" icon={<Activity className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Trigger Count (7d)" value={opportunities.reduce((s, o) => s + o.triggerCount7d, 0)} hint="noise volume" icon={<Bell className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading title="Tuning Opportunities" description="Each suggestion includes the proposed change, rationale, and expected impact" />

        <div className="space-y-3">
          {opportunities.map((o) => {
            const isApplied = applied.has(o.id);
            return (
              <div key={o.id} className={`rounded-lg border p-5 space-y-4 ${isApplied ? "border-success/40 bg-success/5" : "border-border"}`}>
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${isApplied ? "bg-success/15 text-success border border-success/30" : "bg-warning/15 text-warning-foreground border border-warning/30"}`}>
                      {isApplied ? <Check className="w-4 h-4" /> : <Lightbulb className="w-4 h-4" />}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <code className="text-[11px] font-mono text-muted-foreground">{o.ruleRef}</code>
                        <SeverityBadge severity={o.severity} size="sm" />
                        {isApplied && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-success/15 text-success border border-success/30 font-medium uppercase">Applied</span>
                        )}
                      </div>
                      <p className="text-sm font-semibold mt-1">{o.ruleName}</p>
                      <p className="text-[11px] text-muted-foreground">{o.serviceName}</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant={isApplied ? "outline" : "default"}
                    className="gap-1.5"
                    onClick={() => applyTuning(o.id)}
                    disabled={isApplied}
                  >
                    {isApplied ? <><Check className="w-3.5 h-3.5" /> Applied</> : <><Zap className="w-3.5 h-3.5" /> Apply Tuning</>}
                  </Button>
                </div>

                {/* Before → After */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="rounded-lg border border-border p-3 space-y-2">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium flex items-center gap-1">
                      <Target className="w-3 h-3" /> Current
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <p className="text-[10px] text-muted-foreground">Threshold</p>
                        <p className="font-mono font-medium">{o.currentThreshold}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground">Window</p>
                        <p className="font-mono font-medium">{o.currentWindow}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground">Triggers (7d)</p>
                        <p className="font-mono font-medium text-warning-foreground">{o.triggerCount7d}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground">Noise Score</p>
                        <p className="font-mono font-medium text-destructive">{o.noiseScore}</p>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-lg border border-success/30 bg-success/5 p-3 space-y-2">
                    <p className="text-[10px] uppercase tracking-wider text-success font-medium flex items-center gap-1">
                      <Gauge className="w-3 h-3" /> Suggested
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <p className="text-[10px] text-muted-foreground">Threshold</p>
                        <p className="font-mono font-medium text-success">{o.suggestedThreshold}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground">Window</p>
                        <p className="font-mono font-medium text-success">{o.suggestedWindow}</p>
                      </div>
                      <div className="col-span-2">
                        <p className="text-[10px] text-muted-foreground">Expected Impact</p>
                        <p className="font-mono font-medium text-success">{o.expectedReduction}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Rationale */}
                <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/30 border border-border">
                  <Lightbulb className="w-3.5 h-3.5 text-warning mt-0.5 shrink-0" />
                  <p className="text-[11px] text-muted-foreground">{o.rationale}</p>
                </div>

                {/* Flow indicator */}
                <div className="flex items-center justify-center gap-2 text-[10px] text-muted-foreground">
                  <span className="px-2 py-0.5 rounded bg-muted border border-border font-mono">{o.currentThreshold} · {o.currentWindow}</span>
                  <ArrowRight className="w-3 h-3" />
                  <span className="px-2 py-0.5 rounded bg-success/15 text-success border border-success/30 font-mono">{o.suggestedThreshold} · {o.suggestedWindow}</span>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Summary */}
      <Card className="p-5">
        <SectionHeading title="Tuning Summary" description="Impact of applied changes" />
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="rounded-lg border border-border p-4">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Applied</p>
            <p className="text-2xl font-semibold tabular-nums mt-1">{appliedCount}<span className="text-sm text-muted-foreground">/{totalOpportunities}</span></p>
          </div>
          <div className="rounded-lg border border-border p-4">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Alerts Eliminated (7d)</p>
            <p className="text-2xl font-semibold tabular-nums mt-1 text-success">
              {opportunities.filter((o) => applied.has(o.id)).reduce((s, o) => s + o.triggerCount7d, 0)}
            </p>
          </div>
          <div className="rounded-lg border border-border p-4">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Noise Score Reduction</p>
            <p className="text-2xl font-semibold tabular-nums mt-1 text-success">
              -{opportunities.filter((o) => applied.has(o.id)).reduce((s, o) => s + o.noiseScore, 0)}
            </p>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
