"use client";

import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  BellRing, CheckCircle2, XCircle, Ban, Clock, ChevronRight, Activity, ArrowRight,
  Zap, ExternalLink, AlertCircle, Timer, Settings, MessageSquare,
} from "lucide-react";
import { alerts, alertRules, services, people, escalationPolicies, incidents } from "@/lib/data";
import { useIncidentStore } from "@/lib/store";
import { SeverityBadge, AlertStatusBadge } from "@/components/common/badges";
import { toast } from "sonner";

export default function AlertDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const id = params?.id as string | undefined;
  const alert = alerts.find((a) => a.id === id) ?? alerts[0];

  const { isAcked, isResolved, isSuppressed, ackAlert, resolveAlert, suppressAlert } = useIncidentStore();

  function effectiveStatus() {
    if (isSuppressed(alert.ref)) return "suppressed";
    if (isResolved(alert.ref)) return "resolved";
    if (isAcked(alert.ref)) return "acknowledged";
    return alert.status;
  }
  const status = effectiveStatus();

  const rule = alertRules.find((r) => r.id === alert.ruleId);
  const service = services.find((s) => s.id === alert.serviceId);
  const escalation = escalationPolicies.find((e) => e.id === alert.routedTo);
  const incident = alert.incidentId ? incidents.find((i) => i.id === alert.incidentId) : null;
  const ackedBy = alert.acknowledgedBy ? people.find((p) => p.id === alert.acknowledgedBy) : null;

  const [snoozeOpen, setSnoozeOpen] = React.useState(false);
  const [snoozeDur, setSnoozeDur] = React.useState<string>("30m");

  function handleAck() {
    ackAlert(alert.ref);
    toast.success(`Alert ${alert.ref} acknowledged`, { description: "You are now responsible for this alert." });
  }
  function handleResolve() {
    resolveAlert(alert.ref);
    toast.success(`Alert ${alert.ref} resolved`);
  }
  function handleSuppress() {
    suppressAlert(alert.ref);
    toast.success(`Alert ${alert.ref} suppressed`);
  }
  function handleSnooze() {
    setSnoozeOpen(false);
    toast.success(`Alert snoozed for ${snoozeDur}`, { description: "Notifications will resume after the snooze period." });
  }

  const startedAt = new Date(alert.startedAt);
  const durationMs = (alert.resolvedAt ? new Date(alert.resolvedAt).getTime() : Date.now()) - startedAt.getTime();
  const durationMin = Math.round(durationMs / 60000);

  // Build timeline
  const timeline: { time: string; label: string; icon: React.ReactNode; tone: "destructive" | "warning" | "success" | "muted" | "info" }[] = [
    { time: alert.startedAt, label: "Alert triggered", icon: <BellRing className="w-3.5 h-3.5" />, tone: "destructive" },
  ];
  if (alert.acknowledgedAt) {
    timeline.push({ time: alert.acknowledgedAt, label: `Acknowledged by ${ackedBy?.name ?? "engineer"}`, icon: <CheckCircle2 className="w-3.5 h-3.5" />, tone: "warning" });
  }
  if (isAcked(alert.ref) && !alert.acknowledgedAt) {
    timeline.push({ time: new Date().toISOString(), label: "Acknowledged (session)", icon: <CheckCircle2 className="w-3.5 h-3.5" />, tone: "warning" });
  }
  if (alert.resolvedAt) {
    timeline.push({ time: alert.resolvedAt, label: "Resolved", icon: <XCircle className="w-3.5 h-3.5" />, tone: "success" });
  }
  if (isResolved(alert.ref) && !alert.resolvedAt) {
    timeline.push({ time: new Date().toISOString(), label: "Resolved (session)", icon: <XCircle className="w-3.5 h-3.5" />, tone: "success" });
  }
  if (isSuppressed(alert.ref)) {
    timeline.push({ time: new Date().toISOString(), label: "Suppressed (session)", icon: <Ban className="w-3.5 h-3.5" />, tone: "muted" });
  }

  const toneClasses: Record<string, string> = {
    destructive: "bg-destructive/10 text-destructive border-destructive/30",
    warning: "bg-warning/10 text-warning-foreground border-warning/30",
    success: "bg-success/10 text-success border-success/30",
    muted: "bg-muted text-muted-foreground border-border",
    info: "bg-info/10 text-info-foreground border-info/30",
  };

  return (
    <PageContainer>
      <PageHeader
        title={alert.ref}
        description={alert.message}
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Alerts", href: "/alerts" }, { label: alert.ref }]}
        icon={<BellRing className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" onClick={() => router.push("/alerts")}>
            <ChevronRight className="w-3.5 h-3.5 rotate-180" /> Back to Inbox
          </Button>
        }
      />

      {/* Hero */}
      <Card className="p-5 space-y-4 border-l-4" style={{ borderLeftColor: alert.severity === "critical" ? "#F87171" : alert.severity === "high" ? "#FCD34D" : "#60A5FA" }}>
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="space-y-2 min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <SeverityBadge severity={alert.severity} />
              <AlertStatusBadge status={status} />
              {rule && <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border font-mono">{rule.ref}</span>}
            </div>
            <h2 className="text-lg font-semibold">{rule?.name ?? "Unknown rule"}</h2>
            <p className="text-sm text-muted-foreground">{alert.message}</p>
          </div>
          <div className="grid grid-cols-2 gap-3 shrink-0">
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Started</p>
              <p className="text-xs font-mono">{startedAt.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Duration</p>
              <p className="text-xs font-mono font-medium">
                {durationMin < 60 ? `${durationMin}m` : `${Math.floor(durationMin / 60)}h ${durationMin % 60}m`}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Current Value</p>
              <p className="text-sm font-mono font-semibold">{alert.value}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Dedup Key</p>
              <p className="text-[10px] font-mono text-muted-foreground">{alert.dedupKey}</p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 flex-wrap pt-3 border-t border-border">
          {status === "firing" && (
            <Button size="sm" className="gap-1.5" onClick={handleAck}>
              <CheckCircle2 className="w-3.5 h-3.5" /> Acknowledge
            </Button>
          )}
          {status !== "resolved" && (
            <Button size="sm" variant="outline" className="gap-1.5 text-success" onClick={handleResolve}>
              <XCircle className="w-3.5 h-3.5" /> Resolve
            </Button>
          )}
          {status !== "suppressed" && status !== "resolved" && (
            <Button size="sm" variant="outline" className="gap-1.5" onClick={handleSuppress}>
              <Ban className="w-3.5 h-3.5" /> Suppress
            </Button>
          )}
          <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setSnoozeOpen(true)}>
            <Clock className="w-3.5 h-3.5" /> Snooze
          </Button>
          {incident && (
            <Button asChild size="sm" variant="outline" className="gap-1.5 ml-auto">
              <Link href={`/incidents/${incident.id}`}>
                <ExternalLink className="w-3.5 h-3.5" /> View Incident {incident.ref}
              </Link>
            </Button>
          )}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left col: rule definition + service context */}
        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Alert Rule Definition" description={rule?.ref} action={<Settings className="w-4 h-4 text-muted-foreground" />} />
            {rule && (
              <div className="space-y-3">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-1">Name</p>
                  <p className="text-sm font-medium">{rule.name}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-1">Description</p>
                  <p className="text-xs text-muted-foreground">{rule.description}</p>
                </div>
                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-border">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Metric</p>
                    <p className="text-xs font-mono">{rule.metric}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Condition</p>
                    <p className="text-xs font-mono">{rule.condition} {rule.threshold}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Window</p>
                    <p className="text-xs font-mono">{rule.window}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Severity</p>
                    <SeverityBadge severity={rule.severity} size="sm" />
                  </div>
                </div>
                <Button asChild variant="outline" size="sm" className="w-full h-8 mt-2 gap-1.5">
                  <Link href={`/alerts/rules?edit=${rule.id}`}>
                    <Settings className="w-3 h-3" /> Edit Rule
                  </Link>
                </Button>
              </div>
            )}
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Service Context" action={<Activity className="w-4 h-4 text-muted-foreground" />} />
            {service && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{service.name}</p>
                    <p className="text-[11px] text-muted-foreground">{service.teamId}</p>
                  </div>
                  <Button asChild variant="outline" size="sm" className="h-8 gap-1.5">
                    <Link href={`/services/${service.id}`}>
                      <ArrowRight className="w-3 h-3" /> Open
                    </Link>
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border text-xs">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Health</p>
                    <p className="capitalize">{service.health}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Tier</p>
                    <p className="uppercase">{service.tier}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Error Rate</p>
                    <p className="font-mono">{service.errorRate}%</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Open Alerts</p>
                    <p className="font-mono">{service.openAlerts}</p>
                  </div>
                </div>
              </div>
            )}
          </Card>

          {incident && (
            <Card className="p-5 space-y-3 border-l-4 border-l-warning">
              <SectionHeading title="Linked Incident" action={<AlertCircle className="w-4 h-4 text-warning" />} />
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <code className="text-[11px] font-mono text-warning-foreground">{incident.ref}</code>
                  <SeverityBadge severity={incident.severity} size="sm" />
                </div>
                <p className="text-sm font-medium">{incident.title}</p>
                <Button asChild variant="outline" size="sm" className="w-full h-8 mt-3 gap-1.5">
                  <Link href={`/incidents/${incident.id}`}>
                    <ExternalLink className="w-3 h-3" /> Open Incident
                  </Link>
                </Button>
              </div>
            </Card>
          )}
        </div>

        {/* Middle: timeline */}
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading title="Response Timeline" description="Events for this alert from trigger to resolution" />
          <div className="space-y-1">
            {timeline.map((ev, i) => (
              <div key={i} className="relative pl-8 pb-4 last:pb-0">
                <div className="absolute left-0 top-1.5 bottom-0 w-px bg-border" />
                <div className={`absolute left-0 top-1 w-4 h-4 -translate-x-1/2 rounded-full border-2 border-background flex items-center justify-center ${toneClasses[ev.tone]}`}>
                  {ev.icon}
                </div>
                <div className="flex items-center justify-between gap-3">
                  <p className="text-xs font-medium">{ev.label}</p>
                  <span className="text-[10px] font-mono text-muted-foreground whitespace-nowrap">
                    {new Date(ev.time).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                  </span>
                </div>
              </div>
            ))}
            {timeline.length === 1 && (
              <div className="text-center py-6 text-xs text-muted-foreground">
                <Timer className="w-4 h-4 mx-auto mb-2 opacity-50" />
                Awaiting acknowledgement...
              </div>
            )}
          </div>

          {/* Routed to: escalation policy with targets */}
          {escalation && (
            <div className="pt-4 border-t border-border">
              <SectionHeading title="Routed To" description={`${escalation.name} — escalation policy`} action={<Zap className="w-4 h-4 text-warning" />} />
              <div className="mt-3 overflow-x-auto">
                <div className="flex items-stretch gap-2 min-w-max">
                  {escalation.rounds.map((round, ri) => (
                    <React.Fragment key={ri}>
                      {ri > 0 && (
                        <div className="flex flex-col items-center justify-center px-1 text-center">
                          <Clock className="w-3 h-3 text-muted-foreground mb-0.5" />
                          <span className="text-[9px] font-mono text-muted-foreground whitespace-nowrap">+{round.delayMinutes}m</span>
                        </div>
                      )}
                      <div className="rounded-lg border border-border bg-muted/30 p-3 min-w-[140px]">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[9px] uppercase tracking-wider text-muted-foreground font-medium">Round {ri + 1}</span>
                          <span className="text-[9px] font-mono text-muted-foreground">{round.delayMinutes === 0 ? "Now" : `+${round.delayMinutes}m`}</span>
                        </div>
                        <div className="space-y-1.5">
                          {round.targets.map((t, ti) => {
                            const u = people.find((p) => p.id === t.id);
                            return (
                              <div key={ti} className="flex items-center gap-2 p-1.5 rounded border border-border bg-card">
                                <Avatar className="w-5 h-5">
                                  <AvatarImage src={u?.avatarUrl} alt={u?.name ?? ""} />
                                  <AvatarFallback className="text-[8px]">{u?.name?.split(" ").map(s => s[0]).join("").slice(0, 2) ?? "?"}</AvatarFallback>
                                </Avatar>
                                <span className="text-[10px] font-medium truncate">{u?.name ?? t.id}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </React.Fragment>
                  ))}
                </div>
              </div>
              {escalation.repeatCount > 0 && (
                <p className="text-[10px] text-muted-foreground mt-2">Repeats {escalation.repeatCount}x before giving up.</p>
              )}
            </div>
          )}

          {/* Quick comment box */}
          <div className="pt-4 border-t border-border">
            <SectionHeading title="Add Comment" description="Adds a note to the alert timeline" />
            <div className="mt-3 flex items-start gap-2">
              <Avatar className="w-7 h-7">
                <AvatarImage src={people[1].avatarUrl} alt="You" />
                <AvatarFallback>You</AvatarFallback>
              </Avatar>
              <div className="flex-1 flex gap-2">
                <input
                  type="text"
                  placeholder="Add a comment to the timeline..."
                  className="flex-1 h-9 px-3 rounded-md border border-border bg-background text-xs focus:outline-none focus:ring-1 focus:ring-primary"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      const v = (e.target as HTMLInputElement).value;
                      if (v.trim()) {
                        toast.success("Comment added to timeline");
                        (e.target as HTMLInputElement).value = "";
                      }
                    }
                  }}
                />
                <Button size="sm" variant="outline" className="h-9 gap-1.5" onClick={() => toast.success("Comment added")}>
                  <MessageSquare className="w-3.5 h-3.5" /> Post
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Snooze dialog */}
      <Dialog open={snoozeOpen} onOpenChange={setSnoozeOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Snooze Alert</DialogTitle>
            <DialogDescription>Temporarily suppress notifications for this alert.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-3 gap-2 py-2">
            {["30m", "1h", "4h"].map((d) => (
              <button
                key={d}
                onClick={() => setSnoozeDur(d)}
                className={`rounded-lg border p-3 text-center text-sm font-medium transition-colors ${
                  snoozeDur === d ? "border-primary bg-primary/5 text-primary" : "border-border hover:bg-muted/40"
                }`}
              >
                {d}
              </button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSnoozeOpen(false)}>Cancel</Button>
            <Button onClick={handleSnooze} className="gap-1.5">
              <Clock className="w-3.5 h-3.5" /> Snooze for {snoozeDur}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
