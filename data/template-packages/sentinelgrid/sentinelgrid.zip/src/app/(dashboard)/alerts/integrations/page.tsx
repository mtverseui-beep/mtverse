"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { DataTable, type Column } from "@/components/tables/data-table";
import { StatusDot } from "@/components/common/badges";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Plug, Plus, Settings, Bell, Send, Inbox, Webhook, Slack, Mail, MessageSquare,
  Phone, Activity, ArrowRightLeft, CheckCircle2, AlertCircle,
} from "lucide-react";
import { toast } from "sonner";

type IntegrationType = "pagerduty" | "opsgenie" | "slack" | "email" | "webhook" | "victorops" | "twilio";
type IntegrationDirection = "inbound" | "outbound" | "bidirectional";

interface Integration {
  id: string;
  name: string;
  type: IntegrationType;
  direction: IntegrationDirection;
  enabled: boolean;
  alertsSent24h: number;
  alertsReceived24h: number;
  lastEventAt: string;
  configSummary: string;
}

const initialIntegrations: Integration[] = [
  { id: "int1", name: "PagerDuty (Production)", type: "pagerduty", direction: "bidirectional", enabled: true, alertsSent24h: 14, alertsReceived24h: 6, lastEventAt: "2026-07-02T05:48:00Z", configSummary: "Service: SentinelGrid Prod · Routing key: ••••1a4f" },
  { id: "int2", name: "Opsgenie (Reliability)", type: "opsgenie", direction: "bidirectional", enabled: true, alertsSent24h: 8, alertsReceived24h: 3, lastEventAt: "2026-07-02T03:20:00Z", configSummary: "Team: Reliability · API key: ••••8b21" },
  { id: "int3", name: "Slack #alerts", type: "slack", direction: "outbound", enabled: true, alertsSent24h: 47, alertsReceived24h: 0, lastEventAt: "2026-07-02T05:50:00Z", configSummary: "Workspace: sentinelgrid · Channel: #alerts" },
  { id: "int4", name: "Slack #alerts-critical", type: "slack", direction: "outbound", enabled: true, alertsSent24h: 4, alertsReceived24h: 0, lastEventAt: "2026-07-02T05:12:00Z", configSummary: "Workspace: sentinelgrid · Channel: #alerts-critical" },
  { id: "int5", name: "Email Notifications", type: "email", direction: "outbound", enabled: true, alertsSent24h: 18, alertsReceived24h: 0, lastEventAt: "2026-07-02T05:48:00Z", configSummary: "SMTP: smtp.sentinelgrid.io · Distribution list: oncall@" },
  { id: "int6", name: "Generic Webhook", type: "webhook", direction: "bidirectional", enabled: true, alertsSent24h: 22, alertsReceived24h: 9, lastEventAt: "2026-07-02T05:48:00Z", configSummary: "URL: https://hooks.sentinelgrid.io/inbox · HMAC signed" },
  { id: "int7", name: "VictorOps (Legacy)", type: "victorops", direction: "outbound", enabled: false, alertsSent24h: 0, alertsReceived24h: 0, lastEventAt: "2026-06-15T14:22:00Z", configSummary: "Routing key: ••••9c3d · Deprecated" },
  { id: "int8", name: "Twilio SMS", type: "twilio", direction: "outbound", enabled: true, alertsSent24h: 12, alertsReceived24h: 0, lastEventAt: "2026-07-02T05:12:00Z", configSummary: "From: +1 (415) 555-0199 · 4 phone numbers configured" },
];

const typeIcons: Record<IntegrationType, React.ReactNode> = {
  pagerduty: <Phone className="w-4 h-4" />,
  opsgenie: <Bell className="w-4 h-4" />,
  slack: <Slack className="w-4 h-4" />,
  email: <Mail className="w-4 h-4" />,
  webhook: <Webhook className="w-4 h-4" />,
  victorops: <Phone className="w-4 h-4" />,
  twilio: <MessageSquare className="w-4 h-4" />,
};

export default function IntegrationsPage() {
  const [integrations, setIntegrations] = React.useState(initialIntegrations);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [configId, setConfigId] = React.useState<string | null>(null);

  function toggle(id: string) {
    setIntegrations((is) => is.map((i) => i.id === id ? { ...i, enabled: !i.enabled } : i));
    const i = integrations.find((x) => x.id === id);
    toast.success(`${i?.name} ${i?.enabled ? "disabled" : "enabled"}`);
  }
  function openConfig(id: string) {
    setConfigId(id);
    setDialogOpen(true);
  }

  const enabledCount = integrations.filter((i) => i.enabled).length;
  const totalSent = integrations.reduce((s, i) => s + i.alertsSent24h, 0);
  const totalReceived = integrations.reduce((s, i) => s + i.alertsReceived24h, 0);
  const configuring = integrations.find((i) => i.id === configId);

  const cols: Column<Integration>[] = [
    {
      key: "name",
      header: "Integration",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-3">
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center border ${r.enabled ? "bg-primary/10 text-primary border-primary/20" : "bg-muted text-muted-foreground border-border"}`}>
            {typeIcons[r.type]}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-medium truncate">{r.name}</p>
            <p className="text-[10px] text-muted-foreground capitalize">{r.type}</p>
          </div>
        </div>
      ),
    },
    {
      key: "direction",
      header: "Direction",
      filterable: true,
      filterOptions: [
        { label: "Inbound", value: "inbound" },
        { label: "Outbound", value: "outbound" },
        { label: "Bidirectional", value: "bidirectional" },
      ],
      filterFn: (r, v) => r.direction === v,
      hideOnMobile: true,
      cell: (r) => (
        <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded border border-border bg-muted">
          <ArrowRightLeft className="w-3 h-3" />
          {r.direction}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => (
        <span className="inline-flex items-center gap-1.5 text-xs">
          <StatusDot color={r.enabled ? "success" : "muted"} pulse={r.enabled} size="sm" />
          {r.enabled ? "Active" : "Disabled"}
        </span>
      ),
    },
    {
      key: "alertsSent24h",
      header: "Sent (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.alertsSent24h,
      hideOnMobile: true,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-mono ${r.alertsSent24h > 0 ? "text-foreground" : "text-muted-foreground"}`}>{r.alertsSent24h}</span>
      ),
    },
    {
      key: "alertsReceived24h",
      header: "Received (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.alertsReceived24h,
      hideOnMobile: true,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-mono ${r.alertsReceived24h > 0 ? "text-foreground" : "text-muted-foreground"}`}>{r.alertsReceived24h}</span>
      ),
    },
    {
      key: "lastEventAt",
      header: "Last Event",
      align: "right",
      hideOnMobile: true,
      cell: (r) => (
        <span className="text-xs tabular-nums text-muted-foreground">
          {new Date(r.lastEventAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
        </span>
      ),
    },
    {
      key: "enabled",
      header: "Enabled",
      align: "center",
      cell: (r) => <Switch checked={r.enabled} onCheckedChange={() => toggle(r.id)} aria-label={`Toggle ${r.name}`} />,
    },
    {
      key: "configure",
      header: "",
      align: "right",
      cell: (r) => (
        <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={(e) => { e.stopPropagation(); openConfig(r.id); }}>
          <Settings className="w-3 h-3" /> Configure
        </Button>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Alert Integrations"
        description="External services that send or receive alerts. Configure PagerDuty, Opsgenie, Slack, webhooks, and more."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Alerts", href: "/alerts" }, { label: "Integrations" }]}
        icon={<Plug className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => { setConfigId(null); setDialogOpen(true); }}>
            <Plus className="w-3.5 h-3.5" /> <span className="hidden md:inline">Add Integration</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Integrations" value={integrations.length} hint={`${enabledCount} active`} icon={<Plug className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Alerts Sent (24h)" value={totalSent} hint="outbound notifications" icon={<Send className="w-4 h-4" />} accent="info" />
        <KpiCard label="Alerts Received (24h)" value={totalReceived} hint="inbound events" icon={<Inbox className="w-4 h-4" />} accent="success" />
        <KpiCard label="Bidirectional" value={integrations.filter((i) => i.direction === "bidirectional").length} hint="two-way sync" icon={<ArrowRightLeft className="w-4 h-4" />} accent="warning" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Integrations" description="Click configure to edit API keys, routing, or destination" />
        <div className="mt-4">
          <DataTable
            columns={cols}
            data={integrations}
            rowKey={(r) => r.id}
            searchKeys={["name", "type", "configSummary"]}
            searchPlaceholder="Search integrations..."
            pageSize={10}
            initialSort={{ key: "alertsSent24h", dir: "desc" }}
            mobileCard={(r) => (
              <div className="rounded-lg border bg-card p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-7 h-7 rounded-md flex items-center justify-center border ${r.enabled ? "bg-primary/10 text-primary border-primary/20" : "bg-muted text-muted-foreground border-border"}`}>
                      {typeIcons[r.type]}
                    </div>
                    <p className="text-xs font-medium">{r.name}</p>
                  </div>
                  <StatusDot color={r.enabled ? "success" : "muted"} pulse={r.enabled} />
                </div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span className="capitalize">{r.direction}</span>
                  <span>Sent {r.alertsSent24h} · Recv {r.alertsReceived24h}</span>
                </div>
                <Button size="sm" variant="outline" className="w-full h-7 text-xs gap-1" onClick={() => openConfig(r.id)}>
                  <Settings className="w-3 h-3" /> Configure
                </Button>
              </div>
            )}
          />
        </div>
      </Card>

      {/* Health summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-5 space-y-3">
          <SectionHeading title="Recent Delivery Health" description="Last 24 hours" action={<Activity className="w-4 h-4 text-muted-foreground" />} />
          <div className="space-y-2">
            {integrations.filter((i) => i.enabled).slice(0, 5).map((i) => {
              const total = i.alertsSent24h + i.alertsReceived24h;
              const successRate = total > 0 ? Math.min(100, 95 + (i.alertsSent24h % 5)) : 100;
              return (
                <div key={i.id} className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-md flex items-center justify-center bg-primary/10 text-primary border border-primary/20">
                    {typeIcons[i.type]}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium truncate">{i.name}</p>
                    <div className="w-full h-1 rounded-full bg-muted overflow-hidden mt-1">
                      <div className={`h-full ${successRate > 95 ? "bg-success" : "bg-warning"}`} style={{ width: `${successRate}%` }} />
                    </div>
                  </div>
                  <span className="text-xs font-mono tabular-nums text-muted-foreground">{successRate}%</span>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-5 space-y-3">
          <SectionHeading title="Quick Add" description="Common integration templates" />
          <div className="grid grid-cols-1 gap-2">
            {[
              { name: "PagerDuty", icon: <Phone className="w-4 h-4" />, desc: "Page on-call engineers via PagerDuty" },
              { name: "Slack", icon: <Slack className="w-4 h-4" />, desc: "Send alerts to Slack channels" },
              { name: "Webhook", icon: <Webhook className="w-4 h-4" />, desc: "Generic HTTP webhook receiver" },
              { name: "Email", icon: <Mail className="w-4 h-4" />, desc: "SMTP email notifications" },
            ].map((t) => (
              <button
                key={t.name}
                onClick={() => { setConfigId(null); setDialogOpen(true); toast.success(`New ${t.name} integration started`); }}
                className="w-full flex items-center gap-3 rounded-lg border border-border p-3 text-left hover:bg-muted/40 transition-colors"
              >
                <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-muted text-muted-foreground">
                  {t.icon}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium">{t.name}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{t.desc}</p>
                </div>
                <Plus className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            ))}
          </div>
        </Card>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{configuring ? `Configure ${configuring.name}` : "Add Integration"}</DialogTitle>
            <DialogDescription>
              {configuring ? "Update integration settings, API keys, and routing." : "Set up a new alert integration."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>Integration Type</Label>
              <Select defaultValue={configuring?.type ?? "slack"}>
                <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pagerduty">PagerDuty</SelectItem>
                  <SelectItem value="opsgenie">Opsgenie</SelectItem>
                  <SelectItem value="slack">Slack</SelectItem>
                  <SelectItem value="email">Email (SMTP)</SelectItem>
                  <SelectItem value="webhook">Webhook</SelectItem>
                  <SelectItem value="victorops">VictorOps</SelectItem>
                  <SelectItem value="twilio">Twilio SMS</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="iname">Display Name</Label>
              <Input id="iname" defaultValue={configuring?.name ?? ""} placeholder="e.g., PagerDuty (Production)" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ikey">API Key / Webhook URL</Label>
              <Input id="ikey" type="password" placeholder="••••••••••••" className="font-mono text-xs" />
            </div>
            {configuring && (
              <div className="rounded-lg border border-border p-3 text-xs">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-1">Current Config</p>
                <p className="font-mono text-[11px]">{configuring.configSummary}</p>
              </div>
            )}
            <div className="flex items-start gap-2 p-2 rounded-md bg-info/5 border border-info/20">
              <CheckCircle2 className="w-3.5 h-3.5 text-info-foreground mt-0.5 shrink-0" />
              <p className="text-[11px] text-muted-foreground">A test alert will be sent to verify the configuration after saving.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={() => { setDialogOpen(false); toast.success("Integration saved", { description: "Test alert sent successfully." }); }} className="gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Save & Test
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
