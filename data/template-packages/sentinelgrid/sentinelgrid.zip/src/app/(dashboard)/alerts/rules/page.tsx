"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { DataTable, type Column } from "@/components/tables/data-table";
import { SeverityBadge } from "@/components/common/badges";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Shield, Plus, Pencil, Bell, Activity, Volume2, AlertOctagon, Clock, Download,
} from "lucide-react";
import { alertRules, services } from "@/lib/data";
import { toast } from "sonner";
import type { Severity } from "@/lib/types";

export default function AlertRulesPage() {
  const [rules, setRules] = React.useState(alertRules);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [form, setForm] = React.useState({ name: "", description: "", metric: "", condition: ">", threshold: "0", window: "5m", severity: "medium" as Severity });

  function toggle(id: string) {
    setRules((rs) => rs.map((r) => r.id === id ? { ...r, enabled: !r.enabled } : r));
    const r = rules.find((x) => x.id === id);
    toast.success(`${r?.name} ${r?.enabled ? "disabled" : "enabled"}`);
  }

  function openEdit(id: string) {
    const r = rules.find((x) => x.id === id);
    if (!r) return;
    setEditingId(id);
    setForm({ name: r.name, description: r.description, metric: r.metric, condition: r.condition, threshold: String(r.threshold), window: r.window, severity: r.severity });
    setDialogOpen(true);
  }
  function openCreate() {
    setEditingId(null);
    setForm({ name: "", description: "", metric: "", condition: ">", threshold: "0", window: "5m", severity: "medium" });
    setDialogOpen(true);
  }
  function save() {
    if (!form.name.trim()) { toast.error("Rule name is required"); return; }
    if (editingId) {
      toast.success("Alert rule updated");
    } else {
      toast.success("Alert rule created");
    }
    setDialogOpen(false);
  }

  const enabledCount = rules.filter((r) => r.enabled).length;
  const avgNoise = Math.round(rules.reduce((s, r) => s + r.noiseScore, 0) / rules.length);
  const triggered7d = rules.reduce((s, r) => s + r.triggerCount7d, 0);

  const cols: Column<typeof rules[number]>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => <code className="text-[11px] font-mono text-muted-foreground">{r.ref}</code>,
    },
    {
      key: "name",
      header: "Name",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="min-w-0 max-w-xs">
          <p className="text-xs font-medium truncate">{r.name}</p>
          <p className="text-[10px] text-muted-foreground truncate">{r.description}</p>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      filterable: true,
      filterOptions: services.map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.serviceId === v,
      hideOnMobile: true,
      cell: (r) => {
        const s = services.find((x) => x.id === r.serviceId);
        return <span className="text-xs">{s?.name ?? r.serviceId}</span>;
      },
    },
    {
      key: "metric",
      header: "Metric",
      hideOnMobile: true,
      cell: (r) => <code className="text-[11px] font-mono text-muted-foreground">{r.metric}</code>,
    },
    {
      key: "condition",
      header: "Condition",
      hideOnMobile: true,
      cell: (r) => (
        <code className="text-[11px] font-mono">
          {r.condition} {r.threshold} <span className="text-muted-foreground">({r.window})</span>
        </code>
      ),
    },
    {
      key: "severity",
      header: "Severity",
      filterable: true,
      filterOptions: [
        { label: "Critical", value: "critical" },
        { label: "High", value: "high" },
        { label: "Medium", value: "medium" },
        { label: "Low", value: "low" },
      ],
      filterFn: (r, v) => r.severity === v,
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "lastTriggeredAt",
      header: "Last Triggered",
      align: "right",
      sortable: true,
      sortValue: (r) => r.lastTriggeredAt ?? "",
      hideOnMobile: true,
      cell: (r) => (
        <span className="text-xs tabular-nums text-muted-foreground">
          {r.lastTriggeredAt ? new Date(r.lastTriggeredAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "Never"}
        </span>
      ),
    },
    {
      key: "triggerCount7d",
      header: "7d Count",
      align: "right",
      sortable: true,
      sortValue: (r) => r.triggerCount7d,
      cell: (r) => <span className={`text-xs tabular-nums font-mono ${r.triggerCount7d > 3 ? "text-warning-foreground" : "text-foreground"}`}>{r.triggerCount7d}</span>,
    },
    {
      key: "noiseScore",
      header: "Noise Score",
      align: "right",
      sortable: true,
      sortValue: (r) => r.noiseScore,
      cell: (r) => {
        const cls = r.noiseScore > 50 ? "text-destructive" : r.noiseScore > 20 ? "text-warning-foreground" : "text-muted-foreground";
        return (
          <div className="flex items-center gap-2 justify-end">
            <div className="w-10 h-1.5 rounded-full bg-muted overflow-hidden">
              <div className={`h-full ${r.noiseScore > 50 ? "bg-destructive" : r.noiseScore > 20 ? "bg-warning" : "bg-success"}`} style={{ width: `${Math.min(100, r.noiseScore)}%` }} />
            </div>
            <span className={`text-[10px] font-mono tabular-nums w-6 text-right ${cls}`}>{r.noiseScore}</span>
          </div>
        );
      },
    },
    {
      key: "enabled",
      header: "Enabled",
      align: "center",
      cell: (r) => <Switch checked={r.enabled} onCheckedChange={() => toggle(r.id)} aria-label={`Toggle ${r.name}`} />,
    },
    {
      key: "edit",
      header: "",
      align: "right",
      cell: (r) => (
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); openEdit(r.id); }}>
          <Pencil className="w-3 h-3" />
        </Button>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Alert Rules"
        description="Metric-based alert definitions. Each rule has a metric, condition, threshold, and evaluation window."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Alerts", href: "/alerts" }, { label: "Rules" }]}
        icon={<Shield className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Rules exported")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={openCreate}>
              <Plus className="w-3.5 h-3.5" /> <span className="hidden md:inline">New Rule</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Rules" value={rules.length} hint="configured" icon={<Shield className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Enabled" value={enabledCount} hint={`${rules.length - enabledCount} disabled`} icon={<Bell className="w-4 h-4" />} accent="success" />
        <KpiCard label="Avg Noise Score" value={avgNoise} hint="across all rules" icon={<Volume2 className="w-4 h-4" />} accent={avgNoise > 30 ? "warning" : "muted"} />
        <KpiCard label="Triggered (7d)" value={triggered7d} hint="total firings" icon={<Activity className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Alert Rules" description="Toggle to enable/disable. Click edit to modify threshold or condition." />
        <div className="mt-4">
          <DataTable
            columns={cols}
            data={rules}
            rowKey={(r) => r.id}
            searchKeys={["name", "description", "metric", "ref"]}
            searchPlaceholder="Search rules..."
            pageSize={10}
            initialSort={{ key: "triggerCount7d", dir: "desc" }}
          />
        </div>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Alert Rule" : "New Alert Rule"}</DialogTitle>
            <DialogDescription>Configure when this alert fires.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2 max-h-[60vh] overflow-y-auto">
            <div className="space-y-1.5">
              <Label htmlFor="rname">Rule Name</Label>
              <Input id="rname" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="e.g., Checkout 5xx > 1%" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rdesc">Description</Label>
              <Textarea id="rdesc" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} rows={2} placeholder="What this alert means" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="rmetric">Metric</Label>
                <Input id="rmetric" value={form.metric} onChange={(e) => setForm((f) => ({ ...f, metric: e.target.value }))} placeholder="http_5xx_rate" className="font-mono text-xs" />
              </div>
              <div className="space-y-1.5">
                <Label>Service</Label>
                <Select defaultValue="s1">
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {services.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label>Condition</Label>
                <Select value={form.condition} onValueChange={(v) => setForm((f) => ({ ...f, condition: v }))}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value=">">&gt;</SelectItem>
                    <SelectItem value="<">&lt;</SelectItem>
                    <SelectItem value=">=">&gt;=</SelectItem>
                    <SelectItem value="<=">&lt;=</SelectItem>
                    <SelectItem value="==">==</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="rthresh">Threshold</Label>
                <Input id="rthresh" value={form.threshold} onChange={(e) => setForm((f) => ({ ...f, threshold: e.target.value }))} className="font-mono text-xs" />
              </div>
              <div className="space-y-1.5">
                <Label>Window</Label>
                <Select value={form.window} onValueChange={(v) => setForm((f) => ({ ...f, window: v }))}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1m">1m</SelectItem>
                    <SelectItem value="2m">2m</SelectItem>
                    <SelectItem value="5m">5m</SelectItem>
                    <SelectItem value="10m">10m</SelectItem>
                    <SelectItem value="30m">30m</SelectItem>
                    <SelectItem value="1h">1h</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Severity</Label>
              <Select value={form.severity} onValueChange={(v) => setForm((f) => ({ ...f, severity: v as Severity }))}>
                <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={save}>{editingId ? "Save Changes" : "Create Rule"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
