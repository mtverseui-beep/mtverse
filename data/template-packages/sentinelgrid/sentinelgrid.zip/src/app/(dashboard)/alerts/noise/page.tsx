"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LineChartCard, HorizontalBarChart } from "@/components/charts";
import {
  Volume2, Bell, CheckCircle2, AlertTriangle, TrendingDown, Lightbulb, Download,
} from "lucide-react";
import { alertRules, services } from "@/lib/data";
import { toast } from "sonner";

interface NoisyRule {
  id: string;
  ref: string;
  name: string;
  service: string;
  noiseScore: number;
  triggerCount: number;
  falsePositivePct: number;
  autoResolved: number;
}

const noisyRules: NoisyRule[] = alertRules
  .filter((r) => r.triggerCount7d > 0 || r.noiseScore > 0)
  .map((r) => ({
    id: r.id,
    ref: r.ref,
    name: r.name,
    service: services.find((s) => s.id === r.serviceId)?.name ?? r.serviceId,
    noiseScore: r.noiseScore,
    triggerCount: r.triggerCount7d,
    falsePositivePct: Math.min(95, Math.round(r.noiseScore * 0.8 + 5)),
    autoResolved: Math.round(r.triggerCount7d * (r.noiseScore / 100) * 0.7),
  }))
  .sort((a, b) => b.noiseScore - a.noiseScore);

export default function NoisePage() {
  // Alerts per day (14d)
  const alertsPerDay = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - i));
    return {
      date: d.toLocaleDateString([], { month: "numeric", day: "numeric" }),
      value: Math.round(20 + Math.sin(i * 0.5) * 8 + Math.random() * 6),
    };
  });

  // Noise score by service
  const noiseByService = services.slice(0, 8).map((s, i) => ({
    name: s.name.split("-")[0],
    value: Math.max(0, Math.round(40 - i * 4 + Math.random() * 20)),
  })).sort((a, b) => b.value - a.value).slice(0, 6);

  const totalAlerts = alertsPerDay.reduce((s, d) => s + d.value, 0);
  const autoResolved = Math.round(totalAlerts * 0.42);
  const falsePositiveRate = Math.round(noisyRules.reduce((s, r) => s + r.falsePositivePct, 0) / noisyRules.length);
  const avgNoise = Math.round(noisyRules.reduce((s, r) => s + r.noiseScore, 0) / noisyRules.length);

  const cols: Column<NoisyRule>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => <code className="text-[11px] font-mono text-muted-foreground">{r.ref}</code>,
    },
    {
      key: "name",
      header: "Rule",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="min-w-0 max-w-xs">
          <p className="text-xs font-medium truncate">{r.name}</p>
          <p className="text-[10px] text-muted-foreground">{r.service}</p>
        </div>
      ),
    },
    {
      key: "noiseScore",
      header: "Noise Score",
      align: "right",
      sortable: true,
      sortValue: (r) => r.noiseScore,
      cell: (r) => {
        const cls = r.noiseScore > 50 ? "text-destructive" : r.noiseScore > 20 ? "text-warning-foreground" : "text-muted-foreground";
        return (
          <div className="flex items-center gap-2 justify-end">
            <div className="w-12 h-1.5 rounded-full bg-muted overflow-hidden">
              <div className={`h-full ${r.noiseScore > 50 ? "bg-destructive" : r.noiseScore > 20 ? "bg-warning" : "bg-success"}`} style={{ width: `${Math.min(100, r.noiseScore)}%` }} />
            </div>
            <span className={`text-xs font-mono tabular-nums w-6 text-right ${cls}`}>{r.noiseScore}</span>
          </div>
        );
      },
    },
    {
      key: "triggerCount",
      header: "Triggers (7d)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.triggerCount,
      cell: (r) => <span className="text-xs tabular-nums font-mono">{r.triggerCount}</span>,
    },
    {
      key: "falsePositivePct",
      header: "False Positive %",
      align: "right",
      sortable: true,
      sortValue: (r) => r.falsePositivePct,
      hideOnMobile: true,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-mono ${r.falsePositivePct > 60 ? "text-destructive" : r.falsePositivePct > 30 ? "text-warning-foreground" : "text-muted-foreground"}`}>
          {r.falsePositivePct}%
        </span>
      ),
    },
    {
      key: "autoResolved",
      header: "Auto-Resolved",
      align: "right",
      sortable: true,
      sortValue: (r) => r.autoResolved,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums font-mono text-muted-foreground">{r.autoResolved}</span>,
    },
    {
      key: "action",
      header: "",
      align: "right",
      cell: (r) => (
        <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => toast.success(`Tuning suggestion prepared for ${r.name}`, { description: "Review in Alert Tuning page" })}>
          <Lightbulb className="w-3 h-3" /> Tune
        </Button>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Alert Noise Analytics"
        description="Identify noisy rules, false-positive rates, and tuning opportunities to reduce alert fatigue."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Alerts", href: "/alerts" }, { label: "Noise" }]}
        icon={<Volume2 className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Noise report exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Alerts (7d)" value={totalAlerts} hint="across all rules" icon={<Bell className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Auto-Resolved" value={autoResolved} hint="closed without ack" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="False Positive Rate" value={falsePositiveRate} unit="%" delta={-6} deltaLabel="improving" icon={<AlertTriangle className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Avg Noise Score" value={avgNoise} hint="across active rules" icon={<TrendingDown className="w-4 h-4" />} accent={avgNoise > 30 ? "destructive" : "muted"} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <LineChartCard
          data={alertsPerDay}
          dataKey="value"
          color={0}
          title="Alerts per Day (14d)"
          description="Daily alert volume — spikes indicate noisy periods"
          height={260}
        />
        <HorizontalBarChart
          data={noiseByService}
          title="Noise Score by Service"
          description="Top services contributing to alert noise"
          color={2}
        />
        <KpiCard
          label="Noise Reduction Potential"
          value={`${Math.round((noisyRules.filter((r) => r.noiseScore > 30).length / noisyRules.length) * 100)}%`}
          hint={`${noisyRules.filter((r) => r.noiseScore > 30).length} rules need tuning`}
          icon={<Lightbulb className="w-4 h-4" />}
          accent="warning"
        />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Top Noisy Rules" description="Rules with high noise scores — candidates for tuning or suppression" />
        <div className="mt-4">
          <DataTable
            columns={cols}
            data={noisyRules}
            rowKey={(r) => r.id}
            searchKeys={["name", "ref", "service"]}
            searchPlaceholder="Search noisy rules..."
            pageSize={10}
            initialSort={{ key: "noiseScore", dir: "desc" }}
          />
        </div>
      </Card>

      {/* Noise reduction opportunities */}
      <Card className="p-5 space-y-3">
        <SectionHeading title="Noise Reduction Opportunities" description="High-impact recommendations" action={<Lightbulb className="w-4 h-4 text-warning" />} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { title: "Tune ALERT-009 threshold", desc: "Host CPU > 90% triggered 12 times in 7d with 87% false-positive rate. Suggest: increase window from 10m to 30m or threshold to 95%.", impact: "Reduces 12 alerts/week" },
            { title: "Suppress ALERT-010 during backup window", desc: "Disk usage spikes during nightly backup. Suggest: scheduled suppression 02:00-04:00 UTC daily.", impact: "Reduces 4 alerts/week" },
            { title: "Increase ALERT-007 window", desc: "API Gateway p99 latency spikes are transient. Suggest: increase window from 5m to 10m to filter noise.", impact: "Reduces 3 alerts/week" },
            { title: "Aggregate ALERT-003 notifications", desc: "Auth 401 rate triggers frequently. Suggest: route to Slack digest instead of paging.", impact: "Reduces 8 pages/week" },
          ].map((o, i) => (
            <div key={i} className="rounded-lg border border-border p-4 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm font-semibold">{o.title}</p>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-success/15 text-success border border-success/30 font-medium whitespace-nowrap">{o.impact}</span>
              </div>
              <p className="text-[11px] text-muted-foreground">{o.desc}</p>
              <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => toast.success("Opportunity queued for review")}>
                <Lightbulb className="w-3 h-3" /> Apply
              </Button>
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
