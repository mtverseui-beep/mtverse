"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  GitBranch, Plus, Pencil, ArrowRight, Filter, Zap, Bell, Webhook, Slack,
  Share2, Trash2,
} from "lucide-react";
import { services, escalationPolicies } from "@/lib/data";
import { SeverityBadge } from "@/components/common/badges";
import { toast } from "sonner";
import type { Severity } from "@/lib/types";

interface RoutingRule {
  id: string;
  name: string;
  conditions: { field: "service" | "severity" | "tag" | "environment"; op: "is" | "is_not" | "in" | "contains"; value: string }[];
  targetId: string;
  targetType: "policy" | "channel";
  enabled: boolean;
  priority: number;
  matched24h: number;
}

const initialRules: RoutingRule[] = [
  {
    id: "rr1",
    name: "Critical production → Platform escalation",
    conditions: [
      { field: "severity", op: "is", value: "critical" },
      { field: "environment", op: "is", value: "production" },
    ],
    targetId: "ep1",
    targetType: "policy",
    enabled: true,
    priority: 1,
    matched24h: 2,
  },
  {
    id: "rr2",
    name: "Checkout alerts → Payments team",
    conditions: [
      { field: "service", op: "is", value: "checkout-api" },
      { field: "severity", op: "in", value: "critical,high" },
    ],
    targetId: "ep1",
    targetType: "policy",
    enabled: true,
    priority: 2,
    matched24h: 4,
  },
  {
    id: "rr3",
    name: "Security tags → Security escalation",
    conditions: [
      { field: "tag", op: "contains", value: "security" },
    ],
    targetId: "ep3",
    targetType: "policy",
    enabled: true,
    priority: 3,
    matched24h: 0,
  },
  {
    id: "rr4",
    name: "Low severity → Slack only",
    conditions: [
      { field: "severity", op: "is", value: "low" },
    ],
    targetId: "#alerts-low",
    targetType: "channel",
    enabled: true,
    priority: 4,
    matched24h: 18,
  },
  {
    id: "rr5",
    name: "DB alerts → Reliability policy",
    conditions: [
      { field: "service", op: "in", value: "postgres-primary,redis-cluster,kafka-bus" },
    ],
    targetId: "ep2",
    targetType: "policy",
    enabled: true,
    priority: 5,
    matched24h: 1,
  },
  {
    id: "rr6",
    name: "Staging noise → mute",
    conditions: [
      { field: "environment", op: "is", value: "staging" },
    ],
    targetId: "#alerts-staging",
    targetType: "channel",
    enabled: false,
    priority: 6,
    matched24h: 0,
  },
];

export default function AlertRoutingPage() {
  const [rules, setRules] = React.useState(initialRules);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);

  function toggle(id: string) {
    setRules((rs) => rs.map((r) => r.id === id ? { ...r, enabled: !r.enabled } : r));
    const r = rules.find((x) => x.id === id);
    toast.success(`${r?.name} ${r?.enabled ? "disabled" : "enabled"}`);
  }
  function openEdit(id: string) {
    setEditingId(id);
    setDialogOpen(true);
  }
  function openCreate() {
    setEditingId(null);
    setDialogOpen(true);
  }
  function remove(id: string) {
    setRules((rs) => rs.filter((r) => r.id !== id));
    toast.success("Routing rule deleted");
  }

  const enabledCount = rules.filter((r) => r.enabled).length;
  const matched24h = rules.reduce((s, r) => s + r.matched24h, 0);

  return (
    <PageContainer>
      <PageHeader
        title="Alert Routing"
        description="Route alerts to escalation policies or notification channels based on conditions. Rules are evaluated in priority order."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Alerts", href: "/alerts" }, { label: "Routing" }]}
        icon={<GitBranch className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={openCreate}>
            <Plus className="w-3.5 h-3.5" /> <span className="hidden md:inline">New Rule</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Routing Rules" value={rules.length} hint={`${enabledCount} active`} icon={<GitBranch className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Escalation Policies" value={rules.filter((r) => r.targetType === "policy").length} hint="route to people" icon={<Zap className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Channels" value={rules.filter((r) => r.targetType === "channel").length} hint="Slack, webhook, etc." icon={<Slack className="w-4 h-4" />} accent="info" />
        <KpiCard label="Matched (24h)" value={matched24h} hint="alerts routed" icon={<Bell className="w-4 h-4" />} accent="success" />
      </div>

      {/* Visual flow */}
      <Card className="p-5">
        <SectionHeading title="Routing Flow" description="From alert trigger to destination" />
        <div className="mt-4 grid grid-cols-1 md:grid-cols-5 gap-2 items-center">
          <div className="rounded-lg border border-border p-3 text-center">
            <Bell className="w-4 h-4 mx-auto mb-1 text-primary" />
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Alert Fires</p>
          </div>
          <ArrowRight className="hidden md:block w-4 h-4 mx-auto text-muted-foreground" />
          <div className="rounded-lg border border-border p-3 text-center">
            <Filter className="w-4 h-4 mx-auto mb-1 text-info-foreground" />
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Rule Match</p>
          </div>
          <ArrowRight className="hidden md:block w-4 h-4 mx-auto text-muted-foreground" />
          <div className="rounded-lg border border-border p-3 text-center">
            <Share2 className="w-4 h-4 mx-auto mb-1 text-accent" />
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Routed</p>
          </div>
        </div>
      </Card>

      {/* Rules list */}
      <Card className="p-5 space-y-3">
        <SectionHeading title="Routing Rules" description="Evaluated in priority order. First match wins." />
        {rules.sort((a, b) => a.priority - b.priority).map((r) => {
          const policy = escalationPolicies.find((p) => p.id === r.targetId);
          return (
            <div key={r.id} className={`rounded-lg border p-4 ${r.enabled ? "border-border" : "border-border bg-muted/30 opacity-70"}`}>
              <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <span className="shrink-0 w-6 h-6 rounded-md bg-muted text-muted-foreground text-[10px] font-mono font-semibold flex items-center justify-center">
                    {r.priority}
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{r.name}</p>
                    <p className="text-[10px] text-muted-foreground">{r.matched24h} alerts matched in last 24h</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openEdit(r.id)} aria-label="Edit">
                    <Pencil className="w-3 h-3" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => remove(r.id)} aria-label="Delete">
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>

              {/* Visual flow: conditions → target */}
              <div className="flex items-center gap-2 flex-wrap text-xs">
                <div className="flex items-center gap-1 flex-wrap">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">IF</span>
                  {r.conditions.map((c, i) => (
                    <React.Fragment key={i}>
                      {i > 0 && <span className="text-[10px] text-muted-foreground font-medium">AND</span>}
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-muted border border-border font-mono text-[10px]">
                        <span className="text-muted-foreground">{c.field}</span>
                        <span className="text-foreground font-medium">{c.op}</span>
                        <span className="text-primary">{c.value}</span>
                      </span>
                    </React.Fragment>
                  ))}
                </div>
                <ArrowRight className="w-3 h-3 text-muted-foreground" />
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md border font-medium text-[10px]"
                  style={{
                    background: r.targetType === "policy" ? "rgba(252, 211, 77, 0.1)" : "rgba(34, 211, 238, 0.1)",
                    borderColor: r.targetType === "policy" ? "rgba(252, 211, 77, 0.3)" : "rgba(34, 211, 238, 0.3)",
                    color: r.targetType === "policy" ? "rgb(252, 211, 77)" : "rgb(34, 211, 238)",
                  }}
                >
                  {r.targetType === "policy" ? <Zap className="w-3 h-3" /> : <Slack className="w-3 h-3" />}
                  {policy?.name ?? r.targetId}
                </span>
                <button
                  onClick={() => toggle(r.id)}
                  className={`ml-auto text-[10px] px-2 py-0.5 rounded-md font-medium uppercase tracking-wider ${
                    r.enabled ? "bg-success/15 text-success border border-success/30" : "bg-muted text-muted-foreground border border-border"
                  }`}
                >
                  {r.enabled ? "Enabled" : "Disabled"}
                </button>
              </div>
            </div>
          );
        })}
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Routing Rule" : "New Routing Rule"}</DialogTitle>
            <DialogDescription>Configure conditions and target for this routing rule.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="rname">Rule Name</Label>
              <Input id="rname" placeholder="e.g., Critical production → Platform" />
            </div>
            <div className="space-y-1.5">
              <Label>Field</Label>
              <Select defaultValue="service">
                <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="service">Service</SelectItem>
                  <SelectItem value="severity">Severity</SelectItem>
                  <SelectItem value="tag">Tag</SelectItem>
                  <SelectItem value="environment">Environment</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Operator</Label>
                <Select defaultValue="is">
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="is">is</SelectItem>
                    <SelectItem value="is_not">is not</SelectItem>
                    <SelectItem value="in">in</SelectItem>
                    <SelectItem value="contains">contains</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="rval">Value</Label>
                <Input id="rval" placeholder="checkout-api" className="font-mono text-xs" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Target</Label>
              <Select defaultValue="ep1">
                <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {escalationPolicies.map((p) => <SelectItem key={p.id} value={p.id}>{p.name} (policy)</SelectItem>)}
                  <SelectItem value="#alerts-low">#alerts-low (channel)</SelectItem>
                  <SelectItem value="#alerts-staging">#alerts-staging (channel)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={() => { setDialogOpen(false); toast.success(editingId ? "Routing rule updated" : "Routing rule created"); }}>
              {editingId ? "Save Changes" : "Create Rule"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
