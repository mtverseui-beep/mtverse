"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Ban, Plus, Clock, Filter, History, ShieldOff, AlertCircle, Trash2,
} from "lucide-react";
import { alertRules, services, people } from "@/lib/data";
import { toast } from "sonner";

interface Suppression {
  id: string;
  scope: "service" | "alert" | "tag";
  scopeValue: string;
  reason: string;
  durationLabel: string;
  durationMinutes: number;
  createdById: string;
  createdAt: string;
  expiresAt: string;
  active: boolean;
}

const initialSuppressions: Suppression[] = [
  { id: "sup1", scope: "service", scopeValue: "staging-cluster", reason: "Planned maintenance window for staging environment upgrade.", durationLabel: "4 hours", durationMinutes: 240, createdById: "u2", createdAt: "2026-07-02T03:00:00Z", expiresAt: "2026-07-02T07:00:00Z", active: true },
  { id: "sup2", scope: "alert", scopeValue: "ALERT-009", reason: "Host CPU alert known noisy during nightly backup window.", durationLabel: "8 hours", durationMinutes: 480, createdById: "u3", createdAt: "2026-07-01T22:00:00Z", expiresAt: "2026-07-02T06:00:00Z", active: true },
  { id: "sup3", scope: "tag", scopeValue: "auto-scaling", reason: "Auto-scaling events during deploy window are expected.", durationLabel: "30 minutes", durationMinutes: 30, createdById: "u6", createdAt: "2026-07-01T18:00:00Z", expiresAt: "2026-07-01T18:30:00Z", active: false },
  { id: "sup4", scope: "alert", scopeValue: "ALERT-010", reason: "Disk usage threshold being recalibrated after capacity expansion.", durationLabel: "1 hour", durationMinutes: 60, createdById: "u15", createdAt: "2026-07-02T02:00:00Z", expiresAt: "2026-07-02T03:00:00Z", active: true },
];

interface HistoryEntry {
  id: string;
  scope: string;
  scopeValue: string;
  reason: string;
  endedAt: string;
  endedById: string;
  alertsSuppressed: number;
}

const history: HistoryEntry[] = [
  { id: "h1", scope: "alert", scopeValue: "ALERT-007", reason: "API Gateway p99 latency — false positive during deploy.", endedAt: "2026-07-01T20:18:00Z", endedById: "u4", alertsSuppressed: 3 },
  { id: "h2", scope: "service", scopeValue: "billing-service", reason: "Billing queue depth expected during month-end close.", endedAt: "2026-06-30T20:00:00Z", endedById: "u15", alertsSuppressed: 12 },
  { id: "h3", scope: "tag", scopeValue: "deploy-rollout", reason: "Rollout-induced errors during canary stage.", endedAt: "2026-06-30T14:38:00Z", endedById: "u2", alertsSuppressed: 8 },
  { id: "h4", scope: "alert", scopeValue: "ALERT-002", reason: "Invoice queue depth — resolved by worker scaling.", endedAt: "2026-06-29T03:00:00Z", endedById: "u15", alertsSuppressed: 1 },
];

export default function SuppressionPage() {
  const [suppressions, setSuppressions] = React.useState(initialSuppressions);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [form, setForm] = React.useState({
    scope: "service" as Suppression["scope"],
    scopeValue: "",
    durationMinutes: "60",
    reason: "",
  });

  function create() {
    if (!form.scopeValue.trim()) {
      toast.error("Scope value is required");
      return;
    }
    const dur = parseInt(form.durationMinutes, 10) || 60;
    const now = new Date();
    const exp = new Date(now.getTime() + dur * 60000);
    const newSup: Suppression = {
      id: `sup${suppressions.length + 1}`,
      scope: form.scope,
      scopeValue: form.scopeValue,
      reason: form.reason || "No reason provided",
      durationLabel: dur >= 1440 ? `${Math.round(dur / 1440)} day(s)` : dur >= 60 ? `${Math.round(dur / 60)} hour(s)` : `${dur} minute(s)`,
      durationMinutes: dur,
      createdById: "u2",
      createdAt: now.toISOString(),
      expiresAt: exp.toISOString(),
      active: true,
    };
    setSuppressions((s) => [newSup, ...s]);
    setDialogOpen(false);
    setForm({ scope: "service", scopeValue: "", durationMinutes: "60", reason: "" });
    toast.success("Suppression created", { description: `Active for ${newSup.durationLabel}.` });
  }

  function end(id: string) {
    setSuppressions((s) => s.map((x) => x.id === id ? { ...x, active: false } : x));
    toast.success("Suppression ended");
  }

  const active = suppressions.filter((s) => s.active);
  const alertsSuppressed = history.reduce((s, h) => s + h.alertsSuppressed, 0);

  return (
    <PageContainer>
      <PageHeader
        title="Alert Suppression"
        description="Temporarily mute alerts during maintenance windows, known-noisy periods, or false-positive rule tuning."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Alerts", href: "/alerts" }, { label: "Suppression" }]}
        icon={<Ban className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setDialogOpen(true)}>
            <Plus className="w-3.5 h-3.5" /> <span className="hidden md:inline">New Suppression</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Active Suppressions" value={active.length} hint="currently muting" icon={<Ban className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Avg Duration" value={active.length ? Math.round(active.reduce((s, x) => s + x.durationMinutes, 0) / active.length) : 0} unit="min" hint="remaining window" icon={<Clock className="w-4 h-4" />} accent="info" />
        <KpiCard label="Suppressed (7d)" value={alertsSuppressed} hint="alerts muted" icon={<ShieldOff className="w-4 h-4" />} accent="muted" />
        <KpiCard label="Scopes" value={new Set(suppressions.map((s) => s.scope)).size} hint="distinct types" icon={<Filter className="w-4 h-4" />} accent="primary" />
      </div>

      {/* Active suppressions */}
      <Card className="p-5 space-y-3">
        <SectionHeading title="Active Suppressions" description="Currently muting alert notifications" />
        {active.length === 0 ? (
          <div className="text-center py-8 text-sm text-muted-foreground">
            <Ban className="w-5 h-5 mx-auto mb-2 opacity-50" />
            No active suppressions.
          </div>
        ) : (
          <div className="space-y-3">
            {active.map((s) => {
              const creator = people.find((p) => p.id === s.createdById);
              const totalMs = new Date(s.expiresAt).getTime() - new Date(s.createdAt).getTime();
              const elapsedMs = Date.now() - new Date(s.createdAt).getTime();
              const pct = Math.min(100, Math.max(0, (elapsedMs / totalMs) * 100));
              const remainingMs = new Date(s.expiresAt).getTime() - Date.now();
              const remainingMin = Math.max(0, Math.round(remainingMs / 60000));
              return (
                <div key={s.id} className="rounded-lg border border-warning/30 bg-warning/5 p-4 space-y-3">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <div className="w-9 h-9 rounded-lg bg-warning/15 border border-warning/30 flex items-center justify-center text-warning-foreground shrink-0">
                        <Ban className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">{s.scope}</span>
                          <code className="text-xs font-mono">{s.scopeValue}</code>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-warning/15 text-warning-foreground border border-warning/30 font-medium uppercase">Active</span>
                        </div>
                        <p className="text-xs mt-1">{s.reason}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => end(s.id)}>
                      <Trash2 className="w-3 h-3" /> End Now
                    </Button>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                      <span>Started {new Date(s.createdAt).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                      <span>{remainingMin > 0 ? `${remainingMin}m remaining` : "expiring"}</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className="h-full bg-warning transition-all" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                  {creator && (
                    <div className="flex items-center gap-2 pt-2 border-t border-warning/20 text-[11px] text-muted-foreground">
                      <Avatar className="w-4 h-4">
                        <AvatarImage src={creator.avatarUrl} alt={creator.name} />
                        <AvatarFallback className="text-[7px]">{creator.name.split(" ").map(x => x[0]).join("").slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      Created by {creator.name} · Duration {s.durationLabel}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Create form */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>New Suppression</DialogTitle>
            <DialogDescription>Suppress alerts matching a scope for a duration.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Scope</Label>
                <Select value={form.scope} onValueChange={(v) => setForm((f) => ({ ...f, scope: v as Suppression["scope"] }))}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="service">Service</SelectItem>
                    <SelectItem value="alert">Alert Rule</SelectItem>
                    <SelectItem value="tag">Tag</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sval">Scope Value</Label>
                <Input id="sval" value={form.scopeValue} onChange={(e) => setForm((f) => ({ ...f, scopeValue: e.target.value }))} placeholder={form.scope === "alert" ? "ALERT-001" : "service-name or tag"} className="font-mono text-xs" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sdur">Duration (minutes)</Label>
              <Input id="sdur" type="number" min="5" value={form.durationMinutes} onChange={(e) => setForm((f) => ({ ...f, durationMinutes: e.target.value }))} />
              <div className="flex gap-1.5">
                {[
                  { label: "30m", val: "30" },
                  { label: "1h", val: "60" },
                  { label: "4h", val: "240" },
                  { label: "8h", val: "480" },
                  { label: "24h", val: "1440" },
                ].map((opt) => (
                  <button
                    key={opt.val}
                    onClick={() => setForm((f) => ({ ...f, durationMinutes: opt.val }))}
                    className={`text-[11px] px-2 py-1 rounded border ${form.durationMinutes === opt.val ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-muted"}`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sreason">Reason</Label>
              <Textarea id="sreason" value={form.reason} onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))} rows={3} placeholder="Why are you suppressing these alerts?" />
            </div>
            <div className="flex items-start gap-2 p-2 rounded-md bg-warning/5 border border-warning/20">
              <AlertCircle className="w-3.5 h-3.5 text-warning mt-0.5 shrink-0" />
              <p className="text-[11px] text-muted-foreground">Critical alerts will still page on-call engineers during suppression.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={create} className="gap-1.5">
              <Ban className="w-3.5 h-3.5" /> Suppress
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* History */}
      <Card className="p-5 space-y-3">
        <SectionHeading title="Suppression History" description="Recently ended suppressions and their impact" action={<History className="w-4 h-4 text-muted-foreground" />} />
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border text-[10px] uppercase tracking-wider text-muted-foreground">
                <th className="text-left py-2 pr-3 font-medium">Scope</th>
                <th className="text-left py-2 pr-3 font-medium">Reason</th>
                <th className="text-left py-2 pr-3 font-medium hidden md:table-cell">Ended By</th>
                <th className="text-right py-2 pr-3 font-medium">Ended</th>
                <th className="text-right py-2 font-medium">Alerts Muted</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => {
                const ender = people.find((p) => p.id === h.endedById);
                return (
                  <tr key={h.id} className="border-b border-border/60">
                    <td className="py-2 pr-3">
                      <span className="text-[10px] uppercase text-muted-foreground mr-1">{h.scope}</span>
                      <code className="font-mono">{h.scopeValue}</code>
                    </td>
                    <td className="py-2 pr-3 max-w-xs truncate text-muted-foreground">{h.reason}</td>
                    <td className="py-2 pr-3 hidden md:table-cell">
                      {ender && (
                        <span className="inline-flex items-center gap-1.5">
                          <Avatar className="w-4 h-4">
                            <AvatarImage src={ender.avatarUrl} alt={ender.name} />
                            <AvatarFallback className="text-[7px]">{ender.name.split(" ").map(x => x[0]).join("").slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          {ender.name.split(" ")[0]}
                        </span>
                      )}
                    </td>
                    <td className="py-2 pr-3 text-right tabular-nums text-muted-foreground">{new Date(h.endedAt).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</td>
                    <td className="py-2 text-right tabular-nums font-mono">{h.alertsSuppressed}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </PageContainer>
  );
}
