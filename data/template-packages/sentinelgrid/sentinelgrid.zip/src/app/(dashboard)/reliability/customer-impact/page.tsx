"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Users, AlertTriangle, Globe, TrendingDown, Download, Clock,
} from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useChartTheme, ChartTooltip } from "@/components/charts/chart-container";
import { incidents, services, timeSeries } from "@/lib/data";
import { SeverityBadge, IncidentStatusBadge } from "@/components/common/badges";

export default function CustomerImpactPage() {
  const t = useChartTheme();

  const impactedIncidents = incidents.filter((i) => i.impactedUsers > 0);
  const totalUserMinutes = impactedIncidents.reduce((s, i) => {
    const end = i.resolvedAt ? new Date(i.resolvedAt) : new Date(i.lastUpdateAt);
    const durMin = (end.getTime() - new Date(i.startedAt).getTime()) / 60000;
    return s + i.impactedUsers * durMin;
  }, 0);

  const avgImpact = impactedIncidents.length > 0
    ? Math.round(totalUserMinutes / impactedIncidents.length)
    : 0;

  const topRegion = impactedIncidents
    .flatMap((i) => i.impactedRegions.map((r) => ({ region: r, users: i.impactedUsers })))
    .reduce<Record<string, number>>((acc, x) => {
      acc[x.region] = (acc[x.region] ?? 0) + x.users;
      return acc;
    }, {});
  const topRegionEntry = Object.entries(topRegion).sort((a, b) => b[1] - a[1])[0];

  // 30-day impact bar chart
  const dailyImpact = timeSeries(3, 30, 5000, 8000).map((d, i) => ({
    date: d.date,
    userMinutes: Math.round(d.value * (i % 7 === 0 ? 2 : 1)),
  }));

  // Impact by service donut
  const impactByService = impactedIncidents.flatMap((i) =>
    i.serviceIds.map((sid) => {
      const svc = services.find((s) => s.id === sid);
      return { name: svc?.name ?? "Unknown", value: i.impactedUsers };
    })
  ).reduce<Record<string, number>>((acc, x) => {
    acc[x.name] = (acc[x.name] ?? 0) + x.value;
    return acc;
  }, {});
  const donutData = Object.entries(impactByService).map(([name, value]) => ({ name, value }));

  // Top 10 incidents by user-minutes
  const topIncidents = impactedIncidents
    .map((i) => {
      const end = i.resolvedAt ? new Date(i.resolvedAt) : new Date(i.lastUpdateAt);
      const durMin = (end.getTime() - new Date(i.startedAt).getTime()) / 60000;
      return { ...i, userMinutes: Math.round(i.impactedUsers * durMin), durationMin: Math.round(durMin) };
    })
    .sort((a, b) => b.userMinutes - a.userMinutes)
    .slice(0, 10);

  const columns: Column<typeof topIncidents[number]>[] = [
    {
      key: "ref",
      header: "Incident",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => (
        <Link href={`/incidents/${r.id}`} className="font-mono text-xs text-primary hover:underline">{r.ref}</Link>
      ),
    },
    {
      key: "title",
      header: "Title",
      cell: (r) => (
        <div className="min-w-0">
          <div className="text-sm font-medium truncate max-w-md">{r.title}</div>
          <div className="text-[10px] text-muted-foreground">{new Date(r.startedAt).toLocaleString()}</div>
        </div>
      ),
    },
    {
      key: "severity",
      header: "Severity",
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "impactedUsers",
      header: "Users",
      sortable: true,
      sortValue: (r) => r.impactedUsers,
      cell: (r) => <span className="font-mono text-xs tabular-nums">{r.impactedUsers.toLocaleString()}</span>,
      align: "right",
      hideOnMobile: true,
    },
    {
      key: "durationMin",
      header: "Duration",
      sortable: true,
      sortValue: (r) => r.durationMin,
      cell: (r) => <span className="font-mono text-xs tabular-nums">{r.durationMin}m</span>,
      align: "right",
      hideOnMobile: true,
    },
    {
      key: "userMinutes",
      header: "User-Minutes",
      sortable: true,
      sortValue: (r) => r.userMinutes,
      cell: (r) => <span className="font-mono text-xs font-semibold text-destructive tabular-nums">{r.userMinutes.toLocaleString()}</span>,
      align: "right",
    },
    {
      key: "regions",
      header: "Regions",
      cell: (r) => <span className="text-[11px] text-muted-foreground">{r.impactedRegions.join(", ")}</span>,
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => <IncidentStatusBadge status={r.status} />,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Customer Impact Reports"
        description="Quantified customer impact across incidents, services, and regions over the trailing 30 days."
        breadcrumbs={[{ label: "Reliability", href: "/reliability/slos" }, { label: "Customer Impact" }]}
        icon={<Users className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="User-Minutes (30d)"
          value={totalUserMinutes.toLocaleString()}
          hint="aggregate customer impact"
          icon={<Users className="w-4 h-4" />}
          accent="destructive"
          delta={-12}
          deltaLabel="vs prev period"
        />
        <KpiCard
          label="Impactful Incidents"
          value={impactedIncidents.length}
          hint={`of ${incidents.length} total`}
          icon={<AlertTriangle className="w-4 h-4" />}
          accent="warning"
        />
        <KpiCard
          label="Avg Impact / Incident"
          value={avgImpact.toLocaleString()}
          unit="user-min"
          hint="per incident"
          icon={<Clock className="w-4 h-4" />}
          accent="info"
        />
        <KpiCard
          label="Top Impacted Region"
          value={topRegionEntry?.[0] ?? "—"}
          hint={`${topRegionEntry?.[1].toLocaleString() ?? 0} users`}
          icon={<Globe className="w-4 h-4" />}
          accent="primary"
        />
      </div>

      {/* Impact per day bar + impact by service donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading
            title="Daily Customer Impact (30 days)"
            description="User-minutes affected per day"
            action={<span className="text-xs text-muted-foreground">peak {Math.max(...dailyImpact.map((d) => d.userMinutes)).toLocaleString()} user-min</span>}
          />
          <div className="h-[260px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyImpact} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
                <CartesianGrid stroke={t.grid} vertical={false} />
                <XAxis dataKey="date" stroke={t.axis} fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={48} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip content={<ChartTooltip suffix=" user-min" />} cursor={{ fill: t.isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.04)" }} />
                <Bar dataKey="userMinutes" radius={[4, 4, 0, 0]} name="User-Minutes">
                  {dailyImpact.map((d, i) => (
                    <Cell key={i} fill={d.userMinutes > 10000 ? t.palette[4] : d.userMinutes > 5000 ? t.palette[2] : t.palette[0]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5 space-y-4">
          <SectionHeading title="Impact by Service" description="User-minutes distribution" />
          <div className="h-[260px] relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={donutData} dataKey="value" nameKey="name" innerRadius="55%" outerRadius="85%" paddingAngle={2} stroke="none">
                  {donutData.map((d, i) => (
                    <Cell key={i} fill={t.palette[i % t.palette.length]} />
                  ))}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-2xl font-semibold tabular-nums">{donutData.length}</span>
              <span className="text-xs text-muted-foreground">services</span>
            </div>
          </div>
          <div className="space-y-1.5">
            {donutData.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="w-2 h-2 rounded-full" style={{ background: t.palette[i % t.palette.length] }} />
                  <span className="truncate">{d.name}</span>
                </div>
                <span className="font-mono tabular-nums">{d.value.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Top 10 impactful incidents */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Top 10 Most Impactful Incidents"
          description="Ranked by total user-minutes affected"
          action={<TrendingDown className="w-4 h-4 text-destructive" />}
        />
        <DataTable
          columns={columns}
          data={topIncidents}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.ref, (r) => r.title]}
          searchPlaceholder="Search incidents..."
          pageSize={10}
          onRowClick={(r) => { window.location.href = `/incidents/${r.id}`; }}
        />
      </Card>
    </PageContainer>
  );
}
