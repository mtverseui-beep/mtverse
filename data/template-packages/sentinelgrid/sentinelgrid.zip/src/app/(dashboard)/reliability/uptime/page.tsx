"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Activity, TrendingUp, TrendingDown, Calendar, Download, ChevronDown, ChevronRight,
} from "lucide-react";
import { services, uptimeForService } from "@/lib/data";
import { TierBadge, ServiceHealthBadge, StatusDot } from "@/components/common/badges";

interface ServiceUptime {
  service: typeof services[number];
  h24: number;
  d7: number;
  d30: number;
  d90: number;
  y1: number;
  daily: { date: string; uptime: number }[];
}

export default function UptimeReportsPage() {
  const [expanded, setExpanded] = React.useState<Set<string>>(new Set());

  const data: ServiceUptime[] = React.useMemo(() =>
    services.map((service) => {
      const records = uptimeForService(service.id, 90);
      const last24h = records.slice(-1);
      const last7d = records.slice(-7);
      const last30d = records.slice(-30);
      const last90d = records;
      const avg = (recs: typeof records) => recs.length > 0 ? recs.reduce((s, r) => s + r.uptime, 0) / recs.length : 100;
      // Synthetic 1y (slightly degraded)
      const y1 = avg(last90d) - 0.02;
      return {
        service,
        h24: avg(last24h),
        d7: avg(last7d),
        d30: avg(last30d),
        d90: avg(last90d),
        y1: Math.max(99.5, y1),
        daily: records.map((r) => ({ date: r.date, uptime: r.uptime })),
      };
    }),
  []);

  function status(uptime: number) {
    if (uptime >= 99.99) return { color: "text-success", bg: "bg-success" };
    if (uptime >= 99.9) return { color: "text-success", bg: "bg-success/70" };
    if (uptime >= 99) return { color: "text-warning-foreground", bg: "bg-warning" };
    return { color: "text-destructive", bg: "bg-destructive" };
  }

  function toggle(id: string) {
    setExpanded((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const avgUptime30d = data.reduce((s, d) => s + d.d30, 0) / data.length;
  const totalIncidents90d = data.reduce((s, d) => s + d.daily.filter((x) => x.uptime < 100).length, 0);
  const worstService = [...data].sort((a, b) => a.d30 - b.d30)[0];

  return (
    <PageContainer>
      <PageHeader
        title="Uptime Reports"
        description="Per-service uptime across 24h, 7d, 30d, 90d, and 1y windows with expandable daily breakdowns."
        breadcrumbs={[{ label: "Reliability", href: "/reliability/slos" }, { label: "Uptime Reports" }]}
        icon={<Activity className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Avg Uptime (30d)" value={`${avgUptime30d.toFixed(3)}%`} hint="across all services" icon={<TrendingUp className="w-4 h-4" />} accent={avgUptime30d >= 99.95 ? "success" : "warning"} />
        <KpiCard label="Services Tracked" value={services.length} hint="production tier" icon={<Activity className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Incidents (90d)" value={totalIncidents90d} hint="days with < 100% uptime" icon={<Calendar className="w-4 h-4" />} accent="info" />
        <KpiCard label="Worst Performer" value={worstService?.service.name ?? "—"} hint={`${worstService?.d30.toFixed(3)}% (30d)`} icon={<TrendingDown className="w-4 h-4" />} accent="destructive" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Per-Service Uptime"
          description="Click a row to expand a 90-day daily breakdown"
          action={<span className="text-xs text-muted-foreground">{data.length} services</span>}
        />
        <div className="overflow-x-auto -mx-2 rounded-lg border">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground w-8"></th>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Service</th>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Tier</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">24h</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">7d</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">30d</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">90d</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">1y</th>
                <th className="px-3 py-2.5 text-center font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {data.map((row) => {
                const isOpen = expanded.has(row.service.id);
                return (
                  <React.Fragment key={row.service.id}>
                    <tr
                      className="border-t border-border hover:bg-muted/30 cursor-pointer"
                      onClick={() => toggle(row.service.id)}
                    >
                      <td className="px-3 py-2.5 text-muted-foreground">
                        {isOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="text-sm font-medium">{row.service.name}</div>
                        <div className="text-[10px] text-muted-foreground">{row.service.language}</div>
                      </td>
                      <td className="px-3 py-2.5"><TierBadge tier={row.service.tier} /></td>
                      <td className={`px-3 py-2.5 text-right font-mono text-xs font-semibold ${status(row.h24).color}`}>{row.h24.toFixed(3)}%</td>
                      <td className={`px-3 py-2.5 text-right font-mono text-xs ${status(row.d7).color}`}>{row.d7.toFixed(3)}%</td>
                      <td className={`px-3 py-2.5 text-right font-mono text-xs ${status(row.d30).color}`}>{row.d30.toFixed(3)}%</td>
                      <td className={`px-3 py-2.5 text-right font-mono text-xs ${status(row.d90).color}`}>{row.d90.toFixed(3)}%</td>
                      <td className={`px-3 py-2.5 text-right font-mono text-xs ${status(row.y1).color}`}>{row.y1.toFixed(3)}%</td>
                      <td className="px-3 py-2.5 text-center"><ServiceHealthBadge health={row.service.health} /></td>
                    </tr>
                    {isOpen && (
                      <tr className="border-t border-border bg-muted/10">
                        <td colSpan={9} className="px-6 py-4">
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">90-day daily uptime</div>
                              <div className="text-[10px] text-muted-foreground">{row.daily.filter((d) => d.uptime < 100).length} days with incidents</div>
                            </div>
                            <div className="flex flex-wrap gap-1">
                              {row.daily.map((d, i) => {
                                const s = status(d.uptime);
                                return (
                                  <div
                                    key={i}
                                    className={`w-3 h-6 rounded-sm ${s.bg} group relative`}
                                    title={`${d.date}: ${d.uptime.toFixed(3)}%`}
                                  />
                                );
                              })}
                            </div>
                            <div className="flex items-center gap-3 text-[10px] text-muted-foreground pt-1">
                              <div className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-success" /> 99.99%+</div>
                              <div className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-success/70" /> 99.9%+</div>
                              <div className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-warning" /> 99%+</div>
                              <div className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-destructive" /> &lt; 99%</div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Status summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-3">
          <SectionHeading title="Tier 1 Posture" description="Critical services uptime summary" />
          <div className="space-y-2">
            {data.filter((d) => d.service.tier === "tier1").map((d) => (
              <div key={d.service.id} className="flex items-center justify-between p-2.5 rounded-md border">
                <div className="flex items-center gap-2 min-w-0">
                  <StatusDot color={d.service.health === "operational" ? "success" : d.service.health === "degraded" ? "warning" : "destructive"} pulse={d.service.health !== "operational"} />
                  <span className="text-sm font-medium truncate">{d.service.name}</span>
                </div>
                <span className={`font-mono text-xs font-semibold ${status(d.d30).color}`}>{d.d30.toFixed(3)}%</span>
              </div>
            ))}
          </div>
        </Card>
        <Card className="p-5 space-y-3">
          <SectionHeading title="30-Day Rollup" description="Distribution by uptime band" />
          <div className="space-y-2">
            {[
              { label: "99.99%+ (excellent)", test: (u: number) => u >= 99.99, color: "text-success", bg: "bg-success" },
              { label: "99.9% - 99.99% (good)", test: (u: number) => u >= 99.9 && u < 99.99, color: "text-success", bg: "bg-success/70" },
              { label: "99% - 99.9% (warning)", test: (u: number) => u >= 99 && u < 99.9, color: "text-warning-foreground", bg: "bg-warning" },
              { label: "< 99% (breached)", test: (u: number) => u < 99, color: "text-destructive", bg: "bg-destructive" },
            ].map((band) => {
              const count = data.filter((d) => band.test(d.d30)).length;
              const pct = Math.round((count / data.length) * 100);
              return (
                <div key={band.label} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">{band.label}</span>
                    <span className={`font-mono font-semibold ${band.color}`}>{count} ({pct}%)</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className={band.bg} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
