"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Award, TrendingUp, Activity, Filter, Download,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown } from "lucide-react";
import { services, teams, slos, incidents, deployments } from "@/lib/data";
import { TierBadge } from "@/components/common/badges";

interface Scorecard {
  serviceId: string;
  serviceName: string;
  tier: string;
  team: string;
  uptime: number;
  sloCompliance: number;
  mttr: number;
  changeFailureRate: number;
  errorBudgetRemaining: number;
  healthScore: number;
  grade: string;
}

function gradeFor(score: number): { grade: string; color: string; bg: string } {
  if (score >= 95) return { grade: "A", color: "text-success", bg: "bg-success/15 border-success/30" };
  if (score >= 85) return { grade: "B", color: "text-success", bg: "bg-success/10 border-success/20" };
  if (score >= 75) return { grade: "C", color: "text-warning-foreground", bg: "bg-warning/15 border-warning/30" };
  if (score >= 65) return { grade: "D", color: "text-warning-foreground", bg: "bg-warning/20 border-warning/40" };
  return { grade: "F", color: "text-destructive", bg: "bg-destructive/15 border-destructive/30" };
}

export default function ScorecardsPage() {
  const [teamFilter, setTeamFilter] = React.useState("All");
  const [tierFilter, setTierFilter] = React.useState("All");

  const scorecards: Scorecard[] = services.map((svc) => {
    const slo = slos.find((s) => s.serviceId === svc.id);
    const serviceIncidents = incidents.filter((i) => i.serviceIds.includes(svc.id) && i.resolvedAt);
    const mttr = serviceIncidents.length > 0
      ? Math.round(serviceIncidents.reduce((s, i) => {
          const diff = new Date(i.resolvedAt!).getTime() - new Date(i.startedAt).getTime();
          return s + diff / 60000;
        }, 0) / serviceIncidents.length)
      : 14;
    const serviceDeployments = deployments.filter((d) => d.serviceId === svc.id);
    const failures = serviceDeployments.filter((d) => d.status === "failed" || d.status === "rolled_back").length;
    const cfr = serviceDeployments.length > 0 ? Math.round((failures / serviceDeployments.length) * 100) : 0;
    const errorBudget = slo?.errorBudget.remaining ?? 100;
    const uptime = svc.uptime30d;

    // Composite health score
    const uptimeScore = Math.min(100, (uptime - 99) * 100 / 1);
    const sloScore = slo ? (slo.status === "healthy" ? 100 : slo.status === "at_risk" ? 70 : 30) : 100;
    const mttrScore = Math.max(0, 100 - mttr * 2);
    const cfrScore = Math.max(0, 100 - cfr * 3);
    const ebScore = errorBudget;
    const healthScore = Math.round(uptimeScore * 0.3 + sloScore * 0.25 + mttrScore * 0.15 + cfrScore * 0.15 + ebScore * 0.15);

    return {
      serviceId: svc.id,
      serviceName: svc.name,
      tier: svc.tier,
      team: teams.find((t) => t.id === svc.teamId)?.name ?? "—",
      uptime,
      sloCompliance: slo?.current ?? 100,
      mttr,
      changeFailureRate: cfr,
      errorBudgetRemaining: errorBudget,
      healthScore: Math.max(0, Math.min(100, healthScore)),
      grade: gradeFor(healthScore).grade,
    };
  });

  const filtered = scorecards.filter((s) => {
    if (teamFilter !== "All" && s.team !== teamFilter) return false;
    if (tierFilter !== "All" && s.tier !== tierFilter) return false;
    return true;
  });

  const avgScore = Math.round(filtered.reduce((s, x) => s + x.healthScore, 0) / filtered.length);
  const topPerformers = [...filtered].sort((a, b) => b.healthScore - a.healthScore).slice(0, 3);
  const needsAttention = [...filtered].sort((a, b) => a.healthScore - b.healthScore).slice(0, 3);

  return (
    <PageContainer>
      <PageHeader
        title="Reliability Scorecards"
        description="Composite reliability scores for every service combining uptime, SLO compliance, MTTR, change failure, and error budget."
        breadcrumbs={[{ label: "Reliability", href: "/reliability/slos" }, { label: "Scorecards" }]}
        icon={<Award className="w-5 h-5" />}
        actions={
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Filter className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">{teamFilter}</span>
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setTeamFilter("All")}>All teams</DropdownMenuItem>
                {teams.map((t) => (
                  <DropdownMenuItem key={t.id} onClick={() => setTeamFilter(t.name)}>{t.name}</DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5">
                  <span className="hidden md:inline">{tierFilter === "All" ? "All tiers" : tierFilter.toUpperCase()}</span>
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setTierFilter("All")}>All tiers</DropdownMenuItem>
                {["tier1", "tier2", "tier3"].map((t) => (
                  <DropdownMenuItem key={t} onClick={() => setTierFilter(t)}>{t.toUpperCase()}</DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Avg Health Score" value={avgScore} unit="/ 100" hint={`${filtered.length} services`} icon={<Activity className="w-4 h-4" />} accent={avgScore >= 85 ? "success" : "warning"} />
        <KpiCard label="Grade A Services" value={filtered.filter((s) => s.grade === "A").length} hint="top performers" icon={<Award className="w-4 h-4" />} accent="success" />
        <KpiCard label="Grade D/F" value={filtered.filter((s) => s.grade === "D" || s.grade === "F").length} hint="need attention" icon={<TrendingUp className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Avg MTTR" value={`${Math.round(filtered.reduce((s, x) => s + x.mttr, 0) / filtered.length)}m`} hint="across services" icon={<Activity className="w-4 h-4" />} accent="info" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((sc) => {
          const g = gradeFor(sc.healthScore);
          return (
            <Card key={sc.serviceId} className={`p-5 space-y-4 border ${g.bg}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-sm font-semibold truncate">{sc.serviceName}</h3>
                    <TierBadge tier={sc.tier} />
                  </div>
                  <p className="text-[11px] text-muted-foreground">{sc.team}</p>
                </div>
                <div className={`shrink-0 w-12 h-12 rounded-lg border flex items-center justify-center text-2xl font-bold ${g.bg} ${g.color}`}>
                  {g.grade}
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-muted-foreground">Composite Health</span>
                  <span className={`font-mono font-semibold ${g.color}`}>{sc.healthScore}/100</span>
                </div>
                <Progress value={sc.healthScore} className="h-1.5" />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-md border p-2">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Uptime (30d)</div>
                  <div className="font-mono font-semibold">{sc.uptime.toFixed(3)}%</div>
                </div>
                <div className="rounded-md border p-2">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">SLO Compliance</div>
                  <div className="font-mono font-semibold">{sc.sloCompliance}%</div>
                </div>
                <div className="rounded-md border p-2">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">MTTR</div>
                  <div className="font-mono font-semibold">{sc.mttr}m</div>
                </div>
                <div className="rounded-md border p-2">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Change Failure</div>
                  <div className={`font-mono font-semibold ${sc.changeFailureRate > 15 ? "text-destructive" : ""}`}>{sc.changeFailureRate}%</div>
                </div>
              </div>

              <div className="space-y-1 pt-2 border-t border-border">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-muted-foreground">Error Budget Remaining</span>
                  <span className={`font-mono font-semibold ${sc.errorBudgetRemaining < 30 ? "text-destructive" : sc.errorBudgetRemaining < 60 ? "text-warning-foreground" : "text-success"}`}>
                    {sc.errorBudgetRemaining}%
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div
                    className={sc.errorBudgetRemaining < 30 ? "bg-destructive" : sc.errorBudgetRemaining < 60 ? "bg-warning" : "bg-success"}
                    style={{ width: `${sc.errorBudgetRemaining}%` }}
                  />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Top / Bottom performers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-3 border-success/20">
          <SectionHeading title="Top Performers" description="Highest composite health scores" />
          <div className="space-y-2">
            {topPerformers.map((sc, i) => {
              const g = gradeFor(sc.healthScore);
              return (
                <div key={sc.serviceId} className="flex items-center justify-between p-3 rounded-md border">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-success/20 text-success text-xs font-bold flex items-center justify-center">{i + 1}</span>
                    <div>
                      <div className="text-sm font-medium">{sc.serviceName}</div>
                      <div className="text-[10px] text-muted-foreground">{sc.team}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`font-mono text-sm font-semibold ${g.color}`}>{sc.healthScore}</span>
                    <div className={`w-8 h-8 rounded-md border flex items-center justify-center text-sm font-bold ${g.bg} ${g.color}`}>{sc.grade}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
        <Card className="p-5 space-y-3 border-destructive/20">
          <SectionHeading title="Needs Attention" description="Lowest composite health scores" />
          <div className="space-y-2">
            {needsAttention.map((sc, i) => {
              const g = gradeFor(sc.healthScore);
              return (
                <div key={sc.serviceId} className="flex items-center justify-between p-3 rounded-md border">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-destructive/20 text-destructive text-xs font-bold flex items-center justify-center">{i + 1}</span>
                    <div>
                      <div className="text-sm font-medium">{sc.serviceName}</div>
                      <div className="text-[10px] text-muted-foreground">{sc.team} · MTTR {sc.mttr}m</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`font-mono text-sm font-semibold ${g.color}`}>{sc.healthScore}</span>
                    <div className={`w-8 h-8 rounded-md border flex items-center justify-center text-sm font-bold ${g.bg} ${g.color}`}>{sc.grade}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
