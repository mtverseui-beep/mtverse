"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  FileText, CheckCircle2, AlertTriangle, Download, Filter, FileSignature,
  Building2, Calendar, Percent, DollarSign,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Column, DataTable } from "@/components/tables/data-table";
import { toast } from "sonner";

interface SLAContract {
  id: string;
  customer: string;
  service: string;
  slaTarget: number;
  actual: number;
  compliancePct: number;
  penalty: string;
  period: string;
}

const slaContracts: SLAContract[] = [
  { id: "sla1", customer: "Acme Corp", service: "api-gateway", slaTarget: 99.95, actual: 99.982, compliancePct: 100, penalty: "$5,000/0.1% breach", period: "Q2 2026" },
  { id: "sla2", customer: "Acme Corp", service: "checkout-api", slaTarget: 99.5, actual: 98.6, compliancePct: 87, penalty: "$15,000/incident", period: "Q2 2026" },
  { id: "sla3", customer: "Globex Industries", service: "api-gateway", slaTarget: 99.9, actual: 99.94, compliancePct: 100, penalty: "$3,500/0.1% breach", period: "Q2 2026" },
  { id: "sla4", customer: "Initech LLC", service: "auth-service", slaTarget: 99.99, actual: 99.97, compliancePct: 100, penalty: "$8,000/0.05% breach", period: "Q2 2026" },
  { id: "sla5", customer: "Umbrella Inc", service: "billing-service", slaTarget: 99.9, actual: 99.86, compliancePct: 96, penalty: "$6,200/0.1% breach", period: "Q2 2026" },
  { id: "sla6", customer: "Wayne Enterprises", service: "payment-ledger", slaTarget: 99.99, actual: 99.999, compliancePct: 100, penalty: "$25,000/incident", period: "Q2 2026" },
  { id: "sla7", customer: "Stark Industries", service: "api-gateway", slaTarget: 99.95, actual: 99.96, compliancePct: 100, penalty: "$12,000/0.1% breach", period: "Q1 2026" },
  { id: "sla8", customer: "Cyberdyne Systems", service: "checkout-api", slaTarget: 99.5, actual: 99.78, compliancePct: 100, penalty: "$10,000/incident", period: "Q1 2026" },
  { id: "sla9", customer: "Soylent Corp", service: "billing-service", slaTarget: 99.9, actual: 99.91, compliancePct: 100, penalty: "$4,500/0.1% breach", period: "Q1 2026" },
];

const periods = ["Q2 2026", "Q1 2026"];
const customers = Array.from(new Set(slaContracts.map((c) => c.customer)));

export default function SLAReportsPage() {
  const [period, setPeriod] = React.useState("Q2 2026");
  const [customer, setCustomer] = React.useState("All");

  const filtered = slaContracts.filter((c) => {
    if (period !== "All" && c.period !== period) return false;
    if (customer !== "All" && c.customer !== customer) return false;
    return true;
  });

  const compliant = filtered.filter((c) => c.compliancePct >= 100).length;
  const atRisk = filtered.filter((c) => c.compliancePct >= 95 && c.compliancePct < 100).length;
  const breached = filtered.filter((c) => c.compliancePct < 95).length;
  const avgCompliance = filtered.length > 0 ? Math.round(filtered.reduce((s, c) => s + c.compliancePct, 0) / filtered.length) : 0;

  const columns: Column<SLAContract>[] = [
    {
      key: "customer",
      header: "Customer",
      sortable: true,
      sortValue: (r) => r.customer,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Building2 className="w-3.5 h-3.5 text-primary" />
          </div>
          <span className="text-sm font-medium">{r.customer}</span>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => r.service,
      cell: (r) => <span className="font-mono text-xs">{r.service}</span>,
      hideOnMobile: true,
    },
    {
      key: "slaTarget",
      header: "SLA Target",
      sortable: true,
      sortValue: (r) => r.slaTarget,
      cell: (r) => <span className="font-mono text-xs">{r.slaTarget}%</span>,
      align: "right",
    },
    {
      key: "actual",
      header: "Actual",
      sortable: true,
      sortValue: (r) => r.actual,
      cell: (r) => (
        <span className={`font-mono text-xs font-semibold ${r.actual < r.slaTarget ? "text-destructive" : "text-success"}`}>
          {r.actual}%
        </span>
      ),
      align: "right",
    },
    {
      key: "compliancePct",
      header: "Compliance",
      sortable: true,
      sortValue: (r) => r.compliancePct,
      cell: (r) => {
        const c = r.compliancePct;
        const color = c >= 100 ? "text-success" : c >= 95 ? "text-warning-foreground" : "text-destructive";
        return (
          <div className="w-24 space-y-1">
            <span className={`text-xs font-semibold tabular-nums ${color}`}>{c}%</span>
            <div className="h-1.5 rounded-full bg-muted overflow-hidden">
              <div
                className={c >= 100 ? "bg-success" : c >= 95 ? "bg-warning" : "bg-destructive"}
                style={{ width: `${Math.min(100, c)}%` }}
              />
            </div>
          </div>
        );
      },
    },
    {
      key: "penalty",
      header: "Penalty",
      cell: (r) => <span className="text-[11px] text-muted-foreground">{r.penalty}</span>,
      hideOnMobile: true,
    },
    {
      key: "period",
      header: "Period",
      cell: (r) => <span className="text-[11px] text-muted-foreground">{r.period}</span>,
      hideOnMobile: true,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="SLA Reports"
        description="Customer SLA contracts with compliance tracking, penalty terms, and period-over-period reporting."
        breadcrumbs={[{ label: "Reliability", href: "/reliability/slos" }, { label: "SLA Reports" }]}
        icon={<FileText className="w-5 h-5" />}
        actions={
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Filter className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">{period}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setPeriod("All")}>All periods</DropdownMenuItem>
                {periods.map((p) => (
                  <DropdownMenuItem key={p} onClick={() => setPeriod(p)}>{p}</DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Building2 className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">{customer}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setCustomer("All")}>All customers</DropdownMenuItem>
                {customers.map((c) => (
                  <DropdownMenuItem key={c} onClick={() => setCustomer(c)}>{c}</DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("SLA report exported as PDF")}>
              <Download className="w-3.5 h-3.5" />
              Export PDF
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Active Contracts" value={filtered.length} hint={`${customers.length} customers`} icon={<FileSignature className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Compliant" value={compliant} hint="meeting target" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="At Risk / Breached" value={atRisk + breached} hint={`${breached} breached`} icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Avg Compliance" value={`${avgCompliance}%`} hint={`for ${period}`} icon={<Percent className="w-4 h-4" />} accent={avgCompliance >= 95 ? "success" : "warning"} />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="SLA Contracts"
          description="Each row is a per-customer, per-service SLA contract"
          action={<span className="text-xs text-muted-foreground">{filtered.length} contracts</span>}
        />
        <DataTable
          columns={columns}
          data={filtered}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.customer, (r) => r.service]}
          searchPlaceholder="Search customer or service..."
          pageSize={10}
          mobileCard={(r) => (
            <div className="rounded-lg border p-3 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Building2 className="w-3.5 h-3.5 text-primary" />
                  <span className="text-sm font-medium">{r.customer}</span>
                </div>
                <span className={`text-xs font-semibold ${r.compliancePct >= 100 ? "text-success" : r.compliancePct >= 95 ? "text-warning-foreground" : "text-destructive"}`}>{r.compliancePct}%</span>
              </div>
              <div className="text-[11px] text-muted-foreground">{r.service} · Target {r.slaTarget}% · Actual {r.actual}%</div>
              <div className="text-[10px] text-muted-foreground">{r.penalty} · {r.period}</div>
            </div>
          )}
        />
      </Card>

      {/* Penalty summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 space-y-3">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-destructive" />
            <h3 className="text-sm font-semibold">Penalty Exposure</h3>
          </div>
          <div className="text-3xl font-bold tabular-nums">$42,800</div>
          <p className="text-xs text-muted-foreground">Potential penalties from breached contracts this period.</p>
          <div className="space-y-1.5 pt-2">
            {filtered.filter((c) => c.compliancePct < 100).map((c) => (
              <div key={c.id} className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{c.customer} · {c.service}</span>
                <span className="font-mono text-destructive">{c.penalty.split("/")[0].replace("$", "")}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card className="p-5 space-y-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Reporting Periods</h3>
          </div>
          <div className="space-y-2">
            {periods.map((p) => {
              const contractsInPeriod = slaContracts.filter((c) => c.period === p);
              const compliant = contractsInPeriod.filter((c) => c.compliancePct >= 100).length;
              return (
                <div key={p} className="flex items-center justify-between p-2.5 rounded-md border">
                  <div>
                    <div className="text-sm font-medium">{p}</div>
                    <div className="text-[10px] text-muted-foreground">{contractsInPeriod.length} contracts · {compliant} compliant</div>
                  </div>
                  <span className={`text-xs font-semibold ${compliant === contractsInPeriod.length ? "text-success" : "text-warning-foreground"}`}>
                    {Math.round((compliant / contractsInPeriod.length) * 100)}%
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
        <Card className="p-5 space-y-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-accent-foreground" />
            <h3 className="text-sm font-semibold">Top Customers</h3>
          </div>
          <div className="space-y-2">
            {customers.slice(0, 5).map((c) => {
              const customerContracts = slaContracts.filter((s) => s.customer === c);
              const avg = Math.round(customerContracts.reduce((s, x) => s + x.compliancePct, 0) / customerContracts.length);
              return (
                <div key={c} className="flex items-center justify-between text-xs">
                  <span className="font-medium truncate">{c}</span>
                  <span className={`font-mono ${avg >= 100 ? "text-success" : avg >= 95 ? "text-warning-foreground" : "text-destructive"}`}>{avg}%</span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
