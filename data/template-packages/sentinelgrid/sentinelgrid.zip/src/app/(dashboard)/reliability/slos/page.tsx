"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Target, CheckCircle2, AlertTriangle, ShieldX, Plus, Download, Filter, Flame,
} from "lucide-react";
import { slos, services } from "@/lib/data";
import { SLOStatusBadge, TierBadge } from "@/components/common/badges";
import type { SLO } from "@/lib/types";

export default function SLOOverviewPage() {
  const totalSLOs = slos.length;
  const healthy = slos.filter((s) => s.status === "healthy").length;
  const atRisk = slos.filter((s) => s.status === "at_risk").length;
  const breached = slos.filter((s) => s.status === "breached" || s.status === "exhausted").length;

  const columns: Column<SLO>[] = [
    {
      key: "ref",
      header: "SLO Ref",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => (
        <Link href={`/reliability/slos/${r.id}`} className="font-mono text-xs font-semibold text-primary hover:underline">
          {r.ref}
        </Link>
      ),
    },
    {
      key: "name",
      header: "Name",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="min-w-0">
          <div className="text-sm font-medium truncate">{r.name}</div>
          <div className="text-[10px] text-muted-foreground line-clamp-1">{r.description}</div>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => services.find((s) => s.id === r.serviceId)?.name ?? "",
      cell: (r) => {
        const svc = services.find((s) => s.id === r.serviceId);
        return (
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium">{svc?.name ?? "—"}</span>
            {svc && <TierBadge tier={svc.tier} />}
          </div>
        );
      },
      filterable: true,
      filterOptions: services.map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.serviceId === v,
    },
    {
      key: "target",
      header: "Target",
      sortable: true,
      sortValue: (r) => r.target,
      cell: (r) => <span className="font-mono text-xs tabular-nums">{r.target}%</span>,
      align: "right",
      hideOnMobile: true,
    },
    {
      key: "current",
      header: "Current",
      sortable: true,
      sortValue: (r) => r.current,
      cell: (r) => (
        <span className={`font-mono text-xs font-semibold tabular-nums ${
          r.status === "breached" || r.status === "exhausted" ? "text-destructive" :
          r.status === "at_risk" ? "text-warning-foreground" : "text-success"
        }`}>
          {r.current}{r.sli.unit === "percent" ? "%" : r.sli.unit}
        </span>
      ),
      align: "right",
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => <SLOStatusBadge status={r.status} />,
      filterable: true,
      filterOptions: [
        { label: "Healthy", value: "healthy" },
        { label: "At Risk", value: "at_risk" },
        { label: "Breached", value: "breached" },
        { label: "Exhausted", value: "exhausted" },
      ],
      filterFn: (r, v) => r.status === v,
    },
    {
      key: "errorBudget",
      header: "Error Budget Remaining",
      cell: (r) => {
        const pct = r.errorBudget.remaining;
        const isBreached = r.status === "breached" || r.status === "exhausted";
        const isHealthy = r.status === "healthy";
        return (
          <div className="w-32 space-y-1">
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-muted-foreground">{pct}% left</span>
              <span className="text-muted-foreground tabular-nums">{r.errorBudget.consumed}% used</span>
            </div>
            <div className="relative h-1.5 rounded-full bg-muted overflow-hidden">
              <div
                className={`absolute inset-y-0 left-0 ${isBreached ? "bg-destructive" : isHealthy ? "bg-success" : "bg-warning"}`}
                style={{ width: `${Math.max(0, Math.min(100, pct))}%` }}
              />
            </div>
          </div>
        );
      },
      hideOnMobile: true,
    },
    {
      key: "burnRate",
      header: "Burn Rate",
      sortable: true,
      sortValue: (r) => r.errorBudget.burnRate,
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <Flame className={`w-3 h-3 ${r.errorBudget.burnRate > 6 ? "text-destructive" : r.errorBudget.burnRate > 1 ? "text-warning-foreground" : "text-muted-foreground"}`} />
          <span className={`font-mono text-xs tabular-nums ${r.errorBudget.burnRate > 6 ? "text-destructive" : ""}`}>
            {r.errorBudget.burnRate}x
          </span>
        </div>
      ),
      align: "right",
      hideOnMobile: true,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="SLO Overview"
        description="Service-level objectives across all services with error budget consumption, burn rate, and posture."
        breadcrumbs={[{ label: "Reliability", href: "/reliability/slos" }, { label: "SLOs" }]}
        icon={<Target className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Filter</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              New SLO
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total SLOs" value={totalSLOs} hint="across 9 services" icon={<Target className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Healthy" value={healthy} hint={`${Math.round((healthy / totalSLOs) * 100)}% of total`} icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="At Risk" value={atRisk} hint="burn rate elevated" icon={<AlertTriangle className="w-4 h-4" />} accent="warning" sparkline={[1, 2, 1, 2, 3, 2, 2, 1, 2, 2]} />
        <KpiCard label="Breached" value={breached} hint="budget exhausted" icon={<ShieldX className="w-4 h-4" />} accent="destructive" sparkline={[0, 1, 0, 1, 1, 1, 1, 0, 1, 1]} />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="All SLOs"
          description="Filter by status or service to focus your review"
          action={<span className="text-xs text-muted-foreground">{slos.length} objectives</span>}
        />
        <DataTable
          columns={columns}
          data={slos}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.ref, (r) => r.name, (r) => services.find((s) => s.id === r.serviceId)?.name ?? ""]}
          searchPlaceholder="Search by ref, name, service..."
          pageSize={10}
          initialSort={{ key: "burnRate", dir: "desc" }}
          onRowClick={(r) => { window.location.href = `/reliability/slos/${r.id}`; }}
        />
      </Card>
    </PageContainer>
  );
}
