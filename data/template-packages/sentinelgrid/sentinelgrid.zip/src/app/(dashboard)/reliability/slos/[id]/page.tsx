"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Target, ArrowLeft, Activity, Database, Code2, Flame, AlertTriangle,
  ShieldAlert, ExternalLink, Bell,
} from "lucide-react";
import { slos, services, incidents, timeSeries } from "@/lib/data";
import { BurnRateChart } from "@/components/charts";
import { SLOStatusBadge, TierBadge, SeverityBadge, IncidentStatusBadge } from "@/components/common/badges";
import { toast } from "sonner";

export default function SLODetailsPage() {
  const params = useParams<{ id: string }>();
  const slo = slos.find((s) => s.id === params.id) ?? slos[0];
  const svc = services.find((s) => s.id === slo.serviceId);
  const relatedIncidents = incidents.filter((i) => i.serviceIds.includes(slo.serviceId));

  const burnRateTrend = timeSeries(7, 24, slo.errorBudget.burnRate, Math.max(slo.errorBudget.burnRate * 0.4, 1)).map((d) => ({
    timestamp: d.date,
    value: Math.max(0, d.value),
  }));

  const windows = [
    { label: "1h", threshold: 14.4, current: slo.errorBudget.burnRate * (1 + Math.random() * 0.4) },
    { label: "6h", threshold: 6, current: slo.errorBudget.burnRate * (0.8 + Math.random() * 0.3) },
    { label: "1d", threshold: 3, current: slo.errorBudget.burnRate * (0.6 + Math.random() * 0.2) },
    { label: "3d", threshold: 1, current: slo.errorBudget.burnRate * (0.4 + Math.random() * 0.2) },
  ];

  const remainingPct = slo.errorBudget.remaining;
  const consumedPct = slo.errorBudget.consumed;
  const isBreached = slo.status === "breached" || slo.status === "exhausted";
  const isHealthy = slo.status === "healthy";

  return (
    <PageContainer>
      <PageHeader
        title={slo.name}
        description={slo.description}
        breadcrumbs={[
          { label: "Reliability", href: "/reliability/slos" },
          { label: "SLOs", href: "/reliability/slos" },
          { label: slo.ref },
        ]}
        icon={<Target className="w-5 h-5" />}
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/reliability/slos"><ArrowLeft className="w-3.5 h-3.5" /> Back</Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Alert rule created")}>
              <Bell className="w-3.5 h-3.5" /> New Alert
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("SLO updated")}>
              Edit SLO
            </Button>
          </>
        }
      />

      {/* Hero */}
      <Card className={`p-6 ${isBreached ? "border-destructive/30 bg-destructive/5" : isHealthy ? "border-success/20" : "border-warning/20"}`}>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1 space-y-3">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs text-muted-foreground">{slo.ref}</span>
              <SLOStatusBadge status={slo.status} />
            </div>
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Service</div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">{svc?.name}</span>
                {svc && <TierBadge tier={svc.tier} />}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Target</div>
                <div className="text-xl font-bold tabular-nums">{slo.target}%</div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Current SLI</div>
                <div className={`text-xl font-bold tabular-nums ${isBreached ? "text-destructive" : isHealthy ? "text-success" : "text-warning-foreground"}`}>
                  {slo.current}{slo.sli.unit === "percent" ? "%" : ` ${slo.sli.unit}`}
                </div>
              </div>
            </div>
            <div className="text-[11px] text-muted-foreground pt-1">Window: {slo.window} · Updated {new Date(slo.updatedAt).toLocaleDateString()}</div>
          </div>

          <div className="lg:col-span-3">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Error Budget</span>
                <span className="text-muted-foreground">
                  <span className={`font-mono font-semibold ${isBreached ? "text-destructive" : isHealthy ? "text-success" : "text-warning-foreground"}`}>{remainingPct}%</span> remaining · {consumedPct}% consumed
                </span>
              </div>
              <div className="relative h-3 rounded-full bg-muted overflow-hidden">
                <div
                  className={`absolute inset-y-0 left-0 ${isBreached ? "bg-destructive" : isHealthy ? "bg-success" : "bg-warning"}`}
                  style={{ width: `${Math.max(0, Math.min(100, remainingPct))}%` }}
                />
                <div
                  className={`absolute inset-y-0 ${isBreached ? "bg-destructive/40" : "bg-muted-foreground/30"}`}
                  style={{ left: `${remainingPct}%`, right: 0 }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-muted-foreground pt-1">
                <span>Window: {slo.window}</span>
                <span>Burn rate: <span className={`font-mono font-semibold ${slo.errorBudget.burnRate > 6 ? "text-destructive" : ""}`}>{slo.errorBudget.burnRate}x</span></span>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
              {windows.map((w) => {
                const triggered = w.current >= w.threshold;
                return (
                  <div key={w.label} className={`rounded-lg border p-3 ${triggered ? "border-destructive/40 bg-destructive/5" : "border-border bg-card"}`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Window {w.label}</span>
                      {triggered ? <Flame className="w-3 h-3 text-destructive" /> : <Activity className="w-3 h-3 text-success" />}
                    </div>
                    <div className={`text-lg font-bold tabular-nums ${triggered ? "text-destructive" : ""}`}>{w.current.toFixed(2)}x</div>
                    <div className="text-[10px] text-muted-foreground">Threshold {w.threshold}x</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* SLI Definition */}
        <Card className="p-5 space-y-4">
          <SectionHeading title="SLI Definition" description="Source metric and query" />
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-primary" />
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Metric</div>
                <div className="text-sm font-mono">{slo.sli.metric}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Database className="w-3.5 h-3.5 text-accent-foreground" />
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Source</div>
                <div className="text-sm font-mono">{slo.sli.source}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Code2 className="w-3.5 h-3.5 text-success" />
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Unit</div>
                <div className="text-sm font-mono">{slo.sli.unit}</div>
              </div>
            </div>
            <div className="space-y-1.5 pt-2">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">PromQL Query</div>
              <pre className="text-[11px] font-mono bg-muted rounded-md p-3 overflow-x-auto whitespace-pre-wrap break-all">{slo.sli.query}</pre>
            </div>
          </div>
        </Card>

        {/* Error budget */}
        <Card className="p-5 space-y-4">
          <SectionHeading title="Error Budget Breakdown" description="Consumed vs remaining" />
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border border-success/30 bg-success/5 p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Remaining</div>
                <div className="text-2xl font-bold tabular-nums text-success">{remainingPct}%</div>
              </div>
              <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Consumed</div>
                <div className="text-2xl font-bold tabular-nums text-destructive">{consumedPct}%</div>
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1.5">
                <span className="text-muted-foreground">Budget consumption</span>
                <span className="font-medium">{consumedPct}% / 100%</span>
              </div>
              <Progress value={consumedPct} className={`h-2 ${isBreached ? "bg-destructive/20" : "bg-muted"}`} />
            </div>
            <div className="grid grid-cols-3 gap-2 pt-1 text-center">
              <div>
                <div className="text-[10px] text-muted-foreground">Burn Rate</div>
                <div className={`text-sm font-mono font-semibold ${slo.errorBudget.burnRate > 6 ? "text-destructive" : ""}`}>{slo.errorBudget.burnRate}x</div>
              </div>
              <div>
                <div className="text-[10px] text-muted-foreground">Total Budget</div>
                <div className="text-sm font-mono font-semibold">{slo.errorBudget.total}</div>
              </div>
              <div>
                <div className="text-[10px] text-muted-foreground">Window</div>
                <div className="text-sm font-mono font-semibold">{slo.window}</div>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full h-8 text-xs gap-1.5" onClick={() => toast.success("Error budget policy opened")}>
              View Error Budget Policy <ExternalLink className="w-3 h-3" />
            </Button>
          </div>
        </Card>

        {/* Burn rate alerts */}
        <Card className="p-5 space-y-4">
          <SectionHeading title="Burn Rate Alerts" description="Multi-window alert configuration" />
          <div className="space-y-2">
            {windows.map((w) => {
              const triggered = w.current >= w.threshold;
              return (
                <div key={w.label} className={`flex items-center justify-between gap-2 rounded-md border p-2.5 ${triggered ? "border-destructive/40 bg-destructive/5" : "border-border"}`}>
                  <div className="flex items-center gap-2">
                    {triggered ? <AlertTriangle className="w-3.5 h-3.5 text-destructive" /> : <ShieldAlert className="w-3.5 h-3.5 text-muted-foreground" />}
                    <div>
                      <div className="text-xs font-medium">{w.threshold}x · {w.label} window</div>
                      <div className="text-[10px] text-muted-foreground">Current: {w.current.toFixed(2)}x</div>
                    </div>
                  </div>
                  <span className={`text-[10px] uppercase font-semibold tracking-wider px-2 py-0.5 rounded ${triggered ? "bg-destructive/15 text-destructive" : "bg-success/15 text-success"}`}>
                    {triggered ? "Triggered" : "OK"}
                  </span>
                </div>
              );
            })}
            {slo.alerts.length === 0 && windows.every((w) => w.current < w.threshold) && (
              <div className="text-center text-xs text-muted-foreground py-3">No alerts configured</div>
            )}
          </div>
        </Card>
      </div>

      {/* Burn rate chart */}
      <BurnRateChart
        data={burnRateTrend}
        threshold={14.4}
        title={`Burn Rate - Last 24h (${slo.ref})`}
        description={`Current burn rate ${slo.errorBudget.burnRate}x · threshold 14.4x (1h window)`}
      />

      {/* Related incidents */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Related Incidents"
          description={`Incidents affecting ${svc?.name} on this SLO`}
          action={<span className="text-xs text-muted-foreground">{relatedIncidents.length} incidents</span>}
        />
        <div className="space-y-2">
          {relatedIncidents.length === 0 ? (
            <div className="text-center text-xs text-muted-foreground py-6">No related incidents</div>
          ) : relatedIncidents.map((inc) => (
            <Link key={inc.id} href={`/incidents/${inc.id}`} className="flex items-center justify-between gap-3 p-3 rounded-md border hover:bg-muted/40 transition-colors">
              <div className="flex items-center gap-3 min-w-0">
                <SeverityBadge severity={inc.severity} size="sm" />
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{inc.title}</div>
                  <div className="text-[10px] text-muted-foreground">{inc.ref} · {new Date(inc.startedAt).toLocaleString()}</div>
                </div>
              </div>
              <IncidentStatusBadge status={inc.status} />
            </Link>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
