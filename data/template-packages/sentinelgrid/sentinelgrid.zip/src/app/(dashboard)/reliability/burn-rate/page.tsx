"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Flame, AlertTriangle, Bell, ShieldAlert, Download, Clock,
} from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useChartTheme, ChartTooltip } from "@/components/charts/chart-container";
import { slos, services } from "@/lib/data";
import { SLOStatusBadge } from "@/components/common/badges";

const WINDOWS = [
  { label: "1h", threshold: 14.4 },
  { label: "6h", threshold: 6 },
  { label: "1d", threshold: 3 },
  { label: "3d", threshold: 1 },
];

export default function BurnRatePage() {
  const t = useChartTheme();

  // Generate per-window alerts
  const allAlerts = slos.flatMap((slo) =>
    WINDOWS.map((w) => {
      const burn = slo.errorBudget.burnRate * (Math.random() * 0.7 + 0.5);
      return {
        sloId: slo.id,
        ref: slo.ref,
        name: slo.name,
        window: w.label,
        threshold: w.threshold,
        burn: parseFloat(burn.toFixed(2)),
        triggered: burn >= w.threshold,
        status: slo.status,
      };
    })
  );

  const triggeredAlerts = allAlerts.filter((a) => a.triggered);
  const avgBurn = (slos.reduce((s, slo) => s + slo.errorBudget.burnRate, 0) / slos.length).toFixed(2);

  // Bar chart data: per SLO current burn rate
  const chartData = slos
    .map((slo) => ({
      name: slo.ref,
      burn: slo.errorBudget.burnRate,
      triggered: slo.errorBudget.burnRate > 1,
    }))
    .sort((a, b) => b.burn - a.burn);

  return (
    <PageContainer>
      <PageHeader
        title="Burn Rate Alerts"
        description="Multi-window burn rate alerting across all SLOs with 1h, 6h, 1d, and 3d thresholds."
        breadcrumbs={[{ label: "Reliability", href: "/reliability/slos" }, { label: "Burn Rate" }]}
        icon={<Flame className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Active Alerts" value={triggeredAlerts.length} hint="currently triggered" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Avg Burn Rate" value={`${avgBurn}x`} hint="across all SLOs" icon={<Flame className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Critical (1h > 14.4x)" value={allAlerts.filter((a) => a.window === "1h" && a.triggered).length} hint="fastest exhaust risk" icon={<ShieldAlert className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Suppressed" value={2} hint="next 60 min" icon={<Bell className="w-4 h-4" />} accent="muted" />
      </div>

      {/* Bar chart with threshold lines */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Burn Rate by SLO"
          description="Current burn rate per SLO with 14.4x (1h) and 1x (3d) threshold lines"
          action={<span className="text-xs text-muted-foreground">{slos.length} SLOs</span>}
        />
        <div className="h-[320px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
              <CartesianGrid stroke={t.grid} vertical={false} />
              <XAxis dataKey="name" stroke={t.axis} fontSize={10} tickLine={false} axisLine={false} angle={-30} textAnchor="end" height={60} />
              <YAxis stroke={t.axis} fontSize={11} tickLine={false} axisLine={false} width={36} />
              <Tooltip content={<ChartTooltip suffix="x" />} cursor={{ fill: t.isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.04)" }} />
              <ReferenceLine y={14.4} stroke={t.palette[4]} strokeDasharray="4 4" label={{ value: "1h: 14.4x", position: "insideTopRight", fill: t.palette[4], fontSize: 10 }} />
              <ReferenceLine y={6} stroke={t.palette[2]} strokeDasharray="4 4" label={{ value: "6h: 6x", position: "insideTopRight", fill: t.palette[2], fontSize: 10 }} />
              <ReferenceLine y={3} stroke={t.palette[5]} strokeDasharray="4 4" label={{ value: "1d: 3x", position: "insideTopRight", fill: t.palette[5], fontSize: 10 }} />
              <ReferenceLine y={1} stroke={t.palette[3]} strokeDasharray="4 4" label={{ value: "3d: 1x", position: "insideBottomRight", fill: t.palette[3], fontSize: 10 }} />
              <Bar dataKey="burn" radius={[4, 4, 0, 0]} name="Burn Rate">
                {chartData.map((d, i) => (
                  <Cell key={i} fill={d.burn >= 14.4 ? t.palette[4] : d.burn >= 6 ? t.palette[2] : d.burn >= 3 ? t.palette[5] : d.burn >= 1 ? t.palette[1] : t.palette[3]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Multi-window alert list */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Multi-Window Alerts"
          description="Each SLO is checked against 4 burn rate thresholds"
          action={
            <div className="flex items-center gap-1.5 text-xs">
              <span className="w-2 h-2 rounded-full bg-destructive" />
              <span className="text-muted-foreground">{triggeredAlerts.length} triggered</span>
            </div>
          }
        />
        <div className="overflow-x-auto -mx-2">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 sticky top-0">
              <tr>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground">SLO</th>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Service</th>
                {WINDOWS.map((w) => (
                  <th key={w.label} className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">
                    {w.label} <span className="text-muted-foreground/60">(&le;{w.threshold}x)</span>
                  </th>
                ))}
                <th className="px-3 py-2.5 text-center font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {slos.map((slo) => {
                const svc = services.find((s) => s.id === slo.serviceId);
                return (
                  <tr key={slo.id} className="border-t border-border hover:bg-muted/30">
                    <td className="px-3 py-2.5">
                      <Link href={`/reliability/slos/${slo.id}`} className="font-mono text-xs text-primary hover:underline">{slo.ref}</Link>
                      <div className="text-[10px] text-muted-foreground line-clamp-1">{slo.name}</div>
                    </td>
                    <td className="px-3 py-2.5 text-xs">{svc?.name}</td>
                    {WINDOWS.map((w) => {
                      const alert = allAlerts.find((a) => a.sloId === slo.id && a.window === w.label);
                      if (!alert) return <td key={w.label} className="px-3 py-2.5 text-right" />;
                      return (
                        <td key={w.label} className="px-3 py-2.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {alert.triggered && <AlertTriangle className="w-3 h-3 text-destructive" />}
                            <span className={`font-mono text-xs tabular-nums ${alert.triggered ? "text-destructive font-semibold" : "text-muted-foreground"}`}>
                              {alert.burn}x
                            </span>
                          </div>
                        </td>
                      );
                    })}
                    <td className="px-3 py-2.5 text-center">
                      <SLOStatusBadge status={slo.status} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Triggered alerts detail */}
      {triggeredAlerts.length > 0 && (
        <Card className="p-5 space-y-4 border-destructive/20 bg-destructive/5">
          <SectionHeading
            title="Triggered Alerts"
            description="Active burn rate alerts requiring attention"
            action={<span className="text-xs text-destructive font-semibold">{triggeredAlerts.length} active</span>}
          />
          <div className="space-y-2">
            {triggeredAlerts.slice(0, 8).map((alert, i) => {
              const slo = slos.find((s) => s.id === alert.sloId);
              const svc = services.find((s) => s.id === alert.sloId);
              return (
                <div key={i} className="flex items-center justify-between gap-3 p-3 rounded-md border border-destructive/30 bg-card">
                  <div className="flex items-center gap-3 min-w-0">
                    <Flame className="w-4 h-4 text-destructive shrink-0" />
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">{alert.name}</div>
                      <div className="text-[10px] text-muted-foreground">
                        <Link href={`/reliability/slos/${slo?.id}`} className="font-mono text-primary hover:underline">{alert.ref}</Link>
                        <span className="mx-1">·</span>{svc?.name}
                        <span className="mx-1">·</span>Window {alert.window}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="text-sm font-mono font-bold text-destructive tabular-nums">{alert.burn}x</div>
                      <div className="text-[10px] text-muted-foreground">threshold {alert.threshold}x</div>
                    </div>
                    <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
                      <Clock className="w-3 h-3" /> Acknowledge
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </PageContainer>
  );
}
