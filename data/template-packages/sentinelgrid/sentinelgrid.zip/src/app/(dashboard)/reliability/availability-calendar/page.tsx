"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  CalendarDays, AlertTriangle, Clock, TrendingDown,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown } from "lucide-react";
import { services, uptimeForService } from "@/lib/data";
import { UptimeHeatmap } from "@/components/charts";
import { TierBadge, StatusDot } from "@/components/common/badges";

export default function AvailabilityCalendarPage() {
  const [selectedId, setSelectedId] = React.useState(services[0].id);
  const service = services.find((s) => s.id === selectedId) ?? services[0];

  const records = uptimeForService(selectedId, 90);

  const heatmapData = records.map((r) => ({ date: r.date, uptime: r.uptime, incidents: r.incidents }));

  const totalDowntime = records.reduce((s, r) => s + r.downtimeSeconds, 0);
  const incidentCount = records.filter((r) => r.incidents > 0).length;
  const worstDay = records.filter((r) => r.uptime < 100).sort((a, b) => a.uptime - b.uptime)[0];
  const avgUptime = records.reduce((s, r) => s + r.uptime, 0) / records.length;

  function formatDowntime(seconds: number) {
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
    return `${Math.floor(seconds / 86400)}d ${Math.floor((seconds % 86400) / 3600)}h`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Availability Calendar"
        description="Per-service 90-day availability heatmap with daily incident overlay and summary statistics."
        breadcrumbs={[{ label: "Reliability", href: "/reliability/slos" }, { label: "Availability Calendar" }]}
        icon={<CalendarDays className="w-5 h-5" />}
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5 min-w-[180px] justify-between">
                <span className="truncate">{service.name}</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="max-h-80 overflow-y-auto">
              {services.map((s) => (
                <DropdownMenuItem key={s.id} onClick={() => setSelectedId(s.id)} className="gap-2">
                  <StatusDot color={s.health === "operational" ? "success" : s.health === "degraded" ? "warning" : "destructive"} />
                  <span className="font-mono text-xs">{s.name}</span>
                  <TierBadge tier={s.tier} />
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Avg Uptime (90d)" value={`${avgUptime.toFixed(3)}%`} hint={`${service.name}`} icon={<CalendarDays className="w-4 h-4" />} accent={avgUptime >= 99.9 ? "success" : "warning"} />
        <KpiCard label="Total Downtime" value={formatDowntime(totalDowntime)} hint="over 90 days" icon={<Clock className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Incident Days" value={incidentCount} hint="days with ≥ 1 incident" icon={<AlertTriangle className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Worst Day" value={worstDay ? `${worstDay.uptime.toFixed(2)}%` : "100%"} hint={worstDay ? worstDay.date : "no incidents"} icon={<TrendingDown className="w-4 h-4" />} accent="destructive" />
      </div>

      <UptimeHeatmap
        data={heatmapData}
        title={`${service.name} - 90 Day Availability`}
        description={`Service ID: ${service.id} · Region(s): ${service.regions.join(", ")}`}
      />

      {/* Day-by-day table for incident days */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Incident Days Breakdown"
          description="Days where availability dropped below 100%"
          action={<span className="text-xs text-muted-foreground">{incidentCount} days affected</span>}
        />
        <div className="overflow-x-auto -mx-2">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr>
                <th className="px-3 py-2.5 text-left font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Date</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Uptime</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Downtime</th>
                <th className="px-3 py-2.5 text-right font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Incidents</th>
                <th className="px-3 py-2.5 font-medium text-[10px] uppercase tracking-wider text-muted-foreground">Severity</th>
              </tr>
            </thead>
            <tbody>
              {records.filter((r) => r.uptime < 100).sort((a, b) => a.uptime - b.uptime).slice(0, 20).map((r) => {
                const severity = r.uptime < 99 ? "destructive" : r.uptime < 99.9 ? "warning" : "info";
                return (
                  <tr key={r.id} className="border-t border-border hover:bg-muted/30">
                    <td className="px-3 py-2.5 text-sm font-mono">{r.date}</td>
                    <td className={`px-3 py-2.5 text-right font-mono text-xs font-semibold ${severity === "destructive" ? "text-destructive" : severity === "warning" ? "text-warning-foreground" : "text-info-foreground"}`}>
                      {r.uptime.toFixed(3)}%
                    </td>
                    <td className="px-3 py-2.5 text-right text-xs tabular-nums">{formatDowntime(r.downtimeSeconds)}</td>
                    <td className="px-3 py-2.5 text-right text-xs tabular-nums">{r.incidents}</td>
                    <td className="px-3 py-2.5">
                      <span className={`inline-flex items-center gap-1 text-[10px] uppercase tracking-wider font-semibold ${severity === "destructive" ? "text-destructive" : severity === "warning" ? "text-warning-foreground" : "text-info-foreground"}`}>
                        <StatusDot color={severity === "destructive" ? "destructive" : severity === "warning" ? "warning" : "info"} />
                        {severity === "destructive" ? "Major" : severity === "warning" ? "Minor" : "Barely"}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {records.filter((r) => r.uptime < 100).length === 0 && (
                <tr>
                  <td colSpan={5} className="px-3 py-8 text-center text-sm text-muted-foreground">No incident days in the last 90 days.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </PageContainer>
  );
}
