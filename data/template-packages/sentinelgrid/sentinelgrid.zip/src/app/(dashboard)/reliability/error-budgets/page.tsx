"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Wallet, TrendingDown, TrendingUp, Flame, Download, AlertTriangle,
  Clock, ArrowUpRight,
} from "lucide-react";
import { slos, services } from "@/lib/data";
import { SLOStatusBadge, TierBadge } from "@/components/common/badges";

export default function ErrorBudgetsPage() {
  const totalBudget = slos.reduce((s, slo) => s + slo.errorBudget.total, 0);
  const totalConsumed = slos.reduce((s, slo) => s + slo.errorBudget.consumed, 0);
  const totalRemaining = slos.reduce((s, slo) => s + slo.errorBudget.remaining, 0);
  const consumedPct = Math.round((totalConsumed / (slos.length * 100)) * 100);
  const remainingPct = Math.round((totalRemaining / (slos.length * 100)) * 100);
  const avgBurn = (slos.reduce((s, slo) => s + slo.errorBudget.burnRate, 0) / slos.length).toFixed(2);

  // Sort by burn rate desc for approaching breach
  const approaching = [...slos].sort((a, b) => b.errorBudget.burnRate - a.errorBudget.burnRate).slice(0, 5);

  function exhaustionDate(burnRate: number, remaining: number): string {
    if (burnRate <= 0 || remaining <= 0) return "Exhausted";
    // Burn rate x means consuming at X times the sustainable rate. With 28d window remaining budget % gets consumed in (remaining/burnRate)/100 * 28 days
    const days = (remaining / 100) * 28 / Math.max(burnRate, 0.01);
    if (days > 365) return `${Math.round(days / 365)}y`;
    if (days > 30) return `${Math.round(days / 30)}mo`;
    return `${Math.round(days)}d`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Error Budgets"
        description="Per-SLO error budget consumption, burn rates, and time-to-exhaustion projections."
        breadcrumbs={[{ label: "Reliability", href: "/reliability/slos" }, { label: "Error Budgets" }]}
        icon={<Wallet className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Total Budget"
          value={slos.length * 100}
          unit="min"
          hint="aggregate budget units"
          icon={<Wallet className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="Consumed"
          value={`${consumedPct}%`}
          delta={4}
          deltaLabel="vs last week"
          icon={<TrendingDown className="w-4 h-4" />}
          accent={consumedPct > 50 ? "destructive" : "warning"}
        />
        <KpiCard
          label="Remaining"
          value={`${remainingPct}%`}
          delta={-4}
          deltaLabel="vs last week"
          icon={<TrendingUp className="w-4 h-4" />}
          accent="success"
        />
        <KpiCard
          label="Avg Burn Rate"
          value={`${avgBurn}x`}
          hint="across all SLOs"
          icon={<Flame className="w-4 h-4" />}
          accent={parseFloat(avgBurn) > 1 ? "destructive" : "info"}
        />
      </div>

      {/* Per-SLO horizontal bars */}
      <Card className="p-5 space-y-5">
        <SectionHeading
          title="Per-SLO Budget Consumption"
          description="Red = consumed · Green = remaining"
          action={<span className="text-xs text-muted-foreground">{slos.length} SLOs</span>}
        />
        <div className="space-y-4">
          {slos.map((slo) => {
            const svc = services.find((s) => s.id === slo.serviceId);
            const consumed = slo.errorBudget.consumed;
            const remaining = slo.errorBudget.remaining;
            const isBreached = slo.status === "breached" || slo.status === "exhausted";
            return (
              <div key={slo.id} className="space-y-1.5">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <Link href={`/reliability/slos/${slo.id}`} className="font-mono text-[11px] text-primary hover:underline">{slo.ref}</Link>
                    <span className="font-medium truncate">{slo.name}</span>
                    {svc && <TierBadge tier={svc.tier} />}
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] text-muted-foreground">Burn <span className={`font-mono font-semibold ${slo.errorBudget.burnRate > 6 ? "text-destructive" : ""}`}>{slo.errorBudget.burnRate}x</span></span>
                    <SLOStatusBadge status={slo.status} />
                  </div>
                </div>
                <div className="relative h-3 rounded-full bg-muted overflow-hidden flex">
                  <div
                    className={isBreached ? "bg-destructive" : "bg-destructive/70"}
                    style={{ width: `${Math.min(100, consumed)}%` }}
                  />
                  <div
                    className={isBreached ? "bg-destructive/20" : "bg-success"}
                    style={{ width: `${Math.min(100, remaining)}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>{svc?.name}</span>
                  <span className="tabular-nums">
                    <span className="text-destructive font-medium">{consumed}%</span> consumed · <span className="text-success font-medium">{remaining}%</span> remaining
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Approaching breach */}
        <Card className="p-5 space-y-4 border-warning/20">
          <SectionHeading
            title="Approaching Breach"
            description="Top SLOs by burn rate, projected exhaustion"
            action={<AlertTriangle className="w-4 h-4 text-warning-foreground" />}
          />
          <div className="space-y-3">
            {approaching.map((slo, idx) => {
              const svc = services.find((s) => s.id === slo.serviceId);
              const tte = exhaustionDate(slo.errorBudget.burnRate, slo.errorBudget.remaining);
              return (
                <Link
                  key={slo.id}
                  href={`/reliability/slos/${slo.id}`}
                  className="block p-3 rounded-lg border hover:bg-muted/40 transition-colors"
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="w-5 h-5 rounded-full bg-warning/20 text-warning-foreground text-[10px] font-semibold flex items-center justify-center shrink-0">{idx + 1}</span>
                      <div className="min-w-0">
                        <div className="text-xs font-medium truncate">{slo.name}</div>
                        <div className="text-[10px] text-muted-foreground">{slo.ref} · {svc?.name}</div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="flex items-center gap-1 text-destructive">
                        <Flame className="w-3 h-3" />
                        <span className="font-mono text-sm font-bold">{slo.errorBudget.burnRate}x</span>
                      </div>
                      <div className="text-[10px] text-muted-foreground">burn rate</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" /> Time to exhaustion</span>
                    <span className={`font-mono font-semibold ${tte === "Exhausted" ? "text-destructive" : "text-warning-foreground"}`}>{tte}</span>
                  </div>
                  <div className="mt-1.5 h-1 rounded-full bg-muted overflow-hidden">
                    <div
                      className={slo.errorBudget.remaining <= 0 ? "bg-destructive" : "bg-warning"}
                      style={{ width: `${Math.max(2, Math.min(100, slo.errorBudget.remaining))}%` }}
                    />
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>

        {/* Time-to-exhaustion projection */}
        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Time-to-Exhaustion Projection"
            description="Based on current burn rate sustained over 28d window"
          />
          <div className="space-y-2">
            <div className="grid grid-cols-4 gap-2 text-[10px] uppercase tracking-wider text-muted-foreground px-2">
              <span>SLO</span>
              <span className="text-right">Burn</span>
              <span className="text-right">Remaining</span>
              <span className="text-right">TTE</span>
            </div>
            {slos.map((slo) => {
              const tte = exhaustionDate(slo.errorBudget.burnRate, slo.errorBudget.remaining);
              return (
                <Link
                  key={slo.id}
                  href={`/reliability/slos/${slo.id}`}
                  className="grid grid-cols-4 gap-2 items-center px-2 py-2 rounded-md hover:bg-muted/40 transition-colors text-xs"
                >
                  <span className="font-mono truncate">{slo.ref}</span>
                  <span className={`text-right font-mono font-semibold ${slo.errorBudget.burnRate > 6 ? "text-destructive" : ""}`}>{slo.errorBudget.burnRate}x</span>
                  <span className="text-right font-mono tabular-nums">{slo.errorBudget.remaining}%</span>
                  <span className={`text-right font-mono font-semibold ${tte === "Exhausted" ? "text-destructive" : ""} flex items-center justify-end gap-0.5`}>
                    {tte === "Exhausted" && <AlertTriangle className="w-3 h-3" />}
                    {tte}
                  </span>
                </Link>
              );
            })}
          </div>
          <div className="flex items-center gap-2 pt-2 text-[10px] text-muted-foreground">
            <ArrowUpRight className="w-3 h-3" />
            Projection assumes constant burn rate; actual varies with traffic.
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
