"use client";

import * as React from "react";
import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { RightPanel } from "@/components/layout/right-panel";
import { useUIStore } from "@/lib/store";
import { allNavItems } from "@/lib/nav";
import { cn } from "@/lib/utils";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const pushRecent = useUIStore((s) => s.pushRecent);

  // Track recently visited pages
  React.useEffect(() => {
    const item = allNavItems.find((n) => n.href === pathname);
    if (item) {
      pushRecent({ href: pathname, title: item.label, visitedAt: Date.now() });
    } else {
      // Try to find parent
      const parent = allNavItems
        .filter((n) => pathname.startsWith(n.href + "/"))
        .sort((a, b) => b.href.length - a.href.length)[0];
      if (parent) {
        // Don't add detail pages to recent
      }
    }
  }, [pathname, pushRecent]);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 overflow-y-auto">
          <div className="animate-fade-up">
            {children}
          </div>
        </main>
      </div>
      <RightPanel />
    </div>
  );
}
