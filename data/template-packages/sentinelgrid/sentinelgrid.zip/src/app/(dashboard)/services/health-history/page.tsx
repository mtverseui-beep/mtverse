"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { UptimeHeatmap } from "@/components/charts";
import { TierBadge, ServiceHealthBadge } from "@/components/common/badges";
import { services, uptimeForService, incidents } from "@/lib/data";
import type { UptimeRecord } from "@/lib/types";
import { toast } from "sonner";
import {
  CalendarClock, Activity, AlertTriangle, TrendingDown, Download,
  RefreshCw, ShieldCheck,
} from "lucide-react";

export default function ServiceHealthHistoryPage() {
  const [tierFilter, setTierFilter] = React.useState<string>("all");

  const filtered = React.useMemo(() => {
    if (tierFilter === "all") return services;
    return services.filter((s) => s.tier === tierFilter);
  }, [tierFilter]);

  // Aggregate stats
  const aggregate = React.useMemo(() => {
    let totalDowntime = 0;
    let totalIncidents = 0;
    let totalUptime = 0;
    filtered.forEach((s) => {
      const records = uptimeForService(s.id, 90);
      const dt = records.reduce((sum, r) => sum + r.downtimeSeconds, 0);
      const inc = records.reduce((sum, r) => sum + r.incidents, 0);
      const avgUp = records.reduce((sum, r) => sum + r.uptime, 0) / records.length;
      totalDowntime += dt;
      totalIncidents += inc;
      totalUptime += avgUp;
    });
    return {
      totalDowntime,
      totalIncidents,
      avgUptime: filtered.length > 0 ? totalUptime / filtered.length : 0,
    };
  }, [filtered]);

  const downtimeMinutes = Math.round(aggregate.totalDowntime / 60);

  function heatmapDataFor(svcId: string): UptimeRecord[] {
    return uptimeForService(svcId, 90);
  }

  return (
    <PageContainer>
      <PageHeader
        title="Service Health History"
        description="90-day availability heatmaps for every production service. Spot chronic issues and degradation patterns."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Services", href: "/services" }, { label: "Health History" }]}
        icon={<CalendarClock className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Refreshing uptime data")}>
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Avg Uptime (90d)" value={`${aggregate.avgUptime.toFixed(3)}%`} icon={<Activity className="w-4 h-4" />} accent="success" hint="Across all filtered services" />
        <KpiCard label="Total Downtime" value={downtimeMinutes} unit="min" icon={<TrendingDown className="w-4 h-4" />} accent="warning" hint="Last 90 days" />
        <KpiCard label="Incident Days" value={aggregate.totalIncidents} icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" hint="Days with at least one incident" />
        <KpiCard label="Services Tracked" value={filtered.length} icon={<ShieldCheck className="w-4 h-4" />} accent="primary" hint={`${services.length} total`} />
      </div>

      {/* Filter */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 md:items-end">
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Tier</label>
            <Select value={tierFilter} onValueChange={setTierFilter}>
              <SelectTrigger className="w-[220px] h-9 text-xs">
                <SelectValue placeholder="All tiers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All tiers</SelectItem>
                <SelectItem value="tier1">Tier 1 (Critical)</SelectItem>
                <SelectItem value="tier2">Tier 2 (Important)</SelectItem>
                <SelectItem value="tier3">Tier 3 (Standard)</SelectItem>
                <SelectItem value="tier4">Tier 4 (Internal)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:ml-auto text-xs text-muted-foreground">
            {filtered.length} of {services.length} services
          </div>
        </div>
      </Card>

      {/* Per-service heatmaps */}
      <div className="space-y-4">
        {filtered.map((s) => {
          const records = heatmapDataFor(s.id);
          const downtimeSec = records.reduce((sum, r) => sum + r.downtimeSeconds, 0);
          const incCount = records.reduce((sum, r) => sum + r.incidents, 0);
          const avgUp = records.reduce((sum, r) => sum + r.uptime, 0) / records.length;
          const serviceIncidents = incidents.filter((i) => i.serviceIds.includes(s.id)).length;

          return (
            <div key={s.id} className="space-y-3">
              <Card className="p-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="shrink-0 w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                      <Activity className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Link href={`/services/${s.id}`} className="text-sm font-semibold hover:underline">{s.name}</Link>
                        <TierBadge tier={s.tier} />
                        <ServiceHealthBadge health={s.health} />
                      </div>
                      <p className="text-[11px] text-muted-foreground line-clamp-1">{s.description}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3 shrink-0">
                    <div className="text-right">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Avg Uptime</p>
                      <p className={`text-sm font-semibold tabular-nums ${avgUp >= 99.95 ? "text-success" : avgUp >= 99 ? "text-warning-foreground" : "text-destructive"}`}>
                        {avgUp.toFixed(3)}%
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Downtime</p>
                      <p className="text-sm font-semibold tabular-nums">{Math.round(downtimeSec / 60)}m</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Incidents</p>
                      <p className="text-sm font-semibold tabular-nums">{serviceIncidents || incCount}</p>
                    </div>
                  </div>
                </div>
              </Card>

              <UptimeHeatmap
                data={records.map((r) => ({ date: r.date, uptime: r.uptime, incidents: r.incidents }))}
                title={`${s.name} - 90-Day Availability`}
                description="Daily uptime % - hover a cell for details"
              />
            </div>
          );
        })}
      </div>
    </PageContainer>
  );
}
