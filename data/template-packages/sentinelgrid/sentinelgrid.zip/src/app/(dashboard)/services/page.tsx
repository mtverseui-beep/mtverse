"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { ServiceHealthBadge, TierBadge, StatusDot } from "@/components/common/badges";
import { services, teams, people } from "@/lib/data";
import type { Service } from "@/lib/types";
import { toast } from "sonner";
import {
  Server, ShieldCheck, AlertTriangle, Gauge, Download, Plus,
} from "lucide-react";

export default function ServicesCatalogPage() {
  const router = useRouter();

  const operational = services.filter((s) => s.health === "operational").length;
  const degraded = services.filter((s) => s.health === "degraded" || s.health === "partial" || s.health === "major").length;
  const avgHealth = Math.round(services.reduce((s, x) => s + x.healthScore, 0) / services.length);

  function ownerOf(s: Service) {
    return people.find((p) => p.id === s.ownerId);
  }
  function teamOf(s: Service) {
    return teams.find((t) => t.id === s.teamId);
  }

  const columns: Column<Service>[] = [
    {
      key: "name",
      header: "Service",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium truncate">{r.name}</span>
            <TierBadge tier={r.tier} />
          </div>
          <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{r.description}</p>
        </div>
      ),
    },
    {
      key: "health",
      header: "Health",
      sortable: true,
      filterable: true,
      sortValue: (r) => r.healthScore,
      filterOptions: [
        { label: "Operational", value: "operational" },
        { label: "Degraded", value: "degraded" },
        { label: "Partial Outage", value: "partial" },
        { label: "Major Outage", value: "major" },
        { label: "Maintenance", value: "maintenance" },
      ],
      filterFn: (r, v) => r.health === v,
      cell: (r) => <ServiceHealthBadge health={r.health} />,
    },
    {
      key: "team",
      header: "Team",
      hideOnMobile: true,
      cell: (r) => {
        const t = teamOf(r);
        return t ? (
          <span className="inline-flex items-center gap-1.5 text-xs">
            <span className="w-2 h-2 rounded-full" style={{ background: t.color }} />
            {t.name}
          </span>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
    },
    {
      key: "owner",
      header: "Owner",
      hideOnMobile: true,
      cell: (r) => {
        const o = ownerOf(r);
        if (!o) return <span className="text-xs text-muted-foreground">—</span>;
        return (
          <div className="flex items-center gap-1.5">
            <img src={o.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate">{o.name}</span>
          </div>
        );
      },
    },
    {
      key: "p95",
      header: "p95",
      sortable: true,
      align: "right",
      hideOnMobile: true,
      sortValue: (r) => r.p95LatencyMs,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.p95LatencyMs > 200 ? "text-warning-foreground" : r.p95LatencyMs > 100 ? "text-info-foreground" : "text-success"}`}>
          {r.p95LatencyMs}ms
        </span>
      ),
    },
    {
      key: "errorRate",
      header: "Error Rate",
      sortable: true,
      align: "right",
      hideOnMobile: true,
      sortValue: (r) => r.errorRate,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.errorRate > 1 ? "text-destructive" : r.errorRate > 0.1 ? "text-warning-foreground" : "text-success"}`}>
          {r.errorRate.toFixed(3)}%
        </span>
      ),
    },
    {
      key: "uptime30d",
      header: "Uptime 30d",
      sortable: true,
      align: "right",
      sortValue: (r) => r.uptime30d,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.uptime30d >= 99.95 ? "text-success" : r.uptime30d >= 99.5 ? "text-warning-foreground" : "text-destructive"}`}>
          {r.uptime30d.toFixed(3)}%
        </span>
      ),
    },
    {
      key: "openAlerts",
      header: "Alerts",
      sortable: true,
      align: "right",
      hideOnMobile: true,
      sortValue: (r) => r.openAlerts,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.openAlerts > 4 ? "text-destructive" : r.openAlerts > 0 ? "text-warning-foreground" : "text-muted-foreground"}`}>
          {r.openAlerts}
        </span>
      ),
    },
    {
      key: "openIncidents",
      header: "Incidents",
      sortable: true,
      align: "right",
      hideOnMobile: true,
      sortValue: (r) => r.openIncidents,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.openIncidents > 0 ? "text-destructive" : "text-muted-foreground"}`}>
          {r.openIncidents}
        </span>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Services Catalog"
        description="Full inventory of production services with reliability, ownership, and alert posture."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Services" }]}
        icon={<Server className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening register form")}>
              <Plus className="w-3.5 h-3.5" /> Register Service
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Services" value={services.length} hint="Production" icon={<Server className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Operational" value={operational} hint={`${Math.round((operational / services.length) * 100)}% of fleet`} icon={<ShieldCheck className="w-4 h-4" />} accent="success" />
        <KpiCard label="Degraded / Outage" value={degraded} hint="Needs attention" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Avg Health Score" value={avgHealth} unit="/100" hint="Fleet-wide weighted" icon={<Gauge className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading
          title="Service Catalog"
          description="Click a row to view full service details, SLOs, dependencies, and recent activity."
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={services}
            rowKey={(r) => r.id}
            searchKeys={["name", "description", "slug"]}
            searchPlaceholder="Search by name or description..."
            pageSize={10}
            initialSort={{ key: "health", dir: "asc" }}
            onRowClick={(r) => router.push(`/services/${r.id}`)}
            mobileCard={(r) => (
              <Card className="p-3 cursor-pointer hover:bg-muted/40">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{r.name}</span>
                      <TierBadge tier={r.tier} />
                    </div>
                    <p className="text-[11px] text-muted-foreground line-clamp-1">{r.description}</p>
                  </div>
                  <ServiceHealthBadge health={r.health} />
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px] mt-2">
                  <div>
                    <p className="text-muted-foreground">p95</p>
                    <p className="font-medium tabular-nums">{r.p95LatencyMs}ms</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Errors</p>
                    <p className="font-medium tabular-nums">{r.errorRate.toFixed(2)}%</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Uptime</p>
                    <p className="font-medium tabular-nums">{r.uptime30d.toFixed(2)}%</p>
                  </div>
                </div>
              </Card>
            )}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
