"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  LatencyChart, ErrorRateChart, VolumeChart, LineChartCard,
  ComposedChartCard, DonutChart,
} from "@/components/charts";
import { ServiceHealthBadge, TierBadge } from "@/components/common/badges";
import { services, timeSeries, multiTimeSeries } from "@/lib/data";
import type { Service } from "@/lib/types";
import { toast } from "sonner";
import {
  Gauge, Activity, Zap, Clock, Cpu, MemoryStick, Database,
  Download, GitCompareArrows, TrendingUp, AlertTriangle,
  BarChart3,
} from "lucide-react";

const timeRanges = [
  { label: "1h", value: "1h" },
  { label: "6h", value: "6h" },
  { label: "24h", value: "24h" },
  { label: "7d", value: "7d" },
  { label: "30d", value: "30d" },
];

export default function ServiceMetricsExplorerPage() {
  const [serviceId, setServiceId] = React.useState<string>(services[0].id);
  const [compareId, setCompareId] = React.useState<string>("none");
  const [timeRange, setTimeRange] = React.useState<string>("24h");
  const [compareEnabled, setCompareEnabled] = React.useState(false);

  const svc = services.find((s) => s.id === serviceId) || services[0];
  const compareSvc = compareEnabled && compareId !== "none" ? services.find((s) => s.id === compareId) : null;

  // Build chart data based on selected service
  const points = timeRange === "1h" ? 12 : timeRange === "6h" ? 24 : timeRange === "24h" ? 24 : timeRange === "7d" ? 28 : 30;
  const latencyData = multiTimeSeries(2, points, [
    { name: "p50", base: svc.p95LatencyMs * 0.4, variance: svc.p95LatencyMs * 0.1 },
    { name: "p95", base: svc.p95LatencyMs, variance: svc.p95LatencyMs * 0.2 },
    { name: "p99", base: svc.p95LatencyMs * 1.6, variance: svc.p95LatencyMs * 0.4 },
  ]).map((d) => ({ timestamp: String(d.date), p50: Number(d.p50), p95: Number(d.p95), p99: Number(d.p99) }));

  const errorData = timeSeries(5, points, svc.errorRate, svc.errorRate * 0.5).map((d) => ({ timestamp: String(d.date), value: d.value }));
  const volumeData = timeSeries(3, points, svc.requestsPerSecond, svc.requestsPerSecond * 0.2).map((d) => ({ timestamp: String(d.date), value: d.value }));

  // Throughput composed: bars (rps) + line (p95)
  const composedThroughput = multiTimeSeries(7, points, [
    { name: "rps", base: svc.requestsPerSecond, variance: svc.requestsPerSecond * 0.2 },
    { name: "p95", base: svc.p95LatencyMs, variance: svc.p95LatencyMs * 0.2 },
  ]).map((d) => ({ date: d.date, rps: Number(d.rps), p95: Number(d.p95) }));

  // Cache hit ratio + saturation
  const cacheData = timeSeries(11, points, 94, 4).map((d) => ({ timestamp: String(d.date), value: d.value }));
  const cpuData = multiTimeSeries(13, points, [
    { name: "cpu", base: 42, variance: 15 },
    { name: "mem", base: 58, variance: 12 },
  ]).map((d) => ({ date: d.date, cpu: Number(d.cpu), mem: Number(d.mem) }));

  // Compare mode
  const compareLatency = compareSvc ? multiTimeSeries(99, points, [
    { name: "p95", base: compareSvc.p95LatencyMs, variance: compareSvc.p95LatencyMs * 0.2 },
  ]).map((d) => ({ date: d.date, p95: Number(d.p95) })) : [];
  const combinedLatency = latencyData.map((d, i) => ({
    timestamp: d.timestamp,
    primary: d.p95,
    compare: compareLatency[i]?.p95 ?? 0,
  }));

  // Metric tiles
  const metrics = [
    { label: "RPS", value: svc.requestsPerSecond.toLocaleString(), icon: <Zap className="w-4 h-4" />, accent: "primary" as const, hint: "Requests/sec" },
    { label: "p50", value: `${Math.round(svc.p95LatencyMs * 0.4)}ms`, icon: <Clock className="w-4 h-4" />, accent: "info" as const, hint: "Median" },
    { label: "p95", value: `${svc.p95LatencyMs}ms`, icon: <Gauge className="w-4 h-4" />, accent: "primary" as const, hint: "95th percentile" },
    { label: "p99", value: `${Math.round(svc.p95LatencyMs * 1.6)}ms`, icon: <Gauge className="w-4 h-4" />, accent: "warning" as const, hint: "99th percentile" },
    { label: "Error Rate", value: `${svc.errorRate.toFixed(3)}%`, icon: <AlertTriangle className="w-4 h-4" />, accent: svc.errorRate > 1 ? "destructive" as const : "success" as const, hint: "Last 5m" },
    { label: "Cache Hit", value: "94.2%", icon: <Database className="w-4 h-4" />, accent: "success" as const, hint: "Hit ratio" },
    { label: "CPU", value: "42%", icon: <Cpu className="w-4 h-4" />, accent: "info" as const, hint: "Avg usage" },
    { label: "Memory", value: "58%", icon: <MemoryStick className="w-4 h-4" />, accent: "info" as const, hint: "Avg usage" },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Service Metrics Explorer"
        description="Cross-service metrics explorer with multi-metric grid, time-range selection, and side-by-side comparison."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Services", href: "/services" }, { label: "Metrics Explorer" }]}
        icon={<BarChart3 className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Saved as dashboard view")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Save View</span>
            </Button>
          </>
        }
      />

      {/* Service selector + controls */}
      <Card className="p-4">
        <div className="flex flex-col lg:flex-row gap-3 lg:items-end">
          <div className="space-y-1.5 flex-1 min-w-0">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Primary Service</label>
            <Select value={serviceId} onValueChange={setServiceId}>
              <SelectTrigger className="w-full lg:w-[280px] h-9 text-xs">
                <SelectValue placeholder="Select service" />
              </SelectTrigger>
              <SelectContent>
                {services.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name} ({s.tier})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Time Range</label>
            <div className="inline-flex rounded-md border border-border overflow-hidden">
              {timeRanges.map((tr) => (
                <button
                  key={tr.value}
                  onClick={() => setTimeRange(tr.value)}
                  className={`px-3 py-1.5 text-xs font-medium transition-colors ${
                    timeRange === tr.value ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted/50"
                  }`}
                >
                  {tr.label}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Compare</label>
            <Button
              variant={compareEnabled ? "default" : "outline"}
              size="sm"
              className="gap-1.5 h-9"
              onClick={() => {
                setCompareEnabled(!compareEnabled);
                if (!compareEnabled) toast.info("Compare mode enabled");
              }}
            >
              <GitCompareArrows className="w-3.5 h-3.5" />
              {compareEnabled ? "Comparing" : "Compare"}
            </Button>
          </div>
          {compareEnabled && (
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Compare With</label>
              <Select value={compareId} onValueChange={setCompareId}>
                <SelectTrigger className="w-[220px] h-9 text-xs">
                  <SelectValue placeholder="Select service" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {services.filter((s) => s.id !== serviceId).map((s) => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {/* Active service header */}
        <div className="mt-4 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">{svc.name}</span>
            <TierBadge tier={svc.tier} />
            <ServiceHealthBadge health={svc.health} />
          </div>
          {compareSvc && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">vs</span>
              <span className="text-sm font-medium">{compareSvc.name}</span>
              <TierBadge tier={compareSvc.tier} />
            </div>
          )}
        </div>
      </Card>

      {/* Metric tiles grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        {metrics.map((m, i) => (
          <Card key={i} className="p-3 space-y-1.5">
            <div className="flex items-center justify-between">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold truncate">{m.label}</p>
              <div className={`shrink-0 w-6 h-6 rounded-md flex items-center justify-center ${
                m.accent === "primary" ? "bg-primary/10 text-primary"
                : m.accent === "destructive" ? "bg-destructive/10 text-destructive"
                : m.accent === "success" ? "bg-success/10 text-success"
                : m.accent === "warning" ? "bg-warning/10 text-warning-foreground"
                : "bg-info/10 text-info-foreground"
              }`}>{m.icon}</div>
            </div>
            <p className="text-lg font-semibold tabular-nums">{m.value}</p>
            <p className="text-[10px] text-muted-foreground truncate">{m.hint}</p>
          </Card>
        ))}
      </div>

      {/* KPI summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Throughput" value={svc.requestsPerSecond.toLocaleString()} unit="rps" icon={<Zap className="w-4 h-4" />} accent="primary" hint="Avg over time range" />
        <KpiCard label="Peak p99" value={`${Math.round(svc.p95LatencyMs * 1.6)}ms`} icon={<Gauge className="w-4 h-4" />} accent="warning" hint="Tail latency" />
        <KpiCard label="Error Budget" value="86%" icon={<TrendingUp className="w-4 h-4" />} accent="success" hint="Remaining for 28d" />
        <KpiCard label="Saturation" value="42%" icon={<Cpu className="w-4 h-4" />} accent="info" hint="CPU weighted" />
      </div>

      {/* Charts grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <LatencyChart data={latencyData} title="Latency Percentiles" description={`p50, p95, p99 over ${timeRange}`} />
        <ErrorRateChart data={errorData} title="Error Rate" description={`Error percentage over ${timeRange}`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <VolumeChart data={volumeData} title="Request Volume" description={`Requests per minute over ${timeRange}`} unit=" rpm" />
        <ComposedChartCard
          data={composedThroughput}
          bars={[{ key: "rps", name: "Throughput (rps)", color: 0 }]}
          lines={[{ key: "p95", name: "p95 Latency (ms)", color: 2 }]}
          title="Throughput vs Latency"
          description="Correlation between request volume and p95"
        />
      </div>

      {/* Comparison view */}
      {compareEnabled && compareSvc && (
        <Card className="p-4">
          <SectionHeading
            title={`Side-by-Side Comparison: ${svc.name} vs ${compareSvc.name}`}
            description="p95 latency comparison over selected time range"
            action={<Badge variant="outline" className="text-xs">{timeRange}</Badge>}
          />
          <div className="mt-4 h-[280px]">
            <LineChartCard
              data={combinedLatency}
              dataKey="primary"
              color={0}
              height={280}
            />
          </div>
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-border">
            <div className="rounded-md border border-border p-3">
              <p className="text-[10px] uppercase text-muted-foreground">p95 Latency Diff</p>
              <p className={`text-sm font-semibold tabular-nums ${compareSvc.p95LatencyMs > svc.p95LatencyMs ? "text-success" : "text-destructive"}`}>
                {compareSvc.p95LatencyMs > svc.p95LatencyMs ? "+" : ""}{compareSvc.p95LatencyMs - svc.p95LatencyMs}ms
              </p>
              <p className="text-[10px] text-muted-foreground">vs {compareSvc.name}</p>
            </div>
            <div className="rounded-md border border-border p-3">
              <p className="text-[10px] uppercase text-muted-foreground">Error Rate Diff</p>
              <p className={`text-sm font-semibold tabular-nums ${compareSvc.errorRate > svc.errorRate ? "text-success" : "text-destructive"}`}>
                {compareSvc.errorRate > svc.errorRate ? "+" : ""}{(compareSvc.errorRate - svc.errorRate).toFixed(3)}%
              </p>
              <p className="text-[10px] text-muted-foreground">vs {compareSvc.name}</p>
            </div>
            <div className="rounded-md border border-border p-3">
              <p className="text-[10px] uppercase text-muted-foreground">Throughput Diff</p>
              <p className={`text-sm font-semibold tabular-nums ${compareSvc.requestsPerSecond > svc.requestsPerSecond ? "text-success" : "text-destructive"}`}>
                {compareSvc.requestsPerSecond > svc.requestsPerSecond ? "+" : ""}{(compareSvc.requestsPerSecond - svc.requestsPerSecond).toLocaleString()} rps
              </p>
              <p className="text-[10px] text-muted-foreground">vs {compareSvc.name}</p>
            </div>
            <div className="rounded-md border border-border p-3">
              <p className="text-[10px] uppercase text-muted-foreground">Uptime Diff</p>
              <p className={`text-sm font-semibold tabular-nums ${compareSvc.uptime30d > svc.uptime30d ? "text-success" : "text-destructive"}`}>
                {compareSvc.uptime30d > svc.uptime30d ? "+" : ""}{(compareSvc.uptime30d - svc.uptime30d).toFixed(3)}%
              </p>
              <p className="text-[10px] text-muted-foreground">vs {compareSvc.name}</p>
            </div>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <LineChartCard data={cacheData} dataKey="value" title="Cache Hit Ratio" description={`Redis cluster hit % over ${timeRange}`} suffix="%" color={3} height={260} />
        <ComposedChartCard
          data={cpuData}
          bars={[]}
          lines={[
            { key: "cpu", name: "CPU %", color: 0 },
            { key: "mem", name: "Memory %", color: 1 },
          ]}
          title="CPU & Memory Saturation"
          description={`Average utilization across fleet over ${timeRange}`}
          suffix="%"
        />
      </div>
    </PageContainer>
  );
}
