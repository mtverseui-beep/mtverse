"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { TierBadge, ServiceHealthBadge, StatusDot } from "@/components/common/badges";
import { services, teams, people } from "@/lib/data";
import { toast } from "sonner";
import {
  Grid3x3, Users, UserX, UserCheck, ShieldCheck, Download,
  Server, AlertCircle,
} from "lucide-react";

export default function ServiceOwnershipPage() {
  const [teamFilter, setTeamFilter] = React.useState<string>("all");

  // Determine orphan services (no team owner)
  const orphanServices = services.filter((s) => !teams.find((t) => t.id === s.teamId));

  // Filtered teams
  const filteredTeams = teamFilter === "all" ? teams : teams.filter((t) => t.id === teamFilter);

  // Services per team count (for KPI)
  const servicesWithOwner = services.length - orphanServices.length;
  const totalServices = services.length;
  const coveragePct = Math.round((servicesWithOwner / totalServices) * 100);

  return (
    <PageContainer>
      <PageHeader
        title="Service Ownership Matrix"
        description="Team-by-service ownership grid with orphan detection. Click a team to drill into its services."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Services", href: "/services" }, { label: "Ownership" }]}
        icon={<Grid3x3 className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Export Matrix</span>
          </Button>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Services" value={totalServices} icon={<Server className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Owning Teams" value={teams.length} icon={<Users className="w-4 h-4" />} accent="info" />
        <KpiCard label="Ownership Coverage" value={`${coveragePct}%`} hint={`${servicesWithOwner}/${totalServices} owned`} icon={<UserCheck className="w-4 h-4" />} accent="success" />
        <KpiCard label="Orphan Services" value={orphanServices.length} hint="No team assigned" icon={<UserX className="w-4 h-4" />} accent={orphanServices.length > 0 ? "destructive" : "muted"} />
      </div>

      {/* Filter */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 md:items-end">
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Filter by team</label>
            <Select value={teamFilter} onValueChange={setTeamFilter}>
              <SelectTrigger className="w-[260px] h-9 text-xs">
                <SelectValue placeholder="All teams" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All teams</SelectItem>
                {teams.map((t) => (
                  <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="md:ml-auto text-xs text-muted-foreground">
            {filteredTeams.length} team{filteredTeams.length !== 1 ? "s" : ""} - {filteredTeams.reduce((s, t) => s + t.servicesOwned.length, 0)} services
          </div>
        </div>
      </Card>

      {/* Ownership matrix grid */}
      <Card className="p-4">
        <SectionHeading
          title="Team x Service Matrix"
          description="Each card represents a team and its owned services. Click a team card to view team details."
        />
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTeams.map((team) => {
            const lead = people.find((p) => p.id === team.leadId);
            const teamServices = services.filter((s) => team.servicesOwned.includes(s.id));
            const tier1Count = teamServices.filter((s) => s.tier === "tier1").length;
            const operational = teamServices.filter((s) => s.health === "operational").length;
            const degraded = teamServices.filter((s) => s.health !== "operational").length;
            return (
              <Card key={team.id} className="p-4 space-y-3 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5 min-w-0">
                    <div className="shrink-0 w-9 h-9 rounded-lg flex items-center justify-center border" style={{ background: `${team.color}20`, borderColor: `${team.color}50`, color: team.color }}>
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 space-y-0.5">
                      <p className="text-sm font-semibold truncate">{team.name}</p>
                      <p className="text-[11px] text-muted-foreground truncate">{lead?.name} - Lead</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[10px] shrink-0">
                    {teamServices.length} svc
                  </Badge>
                </div>

                <p className="text-[11px] text-muted-foreground line-clamp-2">{team.description}</p>

                {/* Stats row */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-md border border-border p-2">
                    <p className="text-sm font-semibold tabular-nums text-primary">{tier1Count}</p>
                    <p className="text-[10px] text-muted-foreground">Tier 1</p>
                  </div>
                  <div className="rounded-md border border-border p-2">
                    <p className="text-sm font-semibold tabular-nums text-success">{operational}</p>
                    <p className="text-[10px] text-muted-foreground">Healthy</p>
                  </div>
                  <div className="rounded-md border border-border p-2">
                    <p className={`text-sm font-semibold tabular-nums ${degraded > 0 ? "text-destructive" : "text-muted-foreground"}`}>{degraded}</p>
                    <p className="text-[10px] text-muted-foreground">At risk</p>
                  </div>
                </div>

                {/* Services list */}
                <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
                  {teamServices.map((s) => (
                    <Link key={s.id} href={`/services/${s.id}`} className="flex items-center justify-between gap-2 rounded-md border border-border px-2 py-1.5 hover:bg-muted/40 transition-colors">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <StatusDot color={s.health === "operational" ? "success" : s.health === "degraded" ? "warning" : "destructive"} />
                        <span className="text-xs truncate">{s.name}</span>
                      </div>
                      <TierBadge tier={s.tier} />
                    </Link>
                  ))}
                  {teamServices.length === 0 && (
                    <p className="text-[11px] text-muted-foreground text-center py-2">No services owned</p>
                  )}
                </div>

                <div className="pt-2 border-t border-border">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-1.5">Members ({team.memberIds.length})</p>
                  <div className="flex -space-x-1.5">
                    {team.memberIds.slice(0, 5).map((mid) => {
                      const m = people.find((p) => p.id === mid);
                      return m ? (
                        <img key={mid} src={m.avatarUrl} alt={m.name} title={m.name} className="w-6 h-6 rounded-full object-cover border-2 border-card" />
                      ) : null;
                    })}
                    {team.memberIds.length > 5 && (
                      <div className="w-6 h-6 rounded-full bg-muted border-2 border-card flex items-center justify-center text-[9px] font-semibold">
                        +{team.memberIds.length - 5}
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </Card>

      {/* Orphan services */}
      <Card className="p-4">
        <SectionHeading
          title="Orphan Services"
          description="Services without an assigned owning team - high operational risk"
          action={<AlertCircle className="w-4 h-4 text-muted-foreground" />}
        />
        {orphanServices.length === 0 ? (
          <div className="mt-4">
            <EmptyState
              icon={<UserCheck className="w-5 h-5" />}
              title="No orphan services"
              description="All production services have a clear owning team."
            />
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {orphanServices.map((s) => (
              <Card key={s.id} className="p-3 border-destructive/30">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-medium">{s.name}</span>
                  <TierBadge tier={s.tier} />
                </div>
                <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">{s.description}</p>
                <div className="mt-2 flex items-center justify-between">
                  <ServiceHealthBadge health={s.health} />
                  <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => toast.success(`Assigning owner for ${s.name}`)}>
                    Assign owner
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </Card>
    </PageContainer>
  );
}
