"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ServiceHealthBadge, TierBadge, StatusDot } from "@/components/common/badges";
import { services, teams } from "@/lib/data";
import type { Service } from "@/lib/types";
import { toast } from "sonner";
import {
  Network, GitFork, AlertTriangle, ShieldCheck, Download,
  ArrowRight, ArrowUpRight, ArrowDownRight, Zap,
} from "lucide-react";

export default function ServiceDependencyMapPage() {
  const [serviceFilter, setServiceFilter] = React.useState<string>("all");
  const [teamFilter, setTeamFilter] = React.useState<string>("all");
  const [focusService, setFocusService] = React.useState<string | null>(null);

  const filtered = React.useMemo(() => {
    let r = services;
    if (teamFilter !== "all") r = r.filter((s) => s.teamId === teamFilter);
    if (serviceFilter !== "all") r = r.filter((s) => s.id === serviceFilter);
    return r;
  }, [serviceFilter, teamFilter]);

  // Build dependency edges
  const visibleIds = new Set(filtered.map((s) => s.id));
  const edges: { from: string; to: string }[] = [];
  services.forEach((s) => {
    s.dependencies.forEach((d) => {
      if (visibleIds.has(s.id) && visibleIds.has(d)) {
        edges.push({ from: s.id, to: d });
      }
    });
  });

  // Risk metrics: most dependencies and most dependents
  const mostDeps = [...services].sort((a, b) => b.dependencies.length - a.dependencies.length).slice(0, 5);
  const mostDependents = [...services].sort((a, b) => b.dependents.length - a.dependents.length).slice(0, 5);

  // Build column layout for the graph - simple topological-ish by tier
  function tierOrder(t: string) {
    return { tier1: 0, tier2: 1, tier3: 2, tier4: 3 }[t] ?? 4;
  }
  const byTier: Record<number, Service[]> = { 0: [], 1: [], 2: [], 3: [] };
  filtered.forEach((s) => {
    const t = tierOrder(s.tier);
    if (!byTier[t]) byTier[t] = [];
    byTier[t].push(s);
  });

  // SVG dimensions
  const cardW = 200;
  const cardH = 60;
  const colGap = 80;
  const rowGap = 30;
  const cols = [byTier[0], byTier[1], byTier[2], byTier[3]].filter((c) => c.length > 0);
  const colCount = cols.length;
  const maxRows = Math.max(...cols.map((c) => c.length), 1);
  const svgW = colCount * cardW + (colCount - 1) * colGap + 40;
  const svgH = maxRows * cardH + (maxRows - 1) * rowGap + 40;

  // Compute positions
  const positions: Record<string, { x: number; y: number; col: number; row: number }> = {};
  cols.forEach((col, ci) => {
    col.forEach((s, ri) => {
      const x = 20 + ci * (cardW + colGap);
      const y = 20 + ri * (cardH + rowGap);
      positions[s.id] = { x, y, col: ci, row: ri };
    });
  });

  function edgePath(fromId: string, toId: string) {
    const f = positions[fromId];
    const t = positions[toId];
    if (!f || !t) return "";
    const x1 = f.x + cardW;
    const y1 = f.y + cardH / 2;
    const x2 = t.x;
    const y2 = t.y + cardH / 2;
    const midX = (x1 + x2) / 2;
    return `M${x1},${y1} C${midX},${y1} ${midX},${y2} ${x2},${y2}`;
  }

  function isFocusRelated(svcId: string) {
    if (!focusService) return true;
    const focus = services.find((s) => s.id === focusService);
    if (!focus) return true;
    if (svcId === focusService) return true;
    if (focus.dependencies.includes(svcId)) return true;
    if (focus.dependents.includes(svcId)) return true;
    return false;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Service Dependency Map"
        description="Visual map of upstream and downstream service dependencies. Identify blast radius and single points of failure."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Services", href: "/services" }, { label: "Dependencies" }]}
        icon={<Network className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Refreshing topology")}>
              <Zap className="w-3.5 h-3.5" /> Refresh
            </Button>
          </>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Services Mapped" value={services.length} icon={<Network className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Dependency Edges" value={services.reduce((s, x) => s + x.dependencies.length, 0)} icon={<GitFork className="w-4 h-4" />} accent="info" />
        <KpiCard label="Single Points of Failure" value={services.filter((s) => s.dependents.length > 3 && s.dependencies.length === 0).length} icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" hint="No deps, many dependents" />
        <KpiCard label="Tier 1 Services" value={services.filter((s) => s.tier === "tier1").length} icon={<ShieldCheck className="w-4 h-4" />} accent="success" />
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 md:items-end">
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Service</label>
            <Select value={serviceFilter} onValueChange={setServiceFilter}>
              <SelectTrigger className="w-[220px] h-9 text-xs">
                <SelectValue placeholder="All services" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All services</SelectItem>
                {services.map((s) => (
                  <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Team</label>
            <Select value={teamFilter} onValueChange={setTeamFilter}>
              <SelectTrigger className="w-[220px] h-9 text-xs">
                <SelectValue placeholder="All teams" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All teams</SelectItem>
                {teams.map((t) => (
                  <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="md:ml-auto text-xs text-muted-foreground">
            {filtered.length} services - {edges.length} edges
          </div>
        </div>
      </Card>

      {/* Dependency graph */}
      <Card className="p-4">
        <SectionHeading
          title="Dependency Topology"
          description="Left-to-right flow by tier. Arrows point from dependent (downstream) to dependency (upstream). Click a card to focus its connections."
          action={
            focusService && (
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setFocusService(null)}>
                Clear focus
              </Button>
            )
          }
        />
        <div className="mt-4 overflow-x-auto">
          {filtered.length === 0 ? (
            <EmptyState icon={<Network className="w-5 h-5" />} title="No services match filters" description="Adjust your filters to see the dependency graph." />
          ) : (
            <svg width={svgW} height={svgH} className="min-w-full" style={{ minWidth: svgW }}>
              {/* Tier column headers */}
              {cols.map((col, ci) => {
                const tierLabel = col[0]?.tier ?? "tier3";
                const x = 20 + ci * (cardW + colGap) + cardW / 2;
                return (
                  <text key={ci} x={x} y={12} textAnchor="middle" className="fill-muted-foreground" style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>
                    {tierLabel}
                  </text>
                );
              })}

              {/* Edges */}
              {edges.map((e, i) => {
                const path = edgePath(e.from, e.to);
                if (!path) return null;
                const highlight = focusService ? (e.from === focusService || e.to === focusService) : false;
                return (
                  <path
                    key={i}
                    d={path}
                    fill="none"
                    stroke={highlight ? "var(--primary)" : "currentColor"}
                    strokeOpacity={highlight ? 0.9 : focusService ? 0.1 : 0.3}
                    strokeWidth={highlight ? 2 : 1}
                    className="text-muted-foreground"
                    markerEnd="url(#arrow)"
                  />
                );
              })}

              {/* Arrow marker */}
              <defs>
                <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M0,0 L10,5 L0,10 z" fill="currentColor" className="text-muted-foreground" />
                </marker>
              </defs>

              {/* Service nodes */}
              {filtered.map((s) => {
                const pos = positions[s.id];
                if (!pos) return null;
                const team = teams.find((t) => t.id === s.teamId);
                const isFocus = focusService === s.id;
                const related = isFocusRelated(s.id);
                const dim = focusService && !related ? 0.3 : 1;
                return (
                  <g
                    key={s.id}
                    transform={`translate(${pos.x},${pos.y})`}
                    style={{ cursor: "pointer", opacity: dim }}
                    onClick={() => {
                      if (focusService === s.id) {
                        setFocusService(null);
                      } else {
                        setFocusService(s.id);
                        toast.info(`Focused on ${s.name}`, { description: `${s.dependencies.length} deps - ${s.dependents.length} dependents` });
                      }
                    }}
                  >
                    <foreignObject width={cardW} height={cardH}>
                      <div
                        className={`w-full h-full rounded-lg border p-2 transition-colors ${
                          isFocus ? "border-primary bg-primary/10" : "border-border bg-card hover:border-primary/40"
                        }`}
                        style={{ boxSizing: "border-box" }}
                      >
                        <div className="flex items-start justify-between gap-1">
                          <span className="text-xs font-medium truncate flex-1">{s.name}</span>
                          <TierBadge tier={s.tier} />
                        </div>
                        <div className="flex items-center gap-1.5 mt-1">
                          <StatusDot color={s.health === "operational" ? "success" : s.health === "degraded" ? "warning" : "destructive"} />
                          <span className="w-2 h-2 rounded-full shrink-0" style={{ background: team?.color }} />
                          <span className="text-[10px] text-muted-foreground truncate">{team?.name}</span>
                        </div>
                        <div className="flex items-center justify-between mt-1 text-[10px] text-muted-foreground">
                          <span className="inline-flex items-center gap-0.5">
                            <ArrowUpRight className="w-2.5 h-2.5" />
                            {s.dependencies.length}
                          </span>
                          <span className="inline-flex items-center gap-0.5">
                            <ArrowDownRight className="w-2.5 h-2.5" />
                            {s.dependents.length}
                          </span>
                        </div>
                      </div>
                    </foreignObject>
                  </g>
                );
              })}
            </svg>
          )}
        </div>
        <div className="mt-3 flex items-center gap-4 text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <ArrowRight className="w-3 h-3" /> depends on
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-success" /> operational
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-warning" /> degraded
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-destructive" /> outage
          </span>
        </div>
      </Card>

      {/* Risk summary - two columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <SectionHeading
            title="Most Dependencies"
            description="Services with the largest upstream surface area"
            action={<ArrowUpRight className="w-4 h-4 text-primary" />}
          />
          <div className="mt-3 space-y-2">
            {mostDeps.map((s, i) => {
              const team = teams.find((t) => t.id === s.teamId);
              return (
                <Link key={s.id} href={`/services/${s.id}`} className="block rounded-lg border border-border p-3 hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono text-muted-foreground">#{i + 1}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium">{s.name}</p>
                      <p className="text-[11px] text-muted-foreground truncate">{team?.name}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-semibold tabular-nums text-primary">{s.dependencies.length}</p>
                      <p className="text-[10px] text-muted-foreground">deps</p>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>
        <Card className="p-4">
          <SectionHeading
            title="Most Dependents"
            description="Highest blast radius - failure impacts most other services"
            action={<AlertTriangle className="w-4 h-4 text-destructive" />}
          />
          <div className="mt-3 space-y-2">
            {mostDependents.map((s, i) => {
              const team = teams.find((t) => t.id === s.teamId);
              return (
                <Link key={s.id} href={`/services/${s.id}`} className="block rounded-lg border border-border p-3 hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono text-muted-foreground">#{i + 1}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium">{s.name}</p>
                      <p className="text-[11px] text-muted-foreground truncate">{team?.name}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className={`text-sm font-semibold tabular-nums ${s.dependents.length > 3 ? "text-destructive" : "text-warning-foreground"}`}>{s.dependents.length}</p>
                      <p className="text-[10px] text-muted-foreground">dependents</p>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
