"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  DeploymentStatusBadge, TierBadge, ServiceHealthBadge, StatusDot,
} from "@/components/common/badges";
import { deployments, services, people, incidents } from "@/lib/data";
import type { Deployment } from "@/lib/types";
import { toast } from "sonner";
import {
  Rocket, GitBranch, CheckCircle2, XCircle, AlertTriangle,
  Download, Activity, Clock, TrendingUp, ArrowUpRight, ArrowDownRight,
  GitCommit, History, Gauge, Server, Zap,
} from "lucide-react";

export default function ServiceDeploymentsPage() {
  const [serviceId, setServiceId] = React.useState<string>(services[0].id);

  const svc = services.find((s) => s.id === serviceId) || services[0];
  const svcDeployments = deployments.filter((d) => d.serviceId === svc.id);

  // Fleet stats
  const allDeploys = deployments;
  const succeeded = allDeploys.filter((d) => d.status === "succeeded").length;
  const failed = allDeploys.filter((d) => d.status === "failed" || d.status === "rolled_back").length;
  const successRate = allDeploys.length > 0 ? Math.round((succeeded / allDeploys.length) * 100) : 0;
  const avgDuration = allDeploys.length > 0
    ? Math.round(allDeploys.reduce((s, d) => s + (d.duration || 0), 0) / allDeploys.length)
    : 0;

  // Per-service deployment stats across the fleet
  const serviceStats = services.map((s) => {
    const deps = deployments.filter((d) => d.serviceId === s.id);
    const ok = deps.filter((d) => d.status === "succeeded").length;
    const fail = deps.filter((d) => d.status === "failed" || d.status === "rolled_back").length;
    const inFlight = deps.filter((d) => d.status === "rolling_out" || d.status === "in_progress" || d.status === "canary").length;
    const avgRisk = deps.length > 0 ? Math.round(deps.reduce((s, d) => s + d.riskScore, 0) / deps.length) : 0;
    return { service: s, total: deps.length, ok, fail, inFlight, avgRisk, deps };
  }).sort((a, b) => b.total - a.total);

  function authorOf(d: Deployment) {
    return people.find((p) => p.id === d.authorId);
  }
  function incidentRefsFor(d: Deployment): string[] {
    return d.incidentsTriggered.map((id) => incidents.find((i) => i.id === id)?.ref).filter(Boolean) as string[];
  }

  function riskColor(score: number) {
    if (score > 60) return "destructive";
    if (score > 30) return "warning";
    return "success";
  }
  function riskBar(score: number) {
    return riskColor(score) === "destructive" ? "bg-destructive" : riskColor(score) === "warning" ? "bg-warning" : "bg-success";
  }

  return (
    <PageContainer>
      <PageHeader
        title="Service Deployments"
        description="Cross-service deployment activity, risk posture, and per-service success/failure timeline."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Services", href: "/services" }, { label: "Deployments" }]}
        icon={<Rocket className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening deploy wizard")}>
              <Rocket className="w-3.5 h-3.5" /> New Deploy
            </Button>
          </>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Deploys" value={allDeploys.length} icon={<Rocket className="w-4 h-4" />} accent="primary" hint="Across all services" />
        <KpiCard label="Success Rate" value={`${successRate}%`} icon={<CheckCircle2 className="w-4 h-4" />} accent="success" hint={`${succeeded} succeeded`} />
        <KpiCard label="Failures" value={failed} icon={<XCircle className="w-4 h-4" />} accent="destructive" hint="Failed + rolled back" />
        <KpiCard label="Avg Duration" value={avgDuration} unit="s" icon={<Clock className="w-4 h-4" />} accent="info" hint="Per deployment" />
      </div>

      {/* Service selector */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 md:items-end">
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Filter by service</label>
            <Select value={serviceId} onValueChange={setServiceId}>
              <SelectTrigger className="w-full md:w-[280px] h-9 text-xs">
                <SelectValue placeholder="Select service" />
              </SelectTrigger>
              <SelectContent>
                {services.map((s) => (
                  <SelectItem key={s.id} value={s.id}>{s.name} ({s.tier})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="md:ml-auto flex items-center gap-2 flex-wrap">
            <Link href={`/services/${svc.id}`}>
              <Button variant="outline" size="sm" className="gap-1.5 h-9">
                <Server className="w-3.5 h-3.5" />
                View service
              </Button>
            </Link>
            <div className="flex items-center gap-2 text-xs">
              <TierBadge tier={svc.tier} />
              <ServiceHealthBadge health={svc.health} />
            </div>
          </div>
        </div>
      </Card>

      {/* Timeline for selected service */}
      <Card className="p-4">
        <SectionHeading
          title={`${svc.name} - Deployment Timeline`}
          description={`${svcDeployments.length} deployments - newest first`}
          action={<History className="w-4 h-4 text-muted-foreground" />}
        />
        {svcDeployments.length === 0 ? (
          <div className="mt-4">
            <EmptyState icon={<Rocket className="w-5 h-5" />} title="No deployments found" description={`${svc.name} has no deployment history.`} />
          </div>
        ) : (
          <div className="mt-4 relative">
            {/* Vertical timeline line */}
            <div className="absolute left-5 top-2 bottom-2 w-px bg-border" />

            <div className="space-y-4">
              {svcDeployments.map((d) => {
                const author = authorOf(d);
                const incRefs = incidentRefsFor(d);
                const rColor = riskColor(d.riskScore);
                return (
                  <div key={d.id} className="relative pl-12">
                    {/* Timeline dot */}
                    <div className={`absolute left-2 top-1.5 w-6 h-6 rounded-full flex items-center justify-center border-2 border-card ${
                      d.status === "succeeded" ? "bg-success text-success-foreground"
                      : d.status === "failed" || d.status === "rolled_back" ? "bg-destructive text-destructive-foreground"
                      : d.status === "rolling_out" || d.status === "in_progress" || d.status === "canary" ? "bg-info text-info-foreground"
                      : "bg-muted text-muted-foreground"
                    }`}>
                      {d.status === "succeeded" ? <CheckCircle2 className="w-3 h-3" />
                      : (d.status === "failed" || d.status === "rolled_back") ? <XCircle className="w-3 h-3" />
                      : <Rocket className="w-3 h-3" />}
                    </div>

                    <div className="rounded-lg border border-border p-3 hover:bg-muted/30 transition-colors">
                      {/* Header */}
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div className="min-w-0 space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[11px] font-mono text-primary">{d.ref}</span>
                            <DeploymentStatusBadge status={d.status} />
                            {d.strategy === "canary" && (
                              <Badge variant="outline" className="text-[10px] gap-0.5">
                                <Zap className="w-2.5 h-2.5" />
                                canary {d.rolloutPercent}%
                              </Badge>
                            )}
                            {d.strategy === "blue_green" && (
                              <Badge variant="outline" className="text-[10px]">blue/green</Badge>
                            )}
                          </div>
                          <p className="text-sm font-medium line-clamp-1">{d.commitMessage}</p>
                          <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                            <span className="font-mono">{d.version}</span>
                            <span className="inline-flex items-center gap-1">
                              <GitCommit className="w-2.5 h-2.5" />
                              {d.commitSha}
                            </span>
                            {author && (
                              <span className="inline-flex items-center gap-1">
                                <img src={author.avatarUrl} alt="" className="w-3.5 h-3.5 rounded-full object-cover" />
                                {author.name}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right shrink-0 space-y-1">
                          <p className="text-[10px] uppercase text-muted-foreground">Started</p>
                          <p className="text-xs">{new Date(d.startedAt).toLocaleString()}</p>
                          {d.duration > 0 && (
                            <p className="text-[11px] text-muted-foreground tabular-nums">{Math.round(d.duration / 60)}m {d.duration % 60}s</p>
                          )}
                        </div>
                      </div>

                      {/* Risk score + metrics */}
                      <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-border">
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Risk Score</p>
                            <span className={`text-xs font-semibold tabular-nums ${
                              rColor === "destructive" ? "text-destructive"
                              : rColor === "warning" ? "text-warning-foreground"
                              : "text-success"
                            }`}>{d.riskScore}</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                            <div className={`h-full ${riskBar(d.riskScore)}`} style={{ width: `${d.riskScore}%` }} />
                          </div>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Changes</p>
                          <p className="text-sm font-semibold tabular-nums">{d.changesCount} files</p>
                          <p className="text-[10px] text-muted-foreground">{d.prIds.length} PRs</p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Error Rate</p>
                          <p className="text-sm font-semibold tabular-nums">
                            {d.metrics.errorRateBefore.toFixed(2)}% <ArrowUpRight className="inline w-3 h-3 text-muted-foreground" /> {d.metrics.errorRateAfter.toFixed(2)}%
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-muted-foreground">p95 Latency</p>
                          <p className="text-sm font-semibold tabular-nums">
                            {d.metrics.p95LatencyBefore}ms <ArrowUpRight className="inline w-3 h-3 text-muted-foreground" /> {d.metrics.p95LatencyAfter}ms
                          </p>
                        </div>
                      </div>

                      {/* Incidents triggered */}
                      {incRefs.length > 0 && (
                        <div className="mt-2 flex items-center gap-2 text-xs">
                          <AlertTriangle className="w-3 h-3 text-destructive" />
                          <span className="text-muted-foreground">Triggered:</span>
                          {incRefs.map((ref) => (
                            <span key={ref} className="font-mono text-destructive">{ref}</span>
                          ))}
                        </div>
                      )}

                      {/* Stages */}
                      {d.stages.length > 0 && (
                        <div className="mt-3 flex items-center gap-1 flex-wrap">
                          {d.stages.map((stage, si) => (
                            <div key={si} className="flex items-center gap-1">
                              <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${
                                stage.status === "succeeded" ? "bg-success/15 text-success border-success/30"
                                : stage.status === "failed" ? "bg-destructive/15 text-destructive border-destructive/30"
                                : stage.status === "in_progress" || stage.status === "rolling_out" || stage.status === "canary" ? "bg-info/15 text-info-foreground border-info/30"
                                : "bg-muted text-muted-foreground border-border"
                              }`}>
                                {stage.status === "succeeded" && <CheckCircle2 className="w-2.5 h-2.5" />}
                                {stage.status === "failed" && <XCircle className="w-2.5 h-2.5" />}
                                {stage.name}
                              </span>
                              {si < d.stages.length - 1 && <span className="text-muted-foreground/50">-</span>}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </Card>

      {/* Per-service success/failure summary */}
      <Card className="p-4">
        <SectionHeading
          title="Per-Service Deployment Stats"
          description="Fleet-wide summary of deployment volume, success rate, and average risk"
          action={<Activity className="w-4 h-4 text-muted-foreground" />}
        />
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {serviceStats.map(({ service, total, ok, fail, inFlight, avgRisk, deps }) => (
            <Card key={service.id} className="p-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <Link href={`/services/${service.id}`} className="inline-flex items-center gap-1.5 text-xs font-medium hover:underline min-w-0">
                  <StatusDot color={service.health === "operational" ? "success" : service.health === "degraded" ? "warning" : "destructive"} />
                  <span className="truncate">{service.name}</span>
                </Link>
                <TierBadge tier={service.tier} />
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div>
                  <p className="text-sm font-semibold tabular-nums text-primary">{total}</p>
                  <p className="text-[10px] text-muted-foreground">total</p>
                </div>
                <div>
                  <p className="text-sm font-semibold tabular-nums text-success">{ok}</p>
                  <p className="text-[10px] text-muted-foreground">ok</p>
                </div>
                <div>
                  <p className="text-sm font-semibold tabular-nums text-destructive">{fail}</p>
                  <p className="text-[10px] text-muted-foreground">fail</p>
                </div>
                <div>
                  <p className="text-sm font-semibold tabular-nums text-info-foreground">{inFlight}</p>
                  <p className="text-[10px] text-muted-foreground">live</p>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                  <span>Avg risk</span>
                  <span className={`font-semibold tabular-nums ${avgRisk > 50 ? "text-destructive" : avgRisk > 25 ? "text-warning-foreground" : "text-success"}`}>{avgRisk}</span>
                </div>
                <Progress value={avgRisk} className="h-1" />
              </div>
            </Card>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
