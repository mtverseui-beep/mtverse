"use client";

import * as React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  SeverityBadge, IncidentStatusBadge, ServiceHealthBadge, TierBadge,
  SLOStatusBadge, AlertStatusBadge, DeploymentStatusBadge, StatusDot,
} from "@/components/common/badges";
import {
  LatencyChart, ErrorRateChart, VolumeChart, LineChartCard,
} from "@/components/charts";
import {
  services, slos, incidents, deployments, runbooks, alerts,
  people, teams, timeSeries, multiTimeSeries,
} from "@/lib/data";
import type { Service, SLO, Incident, Deployment, Runbook, AlertEvent } from "@/lib/types";
import { toast } from "sonner";
import {
  Server, ArrowLeft, Activity, Gauge, AlertTriangle, Rocket,
  BookOpen, Bell, Target, GitBranch, Zap, Clock, Cpu, MemoryStick,
  TrendingUp, TrendingDown, Database, Network, ArrowUpRight, ArrowDownRight,
  Eye, Plus, Download, ExternalLink, AlertOctagon,
} from "lucide-react";

export default function ServiceDetailsPage() {
  const params = useParams();
  const id = (params?.id as string) || services[0].id;
  const svc = services.find((s) => s.id === id) || services[0];
  const owner = people.find((p) => p.id === svc.ownerId);
  const team = teams.find((t) => t.id === svc.teamId);

  const serviceSLOs = slos.filter((s) => s.serviceId === svc.id);
  const serviceIncidents = incidents.filter((i) => i.serviceIds.includes(svc.id));
  const serviceDeployments = deployments.filter((d) => d.serviceId === svc.id);
  const serviceRunbooks = runbooks.filter((r) => r.serviceId === svc.id || svc.runbooks.includes(r.id));
  const serviceAlerts = alerts.filter((a) => a.serviceId === svc.id);

  const deps = svc.dependencies.map((d) => services.find((s) => s.id === d)).filter(Boolean) as Service[];
  const dependents = svc.dependents.map((d) => services.find((s) => s.id === d)).filter(Boolean) as Service[];

  // Build chart data
  const latencyData = multiTimeSeries(2, 24, [
    { name: "p50", base: svc.p95LatencyMs * 0.4, variance: svc.p95LatencyMs * 0.1 },
    { name: "p95", base: svc.p95LatencyMs, variance: svc.p95LatencyMs * 0.2 },
    { name: "p99", base: svc.p95LatencyMs * 1.6, variance: svc.p95LatencyMs * 0.4 },
  ]).map((d) => ({ timestamp: String(d.date), p50: Number(d.p50), p95: Number(d.p95), p99: Number(d.p99) }));
  const errorData = timeSeries(5, 24, svc.errorRate, svc.errorRate * 0.5).map((d) => ({ timestamp: String(d.date), value: d.value }));
  const volumeData = timeSeries(3, 24, svc.requestsPerSecond, svc.requestsPerSecond * 0.2).map((d) => ({ timestamp: String(d.date), value: d.value }));

  function metricColor(v: number, warn: number, crit: number, lower = false) {
    if (lower) return v < warn ? "text-warning-foreground" : v < crit ? "text-destructive" : "text-success";
    return v > crit ? "text-destructive" : v > warn ? "text-warning-foreground" : "text-success";
  }

  const healthColor =
    svc.healthScore >= 95 ? "success" : svc.healthScore >= 80 ? "info" : svc.healthScore >= 60 ? "warning" : "destructive";

  const metricsGrid = [
    { label: "Requests/sec", value: svc.requestsPerSecond.toLocaleString(), icon: <Activity className="w-4 h-4" />, hint: "Current RPS" },
    { label: "p50 Latency", value: `${Math.round(svc.p95LatencyMs * 0.4)}ms`, icon: <Clock className="w-4 h-4" />, hint: "Median" },
    { label: "p95 Latency", value: `${svc.p95LatencyMs}ms`, icon: <Gauge className="w-4 h-4" />, hint: "95th percentile" },
    { label: "p99 Latency", value: `${Math.round(svc.p95LatencyMs * 1.6)}ms`, icon: <Gauge className="w-4 h-4" />, hint: "99th percentile" },
    { label: "Error Rate", value: `${svc.errorRate.toFixed(3)}%`, icon: <AlertTriangle className="w-4 h-4" />, hint: "Last 5m" },
    { label: "Cache Hit Ratio", value: "94.2%", icon: <Database className="w-4 h-4" />, hint: "Redis cluster" },
    { label: "CPU Usage", value: "42%", icon: <Cpu className="w-4 h-4" />, hint: "Average across fleet" },
    { label: "Memory Usage", value: "58%", icon: <MemoryStick className="w-4 h-4" />, hint: "Average across fleet" },
  ];

  return (
    <PageContainer>
      <PageHeader
        title={svc.name}
        description={svc.description}
        breadcrumbs={[
          { label: "Home", href: "/dashboard" },
          { label: "Services", href: "/services" },
          { label: svc.name },
        ]}
        icon={<Server className="w-5 h-5" />}
        meta={
          <div className="flex items-center gap-2 flex-wrap">
            <TierBadge tier={svc.tier} />
            <ServiceHealthBadge health={svc.health} />
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
              <GitBranch className="w-3 h-3" />
              {svc.repository}
            </span>
          </div>
        }
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/services">
                <ArrowLeft className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Back</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Viewing metrics in explorer")}>
              <Eye className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Metrics</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success(`Started new incident for ${svc.name}`)}>
              <Plus className="w-3.5 h-3.5" /> New Incident
            </Button>
          </>
        }
      />

      {/* Hero card */}
      <Card className="p-5">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center gap-3">
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center border ${
                healthColor === "success" ? "bg-success/10 border-success/20 text-success"
                : healthColor === "info" ? "bg-info/10 border-info/20 text-info-foreground"
                : healthColor === "warning" ? "bg-warning/10 border-warning/20 text-warning-foreground"
                : "bg-destructive/10 border-destructive/20 text-destructive"
              }`}>
                <Server className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-semibold">{svc.name}</h3>
                <p className="text-xs text-muted-foreground">{svc.language} - {svc.framework}</p>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="inline-flex items-center gap-1 text-xs">
                    <StatusDot color="primary" size="sm" />
                    {svc.environment}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                    <Network className="w-3 h-3" />
                    {svc.regions.join(", ")}
                  </span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Owner</p>
                {owner && (
                  <div className="flex items-center gap-1.5 mt-1">
                    <img src={owner.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
                    <span className="text-xs">{owner.name}</span>
                  </div>
                )}
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Team</p>
                {team && (
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="w-2 h-2 rounded-full" style={{ background: team.color }} />
                    <span className="text-xs">{team.name}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 grid grid-cols-2 gap-3">
            <div className="rounded-lg border border-border p-3 space-y-1">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Health Score</p>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-semibold tabular-nums">{svc.healthScore}</span>
                <span className="text-xs text-muted-foreground">/100</span>
              </div>
              <Progress value={svc.healthScore} className="h-1.5" />
            </div>
            <div className="rounded-lg border border-border p-3 space-y-1">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Uptime 30d</p>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-semibold tabular-nums">{svc.uptime30d.toFixed(3)}</span>
                <span className="text-xs text-muted-foreground">%</span>
              </div>
              <p className="text-[10px] text-muted-foreground">Last deploy: {new Date(svc.lastDeployAt).toLocaleDateString()}</p>
            </div>
            <div className="rounded-lg border border-border p-3 space-y-1">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Open Alerts</p>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-semibold tabular-nums">{svc.openAlerts}</span>
              </div>
              <p className="text-[10px] text-muted-foreground">{svc.endpoints} endpoints</p>
            </div>
            <div className="rounded-lg border border-border p-3 space-y-1">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Open Incidents</p>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-semibold tabular-nums">{svc.openIncidents}</span>
              </div>
              <p className="text-[10px] text-muted-foreground">{deps.length} deps, {dependents.length} dependents</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="overview">
        <TabsList className="grid w-full grid-cols-4 md:grid-cols-8 h-auto">
          <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
          <TabsTrigger value="slos" className="text-xs">SLOs</TabsTrigger>
          <TabsTrigger value="deps" className="text-xs">Dependencies</TabsTrigger>
          <TabsTrigger value="incidents" className="text-xs">Incidents</TabsTrigger>
          <TabsTrigger value="deployments" className="text-xs">Deployments</TabsTrigger>
          <TabsTrigger value="runbooks" className="text-xs">Runbooks</TabsTrigger>
          <TabsTrigger value="alerts" className="text-xs">Alerts</TabsTrigger>
          <TabsTrigger value="metrics" className="text-xs">Metrics</TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="space-y-4 mt-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <KpiCard label="p95 Latency" value={`${svc.p95LatencyMs}ms`} icon={<Gauge className="w-4 h-4" />} accent="primary" hint="Last 5m" />
            <KpiCard label="Error Rate" value={`${svc.errorRate.toFixed(3)}%`} icon={<AlertTriangle className="w-4 h-4" />} accent={svc.errorRate > 1 ? "destructive" : "success"} hint="Last 5m" />
            <KpiCard label="Uptime 30d" value={`${svc.uptime30d.toFixed(3)}%`} icon={<Activity className="w-4 h-4" />} accent="info" />
            <KpiCard label="Requests/sec" value={svc.requestsPerSecond.toLocaleString()} icon={<Zap className="w-4 h-4" />} accent="accent" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <LatencyChart data={latencyData} title="Latency Percentiles" description="p50, p95, p99 over last 24 hours" />
            <ErrorRateChart data={errorData} title="Error Rate" description="Last 24 hours" />
          </div>
          <VolumeChart data={volumeData} title="Request Volume" description="Requests per minute, last 24 hours" unit=" rpm" />
        </TabsContent>

        {/* SLOs */}
        <TabsContent value="slos" className="mt-4 space-y-3">
          {serviceSLOs.length === 0 ? (
            <EmptyState icon={<Target className="w-5 h-5" />} title="No SLOs defined" description="Configure SLOs to track reliability targets for this service." action={<Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening SLO editor")}><Plus className="w-3.5 h-3.5" /> Define SLO</Button>} />
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
              {serviceSLOs.map((slo) => (
                <Card key={slo.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono text-primary">{slo.ref}</span>
                        <SLOStatusBadge status={slo.status} />
                      </div>
                      <p className="text-sm font-semibold">{slo.name}</p>
                      <p className="text-xs text-muted-foreground">{slo.description}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-[10px] uppercase text-muted-foreground">Target</p>
                      <p className="text-sm font-semibold tabular-nums">{slo.target}%</p>
                      <p className="text-[10px] text-muted-foreground">{slo.window}</p>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-muted-foreground">Current SLI</span>
                      <span className="font-medium tabular-nums">{slo.current.toFixed(2)}%</span>
                    </div>
                    <Progress value={slo.current} className="h-1.5" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-muted-foreground">Error Budget</span>
                      <span className="font-medium tabular-nums">{slo.errorBudget.remaining}% remaining</span>
                    </div>
                    <div className="flex gap-1 h-1.5 rounded-full overflow-hidden bg-muted">
                      <div className="bg-success" style={{ width: `${slo.errorBudget.remaining}%` }} />
                      <div className="bg-destructive/70" style={{ width: `${slo.errorBudget.consumed}%` }} />
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-1">Burn rate: {slo.errorBudget.burnRate}x</p>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Dependencies */}
        <TabsContent value="deps" className="mt-4 space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="p-4">
              <SectionHeading title="Upstream Dependencies" description={`${deps.length} services this service depends on`} action={<ArrowUpRight className="w-4 h-4 text-primary" />} />
              <div className="mt-3 space-y-2">
                {deps.length === 0 ? (
                  <p className="text-xs text-muted-foreground py-6 text-center">No upstream dependencies</p>
                ) : deps.map((d) => (
                  <Link key={d.id} href={`/services/${d.id}`} className="block rounded-lg border border-border p-3 hover:bg-muted/40 transition-colors">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 min-w-0">
                        <StatusDot color={d.health === "operational" ? "success" : d.health === "degraded" ? "warning" : "destructive"} size="md" />
                        <div className="min-w-0">
                          <p className="text-xs font-medium">{d.name}</p>
                          <p className="text-[11px] text-muted-foreground">{d.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <TierBadge tier={d.tier} />
                        <ExternalLink className="w-3 h-3 text-muted-foreground" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </Card>
            <Card className="p-4">
              <SectionHeading title="Downstream Dependents" description={`${dependents.length} services depend on this service`} action={<ArrowDownRight className="w-4 h-4 text-accent" />} />
              <div className="mt-3 space-y-2">
                {dependents.length === 0 ? (
                  <p className="text-xs text-muted-foreground py-6 text-center">No downstream dependents</p>
                ) : dependents.map((d) => (
                  <Link key={d.id} href={`/services/${d.id}`} className="block rounded-lg border border-border p-3 hover:bg-muted/40 transition-colors">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 min-w-0">
                        <StatusDot color={d.health === "operational" ? "success" : d.health === "degraded" ? "warning" : "destructive"} size="md" />
                        <div className="min-w-0">
                          <p className="text-xs font-medium">{d.name}</p>
                          <p className="text-[11px] text-muted-foreground">{d.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <TierBadge tier={d.tier} />
                        <ExternalLink className="w-3 h-3 text-muted-foreground" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Incidents */}
        <TabsContent value="incidents" className="mt-4">
          <Card className="p-4">
            <SectionHeading title="Incidents" description={`${serviceIncidents.length} incidents involving this service`} />
            {serviceIncidents.length === 0 ? (
              <EmptyState icon={<AlertOctagon className="w-5 h-5" />} title="No incidents" description="This service has no incident history." />
            ) : (
              <div className="mt-3 space-y-2">
                {serviceIncidents.map((inc) => (
                  <Link key={inc.id} href={`/incidents/${inc.id}`} className="block rounded-lg border border-border p-3 hover:bg-muted/40 transition-colors">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-mono text-primary">{inc.ref}</span>
                          <SeverityBadge severity={inc.severity} size="sm" />
                          <IncidentStatusBadge status={inc.status} />
                        </div>
                        <p className="text-xs font-medium line-clamp-1">{inc.title}</p>
                        <p className="text-[11px] text-muted-foreground">
                          Started {new Date(inc.startedAt).toLocaleDateString()} - {inc.impactedUsers.toLocaleString()} users impacted
                        </p>
                      </div>
                      <ExternalLink className="w-3 h-3 text-muted-foreground shrink-0 mt-1" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Deployments */}
        <TabsContent value="deployments" className="mt-4">
          <Card className="p-4">
            <SectionHeading title="Recent Deployments" description={`${serviceDeployments.length} deployments`} />
            {serviceDeployments.length === 0 ? (
              <EmptyState icon={<Rocket className="w-5 h-5" />} title="No deployments" />
            ) : (
              <div className="mt-3 space-y-2">
                {serviceDeployments.map((d) => (
                  <div key={d.id} className="rounded-lg border border-border p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-mono text-primary">{d.ref}</span>
                          <DeploymentStatusBadge status={d.status} />
                        </div>
                        <p className="text-xs font-medium line-clamp-1">{d.commitMessage}</p>
                        <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                          <span className="font-mono">{d.version}</span>
                          <span>{d.commitSha}</span>
                          <span>{new Date(d.startedAt).toLocaleString()}</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0 space-y-1">
                        <p className="text-[10px] uppercase text-muted-foreground">Risk</p>
                        <p className={`text-sm font-semibold tabular-nums ${d.riskScore > 50 ? "text-destructive" : d.riskScore > 25 ? "text-warning-foreground" : "text-success"}`}>
                          {d.riskScore}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Runbooks */}
        <TabsContent value="runbooks" className="mt-4">
          <Card className="p-4">
            <SectionHeading title="Runbooks" description={`${serviceRunbooks.length} operational runbooks`} />
            {serviceRunbooks.length === 0 ? (
              <EmptyState icon={<BookOpen className="w-5 h-5" />} title="No runbooks" />
            ) : (
              <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
                {serviceRunbooks.map((r) => (
                  <Link key={r.id} href={`/services/runbooks/${r.id}`} className="block rounded-lg border border-border p-3 hover:bg-muted/40 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="shrink-0 w-8 h-8 rounded-md bg-primary/10 text-primary flex items-center justify-center">
                        <BookOpen className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 space-y-1">
                        <p className="text-xs font-medium">{r.title}</p>
                        <p className="text-[11px] text-muted-foreground">{r.category} - {r.steps.length} steps</p>
                        <p className="text-[11px] text-muted-foreground">Updated {r.lastUpdated} - {r.views} views</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Alerts */}
        <TabsContent value="alerts" className="mt-4">
          <Card className="p-4">
            <SectionHeading title="Open Alerts" description={`${serviceAlerts.length} alerts for this service`} />
            {serviceAlerts.length === 0 ? (
              <EmptyState icon={<Bell className="w-5 h-5" />} title="No alerts" description="All clear for this service." />
            ) : (
              <div className="mt-3 space-y-2">
                {serviceAlerts.map((a) => (
                  <div key={a.id} className="rounded-lg border border-border p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-mono text-primary">{a.ref}</span>
                          <SeverityBadge severity={a.severity} size="sm" />
                          <AlertStatusBadge status={a.status} />
                        </div>
                        <p className="text-xs">{a.message}</p>
                        <p className="text-[11px] text-muted-foreground">Started {new Date(a.startedAt).toLocaleString()}</p>
                      </div>
                      <Badge variant="outline" className="text-xs shrink-0">{a.value}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* Metrics */}
        <TabsContent value="metrics" className="mt-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {metricsGrid.map((m, i) => (
              <Card key={i} className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{m.label}</p>
                  <div className="w-7 h-7 rounded-md bg-primary/10 text-primary flex items-center justify-center">{m.icon}</div>
                </div>
                <p className="text-xl font-semibold tabular-nums">{m.value}</p>
                <p className="text-[11px] text-muted-foreground">{m.hint}</p>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </PageContainer>
  );
}
