"use client";

import * as React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { TierBadge } from "@/components/common/badges";
import { runbooks, services, people, incidents, alerts } from "@/lib/data";
import { toast } from "sonner";
import {
  BookOpen, ArrowLeft, Clock, Eye, User, Server, Play,
  AlertTriangle, Bell, FileText, ArrowUpRight, ListOrdered,
  CheckCircle2, Copy, Printer, Share2, GitBranch,
} from "lucide-react";

const categoryColor: Record<string, string> = {
  "Incident Response": "bg-destructive/15 text-destructive border-destructive/30",
  "Security": "bg-destructive/15 text-destructive border-destructive/30",
  "Performance": "bg-warning/15 text-warning-foreground border-warning/30",
  "Database": "bg-info/15 text-info-foreground border-info/30",
  "Infrastructure": "bg-accent text-accent-foreground border-accent/30",
  "Operations": "bg-primary/15 text-primary border-primary/30",
  "Build": "bg-muted text-muted-foreground border-border",
};

export default function RunbookDetailsPage() {
  const params = useParams();
  const id = (params?.id as string) || runbooks[0].id;
  const rb = runbooks.find((r) => r.id === id) || runbooks[0];

  const svc = services.find((s) => s.id === rb.serviceId);
  const author = people.find((p) => p.id === rb.authorId);
  const catColor = categoryColor[rb.category] || categoryColor.Operations;

  // Related runbooks: same service or same category, excluding current
  const relatedRunbooks = runbooks
    .filter((r) => r.id !== rb.id && (r.serviceId === rb.serviceId || r.category === rb.category))
    .slice(0, 4);

  // Related incidents: incidents on this service
  const relatedIncidents = svc ? incidents.filter((i) => i.serviceIds.includes(svc.id)).slice(0, 4) : [];

  // Related alerts: alerts on this service
  const relatedAlerts = svc ? alerts.filter((a) => a.serviceId === svc.id).slice(0, 4) : [];

  const [activeStep, setActiveStep] = React.useState<number | null>(null);

  return (
    <PageContainer>
      <PageHeader
        title={rb.title}
        description={`Operational runbook - ${rb.steps.length} steps`}
        breadcrumbs={[
          { label: "Home", href: "/dashboard" },
          { label: "Services", href: "/services" },
          { label: "Runbooks", href: "/services/runbooks" },
          { label: rb.slug },
        ]}
        icon={<BookOpen className="w-5 h-5" />}
        meta={
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium ${catColor}`}>
              {rb.category}
            </span>
            {svc && (
              <Link href={`/services/${svc.id}`} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                <Server className="w-3 h-3" />
                {svc.name}
              </Link>
            )}
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
              <GitBranch className="w-3 h-3" />
              {rb.slug}
            </span>
          </div>
        }
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/services/runbooks">
                <ArrowLeft className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Back</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Link copied to clipboard")}>
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Share</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success(`Started runbook: ${rb.title}`, { description: "Tracking execution progress" })}>
              <Play className="w-3.5 h-3.5" /> Start Runbook
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Main content - steps */}
        <div className="lg:col-span-3 space-y-4">
          {/* Hero metadata */}
          <Card className="p-5">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Author</p>
                {author && (
                  <div className="flex items-center gap-1.5 mt-1">
                    <img src={author.avatarUrl} alt={author.name} className="w-5 h-5 rounded-full object-cover" />
                    <span className="text-xs">{author.name}</span>
                  </div>
                )}
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Last Updated</p>
                <div className="flex items-center gap-1.5 mt-1">
                  <Clock className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs">{rb.lastUpdated}</span>
                </div>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Views</p>
                <div className="flex items-center gap-1.5 mt-1">
                  <Eye className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs tabular-nums">{rb.views.toLocaleString()}</span>
                </div>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Steps</p>
                <div className="flex items-center gap-1.5 mt-1">
                  <ListOrdered className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs tabular-nums">{rb.steps.length}</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Steps */}
          <Card className="p-5">
            <SectionHeading
              title="Procedure"
              description="Follow each step in order. Mark complete as you proceed."
              action={
                <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success("Print dialog opened")}>
                  <Printer className="w-3 h-3" />
                  Print
                </Button>
              }
            />
            <div className="mt-4 space-y-3">
              {rb.steps.map((step, i) => {
                const isActive = activeStep === i;
                const isDone = activeStep !== null && i < activeStep;
                return (
                  <div
                    key={i}
                    className={`rounded-lg border p-4 transition-colors cursor-pointer ${
                      isActive ? "border-primary bg-primary/5"
                      : isDone ? "border-success/30 bg-success/5"
                      : "border-border hover:bg-muted/40"
                    }`}
                    onClick={() => setActiveStep(isActive ? null : i)}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm ${
                        isActive ? "bg-primary text-primary-foreground"
                        : isDone ? "bg-success text-success-foreground"
                        : "bg-muted text-muted-foreground border border-border"
                      }`}>
                        {isDone ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
                      </div>
                      <div className="min-w-0 flex-1 space-y-1.5">
                        <div className="flex items-center justify-between gap-2">
                          <h3 className="text-sm font-semibold">{step.title}</h3>
                          <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={(e) => { e.stopPropagation(); toast.success("Step copied to clipboard"); }}>
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground leading-relaxed whitespace-pre-line">{step.body}</p>
                        <div className="flex items-center gap-2 pt-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-xs gap-1"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (isDone) setActiveStep(i - 1 >= 0 ? i - 1 : null);
                              else setActiveStep(i);
                              toast.success(isDone ? `Step ${i + 1} unmarked` : `Step ${i + 1} marked complete`);
                            }}
                          >
                            {isDone ? "Mark incomplete" : "Mark complete"}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Progress footer */}
            <Separator className="my-4" />
            <div className="flex items-center justify-between gap-3">
              <div className="text-xs text-muted-foreground">
                {activeStep !== null ? `Step ${activeStep + 1} of ${rb.steps.length} in progress` : `${rb.steps.length} steps total`}
              </div>
              <Button size="sm" className="gap-1.5" onClick={() => toast.success(`Runbook completed: ${rb.title}`, { description: "Logged to audit trail" })}>
                <CheckCircle2 className="w-3.5 h-3.5" /> Complete Runbook
              </Button>
            </div>
          </Card>
        </div>

        {/* Sidebar - related */}
        <div className="space-y-4">
          {/* Quick actions */}
          <Card className="p-4">
            <SectionHeading title="Quick Actions" />
            <div className="mt-3 space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start gap-2 h-9 text-xs" onClick={() => toast.success("Linked to active incident")}>
                <AlertTriangle className="w-3.5 h-3.5" />
                Link to incident
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start gap-2 h-9 text-xs" onClick={() => toast.success("Linked to firing alert")}>
                <Bell className="w-3.5 h-3.5" />
                Link to alert
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start gap-2 h-9 text-xs" onClick={() => toast.success("Opened in editor")}>
                <FileText className="w-3.5 h-3.5" />
                Edit runbook
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start gap-2 h-9 text-xs" onClick={() => toast.success("Duplicated to drafts")}>
                <Copy className="w-3.5 h-3.5" />
                Duplicate
              </Button>
            </div>
          </Card>

          {/* Related runbooks */}
          <Card className="p-4">
            <SectionHeading title="Related Runbooks" description={`${relatedRunbooks.length} related`} />
            <div className="mt-3 space-y-2">
              {relatedRunbooks.length === 0 ? (
                <p className="text-[11px] text-muted-foreground text-center py-3">No related runbooks</p>
              ) : relatedRunbooks.map((r) => (
                <Link key={r.id} href={`/services/runbooks/${r.id}`} className="block rounded-md border border-border p-2 hover:bg-muted/40 transition-colors">
                  <p className="text-xs font-medium line-clamp-1">{r.title}</p>
                  <p className="text-[10px] text-muted-foreground">{r.category} - {r.steps.length} steps</p>
                </Link>
              ))}
            </div>
          </Card>

          {/* Related incidents */}
          <Card className="p-4">
            <SectionHeading title="Related Incidents" description={`${relatedIncidents.length} on this service`} />
            <div className="mt-3 space-y-2">
              {relatedIncidents.length === 0 ? (
                <p className="text-[11px] text-muted-foreground text-center py-3">No related incidents</p>
              ) : relatedIncidents.map((inc) => (
                <Link key={inc.id} href={`/incidents/${inc.id}`} className="block rounded-md border border-border p-2 hover:bg-muted/40 transition-colors">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-mono text-primary">{inc.ref}</span>
                    <ArrowUpRight className="w-3 h-3 text-muted-foreground" />
                  </div>
                  <p className="text-xs font-medium line-clamp-1 mt-0.5">{inc.title}</p>
                  <p className="text-[10px] text-muted-foreground">{new Date(inc.startedAt).toLocaleDateString()}</p>
                </Link>
              ))}
            </div>
          </Card>

          {/* Related alerts */}
          <Card className="p-4">
            <SectionHeading title="Related Alerts" description={`${relatedAlerts.length} on this service`} />
            <div className="mt-3 space-y-2">
              {relatedAlerts.length === 0 ? (
                <p className="text-[11px] text-muted-foreground text-center py-3">No related alerts</p>
              ) : relatedAlerts.map((a) => (
                <div key={a.id} className="rounded-md border border-border p-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-mono text-primary">{a.ref}</span>
                    <span className="text-[10px] text-muted-foreground">{a.status}</span>
                  </div>
                  <p className="text-xs font-medium line-clamp-1 mt-0.5">{a.message}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
