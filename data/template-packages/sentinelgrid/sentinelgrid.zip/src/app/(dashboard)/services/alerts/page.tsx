"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { SeverityBadge, AlertStatusBadge, StatusDot } from "@/components/common/badges";
import { alerts, alertRules, services } from "@/lib/data";
import type { AlertEvent } from "@/lib/types";
import { toast } from "sonner";
import {
  Bell, BellRing, AlertTriangle, BellOff, Volume2, Download,
  Check, EyeOff, Filter, Zap,
} from "lucide-react";

interface AlertRow {
  alert: AlertEvent;
  service: ReturnType<typeof services.find> extends infer T ? NonNullable<T> : never;
  rule: ReturnType<typeof alertRules.find> extends infer T ? NonNullable<T> : never;
}

export default function ServiceAlertsPage() {
  // Build alert rows linking alerts to their rule + service
  const alertRows: AlertRow[] = alerts.map((a) => {
    const service = services.find((s) => s.id === a.serviceId)!;
    const rule = alertRules.find((r) => r.id === a.ruleId)!;
    return { alert: a, service, rule };
  });

  // Group by service
  const byService = React.useMemo(() => {
    const map = new Map<string, AlertRow[]>();
    alertRows.forEach((r) => {
      const list = map.get(r.service.id) || [];
      list.push(r);
      map.set(r.service.id, list);
    });
    return Array.from(map.entries()).map(([sid, rows]) => ({
      service: services.find((s) => s.id === sid)!,
      rows,
    }));
  }, [alertRows]);

  const firing = alerts.filter((a) => a.status === "firing").length;
  const acknowledged = alerts.filter((a) => a.status === "acknowledged").length;
  const avgNoise = alertRules.length > 0
    ? Math.round(alertRules.reduce((s, r) => s + r.noiseScore, 0) / alertRules.length * 10) / 10
    : 0;
  const total7d = alertRules.reduce((s, r) => s + r.triggerCount7d, 0);

  function formatTimeAgo(iso: string) {
    const diff = Date.now() - new Date(iso).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h ago`;
    if (hours > 0) return `${hours}h ${mins % 60}m ago`;
    return `${mins}m ago`;
  }

  const columns: Column<AlertRow>[] = [
    {
      key: "service",
      header: "Service",
      sortable: true,
      filterable: true,
      sortValue: (r) => r.service.name,
      filterOptions: services.map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.service.id === v,
      cell: (r) => (
        <Link href={`/services/${r.service.id}`} className="inline-flex items-center gap-1.5 text-xs font-medium hover:underline">
          <StatusDot color={r.service.health === "operational" ? "success" : r.service.health === "degraded" ? "warning" : "destructive"} />
          {r.service.name}
        </Link>
      ),
    },
    {
      key: "alert",
      header: "Alert",
      sortable: true,
      sortValue: (r) => r.rule.name,
      cell: (r) => (
        <div className="min-w-0">
          <p className="text-xs font-medium line-clamp-1">{r.rule.name}</p>
          <p className="text-[11px] text-muted-foreground line-clamp-1">{r.alert.message}</p>
        </div>
      ),
    },
    {
      key: "severity",
      header: "Severity",
      sortable: true,
      filterable: true,
      sortValue: (r) => ({ critical: 0, high: 1, medium: 2, low: 3, info: 4 }[r.alert.severity]),
      filterOptions: [
        { label: "Critical", value: "critical" },
        { label: "High", value: "high" },
        { label: "Medium", value: "medium" },
        { label: "Low", value: "low" },
      ],
      filterFn: (r, v) => r.alert.severity === v,
      cell: (r) => <SeverityBadge severity={r.alert.severity} size="sm" />,
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      filterable: true,
      sortValue: (r) => r.alert.status,
      filterOptions: [
        { label: "Firing", value: "firing" },
        { label: "Acknowledged", value: "acknowledged" },
        { label: "Resolved", value: "resolved" },
        { label: "Suppressed", value: "suppressed" },
      ],
      filterFn: (r, v) => r.alert.status === v,
      cell: (r) => <AlertStatusBadge status={r.alert.status} />,
    },
    {
      key: "lastTriggered",
      header: "Last Triggered",
      sortable: true,
      hideOnMobile: true,
      sortValue: (r) => new Date(r.alert.startedAt).getTime(),
      cell: (r) => (
        <span className="text-xs text-muted-foreground">{formatTimeAgo(r.alert.startedAt)}</span>
      ),
    },
    {
      key: "count7d",
      header: "7d Count",
      sortable: true,
      align: "right",
      hideOnMobile: true,
      sortValue: (r) => r.rule.triggerCount7d,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.rule.triggerCount7d > 5 ? "text-warning-foreground" : "text-muted-foreground"}`}>
          {r.rule.triggerCount7d}
        </span>
      ),
    },
    {
      key: "noise",
      header: "Noise Score",
      sortable: true,
      align: "right",
      sortValue: (r) => r.rule.noiseScore,
      cell: (r) => {
        const n = r.rule.noiseScore;
        const color = n > 50 ? "text-destructive" : n > 20 ? "text-warning-foreground" : n > 0 ? "text-info-foreground" : "text-muted-foreground";
        return (
          <div className="flex items-center gap-1.5 justify-end">
            {n > 50 && <Volume2 className={`w-3 h-3 ${color}`} />}
            {n > 0 && n <= 50 && <BellRing className={`w-3 h-3 ${color}`} />}
            {n === 0 && <BellOff className={`w-3 h-3 ${color}`} />}
            <span className={`text-xs tabular-nums font-medium ${color}`}>{n}</span>
          </div>
        );
      },
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Service Alerts"
        description="All alerts across the service fleet with severity, status, trigger frequency, and noise scoring."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Services", href: "/services" }, { label: "Alerts" }]}
        icon={<Bell className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Silence rules applied")}>
              <EyeOff className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Silence</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Firing Alerts" value={firing} icon={<BellRing className="w-4 h-4" />} accent="destructive" hint="Require attention" />
        <KpiCard label="Acknowledged" value={acknowledged} icon={<Check className="w-4 h-4" />} accent="warning" hint="In progress" />
        <KpiCard label="Alerts (7d)" value={total7d} icon={<Bell className="w-4 h-4" />} accent="info" hint="Trigger count" />
        <KpiCard label="Avg Noise Score" value={avgNoise} icon={<Volume2 className="w-4 h-4" />} accent={avgNoise > 20 ? "warning" : "muted"} hint="Lower is better" />
      </div>

      {/* Alerts grouped by service */}
      <Card className="p-4">
        <SectionHeading
          title="Alerts by Service"
          description="Alerts grouped by their owning service"
          action={<Filter className="w-4 h-4 text-muted-foreground" />}
        />
        <div className="mt-4 space-y-3 max-h-96 overflow-y-auto pr-1">
          {byService.map(({ service, rows }) => (
            <div key={service.id} className="rounded-lg border border-border">
              <div className="flex items-center justify-between p-3 border-b border-border">
                <div className="flex items-center gap-2">
                  <StatusDot color={service.health === "operational" ? "success" : service.health === "degraded" ? "warning" : "destructive"} size="md" />
                  <Link href={`/services/${service.id}`} className="text-sm font-semibold hover:underline">
                    {service.name}
                  </Link>
                  <span className="text-[11px] text-muted-foreground">{rows.length} alert{rows.length !== 1 ? "s" : ""}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {rows.filter((r) => r.alert.status === "firing").length > 0 && (
                    <span className="inline-flex items-center gap-1 rounded-md border border-destructive/30 bg-destructive/15 text-destructive px-1.5 py-0.5 text-[10px] font-medium">
                      <Zap className="w-2.5 h-2.5" />
                      {rows.filter((r) => r.alert.status === "firing").length} firing
                    </span>
                  )}
                </div>
              </div>
              <div className="divide-y divide-border">
                {rows.map((r) => (
                  <div key={r.alert.id} className="flex items-start gap-3 p-3 hover:bg-muted/30 transition-colors">
                    <div className="shrink-0 mt-0.5">
                      <SeverityBadge severity={r.alert.severity} size="sm" />
                    </div>
                    <div className="min-w-0 flex-1 space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11px] font-mono text-primary">{r.alert.ref}</span>
                        <AlertStatusBadge status={r.alert.status} />
                      </div>
                      <p className="text-xs font-medium line-clamp-1">{r.rule.name}</p>
                      <p className="text-[11px] text-muted-foreground line-clamp-1">{r.alert.message}</p>
                    </div>
                    <div className="shrink-0 text-right space-y-1">
                      <p className="text-[11px] text-muted-foreground">{formatTimeAgo(r.alert.startedAt)}</p>
                      <p className="text-[10px] text-muted-foreground tabular-nums">7d: {r.rule.triggerCount7d}</p>
                      <p className={`text-[10px] tabular-nums ${r.rule.noiseScore > 50 ? "text-destructive" : r.rule.noiseScore > 20 ? "text-warning-foreground" : "text-muted-foreground"}`}>
                        noise: {r.rule.noiseScore}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Full alerts DataTable */}
      <Card className="p-4 md:p-5">
        <SectionHeading
          title="All Alerts"
          description="Searchable, sortable, filterable table of every alert event"
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={alertRows}
            rowKey={(r) => r.alert.id}
            searchKeys={["alert", (r) => r.rule.name, (r) => r.service.name, (r) => r.alert.ref]}
            searchPlaceholder="Search by alert name, service, or ref..."
            pageSize={10}
            initialSort={{ key: "lastTriggered", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
