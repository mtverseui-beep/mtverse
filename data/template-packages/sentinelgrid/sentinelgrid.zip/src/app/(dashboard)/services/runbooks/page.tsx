"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { runbooks, services, people } from "@/lib/data";
import type { Runbook } from "@/lib/types";
import { toast } from "sonner";
import {
  BookOpen, Eye, Clock, Search, Download, Plus, Server,
  Filter, FileText, ArrowUpRight, GitBranch,
} from "lucide-react";

const categoryColor: Record<string, string> = {
  "Incident Response": "bg-destructive/15 text-destructive border-destructive/30",
  "Security": "bg-destructive/15 text-destructive border-destructive/30",
  "Performance": "bg-warning/15 text-warning-foreground border-warning/30",
  "Database": "bg-info/15 text-info-foreground border-info/30",
  "Infrastructure": "bg-accent text-accent-foreground border-accent/30",
  "Operations": "bg-primary/15 text-primary border-primary/30",
  "Build": "bg-muted text-muted-foreground border-border",
};

export default function RunbooksLibraryPage() {
  const router = useRouter();
  const [search, setSearch] = React.useState("");
  const [serviceFilter, setServiceFilter] = React.useState<string>("all");
  const [categoryFilter, setCategoryFilter] = React.useState<string>("all");

  const categories = ["all", ...Array.from(new Set(runbooks.map((r) => r.category)))];

  const filtered = React.useMemo(() => {
    let r = runbooks;
    if (search) {
      const q = search.toLowerCase();
      r = r.filter((rb) => rb.title.toLowerCase().includes(q) || rb.slug.toLowerCase().includes(q));
    }
    if (serviceFilter !== "all") r = r.filter((rb) => rb.serviceId === serviceFilter);
    if (categoryFilter !== "all") r = r.filter((rb) => rb.category === categoryFilter);
    return r;
  }, [search, serviceFilter, categoryFilter]);

  const totalViews = runbooks.reduce((s, r) => s + r.views, 0);
  const avgViews = Math.round(totalViews / runbooks.length);
  const mostViewed = [...runbooks].sort((a, b) => b.views - a.views)[0];

  function serviceOf(r: Runbook) {
    return services.find((s) => s.id === r.serviceId);
  }
  function authorOf(r: Runbook) {
    return people.find((p) => p.id === r.authorId);
  }

  return (
    <PageContainer>
      <PageHeader
        title="Runbooks Library"
        description="Operational runbooks for incident response, routine operations, and recovery procedures."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Services", href: "/services" }, { label: "Runbooks" }]}
        icon={<BookOpen className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening runbook editor")}>
              <Plus className="w-3.5 h-3.5" /> New Runbook
            </Button>
          </>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Runbooks" value={runbooks.length} icon={<BookOpen className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Categories" value={categories.length - 1} icon={<Filter className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg Views" value={avgViews} icon={<Eye className="w-4 h-4" />} accent="success" hint={`${totalViews.toLocaleString()} total views`} />
        <KpiCard label="Most Viewed" value={mostViewed.views} icon={<ArrowUpRight className="w-4 h-4" />} accent="accent" hint={mostViewed.title} />
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 md:items-center">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title..."
              className="pl-8 h-9 text-sm"
            />
          </div>
          <Select value={serviceFilter} onValueChange={setServiceFilter}>
            <SelectTrigger className="w-full md:w-[200px] h-9 text-xs">
              <SelectValue placeholder="All services" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All services</SelectItem>
              {services.map((s) => (
                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full md:w-[200px] h-9 text-xs">
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>{c === "all" ? "All categories" : c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="md:ml-auto text-xs text-muted-foreground">
            {filtered.length} of {runbooks.length} runbooks
          </div>
        </div>
      </Card>

      {/* Runbook grid */}
      {filtered.length === 0 ? (
        <Card className="p-12">
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-xl bg-muted border flex items-center justify-center text-muted-foreground mb-3">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-medium">No runbooks match filters</h3>
            <p className="text-xs text-muted-foreground mt-1">Try adjusting your search or filters.</p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((rb) => {
            const svc = serviceOf(rb);
            const author = authorOf(rb);
            const catColor = categoryColor[rb.category] || categoryColor.Operations;
            return (
              <Card key={rb.id} className="p-4 flex flex-col gap-3 hover:shadow-md hover:border-primary/30 transition-all">
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5 min-w-0">
                    <div className="shrink-0 w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 space-y-1">
                      <Link href={`/services/runbooks/${rb.id}`} className="text-sm font-semibold leading-tight hover:underline line-clamp-2">
                        {rb.title}
                      </Link>
                      <p className="text-[11px] text-muted-foreground font-mono">{rb.slug}</p>
                    </div>
                  </div>
                </div>

                {/* Badges */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${catColor}`}>
                    {rb.category}
                  </span>
                  {svc && (
                    <Link href={`/services/${svc.id}`} className="inline-flex items-center gap-1 rounded-md border border-border bg-muted px-1.5 py-0.5 text-[10px] font-medium hover:bg-muted/60">
                      <Server className="w-2.5 h-2.5" />
                      {svc.name}
                    </Link>
                  )}
                </div>

                {/* Steps preview */}
                <div className="space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{rb.steps.length} steps</p>
                  <div className="space-y-0.5 max-h-20 overflow-y-auto pr-1">
                    {rb.steps.slice(0, 3).map((s, i) => (
                      <div key={i} className="flex items-start gap-1.5 text-[11px]">
                        <span className="shrink-0 w-4 h-4 rounded-full bg-primary/10 text-primary flex items-center justify-center text-[9px] font-semibold mt-0.5">{i + 1}</span>
                        <span className="text-muted-foreground line-clamp-1">{s.title}</span>
                      </div>
                    ))}
                    {rb.steps.length > 3 && (
                      <p className="text-[10px] text-muted-foreground pl-5">+{rb.steps.length - 3} more</p>
                    )}
                  </div>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-border mt-auto">
                  <div className="flex items-center gap-2 min-w-0">
                    {author && (
                      <img src={author.avatarUrl} alt={author.name} title={author.name} className="w-5 h-5 rounded-full object-cover shrink-0" />
                    )}
                    <div className="flex items-center gap-2 text-[10px] text-muted-foreground min-w-0">
                      <span className="inline-flex items-center gap-0.5">
                        <Clock className="w-2.5 h-2.5" />
                        {rb.lastUpdated}
                      </span>
                      <span className="inline-flex items-center gap-0.5">
                        <Eye className="w-2.5 h-2.5" />
                        {rb.views}
                      </span>
                    </div>
                  </div>
                  <Button asChild size="sm" variant="outline" className="h-7 text-xs gap-1 shrink-0">
                    <Link href={`/services/runbooks/${rb.id}`}>
                      Open
                      <ArrowUpRight className="w-3 h-3" />
                    </Link>
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </PageContainer>
  );
}
