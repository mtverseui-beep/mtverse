"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SeverityBadge, IncidentStatusBadge } from "@/components/common/badges";
import { incidents, people, postmortems } from "@/lib/data";
import { toast } from "sonner";
import {
  Crown, Siren, Clock, CheckSquare, Plus, ChevronRight, ArrowUpRight,
  Zap, MessageSquare, CheckCircle2, FileText, Timer,
} from "lucide-react";

export default function CommanderViewPage() {
  const now = Date.now();
  // current user is u1 - Maya Okonkwo
  const currentUser = people.find((p) => p.id === "u1")!;
  const myIncidents = incidents.filter((i) => i.commanderId === "u1");
  const allMyIncidents = incidents.filter((i) => i.commanderId === "u1");
  const myActive = myIncidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");
  const resolved = allMyIncidents.filter((i) => i.status === "resolved");

  function formatDuration(startedAt: string, endedAt?: string) {
    const end = endedAt ? new Date(endedAt).getTime() : now;
    const diff = end - new Date(startedAt).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${mins % 60}m`;
    return `${mins}m`;
  }

  // calculate action items from postmortems authored or reviewed
  const myActionItems = postmortems.flatMap((p) => p.actionItems).filter((a) => a.ownerId === "u1" && a.status !== "done" && a.status !== "cancelled");

  const avgResolution = resolved.length > 0
    ? Math.round(resolved.reduce((a, i) => a + (i.resolutionSlaSeconds ?? 0), 0) / resolved.length / 60)
    : 0;

  return (
    <PageContainer>
      <PageHeader
        title="Commander View"
        description={`Incidents you command as ${currentUser.name}. Lead the response, track checklist progress, and follow through to postmortem.`}
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Commander" }]}
        icon={<Crown className="w-5 h-5" />}
        actions={
          <Button asChild size="sm" className="gap-1.5">
            <Link href="/incidents/new"><Plus className="w-3.5 h-3.5" /> Declare</Link>
          </Button>
        }
        meta={
          <div className="flex items-center gap-2">
            <Avatar className="w-6 h-6">
              <AvatarImage src={currentUser.avatarUrl} />
              <AvatarFallback>{currentUser.name[0]}</AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground">@{currentUser.handle}</span>
          </div>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Currently Commanding" value={myActive.length} hint="Active incidents" icon={<Siren className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Lifetime Commanded" value={allMyIncidents.length} hint="All time" icon={<Crown className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Avg Resolution" value={avgResolution} unit="min" hint="Across resolved" icon={<Clock className="w-4 h-4" />} accent="success" />
        <KpiCard label="Open Action Items" value={myActionItems.length} hint="From postmortems" icon={<CheckSquare className="w-4 h-4" />} accent="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-5">
            <SectionHeading
              title="Active Incidents You Command"
              description="Your current war rooms"
              action={<Button variant="ghost" size="sm" className="h-7 text-xs gap-1">All incidents <ChevronRight className="w-3 h-3" /></Button>}
            />
            {myActive.length === 0 ? (
              <EmptyState icon={<CheckCircle2 className="w-5 h-5" />} title="No active incidents" description="You're not currently commanding any incidents." />
            ) : (
              <div className="mt-4 space-y-3">
                {myActive.map((inc) => {
                  const responders = inc.responderIds.map((id) => people.find((p) => p.id === id)).filter(Boolean);
                  const checklistDone = inc.checklist.filter((c) => c.done).length;
                  const lastEvent = inc.timeline[inc.timeline.length - 1];
                  return (
                    <div key={inc.id} className="rounded-lg border p-4 hover:bg-elevated/40 transition-colors">
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap mb-1">
                            <span className="text-xs font-mono font-semibold text-muted-foreground">{inc.ref}</span>
                            <SeverityBadge severity={inc.severity} size="sm" />
                            <IncidentStatusBadge status={inc.status} />
                            <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                              <Timer className="w-3 h-3" />
                              {formatDuration(inc.startedAt)}
                            </span>
                          </div>
                          <h3 className="text-sm font-semibold line-clamp-1">{inc.title}</h3>
                        </div>
                        <Button asChild size="sm" variant="outline" className="shrink-0 h-8 text-xs gap-1">
                          <Link href={`/incidents/${inc.id}`}>Open <ArrowUpRight className="w-3 h-3" /></Link>
                        </Button>
                      </div>

                      <div className="grid grid-cols-3 gap-3 mb-3 text-xs">
                        <div>
                          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Responders</div>
                          <div className="flex -space-x-2 mt-1">
                            {responders.slice(0, 4).map((r) => r && (
                              <Avatar key={r.id} className="w-6 h-6 border-2 border-background">
                                <AvatarImage src={r.avatarUrl} />
                                <AvatarFallback>{r.name[0]}</AvatarFallback>
                              </Avatar>
                            ))}
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Checklist</div>
                          <div className="flex items-center gap-1.5 mt-1">
                            <Progress value={(checklistDone / inc.checklist.length) * 100} className="w-12 h-1.5" />
                            <span className="text-[11px] tabular-nums">{checklistDone}/{inc.checklist.length}</span>
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Impacted</div>
                          <div className="text-sm font-semibold tabular-nums mt-1">{inc.impactedUsers.toLocaleString()}</div>
                        </div>
                      </div>

                      {lastEvent && (
                        <div className="pt-3 border-t border-border flex items-start gap-2">
                          <MessageSquare className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
                          <p className="text-[11px] text-muted-foreground line-clamp-1 flex-1">
                            <span className="font-medium text-foreground">{people.find((p) => p.id === lastEvent.authorId)?.name ?? "System"}:</span> {lastEvent.message}
                          </p>
                          <span className="text-[10px] text-muted-foreground shrink-0">{new Date(lastEvent.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                        </div>
                      )}

                      <div className="flex gap-1.5 mt-3">
                        <Button variant="outline" size="sm" className="h-7 text-xs gap-1 flex-1" onClick={() => toast.success("Stakeholder update sent")}>
                          <MessageSquare className="w-3 h-3" /> Send Update
                        </Button>
                        <Button variant="outline" size="sm" className="h-7 text-xs gap-1 flex-1" onClick={() => toast.info("Escalation triggered")}>
                          <Zap className="w-3 h-3" /> Escalate
                        </Button>
                        <Button variant="default" size="sm" className="h-7 text-xs gap-1 flex-1" onClick={() => toast.success("Incident resolved")}>
                          <CheckCircle2 className="w-3 h-3" /> Resolve
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Recently Resolved" description="Incidents you commanded" />
            <div className="space-y-2">
              {resolved.length === 0 && <p className="text-xs text-muted-foreground">No resolved incidents.</p>}
              {resolved.map((inc) => (
                <Link key={inc.id} href={`/incidents/${inc.id}`} className="block p-2.5 rounded-md border hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-[10px] font-mono text-muted-foreground">{inc.ref}</span>
                    <SeverityBadge severity={inc.severity} size="sm" />
                  </div>
                  <div className="text-xs font-medium line-clamp-1">{inc.title}</div>
                  <div className="text-[11px] text-muted-foreground mt-1">
                    Resolved in {formatDuration(inc.startedAt, inc.resolvedAt)}
                  </div>
                </Link>
              ))}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading
              title="Open Action Items"
              description="From your postmortems"
              action={<Button variant="ghost" size="sm" className="h-7 text-xs gap-1">View all <ChevronRight className="w-3 h-3" /></Button>}
            />
            {myActionItems.length === 0 ? (
              <p className="text-xs text-muted-foreground">No open action items.</p>
            ) : (
              <div className="space-y-2">
                {myActionItems.slice(0, 6).map((a) => (
                  <div key={a.id} className="p-2.5 rounded-md border">
                    <div className="flex items-start gap-2">
                      <FileText className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium line-clamp-2">{a.description}</p>
                        <div className="flex items-center gap-1.5 mt-1">
                          <Badge variant="outline" className="text-[10px] h-4 capitalize">{a.status.replace(/_/g, " ")}</Badge>
                          <Badge variant="outline" className="text-[10px] h-4 capitalize">{a.type}</Badge>
                          <span className="text-[10px] text-muted-foreground ml-auto">Due {a.dueDate}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
