"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SeverityBadge } from "@/components/common/badges";
import { toast } from "sonner";
import {
  FileText, Plus, Clock, CheckSquare, ListChecks, ShieldAlert,
  AlertTriangle, Database, Server, Lock, ChevronRight, Eye,
} from "lucide-react";

interface IncidentTemplate {
  id: string;
  name: string;
  description: string;
  category: "outage" | "degradation" | "security" | "data";
  recommendedSeverity: "critical" | "high" | "medium" | "low";
  checklist: string[];
  estimatedDuration: string;
  responders: string[];
  icon: React.ReactNode;
}

const templates: IncidentTemplate[] = [
  {
    id: "tpl_outage_t1",
    name: "Tier-1 Service Outage",
    description: "Complete outage of a Tier-1 service (auth, payments, gateway) affecting all customers in one or more regions.",
    category: "outage",
    recommendedSeverity: "critical",
    checklist: [
      "Acknowledge within 2 minutes",
      "Page on-call engineer + manager",
      "Open war room (Slack + video bridge)",
      "Post initial public status update",
      "Identify blast radius",
      "Check recent deployments",
      "Engage service owner",
      "Escalate to executive if >15min",
      "Verify recovery after fix",
      "Schedule postmortem within 24h",
    ],
    estimatedDuration: "30-120 min",
    responders: ["On-call SRE", "Service owner", "Engineering manager", "Incident commander"],
    icon: <ShieldAlert className="w-5 h-5" />,
  },
  {
    id: "tpl_degradation",
    name: "Service Degradation",
    description: "Increased latency, error rate, or partial unavailability of a service. Customers impacted but service is still usable.",
    category: "degradation",
    recommendedSeverity: "high",
    checklist: [
      "Acknowledge within 5 minutes",
      "Page on-call engineer",
      "Identify scope and impact",
      "Check dashboards and recent changes",
      "Notify stakeholders",
      "Apply mitigation",
      "Monitor recovery",
      "Resolve once stable for 15 min",
      "Schedule postmortem if customer-impacting",
    ],
    estimatedDuration: "20-90 min",
    responders: ["On-call SRE", "Service owner"],
    icon: <AlertTriangle className="w-5 h-5" />,
  },
  {
    id: "tpl_security",
    name: "Security Incident",
    description: "Suspected or confirmed security breach, vulnerability exploitation, or unauthorized access. Requires security team engagement.",
    category: "security",
    recommendedSeverity: "critical",
    checklist: [
      "Acknowledge within 2 minutes",
      "Page security on-call + CISO",
      "Engage legal and compliance",
      "Preserve forensic evidence",
      "Contain the breach (rotate keys, block IPs)",
      "Assess data exposure scope",
      "Notify executives and legal",
      "Prepare customer disclosure if required",
      "Coordinate with law enforcement if needed",
      "Schedule security postmortem",
    ],
    estimatedDuration: "Hours to days",
    responders: ["Security on-call", "CISO", "Legal", "Incident commander", "Comms"],
    icon: <Lock className="w-5 h-5" />,
  },
  {
    id: "tpl_data",
    name: "Data Incident",
    description: "Data loss, corruption, or unauthorized data access. Includes production DB issues, missing backups, or data leak.",
    category: "data",
    recommendedSeverity: "critical",
    checklist: [
      "Acknowledge within 5 minutes",
      "Page DBA + service owner",
      "Stop write traffic if needed",
      "Identify scope of data affected",
      "Engage backup/restore process",
      "Notify data protection officer",
      "Assess regulatory notification requirements",
      "Restore from backup if needed",
      "Verify data integrity post-restore",
      "Schedule postmortem",
    ],
    estimatedDuration: "1-8 hours",
    responders: ["DBA", "Service owner", "Data protection officer", "Incident commander"],
    icon: <Database className="w-5 h-5" />,
  },
  {
    id: "tpl_partial_outage",
    name: "Single-Region Partial Outage",
    description: "Loss of service in a single region with multi-region failover available. Customers in affected region impacted.",
    category: "outage",
    recommendedSeverity: "high",
    checklist: [
      "Acknowledge within 5 minutes",
      "Trigger regional failover",
      "Verify failover success",
      "Notify customers in affected region",
      "Investigate root cause of regional failure",
      "Restore original region once stable",
      "Verify traffic distribution",
      "Schedule postmortem",
    ],
    estimatedDuration: "30-90 min",
    responders: ["On-call SRE", "Infra lead", "Incident commander"],
    icon: <Server className="w-5 h-5" />,
  },
  {
    id: "tpl_perf_regression",
    name: "Performance Regression",
    description: "Latency or throughput regression detected via synthetic monitoring or RUM. May not be customer-impacting yet.",
    category: "degradation",
    recommendedSeverity: "medium",
    checklist: [
      "Acknowledge within 15 minutes",
      "Identify affected endpoints/services",
      "Check recent deployments for regressions",
      "Roll back suspect deployment if needed",
      "Verify metrics return to baseline",
      "Document regression in postmortem",
    ],
    estimatedDuration: "30-60 min",
    responders: ["Service owner", "Performance engineer"],
    icon: <Clock className="w-5 h-5" />,
  },
];

const categoryConfig: Record<IncidentTemplate["category"], { label: string; className: string }> = {
  outage: { label: "Outage", className: "bg-destructive/15 text-destructive border-destructive/30" },
  degradation: { label: "Degradation", className: "bg-warning/15 text-warning-foreground border-warning/30" },
  security: { label: "Security", className: "bg-accent text-accent-foreground border-accent/30" },
  data: { label: "Data", className: "bg-info/15 text-info-foreground border-info/30" },
};

export default function IncidentTemplatesPage() {
  const router = useRouter();
  const [filter, setFilter] = React.useState<"all" | IncidentTemplate["category"]>("all");

  const filtered = filter === "all" ? templates : templates.filter((t) => t.category === filter);

  return (
    <PageContainer>
      <PageHeader
        title="Incident Templates"
        description="Pre-defined templates for common incident types. Each template includes a recommended severity, checklist, and responder roster."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Templates" }]}
        icon={<FileText className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.info("New template editor opened")}>
            <Plus className="w-3.5 h-3.5" /> New Template
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Templates" value={templates.length} hint="Available to use" icon={<FileText className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Avg Checklist Steps" value={Math.round(templates.reduce((a, t) => a + t.checklist.length, 0) / templates.length)} hint="Per template" icon={<ListChecks className="w-4 h-4" />} accent="info" />
        <KpiCard label="Critical Severity" value={templates.filter((t) => t.recommendedSeverity === "critical").length} hint="Templates for major incidents" icon={<ShieldAlert className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Categories" value={Object.keys(categoryConfig).length} hint="Outage, degradation, security, data" icon={<AlertTriangle className="w-4 h-4" />} accent="accent" />
      </div>

      <Card className="p-4">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-medium">Category:</span>
          {(["all", "outage", "degradation", "security", "data"] as const).map((c) => (
            <Button key={c} variant={filter === c ? "default" : "outline"} size="sm" className="h-7 text-xs capitalize" onClick={() => setFilter(c)}>
              {c === "all" ? "All" : categoryConfig[c].label}
            </Button>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((t) => (
          <Card key={t.id} className="p-5 flex flex-col hover:bg-elevated/30 transition-colors">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-muted border flex items-center justify-center text-foreground">
                {t.icon}
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <Badge className={`text-[10px] ${categoryConfig[t.category].className}`}>{categoryConfig[t.category].label}</Badge>
                <SeverityBadge severity={t.recommendedSeverity} size="sm" />
              </div>
            </div>
            <h3 className="text-sm font-semibold mb-1">{t.name}</h3>
            <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{t.description}</p>

            <div className="grid grid-cols-2 gap-2 text-xs mb-3">
              <div className="rounded-md border p-2">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Est. Duration</div>
                <div className="text-xs font-medium mt-0.5">{t.estimatedDuration}</div>
              </div>
              <div className="rounded-md border p-2">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Checklist</div>
                <div className="text-xs font-medium mt-0.5">{t.checklist.length} steps</div>
              </div>
            </div>

            <div className="mb-3">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Responders</div>
              <div className="flex flex-wrap gap-1">
                {t.responders.map((r) => (
                  <Badge key={r} variant="outline" className="text-[10px] h-5">{r}</Badge>
                ))}
              </div>
            </div>

            <div className="mb-3">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Checklist preview</div>
              <ul className="space-y-1 max-h-24 overflow-y-auto pr-1 custom-scroll">
                {t.checklist.slice(0, 4).map((c, i) => (
                  <li key={i} className="text-[11px] text-muted-foreground flex items-start gap-1.5">
                    <CheckSquare className="w-3 h-3 mt-0.5 shrink-0" /> {c}
                  </li>
                ))}
                {t.checklist.length > 4 && <li className="text-[10px] text-muted-foreground">+ {t.checklist.length - 4} more</li>}
              </ul>
            </div>

            <div className="flex gap-1.5 mt-auto">
              <Button size="sm" className="flex-1 h-8 text-xs gap-1.5" onClick={() => { toast.success(`Started incident from ${t.name}`); router.push("/incidents/new"); }}>
                Use Template <ChevronRight className="w-3 h-3" />
              </Button>
              <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => toast.info("Preview opened")}>
                <Eye className="w-3.5 h-3.5" />
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <Card>
          <EmptyState icon={<FileText className="w-5 h-5" />} title="No templates match" description="Try a different category filter." />
        </Card>
      )}
    </PageContainer>
  );
}
