"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SeverityBadge } from "@/components/common/badges";
import { toast } from "sonner";
import {
  AlertTriangle, Plus, Save, Trash2, Pencil, ShieldAlert,
  AlertOctagon, Info, X, Check, Server,
} from "lucide-react";

interface SeverityRule {
  id: string;
  name: string;
  condition: string;
  severity: "critical" | "high" | "medium" | "low";
  examples: string[];
  enabled: boolean;
}

const initialRules: SeverityRule[] = [
  {
    id: "sr1",
    name: "Tier-1 service down",
    condition: "service.tier == 1 AND service.health == 'major_outage'",
    severity: "critical",
    examples: ["auth-service unavailable in us-east-1", "payments-api 5xx > 50%"],
    enabled: true,
  },
  {
    id: "sr2",
    name: "Single region degraded",
    condition: "service.health == 'degraded' AND affected_regions == 1",
    severity: "high",
    examples: ["checkout latency p99 > 2s in eu-west-1", "API gateway errors in ap-south-1"],
    enabled: true,
  },
  {
    id: "sr3",
    name: "Multi-region outage",
    condition: "service.health IN ['partial_outage', 'major_outage'] AND affected_regions >= 2",
    severity: "critical",
    examples: ["Auth down in us-east-1 and us-west-2", "Payments unavailable globally"],
    enabled: true,
  },
  {
    id: "sr4",
    name: "Performance regression",
    condition: "p95_latency > baseline * 1.5 AND customer_impact == 'none'",
    severity: "medium",
    examples: ["Web LCP regressed from 1.8s to 2.7s", "API p99 +30% over baseline"],
    enabled: true,
  },
  {
    id: "sr5",
    name: "Background job backlog",
    condition: "queue_depth > 10000 AND customer_impact == 'delayed'",
    severity: "medium",
    examples: ["Invoice queue > 14k pending", "Webhook delivery backlog"],
    enabled: true,
  },
  {
    id: "sr6",
    name: "Non-customer-impacting alert",
    condition: "customer_impact == 'none' AND service.tier IN [3, 4]",
    severity: "low",
    examples: ["Internal tool degraded", "Staging environment slow"],
    enabled: false,
  },
];

const sevConfig = [
  { value: "critical", label: "Critical", icon: ShieldAlert },
  { value: "high", label: "High", icon: AlertTriangle },
  { value: "medium", label: "Medium", icon: Info },
  { value: "low", label: "Low", icon: AlertOctagon },
] as const;

export default function SeverityRulesPage() {
  const [rules, setRules] = React.useState<SeverityRule[]>(initialRules);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [newRule, setNewRule] = React.useState<Partial<SeverityRule> | null>(null);

  function toggleRule(id: string) {
    setRules((r) => r.map((x) => x.id === id ? { ...x, enabled: !x.enabled } : x));
    toast.success("Rule updated");
  }

  function deleteRule(id: string) {
    setRules((r) => r.filter((x) => x.id !== id));
    toast.success("Rule deleted");
  }

  function saveEdit(id: string, updated: SeverityRule) {
    setRules((r) => r.map((x) => x.id === id ? updated : x));
    setEditingId(null);
    toast.success("Rule saved");
  }

  function createRule() {
    if (!newRule?.name || !newRule?.condition) {
      toast.error("Name and condition are required");
      return;
    }
    const rule: SeverityRule = {
      id: `sr${Date.now()}`,
      name: newRule.name,
      condition: newRule.condition,
      severity: newRule.severity ?? "medium",
      examples: newRule.examples ?? [],
      enabled: true,
    };
    setRules((r) => [...r, rule]);
    setNewRule(null);
    toast.success("Rule created");
  }

  return (
    <PageContainer>
      <PageHeader
        title="Severity Rules"
        description="Map alert conditions to incident severity levels. These rules run automatically when an incident is declared from an alert."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Severity Rules" }]}
        icon={<AlertTriangle className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setNewRule({ name: "", condition: "", severity: "medium", examples: [] })}>
            <Plus className="w-3.5 h-3.5" /> New Rule
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-3">
          {rules.map((rule) => {
            const isEditing = editingId === rule.id;
            if (isEditing) {
              return <RuleEditor key={rule.id} rule={rule} onSave={(r) => saveEdit(rule.id, r)} onCancel={() => setEditingId(null)} />;
            }
            return (
              <Card key={rule.id} className={`p-4 ${!rule.enabled ? "opacity-60" : ""}`}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <h3 className="text-sm font-semibold">{rule.name}</h3>
                      <SeverityBadge severity={rule.severity} size="sm" />
                    </div>
                    <code className="text-[11px] font-mono text-muted-foreground block bg-muted px-2 py-1 rounded">{rule.condition}</code>
                  </div>
                  <label className="flex items-center gap-1 text-[11px] text-muted-foreground shrink-0 cursor-pointer">
                    <input type="checkbox" checked={rule.enabled} onChange={() => toggleRule(rule.id)} className="accent-primary w-3.5 h-3.5" />
                    <span>{rule.enabled ? "Enabled" : "Disabled"}</span>
                  </label>
                </div>
                {rule.examples.length > 0 && (
                  <div className="mt-2">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Examples</div>
                    <div className="space-y-1">
                      {rule.examples.map((ex, i) => (
                        <div key={i} className="text-[11px] text-muted-foreground flex items-start gap-1.5">
                          <Server className="w-3 h-3 mt-0.5 shrink-0" /> {ex}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-border">
                  <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => setEditingId(rule.id)}>
                    <Pencil className="w-3 h-3" /> Edit
                  </Button>
                  <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-destructive" onClick={() => deleteRule(rule.id)}>
                    <Trash2 className="w-3 h-3" /> Delete
                  </Button>
                </div>
              </Card>
            );
          })}

          {newRule && (
            <RuleEditor
              rule={newRule as SeverityRule}
              isNew
              onSave={(r) => createRule()}
              onCancel={() => setNewRule(null)}
              onChange={setNewRule}
            />
          )}

          {rules.length === 0 && !newRule && (
            <Card><EmptyState icon={<AlertTriangle className="w-5 h-5" />} title="No severity rules" description="Create a rule to start mapping conditions to severities." /></Card>
          )}
        </div>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Severity Reference" description="Quick guide to severity levels" />
            <div className="space-y-2">
              {sevConfig.map((s) => {
                const Icon = s.icon;
                return (
                  <div key={s.value} className="flex items-start gap-2.5 p-2 rounded-md border">
                    <Icon className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5" />
                    <div className="min-w-0">
                      <div className="text-xs font-medium">{s.label}</div>
                      <div className="text-[11px] text-muted-foreground">
                        {s.value === "critical" && "Tier-1 down, multi-region, broad impact"}
                        {s.value === "high" && "Significant degradation, regional impact"}
                        {s.value === "medium" && "Limited impact, performance regression"}
                        {s.value === "low" && "Minor issue, no customer impact"}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Condition Syntax" description="Supported operators" />
            <div className="space-y-1.5 text-xs">
              {[
                "==", "!=", ">", "<", ">=", "<=",
                "IN", "AND", "OR", "NOT",
                "* (wildcard)", "baseline * N",
              ].map((op) => (
                <div key={op} className="flex items-center gap-2 p-1.5 rounded border">
                  <code className="font-mono text-primary text-[11px]">{op}</code>
                </div>
              ))}
            </div>
            <div className="text-[11px] text-muted-foreground pt-2 border-t border-border">
              Available fields: <code className="font-mono">service.tier</code>, <code className="font-mono">service.health</code>, <code className="font-mono">affected_regions</code>, <code className="font-mono">customer_impact</code>, <code className="font-mono">p95_latency</code>, <code className="font-mono">queue_depth</code>
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}

function RuleEditor({
  rule, onSave, onCancel, isNew, onChange,
}: {
  rule: SeverityRule;
  onSave: (r: SeverityRule) => void;
  onCancel: () => void;
  isNew?: boolean;
  onChange?: (r: Partial<SeverityRule>) => void;
}) {
  const [local, setLocal] = React.useState<SeverityRule>(rule);
  return (
    <Card className="p-4 border-primary/30 bg-primary/5">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-semibold uppercase tracking-wider text-primary">{isNew ? "New Rule" : "Edit Rule"}</span>
        <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={onCancel}><X className="w-3.5 h-3.5" /></Button>
      </div>
      <div className="space-y-3">
        <div>
          <Label className="text-xs">Name</Label>
          <Input value={local.name} onChange={(e) => { const v = { ...local, name: e.target.value }; setLocal(v); onChange?.(v); }} className="mt-1.5 h-8 text-sm" />
        </div>
        <div>
          <Label className="text-xs">Condition</Label>
          <Input value={local.condition} onChange={(e) => { const v = { ...local, condition: e.target.value }; setLocal(v); onChange?.(v); }} className="mt-1.5 h-8 text-sm font-mono" />
        </div>
        <div>
          <Label className="text-xs">Severity</Label>
          <div className="flex items-center gap-1.5 mt-1.5">
            {sevConfig.map((s) => (
              <button key={s.value} onClick={() => { const v = { ...local, severity: s.value }; setLocal(v); onChange?.(v); }} className={`px-2 py-1 rounded-md border text-[11px] font-medium ${local.severity === s.value ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"}`}>
                {s.label}
              </button>
            ))}
          </div>
        </div>
        <div className="flex justify-end gap-1.5 pt-2">
          <Button variant="outline" size="sm" className="h-8 text-xs gap-1" onClick={onCancel}>Cancel</Button>
          <Button size="sm" className="h-8 text-xs gap-1" onClick={() => onSave(local)}><Save className="w-3 h-3" /> Save</Button>
        </div>
      </div>
    </Card>
  );
}
