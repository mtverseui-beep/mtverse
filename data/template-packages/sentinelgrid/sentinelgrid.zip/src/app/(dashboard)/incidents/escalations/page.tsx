"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { SeverityBadge } from "@/components/common/badges";
import { incidents, people, escalationPolicies } from "@/lib/data";
import type { IncidentTimelineEvent } from "@/lib/types";
import {
  TrendingUp, Zap, Clock, CheckCircle2, AlertTriangle, Phone,
  ChevronRight, Activity,
} from "lucide-react";

export default function EscalationsPage() {
  const escalationEvents = React.useMemo(() => {
    return incidents
      .flatMap((i) => i.timeline.filter((t) => t.kind === "escalated" || t.kind === "acknowledged").map((t) => ({ ...t, incident: i })))
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, []);

  // Build mock escalation stats per policy
  const policyStats = escalationPolicies.map((p, idx) => ({
    ...p,
    triggers: [3, 1, 5, 2][idx] ?? 0,
    avgAckMinutes: [2.4, 1.8, 4.2, 3.1][idx] ?? 0,
    escalationRate: [12, 8, 24, 16][idx] ?? 0,
    effectiveness: [92, 95, 78, 88][idx] ?? 0,
  }));

  const ttaStats = {
    p50: 2.4,
    p90: 5.8,
    p99: 11.2,
    target: 5,
  };

  return (
    <PageContainer>
      <PageHeader
        title="Escalations"
        description="Escalation events, time-to-acknowledge metrics, and policy effectiveness across incidents."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Escalations" }]}
        icon={<TrendingUp className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Escalations (30d)" value={policyStats.reduce((a, p) => a + p.triggers, 0)} hint="All policies" icon={<Zap className="w-4 h-4" />} accent="destructive" delta={4} deltaLabel="vs prior" />
        <KpiCard label="P50 Ack Time" value={ttaStats.p50} unit="min" hint="Target 5 min" icon={<Clock className="w-4 h-4" />} accent="success" delta={-12} deltaLabel="improving" />
        <KpiCard label="P99 Ack Time" value={ttaStats.p99} unit="min" hint="Slowest decile" icon={<AlertTriangle className="w-4 h-4" />} accent="warning" delta={3} deltaLabel="vs prior" />
        <KpiCard label="Policy Effectiveness" value="88%" hint="Avg across policies" icon={<CheckCircle2 className="w-4 h-4" />} accent="primary" delta={2} deltaLabel="vs prior" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <SectionHeading title="Escalation & Acknowledgment Log" description="Chronological log of escalations and acknowledgments" />
          <div className="mt-4 space-y-2 max-h-[560px] overflow-y-auto pr-1 custom-scroll">
            {escalationEvents.length === 0 ? (
              <EmptyState icon={<Zap className="w-5 h-5" />} title="No escalations" description="No escalation events recorded." />
            ) : (
              escalationEvents.map((evt) => {
                const author = people.find((p) => p.id === evt.authorId);
                const isEscalation = evt.kind === "escalated";
                return (
                  <div key={evt.id} className={`rounded-lg border p-3 ${isEscalation ? "border-destructive/30 bg-destructive/5" : "border-border"}`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-8 h-8 rounded-full border flex items-center justify-center shrink-0 ${isEscalation ? "bg-destructive/15 text-destructive border-destructive/30" : "bg-success/15 text-success border-success/30"}`}>
                        {isEscalation ? <Zap className="w-3.5 h-3.5" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="outline" className={`text-[10px] capitalize h-4 ${isEscalation ? "bg-destructive/10 text-destructive" : "bg-success/10 text-success"}`}>
                            {evt.kind}
                          </Badge>
                          <Link href={`/incidents/${evt.incident.id}`} className="text-[10px] font-mono text-primary hover:underline">{evt.incident.ref}</Link>
                          <SeverityBadge severity={evt.incident.severity} size="sm" />
                          <span className="text-[11px] text-muted-foreground ml-auto">{new Date(evt.timestamp).toLocaleString()}</span>
                        </div>
                        <p className="text-xs mt-1.5">{evt.message}</p>
                        {author && (
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <Avatar className="w-5 h-5">
                              <AvatarImage src={author.avatarUrl} />
                              <AvatarFallback>{author.name[0]}</AvatarFallback>
                            </Avatar>
                            <span className="text-[10px] text-muted-foreground">{author.name}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Time to Acknowledge" description="Distribution across incidents" />
            <div className="space-y-2.5">
              {[
                { label: "P50", value: ttaStats.p50, target: ttaStats.target, color: "bg-success" },
                { label: "P90", value: ttaStats.p90, target: ttaStats.target, color: "bg-warning" },
                { label: "P99", value: ttaStats.p99, target: ttaStats.target, color: "bg-destructive" },
              ].map((s) => (
                <div key={s.label}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium">{s.label}</span>
                    <span className="tabular-nums">{s.value.toFixed(1)} min</span>
                  </div>
                  <div className="relative h-2 rounded-full bg-muted overflow-hidden">
                    <div className={`absolute left-0 top-0 h-full ${s.color}`} style={{ width: `${Math.min((s.value / (ttaStats.target * 2)) * 100, 100)}%` }} />
                    <div className="absolute top-0 h-full w-px bg-foreground/40" style={{ left: `${(ttaStats.target / (ttaStats.target * 2)) * 100}%` }} />
                  </div>
                </div>
              ))}
              <div className="flex items-center justify-between text-[11px] text-muted-foreground pt-1">
                <span>Target: {ttaStats.target} min</span>
                <span>| = target marker</span>
              </div>
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Escalation Policies" description="Effectiveness by policy" />
            <div className="space-y-2">
              {policyStats.map((p) => (
                <div key={p.id} className="rounded-md border p-2.5">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-medium">{p.name}</span>
                    <Badge variant="outline" className="text-[10px] h-4">{p.triggers} triggers</Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[10px] mb-2">
                    <div>
                      <div className="text-muted-foreground">Avg ack</div>
                      <div className="font-semibold tabular-nums">{p.avgAckMinutes}m</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Esc. rate</div>
                      <div className="font-semibold tabular-nums">{p.escalationRate}%</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Effective</div>
                      <div className="font-semibold tabular-nums text-success">{p.effectiveness}%</div>
                    </div>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className="h-full bg-success" style={{ width: `${p.effectiveness}%` }} />
                  </div>
                </div>
              ))}
            </div>
            <Button asChild variant="outline" size="sm" className="w-full h-8 text-xs gap-1">
              <Link href="/oncall/escalation">Manage policies <ChevronRight className="w-3 h-3" /></Link>
            </Button>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
