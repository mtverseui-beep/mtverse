"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { SeverityBadge } from "@/components/common/badges";
import { incidents, people } from "@/lib/data";
import { toast } from "sonner";
import {
  Mail, Globe, MessageSquare, Send, FileText, Users, Bell,
  ExternalLink, ChevronRight, Smartphone, Newspaper,
} from "lucide-react";

interface CommsTemplate {
  id: string;
  name: string;
  channel: "status_page" | "email" | "slack";
  audience: string;
  body: string;
}

const templates: CommsTemplate[] = [
  {
    id: "t1",
    name: "Initial investigation (status page)",
    channel: "status_page",
    audience: "Public",
    body: "We are currently investigating reports of {{impact_summary}}. We will provide an update as soon as we have more information.",
  },
  {
    id: "t2",
    name: "Identified root cause (status page)",
    channel: "status_page",
    audience: "Public",
    body: "We have identified the cause of {{issue}} and are working on a fix. Estimated time to resolution: {{eta}}.",
  },
  {
    id: "t3",
    name: "Stakeholder escalation email",
    channel: "email",
    audience: "Stakeholders",
    body: "Executive summary: {{incident_ref}} is {{severity}} severity. Impact: {{impact}}. Commander: {{commander}}. Next update in 30 minutes.",
  },
  {
    id: "t4",
    name: "Resolved (status page)",
    channel: "status_page",
    audience: "Public",
    body: "The issue has been resolved and all systems are operating normally. We apologize for any inconvenience.",
  },
  {
    id: "t5",
    name: "Slack incident declaration",
    channel: "slack",
    audience: "Internal",
    body: "Incident {{ref}} declared. Severity: {{severity}}. Commander: {{commander}}. War room: {{war_room}}. Please join if you can help.",
  },
  {
    id: "t6",
    name: "SMS critical page",
    channel: "slack",
    audience: "On-call",
    body: "CRITICAL: {{ref}} - {{title}}. Acknowledge at {{ack_url}}.",
  },
];

const channelConfig: Record<CommsTemplate["channel"], { label: string; className: string; icon: React.ReactNode }> = {
  status_page: { label: "Status Page", className: "bg-success/15 text-success border-success/30", icon: <Globe className="w-3 h-3" /> },
  email: { label: "Email", className: "bg-accent text-accent-foreground border-accent/30", icon: <Mail className="w-3 h-3" /> },
  slack: { label: "Slack", className: "bg-primary/15 text-primary border-primary/30", icon: <MessageSquare className="w-3 h-3" /> },
};

export default function CommunicationsPage() {
  const [activeTemplate, setActiveTemplate] = React.useState<CommsTemplate>(templates[0]);
  const [body, setBody] = React.useState(templates[0].body);
  const [selectedIncident, setSelectedIncident] = React.useState(incidents[0].id);

  function selectTemplate(t: CommsTemplate) {
    setActiveTemplate(t);
    setBody(t.body);
  }

  function send() {
    toast.success(`${channelConfig[activeTemplate.channel].label} update sent`);
  }

  // Recent comms sent (mock)
  const recentComms = incidents.flatMap((i) =>
    i.updates.map((u) => {
      const author = people.find((p) => p.id === u.authorId);
      const channel = u.audience === "public" ? "status_page" : u.audience === "stakeholder" ? "email" : "slack";
      return { ...u, incident: i, author, channel: channel as CommsTemplate["channel"] };
    })
  ).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <PageContainer>
      <PageHeader
        title="Communications Center"
        description="Manage outbound communications across public status page, stakeholder emails, and Slack notifications."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Communications" }]}
        icon={<Mail className="w-5 h-5" />}
        actions={
          <Button asChild size="sm" variant="outline" className="gap-1.5">
            <Link href="/incidents/status-page">View status page <ExternalLink className="w-3.5 h-3.5" /></Link>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Comms Sent (30d)" value={recentComms.length} hint="Across all channels" icon={<Send className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Public Updates" value={recentComms.filter((c) => c.channel === "status_page").length} hint="Posted to status page" icon={<Globe className="w-4 h-4" />} accent="success" />
        <KpiCard label="Stakeholder Emails" value={recentComms.filter((c) => c.channel === "email").length} hint="Sent to subscribers" icon={<Mail className="w-4 h-4" />} accent="accent" />
        <KpiCard label="Slack Notifications" value={recentComms.filter((c) => c.channel === "slack").length} hint="Posted to channels" icon={<MessageSquare className="w-4 h-4" />} accent="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2 space-y-4">
          <SectionHeading title="Compose" description="Pick a template, edit, and send" />
          <div>
            <label className="text-xs font-medium text-muted-foreground">Incident</label>
            <select value={selectedIncident} onChange={(e) => setSelectedIncident(e.target.value)} className="mt-1.5 w-full rounded-md border bg-background px-3 py-2 text-sm">
              {incidents.map((i) => <option key={i.id} value={i.id}>{i.ref} — {i.title}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Message body</label>
            <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={6} className="mt-1.5 text-sm" />
            <p className="text-[10px] text-muted-foreground mt-1">Use tokens like {`{{impact_summary}}`}, {`{{severity}}`}, {`{{commander}}`} — they'll be replaced on send.</p>
          </div>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-muted-foreground">Channel:</span>
              <Badge className={`gap-1 ${channelConfig[activeTemplate.channel].className}`}>{channelConfig[activeTemplate.channel].icon} {channelConfig[activeTemplate.channel].label}</Badge>
            </div>
            <div className="flex gap-1.5">
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast.success("Saved as draft")}>
                <FileText className="w-3 h-3" /> Save Draft
              </Button>
              <Button size="sm" className="h-8 text-xs gap-1.5" onClick={send}>
                <Send className="w-3 h-3" /> Send Now
              </Button>
            </div>
          </div>
        </Card>

        <Card className="p-5 space-y-3">
          <SectionHeading title="Templates" description="Reusable message templates" />
          <div className="space-y-1.5 max-h-[460px] overflow-y-auto pr-1 custom-scroll">
            {templates.map((t) => {
              const c = channelConfig[t.channel];
              const active = activeTemplate.id === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => selectTemplate(t)}
                  className={`w-full text-left p-2.5 rounded-md border transition-colors ${active ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className={`inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-[10px] font-medium ${c.className}`}>{c.icon} {c.label}</span>
                    {active && <Badge variant="default" className="text-[10px] h-4 ml-auto">Selected</Badge>}
                  </div>
                  <div className="text-xs font-medium line-clamp-1">{t.name}</div>
                  <div className="text-[11px] text-muted-foreground line-clamp-2 mt-0.5">{t.body}</div>
                </button>
              );
            })}
          </div>
        </Card>
      </div>

      <Card className="p-5">
        <SectionHeading
          title="Recent Communications"
          description="Outbound messages across all channels"
          action={<Button variant="ghost" size="sm" className="h-7 text-xs gap-1">View all <ChevronRight className="w-3 h-3" /></Button>}
        />
        <div className="mt-4 space-y-2 max-h-[480px] overflow-y-auto pr-1 custom-scroll">
          {recentComms.length === 0 ? (
            <EmptyState icon={<Send className="w-5 h-5" />} title="No communications yet" />
          ) : (
            recentComms.map((c) => {
              const ch = channelConfig[c.channel];
              return (
                <div key={c.id} className="rounded-lg border p-3 hover:bg-elevated/30 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <Badge className={`gap-1 ${ch.className}`}>{ch.icon} {ch.label}</Badge>
                        <Link href={`/incidents/${c.incident.id}`} className="text-[10px] font-mono text-primary hover:underline">{c.incident.ref}</Link>
                        <SeverityBadge severity={c.incident.severity} size="sm" />
                        <span className="text-[11px] text-muted-foreground ml-auto">{new Date(c.timestamp).toLocaleString()}</span>
                      </div>
                      <p className="text-xs text-foreground line-clamp-2">{c.body}</p>
                      {c.author && (
                        <div className="flex items-center gap-1.5 mt-1.5">
                          <Avatar className="w-5 h-5">
                            <AvatarImage src={c.author.avatarUrl} />
                            <AvatarFallback>{c.author.name[0]}</AvatarFallback>
                          </Avatar>
                          <span className="text-[10px] text-muted-foreground">{c.author.name}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </Card>
    </PageContainer>
  );
}
