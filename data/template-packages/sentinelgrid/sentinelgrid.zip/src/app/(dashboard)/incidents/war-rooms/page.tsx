"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SeverityBadge, IncidentStatusBadge, StatusDot } from "@/components/common/badges";
import { incidents, people } from "@/lib/data";
import { toast } from "sonner";
import {
  Siren, Radio, Users, MessageSquare, ExternalLink, Timer,
  Video, Phone, Plus, ShieldAlert, ArrowUpRight,
} from "lucide-react";

const sevColor: Record<string, string> = {
  critical: "border-l-destructive",
  high: "border-l-warning",
  medium: "border-l-info",
  low: "border-l-muted-foreground",
};

export default function WarRoomsPage() {
  const now = Date.now();
  const active = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");

  function formatDuration(startedAt: string) {
    const diff = now - new Date(startedAt).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h ${mins % 60}m`;
    if (hours > 0) return `${hours}h ${mins % 60}m`;
    return `${mins}m`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="War Rooms"
        description="Live coordination channels for each active incident. Join the bridge, page additional responders, or post updates."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "War Rooms" }]}
        icon={<Radio className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.info("Create war room dialog opened")}>
            <Plus className="w-3.5 h-3.5" /> Open War Room
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Live War Rooms" value={active.length} hint="Currently active" icon={<Radio className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Total Responders" value={active.reduce((a, i) => a + i.responderIds.length, 0)} hint="Across all war rooms" icon={<Users className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Slack Channels" value={active.length} hint="One per incident" icon={<MessageSquare className="w-4 h-4" />} accent="accent" />
        <KpiCard label="Longest Running" value={active.length > 0 ? formatDuration([...active].sort((a, b) => new Date(a.startedAt).getTime() - new Date(b.startedAt).getTime())[0].startedAt) : "—"} hint="Time since open" icon={<Timer className="w-4 h-4" />} accent="warning" />
      </div>

      {active.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Radio className="w-5 h-5" />}
            title="No active war rooms"
            description="When an incident is declared, a war room is automatically created."
            action={<Button asChild size="sm"><Link href="/incidents/new">Declare Incident</Link></Button>}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {active.map((inc) => {
            const commander = people.find((p) => p.id === inc.commanderId);
            const responders = inc.responderIds.map((id) => people.find((p) => p.id === id)).filter(Boolean);
            const lastEvent = inc.timeline[inc.timeline.length - 1];
            const lastAuthor = lastEvent ? people.find((p) => p.id === lastEvent.authorId) : null;
            const isCritical = inc.severity === "critical" || inc.severity === "high";
            return (
              <Card key={inc.id} className={`p-5 border-l-4 ${sevColor[inc.severity]} flex flex-col`}>
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
                      <span className="text-xs font-mono font-semibold text-muted-foreground">{inc.ref}</span>
                      <SeverityBadge severity={inc.severity} size="sm" />
                      <IncidentStatusBadge status={inc.status} />
                      <Badge variant="outline" className="text-[10px] gap-1 h-5"><StatusDot color={isCritical ? "destructive" : "warning"} pulse /> Live</Badge>
                    </div>
                    <h3 className="text-sm font-semibold line-clamp-1">{inc.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{inc.customerImpact}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Duration</div>
                    <div className="text-sm font-semibold tabular-nums flex items-center gap-1 justify-end mt-0.5">
                      <Timer className="w-3 h-3 text-muted-foreground" />
                      {formatDuration(inc.startedAt)}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="rounded-lg border p-3 space-y-2">
                    <div className="flex items-center gap-1.5">
                      <ShieldAlert className="w-3.5 h-3.5 text-primary" />
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Commander</span>
                    </div>
                    {commander && (
                      <div className="flex items-center gap-2">
                        <Avatar className="w-7 h-7">
                          <AvatarImage src={commander.avatarUrl} />
                          <AvatarFallback>{commander.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <div className="text-xs font-medium truncate">{commander.name}</div>
                          <div className="text-[10px] text-muted-foreground truncate">{commander.title}</div>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="rounded-lg border p-3 space-y-2">
                    <div className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Responders ({responders.length})</span>
                    </div>
                    <div className="flex -space-x-2">
                      {responders.slice(0, 5).map((r) => r && (
                        <Avatar key={r.id} className="w-7 h-7 border-2 border-background">
                          <AvatarImage src={r.avatarUrl} />
                          <AvatarFallback>{r.name[0]}</AvatarFallback>
                        </Avatar>
                      ))}
                      {responders.length > 5 && (
                        <div className="w-7 h-7 rounded-full bg-muted border-2 border-background flex items-center justify-center text-[10px] font-medium">
                          +{responders.length - 5}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {lastEvent && (
                  <div className="rounded-lg bg-muted/40 border p-3 mb-4">
                    <div className="flex items-start gap-2">
                      <MessageSquare className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="text-[11px] text-muted-foreground mb-0.5">
                          Latest from <span className="font-medium text-foreground">{lastAuthor?.name ?? "System"}</span>
                          {" · "}
                          {new Date(lastEvent.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </div>
                        <p className="text-xs line-clamp-2">{lastEvent.message}</p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
                  <div className="rounded-md border p-2">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Slack</div>
                    <div className="text-xs font-mono font-medium truncate mt-0.5">{inc.warRoomChannel}</div>
                  </div>
                  <div className="rounded-md border p-2">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Bridge</div>
                    <div className="text-xs font-medium truncate mt-0.5">meet.sgrid.io</div>
                  </div>
                  <div className="rounded-md border p-2">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Impacted</div>
                    <div className="text-xs font-semibold tabular-nums mt-0.5">{inc.impactedUsers.toLocaleString()}</div>
                  </div>
                </div>

                <div className="flex gap-1.5 mt-auto">
                  <Button asChild size="sm" className="flex-1 h-8 text-xs gap-1.5">
                    <Link href={`/incidents/${inc.id}`}>
                      Open Incident <ArrowUpRight className="w-3 h-3" />
                    </Link>
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" onClick={() => toast.info(`Joining bridge for ${inc.ref}`)}>
                    <Video className="w-3 h-3" /> Join
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => toast.info(`Paged all responders for ${inc.ref}`)}>
                    <Phone className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </PageContainer>
  );
}
