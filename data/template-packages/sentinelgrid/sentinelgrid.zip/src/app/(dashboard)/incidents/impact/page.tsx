"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SeverityBadge } from "@/components/common/badges";
import { HorizontalBarChart, DonutChart, LineChartCard } from "@/components/charts";
import { incidents, services, regions, multiTimeSeries, timeSeries } from "@/lib/data";
import {
  PieChart, Users, Clock, AlertTriangle, MapPin, Server, Activity,
  TrendingDown, Timer,
} from "lucide-react";

export default function ImpactAnalysisPage() {
  // Impact by service: sum impactedUsers across incidents per service
  const byService = services.map((s) => {
    const incs = incidents.filter((i) => i.serviceIds.includes(s.id));
    const users = incs.reduce((a, i) => a + i.impactedUsers, 0);
    return { name: s.name, value: users };
  }).filter((x) => x.value > 0).sort((a, b) => b.value - a.value).slice(0, 8);

  // Impact by region
  const byRegion = regions.filter((r) => r !== "global").map((r) => {
    const incs = incidents.filter((i) => i.impactedRegions.includes(r));
    const users = incs.reduce((a, i) => a + i.impactedUsers, 0);
    return { name: r, value: users };
  }).filter((x) => x.value > 0);

  // Impact by severity
  const bySeverity = (["critical", "high", "medium", "low"] as const).map((sev) => ({
    name: sev.charAt(0).toUpperCase() + sev.slice(1),
    value: incidents.filter((i) => i.severity === sev).reduce((a, i) => a + i.impactedUsers, 0),
  }));

  // Compute total user-minutes (impact * duration)
  const now = Date.now();
  const totalUserMinutes = incidents.reduce((acc, inc) => {
    const end = inc.resolvedAt ? new Date(inc.resolvedAt).getTime() : now;
    const minutes = (end - new Date(inc.startedAt).getTime()) / 60000;
    return acc + (inc.impactedUsers * minutes);
  }, 0);

  const impactTrend = multiTimeSeries(11, 30, [
    { name: "users", base: 800, variance: 400 },
    { name: "incidents", base: 4, variance: 3 },
  ]);

  const userMinTrend = timeSeries(7, 14, 60000, 30000);

  return (
    <PageContainer>
      <PageHeader
        title="Impact Analysis"
        description="Customer impact metrics across incidents — by service, region, severity, and total user-minutes affected."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Impact" }]}
        icon={<PieChart className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Impacted Users" value={incidents.reduce((a, i) => a + i.impactedUsers, 0).toLocaleString()} hint="Across all incidents" icon={<Users className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="User-Minutes Affected" value={(totalUserMinutes / 1000).toFixed(1)} unit="k" hint="Users × duration" icon={<Timer className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Avg Incident Duration" value="2.4" unit="h" hint="Across all incidents" icon={<Clock className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg Impact / Incident" value={Math.round(incidents.reduce((a, i) => a + i.impactedUsers, 0) / incidents.length).toLocaleString()} hint="Users per incident" icon={<TrendingDown className="w-4 h-4" />} accent="primary" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <LineChartCard
          title="Customer Impact Trend (30d)"
          description="Daily impacted users and incident count"
          data={impactTrend}
          dataKey="users"
          suffix=" users"
          color={2}
        />
        <LineChartCard
          title="User-Minutes Affected (14d)"
          description="Total user-minutes lost per day"
          data={userMinTrend}
          dataKey="value"
          suffix=" min"
          color={3}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <HorizontalBarChart
          title="Impact by Service"
          description="Impacted users per service"
          data={byService}
          color={2}
        />
        <DonutChart
          title="Impact by Region"
          description="Impacted users per region"
          data={byRegion}
          centerLabel="Regions"
          centerValue={String(byRegion.length)}
        />
        <DonutChart
          title="Impact by Severity"
          description="Impacted users per severity level"
          data={bySeverity}
          centerLabel="Severities"
          centerValue="4"
        />
      </div>

      <Card className="p-5">
        <SectionHeading
          title="Top Impact Incidents"
          description="Sorted by user-minutes affected"
          action={<Badge variant="outline" className="text-xs">{incidents.length} total</Badge>}
        />
        <div className="mt-4 space-y-2 max-h-[420px] overflow-y-auto pr-1 custom-scroll">
          {[...incidents].map((inc) => {
            const end = inc.resolvedAt ? new Date(inc.resolvedAt).getTime() : now;
            const minutes = (end - new Date(inc.startedAt).getTime()) / 60000;
            const userMin = Math.round(inc.impactedUsers * minutes);
            return (
              <Link key={inc.id} href={`/incidents/${inc.id}`} className="block p-3 rounded-lg border hover:bg-elevated/30 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap mb-1">
                      <span className="text-xs font-mono font-semibold text-muted-foreground">{inc.ref}</span>
                      <SeverityBadge severity={inc.severity} size="sm" />
                      <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground"><MapPin className="w-3 h-3" />{inc.impactedRegions.join(", ")}</span>
                    </div>
                    <div className="text-sm font-medium line-clamp-1">{inc.title}</div>
                    <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground">
                      <span className="inline-flex items-center gap-1"><Users className="w-3 h-3" /> {inc.impactedUsers.toLocaleString()} users</span>
                      <span className="inline-flex items-center gap-1"><Clock className="w-3 h-3" /> {Math.round(minutes)} min</span>
                      <span className="inline-flex items-center gap-1"><Server className="w-3 h-3" /> {inc.serviceIds.length} services</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-sm font-semibold tabular-nums text-destructive">{(userMin / 1000).toFixed(1)}k</div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">user-min</div>
                  </div>
                </div>
              </Link>
            );
          }).sort((a, b) => 0).slice(0, 8)}
        </div>
      </Card>

      <Card className="p-5 bg-muted/30 border-dashed">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold">Reading these numbers</h4>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
              User-minutes affected = sum of (impacted users × incident duration in minutes) across all incidents. This is the most meaningful single metric for customer harm — use it to prioritize prevention work.
            </p>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
