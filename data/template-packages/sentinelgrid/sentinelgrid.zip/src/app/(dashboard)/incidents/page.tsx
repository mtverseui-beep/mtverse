"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { SeverityBadge, IncidentStatusBadge } from "@/components/common/badges";
import {
  incidents, people, services, dashboardStats,
} from "@/lib/data";
import type { Incident } from "@/lib/types";
import { toast } from "sonner";
import {
  Siren, Plus, Activity, CheckCircle2, Clock, Users,
  CheckCheck, UserPlus, Download, ArrowUpRight,
} from "lucide-react";

export default function IncidentsListPage() {
  const router = useRouter();
  const stats = dashboardStats();
  const now = Date.now();

  const activeIncidents = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");
  const resolved30d = incidents.filter((i) => i.status === "resolved").length;

  function formatDuration(startedAt: string, endedAt?: string) {
    const end = endedAt ? new Date(endedAt).getTime() : now;
    const diff = end - new Date(startedAt).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${mins % 60}m`;
    return `${mins}m`;
  }

  function person(id: string) {
    return people.find((p) => p.id === id);
  }
  function serviceNames(ids: string[]) {
    return ids.map((id) => services.find((s) => s.id === id)?.name).filter(Boolean).join(", ");
  }

  const columns: Column<Incident>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      width: "120px",
      sortValue: (r) => r.ref,
      cell: (r) => (
        <Link href={`/incidents/${r.id}`} className="text-xs font-mono font-semibold text-primary hover:underline">
          {r.ref}
        </Link>
      ),
    },
    {
      key: "title",
      header: "Title",
      sortable: true,
      sortValue: (r) => r.title,
      cell: (r) => (
        <div className="min-w-0">
          <Link href={`/incidents/${r.id}`} className="text-sm font-medium hover:underline line-clamp-1">
            {r.title}
          </Link>
          <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{r.summary}</p>
        </div>
      ),
    },
    {
      key: "severity",
      header: "Severity",
      sortable: true,
      filterable: true,
      sortValue: (r) => ({ critical: 0, high: 1, medium: 2, low: 3, info: 4 }[r.severity]),
      filterOptions: [
        { label: "Critical", value: "critical" },
        { label: "High", value: "high" },
        { label: "Medium", value: "medium" },
        { label: "Low", value: "low" },
      ],
      filterFn: (r, v) => r.severity === v,
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      filterable: true,
      sortValue: (r) => r.status,
      filterOptions: [
        { label: "Investigating", value: "investigating" },
        { label: "Identified", value: "identified" },
        { label: "Monitoring", value: "monitoring" },
        { label: "Mitigated", value: "mitigated" },
        { label: "Resolved", value: "resolved" },
        { label: "Postmortem", value: "postmortem" },
      ],
      filterFn: (r, v) => r.status === v,
      cell: (r) => <IncidentStatusBadge status={r.status} />,
    },
    {
      key: "commander",
      header: "Commander",
      hideOnMobile: true,
      cell: (r) => {
        const c = person(r.commanderId);
        if (!c) return <span className="text-xs text-muted-foreground">—</span>;
        return (
          <div className="flex items-center gap-1.5">
            <img src={c.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate">{c.name}</span>
          </div>
        );
      },
    },
    {
      key: "services",
      header: "Services",
      hideOnMobile: true,
      filterable: true,
      filterOptions: services.slice(0, 8).map((s) => ({ label: s.name, value: s.id })),
      filterFn: (r, v) => r.serviceIds.includes(v),
      cell: (r) => (
        <span className="text-xs text-muted-foreground truncate block max-w-[180px]">
          {serviceNames(r.serviceIds)}
        </span>
      ),
    },
    {
      key: "startedAt",
      header: "Started",
      sortable: true,
      hideOnMobile: true,
      sortValue: (r) => new Date(r.startedAt).getTime(),
      cell: (r) => (
        <span className="text-xs text-muted-foreground">
          {new Date(r.startedAt).toLocaleDateString([], { month: "short", day: "numeric" })}
          {" "}
          {new Date(r.startedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </span>
      ),
    },
    {
      key: "duration",
      header: "Duration",
      sortable: true,
      align: "right",
      sortValue: (r) => now - new Date(r.startedAt).getTime(),
      cell: (r) => (
        <span className="text-xs font-medium tabular-nums">
          {formatDuration(r.startedAt, r.resolvedAt)}
        </span>
      ),
    },
    {
      key: "impactedUsers",
      header: "Impacted",
      sortable: true,
      align: "right",
      hideOnMobile: true,
      sortValue: (r) => r.impactedUsers,
      cell: (r) => (
        <span className="text-xs tabular-nums">
          {r.impactedUsers > 0 ? r.impactedUsers.toLocaleString() : "—"}
        </span>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Incidents"
        description="Browse, filter, and manage all incidents across the platform. Use bulk actions to acknowledge, assign, or export multiple incidents at once."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents" }]}
        icon={<Siren className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Export started — you'll be notified when ready.")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => router.push("/incidents/new")}>
              <Plus className="w-3.5 h-3.5" />
              Declare Incident
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Total Incidents"
          value={incidents.length}
          hint="All time records"
          icon={<Siren className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="Active Now"
          value={activeIncidents.length}
          hint={`${activeIncidents.filter((i) => i.severity === "critical").length} critical`}
          icon={<Activity className="w-4 h-4" />}
          accent="destructive"
          delta={-2}
          deltaLabel="vs last week"
        />
        <KpiCard
          label="Resolved (30d)"
          value={resolved30d}
          hint="Within rolling window"
          icon={<CheckCircle2 className="w-4 h-4" />}
          accent="success"
          delta={4}
          deltaLabel="vs prior 30d"
        />
        <KpiCard
          label="MTTR (30d)"
          value={stats.mttr30d}
          unit="min"
          delta={-8}
          deltaLabel="improving"
          icon={<Clock className="w-4 h-4" />}
          accent="info"
        />
      </div>

      <div className="grid grid-cols-1 gap-4">
        <Card className="p-4 md:p-5">
          <SectionHeading
            title="All Incidents"
            description="Click a row to view the full incident details"
            action={
              <Button asChild size="sm" variant="ghost" className="h-7 text-xs gap-1">
                <Link href="/incidents/active">View active <ArrowUpRight className="w-3 h-3" /></Link>
              </Button>
            }
          />
          <div className="mt-4">
            <DataTable
              columns={columns}
              data={incidents}
              rowKey={(r) => r.id}
              searchKeys={["ref", "title", "summary"]}
              searchPlaceholder="Search by ref, title, summary..."
              pageSize={10}
              initialSort={{ key: "startedAt", dir: "desc" }}
              enableSelection
              onRowClick={(r) => router.push(`/incidents/${r.id}`)}
              bulkActions={[
                {
                  label: "Acknowledge",
                  icon: <CheckCheck className="w-3.5 h-3.5" />,
                  onClick: (rows) => {
                    toast.success(`Acknowledged ${rows.length} incident${rows.length > 1 ? "s" : ""}`);
                  },
                },
                {
                  label: "Assign",
                  icon: <UserPlus className="w-3.5 h-3.5" />,
                  onClick: (rows) => {
                    toast.info(`Assignment dialog opened for ${rows.length} incident${rows.length > 1 ? "s" : ""}`);
                  },
                },
                {
                  label: "Export Selected",
                  icon: <Download className="w-3.5 h-3.5" />,
                  onClick: (rows) => {
                    toast.success(`Exported ${rows.length} incident${rows.length > 1 ? "s" : ""} as CSV`);
                  },
                },
              ]}
            />
          </div>
        </Card>

        <Card className="p-4 md:p-5 bg-muted/20 border-dashed">
          <div className="flex flex-col md:flex-row md:items-center gap-3 md:justify-between">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shrink-0">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold">Need a faster response workflow?</h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Open the Active Incidents board for a war-room card view, or jump to the Commander View to manage incidents you own.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Button asChild variant="outline" size="sm" className="gap-1.5">
                <Link href="/incidents/active">Active Board</Link>
              </Button>
              <Button asChild size="sm" className="gap-1.5">
                <Link href="/incidents/commander">Commander View</Link>
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
