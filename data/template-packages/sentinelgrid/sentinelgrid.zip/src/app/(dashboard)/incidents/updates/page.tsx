"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SeverityBadge } from "@/components/common/badges";
import { incidents, people } from "@/lib/data";
import type { IncidentUpdate } from "@/lib/types";
import {
  MessageSquare, Mail, Globe, Lock, Bell, Send, Filter, Users,
} from "lucide-react";

const audienceConfig: Record<IncidentUpdate["audience"], { label: string; className: string; icon: React.ReactNode }> = {
  internal: { label: "Internal", className: "bg-muted text-muted-foreground border-border", icon: <Lock className="w-3 h-3" /> },
  stakeholder: { label: "Stakeholder", className: "bg-accent text-accent-foreground border-accent/30", icon: <Mail className="w-3 h-3" /> },
  public: { label: "Public", className: "bg-success/15 text-success border-success/30", icon: <Globe className="w-3 h-3" /> },
};

export default function UpdatesFeedPage() {
  const [filter, setFilter] = React.useState<"all" | IncidentUpdate["audience"]>("all");

  const allUpdates = React.useMemo(() => {
    return incidents
      .flatMap((i) => i.updates.map((u) => ({ ...u, incident: i })))
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, []);

  const filtered = filter === "all" ? allUpdates : allUpdates.filter((u) => u.audience === filter);

  const counts = {
    all: allUpdates.length,
    internal: allUpdates.filter((u) => u.audience === "internal").length,
    stakeholder: allUpdates.filter((u) => u.audience === "stakeholder").length,
    public: allUpdates.filter((u) => u.audience === "public").length,
  };

  return (
    <PageContainer>
      <PageHeader
        title="Updates Feed"
        description="Reverse-chronological feed of all incident updates across every incident, regardless of audience."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Updates" }]}
        icon={<MessageSquare className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Updates" value={counts.all} hint="All time" icon={<MessageSquare className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Internal" value={counts.internal} hint="Team-only" icon={<Lock className="w-4 h-4" />} accent="muted" />
        <KpiCard label="Stakeholder" value={counts.stakeholder} hint="Emailed to stakeholders" icon={<Mail className="w-4 h-4" />} accent="accent" />
        <KpiCard label="Public" value={counts.public} hint="Posted to status page" icon={<Globe className="w-4 h-4" />} accent="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-3 space-y-4">
          <Card className="p-4">
            <div className="flex items-center gap-2 flex-wrap">
              <Filter className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-xs font-medium">Audience:</span>
              {(["all", "internal", "stakeholder", "public"] as const).map((a) => (
                <Button key={a} variant={filter === a ? "default" : "outline"} size="sm" className="h-7 text-xs capitalize gap-1.5" onClick={() => setFilter(a)}>
                  {a !== "all" && audienceConfig[a].icon}
                  {a}
                  <span className="opacity-60 tabular-nums">({counts[a]})</span>
                </Button>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            {filtered.length === 0 ? (
              <EmptyState icon={<MessageSquare className="w-5 h-5" />} title="No updates" description="No updates match this filter." />
            ) : (
              <div className="space-y-4 max-h-[820px] overflow-y-auto pr-1 custom-scroll">
                {filtered.map((u) => {
                  const author = people.find((p) => p.id === u.authorId);
                  const ab = audienceConfig[u.audience];
                  return (
                    <div key={u.id} className="rounded-lg border p-4 hover:bg-elevated/30 transition-colors">
                      <div className="flex items-start gap-3">
                        {author && (
                          <Avatar className="w-9 h-9 shrink-0">
                            <AvatarImage src={author.avatarUrl} />
                            <AvatarFallback>{author.name[0]}</AvatarFallback>
                          </Avatar>
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-1.5">
                            <span className="text-sm font-medium">{author?.name ?? "System"}</span>
                            <Link href={`/incidents/${u.incident.id}`} className="text-[10px] font-mono text-primary hover:underline">{u.incident.ref}</Link>
                            <SeverityBadge severity={u.incident.severity} size="sm" />
                            <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${ab.className}`}>
                              {ab.icon} {ab.label}
                            </span>
                            <span className="text-[11px] text-muted-foreground ml-auto">{new Date(u.timestamp).toLocaleString()}</span>
                          </div>
                          <p className="text-sm text-foreground leading-relaxed">{u.body}</p>
                          <div className="mt-2 text-[11px] text-muted-foreground truncate">
                            From incident: <Link href={`/incidents/${u.incident.id}`} className="text-foreground hover:underline">{u.incident.title}</Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Quick Post" description="Send a quick update" />
            <div className="space-y-2">
              <textarea
                placeholder="What's the latest?"
                rows={4}
                className="w-full rounded-md border bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
              <div className="flex items-center gap-1.5">
                <Button size="sm" variant="outline" className="h-7 text-xs gap-1 flex-1"><Lock className="w-3 h-3" /> Internal</Button>
                <Button size="sm" variant="outline" className="h-7 text-xs gap-1 flex-1"><Mail className="w-3 h-3" /> Stakeholder</Button>
                <Button size="sm" className="h-7 text-xs gap-1 flex-1"><Send className="w-3 h-3" /> Send</Button>
              </div>
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Top Authors" description="Most active update posters" />
            <div className="space-y-2">
              {Object.entries(
                allUpdates.reduce((acc, u) => {
                  acc[u.authorId] = (acc[u.authorId] ?? 0) + 1;
                  return acc;
                }, {} as Record<string, number>)
              )
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5)
                .map(([id, count]) => {
                  const p = people.find((x) => x.id === id);
                  if (!p) return null;
                  return (
                    <div key={id} className="flex items-center gap-2">
                      <Avatar className="w-7 h-7">
                        <AvatarImage src={p.avatarUrl} />
                        <AvatarFallback>{p.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-medium truncate">{p.name}</div>
                        <div className="text-[10px] text-muted-foreground">{p.title}</div>
                      </div>
                      <span className="text-xs font-semibold tabular-nums">{count}</span>
                    </div>
                  );
                })}
            </div>
          </Card>

          <Card className="p-4 bg-muted/30 border-dashed">
            <div className="flex items-start gap-2.5">
              <Bell className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <div className="text-xs text-muted-foreground leading-relaxed">
                Subscribe to specific incidents to get notified the moment a new update is posted.
              </div>
            </div>
            <Button asChild variant="link" size="sm" className="h-auto p-0 mt-2 text-xs gap-1">
              <Link href="/incidents/subscribers">Manage subscriptions <Users className="w-3 h-3" /></Link>
            </Button>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
