"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SeverityBadge, IncidentStatusBadge } from "@/components/common/badges";
import { incidents, people } from "@/lib/data";
import { toast } from "sonner";
import {
  RotateCcw, FileText, Calendar, Clock, Users, CheckCircle2,
  ChevronRight, Plus, AlertTriangle, CalendarPlus,
} from "lucide-react";

export default function RetrospectivesPage() {
  const now = Date.now();
  // Incidents that need postmortems (resolved but no postmortem yet)
  const needsPostmortem = incidents.filter((i) => i.status === "resolved" && !i.postmortemId);

  // Already scheduled retros (mock)
  const scheduled = [
    {
      id: "retro1",
      incidentId: "inc3",
      scheduledAt: "2026-07-04T15:00:00Z",
      duration: 60,
      participants: ["u4", "u3", "u1", "u11"],
      facilitator: "u1",
      status: "scheduled",
    },
  ];

  function formatDuration(startedAt: string, endedAt?: string) {
    const end = endedAt ? new Date(endedAt).getTime() : now;
    const mins = Math.floor((end - new Date(startedAt).getTime()) / 60000);
    const hours = Math.floor(mins / 60);
    if (hours > 0) return `${hours}h ${mins % 60}m`;
    return `${mins}m`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Retrospective Queue"
        description="Incidents that have been resolved but still need a postmortem. Schedule blameless retros and follow through on action items."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Retrospectives" }]}
        icon={<RotateCcw className="w-5 h-5" />}
        actions={
          <Button asChild size="sm" className="gap-1.5">
            <Link href="/postmortems/new"><Plus className="w-3.5 h-3.5" /> New Postmortem</Link>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Awaiting Retro" value={needsPostmortem.length} hint="Resolved, no postmortem" icon={<RotateCcw className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Scheduled Retros" value={scheduled.length} hint="Upcoming sessions" icon={<Calendar className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Avg Days to Publish" value="3.2" unit="d" hint="Resolution to published PM" icon={<Clock className="w-4 h-4" />} accent="info" />
        <KpiCard label="On-Time Rate" value="84%" hint="Published within 7 days" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <SectionHeading
            title="Needs Postmortem"
            description="Resolved incidents that require a blameless retrospective"
          />
          {needsPostmortem.length === 0 ? (
            <EmptyState icon={<CheckCircle2 className="w-5 h-5" />} title="All caught up" description="No incidents are awaiting a postmortem." />
          ) : (
            <div className="mt-4 space-y-3">
              {needsPostmortem.map((inc) => {
                const commander = people.find((p) => p.id === inc.commanderId);
                const responders = inc.responderIds.map((id) => people.find((p) => p.id === id)).filter(Boolean);
                const daysSinceResolved = inc.resolvedAt ? Math.floor((now - new Date(inc.resolvedAt).getTime()) / 86400000) : 0;
                const overdue = daysSinceResolved > 7;
                return (
                  <div key={inc.id} className={`rounded-lg border p-4 ${overdue ? "border-destructive/30 bg-destructive/5" : ""}`}>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap mb-1">
                          <span className="text-xs font-mono font-semibold text-muted-foreground">{inc.ref}</span>
                          <SeverityBadge severity={inc.severity} size="sm" />
                          <IncidentStatusBadge status={inc.status} />
                          {overdue && <Badge className="text-[10px] h-5 bg-destructive/15 text-destructive border-destructive/30 gap-1"><AlertTriangle className="w-2.5 h-2.5" /> Overdue</Badge>}
                        </div>
                        <h3 className="text-sm font-semibold line-clamp-1">{inc.title}</h3>
                        <div className="flex items-center gap-3 mt-1.5 text-[11px] text-muted-foreground">
                          <span className="inline-flex items-center gap-1"><Clock className="w-3 h-3" /> Duration: {formatDuration(inc.startedAt, inc.resolvedAt)}</span>
                          <span className="inline-flex items-center gap-1"><Calendar className="w-3 h-3" /> Resolved {daysSinceResolved}d ago</span>
                          <span className="inline-flex items-center gap-1"><Users className="w-3 h-3" /> {responders.length} responders</span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-md bg-muted/40 border p-2.5 mb-3">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-0.5">Customer Impact</div>
                      <p className="text-xs">{inc.customerImpact}</p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Button size="sm" className="h-8 text-xs gap-1.5 flex-1" onClick={() => toast.success("Postmortem started")}>
                        <FileText className="w-3 h-3" /> Start Postmortem
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast.success("Retro scheduled")}>
                        <CalendarPlus className="w-3 h-3" /> Schedule Retro
                      </Button>
                      <Button asChild variant="ghost" size="sm" className="h-8 text-xs gap-1">
                        <Link href={`/incidents/${inc.id}`}>View incident <ChevronRight className="w-3 h-3" /></Link>
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Scheduled Retros" description="Upcoming blameless sessions" />
            {scheduled.length === 0 ? (
              <p className="text-xs text-muted-foreground">No scheduled retros.</p>
            ) : (
              <div className="space-y-2">
                {scheduled.map((r) => {
                  const inc = incidents.find((i) => i.id === r.incidentId);
                  const facilitator = people.find((p) => p.id === r.facilitator);
                  const participants = r.participants.map((id) => people.find((p) => p.id === id)).filter(Boolean);
                  return (
                    <div key={r.id} className="rounded-lg border p-3">
                      <div className="flex items-center gap-1.5 mb-1">
                        <Calendar className="w-3 h-3 text-primary" />
                        <span className="text-xs font-medium">{new Date(r.scheduledAt).toLocaleString()}</span>
                      </div>
                      {inc && (
                        <>
                          <div className="text-xs font-medium line-clamp-1">{inc.ref} — {inc.title}</div>
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <span className="text-[10px] text-muted-foreground">Facilitator:</span>
                            {facilitator && <Avatar className="w-5 h-5"><AvatarImage src={facilitator.avatarUrl} /><AvatarFallback>{facilitator.name[0]}</AvatarFallback></Avatar>}
                            <span className="text-[10px]">{facilitator?.name}</span>
                          </div>
                          <div className="flex items-center gap-1 mt-2">
                            <div className="flex -space-x-2">
                              {participants.slice(0, 4).map((p) => p && (
                                <Avatar key={p.id} className="w-6 h-6 border-2 border-background">
                                  <AvatarImage src={p.avatarUrl} />
                                  <AvatarFallback>{p.name[0]}</AvatarFallback>
                                </Avatar>
                              ))}
                            </div>
                            <span className="text-[10px] text-muted-foreground ml-1">{r.duration} min</span>
                          </div>
                          <Button asChild variant="link" size="sm" className="h-auto p-0 mt-2 text-xs gap-1">
                            <Link href={`/postmortems/new`}>Start draft <ChevronRight className="w-3 h-3" /></Link>
                          </Button>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          <Card className="p-5 space-y-3 bg-muted/30 border-dashed">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold">Blameless Retrospective Principles</h4>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1.5 list-disc list-inside">
                  <li>Focus on systems and processes, not individuals</li>
                  <li>Assume everyone did the best they could with the info available</li>
                  <li>Look for missing safeguards, not fault</li>
                  <li>Capture actionable improvements with owners and dates</li>
                  <li>Share broadly so the org learns together</li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
