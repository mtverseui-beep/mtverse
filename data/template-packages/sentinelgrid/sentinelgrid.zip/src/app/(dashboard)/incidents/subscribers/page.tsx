"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { SeverityBadge } from "@/components/common/badges";
import { incidents, people } from "@/lib/data";
import { toast } from "sonner";
import {
  Bell, Users, Mail, MessageSquare, Smartphone, Plus, X, Search,
  BellOff, ChevronRight, ShieldAlert,
} from "lucide-react";

interface SubscriberPref {
  email: boolean;
  slack: boolean;
  sms: boolean;
}

export default function SubscribersPage() {
  const [search, setSearch] = React.useState("");
  const [expandedInc, setExpandedInc] = React.useState<string | null>(incidents[0]?.id ?? null);
  const [prefs, setPrefs] = React.useState<Record<string, SubscriberPref>>(() => {
    const out: Record<string, SubscriberPref> = {};
    people.forEach((p) => {
      out[p.id] = { email: true, slack: true, sms: p.role.toLowerCase().includes("manager") };
    });
    return out;
  });
  const [extraSubs, setExtraSubs] = React.useState<Record<string, string[]>>({});

  const totalSubscribers = incidents.reduce((acc, i) => acc + i.subscriberIds.length + (extraSubs[i.id]?.length ?? 0), 0);

  function togglePref(uid: string, channel: keyof SubscriberPref) {
    setPrefs((p) => ({ ...p, [uid]: { ...p[uid], [channel]: !p[uid][channel] } }));
    toast.success("Subscription preference updated");
  }

  function addSubscriber(incId: string, uid: string) {
    setExtraSubs((p) => ({ ...p, [incId]: [...(p[incId] ?? []), uid] }));
    toast.success("Subscriber added");
  }

  function removeSubscriber(incId: string, uid: string) {
    setExtraSubs((p) => ({ ...p, [incId]: (p[incId] ?? []).filter((x) => x !== uid) }));
    toast.success("Subscriber removed");
  }

  const filteredPeople = people.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()) || p.handle.toLowerCase().includes(search.toLowerCase()));

  return (
    <PageContainer>
      <PageHeader
        title="Subscribers"
        description="Manage who receives notifications for each incident. Add, remove, and configure per-channel preferences."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Subscribers" }]}
        icon={<Bell className="w-5 h-5" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Subscriptions" value={totalSubscribers} hint="Across all incidents" icon={<Bell className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Incidents Tracked" value={incidents.length} hint="Open for subscription" icon={<ShieldAlert className="w-4 h-4" />} accent="accent" />
        <KpiCard label="Unique Subscribers" value={people.length} hint="People on the platform" icon={<Users className="w-4 h-4" />} accent="info" />
        <KpiCard label="Channels Active" value={3} hint="Email, Slack, SMS" icon={<MessageSquare className="w-4 h-4" />} accent="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-3">
          {incidents.map((inc) => {
            const expanded = expandedInc === inc.id;
            const subs = Array.from(new Set([...inc.subscriberIds, ...(extraSubs[inc.id] ?? [])]));
            return (
              <Card key={inc.id} className="overflow-hidden">
                <button
                  onClick={() => setExpandedInc(expanded ? null : inc.id)}
                  className="w-full flex items-center gap-3 p-4 hover:bg-elevated/30 transition-colors text-left"
                >
                  <div className={`w-1 h-12 rounded-full ${inc.severity === "critical" ? "bg-destructive" : inc.severity === "high" ? "bg-warning" : inc.severity === "medium" ? "bg-info" : "bg-muted-foreground"}`} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-xs font-mono font-semibold text-muted-foreground">{inc.ref}</span>
                      <SeverityBadge severity={inc.severity} size="sm" />
                    </div>
                    <div className="text-sm font-medium truncate">{inc.title}</div>
                  </div>
                  <Badge variant="outline" className="text-xs gap-1"><Bell className="w-3 h-3" /> {subs.length}</Badge>
                  <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${expanded ? "rotate-90" : ""}`} />
                </button>
                {expanded && (
                  <div className="border-t border-border p-4 space-y-3">
                    <div className="space-y-1.5">
                      {subs.length === 0 ? (
                        <EmptyState icon={<BellOff className="w-5 h-5" />} title="No subscribers" description="Add subscribers below to notify them when updates are posted." />
                      ) : (
                        subs.map((sid) => {
                          const p = people.find((x) => x.id === sid);
                          if (!p) return null;
                          const pref = prefs[p.id];
                          return (
                            <div key={sid} className="flex items-center gap-3 p-2 rounded-md border">
                              <Avatar className="w-7 h-7">
                                <AvatarImage src={p.avatarUrl} />
                                <AvatarFallback>{p.name[0]}</AvatarFallback>
                              </Avatar>
                              <div className="min-w-0 flex-1">
                                <div className="text-xs font-medium truncate">{p.name}</div>
                                <div className="text-[10px] text-muted-foreground truncate">{p.title}</div>
                              </div>
                              <div className="flex items-center gap-1">
                                <button onClick={() => togglePref(p.id, "email")} className={`w-6 h-6 rounded flex items-center justify-center border ${pref.email ? "bg-primary/15 text-primary border-primary/30" : "text-muted-foreground border-border"}`}>
                                  <Mail className="w-3 h-3" />
                                </button>
                                <button onClick={() => togglePref(p.id, "slack")} className={`w-6 h-6 rounded flex items-center justify-center border ${pref.slack ? "bg-primary/15 text-primary border-primary/30" : "text-muted-foreground border-border"}`}>
                                  <MessageSquare className="w-3 h-3" />
                                </button>
                                <button onClick={() => togglePref(p.id, "sms")} className={`w-6 h-6 rounded flex items-center justify-center border ${pref.sms ? "bg-primary/15 text-primary border-primary/30" : "text-muted-foreground border-border"}`}>
                                  <Smartphone className="w-3 h-3" />
                                </button>
                              </div>
                              <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive" onClick={() => removeSubscriber(inc.id, p.id)}>
                                <X className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          );
                        })
                      )}
                    </div>
                    <Separator />
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Add subscriber</div>
                      <div className="flex items-center gap-2">
                        <Input placeholder="Search by name or handle..." value={search} onChange={(e) => setSearch(e.target.value)} className="h-8 text-xs" />
                        <Button size="sm" variant="outline" className="h-8 text-xs gap-1" onClick={() => {
                          const first = filteredPeople.find((p) => !subs.includes(p.id));
                          if (first) addSubscriber(inc.id, first.id);
                          else toast.info("No new subscribers to add");
                        }}>
                          <Plus className="w-3 h-3" /> Add
                        </Button>
                      </div>
                      {search && (
                        <div className="mt-1.5 space-y-1 max-h-32 overflow-y-auto">
                          {filteredPeople.slice(0, 4).map((p) => (
                            <button key={p.id} onClick={() => addSubscriber(inc.id, p.id)} className="w-full flex items-center gap-2 p-1.5 rounded-md border hover:bg-muted/40 text-left">
                              <Avatar className="w-6 h-6">
                                <AvatarImage src={p.avatarUrl} />
                                <AvatarFallback>{p.name[0]}</AvatarFallback>
                              </Avatar>
                              <span className="text-xs">{p.name}</span>
                              <Plus className="w-3 h-3 text-primary ml-auto" />
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Notification Channels" description="Platform-wide channel status" />
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 rounded-md border">
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-primary" />
                  <span className="text-xs">Email</span>
                </div>
                <Badge className="text-[10px] h-5 bg-success/15 text-success border-success/30">Operational</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded-md border">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-3.5 h-3.5 text-primary" />
                  <span className="text-xs">Slack</span>
                </div>
                <Badge className="text-[10px] h-5 bg-success/15 text-success border-success/30">Operational</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded-md border">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-3.5 h-3.5 text-primary" />
                  <span className="text-xs">SMS (Twilio)</span>
                </div>
                <Badge className="text-[10px] h-5 bg-warning/15 text-warning-foreground border-warning/30">Degraded</Badge>
              </div>
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="My Subscriptions" description="Incidents you're subscribed to" />
            <div className="space-y-1.5">
              {incidents.filter((i) => i.subscriberIds.includes("u1")).map((inc) => (
                <Link key={inc.id} href={`/incidents/${inc.id}`} className="block p-2 rounded-md border hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className="text-[10px] font-mono text-muted-foreground">{inc.ref}</span>
                    <SeverityBadge severity={inc.severity} size="sm" />
                  </div>
                  <div className="text-xs font-medium truncate">{inc.title}</div>
                </Link>
              ))}
              {incidents.filter((i) => i.subscriberIds.includes("u1")).length === 0 && (
                <p className="text-xs text-muted-foreground">You're not subscribed to any incidents.</p>
              )}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
