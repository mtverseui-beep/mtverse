"use client";

import * as React from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { SeverityBadge, IncidentStatusBadge, AlertStatusBadge, TierBadge, StatusDot } from "@/components/common/badges";
import { incidents, people, services, alerts, deployments } from "@/lib/data";
import type { Incident, IncidentTimelineEvent, IncidentUpdate } from "@/lib/types";
import { toast } from "sonner";
import {
  Siren, ArrowLeft, Timer, Users, ShieldAlert, MessageSquare, Bell,
  ExternalLink, CheckCircle2, Circle, ChevronRight, FileText, Plus,
  AlertTriangle, Rocket, BookOpen, Phone, Radio, Send, UserPlus, Zap,
  Activity, Eye, Globe, Lock, Mail, Server,
} from "lucide-react";

const kindIcon: Record<IncidentTimelineEvent["kind"], React.ReactNode> = {
  created: <Plus className="w-3 h-3" />,
  acknowledged: <CheckCircle2 className="w-3 h-3" />,
  status_change: <Activity className="w-3 h-3" />,
  severity_change: <AlertTriangle className="w-3 h-3" />,
  note: <MessageSquare className="w-3 h-3" />,
  public_update: <Globe className="w-3 h-3" />,
  responder_added: <UserPlus className="w-3 h-3" />,
  responder_removed: <Users className="w-3 h-3" />,
  commander_change: <ShieldAlert className="w-3 h-3" />,
  service_added: <Server className="w-3 h-3" />,
  deployment_linked: <Rocket className="w-3 h-3" />,
  runbook_linked: <BookOpen className="w-3 h-3" />,
  alert_linked: <Bell className="w-3 h-3" />,
  resolved: <CheckCircle2 className="w-3 h-3" />,
  escalated: <Zap className="w-3 h-3" />,
  subscriber_added: <Bell className="w-3 h-3" />,
  postmortem_started: <FileText className="w-3 h-3" />,
};

const severityColor: Record<string, string> = {
  critical: "border-l-destructive",
  high: "border-l-warning",
  medium: "border-l-info",
  low: "border-l-muted-foreground",
  info: "border-l-muted-foreground",
};

const audienceBadge: Record<IncidentUpdate["audience"], { label: string; className: string; icon: React.ReactNode }> = {
  internal: { label: "Internal", className: "bg-muted text-muted-foreground border-border", icon: <Lock className="w-3 h-3" /> },
  stakeholder: { label: "Stakeholder", className: "bg-accent text-accent-foreground border-accent/30", icon: <Mail className="w-3 h-3" /> },
  public: { label: "Public", className: "bg-success/15 text-success border-success/30", icon: <Globe className="w-3 h-3" /> },
};

export default function IncidentDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const id = (params?.id as string) || "inc1";
  const incident = incidents.find((i) => i.id === id) || incidents[0];
  const now = Date.now();
  const [note, setNote] = React.useState("");
  const [update, setUpdate] = React.useState("");
  const [checklist, setChecklist] = React.useState(incident.checklist);
  const [noteModalOpen, setNoteModalOpen] = React.useState(false);
  const [updateModalOpen, setUpdateModalOpen] = React.useState(false);
  const [modalNote, setModalNote] = React.useState("");
  const [modalUpdate, setModalUpdate] = React.useState("");
  const [modalAudience, setModalAudience] = React.useState<"internal" | "stakeholder" | "public">("stakeholder");

  const commander = people.find((p) => p.id === incident.commanderId);
  const responders = incident.responderIds.map((rid) => people.find((p) => p.id === rid)).filter(Boolean) as NonNullable<ReturnType<typeof people.find>>[];
  const svc = incident.serviceIds.map((sid) => services.find((s) => s.id === sid)).filter(Boolean) as NonNullable<ReturnType<typeof services.find>>[];
  const linkedAlerts = incident.alertIds.map((aid) => alerts.find((a) => a.id === aid)).filter(Boolean) as NonNullable<ReturnType<typeof alerts.find>>[];
  const linkedDeployment = incident.deploymentId ? deployments.find((d) => d.id === incident.deploymentId) : null;
  const subscribers = incident.subscriberIds.map((sid) => people.find((p) => p.id === sid)).filter(Boolean) as NonNullable<ReturnType<typeof people.find>>[];

  function formatDuration(startedAt: string, endedAt?: string) {
    const end = endedAt ? new Date(endedAt).getTime() : now;
    const diff = end - new Date(startedAt).getTime();
    const secs = Math.floor(diff / 1000);
    const mins = Math.floor(secs / 60);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h ${mins % 60}m`;
    if (hours > 0) return `${hours}h ${mins % 60}m ${secs % 60}s`;
    if (mins > 0) return `${mins}m ${secs % 60}s`;
    return `${secs}s`;
  }

  function toggleChecklistItem(itemId: string) {
    setChecklist((prev) => prev.map((c) => (c.id === itemId ? { ...c, done: !c.done } : c)));
    toast.success("Checklist updated");
  }

  function postNote() {
    if (!note.trim()) return;
    toast.success("Internal note posted");
    setNote("");
  }
  function postUpdate() {
    if (!update.trim()) return;
    toast.success("Stakeholder update posted");
    setUpdate("");
  }
  function submitModalNote() {
    if (!modalNote.trim()) return;
    toast.success("Note added to incident timeline");
    setModalNote("");
    setNoteModalOpen(false);
  }
  function submitModalUpdate() {
    if (!modalUpdate.trim()) return;
    toast.success(`${modalAudience[0].toUpperCase()}${modalAudience.slice(1)} update posted`);
    setModalUpdate("");
    setUpdateModalOpen(false);
  }

  const checklistDone = checklist.filter((c) => c.done).length;
  const isActive = incident.status !== "resolved" && incident.status !== "postmortem";

  return (
    <PageContainer wide>
      <PageHeader
        title={incident.title}
        description={incident.summary}
        breadcrumbs={[
          { label: "Home", href: "/dashboard" },
          { label: "Incidents", href: "/incidents" },
          { label: incident.ref },
        ]}
        icon={<Siren className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => router.push("/incidents")}>
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Back</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Escalation policy EP-1 triggered")}>
              <Zap className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Escalate</span>
            </Button>
            {isActive ? (
              <Button size="sm" className="gap-1.5" onClick={() => toast.success("Incident marked as resolved")}>
                <CheckCircle2 className="w-3.5 h-3.5" />
                Resolve
              </Button>
            ) : (
              <Button size="sm" className="gap-1.5" onClick={() => router.push("/postmortems/new")}>
                <FileText className="w-3.5 h-3.5" />
                Start Postmortem
              </Button>
            )}
          </>
        }
        meta={
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-mono text-muted-foreground">{incident.ref}</span>
            <SeverityBadge severity={incident.severity} size="sm" />
            <IncidentStatusBadge status={incident.status} />
          </div>
        }
      />

      {/* Hero banner */}
      <Card className={`p-5 border-l-4 ${severityColor[incident.severity]} bg-gradient-to-r from-muted/40 to-transparent`}>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Duration</div>
            <div className="flex items-center gap-1.5">
              <Timer className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-sm font-semibold tabular-nums">{formatDuration(incident.startedAt, incident.resolvedAt)}</span>
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Impacted Users</div>
            <div className="text-sm font-semibold tabular-nums">{incident.impactedUsers.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Regions</div>
            <div className="text-sm font-medium">{incident.impactedRegions.join(", ")}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Response SLA</div>
            <div className="flex items-center gap-1.5">
              {incident.responseSlaSeconds && incident.responseSlaSeconds < 300 ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-success" />
              ) : (
                <AlertTriangle className="w-3.5 h-3.5 text-warning" />
              )}
              <span className="text-sm font-medium tabular-nums">{incident.responseSlaSeconds ? `${incident.responseSlaSeconds}s` : "—"}</span>
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Status Page</div>
            <div className="flex items-center gap-1.5">
              {incident.statusPagePosted ? (
                <><Globe className="w-3.5 h-3.5 text-success" /><span className="text-sm font-medium">Posted</span></>
              ) : (
                <><Circle className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-sm font-medium text-muted-foreground">Not posted</span></>
              )}
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">War Room</div>
            <div className="flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-primary" />
              <span className="text-sm font-medium font-mono">{incident.warRoomChannel ?? "—"}</span>
            </div>
          </div>
        </div>
        <Separator className="my-4" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div>
            <span className="text-muted-foreground">Detected at: </span>
            <span className="font-medium">{new Date(incident.detectedAt).toLocaleString()}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Acknowledged: </span>
            <span className="font-medium">{incident.acknowledgedAt ? new Date(incident.acknowledgedAt).toLocaleString() : "—"}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Last update: </span>
            <span className="font-medium">{new Date(incident.lastUpdateAt).toLocaleString()}</span>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
        {/* Main column with tabs */}
        <div className="xl:col-span-3 space-y-4">
          <Tabs defaultValue="timeline">
            <TabsList className="w-full justify-start overflow-x-auto h-auto flex-wrap">
              <TabsTrigger value="timeline" className="gap-1.5">Timeline</TabsTrigger>
              <TabsTrigger value="updates" className="gap-1.5">Updates</TabsTrigger>
              <TabsTrigger value="responders" className="gap-1.5">Responders</TabsTrigger>
              <TabsTrigger value="impact" className="gap-1.5">Impact</TabsTrigger>
              <TabsTrigger value="checklist" className="gap-1.5">Checklist</TabsTrigger>
              <TabsTrigger value="warroom" className="gap-1.5">War Room</TabsTrigger>
            </TabsList>

            {/* Timeline */}
            <TabsContent value="timeline">
              <Card className="p-5">
                <SectionHeading
                  title="Incident Timeline"
                  description="Chronological log of all events during this incident"
                  action={<Button variant="outline" size="sm" className="h-8 text-xs gap-1.5"><Plus className="w-3 h-3" />Add event</Button>}
                />
                <div className="mt-5 space-y-1">
                  {[...incident.timeline].reverse().map((evt, i) => {
                    const author = people.find((p) => p.id === evt.authorId);
                    return (
                      <div key={evt.id} className="flex items-start gap-3 group">
                        <div className="relative flex flex-col items-center">
                          <div className="w-7 h-7 rounded-full bg-muted border flex items-center justify-center text-muted-foreground group-hover:text-foreground group-hover:border-foreground/40 transition-colors">
                            {kindIcon[evt.kind]}
                          </div>
                          {i < incident.timeline.length - 1 && <div className="w-px flex-1 bg-border mt-1" />}
                        </div>
                        <div className="flex-1 min-w-0 pb-4">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-medium">{author?.name ?? "System"}</span>
                            <Badge variant="outline" className="text-[10px] capitalize px-1.5 py-0 h-4">{evt.kind.replace(/_/g, " ")}</Badge>
                            <span className="text-[11px] text-muted-foreground">{new Date(evt.timestamp).toLocaleString()}</span>
                          </div>
                          <p className="text-xs text-foreground mt-1">{evt.message}</p>
                          {evt.metadata && Object.keys(evt.metadata).length > 0 && (
                            <div className="mt-1.5 flex flex-wrap gap-1">
                              {Object.entries(evt.metadata).map(([k, v]) => (
                                <span key={k} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{k}: {v}</span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            </TabsContent>

            {/* Updates */}
            <TabsContent value="updates">
              <Card className="p-5 space-y-4">
                <SectionHeading
                  title="Incident Updates"
                  description="Posted messages to internal, stakeholder, or public audiences"
                />
                <div className="rounded-lg border bg-muted/20 p-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-xs font-medium">Post a stakeholder update</span>
                  </div>
                  <Textarea value={update} onChange={(e) => setUpdate(e.target.value)} placeholder="What's the latest on this incident? Stakeholders will receive this via email..." rows={3} className="text-sm bg-background" />
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] text-muted-foreground">Posting as {commander?.name ?? "you"}</span>
                    <Button size="sm" className="h-7 gap-1.5 text-xs" onClick={postUpdate} disabled={!update.trim()}>
                      <Send className="w-3 h-3" /> Post Update
                    </Button>
                  </div>
                </div>
                <Separator />
                <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1 custom-scroll">
                  {incident.updates.length === 0 ? (
                    <EmptyState icon={<MessageSquare className="w-5 h-5" />} title="No updates posted yet" description="Be the first to post an incident update." />
                  ) : (
                    [...incident.updates].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map((u) => {
                      const author = people.find((p) => p.id === u.authorId);
                      const ab = audienceBadge[u.audience];
                      return (
                        <div key={u.id} className="rounded-lg border p-3 bg-card">
                          <div className="flex items-center gap-2 flex-wrap mb-2">
                            {author && <Avatar className="w-6 h-6"><AvatarImage src={author.avatarUrl} /><AvatarFallback>{author.name[0]}</AvatarFallback></Avatar>}
                            <span className="text-xs font-medium">{author?.name ?? "System"}</span>
                            <span className="text-[11px] text-muted-foreground">{new Date(u.timestamp).toLocaleString()}</span>
                            <span className={`inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium ${ab.className}`}>
                              {ab.icon} {ab.label}
                            </span>
                          </div>
                          <p className="text-sm text-foreground leading-relaxed">{u.body}</p>
                        </div>
                      );
                    })
                  )}
                </div>
              </Card>
            </TabsContent>

            {/* Responders */}
            <TabsContent value="responders">
              <Card className="p-5">
                <SectionHeading
                  title="Responders"
                  description="People currently engaged on this incident"
                  action={<Button variant="outline" size="sm" className="h-8 text-xs gap-1.5"><UserPlus className="w-3 h-3" />Add responder</Button>}
                />
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {responders.map((r) => (
                    <div key={r.id} className="rounded-lg border p-3 hover:bg-elevated/40 transition-colors">
                      <div className="flex items-start gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={r.avatarUrl} />
                          <AvatarFallback>{r.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-medium truncate">{r.name}</div>
                          <div className="text-xs text-muted-foreground truncate">{r.title}</div>
                          <div className="text-[11px] text-muted-foreground mt-0.5">@{r.handle} · {r.team}</div>
                        </div>
                        {r.id === incident.commanderId && (
                          <Badge className="text-[10px] px-1.5 h-5 gap-1"><ShieldAlert className="w-2.5 h-2.5" />IC</Badge>
                        )}
                      </div>
                      <div className="flex gap-1.5 mt-3">
                        <Button variant="outline" size="sm" className="h-7 text-xs flex-1 gap-1" onClick={() => toast.info(`Paged ${r.name}`)}>
                          <Phone className="w-3 h-3" /> Page
                        </Button>
                        <Button variant="outline" size="sm" className="h-7 text-xs flex-1 gap-1" onClick={() => toast.info(`Message sent to ${r.name}`)}>
                          <MessageSquare className="w-3 h-3" /> Message
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* Impact */}
            <TabsContent value="impact">
              <Card className="p-5 space-y-4">
                <SectionHeading title="Customer Impact" description="Scope and severity of user-facing impact" />
                <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-4">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                    <div>
                      <div className="text-sm font-medium text-destructive">Customer Impact Statement</div>
                      <p className="text-xs text-foreground mt-1 leading-relaxed">{incident.customerImpact}</p>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="rounded-lg border p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Impacted Users</div>
                    <div className="text-xl font-semibold tabular-nums mt-1">{incident.impactedUsers.toLocaleString()}</div>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Regions</div>
                    <div className="text-xl font-semibold mt-1">{incident.impactedRegions.length}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{incident.impactedRegions.join(", ")}</div>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Services Affected</div>
                    <div className="text-xl font-semibold mt-1">{incident.serviceIds.length}</div>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Duration</div>
                    <div className="text-xl font-semibold tabular-nums mt-1">{formatDuration(incident.startedAt, incident.resolvedAt)}</div>
                  </div>
                </div>
                <Separator />
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Root Cause</h4>
                  <p className="text-sm text-foreground leading-relaxed">
                    {incident.rootCause ?? "Root cause not yet identified. Investigation is ongoing."}
                  </p>
                </div>
                {incident.resolution && (
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Resolution</h4>
                    <p className="text-sm text-foreground leading-relaxed">{incident.resolution}</p>
                  </div>
                )}
              </Card>
            </TabsContent>

            {/* Checklist */}
            <TabsContent value="checklist">
              <Card className="p-5">
                <SectionHeading
                  title="Response Checklist"
                  description={`${checklistDone} of ${checklist.length} steps completed`}
                  action={
                    <div className="flex items-center gap-2">
                      <Progress value={(checklistDone / checklist.length) * 100} className="w-24 h-1.5" />
                      <span className="text-xs tabular-nums text-muted-foreground">{Math.round((checklistDone / checklist.length) * 100)}%</span>
                    </div>
                  }
                />
                <div className="mt-4 space-y-1.5">
                  {checklist.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => toggleChecklistItem(item.id)}
                      className="w-full flex items-center gap-3 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors text-left"
                    >
                      {item.done ? (
                        <CheckCircle2 className="w-4 h-4 text-success shrink-0" />
                      ) : (
                        <Circle className="w-4 h-4 text-muted-foreground shrink-0" />
                      )}
                      <span className={`text-sm flex-1 ${item.done ? "text-muted-foreground line-through" : "text-foreground"}`}>{item.label}</span>
                    </button>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* War Room */}
            <TabsContent value="warroom">
              <Card className="p-5 space-y-4">
                <SectionHeading
                  title="War Room"
                  description="Live coordination channel and video bridge"
                  action={<Button size="sm" className="h-8 text-xs gap-1.5"><Radio className="w-3 h-3" />Join Bridge</Button>}
                />
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="rounded-lg border p-3 space-y-1">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Slack Channel</div>
                    <div className="text-sm font-mono font-medium">{incident.warRoomChannel ?? "—"}</div>
                    <Button asChild variant="link" size="sm" className="h-auto p-0 text-xs gap-1 mt-2">
                      <a href="#" onClick={(e) => e.preventDefault()}>Open in Slack <ExternalLink className="w-3 h-3" /></a>
                    </Button>
                  </div>
                  <div className="rounded-lg border p-3 space-y-1">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Video Bridge</div>
                    <div className="text-sm font-medium">meet.sentinelgrid.io/wr-{incident.ref.toLowerCase()}</div>
                    <Button asChild variant="link" size="sm" className="h-auto p-0 text-xs gap-1 mt-2">
                      <a href="#" onClick={(e) => e.preventDefault()}>Join meeting <ExternalLink className="w-3 h-3" /></a>
                    </Button>
                  </div>
                  <div className="rounded-lg border p-3 space-y-1">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Status Page</div>
                    <div className="text-sm font-medium">{incident.statusPagePosted ? "Live update posted" : "Not posted"}</div>
                    <Button asChild variant="link" size="sm" className="h-auto p-0 text-xs gap-1 mt-2">
                      <Link href="/incidents/status-page">View status page <ExternalLink className="w-3 h-3" /></Link>
                    </Button>
                  </div>
                </div>
                <Separator />
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Quick note to war room</h4>
                  <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Share an internal note with the war room..." rows={2} className="text-sm" />
                  <div className="flex justify-end mt-2">
                    <Button size="sm" className="h-7 text-xs gap-1.5" onClick={postNote} disabled={!note.trim()}>
                      <Send className="w-3 h-3" /> Post Note
                    </Button>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right sidebar */}
        <div className="space-y-4">
          <Card className="p-4 space-y-3 border-primary/20 bg-primary/5">
            <div className="flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-primary" />
              <h3 className="text-xs font-semibold uppercase tracking-wider">Incident Commander</h3>
            </div>
            {commander && (
              <div className="flex items-center gap-3">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={commander.avatarUrl} />
                  <AvatarFallback>{commander.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">{commander.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{commander.title}</div>
                  <div className="text-[11px] text-muted-foreground">@{commander.handle}</div>
                </div>
              </div>
            )}
            <Button size="sm" variant="outline" className="w-full h-8 text-xs gap-1.5" onClick={() => toast.info("Commander change requested")}>
              <ShieldAlert className="w-3 h-3" /> Change Commander
            </Button>
          </Card>

          {/* Quick Actions card */}
          <Card className="p-4 space-y-3 border-primary/20">
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-primary" />
              <h3 className="text-xs font-semibold uppercase tracking-wider">Quick Actions</h3>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast.success("Incident acknowledged")}>
                <CheckCircle2 className="w-3.5 h-3.5" /> Acknowledge
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast.info("Escalation policy EP-1 triggered")}>
                <Zap className="w-3.5 h-3.5" /> Escalate
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => setNoteModalOpen(true)}>
                <MessageSquare className="w-3.5 h-3.5" /> Add Note
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => setUpdateModalOpen(true)}>
                <Send className="w-3.5 h-3.5" /> Post Update
              </Button>
              {isActive ? (
                <Button size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast.success("Incident marked as resolved")}>
                  <CheckCircle2 className="w-3.5 h-3.5" /> Resolve
                </Button>
              ) : (
                <Button size="sm" className="h-8 text-xs gap-1.5" onClick={() => router.push("/postmortems/new")}>
                  <FileText className="w-3.5 h-3.5" /> Postmortem
                </Button>
              )}
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast.success("You subscribed to this incident")}>
                <Bell className="w-3.5 h-3.5" /> Subscribe
              </Button>
            </div>
          </Card>

          <Card className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-muted-foreground" />
                <h3 className="text-xs font-semibold uppercase tracking-wider">Responders</h3>
              </div>
              <span className="text-xs text-muted-foreground tabular-nums">{responders.length}</span>
            </div>
            <div className="space-y-1.5">
              {responders.map((r) => (
                <div key={r.id} className="flex items-center gap-2">
                  <Avatar className="w-6 h-6">
                    <AvatarImage src={r.avatarUrl} />
                    <AvatarFallback>{r.name[0]}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs truncate flex-1">{r.name}</span>
                  <StatusDot color="success" pulse size="sm" />
                </div>
              ))}
            </div>
            <Button size="sm" variant="outline" className="w-full h-8 text-xs gap-1.5" onClick={() => toast.info("Add responder dialog opened")}>
              <UserPlus className="w-3 h-3" /> Add Responder
            </Button>
          </Card>

          <Card className="p-4 space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-muted-foreground" /> Affected Services
            </h3>
            <div className="space-y-1.5">
              {svc.map((s) => (
                <Link key={s.id} href={`/services`} className="block p-2 rounded-md border hover:bg-muted/40 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium truncate">{s.name}</span>
                    <TierBadge tier={s.tier} />
                  </div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">{s.framework} · {s.regions.length} regions</div>
                </Link>
              ))}
            </div>
          </Card>

          {linkedAlerts.length > 0 && (
            <Card className="p-4 space-y-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5 text-muted-foreground" /> Linked Alerts
              </h3>
              <div className="space-y-1.5">
                {linkedAlerts.map((a) => (
                  <div key={a.id} className="p-2 rounded-md border">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[10px] font-mono text-muted-foreground">{a.ref}</span>
                      <SeverityBadge severity={a.severity} size="sm" />
                      <AlertStatusBadge status={a.status} />
                    </div>
                    <div className="text-[11px] text-foreground line-clamp-2">{a.message}</div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {linkedDeployment && (
            <Card className="p-4 space-y-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
                <Rocket className="w-3.5 h-3.5 text-muted-foreground" /> Linked Deployment
              </h3>
              <div className="p-2 rounded-md border">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono font-semibold">{linkedDeployment.ref}</span>
                  <Badge variant="outline" className="text-[10px] h-4 capitalize">{linkedDeployment.status.replace(/_/g, " ")}</Badge>
                </div>
                <div className="text-xs font-medium truncate">{linkedDeployment.commitMessage}</div>
                <div className="text-[11px] text-muted-foreground mt-1 font-mono">{linkedDeployment.commitSha} · v{linkedDeployment.version}</div>
                <Button asChild variant="link" size="sm" className="h-auto p-0 text-xs gap-1 mt-2">
                  <Link href="/deployments">View deployment <ChevronRight className="w-3 h-3" /></Link>
                </Button>
              </div>
            </Card>
          )}

          <Card className="p-4 space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-muted-foreground" /> Subscribers ({subscribers.length})
            </h3>
            {subscribers.length === 0 ? (
              <p className="text-[11px] text-muted-foreground">No subscribers yet.</p>
            ) : (
              <div className="flex flex-wrap gap-1">
                {subscribers.map((s) => (
                  <Avatar key={s.id} className="w-6 h-6 border-2 border-background">
                    <AvatarImage src={s.avatarUrl} />
                    <AvatarFallback>{s.name[0]}</AvatarFallback>
                  </Avatar>
                ))}
              </div>
            )}
            <Button asChild size="sm" variant="outline" className="w-full h-8 text-xs gap-1.5">
              <Link href="/incidents/subscribers">Manage Subscribers <ChevronRight className="w-3 h-3" /></Link>
            </Button>
          </Card>

          <Card className="p-4 space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-muted-foreground" /> Tags
            </h3>
            <div className="flex flex-wrap gap-1">
              {incident.tags.map((t) => (
                <Badge key={t} variant="outline" className="text-[10px] px-1.5 h-5">#{t}</Badge>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Add Note Modal */}
      <Dialog open={noteModalOpen} onOpenChange={setNoteModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-1.5 text-sm">
              <MessageSquare className="w-4 h-4 text-primary" /> Add Internal Note
            </DialogTitle>
            <DialogDescription className="text-xs">
              Add an internal note to the incident timeline. Visible only to responders — not stakeholders or the public.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Textarea
              value={modalNote}
              onChange={(e) => setModalNote(e.target.value)}
              placeholder="e.g. Identified that 3DS retry logic in v2.4.1-rc1 canary is causing the 5xx. Rolling back canary to 0%."
              rows={5}
              className="text-sm"
            />
            <p className="text-[11px] text-muted-foreground">
              Posting as <span className="font-medium text-foreground">{commander?.name ?? "you"}</span> · Internal audience only
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setNoteModalOpen(false)}>Cancel</Button>
            <Button size="sm" className="gap-1.5" onClick={submitModalNote} disabled={!modalNote.trim()}>
              <Send className="w-3.5 h-3.5" /> Post Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Post Update Modal */}
      <Dialog open={updateModalOpen} onOpenChange={setUpdateModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-1.5 text-sm">
              <Send className="w-4 h-4 text-primary" /> Post Incident Update
            </DialogTitle>
            <DialogDescription className="text-xs">
              Broadcast a status update. Stakeholder updates are emailed; public updates appear on the status page.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label className="text-xs font-medium">Audience</Label>
              <div className="grid grid-cols-3 gap-1.5 mt-1.5">
                {(["internal", "stakeholder", "public"] as const).map((a) => {
                  const ab = audienceBadge[a];
                  const active = modalAudience === a;
                  return (
                    <button
                      key={a}
                      onClick={() => setModalAudience(a)}
                      className={`inline-flex items-center justify-center gap-1 rounded-md border px-2 py-1.5 text-[11px] font-medium transition-colors ${active ? "border-primary bg-primary/10" : "border-border hover:bg-muted/40"} ${ab.className}`}
                    >
                      {ab.icon} {ab.label}
                    </button>
                  );
                })}
              </div>
            </div>
            <Textarea
              value={modalUpdate}
              onChange={(e) => setModalUpdate(e.target.value)}
              placeholder="e.g. We have identified the cause of elevated checkout failures and are rolling back the canary. Customers should see recovery within 5 minutes."
              rows={5}
              className="text-sm"
            />
            <p className="text-[11px] text-muted-foreground">
              Posting as <span className="font-medium text-foreground">{commander?.name ?? "you"}</span>
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setUpdateModalOpen(false)}>Cancel</Button>
            <Button size="sm" className="gap-1.5" onClick={submitModalUpdate} disabled={!modalUpdate.trim()}>
              <Send className="w-3.5 h-3.5" /> Post Update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
