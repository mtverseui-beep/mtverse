"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SeverityBadge } from "@/components/common/badges";
import { incidents, services, regions } from "@/lib/data";
import {
  Globe, CheckCircle2, AlertTriangle, ShieldAlert, Activity,
  Calendar, ExternalLink, Eye, RefreshCw, Bell,
} from "lucide-react";

const healthConfig: Record<string, { label: string; className: string; dot: string; icon: React.ReactNode }> = {
  operational: { label: "Operational", className: "bg-success/15 text-success border-success/30", dot: "bg-success", icon: <CheckCircle2 className="w-3.5 h-3.5" /> },
  degraded: { label: "Degraded Performance", className: "bg-warning/15 text-warning-foreground border-warning/30", dot: "bg-warning", icon: <AlertTriangle className="w-3.5 h-3.5" /> },
  partial: { label: "Partial Outage", className: "bg-destructive/15 text-destructive border-destructive/30", dot: "bg-destructive", icon: <ShieldAlert className="w-3.5 h-3.5" /> },
  major: { label: "Major Outage", className: "bg-destructive/20 text-destructive border-destructive/40", dot: "bg-destructive", icon: <ShieldAlert className="w-3.5 h-3.5" /> },
  maintenance: { label: "Maintenance", className: "bg-info/15 text-info-foreground border-info/30", dot: "bg-info", icon: <Activity className="w-3.5 h-3.5" /> },
};

export default function StatusPagePage() {
  const [refreshed, setRefreshed] = React.useState<Date>(new Date());
  const activeIncidents = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");
  const publicUpdates = incidents.flatMap((i) => i.updates.filter((u) => u.audience === "public").map((u) => ({ ...u, incident: i }))).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // Overall status
  const overallHealth = activeIncidents.some((i) => i.severity === "critical") ? "major" : activeIncidents.some((i) => i.severity === "high") ? "partial" : activeIncidents.length > 0 ? "degraded" : "operational";
  const overall = healthConfig[overallHealth];

  // Group services by category
  const serviceCategories = [
    { name: "API & Gateway", services: services.filter((s) => s.id === "s1" || s.id === "s3") },
    { name: "Payments & Billing", services: services.filter((s) => s.id === "s2" || s.id === "s6") },
    { name: "Data & Storage", services: services.filter((s) => s.id === "s4" || s.id === "s5" || s.id === "s7") },
    { name: "Web & Frontend", services: services.filter((s) => s.id === "s8" || s.id === "s11") },
  ].filter((c) => c.services.length > 0);

  // 90-day uptime bar
  const uptimeDays = Array.from({ length: 90 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (89 - i));
    const incidentsToday = incidents.filter((inc) => {
      const s = new Date(inc.startedAt);
      return s.toDateString() === date.toDateString();
    });
    const hasIssue = incidentsToday.length > 0;
    return { date, hasIssue, severity: incidentsToday[0]?.severity };
  });

  function refresh() {
    setRefreshed(new Date());
  }

  return (
    <PageContainer>
      <PageHeader
        title="Public Status Page"
        description="Preview of what customers see at status.sentinelgrid.io. This is the public-facing view of system health."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Status Page" }]}
        icon={<Globe className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={refresh}>
              <RefreshCw className="w-3.5 h-3.5" /> Refresh
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => window.open("#", "_blank")}>
              <ExternalLink className="w-3.5 h-3.5" /> Open Live
            </Button>
          </>
        }
        meta={<span className="text-[11px] text-muted-foreground">Last updated: {refreshed.toLocaleTimeString()}</span>}
      />

      {/* Mock status page */}
      <Card className="p-6 md:p-8 bg-background">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto">
          <div className="flex items-center justify-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4 text-primary" />
            </div>
            <h2 className="text-xl font-semibold">SentinelGrid Status</h2>
          </div>
          {/* Overall status banner */}
          <div className={`rounded-xl border-2 p-6 ${overall.className}`}>
            <div className="flex items-center justify-center gap-3 mb-2">
              <div className={`w-10 h-10 rounded-full ${overall.dot} flex items-center justify-center text-white`}>
                {overall.icon}
              </div>
              <span className="text-2xl font-bold">{overall.label}</span>
            </div>
            <p className="text-xs opacity-80">
              {overallHealth === "operational"
                ? "All systems are operational."
                : `${activeIncidents.length} active incident${activeIncidents.length > 1 ? "s" : ""} affecting service.`}
            </p>
          </div>
          <div className="text-[11px] text-muted-foreground mt-3 flex items-center justify-center gap-1">
            <Calendar className="w-3 h-3" />
            Last updated {refreshed.toLocaleString()} · Auto-refreshes every 60 seconds
          </div>
        </div>

        {/* 90-day uptime */}
        <div className="mt-8 max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">90-Day Availability</h3>
            <span className="text-xs text-success font-semibold">99.94% uptime</span>
          </div>
          <div className="flex gap-0.5">
            {uptimeDays.map((d, i) => (
              <div
                key={i}
                title={`${d.date.toLocaleDateString()} - ${d.hasIssue ? "Issue" : "Operational"}`}
                className={`flex-1 h-8 rounded-sm ${d.hasIssue ? (d.severity === "critical" ? "bg-destructive" : d.severity === "high" ? "bg-warning" : "bg-info") : "bg-success/70"}`}
              />
            ))}
          </div>
          <div className="flex items-center justify-between text-[10px] text-muted-foreground mt-1">
            <span>90 days ago</span>
            <span>Today</span>
          </div>
        </div>

        {/* Services by category */}
        <div className="mt-8 max-w-3xl mx-auto space-y-6">
          {serviceCategories.map((cat) => (
            <div key={cat.name}>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">{cat.name}</h3>
              <div className="space-y-1.5">
                {cat.services.map((s) => {
                  const h = healthConfig[s.health];
                  return (
                    <div key={s.id} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${h.dot} ${s.health === "operational" ? "animate-status-pulse" : ""}`} />
                        <span className="text-sm font-medium">{s.name}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="hidden sm:flex gap-0.5">
                          {Array.from({ length: 14 }).map((_, i) => (
                            <div key={i} className={`w-1.5 h-4 rounded-sm ${i === 7 && s.health !== "operational" ? h.dot : "bg-success/60"}`} />
                          ))}
                        </div>
                        <span className="text-xs text-success font-medium">99.9%</span>
                        <Badge className={`text-[10px] ${h.className}`}>{h.label}</Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Active incidents */}
        {activeIncidents.length > 0 && (
          <div className="mt-10 max-w-3xl mx-auto">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Active Incidents</h3>
            <div className="space-y-3">
              {activeIncidents.map((inc) => (
                <div key={inc.id} className="rounded-lg border-l-4 border-l-destructive/60 border border-border p-4">
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <span className="text-xs font-mono font-semibold text-muted-foreground">{inc.ref}</span>
                    <SeverityBadge severity={inc.severity} size="sm" />
                    <Badge variant="outline" className="text-[10px] capitalize">{inc.status}</Badge>
                    <span className="text-[11px] text-muted-foreground ml-auto">{new Date(inc.startedAt).toLocaleString()}</span>
                  </div>
                  <h4 className="text-sm font-semibold mb-1">{inc.title}</h4>
                  <p className="text-xs text-muted-foreground">{inc.customerImpact}</p>
                  {inc.updates.filter((u) => u.audience === "public").slice(0, 1).map((u) => (
                    <div key={u.id} className="mt-3 pt-3 border-t border-border">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Latest update</div>
                      <p className="text-xs">{u.body}</p>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent incidents */}
        <div className="mt-10 max-w-3xl mx-auto">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Recent Public Updates</h3>
          <div className="space-y-2">
            {publicUpdates.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-6">No recent public updates.</p>
            ) : (
              publicUpdates.map((u) => (
                <div key={u.id} className="rounded-lg border p-3">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-xs font-mono font-semibold text-muted-foreground">{u.incident.ref}</span>
                    <SeverityBadge severity={u.incident.severity} size="sm" />
                    <span className="text-[11px] text-muted-foreground ml-auto">{new Date(u.timestamp).toLocaleString()}</span>
                  </div>
                  <p className="text-xs">{u.body}</p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Scheduled maintenance */}
        <div className="mt-10 max-w-3xl mx-auto">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Scheduled Maintenance</h3>
          <div className="rounded-lg border border-info/30 bg-info/5 p-4">
            <div className="flex items-start gap-3">
              <Calendar className="w-4 h-4 text-info shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-medium">Database failover drill — eu-west-1</div>
                <div className="text-xs text-muted-foreground mt-1">Saturday, July 12, 2026 · 02:00 - 04:00 UTC</div>
                <p className="text-xs mt-2">Brief connectivity interruptions possible in eu-west-1 during controlled failover testing.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Subscribe */}
        <div className="mt-10 max-w-md mx-auto text-center">
          <div className="rounded-xl border border-dashed p-5 bg-muted/20">
            <Bell className="w-5 h-5 text-primary mx-auto mb-2" />
            <h4 className="text-sm font-semibold">Subscribe to updates</h4>
            <p className="text-xs text-muted-foreground mt-1 mb-3">Get notified when incidents are declared or resolved.</p>
            <div className="flex gap-1.5">
              <input type="email" placeholder="you@company.com" className="flex-1 rounded-md border bg-background px-3 py-1.5 text-sm" />
              <Button size="sm" className="gap-1.5"><Bell className="w-3 h-3" /> Subscribe</Button>
            </div>
          </div>
          <p className="text-[11px] text-muted-foreground mt-4">
            Powered by SentinelGrid · status.sentinelgrid.io
          </p>
        </div>
      </Card>
    </PageContainer>
  );
}
