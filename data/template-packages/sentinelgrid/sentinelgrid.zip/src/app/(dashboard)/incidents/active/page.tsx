"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SeverityBadge, IncidentStatusBadge, StatusDot } from "@/components/common/badges";
import { incidents, people, services } from "@/lib/data";
import { toast } from "sonner";
import {
  Siren, Activity, ShieldAlert, Users, Timer, MessageSquare,
  ArrowUpRight, Radio, Zap, UserPlus, CheckCircle2,
} from "lucide-react";

const sevColor: Record<string, string> = {
  critical: "border-l-destructive",
  high: "border-l-warning",
  medium: "border-l-info",
  low: "border-l-muted-foreground",
};

export default function ActiveIncidentsPage() {
  const now = Date.now();
  const active = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");
  const critical = active.filter((i) => i.severity === "critical").length;
  const high = active.filter((i) => i.severity === "high").length;

  function formatDuration(startedAt: string) {
    const diff = now - new Date(startedAt).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h ${mins % 60}m`;
    if (hours > 0) return `${hours}h ${mins % 60}m`;
    return `${mins}m`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Active Incidents"
        description="Live board of all unresolved incidents. Each card is a war-room preview — click Enter to join."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Active" }]}
        icon={<Siren className="w-5 h-5" />}
        actions={
          <Button asChild size="sm" className="gap-1.5">
            <Link href="/incidents/war-rooms"><Radio className="w-3.5 h-3.5" /> War Rooms</Link>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Active" value={active.length} hint="Currently being worked" icon={<Siren className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Critical" value={critical} hint="Tier-1 down or widespread" icon={<ShieldAlert className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="High" value={high} hint="Significant degradation" icon={<Activity className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Responders Engaged" value={active.reduce((acc, i) => acc + i.responderIds.length, 0)} hint="Across all active" icon={<Users className="w-4 h-4" />} accent="primary" />
      </div>

      {active.length === 0 ? (
        <Card>
          <EmptyState
            icon={<CheckCircle2 className="w-5 h-5" />}
            title="All systems operational"
            description="There are no active incidents. Enjoy the quiet."
            action={<Button asChild size="sm"><Link href="/incidents">View all incidents</Link></Button>}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {active.map((inc) => {
            const commander = people.find((p) => p.id === inc.commanderId);
            const responders = inc.responderIds.map((id) => people.find((p) => p.id === id)).filter(Boolean);
            const svcs = inc.serviceIds.map((id) => services.find((s) => s.id === id)).filter(Boolean);
            const lastEvent = inc.timeline[inc.timeline.length - 1];
            const lastAuthor = lastEvent ? people.find((p) => p.id === lastEvent.authorId) : null;
            const checklistDone = inc.checklist.filter((c) => c.done).length;
            const isCritical = inc.severity === "critical" || inc.severity === "high";
            return (
              <Card key={inc.id} className={`p-4 border-l-4 ${sevColor[inc.severity]} hover:bg-elevated/40 transition-colors flex flex-col`}>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-mono font-semibold text-muted-foreground">{inc.ref}</span>
                    <SeverityBadge severity={inc.severity} size="sm" />
                    <IncidentStatusBadge status={inc.status} />
                  </div>
                  <StatusDot color={isCritical ? "destructive" : "warning"} pulse size="md" />
                </div>

                <h3 className="text-sm font-semibold line-clamp-2 mb-1.5">{inc.title}</h3>
                <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{inc.customerImpact}</p>

                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="rounded-md border p-2">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Duration</div>
                    <div className="flex items-center gap-1 mt-0.5">
                      <Timer className="w-3 h-3 text-muted-foreground" />
                      <span className="text-sm font-semibold tabular-nums">{formatDuration(inc.startedAt)}</span>
                    </div>
                  </div>
                  <div className="rounded-md border p-2">
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Impacted</div>
                    <div className="text-sm font-semibold tabular-nums mt-0.5">{inc.impactedUsers.toLocaleString()}</div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-1.5 min-w-0">
                    {commander && (
                      <>
                        <Avatar className="w-6 h-6">
                          <AvatarImage src={commander.avatarUrl} />
                          <AvatarFallback>{commander.name[0]}</AvatarFallback>
                        </Avatar>
                        <span className="text-xs truncate">{commander.name}</span>
                        <Badge className="text-[10px] h-4 px-1.5 gap-0.5"><ShieldAlert className="w-2.5 h-2.5" />IC</Badge>
                      </>
                    )}
                  </div>
                  <div className="flex -space-x-2 shrink-0">
                    {responders.slice(0, 3).map((r) => r && (
                      <Avatar key={r.id} className="w-6 h-6 border-2 border-background">
                        <AvatarImage src={r.avatarUrl} />
                        <AvatarFallback>{r.name[0]}</AvatarFallback>
                      </Avatar>
                    ))}
                    {responders.length > 3 && (
                      <div className="w-6 h-6 rounded-full bg-muted border-2 border-background flex items-center justify-center text-[10px] font-medium">
                        +{responders.length - 3}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap mb-3">
                  {svcs.map((s) => (
                    <Badge key={s!.id} variant="outline" className="text-[10px] h-5">{s!.name}</Badge>
                  ))}
                </div>

                {lastEvent && (
                  <div className="pt-3 border-t border-border mb-3">
                    <div className="flex items-start gap-2">
                      <MessageSquare className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
                      <p className="text-[11px] text-muted-foreground line-clamp-2 flex-1">
                        <span className="font-medium text-foreground">{lastAuthor?.name ?? "System"}:</span> {lastEvent.message}
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between gap-2 mb-3 mt-auto">
                  <div className="flex items-center gap-1.5">
                    <Progress value={(checklistDone / inc.checklist.length) * 100} className="w-16 h-1.5" />
                    <span className="text-[11px] text-muted-foreground tabular-nums">{checklistDone}/{inc.checklist.length}</span>
                  </div>
                  <span className="text-[10px] font-mono text-muted-foreground">{inc.warRoomChannel}</span>
                </div>

                <div className="flex gap-1.5">
                  <Button asChild size="sm" className="flex-1 h-8 text-xs gap-1.5">
                    <Link href={`/incidents/${inc.id}`}>
                      Enter War Room <ArrowUpRight className="w-3 h-3" />
                    </Link>
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => toast.info(`Escalated ${inc.ref}`)}>
                    <Zap className="w-3.5 h-3.5" />
                  </Button>
                  <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => toast.info(`Add responder to ${inc.ref}`)}>
                    <UserPlus className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </PageContainer>
  );
}
