"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SeverityBadge } from "@/components/common/badges";
import { incidents, people } from "@/lib/data";
import type { IncidentTimelineEvent } from "@/lib/types";
import {
  Siren, Clock, Plus, CheckCircle2, Activity, AlertTriangle, MessageSquare,
  Globe, UserPlus, Users, ShieldAlert, Rocket, BookOpen, Bell, Zap, FileText,
  Filter,
} from "lucide-react";

const kindIcon: Record<IncidentTimelineEvent["kind"], React.ReactNode> = {
  created: <Plus className="w-3 h-3" />,
  acknowledged: <CheckCircle2 className="w-3 h-3" />,
  status_change: <Activity className="w-3 h-3" />,
  severity_change: <AlertTriangle className="w-3 h-3" />,
  note: <MessageSquare className="w-3 h-3" />,
  public_update: <Globe className="w-3 h-3" />,
  responder_added: <UserPlus className="w-3 h-3" />,
  responder_removed: <Users className="w-3 h-3" />,
  commander_change: <ShieldAlert className="w-3 h-3" />,
  service_added: <Activity className="w-3 h-3" />,
  deployment_linked: <Rocket className="w-3 h-3" />,
  runbook_linked: <BookOpen className="w-3 h-3" />,
  alert_linked: <Bell className="w-3 h-3" />,
  resolved: <CheckCircle2 className="w-3 h-3" />,
  escalated: <Zap className="w-3 h-3" />,
  subscriber_added: <Bell className="w-3 h-3" />,
  postmortem_started: <FileText className="w-3 h-3" />,
};

const kindOptions: { label: string; value: string }[] = [
  { label: "Created", value: "created" },
  { label: "Acknowledged", value: "acknowledged" },
  { label: "Status Change", value: "status_change" },
  { label: "Severity Change", value: "severity_change" },
  { label: "Note", value: "note" },
  { label: "Public Update", value: "public_update" },
  { label: "Responder Added", value: "responder_added" },
  { label: "Commander Change", value: "commander_change" },
  { label: "Deployment Linked", value: "deployment_linked" },
  { label: "Runbook Linked", value: "runbook_linked" },
  { label: "Alert Linked", value: "alert_linked" },
  { label: "Resolved", value: "resolved" },
  { label: "Escalated", value: "escalated" },
];

const kindColor: Record<string, string> = {
  created: "bg-primary/15 text-primary border-primary/30",
  acknowledged: "bg-info/15 text-info-foreground border-info/30",
  status_change: "bg-info/15 text-info-foreground border-info/30",
  severity_change: "bg-warning/15 text-warning-foreground border-warning/30",
  note: "bg-muted text-muted-foreground border-border",
  public_update: "bg-success/15 text-success border-success/30",
  responder_added: "bg-accent text-accent-foreground border-accent/30",
  commander_change: "bg-primary/15 text-primary border-primary/30",
  resolved: "bg-success/15 text-success border-success/30",
  escalated: "bg-destructive/15 text-destructive border-destructive/30",
};

export default function IncidentTimelinePage() {
  const [filter, setFilter] = React.useState<string>("");
  const allEvents = React.useMemo(() => {
    return incidents
      .flatMap((i) => i.timeline.map((t) => ({ ...t, incident: i })))
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, []);
  const filtered = filter ? allEvents.filter((e) => e.kind === filter) : allEvents;

  function day(ts: string) {
    return new Date(ts).toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });
  }

  // group by day
  const groups: Record<string, typeof filtered> = {};
  filtered.forEach((e) => {
    const d = day(e.timestamp);
    if (!groups[d]) groups[d] = [];
    groups[d].push(e);
  });

  return (
    <PageContainer>
      <PageHeader
        title="Incident Timeline"
        description="Cross-incident chronological timeline of every event across the platform."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "Timeline" }]}
        icon={<Clock className="w-5 h-5" />}
      />

      <Card className="p-4">
        <div className="flex items-center gap-2 flex-wrap">
          <Filter className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-xs font-medium">Filter by event kind:</span>
          <Button variant={filter === "" ? "default" : "outline"} size="sm" className="h-7 text-xs" onClick={() => setFilter("")}>All</Button>
          {kindOptions.map((o) => (
            <Button key={o.value} variant={filter === o.value ? "default" : "outline"} size="sm" className="h-7 text-xs" onClick={() => setFilter(o.value)}>
              {o.label}
            </Button>
          ))}
        </div>
      </Card>

      <Card className="p-5">
        <SectionHeading
          title={`${filtered.length} events`}
          description="Most recent first"
        />
        {filtered.length === 0 ? (
          <EmptyState icon={<Clock className="w-5 h-5" />} title="No events match" description="Try clearing the filter." />
        ) : (
          <div className="mt-5 space-y-6 max-h-[820px] overflow-y-auto pr-1 custom-scroll">
            {Object.entries(groups).map(([day, events]) => (
              <div key={day}>
                <div className="sticky top-0 z-10 bg-card py-1.5 mb-2 -mx-1 px-1">
                  <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{day}</span>
                  <span className="text-[11px] text-muted-foreground ml-2">({events.length})</span>
                </div>
                <div className="space-y-1">
                  {events.map((evt, i) => {
                    const author = people.find((p) => p.id === evt.authorId);
                    return (
                      <div key={evt.id} className="flex items-start gap-3 group">
                        <div className="relative flex flex-col items-center">
                          <div className={`w-7 h-7 rounded-full border flex items-center justify-center ${kindColor[evt.kind] ?? "bg-muted text-muted-foreground border-border"}`}>
                            {kindIcon[evt.kind]}
                          </div>
                          {i < events.length - 1 && <div className="w-px flex-1 bg-border mt-1 min-h-[24px]" />}
                        </div>
                        <div className="flex-1 min-w-0 pb-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-medium">{author?.name ?? "System"}</span>
                            <Link href={`/incidents/${evt.incident.id}`} className="text-[10px] font-mono text-primary hover:underline">{evt.incident.ref}</Link>
                            <Badge variant="outline" className={`text-[10px] capitalize px-1.5 py-0 h-4 ${kindColor[evt.kind] ?? ""}`}>
                              {evt.kind.replace(/_/g, " ")}
                            </Badge>
                            <SeverityBadge severity={evt.incident.severity} size="sm" />
                            <span className="text-[11px] text-muted-foreground">
                              {new Date(evt.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                          </div>
                          <p className="text-xs text-foreground mt-1">{evt.message}</p>
                          <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{evt.incident.title}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </PageContainer>
  );
}
