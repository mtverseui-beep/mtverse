"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { SeverityBadge } from "@/components/common/badges";
import { people, services } from "@/lib/data";
import { toast } from "sonner";
import {
  Siren, ArrowLeft, Plus, X, Check, AlertTriangle, ShieldAlert,
  Info, AlertOctagon, Send, Save, Server,
} from "lucide-react";

const sevConfig = [
  { value: "critical", label: "Critical", desc: "Major outage, Tier-1 down, broad customer impact", icon: ShieldAlert },
  { value: "high", label: "High", desc: "Significant degradation, partial outage, regional impact", icon: AlertTriangle },
  { value: "medium", label: "Medium", desc: "Performance regression, limited customer impact", icon: Info },
  { value: "low", label: "Low", desc: "Minor issue, no customer-visible impact", icon: AlertOctagon },
] as const;

export default function NewIncidentPage() {
  const router = useRouter();
  const [title, setTitle] = React.useState("");
  const [summary, setSummary] = React.useState("");
  const [severity, setSeverity] = React.useState<"critical" | "high" | "medium" | "low">("high");
  const [commanderId, setCommanderId] = React.useState("u1");
  const [selectedServices, setSelectedServices] = React.useState<string[]>([]);
  const [initialUpdate, setInitialUpdate] = React.useState("");
  const [postPublic, setPostPublic] = React.useState(false);

  function toggleService(sid: string) {
    setSelectedServices((prev) => prev.includes(sid) ? prev.filter((x) => x !== sid) : [...prev, sid]);
  }

  function submit() {
    if (!title.trim()) {
      toast.error("Title is required");
      return;
    }
    if (selectedServices.length === 0) {
      toast.error("Select at least one affected service");
      return;
    }
    toast.success("Incident declared — war room created");
    setTimeout(() => router.push("/incidents"), 600);
  }

  return (
    <PageContainer>
      <PageHeader
        title="Declare Incident"
        description="Open a new incident with an initial severity, commander, and affected services. A war room will be created automatically."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Incidents", href: "/incidents" }, { label: "New" }]}
        icon={<Siren className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => router.push("/incidents")}>
            <ArrowLeft className="w-3.5 h-3.5" /> Cancel
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Incident Basics" description="Provide a clear title and summary so responders can quickly understand the situation" />
            <div className="space-y-3">
              <div>
                <Label htmlFor="title" className="text-xs">Title <span className="text-destructive">*</span></Label>
                <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Checkout API elevated 5xx rate in us-east-1" className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="summary" className="text-xs">Summary</Label>
                <Textarea id="summary" value={summary} onChange={(e) => setSummary(e.target.value)} placeholder="Brief description of the issue, scope, and any known impact..." rows={3} className="mt-1.5" />
              </div>
            </div>
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Severity" description="Choose the most appropriate severity. The severity rules page has guidance." />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {sevConfig.map((s) => {
                const Icon = s.icon;
                const active = severity === s.value;
                return (
                  <button
                    key={s.value}
                    onClick={() => setSeverity(s.value)}
                    className={`text-left p-3 rounded-lg border transition-colors ${active ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Icon className={`w-4 h-4 ${active ? "text-primary" : "text-muted-foreground"}`} />
                      <SeverityBadge severity={s.value} size="sm" />
                      {active && <Check className="w-3.5 h-3.5 text-primary ml-auto" />}
                    </div>
                    <p className="text-[11px] text-muted-foreground leading-snug">{s.desc}</p>
                  </button>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading
              title="Affected Services"
              description="Select all services impacted by this incident"
              action={<span className="text-xs text-muted-foreground tabular-nums">{selectedServices.length} selected</span>}
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1 custom-scroll">
              {services.map((s) => {
                const checked = selectedServices.includes(s.id);
                return (
                  <button
                    key={s.id}
                    onClick={() => toggleService(s.id)}
                    className={`flex items-center gap-2 p-2.5 rounded-md border text-left transition-colors ${checked ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}
                  >
                    <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${checked ? "bg-primary border-primary" : "border-border"}`}>
                      {checked && <Check className="w-3 h-3 text-primary-foreground" />}
                    </div>
                    <Server className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium truncate">{s.name}</div>
                      <div className="text-[10px] text-muted-foreground">{s.tier} · {s.regions.length} regions</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Initial Update" description="The first status update that goes out to the chosen audience" />
            <div>
              <Label className="text-xs">Update body</Label>
              <Textarea
                value={initialUpdate}
                onChange={(e) => setInitialUpdate(e.target.value)}
                placeholder="We are investigating elevated checkout failures in US-East. Some payment attempts may fail. Please retry."
                rows={4}
                className="mt-1.5"
              />
            </div>
            <label className="flex items-center gap-2 text-xs cursor-pointer">
              <input type="checkbox" checked={postPublic} onChange={(e) => setPostPublic(e.target.checked)} className="accent-primary w-4 h-4" />
              <span>Post as public status page update (visible to customers)</span>
            </label>
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <SectionHeading title="Commander" description="The incident commander coordinates the response" />
            <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1 custom-scroll">
              {people.slice(0, 8).map((p) => {
                const active = commanderId === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => setCommanderId(p.id)}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-md border text-left transition-colors ${active ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"}`}
                  >
                    <img src={p.avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium truncate">{p.name}</div>
                      <div className="text-[11px] text-muted-foreground truncate">{p.title}</div>
                    </div>
                    {active && <Check className="w-3.5 h-3.5 text-primary" />}
                  </button>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Summary" description="Review before declaring" />
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Title</span>
                <span className="font-medium truncate ml-2 max-w-[160px]">{title || "—"}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Severity</span>
                <SeverityBadge severity={severity} size="sm" />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Services</span>
                <span className="font-medium tabular-nums">{selectedServices.length}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Commander</span>
                <span className="font-medium truncate ml-2 max-w-[160px]">{people.find((p) => p.id === commanderId)?.name ?? "—"}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Public update</span>
                <span className="font-medium">{postPublic ? "Yes" : "No"}</span>
              </div>
            </div>
            <Separator />
            <div className="flex flex-col gap-2">
              <Button className="w-full gap-1.5" onClick={submit}>
                <Siren className="w-3.5 h-3.5" /> Declare Incident
              </Button>
              <Button variant="outline" className="w-full gap-1.5" onClick={() => toast.success("Saved as draft")}>
                <Save className="w-3.5 h-3.5" /> Save as Draft
              </Button>
            </div>
          </Card>

          <Card className="p-4 bg-muted/30 border-dashed">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
              <div className="text-xs text-muted-foreground leading-relaxed">
                Declaring an incident will page the on-call, create a Slack war room, and notify subscribers based on severity policy.
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
