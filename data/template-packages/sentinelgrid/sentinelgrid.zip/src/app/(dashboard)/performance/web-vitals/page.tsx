"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LineChartCard, RadialGauge } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { Globe, Clock, Layers, MousePointerClick, Zap, Activity, Download } from "lucide-react";

interface VitalDef {
  key: string;
  label: string;
  full: string;
  value: number;
  unit: string;
  goodMax: number;
  poorMin: number;
  color: "success" | "warning" | "destructive" | "info" | "primary" | "accent";
  icon: React.ReactNode;
}

const vitals: VitalDef[] = [
  { key: "lcp", label: "LCP", full: "Largest Contentful Paint", value: 2.1, unit: "s", goodMax: 2.5, poorMin: 4.0, color: "success", icon: <Globe className="w-4 h-4" /> },
  { key: "fid", label: "FID", full: "First Input Delay", value: 92, unit: "ms", goodMax: 100, poorMin: 300, color: "success", icon: <MousePointerClick className="w-4 h-4" /> },
  { key: "cls", label: "CLS", full: "Cumulative Layout Shift", value: 0.14, unit: "", goodMax: 0.1, poorMin: 0.25, color: "warning", icon: <Layers className="w-4 h-4" /> },
  { key: "fcp", label: "FCP", full: "First Contentful Paint", value: 1.4, unit: "s", goodMax: 1.8, poorMin: 3.0, color: "success", icon: <Clock className="w-4 h-4" /> },
  { key: "ttfb", label: "TTFB", full: "Time to First Byte", value: 480, unit: "ms", goodMax: 800, poorMin: 1800, color: "success", icon: <Activity className="w-4 h-4" /> },
  { key: "inp", label: "INP", full: "Interaction to Next Paint", value: 240, unit: "ms", goodMax: 200, poorMin: 500, color: "warning", icon: <Zap className="w-4 h-4" /> },
];

function vitalStatus(v: VitalDef): "good" | "needs improvement" | "poor" {
  if (v.value <= v.goodMax) return "good";
  if (v.value >= v.poorMin) return "poor";
  return "needs improvement";
}

interface PageVital {
  id: string;
  url: string;
  lcp: number;
  fid: number;
  cls: number;
  inp: number;
  views: number;
}

const worstPages: PageVital[] = [
  { id: "p1", url: "/dashboard/analytics", lcp: 4.2, fid: 280, cls: 0.32, inp: 520, views: 18400 },
  { id: "p2", url: "/billing/history", lcp: 3.6, fid: 180, cls: 0.18, inp: 340, views: 9200 },
  { id: "p3", url: "/settings/team", lcp: 3.1, fid: 142, cls: 0.24, inp: 280, views: 6400 },
  { id: "p4", url: "/reports/monthly", lcp: 2.9, fid: 220, cls: 0.21, inp: 410, views: 4200 },
  { id: "p5", url: "/checkout/review", lcp: 2.7, fid: 156, cls: 0.16, inp: 240, views: 12400 },
  { id: "p6", url: "/integrations/list", lcp: 2.5, fid: 132, cls: 0.12, inp: 210, views: 3200 },
  { id: "p7", url: "/profile/notifications", lcp: 2.4, fid: 110, cls: 0.14, inp: 195, views: 8800 },
  { id: "p8", url: "/admin/audit-log", lcp: 2.2, fid: 124, cls: 0.10, inp: 188, views: 1100 },
];

export default function WebVitalsPage() {
  const trendData = React.useMemo(() => {
    return vitals.slice(0, 4).map((v) => ({
      vital: v,
      data: timeSeries(v.key.charCodeAt(0), 30, v.value, v.value * 0.15).map((d) => ({
        date: d.date,
        value: Number(d.value.toFixed(2)),
      })),
    }));
  }, []);

  const columns: Column<PageVital>[] = [
    {
      key: "url",
      header: "Page URL",
      sortable: true,
      sortValue: (r) => r.url,
      cell: (r) => <span className="text-xs font-mono truncate">{r.url}</span>,
    },
    {
      key: "lcp",
      header: "LCP",
      align: "right",
      sortable: true,
      sortValue: (r) => r.lcp,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.lcp > 4 ? "text-destructive" : r.lcp > 2.5 ? "text-warning-foreground" : "text-success"}`}>{r.lcp.toFixed(1)}s</span>,
    },
    {
      key: "fid",
      header: "FID",
      align: "right",
      sortable: true,
      sortValue: (r) => r.fid,
      hideOnMobile: true,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.fid > 300 ? "text-destructive" : r.fid > 100 ? "text-warning-foreground" : "text-success"}`}>{r.fid}ms</span>,
    },
    {
      key: "cls",
      header: "CLS",
      align: "right",
      sortable: true,
      sortValue: (r) => r.cls,
      hideOnMobile: true,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.cls > 0.25 ? "text-destructive" : r.cls > 0.1 ? "text-warning-foreground" : "text-success"}`}>{r.cls.toFixed(2)}</span>,
    },
    {
      key: "inp",
      header: "INP",
      align: "right",
      sortable: true,
      sortValue: (r) => r.inp,
      hideOnMobile: true,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.inp > 500 ? "text-destructive" : r.inp > 200 ? "text-warning-foreground" : "text-success"}`}>{r.inp}ms</span>,
    },
    {
      key: "views",
      header: "Views (7d)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.views,
      cell: (r) => <span className="text-xs tabular-nums">{r.views.toLocaleString()}</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Core Web Vitals"
        description="Real-user monitoring (RUM) of Google's Core Web Vitals and supporting metrics across the customer-facing web app."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "Web Vitals" }]}
        icon={<Globe className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Field data refreshed")}>
            <Activity className="w-3.5 h-3.5" /> <span className="hidden md:inline">Refresh</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
        {vitals.map((v) => {
          const status = vitalStatus(v);
          const accent = status === "good" ? "success" : status === "poor" ? "destructive" : "warning";
          return (
            <KpiCard
              key={v.key}
              label={v.label}
              value={v.value.toFixed(v.unit === "ms" ? 0 : 2)}
              unit={v.unit}
              hint={status === "good" ? "Good" : status === "poor" ? "Poor" : "Needs improvement"}
              icon={v.icon}
              accent={accent as any}
            />
          );
        })}
      </div>

      {/* Gauges */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {vitals.map((v) => {
          const status = vitalStatus(v);
          const colorIdx = status === "good" ? 3 : status === "poor" ? 4 : 2;
          return (
            <Card key={`g-${v.key}`} className="p-4 flex flex-col items-center justify-center gap-2">
              <RadialGauge value={Math.min(100, Math.round((v.value / v.poorMin) * 60 + 20))} target={100} label={v.label} color={colorIdx} size={120} />
              <div className="text-center space-y-0.5">
                <div className="text-xs font-medium">{v.value.toFixed(v.unit === "ms" ? 0 : 2)} {v.unit}</div>
                <div className={`text-[10px] uppercase tracking-wide ${status === "good" ? "text-success" : status === "poor" ? "text-destructive" : "text-warning-foreground"}`}>
                  {status}
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Trend grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {trendData.map(({ vital, data }) => (
          <Card key={`t-${vital.key}`} className="p-4 h-[260px]">
            <SectionHeading title={`${vital.full} Trend`} description="75th percentile over 30 days" />
            <div className="h-[180px] mt-2">
              <LineChartCard data={data} suffix={` ${vital.unit}`} />
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Pages with Worst Vitals" description="Lowest-performing pages by LCP, ranked by traffic impact." />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={worstPages}
            rowKey={(r) => r.id}
            searchKeys={["url"]}
            searchPlaceholder="Search page URLs..."
            pageSize={8}
            initialSort={{ key: "lcp", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
