"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { DonutChart, HorizontalBarChart } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { Network, Clock, AlertTriangle, Database, Download, Activity } from "lucide-react";

interface EndpointPerf {
  id: string;
  path: string;
  method: string;
  service: string;
  latency: number;
  rps: number;
  errorRate: number;
  cacheHit: number;
}

const endpoints: EndpointPerf[] = [
  { id: "e1", path: "/api/v1/reports/generate", method: "GET", service: "billing-service", latency: 580, rps: 80, errorRate: 0.42, cacheHit: 12 },
  { id: "e2", path: "/api/v1/checkout/process", method: "POST", service: "checkout-api", latency: 312, rps: 940, errorRate: 1.4, cacheHit: 0 },
  { id: "e3", path: "/api/v1/invoices/generate", method: "POST", service: "billing-service", latency: 240, rps: 320, errorRate: 0.21, cacheHit: 8 },
  { id: "e4", path: "/api/v1/ledger/entries", method: "POST", service: "payment-ledger", latency: 184, rps: 320, errorRate: 0.05, cacheHit: 0 },
  { id: "e5", path: "/api/v1/notifications/send", method: "POST", service: "api-gateway", latency: 142, rps: 980, errorRate: 0.22, cacheHit: 0 },
  { id: "e6", path: "/api/v1/webhooks/dispatch", method: "POST", service: "api-gateway", latency: 110, rps: 1800, errorRate: 0.18, cacheHit: 0 },
  { id: "e7", path: "/api/v1/users/profile", method: "GET", service: "api-gateway", latency: 68, rps: 12400, errorRate: 0.02, cacheHit: 94 },
  { id: "e8", path: "/api/v1/subscriptions/list", method: "GET", service: "billing-service", latency: 58, rps: 240, errorRate: 0.08, cacheHit: 88 },
  { id: "e9", path: "/api/v1/auth/token", method: "POST", service: "auth-service", latency: 52, rps: 8900, errorRate: 0.04, cacheHit: 0 },
  { id: "e10", path: "/api/v1/sessions/refresh", method: "POST", service: "auth-service", latency: 34, rps: 6800, errorRate: 0.01, cacheHit: 42 },
];

const statusDist = [
  { name: "2xx Success", value: 412800 },
  { name: "3xx Redirect", value: 8400 },
  { name: "4xx Client Error", value: 18200 },
  { name: "5xx Server Error", value: 1280 },
];

const latByEndpoint = [
  { name: "/reports/generate", value: 580 },
  { name: "/checkout/process", value: 312 },
  { name: "/invoices/generate", value: 240 },
  { name: "/ledger/entries", value: 184 },
  { name: "/notifications/send", value: 142 },
  { name: "/webhooks/dispatch", value: 110 },
  { name: "/users/profile", value: 68 },
  { name: "/auth/token", value: 52 },
];

export default function ApiPerfPage() {
  const latTrend = React.useMemo(() => timeSeries(13, 24, 84, 24).map((d, i) => ({
    timestamp: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  })), []);

  const columns: Column<EndpointPerf>[] = [
    {
      key: "path",
      header: "Endpoint",
      sortable: true,
      sortValue: (r) => r.path,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <span className="inline-flex items-center rounded-md border border-border px-1.5 py-0.5 text-[10px] font-mono font-semibold uppercase tracking-wider text-muted-foreground">
            {r.method}
          </span>
          <span className="text-xs font-mono truncate">{r.path}</span>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      hideOnMobile: true,
      cell: (r) => <span className="text-xs text-muted-foreground">{r.service}</span>,
    },
    {
      key: "latency",
      header: "p95 Latency",
      align: "right",
      sortable: true,
      sortValue: (r) => r.latency,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.latency > 200 ? "text-destructive" : r.latency > 100 ? "text-warning-foreground" : "text-success"}`}>{r.latency}ms</span>,
    },
    {
      key: "rps",
      header: "RPS",
      align: "right",
      sortable: true,
      sortValue: (r) => r.rps,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.rps.toLocaleString()}</span>,
    },
    {
      key: "errorRate",
      header: "Error Rate",
      align: "right",
      sortable: true,
      sortValue: (r) => r.errorRate,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.errorRate > 1 ? "text-destructive" : r.errorRate > 0.1 ? "text-warning-foreground" : "text-success"}`}>{r.errorRate.toFixed(2)}%</span>,
    },
    {
      key: "cacheHit",
      header: "Cache Hit",
      align: "right",
      sortable: true,
      sortValue: (r) => r.cacheHit,
      hideOnMobile: true,
      cell: (r) => <span className={`text-xs tabular-nums ${r.cacheHit > 80 ? "text-success" : r.cacheHit > 40 ? "text-warning-foreground" : "text-muted-foreground"}`}>{r.cacheHit}%</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="API Performance"
        description="End-to-end API latency, error distribution, and cache posture across all HTTP endpoints."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "API" }]}
        icon={<Network className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("OpenAPI spec exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export Spec</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Tracked Endpoints" value="142" hint="across 8 services" icon={<Network className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Avg Latency" value="84" unit="ms" delta={-6} deltaLabel="vs prev" icon={<Clock className="w-4 h-4" />} accent="success" sparkline={[98, 92, 88, 86, 84, 84, 84]} />
        <KpiCard label="Error Rate" value="0.62" unit="%" delta={0.14} deltaLabel="vs prev" icon={<AlertTriangle className="w-4 h-4" />} accent="warning" sparkline={[0.42, 0.48, 0.52, 0.58, 0.6, 0.62, 0.62]} />
        <KpiCard label="Cache Hit Ratio" value="78.4" unit="%" delta={4} deltaLabel="vs prev" icon={<Database className="w-4 h-4" />} accent="info" sparkline={[68, 70, 72, 74, 76, 78, 78.4]} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 h-[320px]">
          <SectionHeading title="Average API Latency" description="p95 latency across all endpoints, 24h window" />
          <div className="h-[240px] mt-2">
            <HorizontalBarChart data={latByEndpoint} color={2} />
          </div>
        </Card>
        <Card className="p-4 h-[320px]">
          <SectionHeading title="Status Code Distribution" description="24h request outcomes" />
          <div className="h-[240px] mt-2">
            <DonutChart data={statusDist} centerValue="95.4%" centerLabel="success rate" />
          </div>
        </Card>
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Top Endpoints by Latency" description="Slowest endpoints by p95 latency, with throughput, error, and cache stats." />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={endpoints}
            rowKey={(r) => r.id}
            searchKeys={["path", "service"]}
            searchPlaceholder="Search endpoints or services..."
            pageSize={8}
            initialSort={{ key: "latency", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
