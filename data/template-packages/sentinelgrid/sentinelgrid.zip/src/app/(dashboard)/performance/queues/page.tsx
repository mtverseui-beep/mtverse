"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { StatusDot } from "@/components/common/badges";
import { LineChartCard } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { ListOrdered, Activity, Clock, AlertTriangle, Download, Server, Zap } from "lucide-react";

interface KafkaTopic {
  id: string;
  name: string;
  partitions: number;
  consumers: number;
  lag: number;
  throughput: number;
  status: "healthy" | "warning" | "critical";
}

const topics: KafkaTopic[] = [
  { id: "t1", name: "checkout.events.v1", partitions: 12, consumers: 4, lag: 0, throughput: 1840, status: "healthy" },
  { id: "t2", name: "billing.events.v1", partitions: 8, consumers: 3, lag: 1240, throughput: 920, status: "warning" },
  { id: "t3", name: "user.activity.v2", partitions: 16, consumers: 6, lag: 0, throughput: 4200, status: "healthy" },
  { id: "t4", name: "payment.events.v1", partitions: 6, consumers: 2, lag: 8400, throughput: 680, status: "critical" },
  { id: "t5", name: "audit.log.v1", partitions: 4, consumers: 2, lag: 0, throughput: 320, status: "healthy" },
  { id: "t6", name: "webhook.deliveries.v1", partitions: 8, consumers: 4, lag: 320, throughput: 1240, status: "warning" },
  { id: "t7", name: "feature.flags.v1", partitions: 2, consumers: 8, lag: 0, throughput: 80, status: "healthy" },
  { id: "t8", name: "session.events.v1", partitions: 12, consumers: 3, lag: 0, throughput: 2200, status: "healthy" },
];

interface ConsumerGroup {
  id: string;
  group: string;
  topic: string;
  members: number;
  lag: number;
  rate: number;
  status: "active" | "idle" | "rebalancing" | "dead";
}

const groups: ConsumerGroup[] = [
  { id: "g1", group: "checkout-worker", topic: "checkout.events.v1", members: 4, lag: 0, rate: 1840, status: "active" },
  { id: "g2", group: "billing-ledger", topic: "billing.events.v1", members: 3, lag: 1240, rate: 920, status: "active" },
  { id: "g3", group: "analytics-ingest", topic: "user.activity.v2", members: 6, lag: 0, rate: 4200, status: "active" },
  { id: "g4", group: "payment-processor", topic: "payment.events.v1", members: 2, lag: 8400, rate: 680, status: "active" },
  { id: "g5", group: "audit-sink", topic: "audit.log.v1", members: 2, lag: 0, rate: 320, status: "active" },
  { id: "g6", group: "webhook-dispatcher", topic: "webhook.deliveries.v1", members: 4, lag: 320, rate: 1240, status: "active" },
  { id: "g7", group: "flag-relay", topic: "feature.flags.v1", members: 8, lag: 0, rate: 80, status: "idle" },
  { id: "g8", group: "session-store", topic: "session.events.v1", members: 3, lag: 0, rate: 2200, status: "active" },
];

const statusColorMap: Record<string, "success" | "warning" | "destructive" | "muted" | "primary"> = {
  healthy: "success",
  warning: "warning",
  critical: "destructive",
  active: "success",
  idle: "muted",
  rebalancing: "warning",
  dead: "destructive",
};

export default function QueuePerfPage() {
  const lagTrend = React.useMemo(() => timeSeries(17, 24, 2400, 1800).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  })), []);

  const totalLag = topics.reduce((s, t) => s + t.lag, 0);
  const totalThroughput = topics.reduce((s, t) => s + t.throughput, 0);
  const dlqCount = 14;

  const topicCols: Column<KafkaTopic>[] = [
    {
      key: "name",
      header: "Topic",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <StatusDot color={statusColorMap[r.status]} pulse={r.status === "critical"} />
          <code className="text-xs font-mono truncate">{r.name}</code>
        </div>
      ),
    },
    {
      key: "partitions",
      header: "Partitions",
      align: "right",
      sortable: true,
      sortValue: (r) => r.partitions,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.partitions}</span>,
    },
    {
      key: "consumers",
      header: "Consumers",
      align: "right",
      sortable: true,
      sortValue: (r) => r.consumers,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.consumers}</span>,
    },
    {
      key: "lag",
      header: "Lag",
      align: "right",
      sortable: true,
      sortValue: (r) => r.lag,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.lag > 5000 ? "text-destructive" : r.lag > 100 ? "text-warning-foreground" : "text-success"}`}>{r.lag.toLocaleString()}</span>,
    },
    {
      key: "throughput",
      header: "Throughput",
      align: "right",
      sortable: true,
      sortValue: (r) => r.throughput,
      cell: (r) => <span className="text-xs tabular-nums">{r.throughput.toLocaleString()} msg/s</span>,
    },
  ];

  const groupCols: Column<ConsumerGroup>[] = [
    {
      key: "group",
      header: "Consumer Group",
      sortable: true,
      sortValue: (r) => r.group,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <StatusDot color={statusColorMap[r.status]} />
          <code className="text-xs font-mono truncate">{r.group}</code>
        </div>
      ),
    },
    {
      key: "topic",
      header: "Topic",
      hideOnMobile: true,
      cell: (r) => <code className="text-[11px] font-mono text-muted-foreground truncate">{r.topic}</code>,
    },
    {
      key: "members",
      header: "Members",
      align: "right",
      sortable: true,
      sortValue: (r) => r.members,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.members}</span>,
    },
    {
      key: "rate",
      header: "Consume Rate",
      align: "right",
      sortable: true,
      sortValue: (r) => r.rate,
      cell: (r) => <span className="text-xs tabular-nums">{r.rate.toLocaleString()} msg/s</span>,
    },
    {
      key: "lag",
      header: "Lag",
      align: "right",
      sortable: true,
      sortValue: (r) => r.lag,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.lag > 5000 ? "text-destructive" : r.lag > 100 ? "text-warning-foreground" : "text-success"}`}>{r.lag.toLocaleString()}</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Queue Performance"
        description="Kafka topic throughput, consumer group lag, and dead-letter queue posture across the event bus."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "Queues" }]}
        icon={<ListOrdered className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Lag report exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Queue Depth" value={totalLag.toLocaleString()} unit="msgs" delta={-12} deltaLabel="vs 1h ago" icon={<Server className="w-4 h-4" />} accent="warning" sparkline={[3200, 2900, 2600, 2400, 2200, 2100, 1996]} />
        <KpiCard label="Messages / sec" value={totalThroughput.toLocaleString()} delta={6} deltaLabel="vs prev" icon={<Activity className="w-4 h-4" />} accent="primary" sparkline={[10200, 10800, 11200, 11600, 11800, 11900, 12080]} />
        <KpiCard label="Avg Processing Time" value="42" unit="ms" delta={-8} deltaLabel="vs prev" icon={<Clock className="w-4 h-4" />} accent="success" sparkline={[58, 54, 50, 46, 44, 43, 42]} />
        <KpiCard label="DLQ Count" value={dlqCount} delta={4} deltaLabel="vs prev day" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
      </div>

      <Card className="p-4 h-[320px]">
        <SectionHeading title="Consumer Lag Trend" description="Total unprocessed messages across all topics, 24h window" action={<span className="text-[11px] text-muted-foreground">Threshold 5,000</span>} />
        <div className="h-[240px] mt-2">
          <LineChartCard data={lagTrend} suffix=" msgs" />
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-4 md:p-5">
          <SectionHeading title="Kafka Topics" description="Topic-level throughput and lag." />
          <div className="mt-4">
            <DataTable
              columns={topicCols}
              data={topics}
              rowKey={(r) => r.id}
              searchKeys={["name"]}
              searchPlaceholder="Search topics..."
              pageSize={6}
              initialSort={{ key: "lag", dir: "desc" }}
            />
          </div>
        </Card>

        <Card className="p-4 md:p-5">
          <SectionHeading title="Consumer Groups" description="Group-level consume rate and lag." />
          <div className="mt-4">
            <DataTable
              columns={groupCols}
              data={groups}
              rowKey={(r) => r.id}
              searchKeys={["group", "topic"]}
              searchPlaceholder="Search groups..."
              pageSize={6}
              initialSort={{ key: "lag", dir: "desc" }}
            />
          </div>
        </Card>
      </div>

      <Card className="p-4 border-destructive/20 bg-destructive/5">
        <div className="flex items-start gap-3">
          <Zap className="w-4 h-4 text-destructive mt-0.5" />
          <div className="text-xs space-y-1">
            <p className="font-medium">Dead-letter queue summary</p>
            <p className="text-muted-foreground">
              14 messages across 3 topics in the last hour. <code className="font-mono">payment.events.v1</code> accounts for 11 of them — investigate the deserializer for malformed schema version 3 events.
            </p>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
