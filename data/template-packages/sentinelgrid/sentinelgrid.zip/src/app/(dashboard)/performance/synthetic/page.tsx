"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LineChartCard } from "@/components/charts";
import { StatusDot } from "@/components/common/badges";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { Radio, Plus, Activity, Globe, Clock, CheckCircle2, AlertTriangle, Download } from "lucide-react";

interface SyntheticCheck {
  id: string;
  name: string;
  url: string;
  location: string;
  frequency: string;
  status: "passing" | "failing" | "degraded";
  responseMs: number;
  availability24h: number;
  trend: number[];
  lastError?: string;
}

const checks: SyntheticCheck[] = [
  { id: "c1", name: "Homepage Load", url: "https://sentinelgrid.io/", location: "us-east-1", frequency: "1m", status: "passing", responseMs: 420, availability24h: 100, trend: [410, 415, 422, 418, 420, 425, 420] },
  { id: "c2", name: "Login Flow", url: "https://app.sentinelgrid.io/login", location: "us-east-1", frequency: "5m", status: "passing", responseMs: 680, availability24h: 99.96, trend: [640, 660, 670, 680, 685, 682, 680] },
  { id: "c3", name: "Checkout Critical Path", url: "https://app.sentinelgrid.io/checkout", location: "us-east-1", frequency: "1m", status: "degraded", responseMs: 1820, availability24h: 97.2, trend: [620, 680, 940, 1240, 1620, 1780, 1820], lastError: "Timeout on /api/v1/checkout/process" },
  { id: "c4", name: "API Health Ping", url: "https://api.sentinelgrid.io/health", location: "eu-west-1", frequency: "30s", status: "passing", responseMs: 42, availability24h: 100, trend: [38, 40, 42, 41, 42, 43, 42] },
  { id: "c5", name: "API Health Ping", url: "https://api.sentinelgrid.io/health", location: "ap-southeast-2", frequency: "30s", status: "passing", responseMs: 88, availability24h: 100, trend: [82, 84, 86, 88, 88, 87, 88] },
  { id: "c6", name: "Webhook Delivery Test", url: "https://api.sentinelgrid.io/webhooks/test", location: "us-east-1", frequency: "5m", status: "passing", responseMs: 240, availability24h: 99.92, trend: [220, 230, 240, 235, 240, 238, 240] },
  { id: "c7", name: "Signup Flow", url: "https://app.sentinelgrid.io/signup", location: "eu-west-1", frequency: "5m", status: "failing", responseMs: 0, availability24h: 84.4, trend: [680, 720, 880, 1240, 0, 0, 0], lastError: "HTTP 500 from /api/v1/users/create" },
  { id: "c8", name: "Public Status Page", url: "https://status.sentinelgrid.io/", location: "us-east-1", frequency: "1m", status: "passing", responseMs: 180, availability24h: 100, trend: [170, 175, 180, 178, 182, 180, 180] },
  { id: "c9", name: "Docs Search", url: "https://docs.sentinelgrid.io/search?q=alerts", location: "eu-west-1", frequency: "5m", status: "passing", responseMs: 320, availability24h: 99.88, trend: [300, 310, 320, 315, 320, 322, 320] },
  { id: "c10", name: "Billing Invoice PDF", url: "https://app.sentinelgrid.io/billing/invoice.pdf", location: "us-east-1", frequency: "10m", status: "degraded", responseMs: 2480, availability24h: 92.4, trend: [680, 920, 1240, 1820, 2200, 2400, 2480], lastError: "PDF render timeout > 2s" },
];

const statusColorMap: Record<string, "success" | "warning" | "destructive"> = {
  passing: "success",
  degraded: "warning",
  failing: "destructive",
};

export default function SyntheticPage() {
  const [selectedId, setSelectedId] = React.useState("c3");
  const selected = checks.find((c) => c.id === selectedId) ?? checks[0];

  const passing = checks.filter((c) => c.status === "passing").length;
  const degraded = checks.filter((c) => c.status === "degraded").length;
  const failing = checks.filter((c) => c.status === "failing").length;
  const avgResponse = Math.round(checks.filter((c) => c.responseMs > 0).reduce((s, c) => s + c.responseMs, 0) / checks.filter((c) => c.responseMs > 0).length);

  const trendData = React.useMemo(() => timeSeries(29, 24, 90, 4).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value * 10) / 10,
  })), []);

  const columns: Column<SyntheticCheck>[] = [
    {
      key: "name",
      header: "Check",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <StatusDot color={statusColorMap[r.status]} pulse={r.status !== "passing"} size="md" />
          <div className="min-w-0">
            <div className="text-xs font-medium truncate">{r.name}</div>
            <code className="text-[10px] font-mono text-muted-foreground truncate block max-w-[220px]">{r.url}</code>
          </div>
        </div>
      ),
    },
    {
      key: "location",
      header: "Location",
      hideOnMobile: true,
      cell: (r) => <span className="text-xs text-muted-foreground">{r.location}</span>,
    },
    {
      key: "frequency",
      header: "Frequency",
      align: "right",
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.frequency}</span>,
    },
    {
      key: "responseMs",
      header: "Response",
      align: "right",
      sortable: true,
      sortValue: (r) => r.responseMs,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.responseMs === 0 ? "text-destructive" : r.responseMs > 1000 ? "text-warning-foreground" : "text-success"}`}>
          {r.responseMs === 0 ? "—" : `${r.responseMs}ms`}
        </span>
      ),
    },
    {
      key: "availability24h",
      header: "24h Avail.",
      align: "right",
      sortable: true,
      sortValue: (r) => r.availability24h,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.availability24h >= 99.9 ? "text-success" : r.availability24h >= 95 ? "text-warning-foreground" : "text-destructive"}`}>
          {r.availability24h.toFixed(2)}%
        </span>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Synthetic Monitoring"
        description="Proactive checks simulating user journeys from global locations. Catch outages before real users do."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "Synthetic" }]}
        icon={<Radio className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Synthetic results exported")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening new check form")}>
              <Plus className="w-3.5 h-3.5" /> Add Check
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Checks" value={checks.length} hint="across 3 regions" icon={<Radio className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Passing" value={passing} hint={`${Math.round((passing / checks.length) * 100)}% of checks`} icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Degraded / Failing" value={degraded + failing} hint={`${degraded} degraded · ${failing} failing`} icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Avg Response" value={avgResponse} unit="ms" delta={-4} deltaLabel="vs 1h ago" icon={<Clock className="w-4 h-4" />} accent="info" />
      </div>

      {/* Selected check details */}
      <Card className={`p-5 border-${selected.status === "passing" ? "success" : selected.status === "degraded" ? "warning" : "destructive"}/20 bg-${selected.status === "passing" ? "success" : selected.status === "degraded" ? "warning" : "destructive"}/5`}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-3">
            <div className="flex items-center gap-2">
              <StatusDot color={statusColorMap[selected.status]} pulse={selected.status !== "passing"} size="md" />
              <span className="font-semibold text-sm">{selected.name}</span>
            </div>
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">URL</span>
                <code className="font-mono truncate max-w-[200px]">{selected.url}</code>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Location</span>
                <span>{selected.location}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Frequency</span>
                <span className="tabular-nums">{selected.frequency}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Last response</span>
                <span className={`tabular-nums font-medium ${selected.responseMs > 1000 ? "text-warning-foreground" : "text-success"}`}>
                  {selected.responseMs === 0 ? "—" : `${selected.responseMs}ms`}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">24h availability</span>
                <span className={`tabular-nums font-medium ${selected.availability24h >= 99.9 ? "text-success" : selected.availability24h >= 95 ? "text-warning-foreground" : "text-destructive"}`}>
                  {selected.availability24h.toFixed(2)}%
                </span>
              </div>
            </div>
            {selected.lastError && (
              <div className="rounded-md border border-destructive/30 bg-destructive/10 p-2 text-[11px] text-destructive font-mono">
                {selected.lastError}
              </div>
            )}
          </div>
          <div className="lg:col-span-2">
            <div className="text-xs text-muted-foreground mb-2">Response time trend (last 7 runs)</div>
            <div className="h-[140px] flex items-end gap-1">
              {selected.trend.map((v, i) => {
                const max = Math.max(...selected.trend, 1);
                const h = v === 0 ? 4 : Math.max(8, (v / max) * 100);
                const color = v === 0 ? "bg-destructive" : v > 1500 ? "bg-destructive" : v > 800 ? "bg-warning" : "bg-success";
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className={`w-full rounded-t ${color}`} style={{ height: `${h}%` }} />
                    <span className="text-[9px] text-muted-foreground tabular-nums">{i + 1}</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-2 flex items-center justify-between text-[10px] text-muted-foreground">
              <span>Run 1</span>
              <span>Run 7</span>
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-4 h-[260px]">
        <SectionHeading title="Fleet Availability Trend" description="Aggregate availability across all synthetic checks, 24h window" />
        <div className="h-[180px] mt-2">
          <LineChartCard data={trendData} suffix="%" />
        </div>
      </Card>

      <Card className="p-4 md:p-5">
        <SectionHeading title="All Synthetic Checks" description="Click a row to inspect trends and recent errors." />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={checks}
            rowKey={(r) => r.id}
            searchKeys={["name", "url", "location"]}
            searchPlaceholder="Search checks..."
            pageSize={8}
            initialSort={{ key: "availability24h", dir: "asc" }}
            onRowClick={(r) => { setSelectedId(r.id); toast.info(`Loaded check: ${r.name}`); }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
