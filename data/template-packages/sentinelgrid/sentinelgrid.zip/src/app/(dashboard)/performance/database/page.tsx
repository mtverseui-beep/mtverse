"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { DataTable, type Column } from "@/components/tables/data-table";
import { VolumeChart } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { Database, Clock, AlertTriangle, Link2, Download, Gauge } from "lucide-react";

interface SlowQuery {
  id: string;
  query: string;
  avgMs: number;
  maxMs: number;
  calls: number;
  totalTimeS: number;
}

const slowQueries: SlowQuery[] = [
  { id: "q1", query: "SELECT * FROM invoices WHERE org_id = $1 AND created_at > $2 ORDER BY created_at DESC", avgMs: 1240, maxMs: 3820, calls: 1840, totalTimeS: 2282 },
  { id: "q2", query: "SELECT u.*, s.* FROM users u LEFT JOIN sessions s ON s.user_id = u.id WHERE u.tenant_id = $1", avgMs: 820, maxMs: 2104, calls: 4280, totalTimeS: 3509 },
  { id: "q3", query: "SELECT COUNT(*) FROM events WHERE metadata->>'source' = $1 AND created_at > NOW() - INTERVAL '30 days'", avgMs: 642, maxMs: 1820, calls: 9200, totalTimeS: 5906 },
  { id: "q4", query: "UPDATE ledger_entries SET reconciled = true WHERE batch_id = $1 AND reconciled = false", avgMs: 480, maxMs: 1240, calls: 320, totalTimeS: 154 },
  { id: "q5", query: "SELECT order_id, SUM(amount) FROM payments WHERE status = 'completed' GROUP BY order_id HAVING SUM(amount) > $1", avgMs: 380, maxMs: 920, calls: 1840, totalTimeS: 699 },
  { id: "q6", query: "SELECT * FROM audit_log WHERE actor_id = $1 AND action LIKE '%delete%' ORDER BY timestamp DESC LIMIT 100", avgMs: 312, maxMs: 820, calls: 6800, totalTimeS: 2122 },
  { id: "q7", query: "INSERT INTO webhook_deliveries (url, payload) VALUES ($1, $2) RETURNING id", avgMs: 84, maxMs: 240, calls: 184000, totalTimeS: 15456 },
  { id: "q8", query: "SELECT tenant_id, COUNT(*) FROM api_keys WHERE expires_at > NOW() GROUP BY tenant_id", avgMs: 62, maxMs: 180, calls: 4200, totalTimeS: 260 },
];

const indexUsage = [
  { name: "invoices_org_created_idx", table: "invoices", scans: 184200, size: "248 MB", usage: 96 },
  { name: "users_tenant_id_idx", table: "users", scans: 142800, size: "82 MB", usage: 88 },
  { name: "events_metadata_gin", table: "events", scans: 92400, size: "1.2 GB", usage: 72 },
  { name: "payments_status_idx", table: "payments", scans: 64800, size: "156 MB", usage: 64 },
  { name: "ledger_entries_batch_idx", table: "ledger_entries", scans: 18200, size: "44 MB", usage: 42 },
  { name: "audit_log_actor_idx", table: "audit_log", scans: 12400, size: "92 MB", usage: 38 },
  { name: "webhook_deliveries_url_idx", table: "webhook_deliveries", scans: 2400, size: "12 MB", usage: 14 },
  { name: "api_keys_expires_idx", table: "api_keys", scans: 820, size: "2 MB", usage: 4 },
];

export default function DatabasePerfPage() {
  const throughput = React.useMemo(() => timeSeries(11, 24, 4200, 1800).map((d, i) => ({
    timestamp: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  })), []);

  const columns: Column<SlowQuery>[] = [
    {
      key: "query",
      header: "Query",
      sortable: true,
      sortValue: (r) => r.query,
      cell: (r) => <code className="text-[11px] font-mono text-muted-foreground line-clamp-2 block max-w-md">{r.query}</code>,
    },
    {
      key: "avgMs",
      header: "Avg ms",
      align: "right",
      sortable: true,
      sortValue: (r) => r.avgMs,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.avgMs > 500 ? "text-destructive" : r.avgMs > 200 ? "text-warning-foreground" : "text-success"}`}>{r.avgMs}</span>,
    },
    {
      key: "maxMs",
      header: "Max ms",
      align: "right",
      sortable: true,
      sortValue: (r) => r.maxMs,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.maxMs}</span>,
    },
    {
      key: "calls",
      header: "Calls (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.calls,
      cell: (r) => <span className="text-xs tabular-nums">{r.calls.toLocaleString()}</span>,
    },
    {
      key: "totalTimeS",
      header: "Total Time",
      align: "right",
      sortable: true,
      sortValue: (r) => r.totalTimeS,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.totalTimeS >= 3600 ? `${(r.totalTimeS / 3600).toFixed(1)}h` : `${Math.round(r.totalTimeS / 60)}m`}</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Database Performance"
        description="Query throughput, slow query analysis, connection pool saturation, and index utilization for PostgreSQL primary."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "Database" }]}
        icon={<Database className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Query plan exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Queries / sec" value="4,182" delta={8} deltaLabel="vs 1h ago" icon={<Gauge className="w-4 h-4" />} accent="primary" sparkline={[3800, 3950, 4100, 4020, 4200, 4180, 4182]} />
        <KpiCard label="Avg Query Time" value="4.2" unit="ms" delta={-12} deltaLabel="vs prev" icon={<Clock className="w-4 h-4" />} accent="success" sparkline={[5.2, 5.0, 4.8, 4.5, 4.4, 4.3, 4.2]} />
        <KpiCard label="Slow Queries (>200ms)" value="142" delta={18} deltaLabel="vs prev" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" sparkline={[80, 92, 104, 118, 128, 134, 142]} />
        <KpiCard label="Active Connections" value="84 / 100" delta={0} deltaLabel="of pool" icon={<Link2 className="w-4 h-4" />} accent="warning" />
      </div>

      <Card className="p-4 h-[320px]">
        <SectionHeading title="Query Throughput" description="Queries per second over the past 24 hours" />
        <div className="h-[240px] mt-2">
          <VolumeChart data={throughput} unit=" qps" />
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 md:p-5">
          <SectionHeading title="Slowest Queries" description="Ranked by average execution time over the last 24h." />
          <div className="mt-4">
            <DataTable
              columns={columns}
              data={slowQueries}
              rowKey={(r) => r.id}
              searchKeys={["query"]}
              searchPlaceholder="Search queries..."
              pageSize={6}
              initialSort={{ key: "avgMs", dir: "desc" }}
            />
          </div>
        </Card>

        {/* Connection pool */}
        <Card className="p-4 flex flex-col gap-4">
          <SectionHeading title="Connection Pool" description="PgBouncer pool utilization" />
          <div className="space-y-4">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Active</span>
                <span className="tabular-nums">84 / 100</span>
              </div>
              <Progress value={84} className="h-2" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Idle</span>
                <span className="tabular-nums">12 / 100</span>
              </div>
              <Progress value={12} className="h-2" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Waiting</span>
                <span className="tabular-nums">4</span>
              </div>
              <Progress value={4} className="h-2" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Max Lifetime (s)</span>
                <span className="tabular-nums">1800</span>
              </div>
              <Progress value={62} className="h-2" />
            </div>
          </div>
          <div className="pt-3 border-t border-border space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Pool mode</span>
              <span className="font-mono">transaction</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Avg wait time</span>
              <span className="tabular-nums">2.4ms</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Pool hits</span>
              <span className="tabular-nums">98.2%</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Index usage */}
      <Card className="p-4 md:p-5">
        <SectionHeading title="Index Usage Stats" description="Scans, size, and utilization per index (sorted by usage)." />
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
          {indexUsage.map((idx) => (
            <div key={idx.name} className="rounded-lg border border-border p-3 space-y-2">
              <div className="flex items-center justify-between gap-2 min-w-0">
                <code className="text-xs font-mono truncate">{idx.name}</code>
                <span className="text-[10px] text-muted-foreground shrink-0">{idx.size}</span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                <span>table: <code className="font-mono">{idx.table}</code></span>
                <span className="tabular-nums">{idx.scans.toLocaleString()} scans</span>
              </div>
              <Progress value={idx.usage} className="h-1.5" />
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
