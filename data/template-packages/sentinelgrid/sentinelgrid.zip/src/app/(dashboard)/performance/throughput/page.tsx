"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { DataTable, type Column } from "@/components/tables/data-table";
import { VolumeChart, DonutChart } from "@/components/charts";
import { services, timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { TrendingUp, Activity, Gauge, Database, Download, Zap } from "lucide-react";

interface EndpointTP {
  id: string;
  path: string;
  method: string;
  rps: number;
  peak: number;
  total: number;
  avgSize: number;
}

const endpoints: EndpointTP[] = [
  { id: "e1", path: "/api/v1/users/profile", method: "GET", rps: 12400, peak: 18200, total: 1070000000, avgSize: 2.4 },
  { id: "e2", path: "/api/v1/auth/token", method: "POST", rps: 8900, peak: 12400, total: 768000000, avgSize: 0.8 },
  { id: "e3", path: "/api/v1/sessions/refresh", method: "POST", rps: 6800, peak: 9100, total: 588000000, avgSize: 0.4 },
  { id: "e4", path: "/api/v1/cache/invalidate", method: "POST", rps: 2400, peak: 3200, total: 207000000, avgSize: 0.1 },
  { id: "e5", path: "/api/v1/webhooks/dispatch", method: "POST", rps: 1800, peak: 2400, total: 155000000, avgSize: 1.2 },
  { id: "e6", path: "/api/v1/notifications/send", method: "POST", rps: 980, peak: 1420, total: 84600000, avgSize: 3.6 },
  { id: "e7", path: "/api/v1/checkout/process", method: "POST", rps: 940, peak: 1680, total: 81200000, avgSize: 5.8 },
  { id: "e8", path: "/api/v1/subscriptions/update", method: "PATCH", rps: 320, peak: 580, total: 27600000, avgSize: 2.1 },
  { id: "e9", path: "/api/v1/ledger/entries", method: "POST", rps: 320, peak: 480, total: 27600000, avgSize: 4.4 },
  { id: "e10", path: "/api/v1/reports/generate", method: "GET", rps: 80, peak: 142, total: 6900000, avgSize: 18.6 },
];

const regionDist = [
  { name: "us-east-1", value: 18400 },
  { name: "eu-west-1", value: 11200 },
  { name: "ap-south-1", value: 6400 },
  { name: "us-west-2", value: 4200 },
  { name: "ap-southeast-2", value: 2400 },
  { name: "eu-central-1", value: 1800 },
];

export default function ThroughputExplorerPage() {
  const [serviceId, setServiceId] = React.useState("s1");

  const vol24 = React.useMemo(() => timeSeries(3, 24, 42000, 12000).map((d, i) => ({
    timestamp: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  })), []);

  const columns: Column<EndpointTP>[] = [
    {
      key: "path",
      header: "Endpoint",
      sortable: true,
      sortValue: (r) => r.path,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <span className="inline-flex items-center rounded-md border border-border px-1.5 py-0.5 text-[10px] font-mono font-semibold uppercase tracking-wider text-muted-foreground">
            {r.method}
          </span>
          <span className="text-xs font-mono truncate">{r.path}</span>
        </div>
      ),
    },
    {
      key: "rps",
      header: "RPS",
      align: "right",
      sortable: true,
      sortValue: (r) => r.rps,
      cell: (r) => <span className="text-xs tabular-nums font-medium">{r.rps.toLocaleString()}</span>,
    },
    {
      key: "peak",
      header: "Peak RPS",
      align: "right",
      sortable: true,
      sortValue: (r) => r.peak,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.peak.toLocaleString()}</span>,
    },
    {
      key: "total",
      header: "Total (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.total,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.total >= 1e9 ? `${(r.total / 1e9).toFixed(2)}B` : `${(r.total / 1e6).toFixed(0)}M`}</span>,
    },
    {
      key: "avgSize",
      header: "Avg Size",
      align: "right",
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.avgSize} KB</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Throughput Explorer"
        description="Request volume, peak rates, and regional distribution across all monitored endpoints."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "Throughput" }]}
        icon={<TrendingUp className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <Card className="p-4 flex flex-col sm:flex-row sm:items-center gap-3 sm:justify-between">
        <div className="flex items-center gap-3">
          <Label className="text-xs text-muted-foreground">Service</Label>
          <Select value={serviceId} onValueChange={setServiceId}>
            <SelectTrigger className="w-full sm:w-[280px] h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {services.map((s) => (
                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Zap className="w-3.5 h-3.5 text-primary" />
          Live · updated 2s ago
        </div>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Current RPS" value="42,580" delta={6} deltaLabel="vs 1h ago" icon={<TrendingUp className="w-4 h-4" />} accent="primary" sparkline={[38000, 39500, 41000, 40200, 42000, 41800, 42580]} />
        <KpiCard label="Peak RPS (24h)" value="61,240" delta={4} deltaLabel="vs prev day" icon={<Activity className="w-4 h-4" />} accent="warning" sparkline={[52000, 55000, 58000, 61240, 59000, 56000, 54000]} />
        <KpiCard label="Total Requests" value="3.68B" unit="24h" delta={8} deltaLabel="vs prev" icon={<Database className="w-4 h-4" />} accent="info" sparkline={[3.2, 3.3, 3.4, 3.5, 3.55, 3.6, 3.68]} />
        <KpiCard label="Avg Response Size" value="2.4" unit="KB" delta={-2} deltaLabel="vs prev" icon={<Gauge className="w-4 h-4" />} accent="success" sparkline={[2.6, 2.5, 2.5, 2.4, 2.4, 2.5, 2.4]} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 h-[360px]">
          <SectionHeading title="Request Volume" description="Requests per second over the past 24 hours" />
          <div className="h-[280px] mt-2">
            <VolumeChart data={vol24} unit=" rps" />
          </div>
        </Card>
        <Card className="p-4 h-[360px]">
          <SectionHeading title="Throughput by Region" description="Distribution across active regions" />
          <div className="h-[280px] mt-2">
            <DonutChart data={regionDist} centerValue="42.5K" centerLabel="rps total" />
          </div>
        </Card>
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Throughput by Endpoint" description="Per-endpoint request volume, peak, and average response size." />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={endpoints}
            rowKey={(r) => r.id}
            searchKeys={["path"]}
            searchPlaceholder="Search endpoints..."
            pageSize={8}
            initialSort={{ key: "rps", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
