"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LatencyChart } from "@/components/charts";
import { services, multiTimeSeries } from "@/lib/data";
import { toast } from "sonner";
import { Timer, Activity, Gauge, TrendingUp, ArrowUpRight, ArrowDownRight, Download } from "lucide-react";

interface EndpointLatency {
  id: string;
  path: string;
  method: string;
  p50: number;
  p95: number;
  p99: number;
  avg: number;
  calls: number;
  trend: number;
}

const endpoints: EndpointLatency[] = [
  { id: "e1", path: "/api/v1/checkout/process", method: "POST", p50: 142, p95: 312, p99: 890, avg: 188, calls: 94000, trend: 18 },
  { id: "e2", path: "/api/v1/invoices/generate", method: "POST", p50: 88, p95: 240, p99: 612, avg: 142, calls: 32000, trend: 4 },
  { id: "e3", path: "/api/v1/reports/generate", method: "GET", p50: 220, p95: 580, p99: 1240, avg: 320, calls: 8000, trend: 22 },
  { id: "e4", path: "/api/v1/users/profile", method: "GET", p50: 22, p95: 68, p99: 142, avg: 34, calls: 1240000, trend: -8 },
  { id: "e5", path: "/api/v1/auth/token", method: "POST", p50: 18, p95: 52, p99: 98, avg: 28, calls: 890000, trend: -3 },
  { id: "e6", path: "/api/v1/ledger/entries", method: "POST", p50: 64, p95: 184, p99: 412, avg: 102, calls: 32000, trend: 12 },
  { id: "e7", path: "/api/v1/webhooks/dispatch", method: "POST", p50: 38, p95: 110, p99: 268, avg: 64, calls: 180000, trend: 6 },
  { id: "e8", path: "/api/v1/notifications/send", method: "POST", p50: 48, p95: 142, p99: 312, avg: 82, calls: 98000, trend: 9 },
  { id: "e9", path: "/api/v1/payments/refund", method: "POST", p50: 102, p95: 280, p99: 720, avg: 168, calls: 12000, trend: 14 },
  { id: "e10", path: "/api/v1/subscriptions/update", method: "PATCH", p50: 58, p95: 168, p99: 384, avg: 92, calls: 24000, trend: -5 },
];

// Histogram buckets
const histogram = [
  { bucket: "0-25ms", count: 4820 },
  { bucket: "25-50ms", count: 6240 },
  { bucket: "50-100ms", count: 5120 },
  { bucket: "100-200ms", count: 3180 },
  { bucket: "200-400ms", count: 1840 },
  { bucket: "400-800ms", count: 920 },
  { bucket: "800ms-1.5s", count: 312 },
  { bucket: "1.5s-3s", count: 88 },
  { bucket: "3s+", count: 24 },
];
const histMax = Math.max(...histogram.map((h) => h.count));

export default function LatencyExplorerPage() {
  const [serviceId, setServiceId] = React.useState("s1");
  const [compare, setCompare] = React.useState(false);

  const lat24 = React.useMemo(() => multiTimeSeries(2, 24, [
    { name: "p50", base: 35, variance: 8 },
    { name: "p95", base: 120, variance: 30 },
    { name: "p99", base: 280, variance: 60 },
  ]).map((d, i) => ({
    timestamp: `${String(i).padStart(2, "0")}:00`,
    p50: Math.round(Number(d.p50)),
    p95: Math.round(Number(d.p95)),
    p99: Math.round(Number(d.p99)),
  })), []);

  const columns: Column<EndpointLatency>[] = [
    {
      key: "path",
      header: "Endpoint",
      sortable: true,
      sortValue: (r) => r.path,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <span className="inline-flex items-center rounded-md border border-border px-1.5 py-0.5 text-[10px] font-mono font-semibold uppercase tracking-wider text-muted-foreground">
            {r.method}
          </span>
          <span className="text-xs font-mono truncate">{r.path}</span>
        </div>
      ),
    },
    {
      key: "p50",
      header: "p50",
      align: "right",
      sortable: true,
      sortValue: (r) => r.p50,
      cell: (r) => <span className="text-xs tabular-nums font-medium">{r.p50}ms</span>,
    },
    {
      key: "p95",
      header: "p95",
      align: "right",
      sortable: true,
      sortValue: (r) => r.p95,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.p95 > 200 ? "text-destructive" : r.p95 > 100 ? "text-warning-foreground" : "text-success"}`}>
          {r.p95}ms
        </span>
      ),
    },
    {
      key: "p99",
      header: "p99",
      align: "right",
      sortable: true,
      sortValue: (r) => r.p99,
      cell: (r) => (
        <span className={`text-xs tabular-nums font-medium ${r.p99 > 500 ? "text-destructive" : r.p99 > 200 ? "text-warning-foreground" : "text-success"}`}>
          {r.p99}ms
        </span>
      ),
    },
    {
      key: "avg",
      header: "Avg",
      align: "right",
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.avg}ms</span>,
    },
    {
      key: "calls",
      header: "Calls",
      align: "right",
      sortable: true,
      sortValue: (r) => r.calls,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.calls.toLocaleString()}</span>,
    },
    {
      key: "trend",
      header: "Trend",
      align: "right",
      sortable: true,
      sortValue: (r) => r.trend,
      cell: (r) => (
        <span className={`inline-flex items-center gap-0.5 text-xs tabular-nums ${r.trend > 5 ? "text-destructive" : r.trend < -5 ? "text-success" : "text-muted-foreground"}`}>
          {r.trend > 0 ? <ArrowUpRight className="w-3 h-3" /> : r.trend < 0 ? <ArrowDownRight className="w-3 h-3" /> : null}
          {r.trend > 0 ? "+" : ""}{r.trend}%
        </span>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Latency Explorer"
        description="Drill into request latency percentiles across services and endpoints. Compare current period against the previous window."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "Latency" }]}
        icon={<Timer className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
              <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" onClick={() => toast.success("Latency SLO saved")}>Save View</Button>
          </>
        }
      />

      {/* Service selector + compare toggle */}
      <Card className="p-4 flex flex-col md:flex-row md:items-center gap-4 md:justify-between">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 flex-1">
          <Label className="text-xs text-muted-foreground">Service</Label>
          <Select value={serviceId} onValueChange={setServiceId}>
            <SelectTrigger className="w-full sm:w-[280px] h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {services.map((s) => (
                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-3">
          <Switch id="compare" checked={compare} onCheckedChange={setCompare} />
          <Label htmlFor="compare" className="text-xs cursor-pointer">Compare previous period</Label>
        </div>
      </Card>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <KpiCard label="p50 Latency" value="35" unit="ms" delta={-8} deltaLabel="vs prev" icon={<Gauge className="w-4 h-4" />} accent="success" sparkline={[42, 40, 38, 36, 35, 34, 35]} />
        <KpiCard label="p95 Latency" value="124" unit="ms" delta={4} deltaLabel="vs prev" icon={<Timer className="w-4 h-4" />} accent="warning" sparkline={[110, 118, 122, 120, 124, 126, 124]} />
        <KpiCard label="p99 Latency" value="282" unit="ms" delta={12} deltaLabel="vs prev" icon={<Activity className="w-4 h-4" />} accent="destructive" sparkline={[240, 260, 270, 280, 282, 290, 282]} />
        <KpiCard label="Average" value="48" unit="ms" delta={-3} deltaLabel="vs prev" icon={<TrendingUp className="w-4 h-4" />} accent="info" sparkline={[52, 50, 49, 48, 47, 48, 48]} />
        <KpiCard label="Max Today" value="1,842" unit="ms" delta={32} deltaLabel="vs prev" icon={<ArrowUpRight className="w-4 h-4" />} accent="destructive" sparkline={[1400, 1620, 1700, 1750, 1820, 1842, 1700]} />
      </div>

      {/* Latency chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 h-[360px]">
          <SectionHeading
            title="Latency Percentiles"
            description="p50, p95, p99 over the past 24 hours"
            action={<span className="text-[11px] text-muted-foreground">24h window</span>}
          />
          <div className="h-[280px] mt-2">
            <LatencyChart data={lat24} />
          </div>
        </Card>

        {/* Histogram */}
        <Card className="p-4 h-[360px] flex flex-col">
          <SectionHeading
            title="Latency Distribution"
            description="Request count by latency bucket"
          />
          <div className="mt-4 flex-1 overflow-y-auto max-h-[260px] space-y-2 pr-2">
            {histogram.map((h) => (
              <div key={h.bucket} className="space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-mono text-muted-foreground">{h.bucket}</span>
                  <span className="tabular-nums font-medium">{h.count.toLocaleString()}</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{ width: `${(h.count / histMax) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {compare && (
        <Card className="p-4 border-warning/30 bg-warning/5">
          <div className="flex items-start gap-3">
            <Activity className="w-4 h-4 text-warning mt-0.5" />
            <div className="text-xs space-y-1">
              <p className="font-medium">Period comparison active</p>
              <p className="text-muted-foreground">
                Previous 24h baseline: p50 38ms, p95 119ms, p99 252ms. Current period shows p99 regression of +12%.
                Largest contributor: <code className="font-mono">/api/v1/reports/generate</code> (+22%).
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Endpoint table */}
      <Card className="p-4 md:p-5">
        <SectionHeading
          title="Latency by Endpoint"
          description="Per-endpoint percentile latency, call volume, and 24h change."
        />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={endpoints}
            rowKey={(r) => r.id}
            searchKeys={["path"]}
            searchPlaceholder="Search endpoints..."
            pageSize={8}
            initialSort={{ key: "p99", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
