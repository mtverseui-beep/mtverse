"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LineChartCard, DonutChart } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { Cloud, Download, Activity, Server, Globe, Zap } from "lucide-react";

interface TopUrl {
  id: string;
  url: string;
  requests: number;
  cacheHit: number;
  bandwidth: number;
  avgTtfb: number;
}

const topUrls: TopUrl[] = [
  { id: "u1", url: "/static/js/main.[hash].js", requests: 18400000, cacheHit: 98.4, bandwidth: 412, avgTtfb: 12 },
  { id: "u2", url: "/static/css/app.[hash].css", requests: 16400000, cacheHit: 98.8, bandwidth: 88, avgTtfb: 8 },
  { id: "u3", url: "/_next/image?url=%2Flogos%2Fhero.png", requests: 8200000, cacheHit: 94.2, bandwidth: 1240, avgTtfb: 22 },
  { id: "u4", url: "/static/fonts/inter-var.woff2", requests: 6400000, cacheHit: 99.2, bandwidth: 184, avgTtfb: 6 },
  { id: "u5", url: "/api/v1/dashboard/snapshot", requests: 2400000, cacheHit: 72.4, bandwidth: 6.4, avgTtfb: 142 },
  { id: "u6", url: "/_next/image?url=%2Fproducts%2Fbanner.jpg", requests: 1840000, cacheHit: 91.8, bandwidth: 820, avgTtfb: 18 },
  { id: "u7", url: "/static/js/vendor.[hash].js", requests: 1620000, cacheHit: 97.2, bandwidth: 280, avgTtfb: 11 },
  { id: "u8", url: "/static/media/illustration.svg", requests: 1240000, cacheHit: 95.8, bandwidth: 48, avgTtfb: 9 },
];

const edgeDist = [
  { name: "IAD (us-east)", value: 8400 },
  { name: "SFO (us-west)", value: 4200 },
  { name: "LHR (eu-west)", value: 5200 },
  { name: "FRA (eu-central)", value: 1800 },
  { name: "BOM (ap-south)", value: 2400 },
  { name: "SYD (ap-southeast)", value: 980 },
];

export default function CdnPerfPage() {
  const hitTrend = React.useMemo(() => timeSeries(23, 24, 92, 4).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Number(d.value.toFixed(1)),
  })), []);

  const columns: Column<TopUrl>[] = [
    {
      key: "url",
      header: "URL",
      sortable: true,
      sortValue: (r) => r.url,
      cell: (r) => <code className="text-xs font-mono truncate block max-w-sm">{r.url}</code>,
    },
    {
      key: "requests",
      header: "Requests (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.requests,
      cell: (r) => <span className="text-xs tabular-nums font-medium">{r.requests >= 1e6 ? `${(r.requests / 1e6).toFixed(1)}M` : `${(r.requests / 1e3).toFixed(0)}K`}</span>,
    },
    {
      key: "cacheHit",
      header: "Cache Hit",
      align: "right",
      sortable: true,
      sortValue: (r) => r.cacheHit,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.cacheHit > 95 ? "text-success" : r.cacheHit > 80 ? "text-warning-foreground" : "text-destructive"}`}>{r.cacheHit.toFixed(1)}%</span>,
    },
    {
      key: "bandwidth",
      header: "Bandwidth",
      align: "right",
      sortable: true,
      sortValue: (r) => r.bandwidth,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums">{r.bandwidth >= 1000 ? `${(r.bandwidth / 1000).toFixed(2)} GB/s` : `${r.bandwidth} MB/s`}</span>,
    },
    {
      key: "avgTtfb",
      header: "Edge TTFB",
      align: "right",
      sortable: true,
      sortValue: (r) => r.avgTtfb,
      hideOnMobile: true,
      cell: (r) => <span className={`text-xs tabular-nums ${r.avgTtfb > 100 ? "text-warning-foreground" : "text-success"}`}>{r.avgTtfb}ms</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="CDN Performance"
        description="Edge cache hit ratio, bandwidth, top-requested URLs, and edge location distribution across the global CDN."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "CDN" }]}
        icon={<Cloud className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("CDN access logs exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export Logs</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Cache Hit Rate" value="93.8" unit="%" delta={2.4} deltaLabel="vs prev" icon={<Zap className="w-4 h-4" />} accent="success" sparkline={[89, 90, 91, 92, 93, 94, 93.8]} />
        <KpiCard label="Bandwidth (24h)" value="184" unit="TB" delta={8} deltaLabel="vs prev" icon={<Activity className="w-4 h-4" />} accent="primary" sparkline={[160, 165, 170, 175, 180, 182, 184]} />
        <KpiCard label="Total Requests" value="142M" delta={12} deltaLabel="vs prev day" icon={<Globe className="w-4 h-4" />} accent="info" />
        <KpiCard label="Origin Fetches" value="8.8M" delta={-6} deltaLabel="6.2% of reqs" icon={<Server className="w-4 h-4" />} accent="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 h-[320px]">
          <SectionHeading title="Cache Hit Trend" description="Edge cache hit ratio over the past 24 hours" action={<span className="text-[11px] text-muted-foreground">Target ≥ 90%</span>} />
          <div className="h-[240px] mt-2">
            <LineChartCard data={hitTrend} suffix="%" />
          </div>
        </Card>
        <Card className="p-4 h-[320px]">
          <SectionHeading title="Edge Locations" description="Requests served by POP" />
          <div className="h-[240px] mt-2">
            <DonutChart data={edgeDist} centerValue="23.4K" centerLabel="rps" />
          </div>
        </Card>
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Top URLs by Requests" description="Most-requested assets in the last 24 hours, with cache hit and bandwidth." />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={topUrls}
            rowKey={(r) => r.id}
            searchKeys={["url"]}
            searchPlaceholder="Search URLs..."
            pageSize={8}
            initialSort={{ key: "requests", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
