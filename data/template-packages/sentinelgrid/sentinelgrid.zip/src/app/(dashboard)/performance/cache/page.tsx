"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { DataTable, type Column } from "@/components/tables/data-table";
import { LineChartCard } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { HardDrive, Clock, Trash2, MemoryStick, Download, Zap } from "lucide-react";

interface CacheKey {
  id: string;
  key: string;
  type: string;
  size: number;
  ttl: number;
  hits: number;
  misses: number;
  lastAccess: string;
}

const keys: CacheKey[] = [
  { id: "k1", key: "user:profile:{u1}", type: "hash", size: 8.4, ttl: 3600, hits: 184200, misses: 1820, lastAccess: "2s ago" },
  { id: "k2", key: "session:{sid}", type: "string", size: 1.2, ttl: 1800, hits: 412800, misses: 2400, lastAccess: "1s ago" },
  { id: "k3", key: "rate-limit:{ip}", type: "sorted-set", size: 0.4, ttl: 60, hits: 924000, misses: 0, lastAccess: "0s ago" },
  { id: "k4", key: "feature-flags:v2", type: "hash", size: 24.6, ttl: 300, hits: 64800, misses: 320, lastAccess: "5s ago" },
  { id: "k5", key: "invoice:pdf:{inv_id}", type: "string", size: 142.8, ttl: 86400, hits: 8400, misses: 1240, lastAccess: "12s ago" },
  { id: "k6", key: "search:results:{q}", type: "list", size: 38.2, ttl: 120, hits: 18400, misses: 4200, lastAccess: "8s ago" },
  { id: "k7", key: "config:checkout", type: "hash", size: 4.2, ttl: 600, hits: 142800, misses: 80, lastAccess: "3s ago" },
  { id: "k8", key: "merchant:rules:{m_id}", type: "hash", size: 18.4, ttl: 3600, hits: 38400, misses: 420, lastAccess: "18s ago" },
  { id: "k9", key: "price:catalog:v3", type: "hash", size: 82.4, ttl: 600, hits: 92400, misses: 1240, lastAccess: "1s ago" },
  { id: "k10", key: "auth:jwks:keys", type: "set", size: 2.8, ttl: 600, hits: 8200, misses: 12, lastAccess: "0s ago" },
];

export default function CachePerfPage() {
  const hitTrend = React.useMemo(() => timeSeries(19, 24, 92, 6).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Number(d.value.toFixed(1)),
  })), []);

  const columns: Column<CacheKey>[] = [
    {
      key: "key",
      header: "Key Pattern",
      sortable: true,
      sortValue: (r) => r.key,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <span className="inline-flex items-center rounded border border-border px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground uppercase">{r.type}</span>
          <code className="text-xs font-mono truncate">{r.key}</code>
        </div>
      ),
    },
    {
      key: "size",
      header: "Size",
      align: "right",
      sortable: true,
      sortValue: (r) => r.size,
      cell: (r) => <span className={`text-xs tabular-nums font-medium ${r.size > 50 ? "text-warning-foreground" : "text-muted-foreground"}`}>{r.size} KB</span>,
    },
    {
      key: "ttl",
      header: "TTL",
      align: "right",
      sortable: true,
      sortValue: (r) => r.ttl,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-muted-foreground">{r.ttl >= 3600 ? `${Math.round(r.ttl / 3600)}h` : `${Math.round(r.ttl / 60)}m`}</span>,
    },
    {
      key: "hits",
      header: "Hits (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.hits,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-success">{r.hits.toLocaleString()}</span>,
    },
    {
      key: "misses",
      header: "Misses (24h)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.misses,
      hideOnMobile: true,
      cell: (r) => <span className="text-xs tabular-nums text-warning-foreground">{r.misses.toLocaleString()}</span>,
    },
    {
      key: "hitRate",
      header: "Hit Rate",
      align: "right",
      cell: (r) => {
        const rate = r.hits + r.misses > 0 ? Math.round((r.hits / (r.hits + r.misses)) * 100) : 0;
        return <span className={`text-xs tabular-nums font-medium ${rate > 90 ? "text-success" : rate > 75 ? "text-warning-foreground" : "text-destructive"}`}>{rate}%</span>;
      },
    },
    {
      key: "lastAccess",
      header: "Last Access",
      align: "right",
      hideOnMobile: true,
      cell: (r) => <span className="text-xs text-muted-foreground">{r.lastAccess}</span>,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Cache Performance"
        description="Redis cluster hit ratio, eviction policy, key-level stats, and memory pressure across all shards."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "Cache" }]}
        icon={<HardDrive className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Cache key report exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Hit Ratio" value="94.2" unit="%" delta={1.8} deltaLabel="vs prev" icon={<Zap className="w-4 h-4" />} accent="success" sparkline={[90, 91, 92, 93, 94, 94, 94.2]} />
        <KpiCard label="Avg GET Time" value="0.8" unit="ms" delta={-12} deltaLabel="vs prev" icon={<Clock className="w-4 h-4" />} accent="primary" sparkline={[1.2, 1.1, 1.0, 0.9, 0.85, 0.82, 0.8]} />
        <KpiCard label="Evictions (24h)" value="2,840" delta={18} deltaLabel="vs prev" icon={<Trash2 className="w-4 h-4" />} accent="warning" sparkline={[1800, 2100, 2400, 2600, 2700, 2800, 2840]} />
        <KpiCard label="Memory Usage" value="3.8 / 6.0" unit="GB" delta={4} deltaLabel="of maxmemory" icon={<MemoryStick className="w-4 h-4" />} accent="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 h-[320px]">
          <SectionHeading title="Hit Ratio Trend" description="Cluster-wide hit ratio over the past 24 hours" action={<span className="text-[11px] text-muted-foreground">Target ≥ 90%</span>} />
          <div className="h-[240px] mt-2">
            <LineChartCard data={hitTrend} suffix="%" />
          </div>
        </Card>

        <Card className="p-4 flex flex-col gap-4">
          <SectionHeading title="Eviction Policy" description="maxmemory-policy: allkeys-lru" />
          <div className="space-y-3 flex-1">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Used memory</span>
                <span className="tabular-nums">3.8 GB / 6.0 GB</span>
              </div>
              <Progress value={63} className="h-2" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Fragmentation ratio</span>
                <span className="tabular-nums">1.12</span>
              </div>
              <Progress value={56} className="h-2" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Keys tracked</span>
                <span className="tabular-nums">8.42M</span>
              </div>
              <Progress value={72} className="h-2" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium">Expires set</span>
                <span className="tabular-nums">98.4%</span>
              </div>
              <Progress value={98} className="h-2" />
            </div>
          </div>
          <div className="pt-3 border-t border-border text-[11px] text-muted-foreground space-y-1">
            <div className="flex items-center justify-between"><span>Shards</span><span className="font-mono">6</span></div>
            <div className="flex items-center justify-between"><span>Replicas</span><span className="font-mono">6</span></div>
            <div className="flex items-center justify-between"><span>Evictions (1h)</span><span className="tabular-nums">142</span></div>
          </div>
        </Card>
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Top Cache Keys by Size" description="Largest keys with hit/miss counts and access recency." />
        <div className="mt-4">
          <DataTable
            columns={columns}
            data={keys}
            rowKey={(r) => r.id}
            searchKeys={["key"]}
            searchPlaceholder="Search key patterns..."
            pageSize={8}
            initialSort={{ key: "size", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
