"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { LineChartCard, HorizontalBarChart } from "@/components/charts";
import { services, timeSeries } from "@/lib/data";
import { toast } from "sonner";
import { Gauge, Smile, Meh, Frown, Target, Info, Download } from "lucide-react";

const apdexByService = services
  .map((s) => ({
    name: s.name,
    value: Math.max(0.62, Math.min(0.99, s.healthScore / 100 - (s.errorRate > 1 ? 0.18 : 0) - (s.p95LatencyMs > 200 ? 0.12 : 0))),
  }))
  .sort((a, b) => b.value - a.value)
  .slice(0, 8);

export default function ApdexPage() {
  const apdexTrend = React.useMemo(() => timeSeries(5, 30, 0.92, 0.04).map((d) => ({
    date: d.date,
    value: Number(d.value.toFixed(3)),
  })), []);

  const score = 0.92;
  const satisfied = 84;
  const tolerating = 12;
  const frustrated = 4;

  return (
    <PageContainer>
      <PageHeader
        title="Apdex Dashboard"
        description="Application Performance Index — a single score quantifying user satisfaction based on response time thresholds."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Performance", href: "/dashboard/performance" }, { label: "Apdex" }]}
        icon={<Gauge className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Export started")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <KpiCard label="Apdex Score" value={score.toFixed(2)} unit="/ 1.0" delta={2} deltaLabel="vs prev" icon={<Gauge className="w-4 h-4" />} accent="success" sparkline={[0.88, 0.89, 0.91, 0.9, 0.92, 0.91, 0.92]} />
        <KpiCard label="Satisfied" value={satisfied} unit="%" delta={4} deltaLabel="vs prev" icon={<Smile className="w-4 h-4" />} accent="success" />
        <KpiCard label="Tolerating" value={tolerating} unit="%" delta={-2} deltaLabel="vs prev" icon={<Meh className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Frustrated" value={frustrated} unit="%" delta={-2} deltaLabel="vs prev" icon={<Frown className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Target" value="0.94" hint="T: 100ms · F: 500ms" icon={<Target className="w-4 h-4" />} accent="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4 h-[360px]">
          <SectionHeading title="Apdex Trend" description="Daily Apdex score over the past 30 days" action={<span className="text-[11px] text-muted-foreground">Target 0.94</span>} />
          <div className="h-[280px] mt-2">
            <LineChartCard data={apdexTrend} suffix="" />
          </div>
        </Card>

        {/* Apdex breakdown */}
        <Card className="p-4 h-[360px] flex flex-col">
          <SectionHeading title="Satisfaction Breakdown" description="Last 24 hours" />
          <div className="mt-4 space-y-4 flex-1">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <Smile className="w-3.5 h-3.5 text-success" />
                  <span className="font-medium">Satisfied</span>
                  <span className="text-muted-foreground">&lt; 100ms</span>
                </div>
                <span className="tabular-nums font-semibold">{satisfied}%</span>
              </div>
              <Progress value={satisfied} className="h-2 bg-muted" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <Meh className="w-3.5 h-3.5 text-warning" />
                  <span className="font-medium">Tolerating</span>
                  <span className="text-muted-foreground">100-500ms</span>
                </div>
                <span className="tabular-nums font-semibold">{tolerating}%</span>
              </div>
              <Progress value={tolerating} className="h-2 bg-muted" />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <Frown className="w-3.5 h-3.5 text-destructive" />
                  <span className="font-medium">Frustrated</span>
                  <span className="text-muted-foreground">&gt; 500ms</span>
                </div>
                <span className="tabular-nums font-semibold">{frustrated}%</span>
              </div>
              <Progress value={frustrated} className="h-2 bg-muted" />
            </div>
          </div>
          <div className="pt-3 border-t border-border">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Total samples (24h)</span>
              <span className="tabular-nums font-medium">3,682,140</span>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-4 h-[320px]">
        <SectionHeading title="Apdex by Service" description="Score (0-1) per service over the past 24 hours" />
        <div className="h-[240px] mt-2">
          <HorizontalBarChart data={apdexByService} />
        </div>
      </Card>

      {/* Explanation card */}
      <Card className="p-5 border-primary/20 bg-primary/5">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center text-primary shrink-0">
            <Info className="w-4 h-4" />
          </div>
          <div className="space-y-2 text-sm min-w-0">
            <h3 className="font-semibold">How Apdex is calculated</h3>
            <p className="text-muted-foreground text-xs leading-relaxed">
              Apdex (Application Performance Index) is an open standard for measuring user satisfaction. Each request is bucketed by response time:
              <strong className="text-success"> Satisfied</strong> responses complete within the target threshold <code className="font-mono text-[11px]">T</code> (100ms);
              <strong className="text-warning-foreground"> Tolerating</strong> responses complete within <code className="font-mono text-[11px]">4T</code> (400ms);
              <strong className="text-destructive"> Frustrated</strong> responses exceed <code className="font-mono text-[11px]">4T</code> or fail.
            </p>
            <p className="text-muted-foreground text-xs">
              The score is computed as <code className="font-mono text-[11px] bg-muted px-1.5 py-0.5 rounded">(Satisfied + Tolerating/2) / Total</code> and ranges from 0 (all users frustrated) to 1 (all users satisfied). A score of 0.92 indicates 92% of users had a satisfactory experience.
            </p>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
