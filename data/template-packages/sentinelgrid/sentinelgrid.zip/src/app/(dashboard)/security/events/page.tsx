"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  ShieldAlert, AlertOctagon, Ban, Activity, Zap, Lock,
  Download, RefreshCw, ChevronRight, Globe, ShieldX,
} from "lucide-react";
import { auditEvents, people } from "@/lib/data";
import { timeSeries } from "@/lib/data";
import { LineChartCard, DonutChart } from "@/components/charts";
import { SeverityBadge } from "@/components/common/badges";
import { toast } from "sonner";

interface SecurityEvent {
  id: string;
  timestamp: string;
  type: string;
  severity: "critical" | "high" | "medium" | "low";
  actor: string;
  resource: string;
  ip: string;
  result: "success" | "failure";
}

// Mock security events derived from audit events + generated
const mockEvents: SecurityEvent[] = [
  { id: "se1", timestamp: "2026-07-02T05:48:00Z", type: "failed_login", severity: "medium", actor: "unknown@external", resource: "auth-service", ip: "203.0.113.42", result: "failure" },
  { id: "se2", timestamp: "2026-07-02T05:22:00Z", type: "privilege_escalation", severity: "critical", actor: "u6", resource: "authz-engine", ip: "10.42.18.92", result: "success" },
  { id: "se3", timestamp: "2026-07-02T04:55:00Z", type: "api_key_used", severity: "low", actor: "system", resource: "api-gateway", ip: "10.42.18.14", result: "success" },
  { id: "se4", timestamp: "2026-07-02T03:20:00Z", type: "config_change", severity: "high", actor: "u3", resource: "vault", ip: "10.42.18.31", result: "success" },
  { id: "se5", timestamp: "2026-07-01T22:45:00Z", type: "mfa_bypass_attempt", severity: "critical", actor: "unknown@external", resource: "auth-service", ip: "198.51.100.7", result: "failure" },
  { id: "se6", timestamp: "2026-07-01T20:18:00Z", type: "rate_limit_breach", severity: "medium", actor: "client_x8f3", resource: "api-gateway", ip: "203.0.113.99", result: "failure" },
  { id: "se7", timestamp: "2026-07-01T18:20:00Z", type: "secret_access", severity: "low", actor: "u16", resource: "vault", ip: "10.42.18.81", result: "success" },
  { id: "se8", timestamp: "2026-07-01T14:18:00Z", type: "policy_violation", severity: "high", actor: "u4", resource: "authz-engine", ip: "10.42.18.42", result: "failure" },
  { id: "se9", timestamp: "2026-07-01T13:58:00Z", type: "deployment_blocked", severity: "medium", actor: "u16", resource: "web-app", ip: "10.42.18.81", result: "failure" },
  { id: "se10", timestamp: "2026-07-01T08:32:00Z", type: "audit_export", severity: "low", actor: "u15", resource: "audit-log", ip: "10.42.18.65", result: "success" },
  { id: "se11", timestamp: "2026-06-30T22:10:00Z", type: "suspicious_login", severity: "high", actor: "u7", resource: "auth-service", ip: "203.0.113.123", result: "failure" },
  { id: "se12", timestamp: "2026-06-30T15:45:00Z", type: "firewall_change", severity: "high", actor: "u2", resource: "edge", ip: "10.42.18.14", result: "success" },
];

const typeOptions = [
  { label: "Failed Login", value: "failed_login" },
  { label: "Privilege Escalation", value: "privilege_escalation" },
  { label: "MFA Bypass Attempt", value: "mfa_bypass_attempt" },
  { label: "Policy Violation", value: "policy_violation" },
  { label: "Config Change", value: "config_change" },
  { label: "Rate Limit Breach", value: "rate_limit_breach" },
];
const severityOptions = [
  { label: "Critical", value: "critical" },
  { label: "High", value: "high" },
  { label: "Medium", value: "medium" },
  { label: "Low", value: "low" },
];
const resultOptions = [
  { label: "Success", value: "success" },
  { label: "Failure", value: "failure" },
];

export default function SecurityEventsPage() {
  const eventsToday = mockEvents.length;
  const failed = mockEvents.filter((e) => e.result === "failure").length;
  const critical = mockEvents.filter((e) => e.severity === "critical").length;
  const blocked = mockEvents.filter((e) => e.type === "rate_limit_breach" || e.type === "mfa_bypass_attempt").length;

  const trendData = timeSeries(7, 30, 18, 8).map((d) => ({ date: d.date, value: Math.round(d.value) }));
  const byType = Array.from(new Set(mockEvents.map((e) => e.type))).map((t) => ({
    name: t.split("_").map((s) => s.charAt(0).toUpperCase() + s.slice(1)).join(" "),
    value: mockEvents.filter((e) => e.type === t).length,
  })).sort((a, b) => b.value - a.value).slice(0, 6);

  function actorLabel(id: string) {
    const p = people.find((p) => p.id === id);
    if (p) return p.name;
    return id;
  }
  function typeIcon(type: string) {
    if (type.includes("login") || type.includes("mfa")) return <Lock className="w-3.5 h-3.5" />;
    if (type.includes("privilege")) return <ShieldX className="w-3.5 h-3.5" />;
    if (type.includes("rate")) return <Ban className="w-3.5 h-3.5" />;
    if (type.includes("config") || type.includes("firewall")) return <ShieldAlert className="w-3.5 h-3.5" />;
    return <Activity className="w-3.5 h-3.5" />;
  }

  const columns: Column<SecurityEvent>[] = [
    {
      key: "timestamp", header: "Timestamp", sortable: true, sortValue: (r) => r.timestamp,
      cell: (r) => <span className="text-[11px] text-muted-foreground font-mono">{new Date(r.timestamp).toLocaleString()}</span>,
    },
    {
      key: "type", header: "Event Type", sortable: true, sortValue: (r) => r.type,
      filterable: true, filterOptions: typeOptions, filterFn: (r, v) => r.type === v,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className={`shrink-0 w-7 h-7 rounded-md flex items-center justify-center ${
            r.severity === "critical" ? "bg-destructive/10 text-destructive" :
            r.severity === "high" ? "bg-warning/10 text-warning-foreground" :
            r.severity === "medium" ? "bg-info/10 text-info-foreground" :
            "bg-muted text-muted-foreground"
          }`}>
            {typeIcon(r.type)}
          </div>
          <span className="text-xs capitalize">{r.type.replace(/_/g, " ")}</span>
        </div>
      ),
    },
    {
      key: "severity", header: "Severity",
      filterable: true, filterOptions: severityOptions, filterFn: (r, v) => r.severity === v,
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "actor", header: "Actor", sortable: true, sortValue: (r) => r.actor, hideOnMobile: true,
      cell: (r) => <span className="text-xs font-mono">{actorLabel(r.actor)}</span>,
    },
    {
      key: "resource", header: "Resource", hideOnMobile: true,
      cell: (r) => <span className="text-xs font-mono text-muted-foreground">{r.resource}</span>,
    },
    {
      key: "ip", header: "IP", hideOnMobile: true,
      cell: (r) => (
        <span className={`text-[11px] font-mono ${r.ip.startsWith("10.") ? "text-muted-foreground" : "text-warning-foreground"}`}>
          {r.ip}
        </span>
      ),
    },
    {
      key: "result", header: "Result",
      filterable: true, filterOptions: resultOptions, filterFn: (r, v) => r.result === v,
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded font-medium ${
          r.result === "success" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
        }`}>
          {r.result}
        </span>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Security Events"
        description="Real-time stream of security-relevant events: logins, privilege changes, policy violations, and access attempts."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security", href: "/security" }, { label: "Events" }]}
        icon={<AlertOctagon className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Live tail refreshed")}>
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting security events...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Events Today" value={eventsToday} icon={<Activity className="w-4 h-4" />} accent="primary" sparkline={[12, 14, 10, 18, 22, 16, 19, 12]} />
        <KpiCard label="Failed Attempts" value={failed} hint="auth/access denials" icon={<Ban className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Critical Events" value={critical} hint="needs triage" icon={<ShieldX className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Blocked" value={blocked} hint="automatic mitigations" icon={<ShieldAlert className="w-4 h-4" />} accent="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <LineChartCard
            data={trendData}
            dataKey="value"
            color={4}
            title="Security Events Trend"
            description="Audit events per day (last 30 days)"
          />
        </div>
        <DonutChart
          title="Events by Type"
          description="Top event categories"
          data={byType}
          centerLabel="Total"
          centerValue={String(mockEvents.length)}
        />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Security Events Log"
          description="Filter by type, severity, or result. Click a row for details."
          action={
            <Button variant="outline" size="sm" className="text-xs h-8 gap-1.5" onClick={() => toast.info("Creating detection rule from filter...")}>
              <Zap className="w-3.5 h-3.5" /> Create Rule
            </Button>
          }
        />
        <DataTable
          columns={columns}
          data={mockEvents}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.type, (r) => r.actor, (r) => r.resource, (r) => r.ip]}
          searchPlaceholder="Search type, actor, resource, IP..."
          pageSize={10}
          initialSort={{ key: "timestamp", dir: "desc" }}
          mobileCard={(r) => (
            <div className="rounded-lg border bg-card p-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs capitalize font-medium">{r.type.replace(/_/g, " ")}</span>
                <SeverityBadge severity={r.severity} size="sm" />
              </div>
              <div className="text-[10px] text-muted-foreground">{new Date(r.timestamp).toLocaleString()}</div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-muted-foreground">Actor: <span className="font-mono">{actorLabel(r.actor)}</span></span>
                <span className={`px-1.5 py-0.5 rounded font-medium ${r.result === "success" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`}>{r.result}</span>
              </div>
              <div className="text-[10px] text-muted-foreground font-mono truncate">{r.resource} · {r.ip}</div>
            </div>
          )}
        />
      </Card>
    </PageContainer>
  );
}
