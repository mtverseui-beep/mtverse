"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  History, Download, Filter, Calendar, User, Server, Activity,
  CheckCircle2, XCircle, Globe, Lock, FileText, ChevronDown,
} from "lucide-react";
import { auditEvents, people } from "@/lib/data";
import type { AuditEvent } from "@/lib/types";
import { toast } from "sonner";

// Extend audit events with extra mock entries for richer table
const extendedAudit: AuditEvent[] = [
  ...auditEvents,
  { id: "a13", timestamp: "2026-07-02T06:12:00Z", actorId: "u12", action: "security.scan_started", resourceType: "scan", resourceId: "vuln-scan-8821", metadata: {}, ip: "10.42.18.12", result: "success" },
  { id: "a14", timestamp: "2026-07-02T04:30:00Z", actorId: "u14", action: "user.role_changed", resourceType: "user", resourceId: "u5", metadata: { old: "viewer", new: "engineer" }, ip: "10.42.18.14", result: "success" },
  { id: "a15", timestamp: "2026-07-01T20:42:00Z", actorId: "u1", action: "team.member_removed", resourceType: "team", resourceId: "t2", metadata: { user: "u9" }, ip: "10.42.18.10", result: "success" },
  { id: "a16", timestamp: "2026-07-01T16:08:00Z", actorId: "u6", action: "deployment.rollback", resourceType: "deployment", resourceId: "d6", metadata: { to: "v2.4.0" }, ip: "10.42.18.92", result: "failure" },
  { id: "a17", timestamp: "2026-07-01T11:22:00Z", actorId: "u12", action: "api_key.revoked", resourceType: "api_key", resourceId: "ak4", metadata: {}, ip: "10.42.18.12", result: "success" },
  { id: "a18", timestamp: "2026-07-01T09:50:00Z", actorId: "u3", action: "alert_rule.created", resourceType: "alert_rule", resourceId: "ar12", metadata: { metric: "p95_latency" }, ip: "10.42.18.31", result: "success" },
  { id: "a19", timestamp: "2026-06-30T22:18:00Z", actorId: "u16", action: "feature_flag.toggled", resourceType: "feature_flag", resourceId: "ff3", metadata: { enabled: "true" }, ip: "10.42.18.81", result: "success" },
  { id: "a20", timestamp: "2026-06-30T15:32:00Z", actorId: "u2", action: "policy.updated", resourceType: "policy", resourceId: "pol-7", metadata: {}, ip: "10.42.18.14", result: "success" },
];

const actorOptions = Array.from(new Set(extendedAudit.map((a) => a.actorId))).map((id) => {
  const p = people.find((p) => p.id === id);
  return { label: p?.name || id, value: id };
});
const actionOptions = Array.from(new Set(extendedAudit.map((a) => a.action.split(".")[0]))).map((k) => ({
  label: k.charAt(0).toUpperCase() + k.slice(1),
  value: k,
}));
const resultOptions = [
  { label: "Success", value: "success" },
  { label: "Failure", value: "failure" },
];

function actionIcon(action: string) {
  if (action.includes("incident")) return <Activity className="w-3.5 h-3.5" />;
  if (action.includes("deployment")) return <Server className="w-3.5 h-3.5" />;
  if (action.includes("security") || action.includes("policy")) return <Lock className="w-3.5 h-3.5" />;
  if (action.includes("user") || action.includes("team")) return <User className="w-3.5 h-3.5" />;
  return <History className="w-3.5 h-3.5" />;
}

export default function AuditTrailsPage() {
  const total = extendedAudit.length;
  const success = extendedAudit.filter((a) => a.result === "success").length;
  const failure = extendedAudit.filter((a) => a.result === "failure").length;
  const uniqueActors = new Set(extendedAudit.map((a) => a.actorId)).size;

  const columns: Column<AuditEvent>[] = [
    {
      key: "timestamp", header: "Timestamp", sortable: true, sortValue: (r) => r.timestamp,
      cell: (r) => <span className="text-[11px] text-muted-foreground font-mono whitespace-nowrap">{new Date(r.timestamp).toLocaleString()}</span>,
    },
    {
      key: "actor", header: "Actor", sortable: true, sortValue: (r) => r.actorId,
      filterable: true, filterOptions: actorOptions, filterFn: (r, v) => r.actorId === v,
      cell: (r) => {
        const p = people.find((p) => p.id === r.actorId);
        return p ? (
          <div className="flex items-center gap-1.5">
            <img src={p.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate max-w-[120px]">{p.name}</span>
          </div>
        ) : <span className="text-xs font-mono">{r.actorId}</span>;
      },
    },
    {
      key: "action", header: "Action", sortable: true, sortValue: (r) => r.action,
      filterable: true, filterOptions: actionOptions, filterFn: (r, v) => r.action.startsWith(v),
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className="shrink-0 w-6 h-6 rounded bg-muted flex items-center justify-center text-muted-foreground">
            {actionIcon(r.action)}
          </div>
          <span className="text-xs font-mono">{r.action}</span>
        </div>
      ),
    },
    {
      key: "resource", header: "Resource", hideOnMobile: true,
      cell: (r) => (
        <div className="text-xs">
          <div className="font-mono text-[11px]">{r.resourceId}</div>
          <div className="text-[10px] text-muted-foreground">{r.resourceType}</div>
        </div>
      ),
    },
    {
      key: "ip", header: "IP", hideOnMobile: true,
      cell: (r) => (
        <span className="text-[11px] font-mono text-muted-foreground inline-flex items-center gap-1">
          <Globe className="w-3 h-3" />
          {r.ip}
        </span>
      ),
    },
    {
      key: "result", header: "Result",
      filterable: true, filterOptions: resultOptions, filterFn: (r, v) => r.result === v,
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded font-medium ${
          r.result === "success" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
        }`}>
          {r.result === "success" ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
          {r.result}
        </span>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Audit Trails"
        description="Immutable record of all security-relevant actions across the platform."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security", href: "/security" }, { label: "Audit Trails" }]}
        icon={<History className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Filter dialog opened")}>
              <Filter className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Advanced</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Audit log exported", { description: "Signed CSV delivered to compliance@sentinelgrid.io" })}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Events" value={total} icon={<History className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Successful" value={success} hint="events completed" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Failed" value={failure} hint="requires review" icon={<XCircle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Unique Actors" value={uniqueActors} hint="users in trail" icon={<User className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Audit Log"
          description="Filter by actor, action category, or result. All entries are cryptographically signed."
          action={
            <Button variant="outline" size="sm" className="text-xs h-8 gap-1.5" onClick={() => toast.success("Verification passed", { description: "Hash chain intact, no tampering detected." })}>
              <FileText className="w-3.5 h-3.5" /> Verify Integrity
            </Button>
          }
        />
        <DataTable
          columns={columns}
          data={extendedAudit}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.action, (r) => r.resourceId, (r) => r.ip]}
          searchPlaceholder="Search action, resource, IP..."
          pageSize={12}
          initialSort={{ key: "timestamp", dir: "desc" }}
          mobileCard={(r) => {
            const p = people.find((p) => p.id === r.actorId);
            return (
              <div className="rounded-lg border bg-card p-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {p && <img src={p.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />}
                    <span className="text-xs font-medium">{p?.name || r.actorId}</span>
                  </div>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${r.result === "success" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`}>
                    {r.result}
                  </span>
                </div>
                <div className="text-[11px] font-mono">{r.action}</div>
                <div className="text-[10px] text-muted-foreground font-mono">{r.resourceType} · {r.resourceId}</div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span className="font-mono">{r.ip}</span>
                  <span>{new Date(r.timestamp).toLocaleString()}</span>
                </div>
              </div>
            );
          }}
        />
      </Card>
    </PageContainer>
  );
}
