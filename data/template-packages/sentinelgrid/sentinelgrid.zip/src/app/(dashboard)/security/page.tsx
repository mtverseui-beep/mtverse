"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  ShieldAlert, ShieldX, ShieldCheck, Bug, Clock, ChevronRight,
  Download, ScanLine, Activity, Lock, Zap, FileCheck, AlertTriangle,
} from "lucide-react";
import { vulnerabilities, auditEvents, people, services, timeSeries } from "@/lib/data";
import { DonutChart, LineChartCard, HorizontalBarChart } from "@/components/charts";
import { SeverityBadge, StatusDot } from "@/components/common/badges";
import type { Vulnerability } from "@/lib/types";
import { toast } from "sonner";

export default function SecurityOverviewPage() {
  const open = vulnerabilities.filter((v) => v.status === "open" || v.status === "in_progress");
  const critical = vulnerabilities.filter((v) => v.severity === "critical" && v.status !== "patched");
  const patched = vulnerabilities.filter((v) => v.status === "patched");
  const complianceScore = 87;
  const mttr = 4.2;

  // Group vulns by severity for donut
  const bySeverity = (["critical", "high", "medium", "low"] as const).map((s) => ({
    name: s.charAt(0).toUpperCase() + s.slice(1),
    value: vulnerabilities.filter((v) => v.severity === s).length,
    color: s === "critical" ? "var(--destructive)" : s === "high" ? "var(--warning)" : s === "medium" ? "var(--info)" : "var(--muted-foreground)",
  }));

  // Group by status for bar chart
  const statusCounts = ["open", "in_progress", "patched", "ignored"].map((s) => ({
    name: s === "in_progress" ? "In Progress" : s.charAt(0).toUpperCase() + s.slice(1),
    value: vulnerabilities.filter((v) => v.status === s).length,
  }));

  // Security events trend (30d)
  const eventsTrend = timeSeries(19, 30, 24, 12).map((d) => ({
    date: d.date,
    value: Math.max(0, Math.round(d.value)),
  }));

  // Top vulnerable assets — count vulns per assetName
  const assetCounts = Array.from(new Set(vulnerabilities.map((v) => v.assetName))).map((asset) => ({
    asset,
    count: vulnerabilities.filter((v) => v.assetName === asset).length,
    serviceId: vulnerabilities.find((v) => v.assetName === asset)?.serviceId,
    critical: vulnerabilities.filter((v) => v.assetName === asset && (v.severity === "critical" || v.severity === "high")).length,
  })).sort((a, b) => b.count - a.count).slice(0, 6);

  const topAssetsBar = assetCounts.map((a) => ({ name: a.asset.split("-").slice(0, 2).join("-"), value: a.count }));

  // Compliance posture
  const complianceFrameworks = [
    { name: "SOC 2 Type II", passing: 88, status: "On Track" },
    { name: "ISO 27001", passing: 92, status: "On Track" },
    { name: "GDPR", passing: 76, status: "At Risk" },
    { name: "HIPAA", passing: 81, status: "On Track" },
    { name: "PCI DSS", passing: 64, status: "Action Needed" },
  ];

  // Recent security events
  const recentEvents = auditEvents.slice(0, 6);

  const vulnColumns: Column<Vulnerability>[] = [
    {
      key: "cve", header: "CVE", sortable: true, sortValue: (r) => r.cve,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Bug className="w-3.5 h-3.5 text-muted-foreground" />
          <div>
            <div className="text-xs font-mono font-medium">{r.cve}</div>
            <div className="text-[10px] text-muted-foreground">{r.ref}</div>
          </div>
        </div>
      ),
    },
    {
      key: "title", header: "Title", sortable: true, sortValue: (r) => r.title,
      cell: (r) => (
        <div className="min-w-0 max-w-xs">
          <div className="text-xs font-medium truncate">{r.title}</div>
          <div className="text-[10px] text-muted-foreground truncate">{r.assetName}</div>
        </div>
      ),
    },
    {
      key: "severity", header: "Severity", sortable: true, sortValue: (r) => r.cvss,
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <SeverityBadge severity={r.severity} size="sm" />
          <span className="text-[10px] font-mono tabular-nums text-muted-foreground">{r.cvss}</span>
        </div>
      ),
    },
    {
      key: "status", header: "Status",
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-md border font-medium capitalize ${
          r.status === "open" ? "bg-destructive/15 text-destructive border-destructive/30" :
          r.status === "in_progress" ? "bg-warning/15 text-warning-foreground border-warning/30" :
          r.status === "patched" ? "bg-success/15 text-success border-success/30" :
          "bg-muted text-muted-foreground border-border"
        }`}>
          <span className={`w-1.5 h-1.5 rounded-full ${
            r.status === "open" ? "bg-destructive" :
            r.status === "in_progress" ? "bg-warning" :
            r.status === "patched" ? "bg-success" :
            "bg-muted-foreground"
          }`} />
          {r.status.replace("_", " ")}
        </span>
      ),
    },
    {
      key: "owner", header: "Owner", hideOnMobile: true,
      cell: (r) => {
        const owner = people.find((p) => p.id === r.owner);
        return owner ? (
          <div className="flex items-center gap-1.5">
            <img src={owner.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate">{owner.name}</span>
          </div>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Security Overview"
        description="Vulnerability management, compliance posture, and security event monitoring across the platform."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security" }]}
        icon={<ShieldAlert className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting security report...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Vulnerability scan started", { description: "Results will appear in 5-10 minutes." })}>
              <ScanLine className="w-3.5 h-3.5" />
              Scan Now
            </Button>
          </>
        }
      />

      {/* 4 KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Open Vulnerabilities"
          value={open.length}
          hint={`${critical.length} critical`}
          icon={<Bug className="w-4 h-4" />}
          accent="destructive"
          sparkline={[3, 4, 5, 4, 6, 5, 4, 5, 4, 4]}
        />
        <KpiCard
          label="Critical (Open)"
          value={critical.length}
          hint="needs immediate patching"
          icon={<ShieldX className="w-4 h-4" />}
          accent="destructive"
        />
        <KpiCard
          label="Compliance Score"
          value={complianceScore}
          unit="%"
          delta={3}
          deltaLabel="vs last month"
          icon={<ShieldCheck className="w-4 h-4" />}
          accent={complianceScore >= 90 ? "success" : "warning"}
          sparkline={[82, 84, 83, 85, 86, 85, 87, 86, 87, 87]}
        />
        <KpiCard
          label="Mean Time to Patch"
          value={mttr}
          unit="days"
          delta={-18}
          deltaLabel="improving"
          icon={<Clock className="w-4 h-4" />}
          accent="primary"
          sparkline={[6.2, 5.8, 5.5, 5.1, 4.9, 4.7, 4.5, 4.4, 4.3, 4.2]}
        />
      </div>

      {/* Donut + Bar + Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <DonutChart
          title="Vulnerabilities by Severity"
          description="All known CVEs grouped by CVSS"
          data={bySeverity}
          centerLabel="Total"
          centerValue={String(vulnerabilities.length)}
        />

        <Card className="p-5">
          <SectionHeading title="Vulnerabilities by Status" description="Remediation state distribution" />
          <div className="h-[220px] mt-3">
            <HorizontalBarChart data={statusCounts} />
          </div>
        </Card>

        <LineChartCard
          data={eventsTrend}
          dataKey="value"
          color={4}
          title="Security Events Trend"
          description="Audit events per day (last 30 days)"
        />
      </div>

      {/* Top vulnerable assets + Compliance posture */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Top Vulnerable Assets"
            description="Assets with most known CVEs"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/security/vulnerabilities">View all <ChevronRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="space-y-3">
            {assetCounts.map((a) => {
              const svc = a.serviceId ? services.find((s) => s.id === a.serviceId) : null;
              return (
                <Link
                  key={a.asset}
                  href={svc ? `/services/${svc.id}` : "/security/vulnerabilities"}
                  className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors group"
                >
                  <div className="shrink-0 w-9 h-9 rounded-md bg-destructive/10 border border-destructive/20 flex items-center justify-center text-destructive">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium font-mono truncate">{a.asset}</span>
                      {svc && <span className="text-[10px] text-muted-foreground truncate">{svc.name}</span>}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] text-muted-foreground">{a.count} total</span>
                      {a.critical > 0 && (
                        <span className="inline-flex items-center gap-1 text-[10px] text-destructive">
                          <StatusDot color="destructive" />{a.critical} critical/high
                        </span>
                      )}
                    </div>
                    <div className="mt-1.5 h-1.5 rounded-full bg-muted overflow-hidden">
                      <div className="h-full bg-destructive" style={{ width: `${(a.count / vulnerabilities.length) * 100}%` }} />
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0 group-hover:translate-x-0.5 transition-transform" />
                </Link>
              );
            })}
          </div>
        </Card>

        <Card className="p-5 space-y-4 border-primary/20">
          <SectionHeading
            title="Compliance Posture"
            description="Framework control pass rates"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/security/compliance">Details <ChevronRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="space-y-3">
            {complianceFrameworks.map((f) => (
              <div key={f.name} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <FileCheck className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="font-medium">{f.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                      f.status === "On Track" ? "bg-success/15 text-success" :
                      f.status === "At Risk" ? "bg-warning/15 text-warning-foreground" :
                      "bg-destructive/15 text-destructive"
                    }`}>{f.status}</span>
                    <span className="font-mono tabular-nums">{f.passing}%</span>
                  </div>
                </div>
                <Progress value={f.passing} className={`h-1.5 ${f.passing >= 85 ? "[&_>div]:bg-success" : f.passing >= 70 ? "[&_>div]:bg-warning" : "[&_>div]:bg-destructive"}`} />
              </div>
            ))}
          </div>
          <div className="pt-3 border-t border-border">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Overall posture</span>
              <div className="flex items-center gap-2">
                <span className="font-mono font-semibold tabular-nums">{complianceScore}%</span>
                <span className="inline-flex items-center gap-1 text-[10px] text-success">
                  <Zap className="w-3 h-3" /> Improving
                </span>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Vulnerability register table */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Vulnerability Register"
          description="All known CVEs with severity, status, and owner"
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/security/vulnerabilities">View all <ChevronRight className="w-3 h-3" /></Link></Button>}
        />
        <DataTable
          columns={vulnColumns}
          data={vulnerabilities}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.cve, (r) => r.title, (r) => r.assetName]}
          searchPlaceholder="Search CVEs..."
          pageSize={5}
          onRowClick={(r) => { window.location.href = `/security/vulnerabilities/${r.id}`; }}
        />
      </Card>

      {/* Recent security events feed */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Recent Security Activity"
          description="Latest audit-trail events"
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/security/audit">Audit trails <ChevronRight className="w-3 h-3" /></Link></Button>}
        />
        <div className="space-y-2">
          {recentEvents.map((evt) => {
            const actor = people.find((p) => p.id === evt.actorId);
            return (
              <div key={evt.id} className="flex items-center gap-3 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors">
                <div className={`shrink-0 w-8 h-8 rounded-md flex items-center justify-center ${evt.result === "failure" ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground"}`}>
                  {evt.action.includes("incident") ? <ShieldAlert className="w-3.5 h-3.5" /> :
                   evt.action.includes("deployment") ? <Activity className="w-3.5 h-3.5" /> :
                   evt.action.includes("alert") ? <Zap className="w-3.5 h-3.5" /> :
                   <Lock className="w-3.5 h-3.5" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-medium">{actor?.name ?? "System"}</span>
                    <span className="text-[10px] font-mono text-muted-foreground">{evt.action}</span>
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-0.5 truncate">
                    {evt.resourceType} · {evt.resourceId} · from {evt.ip}
                  </p>
                </div>
                <span className="text-[10px] text-muted-foreground shrink-0">
                  {new Date(evt.timestamp).toLocaleString()}
                </span>
              </div>
            );
          })}
        </div>
      </Card>
    </PageContainer>
  );
}
