"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  ShieldAlert, Bug, ShieldCheck, Wrench, UserCheck, AlertOctagon,
  Download, Plus,
} from "lucide-react";
import { vulnerabilities, people, services } from "@/lib/data";
import { SeverityBadge } from "@/components/common/badges";
import type { Vulnerability } from "@/lib/types";
import { toast } from "sonner";

const severityOptions = [
  { label: "Critical", value: "critical" },
  { label: "High", value: "high" },
  { label: "Medium", value: "medium" },
  { label: "Low", value: "low" },
];
const statusOptions = [
  { label: "Open", value: "open" },
  { label: "In Progress", value: "in_progress" },
  { label: "Patched", value: "patched" },
  { label: "Ignored", value: "ignored" },
  { label: "False Positive", value: "false_positive" },
];
const serviceOptions = services.map((s) => ({ label: s.name, value: s.id }));

export default function VulnerabilitiesListPage() {
  const patched30d = vulnerabilities.filter((v) => v.status === "patched").length;

  const columns: Column<Vulnerability>[] = [
    {
      key: "ref", header: "Ref", sortable: true, sortValue: (r) => r.ref, hideOnMobile: true,
      cell: (r) => <span className="text-[11px] font-mono text-muted-foreground">{r.ref}</span>,
    },
    {
      key: "cve", header: "CVE", sortable: true, sortValue: (r) => r.cve,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Bug className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-xs font-mono font-medium">{r.cve}</span>
        </div>
      ),
    },
    {
      key: "title", header: "Title", sortable: true, sortValue: (r) => r.title,
      cell: (r) => (
        <div className="min-w-0 max-w-[280px]">
          <div className="text-xs font-medium truncate">{r.title}</div>
          <div className="text-[10px] text-muted-foreground truncate font-mono">{r.assetName}</div>
        </div>
      ),
    },
    {
      key: "severity", header: "Severity", sortable: true, sortValue: (r) => r.cvss,
      filterable: true, filterOptions: severityOptions, filterFn: (r, v) => r.severity === v,
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <SeverityBadge severity={r.severity} size="sm" />
          <span className="text-[10px] font-mono tabular-nums text-muted-foreground">{r.cvss}</span>
        </div>
      ),
    },
    {
      key: "service", header: "Service", sortable: true, sortValue: (r) => r.serviceId || "",
      filterable: true, filterOptions: serviceOptions, filterFn: (r, v) => r.serviceId === v, hideOnMobile: true,
      cell: (r) => {
        const svc = services.find((s) => s.id === r.serviceId);
        return svc ? <span className="text-xs font-mono">{svc.name}</span> : <span className="text-xs text-muted-foreground">—</span>;
      },
    },
    {
      key: "status", header: "Status",
      filterable: true, filterOptions: statusOptions, filterFn: (r, v) => r.status === v,
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-md border font-medium capitalize ${
          r.status === "open" ? "bg-destructive/15 text-destructive border-destructive/30" :
          r.status === "in_progress" ? "bg-warning/15 text-warning-foreground border-warning/30" :
          r.status === "patched" ? "bg-success/15 text-success border-success/30" :
          r.status === "false_positive" ? "bg-muted text-muted-foreground border-border" :
          "bg-muted text-muted-foreground border-border"
        }`}>
          <span className={`w-1.5 h-1.5 rounded-full ${
            r.status === "open" ? "bg-destructive" :
            r.status === "in_progress" ? "bg-warning" :
            r.status === "patched" ? "bg-success" :
            "bg-muted-foreground"
          }`} />
          {r.status.replace("_", " ")}
        </span>
      ),
    },
    {
      key: "discoveredAt", header: "Discovered", sortable: true, sortValue: (r) => r.discoveredAt, hideOnMobile: true,
      cell: (r) => <span className="text-[11px] text-muted-foreground">{new Date(r.discoveredAt).toLocaleDateString()}</span>,
    },
    {
      key: "owner", header: "Owner", hideOnMobile: true,
      cell: (r) => {
        const owner = people.find((p) => p.id === r.owner);
        return owner ? (
          <div className="flex items-center gap-1.5">
            <img src={owner.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate">{owner.name.split(" ")[0]}</span>
          </div>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
    },
  ];

  const total = vulnerabilities.length;
  const critical = vulnerabilities.filter((v) => v.severity === "critical").length;
  const open = vulnerabilities.filter((v) => v.status === "open" || v.status === "in_progress").length;

  return (
    <PageContainer>
      <PageHeader
        title="Vulnerabilities"
        description="Tracked CVEs across the platform with severity, status, and remediation owner."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security", href: "/security" }, { label: "Vulnerabilities" }]}
        icon={<Bug className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting vulnerabilities as CSV...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Vulnerability scan started", { description: "Continuous scan will refresh results every 6 hours." })}>
              <Plus className="w-3.5 h-3.5" />
              New Scan
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Vulnerabilities" value={total} icon={<ShieldAlert className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Critical" value={critical} hint="across all assets" icon={<AlertOctagon className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Open" value={open} hint="not yet patched" icon={<Wrench className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Patched (30d)" value={patched30d} delta={12} deltaLabel="vs prior period" icon={<ShieldCheck className="w-4 h-4" />} accent="success" />
      </div>

      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Vulnerability Register"
          description="Filter by severity, status, or service. Use bulk actions to assign or dismiss."
          action={
            <Button variant="outline" size="sm" className="text-xs h-8 gap-1.5">
              <UserCheck className="w-3.5 h-3.5" /> Auto-Triage
            </Button>
          }
        />
        <DataTable
          columns={columns}
          data={vulnerabilities}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.cve, (r) => r.title, (r) => r.assetName, (r) => r.ref]}
          searchPlaceholder="Search CVE, title, asset..."
          pageSize={8}
          enableSelection
          onRowClick={(r) => { window.location.href = `/security/vulnerabilities/${r.id}`; }}
          mobileCard={(r) => (
            <div className="rounded-lg border bg-card p-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <Bug className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-xs font-mono font-medium">{r.cve}</span>
                </div>
                <SeverityBadge severity={r.severity} size="sm" />
              </div>
              <div className="text-xs font-medium">{r.title}</div>
              <div className="text-[10px] text-muted-foreground font-mono truncate">{r.assetName}</div>
              <div className="flex items-center justify-between pt-1 border-t border-border">
                <span className="text-[10px] text-muted-foreground">{new Date(r.discoveredAt).toLocaleDateString()}</span>
                <span className="text-[10px] capitalize">{r.status.replace("_", " ")}</span>
              </div>
            </div>
          )}
          bulkActions={[
            {
              label: "Assign",
              icon: <UserCheck className="w-3.5 h-3.5" />,
              onClick: (rows) => toast.success(`Assigned ${rows.length} vulnerabilities`, { description: "Default triage owner applied." }),
            },
            {
              label: "Mark false positive",
              icon: <AlertOctagon className="w-3.5 h-3.5" />,
              onClick: (rows) => toast.success(`Marked ${rows.length} as false positive`),
              variant: "destructive",
            },
          ]}
        />
      </Card>
    </PageContainer>
  );
}
