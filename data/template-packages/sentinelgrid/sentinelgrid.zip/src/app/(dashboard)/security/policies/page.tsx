"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  ShieldX, AlertTriangle, ShieldCheck, Wrench, Download,
  Lock, Key, Users, Cloud, GitBranch, Settings, ScanLine, ChevronRight,
} from "lucide-react";
import { SeverityBadge } from "@/components/common/badges";
import { toast } from "sonner";

interface PolicyViolation {
  id: string;
  policy: string;
  category: "access" | "encryption" | "configuration" | "network" | "secrets";
  severity: "critical" | "high" | "medium" | "low";
  resource: string;
  detected: string;
  status: "open" | "resolved" | "ignored";
  owner: string;
}

const violations: PolicyViolation[] = [
  { id: "pv1", policy: "Too many admin users", category: "access", severity: "high", resource: "authz-engine", detected: "2026-07-01T08:00:00Z", status: "open", owner: "Maya Okonkwo" },
  { id: "pv2", policy: "MFA disabled for privileged account", category: "access", severity: "critical", resource: "user:u4", detected: "2026-06-30T14:00:00Z", status: "open", owner: "Hannah Wright" },
  { id: "pv3", policy: "Public S3 bucket detected", category: "configuration", severity: "critical", resource: "s3://sentinelgrid-logs-backup", detected: "2026-06-29T09:00:00Z", status: "open", owner: "Daniel Vargas" },
  { id: "pv4", policy: "Unencrypted RDS snapshot", category: "encryption", severity: "high", resource: "rds:snapshot-8821", detected: "2026-06-28T16:00:00Z", status: "resolved", owner: "Priya Raman" },
  { id: "pv5", policy: "SSH key without passphrase", category: "secrets", severity: "medium", resource: "host:h3", detected: "2026-06-27T11:00:00Z", status: "open", owner: "Marcus Anderson" },
  { id: "pv6", policy: "Security group allows 0.0.0.0/0 on 22", category: "network", severity: "high", resource: "sg-prod-ssh", detected: "2026-06-26T13:00:00Z", status: "open", owner: "Theo Lambert" },
  { id: "pv7", policy: "CloudTrail logging disabled", category: "configuration", severity: "critical", resource: "aws:prod-account", detected: "2026-06-25T10:00:00Z", status: "resolved", owner: "Hannah Wright" },
  { id: "pv8", policy: "Default VPC in use", category: "network", severity: "medium", resource: "vpc-default", detected: "2026-06-24T15:00:00Z", status: "ignored", owner: "Daniel Vargas" },
  { id: "pv9", policy: "IAM access key older than 90 days", category: "secrets", severity: "medium", resource: "iam:ak-legacy", detected: "2026-06-22T08:00:00Z", status: "open", owner: "Hannah Wright" },
  { id: "pv10", policy: "Container running as root", category: "configuration", severity: "high", resource: "k8s:checkout-api/pod-7c2", detected: "2026-06-20T12:00:00Z", status: "open", owner: "Marcus Anderson" },
];

function categoryIcon(c: PolicyViolation["category"]) {
  switch (c) {
    case "access": return <Users className="w-3.5 h-3.5" />;
    case "encryption": return <Lock className="w-3.5 h-3.5" />;
    case "configuration": return <Settings className="w-3.5 h-3.5" />;
    case "network": return <Cloud className="w-3.5 h-3.5" />;
    case "secrets": return <Key className="w-3.5 h-3.5" />;
  }
}

const categoryFilters = ["access", "encryption", "configuration", "network", "secrets"];

export default function PolicyViolationsPage() {
  const [filter, setFilter] = React.useState<string>("all");

  const total = violations.length;
  const critical = violations.filter((v) => v.severity === "critical").length;
  const open = violations.filter((v) => v.status === "open").length;
  const resolved30d = violations.filter((v) => v.status === "resolved").length;

  const filtered = filter === "all" ? violations : violations.filter((v) => v.category === filter);

  const byCategory = categoryFilters.map((c) => ({
    name: c.charAt(0).toUpperCase() + c.slice(1),
    value: violations.filter((v) => v.category === c).length,
    open: violations.filter((v) => v.category === c && v.status === "open").length,
  }));

  return (
    <PageContainer>
      <PageHeader
        title="Policy Violations"
        description="Detected deviations from security policies and best practices across cloud, infrastructure, and code."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security", href: "/security" }, { label: "Policy Violations" }]}
        icon={<ShieldX className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting violations...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Policy scan started", { description: "Re-evaluating all cloud resources against policies." })}>
              <ScanLine className="w-3.5 h-3.5" />
              Run Scan
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Violations" value={total} icon={<ShieldX className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Critical" value={critical} hint="needs immediate action" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Open" value={open} hint="not yet remediated" icon={<Wrench className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Resolved (30d)" value={resolved30d} delta={15} deltaLabel="vs prior period" icon={<ShieldCheck className="w-4 h-4" />} accent="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Violations list */}
        <div className="lg:col-span-2">
          <Card className="p-5 space-y-4">
            <SectionHeading
              title="Active Violations"
              description="Filter by category to focus remediation"
              action={
                <div className="flex items-center gap-1.5 flex-wrap">
                  <Button
                    variant={filter === "all" ? "default" : "outline"}
                    size="sm"
                    className="h-7 text-[11px]"
                    onClick={() => setFilter("all")}
                  >
                    All
                  </Button>
                  {categoryFilters.map((c) => (
                    <Button
                      key={c}
                      variant={filter === c ? "default" : "outline"}
                      size="sm"
                      className="h-7 text-[11px] capitalize"
                      onClick={() => setFilter(c)}
                    >
                      {c}
                    </Button>
                  ))}
                </div>
              }
            />
            <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
              {filtered.map((v) => (
                <div key={v.id} className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors">
                  <div className={`shrink-0 w-9 h-9 rounded-md flex items-center justify-center ${
                    v.severity === "critical" ? "bg-destructive/10 text-destructive border border-destructive/20" :
                    v.severity === "high" ? "bg-warning/10 text-warning-foreground border border-warning/20" :
                    v.severity === "medium" ? "bg-info/10 text-info-foreground border border-info/20" :
                    "bg-muted text-muted-foreground border"
                  }`}>
                    {categoryIcon(v.category)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-medium">{v.policy}</span>
                      <SeverityBadge severity={v.severity} size="sm" />
                    </div>
                    <div className="text-[11px] text-muted-foreground mt-1 font-mono truncate">{v.resource}</div>
                    <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground flex-wrap">
                      <span className="capitalize">category: {v.category}</span>
                      <span>·</span>
                      <span>detected {new Date(v.detected).toLocaleDateString()}</span>
                      <span>·</span>
                      <span>owner: {v.owner}</span>
                    </div>
                  </div>
                  <div className="shrink-0 flex flex-col items-end gap-1.5">
                    <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded font-medium capitalize ${
                      v.status === "open" ? "bg-destructive/15 text-destructive" :
                      v.status === "resolved" ? "bg-success/15 text-success" :
                      "bg-muted text-muted-foreground"
                    }`}>{v.status}</span>
                    {v.status === "open" && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-6 text-[10px] px-2 gap-1"
                        onClick={() => toast.success(`Remediation plan created for "${v.policy}"`)}
                      >
                        <Wrench className="w-3 h-3" /> Remediate
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Side: by category + recent resolutions */}
        <div className="space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="By Category" description="Violation distribution" />
            <div className="space-y-3">
              {byCategory.map((c) => {
                const pct = total > 0 ? (c.value / total) * 100 : 0;
                return (
                  <div key={c.name}>
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-muted-foreground">{c.name}</span>
                      <span className="font-mono tabular-nums">
                        <span className="font-medium">{c.value}</span>
                        {c.open > 0 && <span className="text-destructive ml-1.5">({c.open} open)</span>}
                      </span>
                    </div>
                    <Progress value={pct} className="h-1.5" />
                  </div>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Recent Resolutions" description="Policies remediated this week" />
            <div className="space-y-2">
              {[
                { policy: "CloudTrail logging disabled", resolver: "Hannah Wright", ts: "2026-07-01T18:00:00Z" },
                { policy: "Unencrypted RDS snapshot", resolver: "Priya Raman", ts: "2026-06-30T10:30:00Z" },
                { policy: "IAM user without MFA", resolver: "Maya Okonkwo", ts: "2026-06-29T14:00:00Z" },
              ].map((r, i) => (
                <div key={i} className="flex items-start gap-2 p-2.5 rounded-lg border">
                  <div className="shrink-0 w-7 h-7 rounded-md bg-success/10 text-success flex items-center justify-center">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] font-medium truncate">{r.policy}</div>
                    <div className="text-[10px] text-muted-foreground">{r.resolver} · {new Date(r.ts).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
