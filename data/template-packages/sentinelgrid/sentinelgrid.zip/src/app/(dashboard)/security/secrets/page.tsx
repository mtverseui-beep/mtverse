"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Key, ShieldAlert, ShieldCheck, Wrench, Eye, FileCode, GitBranch,
  Download, ScanLine, ChevronRight, Database, Server, AlertTriangle, History,
} from "lucide-react";
import { SeverityBadge } from "@/components/common/badges";
import { toast } from "sonner";

interface SecretFinding {
  id: string;
  finding: string;
  severity: "critical" | "high" | "medium" | "low";
  type: "api_key" | "private_key" | "token" | "password" | "certificate";
  location: string;
  detected: string;
  status: "open" | "fixed" | "ignored";
}

const findings: SecretFinding[] = [
  { id: "sf1", finding: "AWS Access Key in source code", severity: "critical", type: "api_key", location: "api-gateway/src/main.go:142", detected: "2026-07-01T08:00:00Z", status: "open" },
  { id: "sf2", finding: "Stripe Secret Key in env file", severity: "critical", type: "api_key", location: "checkout-api/.env.example:8", detected: "2026-06-29T14:00:00Z", status: "open" },
  { id: "sf3", finding: "GitHub PAT in CI logs", severity: "high", type: "token", location: "ci-logs/build-8821.log", detected: "2026-06-28T10:30:00Z", status: "fixed" },
  { id: "sf4", finding: "Private SSH key in Docker image", severity: "high", type: "private_key", location: "billing-service/Dockerfile", detected: "2026-06-26T16:00:00Z", status: "open" },
  { id: "sf5", finding: "Database password in Helm values", severity: "high", type: "password", location: "k8s/postgres/values.yaml:24", detected: "2026-06-24T12:00:00Z", status: "fixed" },
  { id: "sf6", finding: "JWT signing secret in commit message", severity: "medium", type: "token", location: "git:web-app@a3f2c1b", detected: "2026-06-22T09:00:00Z", status: "open" },
  { id: "sf7", finding: "Slack webhook URL in code", severity: "low", type: "token", location: "alerts/src/notify.go:67", detected: "2026-06-20T18:00:00Z", status: "ignored" },
  { id: "sf8", finding: "Expired TLS certificate detected", severity: "medium", type: "certificate", location: "edge/lb-prod-eu-west-1", detected: "2026-06-18T08:00:00Z", status: "open" },
];

const scanHistory = [
  { id: "sh1", ts: "2026-07-02T05:00:00Z", scope: "All repositories", findings: 8, new: 2, status: "completed" },
  { id: "sh2", ts: "2026-07-01T05:00:00Z", scope: "All repositories", findings: 7, new: 1, status: "completed" },
  { id: "sh3", ts: "2026-06-30T05:00:00Z", scope: "All repositories", findings: 6, new: 0, status: "completed" },
  { id: "sh4", ts: "2026-06-29T05:00:00Z", scope: "All repositories", findings: 6, new: 3, status: "completed" },
  { id: "sh5", ts: "2026-06-28T05:00:00Z", scope: "All repositories", findings: 4, new: 1, status: "completed" },
];

function typeIcon(t: SecretFinding["type"]) {
  switch (t) {
    case "api_key": return <Key className="w-3.5 h-3.5" />;
    case "private_key": return <Key className="w-3.5 h-3.5" />;
    case "token": return <Key className="w-3.5 h-3.5" />;
    case "password": return <ShieldAlert className="w-3.5 h-3.5" />;
    case "certificate": return <ShieldCheck className="w-3.5 h-3.5" />;
  }
}

export default function SecretsExposurePage() {
  const total = findings.length;
  const critical = findings.filter((f) => f.severity === "critical").length;
  const open = findings.filter((f) => f.status === "open").length;
  const fixed30d = findings.filter((f) => f.status === "fixed").length;

  const sevCounts = (["critical", "high", "medium", "low"] as const).map((s) => ({
    name: s.charAt(0).toUpperCase() + s.slice(1),
    value: findings.filter((f) => f.severity === s).length,
  }));

  return (
    <PageContainer>
      <PageHeader
        title="Secrets Exposure"
        description="Detect leaked credentials, API keys, and certificates across code, configs, and runtime surfaces."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security", href: "/security" }, { label: "Secrets" }]}
        icon={<Key className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting findings as CSV...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Secret scan started", { description: "Scanning all repos, images, and runtime surfaces." })}>
              <ScanLine className="w-3.5 h-3.5" />
              Run Scan
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Findings" value={total} icon={<Key className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Critical" value={critical} hint="keys in source" icon={<ShieldAlert className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Open" value={open} hint="not yet fixed" icon={<Wrench className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Fixed (30d)" value={fixed30d} delta={20} deltaLabel="vs prior period" icon={<ShieldCheck className="w-4 h-4" />} accent="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Findings list */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Active Findings" description="Open and recently-resolved secret exposures" />
            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
              {findings.map((f) => (
                <div key={f.id} className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors">
                  <div className={`shrink-0 w-9 h-9 rounded-md flex items-center justify-center ${
                    f.severity === "critical" ? "bg-destructive/10 text-destructive border border-destructive/20" :
                    f.severity === "high" ? "bg-warning/10 text-warning-foreground border border-warning/20" :
                    f.severity === "medium" ? "bg-info/10 text-info-foreground border border-info/20" :
                    "bg-muted text-muted-foreground border"
                  }`}>
                    {typeIcon(f.type)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-medium">{f.finding}</span>
                      <SeverityBadge severity={f.severity} size="sm" />
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground capitalize">{f.type.replace(/_/g, " ")}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1.5 text-[11px] text-muted-foreground flex-wrap">
                      <span className="inline-flex items-center gap-1"><FileCode className="w-3 h-3" /><span className="font-mono">{f.location}</span></span>
                      <span>·</span>
                      <span>detected {new Date(f.detected).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="shrink-0 flex flex-col items-end gap-1">
                    <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded font-medium capitalize ${
                      f.status === "open" ? "bg-destructive/15 text-destructive" :
                      f.status === "fixed" ? "bg-success/15 text-success" :
                      "bg-muted text-muted-foreground"
                    }`}>{f.status}</span>
                    {f.status === "open" && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-6 text-[10px] px-2 gap-1"
                        onClick={() => toast.success(`Marked finding ${f.id} as fixed`)}
                      >
                        <ShieldCheck className="w-3 h-3" /> Resolve
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right column: severity breakdown + scan history */}
        <div className="space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Severity Breakdown" description="Distribution of all findings" />
            <div className="space-y-3">
              {sevCounts.map((s) => {
                const pct = total > 0 ? (s.value / total) * 100 : 0;
                const color = s.name === "Critical" ? "destructive" : s.name === "High" ? "warning" : s.name === "Medium" ? "info" : "muted";
                return (
                  <div key={s.name}>
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-muted-foreground">{s.name}</span>
                      <span className="font-medium tabular-nums">{s.value}</span>
                    </div>
                    <Progress value={pct} className={`h-2 ${
                      color === "destructive" ? "[&_>div]:bg-destructive" :
                      color === "warning" ? "[&_>div]:bg-warning" :
                      color === "info" ? "[&_>div]:bg-info" :
                      "[&_>div]:bg-muted-foreground"
                    }`} />
                  </div>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading
              title="Scan History"
              description="Last 5 scheduled scans"
              action={<History className="w-4 h-4 text-muted-foreground" />}
            />
            <div className="space-y-2">
              {scanHistory.map((s) => (
                <div key={s.id} className="flex items-center gap-3 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors">
                  <div className="shrink-0 w-7 h-7 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
                    <ScanLine className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] font-medium">{s.scope}</div>
                    <div className="text-[10px] text-muted-foreground">{new Date(s.ts).toLocaleString()}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs font-mono tabular-nums">{s.findings}</div>
                    {s.new > 0 && <div className="text-[10px] text-destructive">+{s.new} new</div>}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
