"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  FileCheck, ShieldCheck, AlertTriangle, Calendar, Download,
  ChevronRight, CheckCircle2, XCircle, FileText, FilePlus, Award, TrendingUp,
} from "lucide-react";
import { LineChartCard } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";

interface Framework {
  id: string;
  name: string;
  short: string;
  status: "compliant" | "at_risk" | "non_compliant";
  lastAudit: string;
  nextAudit: string;
  controlsPassing: number;
  controlsFailing: number;
  controlsTotal: number;
  color: string;
}

const frameworks: Framework[] = [
  { id: "soc2", name: "SOC 2 Type II", short: "SOC 2", status: "compliant", lastAudit: "2026-03-15", nextAudit: "2026-09-15", controlsPassing: 84, controlsFailing: 4, controlsTotal: 88, color: "#22D3EE" },
  { id: "iso27001", name: "ISO 27001", short: "ISO", status: "compliant", lastAudit: "2026-02-20", nextAudit: "2027-02-20", controlsPassing: 108, controlsFailing: 9, controlsTotal: 117, color: "#A78BFA" },
  { id: "gdpr", name: "GDPR", short: "GDPR", status: "at_risk", lastAudit: "2026-05-10", nextAudit: "2026-11-10", controlsPassing: 32, controlsFailing: 10, controlsTotal: 42, color: "#F59E0B" },
  { id: "hipaa", name: "HIPAA", short: "HIPAA", status: "compliant", lastAudit: "2026-04-05", nextAudit: "2026-10-05", controlsPassing: 47, controlsFailing: 11, controlsTotal: 58, color: "#34D399" },
  { id: "pci", name: "PCI DSS", short: "PCI", status: "non_compliant", lastAudit: "2026-01-22", nextAudit: "2026-07-22", controlsPassing: 96, controlsFailing: 54, controlsTotal: 150, color: "#F87171" },
];

function statusConfig(s: Framework["status"]) {
  switch (s) {
    case "compliant": return { label: "Compliant", className: "bg-success/15 text-success border-success/30" };
    case "at_risk": return { label: "At Risk", className: "bg-warning/15 text-warning-foreground border-warning/30" };
    case "non_compliant": return { label: "Non-Compliant", className: "bg-destructive/15 text-destructive border-destructive/30" };
  }
}

const trendData = timeSeries(7, 30, 87, 4).map((d) => ({ date: d.date, value: Math.round(d.value * 10) / 10 }));

export default function ComplianceReportsPage() {
  const totalFrameworks = frameworks.length;
  const compliant = frameworks.filter((f) => f.status === "compliant").length;
  const atRisk = frameworks.filter((f) => f.status === "at_risk").length;
  const nonCompliant = frameworks.filter((f) => f.status === "non_compliant").length;
  const totalControls = frameworks.reduce((s, f) => s + f.controlsTotal, 0);
  const passingControls = frameworks.reduce((s, f) => s + f.controlsPassing, 0);
  const overall = Math.round((passingControls / totalControls) * 100);

  return (
    <PageContainer>
      <PageHeader
        title="Compliance Reports"
        description="Track compliance posture across regulatory frameworks. Generate reports for audits and stakeholder reviews."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security", href: "/security" }, { label: "Compliance" }]}
        icon={<FileCheck className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting posture summary...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Report queued", { description: "PDF report will be ready in 2 minutes." })}>
              <FilePlus className="w-3.5 h-3.5" />
              Generate Report
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Frameworks Tracked" value={totalFrameworks} icon={<FileCheck className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Compliant" value={compliant} hint={`${atRisk} at risk`} icon={<ShieldCheck className="w-4 h-4" />} accent="success" />
        <KpiCard label="Overall Score" value={overall} unit="%" delta={3} deltaLabel="vs last month" icon={<Award className="w-4 h-4" />} accent={overall >= 85 ? "success" : "warning"} />
        <KpiCard label="Failing Controls" value={totalControls - passingControls} hint="needs remediation" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
      </div>

      {/* Trend */}
      <LineChartCard
        data={trendData}
        dataKey="value"
        color={3}
        title="Compliance Trend"
        description="Overall control pass rate over time (30 days)"
        suffix="%"
      />

      {/* Framework cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {frameworks.map((f) => {
          const pct = Math.round((f.controlsPassing / f.controlsTotal) * 100);
          const sc = statusConfig(f.status);
          return (
            <Card key={f.id} className="p-5 space-y-4 hover:border-primary/30 transition-colors">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="shrink-0 w-10 h-10 rounded-lg flex items-center justify-center text-xs font-bold" style={{ background: `${f.color}20`, color: f.color, border: `1px solid ${f.color}40` }}>
                    {f.short.slice(0, 4)}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold truncate">{f.name}</h3>
                    <p className="text-[10px] text-muted-foreground">{f.controlsTotal} controls</p>
                  </div>
                </div>
                <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded border font-medium ${sc.className}`}>
                  {sc.label}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Controls passing</span>
                  <span className="font-mono tabular-nums font-medium">{f.controlsPassing} / {f.controlsTotal}</span>
                </div>
                <Progress value={pct} className={`h-2 ${pct >= 90 ? "[&_>div]:bg-success" : pct >= 70 ? "[&_>div]:bg-warning" : "[&_>div]:bg-destructive"}`} />
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>{pct}% passing</span>
                  <span className="text-destructive">{f.controlsFailing} failing</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="space-y-0.5">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Last audit</p>
                  <p className="font-medium">{new Date(f.lastAudit).toLocaleDateString()}</p>
                </div>
                <div className="space-y-0.5">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Next audit</p>
                  <p className="font-medium">{new Date(f.nextAudit).toLocaleDateString()}</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 pt-2 border-t border-border">
                <Button variant="outline" size="sm" className="flex-1 h-7 text-xs gap-1" onClick={() => toast.success(`Generating ${f.name} report`, { description: "PDF will be available in 2 minutes." })}>
                  <FileText className="w-3 h-3" /> Report
                </Button>
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                  Details <ChevronRight className="w-3 h-3" />
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Failed controls breakdown */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Top Failing Controls" description="Controls requiring immediate remediation" />
        <div className="space-y-2">
          {[
            { framework: "PCI DSS", control: "Req 8.2.3 - MFA for all admin access", severity: "critical", owner: "Hannah Wright", dueIn: "12 days" },
            { framework: "PCI DSS", control: "Req 3.4 - PAN encryption at rest", severity: "critical", owner: "Marcus Anderson", dueIn: "12 days" },
            { framework: "GDPR", control: "Art 32 - Encryption of personal data in transit", severity: "high", owner: "Daniel Vargas", dueIn: "45 days" },
            { framework: "HIPAA", control: "164.312(a)(1) - Access control audit logs", severity: "high", owner: "Hannah Wright", dueIn: "60 days" },
            { framework: "SOC 2", control: "CC6.1 - Logical access review frequency", severity: "medium", owner: "Maya Okonkwo", dueIn: "90 days" },
          ].map((c, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors">
              <div className={`shrink-0 w-7 h-7 rounded-md flex items-center justify-center ${
                c.severity === "critical" ? "bg-destructive/10 text-destructive" :
                c.severity === "high" ? "bg-warning/10 text-warning-foreground" :
                "bg-info/10 text-info-foreground"
              }`}>
                <XCircle className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-medium">{c.control}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{c.framework}</span>
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">Owner: {c.owner} · Due in {c.dueIn}</div>
              </div>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.info(`Opening remediation plan for ${c.control.slice(0, 30)}...`)}>
                <TrendingUp className="w-3 h-3" /> Remediate
              </Button>
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
