"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  UserCheck, Clock, CheckCircle2, XCircle, ShieldAlert,
  RefreshCw, Download, ChevronRight, AlertTriangle, Lock, Database, Server, Key, Settings,
} from "lucide-react";
import { people, services } from "@/lib/data";
import { SeverityBadge } from "@/components/common/badges";
import { toast } from "sonner";

interface AccessReview {
  id: string;
  userId: string;
  resource: string;
  resourceType: "service" | "database" | "vault" | "k8s" | "aws";
  currentAccess: "admin" | "write" | "read" | "billing";
  lastReviewed: string;
  reviewerId: string;
  overdue: boolean;
  status: "pending" | "approved" | "revoked";
}

const reviews: AccessReview[] = [
  { id: "ar1", userId: "u6", resource: "checkout-api", resourceType: "service", currentAccess: "admin", lastReviewed: "2026-01-15T00:00:00Z", reviewerId: "u13", overdue: true, status: "pending" },
  { id: "ar2", userId: "u2", resource: "postgres-primary", resourceType: "database", currentAccess: "admin", lastReviewed: "2026-02-08T00:00:00Z", reviewerId: "u1", overdue: true, status: "pending" },
  { id: "ar3", userId: "u16", resource: "vault", resourceType: "vault", currentAccess: "write", lastReviewed: "2026-04-20T00:00:00Z", reviewerId: "u12", overdue: false, status: "pending" },
  { id: "ar4", userId: "u9", resource: "redis-cluster", resourceType: "service", currentAccess: "admin", lastReviewed: "2026-03-10T00:00:00Z", reviewerId: "u3", overdue: true, status: "pending" },
  { id: "ar5", userId: "u5", resource: "k8s-prod-us-east-1", resourceType: "k8s", currentAccess: "write", lastReviewed: "2026-05-01T00:00:00Z", reviewerId: "u3", overdue: false, status: "pending" },
  { id: "ar6", userId: "u7", resource: "payment-ledger", resourceType: "service", currentAccess: "write", lastReviewed: "2026-02-22T00:00:00Z", reviewerId: "u13", overdue: true, status: "pending" },
  { id: "ar7", userId: "u4", resource: "auth-service", resourceType: "service", currentAccess: "admin", lastReviewed: "2026-03-15T00:00:00Z", reviewerId: "u1", overdue: false, status: "pending" },
  { id: "ar8", userId: "u15", resource: "billing-service", resourceType: "service", currentAccess: "admin", lastReviewed: "2026-04-08T00:00:00Z", reviewerId: "u1", overdue: false, status: "pending" },
  { id: "ar9", userId: "u14", resource: "aws-prod", resourceType: "aws", currentAccess: "billing", lastReviewed: "2026-05-20T00:00:00Z", reviewerId: "u12", overdue: false, status: "pending" },
  { id: "ar10", userId: "u8", resource: "kafka-bus", resourceType: "service", currentAccess: "admin", lastReviewed: "2026-06-01T00:00:00Z", reviewerId: "u1", overdue: false, status: "pending" },
];

const recentActions = [
  { id: "ra1", user: "Maya Okonkwo", action: "approved", resource: "users-service", target: "Priya Raman", ts: "2026-07-01T14:20:00Z" },
  { id: "ra2", user: "Hannah Wright", action: "revoked", resource: "vault", target: "Liam Walker", ts: "2026-07-01T10:14:00Z" },
  { id: "ra3", user: "Diego Morales", action: "approved", resource: "checkout-api", target: "Sofia Bianchi", ts: "2026-06-30T18:45:00Z" },
  { id: "ra4", user: "Maya Okonkwo", action: "revoked", resource: "k8s-prod-eu", target: "Theo Lambert", ts: "2026-06-30T09:30:00Z" },
];

function resourceIcon(t: AccessReview["resourceType"]) {
  switch (t) {
    case "service": return <Server className="w-3.5 h-3.5" />;
    case "database": return <Database className="w-3.5 h-3.5" />;
    case "vault": return <Lock className="w-3.5 h-3.5" />;
    case "k8s": return <Server className="w-3.5 h-3.5" />;
    case "aws": return <Key className="w-3.5 h-3.5" />;
  }
}

function accessColor(a: AccessReview["currentAccess"]) {
  switch (a) {
    case "admin": return "bg-destructive/15 text-destructive border-destructive/30";
    case "write": return "bg-warning/15 text-warning-foreground border-warning/30";
    case "read": return "bg-info/15 text-info-foreground border-info/30";
    case "billing": return "bg-accent text-accent-foreground border-accent/30";
  }
}

export default function AccessReviewsPage() {
  const pending = reviews.filter((r) => r.status === "pending").length;
  const overdue = reviews.filter((r) => r.overdue).length;
  const approved30d = 7;
  const revoked30d = 4;

  const [reviewState, setReviewState] = React.useState<Record<string, AccessReview["status"]>>(
    Object.fromEntries(reviews.map((r) => [r.id, r.status]))
  );

  function approve(id: string) {
    setReviewState((s) => ({ ...s, [id]: "approved" }));
    toast.success("Access approved", { description: "Reviewer signature recorded in audit log." });
  }
  function revoke(id: string) {
    setReviewState((s) => ({ ...s, [id]: "revoked" }));
    toast.success("Access revoked", { description: "User removed from resource ACL." });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Access Reviews"
        description="Periodic review of who has access to sensitive resources. Approve or revoke standing privileges."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security", href: "/security" }, { label: "Access Reviews" }]}
        icon={<UserCheck className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Exporting review queue...")}>
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Review cycle started", { description: "Notifying reviewers via email and Slack." })}>
              <RefreshCw className="w-3.5 h-3.5" />
              Start Cycle
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Pending Reviews" value={pending} icon={<UserCheck className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Overdue" value={overdue} hint="past due date" icon={<AlertTriangle className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Approved (30d)" value={approved30d} delta={2} deltaLabel="vs last cycle" icon={<CheckCircle2 className="w-4 h-4" />} accent="success" />
        <KpiCard label="Revoked (30d)" value={revoked30d} delta={-1} deltaLabel="vs last cycle" icon={<XCircle className="w-4 h-4" />} accent="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Pending reviews list */}
        <div className="lg:col-span-2">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Pending Reviews" description="Awaiting reviewer action" />
            <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
              {reviews.map((r) => {
                const user = people.find((p) => p.id === r.userId);
                const reviewer = people.find((p) => p.id === r.reviewerId);
                const st = reviewState[r.id];
                return (
                  <div key={r.id} className={`flex items-start gap-3 p-3 rounded-lg border transition-colors ${
                    st === "approved" ? "bg-success/5 border-success/30" :
                    st === "revoked" ? "bg-destructive/5 border-destructive/30" :
                    r.overdue ? "border-destructive/30 bg-destructive/5" : "hover:bg-muted/40"
                  }`}>
                    <img src={user?.avatarUrl} alt="" className="shrink-0 w-9 h-9 rounded-full object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-medium">{user?.name}</span>
                        <span className="text-[10px] text-muted-foreground">{user?.role}</span>
                        {r.overdue && st === "pending" && (
                          <span className="inline-flex items-center gap-0.5 text-[10px] text-destructive"><AlertTriangle className="w-2.5 h-2.5" /> overdue</span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[11px] flex-wrap">
                        <span className="inline-flex items-center gap-1 text-muted-foreground">
                          {resourceIcon(r.resourceType)}
                          <span className="font-mono">{r.resource}</span>
                        </span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border font-medium capitalize ${accessColor(r.currentAccess)}`}>
                          {r.currentAccess}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
                        <Clock className="w-2.5 h-2.5" />
                        <span>last reviewed {new Date(r.lastReviewed).toLocaleDateString()}</span>
                        <span>·</span>
                        <span>reviewer: {reviewer?.name}</span>
                      </div>
                    </div>
                    <div className="shrink-0">
                      {st === "pending" ? (
                        <div className="flex items-center gap-1.5">
                          <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => approve(r.id)}>
                            <CheckCircle2 className="w-3 h-3" /> Approve
                          </Button>
                          <Button size="sm" variant="destructive" className="h-7 text-xs gap-1" onClick={() => revoke(r.id)}>
                            <XCircle className="w-3 h-3" /> Revoke
                          </Button>
                        </div>
                      ) : (
                        <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-md border font-medium capitalize ${
                          st === "approved" ? "bg-success/15 text-success border-success/30" : "bg-destructive/15 text-destructive border-destructive/30"
                        }`}>
                          {st}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Right: recent actions + by-resource summary */}
        <div className="space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Recent Actions" description="Latest reviewer decisions" />
            <div className="space-y-2">
              {recentActions.map((a) => (
                <div key={a.id} className="flex items-start gap-2 p-2.5 rounded-lg border">
                  <div className={`shrink-0 w-7 h-7 rounded-md flex items-center justify-center ${
                    a.action === "approved" ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
                  }`}>
                    {a.action === "approved" ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px]">
                      <span className="font-medium">{a.user}</span>
                      <span className="text-muted-foreground"> {a.action} access for </span>
                      <span className="font-medium">{a.target}</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{a.resource} · {new Date(a.ts).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Review Posture" description="By resource type" />
            <div className="space-y-2.5">
              {(["service", "database", "vault", "k8s", "aws"] as const).map((t) => {
                const items = reviews.filter((r) => r.resourceType === t);
                const od = items.filter((r) => r.overdue).length;
                return (
                  <div key={t} className="flex items-center justify-between p-2.5 rounded-lg border">
                    <div className="flex items-center gap-2">
                      {resourceIcon(t)}
                      <span className="text-xs font-medium capitalize">{t === "k8s" ? "Kubernetes" : t}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[10px]">
                      <span className="text-muted-foreground">{items.length} reviews</span>
                      {od > 0 && <span className="text-destructive font-medium">{od} overdue</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
