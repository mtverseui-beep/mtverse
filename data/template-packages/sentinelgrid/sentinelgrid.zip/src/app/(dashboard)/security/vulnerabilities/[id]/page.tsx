"use client";

import * as React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  ShieldAlert, Bug, ArrowLeft, ExternalLink, Wrench, Server, Clock,
  CheckCircle2, Circle, GitBranch, FileText, AlertTriangle, Activity,
  User, ChevronRight, History, Zap, Copy,
} from "lucide-react";
import { vulnerabilities, people, services } from "@/lib/data";
import { SeverityBadge } from "@/components/common/badges";
import { RadialGauge } from "@/components/charts";
import { toast } from "sonner";

export default function VulnerabilityDetailsPage() {
  const params = useParams();
  const id = (params?.id as string) || vulnerabilities[0].id;
  const vuln = vulnerabilities.find((v) => v.id === id) || vulnerabilities[0];
  const owner = people.find((p) => p.id === vuln.owner);
  const svc = services.find((s) => s.id === vuln.serviceId);
  const related = vulnerabilities.filter((v) => v.id !== vuln.id && (v.serviceId === vuln.serviceId || v.severity === vuln.severity)).slice(0, 4);

  // Patch history timeline (mock)
  const patchHistory = [
    { ts: vuln.discoveredAt, kind: "Discovered", actor: "Continuous Scanner", detail: "Detected by Trivy image scan" },
    { ts: vuln.discoveredAt, kind: "Triaged", actor: owner?.name || "Security Team", detail: `Severity assigned: ${vuln.severity}` },
  ];
  if (vuln.status === "in_progress") {
    patchHistory.push({ ts: "2026-06-29T10:00:00Z", kind: "Patch in progress", actor: owner?.name || "Engineer", detail: "Started upgrade to patched version" });
  }
  if (vuln.status === "patched" && vuln.patchedAt) {
    patchHistory.push({ ts: vuln.patchedAt, kind: "Patched", actor: owner?.name || "Engineer", detail: "Verified patched version in production" });
  }
  patchHistory.push({ ts: "2026-06-15T08:00:00Z", kind: "Scanned", actor: "Continuous Scanner", detail: "Asset baseline snapshot" });

  // CVSS severity color
  const cvssColor = vuln.cvss >= 9 ? "destructive" : vuln.cvss >= 7 ? "warning" : vuln.cvss >= 4 ? "info" : "muted";
  const cvssPct = (vuln.cvss / 10) * 100;

  function kindIcon(kind: string) {
    if (kind === "Discovered") return <Zap className="w-3.5 h-3.5 text-warning-foreground" />;
    if (kind === "Patched") return <CheckCircle2 className="w-3.5 h-3.5 text-success" />;
    if (kind === "Patch in progress") return <Wrench className="w-3.5 h-3.5 text-info" />;
    if (kind === "Triaged") return <FileText className="w-3.5 h-3.5 text-muted-foreground" />;
    if (kind === "Scanned") return <Activity className="w-3.5 h-3.5 text-muted-foreground" />;
    return <Circle className="w-3.5 h-3.5 text-muted-foreground" />;
  }

  // Remediation steps (mock split)
  const remediationSteps = vuln.remediation.split(". ").filter(Boolean).map((s, i) => ({
    title: `Step ${i + 1}`,
    body: s.endsWith(".") ? s : s + ".",
  }));
  if (remediationSteps.length === 0) remediationSteps.push({ title: "Step 1", body: vuln.remediation });

  // Add a couple of standard steps
  remediationSteps.push({ title: "Step 2", body: "Validate the patched version in staging before promoting to production." });
  remediationSteps.push({ title: "Step 3", body: "Verify the fix with a re-scan and update the vulnerability status to patched." });

  return (
    <PageContainer>
      <PageHeader
        title={vuln.cve}
        description={vuln.title}
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "Security", href: "/security" }, { label: "Vulnerabilities", href: "/security/vulnerabilities" }, { label: vuln.cve }]}
        icon={<Bug className="w-5 h-5" />}
        meta={
          <div className="flex items-center gap-2 flex-wrap">
            <SeverityBadge severity={vuln.severity} size="sm" />
            <span className="text-xs font-mono text-muted-foreground">{vuln.ref}</span>
          </div>
        }
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/security/vulnerabilities"><ArrowLeft className="w-3.5 h-3.5" />Back</Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.info("Opening CVE reference...")}>
              <ExternalLink className="w-3.5 h-3.5" /> NVD
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Marked as in progress", { description: "Patch workflow initiated." })}>
              <Wrench className="w-3.5 h-3.5" /> Start Patch
            </Button>
          </>
        }
      />

      {/* Hero: CVE, severity, CVSS gauge, status */}
      <Card className="p-5 lg:p-6 border-destructive/30">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-6 items-start">
          <div className="space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-md border font-medium capitalize ${
                vuln.status === "open" ? "bg-destructive/15 text-destructive border-destructive/30" :
                vuln.status === "in_progress" ? "bg-warning/15 text-warning-foreground border-warning/30" :
                vuln.status === "patched" ? "bg-success/15 text-success border-success/30" :
                "bg-muted text-muted-foreground border-border"
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${
                  vuln.status === "open" ? "bg-destructive" :
                  vuln.status === "in_progress" ? "bg-warning" :
                  vuln.status === "patched" ? "bg-success" :
                  "bg-muted-foreground"
                }`} />
                {vuln.status.replace("_", " ")}
              </span>
              <span className="text-xs font-mono text-muted-foreground">CVSS {vuln.cvss}</span>
              <span className="text-xs text-muted-foreground">·</span>
              <span className="text-xs text-muted-foreground">Discovered {new Date(vuln.discoveredAt).toLocaleDateString()}</span>
              {vuln.patchedAt && (
                <>
                  <span className="text-xs text-muted-foreground">·</span>
                  <span className="text-xs text-success">Patched {new Date(vuln.patchedAt).toLocaleDateString()}</span>
                </>
              )}
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">{vuln.description}</p>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Owner:</span>
                {owner && (
                  <div className="flex items-center gap-1.5">
                    <img src={owner.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
                    <span className="text-xs font-medium">{owner.name}</span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                <Server className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Asset:</span>
                <span className="text-xs font-mono">{vuln.assetName}</span>
              </div>
              {svc && (
                <div className="flex items-center gap-1.5">
                  <GitBranch className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Service:</span>
                  <Link href={`/services/${svc.id}`} className="text-xs font-mono text-primary hover:underline">{svc.name}</Link>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col items-center gap-2 lg:border-l lg:border-border lg:pl-6">
            <RadialGauge value={cvssPct} target={100} label={`CVSS ${vuln.cvss}`} color={vuln.cvss >= 9 ? 4 : vuln.cvss >= 7 ? 2 : 1} size={140} />
            <span className={`text-[10px] uppercase tracking-wider font-semibold ${
              cvssColor === "destructive" ? "text-destructive" :
              cvssColor === "warning" ? "text-warning-foreground" :
              cvssColor === "info" ? "text-info-foreground" :
              "text-muted-foreground"
            }`}>
              {vuln.cvss >= 9 ? "Critical" : vuln.cvss >= 7 ? "High" : vuln.cvss >= 4 ? "Medium" : "Low"} Severity
            </span>
          </div>
        </div>
      </Card>

      {/* Description + Affected Asset */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-3">
          <SectionHeading title="Description" description="Full technical description of the vulnerability" />
          <Separator />
          <p className="text-sm leading-relaxed">{vuln.description}</p>
          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-border">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Attack vector</p>
              <p className="text-xs font-medium mt-0.5">Network</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Complexity</p>
              <p className="text-xs font-medium mt-0.5">Low</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Authentication</p>
              <p className="text-xs font-medium mt-0.5">None required</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Impact</p>
              <p className="text-xs font-medium mt-0.5">High confidentiality / integrity</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 space-y-3">
          <SectionHeading title="Affected Asset" description="Where this vulnerability was detected" />
          <Separator />
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 rounded-lg border bg-muted/30">
              <div className="shrink-0 w-10 h-10 rounded-md bg-destructive/10 border border-destructive/20 flex items-center justify-center text-destructive">
                <Server className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-mono font-medium truncate">{vuln.assetName}</div>
                <div className="text-[10px] text-muted-foreground">Asset ID: {vuln.assetId}</div>
              </div>
              <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
                <Link href={svc ? `/services/${svc.id}` : "/infrastructure/hosts"}>View<ExternalLink className="w-3 h-3" /></Link>
              </Button>
            </div>
            {svc && (
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Service</span>
                  <Link href={`/services/${svc.id}`} className="font-mono hover:underline">{svc.name}</Link>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Tier</span>
                  <span className="font-medium capitalize">{svc.tier}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Owner</span>
                  <span className="font-medium">{owner?.name || "—"}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Regions</span>
                  <span className="font-medium">{svc.regions.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Repository</span>
                  <span className="font-mono text-[10px]">{svc.repository}</span>
                </div>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Remediation + Patch history */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-4">
          <SectionHeading title="Remediation Steps" description="Recommended path to remediate this CVE" />
          <div className="space-y-3">
            {remediationSteps.map((step, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="shrink-0 w-6 h-6 rounded-full bg-primary/10 border border-primary/20 text-primary text-[11px] font-semibold flex items-center justify-center">
                  {i + 1}
                </div>
                <div className="min-w-0 flex-1 space-y-1">
                  <p className="text-xs font-medium">{step.title}</p>
                  <p className="text-[11px] text-muted-foreground leading-relaxed">{step.body}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="pt-3 border-t border-border">
            <Button variant="outline" size="sm" className="w-full gap-1.5" onClick={() => toast.success("Remediation runbook copied to clipboard")}>
              <Copy className="w-3.5 h-3.5" /> Copy Runbook
            </Button>
          </div>
        </Card>

        <Card className="p-5 space-y-4">
          <SectionHeading title="Patch History" description="Timeline of remediation activity" />
          <div className="space-y-0 relative">
            {patchHistory.map((evt, i) => (
              <div key={i} className="flex items-start gap-3 pb-4 relative">
                {i < patchHistory.length - 1 && (
                  <div className="absolute left-[14px] top-7 bottom-0 w-px bg-border" />
                )}
                <div className="shrink-0 w-7 h-7 rounded-full bg-muted border flex items-center justify-center z-10">
                  {kindIcon(evt.kind)}
                </div>
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium">{evt.kind}</span>
                    <span className="text-[10px] text-muted-foreground">{new Date(evt.ts).toLocaleString()}</span>
                  </div>
                  <p className="text-[11px] text-muted-foreground">{evt.detail}</p>
                  <p className="text-[10px] text-muted-foreground">by {evt.actor}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Related vulnerabilities */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Related Vulnerabilities"
          description="CVEs on the same service or with the same severity"
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {related.map((r) => {
            const rOwner = people.find((p) => p.id === r.owner);
            const rSvc = services.find((s) => s.id === r.serviceId);
            return (
              <Link
                key={r.id}
                href={`/security/vulnerabilities/${r.id}`}
                className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors group"
              >
                <div className="shrink-0 w-9 h-9 rounded-md bg-muted flex items-center justify-center text-muted-foreground">
                  <Bug className="w-4 h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-mono font-medium">{r.cve}</span>
                    <SeverityBadge severity={r.severity} size="sm" />
                  </div>
                  <p className="text-xs mt-1 truncate">{r.title}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {rSvc && <span className="text-[10px] font-mono text-muted-foreground">{rSvc.name}</span>}
                    {rOwner && (
                      <div className="flex items-center gap-1">
                        <img src={rOwner.avatarUrl} alt="" className="w-3.5 h-3.5 rounded-full object-cover" />
                        <span className="text-[10px] text-muted-foreground">{rOwner.name.split(" ")[0]}</span>
                      </div>
                    )}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0 group-hover:translate-x-0.5 transition-transform" />
              </Link>
            );
          })}
        </div>
      </Card>
    </PageContainer>
  );
}
