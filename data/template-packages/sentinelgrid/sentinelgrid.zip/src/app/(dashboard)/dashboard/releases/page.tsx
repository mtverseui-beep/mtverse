"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  GitBranch, Rocket, CheckCircle2, Undo2, Download, Plus, Clock,
  Activity, AlertTriangle, Calendar, ArrowUpRight, GitCommit,
  ChevronRight, ShieldCheck,
} from "lucide-react";
import {
  deployments, changeRequests, services, people, deploymentFrequencyTrend,
} from "@/lib/data";
import { DeploymentFrequencyChart } from "@/components/charts";
import { DeploymentStatusBadge, TierBadge } from "@/components/common/badges";
import type { Deployment, ChangeRequest } from "@/lib/types";

export default function ReleaseManagementDashboardPage() {
  // 7-day releases
  const now = Date.now();
  const weekAgo = now - 7 * 24 * 3600 * 1000;
  const releasesThisWeek = deployments.filter((d) => new Date(d.startedAt).getTime() > weekAgo).length;
  const inFlight = deployments.filter((d) =>
    d.status === "in_progress" || d.status === "rolling_out" || d.status === "canary" || d.status === "queued"
  ).length;
  const pendingApproval = changeRequests.filter((c) => c.status === "in_review").length;
  const rolledBack = deployments.filter((d) => d.status === "rolled_back").length;

  // Release pipeline stages mock (current in-flight deploys)
  const pipelineStages = [
    { name: "Commit", count: 12, status: "succeeded" as const },
    { name: "Build", count: 11, status: "succeeded" as const },
    { name: "Test", count: 10, status: "succeeded" as const },
    { name: "Security Scan", count: 9, status: "succeeded" as const },
    { name: "Staging", count: 8, status: "succeeded" as const },
    { name: "Approval", count: 4, status: "in_progress" as const },
    { name: "Canary 25%", count: 2, status: "in_progress" as const },
    { name: "Canary 50%", count: 1, status: "queued" as const },
    { name: "Production", count: 0, status: "queued" as const },
  ];

  // Release calendar (30 days bar chart)
  const releaseCalendar = deploymentFrequencyTrend().map((d) => ({
    date: d.date,
    deployments: d.deployments,
    failures: d.failures,
  }));

  // Upcoming releases (change requests approved)
  const upcoming = changeRequests
    .filter((c) => c.status === "approved" || c.status === "in_review")
    .sort((a, b) => new Date(a.plannedAt).getTime() - new Date(b.plannedAt).getTime());

  // Recent deployments table
  const columns: Column<Deployment>[] = [
    {
      key: "ref",
      header: "Release",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <GitBranch className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="font-mono text-xs font-medium">{r.ref}</span>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => services.find((s) => s.id === r.serviceId)?.name ?? "",
      cell: (r) => {
        const svc = services.find((s) => s.id === r.serviceId);
        return (
          <div className="flex items-center gap-2">
            {svc && <TierBadge tier={svc.tier} />}
            <span className="text-sm">{svc?.name ?? "—"}</span>
          </div>
        );
      },
    },
    {
      key: "version",
      header: "Version",
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <GitCommit className="w-3 h-3 text-muted-foreground" />
          <span className="font-mono text-xs">{r.version}</span>
        </div>
      ),
    },
    {
      key: "strategy",
      header: "Strategy",
      cell: (r) => <span className="text-xs capitalize">{r.strategy.replace("_", " ")}</span>,
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => <DeploymentStatusBadge status={r.status} />,
    },
    {
      key: "startedAt",
      header: "Started",
      sortable: true,
      sortValue: (r) => r.startedAt,
      cell: (r) => (
        <span className="text-[11px] text-muted-foreground">
          {new Date(r.startedAt).toLocaleDateString()}
        </span>
      ),
      hideOnMobile: true,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Release Management"
        description="Pipeline activity, release calendar, change requests, and deployment governance."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Release Management" }]}
        icon={<GitBranch className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span className="hidden md:inline">This week</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              New Release
            </Button>
          </>
        }
      />

      {/* KPI row - 4 cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Releases This Week"
          value={releasesThisWeek}
          delta={15}
          deltaLabel="vs last week"
          icon={<Rocket className="w-4 h-4" />}
          accent="primary"
          sparkline={[8, 10, 9, 12, 11, 14, 13, 15, 14, 16]}
        />
        <KpiCard
          label="In-Flight"
          value={inFlight}
          hint="currently rolling out"
          icon={<Activity className="w-4 h-4" />}
          accent="info"
        />
        <KpiCard
          label="Pending Approval"
          value={pendingApproval}
          hint="change requests"
          icon={<CheckCircle2 className="w-4 h-4" />}
          accent="warning"
        />
        <KpiCard
          label="Rolled Back"
          value={rolledBack}
          hint="last 30 days"
          icon={<Undo2 className="w-4 h-4" />}
          accent="destructive"
        />
      </div>

      {/* Release pipeline visualization */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Release Pipeline"
          description="Live stage flow for in-flight deployments. Counts represent releases currently in each stage."
        />
        <div className="flex items-stretch gap-2 overflow-x-auto pb-2">
          {pipelineStages.map((stage, i) => (
            <React.Fragment key={stage.name}>
              <div className={`flex-1 min-w-[120px] p-3 rounded-lg border ${
                stage.status === "in_progress" ? "border-info bg-info/5" :
                stage.status === "queued" ? "border-dashed border-muted-foreground/30" :
                "border-border"
              }`}>
                <div className="flex items-center gap-1.5 mb-1">
                  <div className={`w-2 h-2 rounded-full ${
                    stage.status === "succeeded" ? "bg-success" :
                    stage.status === "in_progress" ? "bg-info animate-status-pulse" :
                    "bg-muted-foreground/40"
                  }`} />
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                    {stage.status === "in_progress" ? "Active" : stage.status === "queued" ? "Pending" : "Done"}
                  </span>
                </div>
                <div className="text-xs font-semibold mb-1">{stage.name}</div>
                <div className="text-2xl font-bold tabular-nums">{stage.count}</div>
                <div className="text-[10px] text-muted-foreground">releases</div>
              </div>
              {i < pipelineStages.length - 1 && (
                <div className="flex items-center text-muted-foreground">
                  <ChevronRight className="w-4 h-4" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </Card>

      {/* Release calendar + upcoming releases */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <DeploymentFrequencyChart
          data={releaseCalendar}
          title="Release Calendar"
          description="Deploys and failures per day (last 30 days)"
        />

        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Upcoming Releases"
            description="Scheduled and approved change requests"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/deployments/change-requests">All <ArrowUpRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1 custom-scroll">
            {upcoming.length === 0 ? (
              <div className="text-center py-6 text-sm text-muted-foreground">No upcoming releases</div>
            ) : (
              upcoming.map((cr) => {
                const svc = services.find((s) => s.id === cr.serviceId);
                const requester = people.find((p) => p.id === cr.requesterId);
                return (
                  <Link key={cr.id} href={`/deployments/change-requests/${cr.id}`} className="block p-3 rounded-lg border hover:bg-muted/40 transition-colors">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[10px] font-mono text-muted-foreground">{cr.ref}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                        cr.status === "approved" ? "bg-success/15 text-success" : "bg-warning/15 text-warning-foreground"
                      }`}>{cr.status.replace("_", " ")}</span>
                    </div>
                    <div className="text-xs font-medium truncate">{cr.title}</div>
                    <div className="flex items-center justify-between mt-1 text-[10px] text-muted-foreground">
                      <span>{svc?.name}</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" />
                        {new Date(cr.plannedAt).toLocaleDateString()}
                      </span>
                    </div>
                    {requester && (
                      <div className="flex items-center gap-1.5 mt-1.5 pt-1.5 border-t border-border">
                        <img src={requester.avatarUrl} alt="" className="w-3.5 h-3.5 rounded-full object-cover" />
                        <span className="text-[10px] text-muted-foreground">{requester.name}</span>
                        <span className="text-[10px] text-muted-foreground ml-auto capitalize">
                          <span className={`px-1 py-0.5 rounded ${cr.risk === "high" ? "bg-destructive/15 text-destructive" : cr.risk === "medium" ? "bg-warning/15 text-warning-foreground" : "bg-success/15 text-success"}`}>
                            {cr.risk} risk
                          </span>
                        </span>
                      </div>
                    )}
                  </Link>
                );
              })
            )}
          </div>
        </Card>
      </div>

      {/* Recent releases table */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Recent Releases"
          description="Full history with strategy, status, and timestamps"
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/deployments">All releases <ChevronRight className="w-3 h-3" /></Link></Button>}
        />
        <DataTable
          columns={columns}
          data={deployments}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.ref, (r) => r.version, (r) => services.find((s) => s.id === r.serviceId)?.name ?? ""]}
          searchPlaceholder="Search releases..."
          pageSize={6}
        />
      </Card>

      {/* Change governance summary */}
      <Card className="p-5 space-y-4 border-success/20">
        <SectionHeading title="Change Governance" description="Policy compliance and approval metrics" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Approval Rate</div>
            <div className="text-xl font-bold tabular-nums text-success">94%</div>
            <div className="text-[10px] text-muted-foreground">last 30 days</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Avg Approval Time</div>
            <div className="text-xl font-bold tabular-nums">3.4h</div>
            <div className="text-[10px] text-muted-foreground">from request to approval</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Cab Reviews Required</div>
            <div className="text-xl font-bold tabular-nums">2</div>
            <div className="text-[10px] text-muted-foreground">high-risk changes</div>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Policy Violations</div>
            <div className="text-xl font-bold tabular-nums text-destructive">0</div>
            <div className="text-[10px] text-muted-foreground">last 7 days</div>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
