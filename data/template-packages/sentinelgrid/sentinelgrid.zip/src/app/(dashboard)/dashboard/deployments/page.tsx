"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Rocket, CheckCircle2, AlertTriangle, XCircle, Plus, Download, GitBranch,
  Clock, Timer, Zap, Activity,
} from "lucide-react";
import {
  deployments, services, people, deploymentFrequencyTrend,
} from "@/lib/data";
import { DeploymentFrequencyChart } from "@/components/charts";
import { DeploymentStatusBadge, TierBadge } from "@/components/common/badges";
import type { Deployment } from "@/lib/types";

export default function DeploymentsDashboardPage() {
  const today = new Date();
  const deployData = deploymentFrequencyTrend();

  const deploysToday = deployments.filter((d) => {
    const ds = new Date(d.startedAt);
    return ds.toDateString() === today.toDateString() ||
      (today.getTime() - ds.getTime() < 24 * 60 * 60 * 1000);
  }).length;
  const successful = deployments.filter((d) => d.status === "succeeded").length;
  const failed = deployments.filter((d) => d.status === "failed" || d.status === "rolled_back").length;
  const successRate = Math.round((successful / deployments.length) * 100);
  const avgDuration = Math.round(
    deployments.filter((d) => d.duration > 0).reduce((s, d) => s + d.duration, 0) /
    deployments.filter((d) => d.duration > 0).length / 60
  );
  const changeFailureRate = Math.round((failed / deployments.length) * 100);

  const activeDeployments = deployments.filter((d) =>
    d.status === "in_progress" || d.status === "rolling_out" || d.status === "canary" || d.status === "queued"
  );

  const columns: Column<Deployment>[] = [
    {
      key: "ref",
      header: "Ref",
      sortable: true,
      sortValue: (r) => r.ref,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs font-medium">{r.ref}</span>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => services.find((s) => s.id === r.serviceId)?.name ?? "",
      cell: (r) => {
        const svc = services.find((s) => s.id === r.serviceId);
        return (
          <div className="flex items-center gap-2">
            <div>
              <div className="text-sm font-medium">{svc?.name ?? "—"}</div>
              <div className="text-[10px] text-muted-foreground">{r.environment}</div>
            </div>
          </div>
        );
      },
    },
    {
      key: "version",
      header: "Version",
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <GitBranch className="w-3 h-3 text-muted-foreground" />
          <span className="font-mono text-xs">{r.version}</span>
        </div>
      ),
    },
    {
      key: "strategy",
      header: "Strategy",
      sortable: true,
      sortValue: (r) => r.strategy,
      cell: (r) => <span className="text-xs capitalize">{r.strategy.replace("_", " ")}</span>,
      hideOnMobile: true,
    },
    {
      key: "author",
      header: "Author",
      cell: (r) => {
        const author = people.find((p) => p.id === r.authorId);
        return author ? (
          <div className="flex items-center gap-1.5">
            <img src={author.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate">{author.name}</span>
          </div>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
      hideOnMobile: true,
    },
    {
      key: "duration",
      header: "Duration",
      sortable: true,
      sortValue: (r) => r.duration,
      cell: (r) => (
        <span className="text-xs tabular-nums">
          {r.duration > 0 ? `${Math.floor(r.duration / 60)}m ${r.duration % 60}s` : "—"}
        </span>
      ),
    },
    {
      key: "riskScore",
      header: "Risk",
      sortable: true,
      sortValue: (r) => r.riskScore,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${r.riskScore > 60 ? "bg-destructive" : r.riskScore > 30 ? "bg-warning" : "bg-success"}`} />
          <span className="text-xs tabular-nums">{r.riskScore}</span>
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => <DeploymentStatusBadge status={r.status} />,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Deployments Dashboard"
        description="Real-time deployment pipeline activity, success metrics, and active rollouts across all environments."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Deployments" }]}
        icon={<Rocket className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              Trigger Deploy
            </Button>
          </>
        }
      />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Deploys (24h)"
          value={deploysToday}
          delta={15}
          deltaLabel="vs yesterday"
          icon={<Rocket className="w-4 h-4" />}
          accent="primary"
          sparkline={[8, 12, 10, 14, 11, 13, 15, 12, 14, 13]}
        />
        <KpiCard
          label="Success Rate"
          value={successRate}
          unit="%"
          delta={2}
          deltaLabel="last 7 days"
          icon={<CheckCircle2 className="w-4 h-4" />}
          accent="success"
        />
        <KpiCard
          label="Avg Duration"
          value={avgDuration}
          unit="min"
          delta={-12}
          deltaLabel="faster"
          icon={<Clock className="w-4 h-4" />}
          accent="info"
          sparkline={[18, 17, 16, 18, 15, 14, 16, 15, 14, 13]}
        />
        <KpiCard
          label="Change Failure Rate"
          value={changeFailureRate}
          unit="%"
          delta={1}
          deltaLabel="vs last week"
          icon={<AlertTriangle className="w-4 h-4" />}
          accent={changeFailureRate > 10 ? "destructive" : "warning"}
          sparkline={[6, 8, 7, 9, 8, 10, 9, 8, 9, 8]}
        />
      </div>

      {/* Active deployments + frequency chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Active deployments */}
        <Card className="lg:col-span-2 p-5 space-y-4 border-info/20">
          <SectionHeading
            title="Active Rollouts"
            description="In-progress canaries and rolling deploys with live progress"
            action={<span className="text-xs text-muted-foreground">{activeDeployments.length} active</span>}
          />
          <div className="space-y-3">
            {activeDeployments.length === 0 ? (
              <div className="text-center py-8 text-sm text-muted-foreground">
                <Rocket className="w-6 h-6 mx-auto mb-2 opacity-50" />
                No active rollouts
              </div>
            ) : (
              activeDeployments.map((d) => {
                const svc = services.find((s) => s.id === d.serviceId);
                const author = people.find((p) => p.id === d.authorId);
                const totalStages = d.stages.length;
                const doneStages = d.stages.filter((s) => s.status === "succeeded").length;
                return (
                  <div key={d.id} className="p-4 rounded-lg border bg-card hover:bg-elevated/40 transition-colors">
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="font-mono text-xs font-semibold">{d.ref}</span>
                          <DeploymentStatusBadge status={d.status} />
                          {svc && <TierBadge tier={svc.tier} />}
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <span className="font-medium">{svc?.name}</span>
                          <span className="text-muted-foreground">·</span>
                          <span className="font-mono text-xs">{d.version}</span>
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-1 line-clamp-1">{d.commitMessage}</p>
                      </div>
                      {author && (
                        <img src={author.avatarUrl} alt={author.name} title={author.name} className="w-7 h-7 rounded-full object-cover shrink-0" />
                      )}
                    </div>

                    {/* Stage pipeline */}
                    <div className="flex items-center gap-1 mb-3">
                      {d.stages.map((stage, i) => (
                        <React.Fragment key={i}>
                          <div className="flex flex-col items-center gap-1 flex-1">
                            <div className={`w-full h-1.5 rounded-full ${
                              stage.status === "succeeded" ? "bg-success" :
                              stage.status === "in_progress" ? "bg-info" :
                              stage.status === "failed" ? "bg-destructive" :
                              stage.status === "queued" ? "bg-muted-foreground/30" :
                              "bg-muted"
                            }`} />
                            <span className={`text-[9px] uppercase tracking-wider truncate ${
                              stage.status === "in_progress" ? "text-info-foreground font-medium" : "text-muted-foreground"
                            }`}>
                              {stage.name.split("-").pop()}
                            </span>
                          </div>
                          {i < d.stages.length - 1 && <div className="w-1 shrink-0" />}
                        </React.Fragment>
                      ))}
                    </div>

                    <div className="flex items-center justify-between gap-3 text-[11px]">
                      <div className="flex items-center gap-3">
                        <span className="text-muted-foreground">
                          <span className="text-success font-medium tabular-nums">{doneStages}</span>
                          <span className="mx-0.5">/</span>
                          <span className="tabular-nums">{totalStages}</span> stages
                        </span>
                        <span className="text-muted-foreground">{d.rolloutPercent}% rollout</span>
                        <span className="text-muted-foreground capitalize">{d.strategy.replace("_", " ")}</span>
                      </div>
                      <span className="text-muted-foreground">
                        Started {new Date(d.startedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>

                    {/* Risk indicator */}
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Risk</span>
                      <Progress value={d.riskScore} className="h-1 flex-1" />
                      <span className={`text-[10px] font-mono tabular-nums ${d.riskScore > 60 ? "text-destructive" : d.riskScore > 30 ? "text-warning-foreground" : "text-success"}`}>
                        {d.riskScore}/100
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </Card>

        {/* Frequency chart */}
        <DeploymentFrequencyChart
          data={deployData}
          title="Deployment Frequency"
          description="Successful deploys and failures over 30 days"
        />
      </div>

      {/* Recent deployments table */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Recent Deployments"
          description="Full history with risk scores, authors, and outcomes"
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/deployments">View all <Activity className="w-3 h-3" /></Link></Button>}
        />
        <DataTable
          columns={columns}
          data={deployments}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.ref, (r) => r.version, (r) => services.find((s) => s.id === r.serviceId)?.name ?? ""]}
          searchPlaceholder="Search by ref, version, service..."
          pageSize={6}
          onRowClick={(r) => { window.location.href = `/deployments/${r.id}`; }}
        />
      </Card>
    </PageContainer>
  );
}
