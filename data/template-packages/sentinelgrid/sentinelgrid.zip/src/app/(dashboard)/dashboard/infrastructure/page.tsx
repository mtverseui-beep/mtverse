"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Server, Cpu, HardDrive, MemoryStick, Boxes, Download, RefreshCw,
  Activity, AlertTriangle, TrendingUp, ArrowUpRight,
} from "lucide-react";
import { hosts, k8sClusters, services } from "@/lib/data";
import {
  RadialGauge, LineChartCard, DonutChart,
} from "@/components/charts";
import { timeSeries } from "@/lib/data";

export default function InfrastructureDashboardPage() {
  const totalHosts = hosts.length;
  const runningHosts = hosts.filter((h) => h.status === "running").length;
  const cpuAvg = Math.round(hosts.reduce((s, h) => s + h.cpuUsage, 0) / hosts.length);
  const memAvg = Math.round(hosts.reduce((s, h) => s + h.memoryUsage, 0) / hosts.length);
  const diskAvg = Math.round(hosts.reduce((s, h) => s + h.diskUsage, 0) / hosts.length);
  const totalPods = k8sClusters.reduce((s, c) => s + c.podCount, 0);
  const totalNodes = k8sClusters.reduce((s, c) => s + c.nodeCount, 0);

  // Top hosts by combined resource usage
  const topHosts = [...hosts].sort((a, b) =>
    (b.cpuUsage + b.memoryUsage + b.diskUsage) - (a.cpuUsage + a.memoryUsage + a.diskUsage)
  ).slice(0, 8);

  // CPU trend
  const cpuTrend = timeSeries(11, 24, cpuAvg, 12).map((d) => ({
    date: `${String(Math.floor(Math.random() * 24)).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  }));
  const memTrend = timeSeries(13, 24, memAvg, 10).map((d) => ({
    date: `${String(Math.floor(Math.random() * 24)).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  }));

  // Hosts by provider
  const byProvider = ["aws", "gcp", "azure", "self"].map((p) => ({
    name: p.toUpperCase(),
    value: hosts.filter((h) => h.provider === p).length,
  })).filter((x) => x.value > 0);

  function gaugeColor(value: number): number {
    if (value >= 85) return 4; // destructive
    if (value >= 70) return 2; // warning
    return 3; // success
  }

  const clusterColumns: Column<typeof k8sClusters[number]>[] = [
    {
      key: "name",
      header: "Cluster",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Boxes className="w-3.5 h-3.5 text-primary" />
          <div>
            <div className="text-sm font-medium">{r.name}</div>
            <div className="text-[10px] text-muted-foreground">{r.provider} · v{r.version}</div>
          </div>
        </div>
      ),
    },
    {
      key: "region",
      header: "Region",
      cell: (r) => <span className="text-xs font-mono">{r.region}</span>,
      hideOnMobile: true,
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => (
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${
          r.status === "healthy" ? "text-success" :
          r.status === "warning" ? "text-warning-foreground" :
          "text-destructive"
        }`}>
          <span className={`w-1.5 h-1.5 rounded-full ${
            r.status === "healthy" ? "bg-success" :
            r.status === "warning" ? "bg-warning" :
            "bg-destructive"
          } ${r.status !== "healthy" ? "animate-status-pulse" : ""}`} />
          <span className="capitalize">{r.status}</span>
        </span>
      ),
    },
    {
      key: "nodes",
      header: "Nodes",
      sortable: true,
      sortValue: (r) => r.nodeCount,
      cell: (r) => <span className="text-xs tabular-nums font-mono">{r.nodeCount}</span>,
    },
    {
      key: "pods",
      header: "Pods",
      sortable: true,
      sortValue: (r) => r.podCount,
      cell: (r) => <span className="text-xs tabular-nums font-mono">{r.podCount}</span>,
    },
    {
      key: "cpu",
      header: "CPU",
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-[100px]">
          <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className={r.cpuUsage >= 85 ? "bg-destructive" : r.cpuUsage >= 70 ? "bg-warning" : "bg-success"}
              style={{ width: `${r.cpuUsage}%`, height: "100%" }}
            />
          </div>
          <span className="text-[11px] tabular-nums font-mono w-8 text-right">{r.cpuUsage}%</span>
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "memory",
      header: "Memory",
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-[100px]">
          <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className={r.memoryUsage >= 85 ? "bg-destructive" : r.memoryUsage >= 70 ? "bg-warning" : "bg-success"}
              style={{ width: `${r.memoryUsage}%`, height: "100%" }}
            />
          </div>
          <span className="text-[11px] tabular-nums font-mono w-8 text-right">{r.memoryUsage}%</span>
        </div>
      ),
      hideOnMobile: true,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Infrastructure Dashboard"
        description="Hosts, Kubernetes clusters, and resource utilization across all cloud providers and regions."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Infrastructure" }]}
        icon={<Server className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPI row - 5 cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        <KpiCard
          label="Hosts"
          value={`${runningHosts}/${totalHosts}`}
          hint="running"
          icon={<Server className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="CPU Avg"
          value={cpuAvg}
          unit="%"
          delta={4}
          deltaLabel="vs 1h ago"
          icon={<Cpu className="w-4 h-4" />}
          accent={cpuAvg > 70 ? "warning" : "success"}
          sparkline={[38, 42, 45, 48, 52, 49, 55, 58, 56, 60]}
        />
        <KpiCard
          label="Memory Avg"
          value={memAvg}
          unit="%"
          delta={2}
          deltaLabel="vs 1h ago"
          icon={<MemoryStick className="w-4 h-4" />}
          accent={memAvg > 80 ? "warning" : "success"}
          sparkline={[62, 65, 67, 68, 70, 72, 71, 73, 72, 74]}
        />
        <KpiCard
          label="Disk Avg"
          value={diskAvg}
          unit="%"
          delta={1}
          deltaLabel="vs 1d ago"
          icon={<HardDrive className="w-4 h-4" />}
          accent={diskAvg > 80 ? "destructive" : "info"}
        />
        <KpiCard
          label="K8s Pods"
          value={totalPods.toLocaleString()}
          hint={`${totalNodes} nodes`}
          icon={<Boxes className="w-4 h-4" />}
          accent="accent"
        />
      </div>

      {/* Resource gauges + trend */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 space-y-4">
          <SectionHeading title="Resource Utilization" description="Real-time averages across all hosts" />
          <div className="flex flex-wrap justify-around items-center gap-4 py-2">
            <div className="flex flex-col items-center gap-1">
              <RadialGauge value={cpuAvg} target={100} label="CPU" color={gaugeColor(cpuAvg)} size={140} />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">CPU Avg</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <RadialGauge value={memAvg} target={100} label="Memory" color={gaugeColor(memAvg)} size={140} />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Memory Avg</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <RadialGauge value={diskAvg} target={100} label="Disk" color={gaugeColor(diskAvg)} size={140} />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Disk Avg</span>
            </div>
          </div>
        </Card>

        <LineChartCard
          data={cpuTrend}
          dataKey="value"
          color={2}
          title="CPU Utilization (24h)"
          description="Average CPU across all production hosts"
          suffix="%"
        />

        <LineChartCard
          data={memTrend}
          dataKey="value"
          color={3}
          title="Memory Utilization (24h)"
          description="Average memory across all production hosts"
          suffix="%"
        />
      </div>

      {/* K8s table + Top hosts + Provider donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading
            title="Kubernetes Clusters"
            description="All managed clusters with live resource utilization"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/infrastructure/kubernetes">View all <ArrowUpRight className="w-3 h-3" /></Link></Button>}
          />
          <DataTable
            columns={clusterColumns}
            data={k8sClusters}
            rowKey={(r) => r.id}
            searchKeys={[(r) => r.name, (r) => r.region]}
            searchPlaceholder="Search clusters..."
            pageSize={5}
          />
        </Card>

        <DonutChart
          title="Hosts by Provider"
          description="Distribution across cloud providers"
          data={byProvider}
          centerLabel="Hosts"
          centerValue={String(totalHosts)}
        />
      </div>

      {/* Top hosts by resource usage */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Top Hosts by Resource Usage"
          description="Hosts with highest combined CPU + memory + disk pressure"
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/infrastructure/hosts">All hosts <ArrowUpRight className="w-3 h-3" /></Link></Button>}
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {topHosts.map((h, i) => {
            const svc = services.find((s) => s.id === h.serviceId);
            const combined = h.cpuUsage + h.memoryUsage + h.diskUsage;
            const isCritical = h.cpuUsage >= 80 || h.memoryUsage >= 80 || h.diskUsage >= 80;
            return (
              <Link
                key={h.id}
                href={`/infrastructure/${h.id}`}
                className={`flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors ${isCritical ? "border-destructive/30 bg-destructive/5" : ""}`}
              >
                <div className={`shrink-0 w-8 h-8 rounded-md flex items-center justify-center text-xs font-bold tabular-nums ${isCritical ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground"}`}>
                  #{i + 1}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className="text-xs font-mono truncate">{h.hostname}</span>
                    {isCritical && <AlertTriangle className="w-3 h-3 text-destructive shrink-0" />}
                  </div>
                  <div className="text-[10px] text-muted-foreground">{svc?.name} · {h.region} · {h.instanceType}</div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-center">
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">CPU</div>
                    <div className={`text-xs font-mono font-medium tabular-nums ${h.cpuUsage >= 80 ? "text-destructive" : h.cpuUsage >= 60 ? "text-warning-foreground" : "text-success"}`}>
                      {h.cpuUsage}%
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Mem</div>
                    <div className={`text-xs font-mono font-medium tabular-nums ${h.memoryUsage >= 80 ? "text-destructive" : h.memoryUsage >= 60 ? "text-warning-foreground" : "text-success"}`}>
                      {h.memoryUsage}%
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Disk</div>
                    <div className={`text-xs font-mono font-medium tabular-nums ${h.diskUsage >= 80 ? "text-destructive" : h.diskUsage >= 60 ? "text-warning-foreground" : "text-success"}`}>
                      {h.diskUsage}%
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </Card>
    </PageContainer>
  );
}
