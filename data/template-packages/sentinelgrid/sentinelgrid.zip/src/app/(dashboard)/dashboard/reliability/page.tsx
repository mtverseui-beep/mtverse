"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  ShieldCheck, Target, Clock, TrendingUp, Wallet, ArrowUpRight, Download,
  AlertTriangle, Activity, Gauge, Calendar,
} from "lucide-react";
import {
  slos, services, uptimeForService, dashboardStats, mttrTrend,
} from "@/lib/data";
import {
  SLOComplianceChart, UptimeHeatmap, MTTRTrendChart, LineChartCard,
} from "@/components/charts";
import { SLOStatusBadge, TierBadge, ServiceHealthBadge } from "@/components/common/badges";
import type { Service, SLO } from "@/lib/types";

export default function ReliabilityDashboardPage() {
  const stats = dashboardStats();

  // Build per-service SLO compliance chart data
  const sloComplianceData = slos.map((s) => ({
    name: services.find((svc) => svc.id === s.serviceId)?.name ?? s.ref,
    value: s.current,
  }));

  // Uptime heatmap for the busiest tier-1 service
  const heatmapData = uptimeForService("s1", 90).map((u) => ({
    date: u.date,
    uptime: u.uptime,
    incidents: u.incidents,
  }));

  // Scorecards table
  type Scorecard = Service & {
    slo?: SLO;
    uptime: number;
    errorBudgetPct: number;
    trend: number;
  };
  const scorecards: Scorecard[] = services.map((s) => {
    const slo = slos.find((sl) => sl.id === s.sloId);
    return {
      ...s,
      slo,
      uptime: s.uptime30d,
      errorBudgetPct: slo ? slo.errorBudget.remaining : 100,
      trend: Math.random() > 0.5 ? Math.random() * 2 : -Math.random() * 2,
    };
  });

  const columns: Column<Scorecard>[] = [
    {
      key: "name",
      header: "Service",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <div>
            <div className="font-medium text-sm">{r.name}</div>
            <div className="text-[10px] text-muted-foreground">{r.framework}</div>
          </div>
        </div>
      ),
    },
    {
      key: "tier",
      header: "Tier",
      sortable: true,
      sortValue: (r) => r.tier,
      cell: (r) => <TierBadge tier={r.tier} />,
    },
    {
      key: "health",
      header: "Health",
      cell: (r) => <ServiceHealthBadge health={r.health} />,
    },
    {
      key: "uptime",
      header: "Uptime 30d",
      sortable: true,
      sortValue: (r) => r.uptime,
      cell: (r) => (
        <span className={`font-mono tabular-nums text-sm ${r.uptime >= 99.9 ? "text-success" : r.uptime >= 99 ? "text-warning-foreground" : "text-destructive"}`}>
          {r.uptime.toFixed(3)}%
        </span>
      ),
    },
    {
      key: "slo",
      header: "SLO",
      cell: (r) => r.slo ? <SLOStatusBadge status={r.slo.status} /> : <span className="text-xs text-muted-foreground">—</span>,
    },
    {
      key: "errorBudget",
      header: "Error Budget",
      sortable: true,
      sortValue: (r) => r.errorBudgetPct,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-[120px]">
          <Progress
            value={r.errorBudgetPct}
            className="h-2 flex-1"
          />
          <span className={`text-xs tabular-nums font-medium w-9 text-right ${r.errorBudgetPct > 50 ? "text-success" : r.errorBudgetPct > 20 ? "text-warning-foreground" : "text-destructive"}`}>
            {r.errorBudgetPct.toFixed(0)}%
          </span>
        </div>
      ),
    },
    {
      key: "p95",
      header: "p95",
      sortable: true,
      sortValue: (r) => r.p95LatencyMs,
      cell: (r) => <span className="text-xs tabular-nums">{r.p95LatencyMs}ms</span>,
      hideOnMobile: true,
    },
    {
      key: "trend",
      header: "Trend",
      cell: (r) => (
        <span className={`inline-flex items-center gap-0.5 text-xs tabular-nums ${r.trend >= 0 ? "text-success" : "text-destructive"}`}>
          <TrendingUp className={`w-3 h-3 ${r.trend < 0 && "rotate-180"}`} />
          {Math.abs(r.trend).toFixed(2)}%
        </span>
      ),
      hideOnMobile: true,
    },
  ];

  const mttrData = mttrTrend();
  const availabilityTrend = mttrTrend().map((d) => ({
    date: d.date,
    value: 99.9 + (Math.random() - 0.5) * 0.08,
  }));

  const avgUptime = (services.reduce((s, x) => s + x.uptime30d, 0) / services.length);
  const errorBudgetRemaining = Math.round(slos.reduce((s, x) => s + x.errorBudget.remaining, 0) / slos.length);
  const sloCompliancePct = Math.round((slos.filter((s) => s.status === "healthy").length / slos.length) * 100);

  // Customer impact calc
  const impactedUsers = services.reduce((s, x) => s + (x.health !== "operational" ? x.requestsPerSecond * 0.001 : 0), 0);
  const impactedServices = services.filter((s) => s.health !== "operational").length;

  return (
    <PageContainer>
      <PageHeader
        title="Reliability Dashboard"
        description="Cross-service reliability posture, SLO compliance, error budget health, and uptime trends."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Reliability" }]}
        icon={<ShieldCheck className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Last 30 days</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Avg Uptime (30d)"
          value={avgUptime.toFixed(3)}
          unit="%"
          delta={0.04}
          deltaLabel="vs prev 30d"
          icon={<Activity className="w-4 h-4" />}
          accent="success"
          sparkline={[99.92, 99.94, 99.96, 99.95, 99.97, 99.98, 99.99, 99.98, 99.99, 99.99]}
        />
        <KpiCard
          label="Error Budget Remaining"
          value={errorBudgetRemaining}
          unit="%"
          delta={-6}
          deltaLabel="vs last week"
          icon={<Wallet className="w-4 h-4" />}
          accent={errorBudgetRemaining > 50 ? "success" : "warning"}
        />
        <KpiCard
          label="SLO Compliance"
          value={sloCompliancePct}
          unit="%"
          hint={`${slos.filter((s) => s.status === "healthy").length}/${slos.length} healthy`}
          icon={<Target className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="MTTR (30d)"
          value={stats.mttr30d}
          unit="min"
          delta={-8}
          deltaLabel="improving"
          icon={<Clock className="w-4 h-4" />}
          accent="info"
          sparkline={[24, 22, 21, 19, 18, 17, 18, 19, 18, 18]}
        />
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <SLOComplianceChart
          data={sloComplianceData}
          title="SLO Compliance by Service"
          description="Current SLI value vs target"
          target={99.5}
        />
        <LineChartCard
          data={availabilityTrend}
          dataKey="value"
          color={3}
          title="Composite Availability"
          description="Weighted availability across tier-1 services"
          suffix="%"
        />
        <MTTRTrendChart
          data={mttrData}
          title="MTTR / MTTD / MTTA"
          description="30-day incident response performance"
        />
      </div>

      {/* Uptime heatmap */}
      <UptimeHeatmap
        data={heatmapData}
        title="Availability Calendar - api-gateway"
        description="Daily uptime for the last 90 days (green = 100%, red = degraded)"
      />

      {/* Scorecards + Customer impact */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <Card className="lg:col-span-3 p-5 space-y-4">
          <SectionHeading
            title="Reliability Scorecards"
            description="Per-service reliability posture with tier, SLO, and error budget"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/reliability/scorecards">View all <ArrowUpRight className="w-3 h-3" /></Link></Button>}
          />
          <DataTable
            columns={columns}
            data={scorecards}
            rowKey={(r) => r.id}
            searchKeys={[(r) => r.name]}
            searchPlaceholder="Search services..."
            pageSize={8}
            onRowClick={(r) => window.location.href = `/services/${r.id}`}
          />
        </Card>

        <Card className="p-5 space-y-4 border-warning/20 bg-warning/5">
          <SectionHeading title="Customer Impact" description="Current state" />
          <div className="space-y-4">
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Impacted Services</div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl font-bold tabular-nums text-warning-foreground">{impactedServices}</span>
                <span className="text-xs text-muted-foreground">/ {services.length}</span>
              </div>
            </div>
            <div className="pt-3 border-t border-border">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Est. Users Affected</div>
              <div className="text-2xl font-bold tabular-nums">
                {Math.round(impactedUsers).toLocaleString()}
              </div>
              <div className="text-[11px] text-muted-foreground mt-0.5">per second, approx</div>
            </div>
            <div className="pt-3 border-t border-border">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Degraded Services</div>
              <div className="space-y-2 max-h-44 overflow-y-auto pr-1 custom-scroll">
                {services.filter((s) => s.health !== "operational").map((s) => (
                  <Link key={s.id} href={`/services/${s.id}`} className="block p-2 rounded-md border hover:bg-muted/40 transition-colors">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-medium truncate">{s.name}</span>
                      <ServiceHealthBadge health={s.health} />
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-muted-foreground mt-1">
                      <span className="font-mono">{s.uptime30d.toFixed(3)}% uptime</span>
                      <span>{s.p95LatencyMs}ms p95</span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
