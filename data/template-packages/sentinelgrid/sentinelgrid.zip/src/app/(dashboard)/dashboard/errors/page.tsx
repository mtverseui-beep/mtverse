"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Bug, Users, GitCommit, Activity, Download, Filter, Clock,
  AlertTriangle, TrendingUp, ChevronRight, ArrowUpRight,
} from "lucide-react";
import { errors, services, people } from "@/lib/data";
import {
  ErrorRateChart, DonutChart, LineChartCard,
} from "@/components/charts";
import { timeSeries } from "@/lib/data";

export default function ErrorTrackingDashboardPage() {
  const openErrors = errors.filter((e) => e.status === "unresolved" || e.status === "in_progress");
  const regressions = errors.filter((e) => e.isRegression);
  const totalAffectedUsers = errors.reduce((s, e) => s + e.userCount, 0);
  const totalEvents = errors.reduce((s, e) => s + e.eventCount, 0);
  const errorRate = (totalEvents / 1000000 * 100).toFixed(2);

  // Error trend chart
  const errorTrend = timeSeries(8, 30, 120, 60).map((d) => ({
    timestamp: d.date,
    value: Math.max(0, Math.round(d.value)),
  }));

  // Errors by service distribution
  const errorsByService = services.map((s) => {
    const count = errors.filter((e) => e.serviceId === s.id).reduce((sum, e) => sum + e.eventCount, 0);
    return { name: s.name, value: count };
  }).filter((x) => x.value > 0).sort((a, b) => b.value - a.value);

  // Top error groups
  const topErrors = [...errors].sort((a, b) => b.eventCount - a.eventCount);

  // Daily error events sparkline
  const dailyErrorsSpark = [42, 48, 38, 62, 84, 128, 156, 142, 168, 184];

  function timeAgo(dateStr: string) {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    return `${mins}m ago`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Error Tracking"
        description="Real-time error monitoring, regression detection, and impact analysis across all services."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Error Tracking" }]}
        icon={<Bug className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Production</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPI row - 4 cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Open Errors"
          value={openErrors.length}
          hint={`${errors.length} total groups`}
          icon={<Bug className="w-4 h-4" />}
          accent="destructive"
          sparkline={[3, 5, 4, 6, 4, 5, 3, 4, 5, 4]}
        />
        <KpiCard
          label="Affected Users"
          value={totalAffectedUsers.toLocaleString()}
          delta={18}
          deltaLabel="vs yesterday"
          icon={<Users className="w-4 h-4" />}
          accent="warning"
        />
        <KpiCard
          label="Regressions"
          value={regressions.length}
          hint="from latest release"
          icon={<GitCommit className="w-4 h-4" />}
          accent="destructive"
        />
        <KpiCard
          label="Error Rate"
          value={errorRate}
          unit="%"
          delta={0.3}
          deltaLabel="last hour"
          icon={<Activity className="w-4 h-4" />}
          accent={Number(errorRate) > 1 ? "destructive" : "warning"}
          sparkline={[0.4, 0.5, 0.6, 0.8, 1.2, 1.4, 1.5, 1.3, 1.4, 1.5]}
        />
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ErrorRateChart
          data={errorTrend}
          title="Error Event Trend"
          description="Daily error events across all production services (30d)"
        />
        <DonutChart
          title="Errors by Service"
          description="Distribution of error events by service"
          data={errorsByService}
          centerLabel="Events"
          centerValue={totalEvents.toLocaleString()}
        />
        <Card className="p-5 space-y-4 border-destructive/20 bg-destructive/5">
          <SectionHeading title="Regressions" description="Errors introduced by recent releases" />
          <div className="space-y-3">
            {regressions.length === 0 ? (
              <div className="text-center py-6 text-sm text-muted-foreground">No regressions detected</div>
            ) : (
              regressions.map((err) => {
                const svc = services.find((s) => s.id === err.serviceId);
                return (
                  <Link key={err.id} href={`/errors/${err.id}`} className="block p-3 rounded-lg border hover:bg-muted/40 transition-colors">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-[10px] font-mono text-muted-foreground">{err.ref}</span>
                      <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-destructive/15 text-destructive border border-destructive/30 font-medium uppercase">
                        <AlertTriangle className="w-2.5 h-2.5" />
                        Regression
                      </span>
                      {err.releaseId && (
                        <span className="text-[10px] text-muted-foreground font-mono">{err.releaseId}</span>
                      )}
                    </div>
                    <div className="text-xs font-medium truncate">{err.message}</div>
                    <div className="flex items-center justify-between mt-1.5 text-[10px] text-muted-foreground">
                      <span>{svc?.name}</span>
                      <span>{err.eventCount.toLocaleString()} events</span>
                    </div>
                  </Link>
                );
              })
            )}
          </div>
        </Card>
      </div>

      {/* Top error groups list */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Top Error Groups"
          description="Ranked by event count. Click any group to view stack trace and recent events."
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/errors">View all <ChevronRight className="w-3 h-3" /></Link></Button>}
        />
        <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1 custom-scroll">
          {topErrors.map((err) => {
            const svc = services.find((s) => s.id === err.serviceId);
            const assignee = err.assigneeId ? people.find((p) => p.id === err.assigneeId) : null;
            return (
              <Link
                key={err.id}
                href={`/errors/${err.id}`}
                className="block p-3 rounded-lg border hover:bg-muted/40 transition-colors group"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-1 h-12 rounded-full shrink-0 ${err.status === "resolved" ? "bg-success" : err.isRegression ? "bg-destructive" : "bg-warning"}`} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-[10px] font-mono text-muted-foreground">{err.ref}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                        err.status === "unresolved" ? "bg-destructive/15 text-destructive" :
                        err.status === "in_progress" ? "bg-warning/15 text-warning-foreground" :
                        err.status === "resolved" ? "bg-success/15 text-success" :
                        "bg-muted text-muted-foreground"
                      }`}>{err.status.replace("_", " ")}</span>
                      {err.isRegression && (
                        <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-destructive/15 text-destructive border border-destructive/30 font-medium uppercase">
                          <AlertTriangle className="w-2.5 h-2.5" /> Regression
                        </span>
                      )}
                      <span className="text-[10px] text-muted-foreground">{err.type}</span>
                    </div>
                    <div className="text-sm font-medium truncate group-hover:text-primary transition-colors">{err.message}</div>
                    <div className="flex items-center gap-4 mt-1 text-[11px] text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Bug className="w-3 h-3" />
                        {svc?.name}
                      </span>
                      <span className="flex items-center gap-1">
                        <Activity className="w-3 h-3" />
                        {err.eventCount.toLocaleString()} events
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {err.userCount.toLocaleString()} users
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {timeAgo(err.lastSeen)}
                      </span>
                      {err.releaseId && (
                        <span className="flex items-center gap-1">
                          <GitCommit className="w-3 h-3" />
                          <span className="font-mono">{err.releaseId}</span>
                        </span>
                      )}
                    </div>
                  </div>
                  {/* Mini trend sparkline */}
                  <div className="shrink-0 hidden md:block">
                    <div className="flex items-end gap-0.5 h-8 w-24">
                      {err.trend.slice(-12).map((v, i) => (
                        <div
                          key={i}
                          className="flex-1 rounded-sm bg-destructive/40"
                          style={{ height: `${Math.max(8, Math.min(100, (v / Math.max(...err.trend)) * 100))}%` }}
                        />
                      ))}
                    </div>
                  </div>
                  {assignee && (
                    <img src={assignee.avatarUrl} alt={assignee.name} title={assignee.name} className="w-7 h-7 rounded-full object-cover shrink-0" />
                  )}
                  <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground shrink-0 group-hover:text-primary transition-colors" />
                </div>
              </Link>
            );
          })}
        </div>
      </Card>
    </PageContainer>
  );
}
