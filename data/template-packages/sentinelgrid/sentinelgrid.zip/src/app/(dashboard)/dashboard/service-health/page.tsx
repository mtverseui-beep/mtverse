"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Server, ShieldCheck, AlertTriangle, ShieldAlert, Activity,
  Download, RefreshCw, ArrowUpRight, Zap, Cpu, AlertOctagon,
} from "lucide-react";
import { services, timeSeries, uptimeForService } from "@/lib/data";
import { ServiceHealthBadge, TierBadge, StatusDot } from "@/components/common/badges";
import { LineChartCard } from "@/components/charts";

export default function ServiceHealthDashboardPage() {
  const operational = services.filter((s) => s.health === "operational").length;
  const degraded = services.filter((s) => s.health === "degraded").length;
  const partialOutage = services.filter((s) => s.health === "partial" || s.health === "major").length;
  const avgHealthScore = Math.round(services.reduce((s, x) => s + x.healthScore, 0) / services.length);

  // Build a per-service sparkline from uptime history (last 14 days)
  function sparklineFor(svcId: string) {
    return uptimeForService(svcId, 14).map((u) => u.uptime);
  }

  // Overall health trend
  const healthTrend = timeSeries(5, 30, 96, 4).map((d) => ({
    date: d.date,
    value: Math.round(d.value * 10) / 10,
  }));

  // Health matrix data
  const healthMatrix = services.map((s) => ({
    service: s,
    uptimeHistory: sparklineFor(s.id),
  }));

  function healthColor(score: number) {
    if (score >= 95) return "bg-success";
    if (score >= 80) return "bg-info";
    if (score >= 60) return "bg-warning";
    return "bg-destructive";
  }

  function sparklinePath(data: number[], w = 60, h = 20) {
    const max = Math.max(...data, 100);
    const min = Math.min(...data, 95);
    const range = max - min || 1;
    return data.map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = h - ((v - min) / range) * h;
      return `${i === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`;
    }).join(" ");
  }

  return (
    <PageContainer>
      <PageHeader
        title="Service Health"
        description="Real-time health posture of all production services with uptime sparklines and reliability metrics."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Service Health" }]}
        icon={<Activity className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPI row - 4 cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Operational"
          value={operational}
          hint={`of ${services.length} services`}
          icon={<ShieldCheck className="w-4 h-4" />}
          accent="success"
        />
        <KpiCard
          label="Degraded"
          value={degraded}
          hint="performance impacted"
          icon={<AlertTriangle className="w-4 h-4" />}
          accent="warning"
        />
        <KpiCard
          label="Partial Outage"
          value={partialOutage}
          hint="requires attention"
          icon={<ShieldAlert className="w-4 h-4" />}
          accent="destructive"
        />
        <KpiCard
          label="Avg Health Score"
          value={avgHealthScore}
          unit="/100"
          delta={2}
          deltaLabel="vs last week"
          icon={<Activity className="w-4 h-4" />}
          accent="primary"
          sparkline={[88, 90, 89, 91, 92, 91, 93, 94, 93, 94]}
        />
      </div>

      {/* Color-coded health matrix banner */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Health Matrix"
          description="At-a-glance color-coded status for every service. Hover for details."
        />
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-11 gap-2">
          {services.map((s) => (
            <Link
              key={s.id}
              href={`/services/${s.id}`}
              className="group flex flex-col items-center gap-1 p-2 rounded-lg border hover:bg-muted/40 transition-colors"
              title={`${s.name}: ${s.healthScore}/100`}
            >
              <div className={`w-full h-2 rounded-full ${healthColor(s.healthScore)}`} />
              <span className="text-[10px] font-medium text-center truncate w-full">{s.name}</span>
              <span className="text-[9px] text-muted-foreground tabular-nums">{s.healthScore}</span>
            </Link>
          ))}
        </div>
        <div className="flex items-center gap-4 text-[10px] text-muted-foreground pt-2 border-t border-border">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-success" /> 95-100</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-info" /> 80-94</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-warning" /> 60-79</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-destructive" /> &lt;60</span>
        </div>
      </Card>

      {/* Service cards grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {healthMatrix.map(({ service: s, uptimeHistory }) => (
          <Card key={s.id} className="p-5 space-y-4 hover:bg-elevated/40 transition-colors">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <TierBadge tier={s.tier} />
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{s.language}</span>
                </div>
                <h3 className="text-sm font-semibold truncate">{s.name}</h3>
                <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{s.description}</p>
              </div>
              <ServiceHealthBadge health={s.health} />
            </div>

            <div className="flex items-center gap-3">
              {/* Sparkline */}
              <svg width={80} height={28} className="shrink-0">
                <path
                  d={sparklinePath(uptimeHistory, 80, 28)}
                  fill="none"
                  stroke={s.health === "operational" ? "#34D399" : s.health === "degraded" ? "#FCD34D" : "#F87171"}
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <div className="text-right ml-auto">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Uptime 14d</div>
                <div className={`text-sm font-mono tabular-nums font-medium ${s.uptime30d >= 99.9 ? "text-success" : s.uptime30d >= 99 ? "text-warning-foreground" : "text-destructive"}`}>
                  {s.uptime30d.toFixed(3)}%
                </div>
              </div>
            </div>

            {/* Health score bar */}
            <div>
              <div className="flex items-center justify-between text-[10px] mb-1">
                <span className="text-muted-foreground uppercase tracking-wider">Health Score</span>
                <span className="font-mono tabular-nums font-medium">{s.healthScore}/100</span>
              </div>
              <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                <div
                  className={`h-full ${healthColor(s.healthScore)}`}
                  style={{ width: `${s.healthScore}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-border">
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">p95</div>
                <div className={`text-xs font-mono tabular-nums font-medium ${s.p95LatencyMs > 200 ? "text-destructive" : s.p95LatencyMs > 100 ? "text-warning-foreground" : "text-success"}`}>
                  {s.p95LatencyMs}ms
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Err Rate</div>
                <div className={`text-xs font-mono tabular-nums font-medium ${s.errorRate > 1 ? "text-destructive" : s.errorRate > 0.1 ? "text-warning-foreground" : "text-success"}`}>
                  {s.errorRate}%
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">RPS</div>
                <div className="text-xs font-mono tabular-nums font-medium">
                  {s.requestsPerSecond > 0 ? s.requestsPerSecond.toLocaleString() : "—"}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center gap-2">
                {s.openIncidents > 0 && (
                  <span className="inline-flex items-center gap-1 text-destructive">
                    <AlertOctagon className="w-3 h-3" />
                    {s.openIncidents} incident{s.openIncidents > 1 ? "s" : ""}
                  </span>
                )}
                {s.openAlerts > 0 && (
                  <span className="inline-flex items-center gap-1 text-warning-foreground">
                    <Zap className="w-3 h-3" />
                    {s.openAlerts} alert{s.openAlerts > 1 ? "s" : ""}
                  </span>
                )}
              </div>
              <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
                <Link href={`/services/${s.id}`}>
                  Details <ArrowUpRight className="w-3 h-3" />
                </Link>
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {/* Aggregate health trend */}
      <LineChartCard
        data={healthTrend}
        dataKey="value"
        color={3}
        title="Composite Health Score Trend"
        description="Average health score across all services (30d)"
        suffix="/100"
      />
    </PageContainer>
  );
}
