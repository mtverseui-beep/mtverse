"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Phone, Bell, Clock, Activity, Download, RefreshCw, MessageSquare,
  Zap, TrendingDown, Calendar, ChevronRight, AlertTriangle,
} from "lucide-react";
import {
  onCallShifts, people, alerts, teams, services, timeSeries,
} from "@/lib/data";
import { LineChartCard } from "@/components/charts";
import { SeverityBadge, AlertStatusBadge } from "@/components/common/badges";

export default function OnCallDashboardPage() {
  const now = Date.now();

  const currentShifts = onCallShifts.filter((s) => {
    return new Date(s.start).getTime() < now && new Date(s.end).getTime() > now;
  });

  // Pages today (alerts that triggered paging)
  const pagesToday = alerts.length;
  const avgResponseTime = 4.2; // minutes
  const fatigueScore = 22;

  // Build a 7-day schedule grid
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - 3 + i);
    return d;
  });

  const dayLabels = ["3 days ago", "2 days ago", "Yesterday", "Today", "Tomorrow", "+2 days", "+3 days"];
  const todayIdx = 3;

  // Generate 7-day shifts by extending current shifts
  const scheduleByDay = days.map((day, dayIdx) => {
    const dayStart = new Date(day);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(day);
    dayEnd.setHours(23, 59, 59, 999);
    // Pull from current onCallShifts and synthesize some
    const baseShifts = onCallShifts.filter((s) => {
      const sStart = new Date(s.start);
      return sStart >= dayStart && sStart <= dayEnd;
    });
    // If no shifts for this day, synthesize from people
    if (baseShifts.length === 0) {
      const primary = people[(dayIdx + 4) % people.length];
      const secondary = people[(dayIdx + 7) % people.length];
      return [
        { id: `syn-${dayIdx}-1`, userId: primary.id, teamId: "t1", role: "primary" as const, start: dayStart.toISOString(), end: new Date(dayStart.getTime() + 12 * 3600 * 1000).toISOString() },
        { id: `syn-${dayIdx}-2`, userId: secondary.id, teamId: "t2", role: "secondary" as const, start: new Date(dayStart.getTime() + 12 * 3600 * 1000).toISOString(), end: dayEnd.toISOString() },
      ];
    }
    return baseShifts;
  });

  // Recent pages (alerts that have been firing/acknowledged)
  const recentPages = alerts.slice(0, 8);

  // Fatigue trend
  const fatigueTrend = timeSeries(21, 30, fatigueScore, 8).map((d) => ({
    date: d.date,
    value: Math.round(d.value),
  }));

  // Response time trend
  const responseTrend = timeSeries(23, 30, avgResponseTime, 1.5).map((d) => ({
    date: d.date,
    value: Number(d.value.toFixed(1)),
  }));

  return (
    <PageContainer>
      <PageHeader
        title="On-Call Dashboard"
        description="Current on-call coverage, paging activity, response metrics, and 7-day rotation schedule."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "On-Call" }]}
        icon={<Phone className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPI row - 4 cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Current On-Call"
          value={currentShifts.length}
          hint="engineers paged"
          icon={<Phone className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="Pages Today"
          value={pagesToday}
          delta={-12}
          deltaLabel="vs yesterday"
          icon={<Bell className="w-4 h-4" />}
          accent="warning"
          sparkline={[4, 6, 5, 8, 6, 9, 7, 5, 6, 7]}
        />
        <KpiCard
          label="Avg Response Time"
          value={avgResponseTime}
          unit="min"
          delta={-8}
          deltaLabel="improving"
          icon={<Clock className="w-4 h-4" />}
          accent="success"
          sparkline={[5.8, 5.4, 5.1, 4.8, 4.6, 4.4, 4.3, 4.2, 4.1, 4.2]}
        />
        <KpiCard
          label="Fatigue Score"
          value={fatigueScore}
          unit="/100"
          hint={fatigueScore < 30 ? "low" : fatigueScore < 60 ? "moderate" : "high"}
          icon={<Activity className="w-4 h-4" />}
          accent={fatigueScore < 30 ? "success" : fatigueScore < 60 ? "warning" : "destructive"}
        />
      </div>

      {/* Current on-call prominent card + recent pages */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Large current on-call card */}
        <Card className="lg:col-span-2 p-6 space-y-4 border-primary/20 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent">
          <SectionHeading title="On-Call Now" description="Currently paged engineers across all teams" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {currentShifts.length === 0 ? (
              <div className="md:col-span-2 text-center py-8 text-sm text-muted-foreground">
                <Phone className="w-6 h-6 mx-auto mb-2 opacity-50" />
                No active on-call shifts
              </div>
            ) : (
              currentShifts.slice(0, 4).map((shift) => {
                const user = people.find((p) => p.id === shift.userId);
                const team = teams.find((t) => t.id === shift.teamId);
                if (!user) return null;
                const end = new Date(shift.end);
                const hoursLeft = Math.max(0, (end.getTime() - now) / 3600000);
                return (
                  <div key={shift.id} className="p-4 rounded-lg border bg-card/80 backdrop-blur">
                    <div className="flex items-start gap-3">
                      <div className="relative shrink-0">
                        <img src={user.avatarUrl} alt={user.name} className="w-14 h-14 rounded-full object-cover ring-2 ring-primary" />
                        <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-success border-2 border-background animate-status-pulse" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-semibold truncate">{user.name}</span>
                        </div>
                        <div className="text-[11px] text-muted-foreground">{team?.name ?? user.team}</div>
                        <div className="flex items-center gap-1.5 mt-1.5">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium uppercase tracking-wider ${
                            shift.role === "primary" ? "bg-primary/15 text-primary border border-primary/30" :
                            shift.role === "secondary" ? "bg-accent text-accent-foreground border border-accent/30" :
                            "bg-muted text-muted-foreground border border-border"
                          }`}>{shift.role}</span>
                          {shift.isOverride && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-warning/15 text-warning-foreground border border-warning/30 font-medium uppercase tracking-wider">
                              Override
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-border flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">Shift ends in</span>
                      <span className="font-mono font-medium tabular-nums">
                        {Math.floor(hoursLeft)}h {Math.floor((hoursLeft % 1) * 60)}m
                      </span>
                    </div>
                    <div className="flex gap-1.5 mt-2">
                      <Button size="sm" variant="default" className="flex-1 h-7 text-xs gap-1">
                        <Phone className="w-3 h-3" /> Page
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1 h-7 text-xs gap-1">
                        <MessageSquare className="w-3 h-3" /> Message
                      </Button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </Card>

        {/* Fatigue trend */}
        <LineChartCard
          data={fatigueTrend}
          dataKey="value"
          color={2}
          title="On-Call Fatigue Score"
          description="Rolling 30-day index (lower is better)"
        />
      </div>

      {/* 7-day schedule grid */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="7-Day On-Call Schedule"
          description="Upcoming rotations across all teams. Click any cell for details."
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/oncall/calendar">Full calendar <ChevronRight className="w-3 h-3" /></Link></Button>}
        />
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          {scheduleByDay.map((dayShifts, dayIdx) => (
            <div
              key={dayIdx}
              className={`p-3 rounded-lg border min-h-[180px] ${
                dayIdx === todayIdx ? "border-primary bg-primary/5" : "border-border"
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                  {dayLabels[dayIdx]}
                </span>
                {dayIdx === todayIdx && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-primary text-primary-foreground font-semibold uppercase">
                    Now
                  </span>
                )}
              </div>
              <div className="text-xs font-semibold mb-2">
                {days[dayIdx].toLocaleDateString([], { month: "short", day: "numeric" })}
              </div>
              <div className="space-y-2">
                {dayShifts.slice(0, 3).map((shift) => {
                  const user = people.find((p) => p.id === shift.userId);
                  if (!user) return null;
                  return (
                    <div key={shift.id} className="flex items-center gap-1.5 p-1.5 rounded border bg-card">
                      <img src={user.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover shrink-0" />
                      <div className="min-w-0 flex-1">
                        <div className="text-[10px] font-medium truncate">{user.name.split(" ")[0]}</div>
                        <div className="text-[9px] text-muted-foreground capitalize">{shift.role}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Recent pages + response time trend */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading
            title="Recent Pages"
            description="Most recent paging alerts with response status"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/alerts">Alert inbox <ChevronRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1 custom-scroll">
            {recentPages.map((a) => {
              const svc = services.find((s) => s.id === a.serviceId);
              const ackedBy = a.acknowledgedBy ? people.find((p) => p.id === a.acknowledgedBy) : null;
              return (
                <Link key={a.id} href={`/alerts/${a.id}`} className="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors">
                  <div className={`shrink-0 w-1 self-stretch rounded-full ${a.severity === "critical" ? "bg-destructive" : a.severity === "high" ? "bg-warning" : "bg-info"}`} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] font-mono text-muted-foreground">{a.ref}</span>
                      <SeverityBadge severity={a.severity} size="sm" />
                      <AlertStatusBadge status={a.status} />
                    </div>
                    <div className="text-xs font-medium mt-1 truncate">{a.message}</div>
                    <div className="flex items-center gap-3 mt-1 text-[10px] text-muted-foreground">
                      <span>{svc?.name}</span>
                      <span>Started {new Date(a.startedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                      {ackedBy && (
                        <span className="flex items-center gap-1">
                          acked by
                          <img src={ackedBy.avatarUrl} alt="" className="w-3 h-3 rounded-full object-cover" />
                          {ackedBy.name.split(" ")[0]}
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>

        <LineChartCard
          data={responseTrend}
          dataKey="value"
          color={3}
          title="Response Time Trend"
          description="Average time to acknowledge pages (30d, minutes)"
          suffix=" min"
        />
      </div>
    </PageContainer>
  );
}
