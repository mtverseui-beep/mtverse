"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Target, CheckCircle2, AlertTriangle, ShieldX, Plus, Download, Filter,
  Flame, TrendingUp, Activity,
} from "lucide-react";
import { slos, services, timeSeries } from "@/lib/data";
import { BurnRateChart } from "@/components/charts";
import { SLOStatusBadge, TierBadge } from "@/components/common/badges";

export default function SLODashboardPage() {
  const totalSLOs = slos.length;
  const healthy = slos.filter((s) => s.status === "healthy").length;
  const atRisk = slos.filter((s) => s.status === "at_risk").length;
  const breached = slos.filter((s) => s.status === "breached" || s.status === "exhausted").length;

  // Find highest-burn SLO for the burn rate chart
  const highestBurnSLO = [...slos].sort((a, b) => b.errorBudget.burnRate - a.errorBudget.burnRate)[0];
  const burnRateTrend = timeSeries(7, 24, highestBurnSLO.errorBudget.burnRate, highestBurnSLO.errorBudget.burnRate * 0.4).map((d) => ({
    timestamp: d.date,
    value: Math.max(0, d.value),
  }));

  function statusColor(status: string) {
    switch (status) {
      case "healthy": return "border-success/30 bg-success/5";
      case "at_risk": return "border-warning/30 bg-warning/5";
      case "breached":
      case "exhausted": return "border-destructive/30 bg-destructive/5";
      default: return "border-border";
    }
  }

  return (
    <PageContainer>
      <PageHeader
        title="SLO Dashboard"
        description="Service-level objective posture, error budget consumption, and burn rate across all services."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "SLO Dashboard" }]}
        icon={<Target className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="w-3.5 h-3.5" />
              <span className="hidden md:inline">All services</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              New SLO
            </Button>
          </>
        }
      />

      {/* KPI row - 4 cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Total SLOs"
          value={totalSLOs}
          hint="across 9 services"
          icon={<Target className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="Healthy"
          value={healthy}
          hint={`${Math.round((healthy / totalSLOs) * 100)}% of total`}
          icon={<CheckCircle2 className="w-4 h-4" />}
          accent="success"
        />
        <KpiCard
          label="At Risk"
          value={atRisk}
          hint="burn rate elevated"
          icon={<AlertTriangle className="w-4 h-4" />}
          accent="warning"
          sparkline={[1, 2, 1, 2, 3, 2, 2, 1, 2, 2]}
        />
        <KpiCard
          label="Breached"
          value={breached}
          hint="budget exhausted"
          icon={<ShieldX className="w-4 h-4" />}
          accent="destructive"
          sparkline={[0, 1, 0, 1, 1, 1, 1, 0, 1, 1]}
        />
      </div>

      {/* Highest burn chart + summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <BurnRateChart
          data={burnRateTrend}
          threshold={14.4}
          title={`Highest Burn Rate - ${highestBurnSLO.ref}`}
          description={`${highestBurnSLO.name} · burn rate ${highestBurnSLO.errorBudget.burnRate}x (threshold 14.4x)`}
        />
        <Card className="p-5 space-y-4 border-destructive/20 bg-destructive/5">
          <SectionHeading title="Critical SLOs" description="Require immediate attention" />
          <div className="space-y-3">
            {slos.filter((s) => s.status === "breached" || s.status === "at_risk").map((slo) => {
              const svc = services.find((s) => s.id === slo.serviceId);
              return (
                <Link key={slo.id} href={`/reliability/slos`} className="block p-3 rounded-lg border hover:bg-muted/40 transition-colors">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-mono text-muted-foreground">{slo.ref}</span>
                    <SLOStatusBadge status={slo.status} />
                  </div>
                  <div className="text-sm font-medium truncate">{slo.name}</div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">{svc?.name} · {slo.window}</div>
                  <div className="grid grid-cols-3 gap-2 mt-2 text-[10px]">
                    <div>
                      <div className="text-muted-foreground">Target</div>
                      <div className="font-mono font-medium">{slo.target}%</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Current</div>
                      <div className="font-mono font-medium">{slo.current}%</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Burn</div>
                      <div className="font-mono font-medium text-destructive">{slo.errorBudget.burnRate}x</div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>
      </div>

      {/* SLO cards grid */}
      <SectionHeading
        title="All SLOs"
        description="Click any SLO to view detailed error budget breakdown"
        action={<span className="text-xs text-muted-foreground">{slos.length} objectives</span>}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {slos.map((slo) => {
          const svc = services.find((s) => s.id === slo.serviceId);
          const remainingPct = slo.errorBudget.remaining;
          const consumedPct = slo.errorBudget.consumed;
          const isHealthy = slo.status === "healthy";
          const isBreached = slo.status === "breached" || slo.status === "exhausted";
          return (
            <Card key={slo.id} className={`p-5 space-y-4 transition-colors hover:bg-elevated/40 ${statusColor(slo.status)}`}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[11px] font-mono text-muted-foreground">{slo.ref}</span>
                    {svc && <TierBadge tier={svc.tier} />}
                  </div>
                  <h3 className="text-sm font-semibold leading-tight">{slo.name}</h3>
                  <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-1">{slo.description}</p>
                </div>
                <SLOStatusBadge status={slo.status} />
              </div>

              <div className="flex items-baseline justify-between gap-2">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Current SLI</div>
                  <div className="flex items-baseline gap-1">
                    <span className={`text-2xl font-bold tabular-nums ${isBreached ? "text-destructive" : isHealthy ? "text-success" : "text-warning-foreground"}`}>
                      {slo.current}%
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Target</div>
                  <div className="text-lg font-semibold tabular-nums">{slo.target}%</div>
                </div>
              </div>

              {/* Error budget progress */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-muted-foreground">Error budget</span>
                  <span className="font-medium tabular-nums">
                    {remainingPct.toFixed(0)}% remaining
                  </span>
                </div>
                <div className="relative h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className={`absolute inset-y-0 left-0 ${isBreached ? "bg-destructive" : isHealthy ? "bg-success" : "bg-warning"}`}
                    style={{ width: `${Math.max(0, Math.min(100, remainingPct))}%` }}
                  />
                  <div
                    className="absolute inset-y-0 right-0 bg-muted-foreground/30"
                    style={{ width: `${Math.max(0, Math.min(100, consumedPct))}%`, left: "auto" }}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>Burn rate: <span className={`font-mono font-medium ${slo.errorBudget.burnRate > 6 ? "text-destructive" : ""}`}>{slo.errorBudget.burnRate}x</span></span>
                  <span>Window: {slo.window}</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-border text-[11px]">
                <span className="text-muted-foreground truncate flex-1">{svc?.name}</span>
                <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1 shrink-0">
                  <Link href="/reliability/slos">
                    Details
                    <TrendingUp className="w-3 h-3" />
                  </Link>
                </Button>
              </div>
            </Card>
          );
        })}
      </div>
    </PageContainer>
  );
}
