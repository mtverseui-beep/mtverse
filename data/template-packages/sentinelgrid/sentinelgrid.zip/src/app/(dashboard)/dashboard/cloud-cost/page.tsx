"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  DollarSign, TrendingUp, TrendingDown, AlertTriangle, Download,
  Calendar, ArrowUpRight, Wallet, Gauge, Activity,
} from "lucide-react";
import { services, timeSeries } from "@/lib/data";
import { VolumeChart, HorizontalBarChart, DonutChart } from "@/components/charts";
import { Column, DataTable } from "@/components/tables/data-table";

interface CostAnomaly {
  id: string;
  service: string;
  region: string;
  expected: number;
  actual: number;
  delta: number;
  detectedAt: string;
  reason: string;
}

export default function CloudCostDashboardPage() {
  // Mock cost data (inline generation)
  const monthlySpend = 184250;
  const dailyAvg = Math.round(monthlySpend / 30);
  const projectedEOM = Math.round(monthlySpend * 1.12);
  const costPerService = Math.round(monthlySpend / services.length);

  // Cost trend (30 days)
  const costTrend = timeSeries(7, 30, dailyAvg, 1200).map((d) => ({
    timestamp: d.date,
    value: Math.round(d.value),
  }));

  // Cost by service (mock)
  const costByService = services
    .map((s, i) => ({
      name: s.name,
      value: Math.round(monthlySpend * (0.18 - i * 0.012) + Math.random() * 2000),
    }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);

  // Cost by region (mock)
  const costByRegion = [
    { name: "us-east-1", value: Math.round(monthlySpend * 0.42) },
    { name: "eu-west-1", value: Math.round(monthlySpend * 0.24) },
    { name: "ap-south-1", value: Math.round(monthlySpend * 0.14) },
    { name: "us-west-2", value: Math.round(monthlySpend * 0.10) },
    { name: "eu-central-1", value: Math.round(monthlySpend * 0.06) },
    { name: "ap-southeast-2", value: Math.round(monthlySpend * 0.04) },
  ];

  // Anomalies (mock)
  const anomalies: CostAnomaly[] = [
    {
      id: "ca1",
      service: "checkout-api",
      region: "us-east-1",
      expected: 4200,
      actual: 7820,
      delta: 86,
      detectedAt: "2026-07-02T03:14:00Z",
      reason: "Auto-scaling group scaled to 18 instances during incident. Recovery lag kept instances running 4h longer than expected.",
    },
    {
      id: "ca2",
      service: "postgres-primary",
      region: "us-east-1",
      expected: 12400,
      actual: 14100,
      delta: 14,
      detectedAt: "2026-07-01T18:42:00Z",
      reason: "Provisioned additional r6i.8xlarge replica for read scaling.",
    },
    {
      id: "ca3",
      service: "web-app",
      region: "global",
      expected: 2800,
      actual: 3920,
      delta: 40,
      detectedAt: "2026-07-01T14:18:00Z",
      reason: "Increased CDN egress after v4.2 hero image deploy (4.2MB image).",
    },
    {
      id: "ca4",
      service: "kafka-bus",
      region: "us-east-1",
      expected: 6800,
      actual: 7200,
      delta: 6,
      detectedAt: "2026-06-30T09:00:00Z",
      reason: "Sustained throughput increase from billing-service backlog.",
    },
  ];

  const anomalyColumns: Column<CostAnomaly>[] = [
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => r.service,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5 text-warning-foreground" />
          <span className="text-sm font-medium">{r.service}</span>
        </div>
      ),
    },
    {
      key: "region",
      header: "Region",
      cell: (r) => <span className="text-xs font-mono">{r.region}</span>,
      hideOnMobile: true,
    },
    {
      key: "expected",
      header: "Expected",
      sortable: true,
      sortValue: (r) => r.expected,
      cell: (r) => <span className="text-xs tabular-nums font-mono">${r.expected.toLocaleString()}</span>,
    },
    {
      key: "actual",
      header: "Actual",
      sortable: true,
      sortValue: (r) => r.actual,
      cell: (r) => <span className="text-xs tabular-nums font-mono">${r.actual.toLocaleString()}</span>,
    },
    {
      key: "delta",
      header: "Delta",
      sortable: true,
      sortValue: (r) => r.delta,
      cell: (r) => (
        <span className={`inline-flex items-center gap-0.5 text-xs font-medium tabular-nums ${r.delta > 30 ? "text-destructive" : "text-warning-foreground"}`}>
          <TrendingUp className="w-3 h-3" />
          +{r.delta}%
        </span>
      ),
    },
    {
      key: "reason",
      header: "Reason",
      cell: (r) => <span className="text-xs text-muted-foreground line-clamp-1">{r.reason}</span>,
      hideOnMobile: true,
    },
  ];

  const monthOverMonth = ((projectedEOM - monthlySpend) / monthlySpend) * 100;

  return (
    <PageContainer>
      <PageHeader
        title="Cloud Cost Dashboard"
        description="Multi-cloud spend tracking, anomaly detection, and per-service cost attribution."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Cloud Cost" }]}
        icon={<DollarSign className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              <span className="hidden md:inline">July 2026</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPI row - 4 cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Monthly Spend (MTD)"
          value={`$${(monthlySpend / 1000).toFixed(1)}k`}
          delta={8}
          deltaLabel="vs last month"
          icon={<DollarSign className="w-4 h-4" />}
          accent="primary"
          sparkline={[5.2, 5.4, 5.5, 5.6, 5.8, 6.0, 6.1, 6.2, 6.3, 6.4]}
        />
        <KpiCard
          label="Daily Average"
          value={`$${dailyAvg.toLocaleString()}`}
          delta={3}
          deltaLabel="vs 30d avg"
          icon={<Activity className="w-4 h-4" />}
          accent="info"
        />
        <KpiCard
          label="Projected EOM"
          value={`$${(projectedEOM / 1000).toFixed(1)}k`}
          delta={monthOverMonth}
          deltaLabel="vs MTD"
          icon={<TrendingUp className="w-4 h-4" />}
          accent={monthOverMonth > 10 ? "destructive" : "warning"}
        />
        <KpiCard
          label="Cost / Service"
          value={`$${costPerService.toLocaleString()}`}
          hint={`avg across ${services.length} services`}
          icon={<Wallet className="w-4 h-4" />}
          accent="accent"
        />
      </div>

      {/* Cost trend area chart */}
      <VolumeChart
        data={costTrend}
        color={1}
        title="Daily Spend Trend"
        description="Cloud spend over the last 30 days (USD)"
        unit=" USD"
      />

      {/* Cost by service + region */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <HorizontalBarChart
            data={costByService}
            color={0}
            title="Cost by Service"
            description="Top 8 services by monthly spend (USD)"
          />
        </div>
        <DonutChart
          title="Cost by Region"
          description="Spend distribution across cloud regions"
          data={costByRegion}
          centerLabel="Total"
          centerValue={`$${(monthlySpend / 1000).toFixed(0)}k`}
        />
      </div>

      {/* Anomalies + budget summary */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <Card className="lg:col-span-3 p-5 space-y-4 border-warning/20">
          <SectionHeading
            title="Cost Anomalies"
            description="Detected spend deviations requiring investigation"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/admin/billing">Billing <ArrowUpRight className="w-3 h-3" /></Link></Button>}
          />
          <DataTable
            columns={anomalyColumns}
            data={anomalies}
            rowKey={(r) => r.id}
            searchKeys={[(r) => r.service, (r) => r.region]}
            searchPlaceholder="Search anomalies..."
            pageSize={5}
          />
        </Card>

        <Card className="p-5 space-y-4">
          <SectionHeading title="Budget Status" description="Monthly budget posture" />
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">Budget Used</span>
                <span className="font-medium tabular-nums">{Math.round((monthlySpend / 220000) * 100)}%</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-primary"
                  style={{ width: `${Math.round((monthlySpend / 220000) * 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                <span>${(monthlySpend / 1000).toFixed(1)}k spent</span>
                <span>$220k budget</span>
              </div>
            </div>

            <div className="pt-3 border-t border-border space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Compute</span>
                <span className="font-medium tabular-nums">${(monthlySpend * 0.48 / 1000).toFixed(1)}k</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Storage</span>
                <span className="font-medium tabular-nums">${(monthlySpend * 0.18 / 1000).toFixed(1)}k</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Network</span>
                <span className="font-medium tabular-nums">${(monthlySpend * 0.14 / 1000).toFixed(1)}k</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Database</span>
                <span className="font-medium tabular-nums">${(monthlySpend * 0.12 / 1000).toFixed(1)}k</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Other</span>
                <span className="font-medium tabular-nums">${(monthlySpend * 0.08 / 1000).toFixed(1)}k</span>
              </div>
            </div>

            <div className="pt-3 border-t border-border">
              <div className="flex items-center gap-2 text-xs">
                <Gauge className="w-3.5 h-3.5 text-warning-foreground" />
                <span className="text-muted-foreground">Forecast: over budget by</span>
                <span className="font-medium text-destructive tabular-nums">${((projectedEOM - 220000) / 1000).toFixed(1)}k</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
