"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Gauge, Timer, TrendingUp, Activity, Zap, Download, Server,
  ArrowDownRight, ArrowUpRight,
} from "lucide-react";
import { services, multiTimeSeries, timeSeries } from "@/lib/data";
import {
  LatencyChart, VolumeChart, LineChartCard, ComposedChartCard,
} from "@/components/charts";
import { TierBadge } from "@/components/common/badges";

interface EndpointMetric {
  id: string;
  path: string;
  method: string;
  service: string;
  p50: number;
  p95: number;
  p99: number;
  throughput: number;
  errorRate: number;
  trend: number;
}

export default function PerformanceDashboardPage() {
  // Latency percentile data
  const latencyData = multiTimeSeries(2, 24, [
    { name: "p50", base: 35, variance: 8 },
    { name: "p95", base: 120, variance: 30 },
    { name: "p99", base: 280, variance: 60 },
  ]).map((d) => ({
    timestamp: `${String(Math.floor(Math.random() * 24)).padStart(2, "0")}:00`,
    p50: Number(d.p50),
    p95: Number(d.p95),
    p99: Number(d.p99),
  }));

  // Throughput area chart
  const throughputData = timeSeries(3, 24, 40000, 12000).map((d) => ({
    timestamp: `${String(Math.floor(Math.random() * 24)).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  }));

  // Apdex trend
  const apdexData = timeSeries(5, 30, 0.94, 0.04).map((d) => ({
    date: d.date,
    value: Number(d.value.toFixed(3)),
  }));

  // Composed: throughput + latency overlay
  const composedData = multiTimeSeries(9, 30, [
    { name: "throughput", base: 42000, variance: 10000 },
    { name: "p95", base: 130, variance: 35 },
  ]).map((d) => ({
    date: String(d.date),
    throughput: Number(d.throughput),
    p95: Number(d.p95),
  }));

  // Slowest endpoints (mock inline)
  const endpoints: EndpointMetric[] = [
    { id: "e1", path: "/api/v1/checkout/process", method: "POST", service: "checkout-api", p50: 142, p95: 312, p99: 890, throughput: 940, errorRate: 1.4, trend: 18 },
    { id: "e2", path: "/api/v1/invoices/generate", method: "POST", service: "billing-service", p50: 88, p95: 240, p99: 612, throughput: 320, errorRate: 0.21, trend: 4 },
    { id: "e3", path: "/api/v1/users/profile", method: "GET", service: "api-gateway", p50: 22, p95: 68, p99: 142, throughput: 12400, errorRate: 0.02, trend: -8 },
    { id: "e4", path: "/api/v1/auth/token", method: "POST", service: "auth-service", p50: 18, p95: 52, p99: 98, throughput: 8900, errorRate: 0.04, trend: -3 },
    { id: "e5", path: "/api/v1/ledger/entries", method: "POST", service: "payment-ledger", p50: 64, p95: 184, p99: 412, throughput: 320, errorRate: 0.05, trend: 12 },
    { id: "e6", path: "/api/v1/webhooks/dispatch", method: "POST", service: "api-gateway", p50: 38, p95: 110, p99: 268, throughput: 1800, errorRate: 0.18, trend: 6 },
    { id: "e7", path: "/api/v1/sessions/refresh", method: "POST", service: "auth-service", p50: 12, p95: 34, p99: 72, throughput: 6800, errorRate: 0.01, trend: -2 },
    { id: "e8", path: "/api/v1/cache/invalidate", method: "POST", service: "redis-cluster", p50: 2, p95: 6, p99: 14, throughput: 2400, errorRate: 0, trend: 0 },
    { id: "e9", path: "/api/v1/notifications/send", method: "POST", service: "api-gateway", p50: 48, p95: 142, p99: 312, throughput: 980, errorRate: 0.22, trend: 9 },
    { id: "e10", path: "/api/v1/reports/generate", method: "GET", service: "billing-service", p50: 220, p95: 580, p99: 1240, throughput: 80, errorRate: 0.42, trend: 22 },
  ];

  const columns: Column<EndpointMetric>[] = [
    {
      key: "path",
      header: "Endpoint",
      sortable: true,
      sortValue: (r) => r.path,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-medium ${
            r.method === "GET" ? "bg-info/15 text-info-foreground" :
            r.method === "POST" ? "bg-success/15 text-success" :
            r.method === "PUT" ? "bg-warning/15 text-warning-foreground" :
            "bg-destructive/15 text-destructive"
          }`}>{r.method}</span>
          <span className="font-mono text-xs">{r.path}</span>
        </div>
      ),
    },
    {
      key: "service",
      header: "Service",
      sortable: true,
      sortValue: (r) => r.service,
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <Server className="w-3 h-3 text-muted-foreground" />
          <span className="text-xs">{r.service}</span>
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "p50",
      header: "p50",
      sortable: true,
      sortValue: (r) => r.p50,
      cell: (r) => <span className="font-mono text-xs tabular-nums">{r.p50}ms</span>,
    },
    {
      key: "p95",
      header: "p95",
      sortable: true,
      sortValue: (r) => r.p95,
      cell: (r) => (
        <span className={`font-mono text-xs tabular-nums font-medium ${r.p95 > 200 ? "text-destructive" : r.p95 > 100 ? "text-warning-foreground" : "text-success"}`}>
          {r.p95}ms
        </span>
      ),
    },
    {
      key: "p99",
      header: "p99",
      sortable: true,
      sortValue: (r) => r.p99,
      cell: (r) => <span className="font-mono text-xs tabular-nums">{r.p99}ms</span>,
      hideOnMobile: true,
    },
    {
      key: "throughput",
      header: "Throughput",
      sortable: true,
      sortValue: (r) => r.throughput,
      cell: (r) => (
        <span className="font-mono text-xs tabular-nums">{r.throughput.toLocaleString()}/s</span>
      ),
    },
    {
      key: "errorRate",
      header: "Err Rate",
      sortable: true,
      sortValue: (r) => r.errorRate,
      cell: (r) => (
        <span className={`font-mono text-xs tabular-nums ${r.errorRate > 1 ? "text-destructive" : r.errorRate > 0.1 ? "text-warning-foreground" : "text-success"}`}>
          {r.errorRate}%
        </span>
      ),
      hideOnMobile: true,
    },
    {
      key: "trend",
      header: "Trend",
      sortable: true,
      sortValue: (r) => r.trend,
      cell: (r) => (
        <span className={`inline-flex items-center gap-0.5 text-xs tabular-nums ${r.trend > 0 ? "text-destructive" : r.trend < 0 ? "text-success" : "text-muted-foreground"}`}>
          {r.trend > 0 ? <ArrowUpRight className="w-3 h-3" /> : r.trend < 0 ? <ArrowDownRight className="w-3 h-3" /> : null}
          {Math.abs(r.trend)}%
        </span>
      ),
    },
  ];

  // Aggregate KPIs
  const totalThroughput = services.reduce((s, x) => s + x.requestsPerSecond, 0);
  const avgP50 = Math.round(endpoints.reduce((s, e) => s + e.p50, 0) / endpoints.length);
  const avgP95 = Math.round(endpoints.reduce((s, e) => s + e.p95, 0) / endpoints.length);
  const avgP99 = Math.round(endpoints.reduce((s, e) => s + e.p99, 0) / endpoints.length);
  const apdex = 0.94;

  return (
    <PageContainer>
      <PageHeader
        title="Performance Dashboard"
        description="Latency percentiles, throughput, Apdex score, and slowest endpoints across the platform."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Performance" }]}
        icon={<Gauge className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Timer className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Last 24h</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPI row - 5 cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        <KpiCard
          label="p50 Latency"
          value={avgP50}
          unit="ms"
          delta={-4}
          deltaLabel="vs avg"
          icon={<Gauge className="w-4 h-4" />}
          accent="success"
          sparkline={[48, 46, 44, 42, 40, 38, 36, 35, 34, 33]}
        />
        <KpiCard
          label="p95 Latency"
          value={avgP95}
          unit="ms"
          delta={6}
          deltaLabel="regression"
          icon={<Timer className="w-4 h-4" />}
          accent="warning"
          sparkline={[110, 115, 108, 122, 118, 125, 120, 128, 122, 125]}
        />
        <KpiCard
          label="p99 Latency"
          value={avgP99}
          unit="ms"
          delta={12}
          deltaLabel="regression"
          icon={<Activity className="w-4 h-4" />}
          accent="destructive"
          sparkline={[240, 250, 268, 280, 290, 275, 295, 310, 305, 290]}
        />
        <KpiCard
          label="Apdex Score"
          value={apdex.toFixed(2)}
          hint="target: 0.94"
          icon={<Zap className="w-4 h-4" />}
          accent={apdex >= 0.94 ? "success" : "warning"}
        />
        <KpiCard
          label="Throughput"
          value={(totalThroughput / 1000).toFixed(1)}
          unit="k/s"
          delta={8}
          deltaLabel="vs yesterday"
          icon={<TrendingUp className="w-4 h-4" />}
          accent="primary"
          sparkline={[68, 72, 70, 75, 73, 78, 76, 80, 78, 82]}
        />
      </div>

      {/* Latency chart + Apdex trend */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <LatencyChart
          data={latencyData}
          title="API Latency Percentiles"
          description="p50 / p95 / p99 across all gateway routes (24h)"
        />
        <LineChartCard
          data={apdexData}
          dataKey="value"
          color={3}
          title="Apdex Trend"
          description="Application performance index (30d, target 0.94)"
        />
      </div>

      {/* Throughput + composed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <VolumeChart
          data={throughputData}
          color={0}
          title="Throughput Volume"
          description="Requests per second across all production services (24h)"
          unit="/s"
        />
        <ComposedChartCard
          data={composedData}
          bars={[{ key: "throughput", name: "Throughput", color: 0 }]}
          lines={[{ key: "p95", name: "p95 (ms)", color: 2 }]}
          title="Throughput vs Latency"
          description="Request volume against p95 latency correlation (30d)"
        />
      </div>

      {/* Slowest endpoints table */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Slowest Endpoints"
          description="Endpoints ranked by p95 latency. Click to view traces."
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/performance/latency">Explore <TrendingUp className="w-3 h-3" /></Link></Button>}
        />
        <DataTable
          columns={columns}
          data={endpoints}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.path, (r) => r.service]}
          searchPlaceholder="Search endpoints..."
          pageSize={8}
          initialSort={{ key: "p95", dir: "desc" }}
        />
      </Card>
    </PageContainer>
  );
}
