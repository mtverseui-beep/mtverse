"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  BarChart3, TrendingUp, ShieldCheck, Clock, Download, Activity,
  Users, AlertTriangle, ArrowUpRight, Zap, Target, Gauge, Award,
} from "lucide-react";
import {
  services, slos, incidents, dashboardStats, mttrTrend,
} from "@/lib/data";
import {
  LineChartCard, DonutChart, ComposedChartCard,
} from "@/components/charts";
import { SeverityBadge, TierBadge } from "@/components/common/badges";

interface BusinessRisk {
  id: string;
  risk: string;
  score: number;
  category: string;
  owner: string;
  ownerAvatar?: string;
  mitigation: string;
  status: "mitigating" | "monitoring" | "accepted";
}

export default function ExecutiveReliabilityDashboardPage() {
  const stats = dashboardStats();
  const activeIncidents = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");

  // Executive KPIs (aggregated, business-impact framing)
  const serviceAvailability = 99.96;
  const customerImpactHours = 2.4;
  const sloAttainment = Math.round((slos.filter((s) => s.status === "healthy").length / slos.length) * 100);
  const mttd = stats.mttd30d;
  const mttr = stats.mttr30d;

  // Quarterly reliability trend (12 weeks)
  const quarterlyTrend = mttrTrend().slice(-12).map((d, i) => ({
    date: `W${i + 1}`,
    availability: 99.9 + (Math.random() - 0.5) * 0.06,
    incidents: Math.floor(Math.random() * 8) + 2,
  }));

  // SLO attainment by service tier
  const sloByTier = [
    { name: "Tier 1 (Critical)", value: Math.round((slos.filter((s) => {
      const svc = services.find((sv) => sv.id === s.serviceId);
      return svc?.tier === "tier1" && s.status === "healthy";
    }).length / slos.filter((s) => {
      const svc = services.find((sv) => sv.id === s.serviceId);
      return svc?.tier === "tier1";
    }).length) * 100) },
    { name: "Tier 2 (Important)", value: 88 },
    { name: "Tier 3 (Standard)", value: 92 },
    { name: "Tier 4 (Supporting)", value: 96 },
  ];

  // Business risks register
  const risks: BusinessRisk[] = [
    {
      id: "r1",
      risk: "Checkout API SLO breach impacting 3% of payment attempts",
      score: 92,
      category: "Customer Impact",
      owner: "Marcus Anderson",
      ownerAvatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&fit=crop&crop=faces",
      mitigation: "Rolling back canary v2.4.1-rc1 and engaging 3DS provider.",
      status: "mitigating",
    },
    {
      id: "r2",
      risk: "Billing invoice backlog delaying customer communications",
      score: 74,
      category: "Customer Impact",
      owner: "Caleb Foster",
      ownerAvatar: "https://images.unsplash.com/photo-1545167622-3a6ac756afa4?w=120&h=120&fit=crop&crop=faces",
      mitigation: "Scaled workers from 4 to 8. Queue depth dropping.",
      status: "mitigating",
    },
    {
      id: "r3",
      risk: "OpenSSL critical CVE on API gateway requires emergency patch",
      score: 88,
      category: "Security",
      owner: "Hannah Wright",
      ownerAvatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop&crop=faces",
      mitigation: "Patch window scheduled for 03:00 UTC Saturday.",
      status: "mitigating",
    },
    {
      id: "r4",
      risk: "Web app LCP regression affecting SEO ranking",
      score: 56,
      category: "Growth",
      owner: "Mei Lin",
      ownerAvatar: "https://images.unsplash.com/photo-1530785602389-07594beb8b73?w=120&h=120&fit=crop&crop=faces",
      mitigation: "Image optimization hotfix in progress.",
      status: "mitigating",
    },
    {
      id: "r5",
      risk: "Single-region PostgreSQL limits DR posture",
      score: 64,
      category: "Architecture",
      owner: "Priya Raman",
      ownerAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&fit=crop&crop=faces",
      mitigation: "Multi-region replica design in review. Q3 roadmap item.",
      status: "monitoring",
    },
    {
      id: "r6",
      risk: "On-call fatigue trending upward in Reliability team",
      score: 42,
      category: "Team Health",
      owner: "Maya Okonkwo",
      ownerAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&fit=crop&crop=faces",
      mitigation: "Hiring additional SRE. Two candidates in onsite loop.",
      status: "monitoring",
    },
  ];

  function riskColor(score: number) {
    if (score >= 80) return { bar: "bg-destructive", text: "text-destructive", bg: "bg-destructive/10" };
    if (score >= 60) return { bar: "bg-warning", text: "text-warning-foreground", bg: "bg-warning/10" };
    return { bar: "bg-info", text: "text-info-foreground", bg: "bg-info/10" };
  }

  // Executive summary metrics
  const revenueAtRisk = "$184k";
  const topCustomerImpact = activeIncidents[0];

  return (
    <PageContainer wide>
      <PageHeader
        title="Executive Reliability Dashboard"
        description="Business-impact view of platform reliability, SLO attainment, and top organizational risks."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Executive" }]}
        icon={<BarChart3 className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Board Report</span>
            </Button>
            <Button size="sm" className="gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              Live View
            </Button>
          </>
        }
      />

      {/* Hero KPI band - business-impact framing, large */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-success/10 rounded-full blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-lg bg-success/15 border border-success/30 flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 text-success" />
              </div>
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Service Availability</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-bold tabular-nums tracking-tight">{serviceAvailability}</span>
              <span className="text-lg text-muted-foreground font-medium">%</span>
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs">
              <TrendingUp className="w-3 h-3 text-success" />
              <span className="text-success font-medium">+0.04%</span>
              <span className="text-muted-foreground">vs last quarter</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-destructive/10 rounded-full blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-lg bg-destructive/15 border border-destructive/30 flex items-center justify-center">
                <Users className="w-4 h-4 text-destructive" />
              </div>
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Customer Impact</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-bold tabular-nums tracking-tight">{customerImpactHours}</span>
              <span className="text-lg text-muted-foreground font-medium">hrs</span>
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs">
              <span className="text-muted-foreground">this quarter · revenue at risk</span>
              <span className="text-destructive font-medium">{revenueAtRisk}</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center">
                <Target className="w-4 h-4 text-primary" />
              </div>
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">SLO Attainment</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-bold tabular-nums tracking-tight">{sloAttainment}</span>
              <span className="text-lg text-muted-foreground font-medium">%</span>
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs">
              <span className="text-muted-foreground">{slos.filter((s) => s.status === "healthy").length}/{slos.length} SLOs healthy ·</span>
              <span className="text-destructive font-medium">{slos.filter((s) => s.status === "breached").length} breached</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-info/10 rounded-full blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-lg bg-info/15 border border-info/30 flex items-center justify-center">
                <Clock className="w-4 h-4 text-info-foreground" />
              </div>
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">MTTD / MTTR</span>
            </div>
            <div className="flex items-baseline gap-2">
              <div>
                <span className="text-3xl font-bold tabular-nums tracking-tight">{mttd}</span>
                <span className="text-sm text-muted-foreground font-medium">m detect</span>
              </div>
              <span className="text-muted-foreground">/</span>
              <div>
                <span className="text-3xl font-bold tabular-nums tracking-tight">{mttr}</span>
                <span className="text-sm text-muted-foreground font-medium">m recover</span>
              </div>
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs">
              <TrendingUp className="w-3 h-3 text-success rotate-180" />
              <span className="text-success font-medium">-8%</span>
              <span className="text-muted-foreground">vs last quarter</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Executive summary card */}
      <Card className="p-6 border-primary/20 bg-gradient-to-r from-primary/5 via-transparent to-accent/5">
        <div className="flex flex-col md:flex-row md:items-start gap-4">
          <div className="flex items-center gap-2 shrink-0">
            <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
              <Award className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-sm font-semibold">Executive Summary</h2>
              <p className="text-[11px] text-muted-foreground">Q3 2026 reliability posture</p>
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm leading-relaxed">
              Platform availability is <span className="font-semibold text-success">{serviceAvailability}%</span> for the quarter, exceeding our <span className="font-semibold">99.9%</span> target. However, a <span className="font-semibold text-destructive">checkout SLO breach</span> is currently impacting approximately 3% of payment attempts in us-east-1, putting an estimated <span className="font-semibold text-destructive">{revenueAtRisk}</span> of quarterly revenue at risk. The Reliability and Payments teams are actively mitigating. SLO attainment stands at <span className="font-semibold">{sloAttainment}%</span> with one breached objective. MTTD and MTTR are both improving quarter-over-quarter. Top organizational risks are documented below with owners and mitigation plans.
            </p>
          </div>
        </div>
      </Card>

      {/* Quarterly trend + SLO by tier */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <ComposedChartCard
            data={quarterlyTrend}
            bars={[{ key: "incidents", name: "Incidents", color: 4 }]}
            lines={[{ key: "availability", name: "Availability %", color: 3 }]}
            title="Quarterly Reliability Trend"
            description="Weekly incident volume overlaid on availability (last 12 weeks)"
            suffix="%"
          />
        </div>
        <DonutChart
          title="SLO Attainment by Tier"
          description="Healthy SLO percentage grouped by service tier"
          data={sloByTier}
          centerLabel="Avg"
          centerValue={`${Math.round(sloByTier.reduce((s, x) => s + x.value, 0) / sloByTier.length)}%`}
        />
      </div>

      {/* Top business risks table */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Top Business Risks"
          description="Ranked register of organizational risks with owners and mitigation plans"
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/reliability/scorecards">All risks <ArrowUpRight className="w-3 h-3" /></Link></Button>}
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr className="text-left">
                <th className="px-3 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Risk</th>
                <th className="px-3 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-medium w-20">Score</th>
                <th className="px-3 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-medium w-32">Category</th>
                <th className="px-3 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-medium w-44">Owner</th>
                <th className="px-3 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Mitigation</th>
                <th className="px-3 py-2.5 text-[10px] uppercase tracking-wider text-muted-foreground font-medium w-28">Status</th>
              </tr>
            </thead>
            <tbody>
              {risks.map((r) => {
                const c = riskColor(r.score);
                return (
                  <tr key={r.id} className="border-t border-border hover:bg-muted/30 transition-colors">
                    <td className="px-3 py-3">
                      <div className="text-xs font-medium">{r.risk}</div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-12 h-1.5 rounded-full bg-muted overflow-hidden">
                          <div className={`h-full ${c.bar}`} style={{ width: `${r.score}%` }} />
                        </div>
                        <span className={`text-xs font-mono tabular-nums font-medium ${c.text}`}>{r.score}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-[11px] text-muted-foreground">{r.category}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1.5">
                        {r.ownerAvatar && <img src={r.ownerAvatar} alt="" className="w-5 h-5 rounded-full object-cover" />}
                        <span className="text-xs truncate">{r.owner}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-[11px] text-muted-foreground line-clamp-1">{r.mitigation}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded font-medium capitalize ${
                        r.status === "mitigating" ? "bg-warning/15 text-warning-foreground" :
                        r.status === "monitoring" ? "bg-info/15 text-info-foreground" :
                        "bg-muted text-muted-foreground"
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          r.status === "mitigating" ? "bg-warning animate-status-pulse" :
                          r.status === "monitoring" ? "bg-info" : "bg-muted-foreground"
                        }`} />
                        {r.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Active incident impact summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-5 space-y-4 border-destructive/20">
          <SectionHeading title="Active Customer Impact" description="Live incidents affecting customers" />
          <div className="space-y-3">
            {activeIncidents.slice(0, 3).map((inc) => (
              <div key={inc.id} className="flex items-start gap-3 p-3 rounded-lg border bg-card">
                <div className={`shrink-0 w-1 self-stretch rounded-full ${inc.severity === "critical" ? "bg-destructive" : inc.severity === "high" ? "bg-warning" : "bg-info"}`} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-[10px] font-mono text-muted-foreground">{inc.ref}</span>
                    <SeverityBadge severity={inc.severity} size="sm" />
                  </div>
                  <div className="text-sm font-medium">{inc.title}</div>
                  <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">{inc.customerImpact}</p>
                  <div className="flex items-center gap-4 mt-2 text-[11px] text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {inc.impactedUsers.toLocaleString()} users
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      since {new Date(inc.startedAt).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            ))}
            {activeIncidents.length === 0 && (
              <div className="text-center py-8 text-sm text-muted-foreground">
                <ShieldCheck className="w-6 h-6 mx-auto mb-2 text-success opacity-50" />
                No active customer impact
              </div>
            )}
          </div>
        </Card>

        <Card className="p-5 space-y-4">
          <SectionHeading title="Tier-1 Service Posture" description="Critical services summary" />
          <div className="space-y-3">
            {services.filter((s) => s.tier === "tier1").slice(0, 6).map((s) => (
              <div key={s.id} className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    s.health === "operational" ? "bg-success animate-status-pulse" :
                    s.health === "degraded" ? "bg-warning" : "bg-destructive"
                  }`} />
                  <span className="text-xs font-medium truncate">{s.name}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={`text-[11px] font-mono tabular-nums ${s.uptime30d >= 99.9 ? "text-success" : "text-warning-foreground"}`}>
                    {s.uptime30d.toFixed(3)}%
                  </span>
                </div>
              </div>
            ))}
            <div className="pt-3 border-t border-border">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Tier-1 Availability</span>
                <span className="font-bold text-success tabular-nums">99.97%</span>
              </div>
              <div className="flex items-center justify-between text-xs mt-1">
                <span className="text-muted-foreground">Coverage</span>
                <span className="font-bold tabular-nums">{services.filter((s) => s.tier === "tier1").length} services</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
