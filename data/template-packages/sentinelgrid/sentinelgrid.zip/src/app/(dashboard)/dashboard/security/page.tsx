"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  ShieldAlert, ShieldX, ShieldCheck, Bug, Download, Plus, Clock,
  Activity, Lock, Zap, TrendingDown, ChevronRight,
} from "lucide-react";
import { vulnerabilities, auditEvents, people, services } from "@/lib/data";
import {
  DonutChart, LineChartCard,
} from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { SeverityBadge } from "@/components/common/badges";
import type { Vulnerability } from "@/lib/types";

export default function SecurityOperationsDashboardPage() {
  const open = vulnerabilities.filter((v) => v.status === "open" || v.status === "in_progress");
  const critical = vulnerabilities.filter((v) => v.severity === "critical");
  const patched = vulnerabilities.filter((v) => v.status === "patched");

  // Compliance score mock
  const complianceScore = 87;
  const meanTimeToPatch = 4.2; // days

  // Vulnerabilities by severity
  const bySeverity = (["critical", "high", "medium", "low"] as const).map((s) => ({
    name: s.charAt(0).toUpperCase() + s.slice(1),
    value: vulnerabilities.filter((v) => v.severity === s).length,
  }));

  // Security events trend (last 30 days)
  const eventsTrend = timeSeries(19, 30, 24, 12).map((d) => ({
    date: d.date,
    value: Math.max(0, Math.round(d.value)),
  }));

  const vulnColumns: Column<Vulnerability>[] = [
    {
      key: "cve",
      header: "CVE",
      sortable: true,
      sortValue: (r) => r.cve,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Bug className="w-3.5 h-3.5 text-muted-foreground" />
          <div>
            <div className="text-xs font-mono font-medium">{r.cve}</div>
            <div className="text-[10px] text-muted-foreground">{r.ref}</div>
          </div>
        </div>
      ),
    },
    {
      key: "title",
      header: "Title",
      sortable: true,
      sortValue: (r) => r.title,
      cell: (r) => (
        <div className="min-w-0 max-w-xs">
          <div className="text-xs font-medium truncate">{r.title}</div>
          <div className="text-[10px] text-muted-foreground truncate">{r.assetName}</div>
        </div>
      ),
    },
    {
      key: "severity",
      header: "Severity",
      sortable: true,
      sortValue: (r) => r.cvss,
      cell: (r) => (
        <div className="flex items-center gap-1.5">
          <SeverityBadge severity={r.severity} size="sm" />
          <span className="text-[10px] font-mono tabular-nums text-muted-foreground">{r.cvss}</span>
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-md border font-medium capitalize ${
          r.status === "open" ? "bg-destructive/15 text-destructive border-destructive/30" :
          r.status === "in_progress" ? "bg-warning/15 text-warning-foreground border-warning/30" :
          r.status === "patched" ? "bg-success/15 text-success border-success/30" :
          "bg-muted text-muted-foreground border-border"
        }`}>
          <span className={`w-1.5 h-1.5 rounded-full ${
            r.status === "open" ? "bg-destructive" :
            r.status === "in_progress" ? "bg-warning" :
            r.status === "patched" ? "bg-success" :
            "bg-muted-foreground"
          }`} />
          {r.status.replace("_", " ")}
        </span>
      ),
    },
    {
      key: "owner",
      header: "Owner",
      cell: (r) => {
        const owner = people.find((p) => p.id === r.owner);
        return owner ? (
          <div className="flex items-center gap-1.5">
            <img src={owner.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
            <span className="text-xs truncate">{owner.name}</span>
          </div>
        ) : <span className="text-xs text-muted-foreground">—</span>;
      },
      hideOnMobile: true,
    },
    {
      key: "discoveredAt",
      header: "Discovered",
      sortable: true,
      sortValue: (r) => r.discoveredAt,
      cell: (r) => (
        <span className="text-[11px] text-muted-foreground">
          {new Date(r.discoveredAt).toLocaleDateString()}
        </span>
      ),
      hideOnMobile: true,
    },
  ];

  // Map audit events to display in timeline
  const securityEvents = auditEvents
    .filter((a) => a.action.includes("deployment") || a.action.includes("incident") || a.action.includes("alert"))
    .slice(0, 12);

  function eventIcon(action: string) {
    if (action.includes("incident")) return <ShieldAlert className="w-3.5 h-3.5 text-destructive" />;
    if (action.includes("deployment")) return <Activity className="w-3.5 h-3.5 text-info" />;
    if (action.includes("alert")) return <Zap className="w-3.5 h-3.5 text-warning-foreground" />;
    return <Lock className="w-3.5 h-3.5 text-muted-foreground" />;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Security Operations"
        description="Vulnerability management, compliance posture, and security event monitoring across the platform."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Security Operations" }]}
        icon={<ShieldAlert className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
            <Button size="sm" className="gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              Scan Now
            </Button>
          </>
        }
      />

      {/* KPI row - 4 cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Open Vulnerabilities"
          value={open.length}
          hint={`${critical.length} critical`}
          icon={<Bug className="w-4 h-4" />}
          accent="destructive"
          sparkline={[3, 4, 5, 4, 6, 5, 4, 5, 4, 4]}
        />
        <KpiCard
          label="Critical (Open)"
          value={critical.filter((v) => v.status !== "patched").length}
          hint="needs immediate patching"
          icon={<ShieldX className="w-4 h-4" />}
          accent="destructive"
        />
        <KpiCard
          label="Compliance Score"
          value={complianceScore}
          unit="%"
          delta={3}
          deltaLabel="vs last month"
          icon={<ShieldCheck className="w-4 h-4" />}
          accent={complianceScore >= 90 ? "success" : "warning"}
          sparkline={[82, 84, 83, 85, 86, 85, 87, 86, 87, 87]}
        />
        <KpiCard
          label="Mean Time to Patch"
          value={meanTimeToPatch}
          unit="days"
          delta={-18}
          deltaLabel="improving"
          icon={<Clock className="w-4 h-4" />}
          accent="primary"
          sparkline={[6.2, 5.8, 5.5, 5.1, 4.9, 4.7, 4.5, 4.4, 4.3, 4.2]}
        />
      </div>

      {/* Donut + events trend + timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <DonutChart
          title="Vulnerabilities by Severity"
          description="All known CVEs grouped by CVSS severity"
          data={bySeverity}
          centerLabel="Total"
          centerValue={String(vulnerabilities.length)}
        />

        <LineChartCard
          data={eventsTrend}
          dataKey="value"
          color={4}
          title="Security Events Trend"
          description="Audit events per day (30d, all sources)"
        />

        <Card className="p-5 space-y-4 border-destructive/20">
          <SectionHeading title="Patch Progress" description="Vulnerability remediation status" />
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">Patched</span>
                <span className="font-medium text-success tabular-nums">{patched.length}</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-success" style={{ width: `${(patched.length / vulnerabilities.length) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">In Progress</span>
                <span className="font-medium text-warning-foreground tabular-nums">{vulnerabilities.filter((v) => v.status === "in_progress").length}</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-warning" style={{ width: `${(vulnerabilities.filter((v) => v.status === "in_progress").length / vulnerabilities.length) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">Open</span>
                <span className="font-medium text-destructive tabular-nums">{vulnerabilities.filter((v) => v.status === "open").length}</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-destructive" style={{ width: `${(vulnerabilities.filter((v) => v.status === "open").length / vulnerabilities.length) * 100}%` }} />
              </div>
            </div>
            <div className="pt-3 border-t border-border">
              <div className="flex items-center gap-2 text-[11px]">
                <TrendingDown className="w-3.5 h-3.5 text-success" />
                <span className="text-muted-foreground">Patch rate up</span>
                <span className="font-medium text-success">+18%</span>
                <span className="text-muted-foreground">vs last quarter</span>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Vulnerabilities table */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Vulnerability Register"
          description="All known CVEs with severity, status, and owner"
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/security/vulnerabilities">View all <ChevronRight className="w-3 h-3" /></Link></Button>}
        />
        <DataTable
          columns={vulnColumns}
          data={vulnerabilities}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.cve, (r) => r.title, (r) => r.assetName]}
          searchPlaceholder="Search CVEs..."
          pageSize={6}
        />
      </Card>

      {/* Security events timeline */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Security Events Timeline"
          description="Recent audit-trail activity related to security operations"
        />
        <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1 custom-scroll">
          {securityEvents.map((evt) => {
            const actor = people.find((p) => p.id === evt.actorId);
            return (
              <div key={evt.id} className="flex items-start gap-3 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors">
                <div className={`shrink-0 w-8 h-8 rounded-md flex items-center justify-center ${
                  evt.result === "failure" ? "bg-destructive/15" : "bg-muted"
                }`}>
                  {eventIcon(evt.action)}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-medium">{actor?.name ?? "System"}</span>
                    <span className="text-[10px] font-mono text-muted-foreground">{evt.action}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                      evt.result === "success" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
                    }`}>{evt.result}</span>
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    {evt.resourceType} · {evt.resourceId} · from {evt.ip}
                  </p>
                </div>
                <span className="text-[10px] text-muted-foreground shrink-0">
                  {new Date(evt.timestamp).toLocaleString()}
                </span>
              </div>
            );
          })}
        </div>
      </Card>
    </PageContainer>
  );
}
