"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Siren, Activity, Clock, Timer, Phone, MessageSquare, ArrowUpRight,
  Radio, ShieldAlert, Plus, ChevronRight, Zap,
} from "lucide-react";
import {
  incidents, onCallShifts, people, alerts, services, escalationPolicies, dashboardStats,
} from "@/lib/data";
import { SeverityBadge, IncidentStatusBadge, StatusDot } from "@/components/common/badges";

export default function IncidentCommandCenterPage() {
  const stats = dashboardStats();
  const activeIncidents = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");
  const firingAlerts = alerts.filter((a) => a.status === "firing" || a.status === "acknowledged");
  const now = Date.now();

  const currentShift = onCallShifts.find((s) => {
    return new Date(s.start).getTime() < now && new Date(s.end).getTime() > now;
  }) || onCallShifts[0];
  const currentOnCallUser = currentShift ? people.find((p) => p.id === currentShift.userId) : null;

  const ackSlaCompliance = 92;
  const responseSlaCompliance = 87;
  const mttr = stats.mttr30d;

  function formatDuration(startedAt: string) {
    const diff = now - new Date(startedAt).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h ${mins % 60}m`;
    if (hours > 0) return `${hours}h ${mins % 60}m`;
    return `${mins}m`;
  }

  const escalationLadder = escalationPolicies[0]?.rounds.flatMap((r, idx) =>
    r.targets.map((t) => ({
      round: idx + 1,
      delay: r.delayMinutes,
      person: t.type === "person" ? people.find((p) => p.id === t.id) : null,
    })).filter((x) => x.person)
  ) ?? [];

  return (
    <PageContainer>
      <PageHeader
        title="Incident Command Center"
        description="Centralized war room view of all active incidents, response timelines, and on-call coverage."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Incident Command" }]}
        icon={<Siren className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Radio className="w-3.5 h-3.5" />
              <span className="hidden md:inline">War Room</span>
            </Button>
            <Button size="sm" className="gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              Declare Incident
            </Button>
          </>
        }
      />

      <Card className="p-5 border-destructive/30 bg-gradient-to-r from-destructive/10 via-destructive/5 to-transparent">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-destructive/20 border border-destructive/40 flex items-center justify-center">
              <ShieldAlert className="w-5 h-5 text-destructive" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold uppercase tracking-wider text-destructive">Major Operations Active</span>
                <StatusDot color="destructive" pulse size="md" />
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                {activeIncidents.length} active incidents · {firingAlerts.length} paging alerts · {stats.openAlerts} firing
              </p>
            </div>
          </div>
          <div className="flex items-center gap-6 md:ml-auto">
            <div className="text-center">
              <div className="text-2xl font-bold tabular-nums text-destructive">{activeIncidents.length}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Active</div>
            </div>
            <div className="w-px h-10 bg-border" />
            <div className="text-center">
              <div className="text-2xl font-bold tabular-nums text-warning-foreground">{activeIncidents.filter((i) => i.severity === "critical" || i.severity === "high").length}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">High+</div>
            </div>
            <div className="w-px h-10 bg-border" />
            <div className="text-center">
              <div className="text-2xl font-bold tabular-nums text-success">{stats.servicesHealthy}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Healthy Svcs</div>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard
          label="Active Incidents"
          value={activeIncidents.length}
          hint={`${activeIncidents.filter((i) => i.severity === "critical").length} critical`}
          icon={<Siren className="w-4 h-4" />}
          accent="destructive"
          sparkline={[2, 3, 1, 4, 2, 5, 3, 4, 3, 3]}
        />
        <KpiCard
          label="Ack SLA (24h)"
          value={`${ackSlaCompliance}%`}
          delta={-3}
          deltaLabel="vs target 95%"
          icon={<Zap className="w-4 h-4" />}
          accent="warning"
        />
        <KpiCard
          label="Response SLA (24h)"
          value={`${responseSlaCompliance}%`}
          delta={2}
          deltaLabel="vs target 90%"
          icon={<Activity className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="MTTR (30d)"
          value={mttr}
          unit="min"
          delta={-8}
          deltaLabel="improving"
          icon={<Clock className="w-4 h-4" />}
          accent="success"
          sparkline={[24, 22, 21, 19, 18, 17, 18, 19, 18, 18]}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <SectionHeading
            title="Active War Rooms"
            description="Live incident response rooms with commander and responder details"
            action={<Button variant="ghost" size="sm" className="text-xs h-7 gap-1">View all <ChevronRight className="w-3 h-3" /></Button>}
          />
          <div className="space-y-3 max-h-[800px] overflow-y-auto pr-1 custom-scroll">
            {activeIncidents.map((inc) => {
              const commander = people.find((p) => p.id === inc.commanderId);
              const responders = inc.responderIds.map((id) => people.find((p) => p.id === id)).filter(Boolean);
              const svc = services.find((s) => s.id === inc.serviceIds[0]);
              const lastEvent = inc.timeline[inc.timeline.length - 1];
              const lastAuthor = lastEvent ? people.find((p) => p.id === lastEvent.authorId) : null;
              const checklistDone = inc.checklist.filter((c) => c.done).length;
              return (
                <Card key={inc.id} className="p-4 border-l-4 border-l-destructive/60 hover:bg-elevated/40 transition-colors">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-1.5">
                        <span className="text-xs font-mono font-semibold text-muted-foreground">{inc.ref}</span>
                        <SeverityBadge severity={inc.severity} size="sm" />
                        <IncidentStatusBadge status={inc.status} />
                        <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                          <Timer className="w-3 h-3" />
                          {formatDuration(inc.startedAt)}
                        </span>
                      </div>
                      <h3 className="text-sm font-semibold truncate">{inc.title}</h3>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{inc.customerImpact}</p>
                    </div>
                    <Button asChild size="sm" variant="outline" className="shrink-0 gap-1">
                      <Link href={`/incidents/${inc.id}`}>
                        Enter
                        <ArrowUpRight className="w-3 h-3" />
                      </Link>
                    </Button>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-xs mb-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Commander</div>
                      <div className="flex items-center gap-1.5">
                        {commander && (
                          <>
                            <img src={commander.avatarUrl} alt="" className="w-5 h-5 rounded-full object-cover" />
                            <span className="font-medium truncate">{commander.name}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Impacted Users</div>
                      <div className="font-semibold tabular-nums">{inc.impactedUsers.toLocaleString()}</div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Service</div>
                      <div className="font-medium truncate">{svc?.name ?? "—"}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <div className="flex -space-x-2">
                        {responders.slice(0, 4).map((r) => r && (
                          <img key={r.id} src={r.avatarUrl} alt={r.name} title={r.name} className="w-6 h-6 rounded-full object-cover border-2 border-background" />
                        ))}
                        {responders.length > 4 && (
                          <div className="w-6 h-6 rounded-full bg-muted border-2 border-background flex items-center justify-center text-[10px] font-medium">
                            +{responders.length - 4}
                          </div>
                        )}
                      </div>
                      <span className="text-[11px] text-muted-foreground">{responders.length} responders</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Progress value={(checklistDone / inc.checklist.length) * 100} className="w-16 h-1.5" />
                      <span className="text-[11px] text-muted-foreground tabular-nums">{checklistDone}/{inc.checklist.length}</span>
                    </div>
                  </div>

                  {lastEvent && (
                    <div className="mt-3 pt-3 border-t border-border flex items-start gap-2">
                      <MessageSquare className="w-3 h-3 text-muted-foreground shrink-0 mt-0.5" />
                      <p className="text-[11px] text-muted-foreground line-clamp-1 flex-1">
                        <span className="font-medium text-foreground">{lastAuthor?.name ?? "System"}:</span> {lastEvent.message}
                      </p>
                      <span className="text-[10px] text-muted-foreground shrink-0">{new Date(lastEvent.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                  )}
                </Card>
              );
            })}
            {activeIncidents.length === 0 && (
              <Card className="p-8 text-center">
                <ShieldAlert className="w-8 h-8 mx-auto mb-2 text-success opacity-50" />
                <p className="text-sm font-medium">All clear</p>
                <p className="text-xs text-muted-foreground mt-1">No active incidents requiring attention.</p>
              </Card>
            )}
          </div>
        </div>

        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Response Timeline"
            description="Latest activity across all incidents"
          />
          <div className="space-y-3 max-h-[760px] overflow-y-auto pr-1 custom-scroll">
            {incidents
              .flatMap((i) => i.timeline.map((t) => ({ ...t, incident: i })))
              .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
              .slice(0, 18)
              .map((evt) => {
                const author = people.find((p) => p.id === evt.authorId);
                return (
                  <div key={evt.id} className="flex items-start gap-2.5">
                    <div className="relative shrink-0">
                      <div className="w-2 h-2 rounded-full bg-primary mt-1.5" />
                      <div className="absolute top-3 left-1/2 -translate-x-1/2 w-px h-full bg-border" />
                    </div>
                    <div className="min-w-0 flex-1 pb-3">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-medium">{author?.name ?? "System"}</span>
                        <span className="text-[10px] font-mono text-muted-foreground">{evt.incident.ref}</span>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-2">{evt.message}</p>
                      <span className="text-[10px] text-muted-foreground">{new Date(evt.timestamp).toLocaleString()}</span>
                    </div>
                  </div>
                );
              })}
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="p-5 space-y-4 border-primary/20 bg-primary/5">
            <SectionHeading title="On-Call Now" description="Currently paged engineer" />
            {currentOnCallUser && currentShift && (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img src={currentOnCallUser.avatarUrl} alt={currentOnCallUser.name} className="w-14 h-14 rounded-full object-cover ring-2 ring-primary" />
                    <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-success border-2 border-background animate-status-pulse" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold truncate">{currentOnCallUser.name}</div>
                    <div className="text-xs text-muted-foreground">{currentShift.role} on-call</div>
                    <div className="text-[11px] text-muted-foreground">{currentOnCallUser.team} · {currentOnCallUser.title}</div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="default" className="flex-1 gap-1.5 h-8">
                    <Phone className="w-3.5 h-3.5" /> Page
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 gap-1.5 h-8">
                    <MessageSquare className="w-3.5 h-3.5" /> Message
                  </Button>
                </div>
              </div>
            )}
          </Card>

          <Card className="p-5 space-y-4">
            <SectionHeading title="Escalation Ladder" description="Platform - Standard policy" />
            <div className="space-y-2">
              {escalationLadder.map((r, i) => (
                <div key={i} className="flex items-center gap-3 p-2 rounded-lg border bg-muted/30">
                  <div className="w-6 h-6 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center text-[10px] font-semibold text-primary">
                    {r.round}
                  </div>
                  {r.person && (
                    <>
                      <img src={r.person.avatarUrl} alt="" className="w-7 h-7 rounded-full object-cover" />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-medium truncate">{r.person.name}</div>
                        <div className="text-[10px] text-muted-foreground">{r.person.title}</div>
                      </div>
                      <span className="text-[10px] text-muted-foreground shrink-0">
                        {r.delay === 0 ? "Immediate" : `+${r.delay}m`}
                      </span>
                    </>
                  )}
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Firing Alerts" description="Awaiting ack or escalation" />
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1 custom-scroll">
              {firingAlerts.slice(0, 6).map((a) => {
                const svc = services.find((s) => s.id === a.serviceId);
                return (
                  <Link key={a.id} href={`/alerts/${a.id}`} className="block p-2 rounded-md border hover:bg-muted/40 transition-colors">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-[10px] font-mono text-muted-foreground">{a.ref}</span>
                      <SeverityBadge severity={a.severity} size="sm" />
                    </div>
                    <div className="text-[11px] text-foreground line-clamp-1">{a.message}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{svc?.name}</div>
                  </Link>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
