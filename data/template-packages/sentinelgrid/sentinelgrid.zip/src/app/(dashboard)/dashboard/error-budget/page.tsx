"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Wallet, TrendingUp, TrendingDown, Flame, AlertTriangle, Download,
  Activity, Clock, ArrowUpRight, ShieldX,
} from "lucide-react";
import { slos, services, timeSeries, multiTimeSeries } from "@/lib/data";
import { BurnRateChart, LineChartCard } from "@/components/charts";
import { SLOStatusBadge, TierBadge } from "@/components/common/badges";

export default function ErrorBudgetPage() {
  // Aggregate budget stats
  const totalBudget = slos.length * 100;
  const consumedBudget = slos.reduce((s, x) => s + x.errorBudget.consumed, 0);
  const remainingBudget = totalBudget - consumedBudget;
  const avgBurnRate = slos.reduce((s, x) => s + x.errorBudget.burnRate, 0) / slos.length;

  // Burn rate trend (multi-SLO)
  const burnRateData = multiTimeSeries(11, 30, [
    { name: "fast_burn", base: 4, variance: 3 },
    { name: "slow_burn", base: 1, variance: 1 },
  ]).map((d) => ({
    timestamp: String(d.date),
    fast_burn: Number(d.fast_burn),
    slow_burn: Number(d.slow_burn),
  }));

  // Single line burn rate trend
  const burnTrend = timeSeries(13, 24, avgBurnRate, avgBurnRate * 0.5).map((d) => ({
    timestamp: d.date,
    value: Math.max(0, d.value),
  }));

  // SLOs approaching breach (remaining < 30% but not exhausted)
  const approachingBreach = slos
    .filter((s) => s.errorBudget.remaining < 40 && s.errorBudget.remaining > 0)
    .sort((a, b) => a.errorBudget.remaining - b.errorBudget.remaining);

  // Projected exhaustion date
  function projectExhaustion(burnRate: number, remaining: number): string {
    if (burnRate === 0) return "Never";
    const days = (remaining / 100) * 28 / burnRate;
    if (days > 365) return ">12 months";
    if (days < 1) return "Exhausted";
    return `${Math.round(days)} days`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Error Budget Dashboard"
        description="Aggregate error budget consumption, burn rate trends, and projected breach timelines."
        breadcrumbs={[{ label: "Dashboard", href: "/dashboard" }, { label: "Error Budget" }]}
        icon={<Wallet className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              <span className="hidden md:inline">28-day window</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPI row - 4 cards with unique large hero layout */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Total Budget"
          value={totalBudget}
          unit="pts"
          hint={`${slos.length} SLOs × 100`}
          icon={<Wallet className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="Consumed"
          value={consumedBudget}
          unit="pts"
          delta={12}
          deltaLabel="vs last week"
          icon={<TrendingUp className="w-4 h-4" />}
          accent="destructive"
        />
        <KpiCard
          label="Remaining"
          value={remainingBudget}
          unit="pts"
          delta={-12}
          deltaLabel="depleting"
          icon={<TrendingDown className="w-4 h-4" />}
          accent={remainingBudget > totalBudget * 0.5 ? "success" : "warning"}
        />
        <KpiCard
          label="Avg Burn Rate"
          value={avgBurnRate.toFixed(2)}
          unit="x"
          hint={avgBurnRate > 6 ? "Above threshold" : "Within budget"}
          icon={<Flame className="w-4 h-4" />}
          accent={avgBurnRate > 6 ? "destructive" : "info"}
          sparkline={[1, 2, 1, 3, 2, 4, 3, 5, 4, 3]}
        />
      </div>

      {/* Main grid: bars + burn rate trend */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Per-SLO error budget bars - the wide column */}
        <Card className="lg:col-span-3 p-5 space-y-4">
          <SectionHeading
            title="Error Budget by SLO"
            description="Consumed (warning) vs remaining (success). Threshold lines mark 50% and 20%."
          />
          <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1 custom-scroll">
            {slos.map((slo) => {
              const svc = services.find((s) => s.id === slo.serviceId);
              const remaining = slo.errorBudget.remaining;
              const consumed = slo.errorBudget.consumed;
              const isBreached = slo.status === "breached" || slo.status === "exhausted";
              return (
                <div key={slo.id} className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="font-mono text-muted-foreground text-[10px]">{slo.ref}</span>
                      <span className="font-medium truncate">{slo.name}</span>
                      {svc && <TierBadge tier={svc.tier} />}
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-muted-foreground tabular-nums text-[11px]">
                        <span className="text-warning-foreground">{consumed.toFixed(0)}</span> / <span className="text-success">{remaining.toFixed(0)}</span>
                      </span>
                      <SLOStatusBadge status={slo.status} />
                    </div>
                  </div>
                  <div className="relative h-3 rounded-full bg-muted overflow-hidden">
                    {/* Consumed portion */}
                    <div
                      className={`absolute inset-y-0 left-0 ${isBreached ? "bg-destructive" : "bg-warning"}`}
                      style={{ width: `${Math.max(2, Math.min(100, consumed))}%` }}
                      title={`Consumed: ${consumed.toFixed(1)}%`}
                    />
                    {/* Remaining portion */}
                    <div
                      className="absolute inset-y-0 right-0 bg-success/60"
                      style={{ width: `${Math.max(0, Math.min(100, remaining))}%`, left: "auto" }}
                      title={`Remaining: ${remaining.toFixed(1)}%`}
                    />
                    {/* Threshold markers */}
                    <div className="absolute inset-y-0 w-px bg-foreground/30" style={{ left: "50%" }} />
                    <div className="absolute inset-y-0 w-px bg-foreground/30" style={{ left: "80%" }} />
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>{svc?.name}</span>
                    <span>Burn: <span className={`font-mono font-medium ${slo.errorBudget.burnRate > 6 ? "text-destructive" : ""}`}>{slo.errorBudget.burnRate}x</span></span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Burn rate trend */}
        <div className="lg:col-span-2 space-y-4">
          <BurnRateChart
            data={burnTrend}
            threshold={6}
            title="Burn Rate Trend"
            description="Average burn rate across all SLOs (24h, threshold 6x)"
          />
          <Card className="p-5 space-y-3">
            <SectionHeading title="Budget Distribution" description="Aggregate consumption" />
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-muted-foreground">Consumed</span>
                  <span className="font-medium tabular-nums text-destructive">{((consumedBudget / totalBudget) * 100).toFixed(1)}%</span>
                </div>
                <Progress value={(consumedBudget / totalBudget) * 100} className="h-2" />
              </div>
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-muted-foreground">Remaining</span>
                  <span className="font-medium tabular-nums text-success">{((remainingBudget / totalBudget) * 100).toFixed(1)}%</span>
                </div>
                <Progress value={(remainingBudget / totalBudget) * 100} className="h-2" />
              </div>
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-border">
                <div className="text-center">
                  <div className="text-base font-bold text-success tabular-nums">{slos.filter((s) => s.status === "healthy").length}</div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Healthy</div>
                </div>
                <div className="text-center">
                  <div className="text-base font-bold text-warning-foreground tabular-nums">{slos.filter((s) => s.status === "at_risk").length}</div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">At Risk</div>
                </div>
                <div className="text-center">
                  <div className="text-base font-bold text-destructive tabular-nums">{slos.filter((s) => s.status === "breached" || s.status === "exhausted").length}</div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Breached</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Action card: SLOs approaching breach */}
      <Card className="p-5 space-y-4 border-destructive/20">
        <SectionHeading
          title="SLOs Approaching Breach"
          description="Ranked by projected exhaustion date. Take action to reduce burn rate."
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/reliability/burn-rate">Burn rate rules <ArrowUpRight className="w-3 h-3" /></Link></Button>}
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr className="text-left">
                <th className="px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground font-medium">SLO</th>
                <th className="px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Service</th>
                <th className="px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Burn Rate</th>
                <th className="px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Remaining</th>
                <th className="px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Projected Exhaustion</th>
                <th className="px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {approachingBreach.concat(slos.filter((s) => s.status === "breached")).map((slo) => {
                const svc = services.find((s) => s.id === slo.serviceId);
                const proj = projectExhaustion(slo.errorBudget.burnRate, slo.errorBudget.remaining);
                return (
                  <tr key={slo.id} className="border-t border-border hover:bg-muted/30 transition-colors">
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[11px] text-muted-foreground">{slo.ref}</span>
                        <SLOStatusBadge status={slo.status} />
                      </div>
                      <div className="text-xs font-medium mt-0.5">{slo.name}</div>
                    </td>
                    <td className="px-3 py-2.5 text-xs">{svc?.name}</td>
                    <td className="px-3 py-2.5">
                      <span className={`font-mono tabular-nums text-xs font-medium ${slo.errorBudget.burnRate > 6 ? "text-destructive" : "text-warning-foreground"}`}>
                        {slo.errorBudget.burnRate}x
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2 min-w-[100px]">
                        <Progress value={slo.errorBudget.remaining} className="h-1.5 flex-1" />
                        <span className="text-xs tabular-nums font-medium w-9 text-right">{slo.errorBudget.remaining.toFixed(0)}%</span>
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      <span className={`text-xs font-medium ${proj === "Exhausted" ? "text-destructive" : "text-warning-foreground"}`}>
                        {proj}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
                        <ShieldX className="w-3 h-3" />
                        Freeze deploys
                      </Button>
                    </td>
                  </tr>
                );
              })}
              {approachingBreach.length === 0 && slos.filter((s) => s.status === "breached").length === 0 && (
                <tr>
                  <td colSpan={6} className="px-3 py-8 text-center text-sm text-muted-foreground">
                    All SLOs within budget. No breaches projected.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </PageContainer>
  );
}
