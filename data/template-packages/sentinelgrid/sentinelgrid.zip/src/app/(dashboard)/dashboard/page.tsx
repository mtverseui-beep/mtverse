"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Siren, AlertTriangle, ShieldCheck, Target, Rocket, Gauge, Bug, Server,
  Phone, Activity, ArrowUpRight, TrendingUp, Clock, Zap, Bell,
} from "lucide-react";
import { dashboardStats, incidents, alerts, services, deployments, errors, mttrTrend, incidentVolumeTrend, deploymentFrequencyTrend, timeSeries, multiTimeSeries, onCallShifts, people } from "@/lib/data";
import {
  LatencyChart, ErrorRateChart, IncidentSeverityTrendChart, MTTRTrendChart,
  DeploymentFrequencyChart, DonutChart, HorizontalBarChart,
} from "@/components/charts";
import { SeverityBadge, IncidentStatusBadge, ServiceHealthBadge, DeploymentStatusBadge } from "@/components/common/badges";

export default function EngineeringOverviewPage() {
  const stats = dashboardStats();
  const activeIncidents = incidents.filter((i) => i.status !== "resolved" && i.status !== "postmortem");
  const firingAlerts = alerts.filter((a) => a.status === "firing");
  const currentOnCall = onCallShifts.find((s) => {
    const now = Date.now();
    return new Date(s.start).getTime() < now && new Date(s.end).getTime() > now;
  }) || onCallShifts[0];
  const onCallUser = currentOnCall ? people.find((p) => p.id === currentOnCall.userId) : null;

  // Build chart data
  const latencyData = multiTimeSeries(2, 24, [
    { name: "p50", base: 35, variance: 8 },
    { name: "p95", base: 120, variance: 30 },
    { name: "p99", base: 280, variance: 60 },
  ]).map((d) => ({ timestamp: `${d.date} ${String(Math.floor(Math.random() * 24)).padStart(2, "0")}:00`, p50: Number(d.p50), p95: Number(d.p95), p99: Number(d.p99) }));
  const errorRateData = timeSeries(5, 24, 0.05, 0.04).map((d) => ({ timestamp: String(d.date), value: d.value }));
  const mttrData = mttrTrend();
  const incidentData = incidentVolumeTrend();
  const deployData = deploymentFrequencyTrend();

  return (
    <PageContainer>
      <PageHeader
        title="Engineering Overview"
        description="Real-time view of system reliability, active incidents, and team operations across all environments."
        breadcrumbs={[{ label: "Dashboard" }]}
        icon={<Activity className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Last 24 hours</span>
            </Button>
            <Button asChild size="sm" className="gap-1.5">
              <Link href="/incidents/new">
                <Siren className="w-3.5 h-3.5" />
                Report Incident
              </Link>
            </Button>
          </>
        }
      />

      {/* Active incident banner */}
      {activeIncidents.length > 0 && (
        <Card className="p-4 border-destructive/30 bg-destructive/5">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-destructive/15 border border-destructive/30 flex items-center justify-center shrink-0">
              <Siren className="w-4 h-4 text-destructive" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm font-semibold">{activeIncidents.length} active {activeIncidents.length === 1 ? "incident" : "incidents"} requiring attention</h2>
                <SeverityBadge severity={activeIncidents[0].severity} size="sm" />
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {activeIncidents[0].ref} - {activeIncidents[0].title}
              </p>
            </div>
            <Button asChild size="sm" variant="destructive" className="shrink-0">
              <Link href={`/incidents/${activeIncidents[0].id}`}>
                Respond
                <ArrowUpRight className="w-3.5 h-3.5 ml-1" />
              </Link>
            </Button>
          </div>
        </Card>
      )}

      {/* KPI grid - unique design, not generic 4-card row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KpiCard
          label="Active Incidents"
          value={stats.activeIncidents}
          delta={-12}
          deltaLabel="vs last week"
          icon={<Siren className="w-4 h-4" />}
          accent="destructive"
          sparkline={[3, 5, 4, 6, 2, 4, 3, 5, 4, 2]}
        />
        <KpiCard
          label="Firing Alerts"
          value={stats.openAlerts}
          delta={8}
          deltaLabel="vs yesterday"
          icon={<Bell className="w-4 h-4" />}
          accent="warning"
          sparkline={[2, 4, 3, 5, 4, 6, 3, 2, 4, 3]}
        />
        <KpiCard
          label="Services Healthy"
          value={`${stats.servicesHealthy}/${stats.servicesTotal}`}
          hint={`${stats.servicesDegraded} degraded`}
          icon={<Server className="w-4 h-4" />}
          accent="success"
        />
        <KpiCard
          label="MTTR (30d)"
          value={stats.mttr30d}
          unit="min"
          delta={-8}
          deltaLabel="improving"
          icon={<Clock className="w-4 h-4" />}
          accent="primary"
          sparkline={[22, 20, 19, 21, 18, 17, 19, 18, 17, 18]}
        />
        <KpiCard
          label="SLO Breached"
          value={stats.slosBreached}
          hint={`${stats.slosAtRisk} at risk`}
          icon={<Target className="w-4 h-4" />}
          accent={stats.slosBreached > 0 ? "destructive" : "success"}
        />
        <KpiCard
          label="Deploy Freq"
          value={stats.deploymentFreq}
          unit="/day"
          delta={4}
          deltaLabel="vs last week"
          icon={<Rocket className="w-4 h-4" />}
          accent="info"
          sparkline={[12, 14, 11, 15, 13, 16, 14, 15, 13, 14]}
        />
      </div>

      {/* Main chart grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <LatencyChart
          data={latencyData}
          title="API Latency Percentiles"
          description="p50, p95, p99 across all gateway routes"
        />
        <ErrorRateChart
          data={errorRateData}
          title="Global Error Rate"
          description="5xx rate across all production services"
        />
        <DonutChart
          title="Service Health Distribution"
          description="Current health of all monitored services"
          data={[
            { name: "Operational", value: stats.servicesHealthy },
            { name: "Degraded", value: stats.servicesDegraded },
            { name: "Partial Outage", value: services.filter((s) => s.health === "partial").length },
            { name: "Major Outage", value: services.filter((s) => s.health === "major").length },
          ]}
          centerLabel="Healthy"
          centerValue={`${Math.round((stats.servicesHealthy / stats.servicesTotal) * 100)}%`}
        />
      </div>

      {/* Lower chart grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <IncidentSeverityTrendChart
          data={incidentData}
          title="Incident Volume (30 days)"
          description="Incidents by severity over the last 30 days"
        />
        <MTTRTrendChart
          data={mttrData}
          title="Response Performance"
          description="MTTR, MTTD, and MTTA over the last 30 days"
        />
      </div>

      {/* Active Incidents + On-Call + Recent Deploys */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Active Incidents */}
        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Active Incidents"
            description={`${activeIncidents.length} requiring attention`}
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7"><Link href="/incidents">View all</Link></Button>}
          />
          <div className="space-y-2">
            {activeIncidents.length === 0 ? (
              <div className="text-center py-8 text-sm text-muted-foreground">
                <ShieldCheck className="w-6 h-6 mx-auto mb-2 opacity-50" />
                All clear. No active incidents.
              </div>
            ) : (
              activeIncidents.slice(0, 4).map((inc) => (
                <Link key={inc.id} href={`/incidents/${inc.id}`} className="block p-3 rounded-lg border hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xs font-mono text-muted-foreground">{inc.ref}</span>
                    <SeverityBadge severity={inc.severity} size="sm" />
                    <IncidentStatusBadge status={inc.status} />
                  </div>
                  <div className="text-sm font-medium truncate">{inc.title}</div>
                  <div className="text-xs text-muted-foreground mt-1 flex items-center gap-3">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(inc.startedAt).toLocaleString()}</span>
                    <span>{inc.impactedUsers.toLocaleString()} users</span>
                  </div>
                </Link>
              ))
            )}
          </div>
        </Card>

        {/* Current On-Call */}
        <Card className="p-5 space-y-4">
          <SectionHeading
            title="On-Call Now"
            description="Currently paged engineers"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7"><Link href="/oncall">Schedule</Link></Button>}
          />
          <div className="space-y-3">
            {onCallUser && currentOnCall && (
              <div className="flex items-center gap-3 p-3 rounded-lg border border-primary/30 bg-primary/5">
                <img src={onCallUser.avatarUrl} alt={onCallUser.name} className="w-11 h-11 rounded-full object-cover" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-success animate-status-pulse" />
                    <span className="text-sm font-medium truncate">{onCallUser.name}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{currentOnCall.role} on-call · {onCallUser.team}</div>
                </div>
                <Button variant="outline" size="icon" className="h-8 w-8">
                  <Phone className="w-3.5 h-3.5" />
                </Button>
              </div>
            )}
            <div className="space-y-2">
              {onCallShifts.slice(1, 4).map((shift) => {
                const u = people.find((p) => p.id === shift.userId);
                if (!u) return null;
                return (
                  <div key={shift.id} className="flex items-center gap-2 text-xs">
                    <img src={u.avatarUrl} alt="" className="w-6 h-6 rounded-full object-cover" />
                    <span className="font-medium truncate flex-1">{u.name}</span>
                    <span className="text-muted-foreground">{shift.role}</span>
                    <span className="text-muted-foreground">{new Date(shift.start).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>

        {/* Recent Deployments */}
        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Recent Deployments"
            description="Last 5 production releases"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7"><Link href="/deployments">View all</Link></Button>}
          />
          <div className="space-y-2">
            {deployments.slice(0, 5).map((d) => {
              const svc = services.find((s) => s.id === d.serviceId);
              return (
                <Link key={d.id} href={`/deployments/${d.id}`} className="flex items-center gap-3 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors">
                  <div className="w-8 h-8 rounded-md bg-info/10 border border-info/30 flex items-center justify-center shrink-0">
                    <Rocket className="w-3.5 h-3.5 text-info-foreground" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-mono">{d.version}</span>
                      <span className="text-xs text-muted-foreground truncate">{svc?.name}</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{new Date(d.startedAt).toLocaleString()}</div>
                  </div>
                  <DeploymentStatusBadge status={d.status} />
                </Link>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Firing Alerts + Top Services */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-4">
          <SectionHeading
            title="Firing Alerts"
            description="Highest priority alerts requiring attention"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7"><Link href="/alerts">Inbox</Link></Button>}
          />
          <div className="space-y-2">
            {firingAlerts.length === 0 ? (
              <div className="text-center py-6 text-sm text-muted-foreground">No firing alerts</div>
            ) : (
              firingAlerts.slice(0, 5).map((a) => {
                const svc = services.find((s) => s.id === a.serviceId);
                return (
                  <Link key={a.id} href={`/alerts/${a.id}`} className="flex items-center gap-3 p-2.5 rounded-lg border hover:bg-muted/40 transition-colors">
                    <div className={`w-1 h-10 rounded-full ${a.severity === "critical" ? "bg-destructive" : a.severity === "high" ? "bg-warning" : "bg-info"}`} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono">{a.ref}</span>
                        <SeverityBadge severity={a.severity} size="sm" />
                      </div>
                      <div className="text-xs text-muted-foreground truncate mt-0.5">{a.message}</div>
                    </div>
                    <span className="text-xs text-muted-foreground shrink-0">{svc?.name}</span>
                  </Link>
                );
              })
            )}
          </div>
        </Card>

        <DeploymentFrequencyChart
          data={deployData}
          title="Deployment Frequency (30 days)"
          description="Successful deployments and failures per day"
        />
      </div>

      {/* Top Services by Requests */}
      <HorizontalBarChart
        title="Top Services by Request Volume"
        description="Requests per second across all production services"
        data={services.slice(0, 8).map((s) => ({ name: s.name, value: s.requestsPerSecond }))}
      />

      {/* Quick Links */}
      <Card className="p-5">
        <SectionHeading title="Quick Access" description="Jump to common workflows" />
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2 mt-4">
          {[
            { href: "/incidents/active", label: "Active Incidents", icon: Siren, color: "text-destructive" },
            { href: "/alerts", label: "Alerts Inbox", icon: Bell, color: "text-warning-foreground" },
            { href: "/services", label: "Services Catalog", icon: Server, color: "text-primary" },
            { href: "/reliability/slos", label: "SLO Dashboard", icon: Target, color: "text-success" },
            { href: "/deployments", label: "Deployments", icon: Rocket, color: "text-info-foreground" },
            { href: "/errors", label: "Error Tracking", icon: Bug, color: "text-destructive" },
            { href: "/oncall", label: "On-Call", icon: Phone, color: "text-accent" },
            { href: "/performance/latency", label: "Latency", icon: Gauge, color: "text-primary" },
            { href: "/reliability/uptime", label: "Uptime", icon: Activity, color: "text-success" },
            { href: "/security", label: "Security", icon: ShieldCheck, color: "text-destructive" },
            { href: "/admin/integrations", label: "Integrations", icon: Zap, color: "text-accent" },
            { href: "/admin/api-keys", label: "API Keys", icon: Activity, color: "text-muted-foreground" },
          ].map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="flex flex-col items-start gap-2 p-3 rounded-lg border hover:bg-muted/40 hover:border-primary/30 transition-colors group"
            >
              <link.icon className={`w-4 h-4 ${link.color}`} />
              <span className="text-xs font-medium">{link.label}</span>
            </Link>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
