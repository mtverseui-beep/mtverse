"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Route, Search, RefreshCw, Download, Clock, Layers, CheckCircle2, XCircle,
  TrendingUp, Filter,
} from "lucide-react";
import { services } from "@/lib/data";
import { toast } from "sonner";

interface TraceSummary {
  id: string;
  rootService: string;
  rootOperation: string;
  duration: number; // ms
  spanCount: number;
  servicesInvolved: number;
  status: "ok" | "error" | "partial";
  startedAt: string;
  errorSpans: number;
}

function generateTraces(): TraceSummary[] {
  const operations = [
    "POST /api/v1/checkout", "GET /api/v1/users/me", "POST /api/v1/auth/login",
    "GET /api/v1/invoices", "POST /api/v1/billing/subscribe", "GET /api/v1/webhooks",
    "POST /api/v1/checkout/refund", "GET /api/v1/orders", "PUT /api/v1/users/me",
    "POST /api/v1/payments", "GET /api/v1/health", "POST /api/v1/audit/events",
    "DELETE /api/v1/sessions", "GET /api/v1/notifications", "POST /api/v1/uploads",
    "GET /api/v1/subscriptions", "POST /api/v1/auth/refresh", "GET /api/v1/reports",
    "POST /api/v1/feedback", "GET /api/v1/dashboard",
  ];
  const traces: TraceSummary[] = [];
  for (let i = 0; i < 20; i++) {
    const svc = services[i % services.length];
    const op = operations[i % operations.length];
    const spanCount = Math.floor(Math.random() * 18) + 3;
    const servicesInvolved = Math.min(services.length, Math.floor(Math.random() * 5) + 2);
    const duration = Math.floor(Math.random() * 800) + 40;
    const errorSpans = Math.random() < 0.2 ? Math.floor(Math.random() * 3) + 1 : 0;
    const status: TraceSummary["status"] = errorSpans > 0 ? (errorSpans >= 2 ? "error" : "partial") : "ok";
    const minutesAgo = Math.floor(Math.random() * 60);
    traces.push({
      id: `trace_${Math.random().toString(36).slice(2, 14)}${i}`,
      rootService: svc.name,
      rootOperation: op,
      duration,
      spanCount,
      servicesInvolved,
      status,
      startedAt: new Date(Date.now() - minutesAgo * 60 * 1000).toISOString(),
      errorSpans,
    });
  }
  return traces.sort((a, b) => b.duration - a.duration);
}

const statusConfig: Record<string, { color: string; dot: string; icon: React.ReactNode; label: string }> = {
  ok: { color: "text-success bg-success/15", dot: "bg-success", icon: <CheckCircle2 className="w-3 h-3" />, label: "OK" },
  partial: { color: "text-warning-foreground bg-warning/15", dot: "bg-warning", icon: <Clock className="w-3 h-3" />, label: "Partial" },
  error: { color: "text-destructive bg-destructive/15", dot: "bg-destructive", icon: <XCircle className="w-3 h-3" />, label: "Error" },
};

const serviceColors = [
  "bg-primary", "bg-accent", "bg-info", "bg-warning", "bg-success", "bg-destructive",
  "bg-primary/70", "bg-accent/70", "bg-info/70", "bg-warning/70", "bg-success/70",
];

export default function TraceExplorerPage() {
  const router = useRouter();
  const [traces] = React.useState<TraceSummary[]>(generateTraces);
  const [search, setSearch] = React.useState("");
  const [serviceFilter, setServiceFilter] = React.useState("all");
  const [statusFilter, setStatusFilter] = React.useState("all");
  const [minDuration, setMinDuration] = React.useState("");
  const [maxDuration, setMaxDuration] = React.useState("");

  const filtered = traces.filter((t) => {
    if (serviceFilter !== "all" && t.rootService !== services.find((s) => s.id === serviceFilter)?.name) return false;
    if (statusFilter !== "all" && t.status !== statusFilter) return false;
    if (minDuration && t.duration < parseInt(minDuration)) return false;
    if (maxDuration && t.duration > parseInt(maxDuration)) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!t.id.toLowerCase().includes(q) && !t.rootService.toLowerCase().includes(q) && !t.rootOperation.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  const maxDurationValue = Math.max(...traces.map((t) => t.duration));
  const totalSpans = traces.reduce((s, t) => s + t.spanCount, 0);
  const errorTraces = traces.filter((t) => t.status === "error").length;
  const avgDuration = Math.round(traces.reduce((s, t) => s + t.duration, 0) / traces.length);

  function handleRowClick(traceId: string) {
    router.push(`/traces/${traceId}`);
  }

  return (
    <PageContainer>
      <PageHeader
        title="Trace Explorer"
        description="Distributed traces across all services with span count, duration, and error status."
        breadcrumbs={[{ label: "Logs & Traces" }, { label: "Traces" }]}
        icon={<Route className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total Traces" value={traces.length} hint="last 60 minutes" icon={<Route className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Avg Duration" value={avgDuration} unit="ms" hint="across all traces" icon={<Clock className="w-4 h-4" />} accent="info" />
        <KpiCard label="Total Spans" value={totalSpans} hint="across all traces" icon={<Layers className="w-4 h-4" />} accent="accent" />
        <KpiCard label="Error Traces" value={errorTraces} hint="with failed spans" icon={<XCircle className="w-4 h-4" />} accent={errorTraces > 0 ? "destructive" : "success"} />
      </div>

      {/* Search & filters */}
      <Card className="p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search trace ID, service, or operation..."
              className="pl-9 h-10 font-mono text-sm"
            />
          </div>
          <select
            value={serviceFilter}
            onChange={(e) => setServiceFilter(e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-xs"
          >
            <option value="all">All Services</option>
            {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="h-10 rounded-md border bg-background px-3 text-xs"
          >
            <option value="all">All Status</option>
            <option value="ok">OK</option>
            <option value="partial">Partial</option>
            <option value="error">Error</option>
          </select>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Filter className="w-3 h-3 text-muted-foreground" />
          <span className="text-[11px] text-muted-foreground">Duration range (ms):</span>
          <Input
            type="number"
            value={minDuration}
            onChange={(e) => setMinDuration(e.target.value)}
            placeholder="min"
            className="w-20 h-8 text-xs"
          />
          <span className="text-[11px] text-muted-foreground">—</span>
          <Input
            type="number"
            value={maxDuration}
            onChange={(e) => setMaxDuration(e.target.value)}
            placeholder="max"
            className="w-20 h-8 text-xs"
          />
          {(minDuration || maxDuration || search || serviceFilter !== "all" || statusFilter !== "all") && (
            <Button
              variant="ghost"
              size="sm"
              className="h-8 text-xs"
              onClick={() => { setSearch(""); setMinDuration(""); setMaxDuration(""); setServiceFilter("all"); setStatusFilter("all"); }}
            >
              Clear
            </Button>
          )}
        </div>
      </Card>

      {/* Trace list */}
      <Card className="p-0 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div className="text-sm font-semibold">{filtered.length} traces</div>
          <div className="text-[10px] text-muted-foreground inline-flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> Sorted by duration (slowest first)
          </div>
        </div>
        <div className="divide-y divide-border">
          {filtered.map((t) => {
            const s = statusConfig[t.status];
            const widthPct = (t.duration / maxDurationValue) * 100;
            return (
              <button
                key={t.id}
                onClick={() => handleRowClick(t.id)}
                className="w-full text-left px-4 py-3 hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide shrink-0 ${s.color}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />{s.label}
                  </span>
                  <span className="text-[11px] font-mono text-muted-foreground shrink-0">{t.id}</span>
                  <span className="text-[10px] text-muted-foreground ml-auto shrink-0">{new Date(t.startedAt).toISOString().slice(11, 19)}</span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium truncate">{t.rootOperation}</div>
                    <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
                      <span>{t.rootService}</span>
                      <span>·</span>
                      <span>{t.spanCount} spans</span>
                      <span>·</span>
                      <span>{t.servicesInvolved} services</span>
                      {t.errorSpans > 0 && <Badge variant="outline" className="text-[9px] text-destructive border-destructive/30">{t.errorSpans} errors</Badge>}
                    </div>
                  </div>
                  <div className="w-32 md:w-48 shrink-0">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                        <div
                          className={t.status === "error" ? "bg-destructive" : t.status === "partial" ? "bg-warning" : "bg-primary"}
                          style={{ width: `${widthPct}%`, height: "100%" }}
                        />
                      </div>
                      <span className="text-[11px] font-mono tabular-nums w-14 text-right">{t.duration}ms</span>
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
          {filtered.length === 0 && (
            <div className="px-4 py-12 text-center text-sm text-muted-foreground">No traces match current filters</div>
          )}
        </div>
      </Card>
    </PageContainer>
  );
}
