"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Route, ArrowLeft, Download, Clock, Layers, CheckCircle2, XCircle, Activity,
  ChevronRight, ChevronDown, Server, Hash,
} from "lucide-react";
import { sampleTrace, services } from "@/lib/data";
import type { TraceSpan } from "@/lib/types";
import { toast } from "sonner";

const spanStatusConfig: Record<TraceSpan["status"], { color: string; dot: string; icon: React.ReactNode }> = {
  ok: { color: "text-success bg-success/15", dot: "bg-success", icon: <CheckCircle2 className="w-3 h-3" /> },
  error: { color: "text-destructive bg-destructive/15", dot: "bg-destructive", icon: <XCircle className="w-3 h-3" /> },
  unset: { color: "text-muted-foreground bg-muted", dot: "bg-muted-foreground", icon: <Activity className="w-3 h-3" /> },
};

// Service color palette
const servicePalette = [
  "bg-primary",
  "bg-accent",
  "bg-info",
  "bg-warning",
  "bg-success",
  "bg-destructive",
  "bg-primary/70",
  "bg-accent/70",
  "bg-info/70",
  "bg-warning/70",
  "bg-success/70",
];

export default function TraceDetailsPage() {
  const params = useParams();
  const id = params?.id as string | undefined;

  const spans = React.useMemo(() => sampleTrace(), []);
  // Override traceId if id is provided
  const traceId = id ?? spans[0]?.traceId ?? "trace_a3f2c1b8e7d2";

  const totalDuration = Math.max(...spans.map((s) => s.startMs + s.durationMs));
  const rootSpan = spans.find((s) => !s.parentSpanId) ?? spans[0];
  const rootSvc = services.find((s) => s.id === rootSpan?.serviceId);
  const servicesInvolved = new Set(spans.map((s) => s.serviceId));
  const errorSpans = spans.filter((s) => s.status === "error");

  // Map serviceId to color
  const svcColorMap = React.useMemo(() => {
    const m = new Map<string, string>();
    Array.from(servicesInvolved).forEach((id, i) => m.set(id, servicePalette[i % servicePalette.length]));
    return m;
  }, [servicesInvolved]);

  const [selectedSpan, setSelectedSpan] = React.useState<TraceSpan | null>(spans[0]);
  const [expandedRows, setExpandedRows] = React.useState<Set<string>>(new Set([spans[0]?.id]));

  function toggleRow(id: string) {
    setExpandedRows((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  }

  return (
    <PageContainer wide>
      <PageHeader
        title={`Trace ${traceId.slice(0, 18)}...`}
        description={`${rootSvc?.name ?? "Service"} · ${rootSpan?.name ?? "operation"} · ${totalDuration}ms total`}
        breadcrumbs={[{ label: "Traces", href: "/traces" }, { label: traceId.slice(0, 16) }]}
        icon={<Route className="w-5 h-5" />}
        actions={
          <>
            <Button asChild variant="outline" size="sm" className="gap-1.5">
              <Link href="/traces"><ArrowLeft className="w-3.5 h-3.5" /><span className="hidden md:inline">Back</span></Link>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Trace exported as JSON")}><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      {/* Hero KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Total Duration</div>
          <div className="text-2xl font-semibold tabular-nums mt-1">{totalDuration}<span className="text-sm text-muted-foreground ml-1">ms</span></div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Span Count</div>
          <div className="text-2xl font-semibold tabular-nums mt-1">{spans.length}</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Services Involved</div>
          <div className="text-2xl font-semibold tabular-nums mt-1">{servicesInvolved.size}</div>
        </Card>
        <Card className="p-4">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Error Spans</div>
          <div className={`text-2xl font-semibold tabular-nums mt-1 ${errorSpans.length > 0 ? "text-destructive" : "text-success"}`}>{errorSpans.length}</div>
        </Card>
      </div>

      {/* Waterfall + Span attributes */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Waterfall */}
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading title="Waterfall View" description="Each span positioned by start time, width by duration, color by service" />
          <div className="space-y-3">
            {/* Time axis */}
            <div className="flex items-center text-[10px] text-muted-foreground font-mono pl-44 pr-2">
              <span>0ms</span>
              <div className="flex-1 mx-2 h-px bg-border" />
              <span>{totalDuration}ms</span>
            </div>

            {spans.map((span) => {
              const svc = services.find((s) => s.id === span.serviceId);
              const s = spanStatusConfig[span.status];
              const leftPct = (span.startMs / totalDuration) * 100;
              const widthPct = Math.max(2, (span.durationMs / totalDuration) * 100);
              const color = svcColorMap.get(span.serviceId);
              const isSelected = selectedSpan?.id === span.id;
              return (
                <button
                  key={span.id}
                  onClick={() => setSelectedSpan(span)}
                  className={`w-full text-left flex items-center gap-2 p-2 rounded-md transition-colors ${isSelected ? "bg-primary/5 ring-1 ring-primary/20" : "hover:bg-muted/30"}`}
                >
                  <div className="w-40 shrink-0 min-w-0">
                    <div className="text-[11px] font-mono truncate">{span.name}</div>
                    <div className="text-[9px] text-muted-foreground truncate">{svc?.name} · {span.id}</div>
                  </div>
                  <div className="relative flex-1 h-6">
                    <div
                      className={`absolute top-0 h-6 rounded ${color} ${span.status === "error" ? "ring-1 ring-destructive" : ""} flex items-center px-1.5 group`}
                      style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                    >
                      <span className="text-[9px] font-mono text-white truncate">{span.durationMs}ms</span>
                    </div>
                  </div>
                  <span className={`inline-flex items-center gap-1 px-1 py-0.5 rounded text-[9px] font-medium uppercase shrink-0 ${s.color}`}>
                    <span className={`w-1 h-1 rounded-full ${s.dot}`} />{span.status}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Legend */}
          <Separator />
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Services:</span>
            {Array.from(servicesInvolved).map((id) => {
              const svc = services.find((s) => s.id === id);
              return (
                <span key={id} className="inline-flex items-center gap-1 text-[10px]">
                  <span className={`w-2 h-2 rounded-sm ${svcColorMap.get(id)}`} />
                  {svc?.name}
                </span>
              );
            })}
          </div>
        </Card>

        {/* Span details */}
        <Card className="p-5 space-y-4">
          <SectionHeading title="Span Details" description="Selected span attributes" />
          {selectedSpan ? (
            <>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Name</div>
                <div className="text-sm font-mono font-medium">{selectedSpan.name}</div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Service</div>
                  <div className="text-xs">{services.find((s) => s.id === selectedSpan.serviceId)?.name}</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Span ID</div>
                  <div className="text-[11px] font-mono">{selectedSpan.id}</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Start</div>
                  <div className="text-[11px] font-mono tabular-nums">{selectedSpan.startMs}ms</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Duration</div>
                  <div className="text-[11px] font-mono tabular-nums">{selectedSpan.durationMs}ms</div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Status</div>
                  <span className={`inline-flex items-center gap-1 px-1 py-0.5 rounded text-[9px] font-medium uppercase ${spanStatusConfig[selectedSpan.status].color}`}>
                    {selectedSpan.status}
                  </span>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Parent</div>
                  <div className="text-[11px] font-mono">{selectedSpan.parentSpanId ?? "—"}</div>
                </div>
              </div>
              <Separator />
              <div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Attributes</div>
                <div className="space-y-1.5 max-h-[280px] overflow-y-auto pr-1">
                  {Object.entries(selectedSpan.attributes).map(([k, v]) => (
                    <div key={k} className="flex items-center justify-between gap-2 text-[11px]">
                      <span className="font-mono text-muted-foreground">{k}</span>
                      <span className="font-mono break-all text-right">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="text-xs text-muted-foreground">Select a span to view its attributes.</div>
          )}
        </Card>
      </div>

      {/* Span list table */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Span List" description="All spans in this trace, sortable" />
        <div className="rounded-lg border overflow-hidden overflow-x-auto">
          <table className="w-full text-xs min-w-[700px]">
            <thead className="bg-muted/40">
              <tr>
                <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Name</th>
                <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Service</th>
                <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Start</th>
                <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Duration</th>
                <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Attributes</th>
              </tr>
            </thead>
            <tbody>
              {spans.map((span) => {
                const svc = services.find((s) => s.id === span.serviceId);
                const s = spanStatusConfig[span.status];
                const isOpen = expandedRows.has(span.id);
                return (
                  <React.Fragment key={span.id}>
                    <tr
                      className="border-t border-border hover:bg-muted/30 cursor-pointer"
                      onClick={() => { toggleRow(span.id); setSelectedSpan(span); }}
                    >
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-1.5">
                          {isOpen ? <ChevronDown className="w-3 h-3 text-muted-foreground" /> : <ChevronRight className="w-3 h-3 text-muted-foreground" />}
                          <span className="font-mono">{span.name}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2">
                        <span className="inline-flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-sm ${svcColorMap.get(span.serviceId)}`} />
                          {svc?.name}
                        </span>
                      </td>
                      <td className="px-3 py-2 font-mono tabular-nums">{span.startMs}ms</td>
                      <td className="px-3 py-2 font-mono tabular-nums">{span.durationMs}ms</td>
                      <td className="px-3 py-2">
                        <span className={`inline-flex items-center gap-1 px-1 py-0.5 rounded text-[9px] font-medium uppercase ${s.color}`}>
                          <span className={`w-1 h-1 rounded-full ${s.dot}`} />{span.status}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">{Object.keys(span.attributes).length} attrs</td>
                    </tr>
                    {isOpen && (
                      <tr className="bg-muted/20">
                        <td colSpan={6} className="px-3 py-3">
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                            {Object.entries(span.attributes).map(([k, v]) => (
                              <div key={k} className="text-[10px]">
                                <div className="font-mono text-muted-foreground">{k}</div>
                                <div className="font-mono break-all">{v}</div>
                              </div>
                            ))}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </PageContainer>
  );
}
