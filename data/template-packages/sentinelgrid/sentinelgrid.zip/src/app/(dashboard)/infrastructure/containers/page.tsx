"use client";

import * as React from "react";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Box, RefreshCw, Download, Cpu, Play, Square, Container,
} from "lucide-react";
import { hosts } from "@/lib/data";
import { toast } from "sonner";

interface Container {
  id: string;
  name: string;
  image: string;
  hostId: string;
  status: "running" | "stopped" | "paused";
  cpu: number;
  memory: number;
  restartCount: number;
  createdAt: string;
}

function generateContainers(): Container[] {
  const images = [
    { name: "api-gateway", image: "sentinelgrid/api-gateway:v2.4.1" },
    { name: "checkout-api", image: "sentinelgrid/checkout-api:v2.4.1-rc1" },
    { name: "billing-worker", image: "sentinelgrid/billing-worker:v5.1.0" },
    { name: "auth-service", image: "sentinelgrid/auth-service:v1.8.2" },
    { name: "redis-cluster", image: "redis:7.2.3-alpine" },
    { name: "postgres-primary", image: "postgres:16.1-alpine" },
    { name: "kafka-broker", image: "confluentinc/cp-kafka:7.5.0" },
    { name: "web-app", image: "sentinelgrid/web-app:v4.2.0" },
    { name: "vault", image: "hashicorp/vault:1.18.0" },
    { name: "node-exporter", image: "prom/node-exporter:v1.7.0" },
  ];
  const out: Container[] = [];
  for (let i = 0; i < 25; i++) {
    const img = images[i % images.length];
    const host = hosts[i % hosts.length];
    const status: Container["status"] = i % 7 === 0 ? "stopped" : i % 11 === 0 ? "paused" : "running";
    out.push({
      id: `ctr${i.toString().padStart(3, "0")}`,
      name: `${img.name}-${i}`,
      image: img.image,
      hostId: host.id,
      status,
      cpu: status === "running" ? Math.round(Math.random() * 80 + 5) : 0,
      memory: status === "running" ? Math.round(Math.random() * 800 + 50) : 0,
      restartCount: Math.floor(Math.random() * 8),
      createdAt: `2026-0${(i % 6) + 1}-${String((i % 28) + 1).padStart(2, "0")}T${String(i % 24).padStart(2, "0")}:14:00Z`,
    });
  }
  return out;
}

const containerData = generateContainers();

export default function ContainersPage() {
  const total = containerData.length;
  const running = containerData.filter((c) => c.status === "running").length;
  const stopped = containerData.filter((c) => c.status === "stopped").length;
  const avgCpu = Math.round(containerData.filter((c) => c.status === "running").reduce((s, c) => s + c.cpu, 0) / running);

  const statusColors: Record<string, string> = {
    running: "text-success bg-success/15",
    stopped: "text-destructive bg-destructive/15",
    paused: "text-warning-foreground bg-warning/15",
  };

  function handleRestart(id: string) {
    toast.success(`Container ${id} restart requested`, { description: "Container will be recreated with the same configuration." });
  }

  const columns: Column<Container>[] = [
    {
      key: "id", header: "Container ID", sortable: true, sortValue: (r) => r.id,
      cell: (r) => <span className="text-xs font-mono text-muted-foreground">{r.id}</span>,
    },
    {
      key: "name", header: "Name", sortable: true, sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-0">
          <Container className="w-3.5 h-3.5 text-primary shrink-0" />
          <span className="text-xs font-medium truncate">{r.name}</span>
        </div>
      ),
    },
    {
      key: "image", header: "Image",
      cell: (r) => <span className="text-[11px] font-mono text-muted-foreground truncate">{r.image}</span>,
      hideOnMobile: true,
    },
    {
      key: "host", header: "Host",
      cell: (r) => { const h = hosts.find((x) => x.id === r.hostId); return <span className="text-[11px] font-mono">{h?.hostname ?? "—"}</span>; },
      filterable: true,
      filterOptions: hosts.slice(0, 8).map((h) => ({ label: h.hostname, value: h.id })),
      filterFn: (r, v) => r.hostId === v,
      hideOnMobile: true,
    },
    {
      key: "status", header: "Status",
      cell: (r) => (
        <span className={`inline-flex items-center gap-1.5 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide ${statusColors[r.status]}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-current" />{r.status}
        </span>
      ),
      filterable: true,
      filterOptions: [
        { label: "Running", value: "running" }, { label: "Stopped", value: "stopped" }, { label: "Paused", value: "paused" },
      ],
      filterFn: (r, v) => r.status === v,
    },
    {
      key: "cpu", header: "CPU", sortable: true, sortValue: (r) => r.cpu,
      cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.cpu}%</span>,
    },
    {
      key: "memory", header: "Memory", sortable: true, sortValue: (r) => r.memory,
      cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.memory} MB</span>,
      hideOnMobile: true,
    },
    {
      key: "restarts", header: "Restarts", sortable: true, sortValue: (r) => r.restartCount,
      cell: (r) => (
        <span className={`text-[11px] font-mono tabular-nums ${r.restartCount > 5 ? "text-destructive" : r.restartCount > 0 ? "text-warning-foreground" : ""}`}>{r.restartCount}</span>
      ),
      hideOnMobile: true,
    },
    {
      key: "created", header: "Created",
      cell: (r) => <span className="text-[11px] font-mono">{r.createdAt.slice(0, 10)}</span>,
      hideOnMobile: true,
    },
    {
      key: "actions", header: "",
      cell: (r) => (
        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={(e) => { e.stopPropagation(); handleRestart(r.id); }}>
          <RefreshCw className="w-3 h-3" /> <span className="hidden lg:inline">Restart</span>
        </Button>
      ),
      align: "right",
    },
  ];

  function mobileCard(c: Container) {
    const h = hosts.find((x) => x.id === c.hostId);
    return (
      <Card className="p-3 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium font-mono">{c.name}</span>
          <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] uppercase ${statusColors[c.status]}`}>{c.status}</span>
        </div>
        <div className="text-[10px] font-mono text-muted-foreground truncate">{c.image}</div>
        <div className="grid grid-cols-3 gap-1 text-center text-[10px]">
          <div>CPU <span className="font-mono">{c.cpu}%</span></div>
          <div>Mem <span className="font-mono">{c.memory}MB</span></div>
          <div>Rstrt <span className="font-mono">{c.restartCount}</span></div>
        </div>
        <div className="text-[10px] text-muted-foreground">{h?.hostname}</div>
      </Card>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Containers"
        description="Live view of all container instances running across the fleet, including image, status, and restart count."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Containers" }]}
        icon={<Box className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total Containers" value={total} icon={<Box className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Running" value={running} hint={`${((running/total)*100).toFixed(0)}% of fleet`} icon={<Play className="w-4 h-4" />} accent="success" />
        <KpiCard label="Stopped" value={stopped} hint="requires investigation" icon={<Square className="w-4 h-4" />} accent={stopped > 0 ? "warning" : "muted"} />
        <KpiCard label="Avg CPU" value={avgCpu} unit="%" icon={<Cpu className="w-4 h-4" />} accent="info" sparkline={[28, 32, 30, 35, 38, 36, 40, 42]} />
      </div>

      <Card className="p-5 space-y-4">
        <div>
          <h2 className="text-sm font-semibold tracking-tight">Container Inventory</h2>
          <p className="text-xs text-muted-foreground">Filter by host or status to investigate issues</p>
        </div>
        <DataTable
          columns={columns}
          data={containerData}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.name, (r) => r.image, (r) => r.id]}
          searchPlaceholder="Search name, image, ID..."
          pageSize={10}
          initialSort={{ key: "cpu", dir: "desc" }}
          mobileCard={mobileCard}
        />
      </Card>
    </PageContainer>
  );
}
