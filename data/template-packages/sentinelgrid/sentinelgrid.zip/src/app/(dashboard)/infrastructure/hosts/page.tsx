"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Server, Cpu, MemoryStick, HardDrive, RefreshCw, Download, Activity, CircleDot,
} from "lucide-react";
import { hosts, services, environments, regions } from "@/lib/data";

export default function HostsListPage() {
  const router = useRouter();
  const total = hosts.length;
  const running = hosts.filter((h) => h.status === "running").length;
  const cpuAvg = Math.round(hosts.reduce((s, h) => s + h.cpuUsage, 0) / hosts.length);
  const memAvg = Math.round(hosts.reduce((s, h) => s + h.memoryUsage, 0) / hosts.length);

  const statusColors: Record<string, string> = {
    running: "text-success bg-success/15",
    stopped: "text-muted-foreground bg-muted",
    terminated: "text-destructive bg-destructive/15",
    draining: "text-warning-foreground bg-warning/15",
  };

  function UsageBar({ value, label }: { value: number; label: string }) {
    return (
      <div className="flex items-center gap-2 min-w-[100px]">
        <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
          <div className={value >= 85 ? "bg-destructive" : value >= 70 ? "bg-warning" : "bg-success"} style={{ width: `${value}%`, height: "100%" }} />
        </div>
        <span className="text-[11px] tabular-nums font-mono w-8 text-right">{value}{label}</span>
      </div>
    );
  }

  const columns: Column<typeof hosts[number]>[] = [
    { key: "hostname", header: "Hostname", sortable: true, sortValue: (r) => r.hostname, cell: (r) => <span className="text-xs font-mono">{r.hostname}</span> },
    {
      key: "service", header: "Service",
      cell: (r) => { const svc = services.find((s) => s.id === r.serviceId); return <span className="text-xs">{svc?.name ?? "—"}</span>; },
      filterable: true, filterOptions: services.map((s) => ({ label: s.name, value: s.id })), filterFn: (r, v) => r.serviceId === v, hideOnMobile: true,
    },
    {
      key: "environment", header: "Env",
      cell: (r) => <span className="text-[11px] uppercase tracking-wide text-muted-foreground">{r.environment}</span>,
      filterable: true, filterOptions: environments.map((e) => ({ label: e, value: e })), filterFn: (r, v) => r.environment === v, hideOnMobile: true,
    },
    {
      key: "region", header: "Region",
      cell: (r) => <span className="text-xs font-mono">{r.region}</span>,
      filterable: true, filterOptions: regions.map((r) => ({ label: r, value: r })), filterFn: (r, v) => r.region === v, hideOnMobile: true,
    },
    {
      key: "status", header: "Status",
      cell: (r) => (
        <span className={`inline-flex items-center gap-1.5 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide ${statusColors[r.status]}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-current" />{r.status}
        </span>
      ),
      filterable: true,
      filterOptions: [
        { label: "Running", value: "running" }, { label: "Stopped", value: "stopped" },
        { label: "Draining", value: "draining" }, { label: "Terminated", value: "terminated" },
      ],
      filterFn: (r, v) => r.status === v,
    },
    { key: "cpu", header: "CPU", sortable: true, sortValue: (r) => r.cpuUsage, cell: (r) => <UsageBar value={r.cpuUsage} label="%" /> },
    { key: "memory", header: "Memory", sortable: true, sortValue: (r) => r.memoryUsage, cell: (r) => <UsageBar value={r.memoryUsage} label="%" />, hideOnMobile: true },
    { key: "disk", header: "Disk", sortable: true, sortValue: (r) => r.diskUsage, cell: (r) => <UsageBar value={r.diskUsage} label="%" />, hideOnMobile: true },
    { key: "uptime", header: "Uptime", cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.uptime}</span>, hideOnMobile: true },
    { key: "provider", header: "Provider", cell: (r) => <span className="text-[11px] uppercase tracking-wide text-muted-foreground">{r.provider}</span>, hideOnMobile: true },
  ];

  function mobileCard(h: typeof hosts[number]) {
    const svc = services.find((s) => s.id === h.serviceId);
    return (
      <Card className="p-3 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono">{h.hostname}</span>
          <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] uppercase ${statusColors[h.status]}`}>{h.status}</span>
        </div>
        <div className="text-[10px] text-muted-foreground">{svc?.name} · {h.region} · {h.provider}</div>
        <div className="grid grid-cols-3 gap-1 text-center text-[10px]">
          <div>CPU <span className="font-mono">{h.cpuUsage}%</span></div>
          <div>Mem <span className="font-mono">{h.memoryUsage}%</span></div>
          <div>Disk <span className="font-mono">{h.diskUsage}%</span></div>
        </div>
      </Card>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Hosts"
        description="Full inventory of every compute host across all environments, regions, and providers."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Hosts" }]}
        icon={<HardDrive className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total Hosts" value={total} icon={<Server className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Running" value={running} hint={`${((running/total)*100).toFixed(0)}% of fleet`} icon={<CircleDot className="w-4 h-4" />} accent="success" />
        <KpiCard label="Avg CPU" value={cpuAvg} unit="%" icon={<Cpu className="w-4 h-4" />} accent={cpuAvg > 70 ? "warning" : "success"} sparkline={[40, 42, 45, 48, 50, 48, 52, 55]} />
        <KpiCard label="Avg Memory" value={memAvg} unit="%" icon={<MemoryStick className="w-4 h-4" />} accent={memAvg > 80 ? "warning" : "success"} sparkline={[62, 64, 66, 68, 70, 71, 72, 73]} />
      </div>

      <Card className="p-5 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold tracking-tight">Host Inventory</h2>
            <p className="text-xs text-muted-foreground">Click a row to view host details</p>
          </div>
          <span className="text-xs text-muted-foreground inline-flex items-center gap-1"><Activity className="w-3 h-3" /> Live · updated 12s ago</span>
        </div>
        <DataTable
          columns={columns}
          data={hosts}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.hostname, (r) => r.region, (r) => r.instanceType]}
          searchPlaceholder="Search hostname, region, instance..."
          pageSize={10}
          initialSort={{ key: "cpu", dir: "desc" }}
          onRowClick={(r) => router.push(`/infrastructure/hosts/${r.id}`)}
          mobileCard={mobileCard}
        />
      </Card>
    </PageContainer>
  );
}
