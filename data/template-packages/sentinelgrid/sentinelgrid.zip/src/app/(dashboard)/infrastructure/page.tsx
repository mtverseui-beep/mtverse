"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Server, Cpu, HardDrive, MemoryStick, Boxes, Download, RefreshCw,
  Activity, AlertTriangle, ArrowUpRight, Cloud, Globe, Network,
} from "lucide-react";
import { hosts, k8sClusters, services, timeSeries } from "@/lib/data";
import { RadialGauge, DonutChart } from "@/components/charts";

export default function InfrastructureOverviewPage() {
  const totalHosts = hosts.length;
  const runningHosts = hosts.filter((h) => h.status === "running").length;
  const cpuAvg = Math.round(hosts.reduce((s, h) => s + h.cpuUsage, 0) / hosts.length);
  const memAvg = Math.round(hosts.reduce((s, h) => s + h.memoryUsage, 0) / hosts.length);
  const diskAvg = Math.round(hosts.reduce((s, h) => s + h.diskUsage, 0) / hosts.length);
  const totalPods = k8sClusters.reduce((s, c) => s + c.podCount, 0);
  const totalClusters = k8sClusters.length;

  const topHosts = [...hosts].sort((a, b) =>
    (b.cpuUsage + b.memoryUsage + b.diskUsage) - (a.cpuUsage + a.memoryUsage + a.diskUsage)
  ).slice(0, 8);

  const byProvider = ["aws", "gcp", "azure", "self"].map((p) => ({
    name: p.toUpperCase(),
    value: hosts.filter((h) => h.provider === p).length,
  }));

  function gaugeColor(value: number): number {
    if (value >= 85) return 4;
    if (value >= 70) return 2;
    return 3;
  }

  const hostColumns: Column<typeof hosts[number]>[] = [
    {
      key: "hostname",
      header: "Hostname",
      sortable: true,
      sortValue: (r) => r.hostname,
      cell: (r) => (
        <Link href={`/infrastructure/hosts/${r.id}`} className="text-xs font-mono hover:text-primary transition-colors">
          {r.hostname}
        </Link>
      ),
    },
    {
      key: "service",
      header: "Service",
      cell: (r) => {
        const svc = services.find((s) => s.id === r.serviceId);
        return <span className="text-xs">{svc?.name ?? "—"}</span>;
      },
      hideOnMobile: true,
    },
    {
      key: "cpu",
      header: "CPU",
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-[100px]">
          <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
            <div className={r.cpuUsage >= 85 ? "bg-destructive" : r.cpuUsage >= 70 ? "bg-warning" : "bg-success"} style={{ width: `${r.cpuUsage}%`, height: "100%" }} />
          </div>
          <span className="text-[11px] tabular-nums font-mono w-8 text-right">{r.cpuUsage}%</span>
        </div>
      ),
    },
    {
      key: "memory",
      header: "Memory",
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-[100px]">
          <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
            <div className={r.memoryUsage >= 85 ? "bg-destructive" : r.memoryUsage >= 70 ? "bg-warning" : "bg-success"} style={{ width: `${r.memoryUsage}%`, height: "100%" }} />
          </div>
          <span className="text-[11px] tabular-nums font-mono w-8 text-right">{r.memoryUsage}%</span>
        </div>
      ),
      hideOnMobile: true,
    },
    {
      key: "disk",
      header: "Disk",
      cell: (r) => (
        <div className="flex items-center gap-2 min-w-[100px]">
          <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
            <div className={r.diskUsage >= 85 ? "bg-destructive" : r.diskUsage >= 70 ? "bg-warning" : "bg-success"} style={{ width: `${r.diskUsage}%`, height: "100%" }} />
          </div>
          <span className="text-[11px] tabular-nums font-mono w-8 text-right">{r.diskUsage}%</span>
        </div>
      ),
      hideOnMobile: true,
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Infrastructure Overview"
        description="Real-time view of hosts, Kubernetes clusters, and resource utilization across all providers and regions."
        breadcrumbs={[{ label: "Infrastructure" }]}
        icon={<Server className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5">
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Export</span>
            </Button>
          </>
        }
      />

      {/* KPI row - 6 cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KpiCard label="Total Hosts" value={totalHosts} hint={`${runningHosts} running`} icon={<Server className="w-4 h-4" />} accent="primary" />
        <KpiCard label="K8s Clusters" value={totalClusters} hint="across 3 regions" icon={<Boxes className="w-4 h-4" />} accent="accent" />
        <KpiCard label="Total Pods" value={totalPods.toLocaleString()} hint="1284 pods scheduled" icon={<Activity className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg CPU" value={cpuAvg} unit="%" delta={4} deltaLabel="1h" icon={<Cpu className="w-4 h-4" />} accent={cpuAvg > 70 ? "warning" : "success"} sparkline={[38, 42, 45, 48, 52, 49, 55, 58]} />
        <KpiCard label="Avg Memory" value={memAvg} unit="%" delta={2} deltaLabel="1h" icon={<MemoryStick className="w-4 h-4" />} accent={memAvg > 80 ? "warning" : "success"} sparkline={[62, 65, 67, 68, 70, 72, 71, 73]} />
        <KpiCard label="Avg Disk" value={diskAvg} unit="%" delta={1} deltaLabel="1d" icon={<HardDrive className="w-4 h-4" />} accent={diskAvg > 80 ? "destructive" : "info"} />
      </div>

      {/* Radial gauges */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 space-y-4">
          <SectionHeading title="Resource Utilization" description="Live averages across all hosts" />
          <div className="flex flex-wrap justify-around items-center gap-4 py-2">
            <div className="flex flex-col items-center gap-1">
              <RadialGauge value={cpuAvg} target={100} label="CPU" color={gaugeColor(cpuAvg)} size={150} />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">CPU Avg</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <RadialGauge value={memAvg} target={100} label="Memory" color={gaugeColor(memAvg)} size={150} />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Memory Avg</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <RadialGauge value={diskAvg} target={100} label="Disk" color={gaugeColor(diskAvg)} size={150} />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Disk Avg</span>
            </div>
          </div>
        </Card>

        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading
            title="Kubernetes Clusters"
            description="Health, node count, and pod count per cluster"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/infrastructure/kubernetes">View all <ArrowUpRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {k8sClusters.map((c) => (
              <Link key={c.id} href="/infrastructure/kubernetes" className="block p-4 rounded-lg border hover:bg-muted/40 transition-colors">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Boxes className="w-3.5 h-3.5 text-primary shrink-0" />
                      <span className="text-sm font-mono font-medium truncate">{c.name}</span>
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{c.provider} · v{c.version} · {c.region}</div>
                  </div>
                  <span className={`inline-flex items-center gap-1 text-[11px] font-medium shrink-0 ${c.status === "healthy" ? "text-success" : c.status === "warning" ? "text-warning-foreground" : "text-destructive"}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${c.status === "healthy" ? "bg-success" : c.status === "warning" ? "bg-warning" : "bg-destructive"} ${c.status !== "healthy" ? "animate-status-pulse" : ""}`} />
                    <span className="capitalize">{c.status}</span>
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2 text-center">
                  <div>
                    <div className="text-base font-semibold tabular-nums">{c.nodeCount}</div>
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Nodes</div>
                  </div>
                  <div>
                    <div className="text-base font-semibold tabular-nums">{c.podCount}</div>
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Pods</div>
                  </div>
                  <div>
                    <div className={`text-base font-semibold tabular-nums ${c.cpuUsage >= 70 ? "text-warning-foreground" : ""}`}>{c.cpuUsage}%</div>
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">CPU</div>
                  </div>
                  <div>
                    <div className={`text-base font-semibold tabular-nums ${c.memoryUsage >= 70 ? "text-warning-foreground" : ""}`}>{c.memoryUsage}%</div>
                    <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Mem</div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </Card>
      </div>

      {/* Top hosts by resource usage + Provider distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading
            title="Top Hosts by Resource Usage"
            description="Hosts with highest combined CPU + memory + disk pressure"
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/infrastructure/hosts">All hosts <ArrowUpRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {topHosts.map((h, i) => {
              const svc = services.find((s) => s.id === h.serviceId);
              const isCritical = h.cpuUsage >= 80 || h.memoryUsage >= 80 || h.diskUsage >= 80;
              return (
                <Link
                  key={h.id}
                  href={`/infrastructure/hosts/${h.id}`}
                  className={`flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/40 transition-colors ${isCritical ? "border-destructive/30 bg-destructive/5" : ""}`}
                >
                  <div className={`shrink-0 w-8 h-8 rounded-md flex items-center justify-center text-xs font-bold tabular-nums ${isCritical ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground"}`}>
                    #{i + 1}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-xs font-mono truncate">{h.hostname}</span>
                      {isCritical && <AlertTriangle className="w-3 h-3 text-destructive shrink-0" />}
                    </div>
                    <div className="text-[10px] text-muted-foreground">{svc?.name} · {h.region} · {h.instanceType}</div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-center">
                      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">CPU</div>
                      <div className={`text-xs font-mono font-medium tabular-nums ${h.cpuUsage >= 80 ? "text-destructive" : h.cpuUsage >= 60 ? "text-warning-foreground" : "text-success"}`}>{h.cpuUsage}%</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Mem</div>
                      <div className={`text-xs font-mono font-medium tabular-nums ${h.memoryUsage >= 80 ? "text-destructive" : h.memoryUsage >= 60 ? "text-warning-foreground" : "text-success"}`}>{h.memoryUsage}%</div>
                    </div>
                    <div className="text-center">
                      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Disk</div>
                      <div className={`text-xs font-mono font-medium tabular-nums ${h.diskUsage >= 80 ? "text-destructive" : h.diskUsage >= 60 ? "text-warning-foreground" : "text-success"}`}>{h.diskUsage}%</div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </Card>

        <DonutChart
          title="Provider Distribution"
          description="Hosts by cloud provider"
          data={byProvider}
          centerLabel="Hosts"
          centerValue={String(totalHosts)}
        />
      </div>

      {/* All hosts DataTable */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="All Hosts"
          description="Sortable, filterable inventory of every host"
          action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/infrastructure/hosts">Full inventory <ArrowUpRight className="w-3 h-3" /></Link></Button>}
        />
        <DataTable
          columns={hostColumns}
          data={hosts}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.hostname, (r) => r.region]}
          searchPlaceholder="Search hosts..."
          pageSize={5}
        />
      </Card>
    </PageContainer>
  );
}
