"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Network, RefreshCw, Download, ArrowDownToLine, ArrowUpFromLine, Globe, Activity,
  Server, Radio, Wifi, Cpu,
} from "lucide-react";
import { hosts, timeSeries, regions } from "@/lib/data";
import { HorizontalBarChart, ComposedChartCard } from "@/components/charts";

export default function NetworkPage() {
  const ingressTrend = timeSeries(41, 24, 1240, 240).map((d, i) => ({ date: `${String(i).padStart(2, "0")}:00`, value: Math.round(d.value) }));
  const egressTrend = timeSeries(42, 24, 840, 180).map((d, i) => ({ date: `${String(i).padStart(2, "0")}:00`, value: Math.round(d.value) }));
  const combinedTrend = ingressTrend.map((d, i) => ({ date: d.date, ingress: d.value, egress: egressTrend[i].value }));

  // Top talkers
  const topTalkers = [...hosts].sort((a, b) => b.cpuUsage - a.cpuUsage).slice(0, 6).map((h, i) => ({
    name: h.hostname,
    value: Math.round(800 - i * 90 + Math.random() * 60),
  }));

  const interfaces = [
    { name: "eth0", host: "api-gw-prod-us-east-1a-01", ip: "10.42.18.21", rx: "1.24 GB", tx: "840 MB", bandwidth: "1.2 Gbps", status: "up" },
    { name: "eth0", host: "checkout-prod-us-east-1a-01", ip: "10.42.18.31", rx: "948 MB", tx: "412 MB", bandwidth: "940 Mbps", status: "up" },
    { name: "eth0", host: "db-primary-us-east-1a-01", ip: "10.42.18.41", rx: "624 MB", tx: "798 MB", bandwidth: "620 Mbps", status: "up" },
    { name: "eth1", host: "kafka-broker-01", ip: "10.42.19.51", rx: "2.18 GB", tx: "1.94 GB", bandwidth: "2.0 Gbps", status: "up" },
    { name: "eth0", host: "billing-prod-us-east-1a-01", ip: "10.42.18.61", rx: "384 MB", tx: "244 MB", bandwidth: "380 Mbps", status: "up" },
    { name: "eth0", host: "redis-node-01", ip: "10.42.18.71", rx: "1.84 GB", tx: "1.42 GB", bandwidth: "1.8 Gbps", status: "up" },
  ];

  const loadBalancers = [
    { name: "api-gateway-prod-lb", type: "ALB", dns: "api-gw.sentinelgrid.io", targets: 8, healthy: 8, region: "us-east-1", status: "operational" },
    { name: "checkout-prod-lb", type: "ALB", dns: "checkout.sentinelgrid.io", targets: 4, healthy: 4, region: "us-east-1", status: "operational" },
    { name: "auth-prod-lb", type: "NLB", dns: "auth.sentinelgrid.io", targets: 6, healthy: 6, region: "us-east-1", status: "operational" },
    { name: "billing-prod-lb", type: "ALB", dns: "billing.sentinelgrid.io", targets: 4, healthy: 3, region: "us-east-1", status: "degraded" },
    { name: "web-app-prod-lb", type: "ALB", dns: "app.sentinelgrid.io", targets: 12, healthy: 12, region: "global", status: "operational" },
    { name: "auth-eu-prod-lb", type: "NLB", dns: "auth-eu.sentinelgrid.io", targets: 4, healthy: 4, region: "eu-west-1", status: "operational" },
  ];

  const lbStatusConfig: Record<string, string> = {
    operational: "text-success bg-success/15",
    degraded: "text-warning-foreground bg-warning/15",
    down: "text-destructive bg-destructive/15",
  };

  return (
    <PageContainer>
      <PageHeader
        title="Network"
        description="Ingress/egress traffic, active connections, DNS queries, top talkers, network interfaces, and load balancers."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Network" }]}
        icon={<Network className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Ingress Traffic" value="1.24" unit="GB/s" delta={6} deltaLabel="1h" icon={<ArrowDownToLine className="w-4 h-4" />} accent="primary" sparkline={[800, 940, 1100, 1040, 1180, 1240, 1180, 1240]} />
        <KpiCard label="Egress Traffic" value="840" unit="MB/s" delta={3} deltaLabel="1h" icon={<ArrowUpFromLine className="w-4 h-4" />} accent="accent" sparkline={[560, 620, 740, 700, 820, 880, 800, 840]} />
        <KpiCard label="Active Connections" value="184.2K" hint="TCP sessions" icon={<Activity className="w-4 h-4" />} accent="info" />
        <KpiCard label="DNS Queries" value="2.4M" unit="/min" delta={2} deltaLabel="1h" icon={<Globe className="w-4 h-4" />} accent="success" />
      </div>

      {/* Traffic trend */}
      <ComposedChartCard
        title="Network Traffic (24h)"
        description="Ingress vs egress in MB/s"
        data={combinedTrend}
        bars={[]}
        lines={[
          { key: "ingress", name: "Ingress", color: 0 },
          { key: "egress", name: "Egress", color: 4 },
        ]}
        suffix=" MB/s"
      />

      {/* Top talkers + Interfaces */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <HorizontalBarChart
          title="Top Talkers"
          description="Hosts by network throughput (Mbps)"
          data={topTalkers}
          color={2}
        />

        <Card className="p-5 space-y-4">
          <SectionHeading title="Network Interfaces" description="Physical interfaces with live bandwidth" />
          <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
            {interfaces.map((iface, i) => (
              <div key={i} className="flex items-center justify-between gap-3 p-3 rounded-lg border">
                <div className="flex items-center gap-3 min-w-0">
                  <Wifi className="w-3.5 h-3.5 text-primary shrink-0" />
                  <div className="min-w-0">
                    <div className="text-xs font-mono font-medium truncate">{iface.host}</div>
                    <div className="text-[10px] text-muted-foreground font-mono">{iface.name} · {iface.ip}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-right text-[10px] shrink-0">
                  <div>
                    <div className="text-muted-foreground uppercase tracking-wider">RX</div>
                    <div className="font-mono tabular-nums">{iface.rx}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground uppercase tracking-wider">TX</div>
                    <div className="font-mono tabular-nums">{iface.tx}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground uppercase tracking-wider">B/W</div>
                    <div className="font-mono tabular-nums text-primary">{iface.bandwidth}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Load balancers */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Load Balancers" description="Application and network load balancers across regions" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {loadBalancers.map((lb) => (
            <div key={lb.name} className={`p-4 rounded-lg border ${lb.status !== "operational" ? "border-warning/30 bg-warning/5" : ""}`}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Radio className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span className="text-xs font-mono font-medium truncate">{lb.name}</span>
                  </div>
                  <div className="text-[10px] text-muted-foreground font-mono mt-1">{lb.dns}</div>
                </div>
                <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide shrink-0 ${lbStatusConfig[lb.status]}`}>
                  <span className={`w-1.5 h-1.5 rounded-full bg-current`} />{lb.status}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-[10px] mt-3 pt-3 border-t border-border">
                <div>
                  <div className="font-semibold tabular-nums">{lb.type}</div>
                  <div className="text-muted-foreground uppercase tracking-wider">Type</div>
                </div>
                <div>
                  <div className="font-semibold tabular-nums">{lb.healthy}/{lb.targets}</div>
                  <div className="text-muted-foreground uppercase tracking-wider">Healthy</div>
                </div>
                <div>
                  <div className="font-semibold tabular-nums">{lb.region}</div>
                  <div className="text-muted-foreground uppercase tracking-wider">Region</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
