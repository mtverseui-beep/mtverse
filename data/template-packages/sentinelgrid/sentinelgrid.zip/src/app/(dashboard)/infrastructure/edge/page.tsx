"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Cloud, RefreshCw, Download, Globe, Activity, Zap, Server, ArrowDownToLine,
  TrendingUp,
} from "lucide-react";
import { LineChartCard, HorizontalBarChart } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";

interface EdgeLocation {
  id: string;
  city: string;
  code: string;
  region: string;
  status: "operational" | "degraded" | "offline";
  requests: number;
  bandwidth: number; // Gbps
  cacheHitRatio: number;
}

const edgeLocations: EdgeLocation[] = [
  { id: "e1", city: "Ashburn", code: "IAD", region: "us-east", status: "operational", requests: 4280000, bandwidth: 84.2, cacheHitRatio: 94.2 },
  { id: "e2", city: "San Jose", code: "SJC", region: "us-west", status: "operational", requests: 2840000, bandwidth: 62.1, cacheHitRatio: 92.8 },
  { id: "e3", city: "London", code: "LHR", region: "eu-west", status: "operational", requests: 3120000, bandwidth: 71.4, cacheHitRatio: 93.5 },
  { id: "e4", city: "Frankfurt", code: "FRA", region: "eu-central", status: "operational", requests: 2480000, bandwidth: 58.7, cacheHitRatio: 91.4 },
  { id: "e5", city: "Mumbai", code: "BOM", region: "ap-south", status: "degraded", requests: 1840000, bandwidth: 41.8, cacheHitRatio: 78.2 },
  { id: "e6", city: "Singapore", code: "SIN", region: "ap-southeast", status: "operational", requests: 2120000, bandwidth: 48.4, cacheHitRatio: 89.6 },
  { id: "e7", city: "Tokyo", code: "NRT", region: "ap-northeast", status: "operational", requests: 1980000, bandwidth: 44.2, cacheHitRatio: 90.1 },
  { id: "e8", city: "Sydney", code: "SYD", region: "ap-southeast", status: "operational", requests: 1240000, bandwidth: 28.4, cacheHitRatio: 87.8 },
  { id: "e9", city: "São Paulo", code: "GRU", region: "sa-east", status: "operational", requests: 920000, bandwidth: 22.1, cacheHitRatio: 84.2 },
  { id: "e10", city: "Cape Town", code: "CPT", region: "af-south", status: "offline", requests: 0, bandwidth: 0, cacheHitRatio: 0 },
];

const statusConfig: Record<string, { color: string; dot: string }> = {
  operational: { color: "text-success bg-success/15", dot: "bg-success" },
  degraded: { color: "text-warning-foreground bg-warning/15", dot: "bg-warning" },
  offline: { color: "text-destructive bg-destructive/15", dot: "bg-destructive" },
};

const topUrls = [
  { url: "/api/v1/users/me", requests: 1240000, bandwidth: 824, ttfb: 42 },
  { url: "/api/v1/checkout/session", requests: 842000, bandwidth: 1240, ttfb: 184 },
  { url: "/_next/static/chunks/main.js", requests: 684000, bandwidth: 2480, ttfb: 18 },
  { url: "/api/v1/invoices", requests: 412000, bandwidth: 612, ttfb: 68 },
  { url: "/_next/static/media/hero.webp", requests: 384000, bandwidth: 8400, ttfb: 12 },
  { url: "/api/v1/auth/refresh", requests: 348000, bandwidth: 124, ttfb: 38 },
  { url: "/api/v1/billing/subscription", requests: 284000, bandwidth: 484, ttfb: 92 },
  { url: "/_next/static/css/app.css", requests: 248000, bandwidth: 184, ttfb: 14 },
  { url: "/api/v1/webhooks/deliveries", requests: 184000, bandwidth: 84, ttfb: 124 },
];

export default function EdgePage() {
  const totalRequests = edgeLocations.reduce((s, e) => s + e.requests, 0);
  const totalBandwidth = edgeLocations.reduce((s, e) => s + e.bandwidth, 0);
  const operationalLocs = edgeLocations.filter((e) => e.status === "operational").length;
  const avgHitRatio = Math.round(edgeLocations.filter((e) => e.status !== "offline").reduce((s, e) => s + e.cacheHitRatio, 0) / edgeLocations.filter((e) => e.status !== "offline").length);
  const originFetches = Math.round(totalRequests * (1 - avgHitRatio / 100));

  const hitRatioTrend = timeSeries(51, 24, avgHitRatio, 4).map((d, i) => ({ date: `${String(i).padStart(2, "0")}:00`, value: Math.round(d.value * 10) / 10 }));

  const topLocs = [...edgeLocations].filter((e) => e.status !== "offline").sort((a, b) => b.requests - a.requests).slice(0, 6).map((e) => ({ name: e.code, value: e.requests }));

  function handlePurge() { toast.success("Edge cache purge initiated", { description: "All edge locations will invalidate their cached objects within 60 seconds." }); }

  const urlColumns: Column<typeof topUrls[number]>[] = [
    { key: "url", header: "URL", sortable: true, sortValue: (r) => r.url, cell: (r) => <span className="text-[11px] font-mono truncate">{r.url}</span> },
    { key: "requests", header: "Requests", sortable: true, sortValue: (r) => r.requests, cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.requests.toLocaleString()}</span> },
    { key: "bandwidth", header: "Bandwidth (MB)", sortable: true, sortValue: (r) => r.bandwidth, cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.bandwidth.toLocaleString()}</span>, hideOnMobile: true },
    { key: "ttfb", header: "TTFB (ms)", sortable: true, sortValue: (r) => r.ttfb, cell: (r) => <span className={`text-[11px] font-mono tabular-nums ${r.ttfb > 100 ? "text-warning-foreground" : ""}`}>{r.ttfb}</span>, hideOnMobile: true },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Edge / CDN"
        description="Edge locations, cache hit ratio, origin fetches, top URLs, and edge bandwidth worldwide."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Edge / CDN" }]}
        icon={<Cloud className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handlePurge}><Zap className="w-3.5 h-3.5" /><span className="hidden md:inline">Purge Cache</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Edge Requests" value={(totalRequests / 1e6).toFixed(2)} unit="M" delta={8} deltaLabel="1h" icon={<Globe className="w-4 h-4" />} accent="primary" sparkline={[16.2, 17.8, 18.4, 19.2, 20.1, 19.6, 20.8, 21.4]} />
        <KpiCard label="Cache Hit Ratio" value={avgHitRatio} unit="%" delta={1.2} deltaLabel="1h" icon={<Activity className="w-4 h-4" />} accent="success" sparkline={[88, 89, 90, 91, 90, 92, 91, 92]} />
        <KpiCard label="Origin Fetches" value={(originFetches / 1e6).toFixed(2)} unit="M" hint={`${100 - avgHitRatio}% miss rate`} icon={<ArrowDownToLine className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Edge Bandwidth" value={totalBandwidth.toFixed(1)} unit="Gbps" hint={`${operationalLocs}/${edgeLocations.length} locations online`} icon={<TrendingUp className="w-4 h-4" />} accent="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <LineChartCard data={hitRatioTrend} dataKey="value" color={3} title="Cache Hit Ratio (24h)" description="Aggregate across all edge locations" suffix="%" />
        </div>
        <HorizontalBarChart
          title="Top Edge Locations"
          description="By request volume"
          data={topLocs}
          color={0}
        />
      </div>

      {/* Edge locations */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Edge Locations" description="PoPs worldwide with live traffic and cache performance" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {edgeLocations.map((loc) => {
            const s = statusConfig[loc.status];
            return (
              <div key={loc.id} className={`p-4 rounded-lg border ${loc.status === "offline" ? "border-destructive/30 bg-destructive/5" : loc.status === "degraded" ? "border-warning/30 bg-warning/5" : ""}`}>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-primary shrink-0" />
                    <div>
                      <div className="text-sm font-semibold">{loc.city}</div>
                      <div className="text-[10px] text-muted-foreground font-mono">{loc.code} · {loc.region}</div>
                    </div>
                  </div>
                  <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide ${s.color}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${s.dot} ${loc.status !== "operational" ? "animate-status-pulse" : ""}`} />{loc.status}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center text-[10px] pt-3 border-t border-border">
                  <div>
                    <div className="font-semibold tabular-nums">{loc.status === "offline" ? "—" : (loc.requests / 1e6).toFixed(1) + "M"}</div>
                    <div className="text-muted-foreground uppercase tracking-wider">Req</div>
                  </div>
                  <div>
                    <div className="font-semibold tabular-nums">{loc.status === "offline" ? "—" : loc.bandwidth}</div>
                    <div className="text-muted-foreground uppercase tracking-wider">Gbps</div>
                  </div>
                  <div>
                    <div className={`font-semibold tabular-nums ${loc.cacheHitRatio < 85 && loc.status !== "offline" ? "text-warning-foreground" : ""}`}>{loc.status === "offline" ? "—" : loc.cacheHitRatio + "%"}</div>
                    <div className="text-muted-foreground uppercase tracking-wider">Hit</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Top URLs */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Top URLs at Edge" description="Most-requested objects served from edge locations" />
        <DataTable
          columns={urlColumns}
          data={topUrls}
          rowKey={(r) => r.url}
          searchKeys={[(r) => r.url]}
          searchPlaceholder="Search URL path..."
          pageSize={10}
          initialSort={{ key: "requests", dir: "desc" }}
        />
      </Card>
    </PageContainer>
  );
}
