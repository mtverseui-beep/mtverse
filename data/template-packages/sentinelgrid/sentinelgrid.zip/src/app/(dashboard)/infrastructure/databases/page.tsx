"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Database, HardDrive, Activity, Zap, RefreshCw, Server, Cloud, GitBranch,
  CheckCircle2, AlertTriangle, Boxes,
} from "lucide-react";
import { services } from "@/lib/data";
import { DonutChart, HorizontalBarChart } from "@/components/charts";
import { toast } from "sonner";

interface DatabaseInstance {
  id: string;
  type: "PostgreSQL" | "Redis" | "Kafka" | "MySQL" | "MongoDB" | "Elasticsearch";
  version: string;
  engine: string;
  instances: number;
  totalStorage: number; // GB
  usedStorage: number;
  qps: number;
  replicationStatus: "in_sync" | "lagging" | "down";
  replicationLag: number; // seconds
  region: string;
  status: "operational" | "degraded" | "down";
}

const databases: DatabaseInstance[] = [
  { id: "db1", type: "PostgreSQL", version: "16.1", engine: "Aurora PostgreSQL", instances: 3, totalStorage: 2048, usedStorage: 1342, qps: 42500, replicationStatus: "in_sync", replicationLag: 0, region: "us-east-1", status: "operational" },
  { id: "db2", type: "Redis", version: "7.2.3", engine: "ElastiCache Redis", instances: 6, totalStorage: 384, usedStorage: 268, qps: 128400, replicationStatus: "in_sync", replicationLag: 0, region: "us-east-1", status: "operational" },
  { id: "db3", type: "Kafka", version: "3.7.0", engine: "MSK Kafka", instances: 5, totalStorage: 4096, usedStorage: 2814, qps: 88200, replicationStatus: "in_sync", replicationLag: 0, region: "us-east-1", status: "operational" },
  { id: "db4", type: "MongoDB", version: "7.0.5", engine: "DocumentDB", instances: 3, totalStorage: 1024, usedStorage: 412, qps: 6800, replicationStatus: "lagging", replicationLag: 12, region: "eu-west-1", status: "degraded" },
  { id: "db5", type: "Elasticsearch", version: "8.12.0", engine: "OpenSearch", instances: 9, totalStorage: 8192, usedStorage: 5234, qps: 18400, replicationStatus: "in_sync", replicationLag: 0, region: "us-east-1", status: "operational" },
  { id: "db6", type: "MySQL", version: "8.0.34", engine: "Aurora MySQL", instances: 2, totalStorage: 512, usedStorage: 188, qps: 3200, replicationStatus: "in_sync", replicationLag: 0, region: "ap-south-1", status: "operational" },
];

const statusConfig: Record<string, { color: string; dot: string; label: string }> = {
  operational: { color: "text-success bg-success/15 border-success/30", dot: "bg-success", label: "Operational" },
  degraded: { color: "text-warning-foreground bg-warning/15 border-warning/30", dot: "bg-warning", label: "Degraded" },
  down: { color: "text-destructive bg-destructive/15 border-destructive/30", dot: "bg-destructive", label: "Down" },
};

const replicationConfig: Record<string, { color: string; label: string }> = {
  in_sync: { color: "text-success", label: "In Sync" },
  lagging: { color: "text-warning-foreground", label: "Lagging" },
  down: { color: "text-destructive", label: "Down" },
};

const typeIcons: Record<string, React.ReactNode> = {
  PostgreSQL: <Database className="w-4 h-4" />,
  Redis: <Zap className="w-4 h-4" />,
  Kafka: <GitBranch className="w-4 h-4" />,
  MongoDB: <Database className="w-4 h-4" />,
  Elasticsearch: <Boxes className="w-4 h-4" />,
  MySQL: <Database className="w-4 h-4" />,
};

export default function DatabasesPage() {
  const totalDbs = databases.length;
  const totalStorage = databases.reduce((s, d) => s + d.totalStorage, 0);
  const avgQps = Math.round(databases.reduce((s, d) => s + d.qps, 0) / databases.length);
  const avgLag = Math.round(databases.reduce((s, d) => s + d.replicationLag, 0) / databases.length);

  const byType = Object.entries(databases.reduce((acc, d) => {
    acc[d.type] = (acc[d.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>)).map(([name, value]) => ({ name, value }));

  const qpsData = [...databases].sort((a, b) => b.qps - a.qps).slice(0, 6).map((d) => ({ name: d.type, value: d.qps }));

  function handleRefresh() { toast.success("Database metrics refreshed", { description: "Latest query throughput and replication status retrieved." }); }

  return (
    <PageContainer>
      <PageHeader
        title="Databases"
        description="Managed databases, caches, and message brokers across all environments with live throughput and replication status."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Databases" }]}
        icon={<Database className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handleRefresh}><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total DBs" value={totalDbs} hint="6 distinct engines" icon={<Database className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Total Storage" value={(totalStorage / 1024).toFixed(1)} unit="TB" hint="across 28 instances" icon={<HardDrive className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg QPS" value={avgQps.toLocaleString()} delta={5} deltaLabel="1h" icon={<Activity className="w-4 h-4" />} accent="success" />
        <KpiCard label="Replication Lag" value={avgLag} unit="s" hint={avgLag > 0 ? "1 database lagging" : "All in sync"} icon={<AlertTriangle className="w-4 h-4" />} accent={avgLag > 5 ? "warning" : "success"} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <DonutChart
          title="Databases by Type"
          description="Engine distribution across the fleet"
          data={byType}
          centerLabel="Engines"
          centerValue={String(totalDbs)}
        />
        <div className="lg:col-span-2">
          <HorizontalBarChart
            title="Queries per Second (Top 6)"
            description="Throughput by database engine"
            data={qpsData}
            color={2}
          />
        </div>
      </div>

      {/* Database cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {databases.map((db) => {
          const s = statusConfig[db.status];
          const r = replicationConfig[db.replicationStatus];
          const usedPct = Math.round((db.usedStorage / db.totalStorage) * 100);
          return (
            <Card key={db.id} className="p-5 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="shrink-0 w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    {typeIcons[db.type]}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold">{db.type}</h3>
                    <div className="text-[10px] text-muted-foreground">{db.engine} · v{db.version}</div>
                  </div>
                </div>
                <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium border ${s.color}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${s.dot} ${db.status !== "operational" ? "animate-status-pulse" : ""}`} />
                  {s.label}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="text-base font-semibold tabular-nums">{db.instances}</div>
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Instances</div>
                </div>
                <div>
                  <div className="text-base font-semibold tabular-nums">{db.qps.toLocaleString()}</div>
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">QPS</div>
                </div>
                <div>
                  <div className="text-base font-semibold tabular-nums">{db.totalStorage} GB</div>
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Capacity</div>
                </div>
              </div>

              {/* Storage bar */}
              <div>
                <div className="flex items-center justify-between text-[10px] mb-1">
                  <span className="text-muted-foreground">Storage used</span>
                  <span className="font-mono tabular-nums">{db.usedStorage} / {db.totalStorage} GB ({usedPct}%)</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className={usedPct >= 85 ? "bg-destructive" : usedPct >= 70 ? "bg-warning" : "bg-success"} style={{ width: `${usedPct}%`, height: "100%" }} />
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-border">
                <div className="flex items-center gap-3 text-[11px]">
                  <span className="text-muted-foreground inline-flex items-center gap-1"><Server className="w-3 h-3" /> {db.region}</span>
                  <span className={`inline-flex items-center gap-1 font-medium ${r.color}`}>
                    {db.replicationStatus === "in_sync" ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {r.label}
                    {db.replicationLag > 0 && <span className="font-mono">({db.replicationLag}s)</span>}
                  </span>
                </div>
                <Badge variant="outline" className="text-[9px] uppercase">{db.region}</Badge>
              </div>
            </Card>
          );
        })}
      </div>

      <Card className="p-5 space-y-3">
        <SectionHeading title="Replication Topology" description="Cross-region read replicas and failover configuration" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="flex items-start gap-3 p-3 rounded-lg border">
            <Cloud className="w-4 h-4 text-info shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium">PostgreSQL primary (us-east-1)</div>
              <p className="text-[11px] text-muted-foreground mt-0.5">2 read replicas in eu-west-1, 1 in ap-south-1. Synchronous replication, RPO 0s.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-lg border">
            <Cloud className="w-4 h-4 text-info shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium">Redis cluster (us-east-1)</div>
              <p className="text-[11px] text-muted-foreground mt-0.5">3 primary shards, 3 replicas. Async replication, RPO &lt; 1s.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-lg border border-warning/30 bg-warning/5">
            <AlertTriangle className="w-4 h-4 text-warning-foreground shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium">MongoDB replica set (eu-west-1)</div>
              <p className="text-[11px] text-muted-foreground mt-0.5">Replication lag at 12s. Investigate network latency or write load.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-lg border">
            <Cloud className="w-4 h-4 text-info shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium">Kafka MSK (us-east-1)</div>
              <p className="text-[11px] text-muted-foreground mt-0.5">3 brokers, RF=3, min ISR=2. MirrorMaker to eu-west-1.</p>
            </div>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
