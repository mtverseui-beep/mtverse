"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  ListOrdered, RefreshCw, Download, Inbox, TrendingUp, AlertTriangle, Users, Zap,
} from "lucide-react";
import { LineChartCard } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";

type QueueType = "Kafka Topic" | "SQS" | "RabbitMQ" | "Kinesis";

interface Queue {
  id: string;
  name: string;
  type: QueueType;
  consumers: number;
  depth: number;
  throughput: number; // msgs/sec
  lag: number;
  dlqCount: number;
  region: string;
  status: "healthy" | "lagging" | "backlogged";
}

const queues: Queue[] = [
  { id: "q1", name: "payment.events", type: "Kafka Topic", consumers: 8, depth: 12450, throughput: 4200, lag: 24, dlqCount: 12, region: "us-east-1", status: "healthy" },
  { id: "q2", name: "checkout.commands", type: "Kafka Topic", consumers: 4, depth: 88200, throughput: 2800, lag: 184, dlqCount: 47, region: "us-east-1", status: "lagging" },
  { id: "q3", name: "billing.invoice-jobs", type: "SQS", consumers: 6, depth: 42100, throughput: 1800, lag: 0, dlqCount: 8, region: "us-east-1", status: "healthy" },
  { id: "q4", name: "user.activity", type: "Kafka Topic", consumers: 12, depth: 256400, throughput: 12400, lag: 84, dlqCount: 22, region: "us-east-1", status: "healthy" },
  { id: "q5", name: "webhook.deliveries", type: "RabbitMQ", consumers: 4, depth: 18400, throughput: 920, lag: 0, dlqCount: 132, region: "eu-west-1", status: "backlogged" },
  { id: "q6", name: "audit.events", type: "Kinesis", consumers: 2, depth: 12800, throughput: 640, lag: 0, dlqCount: 0, region: "us-east-1", status: "healthy" },
  { id: "q7", name: "search.index-updates", type: "Kafka Topic", consumers: 3, depth: 9400, throughput: 480, lag: 12, dlqCount: 4, region: "us-east-1", status: "healthy" },
  { id: "q8", name: "email.notifications", type: "SQS", consumers: 8, depth: 64200, throughput: 2400, lag: 0, dlqCount: 18, region: "eu-west-1", status: "healthy" },
  { id: "q9", name: "fraud.signals", type: "Kafka Topic", consumers: 6, depth: 18400, throughput: 3600, lag: 8, dlqCount: 0, region: "us-east-1", status: "healthy" },
  { id: "q10", name: "image.transforms", type: "RabbitMQ", consumers: 10, depth: 248000, throughput: 1800, lag: 420, dlqCount: 88, region: "us-east-1", status: "backlogged" },
];

const statusConfig: Record<string, { color: string; dot: string }> = {
  healthy: { color: "text-success bg-success/15", dot: "bg-success" },
  lagging: { color: "text-warning-foreground bg-warning/15", dot: "bg-warning" },
  backloged: { color: "text-destructive bg-destructive/15", dot: "bg-destructive" },
  backlogged: { color: "text-destructive bg-destructive/15", dot: "bg-destructive" },
};

const typeColors: Record<QueueType, string> = {
  "Kafka Topic": "bg-primary/15 text-primary border-primary/30",
  "SQS": "bg-accent/15 text-accent-foreground border-accent/30",
  "RabbitMQ": "bg-info/15 text-info-foreground border-info/30",
  "Kinesis": "bg-warning/15 text-warning-foreground border-warning/30",
};

export default function QueuesPage() {
  const total = queues.length;
  const totalDepth = queues.reduce((s, q) => s + q.depth, 0);
  const avgThroughput = Math.round(queues.reduce((s, q) => s + q.throughput, 0) / queues.length);
  const dlqTotal = queues.reduce((s, q) => s + q.dlqCount, 0);

  const depthTrend = timeSeries(31, 24, totalDepth / 1000, 50).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  }));

  function handlePurge(id: string) { toast.success(`Queue ${id} purge requested`, { description: "All in-flight messages will be discarded." }); }

  const columns: Column<Queue>[] = [
    {
      key: "name", header: "Queue Name", sortable: true, sortValue: (r) => r.name,
      cell: (r) => <span className="text-xs font-mono">{r.name}</span>,
    },
    {
      key: "type", header: "Type",
      cell: (r) => <span className={`inline-flex px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide border ${typeColors[r.type]}`}>{r.type}</span>,
      filterable: true,
      filterOptions: Object.keys(typeColors).map((t) => ({ label: t, value: t })),
      filterFn: (r, v) => r.type === v,
    },
    {
      key: "consumers", header: "Consumers", sortable: true, sortValue: (r) => r.consumers,
      cell: (r) => (
        <span className="text-[11px] font-mono tabular-nums inline-flex items-center gap-1">
          <Users className="w-3 h-3 text-muted-foreground" />{r.consumers}
        </span>
      ),
      hideOnMobile: true,
    },
    {
      key: "depth", header: "Depth", sortable: true, sortValue: (r) => r.depth,
      cell: (r) => (
        <span className={`text-[11px] font-mono tabular-nums ${r.depth > 100000 ? "text-destructive" : r.depth > 50000 ? "text-warning-foreground" : ""}`}>
          {r.depth.toLocaleString()}
        </span>
      ),
    },
    {
      key: "throughput", header: "Throughput", sortable: true, sortValue: (r) => r.throughput,
      cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.throughput.toLocaleString()} /s</span>,
      hideOnMobile: true,
    },
    {
      key: "lag", header: "Lag", sortable: true, sortValue: (r) => r.lag,
      cell: (r) => (
        <span className={`text-[11px] font-mono tabular-nums ${r.lag > 100 ? "text-destructive" : r.lag > 20 ? "text-warning-foreground" : ""}`}>
          {r.lag}s
        </span>
      ),
      hideOnMobile: true,
    },
    {
      key: "dlq", header: "DLQ", sortable: true, sortValue: (r) => r.dlqCount,
      cell: (r) => (
        <span className={`text-[11px] font-mono tabular-nums ${r.dlqCount > 50 ? "text-destructive" : r.dlqCount > 10 ? "text-warning-foreground" : ""}`}>
          {r.dlqCount}
        </span>
      ),
      hideOnMobile: true,
    },
    {
      key: "region", header: "Region",
      cell: (r) => <span className="text-[11px] font-mono text-muted-foreground">{r.region}</span>,
      hideOnMobile: true,
    },
    {
      key: "status", header: "Status",
      cell: (r) => {
        const s = statusConfig[r.status];
        return (
          <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide ${s.color}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${s.dot} ${r.status !== "healthy" ? "animate-status-pulse" : ""}`} />{r.status}
          </span>
        );
      },
      filterable: true,
      filterOptions: [
        { label: "Healthy", value: "healthy" }, { label: "Lagging", value: "lagging" }, { label: "Backlogged", value: "backlogged" },
      ],
      filterFn: (r, v) => r.status === v,
    },
    {
      key: "actions", header: "",
      cell: (r) => (
        <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={(e) => { e.stopPropagation(); handlePurge(r.id); }}>Purge</Button>
      ),
      align: "right",
    },
  ];

  function mobileCard(q: Queue) {
    const s = statusConfig[q.status];
    return (
      <Card className="p-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-mono truncate">{q.name}</span>
          <span className={`inline-flex items-center gap-1 px-1 py-0.5 rounded text-[10px] uppercase shrink-0 ${s.color}`}>{q.status}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`inline-flex px-1 py-0.5 rounded text-[10px] uppercase border ${typeColors[q.type]}`}>{q.type}</span>
          <span className="text-[10px] text-muted-foreground">{q.region}</span>
        </div>
        <div className="grid grid-cols-3 gap-1 text-center text-[10px]">
          <div>Depth <span className="font-mono">{q.depth.toLocaleString()}</span></div>
          <div>TPS <span className="font-mono">{q.throughput}</span></div>
          <div>DLQ <span className="font-mono">{q.dlqCount}</span></div>
        </div>
      </Card>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Message Queues"
        description="Kafka topics, SQS, RabbitMQ, and Kinesis streams with depth, throughput, consumer lag, and DLQ counts."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Queues" }]}
        icon={<ListOrdered className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total Queues" value={total} hint="4 distinct backends" icon={<ListOrdered className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Total Depth" value={(totalDepth / 1000).toFixed(1)} unit="K" hint="messages in flight" icon={<Inbox className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg Throughput" value={avgThroughput.toLocaleString()} unit="/s" delta={8} deltaLabel="1h" icon={<TrendingUp className="w-4 h-4" />} accent="success" />
        <KpiCard label="DLQ Count" value={dlqTotal} hint="dead-letter messages" icon={<AlertTriangle className="w-4 h-4" />} accent={dlqTotal > 100 ? "destructive" : "warning"} />
      </div>

      <LineChartCard data={depthTrend} dataKey="value" color={4} title="Aggregate Queue Depth (24h)" description="Total messages across all queues (thousands)" suffix="K" />

      <Card className="p-5 space-y-4">
        <div>
          <h2 className="text-sm font-semibold tracking-tight">Queue Inventory</h2>
          <p className="text-xs text-muted-foreground">Filter by type or status to investigate backlog or lag</p>
        </div>
        <DataTable
          columns={columns}
          data={queues}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.name, (r) => r.region]}
          searchPlaceholder="Search queue name or region..."
          pageSize={10}
          initialSort={{ key: "depth", dir: "desc" }}
          mobileCard={mobileCard}
        />
      </Card>

      <Card className="p-5 space-y-3">
        <SectionHeading title="Backlog Alerts" description="Queues requiring immediate attention" />
        <div className="space-y-2">
          {queues.filter((q) => q.status !== "healthy").map((q) => (
            <div key={q.id} className="flex items-center justify-between gap-3 p-3 rounded-lg border border-warning/30 bg-warning/5">
              <div className="flex items-center gap-3 min-w-0">
                <AlertTriangle className="w-4 h-4 text-warning-foreground shrink-0" />
                <div className="min-w-0">
                  <div className="text-sm font-medium font-mono truncate">{q.name}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {q.status === "backlogged" ? `${(q.depth / 1000).toFixed(1)}K messages backed up` : `${q.lag}s consumer lag`}
                    {" · "}{q.consumers} consumers · {q.throughput}/s
                  </div>
                </div>
              </div>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5 shrink-0" onClick={() => toast.info("Scale dialog opened", { description: `Increase consumers for ${q.name}` })}>
                <Zap className="w-3 h-3" /> Scale
              </Button>
            </div>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}
