"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Boxes, Server, Cpu, MemoryStick, RefreshCw, Download, ArrowUpRight,
  Activity, Layers, Globe, AlertTriangle,
} from "lucide-react";
import { k8sClusters, services, timeSeries } from "@/lib/data";
import { LineChartCard } from "@/components/charts";
import { toast } from "sonner";

export default function K8sClustersPage() {
  const router = useRouter();
  const totalClusters = k8sClusters.length;
  const totalNodes = k8sClusters.reduce((s, c) => s + c.nodeCount, 0);
  const totalPods = k8sClusters.reduce((s, c) => s + c.podCount, 0);
  const avgUtil = Math.round(k8sClusters.reduce((s, c) => s + (c.cpuUsage + c.memoryUsage) / 2, 0) / k8sClusters.length);

  const cpuTrend = timeSeries(21, 24, avgUtil, 10).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  }));

  function statusColor(status: string) {
    if (status === "healthy") return { dot: "bg-success", text: "text-success", pulse: false };
    if (status === "warning") return { dot: "bg-warning", text: "text-warning-foreground", pulse: true };
    return { dot: "bg-destructive", text: "text-destructive", pulse: true };
  }

  function handleRefresh() { toast.success("Cluster data refreshed", { description: "Latest state retrieved from Kubernetes API." }); }

  return (
    <PageContainer>
      <PageHeader
        title="Kubernetes Clusters"
        description="All managed Kubernetes clusters with live health, node count, pod count, and resource utilization."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Kubernetes" }]}
        icon={<Boxes className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handleRefresh}><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total Clusters" value={totalClusters} hint="3 production, 1 staging" icon={<Boxes className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Total Nodes" value={totalNodes} icon={<Server className="w-4 h-4" />} accent="accent" />
        <KpiCard label="Total Pods" value={totalPods.toLocaleString()} icon={<Layers className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg Utilization" value={avgUtil} unit="%" delta={3} deltaLabel="1h" icon={<Cpu className="w-4 h-4" />} accent={avgUtil > 70 ? "warning" : "success"} />
      </div>

      <LineChartCard data={cpuTrend} dataKey="value" color={2} title="Fleet CPU Utilization (24h)" description="Average CPU across all clusters" suffix="%" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {k8sClusters.map((c) => {
          const s = statusColor(c.status);
          const svcCount = services.filter((sv) => sv.regions.includes(c.region)).length;
          return (
            <Card key={c.id} className="p-5 space-y-4 hover:bg-muted/20 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Boxes className="w-4 h-4 text-primary shrink-0" />
                    <h3 className="text-sm font-mono font-medium truncate">{c.name}</h3>
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-1 flex items-center gap-2">
                    <span className="inline-flex items-center gap-1"><Globe className="w-2.5 h-2.5" /> {c.region}</span>
                    <span>·</span>
                    <span>{c.provider}</span>
                    <span>·</span>
                    <span>v{c.version}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={`inline-flex items-center gap-1 text-[11px] font-medium ${s.text}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${s.dot} ${s.pulse ? "animate-status-pulse" : ""}`} />
                    <span className="capitalize">{c.status}</span>
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="p-2 rounded-md bg-muted/30">
                  <div className="text-base font-semibold tabular-nums">{c.nodeCount}</div>
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Nodes</div>
                </div>
                <div className="p-2 rounded-md bg-muted/30">
                  <div className="text-base font-semibold tabular-nums">{c.podCount}</div>
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Pods</div>
                </div>
                <div className="p-2 rounded-md bg-muted/30">
                  <div className={`text-base font-semibold tabular-nums ${c.cpuUsage >= 80 ? "text-destructive" : c.cpuUsage >= 70 ? "text-warning-foreground" : ""}`}>{c.cpuUsage}%</div>
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">CPU</div>
                </div>
                <div className="p-2 rounded-md bg-muted/30">
                  <div className={`text-base font-semibold tabular-nums ${c.memoryUsage >= 80 ? "text-destructive" : c.memoryUsage >= 70 ? "text-warning-foreground" : ""}`}>{c.memoryUsage}%</div>
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Mem</div>
                </div>
              </div>

              {/* Utilization bars */}
              <div className="space-y-2">
                <div>
                  <div className="flex items-center justify-between text-[10px] mb-1">
                    <span className="text-muted-foreground">CPU</span>
                    <span className="font-mono tabular-nums">{c.cpuUsage}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className={c.cpuUsage >= 85 ? "bg-destructive" : c.cpuUsage >= 70 ? "bg-warning" : "bg-success"} style={{ width: `${c.cpuUsage}%`, height: "100%" }} />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between text-[10px] mb-1">
                    <span className="text-muted-foreground">Memory</span>
                    <span className="font-mono tabular-nums">{c.memoryUsage}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className={c.memoryUsage >= 85 ? "bg-destructive" : c.memoryUsage >= 70 ? "bg-warning" : "bg-success"} style={{ width: `${c.memoryUsage}%`, height: "100%" }} />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-border">
                <span className="text-[10px] text-muted-foreground inline-flex items-center gap-1">
                  <Activity className="w-3 h-3" /> {svcCount} services · {Math.floor(c.podCount / c.nodeCount)} pods/node
                </span>
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => router.push("/infrastructure/kubernetes/workloads")}>
                  Workloads <ArrowUpRight className="w-3 h-3" />
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      <Card className="p-5 space-y-3">
        <SectionHeading title="Cluster Health Notes" description="Recent observations from the Kubernetes control plane" />
        <div className="space-y-2">
          <div className="flex items-start gap-3 p-3 rounded-lg border border-warning/30 bg-warning/5">
            <AlertTriangle className="w-4 h-4 text-warning-foreground shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium">prod-ap-south-1-primary under pressure</div>
              <p className="text-xs text-muted-foreground mt-0.5">CPU at 71%, memory at 78%. Consider scaling nodes or migrating workloads.</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-lg border">
            <MemoryStick className="w-4 h-4 text-info shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium">prod-us-east-1-primary autoscaler active</div>
              <p className="text-xs text-muted-foreground mt-0.5">Cluster autoscaler added 3 nodes in the past hour. Current target: 50 nodes.</p>
            </div>
          </div>
        </div>
      </Card>
    </PageContainer>
  );
}
