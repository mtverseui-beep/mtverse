"use client";

import * as React from "react";
import { PageContainer, PageHeader } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  Layers, RefreshCw, Download, Boxes, GitBranch, Cpu, MemoryStick, Clock, Cloud,
} from "lucide-react";
import { k8sClusters, services } from "@/lib/data";
import { toast } from "sonner";

type WorkloadKind = "Deployment" | "StatefulSet" | "DaemonSet" | "Job" | "CronJob";

interface Workload {
  id: string;
  name: string;
  kind: WorkloadKind;
  namespace: string;
  clusterId: string;
  replicasReady: number;
  replicasDesired: number;
  cpu: number;
  memory: number;
  ageDays: number;
  status: "healthy" | "degraded" | "failed";
}

const namespaces = ["default", "payments", "billing", "auth", "checkout", "monitoring", "kube-system", "ingress"];

function generateWorkloads(): Workload[] {
  const workloads: Workload[] = [];
  const kinds: WorkloadKind[] = ["Deployment", "StatefulSet", "DaemonSet", "Job", "CronJob"];
  let i = 0;
  k8sClusters.forEach((cluster) => {
    const count = cluster.id === "k4" ? 6 : 12;
    for (let j = 0; j < count; j++) {
      const kind = kinds[j % kinds.length];
      const desired = kind === "DaemonSet" ? cluster.nodeCount : Math.floor(Math.random() * 8) + 2;
      const failed = Math.random() < 0.08;
      const ready = failed ? Math.max(0, desired - Math.floor(Math.random() * 3) - 1) : desired;
      const degraded = ready < desired && !failed;
      const svc = services[j % services.length];
      workloads.push({
        id: `wl${i++}`,
        name: `${svc.slug}-${kind.toLowerCase()}-${j}`,
        kind,
        namespace: namespaces[j % namespaces.length],
        clusterId: cluster.id,
        replicasReady: ready,
        replicasDesired: desired,
        cpu: Math.round(Math.random() * 800 + 20),
        memory: Math.round(Math.random() * 2048 + 64),
        ageDays: Math.floor(Math.random() * 120) + 1,
        status: failed ? "failed" : degraded ? "degraded" : "healthy",
      });
    }
  });
  return workloads;
}

const workloads = generateWorkloads();

const kindColors: Record<WorkloadKind, string> = {
  Deployment: "bg-primary/15 text-primary border-primary/30",
  StatefulSet: "bg-accent/15 text-accent-foreground border-accent/30",
  DaemonSet: "bg-info/15 text-info-foreground border-info/30",
  Job: "bg-warning/15 text-warning-foreground border-warning/30",
  CronJob: "bg-muted text-muted-foreground border-border",
};

const statusColors: Record<string, string> = {
  healthy: "text-success bg-success/15",
  degraded: "text-warning-foreground bg-warning/15",
  failed: "text-destructive bg-destructive/15",
};

export default function K8sWorkloadsPage() {
  const deployments = workloads.filter((w) => w.kind === "Deployment").length;
  const statefulsets = workloads.filter((w) => w.kind === "StatefulSet").length;
  const daemons = workloads.filter((w) => w.kind === "DaemonSet").length;
  const jobs = workloads.filter((w) => w.kind === "Job" || w.kind === "CronJob").length;

  function handleScale() { toast.success("Scale dialog opened", { description: "Adjust replica count for selected workload." }); }

  const columns: Column<Workload>[] = [
    {
      key: "name", header: "Name", sortable: true, sortValue: (r) => r.name,
      cell: (r) => <span className="text-xs font-mono">{r.name}</span>,
    },
    {
      key: "kind", header: "Kind",
      cell: (r) => <span className={`inline-flex px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide border ${kindColors[r.kind]}`}>{r.kind}</span>,
      filterable: true,
      filterOptions: [
        { label: "Deployment", value: "Deployment" }, { label: "StatefulSet", value: "StatefulSet" },
        { label: "DaemonSet", value: "DaemonSet" }, { label: "Job", value: "Job" }, { label: "CronJob", value: "CronJob" },
      ],
      filterFn: (r, v) => r.kind === v,
    },
    {
      key: "namespace", header: "Namespace",
      cell: (r) => <span className="text-[11px] font-mono">{r.namespace}</span>,
      filterable: true,
      filterOptions: namespaces.map((n) => ({ label: n, value: n })),
      filterFn: (r, v) => r.namespace === v,
      hideOnMobile: true,
    },
    {
      key: "cluster", header: "Cluster",
      cell: (r) => { const c = k8sClusters.find((x) => x.id === r.clusterId); return <span className="text-[11px] font-mono">{c?.name ?? "—"}</span>; },
      filterable: true,
      filterOptions: k8sClusters.map((c) => ({ label: c.name, value: c.id })),
      filterFn: (r, v) => r.clusterId === v,
      hideOnMobile: true,
    },
    {
      key: "replicas", header: "Replicas", sortable: true, sortValue: (r) => r.replicasReady,
      cell: (r) => (
        <span className={`text-xs font-mono tabular-nums ${r.replicasReady < r.replicasDesired ? "text-warning-foreground" : ""}`}>
          {r.replicasReady}/{r.replicasDesired}
        </span>
      ),
    },
    {
      key: "cpu", header: "CPU (m)", sortable: true, sortValue: (r) => r.cpu,
      cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.cpu}</span>,
      hideOnMobile: true,
    },
    {
      key: "memory", header: "Memory (Mi)", sortable: true, sortValue: (r) => r.memory,
      cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.memory}</span>,
      hideOnMobile: true,
    },
    {
      key: "status", header: "Status",
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide ${statusColors[r.status]}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-current" />{r.status}
        </span>
      ),
    },
    {
      key: "age", header: "Age", sortable: true, sortValue: (r) => r.ageDays,
      cell: (r) => <span className="text-[11px] font-mono">{r.ageDays}d</span>,
      hideOnMobile: true,
    },
    {
      key: "actions", header: "",
      cell: (r) => (
        <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={(e) => { e.stopPropagation(); handleScale(); }}>
          Scale
        </Button>
      ),
      align: "right",
    },
  ];

  function mobileCard(w: Workload) {
    const c = k8sClusters.find((x) => x.id === w.clusterId);
    return (
      <Card className="p-3 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono">{w.name}</span>
          <span className={`inline-flex px-1 py-0.5 rounded text-[10px] uppercase border ${kindColors[w.kind]}`}>{w.kind}</span>
        </div>
        <div className="text-[10px] text-muted-foreground">{c?.name} · {w.namespace}</div>
        <div className="flex items-center justify-between text-[10px]">
          <span>Replicas: <span className="font-mono">{w.replicasReady}/{w.replicasDesired}</span></span>
          <span className={`inline-flex items-center gap-1 px-1 py-0.5 rounded uppercase ${statusColors[w.status]}`}>{w.status}</span>
        </div>
      </Card>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Kubernetes Workloads"
        description="Deployments, StatefulSets, DaemonSets, and Jobs across all clusters and namespaces."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Kubernetes", href: "/infrastructure/kubernetes" }, { label: "Workloads" }]}
        icon={<Layers className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Deployments" value={deployments} icon={<Boxes className="w-4 h-4" />} accent="primary" />
        <KpiCard label="StatefulSets" value={statefulsets} icon={<GitBranch className="w-4 h-4" />} accent="accent" />
        <KpiCard label="DaemonSets" value={daemons} icon={<Cloud className="w-4 h-4" />} accent="info" />
        <KpiCard label="Jobs / CronJobs" value={jobs} icon={<Clock className="w-4 h-4" />} accent="warning" />
      </div>

      <Card className="p-5 space-y-4">
        <div>
          <h2 className="text-sm font-semibold tracking-tight">Workload Inventory</h2>
          <p className="text-xs text-muted-foreground">Filter by cluster, namespace, or kind</p>
        </div>
        <DataTable
          columns={columns}
          data={workloads}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.name, (r) => r.namespace]}
          searchPlaceholder="Search workload or namespace..."
          pageSize={12}
          initialSort={{ key: "name", dir: "asc" }}
          mobileCard={mobileCard}
        />
      </Card>
    </PageContainer>
  );
}
