"use client";

import * as React from "react";
import { useParams } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Server, Cpu, MemoryStick, HardDrive, Network, RefreshCw, Power, Trash2,
  AlertTriangle, Globe, Clock, Tag, Activity, Wifi, ArrowDownToLine, ArrowUpFromLine,
} from "lucide-react";
import { hosts, services, timeSeries } from "@/lib/data";
import { LineChartCard } from "@/components/charts";
import { toast } from "sonner";

export default function HostDetailsPage() {
  const params = useParams();
  const id = params?.id as string | undefined;
  const host = hosts.find((h) => h.id === id) ?? hosts[0];
  const svc = services.find((s) => s.id === host.serviceId);

  const cpuTrend = timeSeries(11, 24, host.cpuUsage, 12).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  }));
  const memTrend = timeSeries(13, 24, host.memoryUsage, 10).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  }));
  const diskTrend = timeSeries(15, 24, host.diskUsage, 6).map((d, i) => ({
    date: `${String(i).padStart(2, "0")}:00`,
    value: Math.round(d.value),
  }));

  const processes = [
    { pid: 1234, name: "node", cpu: 38.4, memory: 412, user: "app" },
    { pid: 1456, name: "postgres", cpu: 12.1, memory: 1284, user: "postgres" },
    { pid: 1789, name: "nginx", cpu: 4.2, memory: 88, user: "nginx" },
    { pid: 2011, name: "filebeat", cpu: 2.8, memory: 64, user: "root" },
    { pid: 2233, name: "node-exporter", cpu: 1.1, memory: 32, user: "prometheus" },
    { pid: 2455, name: "dockerd", cpu: 0.9, memory: 156, user: "root" },
    { pid: 2677, name: "containerd", cpu: 0.7, memory: 92, user: "root" },
    { pid: 2899, name: "sshd", cpu: 0.1, memory: 12, user: "root" },
  ];

  const interfaces = [
    { name: "eth0", ip: "10.42.18.21", mac: "02:1a:8b:3f:42:c1", rx: "1.2 GB", tx: "840 MB", status: "up" },
    { name: "eth1", ip: "10.42.19.21", mac: "02:1a:8b:3f:42:c2", rx: "412 MB", tx: "210 MB", status: "up" },
    { name: "lo", ip: "127.0.0.1", mac: "—", rx: "88 MB", tx: "88 MB", status: "up" },
  ];

  const tags = [`env:${host.environment}`, `region:${host.region}`, `provider:${host.provider}`, `tier:${svc?.tier ?? "tier3"}`, `service:${svc?.name ?? "unknown"}`, `instance:${host.instanceType}`];

  function handleRestart() { toast.success(`Restart initiated on ${host.hostname}`, { description: "Host will reboot in approximately 30 seconds." }); }
  function handleDrain() { toast.success(`Drain started on ${host.hostname}`, { description: "Workloads will be migrated to other hosts." }); }
  function handleTerminate() { toast.error(`Terminate requested on ${host.hostname}`, { description: "This action is irreversible. Confirmation required." }); }

  return (
    <PageContainer>
      <PageHeader
        title={host.hostname}
        description={`${svc?.name ?? "Service"} · ${host.instanceType} · ${host.os}`}
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Hosts", href: "/infrastructure/hosts" }, { label: host.hostname }]}
        icon={<Server className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handleRestart}><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Restart</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handleDrain}><ArrowDownToLine className="w-3.5 h-3.5" /><span className="hidden md:inline">Drain</span></Button>
            <Button variant="destructive" size="sm" className="gap-1.5" onClick={handleTerminate}><Trash2 className="w-3.5 h-3.5" /><span className="hidden md:inline">Terminate</span></Button>
          </>
        }
      />

      {/* Hero */}
      <Card className="p-5">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium uppercase tracking-wide ${host.status === "running" ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${host.status === "running" ? "bg-success animate-status-pulse" : "bg-muted-foreground"}`} />
                {host.status}
              </span>
              <Badge variant="outline" className="text-[10px] uppercase">{host.provider}</Badge>
              <Badge variant="outline" className="text-[10px] uppercase">{host.environment}</Badge>
              <Badge variant="outline" className="text-[10px] uppercase font-mono">{host.region}</Badge>
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
              <InfoRow icon={<Server className="w-3.5 h-3.5" />} label="Instance type" value={host.instanceType} mono />
              <InfoRow icon={<Globe className="w-3.5 h-3.5" />} label="OS" value={host.os} />
              <InfoRow icon={<Network className="w-3.5 h-3.5" />} label="Service" value={svc?.name ?? "—"} />
              <InfoRow icon={<Clock className="w-3.5 h-3.5" />} label="Uptime" value={host.uptime} mono />
            </div>
          </div>
          <div className="lg:col-span-2 grid grid-cols-2 gap-2">
            <MiniMetric label="CPU" value={`${host.cpuUsage}%`} critical={host.cpuUsage >= 80} icon={<Cpu className="w-3 h-3" />} />
            <MiniMetric label="Memory" value={`${host.memoryUsage}%`} critical={host.memoryUsage >= 80} icon={<MemoryStick className="w-3 h-3" />} />
            <MiniMetric label="Disk" value={`${host.diskUsage}%`} critical={host.diskUsage >= 80} icon={<HardDrive className="w-3 h-3" />} />
            <MiniMetric label="Net I/O" value="2.04 GB" icon={<Wifi className="w-3 h-3" />} />
          </div>
        </div>
      </Card>

      {/* KPI row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="CPU Usage" value={host.cpuUsage} unit="%" delta={4} deltaLabel="1h" icon={<Cpu className="w-4 h-4" />} accent={host.cpuUsage > 80 ? "destructive" : host.cpuUsage > 70 ? "warning" : "success"} />
        <KpiCard label="Memory Usage" value={host.memoryUsage} unit="%" delta={2} deltaLabel="1h" icon={<MemoryStick className="w-4 h-4" />} accent={host.memoryUsage > 80 ? "destructive" : "success"} />
        <KpiCard label="Disk Usage" value={host.diskUsage} unit="%" delta={1} deltaLabel="1d" icon={<HardDrive className="w-4 h-4" />} accent={host.diskUsage > 80 ? "destructive" : "info"} />
        <KpiCard label="Network I/O" value="2.04" unit="GB" hint="rx 1.2GB · tx 840MB" icon={<Network className="w-4 h-4" />} accent="primary" />
      </div>

      {/* Trend charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <LineChartCard data={cpuTrend} dataKey="value" color={2} title="CPU Trend (24h)" description="Hourly CPU utilization" suffix="%" />
        <LineChartCard data={memTrend} dataKey="value" color={3} title="Memory Trend (24h)" description="Hourly memory utilization" suffix="%" />
        <LineChartCard data={diskTrend} dataKey="value" color={4} title="Disk Trend (24h)" description="Hourly disk utilization" suffix="%" />
      </div>

      {/* Processes + Interfaces */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 space-y-4">
          <SectionHeading title="Processes" description="Top processes by resource usage" />
          <div className="rounded-lg border overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-muted/40">
                <tr>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">PID</th>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">Name</th>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase tracking-wider">User</th>
                  <th className="px-3 py-2 text-right font-medium text-muted-foreground uppercase tracking-wider">CPU</th>
                  <th className="px-3 py-2 text-right font-medium text-muted-foreground uppercase tracking-wider">RSS</th>
                </tr>
              </thead>
              <tbody>
                {processes.map((p) => (
                  <tr key={p.pid} className="border-t border-border">
                    <td className="px-3 py-2 font-mono tabular-nums">{p.pid}</td>
                    <td className="px-3 py-2 font-mono">{p.name}</td>
                    <td className="px-3 py-2 text-muted-foreground">{p.user}</td>
                    <td className="px-3 py-2 text-right font-mono tabular-nums">{p.cpu}%</td>
                    <td className="px-3 py-2 text-right font-mono tabular-nums">{p.memory} MB</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card className="p-5 space-y-4">
          <SectionHeading title="Network Interfaces" description="Physical and virtual network interfaces" />
          <div className="space-y-2">
            {interfaces.map((iface) => (
              <div key={iface.name} className="flex items-center justify-between gap-3 p-3 rounded-lg border">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-2 h-2 rounded-full ${iface.status === "up" ? "bg-success animate-status-pulse" : "bg-muted-foreground"}`} />
                  <div className="min-w-0">
                    <div className="text-xs font-mono font-medium">{iface.name}</div>
                    <div className="text-[10px] text-muted-foreground font-mono">{iface.ip} · {iface.mac}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-[10px] text-right">
                  <div>
                    <div className="text-muted-foreground uppercase tracking-wider">RX</div>
                    <div className="font-mono tabular-nums inline-flex items-center gap-0.5"><ArrowDownToLine className="w-2.5 h-2.5" />{iface.rx}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground uppercase tracking-wider">TX</div>
                    <div className="font-mono tabular-nums inline-flex items-center gap-0.5"><ArrowUpFromLine className="w-2.5 h-2.5" />{iface.tx}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Tags / Metadata */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Tags & Metadata" description="Labels applied to this host for filtering, routing, and cost allocation" />
        <div className="flex flex-wrap gap-2">
          {tags.map((t) => (
            <span key={t} className="inline-flex items-center gap-1 px-2 py-1 rounded-md border bg-muted/40 text-[11px] font-mono">
              <Tag className="w-3 h-3 text-muted-foreground" />
              {t}
            </span>
          ))}
        </div>
        <Separator />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div><span className="text-muted-foreground">Instance ID:</span> <span className="font-mono">i-0{host.id}7a3f2c1b8e7d2</span></div>
          <div><span className="text-muted-foreground">Availability Zone:</span> <span className="font-mono">{host.region}a</span></div>
          <div><span className="text-muted-foreground">Launch Time:</span> <span className="font-mono">2026-05-21T08:14:00Z</span></div>
          <div><span className="text-muted-foreground">VPC:</span> <span className="font-mono">vpc-0a1b2c3d</span></div>
          <div><span className="text-muted-foreground">Subnet:</span> <span className="font-mono">subnet-9f8e7d6c</span></div>
          <div><span className="text-muted-foreground">Security Group:</span> <span className="font-mono">sg-prod-app</span></div>
        </div>
      </Card>
    </PageContainer>
  );
}

function InfoRow({ icon, label, value, mono }: { icon: React.ReactNode; label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-muted-foreground">{icon}</span>
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`text-xs font-medium ml-auto ${mono ? "font-mono" : ""}`}>{value}</span>
    </div>
  );
}

function MiniMetric({ label, value, critical, icon }: { label: string; value: string; critical?: boolean; icon: React.ReactNode }) {
  return (
    <div className={`p-3 rounded-lg border ${critical ? "border-destructive/30 bg-destructive/5" : "bg-muted/30"}`}>
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground inline-flex items-center gap-1">{icon} {label}</span>
        {critical && <AlertTriangle className="w-3 h-3 text-destructive" />}
      </div>
      <div className={`text-base font-semibold tabular-nums mt-1 ${critical ? "text-destructive" : ""}`}>{value}</div>
    </div>
  );
}
