"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Column, DataTable } from "@/components/tables/data-table";
import {
  HardDrive, RefreshCw, Download, Database, Cloud, Activity, Boxes, Server,
} from "lucide-react";
import { DonutChart } from "@/components/charts";
import { toast } from "sonner";

type StorageType = "EBS" | "S3" | "EFS" | "FSx" | "Local";

interface Volume {
  id: string;
  name: string;
  type: StorageType;
  size: number; // GB
  used: number;
  iops: number;
  region: string;
  attachedTo?: string;
  encrypted: boolean;
  status: "in-use" | "available" | "error";
}

const volumes: Volume[] = [
  { id: "vol1", name: "data-vol-postgres-primary", type: "EBS", size: 2048, used: 1342, iops: 16000, region: "us-east-1", attachedTo: "db-primary-us-east-1a-01", encrypted: true, status: "in-use" },
  { id: "vol2", name: "data-vol-postgres-replica", type: "EBS", size: 2048, used: 1342, iops: 12000, region: "us-east-1", attachedTo: "db-replica-us-east-1b-02", encrypted: true, status: "in-use" },
  { id: "vol3", name: "kafka-logs-broker-01", type: "EBS", size: 4096, used: 2814, iops: 8000, region: "us-east-1", attachedTo: "kafka-broker-01", encrypted: true, status: "in-use" },
  { id: "vol4", name: "redis-rdb-snapshots", type: "EBS", size: 512, used: 188, iops: 3000, region: "us-east-1", attachedTo: "redis-node-01", encrypted: true, status: "in-use" },
  { id: "vol5", name: "audit-logs-archive", type: "S3", size: 8192, used: 5234, iops: 2500, region: "us-east-1", encrypted: true, status: "in-use" },
  { id: "vol6", name: "user-uploads", type: "S3", size: 16384, used: 11820, iops: 4200, region: "us-east-1", encrypted: true, status: "in-use" },
  { id: "vol7", name: "shared-tmp-builds", type: "EFS", size: 1024, used: 312, iops: 1200, region: "us-east-1", attachedTo: "build-fleet", encrypted: true, status: "in-use" },
  { id: "vol8", name: "search-indices", type: "EBS", size: 4096, used: 2840, iops: 16000, region: "us-east-1", attachedTo: "search-cluster-01", encrypted: true, status: "in-use" },
  { id: "vol9", name: "vault-sealed-storage", type: "EBS", size: 256, used: 48, iops: 1500, region: "us-east-1", attachedTo: "vault-node-01", encrypted: true, status: "in-use" },
  { id: "vol10", name: "metrics-cold-storage", type: "S3", size: 32768, used: 24180, iops: 800, region: "us-east-1", encrypted: true, status: "in-use" },
  { id: "vol11", name: "checkout-fs-backup", type: "FSx", size: 1024, used: 612, iops: 4000, region: "eu-west-1", attachedTo: "checkout-prod-eu-west-1a-01", encrypted: true, status: "in-use" },
  { id: "vol12", name: "staging-uploads", type: "S3", size: 512, used: 184, iops: 600, region: "us-east-1", encrypted: false, status: "available" },
];

const typeConfig: Record<StorageType, { color: string; icon: React.ReactNode }> = {
  EBS: { color: "bg-primary/15 text-primary border-primary/30", icon: <HardDrive className="w-3 h-3" /> },
  S3: { color: "bg-accent/15 text-accent-foreground border-accent/30", icon: <Cloud className="w-3 h-3" /> },
  EFS: { color: "bg-info/15 text-info-foreground border-info/30", icon: <Database className="w-3 h-3" /> },
  FSx: { color: "bg-warning/15 text-warning-foreground border-warning/30", icon: <Server className="w-3 h-3" /> },
  Local: { color: "bg-muted text-muted-foreground border-border", icon: <HardDrive className="w-3 h-3" /> },
};

const statusConfig: Record<string, string> = {
  "in-use": "text-success bg-success/15",
  "available": "text-muted-foreground bg-muted",
  "error": "text-destructive bg-destructive/15",
};

export default function StoragePage() {
  const totalStorage = volumes.reduce((s, v) => s + v.size, 0);
  const totalUsed = volumes.reduce((s, v) => s + v.used, 0);
  const usedPct = Math.round((totalUsed / totalStorage) * 100);
  const totalIops = volumes.reduce((s, v) => s + v.iops, 0);
  const bucketsCount = volumes.filter((v) => v.type === "S3").length;

  const byType = Object.entries(volumes.reduce((acc, v) => {
    acc[v.type] = (acc[v.type] || 0) + v.size;
    return acc;
  }, {} as Record<string, number>)).map(([name, value]) => ({ name, value }));

  function handleSnapshot() { toast.success("Snapshot scheduled", { description: "EBS snapshot will be taken within the next 5 minutes." }); }

  const columns: Column<Volume>[] = [
    {
      key: "name", header: "Volume / Bucket", sortable: true, sortValue: (r) => r.name,
      cell: (r) => <span className="text-xs font-mono">{r.name}</span>,
    },
    {
      key: "type", header: "Type",
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide border ${typeConfig[r.type].color}`}>
          {typeConfig[r.type].icon} {r.type}
        </span>
      ),
      filterable: true,
      filterOptions: Object.keys(typeConfig).map((t) => ({ label: t, value: t })),
      filterFn: (r, v) => r.type === v,
    },
    {
      key: "size", header: "Size (GB)", sortable: true, sortValue: (r) => r.size,
      cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.size.toLocaleString()}</span>,
    },
    {
      key: "used", header: "Used",
      cell: (r) => {
        const pct = Math.round((r.used / r.size) * 100);
        return (
          <div className="flex items-center gap-2 min-w-[120px]">
            <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
              <div className={pct >= 85 ? "bg-destructive" : pct >= 70 ? "bg-warning" : "bg-success"} style={{ width: `${pct}%`, height: "100%" }} />
            </div>
            <span className="text-[11px] tabular-nums font-mono w-10 text-right">{pct}%</span>
          </div>
        );
      },
    },
    {
      key: "iops", header: "IOPS", sortable: true, sortValue: (r) => r.iops,
      cell: (r) => <span className="text-[11px] font-mono tabular-nums">{r.iops.toLocaleString()}</span>,
      hideOnMobile: true,
    },
    {
      key: "region", header: "Region",
      cell: (r) => <span className="text-[11px] font-mono text-muted-foreground">{r.region}</span>,
      hideOnMobile: true,
    },
    {
      key: "attached", header: "Attached To",
      cell: (r) => <span className="text-[11px] font-mono text-muted-foreground">{r.attachedTo ?? "—"}</span>,
      hideOnMobile: true,
    },
    {
      key: "encrypted", header: "Encrypted",
      cell: (r) => <span className={`text-[10px] uppercase ${r.encrypted ? "text-success" : "text-destructive"}`}>{r.encrypted ? "Yes" : "No"}</span>,
      hideOnMobile: true,
    },
    {
      key: "status", header: "Status",
      cell: (r) => (
        <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide ${statusConfig[r.status]}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-current" />{r.status}
        </span>
      ),
    },
  ];

  function mobileCard(v: Volume) {
    const pct = Math.round((v.used / v.size) * 100);
    return (
      <Card className="p-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-mono truncate">{v.name}</span>
          <span className={`inline-flex items-center gap-1 px-1 py-0.5 rounded text-[10px] uppercase border ${typeConfig[v.type].color}`}>{v.type}</span>
        </div>
        <div className="text-[10px] text-muted-foreground">{v.region} · {v.attachedTo ?? "unattached"}</div>
        <div className="flex items-center justify-between text-[10px]">
          <span>Used: <span className="font-mono">{v.used}/{v.size} GB ({pct}%)</span></span>
          <span>IOPS: <span className="font-mono">{v.iops.toLocaleString()}</span></span>
        </div>
      </Card>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Storage"
        description="EBS volumes, S3 buckets, EFS file systems, and FSx storage with capacity, IOPS, and encryption status."
        breadcrumbs={[{ label: "Infrastructure", href: "/infrastructure" }, { label: "Storage" }]}
        icon={<HardDrive className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handleSnapshot}><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Snapshot</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5"><Download className="w-3.5 h-3.5" /><span className="hidden md:inline">Export</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total Storage" value={(totalStorage / 1024).toFixed(1)} unit="TB" hint="across 12 volumes" icon={<HardDrive className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Used %" value={usedPct} unit="%" hint={`${(totalUsed/1024).toFixed(1)} TB consumed`} icon={<Activity className="w-4 h-4" />} accent={usedPct > 80 ? "destructive" : usedPct > 70 ? "warning" : "success"} />
        <KpiCard label="Total IOPS" value={totalIops.toLocaleString()} hint="aggregate throughput" icon={<Boxes className="w-4 h-4" />} accent="info" />
        <KpiCard label="S3 Buckets" value={bucketsCount} hint="object storage" icon={<Cloud className="w-4 h-4" />} accent="accent" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <DonutChart
          title="Storage by Type"
          description="Capacity (GB) by storage class"
          data={byType}
          centerLabel="Total"
          centerValue={`${(totalStorage / 1024).toFixed(1)}TB`}
        />
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading title="Encryption Posture" description="All volumes should be encrypted at rest" />
          <div className="grid grid-cols-3 gap-3">
            <div className="p-4 rounded-lg border border-success/30 bg-success/5">
              <div className="text-2xl font-semibold tabular-nums text-success">{volumes.filter((v) => v.encrypted).length}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Encrypted</div>
            </div>
            <div className="p-4 rounded-lg border border-destructive/30 bg-destructive/5">
              <div className="text-2xl font-semibold tabular-nums text-destructive">{volumes.filter((v) => !v.encrypted).length}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Unencrypted</div>
            </div>
            <div className="p-4 rounded-lg border">
              <div className="text-2xl font-semibold tabular-nums">{Math.round((volumes.filter((v) => v.encrypted).length / volumes.length) * 100)}%</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Coverage</div>
            </div>
          </div>
          {volumes.some((v) => !v.encrypted) && (
            <div className="text-xs text-destructive">Action required: {volumes.filter((v) => !v.encrypted).map((v) => v.name).join(", ")} not encrypted at rest.</div>
          )}
        </Card>
      </div>

      <Card className="p-5 space-y-4">
        <div>
          <h2 className="text-sm font-semibold tracking-tight">Volume & Bucket Inventory</h2>
          <p className="text-xs text-muted-foreground">Filter by type to view a specific storage class</p>
        </div>
        <DataTable
          columns={columns}
          data={volumes}
          rowKey={(r) => r.id}
          searchKeys={[(r) => r.name, (r) => r.attachedTo ?? "", (r) => r.region]}
          searchPlaceholder="Search volume name, host, region..."
          pageSize={10}
          initialSort={{ key: "size", dir: "desc" }}
          mobileCard={mobileCard}
        />
      </Card>
    </PageContainer>
  );
}
