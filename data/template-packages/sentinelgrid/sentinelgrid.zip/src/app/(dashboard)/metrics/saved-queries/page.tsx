"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Bookmark, Search, Play, Clock, RefreshCw, Folder, Plus, MoreHorizontal,
  TrendingUp, Activity, Users, Star,
} from "lucide-react";
import { toast } from "sonner";

interface SavedQuery {
  id: string;
  name: string;
  query: string;
  createdBy: string;
  lastRun: string;
  resultsCount: number;
  folder: string;
  favorite: boolean;
}

const folders = ["Production", "SRE Team", "Personal", "Shared"];

const savedQueries: SavedQuery[] = [
  { id: "sq1", name: "API Gateway 5xx rate", query: 'sum(rate(http_errors_total{service="api-gateway",status=~"5.."}[5m])) by (endpoint)', createdBy: "Maya Okonkwo", lastRun: "2h ago", resultsCount: 142, folder: "Production", favorite: true },
  { id: "sq2", name: "Checkout p95 latency", query: 'histogram_quantile(0.95, sum(rate(http_request_duration_bucket{service="checkout"}[5m])) by (le))', createdBy: "Daniel Vargas", lastRun: "1h ago", resultsCount: 84, folder: "Production", favorite: true },
  { id: "sq3", name: "Billing DB connections", query: 'pg_connections{database="billing"} / pg_connections_max{database="billing"}', createdBy: "Priya Raman", lastRun: "4h ago", resultsCount: 12, folder: "SRE Team", favorite: false },
  { id: "sq4", name: "Redis hit ratio by shard", query: 'rate(redis_keyspace_hits[5m]) / (rate(redis_keyspace_hits[5m]) + rate(redis_keyspace_misses[5m]))', createdBy: "Theo Lambert", lastRun: "6h ago", resultsCount: 6, folder: "SRE Team", favorite: false },
  { id: "sq5", name: "Kafka consumer lag (all groups)", query: 'sum(kafka_consumer_lag) by (group, topic)', createdBy: "Daniel Vargas", lastRun: "12m ago", resultsCount: 38, folder: "Production", favorite: true },
  { id: "sq6", name: "Web app LCP by region", query: 'histogram_quantile(0.95, sum(rate(web_vitals_lcp_bucket{metric="lcp"}[5m])) by (le, region))', createdBy: "Sofia Bianchi", lastRun: "3h ago", resultsCount: 24, folder: "Production", favorite: false },
  { id: "sq7", name: "Container memory pressure", query: 'container_memory_usage_bytes / container_memory_limit_bytes * 100', createdBy: "Marcus Anderson", lastRun: "8h ago", resultsCount: 64, folder: "SRE Team", favorite: false },
  { id: "sq8", name: "Checkout error rate (deploy window)", query: 'sum(rate(checkout_total{status="error"}[5m])) / sum(rate(checkout_total[5m]))', createdBy: "Maya Okonkwo", lastRun: "1d ago", resultsCount: 48, folder: "Production", favorite: false },
  { id: "sq9", name: "Auth MFA failure rate", query: 'sum(rate(auth_mfa_total{status="failed"}[5m])) / sum(rate(auth_mfa_total[5m]))', createdBy: "Lena Fischer", lastRun: "2d ago", resultsCount: 18, folder: "Shared", favorite: false },
  { id: "sq10", name: "My debug query", query: 'up', createdBy: "You", lastRun: "5m ago", resultsCount: 12, folder: "Personal", favorite: false },
  { id: "sq11", name: "GPU utilization (ML workers)", query: 'avg(DCGM_FI_DEV_GPU_UTIL) by (node)', createdBy: "Aki Tanaka", lastRun: "1d ago", resultsCount: 8, folder: "Shared", favorite: false },
  { id: "sq12", name: "Vault audit events rate", query: 'sum(rate(vault_audit_events[1m])) by (operation)', createdBy: "Priya Raman", lastRun: "6h ago", resultsCount: 24, folder: "SRE Team", favorite: false },
];

export default function SavedQueriesPage() {
  const router = useRouter();
  const [search, setSearch] = React.useState("");
  const [activeFolder, setActiveFolder] = React.useState("All");
  const [favorites, setFavorites] = React.useState<Set<string>>(new Set(savedQueries.filter((q) => q.favorite).map((q) => q.id)));

  const filtered = savedQueries.filter((q) => {
    if (activeFolder !== "All" && q.folder !== activeFolder) return false;
    if (search) {
      const s = search.toLowerCase();
      if (!q.name.toLowerCase().includes(s) && !q.query.toLowerCase().includes(s) && !q.createdBy.toLowerCase().includes(s)) return false;
    }
    return true;
  });

  function toggleFavorite(id: string) {
    setFavorites((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  }

  function handleRun(q: SavedQuery) {
    toast.success(`Running "${q.name}"`, { description: "Redirecting to metrics explorer..." });
    setTimeout(() => router.push("/metrics"), 600);
  }

  function folderCount(folder: string) {
    return folder === "All" ? savedQueries.length : savedQueries.filter((q) => q.folder === folder).length;
  }

  return (
    <PageContainer>
      <PageHeader
        title="Saved Queries"
        description="Reusable PromQL queries organized by folder. Run, favorite, or share with your team."
        breadcrumbs={[{ label: "Logs & Traces" }, { label: "Metrics", href: "/metrics" }, { label: "Saved Queries" }]}
        icon={<Bookmark className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Refresh</span></Button>
            <Button asChild size="sm" className="gap-1.5">
              <a href="/metrics/query-builder"><Plus className="w-3.5 h-3.5" /><span className="hidden md:inline">New Query</span></a>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Saved Queries" value={savedQueries.length} hint="across 4 folders" icon={<Bookmark className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Favorites" value={favorites.size} icon={<Star className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Total Runs (24h)" value="842" delta={12} deltaLabel="1d" icon={<Activity className="w-4 h-4" />} accent="success" />
        <KpiCard label="Shared with Team" value={savedQueries.filter((q) => q.folder === "Shared" || q.folder === "SRE Team").length} icon={<Users className="w-4 h-4" />} accent="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Folders sidebar */}
        <Card className="p-4 space-y-1 h-fit">
          <SectionHeading title="Folders" description="Organize your queries" />
          <button
            onClick={() => setActiveFolder("All")}
            className={`w-full flex items-center justify-between p-2 rounded-md text-left text-xs ${activeFolder === "All" ? "bg-primary/10 text-primary" : "hover:bg-muted/40"}`}
          >
            <span className="inline-flex items-center gap-2"><Folder className="w-3.5 h-3.5" /> All Queries</span>
            <span className="text-[10px] tabular-nums text-muted-foreground">{folderCount("All")}</span>
          </button>
          {folders.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFolder(f)}
              className={`w-full flex items-center justify-between p-2 rounded-md text-left text-xs ${activeFolder === f ? "bg-primary/10 text-primary" : "hover:bg-muted/40"}`}
            >
              <span className="inline-flex items-center gap-2"><Folder className="w-3.5 h-3.5" /> {f}</span>
              <span className="text-[10px] tabular-nums text-muted-foreground">{folderCount(f)}</span>
            </button>
          ))}
          <div className="pt-2 border-t border-border mt-2">
            <Button variant="outline" size="sm" className="w-full h-7 text-xs gap-1" onClick={() => toast.success("Folder created", { description: "New folder added to your workspace." })}>
              <Plus className="w-3 h-3" /> New Folder
            </Button>
          </div>
        </Card>

        {/* Query list */}
        <Card className="lg:col-span-3 p-0 overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center justify-between gap-2">
            <div className="text-sm font-semibold">{filtered.length} queries {activeFolder !== "All" && `in ${activeFolder}`}</div>
            <div className="relative w-64">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search queries..."
                className="h-8 pl-8 text-xs"
              />
            </div>
          </div>
          <div className="divide-y divide-border">
            {filtered.map((q) => {
              const isFav = favorites.has(q.id);
              return (
                <div key={q.id} className="px-4 py-3 hover:bg-muted/30 transition-colors group">
                  <div className="flex items-start gap-3">
                    <button onClick={() => toggleFavorite(q.id)} className="mt-0.5 shrink-0">
                      <Star className={`w-4 h-4 ${isFav ? "fill-warning text-warning" : "text-muted-foreground hover:text-foreground"}`} />
                    </button>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium">{q.name}</span>
                        <Badge variant="outline" className="text-[9px] uppercase">{q.folder}</Badge>
                      </div>
                      <code className="block text-[11px] font-mono text-muted-foreground mt-1 truncate group-hover:whitespace-normal group-hover:overflow-visible">
                        {q.query}
                      </code>
                      <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                        <span className="inline-flex items-center gap-1"><Users className="w-2.5 h-2.5" /> {q.createdBy}</span>
                        <span className="inline-flex items-center gap-1"><Clock className="w-2.5 h-2.5" /> Last run {q.lastRun}</span>
                        <span className="inline-flex items-center gap-1"><TrendingUp className="w-2.5 h-2.5" /> {q.resultsCount} results</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => handleRun(q)}>
                        <Play className="w-3 h-3" /> Run
                      </Button>
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => toast.info("Query menu", { description: "Edit, duplicate, delete, or share this query." })}>
                        <MoreHorizontal className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
            {filtered.length === 0 && (
              <div className="px-4 py-12 text-center text-sm text-muted-foreground">No saved queries match your filters</div>
            )}
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
