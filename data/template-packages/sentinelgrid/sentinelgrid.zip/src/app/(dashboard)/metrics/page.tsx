"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LineChart as LineChartIcon, RefreshCw, Bookmark, Bell, Cpu, MemoryStick, Gauge,
  Activity, AlertTriangle, TrendingUp, TrendingDown, Minus, Save, Plus,
} from "lucide-react";
import { LineChartCard } from "@/components/charts";
import { services, timeSeries } from "@/lib/data";
import { toast } from "sonner";

const metricsCatalog = [
  { id: "cpu", name: "CPU Utilization", unit: "%", icon: <Cpu className="w-3.5 h-3.5" />, base: 52, variance: 12, color: 2 },
  { id: "memory", name: "Memory Utilization", unit: "%", icon: <MemoryStick className="w-3.5 h-3.5" />, base: 68, variance: 8, color: 3 },
  { id: "rps", name: "Requests per Second", unit: "/s", icon: <Activity className="w-3.5 h-3.5" />, base: 4500, variance: 1200, color: 0 },
  { id: "latency", name: "p95 Latency", unit: "ms", icon: <Gauge className="w-3.5 h-3.5" />, base: 84, variance: 24, color: 1 },
  { id: "errors", name: "Error Rate", unit: "%", icon: <AlertTriangle className="w-3.5 h-3.5" />, base: 0.4, variance: 0.3, color: 4 },
  { id: "disk", name: "Disk I/O", unit: "MB/s", icon: <Activity className="w-3.5 h-3.5" />, base: 142, variance: 48, color: 5 },
];

type GroupBy = "service" | "host" | "region";

export default function MetricsExplorerPage() {
  const [selectedMetric, setSelectedMetric] = React.useState(metricsCatalog[0]);
  const [groupBy, setGroupBy] = React.useState<GroupBy>("service");
  const [timeRange, setTimeRange] = React.useState("24h");

  // Generate time series for the selected metric
  const seriesData = React.useMemo(() => {
    return timeSeries(
      selectedMetric.id.charCodeAt(0),
      24,
      selectedMetric.base,
      selectedMetric.variance
    ).map((d, i) => ({ date: `${String(i).padStart(2, "0")}:00`, value: Math.round(d.value * 10) / 10 }));
  }, [selectedMetric]);

  // Compute statistics
  const values = seriesData.map((d) => d.value);
  const current = values[values.length - 1];
  const avg = Math.round((values.reduce((s, v) => s + v, 0) / values.length) * 10) / 10;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const prev = values[values.length - 2] ?? current;
  const rateOfChange = Math.round(((current - prev) / prev) * 1000) / 10;

  // Generate per-group breakdown
  const groupItems = groupBy === "service"
    ? services.slice(0, 6).map((s) => ({ id: s.id, name: s.name, value: Math.round(selectedMetric.base * (0.5 + Math.random()) * 10) / 10 }))
    : groupBy === "host"
    ? ["host-01", "host-02", "host-03", "host-04", "host-05", "host-06"].map((h) => ({ id: h, name: h, value: Math.round(selectedMetric.base * (0.5 + Math.random()) * 10) / 10 }))
    : ["us-east-1", "eu-west-1", "ap-south-1", "us-west-2", "ap-southeast-2"].map((r) => ({ id: r, name: r, value: Math.round(selectedMetric.base * (0.5 + Math.random()) * 10) / 10 }));

  function handleCreateAlert() {
    toast.success("Alert rule created", {
      description: `Threshold alert on ${selectedMetric.name} (${current}${selectedMetric.unit}) has been saved as draft.`,
    });
  }
  function handleSaveQuery() {
    toast.success("Query saved", { description: `${selectedMetric.name} (group by ${groupBy}) saved to your saved queries.` });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Metrics Explorer"
        description="Query, visualize, and analyze any metric across services, hosts, and regions. Build alert rules from any metric."
        breadcrumbs={[{ label: "Logs & Traces" }, { label: "Metrics" }]}
        icon={<LineChartIcon className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handleSaveQuery}><Bookmark className="w-3.5 h-3.5" /><span className="hidden md:inline">Save Query</span></Button>
            <Button size="sm" className="gap-1.5" onClick={handleCreateAlert}><Bell className="w-3.5 h-3.5" /><span className="hidden md:inline">Create Alert</span></Button>
          </>
        }
      />

      {/* Metric selector + controls */}
      <Card className="p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-2 md:items-center md:justify-between">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Metric:</span>
            {metricsCatalog.map((m) => (
              <button
                key={m.id}
                onClick={() => setSelectedMetric(m)}
                className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium border transition-colors ${
                  selectedMetric.id === m.id ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border hover:bg-muted"
                }`}
              >
                {m.icon} {m.name}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="h-9 rounded-md border bg-background px-3 text-xs"
            >
              <option value="1h">Last 1h</option>
              <option value="6h">Last 6h</option>
              <option value="24h">Last 24h</option>
              <option value="7d">Last 7d</option>
              <option value="30d">Last 30d</option>
            </select>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-muted-foreground uppercase tracking-wider">Group by:</span>
          {(["service", "host", "region"] as GroupBy[]).map((g) => (
            <button
              key={g}
              onClick={() => setGroupBy(g)}
              className={`px-2 py-1 rounded-md text-[11px] font-medium border capitalize ${
                groupBy === g ? "bg-accent text-accent-foreground border-accent" : "bg-background text-muted-foreground border-border hover:bg-muted"
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      </Card>

      {/* Metric cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <MetricStatCard label="Current" value={`${current}${selectedMetric.unit}`} icon={<Activity className="w-3.5 h-3.5" />} accent="primary" />
        <MetricStatCard label="Average" value={`${avg}${selectedMetric.unit}`} icon={<Minus className="w-3.5 h-3.5" />} accent="muted" />
        <MetricStatCard label="Max" value={`${max}${selectedMetric.unit}`} icon={<TrendingUp className="w-3.5 h-3.5" />} accent="warning" />
        <MetricStatCard label="Min" value={`${min}${selectedMetric.unit}`} icon={<TrendingDown className="w-3.5 h-3.5" />} accent="info" />
        <MetricStatCard
          label="Rate of Change"
          value={`${rateOfChange > 0 ? "+" : ""}${rateOfChange}%`}
          icon={rateOfChange > 0 ? <TrendingUp className="w-3.5 h-3.5" /> : rateOfChange < 0 ? <TrendingDown className="w-3.5 h-3.5" /> : <Minus className="w-3.5 h-3.5" />}
          accent={rateOfChange > 5 ? "destructive" : rateOfChange < -5 ? "success" : "muted"}
        />
      </div>

      {/* Main chart */}
      <LineChartCard
        data={seriesData}
        dataKey="value"
        color={selectedMetric.color}
        title={`${selectedMetric.name} (24h)`}
        description={`Aggregated across all ${groupBy === "service" ? "services" : groupBy === "host" ? "hosts" : "regions"} · time range: ${timeRange}`}
        suffix={selectedMetric.unit}
      />

      {/* Group breakdown */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title={`Top ${groupBy === "service" ? "Services" : groupBy === "host" ? "Hosts" : "Regions"} by ${selectedMetric.name}`}
          description={`Sorted by current value`}
        />
        <div className="space-y-2">
          {[...groupItems].sort((a, b) => b.value - a.value).map((item, i) => {
            const maxVal = Math.max(...groupItems.map((g) => g.value));
            const pct = (item.value / maxVal) * 100;
            return (
              <div key={item.id} className="flex items-center gap-3">
                <span className="text-[10px] text-muted-foreground tabular-nums w-6">#{i + 1}</span>
                <span className="text-xs font-mono w-40 truncate">{item.name}</span>
                <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                  <div className="bg-primary" style={{ width: `${pct}%`, height: "100%" }} />
                </div>
                <span className="text-[11px] font-mono tabular-nums w-20 text-right">{item.value}{selectedMetric.unit}</span>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Related metrics */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Related Metrics" description="Often queried together" action={
          <Button variant="ghost" size="sm" className="text-xs h-7 gap-1"><Plus className="w-3 h-3" /> Add to dashboard</Button>
        } />
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {metricsCatalog.filter((m) => m.id !== selectedMetric.id).map((m) => (
            <button
              key={m.id}
              onClick={() => setSelectedMetric(m)}
              className="flex items-center gap-2 p-3 rounded-lg border hover:bg-muted/40 transition-colors text-left"
            >
              <div className="w-8 h-8 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shrink-0">
                {m.icon}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-medium truncate">{m.name}</div>
                <div className="text-[10px] text-muted-foreground">{m.unit}</div>
              </div>
            </button>
          ))}
        </div>
      </Card>
    </PageContainer>
  );
}

function MetricStatCard({ label, value, icon, accent }: { label: string; value: string; icon: React.ReactNode; accent: "primary" | "accent" | "success" | "warning" | "destructive" | "info" | "muted" }) {
  const accentClasses: Record<string, string> = {
    primary: "text-primary bg-primary/10 border-primary/20",
    accent: "text-accent-foreground bg-accent border-accent/20",
    success: "text-success bg-success/10 border-success/20",
    warning: "text-warning-foreground bg-warning/10 border-warning/20",
    destructive: "text-destructive bg-destructive/10 border-destructive/20",
    info: "text-info-foreground bg-info/10 border-info/20",
    muted: "text-muted-foreground bg-muted",
  };
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
        <div className={`w-6 h-6 rounded-md flex items-center justify-center border ${accentClasses[accent]}`}>{icon}</div>
      </div>
      <div className="text-xl font-semibold tabular-nums mt-2">{value}</div>
    </Card>
  );
}
