"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Terminal, RefreshCw, Save, Play, Plus, X, Filter, Layers, Clock, Cpu,
  MemoryStick, Activity, AlertTriangle, Gauge, Zap,
} from "lucide-react";
import { LineChartCard } from "@/components/charts";
import { services, timeSeries } from "@/lib/data";
import { toast } from "sonner";

const metricsCatalog = [
  { id: "cpu", name: "cpu_usage_percent", unit: "%", icon: <Cpu className="w-3 h-3" /> },
  { id: "memory", name: "memory_usage_percent", unit: "%", icon: <MemoryStick className="w-3 h-3" /> },
  { id: "rps", name: "http_requests_total", unit: "/s", icon: <Activity className="w-3 h-3" /> },
  { id: "latency", name: "http_request_duration_p95", unit: "ms", icon: <Gauge className="w-3 h-3" /> },
  { id: "errors", name: "http_errors_total", unit: "%", icon: <AlertTriangle className="w-3 h-3" /> },
  { id: "iops", name: "disk_io_ops", unit: "/s", icon: <Zap className="w-3 h-3" /> },
];

const aggregations = ["avg", "sum", "max", "min", "count", "rate", "p95", "p99"];
const groupByOptions = ["service", "host", "region", "endpoint", "status"];
const timeRanges = ["5m", "15m", "1h", "6h", "24h", "7d", "30d"];

interface FilterChip { id: string; field: string; op: string; value: string; }

export default function QueryBuilderPage() {
  const [metric, setMetric] = React.useState(metricsCatalog[0]);
  const [aggregation, setAggregation] = React.useState("avg");
  const [groupBy, setGroupBy] = React.useState<string[]>(["service"]);
  const [timeRange, setTimeRange] = React.useState("1h");
  const [filters, setFilters] = React.useState<FilterChip[]>([
    { id: "f1", field: "environment", op: "=", value: "production" },
  ]);
  const [filterField, setFilterField] = React.useState("");
  const [filterValue, setFilterValue] = React.useState("");
  const [queryName, setQueryName] = React.useState("CPU by service (prod)");

  // Build the PromQL-like string
  const queryString = React.useMemo(() => {
    const filterStr = filters.length > 0 ? `{${filters.map((f) => `${f.field}${f.op}"${f.value}"`).join(", ")}}` : "";
    const groupStr = groupBy.length > 0 ? ` by (${groupBy.join(", ")})` : "";
    return `${aggregation}(${metric.name}${filterStr})${groupStr} [${timeRange}]`;
  }, [metric, aggregation, groupBy, filters, timeRange]);

  // Generate result chart data
  const chartData = React.useMemo(() => {
    const points = timeRange === "5m" ? 12 : timeRange === "15m" ? 24 : timeRange === "1h" ? 30 : timeRange === "6h" ? 36 : timeRange === "24h" ? 48 : 60;
    const base = metric.id === "errors" ? 0.4 : metric.id === "latency" ? 84 : metric.id === "rps" ? 4500 : 52;
    const variance = metric.id === "errors" ? 0.3 : metric.id === "latency" ? 24 : metric.id === "rps" ? 1200 : 12;
    return timeSeries(metric.id.charCodeAt(0) + aggregation.length, points, base, variance).map((d, i) => {
      const interval = timeRange === "5m" ? "5m" : timeRange === "15m" ? "15m" : timeRange === "1h" ? "2m" : timeRange === "6h" ? "10m" : timeRange === "24h" ? "30m" : "1h";
      return { date: `t+${i * (points > 30 ? 2 : 1)}`, value: Math.round(d.value * 10) / 10 };
    });
  }, [metric, aggregation, timeRange]);

  function addFilter() {
    if (!filterField || !filterValue) return;
    setFilters([...filters, { id: `f${Date.now()}`, field: filterField, op: "=", value: filterValue }]);
    setFilterField("");
    setFilterValue("");
  }
  function removeFilter(id: string) {
    setFilters(filters.filter((f) => f.id !== id));
  }
  function toggleGroupBy(g: string) {
    setGroupBy((s) => s.includes(g) ? s.filter((x) => x !== g) : [...s, g]);
  }
  function handleSave() {
    toast.success("Query saved", { description: `"${queryName}" added to your saved queries.` });
  }
  function handleRun() {
    toast.success("Query executed", { description: `${chartData.length} data points returned` });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Query Builder"
        description="Visually construct PromQL-like queries with metric selector, filters, group-by, aggregation, and live preview."
        breadcrumbs={[{ label: "Logs & Traces" }, { label: "Metrics", href: "/metrics" }, { label: "Query Builder" }]}
        icon={<Terminal className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><RefreshCw className="w-3.5 h-3.5" /><span className="hidden md:inline">Reset</span></Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={handleSave}><Save className="w-3.5 h-3.5" /><span className="hidden md:inline">Save</span></Button>
            <Button size="sm" className="gap-1.5" onClick={handleRun}><Play className="w-3.5 h-3.5" /><span className="hidden md:inline">Run</span></Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Builder */}
        <Card className="lg:col-span-1 p-5 space-y-5">
          <SectionHeading title="Build Query" description="Configure metric, aggregation, and grouping" />

          {/* Metric */}
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Metric</label>
            <div className="grid grid-cols-1 gap-1">
              {metricsCatalog.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMetric(m)}
                  className={`flex items-center gap-2 p-2 rounded-md border text-left transition-colors ${
                    metric.id === m.id ? "bg-primary/5 border-primary/30" : "border-border hover:bg-muted/40"
                  }`}
                >
                  <div className={`w-6 h-6 rounded flex items-center justify-center ${metric.id === m.id ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
                    {m.icon}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-mono truncate">{m.name}</div>
                    <div className="text-[10px] text-muted-foreground">{m.unit}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Aggregation */}
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Aggregation</label>
            <div className="flex flex-wrap gap-1">
              {aggregations.map((a) => (
                <button
                  key={a}
                  onClick={() => setAggregation(a)}
                  className={`px-2 py-1 rounded-md text-[11px] font-mono border ${
                    aggregation === a ? "bg-accent text-accent-foreground border-accent" : "bg-background text-muted-foreground border-border hover:bg-muted"
                  }`}
                >{a}</button>
              ))}
            </div>
          </div>

          {/* Group by */}
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Group by</label>
            <div className="flex flex-wrap gap-1">
              {groupByOptions.map((g) => (
                <button
                  key={g}
                  onClick={() => toggleGroupBy(g)}
                  className={`px-2 py-1 rounded-md text-[11px] border ${
                    groupBy.includes(g) ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border hover:bg-muted"
                  }`}
                >{g}</button>
              ))}
            </div>
          </div>

          {/* Filters */}
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium flex items-center gap-1">
              <Filter className="w-3 h-3" /> Filters
            </label>
            <div className="space-y-1.5">
              {filters.map((f) => (
                <div key={f.id} className="flex items-center gap-1">
                  <Badge variant="outline" className="text-[10px] font-mono gap-1">
                    {f.field} {f.op} "{f.value}"
                    <button onClick={() => removeFilter(f.id)}><X className="w-2.5 h-2.5" /></button>
                  </Badge>
                </div>
              ))}
            </div>
            <div className="flex gap-1">
              <Input
                value={filterField}
                onChange={(e) => setFilterField(e.target.value)}
                placeholder="field"
                className="h-8 text-xs font-mono"
              />
              <Input
                value={filterValue}
                onChange={(e) => setFilterValue(e.target.value)}
                placeholder="value"
                className="h-8 text-xs font-mono"
              />
              <Button size="sm" variant="outline" className="h-8 px-2" onClick={addFilter}><Plus className="w-3 h-3" /></Button>
            </div>
          </div>

          {/* Time range */}
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium flex items-center gap-1">
              <Clock className="w-3 h-3" /> Time range
            </label>
            <div className="flex flex-wrap gap-1">
              {timeRanges.map((t) => (
                <button
                  key={t}
                  onClick={() => setTimeRange(t)}
                  className={`px-2 py-1 rounded-md text-[11px] font-mono border ${
                    timeRange === t ? "bg-info/15 text-info-foreground border-info/30" : "bg-background text-muted-foreground border-border hover:bg-muted"
                  }`}
                >{t}</button>
              ))}
            </div>
          </div>
        </Card>

        {/* Preview + Result */}
        <div className="lg:col-span-2 space-y-4">
          {/* Query preview */}
          <Card className="p-5 space-y-3">
            <SectionHeading title="Query Preview" description="PromQL-like representation" action={
              <Button variant="ghost" size="sm" className="text-xs h-7 gap-1" onClick={() => { navigator.clipboard.writeText(queryString); toast.success("Query copied to clipboard"); }}>
                Copy
              </Button>
            } />
            <div className="rounded-lg border bg-muted/30 p-4 font-mono text-xs overflow-x-auto">
              <span className="text-primary">{aggregation}</span>
              <span className="text-muted-foreground">(</span>
              <span className="text-foreground">{metric.name}</span>
              {filters.length > 0 && (
                <span className="text-warning-foreground">{"{"}{filters.map((f, i) => (
                  <React.Fragment key={f.id}>
                    {i > 0 && <span className="text-muted-foreground">, </span>}
                    <span className="text-info-foreground">{f.field}</span>
                    <span className="text-muted-foreground">{f.op}</span>
                    <span className="text-destructive">"{f.value}"</span>
                  </React.Fragment>
                ))}{"}"}</span>
              )}
              <span className="text-muted-foreground">)</span>
              {groupBy.length > 0 && (
                <span className="text-success"> by ({groupBy.join(", ")})</span>
              )}
              <span className="text-muted-foreground"> [</span>
              <span className="text-accent-foreground">{timeRange}</span>
              <span className="text-muted-foreground">]</span>
            </div>
            <div className="flex items-center gap-2">
              <Input
                value={queryName}
                onChange={(e) => setQueryName(e.target.value)}
                placeholder="Query name"
                className="h-8 text-xs"
              />
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1" onClick={handleSave}><Save className="w-3 h-3" /> Save</Button>
            </div>
          </Card>

          {/* Result chart */}
          <LineChartCard
            data={chartData}
            dataKey="value"
            color={0}
            title="Query Result"
            description={`${aggregation}(${metric.name}) over ${timeRange} · ${chartData.length} data points`}
            suffix={metric.unit}
          />

          {/* Result stats */}
          <Card className="p-5">
            <SectionHeading title="Result Statistics" description="Aggregated across the time range" />
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-3">
              <StatBox label="Current" value={chartData[chartData.length - 1].value.toFixed(1)} unit={metric.unit} />
              <StatBox label="Avg" value={(chartData.reduce((s, d) => s + d.value, 0) / chartData.length).toFixed(1)} unit={metric.unit} />
              <StatBox label="Max" value={Math.max(...chartData.map((d) => d.value)).toFixed(1)} unit={metric.unit} />
              <StatBox label="Min" value={Math.min(...chartData.map((d) => d.value)).toFixed(1)} unit={metric.unit} />
              <StatBox label="Points" value={String(chartData.length)} unit="samples" />
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}

function StatBox({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="p-3 rounded-lg border bg-muted/30">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-lg font-semibold tabular-nums mt-0.5">{value}<span className="text-[10px] text-muted-foreground ml-1">{unit}</span></div>
    </div>
  );
}
