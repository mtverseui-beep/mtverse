"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  LayoutGrid, Search, Plus, Star, Clock, Users, MoreHorizontal, Activity,
  Server, ShieldCheck, AlertTriangle, TrendingUp, Gauge, Database, Globe, Zap,
} from "lucide-react";
import { toast } from "sonner";

interface Dashboard {
  id: string;
  title: string;
  description: string;
  owner: string;
  lastModified: string;
  panels: number;
  category: string;
  favorite: boolean;
  tags: string[];
}

const dashboards: Dashboard[] = [
  { id: "d1", title: "API Health Overview", description: "Real-time health of all public-facing APIs: RPS, latency, error rate, status codes.", owner: "Maya Okonkwo", lastModified: "2h ago", panels: 12, category: "Production", favorite: true, tags: ["api", "production", "tier1"] },
  { id: "d2", title: "Infrastructure Overview", description: "Hosts, K8s clusters, pods, and resource utilization across all providers.", owner: "Daniel Vargas", lastModified: "1h ago", panels: 18, category: "Infrastructure", favorite: true, tags: ["infra", "k8s", "hosts"] },
  { id: "d3", title: "SLO Summary", description: "All SLOs with error budget consumption, burn rate, and breach alerts.", owner: "Priya Raman", lastModified: "4h ago", panels: 9, category: "Reliability", favorite: true, tags: ["slo", "error-budget"] },
  { id: "d4", title: "Checkout Funnel Health", description: "End-to-end checkout flow: cart, payment, 3DS, ledger, settlement.", owner: "Marcus Anderson", lastModified: "12m ago", panels: 16, category: "Production", favorite: false, tags: ["checkout", "payments"] },
  { id: "d5", title: "Database Performance", description: "PostgreSQL, Redis, Kafka performance with query throughput and slow queries.", owner: "Priya Raman", lastModified: "3h ago", panels: 14, category: "Infrastructure", favorite: false, tags: ["db", "postgres", "redis"] },
  { id: "d6", title: "Kubernetes Operations", description: "Cluster health, pod scheduling, node pressure, and resource requests/limits.", owner: "Theo Lambert", lastModified: "6h ago", panels: 22, category: "Infrastructure", favorite: false, tags: ["k8s", "containers"] },
  { id: "d7", title: "On-Call War Room", description: "Single pane for on-call: active incidents, firing alerts, recent deployments, SLO burn.", owner: "Sofia Bianchi", lastModified: "8m ago", panels: 8, category: "Operations", favorite: true, tags: ["oncall", "incidents"] },
  { id: "d8", title: "Edge / CDN Performance", description: "Cache hit ratio, edge bandwidth, top URLs, origin fetches by location.", owner: "Aki Tanaka", lastModified: "1d ago", panels: 10, category: "Infrastructure", favorite: false, tags: ["edge", "cdn"] },
];

const categoryIcons: Record<string, React.ReactNode> = {
  Production: <Activity className="w-4 h-4" />,
  Infrastructure: <Server className="w-4 h-4" />,
  Reliability: <ShieldCheck className="w-4 h-4" />,
  Operations: <AlertTriangle className="w-4 h-4" />,
};

const categoryColors: Record<string, string> = {
  Production: "bg-primary/10 text-primary border-primary/20",
  Infrastructure: "bg-accent/15 text-accent-foreground border-accent/30",
  Reliability: "bg-success/10 text-success border-success/20",
  Operations: "bg-warning/10 text-warning-foreground border-warning/30",
};

export default function DashboardsLibraryPage() {
  const [search, setSearch] = React.useState("");
  const [activeCategory, setActiveCategory] = React.useState("All");
  const [favorites, setFavorites] = React.useState<Set<string>>(new Set(dashboards.filter((d) => d.favorite).map((d) => d.id)));

  const categories = ["All", "Production", "Infrastructure", "Reliability", "Operations"];

  const filtered = dashboards.filter((d) => {
    if (activeCategory !== "All" && d.category !== activeCategory) return false;
    if (search) {
      const s = search.toLowerCase();
      if (!d.title.toLowerCase().includes(s) && !d.description.toLowerCase().includes(s) && !d.tags.some((t) => t.includes(s))) return false;
    }
    return true;
  });

  function toggleFavorite(id: string) {
    setFavorites((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  }

  function handleOpen(d: Dashboard) {
    toast.info(`Opening "${d.title}"`, { description: `${d.panels} panels · last modified ${d.lastModified}` });
  }

  return (
    <PageContainer>
      <PageHeader
        title="Dashboards Library"
        description="Curated dashboard library for engineering teams. Browse by category, favorite, and open with one click."
        breadcrumbs={[{ label: "Logs & Traces" }, { label: "Metrics", href: "/metrics" }, { label: "Dashboards" }]}
        icon={<LayoutGrid className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5"><Globe className="w-3.5 h-3.5" /><span className="hidden md:inline">Import</span></Button>
            <Button asChild size="sm" className="gap-1.5">
              <a href="/metrics/dashboard-builder"><Plus className="w-3.5 h-3.5" /><span className="hidden md:inline">New Dashboard</span></a>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Total Dashboards" value={dashboards.length} hint="across 4 categories" icon={<LayoutGrid className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Favorites" value={favorites.size} icon={<Star className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Total Panels" value={dashboards.reduce((s, d) => s + d.panels, 0)} hint="across all dashboards" icon={<LayoutGrid className="w-4 h-4" />} accent="info" />
        <KpiCard label="Viewed (24h)" value="2.4K" delta={8} deltaLabel="1d" icon={<Users className="w-4 h-4" />} accent="success" />
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-2 md:items-center md:justify-between">
          <div className="flex items-center gap-2 flex-wrap">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setActiveCategory(c)}
                className={`px-2 py-1 rounded-md text-[11px] font-medium border ${
                  activeCategory === c ? "bg-primary text-primary-foreground border-primary" : "bg-background text-muted-foreground border-border hover:bg-muted"
                }`}
              >{c}</button>
            ))}
          </div>
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search dashboards..."
              className="h-8 pl-8 text-xs"
            />
          </div>
        </div>
      </Card>

      {/* Dashboard cards grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((d) => {
          const isFav = favorites.has(d.id);
          return (
            <Card key={d.id} className="p-5 space-y-3 hover:bg-muted/20 transition-colors group cursor-pointer" onClick={() => handleOpen(d)}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`shrink-0 w-10 h-10 rounded-lg flex items-center justify-center border ${categoryColors[d.category]}`}>
                    {categoryIcons[d.category]}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold truncate">{d.title}</h3>
                    <div className="text-[10px] text-muted-foreground inline-flex items-center gap-1 mt-0.5">
                      <Clock className="w-2.5 h-2.5" /> {d.lastModified}
                    </div>
                  </div>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); toggleFavorite(d.id); }}
                  className="shrink-0"
                >
                  <Star className={`w-4 h-4 ${isFav ? "fill-warning text-warning" : "text-muted-foreground hover:text-foreground"}`} />
                </button>
              </div>

              <p className="text-xs text-muted-foreground line-clamp-2">{d.description}</p>

              <div className="flex items-center gap-1.5 flex-wrap">
                <Badge variant="outline" className="text-[9px] uppercase">{d.category}</Badge>
                {d.tags.slice(0, 3).map((t) => (
                  <Badge key={t} variant="outline" className="text-[9px] font-mono">{t}</Badge>
                ))}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-border">
                <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                  <span className="inline-flex items-center gap-1"><Users className="w-2.5 h-2.5" /> {d.owner}</span>
                  <span className="inline-flex items-center gap-1"><LayoutGrid className="w-2.5 h-2.5" /> {d.panels} panels</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0"
                  onClick={(e) => { e.stopPropagation(); toast.info("Dashboard menu", { description: "Edit, duplicate, share, or delete this dashboard." }); }}
                >
                  <MoreHorizontal className="w-3.5 h-3.5" />
                </Button>
              </div>
            </Card>
          );
        })}
        {filtered.length === 0 && (
          <Card className="md:col-span-2 lg:col-span-3 p-12 text-center">
            <div className="text-sm text-muted-foreground">No dashboards match your filters</div>
          </Card>
        )}
      </div>
    </PageContainer>
  );
}
