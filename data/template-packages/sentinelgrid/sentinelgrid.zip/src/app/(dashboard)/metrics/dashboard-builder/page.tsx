"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  LayoutPanelLeft, Plus, Save, Trash2, Settings2, GripVertical, LineChart as LineChartIcon,
  BarChart3, Gauge, Table, ScrollText, Activity, X, Copy, MoreHorizontal,
} from "lucide-react";
import { LineChartCard, DonutChart, RadialGauge } from "@/components/charts";
import { timeSeries } from "@/lib/data";
import { toast } from "sonner";

type PanelType = "line" | "bar" | "stat" | "gauge" | "table" | "log";

interface Panel {
  id: string;
  type: PanelType;
  title: string;
  query: string;
  data?: any;
}

const panelTypeConfig: Record<PanelType, { icon: React.ReactNode; label: string; description: string }> = {
  line: { icon: <LineChartIcon className="w-4 h-4" />, label: "Line Chart", description: "Time series line chart" },
  bar: { icon: <BarChart3 className="w-4 h-4" />, label: "Bar Chart", description: "Categorical bar chart" },
  stat: { icon: <Activity className="w-4 h-4" />, label: "Stat", description: "Single large number" },
  gauge: { icon: <Gauge className="w-4 h-4" />, label: "Gauge", description: "Radial gauge with target" },
  table: { icon: <Table className="w-4 h-4" />, label: "Table", description: "Tabular data" },
  log: { icon: <ScrollText className="w-4 h-4" />, label: "Log Stream", description: "Live log stream" },
};

const initialPanels: Panel[] = [
  {
    id: "p1",
    type: "line",
    title: "CPU Utilization",
    query: 'avg(cpu_usage_percent{service="api-gateway"}) by (instance)',
    data: timeSeries(11, 24, 52, 12).map((d, i) => ({ date: `${String(i).padStart(2, "0")}:00`, value: Math.round(d.value) })),
  },
  {
    id: "p2",
    type: "gauge",
    title: "Memory Pressure",
    query: 'avg(memory_usage_percent{service="checkout"})',
  },
  {
    id: "p3",
    type: "stat",
    title: "Active Requests",
    query: 'sum(rate(http_requests_total[5m]))',
  },
  {
    id: "p4",
    type: "bar",
    title: "Requests by Service",
    query: 'sum(rate(http_requests_total[5m])) by (service)',
    data: [
      { name: "api-gw", value: 4200 },
      { name: "auth", value: 1800 },
      { name: "checkout", value: 940 },
      { name: "billing", value: 620 },
      { name: "web", value: 320 },
    ],
  },
];

export default function DashboardBuilderPage() {
  const [panels, setPanels] = React.useState<Panel[]>(initialPanels);
  const [dashboardName, setDashboardName] = React.useState("Untitled Dashboard");
  const [dashboardDesc, setDashboardDesc] = React.useState("A new dashboard");
  const [selectedPanel, setSelectedPanel] = React.useState<Panel | null>(null);
  const [showAddPanel, setShowAddPanel] = React.useState(false);

  function addPanel(type: PanelType) {
    const newPanel: Panel = {
      id: `p${Date.now()}`,
      type,
      title: `New ${panelTypeConfig[type].label}`,
      query: "",
      data: type === "line" ? timeSeries(Math.random() * 100, 24, 50, 20).map((d, i) => ({ date: `${String(i).padStart(2, "0")}:00`, value: Math.round(d.value) })) :
            type === "bar" ? [{ name: "A", value: 100 }, { name: "B", value: 80 }, { name: "C", value: 60 }] :
            undefined,
    };
    setPanels([...panels, newPanel]);
    setShowAddPanel(false);
    toast.success(`${panelTypeConfig[type].label} panel added`, { description: "Configure it in the right sidebar." });
  }

  function deletePanel(id: string) {
    setPanels(panels.filter((p) => p.id !== id));
    if (selectedPanel?.id === id) setSelectedPanel(null);
    toast.success("Panel removed");
  }

  function duplicatePanel(p: Panel) {
    const dup = { ...p, id: `p${Date.now()}`, title: `${p.title} (copy)` };
    setPanels([...panels, dup]);
    toast.success("Panel duplicated");
  }

  function handleSave() {
    toast.success("Dashboard saved", { description: `"${dashboardName}" with ${panels.length} panels saved to your library.` });
  }

  function renderPanel(p: Panel) {
    switch (p.type) {
      case "line":
        return p.data ? (
          <LineChartCard data={p.data} dataKey="value" color={0} suffix="%" />
        ) : <div className="h-[200px] flex items-center justify-center text-xs text-muted-foreground">No data</div>;
      case "gauge":
        return (
          <div className="h-[200px] flex items-center justify-center">
            <RadialGauge value={68} target={100} label="Memory" color={2} size={160} />
          </div>
        );
      case "stat":
        return (
          <div className="h-[200px] flex flex-col items-center justify-center">
            <div className="text-5xl font-semibold tabular-nums">4,250</div>
            <div className="text-xs text-muted-foreground mt-2">requests/sec</div>
            <Badge variant="outline" className="text-success text-[10px] mt-2">+8% vs 1h ago</Badge>
          </div>
        );
      case "bar":
        return p.data ? (
          <div className="h-[200px] flex items-end gap-2 p-2">
            {p.data.map((d: any, i: number) => (
              <div key={i} className="flex-1 flex flex-col items-center justify-end gap-1">
                <span className="text-[10px] font-mono tabular-nums">{d.value}</span>
                <div className="w-full bg-primary rounded-t" style={{ height: `${(d.value / Math.max(...p.data.map((x: any) => x.value))) * 160}px` }} />
                <span className="text-[10px] text-muted-foreground truncate w-full text-center">{d.name}</span>
              </div>
            ))}
          </div>
        ) : null;
      case "table":
        return (
          <div className="rounded-md border overflow-hidden max-h-[200px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="bg-muted/40 sticky top-0">
                <tr>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase">Instance</th>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase">CPU</th>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground uppercase">Memory</th>
                </tr>
              </thead>
              <tbody>
                {[1,2,3,4,5].map((i) => (
                  <tr key={i} className="border-t border-border">
                    <td className="px-3 py-2 font-mono">instance-{i}</td>
                    <td className="px-3 py-2 font-mono tabular-nums">{40 + i * 8}%</td>
                    <td className="px-3 py-2 font-mono tabular-nums">{50 + i * 6}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case "log":
        return (
          <div className="h-[200px] overflow-y-auto rounded-md border bg-muted/20 font-mono text-[10px] divide-y divide-border">
            {["12:48:02 [INFO] Request completed in 42ms", "12:48:01 [INFO] Cache hit for user session", "12:48:00 [WARN] Rate limit exceeded for 10.42.18.92", "12:47:58 [INFO] Database query took 12ms", "12:47:56 [ERROR] Connection refused: redis:6379", "12:47:54 [INFO] Background job completed"].map((l, i) => (
              <div key={i} className="px-3 py-1.5 hover:bg-muted/40">{l}</div>
            ))}
          </div>
        );
      default:
        return null;
    }
  }

  return (
    <PageContainer wide>
      <PageHeader
        title="Dashboard Builder"
        description="Drag, drop, and configure panels to build a custom dashboard. Save to your library when ready."
        breadcrumbs={[{ label: "Logs & Traces" }, { label: "Metrics", href: "/metrics" }, { label: "Dashboards", href: "/metrics/dashboards" }, { label: "Builder" }]}
        icon={<LayoutPanelLeft className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Preview mode", { description: "Viewing dashboard as it would appear to readers." })}>
              <Activity className="w-3.5 h-3.5" /><span className="hidden md:inline">Preview</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={handleSave}><Save className="w-3.5 h-3.5" /><span className="hidden md:inline">Save Dashboard</span></Button>
          </>
        }
      />

      {/* Dashboard metadata */}
      <Card className="p-4 flex flex-col md:flex-row gap-2 md:items-center">
        <Input
          value={dashboardName}
          onChange={(e) => setDashboardName(e.target.value)}
          placeholder="Dashboard name"
          className="h-9 text-sm font-medium md:max-w-xs"
        />
        <Input
          value={dashboardDesc}
          onChange={(e) => setDashboardDesc(e.target.value)}
          placeholder="Short description"
          className="h-9 text-xs flex-1"
        />
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
          <Badge variant="outline" className="text-[9px] uppercase">{panels.length} panels</Badge>
          <Badge variant="outline" className="text-[9px] uppercase">draft</Badge>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Canvas */}
        <div className="lg:col-span-3 space-y-4">
          {panels.length === 0 ? (
            <Card className="p-12 border-dashed">
              <div className="flex flex-col items-center justify-center text-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                  <Plus className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold">No panels yet</h3>
                  <p className="text-xs text-muted-foreground mt-1">Add your first panel to start building this dashboard.</p>
                </div>
                <Button size="sm" className="gap-1.5 mt-2" onClick={() => setShowAddPanel(true)}>
                  <Plus className="w-3.5 h-3.5" /> Add Panel
                </Button>
              </div>
            </Card>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {panels.map((p) => (
                  <Card
                    key={p.id}
                    className={`p-4 space-y-3 cursor-pointer transition-all ${selectedPanel?.id === p.id ? "ring-2 ring-primary" : "hover:ring-1 hover:ring-primary/30"}`}
                    onClick={() => setSelectedPanel(p)}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <GripVertical className="w-3.5 h-3.5 text-muted-foreground shrink-0 cursor-grab" />
                        {panelTypeConfig[p.type].icon}
                        <span className="text-xs font-medium truncate">{p.title}</span>
                      </div>
                      <div className="flex items-center gap-0.5 shrink-0">
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={(e) => { e.stopPropagation(); duplicatePanel(p); }}>
                          <Copy className="w-3 h-3" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={(e) => { e.stopPropagation(); deletePanel(p.id); }}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    {renderPanel(p)}
                  </Card>
                ))}
              </div>

              <Card className="p-4 border-dashed">
                <button
                  onClick={() => setShowAddPanel(true)}
                  className="w-full py-6 text-xs text-muted-foreground hover:text-foreground inline-flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" /> Add another panel
                </button>
              </Card>
            </>
          )}
        </div>

        {/* Right: Panel types + configuration */}
        <div className="space-y-4">
          <Card className="p-4 space-y-3">
            <SectionHeading title="Add Panel" description="Choose a panel type" />
            <div className="grid grid-cols-2 gap-2">
              {(Object.keys(panelTypeConfig) as PanelType[]).map((t) => (
                <button
                  key={t}
                  onClick={() => addPanel(t)}
                  className="flex flex-col items-start gap-1 p-2 rounded-md border hover:bg-muted/40 transition-colors text-left"
                >
                  <div className="w-7 h-7 rounded bg-primary/10 text-primary flex items-center justify-center">
                    {panelTypeConfig[t].icon}
                  </div>
                  <div>
                    <div className="text-[11px] font-medium">{panelTypeConfig[t].label}</div>
                    <div className="text-[9px] text-muted-foreground">{panelTypeConfig[t].description}</div>
                  </div>
                </button>
              ))}
            </div>
          </Card>

          {selectedPanel && (
            <Card className="p-4 space-y-3">
              <SectionHeading
                title="Configure Panel"
                description={selectedPanel.title}
                action={<Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setSelectedPanel(null)}><X className="w-3 h-3" /></Button>}
              />
              <div className="space-y-2">
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Title</label>
                  <Input
                    value={selectedPanel.title}
                    onChange={(e) => {
                      const updated = { ...selectedPanel, title: e.target.value };
                      setSelectedPanel(updated);
                      setPanels(panels.map((p) => p.id === updated.id ? updated : p));
                    }}
                    className="h-8 text-xs mt-1"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Query</label>
                  <Input
                    value={selectedPanel.query}
                    onChange={(e) => {
                      const updated = { ...selectedPanel, query: e.target.value };
                      setSelectedPanel(updated);
                      setPanels(panels.map((p) => p.id === updated.id ? updated : p));
                    }}
                    placeholder="metric{labels} [5m]"
                    className="h-8 text-[11px] font-mono mt-1"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Type</label>
                  <div className="flex items-center gap-1.5 mt-1 p-2 rounded-md border bg-muted/30">
                    {panelTypeConfig[selectedPanel.type].icon}
                    <span className="text-xs">{panelTypeConfig[selectedPanel.type].label}</span>
                  </div>
                </div>
              </div>
              <Button variant="outline" size="sm" className="w-full h-7 text-xs gap-1" onClick={() => toast.success("Panel settings", { description: "Advanced panel configuration opened." })}>
                <Settings2 className="w-3 h-3" /> Advanced
              </Button>
            </Card>
          )}

          <Card className="p-4 space-y-3">
            <SectionHeading title="Dashboard Layout" description="Grid settings" />
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Columns</span>
                <span className="font-mono">2</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Refresh interval</span>
                <span className="font-mono">30s</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Time range</span>
                <span className="font-mono">Last 1h</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Total panels</span>
                <span className="font-mono">{panels.length}</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
