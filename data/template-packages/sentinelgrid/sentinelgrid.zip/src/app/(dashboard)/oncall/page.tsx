"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading, EmptyState } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Phone, Bell, Clock, Activity, RefreshCw, MessageSquare,
  CalendarPlus, UserCog, ChevronRight, PhoneCall, Mail,
  ArrowRight, Users, Zap,
} from "lucide-react";
import {
  onCallShifts, people, teams, alerts, services, timeSeries,
} from "@/lib/data";
import { toast } from "sonner";

export default function OnCallSchedulePage() {
  const now = Date.now();

  const currentShifts = onCallShifts.filter((s) => {
    return new Date(s.start).getTime() < now && new Date(s.end).getTime() > now;
  });

  // Compute next shift (earliest upcoming shift)
  const upcoming = onCallShifts
    .filter((s) => new Date(s.start).getTime() > now)
    .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime());
  const nextShift = upcoming[0];
  const nextShiftUser = nextShift ? people.find((p) => p.id === nextShift.userId) : null;

  // Today's shifts (sort by start time)
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);
  const todayShifts = onCallShifts
    .filter((s) => {
      const st = new Date(s.start).getTime();
      return st >= startOfDay.getTime() && st <= endOfDay.getTime();
    })
    .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime());

  const pagesToday = alerts.length;
  const avgResponseMin = 4.2;

  function fmtTime(iso: string) {
    return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  function fmtDuration(ms: number) {
    const hours = Math.floor(ms / 3600000);
    const min = Math.floor((ms % 3600000) / 60000);
    return `${hours}h ${min}m`;
  }

  return (
    <PageContainer>
      <PageHeader
        title="On-Call Schedule"
        description="Live on-call coverage across all teams. Page engineers, manage rotations, and review the day's shift plan."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call" }]}
        icon={<Phone className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Shift overrides refreshed")}>
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Refresh</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("Opening override dialog")}>
              <UserCog className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Override Shift</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening new schedule form")}>
              <CalendarPlus className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Create Schedule</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Currently On-Call"
          value={currentShifts.length}
          hint="engineers active now"
          icon={<Users className="w-4 h-4" />}
          accent="primary"
        />
        <KpiCard
          label="Next Shift"
          value={nextShift ? fmtTime(nextShift.start) : "—"}
          hint={nextShiftUser ? `${nextShiftUser.name.split(" ")[0]} takes over` : "no upcoming shifts"}
          icon={<Clock className="w-4 h-4" />}
          accent="info"
        />
        <KpiCard
          label="Pages Today"
          value={pagesToday}
          delta={-12}
          deltaLabel="vs yesterday"
          icon={<Bell className="w-4 h-4" />}
          accent="warning"
          sparkline={[4, 6, 5, 8, 6, 9, 7, 5, 6, 7]}
        />
        <KpiCard
          label="Response Time Avg"
          value={avgResponseMin}
          unit="min"
          delta={-8}
          deltaLabel="improving"
          icon={<Activity className="w-4 h-4" />}
          accent="success"
          sparkline={[5.8, 5.4, 5.1, 4.8, 4.6, 4.4, 4.3, 4.2, 4.1, 4.2]}
        />
      </div>

      {/* Who's On Call Now - large card grid */}
      <div className="space-y-3">
        <SectionHeading
          title="Who's On Call Now"
          description="Engineers currently carrying the pager. Contact directly to page or message."
        />
        {currentShifts.length === 0 ? (
          <Card className="p-6">
            <EmptyState
              icon={<Phone className="w-5 h-5" />}
              title="No active on-call shifts"
              description="Schedule a rotation to enable paging coverage."
              action={<Button size="sm" className="gap-1.5"><CalendarPlus className="w-3.5 h-3.5" /> Create Schedule</Button>}
            />
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {currentShifts.map((shift) => {
              const user = people.find((p) => p.id === shift.userId);
              const team = teams.find((t) => t.id === shift.teamId);
              if (!user) return null;
              const end = new Date(shift.end);
              const remaining = end.getTime() - now;
              return (
                <Card key={shift.id} className="p-5 space-y-4 relative overflow-hidden border-primary/20">
                  <div className="absolute top-0 left-0 right-0 h-1" style={{ background: team?.color ?? "#22D3EE" }} />
                  <div className="flex items-start gap-3">
                    <div className="relative shrink-0">
                      <Avatar className="w-14 h-14 border-2 border-primary/40">
                        <AvatarImage src={user.avatarUrl} alt={user.name} />
                        <AvatarFallback>{user.name.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-success border-2 border-background animate-status-pulse" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold truncate">{user.name}</p>
                      <p className="text-xs text-muted-foreground truncate">{team?.name ?? user.team}</p>
                      <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium uppercase tracking-wider ${
                          shift.role === "primary" ? "bg-primary/15 text-primary border border-primary/30" :
                          shift.role === "secondary" ? "bg-accent text-accent-foreground border border-accent/30" :
                          "bg-muted text-muted-foreground border border-border"
                        }`}>{shift.role}</span>
                        {shift.isOverride && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-warning/15 text-warning-foreground border border-warning/30 font-medium uppercase tracking-wider">Override</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="pt-3 border-t border-border space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Shift ends</span>
                      <span className="font-mono tabular-nums font-medium">
                        {fmtTime(shift.end)} ({fmtDuration(remaining)} left)
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Timezone</span>
                      <span className="font-mono text-muted-foreground">{user.timezone}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="default" className="flex-1 h-8 text-xs gap-1.5" onClick={() => toast.success(`Paged ${user.name}`, { description: "Engineer notified via phone, SMS, and push." })}>
                      <PhoneCall className="w-3.5 h-3.5" /> Page
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 h-8 text-xs gap-1.5" onClick={() => toast.success(`Message sent to ${user.name}`)}>
                      <MessageSquare className="w-3.5 h-3.5" /> Message
                    </Button>
                    <Button size="sm" variant="outline" className="h-8 w-8 p-0" aria-label="Email engineer" onClick={() => toast.success(`Email composed to ${user.email}`)}>
                      <Mail className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Today's shifts timeline + side info */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading
            title="Today's Shifts"
            description={`${todayShifts.length} shifts scheduled for ${startOfDay.toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" })}`}
            action={<Button asChild variant="ghost" size="sm" className="text-xs h-7 gap-1"><Link href="/oncall/calendar">Calendar <ChevronRight className="w-3 h-3" /></Link></Button>}
          />
          <div className="space-y-3">
            {todayShifts.map((shift, idx) => {
              const user = people.find((p) => p.id === shift.userId);
              const team = teams.find((t) => t.id === shift.teamId);
              if (!user) return null;
              const shiftStart = new Date(shift.start).getTime();
              const shiftEnd = new Date(shift.end).getTime();
              const isPast = shiftEnd < now;
              const isNow = shiftStart < now && shiftEnd > now;
              return (
                <div key={shift.id} className="relative pl-8">
                  <div className="absolute left-0 top-0 bottom-0 w-px bg-border" />
                  <div className={`absolute left-0 top-1.5 w-3 h-3 -translate-x-1/2 rounded-full border-2 ${
                    isNow ? "bg-success border-success animate-status-pulse" :
                    isPast ? "bg-muted border-muted-foreground" :
                    "bg-background border-primary"
                  }`} />
                  <div className={`flex items-start justify-between gap-3 rounded-lg border p-3 ${isNow ? "border-primary/40 bg-primary/5" : "border-border"}`}>
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <Avatar className="w-8 h-8 shrink-0">
                        <AvatarImage src={user.avatarUrl} alt={user.name} />
                        <AvatarFallback className="text-[10px]">{user.name.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{user.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{team?.name ?? user.team}</p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs font-mono tabular-nums">
                        {fmtTime(shift.start)} - {fmtTime(shift.end)}
                      </p>
                      <p className={`text-[10px] mt-0.5 ${isNow ? "text-success font-medium" : isPast ? "text-muted-foreground" : "text-muted-foreground"}`}>
                        {isNow ? "Active now" : isPast ? "Completed" : "Upcoming"}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
            {todayShifts.length === 0 && (
              <div className="text-center py-8 text-sm text-muted-foreground">
                <CalendarPlus className="w-5 h-5 mx-auto mb-2 opacity-50" />
                No shifts scheduled today.
              </div>
            )}
          </div>
        </Card>

        <Card className="p-5 space-y-4">
          <SectionHeading title="Quick Actions" description="Common on-call workflows" />
          <div className="space-y-2">
            <Button asChild variant="outline" className="w-full justify-start h-12 text-sm gap-3">
              <Link href="/oncall/escalation">
                <Zap className="w-4 h-4 text-warning" />
                <div className="text-left">
                  <div className="font-medium">Configure Escalation</div>
                  <div className="text-[11px] text-muted-foreground">Edit paging escalation chains</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 ml-auto" />
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full justify-start h-12 text-sm gap-3">
              <Link href="/oncall/rotations">
                <RefreshCw className="w-4 h-4 text-primary" />
                <div className="text-left">
                  <div className="font-medium">Manage Rotations</div>
                  <div className="text-[11px] text-muted-foreground">Add participants, reorder</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 ml-auto" />
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full justify-start h-12 text-sm gap-3">
              <Link href="/oncall/handoffs">
                <MessageSquare className="w-4 h-4 text-accent" />
                <div className="text-left">
                  <div className="font-medium">Write Handoff Note</div>
                  <div className="text-[11px] text-muted-foreground">Pass context to next shift</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 ml-auto" />
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full justify-start h-12 text-sm gap-3">
              <Link href="/oncall/preferences">
                <UserCog className="w-4 h-4 text-info-foreground" />
                <div className="text-left">
                  <div className="font-medium">My Preferences</div>
                  <div className="text-[11px] text-muted-foreground">Notification methods, quiet hours</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 ml-auto" />
              </Link>
            </Button>
          </div>
        </Card>
      </div>
    </PageContainer>
  );
}
