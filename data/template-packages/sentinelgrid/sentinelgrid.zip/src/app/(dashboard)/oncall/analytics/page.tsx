"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/tables/data-table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LineChartCard, HorizontalBarChart } from "@/components/charts";
import {
  BarChart3, Bell, Clock, Activity, TrendingDown, Download, Moon, Flame,
} from "lucide-react";
import { people, teams, alerts, services, timeSeries } from "@/lib/data";
import { toast } from "sonner";

interface PagedEngineer {
  id: string;
  name: string;
  team: string;
  avatarUrl: string;
  pages7d: number;
  acks: number;
  avgAckMin: number;
  outsideHours: number;
}

const pagedEngineers: PagedEngineer[] = [
  { id: "u6", name: "Marcus Anderson", team: "Payments", avatarUrl: people.find(p => p.id === "u6")!.avatarUrl, pages7d: 14, acks: 13, avgAckMin: 2.4, outsideHours: 4 },
  { id: "u2", name: "Daniel Vargas", team: "Platform", avatarUrl: people.find(p => p.id === "u2")!.avatarUrl, pages7d: 11, acks: 11, avgAckMin: 3.1, outsideHours: 2 },
  { id: "u5", name: "Naomi Chen", team: "Reliability", avatarUrl: people.find(p => p.id === "u5")!.avatarUrl, pages7d: 9, acks: 8, avgAckMin: 4.5, outsideHours: 3 },
  { id: "u15", name: "Caleb Foster", team: "Platform", avatarUrl: people.find(p => p.id === "u15")!.avatarUrl, pages7d: 8, acks: 8, avgAckMin: 5.2, outsideHours: 1 },
  { id: "u3", name: "Priya Raman", team: "Reliability", avatarUrl: people.find(p => p.id === "u3")!.avatarUrl, pages7d: 7, acks: 7, avgAckMin: 3.8, outsideHours: 0 },
  { id: "u8", name: "Liam Walker", team: "Platform", avatarUrl: people.find(p => p.id === "u8")!.avatarUrl, pages7d: 6, acks: 6, avgAckMin: 4.0, outsideHours: 2 },
  { id: "u4", name: "Theo Lambert", team: "Reliability", avatarUrl: people.find(p => p.id === "u4")!.avatarUrl, pages7d: 5, acks: 5, avgAckMin: 2.9, outsideHours: 1 },
  { id: "u16", name: "Mei Lin", team: "Web", avatarUrl: people.find(p => p.id === "u16")!.avatarUrl, pages7d: 4, acks: 4, avgAckMin: 6.1, outsideHours: 0 },
];

export default function OnCallAnalyticsPage() {
  // Pages per week trend (12 weeks)
  const pagesPerWeek = Array.from({ length: 12 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (11 - i) * 7);
    return {
      date: `W${i + 1}`,
      value: Math.round(20 + Math.sin(i * 0.7) * 8 + Math.random() * 4),
    };
  });

  // Pages by team bar
  const pagesByTeam = teams.map((t, i) => ({
    name: t.name.split(" ")[0],
    value: Math.max(2, Math.round(15 - i * 2 + Math.random() * 6)),
  })).sort((a, b) => b.value - a.value);

  // Pages by hour-of-day heatmap (mock grid)
  const hours = Array.from({ length: 24 }, (_, h) => h);
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const heat = days.map((d, di) =>
    hours.map((h) => {
      // Higher during business hours, lower at night/weekends
      const businessHour = h >= 9 && h <= 18 ? 1 : 0.4;
      const weekday = di < 5 ? 1 : 0.5;
      return Math.round(((Math.sin(h * 0.4) + 1) * 4 + Math.random() * 3) * businessHour * weekday);
    })
  );
  const maxHeat = Math.max(...heat.flat());

  function heatColor(v: number) {
    if (v === 0) return "bg-muted/40";
    const ratio = v / maxHeat;
    if (ratio > 0.75) return "bg-destructive";
    if (ratio > 0.5) return "bg-warning";
    if (ratio > 0.25) return "bg-info";
    return "bg-primary/40";
  }

  const total7d = pagedEngineers.reduce((s, e) => s + e.pages7d, 0);
  const outsideHoursTotal = pagedEngineers.reduce((s, e) => s + e.outsideHours, 0);
  const avgResponse = (pagedEngineers.reduce((s, e) => s + e.avgAckMin * e.pages7d, 0) / total7d).toFixed(1);
  const fatigueScore = 38;

  const cols: Column<PagedEngineer>[] = [
    {
      key: "name",
      header: "Engineer",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="flex items-center gap-2">
          <Avatar className="w-7 h-7">
            <AvatarImage src={r.avatarUrl} alt={r.name} />
            <AvatarFallback className="text-[10px]">{r.name.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <p className="text-xs font-medium truncate">{r.name}</p>
            <p className="text-[10px] text-muted-foreground">{r.team}</p>
          </div>
        </div>
      ),
    },
    {
      key: "pages7d",
      header: "Pages (7d)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.pages7d,
      cell: (r) => <span className="text-xs font-mono tabular-nums font-medium">{r.pages7d}</span>,
    },
    {
      key: "acks",
      header: "Acknowledged",
      align: "right",
      hideOnMobile: true,
      cell: (r) => (
        <span className="text-xs tabular-nums">
          {r.acks}<span className="text-muted-foreground">/{r.pages7d}</span>
        </span>
      ),
    },
    {
      key: "avgAckMin",
      header: "Avg Ack",
      align: "right",
      sortable: true,
      sortValue: (r) => r.avgAckMin,
      cell: (r) => <span className={`text-xs font-mono tabular-nums ${r.avgAckMin > 5 ? "text-warning-foreground" : "text-foreground"}`}>{r.avgAckMin}m</span>,
    },
    {
      key: "outsideHours",
      header: "Outside Hours",
      align: "right",
      hideOnMobile: true,
      cell: (r) => (
        <span className={`text-xs font-mono tabular-nums ${r.outsideHours > 2 ? "text-destructive" : "text-muted-foreground"}`}>{r.outsideHours}</span>
      ),
    },
    {
      key: "fatigue",
      header: "Fatigue",
      align: "right",
      cell: (r) => {
        const score = Math.min(100, Math.round(r.pages7d * 4 + r.outsideHours * 6));
        return (
          <div className="flex items-center gap-2 justify-end">
            <div className="w-12 h-1.5 rounded-full bg-muted overflow-hidden">
              <div className={`h-full ${score > 60 ? "bg-destructive" : score > 30 ? "bg-warning" : "bg-success"}`} style={{ width: `${score}%` }} />
            </div>
            <span className="text-[10px] font-mono tabular-nums w-6 text-right">{score}</span>
          </div>
        );
      },
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="On-Call Analytics"
        description="Paging volume, response times, fatigue indicators, and load distribution across engineers."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call", href: "/oncall" }, { label: "Analytics" }]}
        icon={<BarChart3 className="w-5 h-5" />}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => toast.success("On-call analytics exported")}>
            <Download className="w-3.5 h-3.5" /> <span className="hidden md:inline">Export</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard
          label="Pages per Week"
          value={pagesPerWeek[pagesPerWeek.length - 1].value}
          delta={-8}
          deltaLabel="vs last week"
          icon={<Bell className="w-4 h-4" />}
          accent="primary"
          sparkline={pagesPerWeek.map((p) => p.value)}
        />
        <KpiCard
          label="Response Time"
          value={avgResponse}
          unit="min"
          delta={-12}
          deltaLabel="improving"
          icon={<Clock className="w-4 h-4" />}
          accent="success"
        />
        <KpiCard
          label="Pages Outside Hours"
          value={outsideHoursTotal}
          hint="after-hours in last 7d"
          icon={<Moon className="w-4 h-4" />}
          accent="warning"
        />
        <KpiCard
          label="Fatigue Score"
          value={fatigueScore}
          unit="/100"
          hint={fatigueScore < 30 ? "low" : fatigueScore < 60 ? "moderate" : "high"}
          icon={<Flame className="w-4 h-4" />}
          accent={fatigueScore < 30 ? "success" : fatigueScore < 60 ? "warning" : "destructive"}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <LineChartCard
          data={pagesPerWeek}
          dataKey="value"
          color={0}
          title="Pages per Week"
          description="Rolling 12-week paging volume trend"
          height={260}
        />
        <HorizontalBarChart
          data={pagesByTeam}
          title="Pages by Team (7d)"
          description="Paging volume distributed by team"
          color={1}
        />
        <KpiCard
          label="Total Pages (7d)"
          value={total7d}
          hint={`${(total7d / 7).toFixed(1)} avg/day`}
          icon={<Activity className="w-4 h-4" />}
          accent="info"
        />
      </div>

      {/* Heatmap */}
      <Card className="p-5 space-y-4">
        <SectionHeading
          title="Pages by Hour-of-Day"
          description="Heatmap of paging frequency by day-of-week and hour. Darker = more pages."
          action={
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
              <span>Less</span>
              <div className="flex gap-0.5">
                <span className="w-3 h-3 rounded-sm bg-muted/40" />
                <span className="w-3 h-3 rounded-sm bg-primary/40" />
                <span className="w-3 h-3 rounded-sm bg-info" />
                <span className="w-3 h-3 rounded-sm bg-warning" />
                <span className="w-3 h-3 rounded-sm bg-destructive" />
              </div>
              <span>More</span>
            </div>
          }
        />
        <div className="overflow-x-auto">
          <div className="min-w-[680px]">
            <div className="grid grid-cols-[40px_repeat(24,1fr)] gap-1 mb-1">
              <div></div>
              {hours.map((h) => (
                <div key={h} className="text-center text-[9px] text-muted-foreground font-mono">
                  {h % 3 === 0 ? `${h.toString().padStart(2, "0")}` : ""}
                </div>
              ))}
            </div>
            {days.map((d, di) => (
              <div key={d} className="grid grid-cols-[40px_repeat(24,1fr)] gap-1 mb-1">
                <div className="text-[10px] text-muted-foreground font-medium flex items-center">{d}</div>
                {hours.map((h) => (
                  <div
                    key={h}
                    className={`h-6 rounded-sm ${heatColor(heat[di][h])} hover:ring-1 hover:ring-primary cursor-pointer`}
                    title={`${d} ${h}:00 — ${heat[di][h]} pages`}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Top paged engineers table */}
      <Card className="p-4 md:p-5">
        <SectionHeading title="Top Paged Engineers (7d)" description="Engineers receiving the most pages — flag for rotation review" />
        <div className="mt-4">
          <DataTable
            columns={cols}
            data={pagedEngineers}
            rowKey={(r) => r.id}
            searchKeys={["name", "team"]}
            searchPlaceholder="Search engineers..."
            pageSize={8}
            initialSort={{ key: "pages7d", dir: "desc" }}
          />
        </div>
      </Card>
    </PageContainer>
  );
}
