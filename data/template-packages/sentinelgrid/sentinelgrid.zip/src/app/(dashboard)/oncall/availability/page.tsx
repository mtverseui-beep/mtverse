"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  CalendarDays, Users, CheckCircle2, AlertTriangle, Plane, Brain, Phone, Coffee,
} from "lucide-react";
import { teams, people, onCallShifts } from "@/lib/data";
import { toast } from "sonner";

type Availability = "available" | "pto" | "focus" | "oncall" | "off";

const days = Array.from({ length: 7 }, (_, i) => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + i);
  return d;
});

const dayLabels = days.map((d, i) => ({
  short: d.toLocaleDateString([], { weekday: "short" }),
  date: d.toLocaleDateString([], { month: "numeric", day: "numeric" }),
  isToday: i === 0,
}));

// Build deterministic availability per person/day
function availabilityFor(personId: string, dayIdx: number): Availability {
  const shift = onCallShifts.find((s) => {
    if (s.userId !== personId) return false;
    const ss = new Date(s.start);
    const target = days[dayIdx];
    return ss.getDate() === target.getDate() && ss.getMonth() === target.getMonth();
  });
  if (shift) return "oncall";
  // deterministic pseudo-random
  const h = (personId.charCodeAt(1) * 31 + dayIdx * 7) % 11;
  if (h === 0) return "pto";
  if (h === 1) return "focus";
  if (h === 2) return "off";
  return "available";
}

const availConfig: Record<Availability, { label: string; bg: string; dot: string; text: string }> = {
  available: { label: "Available", bg: "bg-success/15", dot: "bg-success", text: "text-success" },
  pto: { label: "PTO", bg: "bg-warning/15", dot: "bg-warning", text: "text-warning-foreground" },
  focus: { label: "Focus", bg: "bg-accent/15", dot: "bg-accent", text: "text-accent-foreground" },
  oncall: { label: "On-Call", bg: "bg-primary/15", dot: "bg-primary", text: "text-primary" },
  off: { label: "Off", bg: "bg-muted", dot: "bg-muted-foreground", text: "text-muted-foreground" },
};

export default function AvailabilityPage() {
  const [teamFilter, setTeamFilter] = React.useState<string>("all");

  const filteredPeople = teamFilter === "all"
    ? people
    : people.filter((p) => teams.find((t) => t.id === teamFilter)?.memberIds.includes(p.id));

  // Coverage per day
  const coverage = dayLabels.map((_, dayIdx) => {
    const available = filteredPeople.filter((p) => {
      const a = availabilityFor(p.id, dayIdx);
      return a === "available" || a === "oncall";
    }).length;
    return available;
  });
  const lowCoverageDays = coverage.filter((c) => c < 2).length;
  const ptoToday = filteredPeople.filter((p) => availabilityFor(p.id, 0) === "pto").length;
  const onCallToday = filteredPeople.filter((p) => availabilityFor(p.id, 0) === "oncall").length;

  return (
    <PageContainer>
      <PageHeader
        title="Team Availability"
        description="Plan around PTO, focus time, and on-call shifts. Identify days with thin coverage before they become incidents."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call", href: "/oncall" }, { label: "Availability" }]}
        icon={<CalendarDays className="w-5 h-5" />}
        actions={
          <Select value={teamFilter} onValueChange={setTeamFilter}>
            <SelectTrigger className="h-9 w-[180px] text-xs">
              <SelectValue placeholder="Filter by team" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All teams</SelectItem>
              {teams.map((t) => (
                <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="People Tracked" value={filteredPeople.length} hint="in current view" icon={<Users className="w-4 h-4" />} accent="primary" />
        <KpiCard label="On-Call Today" value={onCallToday} hint="engineers carrying pager" icon={<Phone className="w-4 h-4" />} accent="info" />
        <KpiCard label="PTO Today" value={ptoToday} hint="out of office" icon={<Plane className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Coverage Warnings" value={lowCoverageDays} hint="days with < 2 available" icon={<AlertTriangle className="w-4 h-4" />} accent={lowCoverageDays > 0 ? "destructive" : "success"} />
      </div>

      <Card className="p-4 md:p-5 overflow-hidden">
        <SectionHeading
          title="7-Day Availability Matrix"
          description="Each cell shows an engineer's status for the day. Hover for details."
          action={
            <div className="hidden md:flex items-center gap-2 flex-wrap">
              {Object.entries(availConfig).map(([k, v]) => (
                <span key={k} className="inline-flex items-center gap-1.5 text-xs">
                  <span className={`w-2.5 h-2.5 rounded-full ${v.dot}`} />
                  {v.label}
                </span>
              ))}
            </div>
          }
        />

        <div className="mt-4 overflow-x-auto">
          <div className="min-w-[680px]">
            {/* Header */}
            <div className="grid grid-cols-[220px_repeat(7,1fr)] gap-1 mb-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium px-2 py-1">Engineer</div>
              {dayLabels.map((d, i) => (
                <div key={i} className={`text-center px-2 py-1 rounded ${d.isToday ? "bg-primary/10" : ""}`}>
                  <p className={`text-[10px] uppercase tracking-wider font-medium ${d.isToday ? "text-primary" : "text-muted-foreground"}`}>{d.short}</p>
                  <p className={`text-[11px] font-mono ${d.isToday ? "text-primary font-semibold" : "text-foreground"}`}>{d.date}</p>
                </div>
              ))}
            </div>

            {/* Rows */}
            <div className="space-y-1">
              {filteredPeople.map((p) => {
                const team = teams.find((t) => t.memberIds.includes(p.id));
                return (
                  <div key={p.id} className="grid grid-cols-[220px_repeat(7,1fr)] gap-1 items-center">
                    <div className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-muted/30">
                      <Avatar className="w-6 h-6">
                        <AvatarImage src={p.avatarUrl} alt={p.name} />
                        <AvatarFallback className="text-[9px]">{p.name.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <p className="text-[11px] font-medium truncate">{p.name}</p>
                        <p className="text-[9px] text-muted-foreground truncate">{team?.name ?? p.team}</p>
                      </div>
                    </div>
                    {dayLabels.map((_, di) => {
                      const a = availabilityFor(p.id, di);
                      const cfg = availConfig[a];
                      return (
                        <button
                          key={di}
                          onClick={() => toast.success(`${p.name} — ${cfg.label} on ${dayLabels[di].short} ${dayLabels[di].date}`)}
                          className={`h-9 rounded-md ${cfg.bg} border border-border/60 hover:border-primary/40 transition-colors flex items-center justify-center`}
                          title={`${p.name} — ${cfg.label}`}
                          aria-label={`${p.name} ${cfg.label}`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
                        </button>
                      );
                    })}
                  </div>
                );
              })}
              {filteredPeople.length === 0 && (
                <div className="text-center py-12 text-sm text-muted-foreground">No engineers match the filter.</div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile legend */}
        <div className="mt-4 md:hidden grid grid-cols-2 gap-2 pt-3 border-t border-border">
          {Object.entries(availConfig).map(([k, v]) => (
            <span key={k} className="inline-flex items-center gap-1.5 text-xs">
              <span className={`w-2.5 h-2.5 rounded-full ${v.dot}`} />
              {v.label}
            </span>
          ))}
        </div>
      </Card>

      {/* Coverage summary */}
      <Card className="p-5">
        <SectionHeading title="Daily Coverage" description="Number of engineers available to respond per day" />
        <div className="mt-4 grid grid-cols-7 gap-2">
          {coverage.map((c, i) => {
            const low = c < 2;
            const medium = c < 4 && !low;
            return (
              <div key={i} className={`rounded-lg border p-3 text-center ${dayLabels[i].isToday ? "border-primary bg-primary/5" : "border-border"}`}>
                <p className={`text-[10px] uppercase tracking-wider ${dayLabels[i].isToday ? "text-primary" : "text-muted-foreground"}`}>{dayLabels[i].short}</p>
                <p className={`text-2xl font-semibold tabular-nums mt-1 ${low ? "text-destructive" : medium ? "text-warning-foreground" : "text-foreground"}`}>{c}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{low ? "thin" : "ok"}</p>
              </div>
            );
          })}
        </div>
        {lowCoverageDays > 0 && (
          <div className="mt-4 flex items-start gap-2 p-3 rounded-lg border border-destructive/30 bg-destructive/5 text-xs">
            <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-destructive">Coverage warning</p>
              <p className="text-muted-foreground mt-0.5">{lowCoverageDays} day(s) in the next 7 have fewer than 2 available engineers. Consider reassigning shifts or recruiting backup coverage.</p>
            </div>
          </div>
        )}
      </Card>
    </PageContainer>
  );
}
