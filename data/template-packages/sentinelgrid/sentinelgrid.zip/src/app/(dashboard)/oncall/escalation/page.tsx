"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Zap, Clock, Repeat, Plus, Pencil, ArrowRight, Users, Bell, CheckCircle2,
} from "lucide-react";
import { escalationPolicies, people, teams } from "@/lib/data";
import { toast } from "sonner";

export default function EscalationPoliciesPage() {
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingPolicy, setEditingPolicy] = React.useState<string | null>(null);
  const [name, setName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [repeat, setRepeat] = React.useState(1);

  function openCreate() {
    setEditingPolicy(null);
    setName("");
    setDescription("");
    setRepeat(1);
    setDialogOpen(true);
  }
  function openEdit(id: string) {
    const p = escalationPolicies.find((e) => e.id === id);
    if (!p) return;
    setEditingPolicy(id);
    setName(p.name);
    setDescription(p.description);
    setRepeat(p.repeatCount);
    setDialogOpen(true);
  }
  function save() {
    if (!name.trim()) {
      toast.error("Policy name is required");
      return;
    }
    toast.success(editingPolicy ? "Escalation policy updated" : "Escalation policy created", {
      description: `${name} — repeats ${repeat}x`,
    });
    setDialogOpen(false);
  }

  return (
    <PageContainer>
      <PageHeader
        title="Escalation Policies"
        description="Configure paging escalation chains. Each policy defines rounds of targets with delays before advancing to the next round."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call", href: "/oncall" }, { label: "Escalation" }]}
        icon={<Zap className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={openCreate}>
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden md:inline">New Policy</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Active Policies" value={escalationPolicies.length} hint="across all teams" icon={<Zap className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Avg Rounds" value={(escalationPolicies.reduce((s, p) => s + p.rounds.length, 0) / escalationPolicies.length).toFixed(1)} hint="per policy" icon={<Repeat className="w-4 h-4" />} accent="info" />
        <KpiCard label="Max Repeat" value={Math.max(...escalationPolicies.map(p => p.repeatCount))} hint="highest re-escalation count" icon={<Bell className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Targets Configured" value={escalationPolicies.reduce((s, p) => s + p.rounds.reduce((ss, r) => ss + r.targets.length, 0), 0)} hint="people in chains" icon={<Users className="w-4 h-4" />} accent="success" />
      </div>

      <div className="space-y-4">
        {escalationPolicies.map((p) => {
          const team = teams.find((t) => t.escalationPolicyId === p.id);
          return (
            <Card key={p.id} className="p-5 space-y-4">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-semibold">{p.name}</h3>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border font-mono">{p.id}</span>
                    {team && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded font-medium" style={{ background: `${team.color}15`, color: team.color }}>
                        {team.name}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{p.description}</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-right text-xs">
                    <p className="text-muted-foreground">Repeats</p>
                    <p className="font-mono font-medium">{p.repeatCount}x</p>
                  </div>
                  <Button variant="outline" size="sm" className="gap-1.5 h-8" onClick={() => openEdit(p.id)}>
                    <Pencil className="w-3 h-3" /> Edit
                  </Button>
                </div>
              </div>

              {/* Visual flow */}
              <div className="overflow-x-auto">
                <div className="flex items-stretch gap-2 min-w-max">
                  {p.rounds.map((round, ri) => {
                    return (
                      <React.Fragment key={ri}>
                        {ri > 0 && (
                          <div className="flex flex-col items-center justify-center px-1 text-center">
                            <Clock className="w-3.5 h-3.5 text-muted-foreground mb-1" />
                            <span className="text-[10px] font-mono text-muted-foreground whitespace-nowrap">
                              +{round.delayMinutes}m
                            </span>
                          </div>
                        )}
                        <div className="rounded-lg border border-border bg-muted/30 p-3 min-w-[180px]">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Round {ri + 1}</span>
                            <span className="text-[10px] font-mono text-muted-foreground">
                              {round.delayMinutes === 0 ? "Immediate" : `+${round.delayMinutes}m`}
                            </span>
                          </div>
                          <div className="space-y-1.5">
                            {round.targets.map((t, ti) => {
                              const u = people.find((p) => p.id === t.id);
                              return (
                                <div key={ti} className="flex items-center gap-2 p-1.5 rounded border border-border bg-card">
                                  <Avatar className="w-6 h-6">
                                    <AvatarImage src={u?.avatarUrl} alt={u?.name ?? "Target"} />
                                    <AvatarFallback className="text-[9px]">{u?.name?.split(" ").map(s => s[0]).join("").slice(0, 2) ?? "?"}</AvatarFallback>
                                  </Avatar>
                                  <div className="min-w-0 flex-1">
                                    <p className="text-[11px] font-medium truncate">{u?.name ?? t.id}</p>
                                    <p className="text-[9px] text-muted-foreground uppercase">{t.type}</p>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                        {ri === p.rounds.length - 1 && p.repeatCount > 0 && (
                          <div className="flex flex-col items-center justify-center px-2 text-center">
                            <Repeat className="w-3.5 h-3.5 text-warning mb-1" />
                            <span className="text-[10px] font-mono text-warning whitespace-nowrap">Repeat {p.repeatCount}x</span>
                          </div>
                        )}
                      </React.Fragment>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-muted-foreground pt-2 border-t border-border">
                <ArrowRight className="w-3 h-3" />
                <span>
                  Total escalation window: <span className="font-mono font-medium text-foreground">
                    {p.rounds.reduce((s, r) => s + r.delayMinutes, 0)} minutes
                  </span>{" "}
                  before paging manager and repeating.
                </span>
              </div>
            </Card>
          );
        })}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingPolicy ? "Edit Escalation Policy" : "New Escalation Policy"}</DialogTitle>
            <DialogDescription>
              {editingPolicy ? "Update the policy configuration below." : "Define a new paging escalation chain."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="name">Policy Name</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Platform - Critical" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="desc">Description</Label>
              <Textarea id="desc" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What this escalation policy is for" rows={3} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="repeat">Repeat Count</Label>
              <Input id="repeat" type="number" min={0} max={5} value={repeat} onChange={(e) => setRepeat(parseInt(e.target.value || "0", 10))} />
              <p className="text-[11px] text-muted-foreground">How many times to re-escalate from round 1 before giving up.</p>
            </div>
            <div className="rounded-lg border border-dashed border-border p-3 text-xs text-muted-foreground">
              <CheckCircle2 className="w-3.5 h-3.5 inline-block mr-1.5 text-muted-foreground" />
              Round-by-round targets and delays are configured in the visual flow editor after saving.
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={save}>{editingPolicy ? "Save Changes" : "Create Policy"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
