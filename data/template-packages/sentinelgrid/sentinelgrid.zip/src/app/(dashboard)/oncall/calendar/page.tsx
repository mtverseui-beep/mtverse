"use client";

import * as React from "react";
import Link from "next/link";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  ChevronLeft, ChevronRight, CalendarDays, Phone, Info,
} from "lucide-react";
import {
  onCallShifts, people, teams,
} from "@/lib/data";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";

export default function OnCallCalendarPage() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [cursor, setCursor] = React.useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDay, setSelectedDay] = React.useState<Date | null>(null);

  const year = cursor.getFullYear();
  const month = cursor.getMonth();

  // Build calendar grid (Sunday-first, 6 weeks for stable height)
  const firstOfMonth = new Date(year, month, 1);
  const startWeekday = firstOfMonth.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (Date | null)[] = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length < 42) cells.push(null);

  function shiftsForDay(d: Date) {
    const dStart = new Date(d);
    dStart.setHours(0, 0, 0, 0);
    const dEnd = new Date(d);
    dEnd.setHours(23, 59, 59, 999);
    const real = onCallShifts.filter((s) => {
      const ss = new Date(s.start);
      return ss >= dStart && ss <= dEnd;
    });
    if (real.length > 0) return real;
    return teams.map((t, idx) => {
      const memberIds = t.memberIds;
      const personId = memberIds[(d.getDate() + idx) % memberIds.length];
      return {
        id: `syn-${d.toISOString().slice(0,10)}-${t.id}`,
        userId: personId,
        teamId: t.id,
        role: "primary" as const,
        start: new Date(dStart.getTime() + 8 * 3600 * 1000).toISOString(),
        end: new Date(dStart.getTime() + 20 * 3600 * 1000).toISOString(),
      };
    });
  }

  const monthLabel = cursor.toLocaleDateString([], { month: "long", year: "numeric" });
  const isToday = (d: Date) =>
    d.getFullYear() === today.getFullYear() && d.getMonth() === today.getMonth() && d.getDate() === today.getDate();

  const selectedShifts = selectedDay ? shiftsForDay(selectedDay) : [];

  return (
    <PageContainer>
      <PageHeader
        title="On-Call Calendar"
        description="Month view of on-call coverage. Each day shows the engineers carrying the pager, color-coded by team."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call", href: "/oncall" }, { label: "Calendar" }]}
        icon={<CalendarDays className="w-5 h-5" />}
        actions={
          <>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setCursor(new Date(today.getFullYear(), today.getMonth(), 1))}>
              <CalendarDays className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Today</span>
            </Button>
            <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening new schedule form")}>
              <Phone className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Schedule Shift</span>
            </Button>
          </>
        }
      />

      <Card className="p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(year, month - 1, 1))} aria-label="Previous month">
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(year, month + 1, 1))} aria-label="Next month">
              <ChevronRight className="w-4 h-4" />
            </Button>
            <h2 className="text-base font-semibold ml-1">{monthLabel}</h2>
          </div>
          <div className="hidden md:flex items-center gap-3">
            {teams.map((t) => (
              <span key={t.id} className="inline-flex items-center gap-1.5 text-xs">
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: t.color }} />
                {t.name}
              </span>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1.5 text-center">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <div key={d} className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium py-1">
              {d}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1.5">
          {cells.map((d, i) => {
            if (!d) return <div key={i} className="min-h-[96px] md:min-h-[124px] rounded-lg border border-dashed border-border/40 bg-muted/20" />;
            const dayShifts = shiftsForDay(d);
            const todayCls = isToday(d);
            return (
              <button
                key={i}
                onClick={() => { setSelectedDay(d); }}
                className={`min-h-[96px] md:min-h-[124px] text-left rounded-lg border p-2 transition-colors hover:border-primary/40 hover:bg-muted/30 ${
                  todayCls ? "border-primary bg-primary/5" : "border-border"
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-[11px] font-semibold tabular-nums ${todayCls ? "text-primary" : "text-foreground"}`}>
                    {d.getDate()}
                  </span>
                  {todayCls && <span className="text-[9px] px-1 py-0.5 rounded bg-primary text-primary-foreground font-semibold uppercase">Now</span>}
                </div>
                <div className="space-y-1">
                  {dayShifts.slice(0, 3).map((s) => {
                    const u = people.find((p) => p.id === s.userId);
                    if (!u) return null;
                    const t = teams.find((tm) => tm.id === s.teamId);
                    return (
                      <div key={s.id} className="flex items-center gap-1 rounded px-1 py-0.5" style={{ background: `${t?.color ?? "#22D3EE"}15` }}>
                        <span className="w-1 h-3 rounded-full shrink-0" style={{ background: t?.color ?? "#22D3EE" }} />
                        <Avatar className="w-4 h-4 border border-background">
                          <AvatarImage src={u.avatarUrl} alt={u.name} />
                          <AvatarFallback className="text-[8px]">{u.name.split(" ").map(x => x[0]).join("").slice(0, 2)}</AvatarFallback>
                        </Avatar>
                        <span className="text-[10px] font-medium truncate">{u.name.split(" ")[0]}</span>
                      </div>
                    );
                  })}
                  {dayShifts.length > 3 && (
                    <div className="text-[9px] text-muted-foreground px-1">+{dayShifts.length - 3} more</div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </Card>

      <Card className="p-4 md:hidden">
        <SectionHeading title="Teams" description="Tap a day to see details" />
        <div className="mt-3 grid grid-cols-2 gap-2">
          {teams.map((t) => (
            <span key={t.id} className="inline-flex items-center gap-1.5 text-xs">
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: t.color }} />
              {t.name}
            </span>
          ))}
        </div>
      </Card>

      <Dialog open={!!selectedDay} onOpenChange={(o) => !o && setSelectedDay(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {selectedDay ? selectedDay.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric", year: "numeric" }) : ""}
            </DialogTitle>
            <DialogDescription>{selectedShifts.length} on-call shift(s) scheduled</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {selectedShifts.map((s) => {
              const u = people.find((p) => p.id === s.userId);
              const t = teams.find((tm) => tm.id === s.teamId);
              if (!u) return null;
              return (
                <div key={s.id} className="flex items-start gap-3 rounded-lg border p-3">
                  <span className="w-1 self-stretch rounded-full" style={{ background: t?.color ?? "#22D3EE" }} />
                  <Avatar className="w-9 h-9">
                    <AvatarImage src={u.avatarUrl} alt={u.name} />
                    <AvatarFallback className="text-[10px]">{u.name.split(" ").map(x => x[0]).join("").slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{u.name}</p>
                    <p className="text-xs text-muted-foreground">{t?.name ?? u.team}</p>
                    <p className="text-[11px] font-mono mt-1 text-muted-foreground">
                      {new Date(s.start).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} - {new Date(s.end).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded font-medium uppercase tracking-wider bg-muted text-muted-foreground border border-border">
                    {s.role}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="flex items-center justify-between pt-2">
            <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <Info className="w-3 h-3" />
              Click a day cell to inspect shifts
            </span>
            <Button asChild size="sm" className="gap-1.5">
              <Link href="/oncall" onClick={() => setSelectedDay(null)}>Back to schedule</Link>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
