"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  MessageSquare, ArrowRight, Plus, ClipboardList, AlertCircle, CheckSquare,
  ChevronRight, FileText, Send,
} from "lucide-react";
import { people, teams, alerts } from "@/lib/data";
import { toast } from "sonner";

interface HandoffNote {
  id: string;
  fromId: string;
  toId: string;
  teamId: string;
  shiftDate: string;
  notes: string;
  openItems: { id: string; text: string; done: boolean }[];
  followUps: string[];
  createdAt: string;
}

const initialNotes: HandoffNote[] = [
  {
    id: "hn1",
    fromId: "u5",
    toId: "u11",
    teamId: "t2",
    shiftDate: "2026-07-02T12:00:00Z",
    notes: "Reliability shift was quiet. Checkout API is still elevated but stable around 1.4% 5xx. We're monitoring and the payments team is rolling out a fix in canary. No new incidents opened.",
    openItems: [
      { id: "oi1", text: "Monitor checkout-api canary deployment d6", done: false },
      { id: "oi2", text: "Re-evaluate billing-service queue depth after worker scale-up", done: false },
      { id: "oi3", text: "Confirm auth-service JWKS rotation completed", done: true },
    ],
    followUps: ["If checkout 5xx exceeds 2%, escalate to inc1 commander", "Check disk pressure on db-replica-2 — currently 87%"],
    createdAt: "2026-07-02T11:55:00Z",
  },
  {
    id: "hn2",
    fromId: "u10",
    toId: "u8",
    teamId: "t1",
    shiftDate: "2026-07-02T08:00:00Z",
    notes: "Platform overnight was uneventful. Kafka consumer lag briefly spiked at 03:14 but auto-recovered within 4 minutes. No pages fired. Billing-service deploy d2 went out cleanly at 08:15.",
    openItems: [
      { id: "oi4", text: "Watch kafka-bus consumer lag through morning traffic peak", done: false },
      { id: "oi5", text: "Verify d2 billing-service deploy metrics stabilize", done: false },
    ],
    followUps: ["If API gateway p99 > 200ms, page ar7 owner", "Be aware of upcoming auth-service deploy window 14:00 UTC"],
    createdAt: "2026-07-02T07:50:00Z",
  },
  {
    id: "hn3",
    fromId: "u7",
    toId: "u6",
    teamId: "t3",
    shiftDate: "2026-07-02T00:00:00Z",
    notes: "Payments shift picked up the checkout 5xx alert at 05:12. Marcus took commander role for inc1. Canary deploy d6 is suspected root cause — 3DS retry strategy may be misbehaving under load. Investigating.",
    openItems: [
      { id: "oi6", text: "Continue inc1 investigation (checkout 5xx, canary d6)", done: false },
      { id: "oi7", text: "Prepare rollback plan for d6 if 5xx worsens", done: false },
    ],
    followUps: ["If 5xx exceeds 2%, execute d6 rollback", "Coordinate with payments lead Diego (u13) before any prod changes"],
    createdAt: "2026-07-01T23:55:00Z",
  },
];

export default function HandoffsPage() {
  const [notes, setNotes] = React.useState(initialNotes);
  const [openItems, setOpenItems] = React.useState<Record<string, boolean>>({});
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [form, setForm] = React.useState({
    fromId: "u5",
    toId: "u11",
    notes: "",
    openItemsText: "",
    followUpsText: "",
  });

  function toggleOpen(noteId: string, itemId: string) {
    setOpenItems((s) => {
      const key = `${noteId}:${itemId}`;
      return { ...s, [key]: !s[key] };
    });
  }

  function submitHandoff() {
    if (!form.notes.trim()) {
      toast.error("Handoff notes cannot be empty");
      return;
    }
    const newNote: HandoffNote = {
      id: `hn${notes.length + 1}`,
      fromId: form.fromId,
      toId: form.toId,
      teamId: people.find((p) => p.id === form.fromId)?.team === "Reliability" ? "t2" :
              people.find((p) => p.id === form.fromId)?.team === "Platform" ? "t1" :
              people.find((p) => p.id === form.fromId)?.team === "Payments" ? "t3" : "t1",
      shiftDate: new Date().toISOString(),
      notes: form.notes,
      openItems: form.openItemsText.split("\n").filter(Boolean).map((t, i) => ({ id: `oi${Date.now()}_${i}`, text: t, done: false })),
      followUps: form.followUpsText.split("\n").filter(Boolean),
      createdAt: new Date().toISOString(),
    };
    setNotes((n) => [newNote, ...n]);
    setForm({ fromId: "u5", toId: "u11", notes: "", openItemsText: "", followUpsText: "" });
    setDialogOpen(false);
    toast.success("Handoff note created", { description: "Next shift engineer will see this on check-in." });
  }

  const openItemsTotal = notes.reduce((s, n) => s + n.openItems.length, 0);
  const openItemsDone = notes.reduce((s, n) => s + n.openItems.filter((oi) => openItems[`${n.id}:${oi.id}`] ?? oi.done).length, 0);
  const followUpsTotal = notes.reduce((s, n) => s + n.followUps.length, 0);

  return (
    <PageContainer>
      <PageHeader
        title="Handoff Notes"
        description="Pass context between shifts. Capture open work, follow-ups, and ambient awareness from the outgoing engineer."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call", href: "/oncall" }, { label: "Handoffs" }]}
        icon={<MessageSquare className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => setDialogOpen(true)}>
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden md:inline">New Handoff</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Handoffs (7d)" value={notes.length} hint="shift transitions logged" icon={<MessageSquare className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Open Items" value={openItemsTotal - openItemsDone} hint={`${openItemsDone} of ${openItemsTotal} resolved`} icon={<ClipboardList className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Follow-ups" value={followUpsTotal} hint="escalation triggers" icon={<AlertCircle className="w-4 h-4" />} accent="info" />
        <KpiCard label="Avg Note Length" value={`${Math.round(notes.reduce((s, n) => s + n.notes.length, 0) / notes.length)}ch`} hint="median handoff size" icon={<FileText className="w-4 h-4" />} accent="muted" />
      </div>

      <div className="space-y-4">
        {notes.map((n) => {
          const from = people.find((p) => p.id === n.fromId);
          const to = people.find((p) => p.id === n.toId);
          const team = teams.find((t) => t.id === n.teamId);
          const doneCount = n.openItems.filter((oi) => openItems[`${n.id}:${oi.id}`] ?? oi.done).length;
          return (
            <Card key={n.id} className="p-5 space-y-4">
              {/* Header: from -> to */}
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-3 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={from?.avatarUrl} alt={from?.name ?? ""} />
                      <AvatarFallback className="text-[10px]">{from?.name?.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-xs font-medium">{from?.name}</p>
                      <p className="text-[10px] text-muted-foreground">outgoing</p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                  <div className="flex items-center gap-2">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={to?.avatarUrl} alt={to?.name ?? ""} />
                      <AvatarFallback className="text-[10px]">{to?.name?.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-xs font-medium">{to?.name}</p>
                      <p className="text-[10px] text-muted-foreground">incoming</p>
                    </div>
                  </div>
                  {team && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-medium" style={{ background: `${team.color}15`, color: team.color }}>
                      {team.name}
                    </span>
                  )}
                </div>
                <div className="text-right">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Shift Date</p>
                  <p className="text-xs font-mono">{new Date(n.shiftDate).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</p>
                </div>
              </div>

              {/* Notes body */}
              <div className="rounded-lg bg-muted/30 border border-border p-3">
                <p className="text-sm leading-relaxed">{n.notes}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Open items */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium flex items-center gap-1.5">
                      <ClipboardList className="w-3 h-3" /> Open Items
                    </span>
                    <span className="text-[10px] text-muted-foreground font-mono">{doneCount}/{n.openItems.length}</span>
                  </div>
                  <div className="space-y-1">
                    {n.openItems.map((oi) => {
                      const done = openItems[`${n.id}:${oi.id}`] ?? oi.done;
                      return (
                        <button
                          key={oi.id}
                          onClick={() => toggleOpen(n.id, oi.id)}
                          className="w-full flex items-start gap-2 text-left rounded p-1.5 hover:bg-muted/30"
                        >
                          <CheckSquare className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${done ? "text-success" : "text-muted-foreground"}`} />
                          <span className={`text-xs ${done ? "line-through text-muted-foreground" : "text-foreground"}`}>{oi.text}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Follow-ups */}
                <div className="space-y-2">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium flex items-center gap-1.5">
                    <AlertCircle className="w-3 h-3" /> Follow-ups
                  </span>
                  <div className="space-y-1">
                    {n.followUps.map((f, i) => (
                      <div key={i} className="flex items-start gap-2 rounded p-1.5 bg-warning/5 border border-warning/20">
                        <ChevronRight className="w-3 h-3 mt-0.5 shrink-0 text-warning" />
                        <span className="text-xs">{f}</span>
                      </div>
                    ))}
                    {n.followUps.length === 0 && (
                      <p className="text-[11px] text-muted-foreground italic">No follow-ups.</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-border flex items-center justify-between text-[10px] text-muted-foreground">
                <span>Logged {new Date(n.createdAt).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success("Handoff copied to clipboard")}>
                  <FileText className="w-3 h-3" /> Copy
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>New Handoff Note</DialogTitle>
            <DialogDescription>Pass context to the incoming on-call engineer.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2 max-h-[60vh] overflow-y-auto">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>From</Label>
                <Select value={form.fromId} onValueChange={(v) => setForm((f) => ({ ...f, fromId: v }))}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {people.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>To</Label>
                <Select value={form.toId} onValueChange={(v) => setForm((f) => ({ ...f, toId: v }))}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {people.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea
                value={form.notes}
                onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                placeholder="What happened on your shift? What should the next engineer know?"
                rows={4}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Open Items (one per line)</Label>
              <Textarea
                value={form.openItemsText}
                onChange={(e) => setForm((f) => ({ ...f, openItemsText: e.target.value }))}
                placeholder={"Monitor checkout-api canary\nCheck db-replica-2 disk"}
                rows={3}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Follow-ups (one per line)</Label>
              <Textarea
                value={form.followUpsText}
                onChange={(e) => setForm((f) => ({ ...f, followUpsText: e.target.value }))}
                placeholder={"If 5xx > 2%, escalate to inc1 commander"}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button className="gap-1.5" onClick={submitHandoff}>
              <Send className="w-3.5 h-3.5" /> Send Handoff
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
