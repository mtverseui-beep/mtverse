"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Repeat, Calendar, Plus, GripVertical, ChevronUp, ChevronDown, UserPlus,
  RefreshCw, ArrowRight,
} from "lucide-react";
import { teams, people, onCallShifts } from "@/lib/data";
import { toast } from "sonner";

interface Rotation {
  id: string;
  name: string;
  teamId: string;
  schedule: "weekly" | "daily" | "biweekly";
  participantIds: string[];
  nextRotationAt: string;
  handoffDay: string;
}

const initialRotations: Rotation[] = [
  { id: "rot1", name: "Platform Primary", teamId: "t1", schedule: "weekly", participantIds: ["u2", "u8", "u10", "u15"], nextRotationAt: "2026-07-09T08:00:00Z", handoffDay: "Monday" },
  { id: "rot2", name: "Reliability Primary", teamId: "t2", schedule: "weekly", participantIds: ["u3", "u4", "u5", "u9", "u11"], nextRotationAt: "2026-07-09T08:00:00Z", handoffDay: "Monday" },
  { id: "rot3", name: "Payments Primary", teamId: "t3", schedule: "weekly", participantIds: ["u6", "u7", "u13"], nextRotationAt: "2026-07-09T08:00:00Z", handoffDay: "Tuesday" },
  { id: "rot4", name: "Security On-Call", teamId: "t5", schedule: "biweekly", participantIds: ["u12", "u14"], nextRotationAt: "2026-07-16T00:00:00Z", handoffDay: "Sunday" },
  { id: "rot5", name: "Web On-Call", teamId: "t4", schedule: "daily", participantIds: ["u16"], nextRotationAt: "2026-07-03T00:00:00Z", handoffDay: "Daily" },
];

export default function RotationsPage() {
  const [rotations, setRotations] = React.useState(initialRotations);
  const [dragId, setDragId] = React.useState<string | null>(null);
  const [addOpen, setAddOpen] = React.useState<string | null>(null);
  const [newPerson, setNewPerson] = React.useState("");

  function moveParticipant(rotId: string, fromIdx: number, toIdx: number) {
    setRotations((rs) => rs.map((r) => {
      if (r.id !== rotId) return r;
      const next = [...r.participantIds];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      return { ...r, participantIds: next };
    }));
    toast.success("Participant order updated", { description: "Next rotation will use the new order." });
  }

  function addParticipant(rotId: string) {
    const personToAdd = people.find((p) => p.id === newPerson);
    if (!personToAdd) {
      toast.error("Select a valid person to add");
      return;
    }
    setRotations((rs) => rs.map((r) => {
      if (r.id !== rotId) return r;
      if (r.participantIds.includes(newPerson)) return r;
      return { ...r, participantIds: [...r.participantIds, newPerson] };
    }));
    toast.success(`${personToAdd.name} added to rotation`);
    setAddOpen(null);
    setNewPerson("");
  }

  function removeParticipant(rotId: string, personId: string) {
    setRotations((rs) => rs.map((r) => {
      if (r.id !== rotId) return r;
      return { ...r, participantIds: r.participantIds.filter((p) => p !== personId) };
    }));
    toast.success("Participant removed");
  }

  function onDragStart(rotId: string, idx: number) {
    setDragId(`${rotId}:${idx}`);
  }
  function onDrop(rotId: string, idx: number) {
    if (!dragId) return;
    const [srcRotId, srcIdxStr] = dragId.split(":");
    if (srcRotId !== rotId) {
      toast.error("Cannot drag across rotations");
      setDragId(null);
      return;
    }
    moveParticipant(rotId, parseInt(srcIdxStr, 10), idx);
    setDragId(null);
  }

  const totalParticipants = rotations.reduce((s, r) => s + r.participantIds.length, 0);

  return (
    <PageContainer>
      <PageHeader
        title="Rotation Details"
        description="Manage per-team rotations. Reorder participants, add engineers, and review upcoming handoff dates."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call", href: "/oncall" }, { label: "Rotations" }]}
        icon={<Repeat className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={() => toast.success("Opening new rotation form")}>
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden md:inline">New Rotation</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Active Rotations" value={rotations.length} hint="across all teams" icon={<Repeat className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Participants" value={totalParticipants} hint="engineers in rotation" icon={<UserPlus className="w-4 h-4" />} accent="info" />
        <KpiCard label="Weekly Rotations" value={rotations.filter(r => r.schedule === "weekly").length} hint="most common cadence" icon={<Calendar className="w-4 h-4" />} accent="success" />
        <KpiCard label="Next Handoff" value={rotations.sort((a,b) => new Date(a.nextRotationAt).getTime() - new Date(b.nextRotationAt).getTime())[0] ? new Date(rotations[0].nextRotationAt).toLocaleDateString([], { month: "short", day: "numeric" }) : "—"} hint="soonest rotation" icon={<RefreshCw className="w-4 h-4" />} accent="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {rotations.map((r) => {
          const team = teams.find((t) => t.id === r.teamId);
          const nextDate = new Date(r.nextRotationAt);
          const daysUntil = Math.ceil((nextDate.getTime() - Date.now()) / (24 * 3600 * 1000));
          const nextUp = people.find((p) => p.id === r.participantIds[0]);
          return (
            <Card key={r.id} className="p-5 space-y-4">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-semibold">{r.name}</h3>
                    {team && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded font-medium" style={{ background: `${team.color}15`, color: team.color }}>
                        {team.name}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="capitalize">{r.schedule} rotation</span>
                    <span>Handoff: {r.handoffDay}</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Next rotation</p>
                  <p className="text-sm font-mono font-medium">{nextDate.toLocaleDateString([], { month: "short", day: "numeric" })}</p>
                  <p className="text-[10px] text-muted-foreground">{daysUntil > 0 ? `in ${daysUntil} days` : "today"}</p>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Participant Order</span>
                  <Button variant="ghost" size="sm" className="h-6 text-[10px] gap-1" onClick={() => setAddOpen(r.id)}>
                    <Plus className="w-3 h-3" /> Add
                  </Button>
                </div>
                {r.participantIds.map((pid, idx) => {
                  const u = people.find((p) => p.id === pid);
                  if (!u) return null;
                  return (
                    <div
                      key={pid}
                      draggable
                      onDragStart={() => onDragStart(r.id, idx)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => onDrop(r.id, idx)}
                      className="flex items-center gap-2 rounded-lg border border-border bg-card p-2 cursor-grab active:cursor-grabbing hover:border-primary/40 transition-colors"
                    >
                      <GripVertical className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                      <span className="text-[10px] font-mono text-muted-foreground w-5 text-center">{idx + 1}</span>
                      <Avatar className="w-7 h-7">
                        <AvatarImage src={u.avatarUrl} alt={u.name} />
                        <AvatarFallback className="text-[10px]">{u.name.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium truncate">{u.name}</p>
                        <p className="text-[10px] text-muted-foreground truncate">{u.title}</p>
                      </div>
                      {idx === 0 && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-primary/15 text-primary border border-primary/30 font-medium uppercase">Next Up</span>
                      )}
                      <div className="flex items-center gap-0.5">
                        <Button size="icon" variant="ghost" className="h-6 w-6" disabled={idx === 0} onClick={() => moveParticipant(r.id, idx, idx - 1)} aria-label="Move up">
                          <ChevronUp className="w-3 h-3" />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-6 w-6" disabled={idx === r.participantIds.length - 1} onClick={() => moveParticipant(r.id, idx, idx + 1)} aria-label="Move down">
                          <ChevronDown className="w-3 h-3" />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-6 w-6 text-destructive" onClick={() => removeParticipant(r.id, pid)} aria-label="Remove">
                          <ArrowRight className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
                {r.participantIds.length === 0 && (
                  <div className="text-center py-4 text-xs text-muted-foreground border border-dashed border-border rounded-lg">
                    No participants. Add one to start the rotation.
                  </div>
                )}
              </div>

              {nextUp && (
                <div className="pt-3 border-t border-border flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Next on-call: <span className="font-medium text-foreground">{nextUp.name}</span></span>
                  <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => toast.success("Rotation skipped forward", { description: `${nextUp.name} is now on-call` })}>
                    <RefreshCw className="w-3 h-3" /> Skip to Next
                  </Button>
                </div>
              )}
            </Card>
          );
        })}
      </div>

      <Dialog open={!!addOpen} onOpenChange={(o) => !o && setAddOpen(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add Participant</DialogTitle>
            <DialogDescription>Select an engineer to add to this rotation.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Input placeholder="Search engineers..." />
            <div className="max-h-72 overflow-y-auto space-y-1 -mx-1 px-1">
              {people.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setNewPerson(p.id)}
                  className={`w-full flex items-center gap-3 rounded-lg border p-2 text-left hover:bg-muted/40 transition-colors ${newPerson === p.id ? "border-primary bg-primary/5" : "border-border"}`}
                >
                  <Avatar className="w-7 h-7">
                    <AvatarImage src={p.avatarUrl} alt={p.name} />
                    <AvatarFallback className="text-[10px]">{p.name.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium truncate">{p.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{p.team} · {p.role}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(null)}>Cancel</Button>
            <Button onClick={() => addOpen && addParticipant(addOpen)}>Add to Rotation</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
