"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  UserCog, Phone, MessageSquare, Mail, Bell, Moon, Globe, Clock, Save,
  Volume2, Zap, UserCheck,
} from "lucide-react";
import { people } from "@/lib/data";
import { toast } from "sonner";

export default function PreferencesPage() {
  const currentUser = people[1]; // Daniel Vargas
  const [prefs, setPrefs] = React.useState({
    phone: true,
    sms: true,
    email: true,
    push: true,
    phoneCritical: true,
    phoneHigh: true,
    phoneMedium: false,
    phoneLow: false,
    quietStart: "22:00",
    quietEnd: "07:00",
    timezone: currentUser.timezone,
    backupId: "u3",
    volume: "high",
    autoAck: false,
    mobileNumber: "+1 (415) 555-0142",
  });

  function set<K extends keyof typeof prefs>(key: K, value: (typeof prefs)[K]) {
    setPrefs((p) => ({ ...p, [key]: value }));
  }

  function save() {
    toast.success("Preferences saved", {
      description: "Notification settings will apply on the next page.",
    });
  }

  const notificationChannels = [
    { key: "phone" as const, label: "Phone Call", icon: <Phone className="w-4 h-4" />, hint: "Voice call for critical pages" },
    { key: "sms" as const, label: "SMS", icon: <MessageSquare className="w-4 h-4" />, hint: "Text message to mobile" },
    { key: "email" as const, label: "Email", icon: <Mail className="w-4 h-4" />, hint: "Email digest and alerts" },
    { key: "push" as const, label: "Push Notification", icon: <Bell className="w-4 h-4" />, hint: "Mobile app push" },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Personal On-Call Preferences"
        description="Tune your notification methods, quiet hours, and paging behavior. These apply only to your account."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call", href: "/oncall" }, { label: "Preferences" }]}
        icon={<UserCog className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={save}>
            <Save className="w-3.5 h-3.5" /> <span className="hidden md:inline">Save</span>
          </Button>
        }
      />

      {/* User identity card */}
      <Card className="p-5">
        <div className="flex items-start gap-4 flex-wrap">
          <Avatar className="w-16 h-16 ring-2 ring-primary/40">
            <AvatarImage src={currentUser.avatarUrl} alt={currentUser.name} />
            <AvatarFallback>{currentUser.name.split(" ").map(s => s[0]).join("").slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <h3 className="text-base font-semibold">{currentUser.name}</h3>
            <p className="text-sm text-muted-foreground">{currentUser.title}</p>
            <div className="flex items-center gap-3 mt-2 flex-wrap text-xs">
              <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                <Mail className="w-3 h-3" /> {currentUser.email}
              </span>
              <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                <Globe className="w-3 h-3" /> {currentUser.timezone}
              </span>
              <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                <Phone className="w-3 h-3" /> {prefs.mobileNumber}
              </span>
            </div>
          </div>
          <span className="inline-flex items-center gap-1.5 text-[10px] px-2 py-1 rounded-md bg-success/15 text-success border border-success/30 font-medium uppercase tracking-wider">
            <span className="w-1.5 h-1.5 rounded-full bg-success animate-status-pulse" />
            On-call Active
          </span>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Notification methods */}
        <Card className="lg:col-span-2 p-5 space-y-4">
          <SectionHeading title="Notification Methods" description="Choose how pages are delivered to you" action={<Volume2 className="w-4 h-4 text-muted-foreground" />} />
          <div className="space-y-2">
            {notificationChannels.map((c) => (
              <div key={c.key} className="flex items-center justify-between rounded-lg border border-border p-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    {c.icon}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{c.label}</p>
                    <p className="text-[11px] text-muted-foreground">{c.hint}</p>
                  </div>
                </div>
                <Switch
                  checked={prefs[c.key]}
                  onCheckedChange={(v) => set(c.key, v)}
                  aria-label={`Toggle ${c.label}`}
                />
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-border space-y-3">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Phone call severity thresholds</p>
            <p className="text-[11px] text-muted-foreground -mt-2">Only call your phone when alerts are at or above the selected severities.</p>
            {(["critical", "high", "medium", "low"] as const).map((sev) => {
              const key = `phone${sev.charAt(0).toUpperCase() + sev.slice(1)}` as "phoneCritical" | "phoneHigh" | "phoneMedium" | "phoneLow";
              return (
                <div key={sev} className="flex items-center justify-between">
                  <span className={`text-xs capitalize font-medium px-2 py-0.5 rounded border ${
                    sev === "critical" ? "bg-destructive/15 text-destructive border-destructive/30" :
                    sev === "high" ? "bg-warning/15 text-warning-foreground border-warning/30" :
                    sev === "medium" ? "bg-info/15 text-info-foreground border-info/30" :
                    "bg-muted text-muted-foreground border-border"
                  }`}>{sev}</span>
                  <Switch checked={prefs[key]} onCheckedChange={(v) => set(key, v)} aria-label={`Phone for ${sev}`} />
                </div>
              );
            })}
          </div>
        </Card>

        {/* Side: quiet hours, timezone, backup */}
        <div className="space-y-4">
          <Card className="p-5 space-y-4">
            <SectionHeading title="Quiet Hours" description="Suppress non-critical notifications" action={<Moon className="w-4 h-4 text-muted-foreground" />} />
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1.5">
                  <Label htmlFor="qs" className="text-[11px]">Start</Label>
                  <Input id="qs" type="time" value={prefs.quietStart} onChange={(e) => set("quietStart", e.target.value)} className="h-9 text-xs" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="qe" className="text-[11px]">End</Label>
                  <Input id="qe" type="time" value={prefs.quietEnd} onChange={(e) => set("quietEnd", e.target.value)} className="h-9 text-xs" />
                </div>
              </div>
              <div className="flex items-start gap-2 p-2 rounded-md bg-warning/5 border border-warning/20">
                <Clock className="w-3.5 h-3.5 text-warning mt-0.5 shrink-0" />
                <p className="text-[11px] text-muted-foreground">Critical alerts will still page you during quiet hours. Medium and low alerts will be queued.</p>
              </div>
            </div>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Timezone" description="Used for shift scheduling" action={<Globe className="w-4 h-4 text-muted-foreground" />} />
            <Select value={prefs.timezone} onValueChange={(v) => set("timezone", v)}>
              <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {["America/Los_Angeles", "America/New_York", "America/Chicago", "America/Denver", "America/Mexico_City", "Europe/Paris", "Europe/Berlin", "Europe/Rome", "Europe/Moscow", "Asia/Kolkata", "Asia/Tokyo", "Asia/Shanghai", "Asia/Singapore"].map((tz) => (
                  <SelectItem key={tz} value={tz}>{tz.replace(/_/g, " ")}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Card>

          <Card className="p-5 space-y-3">
            <SectionHeading title="Backup Contact" description="Paged if you don't ack" action={<UserCheck className="w-4 h-4 text-muted-foreground" />} />
            <Select value={prefs.backupId} onValueChange={(v) => set("backupId", v)}>
              <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {people.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    <span className="flex items-center gap-2">
                      <span>{p.name}</span>
                      <span className="text-[10px] text-muted-foreground">— {p.team}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">
              If you don't acknowledge within 5 minutes, the system will page your backup.
            </p>
          </Card>
        </div>
      </div>

      {/* Advanced */}
      <Card className="p-5 space-y-4">
        <SectionHeading title="Advanced" description="Less common preferences" action={<Zap className="w-4 h-4 text-muted-foreground" />} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <p className="text-sm font-medium">Auto-acknowledge low severity</p>
              <p className="text-[11px] text-muted-foreground">Automatically ack low-severity alerts after 30 seconds</p>
            </div>
            <Switch checked={prefs.autoAck} onCheckedChange={(v) => set("autoAck", v)} aria-label="Auto-ack" />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <p className="text-sm font-medium">Notification volume</p>
              <p className="text-[11px] text-muted-foreground">Phone and push volume level</p>
            </div>
            <Select value={prefs.volume} onValueChange={(v) => set("volume", v)}>
              <SelectTrigger className="h-9 w-28 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <div className="flex justify-end">
        <Button size="sm" className="gap-1.5" onClick={save}>
          <Save className="w-3.5 h-3.5" /> Save Preferences
        </Button>
      </div>
    </PageContainer>
  );
}
