"use client";

import * as React from "react";
import { PageContainer, PageHeader, SectionHeading } from "@/components/common/page-header";
import { KpiCard } from "@/components/common/kpi-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { DataTable, type Column } from "@/components/tables/data-table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Shield, Plus, Pencil, Bell, Filter, ArrowRight, Zap, Clock,
} from "lucide-react";
import { SeverityBadge } from "@/components/common/badges";
import { services, escalationPolicies } from "@/lib/data";
import { toast } from "sonner";
import type { Severity } from "@/lib/types";

interface PagingRule {
  id: string;
  name: string;
  condition: string;
  severity: Severity;
  targetId: string;
  targetType: "policy" | "person" | "channel";
  enabled: boolean;
  triggered7d: number;
}

const initialRules: PagingRule[] = [
  { id: "pr1", name: "Critical production outage", condition: "severity = critical AND environment = production", severity: "critical", targetId: "ep1", targetType: "policy", enabled: true, triggered7d: 2 },
  { id: "pr2", name: "Tier-1 service degraded", condition: "tier = 1 AND health = degraded", severity: "high", targetId: "ep2", targetType: "policy", enabled: true, triggered7d: 4 },
  { id: "pr3", name: "Checkout 5xx spike", condition: "service = checkout-api AND metric = http_5xx_rate AND value > 1", severity: "high", targetId: "ep1", targetType: "policy", enabled: true, triggered7d: 3 },
  { id: "pr4", name: "PostgreSQL replication lag", condition: "service = postgres-primary AND metric = repl_lag AND value > 5", severity: "high", targetId: "ep2", targetType: "policy", enabled: true, triggered7d: 0 },
  { id: "pr5", name: "Disk pressure warning", condition: "metric = disk_usage AND value > 85", severity: "low", targetId: "u15", targetType: "person", enabled: true, triggered7d: 4 },
  { id: "pr6", name: "Kafka consumer lag spike", condition: "service = kafka-bus AND metric = consumer_lag AND value > 50000", severity: "medium", targetId: "ep1", targetType: "policy", enabled: false, triggered7d: 1 },
  { id: "pr7", name: "Security incident - vault", condition: "service = vault AND category = security", severity: "critical", targetId: "ep3", targetType: "policy", enabled: true, triggered7d: 0 },
  { id: "pr8", name: "After-hours billing queue", condition: "service = billing-service AND queue_depth > 10000 AND hour NOT IN (9-17)", severity: "medium", targetId: "u15", targetType: "person", enabled: true, triggered7d: 1 },
];

export default function PagingRulesPage() {
  const [rules, setRules] = React.useState(initialRules);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [form, setForm] = React.useState({ name: "", condition: "", severity: "medium" as Severity, targetId: "ep1", targetType: "policy" as PagingRule["targetType"] });

  function toggle(id: string) {
    setRules((rs) => rs.map((r) => r.id === id ? { ...r, enabled: !r.enabled } : r));
    const r = rules.find((x) => x.id === id);
    toast.success(`${r?.name} ${r?.enabled ? "disabled" : "enabled"}`);
  }

  function openCreate() {
    setEditingId(null);
    setForm({ name: "", condition: "", severity: "medium", targetId: "ep1", targetType: "policy" });
    setDialogOpen(true);
  }
  function openEdit(id: string) {
    const r = rules.find((x) => x.id === id);
    if (!r) return;
    setEditingId(id);
    setForm({ name: r.name, condition: r.condition, severity: r.severity, targetId: r.targetId, targetType: r.targetType });
    setDialogOpen(true);
  }
  function save() {
    if (!form.name.trim()) {
      toast.error("Rule name is required");
      return;
    }
    if (editingId) {
      setRules((rs) => rs.map((r) => r.id === editingId ? { ...r, ...form } : r));
      toast.success("Paging rule updated");
    } else {
      setRules((rs) => [...rs, { id: `pr${rs.length + 1}`, enabled: true, triggered7d: 0, ...form }]);
      toast.success("Paging rule created");
    }
    setDialogOpen(false);
  }

  function targetLabel(r: PagingRule) {
    if (r.targetType === "policy") {
      const p = escalationPolicies.find((e) => e.id === r.targetId);
      return p?.name ?? r.targetId;
    }
    return r.targetId;
  }

  const enabledCount = rules.filter((r) => r.enabled).length;
  const totalTriggers = rules.reduce((s, r) => s + r.triggered7d, 0);
  const criticalRules = rules.filter((r) => r.severity === "critical").length;

  const cols: Column<PagingRule>[] = [
    {
      key: "name",
      header: "Rule",
      sortable: true,
      sortValue: (r) => r.name,
      cell: (r) => (
        <div className="min-w-0 max-w-xs">
          <p className="text-xs font-medium truncate">{r.name}</p>
          <p className="text-[10px] text-muted-foreground truncate font-mono">{r.condition}</p>
        </div>
      ),
    },
    {
      key: "severity",
      header: "Severity",
      filterable: true,
      filterOptions: [
        { label: "Critical", value: "critical" },
        { label: "High", value: "high" },
        { label: "Medium", value: "medium" },
        { label: "Low", value: "low" },
      ],
      filterFn: (r, v) => r.severity === v,
      hideOnMobile: true,
      cell: (r) => <SeverityBadge severity={r.severity} size="sm" />,
    },
    {
      key: "target",
      header: "Routes To",
      hideOnMobile: true,
      cell: (r) => (
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-[9px] uppercase tracking-wider text-muted-foreground">{r.targetType}</span>
          <span className="font-mono text-[11px]">{targetLabel(r)}</span>
        </div>
      ),
    },
    {
      key: "triggered7d",
      header: "Triggered (7d)",
      align: "right",
      sortable: true,
      sortValue: (r) => r.triggered7d,
      cell: (r) => <span className={`text-xs tabular-nums font-mono ${r.triggered7d > 0 ? "text-warning-foreground" : "text-muted-foreground"}`}>{r.triggered7d}</span>,
    },
    {
      key: "enabled",
      header: "Enabled",
      align: "center",
      cell: (r) => <Switch checked={r.enabled} onCheckedChange={() => toggle(r.id)} aria-label={`Toggle ${r.name}`} />,
    },
    {
      key: "edit",
      header: "",
      align: "right",
      cell: (r) => (
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); openEdit(r.id); }}>
          <Pencil className="w-3 h-3" />
        </Button>
      ),
    },
  ];

  return (
    <PageContainer>
      <PageHeader
        title="Paging Rules"
        description="Decide when to page, who to page, and how. Rules evaluate alert conditions and route to escalation policies or individuals."
        breadcrumbs={[{ label: "Home", href: "/dashboard" }, { label: "On-Call", href: "/oncall" }, { label: "Paging Rules" }]}
        icon={<Shield className="w-5 h-5" />}
        actions={
          <Button size="sm" className="gap-1.5" onClick={openCreate}>
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden md:inline">New Rule</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard label="Total Rules" value={rules.length} hint={`${enabledCount} enabled`} icon={<Shield className="w-4 h-4" />} accent="primary" />
        <KpiCard label="Critical Rules" value={criticalRules} hint="page immediately" icon={<Zap className="w-4 h-4" />} accent="destructive" />
        <KpiCard label="Triggered (7d)" value={totalTriggers} hint="across all rules" icon={<Bell className="w-4 h-4" />} accent="warning" />
        <KpiCard label="Avg Per Rule" value={(totalTriggers / rules.length).toFixed(1)} hint="trigger rate" icon={<Clock className="w-4 h-4" />} accent="info" />
      </div>

      <Card className="p-4 md:p-5">
        <SectionHeading title="Paging Rules" description="Ordered top-to-bottom. First match wins." />
        <div className="mt-4">
          <DataTable
            columns={cols}
            data={rules}
            rowKey={(r) => r.id}
            searchKeys={["name", "condition"]}
            searchPlaceholder="Search paging rules..."
            pageSize={10}
            initialSort={{ key: "triggered7d", dir: "desc" }}
          />
        </div>
      </Card>

      {/* Visual flow */}
      <Card className="p-5">
        <SectionHeading title="How Paging Works" description="From trigger to notification in 4 stages" />
        <div className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-3">
          {[
            { icon: <Filter className="w-4 h-4" />, label: "1. Condition Matched", desc: "Alert rule evaluates true against current metrics" },
            { icon: <Shield className="w-4 h-4" />, label: "2. Paging Rule Applies", desc: "First matching rule determines severity and target" },
            { icon: <ArrowRight className="w-4 h-4" />, label: "3. Routed to Policy", desc: "Escalation chain begins with first-round targets" },
            { icon: <Bell className="w-4 h-4" />, label: "4. Engineer Paged", desc: "Phone, SMS, push notifications dispatched" },
          ].map((s, i) => (
            <div key={i} className="rounded-lg border border-border p-3 space-y-1">
              <div className="flex items-center gap-2 text-primary">
                {s.icon}
                <span className="text-xs font-semibold">{s.label}</span>
              </div>
              <p className="text-[11px] text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Paging Rule" : "New Paging Rule"}</DialogTitle>
            <DialogDescription>Configure when this rule fires and where it routes.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="rname">Rule Name</Label>
              <Input id="rname" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="e.g., Critical production outage" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rcond">Condition</Label>
              <Textarea id="rcond" value={form.condition} onChange={(e) => setForm((f) => ({ ...f, condition: e.target.value }))} placeholder="severity = critical AND environment = production" rows={2} className="font-mono text-xs" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Severity</Label>
                <Select value={form.severity} onValueChange={(v) => setForm((f) => ({ ...f, severity: v as Severity }))}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Target Type</Label>
                <Select value={form.targetType} onValueChange={(v) => setForm((f) => ({ ...f, targetType: v as PagingRule["targetType"] }))}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="policy">Escalation Policy</SelectItem>
                    <SelectItem value="person">Person</SelectItem>
                    <SelectItem value="channel">Channel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Target</Label>
              <Select value={form.targetId} onValueChange={(v) => setForm((f) => ({ ...f, targetId: v }))}>
                <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {escalationPolicies.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  {services.map((s) => <SelectItem key={`svc-${s.id}`} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={save}>{editingId ? "Save Changes" : "Create Rule"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
