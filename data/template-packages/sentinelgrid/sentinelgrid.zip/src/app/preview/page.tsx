"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight, Menu, X, LayoutDashboard, Siren, Activity, Server,
  Phone, Rocket, Bug, ShieldAlert, BarChart3, Users, Clock,
  Target, FileText, GitBranch, Database, Settings,
} from "lucide-react";

const navLinks = [
  { label: "Features", href: "/features" },
  { label: "Preview", href: "/preview" },
  { label: "Components", href: "/components-preview" },
  { label: "Pricing", href: "/pricing" },
  { label: "Docs", href: "/docs" },
];

interface PagePreview {
  title: string;
  description: string;
  href: string;
  category: "Dashboards" | "Incidents" | "Services" | "On-Call" | "Deployments" | "Reliability" | "Errors" | "Performance" | "Infrastructure" | "Security" | "Admin";
  icon: React.ElementType;
  accent: string;
}

const allPages: PagePreview[] = [
  // Dashboards
  { title: "Engineering Overview", description: "Real-time view of system reliability and active incidents.", href: "/dashboard", category: "Dashboards", icon: LayoutDashboard, accent: "text-primary" },
  { title: "Incident Command Center", description: "Active war rooms, responder coordination, live timeline.", href: "/dashboard/incident-command", category: "Dashboards", icon: Siren, accent: "text-destructive" },
  { title: "Reliability Dashboard", description: "SLOs, error budgets, and availability in one view.", href: "/dashboard/reliability", category: "Dashboards", icon: ShieldAlert, accent: "text-success" },
  { title: "SLO Dashboard", description: "Per-service SLO compliance with burn rate alerts.", href: "/dashboard/slo", category: "Dashboards", icon: Target, accent: "text-primary" },
  { title: "Performance", description: "Latency, throughput, and Apdex across services.", href: "/dashboard/performance", category: "Dashboards", icon: Activity, accent: "text-info-foreground" },
  { title: "Service Health", description: "Operational status of every service.", href: "/dashboard/service-health", category: "Dashboards", icon: Activity, accent: "text-success" },
  { title: "Infrastructure", description: "Hosts, containers, pods, and clusters.", href: "/dashboard/infrastructure", category: "Dashboards", icon: Server, accent: "text-muted-foreground" },
  { title: "Security Operations", description: "Vulnerabilities, compliance, and audit trails.", href: "/dashboard/security", category: "Dashboards", icon: ShieldAlert, accent: "text-destructive" },
  { title: "On-Call", description: "Current rotation, paging rules, and handoffs.", href: "/dashboard/oncall", category: "Dashboards", icon: Phone, accent: "text-warning" },
  { title: "Executive Reliability", description: "Board-ready summary of platform health.", href: "/dashboard/executive", category: "Dashboards", icon: BarChart3, accent: "text-primary" },
  // Incidents
  { title: "Incidents List", description: "Search, filter, and triage all incidents.", href: "/incidents", category: "Incidents", icon: Siren, accent: "text-destructive" },
  { title: "Active Incidents", description: "Currently open incidents requiring attention.", href: "/incidents/active", category: "Incidents", icon: Siren, accent: "text-destructive" },
  { title: "War Rooms", description: "Live chat rooms with action item tracking.", href: "/incidents/war-rooms", category: "Incidents", icon: Users, accent: "text-warning" },
  { title: "Incident Timeline", description: "Chronological view of all incident events.", href: "/incidents/timeline", category: "Incidents", icon: Clock, accent: "text-info-foreground" },
  { title: "Status Page", description: "Public-facing status with subscriber notifications.", href: "/incidents/status-page", category: "Incidents", icon: ShieldAlert, accent: "text-success" },
  // Services
  { title: "Service Catalog", description: "Browse and search all services.", href: "/services", category: "Services", icon: Server, accent: "text-primary" },
  { title: "Service Dependencies", description: "Visualize upstream and downstream dependencies.", href: "/services/dependencies", category: "Services", icon: GitBranch, accent: "text-info-foreground" },
  { title: "Runbooks", description: "Step-by-step guides for common ops tasks.", href: "/services/runbooks", category: "Services", icon: FileText, accent: "text-muted-foreground" },
  // On-Call
  { title: "Rotations", description: "Build and manage on-call rotations.", href: "/oncall/rotations", category: "On-Call", icon: Clock, accent: "text-warning" },
  { title: "Escalation Policies", description: "Conditional rules for paging the right person.", href: "/oncall/escalation", category: "On-Call", icon: ArrowRight, accent: "text-destructive" },
  { title: "Handoffs", description: "Shift handoff notes and reports.", href: "/oncall/handoffs", category: "On-Call", icon: FileText, accent: "text-info-foreground" },
  // Deployments
  { title: "Deployments", description: "Pipeline view with stage-by-stage status.", href: "/deployments", category: "Deployments", icon: Rocket, accent: "text-primary" },
  { title: "Change Requests", description: "Risk-scored changes with approval workflow.", href: "/deployments/change-requests", category: "Deployments", icon: FileText, accent: "text-warning" },
  { title: "Feature Flags", description: "Progressive rollouts and instant kill switches.", href: "/deployments/feature-flags", category: "Deployments", icon: GitBranch, accent: "text-info-foreground" },
  { title: "Rollback", description: "One-click rollback to any previous deployment.", href: "/deployments/rollback", category: "Deployments", icon: ArrowRight, accent: "text-destructive" },
  // Reliability
  { title: "SLOs", description: "Define and monitor service-level objectives.", href: "/reliability/slos", category: "Reliability", icon: Target, accent: "text-success" },
  { title: "Error Budgets", description: "Track budget remaining and projected exhaustion.", href: "/reliability/error-budgets", category: "Reliability", icon: Target, accent: "text-warning" },
  { title: "Burn Rate", description: "Multi-window burn rate with threshold alerts.", href: "/reliability/burn-rate", category: "Reliability", icon: Activity, accent: "text-destructive" },
  { title: "Uptime", description: "Service uptime with 90-day availability calendar.", href: "/reliability/uptime", category: "Reliability", icon: ShieldAlert, accent: "text-success" },
  // Errors
  { title: "Error Tracking", description: "Grouped exceptions with stack traces.", href: "/errors", category: "Errors", icon: Bug, accent: "text-destructive" },
  { title: "Error Trends", description: "Error rate over time by service.", href: "/errors/trends", category: "Errors", icon: Activity, accent: "text-warning" },
  // Performance
  { title: "Latency", description: "p50/p95/p99 percentiles by endpoint.", href: "/performance/latency", category: "Performance", icon: Activity, accent: "text-primary" },
  { title: "Throughput", description: "RPS by service and region.", href: "/performance/throughput", category: "Performance", icon: BarChart3, accent: "text-info-foreground" },
  { title: "Web Vitals", description: "LCP, FID, CLS, FCP, TTFB, INP monitoring.", href: "/performance/web-vitals", category: "Performance", icon: Activity, accent: "text-success" },
  // Infrastructure
  { title: "Hosts", description: "Server inventory with resource utilization.", href: "/infrastructure/hosts", category: "Infrastructure", icon: Server, accent: "text-muted-foreground" },
  { title: "Kubernetes", description: "Clusters, workloads, and pods at a glance.", href: "/infrastructure/kubernetes", category: "Infrastructure", icon: Server, accent: "text-info-foreground" },
  { title: "Databases", description: "Connection pools, slow queries, and index usage.", href: "/infrastructure/databases", category: "Infrastructure", icon: Database, accent: "text-primary" },
  // Security
  { title: "Vulnerabilities", description: "CVE tracking with CVSS scoring and SLAs.", href: "/security/vulnerabilities", category: "Security", icon: ShieldAlert, accent: "text-destructive" },
  { title: "Compliance", description: "SOC 2, ISO 27001, PCI DSS posture.", href: "/security/compliance", category: "Security", icon: ShieldAlert, accent: "text-success" },
  { title: "Audit Trails", description: "Tamper-evident log with integrity verification.", href: "/security/audit", category: "Security", icon: FileText, accent: "text-muted-foreground" },
  // Admin
  { title: "Team Members", description: "Manage users, roles, and access.", href: "/admin/team", category: "Admin", icon: Users, accent: "text-primary" },
  { title: "Roles & Permissions", description: "Fine-grained RBAC matrix.", href: "/admin/roles", category: "Admin", icon: ShieldAlert, accent: "text-info-foreground" },
  { title: "Integrations", description: "Marketplace of 50+ integrations.", href: "/admin/integrations", category: "Admin", icon: GitBranch, accent: "text-success" },
  { title: "Workspace Settings", description: "Branding, authentication, and notifications.", href: "/admin/settings", category: "Admin", icon: Settings, accent: "text-muted-foreground" },
];

const categories = ["All", "Dashboards", "Incidents", "Services", "On-Call", "Deployments", "Reliability", "Errors", "Performance", "Infrastructure", "Security", "Admin"];

export default function PreviewPage() {
  const [activeCategory, setActiveCategory] = React.useState("All");
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [search, setSearch] = React.useState("");

  const filtered = allPages.filter((p) => {
    const matchesCat = activeCategory === "All" || p.category === activeCategory;
    const matchesSearch = !search || p.title.toLowerCase().includes(search.toLowerCase()) || p.description.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border-subtle bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <Link href="/landing" className="flex items-center gap-2">
            <svg viewBox="0 0 32 32" className="w-7 h-7" fill="none">
              <defs>
                <linearGradient id="nav-logo-prev" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M16 2 L28 8 V18 C28 25 22 29 16 30 C10 29 4 25 4 18 V8 Z" fill="url(#nav-logo-prev)" fillOpacity="0.16" stroke="url(#nav-logo-prev)" strokeWidth="1.6" strokeLinejoin="round" />
              <circle cx="16" cy="16" r="1.8" fill="#22D3EE" />
            </svg>
            <span className="font-semibold text-lg tracking-tight">SentinelGrid</span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} className={`px-3 py-2 text-sm rounded-md transition-colors ${link.href === "/preview" ? "text-foreground bg-muted/60" : "text-muted-foreground hover:text-foreground hover:bg-muted/60"}`}>
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="hidden md:flex items-center gap-2">
            <Button asChild variant="ghost" size="sm"><Link href="/sign-in">Sign in</Link></Button>
            <Button asChild size="sm" className="gap-1.5"><Link href="/dashboard">Get Started <ArrowRight className="w-3.5 h-3.5" /></Link></Button>
          </div>
          <button className="md:hidden p-2 -mr-2 text-muted-foreground" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label="Toggle menu">
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden py-16 md:py-20 border-b border-border-subtle">
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="relative max-w-4xl mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-balance">Browse every page</h1>
          <p className="mt-4 text-lg text-muted-foreground text-pretty">
            100+ production-ready routes across 11 categories. Filter, search, and click any card to open the live page.
          </p>
          <div className="mt-6 relative max-w-md mx-auto">
            <input
              type="text"
              placeholder="Search pages..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full h-11 pl-4 pr-4 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>
      </section>

      {/* Filters + grid */}
      <section className="py-10 flex-1">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          {/* Category filters */}
          <div className="flex flex-wrap gap-2 mb-8 justify-center">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors border ${
                  activeCategory === cat
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background text-muted-foreground border-border hover:bg-muted/60 hover:text-foreground"
                }`}
              >
                {cat}
                {cat !== "All" && (
                  <span className="ml-1.5 opacity-60">
                    {allPages.filter((p) => p.category === cat).length}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map((page) => (
              <a
                key={page.href}
                href={page.href}
                target="_blank"
                rel="noopener noreferrer"
                className="block group"
              >
                <Card className="p-5 h-full hover:bg-elevated/40 hover:border-primary/30 transition-all">
                  <div className="flex items-start justify-between mb-3">
                    <div className={`w-9 h-9 rounded-lg bg-muted/60 border border-border flex items-center justify-center ${page.accent}`}>
                      <page.icon className="w-4.5 h-4.5" />
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
                  </div>
                  <h3 className="text-sm font-semibold group-hover:text-primary transition-colors">{page.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{page.description}</p>
                  <div className="mt-3 flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0">{page.category}</Badge>
                    <code className="text-[10px] text-muted-foreground font-mono truncate">{page.href}</code>
                  </div>
                </Card>
              </a>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16 text-muted-foreground">
              <p className="text-sm">No pages match your filter.</p>
              <Button variant="ghost" size="sm" className="mt-2" onClick={() => { setSearch(""); setActiveCategory("All"); }}>
                Clear filters
              </Button>
            </div>
          )}

          <div className="mt-10 text-center text-xs text-muted-foreground">
            Showing {filtered.length} of {allPages.length} pages · Click any card to open in a new tab
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border-subtle bg-muted/20 mt-auto">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">© 2024 SentinelGrid, Inc. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <Link href="/docs/license" className="hover:text-foreground transition-colors">License</Link>
            <Link href="/docs/support" className="hover:text-foreground transition-colors">Support</Link>
            <Link href="/docs/changelog" className="hover:text-foreground transition-colors">Changelog</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
