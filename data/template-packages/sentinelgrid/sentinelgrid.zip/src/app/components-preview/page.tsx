"use client";

import * as React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerTrigger } from "@/components/ui/drawer";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { KpiCard } from "@/components/common/kpi-card";
import {
  SeverityBadge, IncidentStatusBadge, ServiceHealthBadge, DeploymentStatusBadge,
  AlertStatusBadge, SLOStatusBadge, TierBadge,
} from "@/components/common/badges";
import { toast } from "sonner";
import {
  ArrowRight, Menu, X, ShieldAlert, Activity, Zap, Target, Rocket,
  Siren, Bell, Code2, Palette, Database, Table as TableIcon, BellRing,
  Filter, Plus, Search, Download, ChevronRight,
} from "lucide-react";

const navLinks = [
  { label: "Features", href: "/features" },
  { label: "Preview", href: "/preview" },
  { label: "Components", href: "/components-preview" },
  { label: "Pricing", href: "/pricing" },
  { label: "Docs", href: "/docs" },
];

function CodeSnippet({ code }: { code: string }) {
  return (
    <pre className="mt-3 p-3 rounded-md bg-muted/60 border border-border text-[11px] font-mono overflow-x-auto text-muted-foreground">
      <code>{code}</code>
    </pre>
  );
}

function Section({ title, description, children, code }: { title: string; description: string; children: React.ReactNode; code?: string }) {
  return (
    <Card className="p-6">
      <h3 className="text-base font-semibold">{title}</h3>
      <p className="text-sm text-muted-foreground mt-1">{description}</p>
      <div className="mt-4">{children}</div>
      {code && <CodeSnippet code={code} />}
    </Card>
  );
}

export default function ComponentsPreviewPage() {
  const [switchOn, setSwitchOn] = React.useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border-subtle bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <Link href="/landing" className="flex items-center gap-2">
            <svg viewBox="0 0 32 32" className="w-7 h-7" fill="none">
              <defs>
                <linearGradient id="nav-logo-comp" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#22D3EE" />
                  <stop offset="1" stopColor="#A78BFA" />
                </linearGradient>
              </defs>
              <path d="M16 2 L28 8 V18 C28 25 22 29 16 30 C10 29 4 25 4 18 V8 Z" fill="url(#nav-logo-comp)" fillOpacity="0.16" stroke="url(#nav-logo-comp)" strokeWidth="1.6" strokeLinejoin="round" />
              <circle cx="16" cy="16" r="1.8" fill="#22D3EE" />
            </svg>
            <span className="font-semibold text-lg tracking-tight">SentinelGrid</span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} className={`px-3 py-2 text-sm rounded-md transition-colors ${link.href === "/components-preview" ? "text-foreground bg-muted/60" : "text-muted-foreground hover:text-foreground hover:bg-muted/60"}`}>
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="hidden md:flex items-center gap-2">
            <Button asChild variant="ghost" size="sm"><Link href="/sign-in">Sign in</Link></Button>
            <Button asChild size="sm" className="gap-1.5"><Link href="/dashboard">Get Started <ArrowRight className="w-3.5 h-3.5" /></Link></Button>
          </div>
          <button className="md:hidden p-2 -mr-2 text-muted-foreground" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label="Toggle menu">
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden py-16 border-b border-border-subtle">
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="relative max-w-4xl mx-auto px-4 md:px-6 text-center">
          <Badge className="mb-4 bg-primary/15 text-primary border-primary/30">Live component library</Badge>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-balance">Every component, ready to use</h1>
          <p className="mt-4 text-lg text-muted-foreground text-pretty">
            KpiCards, badges, charts, DataTables, modals, drawers, and toasts — all theme-aware, all mobile-responsive.
          </p>
        </div>
      </section>

      {/* Component sections */}
      <section className="py-12 flex-1">
        <div className="max-w-5xl mx-auto px-4 md:px-6 space-y-6">
          {/* KpiCard variants */}
          <div>
            <h2 className="text-xl font-bold tracking-tight mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" /> KpiCard Variants
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Section title="Destructive" description="For incidents and outages." code={`<KpiCard label="Incidents" value={3} delta={-2} accent="destructive" icon={<ShieldAlert/>} />`}>
                <KpiCard label="Active Incidents" value={3} delta={-2} deltaLabel="vs last week" icon={<ShieldAlert className="w-4 h-4" />} accent="destructive" />
              </Section>
              <Section title="Success" description="For uptime and healthy metrics." code={`<KpiCard label="Uptime" value="99.97%" accent="success" icon={<Activity/>} />`}>
                <KpiCard label="Uptime" value="99.97" unit="%" delta={0.02} deltaLabel="30d" icon={<Activity className="w-4 h-4" />} accent="success" />
              </Section>
              <Section title="Warning" description="For metrics that need attention." code={`<KpiCard label="MTTR" value="18m" accent="warning" icon={<Zap/>} />`}>
                <KpiCard label="Avg MTTR" value="18" unit="min" delta={-5} deltaLabel="vs target" icon={<Zap className="w-4 h-4" />} accent="warning" />
              </Section>
              <Section title="Primary" description="Default for neutral KPIs." code={`<KpiCard label="SLOs" value="42/47" accent="primary" icon={<Target/>} />`}>
                <KpiCard label="SLOs Healthy" value="42/47" icon={<Target className="w-4 h-4" />} accent="primary" hint="5 at risk" />
              </Section>
            </div>
          </div>

          {/* Badges */}
          <div>
            <h2 className="text-xl font-bold tracking-tight mb-3 flex items-center gap-2">
              <Bell className="w-4 h-4 text-primary" /> Badges
            </h2>
            <Section title="All badge families" description="Typed status badges for every domain." code={`<SeverityBadge severity="critical" />\n<IncidentStatusBadge status="investigating" />`}>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-muted-foreground w-24">Severity</span>
                  <SeverityBadge severity="critical" />
                  <SeverityBadge severity="high" />
                  <SeverityBadge severity="medium" />
                  <SeverityBadge severity="low" />
                  <SeverityBadge severity="info" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-muted-foreground w-24">Incident</span>
                  <IncidentStatusBadge status="investigating" />
                  <IncidentStatusBadge status="identified" />
                  <IncidentStatusBadge status="monitoring" />
                  <IncidentStatusBadge status="resolved" />
                  <IncidentStatusBadge status="postmortem" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-muted-foreground w-24">Service</span>
                  <ServiceHealthBadge health="operational" />
                  <ServiceHealthBadge health="degraded" />
                  <ServiceHealthBadge health="partial" />
                  <ServiceHealthBadge health="major" />
                  <ServiceHealthBadge health="maintenance" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-muted-foreground w-24">Deployment</span>
                  <DeploymentStatusBadge status="in_progress" />
                  <DeploymentStatusBadge status="canary" />
                  <DeploymentStatusBadge status="succeeded" />
                  <DeploymentStatusBadge status="failed" />
                  <DeploymentStatusBadge status="rolled_back" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-muted-foreground w-24">Alert</span>
                  <AlertStatusBadge status="firing" />
                  <AlertStatusBadge status="acknowledged" />
                  <AlertStatusBadge status="resolved" />
                  <AlertStatusBadge status="suppressed" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-muted-foreground w-24">SLO</span>
                  <SLOStatusBadge status="healthy" />
                  <SLOStatusBadge status="at_risk" />
                  <SLOStatusBadge status="breached" />
                  <SLOStatusBadge status="exhausted" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs text-muted-foreground w-24">Tier</span>
                  <TierBadge tier="tier1" />
                  <TierBadge tier="tier2" />
                  <TierBadge tier="tier3" />
                </div>
              </div>
            </Section>
          </div>

          {/* Overlays: Modal, Sheet, Drawer */}
          <div>
            <h2 className="text-xl font-bold tracking-tight mb-3 flex items-center gap-2">
              <Code2 className="w-4 h-4 text-primary" /> Overlays
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Section title="Dialog / Modal" description="Centered overlay for confirmations." code={`<Dialog><DialogTrigger asChild><Button>Open</Button></DialogTrigger><DialogContent>...</DialogContent></Dialog>`}>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">Open Dialog</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Confirm deployment</DialogTitle>
                      <DialogDescription>Are you sure you want to deploy v2.14.0 to production?</DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <Button variant="outline">Cancel</Button>
                      <Button onClick={() => toast.success("Deployment queued")}>Deploy</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </Section>
              <Section title="Sheet (side panel)" description="Slides in from the side for forms." code={`<Sheet><SheetTrigger asChild><Button>Open</Button></SheetTrigger><SheetContent>...</SheetContent></Sheet>`}>
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="sm">Open Sheet</Button>
                  </SheetTrigger>
                  <SheetContent>
                    <div className="p-4 space-y-4">
                      <h3 className="text-sm font-semibold">New incident</h3>
                      <p className="text-xs text-muted-foreground">Fill in the details to declare a new incident.</p>
                      <Button className="w-full" onClick={() => toast.success("Incident created")}>Create</Button>
                    </div>
                  </SheetContent>
                </Sheet>
              </Section>
              <Section title="Drawer (bottom)" description="Mobile-friendly bottom sheet." code={`<Drawer><DrawerTrigger asChild><Button>Open</Button></DrawerTrigger><DrawerContent>...</DrawerContent></Drawer>`}>
                <Drawer>
                  <DrawerTrigger asChild>
                    <Button variant="outline" size="sm">Open Drawer</Button>
                  </DrawerTrigger>
                  <DrawerContent>
                    <DrawerHeader>
                      <DrawerTitle>Quick actions</DrawerTitle>
                    </DrawerHeader>
                    <div className="p-4 pb-8 space-y-2">
                      <Button variant="outline" className="w-full justify-start" onClick={() => toast.info("Acknowledge clicked")}><Bell className="w-4 h-4 mr-2" /> Acknowledge</Button>
                      <Button variant="outline" className="w-full justify-start" onClick={() => toast.info("Escalate clicked")}><ArrowRight className="w-4 h-4 mr-2" /> Escalate</Button>
                      <Button className="w-full justify-start" onClick={() => toast.success("Resolved")}><Target className="w-4 h-4 mr-2" /> Resolve</Button>
                    </div>
                  </DrawerContent>
                </Drawer>
              </Section>
            </div>
          </div>

          {/* Toast triggers */}
          <div>
            <h2 className="text-xl font-bold tracking-tight mb-3 flex items-center gap-2">
              <BellRing className="w-4 h-4 text-primary" /> Toast Notifications
            </h2>
            <Section title="Toast variants" description="Sonner-powered toasts for every state." code={`import { toast } from "sonner";\ntoast.success("Saved");\ntoast.error("Failed");`}>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => toast.success("Saved successfully")}>Success</Button>
                <Button size="sm" variant="outline" onClick={() => toast.error("Something went wrong")}>Error</Button>
                <Button size="sm" variant="outline" onClick={() => toast.warning("Heads up — this may take a moment")}>Warning</Button>
                <Button size="sm" variant="outline" onClick={() => toast.info("New version available")}>Info</Button>
                <Button size="sm" variant="outline" onClick={() => toast.success("Deployment queued", { description: "v2.14.0 will be live in 4 minutes" })}>With description</Button>
              </div>
            </Section>
          </div>

          {/* Form controls */}
          <div>
            <h2 className="text-xl font-bold tracking-tight mb-3 flex items-center gap-2">
              <Palette className="w-4 h-4 text-primary" /> Form Controls
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Section title="Switch" description="Toggle a boolean state." code={`<Switch checked={on} onCheckedChange={setOn} />`}>
                <div className="flex items-center gap-3">
                  <Switch id="preview-switch" checked={switchOn} onCheckedChange={setSwitchOn} />
                  <Label htmlFor="preview-switch" className="text-sm">{switchOn ? "Enabled" : "Disabled"}</Label>
                </div>
              </Section>
              <Section title="Avatar" description="User avatars with fallback initials." code={`<Avatar><AvatarImage src="..." /><AvatarFallback>MO</AvatarFallback></Avatar>`}>
                <div className="flex -space-x-2">
                  {["MO", "DV", "PR", "TL", "YW"].map((initials, i) => (
                    <Avatar key={i} className="border-2 border-background">
                      <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-[10px] font-semibold text-background">{initials}</AvatarFallback>
                    </Avatar>
                  ))}
                </div>
              </Section>
            </div>
          </div>

          {/* Mini chart preview */}
          <div>
            <h2 className="text-xl font-bold tracking-tight mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" /> Chart Preview
            </h2>
            <Section title="Sparklines & mini charts" description="Compact trends for KPI cards and inline use." code={`<KpiCard label="..." sparkline={[4,8,6,12,9,15,11]} />`}>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: "p50 latency", data: [40, 35, 42, 38, 45, 41, 36, 39], color: "from-primary/40 to-primary" },
                  { label: "p95 latency", data: [80, 95, 88, 110, 102, 95, 105, 98], color: "from-warning/40 to-warning" },
                  { label: "error rate", data: [2, 5, 3, 8, 12, 6, 4, 2], color: "from-destructive/40 to-destructive" },
                  { label: "throughput", data: [60, 70, 65, 80, 75, 85, 90, 88], color: "from-success/40 to-success" },
                ].map((c) => (
                  <Card key={c.label} className="p-3">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{c.label}</p>
                    <div className="mt-2 h-12 flex items-end gap-0.5">
                      {c.data.map((v, i) => (
                        <div key={i} className={`flex-1 rounded-sm bg-gradient-to-t ${c.color}`} style={{ height: `${(v / Math.max(...c.data)) * 100}%` }} />
                      ))}
                    </div>
                  </Card>
                ))}
              </div>
            </Section>
          </div>

          {/* Mini DataTable preview */}
          <div>
            <h2 className="text-xl font-bold tracking-tight mb-3 flex items-center gap-2">
              <TableIcon className="w-4 h-4 text-primary" /> DataTable Preview
            </h2>
            <Section title="Compact table" description="Search, sort, filter, and pagination built in." code={`<DataTable columns={columns} data={data} rowKey={r => r.id} />`}>
              <div className="rounded-md border overflow-hidden">
                <div className="flex items-center gap-2 p-2 border-b bg-muted/30">
                  <div className="relative flex-1">
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
                    <input className="w-full h-7 pl-7 pr-2 rounded-md border border-border bg-background text-xs" placeholder="Search..." />
                  </div>
                  <Button variant="ghost" size="sm" className="h-7 gap-1 text-xs"><Filter className="w-3 h-3" /> Filter</Button>
                  <Button variant="ghost" size="sm" className="h-7 gap-1 text-xs"><Download className="w-3 h-3" /> Export</Button>
                </div>
                <table className="w-full text-xs">
                  <thead className="bg-muted/20 text-[10px] uppercase tracking-wider text-muted-foreground">
                    <tr>
                      <th className="text-left px-3 py-2 font-medium">Incident</th>
                      <th className="text-left px-3 py-2 font-medium">Severity</th>
                      <th className="text-left px-3 py-2 font-medium">Status</th>
                      <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Service</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border-subtle">
                    {[
                      { id: "INC-001", title: "Payment timeouts", sev: "critical" as const, status: "investigating" as const, svc: "payments" },
                      { id: "INC-002", title: "API rate limit hit", sev: "high" as const, status: "identified" as const, svc: "api-gateway" },
                      { id: "INC-003", title: "Search slow", sev: "medium" as const, status: "monitoring" as const, svc: "search" },
                    ].map((row) => (
                      <tr key={row.id} className="hover:bg-muted/30 cursor-pointer">
                        <td className="px-3 py-2">
                          <div className="font-mono text-primary text-[10px]">{row.id}</div>
                          <div className="font-medium truncate max-w-[140px]">{row.title}</div>
                        </td>
                        <td className="px-3 py-2"><SeverityBadge severity={row.sev} size="sm" /></td>
                        <td className="px-3 py-2"><IncidentStatusBadge status={row.status} /></td>
                        <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{row.svc}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Section>
          </div>

          {/* CTA */}
          <Card className="p-8 text-center bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20">
            <h2 className="text-2xl font-bold tracking-tight">Want to see more?</h2>
            <p className="mt-2 text-sm text-muted-foreground">Explore the full dashboard or read the component docs.</p>
            <div className="mt-5 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button asChild size="lg" className="gap-2 w-full sm:w-auto">
                <Link href="/dashboard">Open Dashboard <ArrowRight className="w-4 h-4" /></Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
                <Link href="/docs/components">Read docs</Link>
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border-subtle bg-muted/20 mt-auto">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">© 2024 SentinelGrid, Inc. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <Link href="/docs/license" className="hover:text-foreground transition-colors">License</Link>
            <Link href="/docs/support" className="hover:text-foreground transition-colors">Support</Link>
            <Link href="/docs/changelog" className="hover:text-foreground transition-colors">Changelog</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
