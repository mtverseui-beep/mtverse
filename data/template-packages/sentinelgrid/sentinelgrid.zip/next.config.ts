import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // For Vercel: no output setting needed (Vercel handles it automatically)
  // For Docker/self-hosting: uncomment the line below
  // output: "standalone",

  reactStrictMode: true,

  // We have ZERO TypeScript errors, so we enforce them at build time
  typescript: {
    ignoreBuildErrors: false,
  },

  experimental: {
    optimizePackageImports: ["lucide-react", "recharts"],
  },

  images: {
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
    ],
  },
};

export default nextConfig;
