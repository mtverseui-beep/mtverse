"use client";

import { useEffect, useState, useRef } from "react";

interface Metric {
  value: number;
  suffix: string;
  prefix: string;
  decimals?: number;
  label: string;
}

function AnimatedCounter({
  end,
  suffix = "",
  prefix = "",
  decimals = 0,
}: {
  end: number;
  suffix?: string;
  prefix?: string;
  decimals?: number;
}) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          const duration = 2000;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(eased * end);

            if (progress < 1) {
              requestAnimationFrame(animate);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [end, hasAnimated]);

  const displayValue =
    decimals > 0
      ? (count).toFixed(decimals)
      : Math.floor(count).toLocaleString();

  return (
    <div ref={ref} className="text-6xl lg:text-8xl font-display tracking-tight">
      {prefix}
      {displayValue}
      {suffix}
    </div>
  );
}

const metrics: Metric[] = [
  {
    value: 98.7,
    suffix: "",
    prefix: "",
    decimals: 1,
    label: "Average performance score",
  },
  {
    value: 1.2,
    suffix: "M",
    prefix: "",
    decimals: 1,
    label: "Page views monitored today",
  },
  {
    value: 42,
    suffix: "ms",
    prefix: "",
    label: "Median input delay",
  },
  {
    value: 27,
    suffix: "%",
    prefix: "",
    label: "Faster releases after optimization",
  },
];

const supplementaryMetrics = [
  "LCP",
  "INP",
  "CLS",
  "TTFB",
  "JavaScript bundle size",
  "Route load time",
  "Hydration time",
  "Conversion impact",
];

export function MetricsSection() {
  const [time, setTime] = useState<string>("");
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    setTime(new Date().toLocaleTimeString());
    const interval = setInterval(() => setTime(new Date().toLocaleTimeString()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="metrics" ref={sectionRef} className="relative py-24 lg:py-32 border-y border-foreground/10">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-16 lg:mb-24">
          <div>
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Live metrics
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              Performance you
              <br />
              can measure.
            </h2>
          </div>
          <div className="flex items-center gap-4 font-mono text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              Performance checks running globally
            </span>
            <span className="text-foreground/30">|</span>
            <span suppressHydrationWarning>{time}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-foreground/10">
          {metrics.map((metric, index) => (
            <div
              key={metric.label}
              className={`bg-background p-8 lg:p-12 transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <AnimatedCounter
                end={metric.value}
                suffix={metric.suffix}
                prefix={metric.prefix}
                decimals={metric.decimals ?? 0}
              />
              <div className="mt-4 text-lg text-muted-foreground">{metric.label}</div>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-wrap items-center gap-3">
          <span className="text-xs font-mono text-muted-foreground uppercase tracking-widest mr-2">
            Also tracked
          </span>
          {supplementaryMetrics.map((m) => (
            <span
              key={m}
              className="px-3 py-1.5 border border-foreground/10 text-xs font-mono text-muted-foreground"
            >
              {m}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
