"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowRight, Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface Plan {
  name: string;
  description: string;
  monthly: number;
  annual: number;
  features: string[];
  cta: string;
  href: string;
  popular: boolean;
}

const plans: Plan[] = [
  {
    name: "Starter",
    description: "For side projects and small sites",
    monthly: 19,
    annual: 16,
    features: [
      "50k page views / month",
      "Core Web Vitals tracking",
      "3 projects",
      "7-day history",
      "Email reports",
      "Basic alerts",
    ],
    cta: "Start with Starter",
    href: "/sign-up?plan=starter",
    popular: false,
  },
  {
    name: "Growth",
    description: "For growing teams and SaaS products",
    monthly: 49,
    annual: 41,
    features: [
      "500k page views / month",
      "Unlimited projects",
      "Deployment tracking",
      "Performance budgets",
      "Slack alerts",
      "90-day history",
      "Team members",
      "Web Vitals reports",
    ],
    cta: "Start with Growth",
    href: "/sign-up?plan=growth",
    popular: true,
  },
  {
    name: "Scale",
    description: "For high-traffic apps and agencies",
    monthly: 149,
    annual: 124,
    features: [
      "5M page views / month",
      "Advanced segmentation",
      "Custom retention",
      "SSO",
      "Audit logs",
      "Priority support",
      "Custom alerts",
      "SLA reports",
    ],
    cta: "Start with Scale",
    href: "/sign-up?plan=scale",
    popular: false,
  },
];

export function PricingSection() {
  const [isAnnual, setIsAnnual] = useState(true);

  return (
    <section id="pricing" className="relative py-32 lg:py-40 border-t border-foreground/10">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="max-w-3xl mb-20">
          <span className="font-mono text-xs tracking-widest text-muted-foreground uppercase block mb-6">
            Pricing
          </span>
          <h2 className="font-display text-5xl md:text-6xl lg:text-7xl tracking-tight text-foreground mb-6">
            Simple, transparent
            <br />
            <span className="text-stroke">pricing</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-xl">
            Start monitoring in 2 minutes and scale as you grow. No hidden fees,
            no surprises.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-4 mb-16">
          <span
            className={cn(
              "text-sm transition-colors",
              !isAnnual ? "text-foreground" : "text-muted-foreground"
            )}
          >
            Monthly
          </span>
          <button
            type="button"
            onClick={() => setIsAnnual(!isAnnual)}
            aria-label="Toggle billing period"
            className="relative w-14 h-7 bg-foreground/10 rounded-full p-1 transition-colors hover:bg-foreground/20"
          >
            <div
              className={cn(
                "w-5 h-5 bg-foreground rounded-full transition-transform duration-300",
                isAnnual ? "translate-x-7" : "translate-x-0"
              )}
            />
          </button>
          <span
            className={cn(
              "text-sm transition-colors",
              isAnnual ? "text-foreground" : "text-muted-foreground"
            )}
          >
            Annual
          </span>
          {isAnnual && (
            <span className="ml-2 px-2 py-1 bg-foreground text-primary-foreground text-xs font-mono">
              Save 17%
            </span>
          )}
        </div>

        <div className="grid md:grid-cols-3 gap-px bg-foreground/10">
          {plans.map((plan, idx) => (
            <div
              key={plan.name}
              className={cn(
                "relative p-8 lg:p-12 bg-background",
                plan.popular && "md:-my-4 md:py-12 lg:py-16 border-2 border-foreground"
              )}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-8 px-3 py-1 bg-foreground text-primary-foreground text-xs font-mono uppercase tracking-widest">
                  Most Popular
                </span>
              )}

              <div className="mb-8">
                <span className="font-mono text-xs text-muted-foreground">
                  {String(idx + 1).padStart(2, "0")}
                </span>
                <h3 className="font-display text-3xl text-foreground mt-2">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mt-2">{plan.description}</p>
              </div>

              <div className="mb-8 pb-8 border-b border-foreground/10">
                <div className="flex items-baseline gap-2">
                  <span className="font-display text-5xl lg:text-6xl text-foreground">
                    ${isAnnual ? plan.annual : plan.monthly}
                  </span>
                  <span className="text-muted-foreground">/month</span>
                </div>
                {isAnnual && (
                  <p className="text-xs text-muted-foreground mt-2 font-mono">
                    Billed annually (${plan.annual * 12}/yr)
                  </p>
                )}
              </div>

              <ul className="space-y-4 mb-10">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check className="w-4 h-4 text-foreground mt-0.5 shrink-0" />
                    <span className="text-sm text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link
                href={plan.href}
                className={cn(
                  "w-full py-4 flex items-center justify-center gap-2 text-sm font-medium transition-all group",
                  plan.popular
                    ? "bg-foreground text-primary-foreground hover:bg-foreground/90"
                    : "border border-foreground/20 text-foreground hover:border-foreground hover:bg-foreground/5"
                )}
              >
                {plan.cta}
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          ))}
        </div>

        <p className="mt-12 text-center text-sm text-muted-foreground">
          All plans include real-user monitoring, HTTPS beacons, and GDPR-compliant
          data handling.{" "}
          <Link href="/contact" className="underline underline-offset-4 hover:text-foreground transition-colors">
            Talk to sales
          </Link>
        </p>
      </div>
    </section>
  );
}
