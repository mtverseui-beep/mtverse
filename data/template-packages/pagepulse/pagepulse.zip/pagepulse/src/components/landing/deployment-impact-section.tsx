"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowRight, RotateCcw, GitCommit } from "lucide-react";
import { cn } from "@/lib/utils";

interface MetricDelta {
  label: string;
  before: string;
  after: string;
  delta: string;
  improvement: boolean;
  unit: string;
}

const deltas: MetricDelta[] = [
  { label: "Perf score", before: "86", after: "94", delta: "+8", improvement: true, unit: "/100" },
  { label: "LCP", before: "2.30s", after: "1.70s", delta: "-600ms", improvement: true, unit: "" },
  { label: "INP", before: "180ms", after: "96ms", delta: "-84ms", improvement: true, unit: "" },
  { label: "JS size", before: "248KB", after: "184KB", delta: "-64KB", improvement: true, unit: "" },
  { label: "CLS", before: "0.08", after: "0.04", delta: "-0.04", improvement: true, unit: "" },
  { label: "Errors", before: "12", after: "3", delta: "-9", improvement: true, unit: "" },
];

const affectedRoutes = [
  { path: "/", delta: "-540ms LCP", severity: "improved" as const },
  { path: "/p/[id]", delta: "-720ms LCP", severity: "improved" as const },
  { path: "/search", delta: "-180ms LCP", severity: "improved" as const },
  { path: "/checkout", delta: "+40ms LCP", severity: "regressed" as const },
];

export function DeploymentImpactSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="deployment-impact"
      ref={sectionRef}
      className="relative py-24 lg:py-32"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16 items-end">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Deployment impact
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              Every release,
              <br />
              before and after.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-muted-foreground leading-relaxed">
              PagePulse tags every deployment with version, commit, and
              environment, then diffs Core Web Vitals, JS size, and error rate
              automatically. Regressions surface within minutes.
            </p>
          </div>
        </div>

        <div
          className={`border border-foreground/10 bg-background transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <div className="px-4 lg:px-6 py-3 border-b border-foreground/10 flex flex-wrap items-center gap-3 justify-between">
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-mono text-muted-foreground">
                Deployment diff · 4 min ago
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
              <GitCommit className="w-3 h-3" />
              <span className="text-foreground">v2.8.1</span>
              <span className="text-foreground/40">·</span>
              <span>a1b2c3d</span>
              <span className="text-foreground/40">·</span>
              <span>production</span>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-px bg-foreground/10">
            <div className="bg-background p-6 lg:p-8">
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                  Before
                </span>
                <span className="font-mono text-xs text-muted-foreground">v2.8.0</span>
              </div>
              <div className="space-y-3">
                {deltas.map((d) => (
                  <div
                    key={d.label}
                    className="flex items-center justify-between py-2 border-b border-foreground/5 last:border-b-0"
                  >
                    <span className="text-sm text-muted-foreground">{d.label}</span>
                    <span className="font-mono text-sm text-foreground">
                      {d.before}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-foreground/[0.02] p-6 lg:p-8">
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                  After
                </span>
                <span className="font-mono text-xs text-foreground">v2.8.1</span>
              </div>
              <div className="space-y-3">
                {deltas.map((d) => (
                  <div
                    key={d.label}
                    className="flex items-center justify-between py-2 border-b border-foreground/5 last:border-b-0"
                  >
                    <span className="text-sm text-foreground">{d.label}</span>
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-sm text-foreground">
                        {d.after}
                      </span>
                      <span
                        className={cn(
                          "text-xs font-mono px-1.5 py-0.5",
                          d.improvement
                            ? "bg-green-500/10 text-green-600"
                            : "bg-red-500/10 text-red-600"
                        )}
                      >
                        {d.delta}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-px bg-foreground/10 border-t border-foreground/10">
            <div className="lg:col-span-7 bg-background p-6 lg:p-8">
              <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-4 block">
                Affected routes
              </span>
              <div className="space-y-2">
                {affectedRoutes.map((r) => (
                  <div
                    key={r.path}
                    className="flex items-center justify-between py-2 border-b border-foreground/5 last:border-b-0"
                  >
                    <span className="font-mono text-sm text-foreground">{r.path}</span>
                    <span
                      className={cn(
                        "text-xs font-mono",
                        r.severity === "improved"
                          ? "text-green-600"
                          : "text-red-600"
                      )}
                    >
                      {r.delta}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-5 bg-background p-6 lg:p-8 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="w-2 h-2 rounded-full bg-green-500" />
                  <span className="text-xs font-mono uppercase tracking-widest text-green-600">
                    Recommendation
                  </span>
                </div>
                <p className="text-sm text-foreground leading-relaxed">
                  Ship it. 4 of 5 affected routes improved. /checkout regressed
                  by 40ms but remains within budget. No rollback required.
                </p>
              </div>
              <div className="mt-6 flex items-center gap-3">
                <button
                  type="button"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-foreground text-background text-xs font-mono uppercase tracking-widest hover:bg-foreground/90 transition-colors"
                >
                  Mark as shipped
                  <ArrowRight className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  className="inline-flex items-center gap-2 px-4 py-2 border border-foreground/20 text-xs font-mono uppercase tracking-widest hover:border-foreground/40 hover:bg-foreground/5 transition-colors"
                >
                  <RotateCcw className="w-3 h-3" />
                  Rollback
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
