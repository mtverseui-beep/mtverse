"use client";

import { useEffect, useState, useRef } from "react";
import {
  Cookie,
  EyeOff,
  Lock,
  ShieldCheck,
  Users,
  ScrollText,
  KeyRound,
  Globe,
  Database,
  Webhook,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface SecurityFeature {
  icon: LucideIcon;
  title: string;
  description: string;
}

const securityFeatures: SecurityFeature[] = [
  {
    icon: Cookie,
    title: "Cookie-free mode",
    description: "Collect Web Vitals without setting any cookies. No consent banner required.",
  },
  {
    icon: EyeOff,
    title: "Privacy-friendly analytics",
    description: "No session replay, no keystroke logging, no personal content capture.",
  },
  {
    icon: Lock,
    title: "Encrypted data",
    description: "AES-256 at rest, TLS 1.3 in transit. Keys rotated every 90 days.",
  },
  {
    icon: ShieldCheck,
    title: "No session content capture",
    description: "We measure timings, not page content. Your users' data stays theirs.",
  },
  {
    icon: Users,
    title: "Role-based access",
    description: "Owner, admin, developer, viewer. Granular per-project permissions.",
  },
  {
    icon: ScrollText,
    title: "Audit logs",
    description: "Every dashboard action, API call, and config change is logged and exportable.",
  },
  {
    icon: KeyRound,
    title: "SSO-ready",
    description: "SAML 2.0, OIDC, Google Workspace, and Okta on Scale plans.",
  },
  {
    icon: Globe,
    title: "GDPR-ready workflows",
    description: "EU data residency, DPA available, subject access requests handled in 72h.",
  },
  {
    icon: Database,
    title: "Data retention controls",
    description: "Choose 7, 30, 90, 365 days, or custom. Hard delete on schedule.",
  },
  {
    icon: Webhook,
    title: "Webhook signing",
    description: "Every outbound webhook is HMAC-signed and timestamped for verification.",
  },
];

const certifications = ["SOC 2", "ISO 27001", "GDPR", "CCPA", "HIPAA"];

export function SecuritySection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.05 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="security"
      ref={sectionRef}
      className="relative py-24 lg:py-32 bg-foreground/[0.02] overflow-hidden border-t border-foreground/10"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16 lg:mb-20 items-end">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Security &amp; privacy
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              Performance data,
              <br />
              without the creep.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-muted-foreground leading-relaxed">
              PagePulse measures timings, not people. No cookies, no session
              replay, no personal content. Every layer of the platform is built
              to pass your security review on the first try.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {certifications.map((c, i) => (
                <span
                  key={c}
                  className={`px-3 py-1.5 border border-foreground/10 text-xs font-mono transition-all duration-500 ${
                    isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
                  }`}
                  style={{ transitionDelay: `${i * 60}ms` }}
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-px bg-foreground/10 border border-foreground/10">
          {securityFeatures.map((feature, index) => (
            <div
              key={feature.title}
              className={`bg-background p-6 hover:bg-foreground/[0.02] transition-all duration-500 group ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 60}ms` }}
            >
              <div className="w-9 h-9 border border-foreground/10 flex items-center justify-center mb-4 group-hover:bg-foreground group-hover:text-background transition-colors duration-300">
                <feature.icon className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-medium mb-2 group-hover:translate-x-1 transition-transform duration-300">
                {feature.title}
              </h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
