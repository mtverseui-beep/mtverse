"use client";

import { useEffect, useRef, useState } from "react";
import {
  Activity,
  GitCompareArrows,
  Gauge,
  Globe2,
  Route,
  BellRing,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

type VisualKind =
  | "vitals-radar"
  | "deploy-diff"
  | "budget-gauge"
  | "rum-globe"
  | "route-heatmap"
  | "alert-stack";

interface Feature {
  number: string;
  icon: LucideIcon;
  title: string;
  description: string;
  visual: VisualKind;
}

const features: Feature[] = [
  {
    number: "01",
    icon: Activity,
    title: "Core Web Vitals Tracking",
    description:
      "Monitor LCP, INP, CLS, FCP, TTFB, and real-user performance across pages, devices, and browsers.",
    visual: "vitals-radar",
  },
  {
    number: "02",
    icon: GitCompareArrows,
    title: "Deployment Impact",
    description:
      "Compare performance before and after every release to catch slowdowns before they hurt users.",
    visual: "deploy-diff",
  },
  {
    number: "03",
    icon: Gauge,
    title: "Performance Budgets",
    description:
      "Set limits for JavaScript size, image weight, route speed, and Core Web Vitals thresholds.",
    visual: "budget-gauge",
  },
  {
    number: "04",
    icon: Globe2,
    title: "Real User Monitoring",
    description:
      "See real user experience by country, device, browser, route, and traffic source.",
    visual: "rum-globe",
  },
  {
    number: "05",
    icon: Route,
    title: "Route-Level Insights",
    description:
      "Track which pages, layouts, and dynamic routes are slowing down your app.",
    visual: "route-heatmap",
  },
  {
    number: "06",
    icon: BellRing,
    title: "Frontend Alerts",
    description:
      "Get notified when performance drops, budgets fail, or Core Web Vitals regress.",
    visual: "alert-stack",
  },
];

function VitalsRadarVisual() {
  return (
    <svg viewBox="0 0 200 140" className="w-full h-full" aria-hidden="true">
      {[40, 28, 16].map((r, i) => (
        <circle
          key={i}
          cx="100"
          cy="70"
          r={r}
          fill="none"
          stroke="currentColor"
          strokeWidth="0.8"
          opacity="0.15"
        />
      ))}
      <line x1="60" y1="70" x2="140" y2="70" stroke="currentColor" strokeWidth="0.5" opacity="0.15" />
      <line x1="100" y1="30" x2="100" y2="110" stroke="currentColor" strokeWidth="0.5" opacity="0.15" />
      <polygon
        points="100,40 132,62 124,98 76,98 68,62"
        fill="currentColor"
        opacity="0.15"
      />
      <polygon
        points="100,40 132,62 124,98 76,98 68,62"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
      />
      {[
        [100, 40],
        [132, 62],
        [124, 98],
        [76, 98],
        [68, 62],
      ].map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={y} r="3" fill="currentColor">
            <animate
              attributeName="r"
              values="3;5;3"
              dur="2s"
              begin={`${i * 0.3}s`}
              repeatCount="indefinite"
            />
          </circle>
          <text
            x={x}
            y={y - 8}
            textAnchor="middle"
            fontSize="7"
            fontFamily="monospace"
            fill="currentColor"
            opacity="0.6"
          >
            {["LCP", "INP", "CLS", "TTFB", "FCP"][i]}
          </text>
        </g>
      ))}
    </svg>
  );
}

function DeployDiffVisual() {
  return (
    <svg viewBox="0 0 200 140" className="w-full h-full" aria-hidden="true">
      <g>
        <rect x="14" y="32" width="68" height="76" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.4" />
        <text x="48" y="48" textAnchor="middle" fontSize="8" fontFamily="monospace" fill="currentColor" opacity="0.6">v2.4.0</text>
        <text x="48" y="72" textAnchor="middle" fontSize="20" fontFamily="serif" fill="currentColor">86</text>
        <text x="48" y="92" textAnchor="middle" fontSize="6" fontFamily="monospace" fill="currentColor" opacity="0.5">2.1s LCP</text>
      </g>
      <g>
        <rect x="118" y="32" width="68" height="76" fill="currentColor" opacity="0.06" stroke="currentColor" strokeWidth="1" />
        <text x="152" y="48" textAnchor="middle" fontSize="8" fontFamily="monospace" fill="currentColor" opacity="0.8">v2.4.1</text>
        <text x="152" y="72" textAnchor="middle" fontSize="20" fontFamily="serif" fill="currentColor">94</text>
        <text x="152" y="92" textAnchor="middle" fontSize="6" fontFamily="monospace" fill="currentColor" opacity="0.7">1.7s LCP</text>
      </g>
      <g>
        <line x1="86" y1="70" x2="114" y2="70" stroke="currentColor" strokeWidth="1" />
        <polygon points="114,70 108,67 108,73" fill="currentColor" />
      </g>
      <text x="100" y="60" textAnchor="middle" fontSize="8" fontFamily="monospace" fill="#16a34a">+8</text>
      <text x="100" y="120" textAnchor="middle" fontSize="7" fontFamily="monospace" fill="currentColor" opacity="0.6">-400ms LCP</text>
    </svg>
  );
}

function BudgetGaugeVisual() {
  return (
    <svg viewBox="0 0 200 140" className="w-full h-full" aria-hidden="true">
      <g transform="translate(100,80)">
        <path
          d="M -50 0 A 50 50 0 0 1 50 0"
          fill="none"
          stroke="currentColor"
          strokeWidth="8"
          opacity="0.1"
        />
        <path
          d="M -50 0 A 50 50 0 0 1 38 -32"
          fill="none"
          stroke="#16a34a"
          strokeWidth="8"
          strokeLinecap="round"
        />
        <text x="0" y="-6" textAnchor="middle" fontSize="22" fontFamily="serif" fill="currentColor">142</text>
        <text x="0" y="10" textAnchor="middle" fontSize="7" fontFamily="monospace" fill="currentColor" opacity="0.6">/ 180 KB</text>
      </g>
      <text x="100" y="124" textAnchor="middle" fontSize="8" fontFamily="monospace" fill="#16a34a">UNDER BUDGET</text>
      <text x="40" y="20" fontSize="6" fontFamily="monospace" fill="currentColor" opacity="0.4">JS</text>
      <text x="160" y="20" textAnchor="end" fontSize="6" fontFamily="monospace" fill="currentColor" opacity="0.4">180KB</text>
    </svg>
  );
}

function RumGlobeVisual() {
  const points = [
    { x: 40, y: 50, label: "US", delay: "0s" },
    { x: 90, y: 40, label: "EU", delay: "0.5s" },
    { x: 140, y: 60, label: "JP", delay: "1s" },
    { x: 60, y: 90, label: "BR", delay: "1.5s" },
    { x: 110, y: 95, label: "AU", delay: "2s" },
  ];
  return (
    <svg viewBox="0 0 200 140" className="w-full h-full" aria-hidden="true">
      <ellipse cx="100" cy="70" rx="80" ry="50" fill="none" stroke="currentColor" strokeWidth="0.8" opacity="0.2" />
      <ellipse cx="100" cy="70" rx="80" ry="20" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.15" />
      <line x1="20" y1="70" x2="180" y2="70" stroke="currentColor" strokeWidth="0.5" opacity="0.15" />
      <line x1="100" y1="20" x2="100" y2="120" stroke="currentColor" strokeWidth="0.5" opacity="0.15" />
      {points.map((p, i) => (
        <g key={i}>
          <circle cx={p.x} cy={p.y} r="3" fill="currentColor" opacity="0.4">
            <animate attributeName="r" values="3;8;3" dur="2.5s" begin={p.delay} repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.4;0;0.4" dur="2.5s" begin={p.delay} repeatCount="indefinite" />
          </circle>
          <circle cx={p.x} cy={p.y} r="2.5" fill="currentColor" />
          <text x={p.x} y={p.y - 8} textAnchor="middle" fontSize="6" fontFamily="monospace" fill="currentColor" opacity="0.7">
            {p.label}
          </text>
        </g>
      ))}
    </svg>
  );
}

function RouteHeatmapVisual() {
  const routes = [
    { path: "/", cells: [0.4, 0.5, 0.6, 0.5, 0.4, 0.5, 0.4] },
    { path: "/p/[id]", cells: [0.8, 0.9, 0.85, 0.9, 0.95, 0.9, 0.85] },
    { path: "/search", cells: [0.6, 0.7, 0.65, 0.7, 0.6, 0.65, 0.6] },
    { path: "/cart", cells: [0.3, 0.4, 0.3, 0.4, 0.3, 0.4, 0.3] },
    { path: "/blog/...", cells: [0.2, 0.3, 0.2, 0.3, 0.2, 0.3, 0.2] },
  ];
  return (
    <svg viewBox="0 0 200 140" className="w-full h-full" aria-hidden="true">
      {routes.map((route, r) =>
        route.cells.map((v, c) => {
          const x = 60 + c * 18;
          const y = 16 + r * 22;
          const opacity = 0.15 + v * 0.7;
          const isHot = v > 0.75;
          return (
            <g key={`${r}-${c}`}>
              <rect
                x={x}
                y={y}
                width="14"
                height="14"
                fill={isHot ? "#dc2626" : "currentColor"}
                opacity={isHot ? opacity : opacity * 0.6}
              />
            </g>
          );
        })
      )}
      {routes.map((route, r) => (
        <text
          key={r}
          x={56}
          y={26 + r * 22}
          textAnchor="end"
          fontSize="6"
          fontFamily="monospace"
          fill="currentColor"
          opacity="0.7"
        >
          {route.path}
        </text>
      ))}
    </svg>
  );
}

function AlertStackVisual() {
  return (
    <svg viewBox="0 0 200 140" className="w-full h-full" aria-hidden="true">
      {[
        { y: 20, label: "LCP regression", color: "#dc2626", delay: "0s" },
        { y: 56, label: "Budget breached", color: "#d97706", delay: "0.4s" },
        { y: 92, label: "Slow route", color: "#dc2626", delay: "0.8s" },
      ].map((a, i) => (
        <g key={i}>
          <rect x="20" y={a.y} width="160" height="28" fill="currentColor" stroke="currentColor" strokeWidth="0.5" opacity="0.06" />
          <circle cx="32" cy={a.y + 14} r="3" fill={a.color}>
            <animate attributeName="opacity" values="1;0.4;1" dur="1.6s" begin={a.delay} repeatCount="indefinite" />
          </circle>
          <text x="44" y={a.y + 12} fontSize="7" fontFamily="monospace" fill="currentColor" opacity="0.8">
            {a.label}
          </text>
          <text x="44" y={a.y + 22} fontSize="6" fontFamily="monospace" fill="currentColor" opacity="0.5">
            v2.4.1 · /checkout
          </text>
          <text x="172" y={a.y + 17} textAnchor="end" fontSize="6" fontFamily="monospace" fill="currentColor" opacity="0.5">
            just now
          </text>
        </g>
      ))}
    </svg>
  );
}

function FeatureVisual({ kind }: { kind: VisualKind }) {
  switch (kind) {
    case "vitals-radar":
      return <VitalsRadarVisual />;
    case "deploy-diff":
      return <DeployDiffVisual />;
    case "budget-gauge":
      return <BudgetGaugeVisual />;
    case "rum-globe":
      return <RumGlobeVisual />;
    case "route-heatmap":
      return <RouteHeatmapVisual />;
    case "alert-stack":
      return <AlertStackVisual />;
  }
}

function FeatureCard({ feature, index }: { feature: Feature; index: number }) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={cn(
        "group relative bg-background border border-foreground/10 p-6 lg:p-8 transition-all duration-700 hover:border-foreground/30",
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      )}
      style={{ transitionDelay: `${index * 80}ms` }}
    >
      <div className="flex items-start justify-between mb-6">
        <div className="w-10 h-10 border border-foreground/10 flex items-center justify-center group-hover:bg-foreground group-hover:text-background transition-colors duration-300">
          <feature.icon className="w-4 h-4" />
        </div>
        <span className="font-mono text-xs text-muted-foreground">
          {feature.number}
        </span>
      </div>

      <h3 className="text-xl lg:text-2xl font-display mb-3 group-hover:translate-x-1 transition-transform duration-300">
        {feature.title}
      </h3>
      <p className="text-sm text-muted-foreground leading-relaxed mb-6">
        {feature.description}
      </p>

      <div className="aspect-[200/140] w-full text-foreground border-t border-foreground/5 pt-4">
        <FeatureVisual kind={feature.visual} />
      </div>
    </div>
  );
}

export function FeaturesSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.05 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="features"
      ref={sectionRef}
      className="relative py-24 lg:py-32"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16 lg:mb-20 items-end">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Features
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              A complete
              <br />
              performance stack.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-muted-foreground leading-relaxed">
              Six product surfaces, one SDK. PagePulse unifies Core Web Vitals,
              deployment impact, budgets, real user monitoring, route insights,
              and alerts into a single workflow your team will actually use.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-foreground/10 border border-foreground/10">
          {features.map((feature, i) => (
            <FeatureCard key={feature.number} feature={feature} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
