"use client";

import { useEffect, useRef, useState } from "react";

const trustItems = [
  { label: "Core Web Vitals", sub: "LCP · INP · CLS · FCP · TTFB" },
  { label: "Real User Monitoring", sub: "Device · Browser · Country" },
  { label: "Deployment Impact", sub: "Before / after diffing" },
  { label: "Performance Budgets", sub: "JS · LCP · INP · CLS" },
  { label: "4KB SDK", sub: "Zero dependencies" },
  { label: "17 global regions", sub: "Sub-50ms ingestion" },
];

export function TrustStrip() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={ref}
      aria-label="Platform capabilities"
      className="relative border-y border-foreground/10 py-6"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-x-6 gap-y-4">
          {trustItems.map((item, i) => (
            <div
              key={item.label}
              className={`flex flex-col transition-all duration-500 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
              }`}
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <span className="text-xs lg:text-sm font-medium text-foreground">
                {item.label}
              </span>
              <span className="text-[10px] lg:text-xs font-mono text-muted-foreground mt-0.5">
                {item.sub}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
