"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

type VitalStatus = "good" | "needs-improvement" | "poor";

interface Vital {
  key: string;
  label: string;
  fullLabel: string;
  value: string;
  numericValue: number;
  threshold: { good: number; poor: number };
  unit: string;
  status: VitalStatus;
  trend: number;
  sparkline: number[];
  description: string;
  unitPosition: "suffix" | "prefix";
  lowerIsBetter: boolean;
}

const vitals: Vital[] = [
  {
    key: "LCP",
    label: "LCP",
    fullLabel: "Largest Contentful Paint",
    value: "1.9",
    numericValue: 1.9,
    threshold: { good: 2.5, poor: 4.0 },
    unit: "s",
    status: "good",
    trend: -8,
    sparkline: [2.4, 2.3, 2.2, 2.1, 2.0, 2.0, 1.9],
    description: "Largest above-the-fold element renders",
    unitPosition: "suffix",
    lowerIsBetter: true,
  },
  {
    key: "INP",
    label: "INP",
    fullLabel: "Interaction to Next Paint",
    value: "96",
    numericValue: 96,
    threshold: { good: 200, poor: 500 },
    unit: "ms",
    status: "good",
    trend: -42,
    sparkline: [180, 172, 164, 150, 134, 112, 96],
    description: "75th percentile interaction latency",
    unitPosition: "suffix",
    lowerIsBetter: true,
  },
  {
    key: "CLS",
    label: "CLS",
    fullLabel: "Cumulative Layout Shift",
    value: "0.04",
    numericValue: 0.04,
    threshold: { good: 0.1, poor: 0.25 },
    unit: "",
    status: "good",
    trend: 0,
    sparkline: [0.08, 0.07, 0.06, 0.06, 0.05, 0.05, 0.04],
    description: "Unexpected layout shift score",
    unitPosition: "suffix",
    lowerIsBetter: true,
  },
  {
    key: "TTFB",
    label: "TTFB",
    fullLabel: "Time to First Byte",
    value: "240",
    numericValue: 240,
    threshold: { good: 800, poor: 1800 },
    unit: "ms",
    status: "good",
    trend: -12,
    sparkline: [310, 290, 280, 270, 260, 250, 240],
    description: "Origin server response time",
    unitPosition: "suffix",
    lowerIsBetter: true,
  },
  {
    key: "FCP",
    label: "FCP",
    fullLabel: "First Contentful Paint",
    value: "1.4",
    numericValue: 1.4,
    threshold: { good: 1.8, poor: 3.0 },
    unit: "s",
    status: "good",
    trend: -6,
    sparkline: [1.7, 1.6, 1.6, 1.5, 1.5, 1.4, 1.4],
    description: "First text or image rendered",
    unitPosition: "suffix",
    lowerIsBetter: true,
  },
];

function statusColor(status: VitalStatus): string {
  switch (status) {
    case "good":
      return "text-green-600";
    case "needs-improvement":
      return "text-amber-600";
    case "poor":
      return "text-red-600";
  }
}

function statusBg(status: VitalStatus): string {
  switch (status) {
    case "good":
      return "bg-green-500";
    case "needs-improvement":
      return "bg-amber-500";
    case "poor":
      return "bg-red-500";
  }
}

function statusLabel(status: VitalStatus): string {
  switch (status) {
    case "good":
      return "Good";
    case "needs-improvement":
      return "Needs work";
    case "poor":
      return "Poor";
  }
}

function Sparkline({ data, status }: { data: number[]; status: VitalStatus }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const width = 80;
  const height = 28;
  const points = data
    .map((d, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - ((d - min) / range) * height;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  const stroke =
    status === "good"
      ? "#16a34a"
      : status === "needs-improvement"
        ? "#d97706"
        : "#dc2626";
  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className="w-20 h-7"
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <polyline
        points={points}
        fill="none"
        stroke={stroke}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function TrendBadge({ trend, lowerIsBetter }: { trend: number; lowerIsBetter: boolean }) {
  if (trend === 0) {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-mono text-muted-foreground">
        <Minus className="w-3 h-3" />
        0%
      </span>
    );
  }
  const isImprovement = lowerIsBetter ? trend < 0 : trend > 0;
  const isPositive = trend > 0;
  const Icon = isPositive ? ArrowUpRight : ArrowDownRight;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 text-xs font-mono",
        isImprovement ? "text-green-600" : "text-red-600"
      )}
    >
      <Icon className="w-3 h-3" />
      {Math.abs(trend)}%
    </span>
  );
}

function VitalCard({ vital, index }: { vital: Vital; index: number }) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.2 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const progressPct =
    (vital.numericValue / vital.threshold.poor) * 100;

  return (
    <div
      ref={ref}
      className={`bg-background p-6 transition-all duration-700 ${
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      }`}
      style={{ transitionDelay: `${index * 80}ms` }}
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-medium text-foreground">
              {vital.label}
            </span>
            <span
              className={cn(
                "w-1.5 h-1.5 rounded-full",
                statusBg(vital.status)
              )}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-1">{vital.fullLabel}</p>
        </div>
        <Sparkline data={vital.sparkline} status={vital.status} />
      </div>

      <div className="flex items-baseline gap-1 mb-1">
        <span className="text-3xl lg:text-4xl font-display tracking-tight">
          {vital.value}
        </span>
        {vital.unit && (
          <span className="text-sm font-mono text-muted-foreground">
            {vital.unit}
          </span>
        )}
      </div>

      <div className="flex items-center justify-between mb-3">
        <span
          className={cn(
            "text-xs font-mono uppercase tracking-widest",
            statusColor(vital.status)
          )}
        >
          {statusLabel(vital.status)}
        </span>
        <TrendBadge trend={vital.trend} lowerIsBetter={vital.lowerIsBetter} />
      </div>

      <div className="h-1 bg-foreground/5 overflow-hidden mb-2">
        <div
          className={cn("h-full", statusBg(vital.status))}
          style={{ width: `${Math.min(progressPct, 100)}%` }}
        />
      </div>
      <div className="flex justify-between text-[10px] font-mono text-muted-foreground">
        <span>0{vital.unit}</span>
        <span>good: {vital.threshold.good}{vital.unit}</span>
        <span>poor: {vital.threshold.poor}{vital.unit}</span>
      </div>
    </div>
  );
}

export function CoreWebVitalsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [perfScore, setPerfScore] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;
    let frame = 0;
    const target = 98;
    const duration = 1800;
    const start = performance.now();
    const animate = (now: number) => {
      const t = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      setPerfScore(Math.floor(eased * target));
      if (t < 1) {
        frame = requestAnimationFrame(animate);
      } else {
        setPerfScore(target);
      }
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [isVisible]);

  return (
    <section
      id="web-vitals"
      ref={sectionRef}
      className="relative py-24 lg:py-32 overflow-hidden"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16 lg:mb-20 items-end">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Core Web Vitals dashboard
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              Every vital,
              <br />
              measured live.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-muted-foreground leading-relaxed">
              Real-user LCP, INP, CLS, FCP, and TTFB captured on every pageview,
              sliced by device, browser, country, and route. The same dashboard
              your engineers use to debug, your SEO team uses to report.
            </p>
          </div>
        </div>

        <div
          className={`grid lg:grid-cols-12 gap-px bg-foreground/10 border border-foreground/10 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <div className="lg:col-span-3 bg-background p-8 lg:p-10 flex flex-col justify-between">
            <div>
              <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                Performance score
              </span>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-6xl lg:text-7xl font-display tracking-tight text-foreground">
                  {perfScore}
                </span>
                <span className="text-sm font-mono text-muted-foreground">/ 100</span>
              </div>
              <div className="mt-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500" />
                <span className="text-xs font-mono text-green-600 uppercase tracking-widest">
                  Passing
                </span>
              </div>
            </div>
            <div className="mt-8 pt-6 border-t border-foreground/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-muted-foreground">
                  75th percentile
                </span>
                <span className="text-xs font-mono text-foreground">last 7 days</span>
              </div>
              <div className="grid grid-cols-7 gap-1">
                {[88, 91, 89, 93, 95, 96, 98].map((v, i) => (
                  <div key={i} className="flex flex-col items-center gap-1">
                    <div className="w-full h-12 bg-foreground/5 relative">
                      <div
                        className="absolute bottom-0 left-0 right-0 bg-foreground/70"
                        style={{ height: `${v}%` }}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-muted-foreground">
                      {["M", "T", "W", "T", "F", "S", "S"][i]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-9 grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-px bg-foreground/10">
            {vitals.map((v, i) => (
              <VitalCard key={v.key} vital={v} index={i} />
            ))}
            <div className="bg-foreground/[0.02] p-6 flex flex-col justify-center">
              <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-3">
                Auto-captured
              </span>
              <ul className="space-y-2 text-xs text-muted-foreground">
                <li>· Route-level vitals</li>
                <li>· Deployment diffs</li>
                <li>· Budget breaches</li>
                <li>· Conversion impact</li>
                <li>· JS bundle weight</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
