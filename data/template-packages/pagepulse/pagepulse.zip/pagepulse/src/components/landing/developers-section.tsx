"use client";

import { useState, useEffect, useRef } from "react";
import { Copy, Check } from "lucide-react";
import { toast } from "sonner";
import Link from "next/link";

interface CodeExample {
  label: string;
  code: string;
  language: string;
}

const codeExamples: CodeExample[] = [
  {
    label: "Install",
    language: "bash",
    code: `npm install @pagepulse/web

# or
yarn add @pagepulse/web
pnpm add @pagepulse/web`,
  },
  {
    label: "Initialize",
    language: "typescript",
    code: `import { PagePulse } from '@pagepulse/web'

PagePulse.init({
  projectId: "site_123",
  trackWebVitals: true,
  trackRoutes: true,
  trackErrors: true
})`,
  },
  {
    label: "Custom metric",
    language: "typescript",
    code: `PagePulse.metric("checkout_interactive", 184)

PagePulse.metric("search_results", 248, {
  route: "/search",
  device: "mobile"
})`,
  },
  {
    label: "Deployment",
    language: "typescript",
    code: `PagePulse.deployment({
  version: "v2.8.1",
  environment: "production",
  commit: "a1b2c3d"
})`,
  },
];

interface DevFeature {
  title: string;
  description: string;
}

const features: DevFeature[] = [
  { title: "4KB browser SDK", description: "Gzipped, zero dependencies." },
  { title: "Script tag install", description: "Drop-in snippet, no build step." },
  { title: "Next.js support", description: "App Router, RSC, edge runtime." },
  { title: "React support", description: "Hooks and provider for concurrent rendering." },
  { title: "Custom metrics", description: "Track any timing or business KPI." },
  { title: "Deployment markers", description: "Tag every release for diffing." },
  { title: "Performance budgets", description: "Enforce thresholds in CI." },
  { title: "Webhooks", description: "Stream events to any HTTP endpoint." },
  { title: "TypeScript types", description: "Strict types shipped with every package." },
  { title: "Copy code button", description: "One-click snippets for every example." },
];

const codeAnimationStyles = `
  .dev-code-line {
    opacity: 0;
    transform: translateX(-8px);
    animation: devLineReveal 0.4s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  }

  @keyframes devLineReveal {
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  .dev-code-char {
    opacity: 0;
    filter: blur(8px);
    animation: devCharReveal 0.3s cubic-bezier(0.22, 1, 0.36, 1) forwards;
  }

  @keyframes devCharReveal {
    to {
      opacity: 1;
      filter: blur(0);
    }
  }
`;

export function DevelopersSection() {
  const [activeTab, setActiveTab] = useState(0);
  const [copied, setCopied] = useState(false);
  const [installCopied, setInstallCopied] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(codeExamples[activeTab].code);
      setCopied(true);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Could not copy code");
    }
  };

  const handleInstallCopy = async () => {
    try {
      await navigator.clipboard.writeText("npm install @pagepulse/web");
      setInstallCopied(true);
      toast.success("Install command copied");
      setTimeout(() => setInstallCopied(false), 2000);
    } catch {
      toast.error("Could not copy");
    }
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.05 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="developers"
      ref={sectionRef}
      className="relative py-24 lg:py-32 overflow-hidden"
    >
      <style dangerouslySetInnerHTML={{ __html: codeAnimationStyles }} />
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16 items-end">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              For developers
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              A SDK that
              <br />
              gets out of the way.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-muted-foreground leading-relaxed">
              A 4KB browser SDK with TypeScript types, framework adapters for
              Next.js and React, and a CLI that fails your build when budgets
              are breached. Ship faster pages without changing how you work.
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          <div
            className={`transition-all duration-700 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <div className="grid grid-cols-2 gap-x-6 gap-y-8">
              {features.map((feature, index) => (
                <div
                  key={feature.title}
                  className={`transition-all duration-500 ${
                    isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
                  }`}
                  style={{ transitionDelay: `${index * 50 + 200}ms` }}
                >
                  <h3 className="font-medium mb-1">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>

            <div className="mt-10">
              <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3 block">
                Quick install
              </span>
              <div className="flex items-stretch border border-foreground/10">
                <code className="flex-1 px-4 py-3 font-mono text-sm text-foreground/80 overflow-x-auto">
                  npm install @pagepulse/web
                </code>
                <button
                  type="button"
                  onClick={handleInstallCopy}
                  className="px-4 border-l border-foreground/10 text-muted-foreground hover:text-foreground hover:bg-foreground/5 transition-colors flex items-center"
                  aria-label="Copy install command"
                >
                  {installCopied ? (
                    <Check className="w-4 h-4 text-green-600" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            <div className="mt-8 flex items-center gap-6 text-sm">
              <Link
                href="/docs"
                className="text-foreground hover:underline underline-offset-4"
              >
                Read the docs
              </Link>
              <span className="text-foreground/20">|</span>
              <Link
                href="/docs/installation"
                className="text-muted-foreground hover:text-foreground"
              >
                Installation guide
              </Link>
            </div>
          </div>

          <div
            className={`lg:sticky lg:top-32 transition-all duration-700 delay-200 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
            }`}
          >
            <div className="border border-foreground/10">
              <div className="flex items-stretch border-b border-foreground/10 overflow-x-auto">
                {codeExamples.map((example, idx) => (
                  <button
                    key={example.label}
                    type="button"
                    onClick={() => setActiveTab(idx)}
                    className={`px-5 py-4 text-sm font-mono transition-colors relative whitespace-nowrap ${
                      activeTab === idx
                        ? "text-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {example.label}
                    {activeTab === idx && (
                      <span className="absolute bottom-0 left-0 right-0 h-px bg-foreground" />
                    )}
                  </button>
                ))}
                <div className="flex-1" />
                <button
                  type="button"
                  onClick={handleCopy}
                  className="px-4 py-4 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="Copy code"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-green-600" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>

              <div className="px-6 py-4 border-b border-foreground/10 flex items-center justify-between bg-foreground/[0.02]">
                <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                  {codeExamples[activeTab].language}
                </span>
                <span className="text-[10px] font-mono text-muted-foreground">
                  @{codeExamples[activeTab].label.toLowerCase().replace(/\s+/g, "-")}
                </span>
              </div>

              <div className="p-6 lg:p-8 font-mono text-sm bg-foreground/[0.01] min-h-[260px] overflow-x-auto">
                <pre className="text-foreground/80">
                  {codeExamples[activeTab].code.split("\n").map((line, lineIndex) => (
                    <div
                      key={`${activeTab}-${lineIndex}`}
                      className="leading-loose dev-code-line"
                      style={{ animationDelay: `${lineIndex * 80}ms` }}
                    >
                      <span className="inline-flex">
                        {line.split("").map((char, charIndex) => (
                          <span
                            key={`${activeTab}-${lineIndex}-${charIndex}`}
                            className="dev-code-char"
                            style={{
                              animationDelay: `${lineIndex * 80 + charIndex * 15}ms`,
                            }}
                          >
                            {char === " " ? "\u00A0" : char}
                          </span>
                        ))}
                      </span>
                    </div>
                  ))}
                </pre>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
