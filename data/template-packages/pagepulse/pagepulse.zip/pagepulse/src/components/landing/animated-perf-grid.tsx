"use client";

import { useEffect, useRef } from "react";

/**
 * AnimatedPerfGrid — a 3D isometric grid of vertical bars whose heights
 * breathe using layered sine waves. Looks like a real-time performance
 * metrics landscape. Replaces the old ASCII sphere in the hero.
 */
export function AnimatedPerfGrid() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let time = 0;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);
    };

    resize();
    window.addEventListener("resize", resize);

    // Grid configuration
    const gridSize = 9;
    const barSize = 14;
    const barGap = 6;
    const maxBarHeight = 90;

    // Isometric projection — classic 2:1 isometric
    const isoAngle = Math.PI / 6; // 30 degrees
    const cosA = Math.cos(isoAngle);
    const sinA = Math.sin(isoAngle);

    const project = (x: number, y: number, z: number) => {
      // Treat y as up. Project isometric: screenX = (x - z) * cos, screenY = (x + z) * sin - y
      const sx = (x - z) * cosA;
      const sy = (x + z) * sinA - y;
      return { x: sx, y: sy, depth: x + z };
    };

    interface Bar {
      gx: number;
      gy: number;
      phase: number;
      freq: number;
      amp: number;
      baseHeight: number;
    }

    const bars: Bar[] = [];
    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        // Distance from center for a nice radial wave
        const cx = (gridSize - 1) / 2;
        const cy = (gridSize - 1) / 2;
        const dist = Math.sqrt((i - cx) ** 2 + (j - cy) ** 2);
        bars.push({
          gx: i,
          gy: j,
          phase: dist * 0.5,
          freq: 0.6 + Math.random() * 0.3,
          amp: 0.7 + Math.random() * 0.3,
          baseHeight: 8 + Math.random() * 12,
        });
      }
    }

    const totalSize = gridSize * (barSize + barGap);
    const offset = -totalSize / 2;

    const render = () => {
      const root = document.documentElement;
      const isDark = root.classList.contains("dark");
      const fgRgb = isDark ? "245, 241, 234" : "15, 14, 12";

      const rect = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, rect.width, rect.height);

      const centerX = rect.width / 2;
      const centerY = rect.height / 2 + 40; // shift down slightly for balance

      // Compute current heights
      const heights: number[] = bars.map((bar) => {
        const wave1 = Math.sin(time * bar.freq + bar.phase) * 0.5 + 0.5;
        const wave2 = Math.sin(time * bar.freq * 0.6 + bar.phase * 1.7) * 0.3 + 0.3;
        const combined = wave1 * 0.65 + wave2 * 0.35;
        return bar.baseHeight + combined * bar.amp * maxBarHeight;
      });

      // Sort bars back-to-front (painter's algorithm) using depth = gx + gy
      const drawOrder = bars
        .map((bar, idx) => ({ bar, idx, depth: bar.gx + bar.gy }))
        .sort((a, b) => a.depth - b.depth);

      drawOrder.forEach(({ bar, idx }) => {
        const h = heights[idx];
        const baseX = bar.gx * (barSize + barGap) + offset;
        const baseZ = bar.gy * (barSize + barGap) + offset;

        // 8 corners of the box (y is up, so base is y=0, top is y=h)
        const c = [
          project(baseX, 0, baseZ), // 0 bottom front-left
          project(baseX + barSize, 0, baseZ), // 1 bottom front-right
          project(baseX + barSize, 0, baseZ + barSize), // 2 bottom back-right
          project(baseX, 0, baseZ + barSize), // 3 bottom back-left
          project(baseX, h, baseZ), // 4 top front-left
          project(baseX + barSize, h, baseZ), // 5 top front-right
          project(baseX + barSize, h, baseZ + barSize), // 6 top back-right
          project(baseX, h, baseZ + barSize), // 7 top back-left
        ].map((p) => ({ x: centerX + p.x, y: centerY + p.y }));

        // Depth-based alpha (back bars slightly fainter)
        const depthFactor = 1 - (bar.gx + bar.gy) / (2 * (gridSize - 1)) * 0.45;
        const alpha = 0.35 * depthFactor;

        // Helper to draw a polygon
        const poly = (pts: { x: number; y: number }[], fillAlpha: number) => {
          ctx.beginPath();
          ctx.moveTo(pts[0].x, pts[0].y);
          for (let k = 1; k < pts.length; k++) ctx.lineTo(pts[k].x, pts[k].y);
          ctx.closePath();
          ctx.fillStyle = `rgba(${fgRgb}, ${fillAlpha})`;
          ctx.fill();
        };

        // Top face (lightest)
        poly([c[4], c[5], c[6], c[7]], alpha * 1.0);
        // Front-right face (medium)
        poly([c[1], c[5], c[6], c[2]], alpha * 0.55);
        // Front-left face (darkest)
        poly([c[0], c[1], c[5], c[4]], alpha * 0.32);

        // Subtle outline on top edge for crispness
        ctx.strokeStyle = `rgba(${fgRgb}, ${alpha * 1.4})`;
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(c[4].x, c[4].y);
        ctx.lineTo(c[5].x, c[5].y);
        ctx.lineTo(c[6].x, c[6].y);
        ctx.lineTo(c[7].x, c[7].y);
        ctx.closePath();
        ctx.stroke();
      });

      // Subtle ground grid lines for spatial reference
      ctx.strokeStyle = `rgba(${fgRgb}, 0.06)`;
      ctx.lineWidth = 0.5;
      for (let i = 0; i <= gridSize; i++) {
        const a = project(offset + i * (barSize + barGap) - barGap / 2, 0, offset - barGap / 2);
        const b = project(offset + i * (barSize + barGap) - barGap / 2, 0, offset + totalSize - barGap / 2);
        ctx.beginPath();
        ctx.moveTo(centerX + a.x, centerY + a.y);
        ctx.lineTo(centerX + b.x, centerY + b.y);
        ctx.stroke();

        const c = project(offset - barGap / 2, 0, offset + i * (barSize + barGap) - barGap / 2);
        const d = project(offset + totalSize - barGap / 2, 0, offset + i * (barSize + barGap) - barGap / 2);
        ctx.beginPath();
        ctx.moveTo(centerX + c.x, centerY + c.y);
        ctx.lineTo(centerX + d.x, centerY + d.y);
        ctx.stroke();
      }

      time += 0.018;
      frameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(frameRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ display: "block" }}
    />
  );
}
