"use client";

import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { AnimatedWave } from "./animated-wave";
import { footerNav, socialLinks, siteConfig } from "@/lib/site-config";

export function FooterSection() {
  return (
    <footer className="relative border-t border-foreground/10">
      <div className="absolute inset-0 h-64 opacity-20 pointer-events-none overflow-hidden">
        <AnimatedWave />
      </div>

      <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="py-16 lg:py-24">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-12 lg:gap-8">
            <div className="col-span-2">
              <Link href="/" className="inline-flex items-center gap-2 mb-6" aria-label={`${siteConfig.name} home`}>
                <svg viewBox="0 0 64 64" className="w-8 h-8" aria-hidden="true">
                  <rect width="64" height="64" rx="12" fill="currentColor" />
                  <path
                    d="M8 40 L18 28 L26 36 L34 18 L46 32 L56 22"
                    fill="none"
                    stroke="var(--background)"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <circle cx="56" cy="22" r="3.5" fill="var(--background)" />
                </svg>
                <span className="text-2xl font-display">{siteConfig.name}</span>
                <span className="text-xs text-muted-foreground font-mono">TM</span>
              </Link>

              <p className="text-muted-foreground leading-relaxed mb-8 max-w-xs">
                Monitor Core Web Vitals, page speed, JavaScript performance, and
                deployment impact from one beautiful frontend monitoring platform.
              </p>

              <div className="flex gap-6">
                {socialLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 group"
                  >
                    {link.name}
                    <ArrowUpRight className="w-3 h-3 opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </a>
                ))}
              </div>
            </div>

            {Object.entries(footerNav).map(([title, links]) => (
              <div key={title}>
                <h3 className="text-sm font-medium mb-6">{title}</h3>
                <ul className="space-y-4">
                  {links.map((link) => (
                    <li key={link.name}>
                      <Link
                        href={link.href}
                        className="text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center gap-2"
                      >
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="py-8 border-t border-foreground/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            {new Date().getFullYear()} {siteConfig.copyright}. All rights reserved.
          </p>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="/status" className="flex items-center gap-2 hover:text-foreground transition-colors">
              <span className="w-2 h-2 rounded-full bg-green-500" />
              All systems operational
            </Link>
            <span className="text-foreground/20">|</span>
            <a
              href={`mailto:${siteConfig.supportEmail}`}
              className="hover:text-foreground transition-colors"
            >
              {siteConfig.supportEmail}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
