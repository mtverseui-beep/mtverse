"use client";

import { useEffect, useRef } from "react";

/**
 * AnimatedMesh — a 3D constellation of nodes connected by lines, with
 * bright pulses traveling along the edges. Represents the connected
 * nature of performance monitoring (routes, devices, browsers, releases).
 * Replaces the old ASCII tetrahedron in the CTA section.
 */
export function AnimatedMesh() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let time = 0;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);
    };

    resize();
    window.addEventListener("resize", resize);

    interface Node {
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      vz: number;
      radius: number;
    }

    const numNodes = 32;
    const nodes: Node[] = [];
    const bound = 200;

    for (let i = 0; i < numNodes; i++) {
      nodes.push({
        x: (Math.random() - 0.5) * 360,
        y: (Math.random() - 0.5) * 360,
        z: (Math.random() - 0.5) * 360,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        vz: (Math.random() - 0.5) * 0.25,
        radius: 1.6 + Math.random() * 1.4,
      });
    }

    interface Pulse {
      fromIdx: number;
      toIdx: number;
      progress: number;
      speed: number;
    }
    const pulses: Pulse[] = [];

    const rotateY = (p: { x: number; y: number; z: number }, angle: number) => ({
      x: p.x * Math.cos(angle) - p.z * Math.sin(angle),
      y: p.y,
      z: p.x * Math.sin(angle) + p.z * Math.cos(angle),
    });

    const rotateX = (p: { x: number; y: number; z: number }, angle: number) => ({
      x: p.x,
      y: p.y * Math.cos(angle) - p.z * Math.sin(angle),
      z: p.y * Math.sin(angle) + p.z * Math.cos(angle),
    });

    const render = () => {
      const root = document.documentElement;
      const isDark = root.classList.contains("dark");
      const fgRgb = isDark ? "245, 241, 234" : "15, 14, 12";

      const rect = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, rect.width, rect.height);

      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const scale = Math.min(rect.width, rect.height) * 0.55 / 360;

      // Move nodes (gentle drift)
      nodes.forEach((n) => {
        n.x += n.vx;
        n.y += n.vy;
        n.z += n.vz;
        if (n.x > bound || n.x < -bound) n.vx *= -1;
        if (n.y > bound || n.y < -bound) n.vy *= -1;
        if (n.z > bound || n.z < -bound) n.vz *= -1;
      });

      // Rotate the whole field slowly
      const rotated = nodes.map((n) => {
        let p = rotateY(n, time * 0.18);
        p = rotateX(p, time * 0.12);
        return { ...p, radius: n.radius };
      });

      // Project to 2D
      const projected = rotated.map((p) => ({
        x: centerX + p.x * scale,
        y: centerY + p.y * scale,
        z: p.z,
        radius: p.radius,
      }));

      // Compute edges (connect nearby nodes)
      const maxDist = 200;
      const edges: { from: number; to: number; dist: number }[] = [];
      for (let i = 0; i < rotated.length; i++) {
        for (let j = i + 1; j < rotated.length; j++) {
          const dx = rotated[i].x - rotated[j].x;
          const dy = rotated[i].y - rotated[j].y;
          const dz = rotated[i].z - rotated[j].z;
          const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
          if (dist < maxDist) {
            edges.push({ from: i, to: j, dist });
          }
        }
      }

      // Draw edges (sorted by average depth for nicer overlap)
      const edgesWithDepth = edges
        .map((e) => ({
          ...e,
          depth: (rotated[e.from].z + rotated[e.to].z) / 2,
        }))
        .sort((a, b) => a.depth - b.depth);

      edgesWithDepth.forEach((e) => {
        const alpha = (1 - e.dist / maxDist) * 0.28;
        const depthFactor = (e.depth + 200) / 400;
        ctx.strokeStyle = `rgba(${fgRgb}, ${alpha * (0.4 + depthFactor * 0.6)})`;
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        ctx.moveTo(projected[e.from].x, projected[e.from].y);
        ctx.lineTo(projected[e.to].x, projected[e.to].y);
        ctx.stroke();
      });

      // Spawn pulses along random edges — ensure several are always alive
      if (edges.length > 0) {
        // Force-spawn if too few pulses are active
        while (pulses.length < 4) {
          const edge = edges[Math.floor(Math.random() * edges.length)];
          pulses.push({
            fromIdx: edge.from,
            toIdx: edge.to,
            progress: Math.random() * 0.5,
            speed: 0.008 + Math.random() * 0.018,
          });
        }
        // Random additional spawns
        if (Math.random() < 0.12) {
          const edge = edges[Math.floor(Math.random() * edges.length)];
          pulses.push({
            fromIdx: edge.from,
            toIdx: edge.to,
            progress: 0,
            speed: 0.008 + Math.random() * 0.018,
          });
        }
      }

      // Draw nodes (sorted back to front)
      const nodesWithDepth = projected
        .map((p, idx) => ({ ...p, idx, depth: rotated[idx].z }))
        .sort((a, b) => a.depth - b.depth);

      nodesWithDepth.forEach((p) => {
        const depthFactor = (p.depth + 200) / 400;
        const size = p.radius * (0.6 + depthFactor * 0.9);
        const alpha = 0.3 + depthFactor * 0.6;
        // Soft halo for front nodes
        if (depthFactor > 0.6) {
          const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, size * 4);
          grad.addColorStop(0, `rgba(${fgRgb}, ${alpha * 0.25})`);
          grad.addColorStop(1, `rgba(${fgRgb}, 0)`);
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(p.x, p.y, size * 4, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.fillStyle = `rgba(${fgRgb}, ${alpha})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
        ctx.fill();
      });

      // Update and draw pulses ON TOP of nodes (bright dots traveling along edges)
      // Use a distinct green accent so pulses pop on both light and dark themes
      const pulseRgb = "22, 163, 74"; // green-600 — matches the "good" status color
      for (let i = pulses.length - 1; i >= 0; i--) {
        const p = pulses[i];
        p.progress += p.speed;
        if (p.progress >= 1) {
          pulses.splice(i, 1);
          continue;
        }
        const from = projected[p.fromIdx];
        const to = projected[p.toIdx];
        const px = from.x + (to.x - from.x) * p.progress;
        const py = from.y + (to.y - from.y) * p.progress;
        const fade = Math.sin(p.progress * Math.PI);
        // Large glow halo
        const glowRadius = 20;
        const grad = ctx.createRadialGradient(px, py, 0, px, py, glowRadius);
        grad.addColorStop(0, `rgba(${pulseRgb}, ${fade * 0.6})`);
        grad.addColorStop(0.4, `rgba(${pulseRgb}, ${fade * 0.25})`);
        grad.addColorStop(1, `rgba(${pulseRgb}, 0)`);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(px, py, glowRadius, 0, Math.PI * 2);
        ctx.fill();
        // Core dot — bright green
        ctx.fillStyle = `rgba(${pulseRgb}, ${Math.min(fade * 1.2, 1)})`;
        ctx.beginPath();
        ctx.arc(px, py, 3.5, 0, Math.PI * 2);
        ctx.fill();
        // Bright center highlight
        ctx.fillStyle = `rgba(255, 255, 255, ${fade * 0.8})`;
        ctx.beginPath();
        ctx.arc(px, py, 1.2, 0, Math.PI * 2);
        ctx.fill();
      }

      time += 0.01;
      frameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(frameRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ display: "block" }}
    />
  );
}
