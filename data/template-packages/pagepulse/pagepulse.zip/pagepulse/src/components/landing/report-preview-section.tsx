"use client";

import { useEffect, useRef, useState } from "react";
import { Download, Check, TrendingUp, TrendingDown, FileText } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface SlowRoute {
  path: string;
  lcp: string;
  score: number;
}

interface ChangedRoute {
  path: string;
  delta: string;
  direction: "up" | "down";
}

const slowRoutes: SlowRoute[] = [
  { path: "/checkout", lcp: "4.1s", score: 52 },
  { path: "/p/[id]", lcp: "3.4s", score: 64 },
  { path: "/search", lcp: "2.6s", score: 78 },
];

const improvedRoutes: ChangedRoute[] = [
  { path: "/", delta: "-540ms LCP", direction: "up" },
  { path: "/blog/[slug]", delta: "-220ms LCP", direction: "up" },
  { path: "/cart", delta: "-110ms LCP", direction: "up" },
];

const regressedRoutes: ChangedRoute[] = [
  { path: "/checkout", delta: "+40ms LCP", direction: "down" },
  { path: "/account/billing", delta: "+85ms LCP", direction: "down" },
];

const recommendations = [
  "Compress hero images on /checkout to save an estimated 380KB.",
  "Defer the analytics script on /p/[id] to cut INP by 120ms.",
  "Preload the hero font on /search to improve LCP by 180ms.",
  "Code-split the dashboard chart library on /account/billing.",
];

const distribution = [
  { range: "0-49", count: 4, color: "bg-red-500" },
  { range: "50-89", count: 11, color: "bg-amber-500" },
  { range: "90-100", count: 23, color: "bg-green-500" },
];

export function ReportPreviewSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [exported, setExported] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleExport = async () => {
    setExporting(true);
    await new Promise((r) => setTimeout(r, 900));
    setExporting(false);
    setExported(true);
    toast.success("Weekly report exported", {
      description: "pagepulse-weekly-2025-W24.pdf",
    });
    setTimeout(() => setExported(false), 3000);
  };

  return (
    <section
      id="report-preview"
      ref={sectionRef}
      className="relative py-24 lg:py-32"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16 items-end">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Weekly report
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              A report your
              <br />
              stakeholders read.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-muted-foreground leading-relaxed">
              Every Monday at 9am, PagePulse sends a PDF summary of the week:
              slow routes, improvements, regressions, distribution, and a
              prioritized list of recommendations. No setup required.
            </p>
          </div>
        </div>

        <div
          className={`border border-foreground/10 bg-background transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <div className="px-4 lg:px-6 py-3 border-b border-foreground/10 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <FileText className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs font-mono text-muted-foreground">
                Weekly performance report · Week 24, 2025
              </span>
            </div>
            <button
              type="button"
              onClick={handleExport}
              disabled={exporting}
              className="inline-flex items-center gap-2 px-3 py-1.5 border border-foreground/15 hover:border-foreground/40 hover:bg-foreground/5 transition-colors text-xs font-mono disabled:opacity-60"
            >
              {exported ? (
                <>
                  <Check className="w-3 h-3 text-green-600" />
                  Exported
                </>
              ) : exporting ? (
                <>
                  <span className="w-3 h-3 border border-foreground/30 border-t-foreground rounded-full animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Download className="w-3 h-3" />
                  Export PDF
                </>
              )}
            </button>
          </div>

          <div className="grid lg:grid-cols-12 gap-px bg-foreground/10">
            <div className="lg:col-span-5 bg-background p-6 lg:p-8">
              <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-4 block">
                Top slow routes
              </span>
              <div className="space-y-3">
                {slowRoutes.map((r) => (
                  <div
                    key={r.path}
                    className="flex items-center justify-between py-2 border-b border-foreground/5 last:border-b-0"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="font-mono text-sm text-foreground truncate">
                        {r.path}
                      </div>
                      <div className="text-[11px] font-mono text-muted-foreground mt-0.5">
                        LCP {r.lcp}
                      </div>
                    </div>
                    <span
                      className={cn(
                        "font-display text-2xl",
                        r.score >= 90
                          ? "text-green-600"
                          : r.score >= 50
                            ? "text-amber-600"
                            : "text-red-600"
                      )}
                    >
                      {r.score}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-7 bg-background p-6 lg:p-8">
              <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-4 block">
                Core Web Vitals distribution
              </span>
              <div className="space-y-3">
                {distribution.map((d) => (
                  <div key={d.range} className="flex items-center gap-4">
                    <span className="text-xs font-mono text-muted-foreground w-12 shrink-0">
                      {d.range}
                    </span>
                    <div className="flex-1 h-6 bg-foreground/5 relative overflow-hidden">
                      <div
                        className={cn("h-full transition-all duration-1000", d.color)}
                        style={{ width: `${(d.count / 38) * 100}%` }}
                      />
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] font-mono text-background">
                        {d.count}
                      </span>
                    </div>
                    <span className="text-xs font-mono text-muted-foreground w-12 shrink-0 text-right">
                      {Math.round((d.count / 38) * 100)}%
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-4 border-t border-foreground/10 grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Avg score
                  </div>
                  <div className="font-display text-3xl mt-1">87.4</div>
                </div>
                <div>
                  <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Routes monitored
                  </div>
                  <div className="font-display text-3xl mt-1">38</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 bg-background p-6 lg:p-8 border-t lg:border-t-0 lg:border-r border-foreground/10">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-3.5 h-3.5 text-green-600" />
                <span className="text-xs font-mono uppercase tracking-widest text-green-600">
                  Improved
                </span>
              </div>
              <div className="space-y-2">
                {improvedRoutes.map((r) => (
                  <div
                    key={r.path}
                    className="flex items-center justify-between py-1.5 border-b border-foreground/5 last:border-b-0"
                  >
                    <span className="font-mono text-xs text-foreground truncate">
                      {r.path}
                    </span>
                    <span className="font-mono text-xs text-green-600 shrink-0">
                      {r.delta}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-6 bg-background p-6 lg:p-8 border-t border-foreground/10">
              <div className="flex items-center gap-2 mb-4">
                <TrendingDown className="w-3.5 h-3.5 text-red-600" />
                <span className="text-xs font-mono uppercase tracking-widest text-red-600">
                  Regressed
                </span>
              </div>
              <div className="space-y-2">
                {regressedRoutes.map((r) => (
                  <div
                    key={r.path}
                    className="flex items-center justify-between py-1.5 border-b border-foreground/5 last:border-b-0"
                  >
                    <span className="font-mono text-xs text-foreground truncate">
                      {r.path}
                    </span>
                    <span className="font-mono text-xs text-red-600 shrink-0">
                      {r.delta}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-12 bg-background p-6 lg:p-8 border-t border-foreground/10">
              <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-4 block">
                Prioritized recommendations
              </span>
              <div className="grid sm:grid-cols-2 gap-4">
                {recommendations.map((rec, i) => (
                  <div
                    key={i}
                    className={`flex items-start gap-3 transition-all duration-500 ${
                      isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
                    }`}
                    style={{ transitionDelay: `${400 + i * 80}ms` }}
                  >
                    <span className="font-mono text-xs text-muted-foreground mt-0.5 shrink-0">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-sm text-foreground/80 leading-relaxed">
                      {rec}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
