"use client";

import { useEffect, useState } from "react";

interface Testimonial {
  quote: string;
  author: string;
  role: string;
  company: string;
  metric: string;
  persona: string;
}

const testimonials: Testimonial[] = [
  {
    quote:
      "We caught a 700ms LCP regression on the first deploy after install. Performance reviews now ship alongside code reviews, not after.",
    author: "Sarah Chen",
    role: "Frontend Lead",
    company: "Meridian Labs",
    metric: "10x faster regression catches",
    persona: "Frontend Lead",
  },
  {
    quote:
      "Our Core Web Vitals report went from amber to green in 6 weeks. PagePulse finally gave SEO and engineering a shared dashboard.",
    author: "Marcus Webb",
    role: "SEO Manager",
    company: "Beacon Commerce",
    metric: "All green CWV in 6 weeks",
    persona: "SEO Manager",
  },
  {
    quote:
      "Deployment impact diffing alone paid for the platform ten times over. We catch slow bundles before they ever reach production.",
    author: "Elena Rodriguez",
    role: "CTO",
    company: "Prism Analytics",
    metric: "Zero slow releases in 6 months",
    persona: "CTO",
  },
  {
    quote:
      "We roll PagePulse into every client engagement. Performance budgets in CI prove to clients that we hold the line on speed.",
    author: "James Liu",
    role: "Agency Founder",
    company: "Vertex Labs",
    metric: "+22% client retention",
    persona: "Agency Founder",
  },
  {
    quote:
      "Real user monitoring by device and country revealed our mobile LCP in Brazil was 4x slower. We fixed it and conversion jumped 18%.",
    author: "Priya Anand",
    role: "Ecommerce Engineering Manager",
    company: "Nova Retail",
    metric: "+18% mobile conversion",
    persona: "Ecommerce Engineering Manager",
  },
];

export function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setActiveIndex((prev) => (prev + 1) % testimonials.length);
        setIsAnimating(false);
      }, 300);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const activeTestimonial = testimonials[activeIndex];

  return (
    <section className="relative py-32 lg:py-40 border-t border-foreground/10 lg:pb-14">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-xs tracking-widest text-muted-foreground uppercase">
            Customer outcomes
          </span>
          <div className="flex-1 h-px bg-foreground/10" />
          <span className="font-mono text-xs text-muted-foreground">
            {String(activeIndex + 1).padStart(2, "0")} / {String(testimonials.length).padStart(2, "0")}
          </span>
        </div>

        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20">
          <div className="lg:col-span-8">
            <div
              className={`mb-6 transition-all duration-300 ${
                isAnimating ? "opacity-0" : "opacity-100"
              }`}
            >
              <span className="inline-flex items-center gap-3 text-xs font-mono text-muted-foreground uppercase tracking-widest">
                <span className="w-6 h-px bg-foreground/30" />
                {activeTestimonial.persona}
              </span>
            </div>
            <blockquote
              className={`transition-all duration-300 ${
                isAnimating ? "opacity-0 translate-y-4" : "opacity-100 translate-y-0"
              }`}
            >
              <p className="font-display text-4xl md:text-5xl lg:text-6xl leading-[1.1] tracking-tight text-foreground">
                &ldquo;{activeTestimonial.quote}&rdquo;
              </p>
            </blockquote>

            <div
              className={`mt-12 flex items-center gap-6 transition-all duration-300 delay-100 ${
                isAnimating ? "opacity-0" : "opacity-100"
              }`}
            >
              <div className="w-16 h-16 rounded-full bg-foreground/5 border border-foreground/10 flex items-center justify-center">
                <span className="font-display text-2xl text-foreground">
                  {activeTestimonial.author.charAt(0)}
                </span>
              </div>
              <div>
                <p className="text-lg font-medium text-foreground">
                  {activeTestimonial.author}
                </p>
                <p className="text-muted-foreground">
                  {activeTestimonial.role}, {activeTestimonial.company}
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-col justify-center">
            <div
              className={`p-8 border border-foreground/10 transition-all duration-300 ${
                isAnimating ? "opacity-0 scale-95" : "opacity-100 scale-100"
              }`}
            >
              <span className="font-mono text-xs tracking-widest text-muted-foreground uppercase block mb-4">
                Key result
              </span>
              <p className="font-display text-3xl md:text-4xl text-foreground">
                {activeTestimonial.metric}
              </p>
            </div>

            <div className="flex flex-wrap gap-2 mt-8">
              {testimonials.map((t, idx) => (
                <button
                  key={idx}
                  type="button"
                  aria-label={`Show ${t.persona} testimonial`}
                  onClick={() => {
                    setIsAnimating(true);
                    setTimeout(() => {
                      setActiveIndex(idx);
                      setIsAnimating(false);
                    }, 300);
                  }}
                  className={`h-2 transition-all duration-300 ${
                    idx === activeIndex
                      ? "w-8 bg-foreground"
                      : "w-2 bg-foreground/20 hover:bg-foreground/40"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="mt-24 pt-12 border-t border-foreground/10">
          <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase mb-8 text-center">
            Trusted by frontend teams worldwide
          </p>
        </div>
      </div>

      <div className="w-full">
        <div className="flex gap-16 items-center marquee">
          {[...Array(2)].map((_, setIdx) => (
            <div key={setIdx} className="flex gap-16 items-center shrink-0">
              {[
                "Meridian Labs",
                "Flux Systems",
                "Beacon Commerce",
                "Prism Analytics",
                "Nova Retail",
                "Quantum Retail",
                "Atlas Digital",
                "Vertex Labs",
              ].map((company) => (
                <span
                  key={`${setIdx}-${company}`}
                  className="font-display text-xl md:text-2xl text-foreground/30 whitespace-nowrap hover:text-foreground transition-colors duration-300"
                >
                  {company}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
