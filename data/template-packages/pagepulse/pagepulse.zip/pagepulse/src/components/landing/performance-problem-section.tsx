"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowDown, AlertTriangle, Zap, Clock, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface ProblemCard {
  icon: typeof Zap;
  stat: string;
  statLabel: string;
  title: string;
  description: string;
  accent: "red" | "amber" | "neutral";
}

const problems: ProblemCard[] = [
  {
    icon: TrendingDown,
    stat: "-7%",
    statLabel: "conversion per +1s LCP",
    title: "Slow pages kill conversion",
    description:
      "Every additional second of LCP costs roughly 7% of conversions. A 3.5s LCP homepage is quietly taxing your revenue every single day.",
    accent: "red",
  },
  {
    icon: Zap,
    stat: "+12%",
    statLabel: "bounce when INP > 200ms",
    title: "Poor INP frustrates users",
    description:
      "Interactions over 200ms feel sluggish. Users tap again, trigger duplicate actions, and abandon the page. INP is the metric users feel but cannot name.",
    accent: "amber",
  },
  {
    icon: ArrowDown,
    stat: "0.1",
    statLabel: "CLS threshold for trust",
    title: "Layout shifts erode trust",
    description:
      "When content jumps while users are reading or tapping, they lose confidence. Accidental clicks on ads and wrong buttons compound the damage.",
    accent: "amber",
  },
  {
    icon: Clock,
    stat: "800ms",
    statLabel: "average JS parse tax",
    title: "Heavy JavaScript delays action",
    description:
      "Every kilobyte of JavaScript must be parsed, compiled, and executed on the main thread. Mid-range phones pay the price first, and the bill shows up in your funnel.",
    accent: "red",
  },
];

function SilentRegressionsIndicator() {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true);
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`relative border border-foreground/10 bg-foreground/[0.02] p-8 lg:p-10 transition-all duration-700 ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      }`}
    >
      <div className="flex items-start gap-4 mb-8">
        <div className="w-10 h-10 border border-foreground/10 flex items-center justify-center shrink-0">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
        </div>
        <div>
          <h3 className="text-2xl lg:text-3xl font-display">
            Silent deployment regressions
          </h3>
          <p className="text-muted-foreground mt-2 leading-relaxed">
            Without deployment impact diffing, slow releases ship to production
            unnoticed. Each release adds 30-80ms. After a quarter, your page is
            1.2s slower and no one knows why.
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {[
          { version: "v2.4.0", date: "Mar 14", delta: "+40ms LCP", cause: "Added chat widget" },
          { version: "v2.4.1", date: "Mar 21", delta: "+75ms LCP", cause: "Heavy hero image" },
          { version: "v2.4.2", date: "Mar 28", delta: "+30ms LCP", cause: "New analytics SDK" },
          { version: "v2.5.0", date: "Apr 04", delta: "+180ms LCP", cause: "Untagged regression" },
        ].map((r, i) => (
          <div
            key={r.version}
            className={cn(
              "flex items-center gap-4 py-2 transition-all duration-500",
              visible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-4"
            )}
            style={{ transitionDelay: `${300 + i * 120}ms` }}
          >
            <span className="font-mono text-xs text-muted-foreground w-16 shrink-0">
              {r.version}
            </span>
            <span className="font-mono text-xs text-muted-foreground w-16 shrink-0 hidden sm:block">
              {r.date}
            </span>
            <span className="font-mono text-xs text-red-600 w-24 shrink-0">
              {r.delta}
            </span>
            <span className="text-sm text-muted-foreground flex-1 truncate">
              {r.cause}
            </span>
            <span className="w-2 h-2 rounded-full bg-red-500/60 shrink-0" />
          </div>
        ))}
        <div className="pt-4 border-t border-foreground/10 flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Cumulative LCP regression</span>
          <span className="font-mono text-2xl font-display text-red-600">+325ms</span>
        </div>
      </div>
    </div>
  );
}

export function PerformanceProblemSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const accentClasses = {
    red: "text-red-600 border-red-500/20",
    amber: "text-amber-600 border-amber-500/20",
    neutral: "text-foreground border-foreground/15",
  };

  return (
    <section
      ref={sectionRef}
      className="relative py-24 lg:py-32 bg-foreground/[0.02] border-y border-foreground/10"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="max-w-3xl mb-16 lg:mb-20">
          <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
            <span className="w-8 h-px bg-foreground/30" />
            Why performance matters
          </span>
          <h2
            className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Slow pages cost
            <br />
            more than you think.
          </h2>
          <p
            className={`mt-8 text-xl text-muted-foreground leading-relaxed transition-all duration-700 delay-200 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Frontend performance is not a vanity metric. It is the single highest
            leverage investment a product team can make. Here is what the data
            actually says.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          <div className="grid sm:grid-cols-2 gap-px bg-foreground/10 border border-foreground/10">
            {problems.map((p, i) => (
              <div
                key={p.title}
                className={`bg-background p-6 lg:p-8 transition-all duration-700 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <div
                  className={cn(
                    "inline-flex w-9 h-9 items-center justify-center border mb-4",
                    accentClasses[p.accent]
                  )}
                >
                  <p.icon className="w-4 h-4" />
                </div>
                <div className="flex items-baseline gap-1.5 mb-1">
                  <span className="text-3xl lg:text-4xl font-display tracking-tight text-foreground">
                    {p.stat}
                  </span>
                </div>
                <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-3">
                  {p.statLabel}
                </p>
                <h3 className="text-base font-medium mb-2">{p.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {p.description}
                </p>
              </div>
            ))}
          </div>

          <SilentRegressionsIndicator />
        </div>
      </div>
    </section>
  );
}
