"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { AlertTriangle, TrendingDown, TrendingUp } from "lucide-react";

type BreakdownTab = "browser" | "device" | "country";

interface RouteRow {
  path: string;
  views: string;
  lcp: string;
  inp: string;
  cls: string;
  score: number;
  trend: "up" | "down" | "flat";
  delta: string;
  slow: boolean;
}

const routes: RouteRow[] = [
  { path: "/", views: "284k", lcp: "1.9s", inp: "96ms", cls: "0.04", score: 98, trend: "up", delta: "+3", slow: false },
  { path: "/p/[id]", views: "162k", lcp: "3.4s", inp: "240ms", cls: "0.12", score: 64, trend: "down", delta: "-7", slow: true },
  { path: "/search", views: "98k", lcp: "2.6s", inp: "180ms", cls: "0.08", score: 78, trend: "flat", delta: "0", slow: false },
  { path: "/cart", views: "74k", lcp: "1.4s", inp: "82ms", cls: "0.02", score: 99, trend: "up", delta: "+1", slow: false },
  { path: "/blog/[slug]", views: "61k", lcp: "1.7s", inp: "120ms", cls: "0.05", score: 94, trend: "up", delta: "+2", slow: false },
  { path: "/checkout", views: "42k", lcp: "4.1s", inp: "320ms", cls: "0.18", score: 52, trend: "down", delta: "-12", slow: true },
];

interface BreakdownRow {
  label: string;
  value: string;
  pct: number;
  lcp: string;
  score: number;
}

const breakdowns: Record<BreakdownTab, BreakdownRow[]> = {
  browser: [
    { label: "Chrome", value: "62%", pct: 62, lcp: "1.8s", score: 96 },
    { label: "Safari", value: "21%", pct: 21, lcp: "2.4s", score: 84 },
    { label: "Firefox", value: "9%", pct: 9, lcp: "2.0s", score: 92 },
    { label: "Edge", value: "6%", pct: 6, lcp: "1.9s", score: 95 },
    { label: "Samsung", value: "2%", pct: 2, lcp: "3.1s", score: 72 },
  ],
  device: [
    { label: "Desktop", value: "58%", pct: 58, lcp: "1.6s", score: 97 },
    { label: "Mobile", value: "34%", pct: 34, lcp: "2.9s", score: 78 },
    { label: "Tablet", value: "8%", pct: 8, lcp: "2.2s", score: 88 },
  ],
  country: [
    { label: "United States", value: "41%", pct: 41, lcp: "1.7s", score: 96 },
    { label: "United Kingdom", value: "14%", pct: 14, lcp: "1.9s", score: 94 },
    { label: "Germany", value: "11%", pct: 11, lcp: "1.8s", score: 95 },
    { label: "Brazil", value: "9%", pct: 9, lcp: "4.2s", score: 58 },
    { label: "Japan", value: "8%", pct: 8, lcp: "2.1s", score: 90 },
    { label: "India", value: "7%", pct: 7, lcp: "3.6s", score: 68 },
  ],
};

function scoreColor(score: number): string {
  if (score >= 90) return "text-green-600";
  if (score >= 50) return "text-amber-600";
  return "text-red-600";
}
function scoreBg(score: number): string {
  if (score >= 90) return "bg-green-500";
  if (score >= 50) return "bg-amber-500";
  return "bg-red-500";
}

export function RumPreviewSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState(0);
  const [activeTab, setActiveTab] = useState<BreakdownTab>("browser");
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.05 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const route = routes[selectedRoute];

  return (
    <section
      id="rum-preview"
      ref={sectionRef}
      className="relative py-24 lg:py-32 bg-foreground/[0.02] border-y border-foreground/10"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16 items-end">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Real user monitoring
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              See exactly who
              <br />
              is waiting.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-muted-foreground leading-relaxed">
              Slice real-user LCP, INP, and CLS by route, browser, device, and
              country. Click any route to drill in. The dashboard below is a live
              preview of the actual product.
            </p>
          </div>
        </div>

        <div
          className={`border border-foreground/10 bg-background transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <div className="px-4 lg:px-6 py-3 border-b border-foreground/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-mono text-muted-foreground">
                app.pagepulse.dev / rum
              </span>
            </div>
            <span className="text-xs font-mono text-muted-foreground hidden sm:block">
              Last 24 hours · live
            </span>
          </div>

          <div className="grid lg:grid-cols-12">
            <div className="lg:col-span-7 border-b lg:border-b-0 lg:border-r border-foreground/10">
              <div className="px-4 lg:px-6 py-3 border-b border-foreground/10 flex items-center justify-between">
                <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                  Routes
                </span>
                <span className="text-xs font-mono text-muted-foreground hidden sm:block">
                  Click to inspect
                </span>
              </div>
              <div className="max-h-[420px] overflow-y-auto">
                {routes.map((r, i) => {
                  const isSelected = i === selectedRoute;
                  return (
                    <button
                      key={r.path}
                      type="button"
                      onClick={() => setSelectedRoute(i)}
                      className={cn(
                        "w-full text-left px-4 lg:px-6 py-3 border-b border-foreground/5 last:border-b-0 transition-colors flex items-center gap-4",
                        isSelected
                          ? "bg-foreground/[0.04]"
                          : "hover:bg-foreground/[0.02]"
                      )}
                    >
                      <span
                        className={cn(
                          "w-1 h-10 rounded-full shrink-0",
                          isSelected ? "bg-foreground" : "bg-transparent"
                        )}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm text-foreground truncate">
                            {r.path}
                          </span>
                          {r.slow && (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-red-500/10 text-red-600 text-[9px] font-mono uppercase tracking-widest">
                              <AlertTriangle className="w-2.5 h-2.5" />
                              Slow
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1 text-[11px] font-mono text-muted-foreground">
                          <span>{r.views} views</span>
                          <span>LCP {r.lcp}</span>
                          <span>INP {r.inp}</span>
                          <span>CLS {r.cls}</span>
                        </div>
                      </div>
                      <div className="flex flex-col items-end shrink-0">
                        <span className={cn("font-display text-lg", scoreColor(r.score))}>
                          {r.score}
                        </span>
                        <span
                          className={cn(
                            "text-[10px] font-mono flex items-center gap-0.5",
                            r.trend === "up"
                              ? "text-green-600"
                              : r.trend === "down"
                                ? "text-red-600"
                                : "text-muted-foreground"
                          )}
                        >
                          {r.trend === "up" && <TrendingUp className="w-2.5 h-2.5" />}
                          {r.trend === "down" && <TrendingDown className="w-2.5 h-2.5" />}
                          {r.delta}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="lg:col-span-5 p-4 lg:p-6">
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Selected route
                  </span>
                  <span
                    className={cn(
                      "inline-flex items-center gap-1.5 px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest",
                      route.score >= 90
                        ? "bg-green-500/10 text-green-600"
                        : route.score >= 50
                          ? "bg-amber-500/10 text-amber-600"
                          : "bg-red-500/10 text-red-600"
                    )}
                  >
                    <span className={cn("w-1.5 h-1.5 rounded-full", scoreBg(route.score))} />
                    {route.score >= 90 ? "Passing" : route.score >= 50 ? "Needs work" : "Failing"}
                  </span>
                </div>
                <div className="font-mono text-sm text-foreground break-all">
                  {route.path}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 mb-6">
                {[
                  { label: "LCP", value: route.lcp },
                  { label: "INP", value: route.inp },
                  { label: "CLS", value: route.cls },
                ].map((m) => (
                  <div key={m.label} className="border border-foreground/10 p-3">
                    <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                      {m.label}
                    </div>
                    <div className="font-display text-lg mt-1">{m.value}</div>
                  </div>
                ))}
              </div>

              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Breakdown
                  </span>
                  <div className="flex border border-foreground/10">
                    {(["browser", "device", "country"] as const).map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setActiveTab(t)}
                        className={cn(
                          "px-2.5 py-1 text-[10px] font-mono uppercase tracking-widest transition-colors",
                          activeTab === t
                            ? "bg-foreground text-background"
                            : "text-muted-foreground hover:text-foreground"
                        )}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-2.5">
                  {breakdowns[activeTab].map((b) => (
                    <div key={b.label} className="flex items-center gap-3">
                      <span className="text-xs text-foreground w-24 lg:w-28 shrink-0 truncate">
                        {b.label}
                      </span>
                      <div className="flex-1 h-1.5 bg-foreground/5 overflow-hidden">
                        <div
                          className={cn("h-full", scoreBg(b.score))}
                          style={{ width: `${b.pct}%` }}
                        />
                      </div>
                      <span className="text-[11px] font-mono text-muted-foreground w-8 text-right shrink-0">
                        {b.value}
                      </span>
                      <span className={cn("text-[11px] font-mono w-12 text-right shrink-0", scoreColor(b.score))}>
                        {b.lcp}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border border-foreground/10 p-4 bg-foreground/[0.02]">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Conversion impact
                  </span>
                  <span
                    className={cn(
                      "text-xs font-mono",
                      route.score >= 90 ? "text-green-600" : "text-red-600"
                    )}
                  >
                    {route.score >= 90 ? "Neutral" : `-${((100 - route.score) * 0.18).toFixed(1)}% conv`}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {route.score >= 90
                    ? "This route is performing within target. No measurable conversion impact."
                    : `Real users on this route are converting below baseline. Slow LCP and INP are the most likely cause.`}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
