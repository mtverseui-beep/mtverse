"use client";

import { useEffect, useState, useRef, useMemo } from "react";
import { cn } from "@/lib/utils";

type IntegrationCategory =
  | "Deployments"
  | "Frameworks"
  | "Analytics"
  | "Alerts"
  | "Issue Tracking"
  | "Webhooks";

interface Integration {
  name: string;
  category: IntegrationCategory;
}

const integrations: Integration[] = [
  { name: "Vercel", category: "Deployments" },
  { name: "Netlify", category: "Deployments" },
  { name: "Cloudflare", category: "Deployments" },
  { name: "GitHub", category: "Deployments" },
  { name: "GitLab", category: "Deployments" },
  { name: "Next.js", category: "Frameworks" },
  { name: "React", category: "Frameworks" },
  { name: "Vue", category: "Frameworks" },
  { name: "Nuxt", category: "Frameworks" },
  { name: "Remix", category: "Frameworks" },
  { name: "Astro", category: "Frameworks" },
  { name: "Google Analytics", category: "Analytics" },
  { name: "Google Search Console", category: "Analytics" },
  { name: "Slack", category: "Alerts" },
  { name: "Linear", category: "Issue Tracking" },
  { name: "Jira", category: "Issue Tracking" },
  { name: "Sentry", category: "Issue Tracking" },
  { name: "Webhooks", category: "Webhooks" },
];

const categories: IntegrationCategory[] = [
  "Deployments",
  "Frameworks",
  "Analytics",
  "Alerts",
  "Issue Tracking",
  "Webhooks",
];

export function IntegrationsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeCategory, setActiveCategory] = useState<IntegrationCategory | "All">("All");
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const marqueeIntegrations = useMemo(() => integrations, []);

  const filtered = useMemo(() => {
    if (activeCategory === "All") return integrations;
    return integrations.filter((i) => i.category === activeCategory);
  }, [activeCategory]);

  return (
    <section id="integrations" ref={sectionRef} className="relative py-24 lg:py-32 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div
          className={`text-center max-w-3xl mx-auto mb-12 lg:mb-16 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
            <span className="w-8 h-px bg-foreground/30" />
            Integrations
            <span className="w-8 h-px bg-foreground/30" />
          </span>
          <h2 className="text-4xl lg:text-6xl font-display tracking-tight mb-6">
            Works with everything
            <br />
            you already use.
          </h2>
          <p className="text-xl text-muted-foreground">
            Connect performance monitoring directly to your deployment, analytics,
            and issue-tracking workflow.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          <button
            type="button"
            onClick={() => setActiveCategory("All")}
            className={cn(
              "px-4 py-2 text-sm font-mono border transition-colors",
              activeCategory === "All"
                ? "bg-foreground text-background border-foreground"
                : "border-foreground/15 text-muted-foreground hover:text-foreground hover:border-foreground/40"
            )}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={cn(
                "px-4 py-2 text-sm font-mono border transition-colors",
                activeCategory === cat
                  ? "bg-foreground text-background border-foreground"
                  : "border-foreground/15 text-muted-foreground hover:text-foreground hover:border-foreground/40"
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        <div
          className={`grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 transition-opacity duration-500 ${
            isVisible ? "opacity-100" : "opacity-0"
          }`}
        >
          {filtered.map((integration) => (
            <div
              key={`${integration.name}-${integration.category}`}
              className="px-6 py-6 border border-foreground/10 hover:border-foreground/30 hover:bg-foreground/[0.02] transition-all duration-300 group"
            >
              <div className="text-lg font-medium group-hover:translate-x-1 transition-transform">
                {integration.name}
              </div>
              <div className="text-sm text-muted-foreground mt-1">{integration.category}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="w-full mt-16 mb-6">
        <div className="flex gap-6 marquee">
          {[...Array(2)].map((_, setIndex) => (
            <div key={setIndex} className="flex gap-6 shrink-0">
              {marqueeIntegrations.map((integration) => (
                <div
                  key={`${integration.name}-${setIndex}`}
                  className="shrink-0 px-8 py-6 border border-foreground/10 hover:border-foreground/30 hover:bg-foreground/[0.02] transition-all duration-300 group"
                >
                  <div className="text-lg font-medium group-hover:translate-x-1 transition-transform">
                    {integration.name}
                  </div>
                  <div className="text-sm text-muted-foreground">{integration.category}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      <div className="w-full">
        <div className="flex gap-6 marquee-reverse">
          {[...Array(2)].map((_, setIndex) => (
            <div key={setIndex} className="flex gap-6 shrink-0">
              {[...marqueeIntegrations].reverse().map((integration) => (
                <div
                  key={`${integration.name}-reverse-${setIndex}`}
                  className="shrink-0 px-8 py-6 border border-foreground/10 hover:border-foreground/30 hover:bg-foreground/[0.02] transition-all duration-300 group"
                >
                  <div className="text-lg font-medium group-hover:translate-x-1 transition-transform">
                    {integration.name}
                  </div>
                  <div className="text-sm text-muted-foreground">{integration.category}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
