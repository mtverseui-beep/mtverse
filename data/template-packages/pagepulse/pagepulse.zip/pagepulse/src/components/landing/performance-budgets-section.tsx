"use client";

import { useEffect, useRef, useState } from "react";
import { Check, X, Bell } from "lucide-react";
import { cn } from "@/lib/utils";

interface Budget {
  label: string;
  threshold: string;
  current: string;
  currentNumeric: number;
  thresholdNumeric: number;
  unit: string;
  passing: boolean;
  progress: number;
}

const budgets: Budget[] = [
  {
    label: "JavaScript size",
    threshold: "180 KB",
    current: "142 KB",
    currentNumeric: 142,
    thresholdNumeric: 180,
    unit: "KB",
    passing: true,
    progress: 79,
  },
  {
    label: "LCP",
    threshold: "2.5 s",
    current: "1.9 s",
    currentNumeric: 1.9,
    thresholdNumeric: 2.5,
    unit: "s",
    passing: true,
    progress: 76,
  },
  {
    label: "INP",
    threshold: "200 ms",
    current: "96 ms",
    currentNumeric: 96,
    thresholdNumeric: 200,
    unit: "ms",
    passing: true,
    progress: 48,
  },
  {
    label: "CLS",
    threshold: "0.10",
    current: "0.04",
    currentNumeric: 0.04,
    thresholdNumeric: 0.10,
    unit: "",
    passing: true,
    progress: 40,
  },
  {
    label: "Image weight",
    threshold: "500 KB",
    current: "612 KB",
    currentNumeric: 612,
    thresholdNumeric: 500,
    unit: "KB",
    passing: false,
    progress: 122,
  },
  {
    label: "Route load",
    threshold: "1.0 s",
    current: "0.8 s",
    currentNumeric: 0.8,
    thresholdNumeric: 1.0,
    unit: "s",
    passing: true,
    progress: 80,
  },
];

export function PerformanceBudgetsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="performance-budgets"
      ref={sectionRef}
      className="relative py-24 lg:py-32 section-invert overflow-hidden"
    >
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `repeating-linear-gradient(
            -45deg,
            transparent,
            transparent 40px,
            currentColor 40px,
            currentColor 41px
          )`,
          }}
        />
      </div>

      <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16 items-end">
          <div className="lg:col-span-7">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-invert mb-6">
              <span className="w-8 h-px bg-current opacity-30" />
              Performance budgets
            </span>
            <h2
              className={`text-4xl lg:text-6xl font-display tracking-tight transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              Enforce limits,
              <br />
              not wishes.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-muted-invert leading-relaxed">
              Set hard limits on JavaScript size, image weight, route speed, and
              Core Web Vitals. Breaches trigger Slack alerts, webhooks, or fail
              the CI build before code reaches production.
            </p>
          </div>
        </div>

        <div
          className={`grid md:grid-cols-2 lg:grid-cols-3 gap-px border border-invert transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ backgroundColor: "oklch(0.28 0.008 60 / 1)" }}
        >
          {budgets.map((b, i) => (
            <div
              key={b.label}
              className="surface-invert p-6 lg:p-7"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-mono text-muted-invert uppercase tracking-widest">
                  {b.label}
                </span>
                <span
                  className={cn(
                    "inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-mono uppercase tracking-widest",
                    b.passing
                      ? "bg-green-500/15 text-green-400"
                      : "bg-red-500/15 text-red-400"
                  )}
                >
                  {b.passing ? (
                    <Check className="w-2.5 h-2.5" />
                  ) : (
                    <X className="w-2.5 h-2.5" />
                  )}
                  {b.passing ? "Pass" : "Fail"}
                </span>
              </div>

              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-3xl lg:text-4xl font-display tracking-tight">
                  {b.current}
                </span>
                <span className="text-xs font-mono text-muted-invert">
                  / {b.threshold}
                </span>
              </div>

              <div className="h-1.5 overflow-hidden mb-2" style={{ backgroundColor: "oklch(0.28 0.008 60 / 1)" }}>
                <div
                  className={cn(
                    "h-full transition-all duration-1000",
                    b.passing ? "bg-green-500" : "bg-red-500"
                  )}
                  style={{
                    width: `${Math.min(b.progress, 100)}%`,
                    transitionDelay: `${i * 60 + 200}ms`,
                  }}
                />
              </div>
              <div className="flex justify-between text-[10px] font-mono text-muted-invert">
                <span>0 {b.unit}</span>
                <span>{b.threshold}</span>
              </div>
            </div>
          ))}
        </div>

        <div
          className={`mt-12 grid lg:grid-cols-2 gap-px border border-invert transition-all duration-700 delay-300 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ backgroundColor: "oklch(0.28 0.008 60 / 1)" }}
        >
          <div className="surface-invert p-6 lg:p-8">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 border border-invert flex items-center justify-center shrink-0">
                <Bell className="w-4 h-4 text-red-400" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-mono uppercase tracking-widest text-red-400">
                    Alert · Budget breached
                  </span>
                  <span className="text-xs font-mono text-muted-invert">
                    2 min ago
                  </span>
                </div>
                <p className="text-sm leading-relaxed" style={{ color: "oklch(0.85 0.004 90)" }}>
                  Image weight on <span className="font-mono">/blog/[slug]</span> exceeded the 500 KB budget by 112 KB. Largest contributor: <span className="font-mono">hero-og-image.png</span> (640 KB).
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="px-2 py-1 border border-invert text-[10px] font-mono uppercase tracking-widest text-muted-invert">
                    Slack · #perf-alerts
                  </span>
                  <span className="px-2 py-1 border border-invert text-[10px] font-mono uppercase tracking-widest text-muted-invert">
                    Linear · auto-filed
                  </span>
                  <span className="px-2 py-1 border border-invert text-[10px] font-mono uppercase tracking-widest text-muted-invert">
                    Webhook · ci-fail
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="surface-invert p-6 lg:p-8 flex flex-col justify-center">
            <span className="text-xs font-mono uppercase tracking-widest text-muted-invert mb-4 block">
              Budget enforcement
            </span>
            <ul className="space-y-3 text-sm">
              {[
                "Block PRs that breach a budget via @pagepulse/ci",
                "Tag every regression to the offending commit",
                "Promote a budget to an SLO with burn-rate tracking",
                "Auto-file Linear, Jira, or GitHub issues on breach",
                "Stream budget breaches to any webhook endpoint",
              ].map((item, i) => (
                <li
                  key={i}
                  className={`flex items-start gap-2 transition-all duration-500 ${
                    isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-2"
                  }`}
                  style={{ transitionDelay: `${500 + i * 80}ms` }}
                >
                  <Check className="w-3.5 h-3.5 text-green-400 mt-0.5 shrink-0" />
                  <span style={{ color: "oklch(0.85 0.004 90)" }}>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
