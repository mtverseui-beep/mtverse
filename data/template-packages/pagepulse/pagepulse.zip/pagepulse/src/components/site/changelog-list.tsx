"use client";

import { useState, useMemo } from "react";
import { changelog, type ChangelogEntry } from "@/lib/changelog";
import { cn } from "@/lib/utils";

const typeStyles: Record<ChangelogEntry["type"], { label: string; className: string }> = {
  release: { label: "Release", className: "bg-foreground text-background" },
  improvement: { label: "Improvement", className: "bg-foreground/10 text-foreground" },
  fix: { label: "Fix", className: "bg-amber-500/15 text-amber-700" },
  deprecation: { label: "Deprecation", className: "bg-red-500/15 text-red-700" },
};

const filterTypes: { value: ChangelogEntry["type"] | "all"; label: string }[] = [
  { value: "all", label: "All" },
  { value: "release", label: "Releases" },
  { value: "improvement", label: "Improvements" },
  { value: "fix", label: "Fixes" },
  { value: "deprecation", label: "Deprecations" },
];

export function ChangelogList() {
  const [filter, setFilter] = useState<ChangelogEntry["type"] | "all">("all");

  const filtered = useMemo(() => {
    if (filter === "all") return changelog;
    return changelog.filter((c) => c.type === filter);
  }, [filter]);

  return (
    <div className="max-w-[1400px] mx-auto px-6 lg:px-12 pb-24 lg:pb-32">
      <div className="flex flex-wrap gap-2 mb-12">
        {filterTypes.map((ft) => (
          <button
            key={ft.value}
            type="button"
            onClick={() => setFilter(ft.value)}
            className={cn(
              "px-4 py-2 text-sm font-mono border transition-colors",
              filter === ft.value
                ? "bg-foreground text-background border-foreground"
                : "border-foreground/15 text-muted-foreground hover:text-foreground hover:border-foreground/40"
            )}
          >
            {ft.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="py-24 text-center border border-foreground/10">
          <p className="text-muted-foreground">No entries match this filter.</p>
        </div>
      ) : (
        <div className="space-y-px bg-foreground/10 border border-foreground/10">
          {filtered.map((entry) => (
            <article key={`${entry.date}-${entry.version}`} className="bg-background p-8 lg:p-10">
              <div className="flex flex-col lg:flex-row lg:items-start gap-6 lg:gap-12">
                <div className="lg:w-48 shrink-0">
                  <time className="text-sm font-mono text-muted-foreground block">
                    {new Date(entry.date).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </time>
                  <span className="font-mono text-xs text-foreground mt-1 block">
                    {entry.version}
                  </span>
                  <span
                    className={cn(
                      "inline-block mt-3 px-2 py-1 text-[10px] font-mono uppercase tracking-widest",
                      typeStyles[entry.type].className
                    )}
                  >
                    {typeStyles[entry.type].label}
                  </span>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl lg:text-3xl font-display mb-3">
                    {entry.title}
                  </h2>
                  <p className="text-muted-foreground leading-relaxed">
                    {entry.description}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {entry.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-1 border border-foreground/10 text-[10px] font-mono uppercase tracking-widest text-muted-foreground"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
