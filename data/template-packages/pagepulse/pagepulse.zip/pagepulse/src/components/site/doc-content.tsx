"use client";

import { useState } from "react";
import { Copy, Check, Info, AlertTriangle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import type { DocBlock } from "@/lib/docs";
import { cn } from "@/lib/utils";

interface DocContentProps {
  blocks: DocBlock[];
}

export function DocContent({ blocks }: DocContentProps) {
  return (
    <div className="space-y-6">
      {blocks.map((block, i) => {
        if (block.type === "heading") {
          return (
            <h2 key={i} className="text-2xl lg:text-3xl font-display tracking-tight mt-12 mb-2 first:mt-0">
              {block.text}
            </h2>
          );
        }
        if (block.type === "paragraph") {
          return (
            <p key={i} className="text-foreground/80 leading-relaxed">
              {block.text}
            </p>
          );
        }
        if (block.type === "list") {
          return (
            <ul key={i} className="space-y-2 my-4">
              {block.items?.map((item, j) => (
                <li key={j} className="flex gap-3 text-foreground/80 leading-relaxed">
                  <span className="text-foreground/40 font-mono text-sm mt-1 shrink-0">
                    {String(j + 1).padStart(2, "0")}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          );
        }
        if (block.type === "code") {
          return <DocCodeBlock key={i} code={block.code ?? ""} language={block.language ?? "text"} />;
        }
        if (block.type === "callout") {
          return <DocCallout key={i} variant={block.variant ?? "info"} text={block.text ?? ""} />;
        }
        return null;
      })}
    </div>
  );
}

function DocCodeBlock({ code, language }: { code: string; language: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Could not copy code");
    }
  };

  return (
    <div className="my-6 border border-foreground/10 overflow-hidden">
      <div className="px-4 py-2 border-b border-foreground/10 flex items-center justify-between bg-foreground/[0.02]">
        <span className="text-xs font-mono text-muted-foreground">{language}</span>
        <button
          type="button"
          onClick={handleCopy}
          className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5 text-xs font-mono"
          aria-label="Copy code"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-green-600" />
              Copied
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              Copy
            </>
          )}
        </button>
      </div>
      <pre className="p-4 lg:p-6 font-mono text-sm overflow-x-auto leading-relaxed bg-foreground/[0.01]">
        <code className="text-foreground/80">{code}</code>
      </pre>
    </div>
  );
}

function DocCallout({
  variant,
  text,
}: {
  variant: "info" | "warning" | "success";
  text: string;
}) {
  const Icon = variant === "info" ? Info : variant === "warning" ? AlertTriangle : CheckCircle2;
  const colorClasses =
    variant === "info"
      ? "border-foreground/15 bg-foreground/[0.02] text-foreground"
      : variant === "warning"
        ? "border-amber-500/30 bg-amber-500/5 text-foreground"
        : "border-green-500/30 bg-green-500/5 text-foreground";
  const iconColor =
    variant === "info"
      ? "text-foreground"
      : variant === "warning"
        ? "text-amber-600"
        : "text-green-600";

  return (
    <div className={cn("my-6 border p-4 lg:p-5 flex gap-3", colorClasses)}>
      <Icon className={cn("w-5 h-5 shrink-0 mt-0.5", iconColor)} />
      <p className="text-sm text-foreground/80 leading-relaxed">{text}</p>
    </div>
  );
}
