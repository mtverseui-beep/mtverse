"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { docCategories, docPages } from "@/lib/docs";
import { cn } from "@/lib/utils";
import { Search, Menu, X, ChevronLeft, ChevronRight } from "lucide-react";
import { Logo } from "@/components/site/logo";
import { ThemeToggle } from "@/components/site/theme-toggle";
import { siteConfig } from "@/lib/site-config";
import { Button } from "@/components/ui/button";

interface DocsShellProps {
  children: React.ReactNode;
  currentSlug: string;
  title: string;
  description: string;
}

export function DocsShell({
  children,
  currentSlug,
  title,
  description,
}: DocsShellProps) {
  const [query, setQuery] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const filteredCategories = useMemo(() => {
    if (!query.trim()) return docCategories;
    const q = query.toLowerCase();
    return docCategories
      .map((cat) => ({
        ...cat,
        items: cat.items.filter((item) =>
          item.title.toLowerCase().includes(q) ||
          item.slug.toLowerCase().includes(q)
        ),
      }))
      .filter((cat) => cat.items.length > 0);
  }, [query]);

  // Compute prev/next
  const flat = docCategories.flatMap((c) => c.items);
  const idx = flat.findIndex((i) => i.slug === currentSlug);
  const prev = idx > 0 ? flat[idx - 1] : undefined;
  const next = idx < flat.length - 1 ? flat[idx + 1] : undefined;

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-foreground/10 bg-background/80 backdrop-blur-xl">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setMobileNavOpen(true)}
              className="lg:hidden p-2 -ml-2"
              aria-label="Open docs navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <Logo scrolled variant="compact" />
            <span className="text-foreground/20 hidden sm:block">/</span>
            <span className="text-sm font-mono text-muted-foreground hidden sm:block">
              docs
            </span>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <Button
              asChild
              size="sm"
              className="bg-foreground hover:bg-foreground/90 text-background rounded-full hidden sm:flex"
            >
              <Link href="/sign-up">Start monitoring</Link>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-[1400px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-12 lg:gap-16 pt-12">
        {/* Sidebar — desktop */}
        <aside className="hidden lg:block lg:col-span-3">
          <div className="sticky top-24 space-y-8">
            <div>
              <label htmlFor="docs-search" className="sr-only">
                Search docs
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input
                  id="docs-search"
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search docs..."
                  className="w-full pl-9 pr-3 py-2 text-sm bg-transparent border border-foreground/15 focus:border-foreground/40 focus:outline-none transition-colors"
                />
              </div>
            </div>

            <nav>
              {filteredCategories.length === 0 ? (
                <p className="text-sm text-muted-foreground">No results.</p>
              ) : (
                filteredCategories.map((cat) => (
                  <div key={cat.label} className="mb-6">
                    <h3 className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">
                      {cat.label}
                    </h3>
                    <ul className="space-y-1">
                      {cat.items.map((item) => {
                        const isActive = item.slug === currentSlug;
                        return (
                          <li key={item.slug}>
                            <Link
                              href={`/docs/${item.slug === "installation" ? "" : item.slug}`}
                              className={cn(
                                "block text-sm py-1.5 px-3 transition-colors",
                                isActive
                                  ? "bg-foreground text-background"
                                  : "text-muted-foreground hover:text-foreground hover:bg-foreground/5"
                              )}
                            >
                              {item.title}
                            </Link>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))
              )}
            </nav>

            <div className="border-t border-foreground/10 pt-6">
              <Link
                href="/docs"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Docs overview
              </Link>
            </div>
          </div>
        </aside>

        {/* Mobile sidebar */}
        {mobileNavOpen && (
          <div className="lg:hidden fixed inset-0 z-50 bg-background">
            <header className="h-16 border-b border-foreground/10 px-6 flex items-center justify-between">
              <Logo variant="compact" />
              <button
                type="button"
                onClick={() => setMobileNavOpen(false)}
                aria-label="Close docs navigation"
                className="p-2 -mr-2"
              >
                <X className="w-5 h-5" />
              </button>
            </header>
            <div className="p-6 overflow-y-auto h-[calc(100%-4rem)]">
              <div className="relative mb-6">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search docs..."
                  className="w-full pl-9 pr-3 py-2 text-sm bg-transparent border border-foreground/15 focus:border-foreground/40 focus:outline-none transition-colors"
                />
              </div>
              <nav>
                {filteredCategories.map((cat) => (
                  <div key={cat.label} className="mb-6">
                    <h3 className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">
                      {cat.label}
                    </h3>
                    <ul className="space-y-1">
                      {cat.items.map((item) => {
                        const isActive = item.slug === currentSlug;
                        return (
                          <li key={item.slug}>
                            <Link
                              href={`/docs/${item.slug === "installation" ? "" : item.slug}`}
                              onClick={() => setMobileNavOpen(false)}
                              className={cn(
                                "block text-sm py-1.5 px-3 transition-colors",
                                isActive
                                  ? "bg-foreground text-background"
                                  : "text-muted-foreground hover:text-foreground hover:bg-foreground/5"
                              )}
                            >
                              {item.title}
                            </Link>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </nav>
            </div>
          </div>
        )}

        {/* Main content */}
        <main className="lg:col-span-9 pb-24">
          <article className="max-w-3xl">
            <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4 block">
              Documentation
            </span>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-display tracking-tight mb-4">
              {title}
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed mb-12">
              {description}
            </p>

            {children}

            {/* Prev/Next */}
            <nav className="mt-16 pt-8 border-t border-foreground/10 grid sm:grid-cols-2 gap-4">
              {prev ? (
                <Link
                  href={`/docs/${prev.slug === "installation" ? "" : prev.slug}`}
                  className="group border border-foreground/10 p-4 hover:border-foreground/30 transition-colors"
                >
                  <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">
                    <ChevronLeft className="w-3 h-3" />
                    Previous
                  </div>
                  <div className="font-display text-lg group-hover:translate-x-[-4px] transition-transform">
                    {prev.title}
                  </div>
                </Link>
              ) : (
                <div />
              )}
              {next ? (
                <Link
                  href={`/docs/${next.slug === "installation" ? "" : next.slug}`}
                  className="group border border-foreground/10 p-4 hover:border-foreground/30 transition-colors text-right sm:col-start-2"
                >
                  <div className="flex items-center justify-end gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">
                    Next
                    <ChevronRight className="w-3 h-3" />
                  </div>
                  <div className="font-display text-lg group-hover:translate-x-[4px] transition-transform">
                    {next.title}
                  </div>
                </Link>
              ) : (
                <div />
              )}
            </nav>

            <div className="mt-12 p-6 border border-foreground/10 bg-foreground/[0.02]">
              <p className="text-sm text-muted-foreground mb-3">
                Have a question about this doc?
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <Link
                  href="/contact"
                  className="text-foreground hover:underline underline-offset-4"
                >
                  Contact support
                </Link>
                <span className="text-foreground/20">|</span>
                <Link
                  href="/docs/api"
                  className="text-muted-foreground hover:text-foreground"
                >
                  API reference
                </Link>
                <span className="text-foreground/20">|</span>
                <a
                  href={`mailto:${siteConfig.supportEmail}`}
                  className="text-muted-foreground hover:text-foreground"
                >
                  {siteConfig.supportEmail}
                </a>
              </div>
            </div>
          </article>
        </main>
      </div>
    </div>
  );
}
