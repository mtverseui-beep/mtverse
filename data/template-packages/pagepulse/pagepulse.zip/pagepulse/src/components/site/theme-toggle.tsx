"use client";

import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";
import { cn } from "@/lib/utils";

interface ThemeToggleProps {
  className?: string;
  scrolled?: boolean;
}

export function ThemeToggle({ className, scrolled = false }: ThemeToggleProps) {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const current = document.documentElement.classList.contains("dark")
      ? "dark"
      : "light";
    setTheme(current);
    setMounted(true);
  }, []);

  const toggle = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    const root = document.documentElement;
    if (next === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    root.style.colorScheme = next;
    try {
      window.localStorage.setItem("pagepulse-theme", next);
    } catch {
      /* ignore */
    }
  };

  // Render a stable placeholder until mounted to avoid hydration mismatch
  if (!mounted) {
    return (
      <button
        type="button"
        aria-label="Toggle theme"
        className={cn(
          "inline-flex items-center justify-center rounded-full border border-foreground/15",
          scrolled ? "w-8 h-8" : "w-9 h-9",
          className
        )}
      >
        <Sun className={cn(scrolled ? "w-3.5 h-3.5" : "w-4 h-4", "opacity-50")} />
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
      className={cn(
        "inline-flex items-center justify-center rounded-full border border-foreground/15 hover:border-foreground/40 hover:bg-foreground/5 transition-colors",
        scrolled ? "w-8 h-8" : "w-9 h-9",
        className
      )}
    >
      {theme === "dark" ? (
        <Sun className={cn(scrolled ? "w-3.5 h-3.5" : "w-4 h-4")} />
      ) : (
        <Moon className={cn(scrolled ? "w-3.5 h-3.5" : "w-4 h-4")} />
      )}
    </button>
  );
}
