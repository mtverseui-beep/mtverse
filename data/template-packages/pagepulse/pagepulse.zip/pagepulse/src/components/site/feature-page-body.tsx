"use client";

import { useEffect, useRef, useState } from "react";

interface FeatureBlock {
  number: string;
  title: string;
  description: string;
}

interface FeatureRowProps {
  number: string;
  title: string;
  description: string;
  reverse?: boolean;
}

function FeatureRow({ number, title, description, reverse }: FeatureRowProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.15 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`grid lg:grid-cols-2 gap-12 lg:gap-16 items-center py-16 lg:py-24 border-b border-foreground/10 transition-all duration-700 ${
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      }`}
    >
      <div className={reverse ? "lg:order-2" : ""}>
        <span className="font-mono text-sm text-muted-foreground mb-4 block">{number}</span>
        <h3 className="text-3xl lg:text-4xl font-display mb-4">{title}</h3>
        <p className="text-lg text-muted-foreground leading-relaxed">{description}</p>
      </div>
      <div className={reverse ? "lg:order-1" : ""}>
        <div className="aspect-[4/3] border border-foreground/10 bg-foreground/[0.02] flex items-center justify-center p-8">
          <div className="font-mono text-sm text-muted-foreground/60 text-center">
            <div className="text-xs uppercase tracking-widest mb-2">Live preview</div>
            <div className="font-display text-3xl text-foreground/40">{number}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface FeaturePageBodyProps {
  blocks: FeatureBlock[];
}

export function FeaturePageBody({ blocks }: FeaturePageBodyProps) {
  return (
    <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
      {blocks.map((block, i) => (
        <FeatureRow
          key={block.number}
          number={block.number}
          title={block.title}
          description={block.description}
          reverse={i % 2 === 1}
        />
      ))}
    </div>
  );
}
