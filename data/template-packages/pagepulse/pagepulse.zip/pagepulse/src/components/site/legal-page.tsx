import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { siteConfig } from "@/lib/site-config";

export interface LegalSection {
  heading: string;
  body: string[];
  subsections?: { heading: string; body: string[] }[];
}

interface LegalPageProps {
  eyebrow: string;
  title: string;
  description: string;
  lastUpdated: string;
  sections: LegalSection[];
  sidebar: { label: string; href: string; active?: boolean }[];
}

export function LegalPage({
  eyebrow,
  title,
  description,
  lastUpdated,
  sections,
  sidebar,
}: LegalPageProps) {
  return (
    <PageShell>
      <PageHeader eyebrow={eyebrow} title={title} description={description} />

      <div className="max-w-[1400px] mx-auto px-6 lg:px-12 pb-24 lg:pb-32">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16">
          <aside className="lg:col-span-3">
            <div className="lg:sticky lg:top-32">
              <div className="mb-6">
                <span className="text-xs font-mono uppercase tracking-widest text-muted-foreground">
                  Last updated
                </span>
                <p className="text-sm font-mono text-foreground mt-1">
                  {lastUpdated}
                </p>
              </div>
              <div className="border-t border-foreground/10 pt-6">
                <h3 className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-4">
                  Legal documents
                </h3>
                <ul className="space-y-1">
                  {sidebar.map((item) => (
                    <li key={item.href}>
                      <a
                        href={item.href}
                        className={`block text-sm py-1.5 px-3 transition-colors ${
                          item.active
                            ? "bg-foreground text-background"
                            : "text-muted-foreground hover:text-foreground hover:bg-foreground/5"
                        }`}
                      >
                        {item.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </aside>

          <div className="lg:col-span-9">
            <article className="space-y-12">
              {sections.map((section) => (
                <section key={section.heading}>
                  <h2 className="text-2xl lg:text-3xl font-display tracking-tight mb-4">
                    {section.heading}
                  </h2>
                  {section.body.map((p, i) => (
                    <p key={i} className="text-muted-foreground leading-relaxed mb-4">
                      {p}
                    </p>
                  ))}
                  {section.subsections && (
                    <div className="mt-6 space-y-6">
                      {section.subsections.map((sub) => (
                        <div key={sub.heading}>
                          <h3 className="text-lg font-display mb-3">{sub.heading}</h3>
                          {sub.body.map((p, i) => (
                            <p key={i} className="text-muted-foreground leading-relaxed mb-3">
                              {p}
                            </p>
                          ))}
                        </div>
                      ))}
                    </div>
                  )}
                </section>
              ))}

              <section className="border-t border-foreground/10 pt-8">
                <p className="text-sm text-muted-foreground">
                  Questions about this document? Email{" "}
                  <a
                    href={`mailto:${siteConfig.supportEmail}`}
                    className="text-foreground hover:underline underline-offset-4"
                  >
                    {siteConfig.supportEmail}
                  </a>
                  .
                </p>
              </section>
            </article>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
