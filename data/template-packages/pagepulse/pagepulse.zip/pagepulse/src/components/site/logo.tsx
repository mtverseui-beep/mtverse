import Link from "next/link";
import { siteConfig } from "@/lib/site-config";
import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  href?: string;
  scrolled?: boolean;
  variant?: "default" | "compact";
}

export function Logo({ className, href = "/", scrolled = false, variant = "default" }: LogoProps) {
  return (
    <Link
      href={href}
      className={cn("flex items-center gap-2 group", className)}
      aria-label={`${siteConfig.name} home`}
    >
      <svg
        viewBox="0 0 64 64"
        className={cn("transition-all duration-500", scrolled ? "w-7 h-7" : "w-8 h-8")}
        aria-hidden="true"
      >
        <rect width="64" height="64" rx="12" fill="currentColor" />
        <path
          d="M8 40 L18 28 L26 36 L34 18 L46 32 L56 22"
          fill="none"
          stroke="var(--background)"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="56" cy="22" r="3.5" fill="var(--background)" />
      </svg>
      <span
        className={cn(
          "font-display tracking-tight transition-all duration-500",
          scrolled ? "text-xl" : "text-2xl"
        )}
      >
        {siteConfig.name}
      </span>
      {variant === "default" && (
        <span
          className={cn(
            "text-muted-foreground font-mono transition-all duration-500",
            scrolled ? "text-[10px] mt-0.5" : "text-xs mt-1"
          )}
        >
          TM
        </span>
      )}
    </Link>
  );
}
