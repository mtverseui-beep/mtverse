"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Logo } from "@/components/site/logo";
import { ThemeToggle } from "@/components/site/theme-toggle";
import { AnimatedWave } from "@/components/landing/animated-wave";

interface AuthShellProps {
  children: React.ReactNode;
  title: string;
  description: string;
  footer?: React.ReactNode;
}

export function AuthShell({ children, title, description, footer }: AuthShellProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 lg:px-12 py-6 flex items-center justify-between">
        <Logo />
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link
            href="/"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors hidden sm:block"
          >
            Back to home
          </Link>
        </div>
      </header>

      <div className="flex-1 grid lg:grid-cols-2">
        {/* Left: form */}
        <div className="flex items-center justify-center px-6 lg:px-12 py-12">
          <div className="w-full max-w-sm">
            <h1 className="text-3xl lg:text-4xl font-display tracking-tight mb-3">
              {title}
            </h1>
            <p className="text-muted-foreground leading-relaxed mb-8">
              {description}
            </p>
            {children}
            {footer && <div className="mt-8 text-sm text-muted-foreground">{footer}</div>}
          </div>
        </div>

        {/* Right: abstract visual */}
        <div className="hidden lg:block relative bg-foreground/[0.02] border-l border-foreground/10 overflow-hidden">
          <div className="absolute inset-0 opacity-30 pointer-events-none">
            <div
              className={`transition-opacity duration-700 ${mounted ? "opacity-100" : "opacity-0"}`}
            >
              <AnimatedWave />
            </div>
          </div>
          <div className="relative h-full flex flex-col justify-between p-12">
            <div className="space-y-4 max-w-md">
              <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground">
                <span className="w-8 h-px bg-foreground/30" />
                Why PagePulse
              </span>
              <p className="text-3xl font-display leading-tight tracking-tight">
                Catch the regression before
                <br />
                your users do.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Real-user LCP, INP, CLS, FCP, and TTFB captured on every
                pageview, then sliced by route, device, browser, and country.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4 max-w-md">
              <div className="border border-foreground/10 p-4 bg-background/80 backdrop-blur-sm">
                <div className="font-display text-3xl">98</div>
                <div className="text-xs text-muted-foreground mt-1">Perf score</div>
              </div>
              <div className="border border-foreground/10 p-4 bg-background/80 backdrop-blur-sm">
                <div className="font-display text-3xl">1.9s</div>
                <div className="text-xs text-muted-foreground mt-1">LCP p75</div>
              </div>
              <div className="border border-foreground/10 p-4 bg-background/80 backdrop-blur-sm">
                <div className="font-display text-3xl">96<span className="text-base">ms</span></div>
                <div className="text-xs text-muted-foreground mt-1">INP p75</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
