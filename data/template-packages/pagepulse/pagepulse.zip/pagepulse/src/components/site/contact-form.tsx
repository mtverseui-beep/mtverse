"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";

interface FormState {
  name: string;
  email: string;
  company: string;
  topic: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

const topics = [
  { value: "sales", label: "Talk to sales" },
  { value: "support", label: "Technical support" },
  { value: "partnership", label: "Partnership" },
  { value: "press", label: "Press inquiry" },
  { value: "other", label: "Other" },
];

export function ContactForm() {
  const [form, setForm] = useState<FormState>({
    name: "",
    email: "",
    company: "",
    topic: "sales",
    message: "",
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validate = (): boolean => {
    const next: FormErrors = {};
    if (!form.name.trim()) {
      next.name = "Please enter your name.";
    }
    if (!form.email.trim()) {
      next.email = "Please enter your email.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      next.email = "Please enter a valid email address.";
    }
    if (!form.message.trim()) {
      next.message = "Please enter a message.";
    } else if (form.message.trim().length < 10) {
      next.message = "Message must be at least 10 characters.";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleChange = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [key as keyof FormErrors]: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      toast.error("Please fix the errors in the form.");
      return;
    }
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 900));
    setSubmitting(false);
    setSubmitted(true);
    toast.success("Message sent", {
      description: "We will reply within one business day.",
    });
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto px-6 lg:px-12 pb-24 lg:pb-32">
        <div className="border border-foreground/10 p-10 lg:p-12 text-center">
          <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-6">
            <svg className="w-6 h-6 text-green-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6L9 17l-5-5" />
            </svg>
          </div>
          <h2 className="text-2xl lg:text-3xl font-display mb-3">Message sent</h2>
          <p className="text-muted-foreground leading-relaxed mb-6">
            Thanks for reaching out, {form.name.split(" ")[0]}. Our team will
            reply to <span className="font-mono text-foreground">{form.email}</span> within
            one business day.
          </p>
          <Button
            variant="outline"
            onClick={() => {
              setSubmitted(false);
              setForm({ name: "", email: "", company: "", topic: "sales", message: "" });
            }}
          >
            Send another message
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-6 lg:px-12 pb-24 lg:pb-32">
      <form onSubmit={handleSubmit} noValidate className="space-y-6">
        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label htmlFor="name" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Name *
            </label>
            <input
              id="name"
              type="text"
              required
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className={`w-full px-3 py-2.5 bg-transparent border focus:outline-none transition-colors ${
                errors.name
                  ? "border-red-500 focus:border-red-500"
                  : "border-foreground/15 focus:border-foreground/40"
              }`}
              aria-invalid={!!errors.name}
              aria-describedby={errors.name ? "name-error" : undefined}
            />
            {errors.name && (
              <p id="name-error" className="text-xs text-red-600 mt-1.5">
                {errors.name}
              </p>
            )}
          </div>
          <div>
            <label htmlFor="email" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Email *
            </label>
            <input
              id="email"
              type="email"
              required
              value={form.email}
              onChange={(e) => handleChange("email", e.target.value)}
              className={`w-full px-3 py-2.5 bg-transparent border focus:outline-none transition-colors ${
                errors.email
                  ? "border-red-500 focus:border-red-500"
                  : "border-foreground/15 focus:border-foreground/40"
              }`}
              aria-invalid={!!errors.email}
              aria-describedby={errors.email ? "email-error" : undefined}
            />
            {errors.email && (
              <p id="email-error" className="text-xs text-red-600 mt-1.5">
                {errors.email}
              </p>
            )}
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label htmlFor="company" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Company
            </label>
            <input
              id="company"
              type="text"
              value={form.company}
              onChange={(e) => handleChange("company", e.target.value)}
              className="w-full px-3 py-2.5 bg-transparent border border-foreground/15 focus:border-foreground/40 focus:outline-none transition-colors"
            />
          </div>
          <div>
            <label htmlFor="topic" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Topic
            </label>
            <select
              id="topic"
              value={form.topic}
              onChange={(e) => handleChange("topic", e.target.value)}
              className="w-full px-3 py-2.5 bg-transparent border border-foreground/15 focus:border-foreground/40 focus:outline-none transition-colors"
            >
              {topics.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="message" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            Message *
          </label>
          <textarea
            id="message"
            required
            rows={6}
            value={form.message}
            onChange={(e) => handleChange("message", e.target.value)}
            className={`w-full px-3 py-2.5 bg-transparent border focus:outline-none transition-colors resize-y ${
              errors.message
                ? "border-red-500 focus:border-red-500"
                : "border-foreground/15 focus:border-foreground/40"
            }`}
            aria-invalid={!!errors.message}
            aria-describedby={errors.message ? "message-error" : undefined}
          />
          {errors.message && (
            <p id="message-error" className="text-xs text-red-600 mt-1.5">
              {errors.message}
            </p>
          )}
        </div>

        <div className="flex items-center justify-between gap-4 pt-2">
          <p className="text-xs text-muted-foreground">
            We typically reply within one business day.
          </p>
          <Button
            type="submit"
            disabled={submitting}
            className="bg-foreground hover:bg-foreground/90 text-background rounded-full px-6"
          >
            {submitting ? (
              <>
                <span className="w-4 h-4 border-2 border-background/30 border-t-background rounded-full animate-spin" />
                Sending...
              </>
            ) : (
              <>
                Send message
                <Send className="w-3.5 h-3.5" />
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
