"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { blogPosts, blogCategories } from "@/lib/blog-posts";
import { cn } from "@/lib/utils";
import { ArrowRight, Search } from "lucide-react";

export function BlogList() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("All");

  const filtered = useMemo(() => {
    return blogPosts.filter((post) => {
      const matchesCategory = activeCategory === "All" || post.category === activeCategory;
      const matchesQuery =
        query.trim() === "" ||
        post.title.toLowerCase().includes(query.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(query.toLowerCase()) ||
        post.category.toLowerCase().includes(query.toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [query, activeCategory]);

  return (
    <div className="max-w-[1400px] mx-auto px-6 lg:px-12 pb-24 lg:pb-32">
      <div className="grid lg:grid-cols-12 gap-12 lg:gap-16">
        <aside className="lg:col-span-3">
          <div className="lg:sticky lg:top-32 space-y-8">
            <div>
              <label htmlFor="blog-search" className="sr-only">
                Search posts
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input
                  id="blog-search"
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search posts..."
                  className="w-full pl-9 pr-3 py-2 text-sm bg-transparent border border-foreground/15 focus:border-foreground/40 focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <h3 className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4">
                Categories
              </h3>
              <div className="flex flex-col gap-1">
                <button
                  type="button"
                  onClick={() => setActiveCategory("All")}
                  className={cn(
                    "text-left text-sm py-1.5 px-3 transition-colors",
                    activeCategory === "All"
                      ? "bg-foreground text-background"
                      : "text-muted-foreground hover:text-foreground hover:bg-foreground/5"
                  )}
                >
                  All posts
                </button>
                {blogCategories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setActiveCategory(cat)}
                    className={cn(
                      "text-left text-sm py-1.5 px-3 transition-colors",
                      activeCategory === cat
                        ? "bg-foreground text-background"
                        : "text-muted-foreground hover:text-foreground hover:bg-foreground/5"
                    )}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </aside>

        <div className="lg:col-span-9">
          {filtered.length === 0 ? (
            <div className="py-24 text-center border border-foreground/10">
              <p className="text-muted-foreground mb-2">No posts found.</p>
              <p className="text-sm text-muted-foreground">
                Try a different search or category.
              </p>
            </div>
          ) : (
            <div className="space-y-px bg-foreground/10 border border-foreground/10">
              {filtered.map((post) => (
                <Link
                  key={post.slug}
                  href={`/blog/${post.slug}`}
                  className="group block bg-background p-8 lg:p-10 hover:bg-foreground/[0.02] transition-colors"
                >
                  <div className="flex flex-col lg:flex-row lg:items-center gap-6 lg:gap-12">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-4">
                        <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
                          {post.category}
                        </span>
                        <span className="text-muted-foreground/40">|</span>
                        <span className="font-mono text-xs text-muted-foreground">
                          {post.readTime}
                        </span>
                      </div>
                      <h2 className="text-2xl lg:text-3xl font-display mb-3 group-hover:translate-x-1 transition-transform">
                        {post.title}
                      </h2>
                      <p className="text-muted-foreground leading-relaxed">
                        {post.excerpt}
                      </p>
                      <div className="mt-4 text-sm text-muted-foreground">
                        {post.author} · {new Date(post.date).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
                      </div>
                    </div>
                    <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all shrink-0" />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
