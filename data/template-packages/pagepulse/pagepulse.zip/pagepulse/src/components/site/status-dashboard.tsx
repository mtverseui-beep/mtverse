"use client";

import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";
import { CheckCircle2, AlertTriangle, XCircle } from "lucide-react";

type Status = "operational" | "degraded" | "partial" | "major" | "maintenance";
type IncidentSeverity = "minor" | "major" | "maintenance";

interface Component {
  name: string;
  status: Status;
  description: string;
  uptime: number;
}

const components: Component[] = [
  { name: "RUM ingestion API", status: "operational", description: "Beacon collection from browser SDK", uptime: 99.998 },
  { name: "Web Vitals pipeline", status: "operational", description: "LCP, INP, CLS, FCP, TTFB processing", uptime: 99.999 },
  { name: "Dashboard & API", status: "operational", description: "app.pagepulse.dev and REST API", uptime: 99.997 },
  { name: "Deployment diffing", status: "operational", description: "Before/after release comparison engine", uptime: 99.995 },
  { name: "Webhooks delivery", status: "operational", description: "Outbound event delivery and retries", uptime: 99.992 },
  { name: "Alert routing", status: "operational", description: "Slack, email, Linear, Jira delivery", uptime: 99.994 },
  { name: "Report generation", status: "operational", description: "Weekly PDF and CSV report builder", uptime: 99.989 },
  { name: "US East ingestion", status: "operational", description: "Virginia, Oregon, Canada", uptime: 99.999 },
  { name: "EU ingestion", status: "operational", description: "Frankfurt, London, Amsterdam", uptime: 99.997 },
  { name: "Asia Pacific ingestion", status: "operational", description: "Tokyo, Singapore, Sydney", uptime: 99.995 },
];

const statusConfig: Record<Status, { label: string; dot: string; text: string }> = {
  operational: { label: "Operational", dot: "bg-green-500", text: "text-green-600" },
  degraded: { label: "Degraded", dot: "bg-amber-500", text: "text-amber-600" },
  partial: { label: "Partial outage", dot: "bg-amber-500", text: "text-amber-600" },
  major: { label: "Major outage", dot: "bg-red-500", text: "text-red-600" },
  maintenance: { label: "Maintenance", dot: "bg-foreground/40", text: "text-muted-foreground" },
};

interface Incident {
  date: string;
  title: string;
  severity: IncidentSeverity;
  status: "resolved" | "monitoring" | "investigating";
  duration: string;
  summary: string;
  updates: { time: string; text: string }[];
}

const incidents: Incident[] = [
  {
    date: "2025-06-22",
    title: "Elevated webhook delivery latency in EU region",
    severity: "minor",
    status: "resolved",
    duration: "47 minutes",
    summary:
      "Webhook deliveries from the Frankfurt region experienced an additional 2-3 second latency between 14:12 and 14:59 UTC. No webhooks were dropped. Root cause was a Redis failover that triggered additional retry overhead.",
    updates: [
      { time: "14:12 UTC", text: "We are investigating reports of elevated webhook delivery latency in the EU region." },
      { time: "14:38 UTC", text: "Identified the cause as a Redis failover in the Frankfurt region. Implementing mitigation." },
      { time: "14:59 UTC", text: "Webhook delivery latency has returned to normal. We will monitor for the next hour." },
      { time: "16:00 UTC", text: "Incident resolved. No further action required." },
    ],
  },
  {
    date: "2025-06-08",
    title: "Scheduled maintenance: dashboard database upgrade",
    severity: "maintenance",
    status: "resolved",
    duration: "12 minutes",
    summary:
      "We upgraded the dashboard database to a larger instance class to support the growing number of projects on Scale plans. The dashboard was briefly read-only during the upgrade window.",
    updates: [
      { time: "02:00 UTC", text: "Scheduled maintenance window begins. Dashboard is now read-only." },
      { time: "02:12 UTC", text: "Database upgrade complete. Dashboard is back to full read/write." },
    ],
  },
  {
    date: "2025-05-19",
    title: "RUM ingestion delayed for Vercel deployments",
    severity: "minor",
    status: "resolved",
    duration: "1 hour 14 minutes",
    summary:
      "RUM samples from Vercel-hosted customer sites were delayed by up to 90 seconds between 09:18 and 10:32 UTC due to a backpressure issue in our edge ingestion layer. No data was lost; all samples were eventually processed.",
    updates: [
      { time: "09:18 UTC", text: "We are investigating delayed RUM ingestion from Vercel deployments." },
      { time: "09:45 UTC", text: "Root cause identified as backpressure in the edge ingestion layer. Scaling capacity." },
      { time: "10:32 UTC", text: "Ingestion backlog cleared. All RUM samples have been processed." },
    ],
  },
];

const severityConfig: Record<IncidentSeverity, { label: string; className: string }> = {
  minor: { label: "Minor incident", className: "bg-amber-500/15 text-amber-700" },
  major: { label: "Major incident", className: "bg-red-500/15 text-red-700" },
  maintenance: { label: "Maintenance", className: "bg-foreground/10 text-foreground" },
};

export function StatusDashboard() {
  const [filter, setFilter] = useState<IncidentSeverity | "all">("all");

  const filteredIncidents = useMemo(() => {
    if (filter === "all") return incidents;
    return incidents.filter((i) => i.severity === filter);
  }, [filter]);

  const overall: Status = components.every((c) => c.status === "operational")
    ? "operational"
    : "degraded";

  return (
    <div className="max-w-[1400px] mx-auto px-6 lg:px-12 pb-24 lg:pb-32">
      <div className="border border-foreground/10 p-8 lg:p-10 mb-12">
        <div className="flex items-start gap-4">
          <div
            className={cn(
              "w-12 h-12 rounded-full flex items-center justify-center shrink-0",
              overall === "operational" ? "bg-green-500/10" : "bg-amber-500/10"
            )}
          >
            <CheckCircle2
              className={cn(
                "w-6 h-6",
                overall === "operational" ? "text-green-600" : "text-amber-600"
              )}
            />
          </div>
          <div>
            <h2 className="text-2xl lg:text-3xl font-display">
              All systems operational
            </h2>
            <p className="text-muted-foreground mt-1">
              Updated just now · {new Date().toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      <div className="mb-12">
        <h3 className="text-sm font-mono uppercase tracking-widest text-muted-foreground mb-6">
          Components
        </h3>
        <div className="border border-foreground/10 divide-y divide-foreground/10">
          {components.map((c) => {
            const cfg = statusConfig[c.status];
            return (
              <div
                key={c.name}
                className="flex items-center justify-between gap-4 p-5 lg:p-6"
              >
                <div className="flex-1 min-w-0">
                  <div className="font-medium">{c.name}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {c.description}
                  </div>
                </div>
                <div className="hidden sm:block text-xs font-mono text-muted-foreground text-right shrink-0">
                  {c.uptime.toFixed(3)}%
                  <div className="text-[10px] text-muted-foreground/60">30-day uptime</div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={cn("w-2 h-2 rounded-full", cfg.dot)} />
                  <span className={cn("text-xs font-mono uppercase tracking-widest", cfg.text)}>
                    {cfg.label}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-sm font-mono uppercase tracking-widest text-muted-foreground mb-6">
          Incident history · last 60 days
        </h3>
        <div className="flex flex-wrap gap-2 mb-6">
          {(["all", "minor", "major", "maintenance"] as const).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={cn(
                "px-3 py-1.5 text-xs font-mono uppercase tracking-widest border transition-colors",
                filter === f
                  ? "bg-foreground text-background border-foreground"
                  : "border-foreground/15 text-muted-foreground hover:text-foreground hover:border-foreground/40"
              )}
            >
              {f === "all" ? "All" : severityConfig[f].label}
            </button>
          ))}
        </div>

        {filteredIncidents.length === 0 ? (
          <div className="border border-foreground/10 p-12 text-center">
            <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-3" />
            <p className="text-muted-foreground">No incidents in this category.</p>
          </div>
        ) : (
          <div className="space-y-px bg-foreground/10 border border-foreground/10">
            {filteredIncidents.map((inc) => {
              const sev = severityConfig[inc.severity];
              return (
                <article key={`${inc.date}-${inc.title}`} className="bg-background p-6 lg:p-8">
                  <div className="flex flex-wrap items-center gap-3 mb-3">
                    <span
                      className={cn(
                        "inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-mono uppercase tracking-widest",
                        sev.className
                      )}
                    >
                      {inc.severity === "major" ? (
                        <XCircle className="w-2.5 h-2.5" />
                      ) : inc.severity === "minor" ? (
                        <AlertTriangle className="w-2.5 h-2.5" />
                      ) : (
                        <CheckCircle2 className="w-2.5 h-2.5" />
                      )}
                      {sev.label}
                    </span>
                    <time className="text-xs font-mono text-muted-foreground">
                      {new Date(inc.date).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </time>
                    <span className="text-xs font-mono text-muted-foreground">·</span>
                    <span className="text-xs font-mono text-muted-foreground">
                      Duration: {inc.duration}
                    </span>
                    <span className="ml-auto inline-flex items-center gap-1 text-[10px] font-mono uppercase tracking-widest text-green-600">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      Resolved
                    </span>
                  </div>
                  <h4 className="text-xl font-display mb-3">{inc.title}</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-5">
                    {inc.summary}
                  </p>
                  <div className="border-l-2 border-foreground/10 pl-4 space-y-2">
                    {inc.updates.map((u, i) => (
                      <div key={i} className="flex gap-3 text-sm">
                        <span className="font-mono text-xs text-muted-foreground shrink-0 w-20">
                          {u.time}
                        </span>
                        <span className="text-foreground/80">{u.text}</span>
                      </div>
                    ))}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      <div className="mt-12 p-6 lg:p-8 border border-foreground/10 bg-foreground/[0.02] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h4 className="font-medium">Subscribe to status updates</h4>
          <p className="text-sm text-muted-foreground mt-1">
            Get an email the moment a component changes state.
          </p>
        </div>
        <form
          className="flex w-full sm:w-auto gap-2"
          onSubmit={(e) => e.preventDefault()}
        >
          <input
            type="email"
            required
            placeholder="you@company.com"
            aria-label="Email address"
            className="flex-1 sm:w-64 px-3 py-2 text-sm bg-transparent border border-foreground/15 focus:border-foreground/40 focus:outline-none"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-foreground text-background text-sm hover:bg-foreground/90 transition-colors"
          >
            Subscribe
          </button>
        </form>
      </div>
    </div>
  );
}
