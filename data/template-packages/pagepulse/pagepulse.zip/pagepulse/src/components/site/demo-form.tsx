"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";
import { cn } from "@/lib/utils";

interface DemoFormState {
  name: string;
  workEmail: string;
  company: string;
  websiteUrl: string;
  teamSize: string;
  useCase: string;
  framework: string;
  message: string;
}

interface FormErrors {
  name?: string;
  workEmail?: string;
  company?: string;
  websiteUrl?: string;
  teamSize?: string;
  useCase?: string;
}

const teamSizes = [
  { value: "1-5", label: "1-5 engineers" },
  { value: "6-20", label: "6-20 engineers" },
  { value: "21-50", label: "21-50 engineers" },
  { value: "51-200", label: "51-200 engineers" },
  { value: "200+", label: "200+ engineers" },
];

const useCases = [
  { value: "core-web-vitals", label: "Improve Core Web Vitals" },
  { value: "deployment-impact", label: "Catch release regressions" },
  { value: "performance-budgets", label: "Enforce performance budgets" },
  { value: "real-user-monitoring", label: "Real user monitoring" },
  { value: "agency", label: "Agency client reporting" },
  { value: "other", label: "Other" },
];

const frameworks = [
  "Next.js",
  "React",
  "Vue",
  "Nuxt",
  "Remix",
  "Astro",
  "Other",
];

export function DemoForm() {
  const [form, setForm] = useState<DemoFormState>({
    name: "",
    workEmail: "",
    company: "",
    websiteUrl: "",
    teamSize: "",
    useCase: "",
    framework: "Next.js",
    message: "",
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validate = (): boolean => {
    const next: FormErrors = {};
    if (!form.name.trim()) next.name = "Please enter your name.";
    if (!form.workEmail.trim()) {
      next.workEmail = "Please enter your work email.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.workEmail)) {
      next.workEmail = "Please enter a valid email address.";
    } else if (/@(gmail|yahoo|outlook|hotmail|icloud)\./i.test(form.workEmail)) {
      next.workEmail = "Please use a work email address.";
    }
    if (!form.company.trim()) next.company = "Please enter your company.";
    if (!form.websiteUrl.trim()) {
      next.websiteUrl = "Please enter your website URL.";
    } else if (!/^https?:\/\/.+/.test(form.websiteUrl)) {
      next.websiteUrl = "URL must start with http:// or https://";
    }
    if (!form.teamSize) next.teamSize = "Please select a team size.";
    if (!form.useCase) next.useCase = "Please select a primary use case.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleChange = <K extends keyof DemoFormState>(key: K, value: DemoFormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [key as keyof FormErrors]: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      toast.error("Please fix the errors in the form.");
      return;
    }
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 1100));
    setSubmitting(false);
    setSubmitted(true);
    toast.success("Demo requested", {
      description: "Our team will reach out within one business day.",
    });
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto px-6 lg:px-12 pb-24 lg:pb-32">
        <div className="border border-foreground/10 p-10 lg:p-12 text-center">
          <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-6">
            <svg className="w-6 h-6 text-green-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6L9 17l-5-5" />
            </svg>
          </div>
          <h2 className="text-2xl lg:text-3xl font-display mb-3">Demo requested</h2>
          <p className="text-muted-foreground leading-relaxed mb-6">
            Thanks, {form.name.split(" ")[0]}. A product specialist will reach
            out to <span className="font-mono text-foreground">{form.workEmail}</span> within
            one business day to schedule a 30-minute walkthrough of PagePulse
            tailored to {form.company}.
          </p>
          <div className="grid grid-cols-2 gap-4 text-left mb-6">
            <div className="border border-foreground/10 p-4">
              <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">
                What to expect
              </div>
              <div className="text-sm">A 30-minute Zoom call</div>
            </div>
            <div className="border border-foreground/10 p-4">
              <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">
                What we cover
              </div>
              <div className="text-sm">Your stack, your routes, your goals</div>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={() => {
              setSubmitted(false);
              setForm({
                name: "",
                workEmail: "",
                company: "",
                websiteUrl: "",
                teamSize: "",
                useCase: "",
                framework: "Next.js",
                message: "",
              });
            }}
          >
            Submit another request
          </Button>
        </div>
      </div>
    );
  }

  const inputClass = (hasError?: boolean) =>
    cn(
      "w-full px-3 py-2.5 bg-transparent border focus:outline-none transition-colors",
      hasError
        ? "border-red-500 focus:border-red-500"
        : "border-foreground/15 focus:border-foreground/40"
    );

  return (
    <div className="max-w-2xl mx-auto px-6 lg:px-12 pb-24 lg:pb-32">
      <form onSubmit={handleSubmit} noValidate className="space-y-6">
        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label htmlFor="name" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Name *
            </label>
            <input
              id="name"
              type="text"
              required
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className={inputClass(!!errors.name)}
              aria-invalid={!!errors.name}
            />
            {errors.name && <p className="text-xs text-red-600 mt-1.5">{errors.name}</p>}
          </div>
          <div>
            <label htmlFor="workEmail" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Work email *
            </label>
            <input
              id="workEmail"
              type="email"
              required
              value={form.workEmail}
              onChange={(e) => handleChange("workEmail", e.target.value)}
              className={inputClass(!!errors.workEmail)}
              aria-invalid={!!errors.workEmail}
              placeholder="you@company.com"
            />
            {errors.workEmail && <p className="text-xs text-red-600 mt-1.5">{errors.workEmail}</p>}
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label htmlFor="company" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Company *
            </label>
            <input
              id="company"
              type="text"
              required
              value={form.company}
              onChange={(e) => handleChange("company", e.target.value)}
              className={inputClass(!!errors.company)}
              aria-invalid={!!errors.company}
            />
            {errors.company && <p className="text-xs text-red-600 mt-1.5">{errors.company}</p>}
          </div>
          <div>
            <label htmlFor="websiteUrl" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Website URL *
            </label>
            <input
              id="websiteUrl"
              type="url"
              required
              value={form.websiteUrl}
              onChange={(e) => handleChange("websiteUrl", e.target.value)}
              className={inputClass(!!errors.websiteUrl)}
              aria-invalid={!!errors.websiteUrl}
              placeholder="https://your-site.com"
            />
            {errors.websiteUrl && <p className="text-xs text-red-600 mt-1.5">{errors.websiteUrl}</p>}
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">
              Team size *
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {teamSizes.map((ts) => (
                <button
                  key={ts.value}
                  type="button"
                  onClick={() => handleChange("teamSize", ts.value)}
                  className={cn(
                    "px-3 py-2 text-xs font-mono border transition-colors",
                    form.teamSize === ts.value
                      ? "bg-foreground text-background border-foreground"
                      : "border-foreground/15 text-muted-foreground hover:text-foreground hover:border-foreground/40"
                  )}
                >
                  {ts.label}
                </button>
              ))}
            </div>
            {errors.teamSize && <p className="text-xs text-red-600 mt-1.5">{errors.teamSize}</p>}
          </div>
          <div>
            <label className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">
              Primary use case *
            </label>
            <div className="grid grid-cols-2 gap-2">
              {useCases.map((uc) => (
                <button
                  key={uc.value}
                  type="button"
                  onClick={() => handleChange("useCase", uc.value)}
                  className={cn(
                    "px-3 py-2 text-xs font-mono border transition-colors text-left",
                    form.useCase === uc.value
                      ? "bg-foreground text-background border-foreground"
                      : "border-foreground/15 text-muted-foreground hover:text-foreground hover:border-foreground/40"
                  )}
                >
                  {uc.label}
                </button>
              ))}
            </div>
            {errors.useCase && <p className="text-xs text-red-600 mt-1.5">{errors.useCase}</p>}
          </div>
        </div>

        <div>
          <label htmlFor="framework" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            Primary framework
          </label>
          <select
            id="framework"
            value={form.framework}
            onChange={(e) => handleChange("framework", e.target.value)}
            className="w-full px-3 py-2.5 bg-transparent border border-foreground/15 focus:border-foreground/40 focus:outline-none transition-colors"
          >
            {frameworks.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="message" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            Anything else?
          </label>
          <textarea
            id="message"
            rows={4}
            value={form.message}
            onChange={(e) => handleChange("message", e.target.value)}
            className="w-full px-3 py-2.5 bg-transparent border border-foreground/15 focus:border-foreground/40 focus:outline-none transition-colors resize-y"
            placeholder="Tell us about your current performance pain points."
          />
        </div>

        <div className="flex items-center justify-between gap-4 pt-2">
          <p className="text-xs text-muted-foreground">
            30-minute walkthrough · No commitment
          </p>
          <Button
            type="submit"
            disabled={submitting}
            className="bg-foreground hover:bg-foreground/90 text-background rounded-full px-6"
          >
            {submitting ? (
              <>
                <span className="w-4 h-4 border-2 border-background/30 border-t-background rounded-full animate-spin" />
                Requesting...
              </>
            ) : (
              <>
                Request demo
                <Send className="w-3.5 h-3.5" />
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
