"use client";

import { useState } from "react";
import { Copy, Check } from "lucide-react";
import { toast } from "sonner";
import type { BlogBlock } from "@/lib/blog-posts";

interface BlogContentProps {
  content: BlogBlock[];
}

export function BlogContent({ content }: BlogContentProps) {
  return (
    <div className="space-y-6">
      {content.map((block, i) => {
        if (block.type === "heading") {
          return (
            <h2 key={i} className="text-2xl lg:text-3xl font-display tracking-tight mt-12 mb-4">
              {block.text}
            </h2>
          );
        }
        if (block.type === "paragraph") {
          return (
            <p key={i} className="text-lg text-foreground/80 leading-relaxed">
              {block.text}
            </p>
          );
        }
        if (block.type === "list") {
          return (
            <ul key={i} className="space-y-3 my-6">
              {block.items.map((item, j) => (
                <li key={j} className="text-lg text-foreground/80 leading-relaxed flex gap-3">
                  <span className="text-foreground/40 font-mono text-sm mt-1.5 shrink-0">
                    {String(j + 1).padStart(2, "0")}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          );
        }
        if (block.type === "code") {
          return <CodeBlock key={i} code={block.code} language={block.language} />;
        }
        return null;
      })}
    </div>
  );
}

function CodeBlock({ code, language }: { code: string; language: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Could not copy code");
    }
  };

  return (
    <div className="my-8 border border-foreground/10 overflow-hidden">
      <div className="px-4 py-2 border-b border-foreground/10 flex items-center justify-between bg-foreground/[0.02]">
        <span className="text-xs font-mono text-muted-foreground">{language}</span>
        <button
          type="button"
          onClick={handleCopy}
          className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5 text-xs font-mono"
          aria-label="Copy code"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-green-600" />
              Copied
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              Copy
            </>
          )}
        </button>
      </div>
      <pre className="p-6 font-mono text-sm overflow-x-auto leading-relaxed">
        <code className="text-foreground/80">{code}</code>
      </pre>
    </div>
  );
}
