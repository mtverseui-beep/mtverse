"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * GoToTopButton — appears after the user scrolls past 600px and smoothly
 * scrolls back to the top on click. Performance-optimized:
 *   - passive scroll listener
 *   - throttled with requestAnimationFrame
 *   - state only changes when visibility toggles (no per-frame re-renders)
 */
export function GoToTopButton() {
  const [visible, setVisible] = useState(false);
  const tickingRef = useRef(false);
  const lastVisibleRef = useRef(false);

  useEffect(() => {
    const handleScroll = () => {
      if (tickingRef.current) return;
      tickingRef.current = true;
      // Use rAF so we never block the scroll thread
      window.requestAnimationFrame(() => {
        const shouldShow = window.scrollY > 600;
        // Only update state when visibility actually changes — avoids
        // cascading re-renders on every scroll tick.
        if (shouldShow !== lastVisibleRef.current) {
          lastVisibleRef.current = shouldShow;
          setVisible(shouldShow);
        }
        tickingRef.current = false;
      });
    };

    // passive: true so the browser never waits for our handler
    window.addEventListener("scroll", handleScroll, { passive: true });
    // Initial check (in case the page loads scrolled)
    handleScroll();

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    // Honor prefers-reduced-motion
    const prefersReduced =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: prefersReduced ? "auto" : "smooth",
    });
  };

  return (
    <button
      type="button"
      onClick={scrollToTop}
      aria-label="Scroll back to top"
      tabIndex={visible ? 0 : -1}
      className={cn(
        "fixed bottom-6 right-6 z-40 w-11 h-11 rounded-full border border-foreground/15 bg-background/80 backdrop-blur-md flex items-center justify-center shadow-sm",
        "hover:bg-foreground hover:text-background hover:border-foreground transition-colors duration-200",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-foreground/40 focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        visible
          ? "opacity-100 translate-y-0 pointer-events-auto"
          : "opacity-0 translate-y-4 pointer-events-none"
      )}
      style={{
        transition:
          "opacity 250ms cubic-bezier(0.22, 1, 0.36, 1), transform 250ms cubic-bezier(0.22, 1, 0.36, 1), background-color 200ms ease, color 200ms ease, border-color 200ms ease",
      }}
    >
      <ArrowUp className="w-4 h-4" aria-hidden="true" />
    </button>
  );
}
