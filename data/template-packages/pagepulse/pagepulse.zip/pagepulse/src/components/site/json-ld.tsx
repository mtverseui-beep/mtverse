export function FaqJsonLd({ faqs }: { faqs: { question: string; answer: string }[] }) {
  const data = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: f.answer,
      },
    })),
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function SoftwareAppJsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: "PagePulse",
    applicationCategory: "DeveloperApplication",
    operatingSystem: "Web",
    description:
      "Monitor Core Web Vitals, page speed, JavaScript performance, deployment impact, and user experience from one frontend analytics platform.",
    offers: [
      {
        "@type": "Offer",
        name: "Starter",
        price: "19",
        priceCurrency: "USD",
        billingIncrement: "P1M",
      },
      {
        "@type": "Offer",
        name: "Growth",
        price: "49",
        priceCurrency: "USD",
        billingIncrement: "P1M",
      },
      {
        "@type": "Offer",
        name: "Scale",
        price: "149",
        priceCurrency: "USD",
        billingIncrement: "P1M",
      },
    ],
    publisher: {
      "@type": "Organization",
      name: "PagePulse, Inc.",
    },
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function OrganizationJsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "PagePulse, Inc.",
    url: "https://pagepulse.dev",
    logo: "https://pagepulse.dev/icon.svg",
    sameAs: [
      "https://twitter.com/pagepulse",
      "https://github.com/pagepulse",
      "https://linkedin.com/company/pagepulse",
    ],
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "customer support",
      email: "support@pagepulse.dev",
    },
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
