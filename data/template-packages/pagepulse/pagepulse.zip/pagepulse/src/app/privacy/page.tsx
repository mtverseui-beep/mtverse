import type { Metadata } from "next";
import { LegalPage } from "@/components/site/legal-page";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "How PagePulse collects, uses, and protects performance data. Cookie-free mode, GDPR-ready workflows, and data retention controls.",
  alternates: { canonical: "/privacy" },
};

const sidebar = [
  { label: "Privacy Policy", href: "/privacy", active: true },
  { label: "Terms of Service", href: "/terms" },
  { label: "Data Processing Addendum", href: "/dpa" },
  { label: "Cookie Policy", href: "/cookies" },
];

const sections = [
  {
    heading: "1. Overview",
    body: [
      "PagePulse, Inc. (\u201CPagePulse\u201D, \u201Cwe\u201D, \u201Cus\u201D) operates a frontend performance monitoring platform that measures Core Web Vitals, JavaScript performance, and deployment impact for customer websites. This Privacy Policy explains what data we collect, why we collect it, how long we keep it, and the controls you have over it.",
      "We designed PagePulse to measure timings, not people. We do not record session replays, capture keystrokes, log personal browsing history, or build user profiles for advertising. Our default collection mode is cookie-free, which means we do not set any cookies in your end users' browsers unless you explicitly enable an optional feature that requires them.",
    ],
  },
  {
    heading: "2. Data we collect",
    body: [
      "We collect two categories of data: account data and performance telemetry.",
    ],
    subsections: [
      {
        heading: "2.1 Account data",
        body: [
          "When you create a PagePulse account, we collect your name, work email address, company name, and billing information. Billing is handled by our payment processor; we never store full card numbers on our infrastructure. We also retain audit logs of dashboard actions, API calls, and configuration changes you or your team members perform.",
        ],
      },
      {
        heading: "2.2 Performance telemetry",
        body: [
          "When the PagePulse browser SDK runs on a customer website, it collects the following timing data: Core Web Vitals (LCP, INP, CLS, FCP, TTFB), route URL (path only, never query string), device class (e.g. \u201Cmobile\u201D), browser family (e.g. \u201CChrome\u201D), country (derived from IP address, then discarded), connection type (e.g. \u201C4G\u201D), and any custom metrics you explicitly track.",
          "We do not collect IP addresses on a persistent basis. IP addresses are used momentarily to derive country-level geolocation, then discarded within 60 seconds of ingestion. We never use IP addresses for fingerprinting, cross-site tracking, or advertising.",
        ],
      },
    ],
  },
  {
    heading: "3. How we use data",
    body: [
      "We use account data to operate your workspace, manage billing, and provide support. We use performance telemetry to power the dashboards, alerts, reports, and deployment impact diffing you see inside PagePulse.",
      "We do not sell your data. We do not share your data with third parties for advertising purposes. We do not use your data to train machine learning models that benefit anyone other than your own workspace.",
    ],
  },
  {
    heading: "4. Data retention",
    body: [
      "You control how long we keep your performance telemetry. The default retention period depends on your plan: 7 days on Starter, 90 days on Growth, and 365 days or custom on Scale. You can shorten or extend retention at any time from your workspace settings.",
      "When you delete a project, we hard-delete all associated telemetry within 30 days. When you close your account, we hard-delete all data across all projects within 30 days. Audit logs are retained for 7 years to comply with SOC 2 and ISO 27001 requirements.",
    ],
  },
  {
    heading: "5. International data transfers",
    body: [
      "PagePulse operates collection regions in the United States, European Union, and Asia Pacific. Customer telemetry is processed in the region closest to the end user, then stored in your chosen primary region. EU customers can elect EU-only data residency, in which case telemetry from non-EU end users is forwarded to the EU region for storage.",
      "We rely on Standard Contractual Clauses (SCCs) for any transfer of personal data from the European Economic Area to a third country. A signed copy of the SCCs is available on request.",
    ],
  },
  {
    heading: "6. Your rights",
    body: [
      "Under the GDPR, CCPA, and similar regulations, you have the right to access, correct, export, or delete the personal data we hold about you. For account data, you can exercise these rights directly from your workspace settings. For end-user telemetry, your workspace admin can submit a data subject access request to support@pagepulse.dev and we will respond within 72 hours.",
      "You have the right to lodge a complaint with your local data protection authority. We encourage you to contact us first so we can resolve the issue directly.",
    ],
  },
  {
    heading: "7. Security",
    body: [
      "PagePulse is SOC 2 Type II and ISO 27001 certified. All data is encrypted at rest with AES-256 and in transit with TLS 1.3. Encryption keys are rotated every 90 days. Access to production infrastructure is restricted to a small group of engineers and is logged for audit.",
      "We engage independent third parties to perform annual penetration tests. A summary of the most recent test is available on request under NDA. Suspected security incidents should be reported to security@pagepulse.dev.",
    ],
  },
  {
    heading: "8. Sub-processors",
    body: [
      "We use a small number of sub-processors to operate the platform: a cloud hosting provider, a managed database provider, an email delivery service, and a payment processor. Each sub-processor is bound by a data processing agreement that meets GDPR Article 28 requirements.",
      "We provide 30 days' notice before engaging a new sub-processor. You can subscribe to sub-processor updates by emailing support@pagepulse.dev.",
    ],
  },
  {
    heading: "9. Changes to this policy",
    body: [
      "We will notify you by email at least 30 days before this Privacy Policy changes in a material way. A changelog of past versions is available on request. Continued use of PagePulse after the effective date of a new policy constitutes acceptance of the updated terms.",
    ],
  },
];

export default function PrivacyPage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Privacy Policy"
      description="How PagePulse collects, uses, and protects performance data from your websites and applications."
      lastUpdated="June 1, 2025"
      sections={sections}
      sidebar={sidebar}
    />
  );
}
