import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { PerformanceBudgetsSection } from "@/components/landing/performance-budgets-section";
import { CtaSection } from "@/components/landing/cta-section";

export const metadata: Metadata = {
  title: "Performance Budgets",
  description:
    "Set hard limits on JavaScript size, image weight, route speed, and Core Web Vitals. Alert Slack, send webhooks, or fail CI when a budget is breached.",
  alternates: { canonical: "/performance-budgets" },
};

const budgetExamples = [
  {
    metric: "JavaScript size",
    threshold: "180 KB",
    rationale: "Enough for a modern framework, router, and your app code. Forces you to tree-shake and lazy-load.",
  },
  {
    metric: "LCP",
    threshold: "2.5 s",
    rationale: "Google's 'good' threshold at the 75th percentile of real-user traffic.",
  },
  {
    metric: "INP",
    threshold: "200 ms",
    rationale: "Google's 'good' threshold. Interactions over 200ms feel sluggish to most users.",
  },
  {
    metric: "CLS",
    threshold: "0.10",
    rationale: "Google's 'good' threshold. Layout shifts above 0.1 are noticeable and erode trust.",
  },
  {
    metric: "Image weight",
    threshold: "500 KB",
    rationale: "Cap hero and product images. Forces modern formats (AVIF, WebP) and proper srcset.",
  },
  {
    metric: "Route load",
    threshold: "1.0 s",
    rationale: "Per-route budget for client-side navigation. Keeps your app feeling instant.",
  },
];

export default function PerformanceBudgetsPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Performance Budgets"
        title={
          <>
            Performance is
            <br />
            non-negotiable.
          </>
        }
        description="Set hard limits on JavaScript size, image weight, route speed, and Core Web Vitals thresholds. Breaches trigger Slack alerts, webhooks, or fail the CI build before code reaches production."
      />

      <PerformanceBudgetsSection />

      <section className="py-24 lg:py-32 border-t border-foreground/10">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="mb-16">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Recommended budgets
            </span>
            <h2 className="text-4xl lg:text-5xl font-display tracking-tight">
              Sensible defaults to start from.
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mt-6 max-w-2xl">
              These are the budgets we recommend as a starting point. Adjust per
              route based on your actual real-user data, then tighten over time.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-foreground/10 border border-foreground/10">
            {budgetExamples.map((b) => (
              <div key={b.metric} className="bg-background p-6 lg:p-8">
                <div className="flex items-baseline justify-between mb-3">
                  <span className="text-sm font-mono uppercase tracking-widest text-muted-foreground">
                    {b.metric}
                  </span>
                  <span className="font-display text-2xl">{b.threshold}</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {b.rationale}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection />
    </PageShell>
  );
}
