import type { Metadata } from "next";
import Link from "next/link";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { FeaturesSection } from "@/components/landing/features-section";
import { CtaSection } from "@/components/landing/cta-section";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Features",
  description:
    "Core Web Vitals tracking, deployment impact, performance budgets, real user monitoring, route-level insights, and frontend alerts. Everything you need to ship faster pages.",
  alternates: { canonical: "/features" },
};

const subFeatures = [
  { title: "JavaScript bundle size", href: "/performance-budgets", description: "Track first-party and third-party JS weight on every route, every release." },
  { title: "Hydration time", href: "/performance-monitoring", description: "Measure how long React, Vue, and Next.js take to hydrate on real devices." },
  { title: "Route-level performance", href: "/performance-monitoring", description: "Per-route LCP, INP, and CLS for every page in your app." },
  { title: "Conversion impact", href: "/real-user-monitoring", description: "Correlate slow pages with bounce rate, conversion rate, and revenue." },
];

export default function FeaturesPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Features"
        title={
          <>
            Everything you need
            <br />
            to ship faster pages.
          </>
        }
        description="One platform for Core Web Vitals, real user monitoring, deployment impact, and performance budgets. Built for frontend teams who care about speed."
      />

      <FeaturesSection />

      <section className="py-24 lg:py-32 border-t border-foreground/10">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="mb-16">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Explore deeper
            </span>
            <h2 className="text-4xl lg:text-5xl font-display tracking-tight">
              Go deep on every metric.
            </h2>
          </div>
          <div className="grid md:grid-cols-2 gap-px bg-foreground/10">
            {subFeatures.map((sf) => (
              <Link
                key={sf.title}
                href={sf.href}
                className="group bg-background p-8 lg:p-12 hover:bg-foreground/[0.02] transition-colors"
              >
                <div className="flex items-start justify-between gap-6">
                  <div>
                    <h3 className="text-2xl font-display mb-3 group-hover:translate-x-1 transition-transform">
                      {sf.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">{sf.description}</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all shrink-0 mt-1" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CtaSection />
    </PageShell>
  );
}
