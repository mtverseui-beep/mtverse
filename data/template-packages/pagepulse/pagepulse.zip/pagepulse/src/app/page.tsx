import { Navigation } from "@/components/landing/navigation";
import { HeroSection } from "@/components/landing/hero-section";
import { TrustStrip } from "@/components/landing/trust-strip";
import { CoreWebVitalsSection } from "@/components/landing/core-web-vitals-section";
import { PerformanceProblemSection } from "@/components/landing/performance-problem-section";
import { FeaturesSection } from "@/components/landing/features-section";
import { RumPreviewSection } from "@/components/landing/rum-preview-section";
import { DeploymentImpactSection } from "@/components/landing/deployment-impact-section";
import { PerformanceBudgetsSection } from "@/components/landing/performance-budgets-section";
import { MetricsSection } from "@/components/landing/metrics-section";
import { IntegrationsSection } from "@/components/landing/integrations-section";
import { DevelopersSection } from "@/components/landing/developers-section";
import { ReportPreviewSection } from "@/components/landing/report-preview-section";
import { SecuritySection } from "@/components/landing/security-section";
import { TestimonialsSection } from "@/components/landing/testimonials-section";
import { PricingSection } from "@/components/landing/pricing-section";
import { FaqSection } from "@/components/landing/faq-section";
import { CtaSection } from "@/components/landing/cta-section";
import { FooterSection } from "@/components/landing/footer-section";
import { FaqJsonLd, SoftwareAppJsonLd, OrganizationJsonLd } from "@/components/site/json-ld";
import { faqs } from "@/lib/faqs";

export default function Home() {
  return (
    <main className="relative min-h-screen overflow-x-hidden noise-overlay">
      <FaqJsonLd faqs={faqs} />
      <SoftwareAppJsonLd />
      <OrganizationJsonLd />
      <Navigation />
      <HeroSection />
      <TrustStrip />
      <CoreWebVitalsSection />
      <PerformanceProblemSection />
      <FeaturesSection />
      <RumPreviewSection />
      <DeploymentImpactSection />
      <PerformanceBudgetsSection />
      <MetricsSection />
      <IntegrationsSection />
      <DevelopersSection />
      <ReportPreviewSection />
      <SecuritySection />
      <TestimonialsSection />
      <PricingSection />
      <FaqSection />
      <CtaSection />
      <FooterSection />
    </main>
  );
}
