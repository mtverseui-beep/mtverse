import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { DeploymentImpactSection } from "@/components/landing/deployment-impact-section";
import { CtaSection } from "@/components/landing/cta-section";

export const metadata: Metadata = {
  title: "Deployment Impact",
  description:
    "Compare Core Web Vitals, JavaScript bundle size, route load time, and error rate before and after every release. Catch regressions in minutes.",
  alternates: { canonical: "/deployment-impact" },
};

const steps = [
  {
    number: "01",
    title: "Tag every release",
    description:
      "Call PagePulse.deployment from your CI/CD pipeline with version, commit, and environment. PagePulse automatically correlates every RUM sample, every error, and every bundle-size measurement with the release that produced it.",
  },
  {
    number: "02",
    title: "Read the diff",
    description:
      "For every release, PagePulse generates a side-by-side diff of LCP, INP, CLS, FCP, TTFB, JavaScript bundle size, route load time, hydration time, and error rate. Statistically significant regressions are highlighted automatically.",
  },
  {
    number: "03",
    title: "Get alerted in minutes",
    description:
      "When a release regresses LCP by more than 10%, INP by more than 20%, or CLS by more than 0.05, PagePulse can alert you in Slack, Linear, Jira, or any webhook within five minutes of going live.",
  },
  {
    number: "04",
    title: "Decide: ship or roll back",
    description:
      "The deployment diff includes a recommendation: ship it, monitor, or roll back. Every decision is backed by per-route breakdowns and statistical significance, not gut feel.",
  },
];

export default function DeploymentImpactPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Deployment Impact"
        title={
          <>
            Catch regressions
            <br />
            before users do.
          </>
        }
        description="Automatically diff Core Web Vitals, JavaScript bundle size, route load time, and error rate between every release. Get alerted in Slack within minutes."
      />

      <DeploymentImpactSection />

      <section className="py-24 lg:py-32 border-t border-foreground/10">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="mb-16">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              How it works
            </span>
            <h2 className="text-4xl lg:text-5xl font-display tracking-tight">
              From commit to confidence in four steps.
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-px bg-foreground/10 border border-foreground/10">
            {steps.map((s) => (
              <div key={s.number} className="bg-background p-8">
                <span className="font-mono text-sm text-muted-foreground block mb-4">
                  {s.number}
                </span>
                <h3 className="text-xl font-display mb-3">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {s.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection />
    </PageShell>
  );
}
