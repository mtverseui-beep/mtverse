import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { StatusDashboard } from "@/components/site/status-dashboard";

export const metadata: Metadata = {
  title: "Status",
  description:
    "Real-time status of PagePulse's RUM ingestion, Web Vitals pipeline, dashboard, deployment diffing, webhooks, alerts, and report generation. 60-day incident history included.",
  alternates: { canonical: "/status" },
};

export default function StatusPage() {
  return (
    <PageShell showFooter={false}>
      <PageHeader
        eyebrow="System status"
        title={
          <>
            All systems
            <br />
            operational.
          </>
        }
        description="Real-time status for every PagePulse component, plus a 60-day incident history. Subscribe for email updates when a component changes state."
      />
      <StatusDashboard />
    </PageShell>
  );
}
