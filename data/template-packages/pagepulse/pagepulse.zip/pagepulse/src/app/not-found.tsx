import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Home, Search } from "lucide-react";
import { siteConfig } from "@/lib/site-config";

export const metadata = {
  title: "Page not found",
  robots: { index: false, follow: false },
};

const popularRoutes = [
  { label: "Features", href: "/features" },
  { label: "Pricing", href: "/pricing" },
  { label: "Docs", href: "/docs" },
  { label: "Web Vitals", href: "/web-vitals" },
  { label: "Customers", href: "/customers" },
  { label: "Status", href: "/status" },
];

export default function NotFound() {
  return (
    <main className="min-h-screen flex flex-col bg-background text-foreground">
      <header className="px-6 lg:px-12 py-6">
        <Link href="/" className="inline-flex items-center gap-2" aria-label={`${siteConfig.name} home`}>
          <svg viewBox="0 0 64 64" className="w-8 h-8" aria-hidden="true">
            <rect width="64" height="64" rx="14" fill="currentColor" />
            <path
              d="M10 38 L18 30 L26 36 L34 18 L46 32 L54 24"
              fill="none"
              stroke="var(--background)"
              strokeWidth="3.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle cx="54" cy="24" r="3.5" fill="var(--background)" />
          </svg>
          <span className="text-2xl font-display">{siteConfig.name}</span>
        </Link>
      </header>

      <div className="flex-1 flex items-center justify-center px-6 lg:px-12">
        <div className="text-center max-w-xl">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground inline-flex items-center gap-3 mb-6">
            <span className="w-8 h-px bg-foreground/30" />
            Error 404
          </span>
          <h1 className="text-7xl md:text-8xl lg:text-9xl font-display tracking-tight leading-none mb-6">
            404
          </h1>
          <p className="text-xl lg:text-2xl text-muted-foreground leading-relaxed mb-2">
            This route does not exist.
          </p>
          <p className="text-muted-foreground mb-10">
            The page you are looking for has been moved, renamed, or never
            existed. Like a route with a 4-second LCP, it is time to roll back.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-12">
            <Button
              asChild
              className="bg-foreground hover:bg-foreground/90 text-background rounded-full h-12 px-6 w-full sm:w-auto"
            >
              <Link href="/">
                <Home className="w-4 h-4" />
                Back to home
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="rounded-full h-12 px-6 w-full sm:w-auto border-foreground/20 hover:bg-foreground/5"
            >
              <Link href="/docs">
                <Search className="w-4 h-4" />
                Browse the docs
              </Link>
            </Button>
          </div>

          <div className="border-t border-foreground/10 pt-8">
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4">
              Popular routes
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {popularRoutes.map((r) => (
                <Link
                  key={r.href}
                  href={r.href}
                  className="px-3 py-1.5 border border-foreground/15 text-sm text-muted-foreground hover:text-foreground hover:border-foreground/40 transition-colors"
                >
                  {r.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      <footer className="px-6 lg:px-12 py-6 border-t border-foreground/10">
        <div className="max-w-[1400px] mx-auto flex items-center justify-between gap-4">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to home
          </Link>
          <p className="text-xs font-mono text-muted-foreground">
            {new Date().getFullYear()} {siteConfig.copyright}
          </p>
        </div>
      </footer>
    </main>
  );
}
