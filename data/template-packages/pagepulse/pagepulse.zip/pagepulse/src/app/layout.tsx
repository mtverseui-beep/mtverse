import type { Metadata } from "next";
import { Instrument_Sans, Instrument_Serif, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { themeInitScript } from "@/components/site/theme-provider";
import { GoToTopButton } from "@/components/site/go-to-top-button";

const instrumentSans = Instrument_Sans({
  subsets: ["latin"],
  variable: "--font-instrument",
});

const instrumentSerif = Instrument_Serif({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-instrument-serif",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
});

const siteUrl = "https://pagepulse.dev";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "PagePulse — Frontend Performance & Core Web Vitals Monitoring",
    template: "%s · PagePulse",
  },
  description:
    "Monitor Core Web Vitals, page speed, JavaScript performance, deployment impact, and user experience from one frontend analytics platform.",
  applicationName: "PagePulse",
  keywords: [
    "Core Web Vitals",
    "LCP",
    "INP",
    "CLS",
    "TTFB",
    "FCP",
    "page speed",
    "frontend performance monitoring",
    "real user monitoring",
    "performance budgets",
    "deployment impact",
    "JavaScript bundle size",
    "Next.js performance",
    "PagePulse",
  ],
  authors: [{ name: "PagePulse, Inc." }],
  creator: "PagePulse, Inc.",
  publisher: "PagePulse, Inc.",
  icons: {
    icon: [{ url: "/icon.svg", type: "image/svg+xml" }],
  },
  manifest: "/site.webmanifest",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: siteUrl,
    siteName: "PagePulse",
    title: "PagePulse — Frontend Performance & Core Web Vitals Monitoring",
    description:
      "Monitor Core Web Vitals, page speed, JavaScript performance, deployment impact, and user experience from one frontend analytics platform.",
  },
  twitter: {
    card: "summary_large_image",
    title: "PagePulse — Frontend Performance & Core Web Vitals Monitoring",
    description:
      "Monitor Core Web Vitals, page speed, JavaScript performance, deployment impact, and user experience from one frontend analytics platform.",
    creator: "@pagepulse",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: "/",
  },
  category: "technology",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{ __html: themeInitScript }}
        />
      </head>
      <body
        className={`${instrumentSans.variable} ${instrumentSerif.variable} ${jetbrainsMono.variable} font-sans antialiased bg-background text-foreground`}
      >
        {children}
        <GoToTopButton />
        <Toaster />
        <SonnerToaster richColors position="bottom-right" />
      </body>
    </html>
  );
}
