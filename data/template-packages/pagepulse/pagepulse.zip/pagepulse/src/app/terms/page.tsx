import type { Metadata } from "next";
import { LegalPage } from "@/components/site/legal-page";

export const metadata: Metadata = {
  title: "Terms of Service",
  description:
    "The terms that govern your use of PagePulse. Includes acceptable use, payment terms, service levels, and termination.",
  alternates: { canonical: "/terms" },
};

const sidebar = [
  { label: "Privacy Policy", href: "/privacy" },
  { label: "Terms of Service", href: "/terms", active: true },
  { label: "Data Processing Addendum", href: "/dpa" },
  { label: "Cookie Policy", href: "/cookies" },
];

const sections = [
  {
    heading: "1. Agreement to terms",
    body: [
      "These Terms of Service (\u201CTerms\u201D) govern your use of the PagePulse platform, including the web application, browser SDK, command-line tools, and API (collectively, the \u201CService\u201D). The Service is operated by PagePulse, Inc. (\u201CPagePulse\u201D, \u201Cwe\u201D, \u201Cus\u201D).",
      "By creating an account or using the Service, you agree to these Terms. If you are using the Service on behalf of a company, you represent that you have authority to bind that company to these Terms, and \u201Cyou\u201D in these Terms refers to that company.",
    ],
  },
  {
    heading: "2. Your account",
    body: [
      "You must provide accurate, complete, and current information when creating your account. You are responsible for safeguarding your account credentials and for all activity that occurs under your account. Notify us immediately at security@pagepulse.dev if you suspect unauthorized use of your account.",
      "You must be at least 16 years old to create an account. If you are under 18, you represent that your parent or legal guardian has reviewed and agreed to these Terms on your behalf.",
    ],
  },
  {
    heading: "3. Acceptable use",
    body: [
      "You agree not to: (a) use the Service to violate any law or third-party right; (b) reverse engineer, decompile, or disassemble any part of the Service; (c) attempt to gain unauthorized access to any portion of the Service; (d) transmit any malware, virus, or harmful code; (e) interfere with or disrupt the Service or servers used to provide it; or (f) resell, sublicense, or redistribute access to the Service without our written consent.",
      "You are responsible for the websites on which you install the PagePulse browser SDK and for ensuring that your use of the SDK complies with applicable privacy laws, including obtaining any required end-user consent.",
    ],
  },
  {
    heading: "4. Plans and payment",
    body: [
      "PagePulse offers three subscription plans: Starter ($19/month), Growth ($49/month), and Scale ($149/month). Annual billing is available at a 17% discount. All prices are in US dollars and exclude applicable taxes, which are your responsibility.",
      "Subscriptions renew automatically at the end of each billing period unless you cancel before the renewal date. You can cancel at any time from your workspace settings; cancellation takes effect at the end of the current billing period, and no refunds are issued for partial periods.",
      "If we increase prices for your plan, we will notify you by email at least 30 days before the increase takes effect. The increase will not apply to your current billing period; it will apply to the next renewal on or after the effective date.",
    ],
  },
  {
    heading: "5. Service levels",
    body: [
      "We target 99.99% uptime for the Service, measured monthly excluding scheduled maintenance. The Scale plan includes a formal Service Level Agreement with service credits for any month in which uptime falls below 99.9%. Service credits are calculated as a percentage of your monthly fee and are applied to your next invoice.",
      "Scheduled maintenance is performed during low-traffic windows and is announced at least 72 hours in advance on the PagePulse status page. Emergency maintenance may be performed without notice if required to address a security incident or critical bug.",
    ],
  },
  {
    heading: "6. Intellectual property",
    body: [
      "We retain all right, title, and interest in the Service, including the PagePulse name, logo, software, documentation, and design. These Terms do not grant you any right to use our trademarks, service marks, or trade dress.",
      "You retain all right, title, and interest in your data, including the websites on which you install the PagePulse SDK. We receive a limited, non-exclusive license to process your data solely to provide the Service to you, as further described in the Privacy Policy and Data Processing Addendum.",
    ],
  },
  {
    heading: "7. Confidentiality",
    body: [
      "Each party may have access to the other party's confidential information in the course of the relationship. Confidential information includes, for PagePulse, the Service's roadmap, pricing, and security documentation; and for you, your account data and performance telemetry. Each party agrees to protect the other's confidential information with at least the same care it uses to protect its own, and to use it only to perform under these Terms.",
    ],
  },
  {
    heading: "8. Termination",
    body: [
      "You may terminate your account at any time from your workspace settings. We may suspend or terminate your account if you breach these Terms, if your account is inactive for more than 12 months, or if we discontinue the Service (with at least 90 days' notice).",
      "On termination, we will retain your data for 30 days to allow for export, then hard-delete it. Provisions that by their nature should survive termination (including intellectual property, confidentiality, indemnity, and limitation of liability) will remain in effect.",
    ],
  },
  {
    heading: "9. Disclaimers and limitation of liability",
    body: [
      "The Service is provided \u201Cas is\u201D and \u201Cas available\u201D. We disclaim all warranties, express or implied, including merchantability, fitness for a particular purpose, and non-infringement. We do not warrant that the Service will be error-free, uninterrupted, or that performance data will be accurate in all circumstances.",
      "To the maximum extent permitted by law, our total liability for any claim arising out of or relating to these Terms or the Service will not exceed the amount you paid us in the 12 months preceding the claim. In no event will we be liable for indirect, incidental, special, consequential, or punitive damages.",
    ],
  },
  {
    heading: "10. Changes to these Terms",
    body: [
      "We may update these Terms from time to time. We will notify you by email at least 30 days before material changes take effect. Your continued use of the Service after the effective date constitutes acceptance of the updated Terms.",
    ],
  },
  {
    heading: "11. Governing law",
    body: [
      "These Terms are governed by the laws of the State of Delaware, USA, without regard to its conflict of law principles. Any dispute arising out of or relating to these Terms will be resolved in the state or federal courts located in Delaware, and each party submits to the exclusive jurisdiction of those courts.",
    ],
  },
];

export default function TermsPage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Terms of Service"
      description="The terms that govern your use of the PagePulse platform, SDK, and API."
      lastUpdated="June 1, 2025"
      sections={sections}
      sidebar={sidebar}
    />
  );
}
