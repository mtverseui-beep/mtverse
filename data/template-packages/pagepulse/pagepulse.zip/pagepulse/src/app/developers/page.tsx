import type { Metadata } from "next";
import Link from "next/link";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { DevelopersSection } from "@/components/landing/developers-section";
import { CtaSection } from "@/components/landing/cta-section";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Developers",
  description:
    "A tiny browser SDK, script tag install, Next.js and React support, custom metrics, deployment markers, performance budgets, webhooks, and TypeScript types.",
  alternates: { canonical: "/developers" },
};

const docLinks = [
  { title: "Installation", href: "/docs/installation", description: "Get PagePulse running in under 2 minutes." },
  { title: "Web Vitals", href: "/docs/web-vitals", description: "Capture LCP, INP, CLS, FCP, and TTFB." },
  { title: "Performance budgets", href: "/docs/performance-budgets", description: "Enforce thresholds on every metric." },
  { title: "Deployment tracking", href: "/docs/deployments", description: "Tag every release for impact diffing." },
  { title: "Custom metrics", href: "/docs/custom-metrics", description: "Track any timing or business KPI." },
  { title: "API reference", href: "/docs/api", description: "Every endpoint, every parameter." },
  { title: "Webhooks", href: "/docs/webhooks", description: "Stream events to any HTTP endpoint." },
];

export default function DevelopersPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="For developers"
        title={
          <>
            Built by devs.
            <br />
            For devs.
          </>
        }
        description="A tiny browser SDK, script tag install, Next.js and React support, custom metrics, deployment markers, performance budgets, webhooks, and TypeScript types."
      />
      <DevelopersSection />

      <section className="py-24 lg:py-32 border-t border-foreground/10">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="mb-16">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Documentation
            </span>
            <h2 className="text-4xl lg:text-5xl font-display tracking-tight">
              Read the docs.
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-foreground/10">
            {docLinks.map((doc) => (
              <Link
                key={doc.title}
                href={doc.href}
                className="group bg-background p-8 hover:bg-foreground/[0.02] transition-colors"
              >
                <div className="flex items-start justify-between gap-6">
                  <div>
                    <h3 className="text-xl font-display mb-2 group-hover:translate-x-1 transition-transform">
                      {doc.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{doc.description}</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all shrink-0 mt-1" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CtaSection />
    </PageShell>
  );
}
