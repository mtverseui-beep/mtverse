"use client";

import { useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { RefreshCw, Home } from "lucide-react";
import { siteConfig } from "@/lib/site-config";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // In production, this is where you would forward to your error reporter.
    // We intentionally do not log the error object here to avoid leaking PII.
    void error;
  }, [error]);

  return (
    <main className="min-h-screen flex flex-col bg-background text-foreground">
      <header className="px-6 lg:px-12 py-6">
        <Link href="/" className="inline-flex items-center gap-2" aria-label={`${siteConfig.name} home`}>
          <svg viewBox="0 0 64 64" className="w-8 h-8" aria-hidden="true">
            <rect width="64" height="64" rx="14" fill="currentColor" />
            <path
              d="M10 38 L18 30 L26 36 L34 18 L46 32 L54 24"
              fill="none"
              stroke="var(--background)"
              strokeWidth="3.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle cx="54" cy="24" r="3.5" fill="var(--background)" />
          </svg>
          <span className="text-2xl font-display">{siteConfig.name}</span>
        </Link>
      </header>

      <div className="flex-1 flex items-center justify-center px-6 lg:px-12">
        <div className="text-center max-w-xl">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground inline-flex items-center gap-3 mb-6">
            <span className="w-8 h-px bg-foreground/30" />
            Error 500
          </span>
          <h1 className="text-7xl md:text-8xl lg:text-9xl font-display tracking-tight leading-none mb-6">
            500
          </h1>
          <p className="text-xl lg:text-2xl text-muted-foreground leading-relaxed mb-2">
            Something went wrong on our end.
          </p>
          <p className="text-muted-foreground mb-10">
            Our team has been notified. If the problem persists, check our status
            page or contact support. We apologize for the disruption.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-12">
            <Button
              onClick={() => reset()}
              className="bg-foreground hover:bg-foreground/90 text-background rounded-full h-12 px-6 w-full sm:w-auto"
            >
              <RefreshCw className="w-4 h-4" />
              Try again
            </Button>
            <Button
              asChild
              variant="outline"
              className="rounded-full h-12 px-6 w-full sm:w-auto border-foreground/20 hover:bg-foreground/5"
            >
              <Link href="/">
                <Home className="w-4 h-4" />
                Back to home
              </Link>
            </Button>
          </div>

          <div className="border-t border-foreground/10 pt-8">
            <p className="text-sm text-muted-foreground">
              Need to talk to a human? Email{" "}
              <a
                href={`mailto:${siteConfig.supportEmail}`}
                className="text-foreground hover:underline underline-offset-4"
              >
                {siteConfig.supportEmail}
              </a>
            </p>
          </div>
        </div>
      </div>

      <footer className="px-6 lg:px-12 py-6 border-t border-foreground/10">
        <p className="text-xs font-mono text-muted-foreground text-center">
          {new Date().getFullYear()} {siteConfig.copyright}
        </p>
      </footer>
    </main>
  );
}
