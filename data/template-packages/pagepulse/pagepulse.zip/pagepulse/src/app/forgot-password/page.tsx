"use client";

import { useState } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { ArrowLeft, MailCheck } from "lucide-react";
import { AuthShell } from "@/components/site/auth-shell";
import { cn } from "@/lib/utils";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | undefined>();
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setError("Email is required.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    setError(undefined);
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 900));
    setSubmitting(false);
    setSent(true);
    toast.success("Reset link sent", {
      description: `Check your inbox at ${email}`,
    });
  };

  if (sent) {
    return (
      <AuthShell
        title="Check your inbox"
        description={`We sent a password reset link to ${email}. The link expires in 60 minutes.`}
        footer={
          <Link
            href="/sign-in"
            className="inline-flex items-center gap-2 text-foreground hover:underline underline-offset-4"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to sign in
          </Link>
        }
      >
        <div className="border border-foreground/10 p-6 bg-foreground/[0.02]">
          <div className="w-10 h-10 rounded-full bg-foreground/5 flex items-center justify-center mb-4">
            <MailCheck className="w-5 h-5 text-foreground" />
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed mb-4">
            If you do not receive an email within 5 minutes, check your spam
            folder or{" "}
            <Link href="/contact" className="text-foreground hover:underline underline-offset-4">
              contact support
            </Link>
            .
          </p>
          <button
            type="button"
            onClick={() => {
              setSent(false);
              setEmail("");
            }}
            className="text-sm text-foreground hover:underline underline-offset-4"
          >
            Try a different email
          </button>
        </div>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      title="Reset your password"
      description="Enter the email associated with your PagePulse account and we will send a reset link."
      footer={
        <Link
          href="/sign-in"
          className="inline-flex items-center gap-2 text-foreground hover:underline underline-offset-4"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Back to sign in
        </Link>
      }
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        <div>
          <label htmlFor="email" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            Email
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              if (error) setError(undefined);
            }}
            className={cn(
              "w-full px-3 py-2.5 bg-transparent border focus:outline-none transition-colors text-sm",
              error
                ? "border-red-500 focus:border-red-500"
                : "border-foreground/15 focus:border-foreground/40"
            )}
            placeholder="you@company.com"
            aria-invalid={!!error}
          />
          {error && <p className="text-xs text-red-600 mt-1.5">{error}</p>}
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-foreground text-background h-11 text-sm font-medium hover:bg-foreground/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
        >
          {submitting ? (
            <>
              <span className="w-4 h-4 border-2 border-background/30 border-t-background rounded-full animate-spin" />
              Sending link...
            </>
          ) : (
            "Send reset link"
          )}
        </button>
      </form>
    </AuthShell>
  );
}
