import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { PageShell } from "@/components/site/page-shell";
import { CtaSection } from "@/components/landing/cta-section";
import { BlogContent } from "@/components/site/blog-content";
import { blogPosts, getBlogPostBySlug } from "@/lib/blog-posts";
import { ArrowLeft, ArrowRight } from "lucide-react";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return blogPosts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const post = getBlogPostBySlug(slug);
  if (!post) {
    return { title: "Post not found" };
  }
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: {
      type: "article",
      title: post.title,
      description: post.excerpt,
      publishedTime: post.date,
      authors: [post.author],
    },
  };
}

export default async function BlogPostPage({ params }: PageProps) {
  const { slug } = await params;
  const post = getBlogPostBySlug(slug);
  if (!post) {
    notFound();
  }

  const currentIndex = blogPosts.findIndex((p) => p.slug === slug);
  const nextPost = blogPosts[(currentIndex + 1) % blogPosts.length];
  const prevPost = blogPosts[(currentIndex - 1 + blogPosts.length) % blogPosts.length];

  return (
    <PageShell>
      <article className="pb-24 lg:pb-32">
        <div className="max-w-3xl mx-auto px-6 lg:px-12">
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-12"
          >
            <ArrowLeft className="w-4 h-4" />
            All posts
          </Link>

          <div className="flex items-center gap-4 mb-6">
            <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
              {post.category}
            </span>
            <span className="text-muted-foreground/40">|</span>
            <span className="font-mono text-xs text-muted-foreground">
              {post.readTime}
            </span>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-display tracking-tight leading-[0.95] mb-6">
            {post.title}
          </h1>

          <p className="text-xl text-muted-foreground leading-relaxed mb-8">
            {post.excerpt}
          </p>

          <div className="flex items-center gap-4 pb-8 mb-12 border-b border-foreground/10">
            <div className="w-12 h-12 rounded-full bg-foreground/5 border border-foreground/10 flex items-center justify-center">
              <span className="font-display text-xl text-foreground">
                {post.author.charAt(0)}
              </span>
            </div>
            <div>
              <p className="font-medium text-foreground">{post.author}</p>
              <p className="text-sm text-muted-foreground">
                {post.authorRole} ·{" "}
                {new Date(post.date).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>
          </div>

          <BlogContent content={post.content} />

          <div className="mt-16 pt-12 border-t border-foreground/10">
            <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest mb-6">
              Keep reading
            </p>
            <div className="grid sm:grid-cols-2 gap-px bg-foreground/10 border border-foreground/10">
              <Link
                href={`/blog/${prevPost.slug}`}
                className="group bg-background p-6 hover:bg-foreground/[0.02] transition-colors"
              >
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                  <ArrowLeft className="w-3 h-3" />
                  Previous
                </div>
                <div className="font-display text-lg group-hover:translate-x-[-4px] transition-transform">
                  {prevPost.title}
                </div>
              </Link>
              <Link
                href={`/blog/${nextPost.slug}`}
                className="group bg-background p-6 hover:bg-foreground/[0.02] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-2 text-xs text-muted-foreground mb-2">
                  Next
                  <ArrowRight className="w-3 h-3" />
                </div>
                <div className="font-display text-lg group-hover:translate-x-[4px] transition-transform">
                  {nextPost.title}
                </div>
              </Link>
            </div>
          </div>
        </div>
      </article>
      <CtaSection />
    </PageShell>
  );
}
