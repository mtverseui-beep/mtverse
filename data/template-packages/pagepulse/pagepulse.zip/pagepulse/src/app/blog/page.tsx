import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { BlogList } from "@/components/site/blog-list";
import { CtaSection } from "@/components/landing/cta-section";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Deep dives on Core Web Vitals, performance budgets, real user monitoring, deployment impact, and modern frontend performance.",
  alternates: { canonical: "/blog" },
};

export default function BlogPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Blog"
        title={
          <>
            Frontend performance,
            <br />
            explained.
          </>
        }
        description="Deep dives on Core Web Vitals, performance budgets, real user monitoring, deployment impact, and modern frontend performance."
      />
      <BlogList />
      <CtaSection />
    </PageShell>
  );
}
