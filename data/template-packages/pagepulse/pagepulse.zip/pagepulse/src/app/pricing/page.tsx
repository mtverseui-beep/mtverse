import type { Metadata } from "next";
import Link from "next/link";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { PricingSection } from "@/components/landing/pricing-section";
import { FaqSection } from "@/components/landing/faq-section";
import { CtaSection } from "@/components/landing/cta-section";
import { Check, Minus } from "lucide-react";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Simple, transparent pricing for frontend performance monitoring. Start at $19/month and scale to 5M page views with SSO, audit logs, and SLA reports.",
  alternates: { canonical: "/pricing" },
};

interface ComparisonRow {
  feature: string;
  starter: string | boolean;
  growth: string | boolean;
  scale: string | boolean;
}

const comparisonRows: ComparisonRow[] = [
  { feature: "Page views / month", starter: "50,000", growth: "500,000", scale: "5,000,000" },
  { feature: "Projects", starter: "3", growth: "Unlimited", scale: "Unlimited" },
  { feature: "History retention", starter: "7 days", growth: "90 days", scale: "365 days or custom" },
  { feature: "Core Web Vitals tracking", starter: true, growth: true, scale: true },
  { feature: "Real user monitoring", starter: true, growth: true, scale: true },
  { feature: "Route-level insights", starter: true, growth: true, scale: true },
  { feature: "Email reports", starter: true, growth: true, scale: true },
  { feature: "Basic alerts", starter: true, growth: true, scale: true },
  { feature: "Deployment tracking", starter: false, growth: true, scale: true },
  { feature: "Performance budgets", starter: false, growth: true, scale: true },
  { feature: "Slack alerts", starter: false, growth: true, scale: true },
  { feature: "Web Vitals reports", starter: false, growth: true, scale: true },
  { feature: "Team members", starter: false, growth: true, scale: true },
  { feature: "Advanced segmentation", starter: false, growth: false, scale: true },
  { feature: "Custom retention", starter: false, growth: false, scale: true },
  { feature: "SSO (SAML / OIDC)", starter: false, growth: false, scale: true },
  { feature: "Audit logs", starter: false, growth: false, scale: true },
  { feature: "Custom alerts", starter: false, growth: false, scale: true },
  { feature: "Priority support", starter: false, growth: false, scale: true },
  { feature: "SLA reports", starter: false, growth: false, scale: true },
];

function Cell({ value }: { value: string | boolean }) {
  if (value === true) {
    return <Check className="w-4 h-4 text-foreground inline" />;
  }
  if (value === false) {
    return <Minus className="w-4 h-4 text-muted-foreground/40 inline" />;
  }
  return <span className="text-sm text-foreground">{value}</span>;
}

export default function PricingPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Pricing"
        title={
          <>
            Pricing that scales
            <br />
            with your traffic.
          </>
        }
        description="Start monitoring Core Web Vitals in 2 minutes. Upgrade as your traffic grows. Cancel anytime."
      />

      <PricingSection />

      <section className="py-24 lg:py-32 border-t border-foreground/10">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="mb-12">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Compare plans
            </span>
            <h2 className="text-4xl lg:text-5xl font-display tracking-tight">
              Every feature, side by side.
            </h2>
          </div>

          <div className="border border-foreground/10 overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-foreground/10 bg-foreground/[0.02]">
                  <th className="text-left px-4 lg:px-6 py-4 text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Feature
                  </th>
                  <th className="text-left px-4 lg:px-6 py-4">
                    <div className="font-display text-lg">Starter</div>
                    <div className="text-xs font-mono text-muted-foreground mt-0.5">$19/mo</div>
                  </th>
                  <th className="text-left px-4 lg:px-6 py-4 bg-foreground/[0.03]">
                    <div className="font-display text-lg">Growth</div>
                    <div className="text-xs font-mono text-muted-foreground mt-0.5">$49/mo</div>
                  </th>
                  <th className="text-left px-4 lg:px-6 py-4">
                    <div className="font-display text-lg">Scale</div>
                    <div className="text-xs font-mono text-muted-foreground mt-0.5">$149/mo</div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {comparisonRows.map((row) => (
                  <tr key={row.feature} className="border-b border-foreground/5 last:border-b-0">
                    <td className="px-4 lg:px-6 py-3.5 text-sm text-foreground">
                      {row.feature}
                    </td>
                    <td className="px-4 lg:px-6 py-3.5">
                      <Cell value={row.starter} />
                    </td>
                    <td className="px-4 lg:px-6 py-3.5 bg-foreground/[0.02]">
                      <Cell value={row.growth} />
                    </td>
                    <td className="px-4 lg:px-6 py-3.5">
                      <Cell value={row.scale} />
                    </td>
                  </tr>
                ))}
                <tr>
                  <td className="px-4 lg:px-6 py-5" />
                  <td className="px-4 lg:px-6 py-5">
                    <Link
                      href="/sign-up?plan=starter"
                      className="inline-flex items-center justify-center px-4 py-2 border border-foreground/20 text-xs font-mono uppercase tracking-widest hover:border-foreground hover:bg-foreground/5 transition-colors"
                    >
                      Choose Starter
                    </Link>
                  </td>
                  <td className="px-4 lg:px-6 py-5 bg-foreground/[0.02]">
                    <Link
                      href="/sign-up?plan=growth"
                      className="inline-flex items-center justify-center px-4 py-2 bg-foreground text-background text-xs font-mono uppercase tracking-widest hover:bg-foreground/90 transition-colors"
                    >
                      Choose Growth
                    </Link>
                  </td>
                  <td className="px-4 lg:px-6 py-5">
                    <Link
                      href="/sign-up?plan=scale"
                      className="inline-flex items-center justify-center px-4 py-2 border border-foreground/20 text-xs font-mono uppercase tracking-widest hover:border-foreground hover:bg-foreground/5 transition-colors"
                    >
                      Choose Scale
                    </Link>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <p className="mt-8 text-sm text-muted-foreground">
            Need more than 5M page views, on-premise hosting, or a custom contract?{" "}
            <Link href="/contact" className="text-foreground hover:underline underline-offset-4">
              Talk to sales
            </Link>
            .
          </p>
        </div>
      </section>

      <FaqSection />
      <CtaSection />
    </PageShell>
  );
}
