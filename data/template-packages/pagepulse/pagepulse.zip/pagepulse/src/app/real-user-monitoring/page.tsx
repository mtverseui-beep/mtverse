import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { RumPreviewSection } from "@/components/landing/rum-preview-section";
import { CtaSection } from "@/components/landing/cta-section";

export const metadata: Metadata = {
  title: "Real User Monitoring",
  description:
    "See actual user experience by device, browser, country, route, and traffic source. RUM data for every Core Web Vitals metric on every page.",
  alternates: { canonical: "/real-user-monitoring" },
};

const segmentationOptions = [
  {
    label: "Device",
    description: "Slice by device class, model, CPU cores, memory, and connection type. See whether mid-range Android phones on 3G are paying the price for your client component tree.",
  },
  {
    label: "Browser",
    description: "Compare LCP, INP, CLS, FCP, and TTFB across Chrome, Safari, Firefox, Edge, and Samsung Internet. Surface browser-specific regressions and prioritize by user impact.",
  },
  {
    label: "Country",
    description: "See Core Web Vitals by country, region, and city. 17 collection regions ensure low-latency ingestion from every continent, so you always see accurate data from real users.",
  },
  {
    label: "Route",
    description: "Every page route in your application gets its own LCP, INP, CLS, FCP, and TTFB score, updated in real time as new RUM samples arrive. Drill into a single route to see the slowest sessions.",
  },
  {
    label: "Traffic source",
    description: "Join RUM data with your UTM parameters, referrer, and landing page to see which marketing campaigns and traffic sources bring the slowest experiences.",
  },
  {
    label: "Funnel",
    description: "Trace real user journeys through your app. See LCP, INP, and CLS at every step of your signup, checkout, or onboarding funnel, and find the exact page where users drop off.",
  },
];

export default function RealUserMonitoringPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Real User Monitoring"
        title={
          <>
            Real users.
            <br />
            Real data.
          </>
        }
        description="See actual user experience by device, browser, country, route, and traffic source. RUM data for every Core Web Vitals metric on every page."
      />

      <RumPreviewSection />

      <section className="py-24 lg:py-32 border-t border-foreground/10">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="mb-16">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Slice any way
            </span>
            <h2 className="text-4xl lg:text-5xl font-display tracking-tight">
              Six ways to slice your data.
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-foreground/10 border border-foreground/10">
            {segmentationOptions.map((s) => (
              <div key={s.label} className="bg-background p-8 group hover:bg-foreground/[0.02] transition-colors">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-display">{s.label}</h3>
                  <span className="font-mono text-xs text-muted-foreground">
                    {String(segmentationOptions.indexOf(s) + 1).padStart(2, "0")}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {s.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection />
    </PageShell>
  );
}
