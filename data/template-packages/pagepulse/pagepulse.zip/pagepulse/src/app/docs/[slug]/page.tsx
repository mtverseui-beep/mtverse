import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { DocsShell } from "@/components/site/docs-shell";
import { DocContent } from "@/components/site/doc-content";
import { docPages, getDocBySlug, docCategories } from "@/lib/docs";
import { FooterSection } from "@/components/landing/footer-section";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return docPages
    .filter((p) => p.slug !== "installation")
    .map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const doc = getDocBySlug(slug);
  if (!doc) {
    return { title: "Doc not found" };
  }
  return {
    title: doc.title,
    description: doc.description,
    alternates: { canonical: `/docs/${doc.slug}` },
  };
}

export default async function DocPage({ params }: PageProps) {
  const { slug } = await params;
  const doc = getDocBySlug(slug);
  if (!doc || doc.slug === "installation") {
    notFound();
  }

  return (
    <>
      <DocsShell
        currentSlug={doc.slug}
        title={doc.title}
        description={doc.description}
      >
        <DocContent blocks={doc.blocks} />
      </DocsShell>
      <FooterSection />
    </>
  );
}

// Silence unused import in some build setups
void docCategories;
