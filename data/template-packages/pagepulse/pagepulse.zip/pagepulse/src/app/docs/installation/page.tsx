import type { Metadata } from "next";
import { DocsShell } from "@/components/site/docs-shell";
import { DocContent } from "@/components/site/doc-content";
import { getDocBySlug } from "@/lib/docs";
import { FooterSection } from "@/components/landing/footer-section";

export const metadata: Metadata = {
  title: "Installation",
  description:
    "Install the PagePulse browser SDK in under 2 minutes. Supports npm, script tag, Next.js, React, Vue, and more.",
  alternates: { canonical: "/docs/installation" },
};

export default function InstallationDocPage() {
  const doc = getDocBySlug("installation");
  if (!doc) return null;

  return (
    <>
      <DocsShell currentSlug="installation" title={doc.title} description={doc.description}>
        <DocContent blocks={doc.blocks} />
      </DocsShell>
      <FooterSection />
    </>
  );
}
