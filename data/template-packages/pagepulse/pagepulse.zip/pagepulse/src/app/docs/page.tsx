import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { docCategories } from "@/lib/docs";
import { FooterSection } from "@/components/landing/footer-section";

export const metadata: Metadata = {
  title: "Documentation",
  description:
    "PagePulse documentation. Install the SDK, track Core Web Vitals, set performance budgets, mark deployments, and stream events via webhooks.",
  alternates: { canonical: "/docs" },
};

export default function DocsIndexPage() {
  return (
    <main className="min-h-screen bg-background">
      <section className="pt-32 lg:pt-40 pb-16 lg:pb-24 border-b border-foreground/10">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
            <span className="w-8 h-px bg-foreground/30" />
            Documentation
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-7xl font-display tracking-tight leading-[0.95] mb-6">
            Build faster pages,
            <br />
            with confidence.
          </h1>
          <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl">
            Everything you need to install the SDK, track Core Web Vitals, set
            performance budgets, mark deployments, and stream events to your
            own infrastructure.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-3 gap-px bg-foreground/10 border border-foreground/10">
            {docCategories.map((cat) => (
              <div key={cat.label} className="bg-background p-8 lg:p-10">
                <h2 className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-6">
                  {cat.label}
                </h2>
                <ul className="space-y-1">
                  {cat.items.map((item) => (
                    <li key={item.slug}>
                      <Link
                        href={`/docs/${item.slug === "installation" ? "" : item.slug}`}
                        className="group flex items-center justify-between gap-4 py-3 px-3 -mx-3 hover:bg-foreground/[0.02] transition-colors"
                      >
                        <span className="font-display text-lg group-hover:translate-x-1 transition-transform">
                          {item.title}
                        </span>
                        <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all shrink-0" />
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <FooterSection />
    </main>
  );
}
