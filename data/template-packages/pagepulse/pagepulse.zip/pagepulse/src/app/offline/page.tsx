"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { WifiOff, RefreshCw } from "lucide-react";
import { siteConfig } from "@/lib/site-config";

export default function OfflinePage() {
  return (
    <main className="min-h-screen flex flex-col bg-background text-foreground">
      <header className="px-6 lg:px-12 py-6">
        <Link href="/" className="inline-flex items-center gap-2" aria-label={`${siteConfig.name} home`}>
          <svg viewBox="0 0 64 64" className="w-8 h-8" aria-hidden="true">
            <rect width="64" height="64" rx="14" fill="currentColor" />
            <path
              d="M10 38 L18 30 L26 36 L34 18 L46 32 L54 24"
              fill="none"
              stroke="var(--background)"
              strokeWidth="3.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle cx="54" cy="24" r="3.5" fill="var(--background)" />
          </svg>
          <span className="text-2xl font-display">{siteConfig.name}</span>
        </Link>
      </header>

      <div className="flex-1 flex items-center justify-center px-6 lg:px-12">
        <div className="text-center max-w-xl">
          <div className="w-16 h-16 rounded-full border border-foreground/15 flex items-center justify-center mx-auto mb-8">
            <WifiOff className="w-7 h-7 text-muted-foreground" />
          </div>
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground inline-flex items-center gap-3 mb-6">
            <span className="w-8 h-px bg-foreground/30" />
            Offline
          </span>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-display tracking-tight leading-none mb-6">
            You appear to be offline.
          </h1>
          <p className="text-xl text-muted-foreground leading-relaxed mb-10">
            PagePulse needs a network connection to load fresh performance data.
            Reconnect to continue. Cached documentation may still be available
            below.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-12">
            <Button
              className="bg-foreground hover:bg-foreground/90 text-background rounded-full h-12 px-6 w-full sm:w-auto"
              onClick={() => window.location.reload()}
            >
              <RefreshCw className="w-4 h-4" />
              Try again
            </Button>
          </div>

          <div className="border-t border-foreground/10 pt-8 text-left">
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4 text-center">
              Cached pages
            </p>
            <div className="grid sm:grid-cols-2 gap-2 max-w-md mx-auto">
              <Link
                href="/docs"
                className="px-4 py-3 border border-foreground/15 text-sm hover:border-foreground/40 hover:bg-foreground/5 transition-colors"
              >
                Documentation
              </Link>
              <Link
                href="/docs/installation"
                className="px-4 py-3 border border-foreground/15 text-sm hover:border-foreground/40 hover:bg-foreground/5 transition-colors"
              >
                Installation guide
              </Link>
              <Link
                href="/docs/web-vitals"
                className="px-4 py-3 border border-foreground/15 text-sm hover:border-foreground/40 hover:bg-foreground/5 transition-colors"
              >
                Web Vitals reference
              </Link>
              <Link
                href="/docs/api"
                className="px-4 py-3 border border-foreground/15 text-sm hover:border-foreground/40 hover:bg-foreground/5 transition-colors"
              >
                API reference
              </Link>
            </div>
          </div>
        </div>
      </div>

      <footer className="px-6 lg:px-12 py-6 border-t border-foreground/10">
        <p className="text-xs font-mono text-muted-foreground text-center">
          {new Date().getFullYear()} {siteConfig.copyright}
        </p>
      </footer>
    </main>
  );
}
