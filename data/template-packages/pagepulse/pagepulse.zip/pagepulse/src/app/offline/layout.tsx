import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "You are offline",
  description: "You appear to be offline. Reconnect to continue using PagePulse.",
  robots: { index: false, follow: false },
};

export default function OfflineLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
