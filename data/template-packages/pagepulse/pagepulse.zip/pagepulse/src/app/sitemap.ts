import type { MetadataRoute } from "next";
import { blogPosts } from "@/lib/blog-posts";
import { customers } from "@/lib/customers";
import { docPages } from "@/lib/docs";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://pagepulse.dev";
  const now = new Date();

  const staticRoutes = [
    "",
    "/pricing",
    "/features",
    "/web-vitals",
    "/performance-monitoring",
    "/deployment-impact",
    "/performance-budgets",
    "/real-user-monitoring",
    "/developers",
    "/docs",
    "/docs/installation",
    "/integrations",
    "/security",
    "/customers",
    "/blog",
    "/changelog",
    "/status",
    "/contact",
    "/request-demo",
    "/sign-in",
    "/sign-up",
    "/forgot-password",
    "/reset-password",
    "/privacy",
    "/terms",
    "/dpa",
    "/cookies",
  ];

  const staticEntries: MetadataRoute.Sitemap = staticRoutes.map((route) => ({
    url: `${base}${route}`,
    lastModified: now,
    changeFrequency: route === "" ? "daily" : "weekly",
    priority: route === "" ? 1 : route.startsWith("/docs") ? 0.8 : 0.7,
  }));

  const blogEntries: MetadataRoute.Sitemap = blogPosts.map((post) => ({
    url: `${base}/blog/${post.slug}`,
    lastModified: new Date(post.date),
    changeFrequency: "monthly",
    priority: 0.6,
  }));

  const customerEntries: MetadataRoute.Sitemap = customers.map((c) => ({
    url: `${base}/customers/${c.slug}`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.6,
  }));

  const docEntries: MetadataRoute.Sitemap = docPages
    .filter((d) => d.slug !== "installation")
    .map((d) => ({
      url: `${base}/docs/${d.slug}`,
      lastModified: now,
      changeFrequency: "monthly",
      priority: 0.7,
    }));

  return [...staticEntries, ...blogEntries, ...customerEntries, ...docEntries];
}
