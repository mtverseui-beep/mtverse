import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { DemoForm } from "@/components/site/demo-form";

export const metadata: Metadata = {
  title: "Request a demo",
  description:
    "Schedule a 30-minute walkthrough of PagePulse. Tailored to your stack, your routes, and your performance goals.",
  alternates: { canonical: "/request-demo" },
};

const demoPoints = [
  { label: "30 minutes", sub: "Tailored to your stack" },
  { label: "Live RUM walkthrough", sub: "See your routes in the product" },
  { label: "Custom budget plan", sub: "Recommended thresholds for your app" },
  { label: "Q&A", sub: "Bring your most painful perf questions" },
];

export default function RequestDemoPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Request a demo"
        title={
          <>
            See PagePulse on
            <br />
            your own site.
          </>
        }
        description="A 30-minute walkthrough with a product specialist. We will look at your routes, your Core Web Vitals, and your deployment flow together."
      />

      <div className="max-w-2xl mx-auto px-6 lg:px-12 mb-16">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-foreground/10 border border-foreground/10">
          {demoPoints.map((p) => (
            <div key={p.label} className="bg-background p-4">
              <div className="text-sm font-display">{p.label}</div>
              <div className="text-xs text-muted-foreground mt-1">{p.sub}</div>
            </div>
          ))}
        </div>
      </div>

      <DemoForm />
    </PageShell>
  );
}
