import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { ChangelogList } from "@/components/site/changelog-list";

export const metadata: Metadata = {
  title: "Changelog",
  description:
    "Every release, improvement, fix, and deprecation in PagePulse. Filter by type to see what changed and when.",
  alternates: { canonical: "/changelog" },
};

export default function ChangelogPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Changelog"
        title={
          <>
            What we shipped
            <br />
            this week.
          </>
        }
        description="Every PagePulse release, improvement, fix, and deprecation in chronological order. Filter by type to see exactly what changed."
      />
      <ChangelogList />
    </PageShell>
  );
}
