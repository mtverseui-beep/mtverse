import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { ContactForm } from "@/components/site/contact-form";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Contact PagePulse sales, support, partnerships, or press. We reply within one business day.",
  alternates: { canonical: "/contact" },
};

const contactChannels = [
  { label: "Sales", value: siteConfig.salesEmail, href: `mailto:${siteConfig.salesEmail}` },
  { label: "Support", value: siteConfig.supportEmail, href: `mailto:${siteConfig.supportEmail}` },
  { label: "Status", value: "status.pagepulse.dev", href: "/status" },
  { label: "Docs", value: "pagepulse.dev/docs", href: "/docs" },
];

export default function ContactPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Contact"
        title={
          <>
            Let&apos;s talk
            <br />
            performance.
          </>
        }
        description="Sales, technical support, partnerships, or press. Pick a topic and we will reply within one business day."
      />

      <div className="max-w-2xl mx-auto px-6 lg:px-12 mb-16">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-foreground/10 border border-foreground/10">
          {contactChannels.map((c) => (
            <a
              key={c.label}
              href={c.href}
              className="bg-background p-4 hover:bg-foreground/[0.02] transition-colors group"
            >
              <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">
                {c.label}
              </div>
              <div className="text-sm font-mono text-foreground group-hover:translate-x-1 transition-transform">
                {c.value}
              </div>
            </a>
          ))}
        </div>
      </div>

      <ContactForm />
    </PageShell>
  );
}
