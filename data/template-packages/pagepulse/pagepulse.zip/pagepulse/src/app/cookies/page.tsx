import type { Metadata } from "next";
import { LegalPage } from "@/components/site/legal-page";

export const metadata: Metadata = {
  title: "Cookie Policy",
  description:
    "PagePulse uses no cookies by default. This policy explains the optional cookies available and how to control them.",
  alternates: { canonical: "/cookies" },
};

const sidebar = [
  { label: "Privacy Policy", href: "/privacy" },
  { label: "Terms of Service", href: "/terms" },
  { label: "Data Processing Addendum", href: "/dpa" },
  { label: "Cookie Policy", href: "/cookies", active: true },
];

const sections = [
  {
    heading: "1. Default: cookie-free",
    body: [
      "PagePulse's default collection mode is cookie-free. The browser SDK does not set any cookies, local storage entries, session storage entries, or fingerprints in your end users' browsers. End users do not see a cookie banner on customer websites because no cookies are set.",
      "This cookie-free design is made possible by the fact that PagePulse measures timings, not user behavior. We do not need to identify a user across sessions, so we do not need to set a session or user identifier in the browser.",
    ],
  },
  {
    heading: "2. Optional cookies",
    body: [
      "Some PagePulse features are easier to implement with cookies. These features are all opt-in and disabled by default. If you enable any of them, you are responsible for obtaining end-user consent and providing a cookie banner as required by applicable law.",
    ],
    subsections: [
      {
        heading: "2.1 Cross-session user attribution",
        body: [
          "If you enable cross-session user attribution, PagePulse sets a first-party cookie named __pp_uid with a 365-day expiration. The cookie contains a random UUID that allows PagePulse to group pageviews from the same browser across sessions. The cookie does not contain any personal data and is not shared with any third party.",
        ],
      },
      {
        heading: "2.2 A/B test variant persistence",
        body: [
          "If you enable A/B test variant persistence, PagePulse sets a first-party cookie named __pp_variant with a 30-day expiration. The cookie contains the variant name the user was assigned to, so the user sees a consistent experience on return visits.",
        ],
      },
    ],
  },
  {
    heading: "3. PagePulse application cookies",
    body: [
      "The PagePulse web application (app.pagepulse.dev) uses a small number of cookies to keep you signed in and remember your preferences. These cookies are set only when you visit the application itself, not when end users visit customer websites. The application cookies are:",
    ],
    subsections: [
      {
        heading: "3.1 Session cookie",
        body: [
          "Named __pp_session, this cookie keeps you signed in to the application. It is a first-party cookie with a session-scoped expiration (cleared when you close your browser) or a 14-day expiration if you select \u201Ckeep me signed in\u201D.",
        ],
      },
      {
        heading: "3.2 Theme cookie",
        body: [
          "Named __pp_theme, this cookie remembers whether you have selected light or dark mode. It is a first-party cookie with a 365-day expiration. The theme is also stored in window.localStorage for users who have cookies disabled.",
        ],
      },
      {
        heading: "3.3 CSRF token cookie",
        body: [
          "Named __pp_csrf, this cookie protects against cross-site request forgery on state-changing requests. It is a first-party cookie with a session-scoped expiration and is required for the application to function correctly.",
        ],
      },
    ],
  },
  {
    heading: "4. Third-party cookies",
    body: [
      "PagePulse does not use third-party cookies. We do not integrate with advertising networks, social media pixels, or analytics services that set third-party cookies. The only third-party script loaded on app.pagepulse.dev is our payment processor, which sets its own cookies only on the billing page.",
    ],
  },
  {
    heading: "5. Controlling cookies",
    body: [
      "You can control application cookies through your browser settings. Most browsers allow you to refuse new cookies, delete existing cookies, and ask to be notified before a cookie is set. Disabling the session cookie will prevent you from signing in; disabling the theme cookie will fall back to your system preference; disabling the CSRF cookie will prevent form submissions.",
      "If you have enabled optional end-user cookies on customer websites, you are responsible for providing a cookie banner and preference center that complies with the GDPR, ePrivacy Directive, CCPA, and any other applicable law.",
    ],
  },
  {
    heading: "6. Updates to this policy",
    body: [
      "We will update this Cookie Policy if we add, remove, or change any cookies. We will notify you by email at least 30 days before material changes take effect. A changelog of past versions is available on request.",
    ],
  },
];

export default function CookiesPage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Cookie Policy"
      description="PagePulse uses no cookies by default. This policy explains the optional cookies and how to control them."
      lastUpdated="June 1, 2025"
      sections={sections}
      sidebar={sidebar}
    />
  );
}
