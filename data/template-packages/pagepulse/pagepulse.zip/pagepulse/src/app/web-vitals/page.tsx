import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { CoreWebVitalsSection } from "@/components/landing/core-web-vitals-section";
import { CtaSection } from "@/components/landing/cta-section";

export const metadata: Metadata = {
  title: "Core Web Vitals Monitoring",
  description:
    "Track LCP, INP, CLS, FCP, and TTFB for every real-user pageview. Slice by device, browser, country, route, and traffic source.",
  alternates: { canonical: "/web-vitals" },
};

interface Benchmark {
  metric: string;
  fullName: string;
  good: string;
  poor: string;
  unit: string;
  lowerBetter: boolean;
}

const benchmarks: Benchmark[] = [
  { metric: "LCP", fullName: "Largest Contentful Paint", good: "2.5", poor: "4.0", unit: "s", lowerBetter: true },
  { metric: "INP", fullName: "Interaction to Next Paint", good: "200", poor: "500", unit: "ms", lowerBetter: true },
  { metric: "CLS", fullName: "Cumulative Layout Shift", good: "0.1", poor: "0.25", unit: "", lowerBetter: true },
  { metric: "FCP", fullName: "First Contentful Paint", good: "1.8", poor: "3.0", unit: "s", lowerBetter: true },
  { metric: "TTFB", fullName: "Time to First Byte", good: "800", poor: "1800", unit: "ms", lowerBetter: true },
];

export default function WebVitalsPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Web Vitals"
        title={
          <>
            Every Core Web
            <br />
            Vitals metric, live.
          </>
        }
        description="LCP, INP, CLS, FCP, and TTFB captured for every real-user pageview, then sliced by route, device, browser, country, and traffic source."
      />

      <CoreWebVitalsSection />

      <section className="py-24 lg:py-32 border-t border-foreground/10">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="mb-16">
            <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
              <span className="w-8 h-px bg-foreground/30" />
              Benchmark table
            </span>
            <h2 className="text-4xl lg:text-5xl font-display tracking-tight">
              What good looks like.
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mt-6 max-w-2xl">
              PagePulse evaluates every Core Web Vital against Google's
              published thresholds, measured at the 75th percentile of real-user
              traffic. Here are the exact numbers we use.
            </p>
          </div>

          <div className="border border-foreground/10 overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-foreground/10 bg-foreground/[0.02]">
                  <th className="text-left px-4 lg:px-6 py-4 text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Metric
                  </th>
                  <th className="text-left px-4 lg:px-6 py-4 text-xs font-mono uppercase tracking-widest text-muted-foreground">
                    Full name
                  </th>
                  <th className="text-left px-4 lg:px-6 py-4 text-xs font-mono uppercase tracking-widest text-green-600">
                    Good
                  </th>
                  <th className="text-left px-4 lg:px-6 py-4 text-xs font-mono uppercase tracking-widest text-amber-600">
                    Needs work
                  </th>
                  <th className="text-left px-4 lg:px-6 py-4 text-xs font-mono uppercase tracking-widest text-red-600">
                    Poor
                  </th>
                </tr>
              </thead>
              <tbody>
                {benchmarks.map((b) => (
                  <tr key={b.metric} className="border-b border-foreground/5 last:border-b-0">
                    <td className="px-4 lg:px-6 py-4 font-mono text-sm">{b.metric}</td>
                    <td className="px-4 lg:px-6 py-4 text-sm text-muted-foreground">{b.fullName}</td>
                    <td className="px-4 lg:px-6 py-4">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                        <span className="font-mono text-sm">under {b.good}{b.unit}</span>
                      </span>
                    </td>
                    <td className="px-4 lg:px-6 py-4">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        <span className="font-mono text-sm text-muted-foreground">{b.good} to {b.poor}{b.unit}</span>
                      </span>
                    </td>
                    <td className="px-4 lg:px-6 py-4">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                        <span className="font-mono text-sm text-muted-foreground">over {b.poor}{b.unit}</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="mt-8 text-sm text-muted-foreground">
            Benchmarks source: Google Chrome team, web.dev/vitals. PagePulse
            evaluates every metric at the 75th percentile of real-user traffic
            per route, per device class, per country.
          </p>
        </div>
      </section>

      <CtaSection />
    </PageShell>
  );
}
