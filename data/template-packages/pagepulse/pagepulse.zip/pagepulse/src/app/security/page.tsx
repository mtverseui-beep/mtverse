import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { SecuritySection } from "@/components/landing/security-section";
import { CtaSection } from "@/components/landing/cta-section";

export const metadata: Metadata = {
  title: "Security",
  description:
    "SOC 2 Type II, ISO 27001, GDPR, CCPA, and HIPAA. End-to-end encryption, zero-trust architecture, and full data residency controls.",
  alternates: { canonical: "/security" },
};

export default function SecurityPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Security"
        title={
          <>
            Trust is
            <br />
            non-negotiable.
          </>
        }
        description="Enterprise-grade security built into every layer of the platform, from ingestion to analytics to long-term storage."
      />
      <SecuritySection />
      <CtaSection />
    </PageShell>
  );
}
