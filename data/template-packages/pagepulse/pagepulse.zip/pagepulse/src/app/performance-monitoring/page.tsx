import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { FeaturePageBody } from "@/components/site/feature-page-body";
import { CtaSection } from "@/components/landing/cta-section";

export const metadata: Metadata = {
  title: "Performance Monitoring",
  description:
    "Route-level performance, JavaScript bundle size, hydration time, render-blocking resources, image weight, and conversion impact in one dashboard.",
  alternates: { canonical: "/performance-monitoring" },
};

const blocks = [
  {
    number: "01",
    title: "Route-level performance",
    description:
      "Every page route in your application gets its own LCP, INP, CLS, FCP, and TTFB score, updated in real time as new RUM samples arrive. Drill into a single route to see the slowest sessions, the slowest devices, and the slowest countries. Compare route performance across releases to catch regressions the moment they ship.",
  },
  {
    number: "02",
    title: "JavaScript bundle size",
    description:
      "PagePulse parses every production build, attributes each byte to its source module, and tracks first-party and third-party JavaScript weight on every route. Set a 175KB budget, get alerted when a PR pushes you over, and see exactly which dependency or component added the weight.",
  },
  {
    number: "03",
    title: "Hydration time",
    description:
      "Measure exactly how long React, Vue, Nuxt, or Next.js takes to hydrate on real devices. PagePulse captures hydration start, hydration end, and total hydration time for every route, then splits the data by device class so you can see whether mid-range Android phones are paying the price for your client component tree.",
  },
  {
    number: "04",
    title: "Render-blocking resources",
    description:
      "Automatically detect render-blocking CSS, sync scripts, and font requests that delay First Contentful Paint. PagePulse ranks each blocker by its impact on FCP, tells you which routes it affects, and suggests the exact preload, defer, or async fix that will move the needle.",
  },
  {
    number: "05",
    title: "Image weight",
    description:
      "Track total image bytes per route, find images over 200KB, and detect missing width and height attributes that cause CLS. PagePulse also identifies images served without modern formats like AVIF or WebP, and recommends the right srcset and sizes attributes for each breakpoint.",
  },
  {
    number: "06",
    title: "Conversion impact",
    description:
      "Correlate page load time, LCP, and INP with bounce rate, add-to-cart, signup, and revenue. PagePulse joins RUM data with your conversion events to quantify exactly how many dollars a 500ms LCP regression is costing you, and which fix will deliver the highest ROI.",
  },
];

export default function PerformanceMonitoringPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Performance Monitoring"
        title={
          <>
            Performance monitoring
            <br />
            for every route.
          </>
        }
        description="Route-level LCP, INP, CLS, JavaScript bundle size, hydration time, render-blocking resources, image weight, and conversion impact. One dashboard, every metric."
      />
      <FeaturePageBody blocks={blocks} />
      <CtaSection />
    </PageShell>
  );
}
