import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { PageShell } from "@/components/site/page-shell";
import { CtaSection } from "@/components/landing/cta-section";
import { customers, getCustomerBySlug } from "@/lib/customers";
import { ArrowLeft, ArrowRight } from "lucide-react";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  return customers.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const customer = getCustomerBySlug(slug);
  if (!customer) {
    return { title: "Customer not found" };
  }
  return {
    title: `${customer.company} case study`,
    description: customer.headline,
    alternates: { canonical: `/customers/${customer.slug}` },
  };
}

export default async function CustomerCaseStudyPage({ params }: PageProps) {
  const { slug } = await params;
  const customer = getCustomerBySlug(slug);
  if (!customer) {
    notFound();
  }

  const currentIndex = customers.findIndex((c) => c.slug === slug);
  const nextCustomer = customers[(currentIndex + 1) % customers.length];

  return (
    <PageShell>
      <article className="pb-24 lg:pb-32">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <Link
            href="/customers"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-12"
          >
            <ArrowLeft className="w-4 h-4" />
            All customers
          </Link>

          <span className="inline-flex items-center gap-3 text-sm font-mono text-muted-foreground mb-6">
            <span className="w-8 h-px bg-foreground/30" />
            {customer.industry}
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-7xl font-display tracking-tight leading-[0.95] mb-8 max-w-4xl">
            {customer.headline}
          </h1>

          <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 mb-16">
            <div className="lg:col-span-7">
              <p className="text-xl text-muted-foreground leading-relaxed">
                {customer.description}
              </p>
            </div>
            <div className="lg:col-span-5">
              <div className="border border-foreground/10 p-8">
                <span className="font-mono text-xs tracking-widest text-muted-foreground uppercase block mb-4">
                  Key result
                </span>
                <p className="font-display text-5xl text-foreground">
                  {customer.metric}
                </p>
                <p className="text-muted-foreground mt-2">{customer.metricLabel}</p>
              </div>
            </div>
          </div>

          <blockquote className="border-l-2 border-foreground pl-6 lg:pl-8 my-16">
            <p className="font-display text-2xl md:text-3xl lg:text-4xl leading-tight text-foreground">
              &ldquo;{customer.quote}&rdquo;
            </p>
            <footer className="mt-6 text-muted-foreground">
              <span className="font-medium text-foreground">{customer.author}</span>
              <br />
              {customer.authorRole}
            </footer>
          </blockquote>

          <div className="grid md:grid-cols-4 gap-px bg-foreground/10 border border-foreground/10 mb-16">
            {customer.results.map((r) => (
              <div key={r.label} className="bg-background p-6 lg:p-8">
                <div className="font-display text-2xl lg:text-3xl text-foreground">
                  {r.value}
                </div>
                <div className="text-sm text-muted-foreground mt-2">{r.label}</div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-12 lg:gap-16 mb-16">
            <div>
              <h2 className="font-display text-2xl mb-6">Challenges</h2>
              <ul className="space-y-4">
                {customer.challenges.map((c, i) => (
                  <li key={i} className="text-muted-foreground leading-relaxed flex gap-3">
                    <span className="font-mono text-xs text-foreground/40 mt-1.5">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span>{c}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h2 className="font-display text-2xl mb-6">Solutions</h2>
              <ul className="space-y-4">
                {customer.solutions.map((s, i) => (
                  <li key={i} className="text-muted-foreground leading-relaxed flex gap-3">
                    <span className="font-mono text-xs text-foreground/40 mt-1.5">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h2 className="font-display text-2xl mb-6">Outcomes</h2>
              <ul className="space-y-4">
                {customer.outcomes.map((o, i) => (
                  <li key={i} className="text-muted-foreground leading-relaxed flex gap-3">
                    <span className="font-mono text-xs text-foreground/40 mt-1.5">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span>{o}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-foreground/10 pt-12">
            <Link
              href={`/customers/${nextCustomer.slug}`}
              className="group inline-flex items-center gap-4"
            >
              <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
                Next case study
              </span>
              <span className="text-2xl lg:text-3xl font-display group-hover:translate-x-2 transition-transform">
                {nextCustomer.company}
              </span>
              <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-2 transition-all" />
            </Link>
          </div>
        </div>
      </article>
      <CtaSection />
    </PageShell>
  );
}
