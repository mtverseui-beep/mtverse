import type { Metadata } from "next";
import Link from "next/link";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { CtaSection } from "@/components/landing/cta-section";
import { customers } from "@/lib/customers";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Customers",
  description:
    "Frontend teams at Meridian Labs, Flux Systems, Beacon Commerce, Prism Analytics, and more use PagePulse to ship faster pages.",
  alternates: { canonical: "/customers" },
};

export default function CustomersPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Customers"
        title={
          <>
            Frontend teams
            <br />
            ship faster with PagePulse.
          </>
        }
        description="From SaaS platforms to ecommerce giants, teams use PagePulse to catch regressions, optimize Core Web Vitals, and protect revenue."
      />

      <section className="pb-24 lg:pb-32">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="grid gap-px bg-foreground/10 border border-foreground/10">
            {customers.map((customer) => (
              <Link
                key={customer.slug}
                href={`/customers/${customer.slug}`}
                className="group bg-background p-8 lg:p-12 hover:bg-foreground/[0.02] transition-colors"
              >
                <div className="grid lg:grid-cols-12 gap-8 items-center">
                  <div className="lg:col-span-5">
                    <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
                      {customer.industry}
                    </span>
                    <h3 className="text-3xl lg:text-4xl font-display mt-2 group-hover:translate-x-1 transition-transform">
                      {customer.company}
                    </h3>
                  </div>
                  <div className="lg:col-span-3">
                    <div className="text-4xl lg:text-5xl font-display text-foreground">
                      {customer.metric}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      {customer.metricLabel}
                    </div>
                  </div>
                  <div className="lg:col-span-3">
                    <p className="text-muted-foreground leading-relaxed">
                      {customer.headline}
                    </p>
                  </div>
                  <div className="lg:col-span-1 flex justify-end">
                    <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CtaSection />
    </PageShell>
  );
}
