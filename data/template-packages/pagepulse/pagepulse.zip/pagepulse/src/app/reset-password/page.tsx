"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Eye, EyeOff, ArrowLeft, Check } from "lucide-react";
import { AuthShell } from "@/components/site/auth-shell";
import { cn } from "@/lib/utils";

export default function ResetPasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<{ password?: string; confirm?: string }>({});
  const [submitting, setSubmitting] = useState(false);

  const validate = (): boolean => {
    const next: { password?: string; confirm?: string } = {};
    if (!password) {
      next.password = "Password is required.";
    } else if (password.length < 10) {
      next.password = "Password must be at least 10 characters.";
    } else if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
      next.password = "Use upper and lowercase letters, and a number.";
    }
    if (!confirm) {
      next.confirm = "Please confirm your password.";
    } else if (confirm !== password) {
      next.confirm = "Passwords do not match.";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      toast.error("Please fix the errors in the form.");
      return;
    }
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 1000));
    setSubmitting(false);
    toast.success("Password updated", {
      description: "You can now sign in with your new password.",
    });
    setTimeout(() => router.push("/sign-in"), 800);
  };

  const inputClass = (hasError?: boolean) =>
    cn(
      "w-full px-3 py-2.5 bg-transparent border focus:outline-none transition-colors text-sm",
      hasError
        ? "border-red-500 focus:border-red-500"
        : "border-foreground/15 focus:border-foreground/40"
    );

  const requirements = [
    { label: "At least 10 characters", met: password.length >= 10 },
    { label: "One uppercase letter", met: /[A-Z]/.test(password) },
    { label: "One lowercase letter", met: /[a-z]/.test(password) },
    { label: "One number", met: /\d/.test(password) },
  ];

  return (
    <AuthShell
      title="Set a new password"
      description="Choose a strong password for your PagePulse account. This link is valid for 60 minutes."
      footer={
        <Link
          href="/sign-in"
          className="inline-flex items-center gap-2 text-foreground hover:underline underline-offset-4"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Back to sign in
        </Link>
      }
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        <div>
          <label htmlFor="password" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            New password
          </label>
          <div className="relative">
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              autoComplete="new-password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (errors.password) setErrors((p) => ({ ...p, password: undefined }));
              }}
              className={inputClass(!!errors.password) + " pr-10"}
              placeholder="At least 10 characters"
              aria-invalid={!!errors.password}
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {errors.password && <p className="text-xs text-red-600 mt-1.5">{errors.password}</p>}
          {password && (
            <ul className="mt-3 space-y-1.5">
              {requirements.map((r) => (
                <li
                  key={r.label}
                  className={cn(
                    "flex items-center gap-2 text-xs",
                    r.met ? "text-green-600" : "text-muted-foreground"
                  )}
                >
                  <Check className={cn("w-3 h-3", r.met ? "opacity-100" : "opacity-30")} />
                  {r.label}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div>
          <label htmlFor="confirm" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            Confirm password
          </label>
          <input
            id="confirm"
            type={showPassword ? "text" : "password"}
            autoComplete="new-password"
            value={confirm}
            onChange={(e) => {
              setConfirm(e.target.value);
              if (errors.confirm) setErrors((p) => ({ ...p, confirm: undefined }));
            }}
            className={inputClass(!!errors.confirm)}
            placeholder="Re-enter your password"
            aria-invalid={!!errors.confirm}
          />
          {errors.confirm && <p className="text-xs text-red-600 mt-1.5">{errors.confirm}</p>}
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-foreground text-background h-11 text-sm font-medium hover:bg-foreground/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
        >
          {submitting ? (
            <>
              <span className="w-4 h-4 border-2 border-background/30 border-t-background rounded-full animate-spin" />
              Updating password...
            </>
          ) : (
            "Update password"
          )}
        </button>
      </form>
    </AuthShell>
  );
}
