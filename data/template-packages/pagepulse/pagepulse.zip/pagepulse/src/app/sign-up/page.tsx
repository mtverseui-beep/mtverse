"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Eye, EyeOff, Github } from "lucide-react";
import { AuthShell } from "@/components/site/auth-shell";
import { cn } from "@/lib/utils";

interface FormState {
  name: string;
  workEmail: string;
  password: string;
  company: string;
}

interface FormErrors {
  name?: string;
  workEmail?: string;
  password?: string;
}

export default function SignUpPage() {
  const router = useRouter();
  const [form, setForm] = useState<FormState>({
    name: "",
    workEmail: "",
    password: "",
    company: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [agreed, setAgreed] = useState(false);

  const validate = (): boolean => {
    const next: FormErrors = {};
    if (!form.name.trim()) next.name = "Please enter your name.";
    if (!form.workEmail.trim()) {
      next.workEmail = "Work email is required.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.workEmail)) {
      next.workEmail = "Please enter a valid email address.";
    } else if (/@(gmail|yahoo|outlook|hotmail|icloud)\./i.test(form.workEmail)) {
      next.workEmail = "Please use a work email address.";
    }
    if (!form.password) {
      next.password = "Password is required.";
    } else if (form.password.length < 10) {
      next.password = "Password must be at least 10 characters.";
    } else if (!/[A-Z]/.test(form.password) || !/[a-z]/.test(form.password) || !/\d/.test(form.password)) {
      next.password = "Use upper and lowercase letters, and a number.";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreed) {
      toast.error("Please accept the Terms of Service to continue.");
      return;
    }
    if (!validate()) {
      toast.error("Please fix the errors in the form.");
      return;
    }
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 1100));
    setSubmitting(false);
    toast.success("Account created", {
      description: "Check your email to verify your account.",
    });
    setTimeout(() => router.push("/"), 800);
  };

  const handleChange = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (errors[key as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [key as keyof FormErrors]: undefined }));
    }
  };

  const inputClass = (hasError?: boolean) =>
    cn(
      "w-full px-3 py-2.5 bg-transparent border focus:outline-none transition-colors text-sm",
      hasError
        ? "border-red-500 focus:border-red-500"
        : "border-foreground/15 focus:border-foreground/40"
    );

  // Password strength
  const strength: number = (() => {
    let s = 0;
    if (form.password.length >= 10) s++;
    if (/[A-Z]/.test(form.password)) s++;
    if (/[a-z]/.test(form.password)) s++;
    if (/\d/.test(form.password)) s++;
    if (/[^A-Za-z0-9]/.test(form.password)) s++;
    return s;
  })();
  const strengthLabel = ["Too weak", "Weak", "Fair", "Good", "Strong", "Excellent"][strength];
  const strengthColor = ["bg-red-500", "bg-red-500", "bg-amber-500", "bg-amber-500", "bg-green-500", "bg-green-500"][strength];

  return (
    <AuthShell
      title="Create your workspace"
      description="Start monitoring Core Web Vitals in under 2 minutes. No credit card required."
      footer={
        <>
          Already have an account?{" "}
          <Link href="/sign-in" className="text-foreground hover:underline underline-offset-4">
            Sign in
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="name" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Name
            </label>
            <input
              id="name"
              type="text"
              autoComplete="name"
              value={form.name}
              onChange={(e) => handleChange("name", e.target.value)}
              className={inputClass(!!errors.name)}
              placeholder="Jane Doe"
              aria-invalid={!!errors.name}
            />
            {errors.name && <p className="text-xs text-red-600 mt-1.5">{errors.name}</p>}
          </div>
          <div>
            <label htmlFor="company" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              Company
            </label>
            <input
              id="company"
              type="text"
              autoComplete="organization"
              value={form.company}
              onChange={(e) => handleChange("company", e.target.value)}
              className={inputClass(false)}
              placeholder="Acme Inc."
            />
          </div>
        </div>

        <div>
          <label htmlFor="workEmail" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            Work email
          </label>
          <input
            id="workEmail"
            type="email"
            autoComplete="email"
            value={form.workEmail}
            onChange={(e) => handleChange("workEmail", e.target.value)}
            className={inputClass(!!errors.workEmail)}
            placeholder="you@company.com"
            aria-invalid={!!errors.workEmail}
          />
          {errors.workEmail && <p className="text-xs text-red-600 mt-1.5">{errors.workEmail}</p>}
        </div>

        <div>
          <label htmlFor="password" className="block text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
            Password
          </label>
          <div className="relative">
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              autoComplete="new-password"
              value={form.password}
              onChange={(e) => handleChange("password", e.target.value)}
              className={inputClass(!!errors.password) + " pr-10"}
              placeholder="At least 10 characters"
              aria-invalid={!!errors.password}
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {form.password && (
            <div className="mt-2 flex items-center gap-2">
              <div className="flex-1 h-1 bg-foreground/5 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${strengthColor}`}
                  style={{ width: `${(strength / 5) * 100}%` }}
                />
              </div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground w-16 text-right">
                {strengthLabel}
              </span>
            </div>
          )}
          {errors.password && <p className="text-xs text-red-600 mt-1.5">{errors.password}</p>}
        </div>

        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
            className="mt-1 w-4 h-4 accent-foreground shrink-0"
          />
          <span className="text-xs text-muted-foreground leading-relaxed">
            I agree to the{" "}
            <Link href="/terms" className="text-foreground hover:underline underline-offset-4">Terms of Service</Link>{" "}
            and{" "}
            <Link href="/privacy" className="text-foreground hover:underline underline-offset-4">Privacy Policy</Link>.
          </span>
        </label>

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-foreground text-background h-11 text-sm font-medium hover:bg-foreground/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
        >
          {submitting ? (
            <>
              <span className="w-4 h-4 border-2 border-background/30 border-t-background rounded-full animate-spin" />
              Creating account...
            </>
          ) : (
            "Create account"
          )}
        </button>

        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full h-px bg-foreground/10" />
          </div>
          <div className="relative flex justify-center">
            <span className="bg-background px-3 text-xs font-mono uppercase tracking-widest text-muted-foreground">
              or sign up with
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => toast.info("GitHub OAuth is not configured in this demo.")}
            className="h-11 border border-foreground/15 hover:border-foreground/40 hover:bg-foreground/5 transition-colors text-sm flex items-center justify-center gap-2"
          >
            <Github className="w-4 h-4" />
            GitHub
          </button>
          <button
            type="button"
            onClick={() => toast.info("Google OAuth is not configured in this demo.")}
            className="h-11 border border-foreground/15 hover:border-foreground/40 hover:bg-foreground/5 transition-colors text-sm flex items-center justify-center gap-2"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z" />
            </svg>
            Google
          </button>
        </div>
      </form>
    </AuthShell>
  );
}
