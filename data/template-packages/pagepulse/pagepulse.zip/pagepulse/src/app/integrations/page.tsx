import type { Metadata } from "next";
import { PageShell } from "@/components/site/page-shell";
import { PageHeader } from "@/components/site/page-header";
import { IntegrationsSection } from "@/components/landing/integrations-section";
import { CtaSection } from "@/components/landing/cta-section";

export const metadata: Metadata = {
  title: "Integrations",
  description:
    "Connect PagePulse to Vercel, Netlify, Cloudflare, GitHub, GitLab, Sentry, Slack, Linear, Jira, Google Analytics, Next.js, React, Vue, Nuxt, Remix, Astro, and webhooks.",
  alternates: { canonical: "/integrations" },
};

export default function IntegrationsPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Integrations"
        title={
          <>
            Works with everything
            <br />
            you already use.
          </>
        }
        description="Connect performance monitoring directly to your deployment, analytics, and issue-tracking workflow."
      />
      <IntegrationsSection />
      <CtaSection />
    </PageShell>
  );
}
