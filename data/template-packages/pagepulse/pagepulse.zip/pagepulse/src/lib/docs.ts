export interface DocBlock {
  type: "paragraph" | "heading" | "code" | "list" | "callout";
  text?: string;
  language?: string;
  code?: string;
  items?: string[];
  variant?: "info" | "warning" | "success";
}

export interface DocPage {
  slug: string;
  title: string;
  description: string;
  category: string;
  blocks: DocBlock[];
}

export interface DocCategory {
  label: string;
  items: { slug: string; title: string }[];
}

export const docCategories: DocCategory[] = [
  {
    label: "Getting started",
    items: [
      { slug: "installation", title: "Installation" },
      { slug: "web-vitals", title: "Web Vitals" },
    ],
  },
  {
    label: "Configuration",
    items: [
      { slug: "performance-budgets", title: "Performance budgets" },
      { slug: "deployments", title: "Deployment tracking" },
      { slug: "custom-metrics", title: "Custom metrics" },
    ],
  },
  {
    label: "API",
    items: [
      { slug: "api", title: "API reference" },
      { slug: "webhooks", title: "Webhooks" },
    ],
  },
];

export const docPages: DocPage[] = [
  {
    slug: "installation",
    title: "Installation",
    description:
      "Install the PagePulse browser SDK in under 2 minutes. Supports npm, script tag, Next.js, React, Vue, and more.",
    category: "Getting started",
    blocks: [
      {
        type: "paragraph",
        text: "The PagePulse browser SDK is a 4KB gzipped package with zero runtime dependencies. It uses the beacon API for non-blocking uploads and respects the user's Save-Data header. Installation takes under 2 minutes.",
      },
      { type: "heading", text: "Install the package" },
      {
        type: "paragraph",
        text: "Install @pagepulse/web from npm. The package ships with full TypeScript types and works in any modern bundler.",
      },
      {
        type: "code",
        language: "bash",
        code: `npm install @pagepulse/web

# or
yarn add @pagepulse/web
pnpm add @pagepulse/web`,
      },
      { type: "heading", text: "Initialize the SDK" },
      {
        type: "paragraph",
        text: "Call PagePulse.init once on page load, before any user interaction. The projectId is required and identifies which PagePulse workspace the data should be sent to. You can find your project ID in the workspace settings page.",
      },
      {
        type: "code",
        language: "typescript",
        code: `import { PagePulse } from '@pagepulse/web';

PagePulse.init({
  projectId: 'site_123',
  trackWebVitals: true,
  trackRoutes: true,
  trackErrors: true,
});`,
      },
      { type: "heading", text: "Script tag install" },
      {
        type: "paragraph",
        text: "If you do not use a bundler, you can install PagePulse with a single script tag. Add it to the <head> of every page, before any other scripts.",
      },
      {
        type: "code",
        language: "html",
        code: `<script src="https://cdn.pagepulse.dev/v2/pagepulse.min.js"></script>
<script>
  PagePulse.init({
    projectId: 'site_123',
    trackWebVitals: true,
    trackRoutes: true,
  });
</script>`,
      },
      { type: "heading", text: "Next.js integration" },
      {
        type: "paragraph",
        text: "For Next.js App Router, create a client component that initializes PagePulse on mount. Place it inside your root layout so it loads on every route.",
      },
      {
        type: "code",
        language: "typescript",
        code: `'use client';

import { useEffect } from 'react';
import { PagePulse } from '@pagepulse/web';

export function PagePulseProvider({
  projectId,
}: {
  projectId: string;
}) {
  useEffect(() => {
    PagePulse.init({
      projectId,
      trackWebVitals: true,
      trackRoutes: true,
      trackErrors: true,
    });
  }, [projectId]);

  return null;
}`,
      },
      {
        type: "callout",
        variant: "success",
        text: "That's it. Within 60 seconds, the first real-user Web Vitals samples will appear in your dashboard.",
      },
      { type: "heading", text: "Verification" },
      {
        type: "paragraph",
        text: "To verify the SDK is working, open your browser's developer tools and look for a network request to ingest.pagepulse.dev. The request will be sent using the beacon API, so it will appear in the Network tab as type 'ping'.",
      },
    ],
  },
  {
    slug: "web-vitals",
    title: "Web Vitals",
    description:
      "Reference for the Core Web Vitals captured by PagePulse: LCP, INP, CLS, FCP, and TTFB. Includes thresholds and what good looks like.",
    category: "Getting started",
    blocks: [
      {
        type: "paragraph",
        text: "PagePulse captures five Core Web Vitals on every real-user pageview: Largest Contentful Paint (LCP), Interaction to Next Paint (INP), Cumulative Layout Shift (CLS), First Contentful Paint (FCP), and Time to First Byte (TTFB). All five are reported at the 75th percentile per route, per device class, per country.",
      },
      { type: "heading", text: "Largest Contentful Paint (LCP)" },
      {
        type: "paragraph",
        text: "LCP measures the render time of the largest text or image block visible in the viewport. The target is under 2.5 seconds at the 75th percentile of real-user page loads. A poor LCP is over 4.0 seconds. Common LCP offenders are unoptimized hero images, render-blocking CSS, slow origin server response, and client-side rendering of above-the-fold content.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.on('lcp', (metric) => {
  console.log('LCP:', metric.value, 'ms');
  console.log('Element:', metric.attribution.element);
  console.log('URL:', metric.attribution.url);
});`,
      },
      { type: "heading", text: "Interaction to Next Paint (INP)" },
      {
        type: "paragraph",
        text: "INP measures the latency of every tap, click, and keystroke throughout the page lifecycle, then reports the 75th percentile. A good INP is under 200ms; a poor one is over 500ms. INP replaced First Input Delay (FID) as a Core Web Vital in March 2024.",
      },
      {
        type: "paragraph",
        text: "Common INP offenders are long tasks on the main thread, synchronous event handlers, heavy client-side rendering, and large JavaScript bundles. The most effective fix is usually to defer non-critical work out of the event handler using scheduler.postTask or setTimeout.",
      },
      { type: "heading", text: "Cumulative Layout Shift (CLS)" },
      {
        type: "paragraph",
        text: "CLS measures unexpected layout shifts caused by images without dimensions, web fonts, dynamically injected content, and slow third-party widgets. A good CLS is under 0.1; a poor one is over 0.25. The fix is almost always the same: reserve space for content before it loads.",
      },
      { type: "heading", text: "First Contentful Paint (FCP)" },
      {
        type: "paragraph",
        text: "FCP measures the moment the browser first renders any text, image, or canvas. A good FCP is under 1.8 seconds; a poor one is over 3.0 seconds. FCP is highly correlated with TTFB and render-blocking resources.",
      },
      { type: "heading", text: "Time to First Byte (TTFB)" },
      {
        type: "paragraph",
        text: "TTFB measures the time from request start to the first byte of the HTML response. A good TTFB is under 800ms; a poor one is over 1.8 seconds. TTFB is affected by origin server response time, edge function execution, database queries, and CDN cache hit rate.",
      },
      {
        type: "callout",
        variant: "info",
        text: "PagePulse captures all five metrics automatically when trackWebVitals is enabled. No additional configuration is required.",
      },
    ],
  },
  {
    slug: "performance-budgets",
    title: "Performance budgets",
    description:
      "Set thresholds for LCP, INP, CLS, JavaScript bundle size, image weight, and route speed. Alert Slack, send webhooks, or fail CI on breach.",
    category: "Configuration",
    blocks: [
      {
        type: "paragraph",
        text: "Performance budgets are hard limits on metrics that matter. When a budget is breached, PagePulse can trigger a Slack alert, send a webhook, file a Linear or Jira ticket, or fail a CI check. This guide covers how to define budgets, how they are evaluated, and how to enforce them in CI.",
      },
      { type: "heading", text: "Defining a budget" },
      {
        type: "paragraph",
        text: "Use PagePulse.setBudget to define one or more budgets. Budgets are evaluated against the 75th percentile of real-user traffic over the trailing 24 hours, refreshed every 5 minutes.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.setBudget({
  // Core Web Vitals
  lcp: 2500,         // ms, target under 2.5s
  inp: 200,          // ms, target under 200ms
  cls: 0.1,          // score, target under 0.1
  ttfb: 800,         // ms, target under 800ms
  fcp: 1800,         // ms, target under 1.8s

  // Asset budgets
  jsSizeKB: 180,     // first-party + third-party JS
  imageSizeKB: 500,  // total image weight per route
  cssSizeKB: 50,     // total CSS weight per route

  // Timing budgets
  routeLoadMs: 1000, // time to load a route
  hydrationMs: 800,  // React/Vue hydration time
});`,
      },
      { type: "heading", text: "Per-route budgets" },
      {
        type: "paragraph",
        text: "Different routes have different needs. Your marketing homepage and your authenticated dashboard have very different performance characteristics. Set per-route budgets that reflect the actual work each page does.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.setBudget({
  routes: {
    '/':            { lcp: 2500, inp: 200, cls: 0.1 },
    '/dashboard':   { lcp: 3500, inp: 300, cls: 0.1 },
    '/blog/[slug]': { lcp: 2000, inp: 200, cls: 0.05 },
  },
  jsSizeKB: 180,
});`,
      },
      { type: "heading", text: "Alerting on breach" },
      {
        type: "paragraph",
        text: "Configure alert destinations from the dashboard, or programmatically via the API. PagePulse will fire an alert within 5 minutes of a budget breach.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.configureAlerts({
  destinations: ['slack', 'webhook', 'linear'],
  slack: { channel: '#perf-alerts' },
  webhook: { url: 'https://api.example.com/pagepulse' },
  linear: { teamId: 'eng', label: 'performance' },
});`,
      },
      { type: "heading", text: "CI enforcement" },
      {
        type: "paragraph",
        text: "Use the @pagepulse/ci package to fail a pull request when a budget would be breached. PagePulse posts a comment to the PR showing exactly which budget was exceeded, by how much, and which module caused the regression.",
      },
      {
        type: "code",
        language: "bash",
        code: `# In your CI pipeline
npx @pagepulse/ci check \\
  --project site_123 \\
  --base origin/main \\
  --head HEAD`,
      },
      {
        type: "callout",
        variant: "warning",
        text: "Budgets evaluated in CI use synthetic measurements from the PR branch against the base branch. They are not a replacement for real-user monitoring; they are a first line of defense.",
      },
    ],
  },
  {
    slug: "deployments",
    title: "Deployment tracking",
    description:
      "Tag every release with version, commit, and environment. PagePulse diffs Core Web Vitals and JS size between releases automatically.",
    category: "Configuration",
    blocks: [
      {
        type: "paragraph",
        text: "Deployment tracking tags every release in your production environment so PagePulse can diff Core Web Vitals, JavaScript bundle size, route load time, and error rate before and after the release. Regressions are surfaced within minutes of going live.",
      },
      { type: "heading", text: "Marking a deployment" },
      {
        type: "paragraph",
        text: "Call PagePulse.deployment once per release, after the deploy succeeds. Pass a version string, the environment, and the commit SHA. PagePulse correlates every RUM sample collected after the call with the new deployment.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.deployment({
  version: 'v2.8.1',
  environment: 'production',
  commit: process.env.GIT_SHA,
  branch: process.env.GIT_BRANCH,
  author: process.env.GIT_AUTHOR,
});`,
      },
      { type: "heading", text: "CI/CD integration" },
      {
        type: "paragraph",
        text: "The most reliable pattern is to call PagePulse.deployment from your CI/CD pipeline after a successful deploy. This ensures every release is tagged, even if your team forgets to do it manually.",
      },
      {
        type: "code",
        language: "yaml",
        code: `# .github/workflows/deploy.yml
name: Deploy
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to production
        run: ./scripts/deploy.sh
      - name: Mark deployment in PagePulse
        env:
          PAGEPULSE_PROJECT_ID: \${{ secrets.PAGEPULSE_PROJECT_ID }}
          PAGEPULSE_API_KEY: \${{ secrets.PAGEPULSE_API_KEY }}
          GIT_SHA: \${{ github.sha }}
        run: |
          curl -X POST https://api.pagepulse.dev/v2/deployments \\
            -H "Authorization: Bearer $PAGEPULSE_API_KEY" \\
            -H "Content-Type: application/json" \\
            -d "{
              \\"projectId\\": \\"$PAGEPULSE_PROJECT_ID\\",
              \\"version\\": \\"$(git describe --tags --always)\\",
              \\"environment\\": \\"production\\",
              \\"commit\\": \\"$GIT_SHA\\"
            }"`,
      },
      { type: "heading", text: "Canary and A/B variants" },
      {
        type: "paragraph",
        text: "Tag deployments as canary, blue/green, or A/B test variants. PagePulse will compare the performance of each variant against the control, surface statistically significant differences, and help you decide whether to roll forward or roll back.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.deployment({
  version: 'v2.8.1',
  environment: 'production',
  commit: 'a1b2c3d',
  variant: 'canary',
  trafficPercent: 10,
});`,
      },
    ],
  },
  {
    slug: "custom-metrics",
    title: "Custom metrics",
    description:
      "Track any timing or business KPI alongside Core Web Vitals. Filter, segment, and alert on custom metrics.",
    category: "Configuration",
    blocks: [
      {
        type: "paragraph",
        text: "Custom metrics let you track any timing or business KPI alongside PagePulse's built-in Core Web Vitals. Use them to measure checkout interaction time, search result render time, video start time, or any other event that matters to your product.",
      },
      { type: "heading", text: "Tracking a custom metric" },
      {
        type: "paragraph",
        text: "Use PagePulse.metric to track a custom timing. The first argument is the metric name, the second is the value in milliseconds, and the optional third argument is a metadata object that will be attached to the metric.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.metric('checkout_interactive', 184, {
  route: '/checkout',
  step: 'payment',
  device: 'mobile',
});`,
      },
      { type: "heading", text: "Counters and gauges" },
      {
        type: "paragraph",
        text: "In addition to timing metrics, PagePulse supports counters (for events like search results rendered, items added to cart) and gauges (for values like current queue depth, active users).",
      },
      {
        type: "code",
        language: "typescript",
        code: `// Counter: increments a counter by 1 (or by an explicit amount)
PagePulse.counter('search_results_rendered', 248);

// Gauge: sets an absolute value
PagePulse.gauge('active_users', 1423);`,
      },
      { type: "heading", text: "Filtering and segmenting" },
      {
        type: "paragraph",
        text: "Custom metrics appear in the dashboard alongside Core Web Vitals. Use the metadata you passed in to filter and segment. For example, you can view checkout_interactive by route, by device, by step, or by any combination.",
      },
      { type: "heading", text: "Alerting on custom metrics" },
      {
        type: "paragraph",
        text: "Set budgets on custom metrics the same way you would on Core Web Vitals. When the 75th percentile of a custom metric exceeds its threshold for 5 consecutive minutes, PagePulse will fire the configured alerts.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.setBudget({
  custom: {
    checkout_interactive: 300, // ms
    search_results_rendered: 200, // count
  },
});`,
      },
      {
        type: "callout",
        variant: "info",
        text: "Custom metric names must be snake_case and between 3 and 64 characters. Metadata keys must be snake_case and between 1 and 32 characters.",
      },
    ],
  },
  {
    slug: "api",
    title: "API reference",
    description:
      "PagePulse REST API reference. Authenticate with a project API key to query Web Vitals, deployments, budgets, and alerts.",
    category: "API",
    blocks: [
      {
        type: "paragraph",
        text: "The PagePulse REST API is available at https://api.pagepulse.dev. All requests must be authenticated with a project API key, which you can generate from your workspace settings. The API returns JSON and follows REST conventions.",
      },
      { type: "heading", text: "Authentication" },
      {
        type: "paragraph",
        text: "Pass your API key in the Authorization header as a Bearer token. API keys are scoped to a single project and can be revoked at any time.",
      },
      {
        type: "code",
        language: "bash",
        code: `curl https://api.pagepulse.dev/v2/metrics \\
  -H "Authorization: Bearer pp_live_abc123"`,
      },
      { type: "heading", text: "List Web Vitals metrics" },
      {
        type: "paragraph",
        text: "Returns Core Web Vitals for a project, optionally filtered by route, device, browser, country, and date range. The response is a JSON object with one entry per route.",
      },
      {
        type: "code",
        language: "bash",
        code: `GET /v2/metrics?projectId=site_123&route=/checkout&from=2025-06-01&to=2025-06-30

# Response
{
  "routes": [
    {
      "route": "/checkout",
      "samples": 42103,
      "lcp_p75": 4100,
      "inp_p75": 320,
      "cls_p75": 0.18,
      "fcp_p75": 2800,
      "ttfb_p75": 920,
      "score": 52
    }
  ]
}`,
      },
      { type: "heading", text: "Create a deployment marker" },
      {
        type: "paragraph",
        text: "Marks a new deployment. PagePulse will begin correlating RUM samples collected after this call with the new deployment.",
      },
      {
        type: "code",
        language: "bash",
        code: `POST /v2/deployments
Content-Type: application/json

{
  "projectId": "site_123",
  "version": "v2.8.1",
  "environment": "production",
  "commit": "a1b2c3d"
}`,
      },
      { type: "heading", text: "Get deployment diff" },
      {
        type: "paragraph",
        text: "Returns the before/after diff of Core Web Vitals, JavaScript bundle size, route load time, and error rate for a specific deployment.",
      },
      {
        type: "code",
        language: "bash",
        code: `GET /v2/deployments/dep_abc/diff?projectId=site_123

# Response
{
  "deployment": {
    "id": "dep_abc",
    "version": "v2.8.1",
    "environment": "production"
  },
  "diff": {
    "lcp_p75": { "before": 2300, "after": 1700, "delta": -600 },
    "inp_p75": { "before": 180, "after": 96, "delta": -84 },
    "jsSizeKB": { "before": 248, "after": 184, "delta": -64 }
  },
  "affectedRoutes": [...]
}`,
      },
      { type: "heading", text: "Rate limits" },
      {
        type: "paragraph",
        text: "The API is rate-limited to 100 requests per minute per API key. If you exceed the limit, the API will respond with 429 Too Many Requests and include a Retry-After header. Rate limits reset every 60 seconds.",
      },
      {
        type: "callout",
        variant: "info",
        text: "Need higher rate limits? Scale plans include 1,000 requests per minute. Contact sales for custom limits.",
      },
    ],
  },
  {
    slug: "webhooks",
    title: "Webhooks",
    description:
      "Stream performance events to any HTTP endpoint. Every webhook is HMAC-signed and timestamped for verification.",
    category: "API",
    blocks: [
      {
        type: "paragraph",
        text: "Webhooks let you stream PagePulse events to any HTTP endpoint. Use them to trigger incident response, sync performance data to your data warehouse, or build custom alerts in your own tooling. Every webhook is HMAC-signed and timestamped for verification.",
      },
      { type: "heading", text: "Subscribing to events" },
      {
        type: "paragraph",
        text: "Configure webhook destinations from the dashboard, or programmatically via the API. You can subscribe to all event types or filter by type.",
      },
      {
        type: "code",
        language: "typescript",
        code: `await fetch('https://api.pagepulse.dev/v2/webhooks', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer ' + apiKey,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    projectId: 'site_123',
    url: 'https://api.example.com/pagepulse',
    events: [
      'budget.breached',
      'budget.recovered',
      'deployment.regression',
      'deployment.improvement',
      'alert.fired',
    ],
  }),
});`,
      },
      { type: "heading", text: "Event payload" },
      {
        type: "paragraph",
        text: "Every webhook delivery is a POST request with a JSON body. The body includes the event type, the timestamp, the project ID, and a data object whose shape depends on the event type.",
      },
      {
        type: "code",
        language: "json",
        code: `{
  "id": "evt_abc123",
  "type": "budget.breached",
  "createdAt": "2025-06-24T14:12:03Z",
  "projectId": "site_123",
  "data": {
    "budget": "lcp",
    "route": "/checkout",
    "threshold": 2500,
    "actual": 4100,
    "delta": 1600
  }
}`,
      },
      { type: "heading", text: "Verifying the signature" },
      {
        type: "paragraph",
        text: "Every webhook delivery includes a PagePulse-Signature header. The header is formatted as t=<timestamp>,v1=<signature>. To verify, compute the HMAC-SHA256 of the timestamp concatenated with the request body, using your webhook signing secret as the key.",
      },
      {
        type: "code",
        language: "typescript",
        code: `import crypto from 'crypto';

function verifySignature(
  body: string,
  signatureHeader: string,
  secret: string
): boolean {
  const parts = signatureHeader.split(',');
  const timestamp = parts.find(p => p.startsWith('t='))?.slice(2);
  const signature = parts.find(p => p.startsWith('v1='))?.slice(3);

  if (!timestamp || !signature) return false;

  const expected = crypto
    .createHmac('sha256', secret)
    .update(timestamp + body)
    .digest('hex');

  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expected)
  );
}`,
      },
      { type: "heading", text: "Retries" },
      {
        type: "paragraph",
        text: "If your endpoint responds with a non-2xx status code, PagePulse will retry the delivery with exponential backoff for up to 24 hours. After 24 hours, the delivery is marked as failed and the event is available for manual replay from the dashboard.",
      },
      {
        type: "callout",
        variant: "info",
        text: "Your endpoint must respond within 10 seconds with a 2xx status code to be considered successful.",
      },
    ],
  },
];

export function getDocBySlug(slug: string): DocPage | undefined {
  return docPages.find((p) => p.slug === slug);
}

export function getAdjacentDocs(slug: string): {
  prev?: { slug: string; title: string };
  next?: { slug: string; title: string };
} {
  const flat = docCategories.flatMap((c) => c.items);
  const idx = flat.findIndex((i) => i.slug === slug);
  return {
    prev: idx > 0 ? flat[idx - 1] : undefined,
    next: idx < flat.length - 1 ? flat[idx + 1] : undefined,
  };
}
