export interface Customer {
  slug: string;
  company: string;
  industry: string;
  logo: string;
  metric: string;
  metricLabel: string;
  headline: string;
  description: string;
  quote: string;
  author: string;
  authorRole: string;
  results: { label: string; value: string }[];
  challenges: string[];
  solutions: string[];
  outcomes: string[];
}

export const customers: Customer[] = [
  {
    slug: "meridian-labs",
    company: "Meridian Labs",
    industry: "SaaS Platform",
    logo: "Meridian Labs",
    metric: "10x",
    metricLabel: "faster regression catches",
    headline: "Meridian Labs caught a 700ms LCP regression on the first deploy.",
    description:
      "Meridian Labs builds a popular design collaboration SaaS used by 40,000 product teams. Before PagePulse, performance regressions shipped to production silently and were only discovered weeks later when churn ticked up. With PagePulse, every release is benchmarked against the previous one in real time.",
    quote:
      "PagePulse caught a 700ms LCP regression on the very first deploy after install. The whole team now ships performance reviews alongside code reviews.",
    author: "Sarah Chen",
    authorRole: "Staff Engineer, Meridian Labs",
    results: [
      { label: "LCP regression caught", value: "Day 1" },
      { label: "Mean time to detect", value: "5 min" },
      { label: "Releases per week", value: "Up 3x" },
      { label: "Customer-reported perf issues", value: "Down 84%" },
    ],
    challenges: [
      "Performance regressions were discovered weeks after shipping, when churn metrics ticked up.",
      "No automated before/after comparison between releases meant manual sampling with Lighthouse.",
      "Frontend engineers had no visibility into real user experience on mid-range devices.",
    ],
    solutions: [
      "Installed the @pagepulse/web SDK in under 2 minutes via the Next.js package.",
      "Tagged every deployment with version, commit, and environment using markDeployment.",
      "Set a 2.5s LCP budget on every route with Slack alerts on breach.",
    ],
    outcomes: [
      "Caught a 700ms LCP regression on the very first deploy after install.",
      "Reduced mean time to detect a regression from 14 days to 5 minutes.",
      "Increased release cadence 3x without compromising performance.",
      "Reduced customer-reported performance issues by 84% in 6 months.",
    ],
  },
  {
    slug: "flux-systems",
    company: "Flux Systems",
    industry: "Developer Tools",
    logo: "Flux Systems",
    metric: "65%",
    metricLabel: "INP reduction",
    headline: "Flux Systems cut INP from 280ms to 96ms in two sprints.",
    description:
      "Flux Systems builds an observability platform for engineering teams. Their dashboard rendered hundreds of charts on a single page, leading to sluggish interactions. PagePulse's INP breakdown by interaction type helped them pinpoint the slowest event handlers.",
    quote:
      "We finally have one source of truth for LCP, INP and CLS across every Next.js route. INP dropped from 280ms to 96ms in two sprints.",
    author: "Marcus Webb",
    authorRole: "Engineering Lead, Flux Systems",
    results: [
      { label: "INP before", value: "280ms" },
      { label: "INP after", value: "96ms" },
      { label: "Routes optimized", value: "18" },
      { label: "Sprints to ship", value: "2" },
    ],
    challenges: [
      "INP on the main dashboard was over 280ms on mid-range laptops.",
      "No visibility into which event handlers were the slowest.",
      "Synthetic Lighthouse tests did not reflect real user experience.",
    ],
    solutions: [
      "Used PagePulse's INP breakdown by interaction type to rank the slowest handlers.",
      "Set a 200ms INP budget with webhook alerts to the team's incident channel.",
      "Refactored the 6 slowest handlers to defer non-critical work.",
    ],
    outcomes: [
      "Cut 75th-percentile INP from 280ms to 96ms across all routes.",
      "Optimized 18 routes in two sprints using PagePulse's per-route breakdown.",
      "Improved user satisfaction score from 7.2 to 9.1.",
    ],
  },
  {
    slug: "beacon-commerce",
    company: "Beacon Commerce",
    industry: "Ecommerce",
    logo: "Beacon Commerce",
    metric: "0",
    metricLabel: "slow releases in 6 months",
    headline: "Beacon Commerce has not shipped a slow release in 6 months.",
    description:
      "Beacon Commerce operates a headless commerce platform serving 12 million monthly shoppers. Every 100ms of LCP regression translated to measurable revenue loss. PagePulse's deployment impact diffing now blocks any release that regresses Core Web Vitals.",
    quote:
      "Deployment impact diffing alone has paid for the platform ten times over. We catch slow bundles before they ever reach production.",
    author: "Elena Rodriguez",
    authorRole: "VP Engineering, Beacon Commerce",
    results: [
      { label: "Slow releases shipped", value: "0" },
      { label: "Bundle size regressions blocked", value: "27" },
      { label: "Revenue protected", value: "$2.4M" },
      { label: "Sprint velocity", value: "Up 22%" },
    ],
    challenges: [
      "Every 100ms of LCP regression measurably reduced conversion rate.",
      "Bundle size regressions from third-party scripts slipped through code review.",
      "No automated way to compare performance before and after every release.",
    ],
    solutions: [
      "Tagged every Vercel deployment with PagePulse's markDeployment API.",
      "Configured CI to fail any PR that regressed LCP, INP, or CLS by more than 5%.",
      "Set per-route bundle size budgets with Linear tickets auto-filed on breach.",
    ],
    outcomes: [
      "Zero slow releases shipped in 6 months.",
      "Blocked 27 bundle size regressions before they reached production.",
      "Protected an estimated $2.4M in annual revenue.",
      "Increased sprint velocity 22% by eliminating performance rework.",
    ],
  },
  {
    slug: "prism-analytics",
    company: "Prism Analytics",
    industry: "B2B SaaS",
    logo: "Prism Analytics",
    metric: "+18%",
    metricLabel: "mobile conversion",
    headline: "Prism Analytics lifted mobile conversion 18% by fixing Brazil LCP.",
    description:
      "Prism Analytics sells a usage analytics product to marketing teams. Their mobile conversion rate in Brazil was 38% below the global average. PagePulse's country-level RUM data revealed mobile LCP in Brazil was 4x slower than the United States due to a missing CDN edge.",
    quote:
      "Real user monitoring by device and country revealed our mobile LCP in Brazil was 4x slower. We fixed it and conversion jumped 18%.",
    author: "James Liu",
    authorRole: "Founder, Prism Analytics",
    results: [
      { label: "Brazil mobile LCP before", value: "6.8s" },
      { label: "Brazil mobile LCP after", value: "1.7s" },
      { label: "Mobile conversion lift", value: "+18%" },
      { label: "New CDN edges added", value: "3" },
    ],
    challenges: [
      "Mobile conversion rate in Brazil was 38% below the global average.",
      "No country-level RUM data to identify which geos were underserved.",
      "Synthetic tests from the US office showed no problem at all.",
    ],
    solutions: [
      "Used PagePulse's country segmentation to identify Brazil as the worst LCP region.",
      "Added 3 new CDN edges in South America and reconfigured image optimization.",
      "Set per-country LCP budgets to catch future regressions early.",
    ],
    outcomes: [
      "Cut Brazil mobile LCP from 6.8s to 1.7s, a 4x improvement.",
      "Lifted mobile conversion rate by 18% in the affected region.",
      "Added per-country LCP budgets to prevent future regressions.",
    ],
  },
];

export function getCustomerBySlug(slug: string): Customer | undefined {
  return customers.find((c) => c.slug === slug);
}
