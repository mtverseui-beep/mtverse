export interface ChangelogEntry {
  date: string;
  version: string;
  type: "release" | "improvement" | "fix" | "deprecation";
  title: string;
  description: string;
  tags: string[];
}

export const changelog: ChangelogEntry[] = [
  {
    date: "2025-06-24",
    version: "v2.8.1",
    type: "release",
    title: "Performance budgets v3 with SLO burn-rate tracking",
    description:
      "Promote any performance budget to a full SLO. PagePulse now tracks 30-day burn rate, error budget remaining, and projected breach date so you can share objective performance data with leadership.",
    tags: ["budgets", "slo", "alerts"],
  },
  {
    date: "2025-06-17",
    version: "v2.8.0",
    type: "release",
    title: "Real user monitoring by traffic source",
    description:
      "Join RUM data with your UTM parameters, referrer, and landing page to see which marketing campaigns and traffic sources bring the slowest experiences. Available on Growth and Scale plans.",
    tags: ["rum", "analytics"],
  },
  {
    date: "2025-06-10",
    version: "v2.7.4",
    type: "improvement",
    title: "Deployment impact diff now includes hydration time",
    description:
      "The before/after deployment diff now ships with hydration time, route load time, and time-to-interactive in addition to LCP, INP, CLS, and JS bundle size. Statistically significant changes are highlighted automatically.",
    tags: ["deployments", "rum"],
  },
  {
    date: "2025-06-03",
    version: "v2.7.3",
    type: "fix",
    title: "Resolved false-positive INP regression on Safari 17",
    description:
      "Safari 17 reports interaction timing slightly differently than Chrome and Firefox, which produced false-positive INP regressions in the deployment diff. The diff now applies a Safari-specific adjustment factor.",
    tags: ["inp", "safari", "fix"],
  },
  {
    date: "2025-05-27",
    version: "v2.7.2",
    type: "improvement",
    title: "Cookie-free mode is now the default for new projects",
    description:
      "New projects default to cookie-free RUM collection. Existing projects can opt in from Settings > Privacy. Cookie-free mode requires no consent banner in most jurisdictions.",
    tags: ["privacy", "rum"],
  },
  {
    date: "2025-05-20",
    version: "v2.7.1",
    type: "release",
    title: "Webhooks v2 with HMAC signing and retry",
    description:
      "Every outbound webhook is now HMAC-signed and timestamped. Failed deliveries retry with exponential backoff for up to 24 hours. The new /webhooks/events endpoint lets you replay any past event.",
    tags: ["webhooks", "api"],
  },
  {
    date: "2025-05-13",
    version: "v2.7.0",
    type: "release",
    title: "Linear and Jira auto-ticketing for budget breaches",
    description:
      "When a performance budget is breached, PagePulse can now auto-file a Linear issue or Jira ticket with the offending route, the delta, and a deep link into the dashboard. Available on Growth and Scale plans.",
    tags: ["integrations", "budgets", "alerts"],
  },
  {
    date: "2025-05-06",
    version: "v2.6.5",
    type: "fix",
    title: "Fixed route tracking for Next.js App Router parallel routes",
    description:
      "Parallel routes (slot files) were previously tracked as separate pageviews, inflating route counts. The Next.js adapter now correctly attributes parallel route interactions to the parent route.",
    tags: ["nextjs", "fix"],
  },
  {
    date: "2025-04-29",
    version: "v2.6.4",
    type: "improvement",
    title: "Weekly PDF report now includes prioritized recommendations",
    description:
      "The Monday morning PDF report now ships with 4 prioritized recommendations per week, ranked by estimated conversion impact. Each recommendation links to the slow route and the offending resource.",
    tags: ["reports"],
  },
  {
    date: "2025-04-22",
    version: "v2.6.3",
    type: "deprecation",
    title: "Deprecating the v1 INP field in the events API",
    description:
      "The v1 inp field in the /v1/events API is now deprecated and will be removed on October 1, 2025. Use the v2 inp_p75 field instead, which returns the 75th percentile INP per route.",
    tags: ["api", "deprecation"],
  },
];
