export interface Faq {
  question: string;
  answer: string;
}

export const faqs: Faq[] = [
  {
    question: "What are Core Web Vitals?",
    answer:
      "Core Web Vitals are Google's three primary signals for measuring real-user page experience: Largest Contentful Paint (LCP) for loading, Interaction to Next Paint (INP) for interactivity, and Cumulative Layout Shift (CLS) for visual stability. PagePulse captures all three plus First Contentful Paint (FCP) and Time to First Byte (TTFB) for every pageview.",
  },
  {
    question: "How fast can I install PagePulse?",
    answer:
      "Most teams are live in under two minutes. You can either drop a single script tag into your HTML head, or install the @pagepulse/web npm package and call PagePulse.init with your project ID. The SDK is under 4KB gzipped and has zero runtime dependencies.",
  },
  {
    question: "Does it support Next.js?",
    answer:
      "Yes. PagePulse ships first-class support for Next.js App Router, Pages Router, Server Components, and the edge runtime. There is a dedicated next-package, automatic route tracking, and built-in instrumentation for streaming and hydration timing.",
  },
  {
    question: "Can I track deployment impact?",
    answer:
      "Yes. Every release can be tagged with a version, commit, and environment using the markDeployment API. PagePulse then automatically diffs LCP, INP, CLS, JS bundle size, and error rate between releases, so you catch regressions before they reach your users.",
  },
  {
    question: "Can I monitor multiple websites?",
    answer:
      "Yes. Growth and Scale plans include unlimited projects, each with its own API key, team members, performance budgets, and dashboard. You can switch between projects in the UI or query across all of them from the API.",
  },
  {
    question: "Do you support performance budgets?",
    answer:
      "Yes. You can set thresholds for LCP, INP, CLS, TTFB, JavaScript bundle size, route load time, and hydration time. When a budget is exceeded, PagePulse can trigger a Slack alert, a webhook, an email, or fail a CI check.",
  },
  {
    question: "Can I export reports?",
    answer:
      "Yes. Every dashboard supports CSV and JSON export. Scale plans add scheduled PDF reports, custom white-label exports, and a public share link for stakeholder updates. Webhook events can also stream raw performance data into your data warehouse.",
  },
  {
    question: "Is the SDK lightweight?",
    answer:
      "Yes. The browser SDK is under 4KB gzipped with zero dependencies, uses beacon and sendBeacon for non-blocking uploads, and respects the user's Save-Data header. It will not measurably impact your own LCP, INP, or CLS scores.",
  },
];
