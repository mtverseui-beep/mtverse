export const siteConfig = {
  name: "PagePulse",
  productName: "PagePulse",
  company: "PagePulse, Inc.",
  tagline: "The platform to measure frontend performance",
  description:
    "Monitor Core Web Vitals, page speed, JavaScript performance, and deployment impact from one beautiful frontend monitoring platform.",
  url: "https://pagepulse.dev",
  supportEmail: "support@pagepulse.dev",
  salesEmail: "sales@pagepulse.dev",
  twitter: "@pagepulse",
  github: "https://github.com/pagepulse",
  copyright: "PagePulse, Inc.",
  version: "1.0.0",
  themeColor: "#0F0E0C",
};

export const primaryNav = [
  { name: "Features", href: "/features" },
  { name: "Web Vitals", href: "/web-vitals" },
  { name: "Developers", href: "/developers" },
  { name: "Pricing", href: "/pricing" },
  { name: "Docs", href: "/docs" },
];

export const footerNav = {
  Product: [
    { name: "Features", href: "/features" },
    { name: "Web Vitals", href: "/web-vitals" },
    { name: "Performance Monitoring", href: "/performance-monitoring" },
    { name: "Real User Monitoring", href: "/real-user-monitoring" },
    { name: "Deployment Impact", href: "/deployment-impact" },
    { name: "Performance Budgets", href: "/performance-budgets" },
    { name: "Pricing", href: "/pricing" },
    { name: "Integrations", href: "/integrations" },
  ],
  Developers: [
    { name: "Documentation", href: "/docs" },
    { name: "Installation", href: "/docs/installation" },
    { name: "API Reference", href: "/docs/api" },
    { name: "Webhooks", href: "/docs/webhooks" },
    { name: "Custom Metrics", href: "/docs/custom-metrics" },
    { name: "Status", href: "/status" },
    { name: "Changelog", href: "/changelog" },
  ],
  Company: [
    { name: "Customers", href: "/customers" },
    { name: "Security", href: "/security" },
    { name: "Blog", href: "/blog" },
    { name: "Contact", href: "/contact" },
    { name: "Request demo", href: "/request-demo" },
  ],
  Legal: [
    { name: "Privacy", href: "/privacy" },
    { name: "Terms", href: "/terms" },
    { name: "DPA", href: "/dpa" },
    { name: "Cookies", href: "/cookies" },
  ],
};

export const socialLinks = [
  { name: "Twitter", href: "https://twitter.com/pagepulse" },
  { name: "GitHub", href: "https://github.com/pagepulse" },
  { name: "LinkedIn", href: "https://linkedin.com/company/pagepulse" },
];

export type SiteConfig = typeof siteConfig;
