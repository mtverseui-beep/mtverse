export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  author: string;
  authorRole: string;
  date: string;
  readTime: string;
  content: BlogBlock[];
}

export type BlogBlock =
  | { type: "paragraph"; text: string }
  | { type: "heading"; text: string }
  | { type: "code"; language: string; code: string }
  | { type: "list"; items: string[] };

export const blogPosts: BlogPost[] = [
  {
    slug: "understanding-core-web-vitals-in-2025",
    title: "Understanding Core Web Vitals in 2025",
    excerpt:
      "LCP, INP, CLS, FCP, and TTFB explained. What each metric measures, what good looks like, and how to track them on real users in 2025.",
    category: "Web Vitals",
    author: "Sarah Chen",
    authorRole: "Staff Engineer, PagePulse",
    date: "2025-06-12",
    readTime: "8 min read",
    content: [
      {
        type: "paragraph",
        text: "Core Web Vitals are Google's three primary signals for measuring real-user page experience. In 2025, they remain the most reliable way to quantify how a page actually feels to a real user on a real device, on a real network. This guide walks through every metric, what good looks like, and how to track them in production.",
      },
      { type: "heading", text: "Largest Contentful Paint (LCP)" },
      {
        type: "paragraph",
        text: "LCP measures the render time of the largest text or image block visible in the viewport. The target is under 2.5 seconds at the 75th percentile of real-user page loads. The most common LCP offenders are unoptimized hero images, render-blocking CSS, slow origin server response, and client-side rendering of above-the-fold content.",
      },
      {
        type: "list",
        items: [
          "Preload your hero image with fetchpriority=high.",
          "Serve modern formats like AVIF or WebP with a JPEG fallback.",
          "Inline critical CSS and defer non-critical stylesheets.",
          "Move your largest element above the fold and avoid lazy-loading it.",
        ],
      },
      { type: "heading", text: "Interaction to Next Paint (INP)" },
      {
        type: "paragraph",
        text: "INP replaced First Input Delay as a Core Web Vital in March 2024. It measures the latency of every tap, click, and keystroke throughout the page lifecycle, then reports the 75th percentile. A good INP is under 200ms; a poor one is over 500ms. INP is the metric most likely to surprise you, because it captures interaction latency that synthetic tests cannot reproduce.",
      },
      {
        type: "paragraph",
        text: "The most common INP offenders are long tasks on the main thread, third-party scripts, and synchronous event handlers that do too much work. Use the following pattern to defer non-critical work out of the event handler:",
      },
      {
        type: "code",
        language: "typescript",
        code: `button.addEventListener('click', (event) => {
  // Critical work: respond to the user immediately
  updateUI(event.target);

  // Defer non-critical work to the next idle period
  scheduler.postTask(() => {
    analytics.track('button_click', { id: event.target.id });
  }, { priority: 'background' });
});`,
      },
      { type: "heading", text: "Cumulative Layout Shift (CLS)" },
      {
        type: "paragraph",
        text: "CLS measures unexpected layout shifts caused by images without dimensions, web fonts, dynamically injected content, and slow third-party widgets. A good CLS is under 0.1; a poor one is over 0.25. The fix is almost always the same: reserve space for content before it loads.",
      },
      {
        type: "paragraph",
        text: "Always set explicit width and height attributes on images and videos. Use CSS aspect-ratio for responsive media. Preload web fonts and use font-display: optional to prevent FOIT and FOUT. Avoid injecting banners or modals above existing content.",
      },
      { type: "heading", text: "Tracking Core Web Vitals in production" },
      {
        type: "paragraph",
        text: "Synthetic Lighthouse tests are useful for development, but they do not reflect real user experience. To understand what your users actually see, you need real-user monitoring (RUM). The PagePulse SDK captures LCP, INP, CLS, FCP, and TTFB for every pageview, then slices the data by route, device, browser, country, and traffic source.",
      },
      {
        type: "code",
        language: "typescript",
        code: `import { PagePulse } from '@pagepulse/web';

PagePulse.init({
  projectId: 'site_123',
  trackWebVitals: true,
  trackRoutes: true,
  trackErrors: true,
});`,
      },
      {
        type: "paragraph",
        text: "Once you have real-user data, set per-route budgets for each Core Web Vital. PagePulse will alert you in Slack the moment a regression ships to production, so you can roll back before it hurts your users.",
      },
    ],
  },
  {
    slug: "how-to-set-performance-budgets-that-actually-work",
    title: "How to set performance budgets that actually work",
    excerpt:
      "Performance budgets only work when they are enforced. Here is a proven framework for setting, enforcing, and iterating on budgets for LCP, INP, CLS, and JavaScript bundle size.",
    category: "Performance Budgets",
    author: "Marcus Webb",
    authorRole: "Engineering Lead, PagePulse",
    date: "2025-05-28",
    readTime: "6 min read",
    content: [
      {
        type: "paragraph",
        text: "Most teams set performance budgets at some point. Most teams also abandon them within a quarter. The reason is almost always the same: the budgets were aspirational rather than measurable, and they were never enforced in CI. This guide walks through a framework that has worked across dozens of teams.",
      },
      { type: "heading", text: "Start from real-user data" },
      {
        type: "paragraph",
        text: "Never set a budget by guessing. Pull the 75th percentile of LCP, INP, CLS, FCP, and TTFB for each route from your RUM tool. If your dashboard LCP is currently 3.2s, do not set a 2.5s budget tomorrow. Set a 3.0s budget, hit it for a sprint, then tighten to 2.7s, then 2.5s. Budgets that feel achievable get enforced; budgets that feel impossible get ignored.",
      },
      { type: "heading", text: "Categorize by route, not by site" },
      {
        type: "paragraph",
        text: "Your marketing homepage and your authenticated dashboard have very different performance characteristics. Setting a single 2.5s LCP budget across the entire site is a recipe for frustration. Set per-route budgets that reflect the actual work each page does. PagePulse makes this trivial:",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.setBudget({
  routes: {
    '/':            { lcp: 2500, inp: 200, cls: 0.1 },
    '/dashboard':   { lcp: 3500, inp: 300, cls: 0.1 },
    '/blog/[slug]': { lcp: 2000, inp: 200, cls: 0.05 },
  },
  jsSizeKB: 175,
});`,
      },
      { type: "heading", text: "Enforce in CI" },
      {
        type: "paragraph",
        text: "A budget that is not enforced is a wish. Use the @pagepulse/ci package to fail any pull request that breaches a budget. PagePulse posts a comment to the PR showing exactly which budget was exceeded, by how much, and which module caused the regression. Engineers learn very quickly to keep their changes within budget.",
      },
      {
        type: "code",
        language: "bash",
        code: `# In your CI pipeline
npx @pagepulse/ci check \\
  --project site_123 \\
  --base origin/main \\
  --head HEAD`,
      },
      { type: "heading", text: "Iterate monthly" },
      {
        type: "paragraph",
        text: "Budgets should get tighter over time. Review your budgets once a month. If you are comfortably under budget on a route, tighten the budget by 5-10%. If you are consistently over budget, investigate the root cause and either fix it or relax the budget. The goal is continuous improvement, not perfection.",
      },
    ],
  },
  {
    slug: "deployment-impact-the-missing-link-in-frontend-performance",
    title: "Deployment impact: the missing link in frontend performance",
    excerpt:
      "Most teams measure performance before and after a release manually, if at all. Here is how automatic deployment impact diffing catches regressions before users notice.",
    category: "Deployment Impact",
    author: "Elena Rodriguez",
    authorRole: "VP Engineering, PagePulse",
    date: "2025-05-14",
    readTime: "7 min read",
    content: [
      {
        type: "paragraph",
        text: "Frontend performance is not a snapshot, it is a trajectory. A page that loads in 1.8s today can easily drift to 2.4s over six months of releases, each of which individually added only 50ms of LCP. Without automatic deployment tracking, the drift is invisible until a customer complains. Deployment impact diffing closes that gap.",
      },
      { type: "heading", text: "Tag every release" },
      {
        type: "paragraph",
        text: "The first step is to tag every deployment with a version, commit, and environment. PagePulse then automatically correlates every RUM sample, every error, and every bundle-size measurement with the release that produced it. No manual tagging, no spreadsheets.",
      },
      {
        type: "code",
        language: "typescript",
        code: `// In your CI/CD pipeline, after the deploy succeeds
PagePulse.markDeployment({
  version: process.env.RELEASE_VERSION,
  commit: process.env.GIT_SHA,
  environment: process.env.NODE_ENV,
});`,
      },
      { type: "heading", text: "Read the diff" },
      {
        type: "paragraph",
        text: "For every release, PagePulse generates a side-by-side diff of LCP, INP, CLS, FCP, TTFB, JavaScript bundle size, route load time, and error rate. Statistically significant regressions are highlighted in red, improvements in green, and noise is filtered out automatically. You see the diff within minutes of going live.",
      },
      {
        type: "paragraph",
        text: "The diff is not just a number. PagePulse shows you exactly which route regressed, which device class was most affected, and which JavaScript module grew the most. You can go from alert to root cause in a single click.",
      },
      { type: "heading", text: "Automate the rollback decision" },
      {
        type: "paragraph",
        text: "Once you have automatic deployment impact diffing, the rollback decision becomes objective. If LCP regressed by more than 10% and INP by more than 20%, roll back. If CLS regressed by more than 0.05, roll back. PagePulse can trigger the rollback webhook automatically, or surface the regression in Slack and let a human decide.",
      },
      {
        type: "paragraph",
        text: "The teams that get the most value from deployment impact diffing are not the ones with the most alerts. They are the ones who treat every regression as a learning opportunity. Each rollback reveals a weakness in your test suite, your code review process, or your dependency policy. Fix the weakness, not just the regression.",
      },
    ],
  },
  {
    slug: "real-user-monitoring-vs-synthetic-testing",
    title: "Real user monitoring vs synthetic testing",
    excerpt:
      "Synthetic tests are useful for development, but they do not reflect real user experience. Here is how to combine both for a complete performance picture.",
    category: "Real User Monitoring",
    author: "James Liu",
    authorRole: "Founder, PagePulse",
    date: "2025-04-30",
    readTime: "5 min read",
    content: [
      {
        type: "paragraph",
        text: "Synthetic testing and real user monitoring are often presented as competitors. They are not. They are complementary tools that answer different questions. Synthetic testing tells you whether a page can be fast. Real user monitoring tells you whether a page is fast for your actual users. You need both.",
      },
      { type: "heading", text: "What synthetic testing is good for" },
      {
        type: "paragraph",
        text: "Synthetic tests run a consistent, repeatable script against your page from a known location, on a known device, on a known network. They are perfect for catching regressions during development, before they reach production. They are also useful for testing specific user flows, like checkout, that may not generate enough RUM traffic to be statistically meaningful.",
      },
      {
        type: "paragraph",
        text: "The weakness of synthetic tests is that they do not reflect real user experience. A synthetic test from a data center in Virginia on a cable connection does not represent a user on a mid-range Android phone in Brazil on 3G. If you only look at synthetic data, you will optimize for the wrong users.",
      },
      { type: "heading", text: "What real user monitoring is good for" },
      {
        type: "paragraph",
        text: "RUM captures actual user experience, on actual devices, on actual networks, in actual locations. It tells you the truth about how your page performs for the people who matter. RUM is the only way to see that mobile LCP in Brazil is 4x slower than in the United States, or that Safari users see a 200ms slower INP than Chrome users.",
      },
      {
        type: "paragraph",
        text: "The weakness of RUM is that it only tells you about production. It cannot catch a regression before it ships. It also cannot tell you why a regression happened, only that it did. To debug a RUM regression, you usually need to reproduce it synthetically.",
      },
      { type: "heading", text: "The combined workflow" },
      {
        type: "paragraph",
        text: "Use synthetic tests in CI to catch regressions before they ship. Use RUM in production to catch the regressions that synthetic tests missed. When a RUM regression appears, use synthetic tests to reproduce and debug it. When a synthetic test reveals a regression, use RUM to confirm the fix in production.",
      },
      {
        type: "code",
        language: "typescript",
        code: `// Synthetic test in CI
import { test } from '@playwright/test';
import { expect } from '@pagepulse/synthetic';

test('homepage LCP under 2.5s', async ({ page }) => {
  await page.goto('/');
  const { lcp } = await expect(page).webVitals();
  expect(lcp).toBeLessThan(2500);
});`,
      },
      {
        type: "paragraph",
        text: "PagePulse supports both modes. The same SDK captures RUM data in production and synthetic data in CI. Both feed into the same dashboards, the same budgets, and the same alerts, so you always have a complete picture of your performance.",
      },
    ],
  },
  {
    slug: "inp-replacing-fid-what-frontend-teams-need-to-know",
    title: "INP replacing FID: what frontend teams need to know",
    excerpt:
      "Interaction to Next Paint replaced First Input Delay in March 2024. Here is what changed, why it matters, and how to optimize for it.",
    category: "Web Vitals",
    author: "Sarah Chen",
    authorRole: "Staff Engineer, PagePulse",
    date: "2025-04-15",
    readTime: "6 min read",
    content: [
      {
        type: "paragraph",
        text: "In March 2024, Google replaced First Input Delay (FID) with Interaction to Next Paint (INP) as a Core Web Vital. The change was significant. FID measured only the first interaction on a page and only the input delay portion of it. INP measures every interaction throughout the page lifecycle and the full processing time, including event handlers and rendering.",
      },
      { type: "heading", text: "Why the change matters" },
      {
        type: "paragraph",
        text: "FID was a forgiving metric. Most pages passed FID because the first interaction usually happened after the page had finished loading, when the main thread was idle. INP is much stricter. It captures the slowest interactions on the page, which often happen later, when the user is actively interacting with the app and the main thread is busy.",
      },
      {
        type: "paragraph",
        text: "If your FID was good but your INP is poor, you are not alone. Most teams saw their Core Web Vitals score drop when INP replaced FID. The good news is that the fixes for INP are well understood.",
      },
      { type: "heading", text: "Common INP offenders" },
      {
        type: "list",
        items: [
          "Long tasks on the main thread, usually from third-party scripts.",
          "Synchronous event handlers that do too much work.",
          "Heavy client-side rendering, especially in React and Next.js apps.",
          "Large JavaScript bundles that take a long time to parse and compile.",
          "Heavy use of requestAnimationFrame for non-visual work.",
        ],
      },
      { type: "heading", text: "How to optimize INP" },
      {
        type: "paragraph",
        text: "The general principle is to keep the main thread idle. Break long tasks into smaller chunks using scheduler.yield or setTimeout. Defer non-critical work out of event handlers using scheduler.postTask. Move heavy computation to a Web Worker. Lazy-load third-party scripts, especially analytics and tag managers.",
      },
      {
        type: "code",
        language: "typescript",
        code: `// Before: long task blocks the main thread
button.addEventListener('click', () => {
  updateUI();
  trackAnalytics();
  saveToLocalStorage();
  sendBeacon();
});

// After: critical work runs immediately, rest is deferred
button.addEventListener('click', async () => {
  updateUI();
  await scheduler.yield();
  trackAnalytics();
  saveToLocalStorage();
  sendBeacon();
});`,
      },
      { type: "heading", text: "Measure INP on real users" },
      {
        type: "paragraph",
        text: "INP is highly sensitive to device class, browser, and network. A synthetic test from a fast laptop on cable will not reveal the INP problems that real users on mid-range Android phones are experiencing. Use real user monitoring to capture INP for every pageview, then slice the data by device, browser, and country to find the worst offenders.",
      },
    ],
  },
  {
    slug: "javascript-bundle-size-the-hidden-performance-tax",
    title: "JavaScript bundle size: the hidden performance tax",
    excerpt:
      "Every kilobyte of JavaScript you ship has a cost. Here is how to measure, budget, and reduce your JavaScript bundle size without sacrificing functionality.",
    category: "Performance Budgets",
    author: "Marcus Webb",
    authorRole: "Engineering Lead, PagePulse",
    date: "2025-03-28",
    readTime: "8 min read",
    content: [
      {
        type: "paragraph",
        text: "JavaScript is the most expensive byte you can ship to a browser. HTML and CSS are parsed and rendered incrementally. Images are decoded off the main thread. JavaScript, by contrast, must be downloaded, parsed, compiled, and executed on the main thread, blocking everything else. Every kilobyte of JavaScript has a cost that is multiple times higher than the same kilobyte of HTML or CSS.",
      },
      { type: "heading", text: "Measure first" },
      {
        type: "paragraph",
        text: "Before you can reduce your bundle size, you need to know what is in it. PagePulse parses every production build, attributes each byte to its source module, and tracks first-party and third-party JavaScript weight on every route. The breakdown is usually eye-opening.",
      },
      {
        type: "paragraph",
        text: "The most common culprits are large utility libraries (moment.js, lodash), date libraries, polyfills for browsers you do not support, and third-party scripts (analytics, tag managers, chat widgets). In most apps, 80% of the bundle size comes from 20% of the dependencies.",
      },
      { type: "heading", text: "Set a budget" },
      {
        type: "paragraph",
        text: "A good rule of thumb is 175KB of gzipped JavaScript per route. That is enough for a modern framework, a router, and your application code, but not enough for bloat. Set the budget per route, not per site, because different routes have different needs.",
      },
      {
        type: "code",
        language: "typescript",
        code: `PagePulse.setBudget({
  routes: {
    '/': { jsSizeKB: 150 },
    '/dashboard': { jsSizeKB: 250 },
    '/blog/[slug]': { jsSizeKB: 175 },
  },
});`,
      },
      { type: "heading", text: "Reduce" },
      {
        type: "list",
        items: [
          "Replace moment.js with date-fns or Temporal. Save 60KB+.",
          "Replace lodash with native ES modules. Save 25KB+.",
          "Use dynamic imports for routes and large components.",
          "Tree-shake aggressively. Audit your bundler output.",
          "Lazy-load third-party scripts. Defer analytics and tag managers.",
          "Drop polyfills for browsers you no longer support.",
        ],
      },
      { type: "heading", text: "Enforce in CI" },
      {
        type: "paragraph",
        text: "Once you have a budget, enforce it. The @pagepulse/ci package fails any pull request that breaches the budget. PagePulse posts a comment to the PR showing exactly which module added the weight, so the author can fix it before merge.",
      },
      {
        type: "paragraph",
        text: "Bundle size discipline is one of the highest-ROI investments a frontend team can make. Every kilobyte you cut improves LCP, INP, and TTFB on every device, on every network, in every country. The compound effect over months is enormous.",
      },
    ],
  },
];

export function getBlogPostBySlug(slug: string): BlogPost | undefined {
  return blogPosts.find((p) => p.slug === slug);
}

export const blogCategories = Array.from(
  new Set(blogPosts.map((p) => p.category))
).sort();
