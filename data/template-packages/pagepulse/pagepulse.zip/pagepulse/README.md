# PagePulse — Frontend Performance & Core Web Vitals Monitoring

A premium, production-ready Next.js 16 + TypeScript + Tailwind CSS 4 commercial
template for a frontend performance monitoring SaaS. PagePulse ships with a
full marketing site, documentation system, blog, customer case studies, legal
pages, auth flows, and a dual-theme (light/dark) design system with zero
gradients.

This project is sold as a standalone commercial frontend template. Every line
of copy, every brand asset, and every section structure is original.

---

## Highlights

- **Next.js 16** App Router with React 19 and TypeScript 5 (strict mode)
- **Tailwind CSS 4** design system with `@theme inline` tokens
- **Dual color combo**: warm paper light / soft black dark, with no gradients
- **Dark/light theme toggle** with no flash of wrong theme (inline script)
- **Original PagePulse brand**: logo, favicon, OG metadata, theme color
- **19-section homepage** built specifically for a frontend performance product
- **35+ routes**: marketing pages, docs, blog, customers, auth, legal, errors
- **Interactive product previews**: RUM dashboard, deployment diff, budget
  builder, weekly report, Core Web Vitals dashboard
- **Working frontend interactions**: search, filters, accordions, tabs, copy
  buttons, validated forms, mock toasts
- **Production SEO**: per-route metadata, Open Graph, Twitter cards, FAQ
  schema, SoftwareApplication schema, Organization schema, sitemap, robots
- **Zero TypeScript errors, zero ESLint errors, zero AI references, zero
  v0 metadata**

---

## Quick start

```bash
# install dependencies
bun install

# start the dev server on http://localhost:3000
bun run dev

# typecheck, lint, and build
bun run typecheck
bun run lint
bun run build
```

The dev server writes its log to `dev.log` at the project root.

---

## Project structure

```
src/
├── app/                       # Next.js App Router routes
│   ├── layout.tsx             # Root layout, fonts, theme init script
│   ├── page.tsx               # Homepage (19 sections)
│   ├── globals.css            # Tailwind + dual color theme tokens
│   ├── sitemap.ts             # Auto-generated sitemap
│   ├── robots.ts              # Auto-generated robots.txt
│   ├── not-found.tsx          # 404 fallback
│   ├── error.tsx              # 500 fallback (runtime errors)
│   ├── pricing/               # Pricing page with comparison table
│   ├── features/              # Features overview
│   ├── web-vitals/            # Core Web Vitals product page
│   ├── performance-monitoring/# Performance monitoring product page
│   ├── deployment-impact/     # Deployment impact product page
│   ├── performance-budgets/   # Performance budgets product page
│   ├── real-user-monitoring/  # RUM product page
│   ├── developers/            # Developer SDK page
│   ├── integrations/          # Integrations gallery
│   ├── security/              # Security & privacy page
│   ├── customers/             # Customer index
│   │   └── [slug]/            # Customer case study dynamic route
│   ├── blog/                  # Blog index
│   │   └── [slug]/            # Blog post dynamic route
│   ├── docs/                  # Docs index
│   │   ├── installation/      # Installation guide
│   │   └── [slug]/            # All other docs
│   ├── changelog/             # Changelog with filter
│   ├── status/                # Public status page
│   ├── contact/               # Contact form (validated)
│   ├── request-demo/          # Demo request form (validated)
│   ├── sign-in/               # Sign in
│   ├── sign-up/               # Sign up with password strength
│   ├── forgot-password/       # Password reset request
│   ├── reset-password/        # New password
│   ├── privacy/               # Privacy Policy
│   ├── terms/                 # Terms of Service
│   ├── dpa/                   # Data Processing Addendum
│   ├── cookies/               # Cookie Policy
│   ├── 404/                   # 404 page
│   ├── 500/                   # 500 page
│   └── offline/               # Offline page
├── components/
│   ├── landing/               # Homepage sections (hero, features, etc.)
│   ├── site/                  # Shared site components (nav, footer, etc.)
│   └── ui/                    # shadcn/ui components
└── lib/
    ├── site-config.ts         # Brand, nav, footer config
    ├── customers.ts           # Customer case study data
    ├── blog-posts.ts          # Blog post content
    ├── changelog.ts           # Changelog entries
    ├── docs.ts                # Documentation content
    └── faqs.ts                # FAQ entries
```

---

## Customization guide

### 1. Branding

All brand identity lives in `src/lib/site-config.ts`. Edit the `siteConfig`
object to change:

- `name` — product name
- `company` — legal company name
- `tagline`, `description` — SEO and OG copy
- `url` — canonical site URL
- `supportEmail`, `salesEmail` — contact emails
- `twitter`, `github` — social links
- `copyright` — footer copyright holder

The favicon lives at `public/icon.svg` and the manifest at
`public/site.webmanifest`. The logo SVG is inline in
`src/components/site/logo.tsx` and the footer (`footer-section.tsx`).

### 2. Theme colors

The dual color system is defined with CSS custom properties in
`src/app/globals.css`:

- `:root` — light theme (warm paper / ink black)
- `.dark` — dark theme (soft black / warm paper)

Both themes use OKLCH colors for perceptual consistency. There are **no
gradients** anywhere in the design system — only solid color tokens. To change
the palette, edit the OKLCH values in `globals.css` and the theme will update
everywhere automatically.

The theme toggle is in `src/components/site/theme-toggle.tsx`. It is included
in the navigation (desktop and mobile) and in all auth pages. The theme is
persisted to `localStorage` under the `pagepulse-theme` key, with a system
preference fallback. The init script in `src/app/layout.tsx` runs before first
paint to prevent any flash of the wrong theme.

### 3. Pricing

Pricing plans are defined in `src/components/landing/pricing-section.tsx` (the
`plans` array). Each plan has a `name`, `description`, `monthly` price,
`annual` price, `features` list, `cta` label, `href` for the CTA, and a
`popular` flag. The comparison table on `/pricing` is defined in
`src/app/pricing/page.tsx` (the `comparisonRows` array).

### 4. Integrations

The integrations list and categories live in
`src/components/landing/integrations-section.tsx` (the `integrations` and
`categories` arrays). Each integration has a `name` and `category`. The
filter tabs are derived from the `categories` array automatically.

### 5. Documentation

All documentation content lives in `src/lib/docs.ts`. Each `DocPage` has a
`slug`, `title`, `description`, `category`, and a `blocks` array. Blocks can
be `paragraph`, `heading`, `code`, `list`, or `callout`. The docs sidebar is
generated from `docCategories` and the search filters by title and slug.

To add a new doc:

1. Add an entry to `docPages` in `src/lib/docs.ts`
2. Add the slug to the appropriate category in `docCategories`
3. The route `/docs/<slug>` is generated automatically by
   `src/app/docs/[slug]/page.tsx`

### 6. Blog posts

Blog posts live in `src/lib/blog-posts.ts`. Each post has a `slug`, `title`,
`excerpt`, `category`, `author`, `authorRole`, `date`, `readTime`, and a
`content` array of blocks (paragraph, heading, code, list). The blog index at
`/blog` supports search and category filtering.

### 7. Customer case studies

Customer case studies live in `src/lib/customers.ts`. Each customer has a
`slug`, `company`, `industry`, `metric`, `metricLabel`, `headline`,
`description`, `quote`, `author`, `authorRole`, `results`, `challenges`,
`solutions`, and `outcomes`. The route `/customers/[slug]` is generated
automatically.

### 8. Changelog

Changelog entries live in `src/lib/changelog.ts`. Each entry has a `date`,
`version`, `type` (release / improvement / fix / deprecation), `title`,
`description`, and `tags`. The changelog page at `/changelog` supports
filtering by type.

### 9. FAQs

FAQs live in `src/lib/faqs.ts`. They are rendered on the homepage, the
pricing page, and the FAQ schema (JSON-LD) on the homepage.

---

## Routes

The project ships with the following routes. Every route exists, has original
content, has metadata, and has no dead links.

### Marketing

- `/` — Homepage
- `/pricing` — Pricing with comparison table
- `/features` — Features overview
- `/web-vitals` — Core Web Vitals product page
- `/performance-monitoring` — Performance monitoring product page
- `/deployment-impact` — Deployment impact product page
- `/performance-budgets` — Performance budgets product page
- `/real-user-monitoring` — Real user monitoring product page
- `/developers` — Developer SDK page
- `/integrations` — Integrations gallery with filter tabs
- `/security` — Security and privacy page
- `/customers` — Customer case study index
- `/customers/[slug]` — Individual customer case study
- `/blog` — Blog index with search and category filter
- `/blog/[slug]` — Individual blog post
- `/changelog` — Changelog with type filter
- `/status` — Public status page with component list and incident history
- `/contact` — Contact form (validated)
- `/request-demo` — Demo request form (validated)

### Authentication

- `/sign-in` — Sign in with email/password and social login UI
- `/sign-up` — Sign up with password strength meter
- `/forgot-password` — Password reset request
- `/reset-password` — New password with confirmation

### Documentation

- `/docs` — Docs index
- `/docs/installation` — Installation guide
- `/docs/web-vitals` — Web Vitals reference
- `/docs/performance-budgets` — Performance budgets
- `/docs/deployments` — Deployment tracking
- `/docs/custom-metrics` — Custom metrics
- `/docs/api` — API reference
- `/docs/webhooks` — Webhooks

### Legal

- `/privacy` — Privacy Policy
- `/terms` — Terms of Service
- `/dpa` — Data Processing Addendum
- `/cookies` — Cookie Policy

### Errors

- `/404` — Not found
- `/500` — Server error
- `/offline` — Offline page
- `not-found.tsx` — Next.js 404 fallback
- `error.tsx` — Next.js runtime error boundary

---

## Component architecture

The project uses three layers of components:

1. **`components/landing/*`** — Homepage sections. Each section is a
   self-contained client component with its own scroll-reveal animation,
   IntersectionObserver-driven visibility state, and product-specific UI.

2. **`components/site/*`** — Shared site components used across multiple
   routes: `Navigation`, `FooterSection`, `Logo`, `ThemeToggle`,
   `ThemeProvider`, `PageShell`, `PageHeader`, `DocsShell`, `AuthShell`,
   `LegalPage`, `BlogContent`, `BlogList`, `ChangelogList`, `StatusDashboard`,
   `ContactForm`, `DemoForm`, `JsonLd`.

3. **`components/ui/*`** — shadcn/ui primitives (Button, Input, Accordion,
   etc.) configured with the PagePulse theme tokens.

---

## SEO

The project includes production-ready SEO:

- Per-route `metadata` exports with title, description, canonical
- Open Graph and Twitter card metadata in the root layout
- FAQ JSON-LD schema on the homepage (renders the `faqs` array)
- SoftwareApplication JSON-LD schema on the homepage
- Organization JSON-LD schema on the homepage
- Article JSON-LD on blog posts (via `openGraph.type = "article"`)
- `sitemap.ts` auto-generates `/sitemap.xml` with all routes, blog posts,
  customer case studies, and docs
- `robots.ts` auto-generates `/robots.txt` with appropriate disallows
- Semantic HTML throughout (`<main>`, `<header>`, `<nav>`, `<section>`,
  `<article>`, `<aside>`, `<footer>`)
- All interactive elements have `aria-label` and `aria-invalid` attributes
- All form inputs have associated `<label>` elements

---

## Production checklist

Before deploying:

- [ ] Update `siteConfig.url` in `src/lib/site-config.ts` to your production URL
- [ ] Update the `siteUrl` constant in `src/app/layout.tsx`
- [ ] Update the `base` constant in `src/app/sitemap.ts`
- [ ] Update the sitemap URL in `src/app/robots.ts`
- [ ] Replace `support@pagepulse.dev` and `sales@pagepulse.dev` in
      `src/lib/site-config.ts` with your real emails
- [ ] Update the social links in `src/lib/site-config.ts`
- [ ] Update the legal page content in `src/app/privacy`, `/terms`, `/dpa`,
      `/cookies` to reflect your actual practices
- [ ] Update the customer case studies in `src/lib/customers.ts` to use your
      real customers (with their written permission)
- [ ] Update the blog posts in `src/lib/blog-posts.ts`
- [ ] Update the changelog in `src/lib/changelog.ts`
- [ ] Update the docs in `src/lib/docs.ts`
- [ ] Update the pricing in `src/components/landing/pricing-section.tsx` and
      `src/app/pricing/page.tsx`
- [ ] Run `bun run typecheck && bun run lint && bun run build` to verify
      everything passes

---

## License and asset safety

All content in this project is original to PagePulse. No third-party logos,
illustrations, or copyrighted material is used. The integration cards use text
labels only (no third-party logos). The abstract hero visuals are generated
with vanilla Canvas 2D and use only solid colors (no gradients).

The PagePulse name, logo, and all copy are original. There are no references
to v0, Vercel, Optimus, or any other public template or product.

All sample data (customer names, blog post authors, testimonials) is
fictional. Replace it with your own real content before going live.

---

## Tech stack

| Layer            | Technology                                   |
| ---------------- | -------------------------------------------- |
| Framework        | Next.js 16 (App Router)                      |
| Language         | TypeScript 5 (strict, noImplicitAny)         |
| UI library       | React 19                                     |
| Styling          | Tailwind CSS 4 with `@theme inline` tokens   |
| Component system | shadcn/ui (New York) with Radix primitives   |
| Icons            | lucide-react                                 |
| Fonts            | Instrument Sans, Instrument Serif, JetBrains Mono |
| Animations       | CSS keyframes + IntersectionObserver + Canvas 2D |
| Theme            | Dual color (light/dark) with `class` strategy |
| Forms            | React state + native validation              |
| Toasts           | sonner + radix toast                         |

---

## Build verification

The project is verified to pass:

```bash
bun run typecheck   # zero TypeScript errors
bun run lint        # zero ESLint errors
bun run build       # production build succeeds
```

---

© PagePulse, Inc. All rights reserved. This template is licensed for
commercial use by the purchaser. Redistribution or resale of the source code
is not permitted.
