#!/usr/bin/env python3
"""Replace hardcoded dark-only colors with theme-aware CSS variables
across all trading components, so the same markup works in light + dark."""
import re
from pathlib import Path

BASE = Path("/home/z/my-project/src/components/trading")

# Order matters — do more-specific replacements first.
REPLACEMENTS = [
    # Tailwind text-/bg- color utilities referencing hex
    (r"text-\[#8B93A7\]", "text-[var(--muted-foreground)]"),
    (r"text-\[#5C6577\]", "text-[var(--muted-foreground)]"),
    (r"text-\[#E8EAED\]", "text-[var(--foreground)]"),
    (r"text-\[#A99BFF\]", "text-[var(--accent)]"),
    (r"text-\[#00D992\]", "text-[var(--gain)]"),
    (r"text-\[#FF3B5C\]", "text-[var(--loss)]"),
    (r"bg-\[#171B26\]", "bg-[var(--surface-elevated)]"),
    (r"bg-\[#161A24\]", "bg-[var(--surface-hover)]"),
    (r"bg-\[#12161F\]", "bg-[var(--surface)]"),
    (r"bg-\[#0B0E14\]", "bg-[var(--background)]"),
    (r"bg-\[#1D2230\]", "bg-[var(--surface-hover)]"),
    (r"bg-\[#1A1F2B\]", "bg-[var(--surface-hover)]"),
    (r"hover:bg-\[#171B26\]", "hover:bg-[var(--surface-hover)]"),
    (r"hover:bg-\[#161A24\]", "hover:bg-[var(--surface-hover)]"),
    (r"hover:bg-\[#12161F\]", "hover:bg-[var(--surface)]"),
    (r"hover:text-\[#E8EAED\]", "hover:text-[var(--foreground)]"),
    (r"placeholder:text-\[#5C6577\]", "placeholder:text-[var(--muted-foreground)]"),
    (r"border-\[#2E3447\]", "border-[var(--border-strong)]"),

    # Inline style hex colors
    (r'"#8B93A7"', '"var(--muted-foreground)"'),
    (r'"#5C6577"', '"var(--muted-foreground)"'),
    (r'"#E8EAED"', '"var(--foreground)"'),
    (r'"#A99BFF"', '"var(--accent)"'),
    (r'"#00D992"', '"var(--gain)"'),
    (r'"#FF3B5C"', '"var(--loss)"'),
    (r'"#0B0E14"', '"var(--background)"'),
    (r'"#12161F"', '"var(--surface)"'),
    (r'"#171B26"', '"var(--surface-elevated)"'),
    (r'"#1D2230"', '"var(--surface-hover)"'),
    (r'"#232838"', '"var(--border)"'),
    (r'"#2E3447"', '"var(--border-strong)"'),
    (r'"#3A4258"', '"var(--border-strong)"'),

    # rgba financial colors → theme-aware vars
    (r'rgba\(0, ?217, ?146, ?0\.12\)', "var(--gain-soft)"),
    (r'rgba\(0, ?217, ?146, ?0\.15\)', "var(--gain-soft)"),
    (r'rgba\(0, ?217, ?146, ?0\.10\)', "var(--gain-soft)"),
    (r'rgba\(0, ?217, ?146, ?0\.22\)', "var(--gain-soft)"),
    (r'rgba\(0, ?217, ?146, ?0\.45\)', "var(--gain-soft)"),
    (r'rgba\(255, ?59, ?92, ?0\.12\)', "var(--loss-soft)"),
    (r'rgba\(255, ?59, ?92, ?0\.15\)', "var(--loss-soft)"),
    (r'rgba\(255, ?59, ?92, ?0\.10\)', "var(--loss-soft)"),
    (r'rgba\(255, ?59, ?92, ?0\.22\)', "var(--loss-soft)"),
    (r'rgba\(255, ?59, ?92, ?0\.45\)', "var(--loss-soft)"),
    (r'rgba\(108, ?92, ?231, ?0\.12\)', "var(--accent-soft)"),
    (r'rgba\(108, ?92, ?231, ?0\.14\)', "var(--accent-soft)"),
    (r'rgba\(108, ?92, ?231, ?0\.15\)', "var(--accent-soft)"),
    (r'rgba\(108, ?92, ?231, ?0\.35\)', "var(--accent-glow)"),
]

count = 0
for f in sorted(BASE.glob("*.tsx")):
    src = f.read_text()
    new = src
    for pat, repl in REPLACEMENTS:
        new = re.sub(pat, repl, new)
    if new != src:
        f.write_text(new)
        count += 1
        print(f"updated: {f.name}")
print(f"\n{count} files updated")
