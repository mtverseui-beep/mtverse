#!/usr/bin/env python3
"""Generate PNG and ICO favicons from the SVG logo design.
PIL can't parse SVG directly, so we redraw the logo programmatically."""
from PIL import Image, ImageDraw
import os

OUT = "/home/z/my-project/src/app"
PUBLIC = "/home/z/my-project/public"

def draw_logo(size: int) -> ImageDraw.Image:
    """Draw the Meridian logo at the given pixel size."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # Badge background — indigo gradient (approximated with vertical blend)
    # We'll draw a solid indigo since PIL doesn't do gradients natively
    badge_color = (108, 92, 231, 255)  # #6C5CE7
    # Draw rounded rect
    radius = int(size * 0.28)
    draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=badge_color)
    # Draw the "M" shape — ascending peaks
    # Coordinates scaled from the 32x32 viewBox
    s = size / 32.0
    # M stroke: (8,23) -> (8,10) -> (16,18) -> (24,10) -> (24,23)
    w = max(2, int(3.4 * s))
    white = (255, 255, 255, 255)
    points = [
        (8, 23), (8, 10),
        (16, 18),
        (24, 10), (24, 23),
    ]
    for i in range(len(points) - 1):
        x1, y1 = points[i]
        x2, y2 = points[i + 1]
        draw.line(
            [(int(x1 * s), int(y1 * s)), (int(x2 * s), int(y2 * s))],
            fill=white, width=w,
        )
    # Round the line endpoints with circles for stroke-linecap effect
    for px, py in points:
        r = w // 2
        draw.ellipse(
            [int(px * s) - r, int(py * s) - r, int(px * s) + r, int(py * s) + r],
            fill=white,
        )
    return img

# Generate PNGs at common sizes
sizes = {
    "icon.png": 32,
    "apple-icon.png": 180,
}
for name, sz in sizes.items():
    img = draw_logo(sz)
    img.save(os.path.join(OUT, name))
    print(f"Generated {name} ({sz}x{sz})")

# Also save a 192x192 for PWA manifest use
img192 = draw_logo(192)
img192.save(os.path.join(PUBLIC, "icon-192.png"))
img32 = draw_logo(32)
img16 = draw_logo(16)

# Generate ICO (multi-size)
ico_sizes = [16, 32, 48]
ico_images = [draw_logo(s) for s in ico_sizes]
ico_images[0].save(
    os.path.join(OUT, "favicon.ico"),
    format="ICO",
    sizes=[(s, s) for s in ico_sizes],
)
print(f"Generated favicon.ico (sizes: {ico_sizes})")
print("All icons generated successfully")
