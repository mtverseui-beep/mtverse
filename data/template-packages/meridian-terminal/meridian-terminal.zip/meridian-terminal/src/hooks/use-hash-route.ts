"use client";
// ============================================================
// useHashRoute — lightweight hash-based router. Keeps everything
// on the single `/` route (per sandbox constraint) while giving
// shareable URLs like /#/settings/billing.
// ============================================================
import { useEffect, useState, useCallback } from "react";

export interface Route {
  /** Full path without leading hash, e.g. "settings/billing". "" = home. */
  path: string;
  /** Segments split by "/", e.g. ["settings", "billing"]. */
  segments: string[];
}

function parse(): Route {
  if (typeof window === "undefined") return { path: "", segments: [] };
  const raw = window.location.hash.replace(/^#\/?/, "");
  return {
    path: raw,
    segments: raw ? raw.split("/").filter(Boolean) : [],
  };
}

export function useHashRoute(): [Route, (path: string) => void] {
  const [route, setRoute] = useState<Route>({ path: "", segments: [] });

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setRoute(parse());
    const onHash = () => setRoute(parse());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = useCallback((path: string) => {
    const clean = path.replace(/^\/+/, "");
    window.location.hash = `/${clean}`;
  }, []);

  return [route, navigate];
}
