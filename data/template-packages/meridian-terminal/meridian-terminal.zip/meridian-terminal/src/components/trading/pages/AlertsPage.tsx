"use client";
// ============================================================
// AlertsPage — price alert rules CRUD + triggered history.
// Create, toggle, edit, delete rules. Real, functional.
// ============================================================
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bell,
  Plus,
  Trash2,
  Pencil,
  BellRing,
  ArrowUp,
  ArrowDown,
  Clock,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useTradingStore } from "@/store/trading-store";
import { PageHeader } from "../PageHeader";
import { StatCard } from "../StatCard";
import { EmptyState } from "../EmptyState";
import { Button } from "../Button";
import { ModernSelect } from "../ModernSelect";
import { Field, Input } from "../Field";
import { fmtPrice, fmtRelative } from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type AlertCondition = "ABOVE" | "BELOW" | "CROSS_UP" | "CROSS_DOWN";

interface AlertRule {
  id: string;
  ticker: string;
  condition: AlertCondition;
  price: number;
  enabled: boolean;
  createdAt: number;
  lastTriggered?: number;
}

interface TriggeredAlert {
  id: string;
  ticker: string;
  condition: AlertCondition;
  price: number;
  triggeredAt: number;
  message: string;
}

const INITIAL_RULES: AlertRule[] = [
  { id: "al-1", ticker: "ZNRA", condition: "ABOVE", price: 190, enabled: true, createdAt: Date.now() - 86400000, lastTriggered: Date.now() - 7200000 },
  { id: "al-2", ticker: "NVKS", condition: "CROSS_UP", price: 425, enabled: true, createdAt: Date.now() - 172800000, lastTriggered: Date.now() - 3600000 },
  { id: "al-3", ticker: "FJRD", condition: "BELOW", price: 44, enabled: true, createdAt: Date.now() - 259200000 },
  { id: "al-4", ticker: "QBIT", condition: "CROSS_DOWN", price: 245, enabled: false, createdAt: Date.now() - 432000000 },
  { id: "al-5", ticker: "AETH", condition: "ABOVE", price: 96, enabled: true, createdAt: Date.now() - 86400000 },
];

const TRIGGERED: TriggeredAlert[] = [
  { id: "t1", ticker: "NVKS", condition: "CROSS_UP", price: 425.12, triggeredAt: Date.now() - 3600000, message: "NVKS crossed above $425.00" },
  { id: "t2", ticker: "ZNRA", condition: "ABOVE", price: 184.50, triggeredAt: Date.now() - 7200000, message: "ZNRA crossed above $184.00 (alert reset)" },
  { id: "t3", ticker: "HLYO", condition: "BELOW", price: 138.20, triggeredAt: Date.now() - 86400000, message: "HLYO dropped below $138.50" },
  { id: "t4", ticker: "KORE", condition: "CROSS_DOWN", price: 75.10, triggeredAt: Date.now() - 172800000, message: "KORE crossed below $75.50" },
];

const CONDITION_LABELS: Record<AlertCondition, { label: string; icon: React.ComponentType<{ size?: number; style?: React.CSSProperties }>; color: string }> = {
  ABOVE: { label: "Above", icon: ArrowUp, color: "var(--gain)" },
  BELOW: { label: "Below", icon: ArrowDown, color: "var(--loss)" },
  CROSS_UP: { label: "Crosses up", icon: ArrowUp, color: "var(--gain)" },
  CROSS_DOWN: { label: "Crosses down", icon: ArrowDown, color: "var(--loss)" },
};

interface AlertsPageProps {
  navigate: (path: string) => void;
}

export function AlertsPage({ navigate }: AlertsPageProps) {
  const symbols = useTradingStore((s) => s.symbols);
  const [rules, setRules] = useState<AlertRule[]>(INITIAL_RULES);
  const [createOpen, setCreateOpen] = useState(false);
  const [editRule, setEditRule] = useState<AlertRule | null>(null);

  // Create form state
  const [formTicker, setFormTicker] = useState(symbols[0]?.ticker ?? "ZNRA");
  const [formCondition, setFormCondition] = useState<AlertCondition>("ABOVE");
  const [formPrice, setFormPrice] = useState<number>(symbols[0]?.price ?? 100);
  const [formError, setFormError] = useState<string>();

  const resetForm = () => {
    setFormTicker(symbols[0]?.ticker ?? "ZNRA");
    setFormCondition("ABOVE");
    setFormPrice(symbols[0]?.price ?? 100);
    setFormError(undefined);
  };

  const openCreate = () => {
    resetForm();
    setCreateOpen(true);
  };

  const openEdit = (rule: AlertRule) => {
    setFormTicker(rule.ticker);
    setFormCondition(rule.condition);
    setFormPrice(rule.price);
    setFormError(undefined);
    setEditRule(rule);
  };

  const submitForm = () => {
    if (formPrice <= 0) {
      setFormError("Price must be greater than 0");
      return;
    }
    if (editRule) {
      setRules((arr) =>
        arr.map((r) =>
          r.id === editRule.id
            ? { ...r, ticker: formTicker, condition: formCondition, price: formPrice }
            : r,
        ),
      );
      toast.success(`Alert updated for ${formTicker}`);
      setEditRule(null);
    } else {
      const newRule: AlertRule = {
        id: `al-${Date.now()}`,
        ticker: formTicker,
        condition: formCondition,
        price: formPrice,
        enabled: true,
        createdAt: Date.now(),
      };
      setRules((arr) => [newRule, ...arr]);
      toast.success(`Alert created for ${formTicker}`, {
        description: `Notify when ${formTicker} ${CONDITION_LABELS[formCondition].label.toLowerCase()} ${fmtPrice(formPrice)}`,
      });
      setCreateOpen(false);
    }
    resetForm();
  };

  const toggleRule = (id: string) =>
    setRules((arr) => arr.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)));

  const deleteRule = (id: string) => {
    setRules((arr) => arr.filter((r) => r.id !== id));
    toast.success("Alert rule deleted");
  };

  const activeCount = rules.filter((r) => r.enabled).length;

  const conditionOptions = (Object.keys(CONDITION_LABELS) as AlertCondition[]).map((c) => ({
    value: c,
    label: CONDITION_LABELS[c].label,
  }));
  const tickerOptions = symbols.map((s) => ({ value: s.ticker, label: `${s.ticker} — ${fmtPrice(s.price)}` }));

  return (
    <div>
      <PageHeader
        title="Price Alerts"
        description="Get notified when any symbol crosses your price thresholds. Create, edit, enable, or delete alert rules — and review your triggered history."
        breadcrumbs={[{ label: "Terminal", onClick: () => navigate("") }, { label: "Alerts" }]}
        actions={
          <Button variant="primary" size="md" icon={Plus} onClick={openCreate}>
            New alert
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Active rules" value={String(activeCount)} icon={BellRing} accent />
        <StatCard label="Total rules" value={String(rules.length)} icon={Bell} />
        <StatCard label="Triggered (24h)" value={String(TRIGGERED.filter((t) => t.triggeredAt > Date.now() - 86400000).length)} icon={BellRing} />
        <StatCard label="Triggered (7d)" value={String(TRIGGERED.length)} icon={Clock} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Active rules */}
        <section className="lg:col-span-2">
          <div
            className="rounded-[14px] border overflow-hidden glass-card shadow-premium"
            style={{ borderColor: "var(--border)" }}
          >
            <header
              className="px-5 py-3.5 border-b flex items-center justify-between"
              style={{ borderColor: "var(--border)" }}
            >
              <h2 className="text-sm font-semibold">Alert Rules</h2>
              <span className="text-[11px] text-[var(--muted-foreground)]">{rules.length} rules</span>
            </header>
            {rules.length === 0 ? (
              <EmptyState
                icon={Bell}
                title="No alert rules yet"
                description="Create your first price alert to get notified when a symbol crosses your threshold."
                primaryAction={{ label: "Create alert", onClick: openCreate }}
              />
            ) : (
              <div className="divide-y" style={{ borderColor: "var(--border)" }}>
                <AnimatePresence initial={false}>
                  {rules.map((rule) => {
                    const meta = CONDITION_LABELS[rule.condition];
                    const Icon = meta.icon;
                    return (
                      <motion.div
                        key={rule.id}
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0, height: 0 }}
                        className="flex items-center gap-3 px-5 py-3.5"
                        style={{ borderColor: "var(--border)" }}
                      >
                        {/* Toggle */}
                        <button
                          type="button"
                          role="switch"
                          aria-checked={rule.enabled}
                          aria-label={`Toggle alert for ${rule.ticker}`}
                          onClick={() => toggleRule(rule.id)}
                          className={cn(
                            "relative w-9 h-5 rounded-full transition-colors shrink-0 cursor-pointer",
                            rule.enabled ? "" : "opacity-50",
                          )}
                          style={{ background: rule.enabled ? "var(--accent)" : "var(--border-strong)" }}
                        >
                          <motion.span
                            layout
                            transition={{ type: "spring", stiffness: 500, damping: 30 }}
                            className="absolute top-0.5 w-4 h-4 rounded-full bg-white shadow-sm"
                            style={{ left: rule.enabled ? "18px" : "2px" }}
                          />
                        </button>

                        <div
                          className="w-8 h-8 rounded-[8px] flex items-center justify-center shrink-0"
                          style={{ background: "var(--surface-hover)", color: meta.color }}
                        >
                          <Icon size={15} />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-sm text-[var(--foreground)]">{rule.ticker}</span>
                            <span className="text-[11px] text-[var(--muted-foreground)]">
                              {meta.label} <span className="font-mono text-[var(--foreground)]">{fmtPrice(rule.price)}</span>
                            </span>
                          </div>
                          <div className="text-[10px] text-[var(--muted-foreground)] font-mono mt-0.5">
                            Created {fmtRelative(rule.createdAt)}
                            {rule.lastTriggered && ` · Last triggered ${fmtRelative(rule.lastTriggered)}`}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => openEdit(rule)}
                          className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring"
                          aria-label="Edit alert"
                        >
                          <Pencil size={13} />
                        </button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <button
                              type="button"
                              className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--loss)] hover:bg-[var(--loss-soft)] transition-colors cursor-pointer focus-ring"
                              aria-label="Delete alert"
                            >
                              <Trash2 size={13} />
                            </button>
                          </AlertDialogTrigger>
                          <AlertDialogContent style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete alert rule?</AlertDialogTitle>
                              <AlertDialogDescription className="text-[var(--muted-foreground)]">
                                This will remove the alert for {rule.ticker} {meta.label.toLowerCase()} {fmtPrice(rule.price)}. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel style={{ background: "var(--surface)", border: "1px solid var(--border)", color: "var(--foreground)" }}>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteRule(rule.id)}
                                style={{ background: "var(--loss)", color: "#fff" }}
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>
        </section>

        {/* Triggered history */}
        <section>
          <div
            className="rounded-[14px] border overflow-hidden glass-card shadow-premium"
            style={{ borderColor: "var(--border)" }}
          >
            <header
              className="px-5 py-3.5 border-b flex items-center justify-between"
              style={{ borderColor: "var(--border)" }}
            >
              <h2 className="text-sm font-semibold">Triggered</h2>
              <span className="text-[11px] text-[var(--muted-foreground)]">{TRIGGERED.length} events</span>
            </header>
            <div className="divide-y max-h-[480px] overflow-y-auto" style={{ borderColor: "var(--border)" }}>
              {TRIGGERED.map((t) => {
                const meta = CONDITION_LABELS[t.condition];
                const Icon = meta.icon;
                return (
                  <div key={t.id} className="px-5 py-3 flex items-start gap-3">
                    <div
                      className="w-7 h-7 rounded-[7px] flex items-center justify-center shrink-0 mt-0.5"
                      style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                    >
                      <BellRing size={13} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-[var(--foreground)]">{t.message}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Icon size={11} style={{ color: meta.color }} />
                        <span className="text-[10px] font-mono text-[var(--muted-foreground)]">{fmtRelative(t.triggeredAt)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </div>

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent
          className="font-sans max-w-md p-0 gap-0"
          style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "16px", boxShadow: "var(--shadow-xl)" }}
        >
          <DialogHeader className="px-5 pt-5 pb-3">
            <DialogTitle className="text-base font-semibold">Create price alert</DialogTitle>
          </DialogHeader>
          <div className="px-5 pb-5 space-y-4">
            <Field label="Symbol">
              <ModernSelect value={formTicker} onValueChange={(v) => { setFormTicker(v); const s = symbols.find((x) => x.ticker === v); if (s) setFormPrice(s.price); }} options={tickerOptions} ariaLabel="Symbol" />
            </Field>
            <Field label="Condition">
              <ModernSelect value={formCondition} onValueChange={(v) => setFormCondition(v as AlertCondition)} options={conditionOptions} ariaLabel="Condition" />
            </Field>
            <Field label="Target price" error={formError} required>
              <Input type="number" step={0.01} min={0} value={formPrice} onChange={(e) => setFormPrice(Math.max(0, Number(e.target.value)))} invalid={!!formError} aria-label="Target price" />
            </Field>
            <div className="flex items-center justify-end gap-2 pt-2">
              <Button variant="outline" size="md" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button variant="primary" size="md" onClick={submitForm}>Create alert</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit dialog */}
      <Dialog open={!!editRule} onOpenChange={(o) => !o && setEditRule(null)}>
        <DialogContent
          className="font-sans max-w-md p-0 gap-0"
          style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "16px", boxShadow: "var(--shadow-xl)" }}
        >
          <DialogHeader className="px-5 pt-5 pb-3">
            <DialogTitle className="text-base font-semibold">Edit alert rule</DialogTitle>
          </DialogHeader>
          <div className="px-5 pb-5 space-y-4">
            <Field label="Symbol">
              <ModernSelect value={formTicker} onValueChange={setFormTicker} options={tickerOptions} ariaLabel="Symbol" />
            </Field>
            <Field label="Condition">
              <ModernSelect value={formCondition} onValueChange={(v) => setFormCondition(v as AlertCondition)} options={conditionOptions} ariaLabel="Condition" />
            </Field>
            <Field label="Target price" error={formError} required>
              <Input type="number" step={0.01} min={0} value={formPrice} onChange={(e) => setFormPrice(Math.max(0, Number(e.target.value)))} invalid={!!formError} aria-label="Target price" />
            </Field>
            <div className="flex items-center justify-end gap-2 pt-2">
              <Button variant="outline" size="md" onClick={() => setEditRule(null)}>Cancel</Button>
              <Button variant="primary" size="md" onClick={submitForm}>Save changes</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
