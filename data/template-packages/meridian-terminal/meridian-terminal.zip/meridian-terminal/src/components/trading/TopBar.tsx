"use client";
// ============================================================
// TopBar — glassmorphic, premium. Real logo, search bar,
// command palette shortcut, notifications, language, theme
// toggle, profile avatar. Live clock + net worth.
// ============================================================
import { useEffect, useState } from "react";
import { Search, MessageSquare, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { useTradingStore } from "@/store/trading-store";
import { fmtUSD, fmtPct, deltaColor } from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "./ThemeToggle";
import { NotificationsDropdown } from "./NotificationsDropdown";
import { ProfileDropdown } from "./ProfileDropdown";
import { LanguageSelector } from "./LanguageSelector";
import { BrandMark } from "./BrandMark";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface TopBarProps {
  onOpenCommand: () => void;
}

export function TopBar({ onOpenCommand }: TopBarProps) {
  const portfolio = useTradingStore((s) => s.portfolio);
  const positions = useTradingStore((s) => s.positions);
  const quotes = useTradingStore((s) => s.quotes);
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // Live net worth
  const liveMV = positions.reduce((a, p) => {
    const q = quotes[p.ticker];
    return a + (q ? q.price * p.qty : p.marketValue);
  }, 0);
  const liveNet = liveMV + portfolio.cashBalance;
  const liveDay = positions.reduce((a, p) => {
    const q = quotes[p.ticker];
    if (!q) return a + p.dayChange;
    return a + (q.price - q.prevClose) * p.qty * (p.side === "LONG" ? 1 : -1);
  }, 0);
  const prevNet = liveNet - liveDay;

  return (
    <TooltipProvider delayDuration={200}>
      <header
        className="h-14 flex items-center justify-between px-4 gap-3 border-b glass sticky top-0 z-30"
        style={{ borderColor: "var(--border)" }}
      >
        {/* Left — brand + search */}
        <div className="flex items-center gap-3 min-w-0">
          {/* Brand */}
          <BrandMark size={28} stacked />
          <div className="hidden md:block w-px h-7" style={{ background: "var(--border)" }} />

          {/* Search / command bar trigger */}
          <button
            type="button"
            onClick={onOpenCommand}
            className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-[10px] border text-xs text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:border-[var(--border-strong)] transition-all focus-ring cursor-pointer group"
            style={{
              background: "var(--surface)",
              borderColor: "var(--border)",
              minWidth: 260,
            }}
            aria-label="Open command bar"
          >
            <Search size={13} className="text-[var(--muted-foreground)] group-hover:text-[var(--accent)] transition-colors" />
            <span className="flex-1 text-left">Search symbols or actions…</span>
            <kbd
              className="text-[10px] font-mono px-1.5 py-0.5 rounded-[5px] border"
              style={{ borderColor: "var(--border)", background: "var(--background)" }}
            >
              ⌘K
            </kbd>
          </button>
        </div>

        {/* Right — live stats + actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Live net worth */}
          <div className="hidden sm:flex flex-col items-end mr-1">
            <span className="text-[9px] uppercase tracking-wider text-[var(--muted-foreground)]">Net Worth</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xs font-mono tabular-nums font-semibold text-[var(--foreground)]">
                {fmtUSD(liveNet, { compact: true })}
              </span>
              <span className={cn("text-[10px] font-mono tabular-nums", deltaColor(liveDay))}>
                {fmtPct((liveDay / prevNet) * 100)}
              </span>
            </div>
          </div>

          {/* Clock */}
          <div className="hidden xl:flex flex-col items-end mr-1">
            <span className="text-[9px] uppercase tracking-wider text-[var(--muted-foreground)]">NY Time</span>
            <span className="text-xs font-mono tabular-nums text-[var(--foreground)]">
              {now
                ? now.toLocaleTimeString("en-US", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                    hour12: false,
                    timeZone: "America/New_York",
                  })
                : "—"}
            </span>
          </div>

          <div className="w-px h-6 hidden sm:block" style={{ background: "var(--border)" }} />

          {/* Quick action */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                aria-label="Quick trade"
                className="w-9 h-9 rounded-[10px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--accent)] hover:bg-[var(--accent-soft)] transition-colors focus-ring cursor-pointer"
              >
                <Zap size={15} />
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="font-sans text-xs" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
              Quick trade
            </TooltipContent>
          </Tooltip>

          {/* Messages */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                aria-label="Messages"
                className="hidden sm:flex relative w-9 h-9 rounded-[10px] items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer"
              >
                <MessageSquare size={15} />
                <span
                  className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
                  style={{ background: "var(--accent)" }}
                />
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="font-sans text-xs" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
              Messages
            </TooltipContent>
          </Tooltip>

          {/* Notifications */}
          <NotificationsDropdown />

          {/* Language */}
          <LanguageSelector />

          {/* Theme toggle */}
          <ThemeToggle />

          {/* Profile */}
          <ProfileDropdown />
        </div>
      </header>
    </TooltipProvider>
  );
}
