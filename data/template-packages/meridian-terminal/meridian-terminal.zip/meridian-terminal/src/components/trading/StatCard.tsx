"use client";
// ============================================================
// StatCard — premium stat tile with label, value, delta, and
// optional mini icon. Glassmorphic with ambient hover glow.
// ============================================================
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  label: string;
  value: string;
  delta?: string;
  deltaDirection?: "up" | "down" | "neutral";
  icon?: React.ComponentType<{ size?: number; className?: string }>;
  accent?: boolean;
  className?: string;
}

export function StatCard({
  label,
  value,
  delta,
  deltaDirection = "neutral",
  icon: Icon,
  accent,
  className,
}: StatCardProps) {
  const deltaColor =
    deltaDirection === "up"
      ? "var(--gain)"
      : deltaDirection === "down"
        ? "var(--loss)"
        : "var(--muted-foreground)";

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
      className={cn(
        "relative rounded-[14px] border p-5 glass-card shadow-premium overflow-hidden",
        className,
      )}
      style={{ borderColor: "var(--border)" }}
    >
      {accent && (
        <div
          className="absolute -top-12 -right-12 w-32 h-32 rounded-full pointer-events-none"
          style={{ background: "radial-gradient(circle, var(--accent-glow), transparent 70%)", opacity: 0.5 }}
        />
      )}
      <div className="relative flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-[11px] uppercase tracking-wider font-medium text-[var(--muted-foreground)]">
            {label}
          </p>
          <p className="text-2xl font-mono tabular-nums font-semibold text-[var(--foreground)] mt-1.5">
            {value}
          </p>
          {delta && (
            <div className="flex items-center gap-1 mt-1.5">
              {deltaDirection === "up" && <TrendingUp size={13} style={{ color: deltaColor }} />}
              {deltaDirection === "down" && <TrendingDown size={13} style={{ color: deltaColor }} />}
              <span className="text-xs font-mono tabular-nums" style={{ color: deltaColor }}>
                {delta}
              </span>
            </div>
          )}
        </div>
        {Icon && (
          <div
            className="w-10 h-10 rounded-[10px] flex items-center justify-center shrink-0"
            style={{
              background: accent ? "var(--accent-soft)" : "var(--surface-hover)",
              color: accent ? "var(--accent)" : "var(--muted-foreground)",
            }}
          >
            <Icon size={18} />
          </div>
        )}
      </div>
    </motion.div>
  );
}
