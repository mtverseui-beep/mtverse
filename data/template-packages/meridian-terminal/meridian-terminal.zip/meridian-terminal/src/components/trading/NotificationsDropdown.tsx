"use client";
// ============================================================
// NotificationsDropdown — full notification center.
// Mark all as read, individual read state, scrollable list,
// empty state, hover states, animated entrance.
// ============================================================
import { useState } from "react";
import { Bell, Check, CheckCheck, Inbox, TrendingUp, AlertTriangle, Info, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

type NotificationType = "trade" | "alert" | "info" | "social";
interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  time: string; // relative
  read: boolean;
}

const INITIAL: Notification[] = [
  {
    id: "n1",
    type: "trade",
    title: "Order filled",
    body: "BUY 200 ZNRA @ 182.50 — filled at 182.48",
    time: "2m ago",
    read: false,
  },
  {
    id: "n2",
    type: "alert",
    title: "Price alert triggered",
    body: "NVKS crossed above $425.00",
    time: "14m ago",
    read: false,
  },
  {
    id: "n3",
    type: "info",
    title: "Market update",
    body: "Fed minutes released — volatility expected",
    time: "1h ago",
    read: false,
  },
  {
    id: "n4",
    type: "trade",
    title: "Order partially filled",
    body: "SELL 150 AETH — 100 of 150 filled @ 94.10",
    time: "2h ago",
    read: true,
  },
  {
    id: "n5",
    type: "social",
    title: "New follower",
    body: "Marcus Chen started following your portfolio",
    time: "5h ago",
    read: true,
  },
];

const ICONS: Record<NotificationType, { icon: React.ComponentType<{ size?: number }>; color: string; bg: string }> = {
  trade: { icon: TrendingUp, color: "var(--gain)", bg: "var(--gain-soft)" },
  alert: { icon: AlertTriangle, color: "#F0B90B", bg: "rgba(240, 185, 11, 0.12)" },
  info: { icon: Info, color: "var(--accent)", bg: "var(--accent-soft)" },
  social: { icon: User, color: "#3DC6FF", bg: "rgba(61, 198, 255, 0.12)" },
};

export function NotificationsDropdown() {
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL);
  const unread = notifications.filter((n) => !n.read).length;

  const markAllRead = () =>
    setNotifications((arr) => arr.map((n) => ({ ...n, read: true })));
  const markRead = (id: string) =>
    setNotifications((arr) =>
      arr.map((n) => (n.id === id ? { ...n, read: true } : n)),
    );

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}
          className="relative w-9 h-9 rounded-[10px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer"
        >
          <Bell size={16} />
          {unread > 0 && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 500, damping: 25 }}
              className="absolute top-1.5 right-1.5 min-w-[15px] h-[15px] px-1 rounded-full flex items-center justify-center text-[9px] font-bold text-white font-mono"
              style={{ background: "var(--loss)" }}
            >
              {unread}
            </motion.span>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-[360px] p-0 font-sans"
        style={{
          background: "var(--popover)",
          border: "1px solid var(--border)",
          color: "var(--foreground)",
          borderRadius: "16px",
          boxShadow: "var(--shadow-xl)",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-4 py-3 border-b"
          style={{ borderColor: "var(--border)" }}
        >
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold">Notifications</h3>
            {unread > 0 && (
              <span
                className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
                style={{ background: "var(--loss-soft)", color: "var(--loss)" }}
              >
                {unread} new
              </span>
            )}
          </div>
          {unread > 0 && (
            <button
              type="button"
              onClick={markAllRead}
              className="flex items-center gap-1 text-[11px] font-medium text-[var(--accent)] hover:opacity-80 transition-opacity cursor-pointer focus-ring rounded-[6px] px-1.5 py-0.5"
            >
              <CheckCheck size={12} />
              Mark all read
            </button>
          )}
        </div>

        {/* List */}
        <div className="max-h-[360px] overflow-y-auto">
          {notifications.length === 0 ? (
            <EmptyState />
          ) : (
            <AnimatePresence initial={false}>
              {notifications.map((n) => {
                const { icon: Icon, color, bg } = ICONS[n.type];
                return (
                  <motion.button
                    key={n.id}
                    type="button"
                    layout
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, height: 0 }}
                    onClick={() => markRead(n.id)}
                    className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-[var(--surface-hover)] transition-colors cursor-pointer border-b last:border-0 relative"
                    style={{ borderColor: "var(--border)" }}
                  >
                    {/* Unread indicator */}
                    {!n.read && (
                      <span
                        className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full"
                        style={{ background: "var(--accent)" }}
                      />
                    )}
                    <span
                      className="shrink-0 w-8 h-8 rounded-[8px] flex items-center justify-center"
                      style={{ background: bg, color }}
                    >
                      <Icon size={15} />
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline justify-between gap-2">
                        <p className={cn("text-xs font-semibold truncate", !n.read && "text-[var(--foreground)]", n.read && "text-[var(--muted-foreground)]")}>
                          {n.title}
                        </p>
                        <span className="text-[10px] text-[var(--muted-foreground)] shrink-0 font-mono">
                          {n.time}
                        </span>
                      </div>
                      <p className="text-[11px] text-[var(--muted-foreground)] mt-0.5 leading-relaxed line-clamp-2">
                        {n.body}
                      </p>
                    </div>
                    {!n.read && (
                      <Check
                        size={13}
                        className="shrink-0 text-[var(--muted-foreground)] opacity-0 group-hover:opacity-100 mt-1"
                      />
                    )}
                  </motion.button>
                );
              })}
            </AnimatePresence>
          )}
        </div>

        {/* Footer */}
        <DropdownMenuSeparator style={{ background: "var(--border)" }} />
        <button
          type="button"
          className="w-full px-4 py-2.5 text-xs font-medium text-[var(--accent)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring"
        >
          View all notifications
        </button>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
      <div
        className="w-12 h-12 rounded-[14px] flex items-center justify-center mb-3"
        style={{ background: "var(--surface-hover)" }}
      >
        <Inbox size={22} className="text-[var(--muted-foreground)]" />
      </div>
      <p className="text-sm font-medium text-[var(--foreground)]">All caught up</p>
      <p className="text-xs text-[var(--muted-foreground)] mt-1">
        You have no new notifications.
      </p>
    </div>
  );
}
