"use client";
// ShortcutsSettings — keyboard shortcuts reference.
import { Keyboard, Search } from "lucide-react";
import { useState } from "react";
import { SettingsCard } from "./_shared";
import { Input } from "../../Field";
import { cn } from "@/lib/utils";

interface Shortcut {
  keys: string[];
  description: string;
  category: string;
}

const SHORTCUTS: Shortcut[] = [
  { keys: ["⌘", "K"], description: "Open command bar", category: "Global" },
  { keys: ["⌘", "/"], description: "Open keyboard shortcuts", category: "Global" },
  { keys: ["Esc"], description: "Close dialog / menu", category: "Global" },
  { keys: ["G", "T"], description: "Go to Terminal", category: "Navigation" },
  { keys: ["G", "P"], description: "Go to Portfolio", category: "Navigation" },
  { keys: ["G", "O"], description: "Go to Orders", category: "Navigation" },
  { keys: ["G", "A"], description: "Go to Alerts", category: "Navigation" },
  { keys: ["G", "H"], description: "Go to History", category: "Navigation" },
  { keys: ["G", "S"], description: "Go to Settings", category: "Navigation" },
  { keys: ["↑", "↓"], description: "Move watchlist selection", category: "Watchlist" },
  { keys: ["Enter"], description: "Select watchlist row", category: "Watchlist" },
  { keys: ["B"], description: "Buy selected symbol", category: "Trading" },
  { keys: ["S"], description: "Sell selected symbol", category: "Trading" },
  { keys: ["⌘", "↵"], description: "Submit order ticket", category: "Trading" },
  { keys: ["1"], description: "1D chart range", category: "Chart" },
  { keys: ["2"], description: "1W chart range", category: "Chart" },
  { keys: ["3"], description: "1M chart range", category: "Chart" },
  { keys: ["4"], description: "1Y chart range", category: "Chart" },
];

export function ShortcutsSettings() {
  const [query, setQuery] = useState("");
  const filtered = SHORTCUTS.filter(
    (s) => s.description.toLowerCase().includes(query.toLowerCase()) || s.category.toLowerCase().includes(query.toLowerCase()),
  );
  const categories = [...new Set(filtered.map((s) => s.category))];

  return (
    <div className="space-y-4">
      <SettingsCard title="Keyboard shortcuts" description="Master Meridian without leaving the keyboard. Search to filter.">
        <div className="relative mb-4">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)] pointer-events-none" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search shortcuts…"
            className="pl-9"
          />
        </div>
        <div className="space-y-5">
          {categories.map((cat) => (
            <div key={cat}>
              <p className="text-[10px] uppercase tracking-wider font-semibold text-[var(--muted-foreground)] mb-2">{cat}</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {filtered.filter((s) => s.category === cat).map((s, i) => (
                  <div key={i} className="flex items-center justify-between px-3 py-2 rounded-[8px] hover:bg-[var(--surface-hover)] transition-colors">
                    <span className="text-xs text-[var(--foreground)]">{s.description}</span>
                    <div className="flex items-center gap-1">
                      {s.keys.map((k, j) => (
                        <kbd
                          key={j}
                          className="text-[10px] font-mono px-1.5 py-0.5 rounded-[5px] border text-[var(--foreground)] min-w-[22px] text-center"
                          style={{ borderColor: "var(--border)", background: "var(--surface)" }}
                        >
                          {k}
                        </kbd>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </SettingsCard>
    </div>
  );
}
