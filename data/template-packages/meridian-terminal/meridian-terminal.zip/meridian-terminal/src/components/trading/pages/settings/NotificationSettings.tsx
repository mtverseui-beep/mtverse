"use client";
// NotificationSettings — email, push, in-app notification toggles.
import { useState } from "react";
import { Check } from "lucide-react";
import { SettingsCard, Toggle, SettingRow } from "./_shared";
import { Button } from "../../Button";
import { toast } from "sonner";

export function NotificationSettings() {
  const [orderFills, setOrderFills] = useState(true);
  const [priceAlerts, setPriceAlerts] = useState(true);
  const [marginCalls, setMarginCalls] = useState(true);
  const [marketNews, setMarketNews] = useState(false);
  const [weeklyDigest, setWeeklyDigest] = useState(true);
  const [productUpdates, setProductUpdates] = useState(false);
  const [emailChannel, setEmailChannel] = useState(true);
  const [pushChannel, setPushChannel] = useState(true);
  const [inAppChannel, setInAppChannel] = useState(true);

  return (
    <div className="space-y-4">
      <SettingsCard title="Trading notifications" description="Get notified about your order activity.">
        <SettingRow>
          <Toggle checked={orderFills} onCheckedChange={setOrderFills} label="Order fills" description="When your orders are fully or partially filled." />
          <Toggle checked={priceAlerts} onCheckedChange={setPriceAlerts} label="Price alerts" description="When a symbol crosses your alert threshold." />
          <Toggle checked={marginCalls} onCheckedChange={setMarginCalls} label="Margin calls" description="When your account falls below maintenance margin." />
        </SettingRow>
      </SettingsCard>

      <SettingsCard title="Market & product" description="Stay informed about the market and Meridian.">
        <SettingRow>
          <Toggle checked={marketNews} onCheckedChange={setMarketNews} label="Market news" description="Breaking market-moving news during trading hours." />
          <Toggle checked={weeklyDigest} onCheckedChange={setWeeklyDigest} label="Weekly digest" description="A summary of your trading activity every Monday." />
          <Toggle checked={productUpdates} onCheckedChange={setProductUpdates} label="Product updates" description="New features and improvements to Meridian Terminal." />
        </SettingRow>
      </SettingsCard>

      <SettingsCard title="Delivery channels" description="Choose how you receive notifications.">
        <SettingRow>
          <Toggle checked={emailChannel} onCheckedChange={setEmailChannel} label="Email" description="aria.redmond@meridian.io" />
          <Toggle checked={pushChannel} onCheckedChange={setPushChannel} label="Push notifications" description="Browser push when the terminal is open." />
          <Toggle checked={inAppChannel} onCheckedChange={setInAppChannel} label="In-app" description="The notification bell in the top bar." />
        </SettingRow>
      </SettingsCard>

      <div className="flex items-center justify-end">
        <Button variant="primary" size="md" icon={Check} onClick={() => toast.success("Notification preferences saved")}>
          Save preferences
        </Button>
      </div>
    </div>
  );
}
