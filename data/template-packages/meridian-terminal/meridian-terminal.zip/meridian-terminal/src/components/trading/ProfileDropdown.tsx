"use client";
// ============================================================
// ProfileDropdown — animated, outside-click close, keyboard
// accessible. View profile / Settings / Billing / Team /
// Shortcuts / Help / Log out. Navigates via hash routes.
// ============================================================
import {
  User,
  Settings,
  CreditCard,
  Users,
  Keyboard,
  HelpCircle,
  LogOut,
  ChevronDown,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar } from "./Avatar";
import { useHashRoute } from "@/hooks/use-hash-route";
import { toast } from "sonner";

const USER = {
  name: "Aria Redmond",
  email: "aria.redmond@meridian.io",
  seed: "aria-redmond",
  plan: "Margin · Tier 3",
  accountId: "4F92A1",
};

const ITEMS: { icon: typeof User; label: string; path: string; shortcut?: string }[] = [
  { icon: User, label: "View profile", path: "profile" },
  { icon: Settings, label: "Account settings", path: "settings/account" },
  { icon: CreditCard, label: "Billing", path: "settings/billing" },
  { icon: Users, label: "Team", path: "settings/team" },
  { icon: Keyboard, label: "Keyboard shortcuts", path: "settings/shortcuts", shortcut: "⌘/" },
  { icon: HelpCircle, label: "Help & support", path: "help" },
];

export function ProfileDropdown() {
  const [, navigate] = useHashRoute();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label="Account menu"
          className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-[12px] border hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer"
          style={{
            borderColor: "var(--border)",
            background: "var(--surface)",
          }}
        >
          <Avatar seed={USER.seed} name={USER.name} size={28} />
          <div className="hidden sm:flex flex-col items-start leading-none">
            <span className="text-[11px] font-semibold text-[var(--foreground)]">
              {USER.name.split(" ")[0]}
            </span>
            <span className="text-[9px] text-[var(--muted-foreground)] font-mono">
              {USER.plan}
            </span>
          </div>
          <ChevronDown size={12} className="text-[var(--muted-foreground)]" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-64 p-0 font-sans"
        style={{
          background: "var(--popover)",
          border: "1px solid var(--border)",
          color: "var(--foreground)",
          borderRadius: "16px",
          boxShadow: "var(--shadow-xl)",
          overflow: "hidden",
        }}
      >
        {/* User header */}
        <div
          className="flex items-center gap-3 px-4 py-3.5 border-b relative overflow-hidden"
          style={{
            borderColor: "var(--border)",
            background: "linear-gradient(135deg, var(--accent-soft), transparent)",
          }}
        >
          <Avatar seed={USER.seed} name={USER.name} size={40} ring />
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-[var(--foreground)] truncate">
              {USER.name}
            </p>
            <p className="text-[11px] text-[var(--muted-foreground)] truncate">
              {USER.email}
            </p>
          </div>
        </div>

        {/* Account info */}
        <div
          className="flex items-center justify-between px-4 py-2 border-b text-[10px] font-mono"
          style={{ borderColor: "var(--border)", background: "var(--surface)" }}
        >
          <span className="text-[var(--muted-foreground)]">Account</span>
          <span className="text-[var(--foreground)]">{USER.accountId}</span>
        </div>

        {/* Menu items */}
        <div className="py-1.5">
          {ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <DropdownMenuItem
                key={item.label}
                onClick={() => navigate(item.path)}
                className="cursor-pointer focus:bg-[var(--surface-hover)] focus:text-[var(--foreground)] rounded-[8px] mx-1 gap-2.5 px-2.5 py-2 text-sm"
              >
                <Icon size={15} className="text-[var(--muted-foreground)]" />
                <span className="flex-1">{item.label}</span>
                {item.shortcut && (
                  <span className="text-[10px] font-mono text-[var(--muted-foreground)] px-1.5 py-0.5 rounded border"
                    style={{ borderColor: "var(--border)" }}>
                    {item.shortcut}
                  </span>
                )}
              </DropdownMenuItem>
            );
          })}
        </div>

        <DropdownMenuSeparator style={{ background: "var(--border)" }} />

        {/* Logout */}
        <div className="py-1.5">
          <DropdownMenuItem
            onClick={() => toast.info("Log out", { description: "Session ended. (Demo — no auth backend.)" })}
            className="cursor-pointer focus:bg-[var(--loss-soft)] rounded-[8px] mx-1 gap-2.5 px-2.5 py-2 text-sm text-[var(--loss)]"
          >
            <LogOut size={15} />
            <span>Log out</span>
          </DropdownMenuItem>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
