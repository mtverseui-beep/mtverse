"use client";
// ============================================================
// Field + Input + Textarea — modern form primitives.
// Field wraps a label + control + error message with premium styling.
// ============================================================
import { forwardRef } from "react";
import { cn } from "@/lib/utils";
import { AlertCircle } from "lucide-react";

interface FieldProps {
  label?: string;
  description?: string;
  error?: string;
  required?: boolean;
  children: React.ReactNode;
  className?: string;
  htmlFor?: string;
}

export function Field({ label, description, error, required, children, className, htmlFor }: FieldProps) {
  return (
    <div className={cn("space-y-1.5", className)}>
      {label && (
        <label htmlFor={htmlFor} className="block text-xs font-medium text-[var(--foreground)]">
          {label}
          {required && <span className="text-[var(--loss)] ml-0.5">*</span>}
        </label>
      )}
      {children}
      {description && !error && (
        <p className="text-[11px] text-[var(--muted-foreground)] leading-relaxed">{description}</p>
      )}
      {error && (
        <p className="text-[11px] text-[var(--loss)] flex items-center gap-1 leading-relaxed">
          <AlertCircle size={11} />
          {error}
        </p>
      )}
    </div>
  );
}

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  invalid?: boolean;
  leading?: React.ReactNode;
  trailing?: React.ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, invalid, leading, trailing, ...props }, ref) => {
    return (
      <div className="relative">
        {leading && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)] pointer-events-none">
            {leading}
          </span>
        )}
        <input
          ref={ref}
          className={cn(
            "w-full h-9 px-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none transition-colors hover:border-[var(--border-strong)]",
            "text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] font-mono tabular-nums",
            leading && "pl-9",
            trailing && "pr-9",
            invalid && "border-[var(--loss)]",
            className,
          )}
          style={{ borderColor: invalid ? "var(--loss)" : "var(--border)" }}
          {...props}
        />
        {trailing && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]">
            {trailing}
          </span>
        )}
      </div>
    );
  },
);
Input.displayName = "Input";

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  invalid?: boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, invalid, ...props }, ref) => {
    return (
      <textarea
        ref={ref}
        className={cn(
          "w-full px-3 py-2 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none transition-colors hover:border-[var(--border-strong)] resize-none",
          "text-[var(--foreground)] placeholder:text-[var(--muted-foreground)] leading-relaxed",
          invalid && "border-[var(--loss)]",
          className,
        )}
        style={{ borderColor: invalid ? "var(--loss)" : "var(--border)" }}
        {...props}
      />
    );
  },
);
Textarea.displayName = "Textarea";
