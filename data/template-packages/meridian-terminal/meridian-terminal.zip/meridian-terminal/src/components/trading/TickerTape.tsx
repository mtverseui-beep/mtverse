"use client";
// ============================================================
// TickerTape — horizontal scrolling marquee of 12-15 symbols.
// Pauses on hover. Each cell shows ticker, price, delta.
// ============================================================
import { useTradingStore } from "@/store/trading-store";
import { fmtPrice, fmtPct, deltaColor } from "@/lib/trading/format";
import { PriceCell } from "./PriceCell";
import { cn } from "@/lib/utils";

export function TickerTape() {
  const symbols = useTradingStore((s) => s.symbols);
  const quotes = useTradingStore((s) => s.quotes);
  const select = useTradingStore((s) => s.select);
  const selected = useTradingStore((s) => s.selectedTicker);

  // Duplicate the array so the marquee loop is seamless.
  const loop = [...symbols, ...symbols];

  return (
    <div
      className="relative h-10 border-b overflow-hidden glass"
      role="region"
      aria-label="Live ticker tape"
    >
      {/* Edge fades */}
      <div
        className="absolute left-0 top-0 bottom-0 w-16 z-10 pointer-events-none"
        style={{ background: "linear-gradient(to right, var(--surface), transparent)" }}
      />
      <div
        className="absolute right-0 top-0 bottom-0 w-16 z-10 pointer-events-none"
        style={{ background: "linear-gradient(to left, var(--surface), transparent)" }}
      />

      <div className="marquee-track flex items-center h-10 w-max">
        {loop.map((sym, i) => {
          const q = quotes[sym.ticker];
          if (!q) return null;
          const change = q.price - q.prevClose;
          const changePct = (change / q.prevClose) * 100;
          const active = sym.ticker === selected;
          return (
            <button
              key={`${sym.ticker}-${i}`}
              type="button"
              onClick={() => select(sym.ticker)}
              className={cn(
                "flex items-center gap-2 px-4 h-10 border-r whitespace-nowrap transition-colors cursor-pointer",
                active ? "bg-[var(--accent-soft)]" : "hover:bg-[var(--surface-hover)]",
              )}
              style={{ borderColor: "var(--border)" }}
              aria-label={`${sym.ticker} ${fmtPrice(q.price)} ${fmtPct(changePct)}`}
            >
              <span
                className="text-[11px] font-semibold tracking-wide"
                style={{ color: active ? "var(--accent)" : "var(--foreground)" }}
              >
                {sym.ticker}
              </span>
              <PriceCell
                value={q.price}
                format={(n) => fmtPrice(n)}
                className="text-[11px] text-[var(--foreground)]"
              />
              <span
                className={cn("text-[11px] font-mono tabular-nums", deltaColor(change))}
              >
                {fmtPct(changePct)}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
