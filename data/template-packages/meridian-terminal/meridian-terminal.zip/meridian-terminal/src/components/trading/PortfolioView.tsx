"use client";
// ============================================================
// PortfolioView — second page (broken layout). Hero net-worth,
// allocation donut (Recharts), performance area chart (Recharts),
// holdings table.
// ============================================================
import { useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ReferenceLine,
  ResponsiveContainer,
  Sector,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useTradingStore } from "@/store/trading-store";
import {
  fmtPrice,
  fmtUSD,
  fmtPct,
  fmtCompact,
  fmtDate,
  deltaColor,
} from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { Sparkline } from "./Sparkline";
import type { PortfolioSummary } from "@/lib/trading/mock-data";
import type { Position } from "@/lib/trading/types";

/** Resolve a CSS variable to its current computed color, re-resolving on theme change. */
function useResolvedVar(varName: string): string {
  const [val, setVal] = useState(varName);
  useEffect(() => {
    const resolve = () => {
      const v = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
      if (v) setVal(v);
    };
    resolve();
    const obs = new MutationObserver(() => resolve());
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => obs.disconnect();
  }, [varName]);
  return val;
}

const DONUT_COLORS = [
  "#6C5CE7",
  "var(--gain)",
  "#F0B90B",
  "var(--loss)",
  "#3DC6FF",
  "var(--accent)",
  "var(--muted-foreground)",
];

export function PortfolioView() {
  const portfolio = useTradingStore((s) => s.portfolio);
  const positions = useTradingStore((s) => s.positions);
  const quotes = useTradingStore((s) => s.quotes);
  const accentColor = useResolvedVar("--accent");
  const gridColor = useResolvedVar("--border");
  const mutedColor = useResolvedVar("--muted-foreground");
  const [activeSector, setActiveSector] = useState<number | null>(null);

  // Live-adjust positions using current quotes (so P&L feels live)
  const livePositions: Position[] = useMemo(() => {
    return positions.map((p) => {
      const q = quotes[p.ticker];
      if (!q) return p;
      const last = q.price;
      const marketValue = last * p.qty;
      const grossPnl =
        p.side === "LONG"
          ? marketValue - p.costBasis
          : p.costBasis - marketValue;
      const dayChange =
        (last - q.prevClose) * p.qty * (p.side === "LONG" ? 1 : -1);
      return {
        ...p,
        last,
        marketValue,
        unrealizedPnl: grossPnl,
        unrealizedPnlPct: (grossPnl / p.costBasis) * 100,
        dayChange,
        dayChangePct: (last - q.prevClose) / q.prevClose * 100 * (p.side === "LONG" ? 1 : -1),
      };
    });
  }, [positions, quotes]);

  const liveNetWorth =
    livePositions.reduce((a, p) => a + p.marketValue, 0) + portfolio.cashBalance;
  const liveDayPnl = livePositions.reduce((a, p) => a + p.dayChange, 0);
  const liveTotalPnl = livePositions.reduce((a, p) => a + p.unrealizedPnl, 0);
  const prevNetWorth = liveNetWorth - liveDayPnl;

  // Sort holdings by market value desc
  const sortedHoldings = [...livePositions].sort((a, b) => b.marketValue - a.marketValue);

  return (
    <div className="h-full overflow-y-auto" style={{ background: "var(--background)" }}>
      <div className="max-w-[1400px] mx-auto p-6 space-y-4">
        {/* Hero net-worth — glassmorphic with ambient glow */}
        <section
          className="rounded-[16px] border p-6 relative overflow-hidden glass-card shadow-premium-lg"
          style={{
            borderColor: "var(--border)",
          }}
        >
          {/* Ambient glow */}
          <div
            className="absolute -top-24 -right-24 w-72 h-72 rounded-full pointer-events-none"
            style={{ background: "radial-gradient(circle, var(--accent-glow), transparent 70%)", opacity: 0.5 }}
          />
          <div className="relative flex items-end justify-between flex-wrap gap-6">
            <div>
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-wider text-[var(--muted-foreground)]">
                <span className="w-1.5 h-1.5 rounded-full live-pulse" style={{ background: "var(--gain)" }} />
                Net Worth · Live
              </div>
              <div className="mt-2 flex items-baseline gap-3">
                <span className="text-5xl font-mono font-semibold tabular-nums text-[var(--foreground)] tracking-tight">
                  {fmtUSD(liveNetWorth)}
                </span>
                <span
                  className={cn(
                    "text-base font-mono tabular-nums",
                    deltaColor(liveDayPnl),
                  )}
                >
                  {fmtUSD(liveDayPnl, { sign: true })} ({fmtPct((liveDayPnl / prevNetWorth) * 100)})
                </span>
                <span className="text-[11px] text-[var(--muted-foreground)]">today</span>
              </div>
              <div className="mt-1 text-xs text-[var(--muted-foreground)]">
                As of {fmtDate(Date.now())} · Cash {fmtUSD(portfolio.cashBalance)} · Buying Power {fmtUSD(portfolio.buyingPower)}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <HeroStat
                label="Market Value"
                value={fmtUSD(livePositions.reduce((a, p) => a + p.marketValue, 0))}
              />
              <HeroStat
                label="Total P&L"
                value={fmtUSD(liveTotalPnl, { sign: true })}
                valueClass={deltaColor(liveTotalPnl)}
              />
              <HeroStat
                label="Total Return"
                value={fmtPct(portfolio.totalPnlPct)}
                valueClass={deltaColor(portfolio.totalPnlPct)}
              />
            </div>
          </div>
        </section>

        {/* Two-up: performance chart + allocation donut */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Performance chart (2/3) */}
          <section
            className="lg:col-span-2 rounded-[14px] border p-5 glass-card shadow-premium"
            style={{
              borderColor: "var(--border)",
            }}
            aria-label="Net worth performance"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-semibold text-[var(--foreground)]">Net Worth Performance</h2>
                <p className="text-[11px] text-[var(--muted-foreground)]">Trailing 90 days</p>
              </div>
              <div className="flex items-center gap-2">
                <Range label="1M" />
                <Range label="3M" active />
                <Range label="YTD" />
                <Range label="ALL" />
              </div>
            </div>
            <div style={{ height: 280 }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={portfolio.history} margin={{ top: 10, right: 8, bottom: 0, left: 0 }}>
                  <defs>
                    <linearGradient id="networth-grad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={accentColor} stopOpacity={0.45} />
                      <stop offset="100%" stopColor={accentColor} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
                  <XAxis
                    dataKey="t"
                    tickFormatter={(t) => new Date(t).toLocaleDateString("en-US", { month: "short", day: "2-digit" })}
                    stroke={mutedColor}
                    tick={{ fill: mutedColor, fontSize: 10, fontFamily: "var(--font-mono)" }}
                    tickLine={false}
                    axisLine={{ stroke: gridColor }}
                    minTickGap={40}
                  />
                  <YAxis
                    domain={["dataMin", "dataMax"]}
                    tickFormatter={(v) => `$${Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(v)}`}
                    stroke={mutedColor}
                    tick={{ fill: mutedColor, fontSize: 10, fontFamily: "var(--font-mono)" }}
                    tickLine={false}
                    axisLine={false}
                    width={56}
                  />
                  <RTooltip
                    contentStyle={{
                      background: "var(--surface-elevated)",
                      border: "1px solid var(--border)",
                      borderRadius: "10px",
                      fontSize: "11px",
                      fontFamily: "var(--font-mono)",
                      color: "var(--foreground)",
                      boxShadow: "var(--shadow-lg)",
                      padding: "8px 12px",
                    }}
                    labelFormatter={(t) => fmtDate(Number(t))}
                    formatter={(v: number) => [fmtUSD(v), "Net Worth"]}
                    cursor={{ stroke: accentColor, strokeWidth: 1, strokeDasharray: "4 4" }}
                  />
                  {liveNetWorth !== portfolio.history[portfolio.history.length - 1]?.v && (
                    <ReferenceLine
                      y={liveNetWorth}
                      stroke={accentColor}
                      strokeDasharray="2 4"
                      strokeOpacity={0.5}
                      label={{
                        value: "Now",
                        position: "right",
                        fill: accentColor,
                        fontSize: 9,
                        fontFamily: "var(--font-mono)",
                      }}
                    />
                  )}
                  <Area
                    type="monotone"
                    dataKey="v"
                    stroke={accentColor}
                    strokeWidth={2}
                    fill="url(#networth-grad)"
                    isAnimationActive
                    animationDuration={800}
                    dot={false}
                    activeDot={{ r: 4, fill: accentColor, strokeWidth: 2, stroke: "var(--surface)" }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </section>

          {/* Allocation donut (1/3) */}
          <section
            className="rounded-[14px] border p-5 glass-card shadow-premium"
            style={{
              background: "var(--surface)",
              borderColor: "var(--border)",
            }}
            aria-label="Sector allocation"
          >
            <h2 className="text-sm font-semibold text-[var(--foreground)]">Sector Allocation</h2>
            <p className="text-[11px] text-[var(--muted-foreground)] mb-3">By market value</p>
            <div style={{ height: 200 }} className="relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={portfolio.allocation}
                    dataKey="value"
                    nameKey="label"
                    cx="50%"
                    cy="50%"
                    innerRadius={56}
                    outerRadius={86}
                    paddingAngle={2}
                    stroke="none"
                    isAnimationActive
                    animationDuration={600}
                    activeIndex={activeSector ?? undefined}
                    activeShape={(props: { cx?: number; cy?: number; innerRadius?: number; outerRadius?: number; startAngle?: number; endAngle?: number; fill?: string }) => {
                      const { cx = 0, cy = 0, innerRadius = 0, outerRadius = 0, startAngle = 0, endAngle = 0, fill = "#000" } = props;
                      return (
                        <Sector
                          cx={cx}
                          cy={cy}
                          innerRadius={innerRadius}
                          outerRadius={outerRadius + 6}
                          startAngle={startAngle - 1}
                          endAngle={endAngle + 1}
                          fill={fill}
                        />
                      );
                    }}
                    onMouseEnter={(_, i) => setActiveSector(i)}
                    onMouseLeave={() => setActiveSector(null)}
                  >
                    {portfolio.allocation.map((_, i) => (
                      <Cell key={i} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />
                    ))}
                  </Pie>
                  <RTooltip
                    contentStyle={{
                      background: "var(--surface-elevated)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                      fontSize: "11px",
                      fontFamily: "var(--font-mono)",
                      color: "var(--foreground)",
                      boxShadow: "var(--shadow-lg)",
                      padding: "8px 12px",
                    }}
                    formatter={(v: number, _n, p) => [
                      `${fmtUSD(v)} · ${p.payload.pct.toFixed(1)}%`,
                      p.payload.label,
                    ]}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                {activeSector !== null && portfolio.allocation[activeSector] ? (
                  <>
                    <span className="text-[10px] uppercase tracking-wider text-[var(--muted-foreground)]">
                      {portfolio.allocation[activeSector].label}
                    </span>
                    <span className="text-base font-mono tabular-nums text-[var(--foreground)]">
                      {fmtUSD(portfolio.allocation[activeSector].value, { compact: true })}
                    </span>
                    <span className="text-[10px] font-mono tabular-nums" style={{ color: DONUT_COLORS[activeSector % DONUT_COLORS.length] }}>
                      {portfolio.allocation[activeSector].pct.toFixed(1)}%
                    </span>
                  </>
                ) : (
                  <>
                    <span className="text-[10px] uppercase tracking-wider text-[var(--muted-foreground)]">Invested</span>
                    <span className="text-base font-mono tabular-nums text-[var(--foreground)]">
                      {fmtUSD(livePositions.reduce((a, p) => a + p.marketValue, 0), { compact: true })}
                    </span>
                  </>
                )}
              </div>
            </div>
            {/* Legend */}
            <div className="mt-3 grid grid-cols-2 gap-1.5">
              {portfolio.allocation.map((a, i) => (
                <button
                  key={a.label}
                  type="button"
                  onMouseEnter={() => setActiveSector(i)}
                  onMouseLeave={() => setActiveSector(null)}
                  className="flex items-center gap-1.5 text-[11px] rounded-[6px] px-1.5 py-1 transition-colors cursor-pointer focus-ring text-left"
                  style={{ background: activeSector === i ? "var(--surface-hover)" : "transparent" }}
                >
                  <span
                    className="w-2 h-2 rounded-sm shrink-0"
                    style={{ background: DONUT_COLORS[i % DONUT_COLORS.length], opacity: activeSector === null || activeSector === i ? 1 : 0.3 }}
                  />
                  <span className="text-[var(--muted-foreground)] truncate flex-1">{a.label}</span>
                  <span className="text-[var(--foreground)] font-mono tabular-nums">{a.pct.toFixed(1)}%</span>
                </button>
              ))}
            </div>
          </section>
        </div>

        {/* Holdings table */}
        <section
          className="rounded-[14px] border overflow-hidden glass-card shadow-premium"
          style={{
            background: "var(--surface)",
            borderColor: "var(--border)",
          }}
          aria-label="Holdings"
        >
          <header
            className="px-5 py-3 border-b flex items-center justify-between"
            style={{ borderColor: "var(--border)" }}
          >
            <h2 className="text-sm font-semibold text-[var(--foreground)]">Holdings</h2>
            <span className="text-[11px] text-[var(--muted-foreground)]">
              {sortedHoldings.length} positions · sorted by market value
            </span>
          </header>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr
                  className="text-[10px] uppercase tracking-wider text-[var(--muted-foreground)] border-b"
                  style={{ borderColor: "var(--border)", background: "var(--background)" }}
                >
                  <th className="text-left px-4 py-2 font-semibold">Symbol</th>
                  <th className="text-left px-4 py-2 font-semibold">Side</th>
                  <th className="text-right px-4 py-2 font-semibold">Qty</th>
                  <th className="text-right px-4 py-2 font-semibold">Avg Entry</th>
                  <th className="text-right px-4 py-2 font-semibold">Last</th>
                  <th className="text-right px-4 py-2 font-semibold">Mkt Value</th>
                  <th className="text-right px-4 py-2 font-semibold">Day P&L</th>
                  <th className="text-right px-4 py-2 font-semibold">Unrealized P&L</th>
                  <th className="text-right px-4 py-2 font-semibold w-24">Trend</th>
                </tr>
              </thead>
              <tbody>
                {sortedHoldings.map((p) => {
                  const isLong = p.side === "LONG";
                  return (
                    <tr
                      key={p.ticker}
                      className="border-b hover:bg-[var(--surface-hover)] transition-colors font-mono tabular-nums"
                      style={{ borderColor: "var(--border)" }}
                    >
                      <td className="px-4 py-2.5">
                        <div className="font-semibold text-[var(--foreground)]">{p.ticker}</div>
                        <div className="text-[10px] text-[var(--muted-foreground)] font-sans truncate max-w-[140px]">{p.name}</div>
                      </td>
                      <td className="px-4 py-2.5">
                        <span
                          className={cn(
                            "text-[9px] px-1.5 py-0.5 rounded-[3px] font-semibold",
                            isLong ? "text-[var(--gain)]" : "text-[var(--loss)]",
                          )}
                          style={{
                            background: isLong ? "var(--gain-soft)" : "var(--loss-soft)",
                          }}
                        >
                          {p.side}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-right text-[var(--foreground)]">{fmtCompact(p.qty)}</td>
                      <td className="px-4 py-2.5 text-right text-[var(--muted-foreground)]">{fmtPrice(p.avgEntry)}</td>
                      <td className="px-4 py-2.5 text-right text-[var(--foreground)]">{fmtPrice(p.last)}</td>
                      <td className="px-4 py-2.5 text-right text-[var(--foreground)]">{fmtUSD(p.marketValue, { compact: true })}</td>
                      <td className={cn("px-4 py-2.5 text-right", deltaColor(p.dayChange))}>
                        {fmtUSD(p.dayChange, { sign: true })}
                        <div className="text-[10px]">{fmtPct(p.dayChangePct)}</div>
                      </td>
                      <td className={cn("px-4 py-2.5 text-right font-semibold", deltaColor(p.unrealizedPnl))}>
                        {fmtUSD(p.unrealizedPnl, { sign: true })}
                        <div className="text-[10px]">{fmtPct(p.unrealizedPnlPct)}</div>
                      </td>
                      <td className="px-4 py-2.5">
                        <Sparkline data={p.pnlSeries} positive={p.unrealizedPnl > 0} height={28} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr
                  className="border-t font-mono tabular-nums"
                  style={{ borderColor: "var(--border)", background: "var(--background)" }}
                >
                  <td className="px-4 py-2.5 text-[10px] uppercase tracking-wider text-[var(--muted-foreground)] font-sans" colSpan={5}>
                    Total · {sortedHoldings.length} positions
                  </td>
                  <td className="px-4 py-2.5 text-right text-[var(--foreground)]">
                    {fmtUSD(livePositions.reduce((a, p) => a + p.marketValue, 0), { compact: true })}
                  </td>
                  <td className={cn("px-4 py-2.5 text-right", deltaColor(liveDayPnl))}>
                    {fmtUSD(liveDayPnl, { sign: true })}
                  </td>
                  <td className={cn("px-4 py-2.5 text-right font-semibold", deltaColor(liveTotalPnl))}>
                    {fmtUSD(liveTotalPnl, { sign: true })}
                  </td>
                  <td />
                </tr>
              </tfoot>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}

function HeroStat({
  label,
  value,
  valueClass,
}: {
  label: string;
  value: string;
  valueClass?: string;
}) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-[var(--muted-foreground)]">{label}</div>
      <div className={cn("text-base font-mono tabular-nums text-[var(--foreground)] mt-0.5", valueClass)}>
        {value}
      </div>
    </div>
  );
}

function Range({ label, active }: { label: string; active?: boolean }) {
  return (
    <span
      className={cn(
        "px-2 py-0.5 text-[10px] font-mono rounded-[4px] border cursor-default",
        active ? "text-[var(--accent)]" : "text-[var(--muted-foreground)]",
      )}
      style={{
        borderColor: active ? "rgba(108,92,231,0.4)" : "var(--border)",
        background: active ? "var(--accent-soft)" : "transparent",
      }}
    >
      {label}
    </span>
  );
}
