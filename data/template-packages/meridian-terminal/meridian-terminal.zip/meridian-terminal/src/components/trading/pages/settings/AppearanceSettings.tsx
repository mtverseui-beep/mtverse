"use client";
// AppearanceSettings — theme, density, font scale, accent color.
import { useState } from "react";
import { useTheme } from "next-themes";
import { Sun, Moon, Monitor, Check } from "lucide-react";
import { motion } from "framer-motion";
import { SettingsCard, Toggle } from "./_shared";
import { Button } from "../../Button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const THEMES = [
  { id: "light", label: "Light", icon: Sun },
  { id: "dark", label: "Dark", icon: Moon },
  { id: "system", label: "System", icon: Monitor },
] as const;

const ACCENTS = [
  { id: "#6C5CE7", label: "Indigo" },
  { id: "#00A66E", label: "Emerald" },
  { id: "#3DC6FF", label: "Sky" },
  { id: "#F0B90B", label: "Gold" },
  { id: "#FF6B6B", label: "Coral" },
];

export function AppearanceSettings() {
  const { theme, setTheme } = useTheme();
  const [density, setDensity] = useState<"comfortable" | "compact">("comfortable");
  const [fontScale, setFontScale] = useState(100);
  const [accent, setAccent] = useState("#6C5CE7");
  const [animations, setAnimations] = useState(true);

  return (
    <div className="space-y-4">
      <SettingsCard title="Theme" description="Choose how Meridian looks. System follows your OS preference.">
        <div className="grid grid-cols-3 gap-3">
          {THEMES.map((t) => {
            const Icon = t.icon;
            const isActive = theme === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTheme(t.id)}
                className={cn(
                  "relative rounded-[12px] border p-4 flex flex-col items-center gap-2 transition-all cursor-pointer focus-ring",
                  isActive ? "border-[var(--accent)]" : "border-[var(--border)] hover:border-[var(--border-strong)]",
                )}
                style={isActive ? { background: "var(--accent-soft)" } : { background: "var(--surface)" }}
              >
                <Icon size={20} className={isActive ? "text-[var(--accent)]" : "text-[var(--muted-foreground)]"} />
                <span className={cn("text-xs font-medium", isActive ? "text-[var(--accent)]" : "text-[var(--foreground)]")}>{t.label}</span>
                {isActive && (
                  <motion.span layoutId="theme-card-active" className="absolute top-2 right-2 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: "var(--accent)" }}>
                    <Check size={10} className="text-white" />
                  </motion.span>
                )}
              </button>
            );
          })}
        </div>
      </SettingsCard>

      <SettingsCard title="Accent color" description="Personalize the brand accent used across the UI.">
        <div className="flex items-center gap-3 flex-wrap">
          {ACCENTS.map((a) => (
            <button
              key={a.id}
              type="button"
              onClick={() => { setAccent(a.id); toast.success(`Accent set to ${a.label}`); }}
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-transform cursor-pointer focus-ring",
                accent === a.id && "ring-2 ring-offset-2 ring-offset-[var(--surface)]",
              )}
              style={{ background: a.id, boxShadow: `0 4px 12px ${a.id}40` }}
              aria-label={a.label}
            >
              {accent === a.id && <Check size={16} className="text-white" />}
            </button>
          ))}
        </div>
      </SettingsCard>

      <SettingsCard title="Display density" description="Adjust spacing density to fit more or less on screen.">
        <div className="grid grid-cols-2 gap-3">
          {(["comfortable", "compact"] as const).map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => setDensity(d)}
              className={cn(
                "rounded-[12px] border p-4 text-left transition-all cursor-pointer focus-ring",
                density === d ? "border-[var(--accent)]" : "border-[var(--border)] hover:border-[var(--border-strong)]",
              )}
              style={density === d ? { background: "var(--accent-soft)" } : { background: "var(--surface)" }}
            >
              <p className={cn("text-sm font-medium capitalize", density === d ? "text-[var(--accent)]" : "text-[var(--foreground)]")}>{d}</p>
              <p className="text-xs text-[var(--muted-foreground)] mt-1">
                {d === "comfortable" ? "Generous spacing, easier on the eyes" : "Tight spacing, more data per screen"}
              </p>
            </button>
          ))}
        </div>
      </SettingsCard>

      <SettingsCard title="Typography & motion" description="Font scaling and animation preferences.">
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-[var(--foreground)]">Font scale</span>
              <span className="text-xs font-mono text-[var(--muted-foreground)]">{fontScale}%</span>
            </div>
            <input
              type="range"
              min={80}
              max={120}
              step={5}
              value={fontScale}
              onChange={(e) => setFontScale(Number(e.target.value))}
              className="w-full accent-[var(--accent)] cursor-pointer"
            />
          </div>
          <Toggle checked={animations} onCheckedChange={setAnimations} label="Enable animations" description="Framer Motion micro-interactions, transitions, and entrance animations." />
        </div>
      </SettingsCard>
    </div>
  );
}
