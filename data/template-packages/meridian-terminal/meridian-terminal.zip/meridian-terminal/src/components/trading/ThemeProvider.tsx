"use client";
// ============================================================
// ThemeProvider — wraps next-themes with Meridian defaults.
// Default theme = light, with system fallback.
// ============================================================
import { ThemeProvider as NextThemesProvider } from "next-themes";
import type { ComponentProps } from "react";

export function ThemeProvider({
  children,
  ...props
}: ComponentProps<typeof NextThemesProvider>) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="light"
      enableSystem
      disableTransitionOnChange={false}
      storageKey="meridian-theme"
      {...props}
    >
      {children}
    </NextThemesProvider>
  );
}
