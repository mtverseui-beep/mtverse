"use client";
// ============================================================
// ChartPanel — center column. TradingView lightweight-charts:
// candlestick + volume + SMA/EMA overlays + live price line +
// symbol watermark. Range switch 1D / 1W / 1M / 1Y.
// ============================================================
import { useEffect, useMemo, useRef, useState } from "react";
import {
  createChart,
  ColorType,
  CrosshairMode,
  CandlestickSeries,
  HistogramSeries,
  LineSeries,
  LineStyle,
  type IChartApi,
  type ISeriesApi,
  type UTCTimestamp,
  type CandlestickData,
  type HistogramData,
  type LineData,
  type Time,
  type IPriceLine,
} from "lightweight-charts";
import { useTheme } from "next-themes";
import { motion } from "framer-motion";
import { useTradingStore } from "@/store/trading-store";
import { fmtPrice, fmtPct, fmtUSD, deltaColor } from "@/lib/trading/format";
import { PriceCell } from "./PriceCell";
import { cn } from "@/lib/utils";
import type { ChartRange, Candle } from "@/lib/trading/types";

const RANGES: ChartRange[] = ["1D", "1W", "1M", "1Y"];

/** Read a CSS variable's resolved color value from :root. */
function cssVar(name: string): string {
  if (typeof window === "undefined") return "#000000";
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || "#000000";
}

// ---------- Moving average helpers ----------
function sma(closes: number[], period: number): (number | null)[] {
  const out: (number | null)[] = [];
  for (let i = 0; i < closes.length; i++) {
    if (i < period - 1) { out.push(null); continue; }
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += closes[j];
    out.push(sum / period);
  }
  return out;
}

function ema(closes: number[], period: number): (number | null)[] {
  const out: (number | null)[] = [];
  const k = 2 / (period + 1);
  let prev: number | null = null;
  for (let i = 0; i < closes.length; i++) {
    if (i < period - 1) { out.push(null); continue; }
    if (prev === null) {
      let sum = 0;
      for (let j = 0; j < period; j++) sum += closes[j];
      prev = sum / period;
      out.push(prev);
    } else {
      prev = closes[i] * k + prev * (1 - k);
      out.push(prev);
    }
  }
  return out;
}

// ---------- MA config ----------
interface MAConfig {
  id: string;
  label: string;
  period: number;
  type: "SMA" | "EMA";
  color: string;
}

const MA_CONFIGS: MAConfig[] = [
  { id: "ema12", label: "EMA 12", period: 12, type: "EMA", color: "#F0B90B" },
  { id: "sma20", label: "SMA 20", period: 20, type: "SMA", color: "#3DC6FF" },
  { id: "sma50", label: "SMA 50", period: 50, type: "SMA", color: "#FF6B9D" },
];

export function ChartPanel() {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volSeriesRef = useRef<ISeriesApi<"Histogram"> | null>(null);
  const maSeriesRef = useRef<Record<string, ISeriesApi<"Line">>>({});
  const priceLineRef = useRef<IPriceLine | null>(null);
  const [range, setRange] = useState<ChartRange>("1M");
  const [lastCrosshair, setLastCrosshair] = useState<{ o: number; h: number; l: number; c: number; v: number; t: number } | null>(null);
  const { resolvedTheme } = useTheme();
  const [maToggles, setMaToggles] = useState<Record<string, boolean>>({
    ema12: true,
    sma20: true,
    sma50: false,
  });

  const selected = useTradingStore((s) => s.selectedTicker);
  const symbols = useTradingStore((s) => s.symbols);
  const quotes = useTradingStore((s) => s.quotes);
  const getCandles = useTradingStore((s) => s.getCandles);

  const sym = useMemo(
    () => symbols.find((s) => s.ticker === selected) ?? symbols[0],
    [symbols, selected],
  );
  const q = quotes[sym.ticker];
  const candles = useMemo(() => getCandles(sym.ticker, range), [getCandles, sym.ticker, range]);

  // Compute MA data
  const maData = useMemo(() => {
    const closes = candles.map((c) => c.close);
    return MA_CONFIGS.map((ma) => {
      const values = ma.type === "SMA" ? sma(closes, ma.period) : ema(closes, ma.period);
      const data: LineData<Time>[] = [];
      candles.forEach((c, i) => {
        const v = values[i];
        if (v !== null) {
          data.push({ time: c.time as UTCTimestamp, value: v });
        }
      });
      return { config: ma, data };
    });
  }, [candles]);

  // Create chart once
  useEffect(() => {
    if (!containerRef.current) return;
    const grid = cssVar("--border");
    const chart = createChart(containerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: cssVar("--muted-foreground"),
        fontFamily: "var(--font-mono), ui-monospace, monospace",
        fontSize: 11,
        attributionLogo: false,
      },
      grid: {
        vertLines: { color: grid },
        horzLines: { color: grid },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: cssVar("--border-strong"),
          width: 1,
          style: 2,
          labelBackgroundColor: cssVar("--accent"),
        },
        horzLine: {
          color: cssVar("--border-strong"),
          width: 1,
          style: 2,
          labelBackgroundColor: cssVar("--accent"),
        },
      },
      rightPriceScale: {
        borderColor: cssVar("--border"),
        scaleMargins: { top: 0.08, bottom: 0.28 },
      },
      timeScale: {
        borderColor: cssVar("--border"),
        timeVisible: range === "1D",
        secondsVisible: false,
        rightOffset: 4,
      },
      handleScale: true,
      handleScroll: true,
    });
    chartRef.current = chart;

    const gain = cssVar("--gain");
    const loss = cssVar("--loss");
    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: gain,
      downColor: loss,
      borderUpColor: gain,
      borderDownColor: loss,
      wickUpColor: gain,
      wickDownColor: loss,
      priceFormat: {
        type: "price",
        precision: 2,
        minMove: 0.01,
      },
    });
    candleSeriesRef.current = candleSeries;

    const volSeries = chart.addSeries(HistogramSeries, {
      priceFormat: { type: "volume" },
      priceScaleId: "vol",
    });
    chart.priceScale("vol").applyOptions({
      scaleMargins: { top: 0.78, bottom: 0 },
    });
    volSeriesRef.current = volSeries;

    // Create MA line series
    MA_CONFIGS.forEach((ma) => {
      const series = chart.addSeries(LineSeries, {
        color: ma.color,
        lineWidth: 2,
        priceLineVisible: false,
        lastValueVisible: false,
        crosshairMarkerVisible: false,
      });
      maSeriesRef.current[ma.id] = series;
    });

    // Resize observer
    const ro = new ResizeObserver((entries) => {
      for (const e of entries) {
        const { width, height } = e.contentRect;
        chart.applyOptions({ width, height });
      }
    });
    ro.observe(containerRef.current);

    // Crosshair handler — populate the OHLCV readout
    chart.subscribeCrosshairMove((param) => {
      if (!param.time || !candleSeriesRef.current) {
        setLastCrosshair(null);
        return;
      }
      const data = param.seriesData.get(candleSeriesRef.current) as
        | CandlestickData
        | undefined;
      const vData = volSeriesRef.current
        ? (param.seriesData.get(volSeriesRef.current) as HistogramData | undefined)
        : undefined;
      if (!data) {
        setLastCrosshair(null);
        return;
      }
      setLastCrosshair({
        o: data.open,
        h: data.high,
        l: data.low,
        c: data.close,
        v: vData?.value ?? 0,
        t: (param.time as UTCTimestamp) * 1000,
      });
    });

    return () => {
      ro.disconnect();
      chart.remove();
      chartRef.current = null;
      candleSeriesRef.current = null;
      volSeriesRef.current = null;
      maSeriesRef.current = {};
      priceLineRef.current = null;
    };
  }, []);

  // Re-apply colors when theme changes (light ↔ dark)
  useEffect(() => {
    const chart = chartRef.current;
    const candle = candleSeriesRef.current;
    if (!chart || !candle) return;
    const gain = cssVar("--gain");
    const loss = cssVar("--loss");
    const grid = cssVar("--border");
    chart.applyOptions({
      layout: {
        textColor: cssVar("--muted-foreground"),
        background: { type: ColorType.Solid, color: "transparent" },
      },
      grid: {
        vertLines: { color: grid },
        horzLines: { color: grid },
      },
      crosshair: {
        vertLine: { color: cssVar("--border-strong"), labelBackgroundColor: cssVar("--accent") },
        horzLine: { color: cssVar("--border-strong"), labelBackgroundColor: cssVar("--accent") },
      },
      rightPriceScale: { borderColor: cssVar("--border") },
      timeScale: { borderColor: cssVar("--border") },
    });
    candle.applyOptions({
      upColor: gain, downColor: loss,
      borderUpColor: gain, borderDownColor: loss,
      wickUpColor: gain, wickDownColor: loss,
    });
    // Re-color volume bars with soft opacity
    if (volSeriesRef.current && candles.length) {
      const volData: HistogramData<Time>[] = candles.map((c) => ({
        time: c.time as UTCTimestamp,
        value: c.volume,
        color: c.close >= c.open ? `${gain}66` : `${loss}66`,
      }));
      volSeriesRef.current.setData(volData);
    }
  }, [resolvedTheme, candles]);

  // Update time scale visibility when range changes
  useEffect(() => {
    chartRef.current?.applyOptions({
      timeScale: { timeVisible: range === "1D" },
    });
  }, [range]);

  // Feed data when symbol or range changes
  useEffect(() => {
    if (!candleSeriesRef.current || !volSeriesRef.current) return;
    const gain = cssVar("--gain");
    const loss = cssVar("--loss");
    const candleData: CandlestickData<Time>[] = candles.map((c) => ({
      time: c.time as UTCTimestamp,
      open: c.open,
      high: c.high,
      low: c.low,
      close: c.close,
    }));
    // Volume with soft opacity (hex + 66 = ~40% alpha)
    const volData: HistogramData<Time>[] = candles.map((c) => ({
      time: c.time as UTCTimestamp,
      value: c.volume,
      color: c.close >= c.open ? `${gain}66` : `${loss}66`,
    }));
    candleSeriesRef.current.setData(candleData);
    volSeriesRef.current.setData(volData);

    // Feed MA data + toggle visibility
    maData.forEach(({ config, data }) => {
      const series = maSeriesRef.current[config.id];
      if (series) {
        series.setData(data);
        series.applyOptions({ visible: maToggles[config.id] ?? false });
      }
    });

    chartRef.current?.timeScale().fitContent();
  }, [candles, maData, maToggles]);

  // Toggle MA visibility without re-feeding data
  useEffect(() => {
    MA_CONFIGS.forEach((ma) => {
      const series = maSeriesRef.current[ma.id];
      if (series) {
        series.applyOptions({ visible: maToggles[ma.id] ?? false });
      }
    });
  }, [maToggles]);

  // Live price line + last candle update
  useEffect(() => {
    if (!q || !candleSeriesRef.current || candles.length === 0) return;
    const last = candles[candles.length - 1];
    candleSeriesRef.current.update({
      time: last.time as UTCTimestamp,
      open: last.open,
      high: Math.max(last.high, q.price),
      low: Math.min(last.low, q.price),
      close: q.price,
    });
    // Update or create the price line
    const isUp = q.price >= q.prevClose;
    const lineColor = isUp ? cssVar("--gain") : cssVar("--loss");
    if (priceLineRef.current) {
      candleSeriesRef.current.removePriceLine(priceLineRef.current);
    }
    priceLineRef.current = candleSeriesRef.current.createPriceLine({
      price: q.price,
      color: lineColor,
      lineWidth: 1,
      lineStyle: LineStyle.Dashed,
      axisLabelVisible: true,
      title: "",
    });
  }, [q?.price, q?.rev, candles]);

  if (!q) return null;
  const change = q.price - q.prevClose;
  const changePct = (change / q.prevClose) * 100;
  const readout = lastCrosshair ?? {
    o: candles[0]?.open ?? sym.open,
    h: sym.dayHigh,
    l: sym.dayLow,
    c: q.price,
    v: q.volume,
    t: Date.now(),
  };

  return (
    <section
      className="flex flex-col h-full overflow-hidden"
      style={{ background: "var(--surface)" }}
      aria-label={`Price chart for ${sym.ticker}`}
    >
      {/* Symbol header */}
      <header
        className="px-4 pt-3 pb-2 border-b"
        style={{ borderColor: "var(--border)" }}
      >
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-baseline gap-2">
                <h2 className="text-lg font-semibold text-[var(--foreground)] leading-tight">
                  {sym.ticker}
                </h2>
                <span className="text-xs text-[var(--muted-foreground)]">{sym.exchange}</span>
                <span
                  className="text-[9px] px-1.5 py-px rounded-[3px] uppercase tracking-wide"
                  style={{
                    background: "var(--accent-soft)",
                    color: "var(--accent)",
                  }}
                >
                  Live
                </span>
              </div>
              <p className="text-[11px] text-[var(--muted-foreground)]">{sym.name} · {sym.sector}</p>
            </div>
            <div className="flex items-baseline gap-2 ml-2">
              <PriceCell
                value={q.price}
                format={(n) => fmtPrice(n)}
                className="text-2xl font-semibold text-[var(--foreground)]"
              />
              <span
                className={cn("text-sm font-mono tabular-nums", deltaColor(change))}
              >
                {change > 0 ? "+" : change < 0 ? "−" : ""}
                {fmtPrice(Math.abs(change))} ({fmtPct(changePct)})
              </span>
            </div>
          </div>

          {/* Range + MA toggles */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* MA toggle pills */}
            <div className="flex items-center gap-1">
              {MA_CONFIGS.map((ma) => {
                const active = maToggles[ma.id];
                return (
                  <button
                    key={ma.id}
                    type="button"
                    onClick={() => setMaToggles((t) => ({ ...t, [ma.id]: !t[ma.id] }))}
                    className={cn(
                      "flex items-center gap-1.5 px-2 py-1 text-[10px] font-mono font-semibold rounded-[6px] border transition-all cursor-pointer focus-ring",
                      active ? "" : "opacity-40 hover:opacity-70",
                    )}
                    style={{
                      borderColor: active ? ma.color : "var(--border)",
                      background: active ? `${ma.color}1a` : "var(--surface)",
                      color: active ? ma.color : "var(--muted-foreground)",
                    }}
                    aria-pressed={active}
                    title={`${ma.type} ${ma.period}`}
                  >
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ background: ma.color, opacity: active ? 1 : 0.4 }}
                    />
                    {ma.label}
                  </button>
                );
              })}
            </div>
            {/* Range switch */}
            <div
              className="flex items-center rounded-[8px] border overflow-hidden"
              style={{ borderColor: "var(--border)" }}
              role="tablist"
              aria-label="Chart range"
            >
              {RANGES.map((r) => (
                <button
                  key={r}
                  type="button"
                  role="tab"
                  aria-selected={range === r}
                  onClick={() => setRange(r)}
                  className={cn(
                    "px-3 py-1 text-xs font-mono transition-colors focus-ring cursor-pointer",
                    range === r
                      ? ""
                      : "text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-elevated)]",
                  )}
                  style={range === r ? { background: "var(--accent-soft)", color: "var(--accent)" } : undefined}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* OHLCV readout row */}
        <div className="flex items-center gap-4 mt-2 text-[10px] font-mono text-[var(--muted-foreground)]">
          <Readout label="O" value={fmtPrice(readout.o)} />
          <Readout label="H" value={fmtPrice(readout.h)} color="var(--gain)" />
          <Readout label="L" value={fmtPrice(readout.l)} color="var(--loss)" />
          <Readout label="C" value={fmtPrice(readout.c)} />
          <Readout
            label="Vol"
            value={Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 2 }).format(readout.v)}
          />
          {lastCrosshair && (
            <span className="text-[var(--muted-foreground)] ml-2">
              {new Date(readout.t).toLocaleString("en-US", { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false })}
            </span>
          )}
          <span className="ml-auto text-[var(--muted-foreground)]">
            Mkt Cap <span className="text-[var(--foreground)]">{fmtUSD(sym.marketCap, { compact: true })}</span>
          </span>
        </div>
      </header>

      {/* Chart canvas + watermark */}
      <div className="relative flex-1 min-h-0">
        <div ref={containerRef} className="absolute inset-0" />
        {/* Watermark */}
        <div
          className="absolute inset-0 flex items-center justify-center pointer-events-none select-none"
          aria-hidden="true"
        >
          <span
            className="text-7xl font-bold tracking-tight opacity-[0.035]"
            style={{ color: "var(--foreground)" }}
          >
            {sym.ticker}
          </span>
        </div>
      </div>
    </section>
  );
}

function Readout({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color?: string;
}) {
  return (
    <span className="flex items-center gap-1">
      <span className="text-[var(--muted-foreground)]">{label}</span>
      <span style={{ color: color ?? "var(--foreground)" }}>{value}</span>
    </span>
  );
}
