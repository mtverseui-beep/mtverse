"use client";
// AccountSettings — trading preferences, default order size,
// confirmations, account details.
import { useState } from "react";
import { Check } from "lucide-react";
import { Field, Input } from "../../Field";
import { Button } from "../../Button";
import { ModernSelect } from "../../ModernSelect";
import { SettingsCard, Toggle, SettingRow } from "./_shared";
import { toast } from "sonner";

export function AccountSettings() {
  const [defaultOrderSize, setDefaultOrderSize] = useState("100");
  const [defaultOrderType, setDefaultOrderType] = useState("LIMIT");
  const [timeInForce, setTimeInForce] = useState("DAY");
  const [confirmMarket, setConfirmMarket] = useState(true);
  const [confirmLimit, setConfirmLimit] = useState(false);
  const [showHotkeys, setShowHotkeys] = useState(true);
  const [accountId] = useState("4F92A1");
  const [accountType, setAccountType] = useState("MARGIN");

  return (
    <div className="space-y-4">
      <SettingsCard title="Account details" description="Your account identifiers.">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="Account ID">
            <Input value={accountId} readOnly />
          </Field>
          <Field label="Account type">
            <ModernSelect value={accountType} onValueChange={setAccountType} options={[
              { value: "CASH", label: "Cash" },
              { value: "MARGIN", label: "Margin" },
              { value: "RETIREMENT", label: "Retirement (IRA)" },
            ]} />
          </Field>
        </div>
      </SettingsCard>

      <SettingsCard title="Trading defaults" description="Pre-fill values for new order tickets.">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Field label="Default order size">
            <Input type="number" value={defaultOrderSize} onChange={(e) => setDefaultOrderSize(e.target.value)} />
          </Field>
          <Field label="Default order type">
            <ModernSelect value={defaultOrderType} onValueChange={setDefaultOrderType} options={[
              { value: "MARKET", label: "Market" },
              { value: "LIMIT", label: "Limit" },
              { value: "STOP", label: "Stop" },
              { value: "STOP_LIMIT", label: "Stop Limit" },
            ]} />
          </Field>
          <Field label="Time in force">
            <ModernSelect value={timeInForce} onValueChange={setTimeInForce} options={[
              { value: "DAY", label: "Day" },
              { value: "GTC", label: "Good till cancelled" },
              { value: "IOC", label: "Immediate or cancel" },
            ]} />
          </Field>
        </div>
        <div className="flex items-center justify-end mt-5">
          <Button variant="primary" size="md" icon={Check} onClick={() => toast.success("Trading defaults saved")}>
            Save
          </Button>
        </div>
      </SettingsCard>

      <SettingsCard title="Order confirmations" description="Control which orders require a confirmation step.">
        <SettingRow>
          <Toggle checked={confirmMarket} onCheckedChange={setConfirmMarket} label="Confirm market orders" description="Show a confirmation dialog before submitting market orders." />
          <Toggle checked={confirmLimit} onCheckedChange={setConfirmLimit} label="Confirm limit orders" description="Show a confirmation dialog before submitting limit orders." />
          <Toggle checked={showHotkeys} onCheckedChange={setShowHotkeys} label="Show hotkey hints" description="Display keyboard shortcut badges in the watchlist." />
        </SettingRow>
      </SettingsCard>
    </div>
  );
}
