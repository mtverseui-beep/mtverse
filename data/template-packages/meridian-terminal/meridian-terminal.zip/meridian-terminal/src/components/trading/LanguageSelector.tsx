"use client";
// ============================================================
// LanguageSelector — compact globe icon with a dropdown of
// supported locales. Selection is held in local state.
// ============================================================
import { useState } from "react";
import { Globe, Check } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { motion } from "framer-motion";

const LANGS = [
  { code: "en", label: "English", flag: "🇺🇸" },
  { code: "ja", label: "日本語", flag: "🇯🇵" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "es", label: "Español", flag: "🇪🇸" },
  { code: "zh", label: "中文", flag: "🇨🇳" },
];

export function LanguageSelector() {
  const [current, setCurrent] = useState("en");
  const active = LANGS.find((l) => l.code === current) ?? LANGS[0];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={`Language: ${active.label}`}
          className="hidden lg:flex items-center gap-1.5 h-9 px-2 rounded-[10px] text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors focus-ring cursor-pointer text-xs font-medium"
        >
          <Globe size={15} />
          <span className="font-mono uppercase">{active.code}</span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-44 font-sans"
        style={{
          background: "var(--popover)",
          border: "1px solid var(--border)",
          color: "var(--foreground)",
          borderRadius: "12px",
          boxShadow: "var(--shadow-lg)",
        }}
      >
        {LANGS.map((l) => {
          const isActive = l.code === current;
          return (
            <DropdownMenuItem
              key={l.code}
              onClick={() => setCurrent(l.code)}
              className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 gap-2.5 px-2.5 py-2 text-sm"
            >
              <span className="text-base leading-none">{l.flag}</span>
              <span className="flex-1">{l.label}</span>
              {isActive && (
                <motion.span layoutId="lang-active">
                  <Check size={14} style={{ color: "var(--accent)" }} />
                </motion.span>
              )}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
