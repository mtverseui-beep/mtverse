"use client";
// ============================================================
// Avatar — real photo avatars with graceful fallback to initials.
// Uses i.pravatar.cc for realistic face photos. Falls back to a
// gradient circle with initials on image error.
// ============================================================
import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";

interface AvatarProps {
  seed: string; // used to pick a pravatar image (1-70)
  name: string; // for initials fallback + alt text
  size?: number;
  className?: string;
  ring?: boolean;
}

export function Avatar({ seed, name, size = 32, className, ring }: AvatarProps) {
  const [errored, setErrored] = useState(false);
  const [loaded, setLoaded] = useState(false);
  // Deterministic pravatar id from seed string
  const id = useMemo(() => {
    let h = 0;
    for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
    return (h % 70) + 1;
  }, [seed]);

  const initials = name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  // Reset on seed change
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setErrored(false);
    setLoaded(false);
  }, [seed]);

  return (
    <span
      className={cn("relative inline-flex items-center justify-center overflow-hidden shrink-0", className)}
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: "linear-gradient(135deg, var(--accent), var(--accent-hover))",
        boxShadow: ring ? "0 0 0 2px var(--background), 0 0 0 3px var(--accent)" : undefined,
      }}
    >
      {/* Initials fallback (also acts as loading placeholder) */}
      {!loaded && (
        <span
          className="absolute inset-0 flex items-center justify-center font-semibold text-white"
          style={{ fontSize: size * 0.36 }}
        >
          {initials}
        </span>
      )}
      {!errored && (
        <img
          src={`https://i.pravatar.cc/${size * 2}?img=${id}`}
          alt={name}
          width={size}
          height={size}
          loading="lazy"
          onLoad={() => setLoaded(true)}
          onError={() => setErrored(true)}
          className={cn(
            "absolute inset-0 w-full h-full object-cover transition-opacity duration-200",
            loaded ? "opacity-100" : "opacity-0",
          )}
        />
      )}
    </span>
  );
}
