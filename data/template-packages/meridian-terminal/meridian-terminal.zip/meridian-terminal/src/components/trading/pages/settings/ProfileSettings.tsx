"use client";
// ProfileSettings — edit personal info, avatar, bio, social links.
import { useState } from "react";
import { Camera, Check } from "lucide-react";
import { Avatar } from "../../Avatar";
import { Field, Input, Textarea } from "../../Field";
import { Button } from "../../Button";
import { SettingsCard } from "./_shared";
import { toast } from "sonner";

export function ProfileSettings() {
  const [name, setName] = useState("Aria Redmond");
  const [email, setEmail] = useState("aria.redmond@meridian.io");
  const [phone, setPhone] = useState("+1 (415) 555-0148");
  const [location, setLocation] = useState("San Francisco, CA");
  const [bio, setBio] = useState("Quant trader focused on momentum equities and cross-asset arbitrage. 12 years on the desk.");
  const [twitter, setTwitter] = useState("@aria_trades");
  const [linkedin, setLinkedin] = useState("in/aria-redmond");

  return (
    <div className="space-y-4">
      <SettingsCard title="Profile photo" description="Your photo appears on your profile and across the terminal.">
        <div className="flex items-center gap-4">
          <div className="relative">
            <Avatar seed="aria-redmond" name={name} size={72} />
            <button
              type="button"
              className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-white cursor-pointer focus-ring shadow-md"
              style={{ background: "var(--accent)" }}
              aria-label="Change photo"
              onClick={() => toast.info("Photo upload", { description: "File picker would open here." })}
            >
              <Camera size={13} />
            </button>
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-[var(--foreground)]">{name}</p>
            <p className="text-xs text-[var(--muted-foreground)] mt-0.5">JPG, PNG or GIF. Max 4MB.</p>
          </div>
          <Button variant="outline" size="md" icon={Camera} onClick={() => toast.info("Photo upload", { description: "File picker would open here." })}>
            Upload
          </Button>
        </div>
      </SettingsCard>

      <SettingsCard title="Personal information" description="Update your personal details. Changes save to local state.">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="Full name" required>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Email" required>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Phone">
            <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
          </Field>
          <Field label="Location">
            <Input value={location} onChange={(e) => setLocation(e.target.value)} />
          </Field>
          <Field label="Bio" className="md:col-span-2">
            <Textarea rows={3} value={bio} onChange={(e) => setBio(e.target.value)} />
          </Field>
        </div>
        <div className="flex items-center justify-end gap-2 mt-5">
          <Button variant="ghost" size="md">Cancel</Button>
          <Button variant="primary" size="md" icon={Check} onClick={() => toast.success("Profile updated")}>
            Save changes
          </Button>
        </div>
      </SettingsCard>

      <SettingsCard title="Social links" description="Connect your professional profiles.">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="Twitter / X">
            <Input value={twitter} onChange={(e) => setTwitter(e.target.value)} />
          </Field>
          <Field label="LinkedIn">
            <Input value={linkedin} onChange={(e) => setLinkedin(e.target.value)} />
          </Field>
        </div>
        <div className="flex items-center justify-end mt-5">
          <Button variant="primary" size="md" icon={Check} onClick={() => toast.success("Social links saved")}>
            Save
          </Button>
        </div>
      </SettingsCard>
    </div>
  );
}
