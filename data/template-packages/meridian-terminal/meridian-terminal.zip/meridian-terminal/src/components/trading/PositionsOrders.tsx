"use client";
// ============================================================
// PositionsOrders — right column. Tabbed Positions / Orders /
// History. Position rows expand inline to show entry price,
// P&L %, and Close position (with confirm step). Each row has
// a tiny Recharts sparkline.
// ============================================================
import { useState } from "react";
import {
  ChevronRight,
  X,
  TrendingUp,
  TrendingDown,
  Inbox,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useTradingStore } from "@/store/trading-store";
import {
  fmtPrice,
  fmtQty,
  fmtUSD,
  fmtPct,
  fmtCompact,
  fmtRelative,
  deltaColor,
} from "@/lib/trading/format";
import { Sparkline } from "./Sparkline";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Position } from "@/lib/trading/types";

type Tab = "positions" | "orders" | "history";

export function PositionsOrders() {
  const [tab, setTab] = useState<Tab>("positions");
  const positions = useTradingStore((s) => s.positions);
  const orders = useTradingStore((s) => s.orders);
  const trades = useTradingStore((s) => s.trades);

  return (
    <section
      className="flex flex-col h-full overflow-hidden"
      style={{ background: "var(--surface)" }}
      aria-label="Positions, orders and history"
    >
      {/* Tabs */}
      <div
        className="flex border-b"
        style={{ borderColor: "var(--border)" }}
        role="tablist"
      >
        <TabButton tab={tab} value="positions" onClick={setTab} label="Positions" badge={positions.length} />
        <TabButton tab={tab} value="orders" onClick={setTab} label="Orders" badge={orders.filter((o) => o.status === "WORKING").length} />
        <TabButton tab={tab} value="history" onClick={setTab} label="History" badge={trades.length} />
      </div>

      <div className="flex-1 overflow-y-auto">
        {tab === "positions" && <PositionsTab positions={positions} />}
        {tab === "orders" && <OrdersTab orders={orders} />}
        {tab === "history" && <HistoryTab trades={trades} />}
      </div>
    </section>
  );
}

function TabButton({
  tab,
  value,
  onClick,
  label,
  badge,
}: {
  tab: Tab;
  value: Tab;
  onClick: (t: Tab) => void;
  label: string;
  badge: number;
}) {
  const active = tab === value;
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={() => onClick(value)}
      className={cn(
        "relative flex-1 py-2 text-xs font-medium transition-colors focus-ring",
        active ? "text-[var(--foreground)]" : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]",
      )}
    >
      <span className="flex items-center justify-center gap-1.5">
        {label}
        <span
          className="text-[9px] font-mono px-1 py-px rounded-[3px]"
          style={{
            background: active ? "var(--accent-soft)" : "var(--background)",
            color: active ? "var(--accent)" : "var(--muted-foreground)",
          }}
        >
          {badge}
        </span>
      </span>
      {active && (
        <span
          className="absolute bottom-0 left-0 right-0 h-[2px]"
          style={{ background: "var(--accent)" }}
        />
      )}
    </button>
  );
}

// ============================================================
// Positions
// ============================================================
function PositionsTab({ positions }: { positions: Position[] }) {
  const [expanded, setExpanded] = useState<string | null>(null);

  if (positions.length === 0) {
    return <EmptyState icon={Inbox} label="No open positions" />;
  }

  // Aggregate footer
  const totalMV = positions.reduce((a, p) => a + p.marketValue, 0);
  const totalPnl = positions.reduce((a, p) => a + p.unrealizedPnl, 0);
  const totalDay = positions.reduce((a, p) => a + p.dayChange, 0);

  return (
    <div className="flex flex-col h-full">
      {/* Column header */}
      <div
        className="grid grid-cols-[1.4fr_0.7fr_1fr_1fr] gap-2 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted-foreground)] border-b sticky top-0 z-10"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        <span>Symbol</span>
        <span className="text-right">Qty</span>
        <span className="text-right">Last</span>
        <span className="text-right">P&L</span>
      </div>

      <div className="flex-1">
        {positions.map((p) => {
          const isOpen = expanded === p.ticker;
          const isLong = p.side === "LONG";
          const pnlPositive = p.unrealizedPnl > 0;
          return (
            <div key={p.ticker} className="border-b" style={{ borderColor: "var(--border)" }}>
              <button
                type="button"
                onClick={() => setExpanded(isOpen ? null : p.ticker)}
                aria-expanded={isOpen}
                className="w-full grid grid-cols-[1.4fr_0.7fr_1fr_1fr] gap-2 px-3 py-2 text-left hover:bg-[var(--surface-hover)] transition-colors focus-ring items-center"
              >
                <div className="min-w-0 flex items-center gap-1.5">
                  <ChevronRight
                    size={12}
                    className={cn(
                      "text-[var(--muted-foreground)] shrink-0 transition-transform",
                      isOpen && "rotate-90",
                    )}
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-semibold text-[var(--foreground)]">{p.ticker}</span>
                      <span
                        className={cn(
                          "text-[9px] px-1 py-px rounded-[2px] font-mono font-semibold",
                          isLong ? "text-[var(--gain)]" : "text-[var(--loss)]",
                        )}
                        style={{
                          background: isLong ? "var(--gain-soft)" : "var(--loss-soft)",
                        }}
                      >
                        {p.side}
                      </span>
                    </div>
                    <div className="text-[10px] text-[var(--muted-foreground)] truncate">{p.name}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono tabular-nums text-[var(--foreground)]">{fmtQty(p.qty)}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono tabular-nums text-[var(--foreground)]">{fmtPrice(p.last)}</div>
                  <div
                    className={cn("text-[10px] font-mono tabular-nums", deltaColor(p.dayChange))}
                  >
                    {fmtPct(p.dayChangePct)}
                  </div>
                </div>
                <div className="text-right">
                  <div
                    className={cn(
                      "text-xs font-mono tabular-nums font-semibold",
                      deltaColor(p.unrealizedPnl),
                    )}
                  >
                    {fmtUSD(p.unrealizedPnl, { sign: true })}
                  </div>
                  <div className={cn("text-[10px] font-mono tabular-nums", deltaColor(p.unrealizedPnl))}>
                    {fmtPct(p.unrealizedPnlPct)}
                  </div>
                </div>
              </button>

              {/* Expanded detail */}
              {isOpen && (
                <div className="px-3 pb-3 pt-1 grid grid-cols-2 gap-3" style={{ background: "var(--background)" }}>
                  <div className="col-span-2 h-8">
                    <Sparkline data={p.pnlSeries} positive={pnlPositive} height={32} />
                  </div>
                  <DetailRow label="Avg Entry" value={fmtPrice(p.avgEntry)} />
                  <DetailRow label="Last" value={fmtPrice(p.last)} />
                  <DetailRow label="Cost Basis" value={fmtUSD(p.costBasis)} />
                  <DetailRow label="Market Value" value={fmtUSD(p.marketValue)} />
                  <DetailRow
                    label="Unrealized P&L"
                    value={fmtUSD(p.unrealizedPnl, { sign: true })}
                    valueClass={deltaColor(p.unrealizedPnl)}
                  />
                  <DetailRow
                    label="P&L %"
                    value={fmtPct(p.unrealizedPnlPct)}
                    valueClass={deltaColor(p.unrealizedPnlPct)}
                  />
                  <DetailRow label="Day Change" value={fmtUSD(p.dayChange, { sign: true })} valueClass={deltaColor(p.dayChange)} />
                  <DetailRow label="Opened" value={fmtRelative(p.openedAt)} />

                  <div className="col-span-2 mt-1">
                    <PositionCloseButton position={p} />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Aggregate footer */}
      <div
        className="grid grid-cols-[1.4fr_0.7fr_1fr_1fr] gap-2 px-3 py-2 border-t text-[11px] font-mono tabular-nums sticky bottom-0"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        <span className="text-[var(--muted-foreground)] text-[10px] uppercase tracking-wider">Total · {positions.length}</span>
        <span className="text-right" />
        <span className="text-right text-[var(--foreground)]">{fmtUSD(totalMV, { compact: true })}</span>
        <span className={cn("text-right font-semibold", deltaColor(totalPnl))}>
          {fmtUSD(totalPnl, { sign: true })}
        </span>
      </div>
      <div
        className="px-3 py-1.5 border-t text-[10px] font-mono text-[var(--muted-foreground)] flex justify-between"
        style={{ background: "var(--background)", borderColor: "var(--border)" }}
      >
        <span>Day P&L</span>
        <span className={deltaColor(totalDay)}>{fmtUSD(totalDay, { sign: true })}</span>
      </div>
    </div>
  );
}

function DetailRow({
  label,
  value,
  valueClass,
}: {
  label: string;
  value: string;
  valueClass?: string;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[10px] text-[var(--muted-foreground)] uppercase tracking-wide">{label}</span>
      <span className={cn("text-xs font-mono tabular-nums text-[var(--foreground)]", valueClass)}>{value}</span>
    </div>
  );
}

function PositionCloseButton({ position }: { position: Position }) {
  const close = useTradingStore((s) => s.closePosition);
  const isLong = position.side === "LONG";

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <button
          type="button"
          className="w-full py-1.5 text-xs font-semibold rounded-[6px] border transition-colors focus-ring inline-flex items-center justify-center gap-1.5"
          style={{
            borderColor: "rgba(255,59,92,0.4)",
            color: "var(--loss)",
            background: "rgba(255,59,92,0.06)",
          }}
        >
          <X size={12} />
          Close {isLong ? "Long" : "Short"} · {fmtQty(position.qty)} {position.ticker}
        </button>
      </AlertDialogTrigger>
      <AlertDialogContent
        style={{
          background: "var(--surface-elevated)",
          border: "1px solid var(--border)",
          color: "var(--foreground)",
        }}
      >
        <AlertDialogHeader>
          <AlertDialogTitle className="text-base font-semibold">
            Close {position.ticker} position?
          </AlertDialogTitle>
          <AlertDialogDescription className="text-xs text-[var(--muted-foreground)]">
            This will submit a {isLong ? "SELL" : "BUY"} market order for{" "}
            <span className="font-mono text-[var(--foreground)]">{fmtQty(position.qty)}</span> shares of{" "}
            <span className="font-mono text-[var(--foreground)]">{position.ticker}</span> at the current{" "}
            {isLong ? "bid" : "ask"} of{" "}
            <span className="font-mono text-[var(--foreground)]">{fmtPrice(position.last)}</span>.
            {position.unrealizedPnl >= 0 ? " Realized gain: " : " Realized loss: "}
            <span className={cn("font-mono", deltaColor(position.unrealizedPnl))}>
              {fmtUSD(position.unrealizedPnl, { sign: true })}
            </span>
            . This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel
            className="text-xs h-8"
            style={{ background: "var(--background)", border: "1px solid var(--border)", color: "var(--foreground)" }}
          >
            Cancel
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={() => {
              close(position.ticker);
              toast.success(`${position.ticker} position closed`, {
                description: `${isLong ? "Sold" : "Bought"} ${fmtQty(position.qty)} @ ~${fmtPrice(position.last)}`,
              });
            }}
            className="text-xs h-8"
            style={{ background: "var(--loss)", color: "#fff" }}
          >
            Confirm Close
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

// ============================================================
// Orders
// ============================================================
function OrdersTab({ orders }: { orders: ReturnType<typeof useTradingStore.getState>["orders"] }) {
  const cancel = useTradingStore((s) => s.cancelOrder);
  if (orders.length === 0) return <EmptyState icon={Inbox} label="No orders" />;
  return (
    <div>
      <div
        className="grid grid-cols-[0.9fr_0.6fr_0.8fr_1fr_1.1fr_0.6fr] gap-2 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted-foreground)] border-b"
        style={{ borderColor: "var(--border)" }}
      >
        <span>Symbol</span>
        <span className="text-right">Side</span>
        <span className="text-right">Type</span>
        <span className="text-right">Qty</span>
        <span className="text-right">Limit</span>
        <span className="text-right">Status</span>
      </div>
      {orders.map((o) => {
        const isWorking = o.status === "WORKING" || o.status === "PARTIAL";
        return (
          <div
            key={o.id}
            className="grid grid-cols-[0.9fr_0.6fr_0.8fr_1fr_1.1fr_0.6fr] gap-2 px-3 py-2 border-b items-center text-xs font-mono tabular-nums"
            style={{ borderColor: "var(--border)" }}
          >
            <div>
              <div className="text-[var(--foreground)] font-semibold">{o.ticker}</div>
              <div className="text-[9px] text-[var(--muted-foreground)]">{o.id}</div>
            </div>
            <div
              className={cn(
                "text-right font-semibold",
                o.side === "BUY" ? "text-[var(--gain)]" : "text-[var(--loss)]",
              )}
            >
              {o.side}
            </div>
            <div className="text-right text-[var(--muted-foreground)]">{o.type.replace("_", " ")}</div>
            <div className="text-right text-[var(--foreground)]">
              {o.filledQty > 0 ? (
                <>
                  {fmtQty(o.filledQty)}/<span className="text-[var(--muted-foreground)]">{fmtQty(o.qty)}</span>
                </>
              ) : (
                fmtQty(o.qty)
              )}
            </div>
            <div className="text-right text-[var(--foreground)]">
              {o.limitPrice
                ? fmtPrice(o.limitPrice)
                : o.stopPrice
                  ? `STOP ${fmtPrice(o.stopPrice)}`
                  : "MKT"}
            </div>
            <div className="text-right">
              <span
                className={cn(
                  "text-[10px] px-1.5 py-0.5 rounded-[3px] uppercase tracking-wide font-semibold",
                )}
                style={{
                  background:
                    o.status === "FILLED"
                      ? "var(--gain-soft)"
                      : o.status === "WORKING" || o.status === "PARTIAL"
                        ? "var(--accent-soft)"
                        : o.status === "CANCELLED"
                          ? "rgba(139,147,167,0.12)"
                          : "var(--loss-soft)",
                  color:
                    o.status === "FILLED"
                      ? "var(--gain)"
                      : o.status === "WORKING" || o.status === "PARTIAL"
                        ? "var(--accent)"
                        : o.status === "CANCELLED"
                          ? "var(--muted-foreground)"
                          : "var(--loss)",
                }}
              >
                {o.status}
              </span>
              {isWorking && (
                <button
                  type="button"
                  onClick={() => {
                    cancel(o.id);
                    toast.success(`Order ${o.id} cancelled`);
                  }}
                  className="ml-1 text-[var(--muted-foreground)] hover:text-[var(--loss)] focus-ring rounded-[3px] px-1"
                  aria-label={`Cancel order ${o.id}`}
                >
                  <X size={11} />
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ============================================================
// History (recent trades)
// ============================================================
function HistoryTab({ trades }: { trades: ReturnType<typeof useTradingStore.getState>["trades"] }) {
  if (trades.length === 0) return <EmptyState icon={Inbox} label="No recent trades" />;
  return (
    <div>
      <div
        className="grid grid-cols-[0.9fr_0.5fr_0.7fr_0.8fr_1fr] gap-2 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted-foreground)] border-b"
        style={{ borderColor: "var(--border)" }}
      >
        <span>Symbol</span>
        <span className="text-right">Side</span>
        <span className="text-right">Qty</span>
        <span className="text-right">Price</span>
        <span className="text-right">Time</span>
      </div>
      {trades.map((t) => (
        <div
          key={t.id}
          className="grid grid-cols-[0.9fr_0.5fr_0.7fr_0.8fr_1fr] gap-2 px-3 py-1.5 border-b items-center text-xs font-mono tabular-nums"
          style={{ borderColor: "var(--border)" }}
        >
          <span className="text-[var(--foreground)] font-semibold">{t.ticker}</span>
          <span
            className={cn(
              "text-right font-semibold",
              t.side === "BUY" ? "text-[var(--gain)]" : "text-[var(--loss)]",
            )}
          >
            {t.side}
          </span>
          <span className="text-right text-[var(--foreground)]">{fmtQty(t.qty)}</span>
          <span className="text-right text-[var(--foreground)]">{fmtPrice(t.price)}</span>
          <span className="text-right text-[var(--muted-foreground)] text-[10px]">{fmtRelative(t.timestamp)}</span>
        </div>
      ))}
    </div>
  );
}

function EmptyState({ icon: Icon, label }: { icon: React.ComponentType<{ size?: number }>; label: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-[var(--muted-foreground)]">
      <Icon size={28} />
      <p className="mt-2 text-xs">{label}</p>
    </div>
  );
}
