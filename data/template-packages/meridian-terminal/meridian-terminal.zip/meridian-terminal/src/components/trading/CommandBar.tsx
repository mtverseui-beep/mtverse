"use client";
// ============================================================
// CommandBar — ⌘K dialog for jumping to any symbol. Uses shadcn
// Command (cmdk under the hood).
// ============================================================
import { useEffect } from "react";
import { Search } from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { useTradingStore } from "@/store/trading-store";
import { fmtPrice, fmtPct, deltaColor } from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface CommandBarProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function CommandBar({ open, onOpenChange }: CommandBarProps) {
  const symbols = useTradingStore((s) => s.symbols);
  const quotes = useTradingStore((s) => s.quotes);
  const select = useTradingStore((s) => s.select);
  const setQuickOrder = useTradingStore((s) => s.setQuickOrder);

  // Global ⌘K / Ctrl+K listener
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        onOpenChange(!open);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);

  const handleSelect = (ticker: string, action: "view" | "buy" | "sell") => {
    select(ticker);
    if (action === "buy") {
      const q = quotes[ticker];
      setQuickOrder({ ticker, side: "BUY", price: q?.ask ?? 0, qty: 100 });
      toast.success(`Quick-buy form prefilled for ${ticker}`);
    } else if (action === "sell") {
      const q = quotes[ticker];
      setQuickOrder({ ticker, side: "SELL", price: q?.bid ?? 0, qty: 100 });
      toast.success(`Quick-sell form prefilled for ${ticker}`);
    }
    onOpenChange(false);
  };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="Search symbols or type an action (e.g. buy ZNRA)…" />
      <CommandList
        style={{
          background: "var(--surface-elevated)",
          color: "var(--foreground)",
        }}
      >
        <CommandEmpty className="text-xs text-[var(--muted-foreground)]">
          <div className="flex items-center gap-2 justify-center py-6">
            <Search size={14} />
            <span>No matches found</span>
          </div>
        </CommandEmpty>
        <CommandGroup
          heading="Symbols"
          className="text-[10px] uppercase tracking-wider text-[var(--muted-foreground)]"
        >
          {symbols.map((sym) => {
            const q = quotes[sym.ticker];
            if (!q) return null;
            const change = q.price - q.prevClose;
            const changePct = (change / q.prevClose) * 100;
            return (
              <CommandItem
                key={sym.ticker}
                value={`${sym.ticker} ${sym.name} view`}
                onSelect={() => handleSelect(sym.ticker, "view")}
                className="aria-selected:bg-[var(--surface-hover)] aria-selected:text-[var(--foreground)] hover:bg-[var(--surface-hover)] hover:text-[var(--foreground)] text-[var(--foreground)] gap-3"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-xs w-12">{sym.ticker}</span>
                    <span className="text-[11px] text-[var(--muted-foreground)] truncate max-w-[200px]">
                      {sym.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 font-mono tabular-nums text-[11px]">
                    <span className="text-[var(--foreground)]">{fmtPrice(q.price)}</span>
                    <span className={cn("w-16 text-right", deltaColor(change))}>
                      {fmtPct(changePct)}
                    </span>
                  </div>
                </div>
              </CommandItem>
            );
          })}
        </CommandGroup>
        <CommandSeparator style={{ background: "var(--border)" }} />
        <CommandGroup
          heading="Quick Actions"
          className="text-[10px] uppercase tracking-wider text-[var(--muted-foreground)]"
        >
          {symbols.slice(0, 6).map((sym) => (
            <CommandItem
              key={`buy-${sym.ticker}`}
              value={`buy ${sym.ticker} ${sym.name}`}
              onSelect={() => handleSelect(sym.ticker, "buy")}
              className="aria-selected:bg-[var(--surface-hover)] aria-selected:text-[var(--foreground)] hover:bg-[var(--surface-hover)] text-[var(--foreground)] gap-3"
            >
              <span
                className="text-[9px] px-1 py-px rounded-[3px] font-mono font-semibold"
                style={{ background: "var(--gain-soft)", color: "var(--gain)" }}
              >
                BUY
              </span>
              <span className="text-xs">
                Quick buy <span className="font-semibold">{sym.ticker}</span> · 100 @ ask
              </span>
            </CommandItem>
          ))}
          {symbols.slice(0, 4).map((sym) => (
            <CommandItem
              key={`sell-${sym.ticker}`}
              value={`sell ${sym.ticker} ${sym.name}`}
              onSelect={() => handleSelect(sym.ticker, "sell")}
              className="aria-selected:bg-[var(--surface-hover)] aria-selected:text-[var(--foreground)] hover:bg-[var(--surface-hover)] text-[var(--foreground)] gap-3"
            >
              <span
                className="text-[9px] px-1 py-px rounded-[3px] font-mono font-semibold"
                style={{ background: "var(--loss-soft)", color: "var(--loss)" }}
              >
                SELL
              </span>
              <span className="text-xs">
                Quick sell <span className="font-semibold">{sym.ticker}</span> · 100 @ bid
              </span>
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
