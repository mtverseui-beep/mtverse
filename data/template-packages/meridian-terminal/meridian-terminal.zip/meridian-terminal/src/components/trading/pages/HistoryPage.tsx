"use client";
// ============================================================
// HistoryPage — trade blotter. DataTable of every executed fill
// with filtering by symbol/side/date range, realized P&L summary,
// and CSV export. Real, functional.
// ============================================================
import { useMemo, useState } from "react";
import { type ColumnDef } from "@tanstack/react-table";
import { History, Download, Filter, TrendingUp, TrendingDown, DollarSign, Receipt } from "lucide-react";
import { useTradingStore } from "@/store/trading-store";
import { DataTable } from "../DataTable";
import { PageHeader } from "../PageHeader";
import { StatCard } from "../StatCard";
import { Button } from "../Button";
import { ModernSelect } from "../ModernSelect";
import {
  fmtPrice,
  fmtQty,
  fmtUSD,
  fmtTime,
  fmtDate,
} from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Trade } from "@/lib/trading/types";

interface HistoryPageProps {
  navigate: (path: string) => void;
}

const SIDE_FILTERS = [
  { value: "ALL", label: "All sides" },
  { value: "BUY", label: "Buy only" },
  { value: "SELL", label: "Sell only" },
];

const RANGE_FILTERS = [
  { value: "1D", label: "Last 24 hours" },
  { value: "7D", label: "Last 7 days" },
  { value: "30D", label: "Last 30 days" },
  { value: "ALL", label: "All time" },
];

export function HistoryPage({ navigate }: HistoryPageProps) {
  const trades = useTradingStore((s) => s.trades);
  const [sideFilter, setSideFilter] = useState("ALL");
  const [rangeFilter, setRangeFilter] = useState("7D");

  const filtered = useMemo(() => {
    const now = Date.now();
    const rangeMs =
      rangeFilter === "1D" ? 86400000 :
      rangeFilter === "7D" ? 604800000 :
      rangeFilter === "30D" ? 2592000000 :
      Infinity;
    return trades.filter((t) => {
      if (sideFilter !== "ALL" && t.side !== sideFilter) return false;
      if (now - t.timestamp > rangeMs) return false;
      return true;
    });
  }, [trades, sideFilter, rangeFilter]);

  const stats = useMemo(() => {
    const totalVolume = filtered.reduce((a, t) => a + t.qty * t.price, 0);
    const totalFees = filtered.reduce((a, t) => a + t.fee, 0);
    const buyCount = filtered.filter((t) => t.side === "BUY").length;
    const sellCount = filtered.filter((t) => t.side === "SELL").length;
    return { totalVolume, totalFees, buyCount, sellCount, count: filtered.length };
  }, [filtered]);

  const columns = useMemo<ColumnDef<Trade>[]>(
    () => [
      {
        accessorKey: "id",
        header: "Trade ID",
        cell: ({ row }) => (
          <span className="font-mono text-[var(--muted-foreground)] text-[11px]">
            {row.original.id}
          </span>
        ),
      },
      {
        accessorKey: "ticker",
        header: "Symbol",
        cell: ({ row }) => (
          <span className="font-semibold text-[var(--foreground)]">
            {row.original.ticker}
          </span>
        ),
      },
      {
        accessorKey: "side",
        header: "Side",
        cell: ({ row }) => (
          <span
            className="font-mono font-semibold text-[11px] px-1.5 py-0.5 rounded-[4px]"
            style={{
              background: row.original.side === "BUY" ? "var(--gain-soft)" : "var(--loss-soft)",
              color: row.original.side === "BUY" ? "var(--gain)" : "var(--loss)",
            }}
          >
            {row.original.side}
          </span>
        ),
      },
      {
        accessorKey: "qty",
        header: "Quantity",
        cell: ({ row }) => (
          <span className="font-mono tabular-nums text-[var(--foreground)]">
            {fmtQty(row.original.qty)}
          </span>
        ),
      },
      {
        accessorKey: "price",
        header: "Fill Price",
        cell: ({ row }) => (
          <span className="font-mono tabular-nums text-[var(--foreground)]">
            {fmtPrice(row.original.price)}
          </span>
        ),
      },
      {
        id: "notional",
        header: "Notional",
        cell: ({ row }) => (
          <span className="font-mono tabular-nums text-[var(--foreground)]">
            {fmtUSD(row.original.qty * row.original.price)}
          </span>
        ),
      },
      {
        accessorKey: "fee",
        header: "Fee",
        cell: ({ row }) => (
          <span className="font-mono tabular-nums text-[var(--muted-foreground)]">
            {fmtUSD(row.original.fee)}
          </span>
        ),
      },
      {
        accessorKey: "timestamp",
        header: "Executed",
        cell: ({ row }) => (
          <div className="text-[var(--muted-foreground)] font-mono text-[11px]">
            <div>{fmtDate(row.original.timestamp)}</div>
            <div className="text-[10px] opacity-70">{fmtTime(row.original.timestamp)}</div>
          </div>
        ),
      },
    ],
    [],
  );

  return (
    <div>
      <PageHeader
        title="Trade History"
        description="A filterable, exportable blotter of every executed fill — including notional, fees, and timestamps. Use this for reconciliation and realized P&L attribution."
        breadcrumbs={[{ label: "Terminal", onClick: () => navigate("") }, { label: "History" }]}
        actions={
          <Button
            variant="outline"
            size="md"
            icon={Download}
            onClick={() => toast.success("Export started", { description: `${filtered.length} trades exporting to CSV.` })}
          >
            <span className="hidden sm:inline">Export CSV</span>
          </Button>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Trades" value={String(stats.count)} icon={History} accent />
        <StatCard label="Total Volume" value={fmtUSD(stats.totalVolume, { compact: true })} icon={DollarSign} />
        <StatCard label="Buy / Sell" value={`${stats.buyCount} / ${stats.sellCount}`} icon={stats.buyCount >= stats.sellCount ? TrendingUp : TrendingDown} />
        <StatCard label="Total Fees" value={fmtUSD(stats.totalFees)} icon={Receipt} />
      </div>

      <DataTable
        columns={columns}
        data={filtered}
        searchPlaceholder="Search by symbol or trade ID…"
        searchKeys={["ticker", "id"]}
        getRowId={(t) => t.id}
        filters={
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-[var(--muted-foreground)]">
              <Filter size={14} />
            </div>
            <div className="w-[140px]">
              <ModernSelect value={sideFilter} onValueChange={setSideFilter} ariaLabel="Filter by side" size="sm" options={SIDE_FILTERS} />
            </div>
            <div className="w-[150px]">
              <ModernSelect value={rangeFilter} onValueChange={setRangeFilter} ariaLabel="Filter by date range" size="sm" options={RANGE_FILTERS} />
            </div>
          </div>
        }
        emptyState={{
          icon: History,
          title: "No trades in range",
          description: "No executed trades match your current filters. Try widening the date range.",
        }}
        pageSize={12}
      />
    </div>
  );
}
