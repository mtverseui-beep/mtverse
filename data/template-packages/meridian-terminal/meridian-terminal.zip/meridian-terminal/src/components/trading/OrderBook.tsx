"use client";
// ============================================================
// OrderBook — depth ladder. Hoverable rows; clicking a row
// populates the quick-order form (bid → buy limit, ask → sell limit).
// ============================================================
import { useMemo, useState } from "react";
import { useTradingStore } from "@/store/trading-store";
import { fmtPrice, fmtQty, fmtCompact } from "@/lib/trading/format";
import { cn } from "@/lib/utils";

export function OrderBook() {
  const selected = useTradingStore((s) => s.selectedTicker);
  const getOrderBook = useTradingStore((s) => s.getOrderBook);
  const quotes = useTradingStore((s) => s.quotes);
  const setQuickOrder = useTradingStore((s) => s.setQuickOrder);
  const [hovered, setHovered] = useState<{ side: "bid" | "ask"; idx: number } | null>(null);

  const book = useMemo(() => getOrderBook(selected), [getOrderBook, selected]);
  const q = quotes[selected];
  if (!book || !q) return null;

  // Max total across both sides for depth bar scaling
  const maxTotal = Math.max(
    book.bids[book.bids.length - 1]?.total ?? 1,
    book.asks[book.asks.length - 1]?.total ?? 1,
  );
  // Show top 9 levels of each side, stacked: asks (reversed, descending) → spread → bids
  const askRows = book.asks.slice(0, 9).reverse();
  const bidRows = book.bids.slice(0, 9);
  const spreadPct = (book.spread / book.midpoint) * 10000; // bps

  const onAskClick = (level: (typeof book.asks)[number]) => {
    setQuickOrder({ ticker: selected, side: "SELL", price: level.price, qty: 100 });
  };
  const onBidClick = (level: (typeof book.bids)[number]) => {
    setQuickOrder({ ticker: selected, side: "BUY", price: level.price, qty: 100 });
  };

  return (
    <section
      className="flex flex-col h-full overflow-hidden"
      style={{ background: "var(--surface)" }}
      aria-label={`Order book for ${selected}`}
    >
      <header
        className="px-3 py-2 border-b flex items-center justify-between"
        style={{ borderColor: "var(--border)" }}
      >
        <h3 className="text-xs font-semibold tracking-wider uppercase text-[var(--muted-foreground)]">
          Order Book · <span className="text-[var(--foreground)]">{selected}</span>
        </h3>
        <div className="flex items-center gap-1.5 text-[10px] font-mono text-[var(--muted-foreground)]">
          <span className="w-1.5 h-1.5 rounded-full live-pulse" style={{ background: "var(--gain)" }} />
          LIVE
        </div>
      </header>

      {/* Column header */}
      <div
        className="grid grid-cols-3 px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted-foreground)] border-b"
        style={{ borderColor: "var(--border)" }}
      >
        <span>Price</span>
        <span className="text-right">Size</span>
        <span className="text-right">Total</span>
      </div>

      {/* Asks (desc, so highest at top) */}
      <div className="flex-1 overflow-hidden flex flex-col justify-end min-h-0">
        {askRows.map((lvl, i) => {
          const realIdx = book.asks.length - 1 - i; // top of book is last in reversed slice
          const isHover = hovered?.side === "ask" && hovered.idx === realIdx;
          const depthPct = (lvl.total / maxTotal) * 100;
          return (
            <button
              key={`ask-${realIdx}`}
              type="button"
              onMouseEnter={() => setHovered({ side: "ask", idx: realIdx })}
              onMouseLeave={() => setHovered(null)}
              onClick={() => onAskClick(lvl)}
              className="relative grid grid-cols-3 px-3 py-[3px] text-xs font-mono tabular-nums w-full hover:bg-[var(--surface-hover)] transition-colors focus-ring text-left"
              aria-label={`Sell ${lvl.size} at ${lvl.price}`}
            >
              <div
                className="absolute inset-y-0 right-0 pointer-events-none"
                style={{
                  width: `${depthPct}%`,
                  background: "var(--loss-soft)",
                }}
              />
              {isHover && (
                <div
                  className="absolute inset-y-0 right-0 pointer-events-none"
                  style={{ width: `${depthPct}%`, background: "var(--loss-soft)" }}
                />
              )}
              <span className="relative text-[var(--loss)]">{fmtPrice(lvl.price)}</span>
              <span className="relative text-right text-[var(--foreground)]">{fmtQty(lvl.size)}</span>
              <span className="relative text-right text-[var(--muted-foreground)]">{fmtQty(lvl.total)}</span>
            </button>
          );
        })}
      </div>

      {/* Spread / last */}
      <div
        className="grid grid-cols-3 px-3 py-1.5 border-y text-xs font-mono tabular-nums"
        style={{
          borderColor: "var(--border)",
          background: "var(--background)",
        }}
      >
        <span className="text-[var(--muted-foreground)]">
          Spread <span className="text-[var(--foreground)]">{fmtPrice(book.spread)}</span>
        </span>
        <span className="text-center text-[var(--foreground)] font-semibold">{fmtPrice(book.lastPrice)}</span>
        <span className="text-right text-[var(--muted-foreground)]">
          {spreadPct.toFixed(1)} bps
        </span>
      </div>

      {/* Bids */}
      <div className="flex-1 overflow-hidden flex flex-col min-h-0">
        {bidRows.map((lvl, i) => {
          const isHover = hovered?.side === "bid" && hovered.idx === i;
          const depthPct = (lvl.total / maxTotal) * 100;
          return (
            <button
              key={`bid-${i}`}
              type="button"
              onMouseEnter={() => setHovered({ side: "bid", idx: i })}
              onMouseLeave={() => setHovered(null)}
              onClick={() => onBidClick(lvl)}
              className="relative grid grid-cols-3 px-3 py-[3px] text-xs font-mono tabular-nums w-full hover:bg-[var(--surface-hover)] transition-colors focus-ring text-left"
              aria-label={`Buy ${lvl.size} at ${lvl.price}`}
            >
              <div
                className="absolute inset-y-0 right-0 pointer-events-none"
                style={{ width: `${depthPct}%`, background: "var(--gain-soft)" }}
              />
              {isHover && (
                <div
                  className="absolute inset-y-0 right-0 pointer-events-none"
                  style={{ width: `${depthPct}%`, background: "var(--gain-soft)" }}
                />
              )}
              <span className="relative text-[var(--gain)]">{fmtPrice(lvl.price)}</span>
              <span className="relative text-right text-[var(--foreground)]">{fmtQty(lvl.size)}</span>
              <span className="relative text-right text-[var(--muted-foreground)]">{fmtQty(lvl.total)}</span>
            </button>
          );
        })}
      </div>

      {/* Footer stats */}
      <footer
        className="px-3 py-1.5 border-t text-[10px] font-mono text-[var(--muted-foreground)] grid grid-cols-2"
        style={{ borderColor: "var(--border)" }}
      >
        <span>
          Bid Vol <span className="text-[var(--gain)]">{fmtCompact(book.bids.reduce((a, l) => a + l.size, 0))}</span>
        </span>
        <span className="text-right">
          Ask Vol <span className="text-[var(--loss)]">{fmtCompact(book.asks.reduce((a, l) => a + l.size, 0))}</span>
        </span>
      </footer>
    </section>
  );
}
