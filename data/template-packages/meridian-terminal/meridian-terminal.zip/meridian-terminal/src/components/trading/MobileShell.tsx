"use client";
// ============================================================
// MobileShell — single-column layout for narrow viewports with
// a bottom tab bar (Watchlist / Chart / Positions).
// ============================================================
import { useState } from "react";
import { LayoutList, CandlestickChart, Wallet } from "lucide-react";
import { useTradingStore } from "@/store/trading-store";
import { Watchlist } from "./Watchlist";
import { ChartPanel } from "./ChartPanel";
import { OrderBook } from "./OrderBook";
import { QuickOrderForm } from "./QuickOrderForm";
import { PositionsOrders } from "./PositionsOrders";
import { cn } from "@/lib/utils";

type MobileTab = "watchlist" | "chart" | "positions";

const TABS: { id: MobileTab; label: string; icon: React.ComponentType<{ size?: number }> }[] = [
  { id: "watchlist", label: "Watchlist", icon: LayoutList },
  { id: "chart", label: "Chart", icon: CandlestickChart },
  { id: "positions", label: "Positions", icon: Wallet },
];

export function MobileShell() {
  const [tab, setTab] = useState<MobileTab>("chart");
  const selected = useTradingStore((s) => s.selectedTicker);

  return (
    <div className="flex flex-col h-full lg:hidden">
      <main className="flex-1 overflow-hidden min-h-0">
        {tab === "watchlist" && <Watchlist />}
        {tab === "chart" && (
          <div className="h-full grid grid-rows-[1fr_auto] gap-px" style={{ background: "var(--border)" }}>
            <div className="overflow-hidden">
              <ChartPanel />
            </div>
            <div className="h-48 grid grid-cols-2 gap-px" style={{ background: "var(--border)" }}>
              <OrderBook />
              <QuickOrderForm />
            </div>
          </div>
        )}
        {tab === "positions" && <PositionsOrders />}
      </main>

      {/* Bottom tab bar */}
      <nav
        className="grid grid-cols-3 border-t h-14 shrink-0"
        style={{
          background: "var(--background)",
          borderColor: "var(--border)",
          paddingBottom: "env(safe-area-inset-bottom, 0)",
        }}
        aria-label="Primary mobile navigation"
      >
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 text-[10px] transition-colors focus-ring",
                active ? "text-[var(--accent)]" : "text-[var(--muted-foreground)]",
              )}
            >
              <Icon size={18} />
              <span className="font-medium">{t.label}</span>
              {t.id === "chart" && (
                <span className="text-[9px] font-mono text-[var(--muted-foreground)] -mt-0.5">{selected}</span>
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
