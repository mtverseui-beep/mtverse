"use client";
// ============================================================
// SettingsPage — hub with a left sub-nav and routed sub-pages.
// Sections: Profile / Account / Appearance / Notifications /
// Billing / Team / API / Security / Shortcuts.
// ============================================================
import { motion } from "framer-motion";
import {
  User,
  Settings as SettingsIcon,
  Palette,
  Bell,
  CreditCard,
  Users,
  Key,
  Shield,
  Keyboard,
} from "lucide-react";
import { PageHeader } from "../PageHeader";
import { ProfileSettings } from "./settings/ProfileSettings";
import { AccountSettings } from "./settings/AccountSettings";
import { AppearanceSettings } from "./settings/AppearanceSettings";
import { NotificationSettings } from "./settings/NotificationSettings";
import { BillingSettings } from "./settings/BillingSettings";
import { TeamSettings } from "./settings/TeamSettings";
import { ApiSettings } from "./settings/ApiSettings";
import { SecuritySettings } from "./settings/SecuritySettings";
import { ShortcutsSettings } from "./settings/ShortcutsSettings";
import { cn } from "@/lib/utils";
import type { Route } from "@/hooks/use-hash-route";

interface SettingsPageProps {
  route: Route;
  navigate: (path: string) => void;
}

const SECTIONS = [
  { id: "profile", label: "Profile", icon: User, description: "Your personal information" },
  { id: "account", label: "Account", icon: SettingsIcon, description: "Account preferences" },
  { id: "appearance", label: "Appearance", icon: Palette, description: "Theme & display" },
  { id: "notifications", label: "Notifications", icon: Bell, description: "Alerts & emails" },
  { id: "billing", label: "Billing", icon: CreditCard, description: "Plan & invoices" },
  { id: "team", label: "Team", icon: Users, description: "Members & roles" },
  { id: "api", label: "API", icon: Key, description: "Keys & webhooks" },
  { id: "security", label: "Security", icon: Shield, description: "2FA & sessions" },
  { id: "shortcuts", label: "Shortcuts", icon: Keyboard, description: "Keyboard shortcuts" },
] as const;

export function SettingsPage({ route, navigate }: SettingsPageProps) {
  const active = route.segments[1] ?? "profile";

  const renderSection = () => {
    switch (active) {
      case "profile": return <ProfileSettings />;
      case "account": return <AccountSettings />;
      case "appearance": return <AppearanceSettings />;
      case "notifications": return <NotificationSettings />;
      case "billing": return <BillingSettings />;
      case "team": return <TeamSettings />;
      case "api": return <ApiSettings />;
      case "security": return <SecuritySettings />;
      case "shortcuts": return <ShortcutsSettings />;
      default: return <ProfileSettings />;
    }
  };

  return (
    <div>
      <PageHeader
        title="Settings"
        description="Manage your account, preferences, billing, team, and security. Every toggle and control here functions in local state."
        breadcrumbs={[
          { label: "Terminal", onClick: () => navigate("") },
          { label: "Settings", onClick: () => navigate("settings") },
          { label: SECTIONS.find((s) => s.id === active)?.label ?? "" },
        ]}
      />
      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-6">
        {/* Sub-nav */}
        <nav
          className="rounded-[14px] border p-2 glass-card shadow-premium h-fit sticky top-0"
          style={{ borderColor: "var(--border)" }}
          aria-label="Settings sections"
        >
          {SECTIONS.map((s) => {
            const Icon = s.icon;
            const isActive = active === s.id;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => navigate(`settings/${s.id}`)}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "w-full flex items-center gap-2.5 px-3 py-2 rounded-[10px] text-sm transition-colors cursor-pointer focus-ring text-left",
                  isActive
                    ? "text-[var(--accent)]"
                    : "text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]",
                )}
                style={isActive ? { background: "var(--accent-soft)" } : undefined}
              >
                <Icon size={15} />
                <span className="flex-1 font-medium">{s.label}</span>
                {isActive && (
                  <motion.span
                    layoutId="settings-active"
                    className="w-1 h-4 rounded-full"
                    style={{ background: "var(--accent)" }}
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Section content */}
        <motion.div
          key={active}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
        >
          {renderSection()}
        </motion.div>
      </div>
    </div>
  );
}
