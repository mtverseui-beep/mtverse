"use client";
// ============================================================
// QuickOrderForm — buy/sell ticket. Prefilled by Order Book or
// Watchlist context-menu clicks. Submits to the store.
// ============================================================
import { useState } from "react";
import { useTradingStore } from "@/store/trading-store";
import { fmtPrice, fmtUSD } from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { ModernSelect } from "./ModernSelect";
import { Field, Input } from "./Field";
import type { OrderSide, OrderType } from "@/lib/trading/types";

const TYPES: OrderType[] = ["MARKET", "LIMIT", "STOP", "STOP_LIMIT"];

export function QuickOrderForm() {
  const selected = useTradingStore((s) => s.selectedTicker);
  const quotes = useTradingStore((s) => s.quotes);
  const quickOrder = useTradingStore((s) => s.quickOrder);
  const setQuickOrder = useTradingStore((s) => s.setQuickOrder);
  const submit = useTradingStore((s) => s.submitOrder);

  const q = quotes[selected];
  const [side, setSide] = useState<OrderSide>("BUY");
  const [type, setType] = useState<OrderType>("LIMIT");
  const [qty, setQty] = useState<number>(100);
  const [limitPrice, setLimitPrice] = useState<number>(q?.price ?? 0);
  const [stopPrice, setStopPrice] = useState<number>(q?.price ?? 0);

  // Sync prefills from quickOrder using the "adjust state during render"
  // pattern when a prop/store value changes — preferred over effects.
  const [lastQuickOrder, setLastQuickOrder] = useState(quickOrder);
  if (quickOrder !== lastQuickOrder) {
    setLastQuickOrder(quickOrder);
    if (quickOrder) {
      setSide(quickOrder.side);
      setQty(quickOrder.qty);
      setLimitPrice(+quickOrder.price.toFixed(2));
      setStopPrice(+quickOrder.price.toFixed(2));
      setType("LIMIT");
    }
  }

  // When symbol changes (via chart swap), reset prices to current quote.
  const [lastSelected, setLastSelected] = useState(selected);
  if (selected !== lastSelected) {
    setLastSelected(selected);
    if (q) {
      // Round to 2 decimals to avoid float-precision artifacts like 94.300003…
      setLimitPrice(+(side === "BUY" ? q.ask : q.bid).toFixed(2));
      setStopPrice(+q.price.toFixed(2));
    }
  }

  if (!q) return null;

  const estPrice =
    type === "MARKET"
      ? side === "BUY"
        ? q.ask
        : q.bid
      : type === "STOP"
        ? stopPrice
        : limitPrice;
  const estCost = estPrice * qty;
  const buyingPower = 248_750.42; // cash balance
  const isBuy = side === "BUY";

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (qty <= 0) {
      toast.error("Quantity must be greater than 0");
      return;
    }
    submit({
      ticker: selected,
      side,
      type,
      qty,
      limitPrice: type === "LIMIT" || type === "STOP_LIMIT" ? limitPrice : undefined,
      stopPrice: type === "STOP" || type === "STOP_LIMIT" ? stopPrice : undefined,
    });
    toast.success(
      `${side} ${qty} ${selected} @ ${type === "MARKET" ? "MKT" : fmtPrice(estPrice)} ${type === "MARKET" ? "filled" : "submitted"}`,
      {
        description: type === "MARKET" ? `Filled at ${fmtPrice(estPrice)}` : `Working order created`,
      },
    );
    setQuickOrder(null);
  };

  return (
    <section
      className="flex flex-col h-full overflow-hidden"
      style={{ background: "var(--surface)" }}
      aria-label="Quick order ticket"
    >
      <header
        className="px-3 py-2 border-b flex items-center justify-between"
        style={{ borderColor: "var(--border)" }}
      >
        <h3 className="text-xs font-semibold tracking-wider uppercase text-[var(--muted-foreground)]">
          Order Ticket · <span className="text-[var(--foreground)]">{selected}</span>
        </h3>
        <span className="text-[10px] font-mono text-[var(--muted-foreground)]">
          Bid <span className="text-[var(--gain)]">{fmtPrice(q.bid)}</span> · Ask <span className="text-[var(--loss)]">{fmtPrice(q.ask)}</span>
        </span>
      </header>

      <form onSubmit={onSubmit} className="flex flex-col gap-2.5 p-3 flex-1 overflow-y-auto">
        {/* Buy / Sell toggle */}
        <div
          className="grid grid-cols-2 rounded-[6px] border overflow-hidden"
          style={{ borderColor: "var(--border)" }}
          role="radiogroup"
          aria-label="Order side"
        >
          <button
            type="button"
            role="radio"
            aria-checked={isBuy}
            onClick={() => setSide("BUY")}
            className={cn(
              "py-1.5 text-xs font-semibold transition-colors focus-ring",
              isBuy ? "text-white" : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]",
            )}
            style={isBuy ? { background: "var(--gain)", color: "var(--background)" } : { background: "var(--background)" }}
          >
            BUY
          </button>
          <button
            type="button"
            role="radio"
            aria-checked={!isBuy}
            onClick={() => setSide("SELL")}
            className={cn(
              "py-1.5 text-xs font-semibold transition-colors focus-ring",
              !isBuy ? "text-white" : "text-[var(--muted-foreground)] hover:text-[var(--foreground)]",
            )}
            style={!isBuy ? { background: "var(--loss)", color: "#fff" } : { background: "var(--background)" }}
          >
            SELL
          </button>
        </div>

        {/* Type */}
        <Field label="Order Type">
          <ModernSelect
            value={type}
            onValueChange={(v) => setType(v as OrderType)}
            ariaLabel="Order type"
            options={TYPES.map((t) => ({ value: t, label: t.replace("_", " ") }))}
          />
        </Field>

        {/* Quantity */}
        <Field label="Quantity">
          <Input
            type="number"
            min={1}
            step={1}
            value={qty}
            onChange={(e) => setQty(Math.max(0, Math.floor(Number(e.target.value))))}
            aria-label="Quantity"
          />
          <div className="flex gap-1 mt-1.5">
            {[25, 50, 100, 250].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setQty(n)}
                className="flex-1 py-0.5 text-[10px] font-mono rounded-[4px] border hover:bg-[var(--surface-elevated)] focus-ring text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
                style={{ borderColor: "var(--border)" }}
              >
                {n}
              </button>
            ))}
          </div>
        </Field>

        {/* Limit price (if applicable) */}
        {(type === "LIMIT" || type === "STOP_LIMIT") && (
          <Field label="Limit Price">
            <Input
              type="number"
              step={0.01}
              min={0}
              value={limitPrice}
              onChange={(e) => setLimitPrice(Math.max(0, Number(e.target.value)))}
              aria-label="Limit price"
            />
          </Field>
        )}

        {/* Stop price (if applicable) */}
        {(type === "STOP" || type === "STOP_LIMIT") && (
          <Field label="Stop Price">
            <Input
              type="number"
              step={0.01}
              min={0}
              value={stopPrice}
              onChange={(e) => setStopPrice(Math.max(0, Number(e.target.value)))}
              aria-label="Stop price"
            />
          </Field>
        )}

        {/* Summary */}
        <div
          className="rounded-[6px] border p-2 text-[11px] font-mono space-y-1"
          style={{ borderColor: "var(--border)", background: "var(--background)" }}
        >
          <Row label="Est. Price" value={fmtPrice(estPrice)} />
          <Row label="Est. Cost" value={fmtUSD(estCost)} />
          <Row
            label="Buying Power"
            value={fmtUSD(buyingPower)}
            valueClass={estCost > buyingPower && isBuy ? "text-[var(--loss)]" : "text-[var(--foreground)]"}
          />
        </div>

        {/* Submit */}
        <button
          type="submit"
          className={cn(
            "mt-1 w-full py-2 text-xs font-semibold rounded-[6px] transition-colors focus-ring",
            isBuy
              ? "text-[#0B0E14] hover:brightness-110"
              : "text-white hover:brightness-110",
          )}
          style={{ background: isBuy ? "var(--gain)" : "var(--loss)" }}
        >
          {isBuy ? "BUY" : "SELL"} {qty} {selected}{" "}
          {type === "MARKET" ? "@ MKT" : `@ ${fmtPrice(estPrice)}`}
        </button>
      </form>
    </section>
  );
}

function Row({
  label,
  value,
  valueClass,
}: {
  label: string;
  value: string;
  valueClass?: string;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[var(--muted-foreground)]">{label}</span>
      <span className={cn("text-[var(--foreground)]", valueClass)}>{value}</span>
    </div>
  );
}
