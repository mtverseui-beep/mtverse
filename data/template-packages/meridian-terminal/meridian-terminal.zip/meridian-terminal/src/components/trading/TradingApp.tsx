"use client";
// ============================================================
// TradingApp — top-level shell. Hash-based router dispatches to
// real pages. Icon rail + top bar + ticker tape are persistent.
// ============================================================
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { IconRail } from "./IconRail";
import { TopBar } from "./TopBar";
import { TickerTape } from "./TickerTape";
import { Watchlist } from "./Watchlist";
import { ChartPanel } from "./ChartPanel";
import { OrderBook } from "./OrderBook";
import { QuickOrderForm } from "./QuickOrderForm";
import { PositionsOrders } from "./PositionsOrders";
import { PortfolioView } from "./PortfolioView";
import { CommandBar } from "./CommandBar";
import { MobileShell } from "./MobileShell";
import { OrdersPage } from "./pages/OrdersPage";
import { AlertsPage } from "./pages/AlertsPage";
import { HistoryPage } from "./pages/HistoryPage";
import { SettingsPage } from "./pages/SettingsPage";
import { ProfilePage } from "./pages/ProfilePage";
import { HelpPage } from "./pages/HelpPage";
import { useTradingStore } from "@/store/trading-store";
import { useMediaQuery } from "@/hooks/use-media-query";
import { useHashRoute } from "@/hooks/use-hash-route";
import { ScrollArea } from "@/components/ui/scroll-area";

export function TradingApp() {
  const [commandOpen, setCommandOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const tick = useTradingStore((s) => s.tick);
  const [route, navigate] = useHashRoute();

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    const id = setInterval(() => {
      tick();
    }, 2200);
    return () => clearInterval(id);
  }, [tick, mounted]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCommandOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const isDesktop = useMediaQuery("(min-width: 1024px)");

  if (!mounted) {
    return (
      <div
        className="flex h-screen w-screen items-center justify-center"
        style={{ background: "var(--background)" }}
        aria-label="Loading terminal"
      >
        <motion.div
          initial={{ opacity: 0, y: 8, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="flex flex-col items-center gap-5"
        >
          <motion.div
            animate={{ y: [0, -4, 0] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
          >
            <img src="/logo.svg?v=2" alt="Meridian Terminal" width={56} height={56} style={{ display: "block" }} />
          </motion.div>
          <div className="flex flex-col items-center gap-2">
            <div className="flex items-baseline gap-2">
              <span className="text-base font-semibold tracking-tight text-[var(--foreground)]">Meridian</span>
              <span className="text-[10px] text-[var(--muted-foreground)] font-mono uppercase tracking-[0.2em]">Terminal</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-[var(--muted-foreground)]">
              <span
                className="w-3 h-3 rounded-full border-2 border-current border-t-transparent animate-spin"
                style={{ color: "var(--accent)" }}
              />
              <span className="font-mono">Initializing terminal…</span>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  // Route → page resolution
  const top = route.segments[0] ?? "";
  const isTerminal = top === "" || top === "terminal";

  return (
    <div
      className="flex h-screen w-screen overflow-hidden"
      style={{ background: "var(--background)" }}
    >
      {isDesktop && (
        <IconRail
          route={route}
          navigate={navigate}
          onOpenCommand={() => setCommandOpen(true)}
        />
      )}

      <div className="flex flex-col flex-1 min-w-0">
        <TopBar onOpenCommand={() => setCommandOpen(true)} />
        <TickerTape />

        <div className="flex-1 min-h-0 overflow-hidden">
          {isTerminal ? (
            <TerminalView isDesktop={isDesktop} />
          ) : (
            <ScrollArea className="h-full">
              <div className="max-w-[1400px] mx-auto p-6">
                <PageRouter route={route} navigate={navigate} />
              </div>
            </ScrollArea>
          )}
        </div>
      </div>

      <CommandBar open={commandOpen} onOpenChange={setCommandOpen} />
    </div>
  );
}

function PageRouter({
  route,
  navigate,
}: {
  route: { path: string; segments: string[] };
  navigate: (path: string) => void;
}) {
  const top = route.segments[0] ?? "";
  switch (top) {
    case "portfolio":
      return <PortfolioView />;
    case "orders":
      return <OrdersPage navigate={navigate} />;
    case "alerts":
      return <AlertsPage navigate={navigate} />;
    case "history":
      return <HistoryPage navigate={navigate} />;
    case "settings":
      return <SettingsPage route={route} navigate={navigate} />;
    case "profile":
      return <ProfilePage navigate={navigate} />;
    case "help":
      return <HelpPage navigate={navigate} />;
    default:
      return <PortfolioView />;
  }
}

function TerminalView({ isDesktop }: { isDesktop: boolean }) {
  if (!isDesktop) {
    return <MobileShell />;
  }
  return (
    <div
      className="h-full grid gap-px"
      style={{
        gridTemplateColumns: "22% 1fr 22%",
        background: "var(--border)",
      }}
    >
      <div className="overflow-hidden">
        <Watchlist />
      </div>
      <div className="grid grid-rows-[1fr_320px] gap-px min-w-0" style={{ background: "var(--border)" }}>
        <div className="overflow-hidden">
          <ChartPanel />
        </div>
        <div className="grid grid-cols-[1fr_360px] gap-px min-h-0" style={{ background: "var(--border)" }}>
          <div className="overflow-hidden">
            <OrderBook />
          </div>
          <div className="overflow-hidden">
            <QuickOrderForm />
          </div>
        </div>
      </div>
      <div className="overflow-hidden">
        <PositionsOrders />
      </div>
    </div>
  );
}
