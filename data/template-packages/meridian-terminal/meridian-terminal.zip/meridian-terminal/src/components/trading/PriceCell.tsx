"use client";
// ============================================================
// PriceCell — renders a numeric value with mono font and a brief
// green/red flash background when the value changes.
// ============================================================
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

interface PriceCellProps {
  value: number;
  format?: (n: number) => string;
  className?: string;
  /** When true, only color the background (not the text). */
  textOnly?: boolean;
}

export function PriceCell({
  value,
  format = (n) => n.toFixed(2),
  className,
  textOnly = false,
}: PriceCellProps) {
  const prev = useRef(value);
  const [flash, setFlash] = useState<"gain" | "loss" | null>(null);

  useEffect(() => {
    if (value > prev.current) {
      setFlash("gain");
    } else if (value < prev.current) {
      setFlash("loss");
    }
    const t = setTimeout(() => setFlash(null), 700);
    prev.current = value;
    return () => clearTimeout(t);
  }, [value]);

  return (
    <span
      className={cn(
        "font-mono tabular-nums inline-block rounded-[3px] px-0.5 transition-colors",
        !textOnly && flash === "gain" && "flash-gain",
        !textOnly && flash === "loss" && "flash-loss",
        textOnly && flash === "gain" && "text-flash-gain",
        textOnly && flash === "loss" && "text-flash-loss",
        className,
      )}
    >
      {format(value)}
    </span>
  );
}
