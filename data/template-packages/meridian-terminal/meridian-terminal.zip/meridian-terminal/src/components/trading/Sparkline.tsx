"use client";
// ============================================================
// Sparkline — tiny Recharts AreaChart with no axes/grid.
// Used per-position to show recent unrealized P&L shape.
// Theme-aware: reads resolved CSS variable colors.
// ============================================================
import { useEffect, useState } from "react";
import { Area, AreaChart, ResponsiveContainer, YAxis } from "recharts";

interface SparklineProps {
  data: { t: number; v: number }[];
  positive?: boolean;
  width?: number | string;
  height?: number;
}

function useResolvedColor(varName: string): string {
  const [color, setColor] = useState(varName);
  useEffect(() => {
    const resolve = () => {
      const v = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
      if (v) setColor(v);
    };
    resolve();
    // Re-resolve on theme change
    const observer = new MutationObserver(() => resolve());
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  }, [varName]);
  return color;
}

export function Sparkline({
  data,
  positive,
  width = "100%",
  height = 28,
}: SparklineProps) {
  const gain = useResolvedColor("--gain");
  const loss = useResolvedColor("--loss");
  const muted = useResolvedColor("--muted-foreground");
  const color =
    positive === undefined ? muted : positive ? gain : loss;
  const id = `spark-${positive === undefined ? "n" : positive ? "g" : "l"}-${data.length}-${data[0]?.t ?? 0}`;
  return (
    <div style={{ width, height }} className="overflow-hidden">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{ top: 2, right: 0, bottom: 0, left: 0 }}
        >
          <defs>
            <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.35} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <YAxis domain={["dataMin", "dataMax"]} hide />
          <Area
            type="monotone"
            dataKey="v"
            stroke={color}
            strokeWidth={1.4}
            fill={`url(#${id})`}
            isAnimationActive={false}
            dot={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
