"use client";
// ProfilePage — full user profile with stats, activity, achievements.
import { motion } from "framer-motion";
import {
  TrendingUp,
  Award,
  Calendar,
  MapPin,
  Mail,
  Phone,
  Twitter,
  Linkedin,
  Briefcase,
  Activity,
  Zap,
  Target,
} from "lucide-react";
import { Avatar } from "../Avatar";
import { PageHeader } from "../PageHeader";
import { StatCard } from "../StatCard";
import { Button } from "../Button";
import { Sparkline } from "../Sparkline";
import { fmtUSD, fmtPct, fmtRelative, fmtDate } from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ProfilePageProps {
  navigate: (path: string) => void;
}

const USER = {
  name: "Aria Redmond",
  title: "Senior Quant Trader",
  email: "aria.redmond@meridian.io",
  phone: "+1 (415) 555-0148",
  location: "San Francisco, CA",
  joinedAt: Date.now() - 86400000 * 847,
  seed: "aria-redmond",
  bio: "Quant trader focused on momentum equities and cross-asset arbitrage. 12 years on the desk across NY and SF.",
};

const ACTIVITY = [
  { id: "a1", type: "trade", text: "Closed NVKS long position", detail: "+$2,564.45 (+7.57%)", time: Date.now() - 3600000 },
  { id: "a2", type: "alert", text: "Price alert triggered for NVKS", detail: "Crossed above $425.00", time: Date.now() - 7200000 },
  { id: "a3", type: "milestone", text: "Reached $500K portfolio value", detail: "Lifetime achievement", time: Date.now() - 86400000 },
  { id: "a4", type: "trade", text: "Opened AETH long position", detail: "480 shares @ $82.30", time: Date.now() - 172800000 },
  { id: "a5", type: "milestone", text: "100th trade executed", detail: "Trading milestone", time: Date.now() - 259200000 },
];

const ACHIEVEMENTS = [
  { id: "ach1", icon: TrendingUp, label: "First profit", desc: "Closed first winning trade", color: "var(--gain)" },
  { id: "ach2", icon: Zap, label: "Power trader", desc: "100+ trades in a month", color: "var(--accent)" },
  { id: "ach3", icon: Target, label: "Sharpshooter", desc: "90% win rate (50+ trades)", color: "#F0B90B" },
  { id: "ach4", icon: Award, label: "Diamond hands", desc: "Held a position 30+ days", color: "#3DC6FF" },
];

const PNL_SERIES = Array.from({ length: 30 }, (_, i) => ({
  t: Date.now() - (30 - i) * 86400000,
  v: 400000 + i * 5000 + Math.sin(i / 3) * 8000,
}));

export function ProfilePage({ navigate }: ProfilePageProps) {
  return (
    <div>
      <PageHeader
        title="Profile"
        description="Your public profile, trading stats, and activity timeline."
        breadcrumbs={[{ label: "Terminal", onClick: () => navigate("") }, { label: "Profile" }]}
        actions={
          <>
            <Button variant="outline" size="md" onClick={() => navigate("settings/profile")}>
              Edit profile
            </Button>
            <Button variant="primary" size="md" onClick={() => toast.info("Share profile", { description: "Public profile link copied." })}>
              Share
            </Button>
          </>
        }
      />

      {/* Profile hero */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-[16px] border glass-card shadow-premium-lg p-6 mb-6 relative overflow-hidden"
        style={{ borderColor: "var(--border)" }}
      >
        <div
          className="absolute -top-20 -right-20 w-64 h-64 rounded-full pointer-events-none"
          style={{ background: "radial-gradient(circle, var(--accent-glow), transparent 70%)", opacity: 0.5 }}
        />
        <div className="relative flex items-start gap-5 flex-wrap">
          <Avatar seed={USER.seed} name={USER.name} size={88} ring />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-semibold text-[var(--foreground)]">{USER.name}</h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wide" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                Pro · Tier 3
              </span>
            </div>
            <p className="text-sm text-[var(--muted-foreground)] mt-0.5 flex items-center gap-1.5">
              <Briefcase size={13} />
              {USER.title}
            </p>
            <p className="text-xs text-[var(--muted-foreground)] mt-2 max-w-xl leading-relaxed">{USER.bio}</p>
            <div className="flex items-center gap-4 mt-3 text-xs text-[var(--muted-foreground)] flex-wrap">
              <span className="flex items-center gap-1.5"><Mail size={12} />{USER.email}</span>
              <span className="flex items-center gap-1.5"><Phone size={12} />{USER.phone}</span>
              <span className="flex items-center gap-1.5"><MapPin size={12} />{USER.location}</span>
              <span className="flex items-center gap-1.5"><Calendar size={12} />Joined {fmtDate(USER.joinedAt)}</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Portfolio Value" value="$558K" delta="+12.4% YTD" deltaDirection="up" icon={TrendingUp} accent />
        <StatCard label="Total Trades" value="1,247" delta="+24 this month" deltaDirection="up" icon={Activity} />
        <StatCard label="Win Rate" value="68.4%" delta="+3.2%" deltaDirection="up" icon={Target} />
        <StatCard label="Best Trade" value="+42.1%" icon={Award} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* P&L chart */}
        <section className="lg:col-span-2 rounded-[14px] border glass-card shadow-premium p-5" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-[var(--foreground)]">Portfolio P&L (30 days)</h3>
              <p className="text-[11px] text-[var(--muted-foreground)]">Trailing month performance</p>
            </div>
            <span className="text-sm font-mono font-semibold text-[var(--gain)]">
              {fmtPct(12.4)}
            </span>
          </div>
          <div style={{ height: 200 }}>
            <Sparkline data={PNL_SERIES} positive height={200} />
          </div>
        </section>

        {/* Achievements */}
        <section className="rounded-[14px] border glass-card shadow-premium p-5" style={{ borderColor: "var(--border)" }}>
          <h3 className="text-sm font-semibold text-[var(--foreground)] mb-3">Achievements</h3>
          <div className="space-y-2">
            {ACHIEVEMENTS.map((a) => {
              const Icon = a.icon;
              return (
                <div key={a.id} className="flex items-center gap-3 px-3 py-2 rounded-[10px] hover:bg-[var(--surface-hover)] transition-colors">
                  <div
                    className="w-9 h-9 rounded-[10px] flex items-center justify-center shrink-0"
                    style={{ background: `${a.color}1f`, color: a.color }}
                  >
                    <Icon size={16} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-[var(--foreground)]">{a.label}</p>
                    <p className="text-[10px] text-[var(--muted-foreground)]">{a.desc}</p>
                  </div>
                  <Award size={14} style={{ color: a.color }} />
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Activity timeline */}
      <section className="rounded-[14px] border glass-card shadow-premium p-5 mt-6" style={{ borderColor: "var(--border)" }}>
        <h3 className="text-sm font-semibold text-[var(--foreground)] mb-4">Recent activity</h3>
        <div className="space-y-1">
          {ACTIVITY.map((a, i) => (
            <div key={a.id} className="flex items-start gap-3 py-2.5 relative">
              {i < ACTIVITY.length - 1 && (
                <div
                  className="absolute left-[15px] top-10 bottom-0 w-px"
                  style={{ background: "var(--border)" }}
                />
              )}
              <div
                className="w-8 h-8 rounded-[8px] flex items-center justify-center shrink-0 relative z-10"
                style={{
                  background: a.type === "trade" ? "var(--accent-soft)" : a.type === "alert" ? "rgba(240,185,11,0.12)" : "var(--gain-soft)",
                  color: a.type === "trade" ? "var(--accent)" : a.type === "alert" ? "#F0B90B" : "var(--gain)",
                }}
              >
                {a.type === "trade" ? <TrendingUp size={14} /> : a.type === "alert" ? <Zap size={14} /> : <Award size={14} />}
              </div>
              <div className="flex-1 min-w-0 pt-1">
                <p className="text-xs font-medium text-[var(--foreground)]">{a.text}</p>
                <p className="text-[11px] text-[var(--muted-foreground)] mt-0.5">{a.detail}</p>
              </div>
              <span className="text-[10px] font-mono text-[var(--muted-foreground)] shrink-0 pt-1.5">{fmtRelative(a.time)}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
