"use client";
// HelpPage — FAQ, contact form, support tickets, docs links.
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  HelpCircle,
  Search,
  MessageSquare,
  Book,
  Video,
  LifeBuoy,
  ChevronDown,
  Send,
  Mail,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { PageHeader } from "../PageHeader";
import { Button } from "../Button";
import { Field, Input, Textarea } from "../Field";
import { ModernSelect } from "../ModernSelect";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface HelpPageProps {
  navigate: (path: string) => void;
}

const FAQ = [
  { q: "How do I place my first trade?", a: "Open the terminal, click a symbol in the watchlist, use the order ticket on the bottom-right to choose your order type and quantity, then click Buy or Sell. Market orders fill instantly; limit orders appear in the Orders tab." },
  { q: "What's the difference between Market and Limit orders?", a: "Market orders execute immediately at the best available price. Limit orders only execute when the market reaches your specified price. Stop orders trigger when the market hits your stop price." },
  { q: "How do price alerts work?", a: "Go to Alerts → New alert. Choose a symbol, a condition (above, below, crosses up, crosses down), and a target price. When the condition is met, you'll get an in-app notification and optionally an email." },
  { q: "Can I export my trade history?", a: "Yes. Go to History → Export CSV. The export includes every fill in the selected date range with timestamp, symbol, side, quantity, price, notional, and fees." },
  { q: "How is my buying power calculated?", a: "Buying power = cash balance × margin multiplier (2× for Tier 3 margin accounts). Your current buying power is shown in the top bar and on the Portfolio page." },
  { q: "Is my data secure?", a: "All connections use TLS 1.3. We support two-factor authentication (Settings → Security). API keys are scoped and revocable. We never store your password in plaintext." },
  { q: "How do I cancel my subscription?", a: "Go to Settings → Billing → Cancel. Your plan stays active until the end of the current billing period, then downgrades to read-only." },
  { q: "Can I share my watchlist with my team?", a: "Team members on Admin and Trader roles can see shared watchlists. Go to Settings → Team to invite teammates and assign roles." },
];

const RESOURCES = [
  { icon: Book, title: "Documentation", desc: "Comprehensive guides and API reference", action: "Read docs" },
  { icon: Video, title: "Video tutorials", desc: "Step-by-step walkthroughs of every feature", action: "Watch" },
  { icon: LifeBuoy, title: "Status page", desc: "Real-time system health and uptime", action: "Check status" },
  { icon: MessageSquare, title: "Community", desc: "Join 4,000+ traders in our Discord", action: "Join" },
];

const TICKETS = [
  { id: "T-4821", subject: "Order rejection on QBIT", status: "OPEN", priority: "HIGH", updatedAt: Date.now() - 3600000 },
  { id: "T-4815", subject: "API rate limit increase", status: "RESOLVED", priority: "MEDIUM", updatedAt: Date.now() - 86400000 },
  { id: "T-4790", subject: "Webhook delivery failing", status: "RESOLVED", priority: "HIGH", updatedAt: Date.now() - 86400000 * 3 },
];

export function HelpPage({ navigate }: HelpPageProps) {
  const [search, setSearch] = useState("");
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [contactSubject, setContactSubject] = useState("");
  const [contactCategory, setContactCategory] = useState("general");
  const [contactMessage, setContactMessage] = useState("");
  const [sending, setSending] = useState(false);

  const filteredFaq = FAQ.filter(
    (f) => f.q.toLowerCase().includes(search.toLowerCase()) || f.a.toLowerCase().includes(search.toLowerCase()),
  );

  const submitTicket = () => {
    if (!contactSubject.trim() || !contactMessage.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    setSending(true);
    setTimeout(() => {
      setSending(false);
      toast.success("Support ticket created", { description: `Ticket #T-${Math.floor(1000 + Math.random() * 9000)} — we'll respond within 4 hours.` });
      setContactSubject("");
      setContactMessage("");
    }, 1200);
  };

  return (
    <div>
      <PageHeader
        title="Help & Support"
        description="Find answers, browse resources, or reach out to our team. We typically respond within 4 hours during market hours."
        breadcrumbs={[{ label: "Terminal", onClick: () => navigate("") }, { label: "Help" }]}
      />

      {/* Hero search */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-[16px] border glass-card shadow-premium-lg p-6 mb-6 relative overflow-hidden"
        style={{ borderColor: "var(--border)" }}
      >
        <div
          className="absolute -top-20 -right-20 w-64 h-64 rounded-full pointer-events-none"
          style={{ background: "radial-gradient(circle, var(--accent-glow), transparent 70%)", opacity: 0.4 }}
        />
        <div className="relative">
          <div className="flex items-center gap-2 mb-3">
            <HelpCircle size={18} className="text-[var(--accent)]" />
            <h2 className="text-base font-semibold text-[var(--foreground)]">How can we help?</h2>
          </div>
          <div className="relative max-w-xl">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)] pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search the knowledge base…"
              className="pl-10 h-11 text-sm"
            />
          </div>
        </div>
      </motion.div>

      {/* Resources */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {RESOURCES.map((r) => {
          const Icon = r.icon;
          return (
            <motion.button
              key={r.title}
              whileHover={{ y: -2 }}
              onClick={() => toast.info(r.title, { description: r.desc })}
              className="rounded-[14px] border glass-card shadow-premium p-5 text-left cursor-pointer focus-ring transition-all"
              style={{ borderColor: "var(--border)" }}
            >
              <div className="w-10 h-10 rounded-[10px] flex items-center justify-center mb-3" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                <Icon size={18} />
              </div>
              <p className="text-sm font-semibold text-[var(--foreground)]">{r.title}</p>
              <p className="text-[11px] text-[var(--muted-foreground)] mt-1 leading-relaxed">{r.desc}</p>
              <p className="text-[11px] text-[var(--accent)] mt-3 font-medium">{r.action} →</p>
            </motion.button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* FAQ */}
        <section className="lg:col-span-2">
          <div className="rounded-[14px] border glass-card shadow-premium overflow-hidden" style={{ borderColor: "var(--border)" }}>
            <header className="px-5 py-4 border-b" style={{ borderColor: "var(--border)" }}>
              <h3 className="text-sm font-semibold">Frequently asked questions</h3>
              <p className="text-[11px] text-[var(--muted-foreground)] mt-0.5">{filteredFaq.length} articles</p>
            </header>
            <div className="divide-y" style={{ borderColor: "var(--border)" }}>
              <AnimatePresence initial={false}>
                {filteredFaq.map((f, i) => (
                  <motion.div key={i} layout>
                    <button
                      type="button"
                      onClick={() => setOpenFaq(openFaq === i ? null : i)}
                      className="w-full flex items-center justify-between gap-3 px-5 py-3.5 text-left cursor-pointer hover:bg-[var(--surface-hover)] transition-colors focus-ring"
                    >
                      <span className={cn("text-sm", openFaq === i ? "font-semibold text-[var(--accent)]" : "font-medium text-[var(--foreground)]")}>
                        {f.q}
                      </span>
                      <motion.span animate={{ rotate: openFaq === i ? 180 : 0 }} transition={{ duration: 0.2 }}>
                        <ChevronDown size={15} className="text-[var(--muted-foreground)] shrink-0" />
                      </motion.span>
                    </button>
                    <AnimatePresence initial={false}>
                      {openFaq === i && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <p className="px-5 pb-4 text-xs text-[var(--muted-foreground)] leading-relaxed">{f.a}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </section>

        {/* Contact + tickets */}
        <section className="space-y-4">
          <div className="rounded-[14px] border glass-card shadow-premium p-5" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-2 mb-4">
              <Mail size={16} className="text-[var(--accent)]" />
              <h3 className="text-sm font-semibold">Contact support</h3>
            </div>
            <div className="space-y-3">
              <Field label="Subject" required>
                <Input value={contactSubject} onChange={(e) => setContactSubject(e.target.value)} placeholder="Briefly describe your issue" />
              </Field>
              <Field label="Category">
                <ModernSelect
                  value={contactCategory}
                  onValueChange={setContactCategory}
                  options={[
                    { value: "general", label: "General" },
                    { value: "trading", label: "Trading issue" },
                    { value: "billing", label: "Billing" },
                    { value: "api", label: "API" },
                    { value: "bug", label: "Bug report" },
                  ]}
                  ariaLabel="Category"
                />
              </Field>
              <Field label="Message" required>
                <Textarea rows={4} value={contactMessage} onChange={(e) => setContactMessage(e.target.value)} placeholder="Describe your issue in detail…" />
              </Field>
              <Button variant="primary" size="md" icon={Send} className="w-full" loading={sending} onClick={submitTicket}>
                {sending ? "Sending…" : "Submit ticket"}
              </Button>
              <p className="text-[10px] text-[var(--muted-foreground)] text-center flex items-center justify-center gap-1">
                <Clock size={10} />
                Avg response time: 4 hours
              </p>
            </div>
          </div>

          <div className="rounded-[14px] border glass-card shadow-premium p-5" style={{ borderColor: "var(--border)" }}>
            <h3 className="text-sm font-semibold mb-3">Your tickets</h3>
            <div className="space-y-2">
              {TICKETS.map((t) => (
                <div key={t.id} className="flex items-center gap-3 px-3 py-2 rounded-[8px] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer">
                  <div
                    className="w-7 h-7 rounded-[6px] flex items-center justify-center shrink-0"
                    style={{
                      background: t.status === "RESOLVED" ? "var(--gain-soft)" : "rgba(240,185,11,0.12)",
                      color: t.status === "RESOLVED" ? "var(--gain)" : "#F0B90B",
                    }}
                  >
                    {t.status === "RESOLVED" ? <CheckCircle2 size={13} /> : <Clock size={13} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-[var(--foreground)] truncate">{t.subject}</p>
                    <p className="text-[10px] text-[var(--muted-foreground)] font-mono">{t.id}</p>
                  </div>
                  <span
                    className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase"
                    style={{
                      background: t.priority === "HIGH" ? "var(--loss-soft)" : "var(--surface-hover)",
                      color: t.priority === "HIGH" ? "var(--loss)" : "var(--muted-foreground)",
                    }}
                  >
                    {t.priority}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
