"use client";
// ============================================================
// DataTable — premium TanStack Table wrapper.
// Features: sorting, global search, pagination, row selection,
// bulk actions, column visibility, status badges, action menus,
// skeleton loading, empty state.
// ============================================================
import { useState, useMemo } from "react";
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  getFacetedRowModel,
  getFacetedUniqueValues,
  useReactTable,
  type ColumnDef,
  type SortingState,
  type RowSelectionState,
  type VisibilityState,
  type ColumnFiltersState,
} from "@tanstack/react-table";
import {
  Search,
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  ChevronLeft,
  ChevronRight,
  Settings2,
  Inbox,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { Button } from "./Button";

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  searchPlaceholder?: string;
  searchKeys?: (keyof TData)[];
  /** Render bulk-action bar when rows are selected. */
  bulkActions?: (selectedRows: TData[], clearSelection: () => void) => React.ReactNode;
  /** Toolbar actions rendered on the right (e.g. export, add). */
  toolbarActions?: React.ReactNode;
  /** Filter chips rendered left of search. */
  filters?: React.ReactNode;
  emptyState?: { icon: React.ComponentType<{ size?: number; className?: string }>; title: string; description: string };
  pageSize?: number;
  loading?: boolean;
  getRowId?: (row: TData) => string;
}

export function DataTable<TData, TValue>({
  columns,
  data,
  searchPlaceholder = "Search…",
  searchKeys,
  bulkActions,
  toolbarActions,
  filters,
  emptyState,
  pageSize = 10,
  loading,
  getRowId,
}: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [globalFilter, setGlobalFilter] = useState("");

  const table = useReactTable({
    data,
    columns,
    state: { sorting, rowSelection, columnVisibility, globalFilter },
    enableRowSelection: true,
    onSortingChange: setSorting,
    onRowSelectionChange: setRowSelection,
    onColumnVisibilityChange: setColumnVisibility,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getRowId,
    initialState: { pagination: { pageSize } },
    globalFilterFn: (row, _columnId, filterValue) => {
      const value = String(filterValue).toLowerCase();
      if (searchKeys && searchKeys.length > 0) {
        return searchKeys.some((k) => {
          const cell = row.getValue(k as string);
          return cell != null && String(cell).toLowerCase().includes(value);
        });
      }
      // Search all visible cells
      return Object.values(row.original as object).some((v) =>
        v != null && String(v).toLowerCase().includes(value),
      );
    },
  });

  const selectedRows = table.getSelectedRowModel().rows.map((r) => r.original);
  const hasSelection = selectedRows.length > 0;

  return (
    <div className="flex flex-col gap-3">
      {/* Toolbar */}
      <div className="flex items-center gap-2 flex-wrap">
        {filters}
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)] pointer-events-none" />
          <input
            value={globalFilter}
            onChange={(e) => setGlobalFilter(e.target.value)}
            placeholder={searchPlaceholder}
            className="w-full h-9 pl-9 pr-3 text-xs rounded-[10px] border bg-[var(--surface)] focus-ring outline-none placeholder:text-[var(--muted-foreground)] text-[var(--foreground)] transition-colors hover:border-[var(--border-strong)]"
            style={{ borderColor: "var(--border)" }}
          />
        </div>
        <div className="flex items-center gap-2 ml-auto">
          {toolbarActions}
          {/* Column visibility */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="h-9 px-3 inline-flex items-center gap-1.5 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
                style={{ borderColor: "var(--border)", background: "var(--surface)" }}
              >
                <Settings2 size={14} />
                <span className="hidden sm:inline">Columns</span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              sideOffset={8}
              className="w-44 font-sans"
              style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "12px", boxShadow: "var(--shadow-lg)" }}
            >
              <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-[var(--muted-foreground)]">Toggle columns</DropdownMenuLabel>
              <DropdownMenuSeparator style={{ background: "var(--border)" }} />
              {table.getAllColumns()
                .filter((col) => typeof col.accessorFn !== "undefined" || col.id !== "actions")
                .filter((col) => col.getCanHide())
                .map((col) => (
                  <DropdownMenuCheckboxItem
                    key={col.id}
                    checked={col.getIsVisible()}
                    onCheckedChange={(v) => col.toggleVisibility(!!v)}
                    className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 text-sm capitalize"
                  >
                    {col.id.replace(/_/g, " ")}
                  </DropdownMenuCheckboxItem>
                ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Bulk action bar */}
      <AnimatePresence>
        {hasSelection && bulkActions && (
          <motion.div
            initial={{ opacity: 0, y: -8, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -8, height: 0 }}
            className="flex items-center gap-3 px-4 py-2.5 rounded-[12px] border"
            style={{ background: "var(--accent-soft)", borderColor: "var(--accent)" }}
          >
            <span className="text-xs font-semibold text-[var(--accent)]">
              {selectedRows.length} selected
            </span>
            <div className="flex items-center gap-2 ml-auto">
              {bulkActions(selectedRows, () => setRowSelection({}))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Table */}
      <div
        className="rounded-[14px] border overflow-hidden glass-card shadow-premium"
        style={{ borderColor: "var(--border)" }}
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              {table.getHeaderGroups().map((hg) => (
                <tr key={hg.id} className="border-b" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
                  {hg.headers.map((header) => (
                    <th
                      key={header.id}
                      className="px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wider text-[var(--muted-foreground)] whitespace-nowrap"
                      style={{ width: header.getSize() !== 150 ? header.getSize() : undefined }}
                    >
                      {header.isPlaceholder ? null : (
                        <div className={cn("flex items-center gap-1.5", header.column.getCanSort() && "cursor-pointer hover:text-[var(--foreground)] select-none")}>
                          {flexRender(header.column.columnDef.header, header.getContext())}
                          {header.column.getCanSort() && (
                            <span className="opacity-50">
                              {header.column.getIsSorted() === "asc" ? (
                                <ChevronUp size={12} />
                              ) : header.column.getIsSorted() === "desc" ? (
                                <ChevronDown size={12} />
                              ) : (
                                <ChevronsUpDown size={12} className="opacity-40" />
                              )}
                            </span>
                          )}
                        </div>
                      )}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="border-b" style={{ borderColor: "var(--border)" }}>
                    {columns.map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-3 rounded skeleton" style={{ width: `${60 + Math.random() * 40}%` }} />
                      </td>
                    ))}
                  </tr>
                ))
              ) : table.getRowModel().rows.length === 0 ? (
                <tr>
                  <td colSpan={columns.length} className="px-4 py-12">
                    {emptyState ? (
                      <EmptyStateInline icon={emptyState.icon} title={emptyState.title} description={emptyState.description} />
                    ) : (
                      <div className="text-center text-[var(--muted-foreground)] text-xs">No results found.</div>
                    )}
                  </td>
                </tr>
              ) : (
                table.getRowModel().rows.map((row) => (
                  <tr
                    key={row.id}
                    data-state={row.getIsSelected() ? "selected" : undefined}
                    className="border-b last:border-0 hover:bg-[var(--surface-hover)] transition-colors"
                    style={{
                      borderColor: "var(--border)",
                      background: row.getIsSelected() ? "var(--accent-soft)" : undefined,
                    }}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="px-4 py-2.5 text-[var(--foreground)]">
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div
          className="flex items-center justify-between px-4 py-2.5 border-t gap-2 flex-wrap"
          style={{ borderColor: "var(--border)", background: "var(--surface)" }}
        >
          <div className="text-[11px] font-mono text-[var(--muted-foreground)]">
            {table.getFilteredRowModel().rows.length} rows ·{" "}
            <span className="text-[var(--foreground)]">
              {table.getState().pagination.pageIndex * pageSize + 1}–
              {Math.min((table.getState().pagination.pageIndex + 1) * pageSize, table.getFilteredRowModel().rows.length)}
            </span>{" "}
            shown
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
              aria-label="Previous page"
            >
              <ChevronLeft size={15} />
            </Button>
            <span className="text-[11px] font-mono text-[var(--muted-foreground)] px-2">
              {table.getState().pagination.pageIndex + 1} / {table.getPageCount() || 1}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
              aria-label="Next page"
            >
              <ChevronRight size={15} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function EmptyStateInline({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-center">
      <div
        className="w-12 h-12 rounded-[12px] flex items-center justify-center mb-3"
        style={{ background: "var(--surface-hover)" }}
      >
        <Icon size={20} className="text-[var(--muted-foreground)]" />
      </div>
      <p className="text-sm font-semibold text-[var(--foreground)]">{title}</p>
      <p className="text-xs text-[var(--muted-foreground)] mt-1 max-w-xs">{description}</p>
    </div>
  );
}
