"use client";
// ============================================================
// ModernSelect — theme-aware wrapper around shadcn Select (Radix).
// Guarantees our premium dark/light styling and consistent sizing.
// ============================================================
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface ModernSelectProps {
  value: string;
  onValueChange: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
  className?: string;
  size?: "sm" | "md";
  ariaLabel?: string;
}

export function ModernSelect({
  value,
  onValueChange,
  options,
  placeholder,
  className,
  size = "md",
  ariaLabel,
}: ModernSelectProps) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger
        aria-label={ariaLabel}
        size={size === "sm" ? "sm" : "default"}
        className={cn(
          "w-full font-mono border focus-ring outline-none transition-colors hover:border-[var(--border-strong)] cursor-pointer",
          size === "sm" ? "h-8 px-2.5 text-xs rounded-[8px]" : "h-9 px-3 text-xs rounded-[10px]",
          className,
        )}
        style={{
          background: "var(--surface)",
          borderColor: "var(--border)",
          color: "var(--foreground)",
        }}
      >
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent
        position="popper"
        sideOffset={6}
        className="font-sans min-w-[var(--radix-select-trigger-width)]"
        style={{
          background: "var(--popover)",
          border: "1px solid var(--border)",
          color: "var(--foreground)",
          borderRadius: "12px",
          boxShadow: "var(--shadow-xl)",
          overflow: "hidden",
        }}
      >
        {options.map((opt) => (
          <SelectItem
            key={opt.value}
            value={opt.value}
            disabled={opt.disabled}
            className="cursor-pointer focus:bg-[var(--surface-hover)] focus:text-[var(--foreground)] rounded-[8px] mx-1 text-xs gap-2 data-[state=checked]:text-[var(--accent)] data-[state=checked]:bg-[var(--accent-soft)]"
          >
            <span className="flex-1">{opt.label}</span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
