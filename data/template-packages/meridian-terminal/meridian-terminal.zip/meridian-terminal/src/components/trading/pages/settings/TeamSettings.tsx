"use client";
// TeamSettings — team members with roles, invite, remove.
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, UserPlus, Trash2, Mail, Shield, Crown, MoreHorizontal } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Avatar } from "../../Avatar";
import { SettingsCard } from "./_shared";
import { Button } from "../../Button";
import { StatCard } from "../../StatCard";
import { ModernSelect } from "../../ModernSelect";
import { Field, Input } from "../../Field";
import { fmtRelative } from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Role = "OWNER" | "ADMIN" | "TRADER" | "VIEWER";

interface Member {
  id: string;
  name: string;
  email: string;
  role: Role;
  seed: string;
  lastActive: number;
  status: "active" | "invited" | "suspended";
}

const INITIAL: Member[] = [
  { id: "m1", name: "Aria Redmond", email: "aria.redmond@meridian.io", role: "OWNER", seed: "aria-redmond", lastActive: Date.now(), status: "active" },
  { id: "m2", name: "Marcus Chen", email: "marcus.chen@meridian.io", role: "ADMIN", seed: "marcus-chen", lastActive: Date.now() - 3600000, status: "active" },
  { id: "m3", name: "Priya Nair", email: "priya.nair@meridian.io", role: "TRADER", seed: "priya-nair", lastActive: Date.now() - 86400000, status: "active" },
  { id: "m4", name: "Sven Olsen", email: "sven.olsen@meridian.io", role: "TRADER", seed: "sven-olsen", lastActive: Date.now() - 172800000, status: "active" },
  { id: "m5", name: "Yuki Tanaka", email: "yuki.tanaka@meridian.io", role: "VIEWER", seed: "yuki-tanaka", lastActive: Date.now() - 259200000, status: "invited" },
];

const ROLE_META: Record<Role, { label: string; icon: React.ComponentType<{ size?: number }>; color: string; bg: string }> = {
  OWNER: { label: "Owner", icon: Crown, color: "#F0B90B", bg: "rgba(240,185,11,0.12)" },
  ADMIN: { label: "Admin", icon: Shield, color: "var(--accent)", bg: "var(--accent-soft)" },
  TRADER: { label: "Trader", icon: Users, color: "var(--gain)", bg: "var(--gain-soft)" },
  VIEWER: { label: "Viewer", icon: Users, color: "var(--muted-foreground)", bg: "var(--surface-hover)" },
};

export function TeamSettings() {
  const [members, setMembers] = useState<Member[]>(INITIAL);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<Role>("TRADER");
  const [inviteError, setInviteError] = useState<string>();

  const sendInvite = () => {
    if (!inviteEmail.includes("@")) {
      setInviteError("Enter a valid email address");
      return;
    }
    const newMember: Member = {
      id: `m-${Date.now()}`,
      name: inviteEmail.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
      email: inviteEmail,
      role: inviteRole,
      seed: inviteEmail,
      lastActive: Date.now(),
      status: "invited",
    };
    setMembers((arr) => [...arr, newMember]);
    toast.success(`Invitation sent to ${inviteEmail}`, { description: `Role: ${ROLE_META[inviteRole].label}` });
    setInviteEmail("");
    setInviteRole("TRADER");
    setInviteError(undefined);
    setInviteOpen(false);
  };

  const changeRole = (id: string, role: Role) => {
    setMembers((arr) => arr.map((m) => (m.id === id ? { ...m, role } : m)));
    toast.success("Role updated");
  };

  const removeMember = (id: string) => {
    setMembers((arr) => arr.filter((m) => m.id !== id));
    toast.success("Member removed");
  };

  const stats = {
    total: members.length,
    active: members.filter((m) => m.status === "active").length,
    invited: members.filter((m) => m.status === "invited").length,
    admins: members.filter((m) => m.role === "ADMIN" || m.role === "OWNER").length,
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Members" value={String(stats.total)} icon={Users} accent />
        <StatCard label="Active" value={String(stats.active)} icon={Users} />
        <StatCard label="Invited" value={String(stats.invited)} icon={Mail} />
        <StatCard label="Admins" value={String(stats.admins)} icon={Shield} />
      </div>

      <SettingsCard
        title="Team members"
        description="Manage who has access to your Meridian workspace. Invite teammates, assign roles, and remove access."
      >
        <div className="flex items-center justify-between mb-4">
          <p className="text-xs text-[var(--muted-foreground)]">{members.length} members</p>
          <Button variant="primary" size="md" icon={UserPlus} onClick={() => setInviteOpen(true)}>
            Invite member
          </Button>
        </div>

        <div className="space-y-2">
          <AnimatePresence initial={false}>
            {members.map((m) => {
              const roleMeta = ROLE_META[m.role];
              const RoleIcon = roleMeta.icon;
              return (
                <motion.div
                  key={m.id}
                  layout
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-center gap-3 px-4 py-3 rounded-[10px] border"
                  style={{ borderColor: "var(--border)", background: "var(--surface)" }}
                >
                  <Avatar seed={m.seed} name={m.name} size={36} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-[var(--foreground)] truncate">{m.name}</p>
                      {m.status === "invited" && (
                        <span
                          className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase tracking-wide"
                          style={{ background: "rgba(240,185,11,0.12)", color: "#F0B90B" }}
                        >
                          Invited
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-[var(--muted-foreground)] truncate">{m.email}</p>
                  </div>
                  <div className="hidden sm:flex items-center gap-1.5 text-[10px] text-[var(--muted-foreground)] font-mono">
                    <span>Active {fmtRelative(m.lastActive)}</span>
                  </div>
                  <div
                    className="flex items-center gap-1.5 px-2 py-1 rounded-[6px] text-[11px] font-semibold"
                    style={{ background: roleMeta.bg, color: roleMeta.color }}
                  >
                    <RoleIcon size={11} />
                    {roleMeta.label}
                  </div>
                  {m.role !== "OWNER" ? (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button
                          type="button"
                          className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring"
                          aria-label="Member actions"
                        >
                          <MoreHorizontal size={14} />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent
                        align="end"
                        className="w-44 font-sans"
                        style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "12px", boxShadow: "var(--shadow-lg)" }}
                      >
                        <DropdownMenuItem className="text-[10px] uppercase tracking-wider text-[var(--muted-foreground)] cursor-default focus:bg-transparent" disabled>
                          Change role
                        </DropdownMenuItem>
                        {(["ADMIN", "TRADER", "VIEWER"] as Role[]).map((r) => (
                          <DropdownMenuItem
                            key={r}
                            className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[8px] mx-1 text-xs gap-2"
                            onClick={() => changeRole(m.id, r)}
                          >
                            {ROLE_META[r].label}
                            {m.role === r && <span className="ml-auto text-[var(--accent)]">✓</span>}
                          </DropdownMenuItem>
                        ))}
                        <DropdownMenuSeparator style={{ background: "var(--border)" }} />
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <DropdownMenuItem
                              className="cursor-pointer focus:bg-[var(--loss-soft)] rounded-[8px] mx-1 text-xs gap-2 text-[var(--loss)]"
                              onSelect={(e) => e.preventDefault()}
                            >
                              <Trash2 size={13} />
                              Remove member
                            </DropdownMenuItem>
                          </AlertDialogTrigger>
                          <AlertDialogContent style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Remove {m.name}?</AlertDialogTitle>
                              <AlertDialogDescription className="text-[var(--muted-foreground)]">
                                {m.name} will lose access to the workspace immediately. This cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel style={{ background: "var(--surface)", border: "1px solid var(--border)", color: "var(--foreground)" }}>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => removeMember(m.id)} style={{ background: "var(--loss)", color: "#fff" }}>Remove</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  ) : (
                    <div className="w-7" />
                  )}
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </SettingsCard>

      {/* Invite dialog */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent
          className="font-sans max-w-md p-0 gap-0"
          style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "16px", boxShadow: "var(--shadow-xl)" }}
        >
          <DialogHeader className="px-5 pt-5 pb-3">
            <DialogTitle className="text-base font-semibold">Invite team member</DialogTitle>
          </DialogHeader>
          <div className="px-5 pb-5 space-y-4">
            <Field label="Email address" error={inviteError} required>
              <Input
                type="email"
                placeholder="colleague@meridian.io"
                value={inviteEmail}
                onChange={(e) => { setInviteEmail(e.target.value); setInviteError(undefined); }}
                invalid={!!inviteError}
                leading={<Mail size={14} />}
              />
            </Field>
            <Field label="Role" description="Traders can place orders. Viewers have read-only access.">
              <ModernSelect
                value={inviteRole}
                onValueChange={(v) => setInviteRole(v as Role)}
                options={(["ADMIN", "TRADER", "VIEWER"] as Role[]).map((r) => ({ value: r, label: ROLE_META[r].label }))}
                ariaLabel="Role"
              />
            </Field>
            <div className="flex items-center justify-end gap-2 pt-2">
              <Button variant="outline" size="md" onClick={() => setInviteOpen(false)}>Cancel</Button>
              <Button variant="primary" size="md" icon={Mail} onClick={sendInvite}>Send invitation</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
