"use client";
// BillingSettings — subscription plan, usage, invoices, payment methods.
import { useState } from "react";
import { CreditCard, Download, Check, Zap, TrendingUp, Receipt, Plus, Trash2 } from "lucide-react";
import { motion } from "framer-motion";
import { SettingsCard } from "./_shared";
import { Button } from "../../Button";
import { StatCard } from "../../StatCard";
import { fmtUSD, fmtDate } from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const PLANS = [
  {
    id: "trader",
    name: "Trader",
    price: 49,
    features: ["Real-time quotes", "5 working orders", "1 watchlist", "Email support"],
  },
  {
    id: "pro",
    name: "Pro",
    price: 99,
    features: ["Everything in Trader", "Unlimited orders", "10 watchlists", "API access", "Priority support", "Advanced charting"],
    current: true,
  },
  {
    id: "institutional",
    name: "Institutional",
    price: 499,
    features: ["Everything in Pro", "Dedicated server", "Unlimited everything", "White-glove onboarding", "SLA 99.99%", "Custom integrations"],
  },
];

const INVOICES = [
  { id: "INV-2026-007", date: Date.now() - 86400000 * 2, amount: 99.00, status: "PAID" },
  { id: "INV-2026-006", date: Date.now() - 86400000 * 32, amount: 99.00, status: "PAID" },
  { id: "INV-2026-005", date: Date.now() - 86400000 * 62, amount: 99.00, status: "PAID" },
  { id: "INV-2026-004", date: Date.now() - 86400000 * 92, amount: 99.00, status: "PAID" },
  { id: "INV-2026-003", date: Date.now() - 86400000 * 122, amount: 49.00, status: "PAID" },
];

const PAYMENT_METHODS = [
  { id: "pm-1", brand: "VISA", last4: "4242", expMonth: 12, expYear: 2027, isDefault: true },
  { id: "pm-2", brand: "MASTERCARD", last4: "8888", expMonth: 3, expYear: 2028, isDefault: false },
];

export function BillingSettings() {
  const [methods] = useState(PAYMENT_METHODS);

  return (
    <div className="space-y-4">
      {/* Current plan */}
      <SettingsCard title="Current plan" description="You're on the Pro plan. Your next renewal is on the 15th.">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-semibold text-[var(--foreground)]">Pro</span>
              <span
                className="text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wide"
                style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
              >
                Active
              </span>
            </div>
            <p className="text-sm text-[var(--muted-foreground)] mt-1">
              <span className="text-2xl font-mono font-semibold text-[var(--foreground)]">{fmtUSD(99)}</span> / month
            </p>
            <p className="text-xs text-[var(--muted-foreground)] mt-2">Renews on {fmtDate(Date.now() + 86400000 * 14)}</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="md" onClick={() => toast.info("Plan change", { description: "Open plan comparison to downgrade." })}>
              Change plan
            </Button>
            <Button variant="ghost" size="md" onClick={() => toast.info("Cancellation", { description: "Plan stays active until period end." })}>
              Cancel
            </Button>
          </div>
        </div>
      </SettingsCard>

      {/* Usage */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Orders this month" value="247" delta="+12% vs last" deltaDirection="up" icon={Zap} accent />
        <StatCard label="API calls" value="12.4K / 50K" delta="25% used" icon={TrendingUp} />
        <StatCard label="Watchlists" value="4 / 10" icon={Receipt} />
        <StatCard label="Spend YTD" value={fmtUSD(894)} icon={CreditCard} />
      </div>

      {/* Plans */}
      <SettingsCard title="Available plans" description="Upgrade or downgrade at any time. Changes prorate automatically.">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {PLANS.map((plan) => (
            <div
              key={plan.id}
              className={cn(
                "relative rounded-[14px] border p-5 transition-all",
                plan.current ? "border-[var(--accent)]" : "border-[var(--border)]",
              )}
              style={plan.current ? { background: "var(--accent-soft)" } : { background: "var(--surface)" }}
            >
              {plan.current && (
                <span
                  className="absolute -top-2.5 left-5 text-[9px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wide text-white"
                  style={{ background: "var(--accent)" }}
                >
                  Current
                </span>
              )}
              <p className="text-sm font-semibold text-[var(--foreground)]">{plan.name}</p>
              <p className="mt-2">
                <span className="text-3xl font-mono font-semibold text-[var(--foreground)]">${plan.price}</span>
                <span className="text-xs text-[var(--muted-foreground)]">/mo</span>
              </p>
              <ul className="mt-4 space-y-2">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-xs text-[var(--foreground)]">
                    <Check size={13} className="text-[var(--accent)] shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Button
                variant={plan.current ? "outline" : "primary"}
                size="md"
                className="w-full mt-5"
                disabled={plan.current}
                onClick={() => toast.success(`Switched to ${plan.name}`, { description: `Prorated charge of $${plan.price} applied.` })}
              >
                {plan.current ? "Current plan" : `Switch to ${plan.name}`}
              </Button>
            </div>
          ))}
        </div>
      </SettingsCard>

      {/* Payment methods */}
      <SettingsCard title="Payment methods" description="Cards on file for subscription renewals." actions={<Button variant="outline" size="sm" icon={Plus}>Add card</Button>}>
        <div className="space-y-2">
          {methods.map((m) => (
            <motion.div
              key={m.id}
              layout
              className="flex items-center gap-3 px-4 py-3 rounded-[10px] border"
              style={{ borderColor: "var(--border)", background: "var(--surface)" }}
            >
              <div
                className="w-10 h-7 rounded-[5px] flex items-center justify-center text-[9px] font-bold text-white"
                style={{ background: m.brand === "VISA" ? "#1A1F71" : "#EB001B" }}
              >
                {m.brand === "VISA" ? "VISA" : "MC"}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-[var(--foreground)]">
                  •••• {m.last4}
                  {m.isDefault && (
                    <span
                      className="ml-2 text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase tracking-wide"
                      style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                    >
                      Default
                    </span>
                  )}
                </p>
                <p className="text-[11px] text-[var(--muted-foreground)] font-mono">Expires {String(m.expMonth).padStart(2, "0")}/{m.expYear}</p>
              </div>
              <button
                type="button"
                className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--loss)] hover:bg-[var(--loss-soft)] transition-colors cursor-pointer focus-ring"
                aria-label="Remove card"
                onClick={() => toast.success("Card removed")}
              >
                <Trash2 size={13} />
              </button>
            </motion.div>
          ))}
        </div>
      </SettingsCard>

      {/* Invoices */}
      <SettingsCard title="Invoice history" description="Download past invoices for your records.">
        <div className="divide-y" style={{ borderColor: "var(--border)" }}>
          {INVOICES.map((inv) => (
            <div key={inv.id} className="flex items-center gap-3 py-3" style={{ borderColor: "var(--border)" }}>
              <div className="w-8 h-8 rounded-[8px] flex items-center justify-center" style={{ background: "var(--surface-hover)" }}>
                <Receipt size={14} className="text-[var(--muted-foreground)]" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-mono text-[var(--foreground)]">{inv.id}</p>
                <p className="text-[11px] text-[var(--muted-foreground)]">{fmtDate(inv.date)}</p>
              </div>
              <span
                className="text-[10px] px-2 py-0.5 rounded-[6px] uppercase tracking-wide font-semibold"
                style={{ background: "var(--gain-soft)", color: "var(--gain)" }}
              >
                {inv.status}
              </span>
              <span className="text-sm font-mono tabular-nums text-[var(--foreground)] w-16 text-right">{fmtUSD(inv.amount)}</span>
              <button
                type="button"
                className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring"
                aria-label="Download invoice"
                onClick={() => toast.success(`Downloading ${inv.id}`)}
              >
                <Download size={13} />
              </button>
            </div>
          ))}
        </div>
      </SettingsCard>
    </div>
  );
}
