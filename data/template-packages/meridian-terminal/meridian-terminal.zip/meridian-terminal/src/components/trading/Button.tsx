"use client";
// ============================================================
// Button — premium button with variants, sizes, loading state.
// Replaces ad-hoc button styling across the app.
// ============================================================
import { forwardRef } from "react";
import { motion, type HTMLMotionProps } from "framer-motion";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "outline" | "danger" | "success";
type Size = "sm" | "md" | "lg" | "icon";

interface ButtonProps extends Omit<HTMLMotionProps<"button">, "ref"> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ComponentType<{ size?: number }>;
  iconRight?: React.ComponentType<{ size?: number }>;
}

const VARIANTS: Record<Variant, string> = {
  primary: "text-white",
  secondary: "text-[var(--foreground)] bg-[var(--surface)] border border-[var(--border)] hover:bg-[var(--surface-hover)]",
  ghost: "text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]",
  outline: "text-[var(--foreground)] border border-[var(--border)] hover:border-[var(--border-strong)] hover:bg-[var(--surface-hover)]",
  danger: "text-white",
  success: "text-white",
};

const SIZES: Record<Size, string> = {
  sm: "h-8 px-3 text-xs gap-1.5 rounded-[8px]",
  md: "h-9 px-4 text-xs gap-2 rounded-[10px]",
  lg: "h-11 px-6 text-sm gap-2 rounded-[12px]",
  icon: "w-9 h-9 rounded-[10px] justify-center",
};

const VARIANT_STYLES: Record<Variant, React.CSSProperties> = {
  primary: { background: "linear-gradient(135deg, var(--accent), var(--accent-hover))", boxShadow: "var(--shadow-glow)" },
  secondary: {},
  ghost: {},
  outline: {},
  danger: { background: "var(--loss)" },
  success: { background: "var(--gain)", color: "var(--background)" },
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", size = "md", loading, icon: Icon, iconRight: IconRight, className, children, disabled, ...props }, ref) => {
    return (
      <motion.button
        ref={ref}
        whileHover={{ scale: disabled || loading ? 1 : 1.02 }}
        whileTap={{ scale: disabled || loading ? 1 : 0.98 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        disabled={disabled || loading}
        className={cn(
          "inline-flex items-center justify-center font-semibold transition-colors focus-ring cursor-pointer",
          "disabled:opacity-50 disabled:cursor-not-allowed",
          VARIANTS[variant],
          SIZES[size],
          className,
        )}
        style={VARIANT_STYLES[variant]}
        {...props}
      >
        {loading ? (
          <Loader2 size={14} className="animate-spin" />
        ) : (
          Icon && <Icon size={14} />
        )}
        {size !== "icon" && (children as React.ReactNode)}
        {IconRight && !loading && <IconRight size={14} />}
      </motion.button>
    );
  },
);
Button.displayName = "Button";
