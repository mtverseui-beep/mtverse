"use client";
// ============================================================
// OrdersPage — full order management. DataTable with sorting,
// filtering, search, pagination, row selection, bulk cancel,
// status filter, and per-row cancel. Real, functional.
// ============================================================
import { useEffect, useMemo, useRef, useState } from "react";
import { type ColumnDef } from "@tanstack/react-table";
import {
  ListOrdered,
  X,
  Download,
  Plus,
  Filter,
  MoreHorizontal,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { useTradingStore } from "@/store/trading-store";
import { DataTable } from "../DataTable";
import { PageHeader } from "../PageHeader";
import { StatCard } from "../StatCard";
import { Button } from "../Button";
import { ModernSelect } from "../ModernSelect";
import {
  fmtPrice,
  fmtQty,
  fmtUSD,
  fmtTime,
  fmtDate,
  deltaColor,
} from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import type { Order, OrderStatus } from "@/lib/trading/types";

interface OrdersPageProps {
  navigate: (path: string) => void;
}

const STATUS_FILTERS: { value: string; label: string }[] = [
  { value: "ALL", label: "All statuses" },
  { value: "WORKING", label: "Working" },
  { value: "PARTIAL", label: "Partial" },
  { value: "FILLED", label: "Filled" },
  { value: "CANCELLED", label: "Cancelled" },
];

const STATUS_STYLES: Record<OrderStatus, { bg: string; color: string }> = {
  WORKING: { bg: "var(--accent-soft)", color: "var(--accent)" },
  PARTIAL: { bg: "rgba(240,185,11,0.12)", color: "#F0B90B" },
  FILLED: { bg: "var(--gain-soft)", color: "var(--gain)" },
  CANCELLED: { bg: "var(--surface-hover)", color: "var(--muted-foreground)" },
  REJECTED: { bg: "var(--loss-soft)", color: "var(--loss)" },
};

export function OrdersPage({ navigate }: OrdersPageProps) {
  const orders = useTradingStore((s) => s.orders);
  const cancel = useTradingStore((s) => s.cancelOrder);
  const [statusFilter, setStatusFilter] = useState("ALL");

  const filtered = useMemo(() => {
    if (statusFilter === "ALL") return orders;
    return orders.filter((o) => o.status === statusFilter);
  }, [orders, statusFilter]);

  const stats = useMemo(() => {
    const working = orders.filter((o) => o.status === "WORKING" || o.status === "PARTIAL").length;
    const filled = orders.filter((o) => o.status === "FILLED").length;
    const cancelled = orders.filter((o) => o.status === "CANCELLED").length;
    const notional = orders
      .filter((o) => o.status === "FILLED" || o.status === "PARTIAL")
      .reduce((a, o) => a + (o.avgFillPrice ?? 0) * o.filledQty, 0);
    return { working, filled, cancelled, notional };
  }, [orders]);

  const columns = useMemo<ColumnDef<Order>[]>(
    () => [
      {
        id: "select",
        size: 32,
        header: ({ table }) => (
          <IndeterminateCheckbox
            checked={table.getIsAllPageRowsSelected()}
            indeterminate={table.getIsSomePageRowsSelected()}
            onChange={table.getToggleAllPageRowsSelectedHandler()}
            aria-label="Select all"
          />
        ),
        cell: ({ row }) => (
          <IndeterminateCheckbox
            checked={row.getIsSelected()}
            onChange={row.getToggleSelectedHandler()}
            aria-label="Select row"
          />
        ),
        enableSorting: false,
        enableHiding: false,
      },
      {
        accessorKey: "id",
        header: "Order ID",
        cell: ({ row }) => (
          <span className="font-mono text-[var(--muted-foreground)] text-[11px]">
            {row.original.id}
          </span>
        ),
      },
      {
        accessorKey: "ticker",
        header: "Symbol",
        cell: ({ row }) => (
          <span className="font-semibold text-[var(--foreground)]">
            {row.original.ticker}
          </span>
        ),
      },
      {
        accessorKey: "side",
        header: "Side",
        cell: ({ row }) => (
          <span
            className={cn(
              "font-mono font-semibold text-[11px] px-1.5 py-0.5 rounded-[4px]",
            )}
            style={{
              background: row.original.side === "BUY" ? "var(--gain-soft)" : "var(--loss-soft)",
              color: row.original.side === "BUY" ? "var(--gain)" : "var(--loss)",
            }}
          >
            {row.original.side}
          </span>
        ),
      },
      {
        accessorKey: "type",
        header: "Type",
        cell: ({ row }) => (
          <span className="text-[var(--muted-foreground)] font-mono text-[11px]">
            {row.original.type.replace("_", " ")}
          </span>
        ),
      },
      {
        accessorKey: "qty",
        header: "Qty",
        cell: ({ row }) => (
          <span className="font-mono tabular-nums text-[var(--foreground)]">
            {row.original.filledQty > 0 ? (
              <>
                {fmtQty(row.original.filledQty)}/<span className="text-[var(--muted-foreground)]">{fmtQty(row.original.qty)}</span>
              </>
            ) : (
              fmtQty(row.original.qty)
            )}
          </span>
        ),
      },
      {
        id: "price",
        header: "Limit / Stop",
        cell: ({ row }) => (
          <span className="font-mono tabular-nums text-[var(--foreground)]">
            {row.original.limitPrice
              ? fmtPrice(row.original.limitPrice)
              : row.original.stopPrice
                ? `STOP ${fmtPrice(row.original.stopPrice)}`
                : "MKT"}
          </span>
        ),
      },
      {
        accessorKey: "avgFillPrice",
        header: "Avg Fill",
        cell: ({ row }) => (
          <span className="font-mono tabular-nums text-[var(--foreground)]">
            {row.original.avgFillPrice ? fmtPrice(row.original.avgFillPrice) : "—"}
          </span>
        ),
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
          const s = STATUS_STYLES[row.original.status];
          return (
            <span
              className="text-[10px] px-2 py-0.5 rounded-[6px] uppercase tracking-wide font-semibold"
              style={{ background: s.bg, color: s.color }}
            >
              {row.original.status}
            </span>
          );
        },
      },
      {
        accessorKey: "createdAt",
        header: "Created",
        cell: ({ row }) => (
          <div className="text-[var(--muted-foreground)] font-mono text-[11px]">
            <div>{fmtDate(row.original.createdAt)}</div>
            <div className="text-[10px] opacity-70">{fmtTime(row.original.createdAt)}</div>
          </div>
        ),
      },
      {
        id: "actions",
        header: "",
        size: 48,
        enableSorting: false,
        enableHiding: false,
        cell: ({ row }) => {
          const isWorking = row.original.status === "WORKING" || row.original.status === "PARTIAL";
          return (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring"
                  aria-label="Row actions"
                >
                  <MoreHorizontal size={14} />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="w-40 font-sans"
                style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "10px", boxShadow: "var(--shadow-lg)" }}
              >
                <DropdownMenuItem className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[6px] mx-1 text-xs gap-2" onClick={() => navigate(`terminal`)}>
                  View chart
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="cursor-pointer focus:bg-[var(--surface-hover)] rounded-[6px] mx-1 text-xs gap-2"
                  onClick={() => toast.info("Order ticket", { description: `Modify ${row.original.id} — reprice or resize.` })}
                >
                  Modify
                </DropdownMenuItem>
                {isWorking && (
                  <>
                    <DropdownMenuSeparator style={{ background: "var(--border)" }} />
                    <DropdownMenuItem
                      className="cursor-pointer focus:bg-[var(--loss-soft)] rounded-[6px] mx-1 text-xs gap-2 text-[var(--loss)]"
                      onClick={() => {
                        cancel(row.original.id);
                        toast.success(`Order ${row.original.id} cancelled`);
                      }}
                    >
                      Cancel order
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          );
        },
      },
    ],
    [cancel, navigate],
  );

  return (
    <div>
      <PageHeader
        title="Orders"
        description="Manage all working, partial, filled and cancelled orders across your account. Filter by status, search by symbol, and cancel in bulk."
        breadcrumbs={[{ label: "Terminal", onClick: () => navigate("") }, { label: "Orders" }]}
        actions={
          <>
            <Button variant="outline" size="md" icon={Download} onClick={() => toast.success("Export started", { description: "Orders CSV will download shortly." })}>
              <span className="hidden sm:inline">Export</span>
            </Button>
            <Button variant="primary" size="md" icon={Plus} onClick={() => navigate("")}>
              <span className="hidden sm:inline">New order</span>
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Working" value={String(stats.working)} icon={ListOrdered} accent />
        <StatCard label="Filled today" value={String(stats.filled)} icon={ListOrdered} />
        <StatCard label="Cancelled" value={String(stats.cancelled)} icon={X} />
        <StatCard label="Filled Notional" value={fmtUSD(stats.notional, { compact: true })} icon={ListOrdered} />
      </div>

      <DataTable
        columns={columns}
        data={filtered}
        searchPlaceholder="Search by symbol or order ID…"
        searchKeys={["ticker", "id"]}
        getRowId={(o) => o.id}
        filters={
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-[var(--muted-foreground)]">
              <Filter size={14} />
            </div>
            <div className="w-[160px]">
              <ModernSelect
                value={statusFilter}
                onValueChange={setStatusFilter}
                ariaLabel="Filter by status"
                size="sm"
                options={STATUS_FILTERS}
              />
            </div>
          </div>
        }
        bulkActions={(selected, clear) => (
          <>
            <Button
              variant="danger"
              size="sm"
              icon={X}
              onClick={() => {
                selected.forEach((o) => cancel(o.id));
                toast.success(`${selected.length} order(s) cancelled`);
                clear();
              }}
            >
              Cancel selected
            </Button>
            <Button variant="ghost" size="sm" onClick={clear}>
              Clear
            </Button>
          </>
        )}
        emptyState={{
          icon: ListOrdered,
          title: "No orders found",
          description: "Try adjusting your filters or create a new order from the terminal.",
        }}
        pageSize={10}
      />
    </div>
  );
}

/** Checkbox that properly supports the `indeterminate` state via ref. */
function IndeterminateCheckbox({
  checked,
  indeterminate,
  onChange,
  "aria-label": ariaLabel,
}: {
  checked: boolean;
  indeterminate?: boolean;
  onChange: (e: unknown) => void;
  "aria-label"?: string;
}) {
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.indeterminate = !!indeterminate;
  }, [indeterminate]);
  return (
    <input
      ref={ref}
      type="checkbox"
      checked={checked}
      onChange={onChange as React.ChangeEventHandler<HTMLInputElement>}
      className="w-3.5 h-3.5 rounded cursor-pointer accent-[var(--accent)]"
      aria-label={ariaLabel}
    />
  );
}
