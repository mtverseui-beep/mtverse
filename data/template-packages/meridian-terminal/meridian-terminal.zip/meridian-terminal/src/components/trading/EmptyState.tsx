"use client";
// ============================================================
// EmptyState — beautiful empty state with illustration, title,
// description, primary + secondary actions.
// ============================================================
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface EmptyStateProps {
  icon: React.ComponentType<{ size?: number; className?: string; style?: React.CSSProperties }>;
  title: string;
  description: string;
  primaryAction?: { label: string; onClick: () => void };
  secondaryAction?: { label: string; onClick: () => void };
  className?: string;
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  primaryAction,
  secondaryAction,
  className,
}: EmptyStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={cn("flex flex-col items-center justify-center py-16 px-6 text-center", className)}
    >
      <div
        className="w-16 h-16 rounded-[18px] flex items-center justify-center mb-4 relative overflow-hidden"
        style={{ background: "var(--accent-soft)" }}
      >
        <div
          className="absolute inset-0 opacity-40"
          style={{ background: "radial-gradient(circle at 30% 30%, var(--accent-glow), transparent 70%)" }}
        />
        <Icon size={26} className="relative" />
        <span style={{ color: "var(--accent)" }} />
      </div>
      <h3 className="text-base font-semibold text-[var(--foreground)]">{title}</h3>
      <p className="text-sm text-[var(--muted-foreground)] mt-1.5 max-w-sm leading-relaxed">
        {description}
      </p>
      {(primaryAction || secondaryAction) && (
        <div className="flex items-center gap-2 mt-5">
          {secondaryAction && (
            <button
              type="button"
              onClick={secondaryAction.onClick}
              className="px-4 py-2 text-xs font-medium rounded-[10px] border hover:bg-[var(--surface-hover)] transition-colors cursor-pointer focus-ring"
              style={{ borderColor: "var(--border)", color: "var(--foreground)" }}
            >
              {secondaryAction.label}
            </button>
          )}
          {primaryAction && (
            <button
              type="button"
              onClick={primaryAction.onClick}
              className="px-4 py-2 text-xs font-semibold rounded-[10px] text-white transition-all hover:brightness-110 cursor-pointer focus-ring"
              style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-hover))", boxShadow: "var(--shadow-glow)" }}
            >
              {primaryAction.label}
            </button>
          )}
        </div>
      )}
    </motion.div>
  );
}
