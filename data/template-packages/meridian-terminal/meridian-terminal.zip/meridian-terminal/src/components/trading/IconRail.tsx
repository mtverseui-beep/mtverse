"use client";
// ============================================================
// IconRail — 72px premium rail. Nav items navigate via hash routes.
// ============================================================
import {
  LayoutDashboard,
  Wallet,
  ListOrdered,
  Bell,
  History,
  Settings,
  Command,
} from "lucide-react";
import { motion } from "framer-motion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import type { Route } from "@/hooks/use-hash-route";

interface IconRailProps {
  route: Route;
  navigate: (path: string) => void;
  onOpenCommand: () => void;
}

const NAV: { path: string; label: string; icon: React.ComponentType<{ size?: number; className?: string }> }[] = [
  { path: "", label: "Terminal", icon: LayoutDashboard },
  { path: "portfolio", label: "Portfolio", icon: Wallet },
  { path: "orders", label: "Orders", icon: ListOrdered },
  { path: "alerts", label: "Alerts", icon: Bell },
  { path: "history", label: "History", icon: History },
  { path: "settings", label: "Settings", icon: Settings },
];

export function IconRail({ route, navigate, onOpenCommand }: IconRailProps) {
  const currentTop = route.segments[0] ?? "";

  return (
    <TooltipProvider delayDuration={200}>
      <motion.aside
        initial={false}
        className="w-[72px] shrink-0 border-r flex flex-col items-center py-4 gap-1.5 relative z-10"
        style={{
          background: "var(--surface)",
          borderColor: "var(--border)",
        }}
        aria-label="Primary navigation"
      >
        <motion.button
          type="button"
          whileHover={{ scale: 1.06 }}
          whileTap={{ scale: 0.94 }}
          onClick={() => navigate("")}
          className="mb-4 cursor-pointer focus-ring rounded-[12px] relative"
          aria-label="Meridian Terminal home"
        >
          <img
            src="/logo.svg?v=2"
            alt="Meridian Terminal"
            width={32}
            height={32}
            style={{ display: "block", filter: "drop-shadow(0 4px 12px rgba(108,92,231,0.35))" }}
          />
        </motion.button>

        <nav className="flex flex-col gap-1.5 flex-1 w-full items-center" role="navigation">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = currentTop === item.path;
            return (
              <Tooltip key={item.path}>
                <TooltipTrigger asChild>
                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigate(item.path)}
                    aria-label={item.label}
                    aria-current={active ? "page" : undefined}
                    className={cn(
                      "w-12 h-12 rounded-[12px] flex items-center justify-center transition-colors focus-ring relative cursor-pointer",
                      active
                        ? "text-white"
                        : "text-[var(--muted-foreground)] hover:text-[var(--foreground)] hover:bg-[var(--surface-hover)]",
                    )}
                    style={
                      active
                        ? {
                            background: "linear-gradient(135deg, var(--accent), var(--accent-hover))",
                            boxShadow: "var(--shadow-glow)",
                          }
                        : undefined
                    }
                  >
                    <Icon size={18} />
                  </motion.button>
                </TooltipTrigger>
                <TooltipContent
                  side="right"
                  sideOffset={12}
                  className="font-sans text-xs"
                  style={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    color: "var(--foreground)",
                    borderRadius: "8px",
                    boxShadow: "var(--shadow-md)",
                  }}
                >
                  {item.label}
                </TooltipContent>
              </Tooltip>
            );
          })}
        </nav>

        <Tooltip>
          <TooltipTrigger asChild>
            <motion.button
              type="button"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onOpenCommand}
              aria-label="Command bar (Cmd K)"
              className="w-12 h-12 rounded-[12px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--accent)] hover:bg-[var(--accent-soft)] transition-colors focus-ring cursor-pointer"
            >
              <Command size={18} />
            </motion.button>
          </TooltipTrigger>
          <TooltipContent
            side="right"
            sideOffset={12}
            className="font-sans text-xs"
            style={{
              background: "var(--popover)",
              border: "1px solid var(--border)",
              color: "var(--foreground)",
              borderRadius: "8px",
              boxShadow: "var(--shadow-md)",
            }}
          >
            <span className="font-mono">⌘K</span> · Jump to symbol
          </TooltipContent>
        </Tooltip>
      </motion.aside>
    </TooltipProvider>
  );
}
