"use client";
// SecuritySettings — 2FA, password, active sessions, login history.
import { useState } from "react";
import { Shield, Smartphone, Monitor, LogOut, Key, Eye, EyeOff, Check } from "lucide-react";
import { SettingsCard, Toggle, SettingRow } from "./_shared";
import { Button } from "../../Button";
import { Field, Input } from "../../Field";
import { fmtRelative } from "@/lib/trading/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const SESSIONS = [
  { id: "s1", device: "MacBook Pro · Chrome", location: "San Francisco, CA", ip: "73.158.42.10", current: true, lastActive: Date.now() },
  { id: "s2", device: "iPhone 15 · Safari", location: "San Francisco, CA", ip: "73.158.42.11", current: false, lastActive: Date.now() - 3600000 },
  { id: "s3", device: "iPad · Safari", location: "New York, NY", ip: "108.29.84.221", current: false, lastActive: Date.now() - 86400000 * 2 },
];

const LOGIN_HISTORY = [
  { id: "l1", device: "MacBook Pro · Chrome", location: "San Francisco, CA", time: Date.now() - 60000, success: true },
  { id: "l2", device: "iPhone 15 · Safari", location: "San Francisco, CA", time: Date.now() - 3600000, success: true },
  { id: "l3", device: "Unknown · Firefox", location: "Moscow, RU", time: Date.now() - 86400000, success: false },
  { id: "l4", device: "MacBook Pro · Chrome", location: "San Francisco, CA", time: Date.now() - 86400000 * 2, success: true },
];

export function SecuritySettings() {
  const [twoFA, setTwoFA] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [sessions, setSessions] = useState(SESSIONS);

  const changePassword = () => {
    if (newPw.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    if (newPw !== confirmPw) {
      toast.error("Passwords don't match");
      return;
    }
    toast.success("Password changed");
    setCurrentPw(""); setNewPw(""); setConfirmPw("");
  };

  const revokeSession = (id: string) => {
    setSessions((arr) => arr.filter((s) => s.id !== id));
    toast.success("Session revoked");
  };

  return (
    <div className="space-y-4">
      <SettingsCard title="Two-factor authentication" description="Add an extra layer of security with an authenticator app.">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[10px] flex items-center justify-center" style={{ background: twoFA ? "var(--gain-soft)" : "var(--surface-hover)", color: twoFA ? "var(--gain)" : "var(--muted-foreground)" }}>
              <Smartphone size={18} />
            </div>
            <div>
              <p className="text-sm font-medium text-[var(--foreground)] flex items-center gap-2">
                Authenticator app
                {twoFA && <span className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: "var(--gain-soft)", color: "var(--gain)" }}>Enabled</span>}
              </p>
              <p className="text-xs text-[var(--muted-foreground)] mt-0.5">{twoFA ? "Protected via Google Authenticator" : "Not enabled — your account is at risk"}</p>
            </div>
          </div>
          <Button variant={twoFA ? "outline" : "primary"} size="md" onClick={() => { setTwoFA(!twoFA); toast.success(twoFA ? "2FA disabled" : "2FA enabled"); }}>
            {twoFA ? "Disable" : "Enable"}
          </Button>
        </div>
      </SettingsCard>

      <SettingsCard title="Change password" description="Use a strong, unique password. Minimum 8 characters.">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Field label="Current password" required>
            <Input
              type={showPassword ? "text" : "password"}
              value={currentPw}
              onChange={(e) => setCurrentPw(e.target.value)}
              trailing={
                <button type="button" onClick={() => setShowPassword((v) => !v)} className="cursor-pointer focus-ring" aria-label="Toggle password visibility">
                  {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              }
            />
          </Field>
          <Field label="New password" required>
            <Input type={showPassword ? "text" : "password"} value={newPw} onChange={(e) => setNewPw(e.target.value)} />
          </Field>
          <Field label="Confirm new password" required>
            <Input type={showPassword ? "text" : "password"} value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} />
          </Field>
        </div>
        <div className="flex items-center justify-end mt-4">
          <Button variant="primary" size="md" icon={Key} onClick={changePassword}>Update password</Button>
        </div>
      </SettingsCard>

      <SettingsCard title="Active sessions" description="Devices currently signed in to your account. Revoke any you don't recognize.">
        <div className="space-y-2">
          {sessions.map((s) => (
            <div key={s.id} className="flex items-center gap-3 px-4 py-3 rounded-[10px] border" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
              <div className="w-9 h-9 rounded-[8px] flex items-center justify-center shrink-0" style={{ background: "var(--surface-hover)", color: "var(--muted-foreground)" }}>
                <Monitor size={15} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[var(--foreground)] flex items-center gap-2">
                  {s.device}
                  {s.current && <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold uppercase" style={{ background: "var(--gain-soft)", color: "var(--gain)" }}>Current</span>}
                </p>
                <p className="text-[11px] text-[var(--muted-foreground)] font-mono">{s.location} · {s.ip} · {fmtRelative(s.lastActive)}</p>
              </div>
              {!s.current && (
                <Button variant="ghost" size="sm" icon={LogOut} onClick={() => revokeSession(s.id)}>Revoke</Button>
              )}
            </div>
          ))}
        </div>
      </SettingsCard>

      <SettingsCard title="Login history" description="Recent attempts to access your account.">
        <div className="space-y-1">
          {LOGIN_HISTORY.map((l) => (
            <div key={l.id} className="flex items-center gap-3 px-3 py-2.5 rounded-[8px] hover:bg-[var(--surface-hover)] transition-colors">
              <div
                className="w-2 h-2 rounded-full shrink-0"
                style={{ background: l.success ? "var(--gain)" : "var(--loss)" }}
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-[var(--foreground)]">{l.device}</p>
                <p className="text-[10px] text-[var(--muted-foreground)] font-mono">{l.location} · {fmtRelative(l.time)}</p>
              </div>
              <span
                className="text-[10px] px-1.5 py-0.5 rounded-full font-semibold uppercase"
                style={{ background: l.success ? "var(--gain-soft)" : "var(--loss-soft)", color: l.success ? "var(--gain)" : "var(--loss)" }}
              >
                {l.success ? "Success" : "Blocked"}
              </span>
            </div>
          ))}
        </div>
      </SettingsCard>
    </div>
  );
}
