"use client";
// ApiSettings — API keys, webhooks, rate limits.
import { useState } from "react";
import { Key, Plus, Copy, Trash2, Eye, EyeOff, Webhook, Zap } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SettingsCard } from "./_shared";
import { Button } from "../../Button";
import { Field, Input } from "../../Field";
import { ModernSelect } from "../../ModernSelect";
import { StatCard } from "../../StatCard";
import { toast } from "sonner";

interface ApiKey {
  id: string;
  name: string;
  key: string;
  createdAt: number;
  lastUsed: number;
  scopes: string[];
}

const INITIAL_KEYS: ApiKey[] = [
  { id: "k1", name: "Production bot", key: "mr_live_4f92a1b8c3d9e7f0a2b1c4d5", createdAt: Date.now() - 86400000 * 30, lastUsed: Date.now() - 60000, scopes: ["trade", "read"] },
  { id: "k2", name: "Analytics read-only", key: "mr_live_8a3b2c1d4e5f6a7b8c9d0e1f", createdAt: Date.now() - 86400000 * 90, lastUsed: Date.now() - 3600000, scopes: ["read"] },
];

const WEBHOOKS = [
  { id: "w1", url: "https://hooks.meridian.io/orders", events: ["order.filled", "order.cancelled"], active: true },
  { id: "w2", url: "https://analytics.internal/trades", events: ["trade.executed"], active: true },
];

export function ApiSettings() {
  const [keys, setKeys] = useState<ApiKey[]>(INITIAL_KEYS);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [createOpen, setCreateOpen] = useState(false);
  const [newKeyName, setNewKeyName] = useState("");
  const [newKeyScopes, setNewKeyScopes] = useState<string[]>(["read"]);

  const mask = (k: string) => `${k.slice(0, 8)}${"•".repeat(16)}${k.slice(-4)}`;

  const createKey = () => {
    if (!newKeyName.trim()) {
      toast.error("Key name is required");
      return;
    }
    const newKey: ApiKey = {
      id: `k-${Date.now()}`,
      name: newKeyName,
      key: `mr_live_${Math.random().toString(36).slice(2, 10)}${Math.random().toString(36).slice(2, 18)}`,
      createdAt: Date.now(),
      lastUsed: 0,
      scopes: newKeyScopes,
    };
    setKeys((arr) => [...arr, newKey]);
    setRevealed((r) => ({ ...r, [newKey.id]: true }));
    toast.success(`API key "${newKeyName}" created`);
    setNewKeyName("");
    setNewKeyScopes(["read"]);
    setCreateOpen(false);
  };

  const deleteKey = (id: string) => {
    setKeys((arr) => arr.filter((k) => k.id !== id));
    toast.success("API key revoked");
  };

  const copyKey = (key: string) => {
    navigator.clipboard?.writeText(key);
    toast.success("Copied to clipboard");
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="API calls (24h)" value="12.4K" delta="+8%" deltaDirection="up" icon={Zap} accent />
        <StatCard label="Rate limit" value="50K / day" icon={Key} />
        <StatCard label="Active keys" value={String(keys.length)} icon={Key} />
        <StatCard label="Webhooks" value={String(WEBHOOKS.length)} icon={Webhook} />
      </div>

      <SettingsCard title="API keys" description="Use API keys to authenticate programmatic access to your Meridian account.">
        <div className="flex items-center justify-between mb-4">
          <p className="text-xs text-[var(--muted-foreground)]">{keys.length} keys</p>
          <Button variant="primary" size="md" icon={Plus} onClick={() => setCreateOpen(true)}>
            Generate key
          </Button>
        </div>
        <div className="space-y-2">
          <AnimatePresence initial={false}>
            {keys.map((k) => (
              <motion.div
                key={k.id}
                layout
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0 }}
                className="flex items-center gap-3 px-4 py-3 rounded-[10px] border"
                style={{ borderColor: "var(--border)", background: "var(--surface)" }}
              >
                <div className="w-9 h-9 rounded-[8px] flex items-center justify-center shrink-0" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                  <Key size={15} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-[var(--foreground)]">{k.name}</p>
                    {k.scopes.map((s) => (
                      <span key={s} className="text-[9px] px-1.5 py-0.5 rounded-full font-mono uppercase" style={{ background: "var(--surface-hover)", color: "var(--muted-foreground)" }}>
                        {s}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <code className="text-[11px] font-mono text-[var(--muted-foreground)]">
                      {revealed[k.id] ? k.key : mask(k.key)}
                    </code>
                    <button
                      type="button"
                      onClick={() => setRevealed((r) => ({ ...r, [k.id]: !r[k.id] }))}
                      className="text-[var(--muted-foreground)] hover:text-[var(--foreground)] cursor-pointer focus-ring rounded-[4px] p-0.5"
                      aria-label={revealed[k.id] ? "Hide key" : "Show key"}
                    >
                      {revealed[k.id] ? <EyeOff size={12} /> : <Eye size={12} />}
                    </button>
                    <button
                      type="button"
                      onClick={() => copyKey(k.key)}
                      className="text-[var(--muted-foreground)] hover:text-[var(--foreground)] cursor-pointer focus-ring rounded-[4px] p-0.5"
                      aria-label="Copy key"
                    >
                      <Copy size={12} />
                    </button>
                  </div>
                </div>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button
                      type="button"
                      className="w-7 h-7 rounded-[6px] flex items-center justify-center text-[var(--muted-foreground)] hover:text-[var(--loss)] hover:bg-[var(--loss-soft)] transition-colors cursor-pointer focus-ring"
                      aria-label="Revoke key"
                    >
                      <Trash2 size={13} />
                    </button>
                  </AlertDialogTrigger>
                  <AlertDialogContent style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)" }}>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Revoke API key "{k.name}"?</AlertDialogTitle>
                      <AlertDialogDescription className="text-[var(--muted-foreground)]">
                        Any application using this key will lose access immediately. This cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel style={{ background: "var(--surface)", border: "1px solid var(--border)", color: "var(--foreground)" }}>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => deleteKey(k.id)} style={{ background: "var(--loss)", color: "#fff" }}>Revoke</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </SettingsCard>

      <SettingsCard title="Webhooks" description="Receive real-time HTTP callbacks for trading events.">
        <div className="space-y-2">
          {WEBHOOKS.map((w) => (
            <div key={w.id} className="flex items-center gap-3 px-4 py-3 rounded-[10px] border" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
              <div className="w-9 h-9 rounded-[8px] flex items-center justify-center shrink-0" style={{ background: "var(--surface-hover)", color: "var(--muted-foreground)" }}>
                <Webhook size={15} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-mono text-[var(--foreground)] truncate">{w.url}</p>
                <div className="flex items-center gap-1 mt-1">
                  {w.events.map((e) => (
                    <span key={e} className="text-[9px] px-1.5 py-0.5 rounded-full font-mono" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
                      {e}
                    </span>
                  ))}
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase" style={{ background: w.active ? "var(--gain-soft)" : "var(--surface-hover)", color: w.active ? "var(--gain)" : "var(--muted-foreground)" }}>
                {w.active ? "Active" : "Paused"}
              </span>
            </div>
          ))}
        </div>
      </SettingsCard>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="font-sans max-w-md p-0 gap-0" style={{ background: "var(--popover)", border: "1px solid var(--border)", color: "var(--foreground)", borderRadius: "16px", boxShadow: "var(--shadow-xl)" }}>
          <DialogHeader className="px-5 pt-5 pb-3">
            <DialogTitle className="text-base font-semibold">Generate API key</DialogTitle>
          </DialogHeader>
          <div className="px-5 pb-5 space-y-4">
            <Field label="Key name" required>
              <Input placeholder="e.g. Production bot" value={newKeyName} onChange={(e) => setNewKeyName(e.target.value)} />
            </Field>
            <Field label="Scopes" description="Choose what this key can access.">
              <div className="flex flex-wrap gap-2">
                {["read", "trade", "withdraw", "admin"].map((s) => {
                  const active = newKeyScopes.includes(s);
                  return (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setNewKeyScopes((arr) => active ? arr.filter((x) => x !== s) : [...arr, s])}
                      className="px-3 py-1.5 text-xs font-medium rounded-[8px] border cursor-pointer transition-colors focus-ring capitalize"
                      style={{
                        borderColor: active ? "var(--accent)" : "var(--border)",
                        background: active ? "var(--accent-soft)" : "var(--surface)",
                        color: active ? "var(--accent)" : "var(--muted-foreground)",
                      }}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
            </Field>
            <div className="flex items-center justify-end gap-2 pt-2">
              <Button variant="outline" size="md" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button variant="primary" size="md" icon={Key} onClick={createKey}>Generate</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
