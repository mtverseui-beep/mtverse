"use client";
// ============================================================
// Watchlist — left column. Click to swap main chart's symbol.
// Right-click opens context menu: Buy / Sell / Set alert / Remove.
// Full keyboard navigation (arrow keys + Enter).
// ============================================================
import { useEffect, useRef, useState } from "react";
import { Search, Plus } from "lucide-react";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import { useTradingStore } from "@/store/trading-store";
import { fmtPrice, fmtPct, fmtCompact, deltaColor } from "@/lib/trading/format";
import { PriceCell } from "./PriceCell";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function Watchlist() {
  const symbols = useTradingStore((s) => s.symbols);
  const quotes = useTradingStore((s) => s.quotes);
  const selected = useTradingStore((s) => s.selectedTicker);
  const select = useTradingStore((s) => s.select);
  const remove = useTradingStore((s) => s.removeFromWatchlist);
  const setQuickOrder = useTradingStore((s) => s.setQuickOrder);

  const [filter, setFilter] = useState("");
  const [activeIdx, setActiveIdx] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);

  const filtered = symbols.filter(
    (s) =>
      s.ticker.toLowerCase().includes(filter.toLowerCase()) ||
      s.name.toLowerCase().includes(filter.toLowerCase()),
  );

  // Clamp active index to the filtered range at render time.
  // (Adjusting-state-during-render pattern; React recommends this over
  // an effect for keeping derived state in sync.)
  const safeActiveIdx = Math.min(activeIdx, Math.max(0, filtered.length - 1));
  if (safeActiveIdx !== activeIdx) {
    setActiveIdx(safeActiveIdx);
  }

  // Keyboard nav
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // Only handle if the list area or its children have focus
      const root = listRef.current;
      if (!root) return;
      const rootHasFocus = root.contains(document.activeElement) || document.activeElement === root;
      if (!rootHasFocus) return;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveIdx((i) => Math.min(i + 1, filtered.length - 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveIdx((i) => Math.max(i - 1, 0));
      } else if (e.key === "Enter") {
        e.preventDefault();
        const sym = filtered[safeActiveIdx];
        if (sym) select(sym.ticker);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [filtered, safeActiveIdx, select]);

  // Scroll active row into view
  useEffect(() => {
    const root = listRef.current;
    if (!root) return;
    const el = root.querySelector<HTMLElement>(`[data-idx="${safeActiveIdx}"]`);
    el?.scrollIntoView({ block: "nearest" });
  }, [safeActiveIdx]);

  const onBuy = (ticker: string) => {
    const q = quotes[ticker];
    setQuickOrder({ ticker, side: "BUY", price: q?.ask ?? 0, qty: 100 });
    select(ticker);
    toast.success(`Quick-buy form prefilled for ${ticker}`);
  };
  const onSell = (ticker: string) => {
    const q = quotes[ticker];
    setQuickOrder({ ticker, side: "SELL", price: q?.bid ?? 0, qty: 100 });
    select(ticker);
    toast.success(`Quick-sell form prefilled for ${ticker}`);
  };
  const onAlert = (ticker: string) => {
    toast.info(`Alert rule queued for ${ticker}`, {
      description: "We'll notify you when price crosses your threshold.",
    });
  };
  const onRemove = (ticker: string) => {
    remove(ticker);
    if (selected === ticker && symbols.length > 1) {
      const next = symbols.find((s) => s.ticker !== ticker);
      if (next) select(next.ticker);
    }
    toast.success(`${ticker} removed from watchlist`);
  };

  return (
    <section
      className="flex flex-col h-full overflow-hidden"
      style={{ background: "var(--surface)" }}
      aria-label="Watchlist"
    >
      {/* Header */}
      <header className="px-3 pt-3 pb-2 border-b" style={{ borderColor: "var(--border)" }}>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xs font-semibold tracking-wider uppercase text-[var(--muted-foreground)]">
            Watchlist
          </h2>
          <button
            type="button"
            className="text-[var(--muted-foreground)] hover:text-[var(--foreground)] p-1 rounded-[6px] hover:bg-[var(--surface-elevated)] focus-ring"
            aria-label="Add symbol"
            title="Add symbol"
          >
            <Plus size={14} />
          </button>
        </div>
        <div className="relative">
          <Search
            size={12}
            className="absolute left-2 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]"
          />
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Filter symbols…"
            aria-label="Filter watchlist"
            className="w-full pl-7 pr-2 py-1.5 text-xs rounded-[6px] bg-[var(--background)] border focus-ring outline-none placeholder:text-[var(--muted-foreground)] text-[var(--foreground)]"
            style={{ borderColor: "var(--border)" }}
          />
        </div>
      </header>

      {/* Column header */}
      <div
        className="grid grid-cols-[1fr_auto_auto] gap-2 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted-foreground)] border-b"
        style={{ borderColor: "var(--border)" }}
      >
        <span>Symbol</span>
        <span className="text-right">Last</span>
        <span className="text-right w-16">Chg%</span>
      </div>

      {/* Rows */}
      <div
        ref={listRef}
        tabIndex={0}
        role="listbox"
        aria-label="Watchlist symbols"
        className="flex-1 overflow-y-auto outline-none"
      >
        {filtered.map((sym, i) => {
          const q = quotes[sym.ticker];
          if (!q) return null;
          const change = q.price - q.prevClose;
          const changePct = (change / q.prevClose) * 100;
          const active = sym.ticker === selected;
          const kbActive = i === safeActiveIdx;
          return (
            <ContextMenu key={sym.ticker}>
              <ContextMenuTrigger asChild>
                <button
                  type="button"
                  data-idx={i}
                  onClick={() => select(sym.ticker)}
                  role="option"
                  aria-selected={active}
                  className={cn(
                    "w-full grid grid-cols-[1fr_auto_auto] gap-2 px-3 py-2 text-left border-b border-l-2 transition-colors",
                    active
                      ? "bg-[var(--surface-elevated)]"
                      : "hover:bg-[var(--surface-hover)]",
                  )}
                  style={{
                    borderColor: "var(--border)",
                    borderLeftColor: active ? "var(--accent)" : "transparent",
                  }}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={cn(
                          "text-xs font-semibold",
                          active ? "text-[var(--accent)]" : "text-[var(--foreground)]",
                        )}
                      >
                        {sym.ticker}
                      </span>
                      {kbActive && (
                        <span
                          className="text-[9px] px-1 py-px rounded-[3px] font-mono"
                          style={{
                            background: "var(--accent-soft)",
                            color: "var(--accent)",
                          }}
                        >
                          ↕
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-[var(--muted-foreground)] truncate">
                      {sym.name}
                    </div>
                  </div>
                  <div className="text-right">
                    <PriceCell
                      value={q.price}
                      format={(n) => fmtPrice(n)}
                      className="text-xs text-[var(--foreground)]"
                    />
                    <div className="text-[9px] text-[var(--muted-foreground)] font-mono">
                      Vol {fmtCompact(q.volume)}
                    </div>
                  </div>
                  <div
                    className={cn(
                      "text-right text-xs font-mono tabular-nums self-center w-16",
                      deltaColor(change),
                    )}
                  >
                    {fmtPct(changePct)}
                  </div>
                </button>
              </ContextMenuTrigger>
              <ContextMenuContent
                className="w-48 font-sans text-xs"
                style={{
                  background: "var(--surface-elevated)",
                  border: "1px solid var(--border)",
                  color: "var(--foreground)",
                }}
              >
                <ContextMenuItem
                  onSelect={() => onBuy(sym.ticker)}
                  className="focus:bg-[var(--surface-hover)] focus:text-[var(--foreground)] cursor-pointer"
                >
                  <span className="font-mono text-[var(--gain)] mr-2">B</span> Buy {sym.ticker}
                </ContextMenuItem>
                <ContextMenuItem
                  onSelect={() => onSell(sym.ticker)}
                  className="focus:bg-[var(--surface-hover)] focus:text-[var(--foreground)] cursor-pointer"
                >
                  <span className="font-mono text-[var(--loss)] mr-2">S</span> Sell {sym.ticker}
                </ContextMenuItem>
                <ContextMenuItem
                  onSelect={() => onAlert(sym.ticker)}
                  className="focus:bg-[var(--surface-hover)] focus:text-[var(--foreground)] cursor-pointer"
                >
                  <span className="font-mono text-[var(--muted-foreground)] mr-2">!</span> Set alert…
                </ContextMenuItem>
                <ContextMenuSeparator style={{ background: "var(--border)" }} />
                <ContextMenuItem
                  onSelect={() => onRemove(sym.ticker)}
                  className="focus:bg-[var(--surface-hover)] focus:text-[var(--loss)] cursor-pointer text-[var(--loss)]"
                >
                  <span className="font-mono mr-2">×</span> Remove from watchlist
                </ContextMenuItem>
              </ContextMenuContent>
            </ContextMenu>
          );
        })}
        {filtered.length === 0 && (
          <div className="px-3 py-8 text-center text-xs text-[var(--muted-foreground)]">
            No symbols match &ldquo;{filter}&rdquo;
          </div>
        )}
      </div>
    </section>
  );
}
