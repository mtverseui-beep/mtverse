"use client";
// ============================================================
// BrandMark — the Meridian logo + wordmark. Used in the top bar,
// loading screen, and anywhere the full brand lockup appears.
// Renders the SVG icon at the requested size and pairs it with
// a typeset "Meridian / Terminal" wordmark.
// ============================================================
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/** Bump this when the logo SVG changes to bust browser caches. */
export const LOGO_VERSION = "2";
export const LOGO_SRC = `/logo.svg?v=${LOGO_VERSION}`;

interface BrandMarkProps {
  /** Icon size in px. */
  size?: number;
  /** Show the wordmark next to the icon. */
  showWordmark?: boolean;
  /** Stack the wordmark (Meridian / TERMINAL) instead of inline. */
  stacked?: boolean;
  /** Make the whole lockup clickable as a link/button. */
  onClick?: () => void;
  className?: string;
}

export function BrandMark({
  size = 28,
  showWordmark = true,
  stacked = true,
  onClick,
  className,
}: BrandMarkProps) {
  const content = (
    <div className={cn("flex items-center gap-2.5 shrink-0", className)}>
      <img
        src={LOGO_SRC}
        alt="Meridian Terminal"
        width={size}
        height={size}
        className="shrink-0"
        style={{ display: "block" }}
      />
      {showWordmark && (
        <div className={cn("flex leading-none", stacked ? "flex-col" : "flex-row items-baseline gap-1.5")}>
          <span
            className="font-semibold tracking-tight text-[var(--foreground)]"
            style={{ fontSize: stacked ? size * 0.5 : size * 0.55 }}
          >
            Meridian
          </span>
          <span
            className="text-[var(--muted-foreground)] font-mono uppercase tracking-[0.15em]"
            style={{ fontSize: stacked ? size * 0.3 : size * 0.32 }}
          >
            Terminal
          </span>
        </div>
      )}
    </div>
  );

  if (onClick) {
    return (
      <motion.button
        type="button"
        onClick={onClick}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        className="cursor-pointer focus-ring rounded-[10px]"
        aria-label="Meridian Terminal home"
      >
        {content}
      </motion.button>
    );
  }
  return content;
}
