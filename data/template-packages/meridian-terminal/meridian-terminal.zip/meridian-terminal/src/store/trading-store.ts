"use client";
// ============================================================
// Trading Terminal — Global market state with simulated ticking
// ============================================================
import { create } from "zustand";
import {
  buildCandles,
  buildIntradayCandles,
  buildOrderBook,
  buildOrders,
  buildPortfolioSummary,
  buildPositions,
  buildSymbols,
  buildTrades,
  type PortfolioSummary,
} from "@/lib/trading/mock-data";
import type {
  Candle,
  Order,
  OrderBookSnapshot,
  OrderSide,
  OrderType,
  Position,
  Symbol,
  Trade,
} from "@/lib/trading/types";

/** A map of ticker → live quote fields that may "tick". */
interface LiveQuote {
  ticker: string;
  price: number;
  bid: number;
  ask: number;
  prevClose: number;
  volume: number;
  /** Last tick direction for flash effect. */
  lastDir: "up" | "down" | "flat";
  /** Monotonic counter so consumers can detect a change. */
  rev: number;
}

interface TradingState {
  symbols: Symbol[];
  quotes: Record<string, LiveQuote>;
  positions: Position[];
  orders: Order[];
  trades: Trade[];
  portfolio: PortfolioSummary;
  selectedTicker: string;
  candleCache: Record<string, { intraday: Candle[]; daily: Candle[] }>;
  bookCache: Record<string, OrderBookSnapshot>;
  /** Working orders that have been added by the user this session. */
  commandOpen: boolean;
  /** Right-click context-menu target ticker (Watchlist). */
  setCommandOpen: (v: boolean) => void;
  select: (ticker: string) => void;
  /** Quick-order form prefill, driven by Order Book clicks. */
  quickOrder: {
    ticker: string;
    side: OrderSide;
    price: number;
    qty: number;
  } | null;
  setQuickOrder: (q: { ticker: string; side: OrderSide; price: number; qty: number } | null) => void;
  submitOrder: (input: {
    ticker: string;
    side: OrderSide;
    type: OrderType;
    qty: number;
    limitPrice?: number;
    stopPrice?: number;
  }) => void;
  cancelOrder: (id: string) => void;
  closePosition: (ticker: string) => void;
  removeFromWatchlist: (ticker: string) => void;
  getCandles: (ticker: string, range: "1D" | "1W" | "1M" | "1Y") => Candle[];
  getOrderBook: (ticker: string) => OrderBookSnapshot;
  /** Tick — nudge a few prices; called from a setInterval in the shell. */
  tick: () => void;
}

const SEED = "meridian-terminal-v1";

const _symbols = buildSymbols(SEED);
const _positions = buildPositions(_symbols);
const _orders = buildOrders(_symbols);
const _trades = buildTrades(_symbols);
const _portfolio = buildPortfolioSummary(_positions);

const initialQuotes: Record<string, LiveQuote> = {};
for (const s of _symbols) {
  initialQuotes[s.ticker] = {
    ticker: s.ticker,
    price: s.price,
    bid: s.bid,
    ask: s.ask,
    prevClose: s.prevClose,
    volume: s.volume,
    lastDir: "flat",
    rev: 0,
  };
}

// Precompute candle cache for all symbols
const candleCache: Record<string, { intraday: Candle[]; daily: Candle[] }> = {};
for (const s of _symbols) {
  candleCache[s.ticker] = {
    intraday: buildIntradayCandles(s),
    daily: buildCandles(s, 365),
  };
}

// Precompute order books
const bookCache: Record<string, OrderBookSnapshot> = {};
for (const s of _symbols) {
  bookCache[s.ticker] = buildOrderBook(s);
}

let _orderSeq = _orders.length;

export const useTradingStore = create<TradingState>((set, get) => ({
  symbols: _symbols,
  quotes: initialQuotes,
  positions: _positions,
  orders: _orders,
  trades: _trades,
  portfolio: _portfolio,
  selectedTicker: _symbols[0].ticker,
  candleCache,
  bookCache,
  commandOpen: false,
  setCommandOpen: (v) => set({ commandOpen: v }),
  select: (ticker) => set({ selectedTicker: ticker }),
  quickOrder: null,
  setQuickOrder: (q) => set({ quickOrder: q }),

  submitOrder: (input) => {
    const state = get();
    const sym = state.symbols.find((s) => s.ticker === input.ticker);
    if (!sym) return;
    const q = state.quotes[input.ticker];
    const id = `ORD-${100240 + ++_orderSeq}`;
    const now = Date.now();
    const isMarket = input.type === "MARKET";
    const fillPrice = isMarket
      ? input.side === "BUY"
        ? q.ask
        : q.bid
      : undefined;
    const newOrder: Order = {
      id,
      ticker: input.ticker,
      side: input.side,
      type: input.type,
      qty: input.qty,
      filledQty: isMarket ? input.qty : 0,
      limitPrice: input.limitPrice,
      stopPrice: input.stopPrice,
      avgFillPrice: fillPrice,
      status: isMarket ? "FILLED" : "WORKING",
      createdAt: now,
      timeInForce: "DAY",
    };
    set({ orders: [newOrder, ...state.orders] });
    if (isMarket && fillPrice) {
      const trade: Trade = {
        id: `TRD-${510020 + state.trades.length + 1}`,
        ticker: input.ticker,
        side: input.side,
        qty: input.qty,
        price: fillPrice,
        timestamp: now,
        fee: +(input.qty * fillPrice * 0.0002).toFixed(2),
      };
      set({ trades: [trade, ...state.trades] });
    }
  },

  cancelOrder: (id) =>
    set((s) => ({
      orders: s.orders.map((o) =>
        o.id === id && (o.status === "WORKING" || o.status === "PARTIAL")
          ? { ...o, status: "CANCELLED" }
          : o,
      ),
    })),

  closePosition: (ticker) =>
    set((s) => ({ positions: s.positions.filter((p) => p.ticker !== ticker) })),

  removeFromWatchlist: (ticker) =>
    set((s) => ({
      symbols: s.symbols.filter((sym) => sym.ticker !== ticker),
    })),

  getCandles: (ticker, range) => {
    const cache = get().candleCache[ticker];
    if (!cache) return [];
    if (range === "1D") return cache.intraday;
    if (range === "1W") return cache.daily.slice(-5);
    if (range === "1M") return cache.daily.slice(-22);
    return cache.daily; // 1Y
  },

  getOrderBook: (ticker) =>
    get().bookCache[ticker] ?? buildOrderBook(get().symbols.find((s) => s.ticker === ticker)!),

  tick: () => {
    const state = get();
    // Pick 2–3 random symbols to nudge each tick.
    const n = 2 + Math.floor(Math.random() * 2);
    const indices = new Set<number>();
    while (indices.size < n && indices.size < state.symbols.length) {
      indices.add(Math.floor(Math.random() * state.symbols.length));
    }
    const newQuotes: Record<string, LiveQuote> = { ...state.quotes };
    for (const i of indices) {
      const sym = state.symbols[i];
      const cur = newQuotes[sym.ticker];
      if (!cur) continue;
      // nudge price by ±0.05% to ±0.4%
      const mag = (Math.random() * 0.0035 + 0.0005) * (Math.random() < 0.5 ? -1 : 1);
      const newPrice = +(cur.price * (1 + mag)).toFixed(2);
      const newBid = +(newPrice - (cur.ask - cur.bid) / 2).toFixed(2);
      const newAsk = +(newPrice + (cur.ask - cur.bid) / 2).toFixed(2);
      const newVol = cur.volume + Math.floor(Math.random() * 5000);
      newQuotes[sym.ticker] = {
        ...cur,
        price: newPrice,
        bid: newBid,
        ask: newAsk,
        volume: newVol,
        lastDir: newPrice > cur.price ? "up" : newPrice < cur.price ? "down" : "flat",
        rev: cur.rev + 1,
      };
    }
    set({ quotes: newQuotes });
  },
}));
