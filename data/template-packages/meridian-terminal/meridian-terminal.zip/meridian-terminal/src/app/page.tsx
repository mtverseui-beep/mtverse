import { TradingApp } from "@/components/trading/TradingApp";

export default function Home() {
  return <TradingApp />;
}
