import type { Metadata, Viewport } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/trading/ThemeProvider";

const inter = Inter({
  variable: "--font-sans",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Meridian Terminal — Trading & Investment",
  description:
    "Professional trading & investment terminal. Real-time prices, order book, positions, and portfolio analytics.",
  metadataBase: new URL("https://meridian.terminal"),
  openGraph: {
    title: "Meridian Terminal — Trading & Investment",
    description:
      "Professional trading & investment terminal. Real-time prices, order book, positions, and portfolio analytics.",
    images: [{ url: "/og-image.svg", width: 1200, height: 630, alt: "Meridian Terminal" }],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Meridian Terminal — Trading & Investment",
    description:
      "Professional trading & investment terminal. Real-time prices, order book, positions, and portfolio analytics.",
    images: ["/og-image.svg"],
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#F7F8FA" },
    { media: "(prefers-color-scheme: dark)", color: "#0B0E14" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Prevent flash of wrong theme — set initial theme before hydration */}
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('meridian-theme');var m=window.matchMedia('(prefers-color-scheme: dark)').matches;if(t==='dark'||(!t&&m)){document.documentElement.classList.add('dark')}}catch(e){}})();`,
          }}
        />
      </head>
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} antialiased`}
        style={{ backgroundColor: "var(--background)", color: "var(--foreground)" }}
      >
        <ThemeProvider>
          {children}
          <Toaster />
          <SonnerToaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: "var(--surface-elevated)",
                border: "1px solid var(--border)",
                color: "var(--foreground)",
                borderRadius: "12px",
                boxShadow: "var(--shadow-lg)",
              },
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
