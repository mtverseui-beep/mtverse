// ============================================================
// Trading Terminal — Core data models
// ============================================================

/** A tradable instrument shown in the watchlist / ticker tape / chart. */
export interface Symbol {
  ticker: string;
  name: string;
  exchange: "NYSE" | "NASDAQ" | "CME" | "LSE" | "TSE";
  sector: string;
  /** Current last-traded price. */
  price: number;
  /** Previous session close — used for day change math. */
  prevClose: number;
  /** Day open. */
  open: number;
  /** Day high. */
  dayHigh: number;
  /** Day low. */
  dayLow: number;
  /** Best bid. */
  bid: number;
  /** Best ask. */
  ask: number;
  /** Bid size. */
  bidSize: number;
  /** Ask size. */
  askSize: number;
  /** Cumulative session volume (shares / contracts). */
  volume: number;
  /** Average session volume, for context. */
  avgVolume: number;
  /** Market cap in USD. */
  marketCap: number;
}

/** Computed day-change fields, derived from price + prevClose. */
export interface SymbolQuote {
  ticker: string;
  price: number;
  change: number;
  changePct: number;
  bid: number;
  ask: number;
  spread: number;
  volume: number;
}

/** A single OHLCV candle, lightweight-charts compatible. */
export interface Candle {
  time: number; // unix seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

/** One row of the order book (aggregated level). */
export interface OrderBookLevel {
  price: number;
  size: number;
  total: number; // cumulative size from top
}

/** A snapshot of both sides of the book plus last trade. */
export interface OrderBookSnapshot {
  ticker: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  lastPrice: number;
  spread: number;
  midpoint: number;
}

/** Side of a position. */
export type PositionSide = "LONG" | "SHORT";

/** An open position in the account. */
export interface Position {
  ticker: string;
  name: string;
  side: PositionSide;
  qty: number; // always positive; direction implied by side
  avgEntry: number;
  last: number;
  marketValue: number;
  costBasis: number;
  unrealizedPnl: number;
  unrealizedPnlPct: number;
  dayChange: number;
  dayChangePct: number;
  openedAt: number; // unix ms
  /** Tiny sparkline series for unrealized P&L over recent session. */
  pnlSeries: { t: number; v: number }[];
}

/** Side of an order. */
export type OrderSide = "BUY" | "SELL";
/** Type of an order. */
export type OrderType = "MARKET" | "LIMIT" | "STOP" | "STOP_LIMIT";
/** Lifecycle state of an order. */
export type OrderStatus = "WORKING" | "PARTIAL" | "FILLED" | "CANCELLED" | "REJECTED";

/** A working or historical order ticket. */
export interface Order {
  id: string;
  ticker: string;
  side: OrderSide;
  type: OrderType;
  qty: number;
  filledQty: number;
  limitPrice?: number;
  stopPrice?: number;
  avgFillPrice?: number;
  status: OrderStatus;
  createdAt: number; // unix ms
  timeInForce: "DAY" | "GTC" | "IOC";
}

/** An executed trade (fill). */
export interface Trade {
  id: string;
  ticker: string;
  side: OrderSide;
  qty: number;
  price: number;
  timestamp: number; // unix ms
  fee: number;
}

/** Range presets for the main chart. */
export type ChartRange = "1D" | "1W" | "1M" | "1Y";

/** Top-level view selectable from the icon rail. */
export type AppView = "terminal" | "portfolio" | "orders" | "alerts" | "history" | "settings";
