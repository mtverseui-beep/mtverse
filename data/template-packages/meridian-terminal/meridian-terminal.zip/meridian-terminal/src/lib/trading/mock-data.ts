// ============================================================
// Trading Terminal — Deterministic seeded mock data
// Same seed → same numbers every load.
// ============================================================
import type {
  Candle,
  Order,
  OrderBookSnapshot,
  Position,
  Symbol,
  Trade,
} from "./types";

// ---------- Seeded PRNG (mulberry32 + xmur3 string hash) ----------
function xmur3(str: string) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return function () {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return h >>> 0;
  };
}
function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export type Rng = () => number;
export function makeRng(seed: string): Rng {
  const seeder = xmur3(seed);
  return mulberry32(seeder());
}
const rint = (rng: Rng, lo: number, hi: number) =>
  Math.floor(rng() * (hi - lo + 1)) + lo;
const rfloat = (rng: Rng, lo: number, hi: number) => rng() * (hi - lo) + lo;
const pick = <T>(rng: Rng, arr: T[]): T => arr[Math.floor(rng() * arr.length)];

// ---------- Symbol universe (fictional but believable names) ----------
interface SymSeed {
  ticker: string;
  name: string;
  exchange: Symbol["exchange"];
  sector: string;
  basePrice: number;
  vol: number; // daily volatility fraction
  sharesOut: number; // shares outstanding (millions)
}

const SYMBOL_SEEDS: SymSeed[] = [
  { ticker: "ZNRA", name: "Zenara Networks", exchange: "NASDAQ", sector: "Technology", basePrice: 184.32, vol: 0.022, sharesOut: 540 },
  { ticker: "AETH", name: "Aetherium Compute", exchange: "NASDAQ", sector: "Technology", basePrice: 92.18, vol: 0.031, sharesOut: 320 },
  { ticker: "NVKS", name: "Nvox Kinetic Systems", exchange: "NYSE", sector: "Industrials", basePrice: 412.55, vol: 0.018, sharesOut: 210 },
  { ticker: "MLPX", name: "MPLX Robotics", exchange: "NYSE", sector: "Industrials", basePrice: 67.91, vol: 0.025, sharesOut: 740 },
  { ticker: "HLYO", name: "Halyon Energy", exchange: "NYSE", sector: "Energy", basePrice: 138.74, vol: 0.020, sharesOut: 480 },
  { ticker: "ORBT", name: "Orbital Freight", exchange: "NYSE", sector: "Industrials", basePrice: 51.22, vol: 0.017, sharesOut: 920 },
  { ticker: "VLDT", name: "Valid Holdings", exchange: "NYSE", sector: "Financials", basePrice: 289.05, vol: 0.014, sharesOut: 165 },
  { ticker: "KORE", name: "Korelya Biotech", exchange: "NASDAQ", sector: "Healthcare", basePrice: 76.43, vol: 0.028, sharesOut: 410 },
  { ticker: "SOLR", name: "Solaria Materials", exchange: "NYSE", sector: "Materials", basePrice: 119.87, vol: 0.024, sharesOut: 360 },
  { ticker: "QBIT", name: "Qbit Logic", exchange: "NASDAQ", sector: "Technology", basePrice: 248.60, vol: 0.035, sharesOut: 195 },
  { ticker: "PRSM", name: "Prisma Pharma", exchange: "NYSE", sector: "Healthcare", basePrice: 63.18, vol: 0.021, sharesOut: 680 },
  { ticker: "HDCN", name: "Hadrian Capital", exchange: "NYSE", sector: "Financials", basePrice: 425.10, vol: 0.012, sharesOut: 120 },
  { ticker: "NOVA", name: "Novaris Aerospace", exchange: "NYSE", sector: "Industrials", basePrice: 198.45, vol: 0.026, sharesOut: 280 },
  { ticker: "FJRD", name: "Fjord Streaming", exchange: "NASDAQ", sector: "Communications", basePrice: 44.72, vol: 0.030, sharesOut: 1100 },
  { ticker: "RAMX", name: "Ramex Holdings", exchange: "LSE", sector: "Financials", basePrice: 312.80, vol: 0.015, sharesOut: 145 },
  { ticker: "CIND", name: "Cindura Foods", exchange: "NYSE", sector: "Consumer Staples", basePrice: 88.16, vol: 0.013, sharesOut: 540 },
];

// ---------- Build deterministic symbol snapshot ----------
export function buildSymbols(seed = "meridian-terminal-v1"): Symbol[] {
  const rng = makeRng(seed);
  return SYMBOL_SEEDS.map((s) => {
    // previous close near basePrice ± 1.5%
    const prevClose = +(s.basePrice * (1 + rfloat(rng, -0.015, 0.015))).toFixed(2);
    // current price: drift from prevClose by ±2% typically, occasionally larger
    const driftMag = rfloat(rng, 0.005, 0.045);
    const drift = rfloat(rng, -1, 1) * driftMag;
    const price = +(prevClose * (1 + drift)).toFixed(2);
    const open = +(prevClose * (1 + rfloat(rng, -0.008, 0.008))).toFixed(2);
    const dayHigh = +Math.max(price, open, prevClose) * (1 + rfloat(rng, 0.001, 0.012));
    const dayLow = +Math.min(price, open, prevClose) * (1 - rfloat(rng, 0.001, 0.012));
    const spreadBps = rfloat(rng, 1, 6); // 1–6 bps spread
    const spread = +(price * (spreadBps / 10000)).toFixed(2);
    const bid = +(price - spread / 2).toFixed(2);
    const ask = +(price + spread / 2).toFixed(2);
    const bidSize = rint(rng, 100, 4800);
    const askSize = rint(rng, 100, 4800);
    const volume = rint(rng, 1, 22) * 100_000 + rint(rng, 0, 99_999);
    const avgVolume = volume * rfloat(rng, 0.7, 1.6);
    const marketCap = s.sharesOut * 1_000_000 * price;
    return {
      ticker: s.ticker,
      name: s.name,
      exchange: s.exchange,
      sector: s.sector,
      price,
      prevClose,
      open,
      dayHigh: +dayHigh.toFixed(2),
      dayLow: +dayLow.toFixed(2),
      bid,
      ask,
      bidSize,
      askSize,
      volume,
      avgVolume: Math.round(avgVolume),
      marketCap,
    } satisfies Symbol;
  });
}

// ---------- Candle history generation (1Y of daily candles) ----------
/** Generate a year of daily OHLCV candles for a symbol using a GBM-ish walk. */
export function buildCandles(
  sym: Symbol,
  days = 365,
  seed = "meridian-candles-v1",
): Candle[] {
  const rng = makeRng(`${seed}:${sym.ticker}`);
  const out: Candle[] = [];
  // Start ~days-1 ago; walk forward to today; final close == current price.
  const nowSec = Math.floor(Date.now() / 1000);
  // Align to start of today, then step back days.
  const todaySec = nowSec - (nowSec % 86400);
  const startSec = todaySec - (days - 1) * 86400;

  // End price known (sym.price). Work backwards to a plausible start price,
  // then forward-simulate so the final close lands near sym.price.
  // We'll just simulate forward and rescale at the end.
  const dailyVol = 0.9 * (SYMBOL_SEEDS.find((s) => s.ticker === sym.ticker)?.vol ?? 0.02);
  let price = sym.prevClose * (1 - rfloat(rng, -0.25, 0.15)); // start somewhere lower-ish
  const rawCloses: number[] = [];
  for (let i = 0; i < days; i++) {
    // mild upward/downward drift, with noise
    const shock = rfloat(rng, -1, 1) * dailyVol;
    const drift = rfloat(rng, -0.0015, 0.0025);
    price = price * (1 + drift + shock);
    // occasional gap
    if (rng() < 0.04) price *= 1 + rfloat(rng, -0.06, 0.06);
    rawCloses.push(Math.max(0.5, price));
  }
  // Rescale so final close == sym.price (preserve shape)
  const scale = sym.price / rawCloses[rawCloses.length - 1];
  const closes = rawCloses.map((c) => +(c * scale).toFixed(2));

  for (let i = 0; i < days; i++) {
    const close = closes[i];
    const open = i === 0 ? close * (1 + rfloat(rng, -0.01, 0.01)) : closes[i - 1];
    const wick = close * dailyVol * rfloat(rng, 0.4, 1.4);
    const high = Math.max(open, close) + Math.abs(rfloat(rng, -1, 1)) * wick;
    const low = Math.min(open, close) - Math.abs(rfloat(rng, -1, 1)) * wick;
    const volume =
      rint(rng, 6, 24) * 100_000 +
      rint(rng, 0, 99_999) +
      (Math.abs(close - open) / close > dailyVol ? rint(rng, 5, 15) * 100_000 : 0);
    out.push({
      time: startSec + i * 86400,
      open: +open.toFixed(2),
      high: +high.toFixed(2),
      low: +Math.max(0.1, low).toFixed(2),
      close: +close.toFixed(2),
      volume,
    });
  }
  // Force the final candle's close to the live price for consistency.
  if (out.length) {
    out[out.length - 1].close = sym.price;
    out[out.length - 1].high = Math.max(out[out.length - 1].high, sym.price);
    out[out.length - 1].low = Math.min(out[out.length - 1].low, sym.price);
  }
  return out;
}

/** Build intraday 1-min candles for the 1D view. */
export function buildIntradayCandles(
  sym: Symbol,
  seed = "meridian-intraday-v1",
): Candle[] {
  const rng = makeRng(`${seed}:${sym.ticker}`);
  const out: Candle[] = [];
  // Build a full trading day: 9:30 → 16:00 ET = 390 minutes.
  // For determinism without timezone complexity, anchor to UTC midnight today.
  const nowSec = Math.floor(Date.now() / 1000);
  const dayStart = nowSec - (nowSec % 86400); // 00:00 UTC today
  const startSec = dayStart + 14 * 3600; // 14:00 UTC ≈ 9:30 ET
  const minutes = 390;
  let price = sym.open;
  const minVol = (SYMBOL_SEEDS.find((s) => s.ticker === sym.ticker)?.vol ?? 0.02) / Math.sqrt(390);
  for (let i = 0; i < minutes; i++) {
    const shock = rfloat(rng, -1, 1) * minVol;
    const drift = (sym.price - sym.open) / sym.open / minutes; // bias toward final price
    const open = price;
    const close = open * (1 + drift + shock);
    const wick = open * minVol * rfloat(rng, 0.3, 1.2);
    const high = Math.max(open, close) + Math.abs(rfloat(rng, 0, 1)) * wick;
    const low = Math.min(open, close) - Math.abs(rfloat(rng, 0, 1)) * wick;
    const volume = rint(rng, 2, 28) * 1000 + rint(rng, 0, 999);
    out.push({
      time: startSec + i * 60,
      open: +open.toFixed(2),
      high: +high.toFixed(2),
      low: +Math.max(0.1, low).toFixed(2),
      close: +close.toFixed(2),
      volume,
    });
    price = close;
  }
  // Pin the last close to the live price.
  if (out.length) {
    out[out.length - 1].close = sym.price;
    out[out.length - 1].high = Math.max(out[out.length - 1].high, sym.price);
    out[out.length - 1].low = Math.min(out[out.length - 1].low, sym.price);
  }
  return out;
}

/** Aggregate a daily series into weekly bars (5 trading days per week). */
export function aggregateWeekly(daily: Candle[]): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i < daily.length; i += 5) {
    const slice = daily.slice(i, i + 5);
    if (!slice.length) break;
    out.push({
      time: slice[0].time,
      open: slice[0].open,
      high: Math.max(...slice.map((c) => c.high)),
      low: Math.min(...slice.map((c) => c.low)),
      close: slice[slice.length - 1].close,
      volume: slice.reduce((a, c) => a + c.volume, 0),
    });
  }
  return out;
}

/** Aggregate a daily series into monthly bars (~21 trading days). */
export function aggregateMonthly(daily: Candle[]): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i < daily.length; i += 21) {
    const slice = daily.slice(i, i + 21);
    if (!slice.length) break;
    out.push({
      time: slice[0].time,
      open: slice[0].open,
      high: Math.max(...slice.map((c) => c.high)),
      low: Math.min(...slice.map((c) => c.low)),
      close: slice[slice.length - 1].close,
      volume: slice.reduce((a, c) => a + c.volume, 0),
    });
  }
  return out;
}

// ---------- Order book ----------
export function buildOrderBook(
  sym: Symbol,
  levels = 14,
  seed = "meridian-book-v1",
): OrderBookSnapshot {
  const rng = makeRng(`${seed}:${sym.ticker}`);
  const tick = sym.price > 200 ? 0.05 : sym.price > 50 ? 0.02 : 0.01;
  const bids: { price: number; size: number; total: number }[] = [];
  const asks: { price: number; size: number; total: number }[] = [];
  let bidTotal = 0;
  let askTotal = 0;
  let bidPrice = sym.bid;
  let askPrice = sym.ask;
  for (let i = 0; i < levels; i++) {
    const bSize = rint(rng, 80, 5200);
    const aSize = rint(rng, 80, 5200);
    bidTotal += bSize;
    askTotal += aSize;
    bids.push({ price: +bidPrice.toFixed(2), size: bSize, total: bidTotal });
    asks.push({ price: +askPrice.toFixed(2), size: aSize, total: askTotal });
    bidPrice = +(bidPrice - tick * rint(rng, 1, 3)).toFixed(2);
    askPrice = +(askPrice + tick * rint(rng, 1, 3)).toFixed(2);
  }
  return {
    ticker: sym.ticker,
    bids,
    asks,
    lastPrice: sym.price,
    spread: +(sym.ask - sym.bid).toFixed(2),
    midpoint: +((sym.bid + sym.ask) / 2).toFixed(2),
  };
}

// ---------- Positions ----------
const POSITION_PICK = [
  { ticker: "ZNRA", side: "LONG" as const, qty: 320 },
  { ticker: "NVKS", side: "LONG" as const, qty: 85 },
  { ticker: "AETH", side: "LONG" as const, qty: 480 },
  { ticker: "FJRD", side: "SHORT" as const, qty: 1200 },
  { ticker: "HLYO", side: "LONG" as const, qty: 210 },
  { ticker: "QBIT", side: "LONG" as const, qty: 145 },
  { ticker: "KORE", side: "SHORT" as const, qty: 380 },
  { ticker: "SOLR", side: "LONG" as const, qty: 175 },
];

export function buildPositions(
  symbols: Symbol[],
  seed = "meridian-positions-v1",
): Position[] {
  const rng = makeRng(seed);
  const now = Date.now();
  return POSITION_PICK.map((p) => {
    const sym = symbols.find((s) => s.ticker === p.ticker)!;
    // entry price: somewhere ±15% from current price
    const entryDrift = rfloat(rng, -0.15, 0.15);
    const avgEntry = +(sym.price * (1 + (p.side === "LONG" ? -entryDrift : entryDrift))).toFixed(2);
    const last = sym.price;
    const qty = p.qty;
    const costBasis = avgEntry * qty;
    const marketValue = last * qty;
    const grossPnl = p.side === "LONG" ? marketValue - costBasis : costBasis - marketValue;
    const unrealizedPnl = grossPnl;
    const unrealizedPnlPct = (grossPnl / costBasis) * 100;
    const dayChange = (last - sym.prevClose) * qty * (p.side === "LONG" ? 1 : -1);
    const dayChangePct = (last - sym.prevClose) / sym.prevClose * 100 * (p.side === "LONG" ? 1 : -1);
    const openedAt = now - rint(rng, 1, 120) * 86400_000;
    // sparkline of recent unrealized P&L (last 30 points)
    const pnlSeries = Array.from({ length: 30 }, (_, i) => {
      const t = now - (30 - i) * 60_000;
      const noise = rfloat(rng, -0.04, 0.04);
      const v = unrealizedPnl * (1 - (30 - i) / 60 + noise * Math.abs(unrealizedPnl));
      return { t, v: +v.toFixed(2) };
    });
    pnlSeries[pnlSeries.length - 1] = { t: now, v: unrealizedPnl };
    return {
      ticker: sym.ticker,
      name: sym.name,
      side: p.side,
      qty,
      avgEntry,
      last,
      marketValue,
      costBasis,
      unrealizedPnl,
      unrealizedPnlPct,
      dayChange,
      dayChangePct,
      openedAt,
      pnlSeries,
    } satisfies Position;
  });
}

// ---------- Orders ----------
const ORDER_TEMPLATES = [
  { ticker: "ZNRA", side: "BUY" as const, type: "LIMIT" as const, qty: 200, limitPrice: 182.50 },
  { ticker: "AETH", side: "SELL" as const, type: "LIMIT" as const, qty: 150, limitPrice: 94.10 },
  { ticker: "QBIT", side: "BUY" as const, type: "STOP" as const, qty: 60, stopPrice: 258.00 },
  { ticker: "FJRD", side: "BUY" as const, type: "LIMIT" as const, qty: 800, limitPrice: 43.80 },
  { ticker: "HLYO", side: "SELL" as const, type: "MARKET" as const, qty: 100 },
];

export function buildOrders(
  symbols: Symbol[],
  seed = "meridian-orders-v1",
): Order[] {
  const rng = makeRng(seed);
  const now = Date.now();
  return ORDER_TEMPLATES.map((o, i) => {
    const filledQty = o.type === "MARKET" ? o.qty : 0;
    const sym = symbols.find((s) => s.ticker === o.ticker)!;
    return {
      id: `ORD-${100240 + i}`,
      ticker: o.ticker,
      side: o.side,
      type: o.type,
      qty: o.qty,
      filledQty,
      limitPrice: o.limitPrice,
      stopPrice: o.type === "STOP" ? o.stopPrice : undefined,
      avgFillPrice: filledQty > 0 ? sym.price : undefined,
      status: filledQty > 0 ? "FILLED" : "WORKING",
      createdAt: now - rint(rng, 1, 480) * 60_000,
      timeInForce: "DAY",
    } satisfies Order;
  });
}

// ---------- Trades (recent fills) ----------
export function buildTrades(
  symbols: Symbol[],
  count = 18,
  seed = "meridian-trades-v1",
): Trade[] {
  const rng = makeRng(seed);
  const now = Date.now();
  const out: Trade[] = [];
  for (let i = 0; i < count; i++) {
    const sym = pick(rng, symbols);
    const side: Trade["side"] = rng() < 0.5 ? "BUY" : "SELL";
    const qty = rint(rng, 1, 25) * 100;
    const price = +(sym.price * (1 + rfloat(rng, -0.002, 0.002))).toFixed(2);
    out.push({
      id: `TRD-${510020 + i}`,
      ticker: sym.ticker,
      side,
      qty,
      price,
      timestamp: now - rint(rng, 1, 600) * 1000,
      fee: +(qty * price * 0.0002).toFixed(2),
    } satisfies Trade);
  }
  return out.sort((a, b) => b.timestamp - a.timestamp);
}

// ---------- Account / portfolio summary ----------
export interface PortfolioSummary {
  netWorth: number;
  cashBalance: number;
  marketValue: number;
  dayPnl: number;
  dayPnlPct: number;
  totalPnl: number;
  totalPnlPct: number;
  buyingPower: number;
  /** Net worth history for performance chart, last N days. */
  history: { t: number; v: number }[];
  /** Sector allocation breakdown. */
  allocation: { label: string; value: number; pct: number }[];
}

export function buildPortfolioSummary(
  positions: Position[],
  seed = "meridian-portfolio-v1",
): PortfolioSummary {
  const rng = makeRng(seed);
  const marketValue = positions.reduce((a, p) => a + p.marketValue, 0);
  const cashBalance = 248_750.42;
  const netWorth = marketValue + cashBalance;
  const dayPnl = positions.reduce((a, p) => a + p.dayChange, 0);
  const totalPnl = positions.reduce((a, p) => a + p.unrealizedPnl, 0);
  const prevNetWorth = netWorth - dayPnl;
  const costBasisTotal = positions.reduce((a, p) => a + p.costBasis, 0);
  // 90-day net worth history, ending today
  const now = Date.now();
  const startNet = netWorth * (1 - rfloat(rng, 0.05, 0.18));
  const history = Array.from({ length: 90 }, (_, i) => {
    const t = now - (90 - i) * 86400_000;
    const progress = i / 89;
    const trend = startNet + (netWorth - startNet) * progress;
    const noise = trend * rfloat(rng, -0.012, 0.012);
    return { t, v: +(trend + noise).toFixed(2) };
  });
  history[history.length - 1] = { t: now, v: netWorth };
  // Sector allocation
  const sectorMap = new Map<string, number>();
  for (const p of positions) {
    // pull sector via symbol table — use lookup of seeds
    const seed = SYMBOL_SEEDS.find((s) => s.ticker === p.ticker);
    const sector = seed?.sector ?? "Other";
    sectorMap.set(sector, (sectorMap.get(sector) ?? 0) + p.marketValue);
  }
  const allocation = Array.from(sectorMap.entries())
    .map(([label, value]) => ({
      label,
      value: +value.toFixed(2),
      pct: (value / marketValue) * 100,
    }))
    .sort((a, b) => b.value - a.value);
  return {
    netWorth,
    cashBalance,
    marketValue,
    dayPnl,
    dayPnlPct: (dayPnl / prevNetWorth) * 100,
    totalPnl,
    totalPnlPct: (totalPnl / costBasisTotal) * 100,
    buyingPower: cashBalance * 2,
    history,
    allocation,
  };
}
