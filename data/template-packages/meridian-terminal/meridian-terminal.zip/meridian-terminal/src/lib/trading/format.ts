// ============================================================
// Trading Terminal — Numeric formatters (always mono-styled)
// ============================================================

const abs = Math.abs;

export function fmtPrice(n: number, opts: { decimals?: number } = {}): string {
  const decimals = opts.decimals ?? (n >= 1000 ? 2 : n >= 1 ? 2 : 4);
  return n.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function fmtChange(n: number, decimals = 2): string {
  const sign = n > 0 ? "+" : n < 0 ? "−" : "";
  return `${sign}${abs(n).toFixed(decimals)}`;
}

export function fmtPct(n: number, decimals = 2): string {
  const sign = n > 0 ? "+" : n < 0 ? "−" : "";
  return `${sign}${abs(n).toFixed(decimals)}%`;
}

export function fmtQty(n: number): string {
  return n.toLocaleString("en-US", { maximumFractionDigits: 0 });
}

export function fmtCompact(n: number): string {
  return Intl.NumberFormat("en-US", {
    notation: "compact",
    maximumFractionDigits: 2,
  }).format(n);
}

export function fmtUSD(n: number, opts: { compact?: boolean; sign?: boolean } = {}): string {
  const sign = opts.sign && n > 0 ? "+" : n < 0 ? "−" : "";
  const body = opts.compact
    ? Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 2 }).format(abs(n))
    : abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${sign}$${body}`;
}

export function fmtTime(ms: number): string {
  return new Date(ms).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

export function fmtDate(ms: number): string {
  return new Date(ms).toLocaleDateString("en-US", {
    month: "short",
    day: "2-digit",
    year: "numeric",
  });
}

export function fmtRelative(ms: number): string {
  const diff = Date.now() - ms;
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  return `${day}d ago`;
}

/** Color class for a signed delta. */
export function deltaColor(n: number): string {
  if (n > 0) return "text-[#00D992]";
  if (n < 0) return "text-[#FF3B5C]";
  return "text-[#8B93A7]";
}
