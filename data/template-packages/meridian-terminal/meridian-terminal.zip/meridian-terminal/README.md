# Meridian Terminal

Professional trading and investment terminal built with Next.js 16, React 19, TypeScript, Tailwind CSS 4, and shadcn/ui. It combines a desktop-style market workspace with watchlists, charting, order entry, order history, portfolio analytics, alerts, and settings.

## Quick Start

```bash
bun install
# or: npm install

bun run dev
# or: npm run dev
```

Open `http://localhost:3000`.

## Available Scripts

```bash
bun run dev
bun run build
bun run start
bun run lint

bun run db:generate
bun run db:push
bun run db:migrate
bun run db:reset
```

## Product Highlights

- Terminal-style desktop layout with persistent icon rail, top bar, ticker tape, watchlist, chart, order book, and order ticket
- Simulated live market updates powered by a timed store tick cycle
- Portfolio, orders, alerts, history, profile, help, and nested settings screens
- Quick command bar opened with `Ctrl+K` / `Cmd+K`
- Responsive mobile shell for smaller screens
- Deterministic mock trading data for symbols, candles, positions, orders, fills, portfolio allocation, and account activity
- Theme-aware UI with branded metadata, OG image, and persisted theme preference

## Tech Stack

- Next.js 16 App Router
- React 19
- TypeScript 5
- Tailwind CSS 4
- shadcn/ui + Radix UI
- Zustand
- Recharts
- Prisma with SQLite
- Framer Motion

## Project Structure

```text
src/
  app/                       # Root Next.js app shell
  components/trading/        # Meridian Terminal shell and trading UI
  components/ui/             # Shared shadcn/ui primitives
  hooks/                     # Hash routing, media/query helpers
  lib/trading/               # Market types, formatters, mock-data builders
  store/trading-store.ts     # Trading state and actions
prisma/
  schema.prisma              # Prisma schema
db/
  custom.db                  # Local SQLite database
scripts/
  generate-icons.py
  theme-colors.py
```

## Navigation Model

The root page (`src/app/page.tsx`) mounts `TradingApp`. Inside the app, navigation is managed client-side with hash routes. Current top-level views include:

- `#/terminal`
- `#/portfolio`
- `#/orders`
- `#/alerts`
- `#/history`
- `#/settings/...`
- `#/profile`
- `#/help`

On desktop, `#/terminal` renders the multi-panel trading workspace. On mobile, the same route switches to a compact `MobileShell`.

## Notes

- Theme preference is stored under `localStorage["meridian-theme"]`.
- Market data updates are simulated in the client store on a repeating interval.
- Prisma is configured for SQLite through `DATABASE_URL` in `.env`.
