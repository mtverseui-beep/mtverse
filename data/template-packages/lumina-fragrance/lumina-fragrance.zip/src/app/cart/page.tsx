"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useCart } from "@/components/boty/cart-context"
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Tag, Gift, Truck, Check } from "lucide-react"

export default function CartPage() {
  const { items, updateQuantity, removeItem, subtotal, clearCart, hydrated } = useCart()
  const [coupon, setCoupon] = useState("")
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null)
  const [discount, setDiscount] = useState(0)
  const [couponError, setCouponError] = useState("")
  const [giftWrap, setGiftWrap] = useState(false)
  const [notes, setNotes] = useState("")

  const shipping = subtotal >= 50 ? 0 : 5
  const giftWrapFee = giftWrap ? 8 : 0
  const tax = Math.round(Math.max(0, subtotal - discount) * 0.08 * 100) / 100
  const total = Math.max(0, subtotal - discount) + shipping + tax + giftWrapFee

  const handleApplyCoupon = () => {
    const code = coupon.trim().toUpperCase()
    if (!code) return
    if (code === "LUMINA10") {
      setAppliedCoupon(code)
      setDiscount(Math.round(subtotal * 0.1 * 100) / 100)
      setCouponError("")
    } else if (code === "WELCOME15" && subtotal >= 75) {
      setAppliedCoupon(code)
      setDiscount(Math.round(subtotal * 0.15 * 100) / 100)
      setCouponError("")
    } else if (code === "FREESHIP") {
      setAppliedCoupon(code)
      setDiscount(5)
      setCouponError("")
    } else {
      setAppliedCoupon(null)
      setDiscount(0)
      setCouponError("Invalid coupon code")
    }
  }

  if (!hydrated) {
    return (
      <main className="min-h-screen">
        <Header />
        <div className="pt-28 pb-20 max-w-7xl mx-auto px-6 lg:px-8">
          <div className="lumina-skeleton h-12 w-64 mb-8" />
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {[1, 2].map((i) => (
                <div key={i} className="lumina-skeleton h-32 w-full" />
              ))}
            </div>
            <div className="lumina-skeleton h-96 w-full" />
          </div>
        </div>
        <Footer />
      </main>
    )
  }

  if (items.length === 0) {
    return (
      <main className="min-h-screen">
        <Header />
        <div className="pt-28 pb-20">
          <div className="max-w-2xl mx-auto px-6 lg:px-8 text-center">
            <div className="w-24 h-24 rounded-full bg-card flex items-center justify-center mx-auto mb-6 boty-shadow">
              <ShoppingBag className="w-10 h-10 text-muted-foreground" />
            </div>
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Your Cart</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4 text-balance">Your cart is empty</h1>
            <p className="text-lg text-muted-foreground mb-8">
              Discover soft fragrance rituals for everyday moments.
            </p>
            <Link
              href="/shop"
              className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-sm tracking-wide boty-transition hover:bg-primary/90 boty-shadow"
            >
              Start Shopping
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <Link href="/shop" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8">
            ← Continue Shopping
          </Link>
          <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-8">Your Cart</h1>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Items */}
            <div className="lg:col-span-2 space-y-4">
              {items.map((item) => (
                <div key={item.id} className="flex gap-4 bg-card rounded-3xl p-5 boty-shadow">
                  <Link href={`/product/${item.id}`} className="relative w-28 h-28 flex-shrink-0 rounded-2xl overflow-hidden bg-muted">
                    <Image src={item.image} alt={item.name} fill className="object-cover" />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link href={`/product/${item.id}`}>
                      <h3 className="font-serif text-lg text-foreground hover:text-primary boty-transition">{item.name}</h3>
                    </Link>
                    <p className="text-sm text-muted-foreground mb-1">{item.description}</p>
                    {item.size && <p className="text-xs text-muted-foreground mb-3">Size: {item.size}</p>}
                    <div className="flex items-center gap-3 flex-wrap">
                      <div className="flex items-center border border-border rounded-full bg-background">
                        <button type="button" onClick={() => updateQuantity(item.id, item.quantity - 1)} className="p-2 hover:bg-muted boty-transition rounded-l-full" aria-label="Decrease">
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-3 text-sm font-medium min-w-[2rem] text-center">{item.quantity}</span>
                        <button type="button" onClick={() => updateQuantity(item.id, item.quantity + 1)} className="p-2 hover:bg-muted boty-transition rounded-r-full" aria-label="Increase">
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <button type="button" onClick={() => removeItem(item.id)} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive boty-transition">
                        <Trash2 className="w-3.5 h-3.5" /> Remove
                      </button>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-serif text-xl text-foreground">${item.price * item.quantity}</p>
                    <p className="text-xs text-muted-foreground">${item.price} each</p>
                  </div>
                </div>
              ))}

              <button onClick={clearCart} className="text-sm text-muted-foreground hover:text-destructive boty-transition">
                Clear cart
              </button>
            </div>

            {/* Summary */}
            <div className="space-y-4">
              {/* Free shipping progress */}
              <div className="bg-card rounded-3xl p-5 boty-shadow">
                <div className="flex items-center gap-2 mb-2">
                  <Truck className="w-4 h-4 text-primary" />
                  <p className="text-sm font-medium text-foreground">
                    {shipping === 0 ? "You got free shipping!" : `Add $${(50 - subtotal).toFixed(2)} for free shipping`}
                  </p>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary transition-all duration-500" style={{ width: `${Math.min(100, (subtotal / 50) * 100)}%` }} />
                </div>
              </div>

              {/* Coupon */}
              <div className="bg-card rounded-3xl p-5 boty-shadow">
                <p className="text-sm font-medium text-foreground mb-3 flex items-center gap-2">
                  <Tag className="w-4 h-4" /> Promo Code
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={coupon}
                    onChange={(e) => setCoupon(e.target.value)}
                    placeholder="Enter code"
                    className="flex-1 bg-background border border-border rounded-full px-4 py-2 text-sm focus:outline-none focus:border-primary boty-transition"
                  />
                  <button type="button" onClick={handleApplyCoupon} className="px-4 py-2 rounded-full bg-foreground text-background text-sm boty-transition hover:bg-foreground/90">
                    Apply
                  </button>
                </div>
                {couponError && <p className="text-xs text-destructive mt-2">{couponError}</p>}
                {appliedCoupon && <p className="text-xs text-primary mt-2 flex items-center gap-1"><Check className="w-3 h-3" /> {appliedCoupon} applied — you saved ${discount}</p>}
                <p className="text-xs text-muted-foreground mt-2">Try: LUMINA10, WELCOME15, FREESHIP</p>
              </div>

              {/* Gift wrap */}
              <div className="bg-card rounded-3xl p-5 boty-shadow">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" checked={giftWrap} onChange={(e) => setGiftWrap(e.target.checked)} className="w-5 h-5 rounded accent-primary" />
                  <Gift className="w-4 h-4 text-primary" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">Gift wrap (+$8)</p>
                    <p className="text-xs text-muted-foreground">Hand-tied ribbon + note</p>
                  </div>
                </label>
              </div>

              {/* Order notes */}
              <div className="bg-card rounded-3xl p-5 boty-shadow">
                <p className="text-sm font-medium text-foreground mb-2">Order Notes</p>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add a gift message or special instructions..."
                  rows={3}
                  className="w-full bg-background border border-border rounded-2xl px-4 py-2 text-sm focus:outline-none focus:border-primary boty-transition resize-none"
                />
              </div>

              {/* Totals */}
              <div className="bg-card rounded-3xl p-5 boty-shadow space-y-2 text-sm">
                <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>${subtotal}</span></div>
                {discount > 0 && <div className="flex justify-between text-primary"><span>Discount</span><span>-${discount}</span></div>}
                <div className="flex justify-between text-muted-foreground"><span>Shipping</span><span>{shipping === 0 ? "Free" : `$${shipping}`}</span></div>
                {giftWrap && <div className="flex justify-between text-muted-foreground"><span>Gift wrap</span><span>${giftWrapFee}</span></div>}
                <div className="flex justify-between text-muted-foreground"><span>Tax (est.)</span><span>${tax}</span></div>
                <div className="flex justify-between text-base font-medium text-foreground pt-2 border-t border-border/50"><span>Total</span><span>${total}</span></div>
              </div>

              <Link href="/checkout" className="block w-full bg-primary text-primary-foreground py-4 rounded-full font-medium hover:bg-primary/90 boty-transition boty-shadow text-center">
                Proceed to Checkout
              </Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
