import { PolicyPage } from "@/components/shared/policy-page"
export default function PrivacyPage() { return <PolicyPage slug="privacy" /> }
