import { use } from "react"
import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { blogPosts, blogPostBySlug } from "@/data/content"
import { ArrowRight, ArrowLeft } from "lucide-react"

export default function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params)
  const post = blogPostBySlug(slug)
  if (!post) notFound()

  const related = blogPosts.filter((p) => p.slug !== slug).slice(0, 3)

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-3xl mx-auto px-6 lg:px-8">
          <Link href="/blog" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"><ArrowLeft className="w-4 h-4" /> Back to Journal</Link>

          <Reveal className="mb-8">
            <p className="text-xs tracking-[0.24em] uppercase text-primary mb-3">{post.category}</p>
            <h1 className="font-serif text-3xl md:text-5xl text-foreground mb-4 text-balance">{post.title}</h1>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <span className="font-medium text-foreground">{post.author}</span><span>•</span><span>{post.publishedAt}</span><span>•</span><span>{post.readingTime}</span>
            </div>
          </Reveal>

          <Reveal delay={80} className="relative aspect-[16/9] rounded-3xl overflow-hidden boty-shadow mb-10">
            <Image src={post.cover} alt={post.title} fill className="object-cover" priority />
          </Reveal>

          <Reveal delay={120} className="lumina-prose mb-12">
            {post.body.map((para, i) => <p key={i}>{para}</p>)}
          </Reveal>

          <Reveal className="border-t border-border/50 pt-8 mb-12">
            <p className="text-sm font-medium text-foreground mb-3">Tags</p>
            <div className="flex flex-wrap gap-2">
              {post.tags.map((tag) => <span key={tag} className="text-xs px-3 py-1 rounded-full bg-card text-muted-foreground boty-shadow">{tag}</span>)}
            </div>
          </Reveal>
        </div>

        {/* Related */}
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <h2 className="font-serif text-2xl text-foreground mb-6 text-center">Related Articles</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            {related.map((p, i) => (
              <Reveal key={p.slug} delay={i * 80}>
                <Link href={`/blog/${p.slug}`} className="group block bg-card rounded-3xl overflow-hidden boty-shadow hover:scale-[1.02] boty-transition">
                  <div className="relative aspect-[4/3] bg-muted overflow-hidden"><Image src={p.cover} alt={p.title} fill className="object-cover boty-transition group-hover:scale-105" /></div>
                  <div className="p-5">
                    <p className="text-xs tracking-[0.18em] uppercase text-primary mb-2">{p.category}</p>
                    <h3 className="font-serif text-base text-foreground mb-2 group-hover:text-primary boty-transition line-clamp-2">{p.title}</h3>
                    <span className="inline-flex items-center gap-1 text-xs text-primary">Read <ArrowRight className="w-3 h-3" /></span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
