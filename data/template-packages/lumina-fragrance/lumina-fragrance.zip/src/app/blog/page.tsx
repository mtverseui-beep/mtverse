import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { blogPosts, blogCategories } from "@/data/content"
import { ArrowRight, Search } from "lucide-react"

export default function BlogPage() {
  const featured = blogPosts[0]
  const rest = blogPosts.slice(1)

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">The Journal</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Stories & Rituals</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Notes on scent, slow living, layering, and the small rituals that shape a day.</p>
          </Reveal>

          {/* Categories */}
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            <Link href="/blog" className="px-4 py-2 rounded-full text-sm bg-primary text-primary-foreground">All</Link>
            {blogCategories.map((c) => <Link key={c} href={`/blog?category=${c}`} className="px-4 py-2 rounded-full text-sm bg-card text-foreground boty-shadow hover:scale-[1.02] boty-transition">{c}</Link>)}
          </div>

          {/* Featured */}
          <Reveal delay={80} className="mb-12">
            <Link href={`/blog/${featured.slug}`} className="group grid md:grid-cols-2 gap-8 bg-card rounded-3xl overflow-hidden boty-shadow">
              <div className="relative aspect-[4/3] md:aspect-auto bg-muted">
                <Image src={featured.cover} alt={featured.title} fill className="object-cover boty-transition group-hover:scale-105" />
              </div>
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <p className="text-xs tracking-[0.24em] uppercase text-primary mb-3">{featured.category} • Featured</p>
                <h2 className="font-serif text-2xl md:text-3xl text-foreground mb-3 group-hover:text-primary boty-transition">{featured.title}</h2>
                <p className="text-muted-foreground mb-4 leading-relaxed">{featured.excerpt}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mb-4">
                  <span>{featured.author}</span><span>•</span><span>{featured.publishedAt}</span><span>•</span><span>{featured.readingTime}</span>
                </div>
                <span className="inline-flex items-center gap-1 text-sm text-primary group-hover:gap-2 transition-all">Read article <ArrowRight className="w-3.5 h-3.5" /></span>
              </div>
            </Link>
          </Reveal>

          {/* Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {rest.map((post, i) => (
              <Reveal key={post.slug} delay={i * 80}>
                <Link href={`/blog/${post.slug}`} className="group block bg-card rounded-3xl overflow-hidden boty-shadow hover:scale-[1.02] boty-transition">
                  <div className="relative aspect-[4/3] bg-muted overflow-hidden">
                    <Image src={post.cover} alt={post.title} fill className="object-cover boty-transition group-hover:scale-105" />
                  </div>
                  <div className="p-5">
                    <p className="text-xs tracking-[0.18em] uppercase text-primary mb-2">{post.category}</p>
                    <h3 className="font-serif text-lg text-foreground mb-2 group-hover:text-primary boty-transition">{post.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{post.excerpt}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground"><span>{post.publishedAt}</span><span>•</span><span>{post.readingTime}</span></div>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
