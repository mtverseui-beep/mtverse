import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"

export default function FragranceNotesPage() {
  const notes = [
    { family: "Top Notes", desc: "The first impression. Bright, fresh, and evaporating quickly (15–30 min).", items: [{ name: "Bergamot", desc: "Bright, slightly bitter citrus", pairings: "Jasmine, Amber, Cedar" }, { name: "Pink Pepper", desc: "Warm, slightly spicy lift", pairings: "Rose, Saffron, Bergamot" }, { name: "Sicilian Lemon", desc: "Cold-pressed, crisp citrus", pairings: "Neroli, White Tea, Musk" }, { name: "Petitgrain", desc: "Bitter orange leaf, green freshness", pairings: "Neroli, Bergamot, Iris" }] },
    { family: "Heart Notes", desc: "The personality. Appears after top notes settle, lingers for hours.", items: [{ name: "Jasmine Petals", desc: "Soft white floral with quiet warmth", pairings: "Bergamot, Amber, Sandalwood" }, { name: "Rose Absolute", desc: "Dewy, fresh rose petals", pairings: "Pink Pepper, Musk, Vanilla" }, { name: "Iris", desc: "Powdery, buttery, luxurious", pairings: "Violet, Musk, Sandalwood" }, { name: "Bourbon Vanilla", desc: "Warm, second-skin vanilla", pairings: "Tonka, Amber, Benzoin" }, { name: "Amber", desc: "Warm, resinous, enveloping", pairings: "Jasmine, Sandalwood, Benzoin" }] },
    { family: "Base Notes", desc: "The foundation. Deep, slow-evaporating, lingers for hours.", items: [{ name: "White Musk", desc: "Clean, soft, lingering", pairings: "Iris, Rose, Cashmeran" }, { name: "Cashmeran", desc: "Soft, woody musk for depth", pairings: "Musk, Cedar, Amber" }, { name: "Sandalwood", desc: "Creamy, smooth wood", pairings: "Amber, Benzoin, Vanilla" }, { name: "Benzoin", desc: "Sweet, balsamic resin", pairings: "Amber, Vanilla, Sandalwood" }, { name: "Tonka Bean", desc: "Sweet almond warmth", pairings: "Vanilla, Amber, Bergamot" }] },
  ]

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">The Note Library</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Fragrance Notes</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Every fragrance is built from three layers of notes. Understanding them is the first step to finding scents you'll love.</p>
          </Reveal>

          <div className="space-y-12">
            {notes.map((group, i) => (
              <Reveal key={group.family} delay={i * 80}>
                <div className="mb-6">
                  <h2 className="font-serif text-2xl text-foreground mb-2">{group.family}</h2>
                  <p className="text-sm text-muted-foreground">{group.desc}</p>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {group.items.map((note) => (
                    <div key={note.name} className="bg-card rounded-3xl p-5 boty-shadow hover:scale-[1.02] boty-transition">
                      <h3 className="font-serif text-lg text-foreground mb-1">{note.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{note.desc}</p>
                      <p className="text-xs text-muted-foreground"><span className="text-foreground font-medium">Pairs with:</span> {note.pairings}</p>
                    </div>
                  ))}
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
