"use client"

import { useState, useMemo } from "react"
import { useSearchParams } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { products, categories } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { Search, ShoppingBag, X, SlidersHorizontal } from "lucide-react"

export default function SearchPage() {
  const params = useSearchParams()
  const initialQ = params.get("q") || ""
  const [query, setQuery] = useState(initialQ)
  const [category, setCategory] = useState("all")
  const [sort, setSort] = useState("featured")
  const [showFilters, setShowFilters] = useState(false)
  const { addItem } = useCart()

  const results = useMemo(() => {
    let r = products
    if (query.trim()) {
      const q = query.toLowerCase()
      r = r.filter((p) => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.tagline?.toLowerCase().includes(q) || p.notes?.top.join(" ").toLowerCase().includes(q) || p.notes?.heart.join(" ").toLowerCase().includes(q) || p.notes?.base.join(" ").toLowerCase().includes(q))
    }
    if (category !== "all") r = r.filter((p) => p.category === category)
    if (sort === "price-low") r = [...r].sort((a, b) => a.price - b.price)
    if (sort === "price-high") r = [...r].sort((a, b) => b.price - a.price)
    if (sort === "rating") r = [...r].sort((a, b) => (b.rating || 0) - (a.rating || 0))
    return r
  }, [query, category, sort])

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Search</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-6">Find Your Scent</h1>
            <div className="max-w-xl mx-auto relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by name, note, or mood..."
                className="w-full bg-card border border-border rounded-full pl-12 pr-12 py-4 text-sm focus:outline-none focus:border-primary boty-shadow boty-transition"
                autoFocus
              />
              {query && (
                <button onClick={() => setQuery("")} className="absolute right-4 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-muted flex items-center justify-center" aria-label="Clear">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Filter bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-8 pb-6 border-b border-border/50">
            <button onClick={() => setShowFilters(!showFilters)} className="lg:hidden inline-flex items-center gap-2 text-sm text-foreground">
              <SlidersHorizontal className="w-4 h-4" /> Filters
            </button>
            <div className="hidden lg:flex items-center gap-2 flex-wrap">
              <button onClick={() => setCategory("all")} className={`px-4 py-2 rounded-full text-sm boty-transition ${category === "all" ? "bg-primary text-primary-foreground" : "bg-card text-foreground/70 hover:text-foreground boty-shadow"}`}>All</button>
              {categories.map((c) => (
                <button key={c.slug} onClick={() => setCategory(c.slug)} className={`px-4 py-2 rounded-full text-sm boty-transition ${category === c.slug ? "bg-primary text-primary-foreground" : "bg-card text-foreground/70 hover:text-foreground boty-shadow"}`}>{c.name}</button>
              ))}
            </div>
            <div className="flex items-center gap-3">
              <select value={sort} onChange={(e) => setSort(e.target.value)} className="bg-card border border-border rounded-full px-4 py-2 text-sm boty-shadow focus:outline-none">
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Top Rated</option>
              </select>
              <span className="text-sm text-muted-foreground">{results.length} results</span>
            </div>
          </div>

          {/* Mobile filters */}
          {showFilters && (
            <div className="lg:hidden mb-6 flex flex-wrap gap-2">
              <button onClick={() => setCategory("all")} className={`px-4 py-2 rounded-full text-sm ${category === "all" ? "bg-primary text-primary-foreground" : "bg-card boty-shadow"}`}>All</button>
              {categories.map((c) => (
                <button key={c.slug} onClick={() => setCategory(c.slug)} className={`px-4 py-2 rounded-full text-sm ${category === c.slug ? "bg-primary text-primary-foreground" : "bg-card boty-shadow"}`}>{c.name}</button>
              ))}
            </div>
          )}

          {results.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-20 h-20 rounded-full bg-card flex items-center justify-center mx-auto mb-6 boty-shadow">
                <Search className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-lg text-foreground mb-2">No results for &ldquo;{query}&rdquo;</p>
              <p className="text-sm text-muted-foreground mb-6">Try a different search term or browse by category.</p>
              <Link href="/shop" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Browse All</Link>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {results.map((p) => (
                <div key={p.id} className="bg-card rounded-3xl overflow-hidden boty-shadow group">
                  <Link href={`/product/${p.id}`} className="relative aspect-square block bg-muted overflow-hidden">
                    <Image src={p.image} alt={p.name} fill className="object-cover boty-transition group-hover:scale-105" />
                    {p.badge && <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs bg-white text-black">{p.badge}</span>}
                  </Link>
                  <div className="p-5">
                    <h3 className="font-serif text-lg text-foreground mb-1">{p.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{p.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-foreground">${p.price}</span>
                      <button onClick={() => addItem({ id: p.id, name: p.name, description: p.description, price: p.price, image: p.image })} className="w-9 h-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 boty-transition" aria-label="Add to cart">
                        <ShoppingBag className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </main>
  )
}
