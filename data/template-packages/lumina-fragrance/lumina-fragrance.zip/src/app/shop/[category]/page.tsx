import { use } from "react"
import { notFound } from "next/navigation"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { ProductGrid } from "@/components/shared/product-grid"
import { categories, productsByCategory } from "@/data/products"

export default function CategoryPage({ params }: { params: Promise<{ category: string }> }) {
  const { category } = use(params)
  const cat = categories.find((c) => c.slug === category)
  if (!cat) notFound()
  const items = productsByCategory(category)

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">{cat.name}</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">{cat.name}</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{cat.description}. {items.length} {items.length === 1 ? "product" : "products"} available.</p>
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {categories.map((c) => (
              <a key={c.slug} href={`/shop/${c.slug}`} className={`px-4 py-2 rounded-full text-sm boty-transition ${c.slug === category ? "bg-primary text-primary-foreground" : "bg-card text-foreground/70 hover:text-foreground boty-shadow"}`}>{c.name}</a>
            ))}
          </div>

          {items.length === 0 ? (
            <div className="text-center py-20"><p className="text-lg text-muted-foreground">No products in this category yet.</p></div>
          ) : (
            <ProductGrid items={items} />
          )}
        </div>
      </div>
      <Footer />
    </main>
  )
}
