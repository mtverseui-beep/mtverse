"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { ShoppingBag, SlidersHorizontal, X } from "lucide-react"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useCart } from "@/components/boty/cart-context"

const products = [
  // Body Mists
  {
    id: "cloud-veil-body-mist",
    name: "Cloud Veil Body Mist",
    description: "Soft musk, white petals, clean air",
    price: 38,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80",
    badge: "Bestseller",
    category: "mists"
  },
  {
    id: "rose-milk-body-mist",
    name: "Rose Milk Body Mist",
    description: "Fresh rose petals, almond milk",
    price: 38,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80",
    badge: null,
    category: "mists"
  },
  {
    id: "vanilla-hour-fragrance-mist",
    name: "Vanilla Hour Fragrance Mist",
    description: "Bourbon vanilla, tonka, golden amber",
    price: 44,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80",
    badge: "Bestseller",
    category: "mists"
  },
  {
    id: "evening-velvet-body-mist",
    name: "Evening Velvet Body Mist",
    description: "Plum, black amber, velvet rose",
    price: 46,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=800&q=80",
    badge: "New",
    category: "mists"
  },
  // Hair Perfumes
  {
    id: "amber-bloom-hair-perfume",
    name: "Amber Bloom Hair Perfume",
    description: "Warm amber, night-blooming jasmine",
    price: 42,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
    badge: "Bestseller",
    category: "hair"
  },
  {
    id: "warm-skin-hair-perfume",
    name: "Warm Skin Hair Perfume",
    description: "Sun-warmed skin, amber, sandalwood",
    price: 42,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
    badge: null,
    category: "hair"
  },
  {
    id: "soft-musk-travel-mini",
    name: "Soft Musk Travel Mini",
    description: "Clean musk in a 15ml companion",
    price: 22,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
    badge: "Travel",
    category: "hair"
  },
  {
    id: "bloom-layering-duo",
    name: "Bloom Layering Duo",
    description: "Body mist + hair perfume set",
    price: 72,
    originalPrice: 80,
    image: "https://images.unsplash.com/photo-1587017539504-67cfbddac569?auto=format&fit=crop&w=800&q=80",
    badge: "Sale",
    category: "hair"
  },
  // Room Sprays
  {
    id: "citrus-linen-room-spray",
    name: "Citrus Linen Room Spray",
    description: "Cold-pressed citrus, white tea, fresh linen",
    price: 28,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1600573472556-e636c2acda88?auto=format&fit=crop&w=800&q=80",
    badge: "New",
    category: "room"
  },
  {
    id: "clean-cotton-room-spray",
    name: "Clean Cotton Room Spray",
    description: "Fresh laundry, white musk, soft cedar",
    price: 28,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=800&q=80",
    badge: null,
    category: "room"
  },
  {
    id: "calm-linen-pillow-mist",
    name: "Calm Linen Pillow Mist",
    description: "Lavender, vanilla, soft cedar for rest",
    price: 32,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=800&q=80",
    badge: "Bestseller",
    category: "room"
  },
  {
    id: "moonlit-amber-gift-set",
    name: "Moonlit Amber Gift Set",
    description: "Three amber rituals in a keepsake box",
    price: 96,
    originalPrice: 116,
    image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=800&q=80",
    badge: "Sale",
    category: "room"
  },
  // Discovery Sets
  {
    id: "golden-fig-discovery-set",
    name: "Golden Fig Discovery Set",
    description: "Five minis to find your signature",
    price: 48,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=800&q=80",
    badge: "Bestseller",
    category: "sets"
  },
  {
    id: "everyday-scent-wardrobe",
    name: "Everyday Scent Wardrobe",
    description: "Six minis for every day of the week",
    price: 78,
    originalPrice: null as number | null,
    image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=800&q=80",
    badge: "New",
    category: "sets"
  },
  {
    id: "fresh-petal-travel-trio",
    name: "Fresh Petal Travel Trio",
    description: "Three 15ml minis for soft mornings",
    price: 54,
    originalPrice: 60,
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
    badge: "Sale",
    category: "sets"
  }
]

const categories = ["all", "mists", "hair", "room", "sets"]
const categoryLabels: Record<string, string> = {
  all: "All",
  mists: "Body Mists",
  hair: "Hair Perfumes",
  room: "Room Sprays",
  sets: "Discovery Sets",
}

export default function ShopPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [showFilters, setShowFilters] = useState(false)
  const [isVisible, setIsVisible] = useState(false)
  const gridRef = useRef<HTMLDivElement>(null)
  const { addItem } = useCart()

  const filteredProducts = selectedCategory === "all"
    ? products
    : products.filter(p => p.category === selectedCategory)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (gridRef.current) {
      observer.observe(gridRef.current)
    }

    return () => {
      if (gridRef.current) {
        observer.unobserve(gridRef.current)
      }
    }
  }, [])

  // Reset animation when category changes
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setIsVisible(false)
    const timer = setTimeout(() => setIsVisible(true), 50)
    return () => clearTimeout(timer)
  }, [selectedCategory])

  return (
    <main className="min-h-screen">
      <Header />

      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">
              Our Collection
            </span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">
              Shop All Products
            </h1>
            <p className="text-lg text-muted-foreground max-w-md mx-auto">
              Discover our complete range of body mists, hair perfumes, and room sprays
            </p>
          </div>

          {/* Filter Bar */}
          <div className="flex items-center justify-between mb-10 pb-6 border-b border-border/50">
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="lg:hidden inline-flex items-center gap-2 text-sm text-foreground"
            >
              <SlidersHorizontal className="w-4 h-4" />
              Filters
            </button>

            {/* Desktop Categories */}
            <div className="hidden lg:flex items-center gap-2 flex-wrap">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm boty-transition ${
                    selectedCategory === category
                      ? "bg-primary text-primary-foreground"
                      : "bg-card text-foreground/70 hover:text-foreground boty-shadow"
                  }`}
                >
                  {categoryLabels[category]}
                </button>
              ))}
            </div>

            <span className="text-sm text-muted-foreground">
              {filteredProducts.length} {filteredProducts.length === 1 ? "product" : "products"}
            </span>
          </div>

          {/* Mobile Filters */}
          {showFilters && (
            <div className="lg:hidden fixed inset-0 z-50 bg-background">
              <div className="p-6">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="font-serif text-2xl text-foreground">Filters</h2>
                  <button
                    type="button"
                    onClick={() => setShowFilters(false)}
                    className="p-2 text-foreground/70 hover:text-foreground"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="space-y-3">
                  {categories.map((category) => (
                    <button
                      key={category}
                      type="button"
                      onClick={() => {
                        setSelectedCategory(category)
                        setShowFilters(false)
                      }}
                      className={`w-full px-6 py-4 rounded-2xl text-left boty-transition ${
                        selectedCategory === category
                          ? "bg-primary text-primary-foreground"
                          : "bg-card text-foreground boty-shadow"
                      }`}
                    >
                      {categoryLabels[category]}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Product Grid */}
          <div
            ref={gridRef}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredProducts.map((product, index) => (
              <ProductCard
                key={product.id}
                product={product}
                index={index}
                isVisible={isVisible}
                onAdd={() => addItem({
                  id: product.id,
                  name: product.name,
                  description: product.description,
                  price: product.price,
                  image: product.image
                })}
              />
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

function ProductCard({
  product,
  index,
  isVisible,
  onAdd,
}: {
  product: typeof products[0]
  index: number
  isVisible: boolean
  onAdd: () => void
}) {
  const [imageLoaded, setImageLoaded] = useState(false)

  return (
    <Link
      href={`/product/${product.id}`}
      className={`group transition-all duration-700 ease-out ${
        isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
      }`}
      style={{ transitionDelay: `${index * 80}ms` }}
    >
      <div className="bg-card rounded-3xl overflow-hidden boty-shadow boty-transition group-hover:scale-[1.02]">
        {/* Image */}
        <div className="relative aspect-square bg-muted overflow-hidden">
          {/* Skeleton */}
          <div
            className={`absolute inset-0 bg-gradient-to-br from-muted via-muted/50 to-muted animate-pulse transition-opacity duration-500 ${
              imageLoaded ? 'opacity-0' : 'opacity-100'
            }`}
          />

          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            fill
            className={`object-cover boty-transition group-hover:scale-105 transition-opacity duration-500 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={() => setImageLoaded(true)}
          />
          {/* Badge */}
          {product.badge && (
            <span
              className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs tracking-wide ${
                product.badge === "Sale"
                  ? "bg-destructive/10 text-destructive"
                  : product.badge === "New"
                  ? "bg-primary/10 text-primary"
                  : "bg-accent text-accent-foreground"
              }`}
            >
              {product.badge}
            </span>
          )}
          {/* Quick add button */}
          <button
            type="button"
            className="absolute bottom-4 right-4 w-12 h-12 rounded-full bg-background/90 backdrop-blur-sm flex items-center justify-center opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 boty-transition boty-shadow"
            onClick={(e) => {
              e.preventDefault()
              e.stopPropagation()
              onAdd()
            }}
            aria-label="Add to cart"
          >
            <ShoppingBag className="w-5 h-5 text-foreground" />
          </button>
        </div>

        {/* Info */}
        <div className="p-6">
          <h3 className="font-serif text-xl text-foreground mb-1">{product.name}</h3>
          <p className="text-sm text-muted-foreground mb-4">{product.description}</p>
          <div className="flex items-center gap-2">
            <span className="text-lg font-medium text-foreground">${product.price}</span>
            {product.originalPrice && (
              <span className="text-sm text-muted-foreground line-through">
                ${product.originalPrice}
              </span>
            )}
          </div>
        </div>
      </div>
    </Link>
  )
}
