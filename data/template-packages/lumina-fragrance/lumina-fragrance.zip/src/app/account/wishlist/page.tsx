"use client"

import Image from "next/image"
import Link from "next/link"
import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { products } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { Heart, ShoppingBag, Trash2, ArrowRight } from "lucide-react"

export default function AccountWishlistPage() {
  const [ids, setIds] = useLocalStorage<string[]>("lumina-wishlist", [])
  const { addItem } = useCart()
  const items = products.filter((p) => ids.includes(p.id))
  const remove = (id: string) => setIds((prev) => prev.filter((x) => x !== id))

  return (
    <AccountLayout title="Wishlist">
      {items.length === 0 ? (
        <Reveal className="bg-card rounded-3xl p-12 boty-shadow text-center">
          <Heart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-lg text-foreground mb-2">Your wishlist is empty</p>
          <p className="text-sm text-muted-foreground mb-6">Save your favorite fragrances for later.</p>
          <Link href="/shop" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Browse Products <ArrowRight className="w-4 h-4" /></Link>
        </Reveal>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((p, i) => (
            <Reveal key={p.id} delay={i * 60} className="bg-card rounded-3xl overflow-hidden boty-shadow group">
              <Link href={`/product/${p.id}`} className="relative aspect-square block bg-muted overflow-hidden">
                <Image src={p.image} alt={p.name} fill className="object-cover boty-transition group-hover:scale-105" />
                {p.badge && <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs bg-white text-black">{p.badge}</span>}
              </Link>
              <div className="p-4">
                <h3 className="font-serif text-base text-foreground mb-1 line-clamp-1">{p.name}</h3>
                <p className="text-xs text-muted-foreground mb-3 line-clamp-1">{p.description}</p>
                <div className="flex items-center justify-between">
                  <span className="font-medium text-foreground">${p.price}</span>
                  <div className="flex gap-2">
                    <button onClick={() => addItem({ id: p.id, name: p.name, description: p.description, price: p.price, image: p.image })} className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 boty-transition" aria-label="Add to cart"><ShoppingBag className="w-3.5 h-3.5" /></button>
                    <button onClick={() => remove(p.id)} className="w-8 h-8 rounded-full bg-muted text-muted-foreground hover:text-destructive flex items-center justify-center boty-transition" aria-label="Remove"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      )}
    </AccountLayout>
  )
}
