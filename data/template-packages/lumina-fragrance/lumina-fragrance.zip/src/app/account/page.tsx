import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import Link from "next/link"
import { Package, Gift, RefreshCw, Heart, ArrowRight } from "lucide-react"

export default function AccountDashboardPage() {
  const stats = [
    { label: "Total Orders", value: "12", icon: Package, href: "/account/orders" },
    { label: "Rewards Points", value: "1,240", icon: Gift, href: "/account/rewards" },
    { label: "Active Subscriptions", value: "1", icon: RefreshCw, href: "/account/subscriptions" },
    { label: "Wishlist Items", value: "5", icon: Heart, href: "/account/wishlist" },
  ]

  const recentOrders = [
    { number: "LUM-100612", date: "Jul 2, 2026", status: "Processing", total: 118.80 },
    { number: "LUM-100589", date: "Jun 30, 2026", status: "Shipped", total: 103.68 },
    { number: "LUM-100482", date: "Jun 22, 2026", status: "Delivered", total: 86.40 },
  ]

  return (
    <AccountLayout title="Dashboard">
      <div className="space-y-6">
        {/* Welcome */}
        <Reveal className="bg-gradient-to-br from-primary to-plum rounded-3xl p-6 boty-shadow text-ivory">
          <p className="text-sm opacity-80 mb-1">Welcome back,</p>
          <h2 className="font-serif text-2xl mb-4">Aurelia Brennan</h2>
          <p className="text-sm opacity-80">You're a Gold Member with 1,240 rewards points. You're 760 points away from Platinum.</p>
          <div className="mt-4 h-2 bg-ivory/20 rounded-full overflow-hidden">
            <div className="h-full bg-gold" style={{ width: "62%" }} />
          </div>
        </Reveal>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i * 60}>
              <Link href={s.href} className="block bg-card rounded-2xl p-5 boty-shadow hover:scale-[1.02] boty-transition">
                <s.icon className="w-6 h-6 text-primary mb-2" />
                <p className="font-serif text-2xl text-foreground">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </Link>
            </Reveal>
          ))}
        </div>

        {/* Recent orders */}
        <Reveal className="bg-card rounded-3xl p-6 boty-shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-serif text-xl text-foreground">Recent Orders</h2>
            <Link href="/account/orders" className="text-sm text-primary hover:underline">View all</Link>
          </div>
          <div className="space-y-3">
            {recentOrders.map((o) => (
              <Link key={o.number} href={`/account/orders/${o.number.toLowerCase()}`} className="flex items-center justify-between p-4 bg-background rounded-2xl hover:scale-[1.01] boty-transition">
                <div>
                  <p className="font-medium text-foreground text-sm">{o.number}</p>
                  <p className="text-xs text-muted-foreground">{o.date}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${o.status === "Delivered" ? "bg-primary/10 text-primary" : o.status === "Shipped" ? "bg-gold/10 text-gold" : "bg-muted text-muted-foreground"}`}>{o.status}</span>
                <p className="font-medium text-foreground">${o.total}</p>
                <ArrowRight className="w-4 h-4 text-muted-foreground" />
              </Link>
            ))}
          </div>
        </Reveal>
      </div>
    </AccountLayout>
  )
}
