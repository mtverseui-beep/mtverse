"use client"

import { useState } from "react"
import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import { User, Mail, Phone, Check } from "lucide-react"
import { toast } from "sonner"

export default function AccountProfilePage() {
  const [form, setForm] = useState({ firstName: "Aurelia", lastName: "Brennan", email: "aurelia@example.com", phone: "+1 (415) 555-0123", birthday: "1992-03-15", pronouns: "she/her" })
  const [loading, setLoading] = useState(false)

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => { setLoading(false); toast.success("Profile updated successfully") }, 800)
  }

  return (
    <AccountLayout title="Profile">
      <Reveal className="bg-card rounded-3xl p-6 boty-shadow">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-plum text-ivory flex items-center justify-center font-serif text-3xl">A</div>
          <div>
            <p className="font-serif text-xl text-foreground">{form.firstName} {form.lastName}</p>
            <p className="text-sm text-muted-foreground">Gold Member since Aug 2025</p>
            <button className="text-xs text-primary hover:underline mt-1">Change photo</button>
          </div>
        </div>

        <form onSubmit={handleSave} className="grid sm:grid-cols-2 gap-4">
          <div><label className="text-sm font-medium text-foreground mb-2 block">First Name</label><div className="relative"><User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} className="w-full bg-background border border-border rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-primary" /></div></div>
          <div><label className="text-sm font-medium text-foreground mb-2 block">Last Name</label><input value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /></div>
          <div><label className="text-sm font-medium text-foreground mb-2 block">Email</label><div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full bg-background border border-border rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-primary" /></div></div>
          <div><label className="text-sm font-medium text-foreground mb-2 block">Phone</label><div className="relative"><Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full bg-background border border-border rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-primary" /></div></div>
          <div><label className="text-sm font-medium text-foreground mb-2 block">Birthday</label><input type="date" value={form.birthday} onChange={(e) => setForm({ ...form, birthday: e.target.value })} className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /></div>
          <div><label className="text-sm font-medium text-foreground mb-2 block">Pronouns</label><select value={form.pronouns} onChange={(e) => setForm({ ...form, pronouns: e.target.value })} className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary"><option>she/her</option><option>he/him</option><option>they/them</option><option>Prefer not to say</option></select></div>
          <div className="sm:col-span-2 mt-2"><button type="submit" disabled={loading} className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-8 py-3 rounded-full text-sm font-medium boty-transition hover:bg-primary/90 disabled:opacity-60 boty-shadow">{loading ? <><span className="lumina-spinner" /> Saving...</> : <><Check className="w-4 h-4" /> Save Changes</>}</button></div>
        </form>
      </Reveal>
    </AccountLayout>
  )
}
