"use client"

import { useState } from "react"
import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import { Shield, Lock, Eye, Smartphone, Check } from "lucide-react"
import { toast } from "sonner"

export default function AccountSecurityPage() {
  const [twoFA, setTwoFA] = useState(true)
  const [loading, setLoading] = useState(false)
  const [pwForm, setPwForm] = useState({ current: "", next: "", confirm: "" })

  const handlePw = (e: React.FormEvent) => {
    e.preventDefault()
    if (pwForm.next !== pwForm.confirm) { toast.error("Passwords don't match"); return }
    if (pwForm.next.length < 8) { toast.error("Password must be at least 8 characters"); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); setPwForm({ current: "", next: "", confirm: "" }); toast.success("Password updated") }, 800)
  }

  return (
    <AccountLayout title="Security">
      <div className="space-y-6">
        <Reveal className="bg-card rounded-3xl p-6 boty-shadow">
          <h2 className="font-serif text-xl text-foreground mb-4 flex items-center gap-2"><Lock className="w-5 h-5 text-primary" /> Change Password</h2>
          <form onSubmit={handlePw} className="space-y-4">
            <div><label className="text-sm font-medium text-foreground mb-2 block">Current Password</label><input type="password" value={pwForm.current} onChange={(e) => setPwForm({ ...pwForm, current: e.target.value })} required className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /></div>
            <div><label className="text-sm font-medium text-foreground mb-2 block">New Password</label><input type="password" value={pwForm.next} onChange={(e) => setPwForm({ ...pwForm, next: e.target.value })} required className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /></div>
            <div><label className="text-sm font-medium text-foreground mb-2 block">Confirm New Password</label><input type="password" value={pwForm.confirm} onChange={(e) => setPwForm({ ...pwForm, confirm: e.target.value })} required className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /></div>
            <p className="text-xs text-muted-foreground">Use at least 8 characters with a mix of letters, numbers, and symbols.</p>
            <button type="submit" disabled={loading} className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm font-medium boty-transition hover:bg-primary/90 disabled:opacity-60 boty-shadow">{loading ? <><span className="lumina-spinner" /> Updating...</> : "Update Password"}</button>
          </form>
        </Reveal>

        <Reveal delay={80} className="bg-card rounded-3xl p-6 boty-shadow">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0"><Smartphone className="w-6 h-6 text-primary" /></div>
              <div>
                <p className="font-medium text-foreground">Two-Factor Authentication</p>
                <p className="text-sm text-muted-foreground">{twoFA ? "Enabled — code sent to your phone" : "Add an extra layer of security"}</p>
              </div>
            </div>
            <button onClick={() => { setTwoFA(!twoFA); toast.success(twoFA ? "2FA disabled" : "2FA enabled") }} className={`relative w-12 h-7 rounded-full boty-transition ${twoFA ? "bg-primary" : "bg-muted"}`}><span className={`absolute top-1 w-5 h-5 rounded-full bg-background boty-transition ${twoFA ? "left-6" : "left-1"}`} /></button>
          </div>
        </Reveal>

        <Reveal delay={120} className="bg-card rounded-3xl p-6 boty-shadow">
          <h2 className="font-serif text-xl text-foreground mb-4 flex items-center gap-2"><Eye className="w-5 h-5 text-primary" /> Recent Activity</h2>
          <div className="divide-y divide-border/50">
            {[
              { device: "Chrome on Mac", location: "San Francisco, CA", time: "2 hours ago", current: true },
              { device: "Safari on iPhone", location: "San Francisco, CA", time: "1 day ago", current: false },
              { device: "Chrome on Android", location: "Oakland, CA", time: "3 days ago", current: false },
            ].map((s, i) => (
              <div key={i} className="flex items-center justify-between py-3">
                <div><p className="text-sm text-foreground">{s.device} {s.current && <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary ml-1">Current</span>}</p><p className="text-xs text-muted-foreground">{s.location} • {s.time}</p></div>
                {!s.current && <button onClick={() => toast.success("Session signed out")} className="text-xs text-destructive hover:underline">Sign out</button>}
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={160} className="bg-card rounded-3xl p-6 boty-shadow flex items-center gap-3">
          <Shield className="w-5 h-5 text-primary flex-shrink-0" />
          <p className="text-sm text-muted-foreground">Your account is protected. Last security review: today. <Check className="w-3.5 h-3.5 text-primary inline" /> All clear.</p>
        </Reveal>
      </div>
    </AccountLayout>
  )
}
