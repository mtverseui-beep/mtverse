import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import { Gift, Star, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function AccountRewardsPage() {
  const points = 1240
  const tier = "Gold"
  const nextTier = "Platinum"
  const pointsToNext = 760
  const progress = (points / 2000) * 100

  const history = [
    { date: "Jun 30, 2026", action: "Order LUM-100589", points: +96 },
    { date: "Jun 22, 2026", action: "Order LUM-100482", points: +80 },
    { date: "Jun 15, 2026", action: "Referred a friend", points: +500 },
    { date: "Jun 10, 2026", action: "Wrote a review", points: +50 },
    { date: "May 18, 2026", action: "Order LUM-100345", points: +54 },
    { date: "May 1, 2026", action: "Redeemed $10 off", points: -250 },
  ]

  return (
    <AccountLayout title="Rewards">
      <div className="space-y-6">
        <Reveal className="bg-gradient-to-br from-gold to-clay rounded-3xl p-6 boty-shadow text-ivory">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm opacity-80">Your Points</p>
              <p className="font-serif text-4xl">{points.toLocaleString()}</p>
            </div>
            <Gift className="w-10 h-10 opacity-80" />
          </div>
          <p className="text-sm opacity-80 mb-2">You're a {tier} Member. {pointsToNext} points to {nextTier}.</p>
          <div className="h-2 bg-ivory/20 rounded-full overflow-hidden"><div className="h-full bg-ivory" style={{ width: `${progress}%` }} /></div>
        </Reveal>

        <Reveal delay={80} className="bg-card rounded-3xl p-6 boty-shadow">
          <h2 className="font-serif text-xl text-foreground mb-4">Redeem Points</h2>
          <div className="space-y-2">
            {[{ pts: 250, reward: "$10 off" }, { pts: 500, reward: "$25 off" }, { pts: 1000, reward: "$55 off" }].map((r) => (
              <div key={r.pts} className="flex items-center justify-between p-3 bg-background rounded-2xl">
                <div className="flex items-center gap-3"><Star className="w-4 h-4 text-gold" /><span className="text-sm text-foreground">{r.reward} any order</span></div>
                <div className="flex items-center gap-3"><span className="text-xs text-muted-foreground">{r.pts} pts</span><button disabled={points < r.pts} className="text-xs px-3 py-1.5 rounded-full bg-foreground text-background disabled:opacity-40 boty-transition">Redeem</button></div>
              </div>
            ))}
          </div>
          <Link href="/rewards" className="inline-flex items-center gap-1 text-sm text-primary mt-4 hover:underline">See all rewards <ArrowRight className="w-3.5 h-3.5" /></Link>
        </Reveal>

        <Reveal delay={120} className="bg-card rounded-3xl p-6 boty-shadow">
          <h2 className="font-serif text-xl text-foreground mb-4">Points History</h2>
          <div className="divide-y divide-border/50">
            {history.map((h, i) => (
              <div key={i} className="flex items-center justify-between py-3">
                <div><p className="text-sm text-foreground">{h.action}</p><p className="text-xs text-muted-foreground">{h.date}</p></div>
                <span className={`font-medium ${h.points > 0 ? "text-primary" : "text-destructive"}`}>{h.points > 0 ? "+" : ""}{h.points}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </AccountLayout>
  )
}
