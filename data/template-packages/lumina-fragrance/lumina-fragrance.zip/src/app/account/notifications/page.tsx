"use client"

import { useState } from "react"
import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import { Bell, Check, Package, Gift, Sparkles } from "lucide-react"

const initialNotifs = [
  { id: "n1", title: "Your order LUM-100612 is processing", body: "We are preparing your order for shipment.", date: "2 hours ago", read: false, type: "order" },
  { id: "n2", title: "Your order LUM-100589 has shipped", body: "Tracking number 1Z999AA10198765432 is now available.", date: "1 day ago", read: false, type: "order" },
  { id: "n3", title: "You earned 96 rewards points", body: "Points from order LUM-100589 have been added to your account.", date: "3 days ago", read: true, type: "rewards" },
  { id: "n4", title: "New arrival: Everyday Scent Wardrobe", body: "Six 8ml minis in a soft-touch case. Now available.", date: "5 days ago", read: true, type: "marketing" },
  { id: "n5", title: "Your subscription ships soon", body: "Cloud Veil Body Mist ships on August 22.", date: "1 week ago", read: true, type: "subscription" },
]

const iconMap = { order: Package, rewards: Gift, marketing: Sparkles, subscription: Bell }

export default function AccountNotificationsPage() {
  const [notifs, setNotifs] = useState(initialNotifs)

  const markAllRead = () => { setNotifs((prev) => prev.map((n) => ({ ...n, read: true }))) }
  const markRead = (id: string) => { setNotifs((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n)) }

  return (
    <AccountLayout title="Notifications">
      <div className="space-y-4">
        <div className="flex justify-end">
          <button onClick={markAllRead} className="text-sm text-primary hover:underline">Mark all as read</button>
        </div>
        {notifs.map((n, i) => {
          const Icon = iconMap[n.type as keyof typeof iconMap]
          return (
            <Reveal key={n.id} delay={i * 50} className={`bg-card rounded-3xl p-5 boty-shadow ${!n.read ? "ring-1 ring-primary/30" : ""}`}>
              <button onClick={() => markRead(n.id)} className="flex items-start gap-4 text-left w-full">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${n.read ? "bg-muted" : "bg-primary/10"}`}><Icon className={`w-5 h-5 ${n.read ? "text-muted-foreground" : "text-primary"}`} /></div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {!n.read && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
                    <p className="font-medium text-foreground">{n.title}</p>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">{n.body}</p>
                  <p className="text-xs text-muted-foreground">{n.date}</p>
                </div>
                {n.read && <Check className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
              </button>
            </Reveal>
          )
        })}
      </div>
    </AccountLayout>
  )
}
