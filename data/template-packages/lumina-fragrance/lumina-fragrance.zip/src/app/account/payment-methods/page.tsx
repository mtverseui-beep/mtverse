"use client"

import { useState } from "react"
import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import { Plus, CreditCard, Check, Trash2, Lock } from "lucide-react"
import { toast } from "sonner"

const initialCards = [
  { id: "1", brand: "Visa", last4: "4242", expiry: "08/27", isDefault: true },
  { id: "2", brand: "Mastercard", last4: "8810", expiry: "11/26", isDefault: false },
]

export default function AccountPaymentMethodsPage() {
  const [cards, setCards] = useState(initialCards)
  const [showForm, setShowForm] = useState(false)

  const setDefault = (id: string) => { setCards((prev) => prev.map((c) => ({ ...c, isDefault: c.id === id }))); toast.success("Default card updated") }
  const remove = (id: string) => { setCards((prev) => prev.filter((c) => c.id !== id)); toast.success("Card removed") }

  return (
    <AccountLayout title="Payment Methods">
      <div className="space-y-4">
        {cards.map((c, i) => (
          <Reveal key={c.id} delay={i * 60} className="bg-card rounded-3xl p-6 boty-shadow">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center"><CreditCard className="w-6 h-6 text-primary" /></div>
                <div>
                  <p className="font-medium text-foreground">{c.brand} ending in {c.last4}</p>
                  <p className="text-xs text-muted-foreground">Expires {c.expiry}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {c.isDefault ? <span className="text-xs px-3 py-1.5 rounded-full bg-primary/10 text-primary inline-flex items-center gap-1"><Check className="w-3 h-3" /> Default</span> : <button onClick={() => setDefault(c.id)} className="text-xs px-3 py-1.5 rounded-full border border-border text-foreground hover:bg-muted boty-transition">Set default</button>}
                <button onClick={() => remove(c.id)} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-destructive/10 hover:text-destructive boty-transition" aria-label="Delete"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          </Reveal>
        ))}

        <Reveal delay={120}>
          <button onClick={() => setShowForm(!showForm)} className="w-full bg-card rounded-3xl p-6 boty-shadow border-2 border-dashed border-border hover:border-primary boty-transition inline-flex items-center justify-center gap-2 text-foreground">
            <Plus className="w-5 h-5" /> Add New Card
          </button>
        </Reveal>

        {showForm && (
          <Reveal className="bg-card rounded-3xl p-6 boty-shadow">
            <h3 className="font-serif text-xl text-foreground mb-4 flex items-center gap-2"><Lock className="w-4 h-4 text-primary" /> Add Card Securely</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <input placeholder="Card number" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
              <input placeholder="Name on card" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
              <input placeholder="MM/YY" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
              <input placeholder="CVC" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
            </div>
            <div className="flex gap-3 mt-4">
              <button onClick={() => { setShowForm(false); toast.success("Card added") }} className="flex-1 bg-primary text-primary-foreground py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Add Card</button>
              <button onClick={() => setShowForm(false)} className="flex-1 border border-border text-foreground py-3 rounded-full text-sm boty-transition hover:bg-muted">Cancel</button>
            </div>
          </Reveal>
        )}

        <Reveal className="bg-card rounded-3xl p-6 boty-shadow flex items-center gap-3">
          <Lock className="w-5 h-5 text-primary flex-shrink-0" />
          <p className="text-sm text-muted-foreground">Your payment information is encrypted and stored securely. We never store your CVC.</p>
        </Reveal>
      </div>
    </AccountLayout>
  )
}
