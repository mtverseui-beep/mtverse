import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import Link from "next/link"
import { Package, ArrowRight } from "lucide-react"

export default function AccountOrdersPage() {
  const orders = [
    { number: "LUM-100612", date: "Jul 2, 2026", status: "Processing", total: 118.80, items: 2 },
    { number: "LUM-100589", date: "Jun 30, 2026", status: "Shipped", total: 103.68, items: 1 },
    { number: "LUM-100482", date: "Jun 22, 2026", status: "Delivered", total: 86.40, items: 2 },
    { number: "LUM-100345", date: "May 18, 2026", status: "Delivered", total: 54.00, items: 1 },
    { number: "LUM-100218", date: "Apr 12, 2026", status: "Delivered", total: 142.00, items: 3 },
  ]

  return (
    <AccountLayout title="Orders">
      <Reveal className="bg-card rounded-3xl boty-shadow overflow-hidden">
        <div className="divide-y divide-border/50">
          {orders.map((o) => (
            <Link key={o.number} href={`/account/orders/${o.number.toLowerCase()}`} className="flex items-center gap-4 p-5 hover:bg-background boty-transition">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Package className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground">{o.number}</p>
                <p className="text-xs text-muted-foreground">{o.date} • {o.items} {o.items === 1 ? "item" : "items"}</p>
              </div>
              <span className={`text-xs px-3 py-1 rounded-full ${o.status === "Delivered" ? "bg-primary/10 text-primary" : o.status === "Shipped" ? "bg-gold/10 text-gold" : "bg-muted text-muted-foreground"}`}>{o.status}</span>
              <p className="font-medium text-foreground hidden sm:block">${o.total}</p>
              <ArrowRight className="w-4 h-4 text-muted-foreground" />
            </Link>
          ))}
        </div>
      </Reveal>
    </AccountLayout>
  )
}
