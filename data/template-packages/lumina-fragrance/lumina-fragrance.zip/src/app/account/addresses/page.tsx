"use client"

import { useState } from "react"
import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import { Plus, Edit, Trash2, MapPin, Check } from "lucide-react"
import { toast } from "sonner"

const initialAddresses = [
  { id: "1", label: "Home", isDefault: true, fullName: "Aurelia Brennan", line1: "248 Marin Avenue", line2: "Apt 4B", city: "San Francisco", state: "CA", zip: "94117", country: "United States", phone: "+1 (415) 555-0123" },
  { id: "2", label: "Office", isDefault: false, fullName: "Aurelia Brennan", line1: "1100 Mission Street", line2: "Suite 410", city: "San Francisco", state: "CA", zip: "94103", country: "United States", phone: "+1 (415) 555-0123" },
]

export default function AccountAddressesPage() {
  const [addresses, setAddresses] = useState(initialAddresses)
  const [showForm, setShowForm] = useState(false)

  const setDefault = (id: string) => {
    setAddresses((prev) => prev.map((a) => ({ ...a, isDefault: a.id === id })))
    toast.success("Default address updated")
  }
  const remove = (id: string) => { setAddresses((prev) => prev.filter((a) => a.id !== id)); toast.success("Address removed") }

  return (
    <AccountLayout title="Addresses">
      <div className="space-y-4">
        {addresses.map((a, i) => (
          <Reveal key={a.id} delay={i * 60} className="bg-card rounded-3xl p-6 boty-shadow">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0"><MapPin className="w-5 h-5 text-primary" /></div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium text-foreground">{a.label}</p>
                    {a.isDefault && <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">Default</span>}
                  </div>
                  <p className="text-sm text-muted-foreground">{a.fullName}<br />{a.line1}{a.line2 ? `, ${a.line2}` : ""}<br />{a.city}, {a.state} {a.zip}<br />{a.country}<br />{a.phone}</p>
                </div>
              </div>
              <div className="flex gap-2">
                {!a.isDefault && <button onClick={() => setDefault(a.id)} className="text-xs px-3 py-1.5 rounded-full border border-border text-foreground hover:bg-muted boty-transition inline-flex items-center gap-1"><Check className="w-3 h-3" /> Set default</button>}
                <button onClick={() => toast.info("Edit coming soon")} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-primary/10 hover:text-primary boty-transition" aria-label="Edit"><Edit className="w-3.5 h-3.5" /></button>
                <button onClick={() => remove(a.id)} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-destructive/10 hover:text-destructive boty-transition" aria-label="Delete"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          </Reveal>
        ))}

        <Reveal delay={120}>
          <button onClick={() => setShowForm(!showForm)} className="w-full bg-card rounded-3xl p-6 boty-shadow border-2 border-dashed border-border hover:border-primary boty-transition inline-flex items-center justify-center gap-2 text-foreground">
            <Plus className="w-5 h-5" /> Add New Address
          </button>
        </Reveal>

        {showForm && (
          <Reveal className="bg-card rounded-3xl p-6 boty-shadow">
            <h3 className="font-serif text-xl text-foreground mb-4">New Address</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <input placeholder="Label (Home, Office...)" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
              <input placeholder="Full name" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
              <input placeholder="Street address" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
              <input placeholder="City" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
              <div className="grid grid-cols-2 gap-4"><input placeholder="State" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /><input placeholder="ZIP" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /></div>
              <input placeholder="Phone" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
            </div>
            <div className="flex gap-3 mt-4">
              <button onClick={() => { setShowForm(false); toast.success("Address added") }} className="flex-1 bg-primary text-primary-foreground py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Save Address</button>
              <button onClick={() => setShowForm(false)} className="flex-1 border border-border text-foreground py-3 rounded-full text-sm boty-transition hover:bg-muted">Cancel</button>
            </div>
          </Reveal>
        )}
      </div>
    </AccountLayout>
  )
}
