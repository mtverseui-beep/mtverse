import { AccountLayout } from "@/components/shared/account-layout"
import { Reveal } from "@/components/shared/reveal"
import Link from "next/link"
import { RefreshCw, Pause, ArrowRight } from "lucide-react"

export default function AccountSubscriptionsPage() {
  const subs = [
    { id: "sub-1", name: "Cloud Veil Body Mist — 50ml", frequency: "Every 2 months", nextDelivery: "August 22, 2026", price: 32.30, status: "Active" },
  ]

  return (
    <AccountLayout title="Subscriptions">
      <div className="space-y-4">
        {subs.map((s, i) => (
          <Reveal key={s.id} delay={i * 60} className="bg-card rounded-3xl p-6 boty-shadow">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0"><RefreshCw className="w-6 h-6 text-primary" /></div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium text-foreground">{s.name}</p>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">{s.status}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{s.frequency}</p>
                  <p className="text-sm text-muted-foreground">Next delivery: {s.nextDelivery}</p>
                  <p className="text-sm font-medium text-primary mt-1">${s.price} per delivery (15% off)</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="text-xs px-3 py-1.5 rounded-full border border-border text-foreground hover:bg-muted boty-transition">Edit</button>
                <button className="text-xs px-3 py-1.5 rounded-full border border-border text-foreground hover:bg-muted boty-transition inline-flex items-center gap-1"><Pause className="w-3 h-3" /> Pause</button>
              </div>
            </div>
          </Reveal>
        ))}

        <Reveal delay={120} className="bg-card rounded-3xl p-6 boty-shadow text-center">
          <p className="text-foreground mb-4">Want to add more rituals to your subscription?</p>
          <Link href="/subscriptions" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Manage Subscriptions <ArrowRight className="w-4 h-4" /></Link>
        </Reveal>
      </div>
    </AccountLayout>
  )
}
