import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { products } from "@/data/products"

const collectionData: Record<string, { name: string; tagline: string; description: string; image: string; ids: string[] }> = {
  "evening-velvet": { name: "Evening Velvet", tagline: "Warm, amber, and quietly intoxicating", description: "A capsule of warm ambers, soft musks, and velvet florals designed for the long evenings. Each scent leans toward depth without weight, designed to be felt more than noticed.", image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1600&q=80", ids: ["evening-velvet-body-mist", "moonlit-amber-gift-set", "warm-skin-hair-perfume"] },
  "fresh-petal": { name: "Fresh Petal", tagline: "Light florals for soft mornings", description: "A collection built around dewy florals and clean petals. Scents for unhurried mornings, fresh linens, and the first warmth of spring light through a window.", image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1600&q=80", ids: ["rose-milk-body-mist", "cloud-veil-body-mist", "fresh-petal-travel-trio"] },
  "vanilla-hour": { name: "Vanilla Hour", tagline: "Warm vanilla, soft amber, golden skin", description: "The hour just before evening, when the light softens and everything slows. Scents that feel like a second skin, warm and lightly sweet without ever becoming heavy.", image: "https://images.unsplash.com/photo-1601990102012-7c88cc2aa9a9?auto=format&fit=crop&w=1600&q=80", ids: ["vanilla-hour-fragrance-mist", "amber-bloom-hair-perfume", "everyday-scent-wardrobe"] },
  "citrus-bright": { name: "Citrus Bright", tagline: "Cold-pressed mornings and clean light", description: "A collection of crisp citrus and green top notes for the moments that need lifting. Scents that wake the senses without sharpness and settle into a clean, soft finish.", image: "https://images.unsplash.com/photo-1600573472556-e636c2acda88?auto=format&fit=crop&w=1600&q=80", ids: ["citrus-linen-room-spray", "golden-fig-discovery-set", "clean-cotton-room-spray"] },
  "calm-linen": { name: "Calm Linen", tagline: "Home rituals for soft landings", description: "A home fragrance collection for the soft moments — pillow mists, linen sprays, and room rituals that turn a room into a quiet place.", image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=1600&q=80", ids: ["calm-linen-pillow-mist", "clean-cotton-room-spray", "citrus-linen-room-spray"] },
  "bloom-layering": { name: "Bloom Layering", tagline: "Pair, mist, and build your own depth", description: "A collection built to be layered. Pairs body mists with hair perfumes and room sprays so each note can be worn alone or composed into a deeper, more personal signature.", image: "https://images.unsplash.com/photo-1587017539504-67cfbddac569?auto=format&fit=crop&w=1600&q=80", ids: ["bloom-layering-duo", "rose-milk-body-mist", "amber-bloom-hair-perfume"] },
}

export default function CollectionDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  return <CollectionDetail params={params} />
}

import { use } from "react"
import { ShoppingBag } from "lucide-react"
import { useCart } from "@/components/boty/cart-context"

function CollectionDetail({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params)
  const data = collectionData[slug] || collectionData["evening-velvet"]
  const items = data.ids.map((id) => products.find((p) => p.id === id)!).filter(Boolean)

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <Link href="/collections" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8">← All Collections</Link>

          {/* Hero */}
          <Reveal className="relative aspect-[21/9] rounded-3xl overflow-hidden boty-shadow mb-12">
            <Image src={data.image} alt={data.name} fill className="object-cover" priority />
            <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/30 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8 lg:p-12 text-ivory">
              <p className="text-xs tracking-[0.24em] uppercase text-gold mb-2">{data.tagline}</p>
              <h1 className="font-serif text-4xl md:text-6xl mb-4">{data.name}</h1>
              <p className="text-base text-ivory/80 max-w-2xl">{data.description}</p>
            </div>
          </Reveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((p, i) => (
              <Reveal key={p.id} delay={i * 80}>
                <ProductCard productId={p.id} />
              </Reveal>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}

function ProductCard({ productId }: { productId: string }) {
  const product = products.find((p) => p.id === productId)!
  const { addItem } = useCart()
  return (
    <div className="bg-card rounded-3xl overflow-hidden boty-shadow group">
      <Link href={`/product/${product.id}`} className="relative aspect-square block bg-muted overflow-hidden">
        <Image src={product.image} alt={product.name} fill className="object-cover boty-transition group-hover:scale-105" />
        {product.badge && <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs bg-white text-black">{product.badge}</span>}
      </Link>
      <div className="p-5">
        <h3 className="font-serif text-lg text-foreground mb-1">{product.name}</h3>
        <p className="text-sm text-muted-foreground mb-3">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="font-medium text-foreground">${product.price}</span>
          <button onClick={() => addItem({ id: product.id, name: product.name, description: product.description, price: product.price, image: product.image })} className="w-9 h-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 boty-transition" aria-label="Add to cart"><ShoppingBag className="w-4 h-4" /></button>
        </div>
      </div>
    </div>
  )
}
