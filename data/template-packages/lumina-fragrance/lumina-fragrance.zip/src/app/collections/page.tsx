import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { categories } from "@/data/products"

export default function CollectionsPage() {
  const collections = [
    { slug: "evening-velvet", name: "Evening Velvet", tagline: "Warm, amber, and quietly intoxicating", description: "A capsule of warm ambers, soft musks, and velvet florals designed for the long evenings.", image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1200&q=80" },
    { slug: "fresh-petal", name: "Fresh Petal", tagline: "Light florals for soft mornings", description: "A collection built around dewy florals and clean petals for unhurried mornings.", image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80" },
    { slug: "vanilla-hour", name: "Vanilla Hour", tagline: "Warm vanilla, soft amber, golden skin", description: "The hour just before evening. Scents that feel like a second skin, warm and lightly sweet.", image: "https://images.unsplash.com/photo-1601990102012-7c88cc2aa9a9?auto=format&fit=crop&w=1200&q=80" },
    { slug: "citrus-bright", name: "Citrus Bright", tagline: "Cold-pressed mornings and clean light", description: "Crisp citrus and green top notes for the moments that need lifting.", image: "https://images.unsplash.com/photo-1600573472556-e636c2acda88?auto=format&fit=crop&w=1200&q=80" },
    { slug: "calm-linen", name: "Calm Linen", tagline: "Home rituals for soft landings", description: "A home fragrance collection for the soft moments — pillow mists, linen sprays, room rituals.", image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=1200&q=80" },
    { slug: "bloom-layering", name: "Bloom Layering", tagline: "Pair, mist, and build your own depth", description: "A collection built to be layered. Pair body mists with hair perfumes and room sprays.", image: "https://images.unsplash.com/photo-1587017539504-67cfbddac569?auto=format&fit=crop&w=1200&q=80" },
  ]

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Curated Edits</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Collections</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Thoughtfully grouped fragrances, each telling a different mood or moment.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {collections.map((c, i) => (
              <Reveal key={c.slug} delay={i * 80}>
                <Link href={`/collections/${c.slug}`} className="group block relative aspect-[4/3] rounded-3xl overflow-hidden boty-shadow">
                  <Image src={c.image} alt={c.name} fill className="object-cover boty-transition group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-8 text-ivory">
                    <p className="text-xs tracking-[0.24em] uppercase text-gold mb-2">{c.tagline}</p>
                    <h2 className="font-serif text-3xl mb-2">{c.name}</h2>
                    <p className="text-sm text-ivory/80 max-w-md">{c.description}</p>
                    <span className="inline-flex items-center gap-2 mt-4 text-sm text-gold group-hover:gap-3 transition-all">Explore Collection →</span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>

          {/* Also browse by category */}
          <div className="mt-20">
            <h2 className="font-serif text-3xl text-foreground text-center mb-8">Or Browse by Category</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {categories.map((c) => (
                <Link key={c.slug} href={`/shop/${c.slug}`} className="bg-card rounded-2xl p-6 text-center boty-shadow hover:scale-[1.02] boty-transition">
                  <h3 className="font-serif text-xl text-foreground mb-1">{c.name}</h3>
                  <p className="text-xs text-muted-foreground">{c.description}</p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
