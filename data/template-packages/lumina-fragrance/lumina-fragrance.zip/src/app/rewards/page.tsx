import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Gift, Star, Award, Users, ShoppingBag, Heart } from "lucide-react"

export default function RewardsPage() {
  const tiers = [
    { name: "Silver", points: "0–499", perks: ["1 point per $1 spent", "Birthday gift", "Early sale access"], color: "from-taupe to-muted" },
    { name: "Gold", points: "500–1,999", perks: ["1.5 points per $1 spent", "Free shipping always", "Free samples every order", "Birthday gift"], color: "from-gold to-clay" },
    { name: "Platinum", points: "2,000+", perks: ["2 points per $1 spent", "Free express shipping", "Exclusive launches", "Personal scent consultation", "Birthday gift"], color: "from-plum to-espresso" },
  ]

  const waysToEarn = [
    { icon: ShoppingBag, title: "Every Purchase", points: "1–2 pts / $1" },
    { icon: Star, title: "Write a Review", points: "50 pts" },
    { icon: Users, title: "Refer a Friend", points: "500 pts" },
    { icon: Heart, title: "Follow on Social", points: "100 pts" },
    { icon: Gift, title: "Birthday Bonus", points: "200 pts" },
    { icon: Award, title: "Account Anniversary", points: "300 pts" },
  ]

  const rewards = [
    { points: 250, reward: "$10 off any order" },
    { points: 500, reward: "$25 off any order" },
    { points: 1000, reward: "$55 off any order" },
    { points: 2000, reward: "Free discovery set" },
    { points: 3500, reward: "Free full-size fragrance" },
    { points: 5000, reward: "Free gift set + $50 credit" },
  ]

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Earn As You Scent</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Lumina Rewards</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Earn points on every purchase and redeem them for discounts, free products, and exclusive perks.</p>
            <Link href="/sign-up" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow mt-6">
              Join Free <Gift className="w-4 h-4" />
            </Link>
          </div>

          {/* Tiers */}
          <Reveal className="mb-16">
            <h2 className="font-serif text-3xl text-foreground text-center mb-8">Membership Tiers</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {tiers.map((t, i) => (
                <div key={t.name} className={`bg-gradient-to-br ${t.color} rounded-3xl p-8 boty-shadow text-ivory relative overflow-hidden`}>
                  <div className="relative z-10">
                    <Award className="w-8 h-8 mb-3 opacity-80" />
                    <h3 className="font-serif text-3xl mb-1">{t.name}</h3>
                    <p className="text-sm opacity-80 mb-6">{t.points} points</p>
                    <ul className="space-y-2">
                      {t.perks.map((perk) => (
                        <li key={perk} className="text-sm flex items-start gap-2"><Star className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" /> {perk}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>

          {/* Ways to earn */}
          <Reveal className="mb-16">
            <h2 className="font-serif text-3xl text-foreground text-center mb-8">Ways to Earn</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {waysToEarn.map((w) => (
                <div key={w.title} className="bg-card rounded-2xl p-5 text-center boty-shadow">
                  <w.icon className="w-7 h-7 text-primary mx-auto mb-2" />
                  <p className="font-medium text-foreground text-sm mb-1">{w.title}</p>
                  <p className="text-xs text-primary font-medium">{w.points}</p>
                </div>
              ))}
            </div>
          </Reveal>

          {/* Redeem */}
          <Reveal>
            <h2 className="font-serif text-3xl text-foreground text-center mb-8">Redeem Your Points</h2>
            <div className="bg-card rounded-3xl p-6 boty-shadow space-y-3">
              {rewards.map((r) => (
                <div key={r.points} className="flex items-center justify-between p-4 bg-background rounded-2xl">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Gift className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{r.reward}</p>
                      <p className="text-xs text-muted-foreground">{r.points} points</p>
                    </div>
                  </div>
                  <Link href="/sign-up" className="px-4 py-2 rounded-full bg-foreground text-background text-sm boty-transition hover:bg-foreground/90">Redeem</Link>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
