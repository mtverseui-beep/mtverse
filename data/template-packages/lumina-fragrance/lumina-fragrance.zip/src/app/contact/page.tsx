"use client"

import { useState } from "react"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Mail, Phone, MapPin, MessageSquare, Check } from "lucide-react"
import { toast } from "sonner"

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", subject: "General", message: "" })
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.email || !form.message) { toast.error("Please fill in all fields"); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); setSent(true); toast.success("Message sent") }, 800)
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">We're Here To Help</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Contact Us</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Questions about an order, a product, or just want to say hello? We'd love to hear from you.</p>
          </Reveal>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Contact info */}
            <Reveal className="space-y-4">
              {[
                { icon: Mail, label: "Email", value: "hello@luminamist.co", href: "mailto:hello@luminamist.co" },
                { icon: Phone, label: "Phone", value: "+1 (415) 555-0100", href: "tel:+14155550100" },
                { icon: MapPin, label: "Studio", value: "1100 Mission Street, San Francisco, CA 94103" },
                { icon: MessageSquare, label: "Live Chat", value: "Mon–Fri, 9am–6pm PT" },
              ].map((c, i) => (
                <div key={i} className="bg-card rounded-3xl p-5 boty-shadow">
                  <c.icon className="w-5 h-5 text-primary mb-2" />
                  <p className="text-xs text-muted-foreground mb-1">{c.label}</p>
                  {c.href ? <a href={c.href} className="text-sm text-foreground hover:text-primary boty-transition">{c.value}</a> : <p className="text-sm text-foreground">{c.value}</p>}
                </div>
              ))}
            </Reveal>

            {/* Form */}
            <Reveal delay={80} className="lg:col-span-2 bg-card rounded-3xl p-6 boty-shadow">
              {sent ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4"><Check className="w-8 h-8 text-primary" /></div>
                  <p className="font-serif text-2xl text-foreground mb-2">Message Sent</p>
                  <p className="text-sm text-muted-foreground mb-6">Thank you for reaching out. We'll get back to you within 1 business day.</p>
                  <button onClick={() => { setSent(false); setForm({ name: "", email: "", subject: "General", message: "" }) }} className="text-sm text-primary hover:underline">Send another message</button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div><label className="text-sm font-medium text-foreground mb-2 block">Name</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /></div>
                    <div><label className="text-sm font-medium text-foreground mb-2 block">Email</label><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" /></div>
                  </div>
                  <div><label className="text-sm font-medium text-foreground mb-2 block">Subject</label><select value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary"><option>General</option><option>Order Support</option><option>Product Question</option><option>Wholesale</option><option>Press</option></select></div>
                  <div><label className="text-sm font-medium text-foreground mb-2 block">Message</label><textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={5} className="w-full bg-background border border-border rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-primary resize-none" /></div>
                  <button type="submit" disabled={loading} className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-8 py-3 rounded-full text-sm font-medium boty-transition hover:bg-primary/90 disabled:opacity-60 boty-shadow">{loading ? <><span className="lumina-spinner" /> Sending...</> : "Send Message"}</button>
                </form>
              )}
            </Reveal>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
