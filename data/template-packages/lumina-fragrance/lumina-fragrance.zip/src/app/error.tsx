"use client"

import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { RefreshCw, Home } from "lucide-react"

export default function Error() {
  return (
    <main className="min-h-screen lumina-page flex flex-col">
      <Header />
      <div className="flex-1 flex items-center pt-28 pb-20">
        <div className="max-w-2xl mx-auto px-6 text-center">
          <Reveal>
            <p className="font-serif text-[120px] md:text-[180px] leading-none text-destructive/20 mb-4">500</p>
            <span className="text-sm tracking-[0.3em] uppercase text-destructive mb-4 block">Server Error</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4 text-balance">Something went wrong</h1>
            <p className="text-lg text-muted-foreground mb-8">An unexpected error occurred. Our team has been notified. Please try again in a moment.</p>
          </Reveal>
          <Reveal delay={80} className="flex flex-col sm:flex-row gap-3 justify-center">
            <button onClick={() => window.location.reload()} className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow"><RefreshCw className="w-4 h-4" /> Try Again</button>
            <Link href="/" className="inline-flex items-center justify-center gap-2 border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted"><Home className="w-4 h-4" /> Back Home</Link>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
