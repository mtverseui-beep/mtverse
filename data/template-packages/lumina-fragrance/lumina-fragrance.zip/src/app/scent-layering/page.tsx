"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { products } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { Layers, ArrowRight, ShoppingBag } from "lucide-react"
import { toast } from "sonner"

const moods = ["Fresh", "Floral", "Warm", "Clean", "Evening"] as const
type Mood = typeof moods[number]

const pairings: Record<Mood, { title: string; description: string; productIds: string[]; tip: string }> = {
  Fresh: { title: "Fresh Morning", description: "Clean musk on skin + citrus in the air for a bright, lifting start.", productIds: ["cloud-veil-body-mist", "citrus-linen-room-spray"], tip: "Mist the room first, then apply the body mist. The citrus lifts while the musk grounds." },
  Floral: { title: "Bloom Layering", description: "A dewy floral body mist + amber hair perfume for dimensional depth.", productIds: ["rose-milk-body-mist", "amber-bloom-hair-perfume"], tip: "Body mist first, hair perfume through lengths. The floral sits close, the amber lifts." },
  Warm: { title: "Vanilla Hour", description: "Bourbon vanilla mist + warm amber hair perfume for the golden hour.", productIds: ["vanilla-hour-fragrance-mist", "warm-skin-hair-perfume"], tip: "Layer the mist over pulse points, then mist the hair perfume. The warmth deepens over hours." },
  Clean: { title: "Clean Cotton", description: "Soft musk body mist + clean cotton room spray for a fresh-laundry feel.", productIds: ["cloud-veil-body-mist", "clean-cotton-room-spray"], tip: "Spritz the room spray on linens and the body mist on skin. Both share a white musk base." },
  Evening: { title: "Evening Velvet", description: "Deep amber mist + warm hair perfume for the long evening.", productIds: ["evening-velvet-body-mist", "warm-skin-hair-perfume"], tip: "Apply the body mist generously, then the hair perfume. The amber deepens through the night." },
}

export default function ScentLayeringPage() {
  const [mood, setMood] = useState<Mood>("Floral")
  const { addItem } = useCart()
  const current = pairings[mood]
  const items = current.productIds.map((id) => products.find((p) => p.id === id)!).filter(Boolean)

  const handleAddBundle = () => {
    items.forEach((p) => addItem({ id: p.id, name: p.name, description: p.description, price: p.price, image: p.image }))
    toast.success(`${current.title} bundle added to cart`)
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">The Art of Layering</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Scent Layering</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Scent is built, not worn. Pair body mists, hair perfumes, and room sprays to create a fragrance wardrobe that is unmistakably yours.</p>
          </div>

          {/* What is layering */}
          <Reveal className="bg-card rounded-3xl p-8 lg:p-12 boty-shadow mb-12">
            <div className="grid md:grid-cols-3 gap-8">
              <div>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4"><Layers className="w-6 h-6 text-primary" /></div>
                <h3 className="font-serif text-xl text-foreground mb-2">Harmony</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Begin with a single note you love and build around it. Avoid scents that compete.</p>
              </div>
              <div>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4"><Layers className="w-6 h-6 text-primary" /></div>
                <h3 className="font-serif text-xl text-foreground mb-2">Format</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Body mists sit close, hair perfumes lift, room sprays create atmosphere. Distribute across formats.</p>
              </div>
              <div>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4"><Layers className="w-6 h-6 text-primary" /></div>
                <h3 className="font-serif text-xl text-foreground mb-2">Restraint</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Two or three complementary formats are enough. More than that, and layers compete.</p>
              </div>
            </div>
          </Reveal>

          {/* Mood tabs */}
          <div className="flex justify-center mb-8">
            <div className="inline-flex bg-card rounded-full p-1 gap-1 boty-shadow overflow-x-auto hide-scrollbar max-w-full">
              {moods.map((m) => (
                <button key={m} onClick={() => setMood(m)} className={`px-6 py-3 rounded-full text-sm font-medium boty-transition whitespace-nowrap ${mood === m ? "bg-foreground text-background" : "text-muted-foreground hover:text-foreground"}`}>{m}</button>
              ))}
            </div>
          </div>

          {/* Current pairing */}
          <Reveal className="bg-card rounded-3xl p-8 lg:p-12 boty-shadow mb-12">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <p className="text-xs tracking-[0.24em] uppercase text-primary mb-2">{mood} Pairing</p>
                <h2 className="font-serif text-3xl text-foreground mb-4">{current.title}</h2>
                <p className="text-muted-foreground mb-6 leading-relaxed">{current.description}</p>
                <div className="bg-background rounded-2xl p-4 mb-6">
                  <p className="text-xs uppercase tracking-[0.18em] text-primary mb-1">Pro Tip</p>
                  <p className="text-sm text-foreground">{current.tip}</p>
                </div>
                <button onClick={handleAddBundle} className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm font-medium boty-transition hover:bg-primary/90 boty-shadow">
                  <ShoppingBag className="w-4 h-4" /> Add Bundle to Cart
                </button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {items.map((p) => (
                  <div key={p.id} className="bg-background rounded-2xl overflow-hidden boty-shadow">
                    <Link href={`/product/${p.id}`} className="relative aspect-square block bg-muted">
                      <Image src={p.image} alt={p.name} fill className="object-cover" />
                    </Link>
                    <div className="p-3">
                      <p className="font-serif text-sm text-foreground line-clamp-1">{p.name}</p>
                      <p className="text-xs text-muted-foreground">${p.price}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          {/* FAQ */}
          <Reveal className="max-w-3xl mx-auto">
            <h2 className="font-serif text-3xl text-foreground text-center mb-8">Layering FAQ</h2>
            <div className="space-y-4">
              {[
                { q: "Can I layer different fragrance families?", a: "Yes, but with care. The most reliable combinations share a base note like musk, amber, or vanilla. Avoid combining two loud florals or two deep orientals." },
                { q: "How many products should I layer?", a: "Two or three is ideal. A body mist, a hair perfume, and optionally a room spray. More than that and the layers begin to compete." },
                { q: "What order should I apply them?", a: "Room spray first to set the atmosphere, then body mist on pulse points, then hair perfume through the lengths. Allow each to settle for 30 seconds." },
                { q: "Will layering make the scent too strong?", a: "No. Our formulas are designed to be layered. Each sits close to its format, so the combined effect is dimensional rather than loud." },
              ].map((item, i) => (
                <details key={i} className="bg-card rounded-2xl p-5 boty-shadow group">
                  <summary className="font-medium text-foreground cursor-pointer flex items-center justify-between">
                    {item.q}
                    <ArrowRight className="w-4 h-4 text-muted-foreground group-open:rotate-90 transition-transform" />
                  </summary>
                  <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{item.a}</p>
                </details>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
