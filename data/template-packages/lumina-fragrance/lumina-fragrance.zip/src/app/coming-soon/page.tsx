"use client"

import Link from "next/link"
import { Sparkles, ArrowRight, Bell } from "lucide-react"
import { toast } from "sonner"

export default function ComingSoonPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast.success("You're on the list!")
  }
  return (
    <main className="min-h-screen lumina-page flex items-center justify-center px-6">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
          <Sparkles className="w-10 h-10 text-primary" />
        </div>
        <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Coming Soon</span>
        <h1 className="font-serif text-4xl text-foreground mb-4">Something beautiful is brewing</h1>
        <p className="text-lg text-muted-foreground mb-8">We're working on something new. Be the first to know when it launches.</p>
        <form className="flex gap-2 max-w-sm mx-auto mb-6" onSubmit={handleSubmit}>
          <input type="email" placeholder="your@email.com" className="flex-1 bg-card border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary boty-shadow" />
          <button type="submit" className="inline-flex items-center gap-1 bg-primary text-primary-foreground px-5 py-3 rounded-full text-sm boty-transition hover:bg-primary/90"><Bell className="w-4 h-4" /> Notify</button>
        </form>
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-primary hover:underline">Back to Home <ArrowRight className="w-3.5 h-3.5" /></Link>
      </div>
    </main>
  )
}
