export default function Loading() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="text-center">
        <div className="lumina-spinner mx-auto mb-4 text-primary" style={{ width: "2rem", height: "2rem" }} />
        <p className="text-sm text-muted-foreground">Loading...</p>
      </div>
    </main>
  )
}
