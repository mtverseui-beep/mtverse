"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { products } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { Check, ArrowRight, Sparkles, Gift } from "lucide-react"
import { toast } from "sonner"

const tiers = [
  { id: "3", count: 3, name: "Trio", price: 36, description: "Choose 3 minis" },
  { id: "5", count: 5, name: "Discovery", price: 48, description: "Choose 5 minis" },
  { id: "8", count: 8, name: "Wardrobe", price: 72, description: "Choose 8 minis" },
]

export default function DiscoverySetsPage() {
  const [tier, setTier] = useState(tiers[1])
  const [selected, setSelected] = useState<string[]>([])
  const { addItem } = useCart()
  const available = products.slice(0, 8)

  const toggle = (id: string) => {
    setSelected((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id)
      if (prev.length >= tier.count) { toast.error(`You can select up to ${tier.count} scents`); return prev }
      return [...prev, id]
    })
  }

  const handleAdd = () => {
    if (selected.length !== tier.count) { toast.error(`Please select ${tier.count} scents`); return }
    addItem({
      id: `discovery-${tier.id}-${selected.join("-")}`,
      name: `Lumina ${tier.name} Discovery Set`,
      description: `${tier.count} x 5ml minis • Custom selected`,
      price: tier.price,
      image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
    })
    toast.success(`${tier.name} Discovery Set added to cart`)
    setSelected([])
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Build Your Own</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Discovery Set Builder</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Choose your minis and build a personalized discovery set. The gentlest way to meet Lumina.</p>
          </div>

          {/* Tier selector */}
          <Reveal className="flex justify-center mb-10">
            <div className="inline-flex bg-card rounded-full p-1 gap-1 boty-shadow">
              {tiers.map((t) => (
                <button key={t.id} onClick={() => { setTier(t); setSelected([]) }} className={`px-6 py-3 rounded-full text-sm font-medium boty-transition ${tier.id === t.id ? "bg-foreground text-background" : "text-muted-foreground hover:text-foreground"}`}>
                  {t.name} (${t.price})
                </button>
              ))}
            </div>
          </Reveal>

          {/* Progress */}
          <div className="max-w-md mx-auto mb-8 text-center">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-muted-foreground">Selected</span>
              <span className="font-medium text-foreground">{selected.length} / {tier.count}</span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-primary transition-all duration-500" style={{ width: `${(selected.length / tier.count) * 100}%` }} />
            </div>
          </div>

          {/* Products */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
            {available.map((p, i) => {
              const isSelected = selected.includes(p.id)
              return (
                <Reveal key={p.id} delay={i * 50}>
                  <button onClick={() => toggle(p.id)} className={`relative w-full text-left bg-card rounded-2xl overflow-hidden boty-shadow boty-transition ${isSelected ? "ring-2 ring-primary" : "hover:scale-[1.02]"}`}>
                    <div className="relative aspect-square bg-muted">
                      <Image src={p.image} alt={p.name} fill className="object-cover" />
                      <div className={`absolute inset-0 bg-primary/20 transition-opacity ${isSelected ? "opacity-100" : "opacity-0"}`} />
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                          <Check className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                    <div className="p-3">
                      <p className="font-serif text-sm text-foreground line-clamp-1">{p.name}</p>
                      <p className="text-xs text-muted-foreground line-clamp-1">{p.description}</p>
                    </div>
                  </button>
                </Reveal>
              )
            })}
          </div>

          {/* Summary bar */}
          <div className="sticky bottom-4 bg-card rounded-3xl p-5 boty-shadow flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-serif text-lg text-foreground">{tier.name} Discovery Set</p>
                <p className="text-xs text-muted-foreground">{selected.length} of {tier.count} scents selected • ${tier.price}</p>
              </div>
            </div>
            <button onClick={handleAdd} disabled={selected.length !== tier.count} className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm font-medium boty-transition hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed">
              <Gift className="w-4 h-4" /> Add to Cart <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Pre-built sets */}
          <div className="mt-20">
            <div className="text-center mb-8">
              <h2 className="font-serif text-3xl text-foreground mb-2">Or Try a Pre-Built Set</h2>
              <p className="text-muted-foreground">Curated by our team for specific moods</p>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {products.filter((p) => p.category === "sets").slice(0, 3).map((p, i) => (
                <Reveal key={p.id} delay={i * 80}>
                  <div className="bg-card rounded-3xl overflow-hidden boty-shadow group">
                    <Link href={`/product/${p.id}`} className="relative aspect-square block bg-muted overflow-hidden">
                      <Image src={p.image} alt={p.name} fill className="object-cover boty-transition group-hover:scale-105" />
                      {p.badge && <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs bg-white text-black">{p.badge}</span>}
                    </Link>
                    <div className="p-5">
                      <h3 className="font-serif text-lg text-foreground mb-1">{p.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{p.description}</p>
                      <Link href={`/product/${p.id}`} className="inline-flex items-center gap-1 text-sm text-primary hover:gap-2 transition-all">View details <ArrowRight className="w-3.5 h-3.5" /></Link>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
