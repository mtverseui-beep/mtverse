import Image from "next/image"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Recycle, Leaf, Droplets, Package } from "lucide-react"

export default function SustainabilityPage() {
  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Our Commitment</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Sustainability</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">How we approach packaging, sourcing, and formulation with intention rather than marketing.</p>
          </Reveal>

          <Reveal delay={80} className="relative aspect-[16/9] rounded-3xl overflow-hidden boty-shadow mb-16">
            <Image src="https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1600&q=80" alt="Sustainable packaging" fill className="object-cover" />
          </Reveal>

          <div className="grid sm:grid-cols-2 gap-6 mb-16">
            {[
              { icon: Recycle, title: "Refillable Bottles", desc: "Our 100ml bottles are refillable. Each can be refilled from a 1L pouch or repurposed once empty." },
              { icon: Leaf, title: "Vegan & Cruelty-Free", desc: "Never tested on animals, never made from them. No parabens, phthalates, or synthetic colorants." },
              { icon: Package, title: "Recyclable Packaging", desc: "Glass bottles, aluminum caps, paper boxes printed with soy inks. Minimal plastic, all post-consumer recycled." },
              { icon: Droplets, title: "Clean Formulas", desc: "Full ingredient lists printed on every box. Moderated alcohol bases with skin-conditioning vitamin E." },
            ].map((item, i) => (
              <Reveal key={item.title} delay={i * 80}>
                <div className="bg-card rounded-3xl p-6 boty-shadow">
                  <item.icon className="w-8 h-8 text-primary mb-3" />
                  <h3 className="font-serif text-xl text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="lumina-prose max-w-3xl mx-auto mb-16">
            <p>Sustainability in fragrance is often reduced to a sticker on a box. We are trying to do better than that, by making specific commitments and reporting on them honestly.</p>
            <p>Our packaging is recyclable and minimal. We use glass bottles, aluminum caps, and paper boxes printed with soy inks. We avoid plastic where possible and use only post-consumer recycled plastic where it is unavoidable. Our gift sets are presented in keepsake boxes designed to be reused rather than discarded.</p>
            <h2>Our Goals for 2026</h2>
            <ul>
              <li>Launch 1L refill pouches for all 100ml bottles</li>
              <li>Achieve 100% recyclable or compostable packaging across the range</li>
              <li>Source 80% of fragrance oils from certified sustainable suppliers</li>
              <li>Publish our first annual sustainability report with full transparency</li>
            </ul>
            <p>We are not perfect. There is more to do, particularly in our supply chain and our international shipping footprint. We publish an annual sustainability report that lists our progress and our gaps, and we welcome questions at hello@luminamist.co.</p>
          </Reveal>

          <Reveal className="bg-card rounded-3xl p-8 boty-shadow text-center">
            <p className="font-serif text-2xl text-foreground mb-2">Questions about our practices?</p>
            <p className="text-sm text-muted-foreground mb-4">We're happy to share our full sustainability report.</p>
            <a href="mailto:hello@luminamist.co" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Email Us</a>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
