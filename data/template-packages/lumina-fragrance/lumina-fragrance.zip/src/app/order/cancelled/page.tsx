import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Ban, ArrowRight, ShoppingBag } from "lucide-react"

export default function OrderCancelledPage() {
  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-2xl mx-auto px-6 lg:px-8 text-center">
          <Reveal>
            <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
              <Ban className="w-12 h-12 text-muted-foreground" />
            </div>
            <span className="text-sm tracking-[0.3em] uppercase text-muted-foreground mb-4 block">Order Cancelled</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4 text-balance">Your order has been cancelled</h1>
            <p className="text-lg text-muted-foreground mb-8">No charges were made. Your cart has been saved if you'd like to try again later.</p>
          </Reveal>
          <Reveal delay={100} className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/shop" className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow"><ShoppingBag className="w-4 h-4" /> Continue Shopping</Link>
            <Link href="/help" className="inline-flex items-center justify-center gap-2 border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted">Help Center <ArrowRight className="w-4 h-4" /></Link>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
