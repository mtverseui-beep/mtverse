import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { XCircle, ArrowRight, RefreshCw } from "lucide-react"

export default function OrderFailedPage() {
  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-2xl mx-auto px-6 lg:px-8 text-center">
          <Reveal>
            <div className="w-24 h-24 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-6">
              <XCircle className="w-12 h-12 text-destructive" />
            </div>
            <span className="text-sm tracking-[0.3em] uppercase text-destructive mb-4 block">Payment Failed</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4 text-balance">Your payment could not be processed</h1>
            <p className="text-lg text-muted-foreground mb-8">No charges were made. Please try again with a different payment method, or contact your bank for more information.</p>
          </Reveal>
          <Reveal delay={100} className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/checkout/payment" className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow"><RefreshCw className="w-4 h-4" /> Try Again</Link>
            <Link href="/help/payments" className="inline-flex items-center justify-center gap-2 border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted">Contact Support <ArrowRight className="w-4 h-4" /></Link>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
