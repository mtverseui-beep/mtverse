import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Check, Package, Mail, ArrowRight, Truck } from "lucide-react"

export default function OrderSuccessPage() {
  const orderNumber = `LUM-${Math.floor(100000 + Math.random() * 900000)}`
  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-2xl mx-auto px-6 lg:px-8 text-center">
          <Reveal>
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
              <Check className="w-12 h-12 text-primary" />
            </div>
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Order Confirmed</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4 text-balance">Thank you for your order</h1>
            <p className="text-lg text-muted-foreground mb-2">Your order number is</p>
            <p className="font-serif text-3xl text-foreground mb-8">{orderNumber}</p>
          </Reveal>

          <Reveal delay={100} className="bg-card rounded-3xl p-6 boty-shadow mb-6 text-left">
            <div className="flex items-center gap-3 mb-4">
              <Mail className="w-5 h-5 text-primary" />
              <p className="text-sm text-foreground">A confirmation email has been sent to your inbox.</p>
            </div>
            <div className="flex items-center gap-3 mb-4">
              <Truck className="w-5 h-5 text-primary" />
              <p className="text-sm text-foreground">Estimated delivery: 3–5 business days</p>
            </div>
            <div className="flex items-center gap-3">
              <Package className="w-5 h-5 text-primary" />
              <p className="text-sm text-foreground">Ships from our Los Angeles studio within 1 business day</p>
            </div>
          </Reveal>

          {/* Timeline */}
          <Reveal delay={150} className="bg-card rounded-3xl p-6 boty-shadow mb-6">
            <div className="flex items-center justify-between relative">
              <div className="absolute top-5 left-5 right-5 h-0.5 bg-muted" />
              <div className="absolute top-5 left-5 h-0.5 bg-primary" style={{ width: "10%" }} />
              {[
                { label: "Confirmed", done: true },
                { label: "Processing", done: false },
                { label: "Shipped", done: false },
                { label: "Delivered", done: false },
              ].map((s, i) => (
                <div key={i} className="relative z-10 flex flex-col items-center" style={{ width: "25%" }}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${s.done ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                    {s.done ? <Check className="w-4 h-4" /> : <span className="text-xs">{i + 1}</span>}
                  </div>
                  <p className="text-xs mt-2 text-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal delay={200} className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href={`/track-order`} className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow">Track Order <ArrowRight className="w-4 h-4" /></Link>
            <Link href="/shop" className="inline-flex items-center justify-center gap-2 border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted">Continue Shopping</Link>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
