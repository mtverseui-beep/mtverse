import { use } from "react"
import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Check, Truck, Package, Clock, ArrowRight } from "lucide-react"

const mockOrders: Record<string, { number: string; date: string; status: string; estimatedDelivery: string; trackingNumber: string; total: number; items: { name: string; qty: number; price: number; image: string }[]; timeline: { label: string; date: string; done: boolean }[] }> = {
  "LUM-100589": {
    number: "LUM-100589", date: "June 30, 2026", status: "Shipped", estimatedDelivery: "July 5, 2026", trackingNumber: "1Z999AA10198765432", total: 103.68,
    items: [{ name: "Moonlit Amber Gift Set", qty: 1, price: 96, image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=400&q=80" }],
    timeline: [{ label: "Order placed", date: "Jun 30", done: true }, { label: "Processing", date: "Jun 30", done: true }, { label: "Shipped", date: "Jul 1", done: true }, { label: "In transit", date: "Jul 2", done: true }, { label: "Delivered", date: "Jul 5", done: false }],
  },
  "LUM-100482": {
    number: "LUM-100482", date: "June 22, 2026", status: "Delivered", estimatedDelivery: "Delivered Jun 26", trackingNumber: "1Z999AA10123456784", total: 86.40,
    items: [{ name: "Cloud Veil Body Mist", qty: 1, price: 38, image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=400&q=80" }, { name: "Amber Bloom Hair Perfume", qty: 1, price: 42, image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=400&q=80" }],
    timeline: [{ label: "Order placed", date: "Jun 22", done: true }, { label: "Processing", date: "Jun 22", done: true }, { label: "Shipped", date: "Jun 23", done: true }, { label: "In transit", date: "Jun 24", done: true }, { label: "Delivered", date: "Jun 26", done: true }],
  },
}

export default function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const order = mockOrders[id.toUpperCase()] || mockOrders["LUM-100589"]
  if (!order) notFound()

  const progress = (order.timeline.filter((t) => t.done).length - 1) / (order.timeline.length - 1) * 100

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <Link href="/account/orders" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8">← All Orders</Link>

          <Reveal className="mb-8">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <span className="text-sm tracking-[0.3em] uppercase text-primary block mb-1">Order Details</span>
                <h1 className="font-serif text-3xl md:text-4xl text-foreground">{order.number}</h1>
                <p className="text-sm text-muted-foreground">Placed on {order.date}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Status</p>
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium ${order.status === "Delivered" ? "bg-primary/10 text-primary" : "bg-gold/10 text-gold"}`}>
                  {order.status === "Delivered" ? <Check className="w-3.5 h-3.5" /> : <Truck className="w-3.5 h-3.5" />} {order.status}
                </span>
              </div>
            </div>
          </Reveal>

          {/* Timeline */}
          <Reveal delay={80} className="bg-card rounded-3xl p-6 boty-shadow mb-6">
            <div className="flex items-center justify-between relative mb-2">
              <div className="absolute top-5 left-5 right-5 h-0.5 bg-muted" />
              <div className="absolute top-5 left-5 h-0.5 bg-primary transition-all duration-700" style={{ width: `${progress}%` }} />
              {order.timeline.map((step, i) => (
                <div key={i} className="relative z-10 flex flex-col items-center text-center" style={{ width: `${100 / order.timeline.length}%` }}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step.done ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                    {step.done ? <Check className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                  </div>
                  <p className={`text-[10px] mt-2 ${step.done ? "text-foreground font-medium" : "text-muted-foreground"}`}>{step.label}</p>
                  <p className="text-[10px] text-muted-foreground">{step.date}</p>
                </div>
              ))}
            </div>
          </Reveal>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Items */}
            <Reveal delay={120} className="md:col-span-2 bg-card rounded-3xl p-6 boty-shadow">
              <h2 className="font-serif text-xl text-foreground mb-4">Items</h2>
              <div className="space-y-3">
                {order.items.map((item, i) => (
                  <div key={i} className="flex gap-4 p-3 bg-background rounded-2xl">
                    <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                      <Image src={item.image} alt={item.name} fill className="object-cover" />
                    </div>
                    <div className="flex-1">
                      <p className="font-serif text-sm text-foreground">{item.name}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.qty}</p>
                    </div>
                    <p className="font-medium text-foreground">${item.price * item.qty}</p>
                  </div>
                ))}
              </div>
            </Reveal>

            {/* Summary */}
            <Reveal delay={160} className="bg-card rounded-3xl p-6 boty-shadow space-y-3">
              <h2 className="font-serif text-xl text-foreground">Summary</h2>
              <div className="text-sm space-y-2">
                <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>${order.total - Math.round(order.total * 0.08 * 100) / 100}</span></div>
                <div className="flex justify-between text-muted-foreground"><span>Shipping</span><span>Free</span></div>
                <div className="flex justify-between text-muted-foreground"><span>Tax</span><span>${Math.round(order.total * 0.08 * 100) / 100}</span></div>
                <div className="flex justify-between font-medium text-foreground pt-2 border-t border-border/50"><span>Total</span><span>${order.total}</span></div>
              </div>
              <div className="pt-3 border-t border-border/50">
                <p className="text-xs text-muted-foreground mb-1">Tracking</p>
                <p className="font-mono text-xs text-foreground">{order.trackingNumber}</p>
              </div>
              <Link href="/track-order" className="block text-center bg-foreground text-background py-2.5 rounded-full text-sm boty-transition hover:bg-foreground/90">Track Shipment</Link>
            </Reveal>
          </div>

          <div className="flex gap-3 mt-6 justify-center">
            <Link href="/shop" className="inline-flex items-center gap-2 border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted">Continue Shopping <ArrowRight className="w-4 h-4" /></Link>
            {order.status !== "Delivered" && <Link href="/help/orders" className="inline-flex items-center gap-2 border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted"><Package className="w-4 h-4" /> Need Help?</Link>}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
