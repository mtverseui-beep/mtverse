"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"
import { ChevronLeft, Minus, Plus, ChevronDown, Leaf, Heart, Award, Recycle, Star, Check } from "lucide-react"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useCart } from "@/components/boty/cart-context"

const products: Record<string, {
  id: string
  name: string
  tagline: string
  description: string
  price: number
  originalPrice: number | null
  image: string
  sizes: string[]
  details: string
  howToUse: string
  ingredients: string
  delivery: string
}> = {
  "cloud-veil-body-mist": {
    id: "cloud-veil-body-mist",
    name: "Cloud Veil Body Mist",
    tagline: "Soft musk, white petals, and clean air",
    description: "A sheer veil of white petals and clean musk that never raises its voice. Cloud Veil sits close to the skin and reads as the gentlest version of you. Wear it on bare skin after a shower, layer it under a richer scent in the evening, or keep it at your desk for a quiet reset.",
    price: 38,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1200&q=80",
    sizes: ["50ml", "100ml", "15ml Travel"],
    details: "Cloud Veil opens with bergamot, white tea, and petitgrain before revealing a heart of jasmine petals, peony, and iris. The drydown settles into white musk, cashmeran, and soft cedar for a clean, intimate presence that lingers for hours. Formulated with a moderated alcohol base and skin-conditioning vitamin E.",
    howToUse: "Hold 20cm from skin and mist over pulse points, behind the knees, and along the collarbone after a warm shower. Allow to air dry for 30 seconds before dressing. Layer with Cloud Veil Hair Perfume for added depth. Reapply every 4 hours for a refreshed trail.",
    ingredients: "Alcohol Denat., Aqua (Water), Parfum (Fragrance), Limonene, Linalool, Citronellol, Geraniol, Benzyl Alcohol, Tocopherol (Vitamin E).",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "amber-bloom-hair-perfume": {
    id: "amber-bloom-hair-perfume",
    name: "Amber Bloom Hair Perfume",
    tagline: "Warm amber and night-blooming jasmine",
    description: "A hair perfume designed to leave a warm, lingering trail of amber and night-blooming jasmine with every movement. The formula is alcohol-light and conditioning, so it never dries hair or leaves residue. The drydown deepens over hours into a soft amber glow.",
    price: 42,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1200&q=80",
    sizes: ["30ml", "15ml Travel"],
    details: "Amber Bloom opens with saffron, pink pepper, and bergamot before revealing a heart of night-blooming jasmine, rose absolute, and apricot. The base of amber, benzoin, and soft sandalwood deepens over hours. Enriched with pro-vitamin B5 and hydrolyzed silk to condition and soften hair.",
    howToUse: "Hold 20cm from dry hair and mist through mid-lengths and ends, avoiding roots. Comb through to distribute evenly. Layer with body mist for added depth. Reapply as desired throughout the day.",
    ingredients: "Aqua (Water), Cyclopentasiloxane, Parfum (Fragrance), Dimethiconol, Panthenol (Pro-Vitamin B5), Hydrolyzed Silk, Linalool, Limonene, Citronellol.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "vanilla-hour-fragrance-mist": {
    id: "vanilla-hour-fragrance-mist",
    name: "Vanilla Hour Fragrance Mist",
    tagline: "Bourbon vanilla, tonka, and golden amber",
    description: "The body mist equivalent of golden hour. A warm blend of bourbon vanilla, tonka, and amber that wears close to the skin like a softly worn sweater. The vanilla is grown-up, never cloying, and the drydown deepens into a soft amber glow.",
    price: 44,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1200&q=80",
    sizes: ["50ml", "100ml"],
    details: "Vanilla Hour opens with bergamot and pink pepper before revealing a heart of bourbon vanilla, tonka bean, and heliotrope. The base of amber, benzoin, and soft musk creates a warm, second-skin presence that lingers for 6 to 8 hours. Skin-conditioning vitamin E included.",
    howToUse: "Mist over pulse points: wrists, neck, behind ears. Allow 30 seconds to dry before dressing. Layer with Amber Bloom Hair Perfume for depth. Reapply every 6 hours for a refreshed trail.",
    ingredients: "Alcohol Denat., Aqua (Water), Parfum (Fragrance), Coumarin, Limonene, Linalool, Vanillin, Tocopherol (Vitamin E).",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "evening-velvet-body-mist": {
    id: "evening-velvet-body-mist",
    name: "Evening Velvet Body Mist",
    tagline: "Plum, black amber, and velvet rose",
    description: "The body mist for the long evenings. Deep plums, black amber, and a velvet rose heart that deepens over hours. The mist wears close to the skin but with a depth that reads clearly in a room. Layer it with Amber Bloom Hair Perfume for a fully enveloping warmth.",
    price: 46,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1200&q=80",
    sizes: ["50ml", "100ml"],
    details: "Evening Velvet opens with plum, bergamot, and pink pepper before revealing a heart of velvet rose, orris, and saffron. The base of black amber, benzoin, and sandalwood creates a deep, intense warmth that wears for 7 to 9 hours. Despite its intensity, the formula never feels heavy.",
    howToUse: "Mist over pulse points before an evening out. Allow 30 seconds to dry before dressing. Layer with Amber Bloom Hair Perfume for depth. Avoid rubbing wrists together after application.",
    ingredients: "Alcohol Denat., Aqua (Water), Parfum (Fragrance), Limonene, Linalool, Eugenol, Coumarin, Tocopherol (Vitamin E).",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "rose-milk-body-mist": {
    id: "rose-milk-body-mist",
    name: "Rose Milk Body Mist",
    tagline: "Fresh rose petals, almond milk, soft musk",
    description: "A soft floral body mist built around fresh rose petals and almond milk. Unlike traditional rose scents, it leans dewy and creamy rather than powdery or soapy, like a fresh petal crushed between fingers. The musk base softens the floral heart for an intimate presence.",
    price: 38,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80",
    sizes: ["50ml", "100ml"],
    details: "Rose Milk opens with green leaves and bergamot before revealing a heart of fresh rose petals, peony, and almond milk. The base of white musk, cashmeran, and soft cedar creates a dewy, creamy floral that wears for 5 to 7 hours.",
    howToUse: "Mist over pulse points after a shower. Layer with Cloud Veil for added depth. Allow to dry before dressing. Reapply midday as desired.",
    ingredients: "Alcohol Denat., Aqua (Water), Parfum (Fragrance), Linalool, Citronellol, Geraniol, Benzyl Alcohol, Tocopherol (Vitamin E).",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "citrus-linen-room-spray": {
    id: "citrus-linen-room-spray",
    name: "Citrus Linen Room Spray",
    tagline: "Cold-pressed citrus, white tea, fresh linen",
    description: "A home fragrance that recreates the moment a window is thrown open on a spring morning. Cold-pressed citrus and white tea lift the air, while a clean musk base keeps the scent from turning sharp. Use it on linens, curtains, or simply in the air to refresh a room.",
    price: 28,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1600573472556-e636c2acda88?auto=format&fit=crop&w=1200&q=80",
    sizes: ["100ml", "250ml"],
    details: "Citrus Linen opens with Sicilian lemon, bergamot, and grapefruit before revealing a heart of white tea, neroli, and spearmint. The base of white musk, cedar leaf, and soft vetiver keeps the scent clean and grounded. Phthalate-free and safe for linens and upholstery.",
    howToUse: "Spritz 2 to 3 pumps into the air or onto linens from 30cm. Hold 30cm from fabric surfaces. Avoid direct contact with delicate silks. Use within 12 months of opening.",
    ingredients: "Aqua (Water), Alcohol Denat., Parfum (Fragrance), Limonene, Linalool, Citral.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "calm-linen-pillow-mist": {
    id: "calm-linen-pillow-mist",
    name: "Calm Linen Pillow Mist",
    tagline: "Lavender, vanilla, and soft cedar for rest",
    description: "A pillow mist designed to settle the senses before rest. Lavender and chamomile open softly, with vanilla and cedar adding warmth without sweetness. The mist settles onto fabric rather than into the air, so the scent lingers close rather than filling the room.",
    price: 32,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=1200&q=80",
    sizes: ["100ml", "250ml"],
    details: "Calm Linen opens with lavender and bergamot before revealing a heart of vanilla, chamomile, and ylang. The base of cedar, soft musk, and amber creates a restful, warm presence. Phthalate-free and non-staining on pillows and sheets.",
    howToUse: "Spritz 2 to 3 times onto pillows and sheets. Hold 30cm from fabric. Allow 5 minutes to settle before bed.",
    ingredients: "Aqua (Water), Alcohol Denat., Parfum (Fragrance), Linalool, Coumarin, Limonene.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "moonlit-amber-gift-set": {
    id: "moonlit-amber-gift-set",
    name: "Moonlit Amber Gift Set",
    tagline: "Three amber rituals in a keepsake box",
    description: "The Moonlit Amber Gift Set collects three amber rituals in a single keepsake box: Evening Velvet Body Mist in 50ml, Warm Skin Hair Perfume in 30ml, and Clean Cotton Room Spray in 100ml. Together they create a full evening ritual, from skin to hair to room.",
    price: 96,
    originalPrice: 116,
    image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=1200&q=80",
    sizes: ["3-Piece Set"],
    details: "The Moonlit Amber Gift Set includes three complementary amber rituals: Evening Velvet Body Mist (50ml), Warm Skin Hair Perfume (30ml), and Clean Cotton Room Spray (100ml). Each scent is designed to layer with the others. The keepsake box is tied with a hand-tied ribbon and includes an optional gift note. Saves 20% versus buying separately.",
    howToUse: "Layer the body mist over pulse points. Mist the hair perfume through mid-lengths. Spritz the room spray into the air before guests arrive.",
    ingredients: "Full ingredient lists included with each product in the set.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "golden-fig-discovery-set": {
    id: "golden-fig-discovery-set",
    name: "Golden Fig Discovery Set",
    tagline: "Five minis to find your everyday signature",
    description: "The Golden Fig Discovery Set collects five 5ml minis from across the Lumina collection, each chosen to represent a different mood. From the citrus brightness of Citrus Linen to the warm amber of Evening Velvet, the set invites you to live with each scent before committing.",
    price: 48,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=1200&q=80",
    sizes: ["5 x 5ml"],
    details: "The Golden Fig Discovery Set includes Cloud Veil, Rose Milk, Citrus Linen, Vanilla Hour, and Soft Musk in 5ml refillable minis. The case is recyclable and the vials are refillable. Each set includes a $20 credit toward a full-size bottle.",
    howToUse: "Wear each mini for a day before deciding. Layer two or three together to find a signature combination. Use the included credit toward a full-size bottle.",
    ingredients: "Each vial: Alcohol Denat., Aqua (Water), Parfum (Fragrance). Full ingredient lists included in the box.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "soft-musk-travel-mini": {
    id: "soft-musk-travel-mini",
    name: "Soft Musk Travel Mini",
    tagline: "Clean musk in a 15ml travel companion",
    description: "Soft Musk in a 15ml travel format, designed to slip into a tote, a clutch, or a carry-on. The scent is the same grown-up, clean musk as the full size, with iris and white lily adding a quiet floral heart. The travel mini is refillable from the 100ml bottle.",
    price: 22,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1200&q=80",
    sizes: ["15ml Travel"],
    details: "Soft Musk opens with bergamot and aldehydes before revealing a heart of iris, white lily, and violet. The base of white musk, cashmeran, and soft amber creates a clean, second-skin presence. The 15ml mini is refillable from any 100ml Lumina bottle and is air-travel approved.",
    howToUse: "Mist over pulse points. Carry in tote or clutch for on-the-go refresh. Refill from the 100ml Soft Musk bottle.",
    ingredients: "Alcohol Denat., Aqua (Water), Parfum (Fragrance), Linalool, Citronellol, Hydroxycitronellal, Tocopherol (Vitamin E).",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "bloom-layering-duo": {
    id: "bloom-layering-duo",
    name: "Bloom Layering Duo",
    tagline: "Body mist and hair perfume in one set",
    description: "The Bloom Layering Duo pairs Rose Milk Body Mist with Amber Bloom Hair Perfume in a single set, designed to be worn together for a deeper, more dimensional floral. The body mist settles close to the skin while the hair perfume lifts with every movement.",
    price: 72,
    originalPrice: 80,
    image: "https://images.unsplash.com/photo-1587017539504-67cfbddac569?auto=format&fit=crop&w=1200&q=80",
    sizes: ["Duo Set"],
    details: "The Bloom Layering Duo includes Rose Milk Body Mist (50ml) and Amber Bloom Hair Perfume (30ml). Together they create a deeper, more dimensional floral scent. Saves 15% versus buying separately. Gift-ready packaging included.",
    howToUse: "Mist Rose Milk over pulse points. Allow 30 seconds to dry. Mist Amber Bloom through hair mid-lengths and ends. Reapply as desired throughout the day.",
    ingredients: "Full ingredient lists included with each product in the duo.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "warm-skin-hair-perfume": {
    id: "warm-skin-hair-perfume",
    name: "Warm Skin Hair Perfume",
    tagline: "Sun-warmed skin, amber, and soft sandalwood",
    description: "A hair perfume built around amber, sandalwood, and the soft heliotrope that gives the impression of sun-warmed skin. The formula is alcohol-light and conditioning, so it leaves hair soft and shiny with a scent that lingers for hours.",
    price: 42,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1200&q=80",
    sizes: ["30ml", "15ml Travel"],
    details: "Warm Skin opens with bergamot and cardamom before revealing a heart of amber, heliotrope, and davana. The base of sandalwood, benzoin, and soft musk creates a warm, intimate presence. Alcohol-light and conditioning with pro-vitamin B5 and hydrolyzed silk.",
    howToUse: "Mist through dry hair from 20cm. Focus on mid-lengths and ends, avoid roots. Layer with Evening Velvet Body Mist.",
    ingredients: "Aqua (Water), Cyclopentasiloxane, Parfum (Fragrance), Dimethiconol, Panthenol, Hydrolyzed Silk, Linalool, Limonene, Coumarin.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "clean-cotton-room-spray": {
    id: "clean-cotton-room-spray",
    name: "Clean Cotton Room Spray",
    tagline: "Fresh laundry, white musk, soft cedar",
    description: "Clean Cotton recreates the moment fresh laundry is pulled from the line, aldehydic, soft, and warm. The musk base keeps the scent from feeling soapy or sharp, while a touch of cedar adds depth. Use it on linens, towels, or in the air to refresh a room.",
    price: 28,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=1200&q=80",
    sizes: ["100ml", "250ml"],
    details: "Clean Cotton opens with aldehydes, bergamot, and green leaves before revealing a heart of cotton flower, iris, and lily of the valley. The base of white musk, cedar, and soft amber creates a clean, warm presence. Phthalate-free and non-staining.",
    howToUse: "Spritz 2 to 3 pumps into the air or onto linens. Hold 30cm from fabric surfaces. Use within 12 months of opening.",
    ingredients: "Aqua (Water), Alcohol Denat., Parfum (Fragrance), Limonene, Linalool, Hydroxycitronellal.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "everyday-scent-wardrobe": {
    id: "everyday-scent-wardrobe",
    name: "Everyday Scent Wardrobe",
    tagline: "Six minis for every day of the week",
    description: "The Everyday Scent Wardrobe collects six 8ml minis from across the Lumina collection, designed to cover the full week from fresh Monday mornings to slow Sunday afternoons. Each mini is refillable from a 100ml bottle. The wardrobe arrives in a soft-touch case.",
    price: 78,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=1200&q=80",
    sizes: ["6 x 8ml"],
    details: "The Everyday Scent Wardrobe includes Cloud Veil, Rose Milk, Citrus Linen, Vanilla Hour, Soft Musk, and Evening Velvet in 8ml refillable minis. The soft-touch case includes a printed scent guide. Each set includes a $30 credit toward full sizes.",
    howToUse: "Choose a mini based on mood each day. Layer two together for a personal combination. Refill from 100ml bottles as needed.",
    ingredients: "Full ingredient lists included with each product in the wardrobe.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
  "fresh-petal-travel-trio": {
    id: "fresh-petal-travel-trio",
    name: "Fresh Petal Travel Trio",
    tagline: "Three 15ml minis for soft mornings",
    description: "The Fresh Petal Travel Trio collects three 15ml minis from our fresh floral collection: Cloud Veil, Rose Milk, and Soft Musk. Each is sized for air travel and refillable from a 100ml bottle. The trio is presented in a small cotton pouch.",
    price: 54,
    originalPrice: 60,
    image: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1200&q=80",
    sizes: ["3 x 15ml"],
    details: "The Fresh Petal Travel Trio includes Cloud Veil, Rose Milk, and Soft Musk in 15ml refillable minis. Each mini is air-travel approved and refillable from any 100ml Lumina bottle. A cotton pouch is included. Saves 10% versus buying separately.",
    howToUse: "Mist over pulse points as desired. Refill from 100ml bottles using the included funnel. Carry in the included cotton pouch.",
    ingredients: "Full ingredient lists included with each product in the trio.",
    delivery: "Free standard shipping on orders over $50. Express shipping available at checkout. All orders ship within 1-2 business days. Returns accepted within 30 days of purchase if product is unused and sealed."
  },
}

const benefits = [
  { icon: Leaf, label: "100% Vegan" },
  { icon: Heart, label: "Cruelty-Free" },
  { icon: Recycle, label: "Refillable" },
  { icon: Award, label: "Clean Formula" }
]

type AccordionSection = "details" | "howToUse" | "ingredients" | "delivery"

export default function ProductPage() {
  const params = useParams()
  const productId = params.id as string
  const product = products[productId] || products["cloud-veil-body-mist"]
  const { addItem } = useCart()

  const [selectedSize, setSelectedSize] = useState(product.sizes[0])
  const [quantity, setQuantity] = useState(1)
  const [openAccordion, setOpenAccordion] = useState<AccordionSection | null>("details")
  const [isAdded, setIsAdded] = useState(false)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [productId])

  const toggleAccordion = (section: AccordionSection) => {
    setOpenAccordion(openAccordion === section ? null : section)
  }

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      description: product.tagline,
      price: product.price,
      image: product.image,
      size: selectedSize,
    })
    setIsAdded(true)
    setTimeout(() => setIsAdded(false), 2000)
  }

  const accordionItems: { key: AccordionSection; title: string; content: string }[] = [
    { key: "details", title: "Details", content: product.details },
    { key: "howToUse", title: "How to Use", content: product.howToUse },
    { key: "ingredients", title: "Ingredients", content: product.ingredients },
    { key: "delivery", title: "Delivery & Returns", content: product.delivery }
  ]

  return (
    <main className="min-h-screen">
      <Header />

      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {/* Back Link */}
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"
          >
            <ChevronLeft className="w-4 h-4" />
            Back to Shop
          </Link>

          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
            {/* Product Image */}
            <div className="relative aspect-square rounded-3xl overflow-hidden bg-card boty-shadow">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover"
                priority
              />
            </div>

            {/* Product Info */}
            <div className="flex flex-col">
              {/* Header */}
              <div className="mb-8">
                <span className="text-sm tracking-[0.3em] uppercase text-primary mb-2 block">
                  Lumina Essentials
                </span>
                <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-3">
                  {product.name}
                </h1>
                <p className="text-lg text-muted-foreground italic mb-4">
                  {product.tagline}
                </p>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground">(128 reviews)</span>
                </div>

                <p className="text-foreground/80 leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Price */}
              <div className="flex items-center gap-3 mb-8">
                <span className="text-3xl font-medium text-foreground">${product.price}</span>
                {product.originalPrice && (
                  <span className="text-xl text-muted-foreground line-through">
                    ${product.originalPrice}
                  </span>
                )}
              </div>

              {/* Size Selector */}
              <div className="mb-6">
                <label className="text-sm font-medium text-foreground mb-3 block">Size</label>
                <div className="flex flex-wrap gap-3">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setSelectedSize(size)}
                      className={`px-6 py-3 rounded-full text-sm boty-transition boty-shadow ${
                        selectedSize === size
                          ? "bg-primary text-primary-foreground"
                          : "bg-card text-foreground hover:bg-card/80"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity Selector */}
              <div className="mb-8">
                <label className="text-sm font-medium text-foreground mb-3 block">Quantity</label>
                <div className="inline-flex items-center gap-4 bg-card rounded-full px-2 py-2 boty-shadow">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 rounded-full bg-background flex items-center justify-center text-foreground/60 hover:text-foreground boty-transition"
                    aria-label="Decrease quantity"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center font-medium text-foreground">{quantity}</span>
                  <button
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 rounded-full bg-background flex items-center justify-center text-foreground/60 hover:text-foreground boty-transition"
                    aria-label="Increase quantity"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Add to Cart Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  className={`flex-1 inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full text-sm tracking-wide boty-transition boty-shadow ${
                    isAdded
                      ? "bg-primary/80 text-primary-foreground"
                      : "bg-primary text-primary-foreground hover:bg-primary/90"
                  }`}
                >
                  {isAdded ? (
                    <>
                      <Check className="w-4 h-4" />
                      Added to Cart
                    </>
                  ) : (
                    "Add to Cart"
                  )}
                </button>
                <Link
                  href="/checkout"
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-transparent border border-foreground/20 text-foreground px-8 py-4 rounded-full text-sm tracking-wide boty-transition hover:bg-foreground/5"
                >
                  Buy Now
                </Link>
              </div>

              {/* Benefits */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
                {benefits.map((benefit) => (
                  <div
                    key={benefit.label}
                    className="flex flex-col items-center gap-2 p-4 boty-shadow bg-transparent shadow-none rounded-md"
                  >
                    <benefit.icon className="w-5 h-5 text-primary" />
                    <span className="text-xs text-muted-foreground text-center">{benefit.label}</span>
                  </div>
                ))}
              </div>

              {/* Accordion */}
              <div className="border-t border-border/50">
                {accordionItems.map((item) => (
                  <div key={item.key} className="border-b border-border/50">
                    <button
                      type="button"
                      onClick={() => toggleAccordion(item.key)}
                      className="w-full flex items-center justify-between py-5 text-left"
                    >
                      <span className="font-medium text-foreground">{item.title}</span>
                      <ChevronDown
                        className={`w-5 h-5 text-muted-foreground boty-transition ${
                          openAccordion === item.key ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    <div
                      className={`overflow-hidden boty-transition ${
                        openAccordion === item.key ? "max-h-96 pb-5" : "max-h-0"
                      }`}
                    >
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {item.content}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
