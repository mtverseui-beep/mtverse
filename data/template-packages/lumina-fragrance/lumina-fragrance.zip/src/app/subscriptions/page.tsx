"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { products } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { RefreshCw, Check, ArrowRight, Sparkles } from "lucide-react"
import { toast } from "sonner"

const subscriptionProducts = products.filter((p) => ["cloud-veil-body-mist", "amber-bloom-hair-perfume", "vanilla-hour-fragrance-mist", "calm-linen-pillow-mist"].includes(p.id))

export default function SubscriptionsPage() {
  const [frequency, setFrequency] = useState("2 months")
  const [selected, setSelected] = useState<string[]>(["cloud-veil-body-mist"])
  const { addItem } = useCart()

  const toggle = (id: string) => setSelected((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id])

  const monthlyTotal = subscriptionProducts.filter((p) => selected.includes(p.id)).reduce((sum, p) => sum + p.price * 0.85, 0)

  const handleSubscribe = () => {
    if (selected.length === 0) { toast.error("Select at least one product to subscribe"); return }
    selected.forEach((id) => {
      const p = subscriptionProducts.find((x) => x.id === id)!
      addItem({ id: `sub-${id}`, name: `${p.name} (Subscription)`, description: `${frequency} delivery • 15% off`, price: Math.round(p.price * 0.85 * 100) / 100, image: p.image })
    })
    toast.success("Subscription added to cart")
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Never Run Out</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Scent Subscriptions</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Subscribe to your favorite rituals and save 15% on every order. Pause, skip, or cancel anytime.</p>
          </div>

          {/* Benefits */}
          <Reveal className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {[
              { icon: Sparkles, title: "15% Off", desc: "On every subscription order" },
              { icon: RefreshCw, title: "Flexible", desc: "Pause, skip, or cancel anytime" },
              { icon: Check, title: "Free Shipping", desc: "Always free for subscribers" },
              { icon: ArrowRight, title: "Early Access", desc: "New launches before everyone" },
            ].map((b, i) => (
              <div key={i} className="bg-card rounded-2xl p-5 text-center boty-shadow">
                <b.icon className="w-6 h-6 text-primary mx-auto mb-2" />
                <p className="font-medium text-foreground text-sm">{b.title}</p>
                <p className="text-xs text-muted-foreground">{b.desc}</p>
              </div>
            ))}
          </Reveal>

          {/* Frequency */}
          <Reveal className="bg-card rounded-3xl p-6 boty-shadow mb-6">
            <p className="text-sm font-medium text-foreground mb-3">Delivery Frequency</p>
            <div className="flex flex-wrap gap-2">
              {["1 month", "2 months", "3 months"].map((f) => (
                <button key={f} onClick={() => setFrequency(f)} className={`px-5 py-2.5 rounded-full text-sm boty-transition ${frequency === f ? "bg-primary text-primary-foreground" : "bg-background text-foreground boty-shadow"}`}>{f}</button>
              ))}
            </div>
          </Reveal>

          {/* Products */}
          <div className="grid sm:grid-cols-2 gap-4 mb-6">
            {subscriptionProducts.map((p, i) => (
              <Reveal key={p.id} delay={i * 60}>
                <button onClick={() => toggle(p.id)} className={`w-full flex gap-4 bg-card rounded-2xl p-4 boty-shadow boty-transition text-left ${selected.includes(p.id) ? "ring-2 ring-primary" : "hover:scale-[1.01]"}`}>
                  <div className="relative w-20 h-20 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-serif text-base text-foreground">{p.name}</p>
                    <p className="text-xs text-muted-foreground line-clamp-1">{p.description}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-sm text-muted-foreground line-through">${p.price}</span>
                      <span className="text-sm font-medium text-primary">${Math.round(p.price * 0.85 * 100) / 100}</span>
                    </div>
                  </div>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${selected.includes(p.id) ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                    {selected.includes(p.id) && <Check className="w-4 h-4" />}
                  </div>
                </button>
              </Reveal>
            ))}
          </div>

          {/* Summary */}
          <div className="sticky bottom-4 bg-card rounded-3xl p-5 boty-shadow flex items-center justify-between gap-4 flex-wrap">
            <div>
              <p className="text-xs text-muted-foreground">{selected.length} products • Every {frequency}</p>
              <p className="font-serif text-2xl text-foreground">${Math.round(monthlyTotal * 100) / 100} <span className="text-sm text-muted-foreground font-sans">per delivery</span></p>
            </div>
            <button onClick={handleSubscribe} disabled={selected.length === 0} className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm font-medium boty-transition hover:bg-primary/90 disabled:opacity-50 boty-shadow">
              Start Subscription <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-6">
            By starting a subscription you agree to our <Link href="/terms" className="underline hover:text-foreground">Terms of Service</Link>. Cancel anytime.
          </p>
        </div>
      </div>
      <Footer />
    </main>
  )
}
