"use client"

import { useState } from "react"
import Link from "next/link"
import { AuthShell } from "@/components/shared/auth-shell"
import { Mail, Lock, Eye, EyeOff, ArrowRight } from "lucide-react"
import { toast } from "sonner"

export default function SignInPage() {
  const [form, setForm] = useState({ email: "", password: "", remember: true })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.email || !form.password) { toast.error("Please fill in all fields"); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); toast.success("Welcome back!"); window.location.href = "/account" }, 800)
  }

  return (
    <AuthShell title="Welcome Back" subtitle="Sign in to your Lumina account">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Email</label>
          <div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="your@email.com" className="w-full bg-background border border-border rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition" /></div>
        </div>
        <div>
          <div className="flex items-center justify-between mb-2"><label className="text-sm font-medium text-foreground">Password</label><Link href="/forgot-password" className="text-xs text-primary hover:underline">Forgot?</Link></div>
          <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type={showPw ? "text" : "password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" className="w-full bg-background border border-border rounded-full pl-11 pr-11 py-3 text-sm focus:outline-none focus:border-primary boty-transition" /><button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">{showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div>
        </div>
        <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={form.remember} onChange={(e) => setForm({ ...form, remember: e.target.checked })} className="w-4 h-4 rounded accent-primary" /><span className="text-sm text-foreground">Remember me</span></label>
        <button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground py-3 rounded-full font-medium boty-transition hover:bg-primary/90 disabled:opacity-60 boty-shadow inline-flex items-center justify-center gap-2">{loading ? <><span className="lumina-spinner" /> Signing in...</> : <>Sign In <ArrowRight className="w-4 h-4" /></>}</button>
      </form>
      <div className="my-6 flex items-center gap-3"><div className="flex-1 h-px bg-border" /><span className="text-xs text-muted-foreground">OR</span><div className="flex-1 h-px bg-border" /></div>
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => toast.info("Google sign-in is a demo")} className="border border-border rounded-full py-2.5 text-sm text-foreground hover:bg-muted boty-transition">Google</button>
        <button onClick={() => toast.info("Apple sign-in is a demo")} className="border border-border rounded-full py-2.5 text-sm text-foreground hover:bg-muted boty-transition">Apple</button>
      </div>
      <p className="text-center text-sm text-muted-foreground mt-6">Don't have an account? <Link href="/sign-up" className="text-primary hover:underline">Sign up</Link></p>
    </AuthShell>
  )
}
