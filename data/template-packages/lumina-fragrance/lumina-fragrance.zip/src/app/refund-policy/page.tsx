import { PolicyPage } from "@/components/shared/policy-page"
export default function RefundPolicyPage() { return <PolicyPage slug="refund-policy" /> }
