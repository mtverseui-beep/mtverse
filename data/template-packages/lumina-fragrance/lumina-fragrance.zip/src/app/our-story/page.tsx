import Image from "next/image"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"

export default function OurStoryPage() {
  const milestones = [
    { year: "2024", title: "The Idea", desc: "Founded in a San Francisco studio with a simple belief: fragrance should feel like a second skin." },
    { year: "2025", title: "First Collection", desc: "Launched our first five body mists, each designed to layer with the others." },
    { year: "2025", title: "Home Rituals", desc: "Expanded into room sprays and pillow mists for soft home fragrance." },
    { year: "2026", title: "Refill Program", desc: "Introduced refillable 100ml bottles and 15ml travel minis to reduce waste." },
    { year: "2026", title: "Today", desc: "A complete fragrance wardrobe, from body to hair to home, all designed to be lived in." },
  ]

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">How We Began</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Our Story</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">A fragrance philosophy built on softness, layering, and the belief that scent is built, not worn.</p>
          </Reveal>

          <Reveal delay={80} className="lumina-prose max-w-3xl mx-auto mb-16">
            <p>Lumina started with a frustration. Every perfume we tried announced itself when it entered a room. We wanted something different, a fragrance that felt like a second skin, that was felt more than noticed, that became part of the texture of a life rather than a statement of identity.</p>
            <p>We began in a small studio in San Francisco, mixing formulas in 50ml glass bottles. The first five scents were soft, layerable, and built around the idea that fragrance should be a gentle ritual, not a complicated routine. Each was designed to be worn alone or composed with the others, so that a person could build a fragrance wardrobe that was unmistakably their own.</p>
            <h2>The Philosophy</h2>
            <p>Our fragrance philosophy is simple: scent is built, not worn. A body mist on the skin, a hair perfume through the lengths, a room spray in the air, each chosen to complement the others. The result is a multi-dimensional trail that feels natural rather than applied.</p>
          </Reveal>

          {/* Timeline */}
          <div className="relative max-w-3xl mx-auto">
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-border -translate-x-1/2" />
            {milestones.map((m, i) => (
              <Reveal key={m.year} delay={i * 80} className={`relative flex gap-6 mb-10 ${i % 2 === 0 ? "md:flex-row-reverse" : ""}`}>
                <div className="flex-none w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-medium z-10 md:absolute md:left-1/2 md:-translate-x-1/2">{i + 1}</div>
                <div className="flex-1 md:w-1/2 md:px-8">
                  <div className="bg-card rounded-3xl p-6 boty-shadow">
                    <p className="text-sm tracking-[0.24em] uppercase text-primary mb-2">{m.year}</p>
                    <h3 className="font-serif text-xl text-foreground mb-2">{m.title}</h3>
                    <p className="text-sm text-muted-foreground">{m.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
