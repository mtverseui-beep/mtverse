"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { AuthShell } from "@/components/shared/auth-shell"
import { Mail, ArrowRight, Check } from "lucide-react"
import { toast } from "sonner"

export default function VerifyEmailPage() {
  const [code, setCode] = useState(["", "", "", "", "", ""])
  const [loading, setLoading] = useState(false)
  const [verified, setVerified] = useState(false)
  const inputs = useRef<(HTMLInputElement | null)[]>([])

  useEffect(() => { inputs.current[0]?.focus() }, [])

  const handleChange = (i: number, val: string) => {
    if (!/^\d?$/.test(val)) return
    const next = [...code]
    next[i] = val
    setCode(next)
    if (val && i < 5) inputs.current[i + 1]?.focus()
  }

  const handleKey = (i: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !code[i] && i > 0) inputs.current[i - 1]?.focus()
  }

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault()
    if (code.join("").length !== 6) { toast.error("Please enter the 6-digit code"); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); setVerified(true); toast.success("Email verified!") }, 800)
  }

  return (
    <AuthShell title="Verify Your Email" subtitle="Enter the 6-digit code we sent you">
      {verified ? (
        <div className="text-center py-4">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4"><Check className="w-8 h-8 text-primary" /></div>
          <p className="font-medium text-foreground mb-2">Email Verified</p>
          <p className="text-sm text-muted-foreground mb-6">Your account is now active. Welcome to Lumina.</p>
          <Link href="/account" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Go to Dashboard <ArrowRight className="w-4 h-4" /></Link>
        </div>
      ) : (
        <form onSubmit={handleVerify} className="space-y-6">
          <div className="flex justify-center gap-2">
            {code.map((digit, i) => (
              <input key={i} ref={(el) => { inputs.current[i] = el }} type="text" maxLength={1} value={digit} onChange={(e) => handleChange(i, e.target.value)} onKeyDown={(e) => handleKey(i, e)} className="w-12 h-14 text-center text-xl font-serif bg-background border-2 border-border rounded-2xl focus:outline-none focus:border-primary boty-transition" />
            ))}
          </div>
          <button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground py-3 rounded-full font-medium boty-transition hover:bg-primary/90 disabled:opacity-60 boty-shadow inline-flex items-center justify-center gap-2">{loading ? <><span className="lumina-spinner" /> Verifying...</> : <>Verify Email <ArrowRight className="w-4 h-4" /></>}</button>
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Didn't receive a code?</p>
            <button type="button" onClick={() => toast.success("Code resent")} className="text-sm text-primary hover:underline mt-1">Resend code</button>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground"><Mail className="w-3.5 h-3.5" /> Sent to your@email.com</div>
        </form>
      )}
    </AuthShell>
  )
}
