"use client"

import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { products } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { Heart, ShoppingBag, Trash2, ArrowRight } from "lucide-react"

export default function WishlistPage() {
  const [ids, setIds, hydrated] = useLocalStorage<string[]>("lumina-wishlist", [])
  const { addItem } = useCart()

  const items = products.filter((p) => ids.includes(p.id))

  const remove = (id: string) => setIds((prev) => prev.filter((x) => x !== id))

  if (!hydrated) {
    return (
      <main className="min-h-screen">
        <Header />
        <div className="pt-28 pb-20 max-w-7xl mx-auto px-6 lg:px-8">
          <div className="lumina-skeleton h-12 w-48 mb-8" />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => <div key={i} className="lumina-skeleton h-80 w-full" />)}
          </div>
        </div>
        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Saved For Later</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">Your Wishlist</h1>
            <p className="text-lg text-muted-foreground">{items.length} {items.length === 1 ? "item" : "items"} saved</p>
          </div>

          {items.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-24 h-24 rounded-full bg-card flex items-center justify-center mx-auto mb-6 boty-shadow">
                <Heart className="w-10 h-10 text-muted-foreground" />
              </div>
              <p className="text-lg text-muted-foreground mb-6">Your wishlist is empty.</p>
              <Link href="/shop" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow">
                Browse Products <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {items.map((product) => (
                <div key={product.id} className="bg-background rounded-3xl overflow-hidden boty-shadow group">
                  <Link href={`/product/${product.id}`} className="relative aspect-square block bg-muted overflow-hidden">
                    <Image src={product.image} alt={product.name} fill className="object-cover boty-transition group-hover:scale-105" />
                    {product.badge && (
                      <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs bg-white text-black">{product.badge}</span>
                    )}
                  </Link>
                  <div className="p-5">
                    <h3 className="font-serif text-lg text-foreground mb-1">{product.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{product.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-foreground">${product.price}</span>
                      <div className="flex gap-2">
                        <button onClick={() => { addItem({ id: product.id, name: product.name, description: product.description, price: product.price, image: product.image }) }} className="w-9 h-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 boty-transition" aria-label="Add to cart">
                          <ShoppingBag className="w-4 h-4" />
                        </button>
                        <button onClick={() => remove(product.id)} className="w-9 h-9 rounded-full bg-muted text-muted-foreground hover:text-destructive flex items-center justify-center boty-transition" aria-label="Remove">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </main>
  )
}
