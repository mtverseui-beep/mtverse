"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { products } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { ArrowRight, ArrowLeft, Check, Sparkles, RotateCcw } from "lucide-react"
import { toast } from "sonner"

const questions = [
  { id: "time", prompt: "Which time of day feels most like you?", options: [{ id: "fresh", label: "Early morning", value: "fresh" }, { id: "citrus", label: "Bright midday", value: "citrus" }, { id: "warm", label: "Golden hour", value: "warm" }, { id: "amber", label: "Long evening", value: "amber" }] },
  { id: "note", prompt: "Which note draws you most?", options: [{ id: "floral", label: "Fresh rose petals", value: "floral" }, { id: "vanilla", label: "Bourbon vanilla", value: "vanilla" }, { id: "musk", label: "Clean white musk", value: "musk" }, { id: "citrus", label: "Cold-pressed bergamot", value: "citrus" }] },
  { id: "wear", prompt: "How do you want a fragrance to wear?", options: [{ id: "soft", label: "Like a second skin", value: "soft" }, { id: "moderate", label: "Quiet but lingering", value: "moderate" }, { id: "moderate2", label: "Quietly present", value: "moderate" }, { id: "intense", label: "Deep and enveloping", value: "intense" }] },
  { id: "occasion", prompt: "Which occasion do you dress for most?", options: [{ id: "everyday", label: "Everyday", value: "everyday" }, { id: "office", label: "Office", value: "office" }, { id: "weekend", label: "Weekend", value: "weekend" }, { id: "evening", label: "Evening out", value: "evening" }] },
  { id: "season", prompt: "Which season do you live for?", options: [{ id: "floral", label: "Spring", value: "floral" }, { id: "citrus", label: "Summer", value: "citrus" }, { id: "warm", label: "Autumn", value: "warm" }, { id: "amber", label: "Winter", value: "amber" }] },
]

function computeResult(answers: Record<string, string>) {
  const values = Object.values(answers)
  const counts: Record<string, number> = {}
  values.forEach((v) => { counts[v] = (counts[v] || 0) + 1 })
  const winner = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || "fresh"
  if (["vanilla", "amber", "warm"].includes(winner)) {
    return { title: "Warm Amber & Vanilla", description: "You lean toward warm ambers, vanilla, and soft sandalwood. Second-skin scents that wear close and deepen over hours.", productIds: ["vanilla-hour-fragrance-mist", "evening-velvet-body-mist", "warm-skin-hair-perfume"], family: "Warm Vanilla Amber" }
  }
  if (["citrus", "fresh"].includes(winner)) {
    return { title: "Clean Citrus & Fresh", description: "You lean toward bright citrus and clean musks. Crisp, lifting scents that wake the senses without sharpness.", productIds: ["citrus-linen-room-spray", "cloud-veil-body-mist", "soft-musk-travel-mini"], family: "Citrus Aromatic" }
  }
  if (["clean", "soft", "musk"].includes(winner)) {
    return { title: "Calm Home & Soft Musk", description: "You lean toward soft home fragrance and clean musk. Quiet rituals for the home and body, designed to settle the senses.", productIds: ["calm-linen-pillow-mist", "cloud-veil-body-mist", "clean-cotton-room-spray"], family: "Clean Musk" }
  }
  return { title: "Soft Floral & Fresh", description: "You lean toward dewy florals and clean musks. Soft, intimate scents that feel like a fresh petal crushed between fingers.", productIds: ["cloud-veil-body-mist", "rose-milk-body-mist", "amber-bloom-hair-perfume"], family: "Soft Floral Musk" }
}

export default function FragranceQuizPage() {
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [showResult, setShowResult] = useState(false)
  const { addItem } = useCart()

  const current = questions[step]
  const progress = showResult ? 100 : (step / questions.length) * 100

  const choose = (qid: string, value: string) => {
    setAnswers((prev) => ({ ...prev, [qid]: value }))
    setTimeout(() => {
      if (step < questions.length - 1) setStep(step + 1)
      else setShowResult(true)
    }, 250)
  }

  const reset = () => { setStep(0); setAnswers({}); setShowResult(false) }

  const result = showResult ? computeResult(answers) : null
  const resultProducts = result ? result.productIds.map((id) => products.find((p) => p.id === id)!).filter(Boolean) : []

  const handleAddAll = () => {
    resultProducts.forEach((p) => addItem({ id: p.id, name: p.name, description: p.description, price: p.price, image: p.image }))
    toast.success("Your recommended rituals added to cart")
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20 min-h-screen flex items-center">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 w-full">
          <div className="text-center mb-8">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Find Your Scent</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Fragrance Quiz</h1>
          </div>

          {/* Progress */}
          <div className="mb-10">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-muted-foreground">{showResult ? "Result" : `Question ${step + 1} of ${questions.length}`}</span>
              <span className="text-muted-foreground">{Math.round(progress)}%</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-primary transition-all duration-500" style={{ width: `${progress}%` }} />
            </div>
          </div>

          {!showResult ? (
            <Reveal key={step} className="bg-card rounded-3xl p-8 lg:p-12 boty-shadow">
              <h2 className="font-serif text-2xl md:text-3xl text-foreground mb-8 text-center">{current.prompt}</h2>
              <div className="grid sm:grid-cols-2 gap-3">
                {current.options.map((opt) => (
                  <button key={opt.id} onClick={() => choose(current.id, opt.value)} className={`p-5 rounded-2xl border-2 boty-transition text-left ${answers[current.id] === opt.value ? "border-primary bg-primary/5" : "border-border bg-background hover:border-primary/50"}`}>
                    <span className="font-serif text-lg text-foreground">{opt.label}</span>
                  </button>
                ))}
              </div>
              {step > 0 && (
                <button onClick={() => setStep(step - 1)} className="mt-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground boty-transition">
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
              )}
            </Reveal>
          ) : result ? (
            <Reveal className="bg-card rounded-3xl p-8 lg:p-12 boty-shadow">
              <div className="text-center mb-8">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-primary" />
                </div>
                <p className="text-xs tracking-[0.24em] uppercase text-primary mb-2">{result.family}</p>
                <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">{result.title}</h2>
                <p className="text-muted-foreground max-w-md mx-auto leading-relaxed">{result.description}</p>
              </div>
              <div className="grid sm:grid-cols-3 gap-4 mb-8">
                {resultProducts.map((p) => (
                  <Link key={p.id} href={`/product/${p.id}`} className="bg-background rounded-2xl overflow-hidden boty-shadow group">
                    <div className="relative aspect-square bg-muted">
                      <Image src={p.image} alt={p.name} fill className="object-cover boty-transition group-hover:scale-105" />
                    </div>
                    <div className="p-3">
                      <p className="font-serif text-sm text-foreground line-clamp-1">{p.name}</p>
                      <p className="text-xs text-muted-foreground">${p.price}</p>
                    </div>
                  </Link>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <button onClick={handleAddAll} className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm font-medium boty-transition hover:bg-primary/90 boty-shadow">
                  <Check className="w-4 h-4" /> Add All to Cart
                </button>
                <button onClick={reset} className="inline-flex items-center justify-center gap-2 bg-transparent border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted">
                  <RotateCcw className="w-4 h-4" /> Retake Quiz
                </button>
                <Link href="/discovery-sets" className="inline-flex items-center justify-center gap-2 bg-transparent border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted">
                  Get Discovery Set <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </Reveal>
          ) : null}
        </div>
      </div>
      <Footer />
    </main>
  )
}
