"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Search, Package, Truck, CheckCircle, Clock, ArrowRight } from "lucide-react"
import { toast } from "sonner"

const mockOrder = {
  number: "LUM-100589",
  date: "June 30, 2026",
  status: "Shipped",
  estimatedDelivery: "July 5, 2026",
  trackingNumber: "1Z999AA10198765432",
  items: [
    { name: "Moonlit Amber Gift Set", qty: 1, price: 96, image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=400&q=80" },
  ],
  timeline: [
    { label: "Order placed", date: "Jun 30", done: true, icon: CheckCircle },
    { label: "Processing", date: "Jun 30", done: true, icon: Clock },
    { label: "Shipped", date: "Jul 1", done: true, icon: Package },
    { label: "In transit", date: "Jul 2", done: true, icon: Truck },
    { label: "Out for delivery", date: "Jul 5", done: false, icon: Truck },
  ],
}

export default function TrackOrderPage() {
  const [orderNumber, setOrderNumber] = useState("")
  const [email, setEmail] = useState("")
  const [searched, setSearched] = useState(false)

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault()
    if (!orderNumber.trim() || !email.trim()) { toast.error("Please enter your order number and email"); return }
    setSearched(true)
    toast.success("Order found")
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-3xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Order Status</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Track Your Order</h1>
            <p className="text-lg text-muted-foreground">Enter your order number and email to see your shipment status.</p>
          </div>

          <Reveal className="bg-card rounded-3xl p-6 lg:p-8 boty-shadow mb-8">
            <form onSubmit={handleTrack} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Order Number</label>
                <input type="text" value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} placeholder="LUM-100589" className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Email Address</label>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition" />
              </div>
              <button type="submit" className="w-full bg-primary text-primary-foreground py-3 rounded-full font-medium hover:bg-primary/90 boty-transition boty-shadow inline-flex items-center justify-center gap-2">
                <Search className="w-4 h-4" /> Track Order
              </button>
            </form>
            <p className="text-xs text-muted-foreground mt-4 text-center">Try order number <button onClick={() => { setOrderNumber("LUM-100589"); setEmail("aurelia@example.com") }} className="text-primary underline">LUM-100589</button> with email aurelia@example.com for a demo.</p>
          </Reveal>

          {searched && (
            <Reveal className="bg-card rounded-3xl p-6 lg:p-8 boty-shadow">
              <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
                <div>
                  <p className="text-xs text-muted-foreground">Order</p>
                  <p className="font-serif text-2xl text-foreground">{mockOrder.number}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Estimated delivery</p>
                  <p className="font-medium text-foreground">{mockOrder.estimatedDelivery}</p>
                </div>
              </div>

              {/* Timeline */}
              <div className="mb-8">
                <div className="flex items-center justify-between relative">
                  <div className="absolute top-5 left-5 right-5 h-0.5 bg-muted" />
                  <div className="absolute top-5 left-5 h-0.5 bg-primary transition-all duration-700" style={{ width: "60%" }} />
                  {mockOrder.timeline.map((step, i) => (
                    <div key={i} className="relative z-10 flex flex-col items-center text-center" style={{ width: "20%" }}>
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 boty-transition ${step.done ? "bg-primary border-primary text-primary-foreground" : "bg-background border-border text-muted-foreground"}`}>
                        <step.icon className="w-4 h-4" />
                      </div>
                      <p className={`text-[10px] mt-2 ${step.done ? "text-foreground font-medium" : "text-muted-foreground"}`}>{step.label}</p>
                      <p className="text-[10px] text-muted-foreground">{step.date}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tracking number */}
              <div className="bg-background rounded-2xl p-4 mb-6 flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Tracking Number</p>
                  <p className="font-mono text-sm text-foreground">{mockOrder.trackingNumber}</p>
                </div>
                <button onClick={() => toast.success("Opening carrier tracking...")} className="text-sm text-primary hover:underline">Track →</button>
              </div>

              {/* Items */}
              <div className="space-y-3">
                <p className="text-sm font-medium text-foreground">Items in this order</p>
                {mockOrder.items.map((item, i) => (
                  <div key={i} className="flex items-center gap-4 bg-background rounded-2xl p-3">
                    <img src={item.image} alt={item.name} className="w-14 h-14 rounded-xl object-cover" />
                    <div className="flex-1">
                      <p className="font-serif text-sm text-foreground">{item.name}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.qty}</p>
                    </div>
                    <p className="font-medium text-foreground">${item.price}</p>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 mt-6">
                <Link href="/account/orders" className="flex-1 text-center bg-foreground text-background py-3 rounded-full text-sm boty-transition hover:bg-foreground/90">View All Orders</Link>
                <Link href="/help/orders" className="flex-1 text-center border border-border text-foreground py-3 rounded-full text-sm boty-transition hover:bg-muted">Need Help?</Link>
              </div>
            </Reveal>
          )}
        </div>
      </div>
      <Footer />
    </main>
  )
}
