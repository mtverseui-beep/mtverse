import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { products } from "@/data/products"
import { ArrowRight } from "lucide-react"

const looks = [
  { title: "Morning Light", caption: "Cloud Veil on bare skin after a warm shower. Soft petals and clean musk for the first hours of the day.", image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1200&q=80", productIds: ["cloud-veil-body-mist", "rose-milk-body-mist"], category: "Morning" },
  { title: "The Long Evening", caption: "Evening Velvet layered with Warm Skin Hair Perfume. Deep amber and plum for hours of slow conversation.", image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1200&q=80", productIds: ["evening-velvet-body-mist", "warm-skin-hair-perfume"], category: "Evening" },
  { title: "The Quiet Room", caption: "Calm Linen Pillow Mist before bed. Lavender and vanilla settle onto sheets for a slow, restful night.", image: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=1200&q=80", productIds: ["calm-linen-pillow-mist"], category: "Home" },
  { title: "The First Warm Day", caption: "Citrus Linen Room Spray through an open window. Cold-pressed citrus and white tea for spring mornings.", image: "https://images.unsplash.com/photo-1600573472556-e636c2acda88?auto=format&fit=crop&w=1200&q=80", productIds: ["citrus-linen-room-spray"], category: "Morning" },
  { title: "Bloom Layering", caption: "Rose Milk Body Mist beneath Amber Bloom Hair Perfume. A dimensional floral that lifts with every movement.", image: "https://images.unsplash.com/photo-1587017539504-67cfbddac569?auto=format&fit=crop&w=1200&q=80", productIds: ["bloom-layering-duo"], category: "Layering" },
  { title: "Vanilla Hour", caption: "Vanilla Hour Body Mist over warm skin. Bourbon vanilla and amber for the moment the light softens.", image: "https://images.unsplash.com/photo-1601990102012-7c88cc2aa9a9?auto=format&fit=crop&w=1200&q=80", productIds: ["vanilla-hour-fragrance-mist"], category: "Evening" },
]

export default function LookbookPage() {
  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Editorial</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Lookbook</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Visual stories of scent in everyday life. Each look is shoppable — click to explore the products.</p>
          </Reveal>

          <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
            {looks.map((look, i) => (
              <Reveal key={look.title} delay={i * 60} className="break-inside-avoid mb-6">
                <div className="group relative rounded-3xl overflow-hidden boty-shadow">
                  <div className="relative aspect-[3/4] bg-muted">
                    <Image src={look.image} alt={look.title} fill className="object-cover boty-transition group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-transparent to-transparent opacity-80" />
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-ivory">
                      <p className="text-xs tracking-[0.24em] uppercase text-gold mb-2">{look.category}</p>
                      <h2 className="font-serif text-2xl mb-2">{look.title}</h2>
                      <p className="text-sm text-ivory/80 mb-4 line-clamp-2">{look.caption}</p>
                      <div className="flex flex-wrap gap-2">
                        {look.productIds.map((id) => {
                          const p = products.find((x) => x.id === id)
                          return p ? <Link key={id} href={`/product/${id}`} className="text-xs px-3 py-1 rounded-full bg-ivory/20 backdrop-blur text-ivory hover:bg-ivory hover:text-espresso boty-transition">Shop {p.name.split(" ").slice(0, 2).join(" ")} →</Link> : null
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
