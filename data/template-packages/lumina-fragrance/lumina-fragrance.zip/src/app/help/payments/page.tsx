import { HelpSubPage } from "@/components/shared/help-sub-page"

export default function HelpPaymentsPage() {
  return <HelpSubPage eyebrow="Help Center" title="Payments" sections={[
    { heading: "Accepted payment methods", body: ["We accept all major credit and debit cards (Visa, Mastercard, American Express, Discover), as well as PayPal, Apple Pay, and Google Pay.", "All payments are processed securely through our payment processor. We never store your full card details on our servers."] },
    { heading: "Payment security", body: ["Our checkout is secured with 256-bit SSL encryption. Your payment information is tokenized and processed by our PCI-compliant payment processor.", "We never see or store your full card number. We only store a tokenized reference to your card for future orders, with your permission."] },
    { heading: "Promo codes and discounts", body: ["Promo codes can be entered at checkout or in your cart. Only one promo code can be used per order. Codes cannot be applied retroactively to past orders.", "Sign up for our newsletter to receive 10% off your first order. Rewards members earn points on every purchase that can be redeemed for discounts."] },
    { heading: "Taxes", body: ["Applicable sales tax is calculated at checkout based on your shipping address. Tax is not charged on gift card purchases, but is applied when the gift card is redeemed.", "For international orders, import duties and taxes may apply and are the responsibility of the recipient."] },
  ]} />
}
