import { HelpSubPage } from "@/components/shared/help-sub-page"

export default function HelpReturnsPage() {
  return <HelpSubPage eyebrow="Help Center" title="Returns & Exchanges" sections={[
    { heading: "30-day return policy", body: ["We accept returns within 30 days of delivery on unopened products in their original packaging. To start a return, email hello@luminamist.co with your order number and the items you would like to return.", "We will send you a return label and instructions within 1 business day. Drop off the package at any carrier location. Refunds are processed within 3 business days of receiving your return."] },
    { heading: "Tried and didn't love it", body: ["If you have tried a product and it has not worked for you, contact us. We will often offer a store credit or exchange rather than require a return. We want you to find a fragrance you love, and we will work with you to make that happen.", "For safety and hygiene reasons, we cannot accept returns of opened products. We will instead offer a store credit toward a different scent."] },
    { heading: "Damaged or incorrect items", body: ["If your order arrives damaged or you received the wrong item, please contact us within 7 days of delivery with a photo of the issue. We will send a replacement or issue a full refund, including return shipping if applicable.", "We take full responsibility for any errors on our part and will make it right at no cost to you."] },
    { heading: "Refunds", body: ["Refunds are processed within 3 business days of receiving your return. The refund is issued to the original payment method and may take an additional 3 to 5 business days to appear on your statement, depending on your bank.", "Shipping charges are non-refundable except in cases where the order was lost, damaged, or incorrectly fulfilled by us."] },
  ]} />
}
