import { HelpSubPage } from "@/components/shared/help-sub-page"

export default function HelpOrdersPage() {
  return <HelpSubPage eyebrow="Help Center" title="Orders" sections={[
    { heading: "Tracking your order", body: ["You will receive a tracking number by email when your order ships. You can also track your order anytime at /track-order using your order number and email address.", "If you created an account, you can view all your orders and their statuses in your account dashboard."] },
    { heading: "Modifying or canceling an order", body: ["Orders can be changed or cancelled within 1 hour of placing them. Email hello@luminamist.co as soon as possible with your order number and the change you would like to make.", "Once an order has been processed for shipping, it can no longer be modified. You can return any unwanted items for a refund within 30 days of delivery."] },
    { heading: "Missing items", body: ["If your order is missing an item, please contact us within 7 days of delivery with your order number and a description of what's missing. We will send the missing item immediately at no additional cost.", "If an item was listed as backordered at checkout, it will ship separately when it becomes available, with no additional shipping charge."] },
    { heading: "Gift orders", body: ["Add a gift note at checkout and we will handwrite it on Lumina stationery and include it in the package. Gift notes are free and available on any order.", "Gift orders do not include a packing slip with prices. The recipient will receive a separate email with their own tracking information."] },
  ]} />
}
