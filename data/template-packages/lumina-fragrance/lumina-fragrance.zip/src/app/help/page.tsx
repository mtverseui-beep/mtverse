"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { faqs } from "@/data/content"
import { Search, ArrowRight, Truck, RotateCcw, Package, CreditCard } from "lucide-react"

export default function HelpPage() {
  const [query, setQuery] = useState("")
  const filtered = faqs.filter((f) => f.question.toLowerCase().includes(query.toLowerCase()) || f.answer.toLowerCase().includes(query.toLowerCase()))

  const topics = [
    { icon: Truck, title: "Shipping", desc: "Delivery times, tracking, international", href: "/help/shipping" },
    { icon: RotateCcw, title: "Returns", desc: "30-day returns and exchanges", href: "/help/returns" },
    { icon: Package, title: "Orders", desc: "Track, modify, or cancel your order", href: "/help/orders" },
    { icon: CreditCard, title: "Payments", desc: "Payment methods and security", href: "/help/payments" },
  ]

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Help Center</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">How Can We Help?</h1>
            <div className="max-w-xl mx-auto relative mt-6">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search for help..." className="w-full bg-card border border-border rounded-full pl-12 pr-4 py-4 text-sm focus:outline-none focus:border-primary boty-shadow boty-transition" />
            </div>
          </Reveal>

          {/* Topics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            {topics.map((t, i) => (
              <Reveal key={t.title} delay={i * 60}>
                <Link href={t.href} className="block bg-card rounded-3xl p-5 boty-shadow hover:scale-[1.02] boty-transition text-center">
                  <t.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                  <h3 className="font-serif text-lg text-foreground mb-1">{t.title}</h3>
                  <p className="text-xs text-muted-foreground">{t.desc}</p>
                </Link>
              </Reveal>
            ))}
          </div>

          {/* FAQs */}
          <Reveal className="bg-card rounded-3xl p-6 boty-shadow">
            <h2 className="font-serif text-2xl text-foreground mb-4">Frequently Asked Questions</h2>
            {filtered.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No results for &ldquo;{query}&rdquo;. Try a different search or <Link href="/contact" className="text-primary hover:underline">contact us</Link>.</p>
            ) : (
              <div className="space-y-3">
                {filtered.slice(0, 6).map((f) => (
                  <details key={f.id} className="bg-background rounded-2xl p-4 group">
                    <summary className="font-medium text-foreground cursor-pointer flex items-center justify-between">{f.question}<ArrowRight className="w-4 h-4 text-muted-foreground group-open:rotate-90 transition-transform" /></summary>
                    <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{f.answer}</p>
                  </details>
                ))}
              </div>
            )}
            <Link href="/faq" className="inline-flex items-center gap-1 text-sm text-primary mt-4 hover:underline">View all FAQs <ArrowRight className="w-3.5 h-3.5" /></Link>
          </Reveal>

          <Reveal delay={120} className="text-center mt-8">
            <p className="text-muted-foreground mb-2">Still need help?</p>
            <Link href="/contact" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow">Contact Support <ArrowRight className="w-4 h-4" /></Link>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
