import { HelpSubPage } from "@/components/shared/help-sub-page"

export default function HelpShippingPage() {
  return <HelpSubPage eyebrow="Help Center" title="Shipping" sections={[
    { heading: "Processing time", body: ["Orders are processed within 1 business day of being placed. Orders placed on weekends or holidays are processed on the next business day. You will receive a confirmation email with tracking information when your order ships.", "During high-volume periods such as product launches or holidays, processing may take up to 2 business days. We will communicate any delays by email."] },
    { heading: "Domestic shipping (United States)", body: ["We offer free standard shipping on all orders over $50 within the US. Orders under $50 ship for a flat $5. Standard shipping takes 3 to 5 business days. Expedited shipping options are available at checkout.", "We ship to all 50 states, including PO boxes and APO/FPO addresses. Signature confirmation is required on orders over $200."] },
    { heading: "International shipping", body: ["We ship to over 40 countries. International shipping is calculated at checkout based on destination and weight. Delivery typically takes 7 to 14 business days depending on the destination.", "Import duties, taxes, and customs fees may apply and are the responsibility of the recipient. We cannot mark packages as gifts or undervalue the contents for customs purposes."] },
    { heading: "Tracking your order", body: ["You will receive a tracking number by email when your order ships. You can also track your order anytime at /track-order using your order number and email address.", "If your tracking number hasn't updated in 48 hours, please contact us at hello@luminamist.co and we'll look into it."] },
  ]} />
}
