"use client"

import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { products } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { Clock, ShoppingBag, ArrowRight, Trash2 } from "lucide-react"

export default function RecentlyViewedPage() {
  const [ids, setIds, hydrated] = useLocalStorage<string[]>("lumina-recently-viewed", [])
  const { addItem } = useCart()
  const items = ids.map((id) => products.find((p) => p.id === id)).filter(Boolean) as typeof products

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Your History</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">Recently Viewed</h1>
            <p className="text-lg text-muted-foreground">{items.length} {items.length === 1 ? "item" : "items"} you've looked at</p>
          </div>

          {!hydrated ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">{[1, 2, 3, 4].map((i) => <div key={i} className="lumina-skeleton h-80 w-full" />)}</div>
          ) : items.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-24 h-24 rounded-full bg-card flex items-center justify-center mx-auto mb-6 boty-shadow">
                <Clock className="w-10 h-10 text-muted-foreground" />
              </div>
              <p className="text-lg text-muted-foreground mb-6">You haven't viewed any products yet.</p>
              <Link href="/shop" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow">Browse Products <ArrowRight className="w-4 h-4" /></Link>
            </div>
          ) : (
            <>
              <div className="flex justify-end mb-4">
                <button onClick={() => setIds([])} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-destructive boty-transition"><Trash2 className="w-3.5 h-3.5" /> Clear history</button>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {items.map((p) => (
                  <div key={p.id} className="bg-card rounded-3xl overflow-hidden boty-shadow group">
                    <Link href={`/product/${p.id}`} className="relative aspect-square block bg-muted overflow-hidden">
                      <Image src={p.image} alt={p.name} fill className="object-cover boty-transition group-hover:scale-105" />
                      {p.badge && <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs bg-white text-black">{p.badge}</span>}
                    </Link>
                    <div className="p-5">
                      <h3 className="font-serif text-lg text-foreground mb-1">{p.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{p.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-foreground">${p.price}</span>
                        <button onClick={() => addItem({ id: p.id, name: p.name, description: p.description, price: p.price, image: p.image })} className="w-9 h-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 boty-transition" aria-label="Add to cart"><ShoppingBag className="w-4 h-4" /></button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
      <Footer />
    </main>
  )
}
