"use client"

import { useState } from "react"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Star, Quote } from "lucide-react"

const reviews = [
  { name: "Sarah M.", location: "New York", rating: 5, date: "2 weeks ago", product: "Cloud Veil Body Mist", text: "Cloud Veil has become my everyday signature. It wears so softly and the musk base lingers for hours without ever feeling loud.", verified: true },
  { name: "Emma L.", location: "Los Angeles", rating: 5, date: "3 weeks ago", product: "Amber Bloom Hair Perfume", text: "Finally, a hair perfume that doesn't dry my hair. Amber Bloom leaves the most beautiful trail whenever I move. Absolutely in love.", verified: true },
  { name: "Jessica R.", location: "Chicago", rating: 5, date: "1 month ago", product: "Vanilla Hour Fragrance Mist", text: "The Vanilla Hour mist is divine. Grown-up vanilla, never cloying. I layer it with the hair perfume for the long evenings.", verified: true },
  { name: "Maria K.", location: "Miami", rating: 5, date: "1 month ago", product: "Bloom Layering Duo", text: "I've tried countless body mists but nothing compares to the depth of Lumina. The layering duo changed my whole routine.", verified: true },
  { name: "Sophie T.", location: "Seattle", rating: 4, date: "1 month ago", product: "Soft Musk Travel Mini", text: "The packaging is beautiful and the bottles are refillable. I feel good choosing sustainable fragrance that also smells incredible.", verified: true },
  { name: "Anna P.", location: "Boston", rating: 5, date: "2 months ago", product: "Calm Linen Pillow Mist", text: "The Calm Linen pillow mist has completely transformed my bedtime routine. I sleep so much better now. A small ritual I treasure.", verified: true },
  { name: "Claire B.", location: "Austin", rating: 5, date: "2 months ago", product: "Citrus Linen Room Spray", text: "The Citrus Linen room spray is perfection. I spritz it before guests arrive and everyone asks what the scent is. So fresh and clean.", verified: true },
  { name: "Lily W.", location: "Portland", rating: 5, date: "3 months ago", product: "Golden Fig Discovery Set", text: "I love that Lumina is vegan and cruelty-free. Beautiful fragrances that align with my values. The discovery set was the perfect intro.", verified: true },
  { name: "Rachel D.", location: "Denver", rating: 5, date: "3 months ago", product: "Rose Milk Body Mist", text: "The scent is so subtle and natural. No overpowering perfumes, just soft layered fragrance that feels like a second skin.", verified: true },
]

export default function ReviewsPage() {
  const [filter, setFilter] = useState("all")
  const [rating, setRating] = useState<number | null>(null)

  const filtered = reviews.filter((r) => (filter === "all" || r.product.includes(filter)) && (rating === null || r.rating === rating))
  const avg = (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Kind Words</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Customer Reviews</h1>
            <p className="text-lg text-muted-foreground">Real reviews from real Lumina customers.</p>
          </Reveal>

          {/* Summary */}
          <Reveal delay={80} className="bg-card rounded-3xl p-8 boty-shadow mb-12">
            <div className="grid sm:grid-cols-4 gap-6 items-center">
              <div className="text-center sm:border-r sm:border-border/50">
                <p className="font-serif text-5xl text-foreground">{avg}</p>
                <div className="flex justify-center gap-0.5 my-2">{[1, 2, 3, 4, 5].map((n) => <Star key={n} className={`w-4 h-4 ${n <= Math.round(Number(avg)) ? "fill-primary text-primary" : "text-muted"}`} />)}</div>
                <p className="text-xs text-muted-foreground">{reviews.length} reviews</p>
              </div>
              <div className="sm:col-span-3 space-y-2">
                {[5, 4, 3, 2, 1].map((star) => {
                  const count = reviews.filter((r) => r.rating === star).length
                  const pct = (count / reviews.length) * 100
                  return (
                    <div key={star} className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground w-12 flex items-center gap-1">{star} <Star className="w-3 h-3 fill-primary text-primary" /></span>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden"><div className="h-full bg-primary" style={{ width: `${pct}%` }} /></div>
                      <span className="text-xs text-muted-foreground w-8 text-right">{count}</span>
                    </div>
                  )
                })}
              </div>
            </div>
          </Reveal>

          {/* Filters */}
          <Reveal delay={120} className="flex flex-wrap items-center justify-between gap-4 mb-8">
            <div className="flex flex-wrap gap-2">
              <button onClick={() => setRating(null)} className={`px-4 py-2 rounded-full text-sm boty-transition ${rating === null ? "bg-primary text-primary-foreground" : "bg-card text-foreground boty-shadow"}`}>All ratings</button>
              {[5, 4, 3].map((r) => <button key={r} onClick={() => setRating(r)} className={`px-4 py-2 rounded-full text-sm boty-transition ${rating === r ? "bg-primary text-primary-foreground" : "bg-card text-foreground boty-shadow"}`}>{r} stars</button>)}
            </div>
            <select onChange={(e) => setFilter(e.target.value)} className="bg-card border border-border rounded-full px-4 py-2 text-sm boty-shadow focus:outline-none">
              <option value="all">All products</option>
              <option value="Body Mist">Body Mists</option>
              <option value="Hair Perfume">Hair Perfumes</option>
              <option value="Room Spray">Room Sprays</option>
              <option value="Discovery Set">Discovery Sets</option>
            </select>
          </Reveal>

          {/* Reviews */}
          <div className="grid md:grid-cols-2 gap-6">
            {filtered.map((r, i) => (
              <Reveal key={i} delay={i * 50} className="bg-card rounded-3xl p-6 boty-shadow">
                <Quote className="w-8 h-8 text-primary/30 mb-3" />
                <div className="flex gap-0.5 mb-3">{[1, 2, 3, 4, 5].map((n) => <Star key={n} className={`w-4 h-4 ${n <= r.rating ? "fill-primary text-primary" : "text-muted"}`} />)}</div>
                <p className="text-foreground/80 leading-relaxed mb-4 font-serif text-lg">&ldquo;{r.text}&rdquo;</p>
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-bold text-foreground">{r.name} {r.verified && <span className="text-xs font-normal text-primary ml-1">✓ Verified</span>}</p>
                    <p className="text-xs text-muted-foreground">{r.location} • {r.date}</p>
                  </div>
                  <span className="text-xs text-primary bg-primary/5 px-2 py-1 rounded-full whitespace-nowrap">{r.product}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
