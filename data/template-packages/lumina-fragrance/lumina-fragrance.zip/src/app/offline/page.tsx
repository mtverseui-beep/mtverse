"use client"

import { WifiOff, RefreshCw } from "lucide-react"

export default function OfflinePage() {
  return (
    <main className="min-h-screen lumina-page flex items-center justify-center px-6">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 rounded-full bg-card flex items-center justify-center mx-auto mb-6 boty-shadow">
          <WifiOff className="w-10 h-10 text-muted-foreground" />
        </div>
        <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">No Connection</span>
        <h1 className="font-serif text-4xl text-foreground mb-4">You're offline</h1>
        <p className="text-lg text-muted-foreground mb-8">It looks like you've lost your internet connection. Please check your network and try again.</p>
        <button onClick={() => window.location.reload()} className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow"><RefreshCw className="w-4 h-4" /> Retry</button>
      </div>
    </main>
  )
}
