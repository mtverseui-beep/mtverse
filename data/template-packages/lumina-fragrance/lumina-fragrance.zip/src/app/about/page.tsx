import Image from "next/image"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Flower2, Sparkles, Heart, Globe } from "lucide-react"

export default function AboutPage() {
  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Our Story</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">About Lumina</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Modern fragrance rituals for everyday moments. We make soft, layerable scents designed to be lived in, not announced.</p>
          </Reveal>

          <Reveal delay={80} className="relative aspect-[16/9] rounded-3xl overflow-hidden boty-shadow mb-16">
            <Image src="https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1600&q=80" alt="Lumina studio" fill className="object-cover" />
          </Reveal>

          <Reveal delay={120} className="lumina-prose max-w-3xl mx-auto mb-16">
            <p>Lumina began in a small studio in San Francisco, with a simple idea: fragrance should be a gentle ritual, not a loud statement. We were tired of perfumes that announced themselves when they entered a room, and we wanted something different, scents that sat close to the skin, that were felt more than noticed, that became part of the texture of a life rather than a performance of it.</p>
            <p>So we started making them. Body mists that wore softly. Hair perfumes that didn't dry the hair. Room sprays that settled onto fabric rather than filling the air. Each formula designed to be layered with the others, so that a person could build a fragrance wardrobe that was unmistakably their own.</p>
            <h2>Our Mission</h2>
            <p>To make fragrance that feels like a second skin. To respect the senses rather than overwhelm them. To build a brand that is calm, trustworthy, and quietly luxurious, never loud, never artificial, never trying too hard.</p>
          </Reveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {[
              { icon: Flower2, title: "Soft Luxury", desc: "Fragrance that feels like a second skin, never loud." },
              { icon: Sparkles, title: "Layerable", desc: "Body mists, hair perfumes, and room sprays designed to be worn together." },
              { icon: Heart, title: "Vegan & Cruelty-Free", desc: "Never tested on animals, never made from them." },
              { icon: Globe, title: "Sustainable", desc: "Refillable bottles, recyclable packaging, minimal waste." },
            ].map((v, i) => (
              <Reveal key={v.title} delay={i * 80}>
                <div className="bg-card rounded-3xl p-6 boty-shadow text-center">
                  <v.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                  <h3 className="font-serif text-lg text-foreground mb-2">{v.title}</h3>
                  <p className="text-sm text-muted-foreground">{v.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="bg-gradient-to-br from-primary to-plum rounded-3xl p-8 lg:p-12 boty-shadow text-ivory text-center">
            <p className="font-serif text-2xl md:text-3xl mb-4">&ldquo;Scent should be a gentle ritual, not a complicated routine.&rdquo;</p>
            <p className="text-sm opacity-80">— The Lumina Team</p>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
