"use client"

import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { products } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { GitCompare, ShoppingBag, X, ArrowRight } from "lucide-react"

export default function ComparePage() {
  const [ids, setIds, hydrated] = useLocalStorage<string[]>("lumina-compare", [])
  const { addItem } = useCart()
  const items = products.filter((p) => ids.includes(p.id))

  const remove = (id: string) => setIds((prev) => prev.filter((x) => x !== id))

  if (!hydrated) {
    return (
      <main className="min-h-screen"><Header /><div className="pt-28 pb-20 max-w-7xl mx-auto px-6 lg:px-8"><div className="lumina-skeleton h-12 w-48 mb-8" /><div className="lumina-skeleton h-96 w-full" /></div><Footer /></main>
    )
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Side By Side</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">Compare Products</h1>
            <p className="text-lg text-muted-foreground">Compare up to 4 fragrances at once</p>
          </div>

          {items.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-24 h-24 rounded-full bg-card flex items-center justify-center mx-auto mb-6 boty-shadow">
                <GitCompare className="w-10 h-10 text-muted-foreground" />
              </div>
              <p className="text-lg text-muted-foreground mb-6">No products to compare yet.</p>
              <Link href="/shop" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow">
                Browse Products <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px]">
                <tbody>
                  <tr>
                    <td className="w-40 p-4 align-top text-sm font-medium text-muted-foreground">Product</td>
                    {items.map((p) => (
                      <td key={p.id} className="p-4 align-top">
                        <div className="relative aspect-square rounded-2xl overflow-hidden bg-muted mb-3">
                          <Image src={p.image} alt={p.name} fill className="object-cover" />
                          <button onClick={() => remove(p.id)} className="absolute top-2 right-2 w-7 h-7 rounded-full bg-background/90 flex items-center justify-center" aria-label="Remove"><X className="w-3.5 h-3.5" /></button>
                        </div>
                        <Link href={`/product/${p.id}`} className="font-serif text-base text-foreground hover:text-primary">{p.name}</Link>
                      </td>
                    ))}
                  </tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Price</td>{items.map((p) => <td key={p.id} className="p-4 font-medium text-foreground">${p.price}</td>)}</tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Category</td>{items.map((p) => <td key={p.id} className="p-4 text-sm capitalize text-foreground">{p.category}</td>)}</tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Tagline</td>{items.map((p) => <td key={p.id} className="p-4 text-sm text-muted-foreground">{p.tagline}</td>)}</tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Top Notes</td>{items.map((p) => <td key={p.id} className="p-4 text-sm text-muted-foreground">{p.notes?.top.join(", ")}</td>)}</tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Heart Notes</td>{items.map((p) => <td key={p.id} className="p-4 text-sm text-muted-foreground">{p.notes?.heart.join(", ")}</td>)}</tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Base Notes</td>{items.map((p) => <td key={p.id} className="p-4 text-sm text-muted-foreground">{p.notes?.base.join(", ")}</td>)}</tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Rating</td>{items.map((p) => <td key={p.id} className="p-4 text-sm text-foreground">{p.rating} ({p.reviewCount})</td>)}</tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Sizes</td>{items.map((p) => <td key={p.id} className="p-4 text-sm text-foreground">{p.sizes?.join(", ")}</td>)}</tr>
                  <tr className="border-t border-border/50"><td className="p-4 text-sm font-medium text-muted-foreground">Action</td>{items.map((p) => <td key={p.id} className="p-4"><button onClick={() => addItem({ id: p.id, name: p.name, description: p.description, price: p.price, image: p.image })} className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm boty-transition hover:bg-primary/90"><ShoppingBag className="w-4 h-4" /> Add</button></td>)}</tr>
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      <Footer />
    </main>
  )
}
