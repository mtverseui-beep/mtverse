"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Gift, ArrowRight, Check } from "lucide-react"
import { useCart } from "@/components/boty/cart-context"
import { toast } from "sonner"

const denominations = [25, 50, 75, 100, 150, 200]

export default function GiftCardsPage() {
  const [amount, setAmount] = useState(50)
  const [custom, setCustom] = useState("")
  const [design, setDesign] = useState(0)
  const [recipient, setRecipient] = useState("")
  const [message, setMessage] = useState("")
  const { addItem } = useCart()

  const designs = [
    { name: "Soft Bloom", gradient: "from-blush via-clay to-plum" },
    { name: "Golden Hour", gradient: "from-gold via-clay to-espresso" },
    { name: "Calm Linen", gradient: "from-champagne via-taupe to-clay" },
  ]

  const finalAmount = custom ? Math.max(10, Math.min(500, parseInt(custom) || 0)) : amount

  const handleAdd = () => {
    if (finalAmount < 10) { toast.error("Minimum gift card amount is $10"); return }
    addItem({
      id: `giftcard-${finalAmount}-${design}`,
      name: `Lumina Gift Card — $${finalAmount}`,
      description: `Digital gift card • ${designs[design].name} design${recipient ? ` • For ${recipient}` : ""}`,
      price: finalAmount,
      image: "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=800&q=80",
    })
    toast.success(`$${finalAmount} gift card added to cart`)
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">The Perfect Gift</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Lumina Gift Cards</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Digital gift cards delivered by email. Let them choose their own ritual.</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start">
            {/* Preview */}
            <Reveal>
              <div className={`relative aspect-[4/3] rounded-3xl overflow-hidden boty-shadow bg-gradient-to-br ${designs[design].gradient} p-8 flex flex-col justify-between`}>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-serif text-2xl text-ivory">Lumina</p>
                    <p className="text-xs tracking-[0.24em] uppercase text-ivory/70 mt-1">Gift Card</p>
                  </div>
                  <Gift className="w-8 h-8 text-ivory/80" />
                </div>
                <div>
                  <p className="font-serif text-5xl text-ivory mb-2">${finalAmount}</p>
                  <p className="text-xs text-ivory/70">{designs[design].name} design</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mt-4">
                {designs.map((d, i) => (
                  <button key={d.name} onClick={() => setDesign(i)} className={`aspect-[4/3] rounded-2xl bg-gradient-to-br ${d.gradient} p-3 text-left boty-transition ${design === i ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : "opacity-70 hover:opacity-100"}`}>
                    <span className="text-[10px] text-ivory/80">{d.name}</span>
                  </button>
                ))}
              </div>
            </Reveal>

            {/* Form */}
            <Reveal delay={100}>
              <div className="space-y-6">
                <div>
                  <label className="text-sm font-medium text-foreground mb-3 block">Choose an amount</label>
                  <div className="grid grid-cols-3 gap-2">
                    {denominations.map((d) => (
                      <button key={d} onClick={() => { setAmount(d); setCustom("") }} className={`px-4 py-3 rounded-full text-sm boty-transition ${amount === d && !custom ? "bg-primary text-primary-foreground" : "bg-card text-foreground boty-shadow hover:scale-[1.02]"}`}>${d}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">Or enter custom amount ($10–$500)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground">$</span>
                    <input type="number" min={10} max={500} value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="50" className="w-full bg-card border border-border rounded-full pl-8 pr-4 py-3 text-sm focus:outline-none focus:border-primary boty-shadow" />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">Recipient email (optional)</label>
                  <input type="email" value={recipient} onChange={(e) => setRecipient(e.target.value)} placeholder="friend@email.com" className="w-full bg-card border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary boty-shadow" />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">Personal message (optional)</label>
                  <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={3} placeholder="Add a note..." className="w-full bg-card border border-border rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-primary boty-shadow resize-none" />
                </div>
                <div className="bg-card rounded-2xl p-4 boty-shadow space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-foreground"><Check className="w-4 h-4 text-primary" /> Delivered by email instantly</div>
                  <div className="flex items-center gap-2 text-foreground"><Check className="w-4 h-4 text-primary" /> No expiration date</div>
                  <div className="flex items-center gap-2 text-foreground"><Check className="w-4 h-4 text-primary" /> Redeemable site-wide</div>
                </div>
                <button onClick={handleAdd} className="w-full bg-primary text-primary-foreground py-4 rounded-full font-medium hover:bg-primary/90 boty-transition boty-shadow inline-flex items-center justify-center gap-2">
                  Add ${finalAmount} Gift Card to Cart <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
