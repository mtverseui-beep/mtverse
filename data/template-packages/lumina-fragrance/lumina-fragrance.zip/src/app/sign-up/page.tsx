"use client"

import { useState } from "react"
import Link from "next/link"
import { AuthShell } from "@/components/shared/auth-shell"
import { Mail, Lock, User, Eye, EyeOff, ArrowRight, Check } from "lucide-react"
import { toast } from "sonner"

export default function SignUpPage() {
  const [form, setForm] = useState({ firstName: "", email: "", password: "", agree: false })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)

  const strength = form.password.length >= 8 ? (form.password.length >= 12 ? 3 : 2) : form.password.length > 0 ? 1 : 0
  const strengthLabels = ["", "Weak", "Good", "Strong"]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.firstName || !form.email || !form.password) { toast.error("Please fill in all fields"); return }
    if (form.password.length < 8) { toast.error("Password must be at least 8 characters"); return }
    if (!form.agree) { toast.error("Please accept the terms"); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); toast.success("Account created!"); window.location.href = "/verify-email" }, 800)
  }

  return (
    <AuthShell title="Create Account" subtitle="Join Lumina and start earning rewards">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Name</label>
          <div className="relative"><User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} placeholder="Your name" className="w-full bg-background border border-border rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition" /></div>
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Email</label>
          <div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="your@email.com" className="w-full bg-background border border-border rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition" /></div>
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Password</label>
          <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type={showPw ? "text" : "password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="At least 8 characters" className="w-full bg-background border border-border rounded-full pl-11 pr-11 py-3 text-sm focus:outline-none focus:border-primary boty-transition" /><button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">{showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div>
          {strength > 0 && <div className="mt-2 flex items-center gap-2"><div className="flex-1 flex gap-1">{[1, 2, 3].map((n) => <div key={n} className={`h-1 flex-1 rounded-full ${n <= strength ? (strength === 1 ? "bg-destructive" : strength === 2 ? "bg-gold" : "bg-primary") : "bg-muted"}`} />)}</div><span className="text-xs text-muted-foreground">{strengthLabels[strength]}</span></div>}
        </div>
        <label className="flex items-start gap-2 cursor-pointer"><input type="checkbox" checked={form.agree} onChange={(e) => setForm({ ...form, agree: e.target.checked })} className="w-4 h-4 rounded accent-primary mt-0.5" /><span className="text-sm text-muted-foreground">I agree to the <Link href="/terms" className="text-primary hover:underline">Terms</Link> and <Link href="/privacy" className="text-primary hover:underline">Privacy Policy</Link></span></label>
        <button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground py-3 rounded-full font-medium boty-transition hover:bg-primary/90 disabled:opacity-60 boty-shadow inline-flex items-center justify-center gap-2">{loading ? <><span className="lumina-spinner" /> Creating...</> : <>Create Account <ArrowRight className="w-4 h-4" /></>}</button>
      </form>
      <div className="my-6 flex items-center gap-3"><div className="flex-1 h-px bg-border" /><span className="text-xs text-muted-foreground">OR</span><div className="flex-1 h-px bg-border" /></div>
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => toast.info("Google sign-up is a demo")} className="border border-border rounded-full py-2.5 text-sm text-foreground hover:bg-muted boty-transition">Google</button>
        <button onClick={() => toast.info("Apple sign-up is a demo")} className="border border-border rounded-full py-2.5 text-sm text-foreground hover:bg-muted boty-transition">Apple</button>
      </div>
      <p className="text-center text-sm text-muted-foreground mt-6">Already have an account? <Link href="/sign-in" className="text-primary hover:underline">Sign in</Link></p>
      <div className="mt-6 bg-background rounded-2xl p-4 space-y-1.5">
        <p className="text-xs font-medium text-foreground mb-2">Member benefits:</p>
        <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Check className="w-3 h-3 text-primary" /> Earn 1 point per $1 spent</p>
        <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Check className="w-3 h-3 text-primary" /> Free shipping on orders over $50</p>
        <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Check className="w-3 h-3 text-primary" /> Early access to new launches</p>
      </div>
    </AuthShell>
  )
}
