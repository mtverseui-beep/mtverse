import { PolicyPage } from "@/components/shared/policy-page"
export default function AccessibilityPage() { return <PolicyPage slug="accessibility" /> }
