import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { ArrowRight } from "lucide-react"

export default function ScentGuidePage() {
  const families = [
    { name: "Floral", desc: "Built around flowers — rose, jasmine, peony, iris. Fresh and dewy or deep and velvety.", image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80", products: ["rose-milk-body-mist", "cloud-veil-body-mist"] },
    { name: "Amber", desc: "Warm, resinous, and enveloping. Built around amber, benzoin, and soft resins.", image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=800&q=80", products: ["evening-velvet-body-mist", "moonlit-amber-gift-set"] },
    { name: "Musk", desc: "Clean, soft, and lingering. The foundation of every second-skin fragrance.", image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80", products: ["cloud-veil-body-mist", "soft-musk-travel-mini"] },
    { name: "Citrus", desc: "Bright, crisp, and refreshing. Built around lemon, bergamot, and grapefruit.", image: "https://images.unsplash.com/photo-1600573472556-e636c2acda88?auto=format&fit=crop&w=800&q=80", products: ["citrus-linen-room-spray"] },
    { name: "Vanilla", desc: "Warm, sweet, and second-skin. Built around bourbon vanilla and tonka.", image: "https://images.unsplash.com/photo-1601990102012-7c88cc2aa9a9?auto=format&fit=crop&w=800&q=80", products: ["vanilla-hour-fragrance-mist"] },
  ]

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Find Your Match</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Scent Guide</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">A practical guide to fragrance families, layering, and finding the scent that feels like you.</p>
          </Reveal>

          <div className="space-y-6 mb-16">
            {families.map((f, i) => (
              <Reveal key={f.name} delay={i * 60}>
                <div className={`grid md:grid-cols-2 gap-6 items-center bg-card rounded-3xl p-6 boty-shadow ${i % 2 === 1 ? "md:grid-flow-dense" : ""}`}>
                  <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-muted md:col-span-1">
                    <Image src={f.image} alt={f.name} fill className="object-cover" />
                  </div>
                  <div className={i % 2 === 1 ? "md:col-start-1 md:row-start-1" : ""}>
                    <h2 className="font-serif text-2xl text-foreground mb-3">{f.name}</h2>
                    <p className="text-muted-foreground mb-4 leading-relaxed">{f.desc}</p>
                    <Link href={`/shop?mood=${f.name.toLowerCase()}`} className="inline-flex items-center gap-1 text-sm text-primary hover:gap-2 transition-all">Shop {f.name} <ArrowRight className="w-3.5 h-3.5" /></Link>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="bg-card rounded-3xl p-8 boty-shadow mb-12">
            <h2 className="font-serif text-2xl text-foreground mb-4">How to Choose a Scent</h2>
            <ol className="space-y-4 text-muted-foreground">
              <li className="flex gap-3"><span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm flex-shrink-0">1</span><div><p className="text-foreground font-medium">Start with a discovery set</p><p className="text-sm">Live with each scent for a day before committing. Our Golden Fig Discovery Set is a perfect beginning.</p></div></li>
              <li className="flex gap-3"><span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm flex-shrink-0">2</span><div><p className="text-foreground font-medium">Pay attention to the drydown</p><p className="text-sm">The first impression is the loudest but most fleeting. The drydown — the heart and base notes that emerge after 30 minutes — is what you'll live with.</p></div></li>
              <li className="flex gap-3"><span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm flex-shrink-0">3</span><div><p className="text-foreground font-medium">Notice what you return to</p><p className="text-sm">After a week of testing, which scent did you reach for again? That pull is more reliable than your first impression.</p></div></li>
              <li className="flex gap-3"><span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm flex-shrink-0">4</span><div><p className="text-foreground font-medium">Don't be afraid to layer</p><p className="text-sm">A signature scent doesn't have to be a single fragrance. Compose yours from two or three complementary formats.</p></div></li>
            </ol>
          </Reveal>

          <Reveal className="text-center">
            <Link href="/fragrance-quiz" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow">Take the Fragrance Quiz <ArrowRight className="w-4 h-4" /></Link>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
