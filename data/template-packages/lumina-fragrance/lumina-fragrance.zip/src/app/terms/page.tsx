import { PolicyPage } from "@/components/shared/policy-page"
export default function TermsPage() { return <PolicyPage slug="terms" /> }
