import { PolicyPage } from "@/components/shared/policy-page"
export default function ReturnsPolicyPage() { return <PolicyPage slug="returns-policy" /> }
