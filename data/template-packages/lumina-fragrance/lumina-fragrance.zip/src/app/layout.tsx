import React from "react"
import type { Metadata, Viewport } from 'next'
import { DM_Sans, Playfair_Display } from 'next/font/google'
import { CartProvider } from '@/components/boty/cart-context'
import { GoToTop } from '@/components/shared/go-to-top'
import './globals.css'

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: '--font-dm-sans',
  weight: ['300', '400', '500', '600'],
  display: 'swap',
})

const playfairDisplay = Playfair_Display({
  subsets: ["latin"],
  variable: '--font-playfair',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Lumina — Premium Body Mists, Hair Perfumes & Discovery Sets',
  description: 'Shop premium body mists, hair perfumes, room sprays, discovery sets, and scent layering gifts from Lumina. Modern fragrance rituals for everyday moments.',
  keywords: ['Lumina', 'premium fragrance', 'body mist', 'hair perfume', 'room spray', 'discovery set', 'gift set', 'scent layering', 'fragrance gift', 'luxury body mist'],
  authors: [{ name: 'Lumina' }],
  creator: 'Lumina',
  publisher: 'Lumina',
  applicationName: 'Lumina',
  icons: {
    icon: [
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/icon.svg',
  },
  manifest: '/manifest.webmanifest',
  openGraph: {
    title: 'Lumina — Premium Body Mists, Hair Perfumes & Discovery Sets',
    description: 'Shop premium body mists, hair perfumes, room sprays, discovery sets, and scent layering gifts from Lumina.',
    url: 'https://luminamist.co',
    siteName: 'Lumina',
    locale: 'en_US',
    type: 'website',
    images: [
      {
        url: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1200&q=80',
        width: 1200,
        height: 630,
        alt: 'Lumina',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Lumina — Premium Body Mists, Hair Perfumes & Discovery Sets',
    description: 'Shop premium body mists, hair perfumes, room sprays, discovery sets, and scent layering gifts from Lumina.',
    images: ['https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1200&q=80'],
  },
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical: 'https://luminamist.co',
  },
}

export const viewport: Viewport = {
  themeColor: '#F7F1E8',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${dmSans.variable} ${playfairDisplay.variable} font-sans antialiased bg-background text-foreground`}>
        <CartProvider>
          {children}
          <GoToTop />
        </CartProvider>
      </body>
    </html>
  )
}
