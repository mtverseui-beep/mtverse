"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useCart } from "@/components/boty/cart-context"
import { Check, ChevronLeft, CreditCard, Truck, Shield, Lock, ArrowRight } from "lucide-react"
import { toast } from "sonner"

export default function CheckoutReviewPage() {
  const { items, subtotal, clearCart } = useCart()
  const [loading, setLoading] = useState(false)
  const [placed, setPlaced] = useState(false)

  const shipping = subtotal >= 50 ? 0 : 5
  const tax = Math.round(subtotal * 0.08 * 100) / 100
  const total = subtotal + shipping + tax

  const handlePlaceOrder = () => {
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      setPlaced(true)
      clearCart()
      window.location.href = "/order/success"
    }, 1200)
  }

  if (items.length === 0 && !loading) {
    return (
      <main className="min-h-screen lumina-page">
        <Header />
        <div className="pt-28 pb-20 max-w-2xl mx-auto px-6 text-center">
          <h1 className="font-serif text-3xl text-foreground mb-4">Your cart is empty</h1>
          <p className="text-muted-foreground mb-6">Add items to your cart before reviewing your order.</p>
          <Link href="/shop" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Shop Products</Link>
        </div>
        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <Link href="/checkout/payment" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"><ChevronLeft className="w-4 h-4" /> Back to Payment</Link>

          <div className="flex items-center justify-center mb-12">
            {[
              { id: "shipping", label: "Shipping", icon: Truck },
              { id: "payment", label: "Payment", icon: CreditCard },
              { id: "review", label: "Review", icon: Shield },
            ].map((s, i) => (
              <div key={s.id} className="flex items-center">
                <div className={`flex items-center gap-2 text-primary`}>
                  <div className="w-9 h-9 rounded-full flex items-center justify-center bg-primary text-primary-foreground">
                    {i < 2 ? <Check className="w-4 h-4" /> : <s.icon className="w-4 h-4" />}
                  </div>
                  <span className="text-sm font-medium hidden sm:inline">{s.label}</span>
                </div>
                {i < 2 && <div className="w-12 sm:w-24 h-0.5 mx-2 bg-primary" />}
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-card rounded-3xl p-6 boty-shadow">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-serif text-2xl text-foreground">Review Your Order</h2>
                  <Shield className="w-5 h-5 text-primary" />
                </div>
                <div className="space-y-3">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-4 p-3 bg-background rounded-2xl">
                      <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                        <Image src={item.image} alt={item.name} fill className="object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-serif text-sm text-foreground">{item.name}</p>
                        <p className="text-xs text-muted-foreground">{item.description}</p>
                        {item.size && <p className="text-xs text-muted-foreground">Size: {item.size}</p>}
                        <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-medium text-foreground">${item.price * item.quantity}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-card rounded-3xl p-6 boty-shadow">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-foreground">Shipping To</h3>
                    <Link href="/checkout/shipping" className="text-xs text-primary hover:underline">Edit</Link>
                  </div>
                  <p className="text-sm text-muted-foreground">Aurelia Brennan<br />248 Marin Avenue, Apt 4B<br />San Francisco, CA 94117<br />United States</p>
                </div>
                <div className="bg-card rounded-3xl p-6 boty-shadow">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-foreground">Payment</h3>
                    <Link href="/checkout/payment" className="text-xs text-primary hover:underline">Edit</Link>
                  </div>
                  <p className="text-sm text-muted-foreground">Visa ending in 4242<br />Expires 08/27</p>
                </div>
              </div>

              <button onClick={handlePlaceOrder} disabled={loading} className="w-full bg-primary text-primary-foreground py-4 rounded-full font-medium hover:bg-primary/90 boty-transition boty-shadow inline-flex items-center justify-center gap-2 disabled:opacity-60">
                {loading ? <><span className="lumina-spinner" /> Placing Order...</> : <><Lock className="w-4 h-4" /> Place Order — ${total}</>}
              </button>
              <p className="text-center text-xs text-muted-foreground">By placing your order you agree to our <Link href="/terms" className="underline">Terms</Link> and <Link href="/privacy" className="underline">Privacy Policy</Link>.</p>
            </div>

            <div>
              <div className="bg-card rounded-3xl p-6 boty-shadow sticky top-24">
                <h3 className="font-serif text-xl text-foreground mb-4">Summary</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>${subtotal}</span></div>
                  <div className="flex justify-between text-muted-foreground"><span>Shipping</span><span>{shipping === 0 ? "Free" : `$${shipping}`}</span></div>
                  <div className="flex justify-between text-muted-foreground"><span>Tax</span><span>${tax}</span></div>
                  <div className="flex justify-between font-medium text-foreground text-base pt-2 border-t border-border/50"><span>Total</span><span>${total}</span></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
