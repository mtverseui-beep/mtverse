"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useCart } from "@/components/boty/cart-context"
import { Check, ChevronLeft, CreditCard, Truck, Shield, Lock, ArrowRight } from "lucide-react"
import { toast } from "sonner"

const steps = [
  { id: "shipping", label: "Shipping", icon: Truck },
  { id: "payment", label: "Payment", icon: CreditCard },
  { id: "review", label: "Review", icon: Shield },
]

export default function CheckoutShippingPage() {
  const { items, subtotal } = useCart()
  const [form, setForm] = useState({ fullName: "", email: "", address: "", apt: "", city: "", state: "", zip: "", country: "United States", phone: "", method: "standard" })
  const [loading, setLoading] = useState(false)

  const shipping = form.method === "express" ? 15 : subtotal >= 50 ? 0 : 5
  const tax = Math.round(subtotal * 0.08 * 100) / 100
  const total = subtotal + shipping + tax

  const handleContinue = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.fullName || !form.email || !form.address || !form.city || !form.state || !form.zip) {
      toast.error("Please fill in all required fields")
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      window.location.href = "/checkout/payment"
    }, 800)
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <Link href="/cart" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"><ChevronLeft className="w-4 h-4" /> Back to Cart</Link>

          {/* Stepper */}
          <div className="flex items-center justify-center mb-12">
            {steps.map((s, i) => (
              <div key={s.id} className="flex items-center">
                <div className={`flex items-center gap-2 ${i === 0 ? "text-primary" : "text-muted-foreground"}`}>
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center ${i === 0 ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                    {i === 0 ? <s.icon className="w-4 h-4" /> : <s.icon className="w-4 h-4" />}
                  </div>
                  <span className="text-sm font-medium hidden sm:inline">{s.label}</span>
                </div>
                {i < steps.length - 1 && <div className={`w-12 sm:w-24 h-0.5 mx-2 ${i < 0 ? "bg-primary" : "bg-muted"}`} />}
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Form */}
            <form onSubmit={handleContinue} className="lg:col-span-2 space-y-6">
              <div className="bg-card rounded-3xl p-6 boty-shadow">
                <h2 className="font-serif text-2xl text-foreground mb-4">Contact</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <input required type="text" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} placeholder="Full name *" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
                  <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="Email *" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
                  <input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Phone (optional)" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
                </div>
              </div>

              <div className="bg-card rounded-3xl p-6 boty-shadow">
                <h2 className="font-serif text-2xl text-foreground mb-4">Shipping Address</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <input required type="text" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Street address *" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
                  <input type="text" value={form.apt} onChange={(e) => setForm({ ...form, apt: e.target.value })} placeholder="Apt, suite (optional)" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
                  <input required type="text" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} placeholder="City *" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
                  <div className="grid grid-cols-2 gap-4">
                    <input required type="text" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} placeholder="State *" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
                    <input required type="text" value={form.zip} onChange={(e) => setForm({ ...form, zip: e.target.value })} placeholder="ZIP *" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
                  </div>
                  <select value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2">
                    <option>United States</option><option>Canada</option><option>United Kingdom</option><option>Australia</option><option>Germany</option><option>France</option>
                  </select>
                </div>
              </div>

              <div className="bg-card rounded-3xl p-6 boty-shadow">
                <h2 className="font-serif text-2xl text-foreground mb-4">Delivery Method</h2>
                <div className="space-y-3">
                  {[{ id: "standard", name: "Standard Shipping", desc: "3–5 business days", price: subtotal >= 50 ? "Free" : "$5" }, { id: "express", name: "Express Shipping", desc: "1–2 business days", price: "$15" }].map((m) => (
                    <label key={m.id} className={`flex items-center gap-3 p-4 rounded-2xl border-2 boty-transition cursor-pointer ${form.method === m.id ? "border-primary bg-primary/5" : "border-border bg-background hover:border-primary/50"}`}>
                      <input type="radio" name="method" value={m.id} checked={form.method === m.id} onChange={(e) => setForm({ ...form, method: e.target.value })} className="w-5 h-5 accent-primary" />
                      <Truck className="w-5 h-5 text-primary" />
                      <div className="flex-1"><p className="font-medium text-foreground text-sm">{m.name}</p><p className="text-xs text-muted-foreground">{m.desc}</p></div>
                      <span className="font-medium text-foreground">{m.price}</span>
                    </label>
                  ))}
                </div>
              </div>

              <button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground py-4 rounded-full font-medium hover:bg-primary/90 boty-transition boty-shadow inline-flex items-center justify-center gap-2 disabled:opacity-60">
                {loading ? <><span className="lumina-spinner" /> Saving...</> : <>Continue to Payment <ArrowRight className="w-4 h-4" /></>}
              </button>
            </form>

            {/* Summary */}
            <div className="space-y-4">
              <div className="bg-card rounded-3xl p-6 boty-shadow sticky top-24">
                <h3 className="font-serif text-xl text-foreground mb-4">Order Summary</h3>
                <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                        <Image src={item.image} alt={item.name} fill className="object-cover" />
                        <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-foreground text-background text-[10px] flex items-center justify-center">{item.quantity}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground line-clamp-1">{item.name}</p>
                        <p className="text-xs text-muted-foreground">${item.price}</p>
                      </div>
                    </div>
                  ))}
                  {items.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">Cart is empty</p>}
                </div>
                <div className="space-y-2 text-sm border-t border-border/50 pt-4">
                  <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>${subtotal}</span></div>
                  <div className="flex justify-between text-muted-foreground"><span>Shipping</span><span>{shipping === 0 ? "Free" : `$${shipping}`}</span></div>
                  <div className="flex justify-between text-muted-foreground"><span>Tax</span><span>${tax}</span></div>
                  <div className="flex justify-between font-medium text-foreground text-base pt-2 border-t border-border/50"><span>Total</span><span>${total}</span></div>
                </div>
                <div className="flex items-center gap-2 mt-4 text-xs text-muted-foreground"><Lock className="w-3 h-3" /> Secure checkout — 256-bit SSL</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
