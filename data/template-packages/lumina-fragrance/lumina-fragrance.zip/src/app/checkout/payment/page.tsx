"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useCart } from "@/components/boty/cart-context"
import { Check, ChevronLeft, CreditCard, Truck, Shield, Lock, ArrowRight } from "lucide-react"
import { toast } from "sonner"

export default function CheckoutPaymentPage() {
  const { items, subtotal } = useCart()
  const [method, setMethod] = useState("card")
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ number: "", name: "", expiry: "", cvc: "" })

  const shipping = subtotal >= 50 ? 0 : 5
  const tax = Math.round(subtotal * 0.08 * 100) / 100
  const total = subtotal + shipping + tax

  const handleContinue = (e: React.FormEvent) => {
    e.preventDefault()
    if (method === "card" && (!form.number || !form.name || !form.expiry || !form.cvc)) { toast.error("Please fill in card details"); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); window.location.href = "/checkout/review" }, 800)
  }

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <Link href="/checkout/shipping" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"><ChevronLeft className="w-4 h-4" /> Back to Shipping</Link>

          <div className="flex items-center justify-center mb-12">
            {[
              { id: "shipping", label: "Shipping", icon: Truck },
              { id: "payment", label: "Payment", icon: CreditCard },
              { id: "review", label: "Review", icon: Shield },
            ].map((s, i) => (
              <div key={s.id} className="flex items-center">
                <div className={`flex items-center gap-2 ${i === 1 ? "text-primary" : i === 0 ? "text-primary" : "text-muted-foreground"}`}>
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center ${i <= 1 ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                    {i < 1 ? <Check className="w-4 h-4" /> : <s.icon className="w-4 h-4" />}
                  </div>
                  <span className="text-sm font-medium hidden sm:inline">{s.label}</span>
                </div>
                {i < 2 && <div className={`w-12 sm:w-24 h-0.5 mx-2 ${i < 1 ? "bg-primary" : "bg-muted"}`} />}
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <form onSubmit={handleContinue} className="lg:col-span-2 space-y-6">
              <div className="bg-card rounded-3xl p-6 boty-shadow">
                <h2 className="font-serif text-2xl text-foreground mb-4">Payment Method</h2>
                <div className="space-y-3 mb-6">
                  {[{ id: "card", name: "Credit / Debit Card", desc: "Visa, Mastercard, Amex" }, { id: "paypal", name: "PayPal", desc: "Pay with your PayPal account" }, { id: "apple", name: "Apple Pay", desc: "Fast, secure checkout" }].map((m) => (
                    <label key={m.id} className={`flex items-center gap-3 p-4 rounded-2xl border-2 boty-transition cursor-pointer ${method === m.id ? "border-primary bg-primary/5" : "border-border bg-background hover:border-primary/50"}`}>
                      <input type="radio" name="method" value={m.id} checked={method === m.id} onChange={(e) => setMethod(e.target.value)} className="w-5 h-5 accent-primary" />
                      <CreditCard className="w-5 h-5 text-primary" />
                      <div className="flex-1"><p className="font-medium text-foreground text-sm">{m.name}</p><p className="text-xs text-muted-foreground">{m.desc}</p></div>
                    </label>
                  ))}
                </div>

                {method === "card" && (
                  <div className="grid sm:grid-cols-2 gap-4 animate-[lumina-fade-in_0.4s_ease]">
                    <input required type="text" value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} placeholder="Card number" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
                    <input required type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Name on card" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary sm:col-span-2" />
                    <input required type="text" value={form.expiry} onChange={(e) => setForm({ ...form, expiry: e.target.value })} placeholder="MM/YY" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
                    <input required type="text" value={form.cvc} onChange={(e) => setForm({ ...form, cvc: e.target.value })} placeholder="CVC" className="bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary" />
                  </div>
                )}
                {method !== "card" && (
                  <div className="bg-background rounded-2xl p-6 text-center text-sm text-muted-foreground animate-[lumina-fade-in_0.4s_ease]">
                    You will be redirected to {method === "paypal" ? "PayPal" : "Apple Pay"} to complete your purchase.
                  </div>
                )}
              </div>

              <div className="bg-card rounded-3xl p-6 boty-shadow">
                <h2 className="font-serif text-2xl text-foreground mb-4">Billing Address</h2>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" defaultChecked className="w-5 h-5 rounded accent-primary" />
                  <span className="text-sm text-foreground">Same as shipping address</span>
                </label>
              </div>

              <button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground py-4 rounded-full font-medium hover:bg-primary/90 boty-transition boty-shadow inline-flex items-center justify-center gap-2 disabled:opacity-60">
                {loading ? <><span className="lumina-spinner" /> Processing...</> : <>Review Order <ArrowRight className="w-4 h-4" /></>}
              </button>
            </form>

            <div className="space-y-4">
              <div className="bg-card rounded-3xl p-6 boty-shadow sticky top-24">
                <h3 className="font-serif text-xl text-foreground mb-4">Order Summary</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-muted-foreground"><span>Subtotal ({items.length} items)</span><span>${subtotal}</span></div>
                  <div className="flex justify-between text-muted-foreground"><span>Shipping</span><span>{shipping === 0 ? "Free" : `$${shipping}`}</span></div>
                  <div className="flex justify-between text-muted-foreground"><span>Tax</span><span>${tax}</span></div>
                  <div className="flex justify-between font-medium text-foreground text-base pt-2 border-t border-border/50"><span>Total</span><span>${total}</span></div>
                </div>
                <div className="flex items-center gap-2 mt-4 text-xs text-muted-foreground"><Lock className="w-3 h-3" /> Your payment is secure</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
