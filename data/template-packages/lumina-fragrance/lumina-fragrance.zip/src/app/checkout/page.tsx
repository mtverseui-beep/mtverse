"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { useCart } from "@/components/boty/cart-context"
import { Minus, Plus, Trash2, ArrowRight, Check } from "lucide-react"

export default function CheckoutPage() {
  const { items, updateQuantity, removeItem, subtotal, clearCart } = useCart()
  const [placed, setPlaced] = useState(false)

  const shipping = subtotal >= 50 ? 0 : 5
  const tax = Math.round(subtotal * 0.08 * 100) / 100
  const total = subtotal + shipping + tax

  if (placed) {
    return (
      <main className="min-h-screen">
        <Header />
        <div className="pt-28 pb-20">
          <div className="max-w-2xl mx-auto px-6 lg:px-8 text-center">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-primary" />
            </div>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4">
              Order Confirmed
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Thank you for your order. A confirmation email is on its way to your inbox.
            </p>
            <div className="bg-card rounded-3xl p-8 boty-shadow mb-8 text-left">
              <p className="text-sm text-muted-foreground mb-2">Order Number</p>
              <p className="font-serif text-2xl text-foreground mb-6">
                AM-{Math.floor(100000 + Math.random() * 900000)}
              </p>
              <p className="text-sm text-muted-foreground mb-2">Total</p>
              <p className="font-medium text-foreground text-lg">${total}</p>
            </div>
            <Link
              href="/shop"
              className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-sm tracking-wide boty-transition hover:bg-primary/90 boty-shadow"
            >
              Continue Shopping
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
        <Footer />
      </main>
    )
  }

  return (
    <main className="min-h-screen">
      <Header />

      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"
          >
            ← Continue Shopping
          </Link>

          <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-8">Checkout</h1>

          {items.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-lg text-muted-foreground mb-6">Your cart is empty.</p>
              <Link
                href="/shop"
                className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full text-sm tracking-wide boty-transition hover:bg-primary/90"
              >
                Shop Products
              </Link>
            </div>
          ) : (
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Order Summary */}
              <div>
                <h2 className="font-serif text-2xl text-foreground mb-6">Order Summary</h2>
                <div className="space-y-6">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-4">
                      <div className="relative w-24 h-24 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
                        <Image
                          src={item.image}
                          alt={item.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-serif text-base text-foreground mb-1 font-semibold">{item.name}</h3>
                        <p className="text-muted-foreground mb-3 text-sm">{item.description}</p>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center border border-border rounded-full">
                            <button
                              type="button"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="p-1.5 hover:bg-muted boty-transition rounded-l-full"
                              aria-label="Decrease quantity"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-3 text-sm font-medium">{item.quantity}</span>
                            <button
                              type="button"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="p-1.5 hover:bg-muted boty-transition rounded-r-full"
                              aria-label="Increase quantity"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeItem(item.id)}
                            className="p-1.5 text-muted-foreground hover:text-destructive boty-transition"
                            aria-label="Remove item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <p className="font-medium text-foreground">${item.price * item.quantity}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Checkout Form & Totals */}
              <div>
                <h2 className="font-serif text-2xl text-foreground mb-6">Payment Details</h2>
                <div className="bg-card rounded-3xl p-8 boty-shadow space-y-4 mb-6">
                  <p className="text-sm text-muted-foreground">
                    This is a demo checkout. No real payment will be processed. Click place order to see the confirmation.
                  </p>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">Email</label>
                    <input
                      type="email"
                      placeholder="your@email.com"
                      className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-2 block">Card Number</label>
                    <input
                      type="text"
                      placeholder="4242 4242 4242 4242"
                      className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">Expiry</label>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">CVC</label>
                      <input
                        type="text"
                        placeholder="123"
                        className="w-full bg-background border border-border rounded-full px-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-3xl p-8 boty-shadow space-y-2 text-sm mb-6">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Subtotal</span>
                    <span>${subtotal}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Shipping</span>
                    <span>{shipping === 0 ? 'Free' : `$${shipping}`}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Tax</span>
                    <span>${tax}</span>
                  </div>
                  <div className="flex justify-between text-base font-medium text-foreground pt-2 border-t border-border/50">
                    <span>Total</span>
                    <span>${total}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setPlaced(true)
                    clearCart()
                    window.scrollTo(0, 0)
                  }}
                  className="w-full bg-primary text-primary-foreground py-4 rounded-full font-medium hover:bg-primary/90 boty-transition boty-shadow inline-flex items-center justify-center gap-2"
                >
                  Place Order
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </main>
  )
}
