import { PolicyPage } from "@/components/shared/policy-page"
export default function ShippingPolicyPage() { return <PolicyPage slug="shipping-policy" /> }
