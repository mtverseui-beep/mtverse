import { PolicyPage } from "@/components/shared/policy-page"
export default function CookiesPage() { return <PolicyPage slug="cookies" /> }
