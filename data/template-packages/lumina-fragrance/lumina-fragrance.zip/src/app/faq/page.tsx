"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { faqs, faqCategories } from "@/data/content"
import { Search, ArrowRight } from "lucide-react"

export default function FaqPage() {
  const [category, setCategory] = useState("All")
  const [query, setQuery] = useState("")

  const filtered = faqs.filter((f) => (category === "All" || f.category === category) && (f.question.toLowerCase().includes(query.toLowerCase()) || f.answer.toLowerCase().includes(query.toLowerCase())))

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Got Questions?</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">FAQ</h1>
            <div className="max-w-xl mx-auto relative mt-6">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search questions..." className="w-full bg-card border border-border rounded-full pl-12 pr-4 py-4 text-sm focus:outline-none focus:border-primary boty-shadow boty-transition" />
            </div>
          </Reveal>

          <div className="flex flex-wrap justify-center gap-2 mb-10">
            <button onClick={() => setCategory("All")} className={`px-4 py-2 rounded-full text-sm boty-transition ${category === "All" ? "bg-primary text-primary-foreground" : "bg-card text-foreground boty-shadow"}`}>All</button>
            {faqCategories.map((c) => <button key={c} onClick={() => setCategory(c)} className={`px-4 py-2 rounded-full text-sm boty-transition ${category === c ? "bg-primary text-primary-foreground" : "bg-card text-foreground boty-shadow"}`}>{c}</button>)}
          </div>

          <div className="space-y-3">
            {filtered.map((f) => (
              <Reveal key={f.id}>
                <details className="bg-card rounded-3xl p-5 boty-shadow group">
                  <summary className="font-medium text-foreground cursor-pointer flex items-center justify-between gap-4">
                    <span>{f.question}</span>
                    <ArrowRight className="w-4 h-4 text-muted-foreground group-open:rotate-90 transition-transform flex-shrink-0" />
                  </summary>
                  <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{f.answer}</p>
                  <p className="text-xs text-primary mt-2">{f.category}</p>
                </details>
              </Reveal>
            ))}
          </div>

          {filtered.length === 0 && (
            <Reveal className="text-center py-12">
              <p className="text-muted-foreground mb-4">No questions match your search.</p>
              <Link href="/contact" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Contact Support <ArrowRight className="w-4 h-4" /></Link>
            </Reveal>
          )}

          <Reveal delay={120} className="bg-card rounded-3xl p-8 boty-shadow text-center mt-12">
            <p className="font-serif text-2xl text-foreground mb-2">Still have a question?</p>
            <p className="text-sm text-muted-foreground mb-4">Our team is here to help Monday through Friday, 9am to 6pm PT.</p>
            <Link href="/contact" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Get in Touch <ArrowRight className="w-4 h-4" /></Link>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
