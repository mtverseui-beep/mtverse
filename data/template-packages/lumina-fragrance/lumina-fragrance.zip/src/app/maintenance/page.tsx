import Link from "next/link"
import { Wrench, Mail } from "lucide-react"

export default function MaintenancePage() {
  return (
    <main className="min-h-screen lumina-page flex items-center justify-center px-6">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 rounded-full bg-card flex items-center justify-center mx-auto mb-6 boty-shadow">
          <Wrench className="w-10 h-10 text-primary" />
        </div>
        <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Under Maintenance</span>
        <h1 className="font-serif text-4xl text-foreground mb-4">We'll be right back</h1>
        <p className="text-lg text-muted-foreground mb-8">Lumina is getting a little refresh. We'll be back online shortly. Thank you for your patience.</p>
        <a href="mailto:hello@luminamist.co" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow"><Mail className="w-4 h-4" /> Contact Us</a>
      </div>
    </main>
  )
}
