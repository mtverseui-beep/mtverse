"use client"

import { useState } from "react"
import Link from "next/link"
import { AuthShell } from "@/components/shared/auth-shell"
import { Lock, Eye, EyeOff, ArrowRight, Check } from "lucide-react"
import { toast } from "sonner"

export default function ResetPasswordPage() {
  const [form, setForm] = useState({ password: "", confirm: "" })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (form.password.length < 8) { toast.error("Password must be at least 8 characters"); return }
    if (form.password !== form.confirm) { toast.error("Passwords don't match"); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); toast.success("Password reset!"); window.location.href = "/sign-in" }, 800)
  }

  return (
    <AuthShell title="Reset Password" subtitle="Enter your new password">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">New Password</label>
          <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type={showPw ? "text" : "password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="At least 8 characters" className="w-full bg-background border border-border rounded-full pl-11 pr-11 py-3 text-sm focus:outline-none focus:border-primary boty-transition" /><button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">{showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div>
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-2 block">Confirm Password</label>
          <div className="relative"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type={showPw ? "text" : "password"} value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} placeholder="Re-enter password" className="w-full bg-background border border-border rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition" /></div>
        </div>
        <div className="bg-background rounded-2xl p-4 space-y-1.5">
          <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Check className={`w-3 h-3 ${form.password.length >= 8 ? "text-primary" : "text-muted-foreground"}`} /> At least 8 characters</p>
          <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Check className={`w-3 h-3 ${/[A-Z]/.test(form.password) ? "text-primary" : "text-muted-foreground"}`} /> One uppercase letter</p>
          <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Check className={`w-3 h-3 ${/[0-9]/.test(form.password) ? "text-primary" : "text-muted-foreground"}`} /> One number</p>
        </div>
        <button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground py-3 rounded-full font-medium boty-transition hover:bg-primary/90 disabled:opacity-60 boty-shadow inline-flex items-center justify-center gap-2">{loading ? <><span className="lumina-spinner" /> Resetting...</> : <>Reset Password <ArrowRight className="w-4 h-4" /></>}</button>
      </form>
      <p className="text-center text-sm text-muted-foreground mt-6"><Link href="/sign-in" className="text-primary hover:underline">← Back to sign in</Link></p>
    </AuthShell>
  )
}
