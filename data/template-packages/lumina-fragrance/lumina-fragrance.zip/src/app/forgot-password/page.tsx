"use client"

import { useState } from "react"
import Link from "next/link"
import { AuthShell } from "@/components/shared/auth-shell"
import { Mail, ArrowRight } from "lucide-react"
import { toast } from "sonner"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) { toast.error("Please enter your email"); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); setSent(true); toast.success("Reset link sent") }, 800)
  }

  return (
    <AuthShell title="Forgot Password" subtitle="We'll email you a reset link">
      {sent ? (
        <div className="text-center py-4">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4"><Mail className="w-8 h-8 text-primary" /></div>
          <p className="font-medium text-foreground mb-2">Check your inbox</p>
          <p className="text-sm text-muted-foreground mb-6">We've sent a password reset link to {email}</p>
          <Link href="/sign-in" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Back to Sign In</Link>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Email</label>
            <div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" className="w-full bg-background border border-border rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:border-primary boty-transition" /></div>
          </div>
          <button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground py-3 rounded-full font-medium boty-transition hover:bg-primary/90 disabled:opacity-60 boty-shadow inline-flex items-center justify-center gap-2">{loading ? <><span className="lumina-spinner" /> Sending...</> : <>Send Reset Link <ArrowRight className="w-4 h-4" /></>}</button>
        </form>
      )}
      <p className="text-center text-sm text-muted-foreground mt-6"><Link href="/sign-in" className="text-primary hover:underline">← Back to sign in</Link></p>
    </AuthShell>
  )
}
