import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { MapPin } from "lucide-react"

export default function StockistsPage() {
  const stockists = [
    { name: "Maison Verte", city: "New York, NY", address: "218 Crosby Street", type: "Boutique" },
    { name: "The Soft Shop", city: "Los Angeles, CA", address: "8412 Melrose Avenue", type: "Concept Store" },
    { name: "Cedar & Co.", city: "Chicago, IL", address: "1040 W Armitage Avenue", type: "Boutique" },
    { name: "Maison Lumière", city: "San Francisco, CA", address: "518 Hayes Street", type: "Flagship" },
    { name: "Studio Aroma", city: "Austin, TX", address: "902 E 6th Street", type: "Concept Store" },
    { name: "The Quiet Room", city: "Seattle, WA", address: "1412 12th Avenue", type: "Boutique" },
    { name: "Botanica Home", city: "Portland, OR", address: "3731 SE Hawthorne Blvd", type: "Home Goods" },
    { name: "Maison Douce", city: "Miami, FL", address: "3930 NE 2nd Avenue", type: "Boutique" },
  ]

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Find Us In Person</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">Stockists</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Visit one of our beautiful retail partners to experience Lumina in person.</p>
          </Reveal>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {stockists.map((s, i) => (
              <Reveal key={s.name} delay={i * 60}>
                <div className="bg-card rounded-3xl p-5 boty-shadow hover:scale-[1.02] boty-transition">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0"><MapPin className="w-5 h-5 text-primary" /></div>
                    <div>
                      <p className="font-serif text-lg text-foreground">{s.name}</p>
                      <p className="text-xs text-primary">{s.type}</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{s.address}</p>
                  <p className="text-sm text-foreground">{s.city}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={200} className="bg-card rounded-3xl p-8 boty-shadow text-center mt-12">
            <p className="font-serif text-2xl text-foreground mb-2">Interested in stocking Lumina?</p>
            <p className="text-sm text-muted-foreground mb-4">We partner with like-minded boutiques and concept stores worldwide.</p>
            <a href="mailto:wholesale@luminamist.co" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Apply for Wholesale</a>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
