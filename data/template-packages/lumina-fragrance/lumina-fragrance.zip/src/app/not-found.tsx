import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { Home, Search, ArrowRight } from "lucide-react"

export default function NotFound() {
  return (
    <main className="min-h-screen lumina-page flex flex-col">
      <Header />
      <div className="flex-1 flex items-center pt-28 pb-20">
        <div className="max-w-2xl mx-auto px-6 text-center">
          <Reveal>
            <p className="font-serif text-[120px] md:text-[180px] leading-none text-primary/20 mb-4">404</p>
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Page Not Found</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4 text-balance">This page wandered off</h1>
            <p className="text-lg text-muted-foreground mb-8">The page you're looking for doesn't exist or has been moved. Let's get you back on the scent trail.</p>
          </Reveal>
          <Reveal delay={80} className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/" className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90 boty-shadow"><Home className="w-4 h-4" /> Back Home</Link>
            <Link href="/shop" className="inline-flex items-center justify-center gap-2 border border-border text-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-muted"><Search className="w-4 h-4" /> Browse Shop <ArrowRight className="w-4 h-4" /></Link>
          </Reveal>
          <Reveal delay={120} className="mt-12">
            <p className="text-sm text-muted-foreground mb-4">Popular pages:</p>
            <div className="flex flex-wrap justify-center gap-2">
              {[{ label: "Body Mists", href: "/shop/mists" }, { label: "Discovery Sets", href: "/discovery-sets" }, { label: "Best Sellers", href: "/best-sellers" }, { label: "Fragrance Quiz", href: "/fragrance-quiz" }, { label: "Contact", href: "/contact" }].map((l) => (
                <Link key={l.href} href={l.href} className="text-xs px-3 py-1.5 rounded-full bg-card text-foreground boty-shadow hover:scale-[1.05] boty-transition">{l.label}</Link>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
