import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { ProductGrid } from "@/components/shared/product-grid"
import { onSaleProducts } from "@/data/products"

export default function SalePage() {
  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-sm tracking-[0.3em] uppercase text-destructive mb-4 block">Limited Time</span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">On Sale</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">A curated selection of fragrances at a special price. Use code LUMINA10 for an extra 10% off.</p>
          </div>
          <ProductGrid items={onSaleProducts} />
        </div>
      </div>
      <Footer />
    </main>
  )
}
