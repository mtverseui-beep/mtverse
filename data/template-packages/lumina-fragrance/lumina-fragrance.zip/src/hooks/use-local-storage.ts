"use client"

import { useEffect, useState } from "react"

/**
 * useLocalStorage — a typed, SSR-safe localStorage hook.
 * Returns [value, setValue] just like useState, with persistence.
 */
export function useLocalStorage<T>(key: string, initial: T): [T, (v: T | ((prev: T) => T)) => void, boolean] {
  const [value, setValue] = useState<T>(initial)
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    try {
      const stored = localStorage.getItem(key)
      if (stored !== null) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setValue(JSON.parse(stored) as T)
      }
    } catch {
      // ignore
    }
    setHydrated(true)
  }, [key])

  useEffect(() => {
    if (hydrated) {
      try {
        localStorage.setItem(key, JSON.stringify(value))
      } catch {
        // ignore
      }
    }
  }, [key, value, hydrated])

  return [value, setValue, hydrated]
}
