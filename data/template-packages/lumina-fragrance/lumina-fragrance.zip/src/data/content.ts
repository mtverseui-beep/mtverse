import type { BlogPost, FaqItem, PolicyDoc } from "@/types"

export const blogPosts: BlogPost[] = [
  {
    slug: "the-art-of-scent-layering",
    title: "The Art of Scent Layering: Building Your Signature",
    excerpt: "Scent is built, not worn. A practical guide to layering body mists, hair perfumes, and room sprays for a fragrance that is unmistakably yours.",
    body: [
      "Scent layering is the practice of combining multiple fragrance formats to create a deeper, more personal signature. Rather than wearing a single perfume, you build a scent wardrobe, a body mist on the skin, a hair perfume through the lengths, perhaps a room spray in the air, each chosen to complement the others.",
      "The first principle of layering is harmony. Begin with a single note you love, a fresh rose, a warm amber, a clean musk, and build around it. Avoid combining scents that compete, such as two loud florals or two deep orientals, which can create a confused and overwhelming impression.",
      "The second principle is format. Body mists sit close to the skin and wear softly. Hair perfumes lift with movement and linger longer. Room sprays create atmosphere. By distributing your scent across formats, you create a multi-dimensional trail that feels natural rather than applied.",
      "The third principle is restraint. The goal is not to wear more fragrance, but to wear it more thoughtfully. Two or three complementary formats are enough. More than that, and the layers begin to compete rather than compose.",
      "A simple place to begin: choose a body mist you love, pair it with a hair perfume from the same family, and finish with a room spray that shares a base note. The Bloom Layering Duo is a ready-made introduction, pairing Rose Milk Body Mist with Amber Bloom Hair Perfume for a soft, dimensional floral.",
    ],
    cover: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1600&q=80",
    category: "Rituals",
    author: "Elena Vance",
    publishedAt: "2026-05-22",
    readingTime: "6 min read",
    tags: ["Layering", "Ritual", "Guide"],
  },
  {
    slug: "understanding-fragrance-families",
    title: "Understanding Fragrance Families: A Beginner's Guide",
    excerpt: "From fresh florals to warm ambers, a primer on the major fragrance families and how to recognize them.",
    body: [
      "Every fragrance belongs, roughly, to a family. Understanding these families is the first step to articulating what you like and why, and to finding scents that share a particular quality.",
      "Floral scents are built around flowers, rose, jasmine, peony, iris. They can be fresh and dewy or deep and velvety, but they always place flowers at the center. Our Rose Milk is a soft floral, dewy and creamy.",
      "Amber scents are warm, resinous, and quietly enveloping. They are built around amber, benzoin, and soft resins, often paired with vanilla and sandalwood. Our Evening Velvet is an amber oriental, deep and warm without being loud.",
      "Musk scents are clean, soft, and lingering. They are the foundation of every second-skin fragrance, often paired with iris, rose, or cashmeran for a soft, intimate presence. Our Cloud Veil is a soft floral musk.",
      "Citrus scents are bright, crisp, and refreshing. They are built around lemon, bergamot, and grapefruit, often paired with neroli or white tea. Our Citrus Linen Room Spray is a citrus aromatic for the home.",
      "Vanilla scents are warm, sweet, and second-skin. They are built around bourbon vanilla and tonka, often paired with amber and benzoin for depth. Our Vanilla Hour is a warm vanilla amber for the body.",
    ],
    cover: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1600&q=80",
    category: "Education",
    author: "Maya Okonkwo",
    publishedAt: "2026-04-18",
    readingTime: "5 min read",
    tags: ["Education", "Families", "Guide"],
  },
  {
    slug: "fragrance-for-the-home",
    title: "Fragrance for the Home: Beyond the Candle",
    excerpt: "Room sprays, pillow mists, and linen sprays offer a quieter, more versatile alternative to scented candles. Here is how to use them well.",
    body: [
      "Scented candles have dominated home fragrance for decades, but they are not the only option. Room sprays, pillow mists, and linen sprays offer a quieter, more versatile alternative that can be layered and applied exactly where needed.",
      "The advantage of a spray format is precision. A candle fills a room uniformly and continuously, which is not always what you want. A spray allows you to scent a pillow before bed, a towel before a shower, or the air before guests arrive, with no commitment beyond the moment.",
      "The Lumina home collection is built around this principle. Citrus Linen refreshes a room with cold-pressed citrus and white tea. Clean Cotton recreates the moment fresh laundry is pulled from the line. Calm Linen settles the senses before rest with lavender and vanilla.",
      "A simple ritual: spritz your pillow with Calm Linen five minutes before bed. In the morning, spritz the air with Citrus Linen before opening the curtains. Before guests arrive, spritz Clean Cotton onto the throw on your sofa. Each takes five seconds and changes the room.",
      "Unlike candles, sprays are safe to leave unattended, require no flame or heat, and can be reapplied as desired. They are also more sustainable, with refillable formats and recyclable packaging throughout the collection.",
    ],
    cover: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?auto=format&fit=crop&w=1600&q=80",
    category: "Home Rituals",
    author: "Lila Marchetti",
    publishedAt: "2026-03-12",
    readingTime: "4 min read",
    tags: ["Home", "Room Spray", "Ritual"],
  },
  {
    slug: "how-to-find-your-signature-scent",
    title: "How to Find Your Signature Scent",
    excerpt: "A practical, no-pressure guide to discovering the fragrance that feels like you.",
    body: [
      "A signature scent is a fragrance that becomes associated with you, the one people remember and expect. Finding it is not a single moment of revelation, but a slow process of paying attention to what you love.",
      "Begin with discovery sets rather than full sizes. The Golden Fig Discovery Set collects five minis from across the Lumina collection, allowing you to live with each scent for a day before committing. Wear each one for a full day, not just a moment, and notice how it evolves and how it makes you feel.",
      "Pay attention to the drydown. The first impression of a fragrance, the top notes, is often the loudest part but also the most fleeting. The drydown, the heart and base notes that emerge after thirty minutes, is what you will actually live with. Wait before you decide.",
      "Notice what you return to. After a week of testing, which scent did you reach for again? Which one did you miss on the days you didn't wear it? That pull is more reliable than your first impression.",
      "Don't be afraid to layer. A signature scent doesn't have to be a single fragrance. Many people compose their signature from two or three complementary formats, a body mist and a hair perfume, perhaps, that together feel unmistakably theirs.",
    ],
    cover: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1600&q=80",
    category: "Rituals",
    author: "Elena Vance",
    publishedAt: "2026-02-04",
    readingTime: "5 min read",
    tags: ["Discovery", "Guide", "Ritual"],
  },
  {
    slug: "the-lumina-sustainability-standard",
    title: "The Lumina Sustainability Standard",
    excerpt: "How we approach packaging, sourcing, and formulation with intention rather than marketing.",
    body: [
      "Sustainability in fragrance is often reduced to a sticker on a box. We are trying to do better than that, by making specific commitments and reporting on them honestly.",
      "Our packaging is recyclable and minimal. We use glass bottles, aluminum caps, and paper boxes printed with soy inks. We avoid plastic where possible and use only post-consumer recycled plastic where it is unavoidable. Our gift sets are presented in keepsake boxes designed to be reused rather than discarded.",
      "Our formulations are vegan and cruelty-free. We never use animal-derived ingredients and never test on animals. We do not use parabens, phthalates, or synthetic colorants. Our full ingredient lists are printed on every box.",
      "Our 100ml bottles are refillable. Each can be refilled from a 1L refill pouch (launching late 2026) or repurposed as a vase once empty. Our 15ml travel minis are designed to be refilled from the 100ml bottle using the included funnel.",
      "We are not perfect. There is more to do, particularly in our supply chain and our international shipping footprint. We publish an annual sustainability report that lists our progress and our gaps, and we welcome questions at hello@luminamist.co.",
    ],
    cover: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1600&q=80",
    category: "Brand",
    author: "Lumina Team",
    publishedAt: "2026-01-15",
    readingTime: "4 min read",
    tags: ["Sustainability", "Brand"],
  },
  {
    slug: "fragrance-and-memory",
    title: "Fragrance and Memory: Why Scent Lingers",
    excerpt: "Of all the senses, smell is the most directly connected to memory. A short essay on why.",
    body: [
      "Of all the senses, smell is the most directly connected to memory. The olfactory bulb sits beside the hippocampus and amygdala, the brain regions responsible for memory and emotion, and a single scent can call up a moment from decades ago with an immediacy no other sense can match.",
      "This is why a particular fragrance can feel so personal. The rose your grandmother grew, the clean laundry of a childhood bedroom, the warm skin of someone you loved, each becomes associated with a moment and a feeling, and the scent recalls the moment whenever it returns.",
      "It is also why we are deliberate, at Lumina, about scents that feel like memories rather than performances. Our fragrances are designed to sit close to the skin, to be felt more than noticed, and to become part of the texture of a life rather than a statement made upon entering a room.",
      "When you choose a fragrance, you are not just choosing a smell. You are choosing the memory it will become. Choose with that in mind, and wear it long enough for the memory to form.",
    ],
    cover: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1600&q=80",
    category: "Essays",
    author: "Maya Okonkwo",
    publishedAt: "2025-12-08",
    readingTime: "3 min read",
    tags: ["Essay", "Memory"],
  },
]

export const blogPostBySlug = (slug: string) => blogPosts.find((p) => p.slug === slug)
export const blogCategories = Array.from(new Set(blogPosts.map((p) => p.category)))

export const faqs: FaqItem[] = [
  { id: "f1", category: "Products", question: "What is the difference between a body mist and a perfume?", answer: "Body mists are lighter and lower in fragrance concentration than traditional perfumes. They wear close to the skin, are easy to reapply throughout the day, and are designed for everyday wear rather than special occasions. Our body mists are also formulated to be layered with our hair perfumes and room sprays for a deeper, more dimensional scent." },
  { id: "f2", category: "Products", question: "Are your products vegan and cruelty-free?", answer: "Yes. Every product in the Lumina collection is vegan and cruelty-free. We never use animal-derived ingredients and never test on animals. Our full ingredient lists are printed on every box." },
  { id: "f3", category: "Products", question: "Are your products safe for sensitive skin?", answer: "Our products are formulated with moderated alcohol bases and skin-conditioning vitamin E. We recommend patch testing on the inner wrist before first use if you have known sensitivities, and we offer a 30-day return policy if a product does not work for you." },
  { id: "f4", category: "Products", question: "How long does a body mist last on skin?", answer: "Our body mists wear for 4 to 7 hours depending on the fragrance family and your skin chemistry. Softer scents such as Cloud Veil wear for 4 to 6 hours, while deeper scents such as Evening Velvet wear for 7 to 9 hours. Reapply as desired throughout the day." },
  { id: "f5", category: "Shipping", question: "How long does shipping take?", answer: "Orders ship within 1 business day from our Los Angeles studio. Delivery within the US takes 3 to 5 business days. International delivery takes 7 to 14 business days depending on the destination. You will receive a tracking number by email when your order ships." },
  { id: "f6", category: "Shipping", question: "Do you offer free shipping?", answer: "Yes. We offer free standard shipping on all orders over $50 within the US. Orders under $50 ship for a flat $5. International shipping is calculated at checkout based on destination and weight." },
  { id: "f7", category: "Shipping", question: "Do you ship internationally?", answer: "Yes. We ship to over 40 countries. International shipping is calculated at checkout. Please note that some destinations may charge import duties or taxes, which are the responsibility of the recipient." },
  { id: "f8", category: "Returns", question: "What is your return policy?", answer: "We offer a 30-day return policy on all unopened products. If you have tried a product and it has not worked for you, contact us at hello@luminamist.co and we will do our best to make it right, often with a store credit or exchange." },
  { id: "f9", category: "Returns", question: "How do I start a return?", answer: "Email hello@luminamist.co with your order number and the items you would like to return. We will send you a return label and instructions within 1 business day. Refunds are processed within 3 business days of receiving your return." },
  { id: "f10", category: "Orders", question: "How do I track my order?", answer: "You will receive a tracking number by email when your order ships. You can also track your order anytime at /track-order using your order number and email address." },
  { id: "f11", category: "Orders", question: "Can I change or cancel my order after placing it?", answer: "Orders can be changed or cancelled within 1 hour of placing them. Email hello@luminamist.co as soon as possible with your order number and the change you would like to make." },
  { id: "f12", category: "Orders", question: "Can I include a gift note with my order?", answer: "Yes. Add a gift note at checkout and we will handwrite it on Lumina stationery and include it in the package. Gift notes are free and available on any order." },
  { id: "f13", category: "Account", question: "Do I need an account to place an order?", answer: "No. Guest checkout is available on every order. Creating an account allows you to track orders, save addresses, and earn rewards points, but is not required." },
  { id: "f14", category: "Account", question: "How do I earn rewards points?", answer: "Create an account and you will earn 1 point for every $1 spent. Points can be redeemed for discounts on future orders. You also earn points for referring friends, writing reviews, and following us on social media." },
  { id: "f15", category: "Products", question: "How should I store my fragrances?", answer: "Store your fragrances in a cool, dry place away from direct sunlight and temperature fluctuations. A bedroom drawer or closet is ideal. Avoid storing fragrances in the bathroom, where temperature and humidity fluctuate with shower use." },
  { id: "f16", category: "Products", question: "Can I layer different fragrance families together?", answer: "Yes, but with care. The most reliable layering combinations share a base note, such as musk, amber, or vanilla. Avoid combining scents that compete, such as two loud florals or two deep orientals, which can create a confused impression. Our Bloom Layering Duo is a ready-made introduction." },
]

export const faqCategories = Array.from(new Set(faqs.map((f) => f.category)))

export const policies: PolicyDoc[] = [
  {
    slug: "privacy",
    title: "Privacy Policy",
    updatedAt: "2026-07-01",
    sections: [
      { heading: "Our approach to privacy", body: ["Lumina is committed to protecting your privacy. This policy explains what information we collect, how we use it, and the choices you have. We collect only the information necessary to process your orders, provide customer service, and improve our products and services.", "We never sell your personal information. We do not share your information with third parties for their own marketing purposes. We share information only with service providers who help us operate our business, and only under written agreements that require them to protect your information."] },
      { heading: "Information we collect", body: ["We collect information you provide directly, such as your name, email address, shipping address, and payment information when you place an order. We also collect information automatically, such as your IP address, browser type, and browsing behavior on our website, through cookies and similar technologies.", "You can choose not to provide certain information, though this may limit your ability to use some features of our website. For example, without a shipping address we cannot fulfill an order."] },
      { heading: "How we use your information", body: ["We use your information to process and fulfill your orders, communicate with you about your orders, provide customer service, send marketing communications (with your consent), improve our website and products, and comply with legal obligations.", "We retain your information for as long as necessary to provide our services and comply with legal obligations. You can request deletion of your account and personal information at any time by emailing hello@luminamist.co."] },
      { heading: "Your choices", body: ["You can update your account information at any time in your account settings. You can unsubscribe from marketing communications by clicking the unsubscribe link in any email. You can request access to, correction of, or deletion of your personal information by emailing hello@luminamist.co.", "You can also control cookies through your browser settings. Disabling cookies may limit some features of our website."] },
    ],
  },
  {
    slug: "terms",
    title: "Terms of Service",
    updatedAt: "2026-07-01",
    sections: [
      { heading: "Acceptance of terms", body: ["By accessing or using the Lumina website, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our website.", "These terms may be updated from time to time. Continued use of the website after changes constitutes acceptance of the updated terms."] },
      { heading: "Use of our website", body: ["You agree to use our website only for lawful purposes and in a manner that does not infringe the rights of others. You may not use our website to transmit viruses, malware, or harmful code, or to attempt to gain unauthorized access to our systems.", "All content on our website, including text, images, logos, and product designs, is the property of Lumina or its licensors and is protected by copyright and trademark law. You may not reproduce, distribute, or modify our content without written permission."] },
      { heading: "Orders and pricing", body: ["All orders are subject to availability and confirmation of the order price. We reserve the right to refuse or cancel any order at any time. Prices are displayed in US dollars and are subject to change without notice.", "We make every effort to display accurate product information, including prices, descriptions, and availability. If an error occurs, we will contact you before processing your order."] },
    ],
  },
  {
    slug: "cookies",
    title: "Cookie Policy",
    updatedAt: "2026-07-01",
    sections: [
      { heading: "How we use cookies", body: ["Cookies are small text files stored on your device when you visit a website. We use cookies to remember items in your cart, remember your preferences, analyze how our website is used, and personalize your experience.", "We use both session cookies (which expire when you close your browser) and persistent cookies (which remain on your device until they expire or you delete them)."] },
      { heading: "Types of cookies we use", body: ["Essential cookies are necessary for our website to function. They enable you to add items to your cart and complete checkout. These cannot be disabled.", "Analytics cookies help us understand how visitors use our website so we can improve it. Marketing cookies allow us to show you relevant products and offers. Both can be disabled through your browser settings or our cookie preference center."] },
      { heading: "Managing cookies", body: ["You can control and delete cookies through your browser settings. Disabling cookies may affect your ability to use some features of our website, such as the shopping cart.", "For more information about managing cookies, visit the help pages of your browser or visit allaboutcookies.org."] },
    ],
  },
  {
    slug: "accessibility",
    title: "Accessibility Statement",
    updatedAt: "2026-07-01",
    sections: [
      { heading: "Our commitment", body: ["Lumina is committed to making our website accessible to everyone, including people with disabilities. We are working to ensure our website meets the Web Content Accessibility Guidelines (WCAG) 2.1 Level AA.", "We have implemented features such as semantic HTML, keyboard navigation, alt text for images, and sufficient color contrast. We continue to audit and improve our website to ensure it is usable by everyone."] },
      { heading: "Feedback and contact", body: ["If you encounter any accessibility barrier on our website, please contact us at hello@luminamist.co. We take accessibility feedback seriously and will work to address any issues as quickly as possible.", "If you need assistance placing an order, our customer service team is available by email and can help you complete your order over the phone."] },
    ],
  },
  {
    slug: "refund-policy",
    title: "Refund Policy",
    updatedAt: "2026-07-01",
    sections: [
      { heading: "When refunds are issued", body: ["We issue refunds for returned items that are unopened and in their original packaging, returned within 30 days of delivery. Refunds are also issued for orders that are lost in transit or arrive damaged.", "If you have tried a product and it has not worked for you, contact us at hello@luminamist.co. We will do our best to make it right, often with a store credit or exchange."] },
      { heading: "How refunds are processed", body: ["Refunds are processed within 3 business days of receiving your return. The refund is issued to the original payment method and may take an additional 3 to 5 business days to appear on your statement, depending on your bank.", "Shipping charges are non-refundable except in cases where the order was lost, damaged, or incorrectly fulfilled by us."] },
    ],
  },
  {
    slug: "returns-policy",
    title: "Returns Policy",
    updatedAt: "2026-07-01",
    sections: [
      { heading: "30-day returns", body: ["We accept returns within 30 days of delivery on unopened products in their original packaging. To start a return, email hello@luminamist.co with your order number and the items you would like to return.", "We will send you a return label and instructions within 1 business day. Drop off the package at any carrier location. Refunds are processed within 3 business days of receiving your return."] },
      { heading: "Tried and didn't love it", body: ["If you have tried a product and it has not worked for you, contact us. We will often offer a store credit or exchange rather than require a return. We want you to find a fragrance you love, and we will work with you to make that happen.", "For safety and hygiene reasons, we cannot accept returns of opened products. We will instead offer a store credit toward a different scent."] },
    ],
  },
  {
    slug: "shipping-policy",
    title: "Shipping Policy",
    updatedAt: "2026-07-01",
    sections: [
      { heading: "Processing time", body: ["Orders are processed within 1 business day of being placed. Orders placed on weekends or holidays are processed on the next business day. You will receive a confirmation email with tracking information when your order ships.", "During high-volume periods such as product launches or holidays, processing may take up to 2 business days. We will communicate any delays by email."] },
      { heading: "Domestic shipping (United States)", body: ["We offer free standard shipping on all orders over $50 within the US. Orders under $50 ship for a flat $5. Standard shipping takes 3 to 5 business days. Expedited shipping options are available at checkout.", "We ship to all 50 states, including PO boxes and APO/FPO addresses. Signature confirmation is required on orders over $200."] },
      { heading: "International shipping", body: ["We ship to over 40 countries. International shipping is calculated at checkout based on destination and weight. Delivery typically takes 7 to 14 business days depending on the destination.", "Import duties, taxes, and customs fees may apply and are the responsibility of the recipient. We cannot mark packages as gifts or undervalue the contents for customs purposes."] },
    ],
  },
]

export const policyBySlug = (slug: string) => policies.find((p) => p.slug === slug)
