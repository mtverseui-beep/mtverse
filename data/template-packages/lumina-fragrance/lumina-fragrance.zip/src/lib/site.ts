export const siteConfig = {
  name: "Lumina",
  shortName: "Lumina",
  domain: "lumina.co",
  url: "https://lumina.co",
  tagline: "Modern fragrance rituals for everyday moments",
  description:
    "Shop premium body mists, hair perfumes, room sprays, discovery sets, and scent layering gifts from Lumina.",
  supportEmail: "hello@lumina.co",
  pressEmail: "press@lumina.co",
  address: "Lumina Studio, 1100 Mission Street, San Francisco, CA 94103",
  phone: "+1 (415) 555-0100",
  social: {
    instagram: "https://instagram.com/lumina",
    tiktok: "https://tiktok.com/@lumina",
    pinterest: "https://pinterest.com/lumina",
    youtube: "https://youtube.com/@lumina",
  },
  keywords: [
    "Lumina",
    "premium fragrance",
    "body mist",
    "hair perfume",
    "room spray",
    "discovery set",
    "gift set",
    "scent layering",
    "fragrance gift",
    "luxury body mist",
  ],
  seo: {
    title: "Lumina — Premium Body Mists, Hair Perfumes & Discovery Sets",
    description:
      "Shop premium body mists, hair perfumes, room sprays, discovery sets, and scent layering gifts from Lumina. Modern fragrance rituals for everyday moments.",
    ogImage: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1200&q=80",
  },
} as const;

export const formatPrice = (price: number): string =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(price);

export const formatDate = (date: string | Date): string => {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(d);
};

export const formatDateTime = (date: string | Date): string => {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(d);
};

export const cn = (...inputs: (string | undefined | null | false)[]): string =>
  inputs.filter(Boolean).join(" ");

export const slugify = (text: string): string =>
  text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");

export const truncate = (text: string, max: number): string =>
  text.length > max ? text.slice(0, max - 1).trimEnd() + "\u2026" : text;

export const generateOrderNumber = (): string => {
  const part = Math.floor(100000 + Math.random() * 900000);
  return `LUM-${part}`;
};
