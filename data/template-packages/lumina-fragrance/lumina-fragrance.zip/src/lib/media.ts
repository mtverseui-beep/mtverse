/**
 * Central media configuration for Lumina.
 * All video URLs and posters are read from environment variables.
 * If a variable is empty, the AmbientVideo component will fall back
 * to a premium static image rather than rendering a broken video element.
 *
 * NEXT_PUBLIC_ variables are visible in the browser, so use them only
 * for public video URLs. Never put secrets in NEXT_PUBLIC_ variables.
 *
 * To self-host videos:
 *   1. Place video files in /public/videos/ (e.g. /public/videos/hero.mp4)
 *   2. Set NEXT_PUBLIC_HERO_VIDEO_URL=/videos/hero.mp4
 *   3. Place a poster image in /public/images/video-posters/ (e.g. hero.jpg)
 *   4. Set NEXT_PUBLIC_HERO_VIDEO_POSTER_URL=/images/video-posters/hero.jpg
 *
 * To use stock videos:
 *   - Pexels, Pixabay, Mixkit, and Coverr offer free, license-clear videos.
 *   - Search terms: perfume bottle, fragrance spray, body mist, hair perfume,
 *     luxury perfume, vanity fragrance, woman applying perfume, room spray,
 *     candle and perfume, gift box fragrance, floral still life,
 *     bathroom fragrance ritual.
 *
 * To disable videos entirely:
 *   - Leave the env variables empty. The AmbientVideo component will
 *     automatically fall back to the provided image.
 */

export type MediaConfig = {
  hero: { videoUrl?: string; posterUrl: string };
  scentRitual: { videoUrl?: string; posterUrl: string };
  productCloseup: { videoUrl?: string; posterUrl: string };
  giftSet: { videoUrl?: string; posterUrl: string };
  roomSpray: { videoUrl?: string; posterUrl: string };
  lookbook: { videoUrl?: string; posterUrl: string };
};

const env = (key: string): string | undefined => {
  const v = process.env[key];
  return v && v.trim().length > 0 ? v.trim() : undefined;
};

export const mediaConfig: MediaConfig = {
  hero: {
    videoUrl: env("NEXT_PUBLIC_HERO_VIDEO_URL"),
    posterUrl:
      env("NEXT_PUBLIC_HERO_VIDEO_POSTER_URL") ||
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1920&q=80",
  },
  scentRitual: {
    videoUrl: env("NEXT_PUBLIC_SCENT_RITUAL_VIDEO_URL"),
    posterUrl:
      env("NEXT_PUBLIC_SCENT_RITUAL_VIDEO_POSTER_URL") ||
      "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1920&q=80",
  },
  productCloseup: {
    videoUrl: env("NEXT_PUBLIC_PRODUCT_CLOSEUP_VIDEO_URL"),
    posterUrl:
      env("NEXT_PUBLIC_PRODUCT_CLOSEUP_VIDEO_POSTER_URL") ||
      "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1920&q=80",
  },
  giftSet: {
    videoUrl: env("NEXT_PUBLIC_GIFT_SET_VIDEO_URL"),
    posterUrl:
      env("NEXT_PUBLIC_GIFT_SET_VIDEO_POSTER_URL") ||
      "https://images.unsplash.com/photo-1549887552-cb1071d3e5ca?auto=format&fit=crop&w=1920&q=80",
  },
  roomSpray: {
    videoUrl: env("NEXT_PUBLIC_ROOM_SPRAY_VIDEO_URL"),
    posterUrl:
      env("NEXT_PUBLIC_ROOM_SPRAY_VIDEO_POSTER_URL") ||
      "https://images.unsplash.com/photo-1600573472556-e636c2acda88?auto=format&fit=crop&w=1920&q=80",
  },
  lookbook: {
    videoUrl: env("NEXT_PUBLIC_LOOKBOOK_VIDEO_URL"),
    posterUrl:
      env("NEXT_PUBLIC_LOOKBOOK_VIDEO_POSTER_URL") ||
      "https://images.unsplash.com/photo-1588405748880-12d1d2a59d75?auto=format&fit=crop&w=1920&q=80",
  },
};

export type MediaKey = keyof MediaConfig;
