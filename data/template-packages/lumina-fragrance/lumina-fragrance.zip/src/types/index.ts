export interface BlogPost {
  slug: string
  title: string
  excerpt: string
  body: string[]
  cover: string
  category: string
  author: string
  publishedAt: string
  readingTime: string
  tags: string[]
}

export interface FaqItem {
  id: string
  category: string
  question: string
  answer: string
}

export interface PolicyDoc {
  slug: string
  title: string
  updatedAt: string
  sections: { heading: string; body: string[] }[]
}

export interface Product {
  id: string
  name: string
  description: string
  price: number
  originalPrice?: number | null
  image: string
  badge?: string | null
  category: string
  tagline?: string
  notes?: { top: string[]; heart: string[]; base: string[] }
  rating?: number
  reviewCount?: number
  sizes?: string[]
}
