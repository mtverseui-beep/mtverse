"use client"

import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "./reveal"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"

interface PageShellProps {
  children: React.ReactNode
  eyebrow?: string
  title?: string
  description?: string
  backHref?: string
  backLabel?: string
  showHeader?: boolean
  showFooter?: boolean
  align?: "left" | "center"
}

/**
 * PageShell — standard page wrapper with header, footer, page title block,
 * back link, and fade-in. Used by all interior pages for consistency.
 */
export function PageShell({
  children,
  eyebrow,
  title,
  description,
  backHref,
  backLabel = "Back",
  showHeader = true,
  showFooter = true,
  align = "center",
}: PageShellProps) {
  return (
    <main className="min-h-screen lumina-page">
      {showHeader && <Header />}

      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {backHref && (
            <Link
              href={backHref}
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"
            >
              <ChevronLeft className="w-4 h-4" />
              {backLabel}
            </Link>
          )}

          {(eyebrow || title || description) && (
            <Reveal className={`mb-12 ${align === "center" ? "text-center" : "text-left"}`}>
              {eyebrow && (
                <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">
                  {eyebrow}
                </span>
              )}
              {title && (
                <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4 text-balance">
                  {title}
                </h1>
              )}
              {description && (
                <p className={`text-lg text-muted-foreground max-w-2xl ${align === "center" ? "mx-auto" : ""}`}>
                  {description}
                </p>
              )}
            </Reveal>
          )}

          {children}
        </div>
      </div>

      {showFooter && <Footer />}
    </main>
  )
}
