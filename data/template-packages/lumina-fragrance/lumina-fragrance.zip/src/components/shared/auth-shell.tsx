import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"

export function AuthShell({ children, title, subtitle }: { children: React.ReactNode; title: string; subtitle: string }) {
  return (
    <main className="min-h-screen lumina-page flex flex-col">
      <Header />
      <div className="flex-1 flex items-center pt-28 pb-20">
        <div className="max-w-md mx-auto px-6 w-full">
          <Reveal className="text-center mb-8">
            <Link href="/" className="font-serif text-3xl text-foreground">Lumina</Link>
            <h1 className="font-serif text-3xl text-foreground mt-4 mb-2">{title}</h1>
            <p className="text-sm text-muted-foreground">{subtitle}</p>
          </Reveal>
          <Reveal delay={80} className="bg-card rounded-3xl p-6 lg:p-8 boty-shadow">
            {children}
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
