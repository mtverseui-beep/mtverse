import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { policyBySlug } from "@/data/content"
import { notFound } from "next/navigation"
import { ChevronLeft } from "lucide-react"

export function PolicyPage({ slug }: { slug: string }) {
  const policy = policyBySlug(slug)
  if (!policy) notFound()

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-3xl mx-auto px-6 lg:px-8">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"><ChevronLeft className="w-4 h-4" /> Back to Home</Link>
          <Reveal className="mb-10">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">Legal</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-2 text-balance">{policy.title}</h1>
            <p className="text-sm text-muted-foreground">Last updated: {policy.updatedAt}</p>
          </Reveal>
          <div className="space-y-8">
            {policy.sections.map((s, i) => (
              <Reveal key={i} delay={i * 60}>
                <h2 className="font-serif text-xl text-foreground mb-3">{s.heading}</h2>
                {s.body.map((p, j) => <p key={j} className="text-sm text-muted-foreground leading-relaxed mb-3">{p}</p>)}
              </Reveal>
            ))}
          </div>
          <Reveal delay={200} className="bg-card rounded-3xl p-6 boty-shadow text-center mt-12">
            <p className="text-sm text-muted-foreground mb-3">Questions about this policy?</p>
            <a href="mailto:hello@luminamist.co" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Email Us</a>
          </Reveal>
        </div>
      </div>
      <Footer />
    </main>
  )
}
