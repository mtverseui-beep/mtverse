import Link from "next/link"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { Reveal } from "@/components/shared/reveal"
import { ChevronLeft } from "lucide-react"

export function HelpSubPage({ title, eyebrow, sections, contactCta = true }: { title: string; eyebrow: string; sections: { heading: string; body: string[] }[]; contactCta?: boolean }) {
  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-3xl mx-auto px-6 lg:px-8">
          <Link href="/help" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground boty-transition mb-8"><ChevronLeft className="w-4 h-4" /> Help Center</Link>
          <Reveal className="mb-10">
            <span className="text-sm tracking-[0.3em] uppercase text-primary mb-4 block">{eyebrow}</span>
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4 text-balance">{title}</h1>
          </Reveal>
          <div className="space-y-8">
            {sections.map((s, i) => (
              <Reveal key={i} delay={i * 60} className="bg-card rounded-3xl p-6 boty-shadow">
                <h2 className="font-serif text-xl text-foreground mb-3">{s.heading}</h2>
                {s.body.map((p, j) => <p key={j} className="text-sm text-muted-foreground leading-relaxed mb-3 last:mb-0">{p}</p>)}
              </Reveal>
            ))}
          </div>
          {contactCta && (
            <Reveal delay={200} className="bg-card rounded-3xl p-6 boty-shadow text-center mt-8">
              <p className="text-foreground mb-3">Still have questions?</p>
              <Link href="/contact" className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-full text-sm boty-transition hover:bg-primary/90">Contact Support</Link>
            </Reveal>
          )}
        </div>
      </div>
      <Footer />
    </main>
  )
}
