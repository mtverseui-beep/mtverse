"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { products as allProducts } from "@/data/products"
import { useCart } from "@/components/boty/cart-context"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { ShoppingBag, Heart, GitCompare, Star } from "lucide-react"

interface ProductGridProps {
  items: typeof allProducts
  showFilters?: boolean
}

export function ProductGrid({ items, showFilters = true }: ProductGridProps) {
  const [isVisible, setIsVisible] = useState(false)
  const gridRef = useRef<HTMLDivElement>(null)
  const { addItem } = useCart()
  const [wishlist, setWishlist] = useLocalStorage<string[]>("lumina-wishlist", [])
  const [compare, setCompare] = useLocalStorage<string[]>("lumina-compare", [])

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setIsVisible(true) }, { threshold: 0.05 })
    if (gridRef.current) obs.observe(gridRef.current)
    return () => { if (gridRef.current) obs.unobserve(gridRef.current) }
  }, [])

  const toggleWishlist = (id: string) => setWishlist((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id])
  const toggleCompare = (id: string) => setCompare((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : (prev.length >= 4 ? prev : [...prev, id]))

  return (
    <div ref={gridRef} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {items.map((product, index) => (
        <div
          key={product.id}
          className={`group transition-all duration-700 ease-out ${isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          style={{ transitionDelay: `${index * 60}ms` }}
        >
          <div className="bg-card rounded-3xl overflow-hidden boty-shadow boty-transition group-hover:scale-[1.02]">
            <Link href={`/product/${product.id}`} className="relative aspect-square block bg-muted overflow-hidden">
              <Image src={product.image} alt={product.name} fill className="object-cover boty-transition group-hover:scale-105" />
              {product.badge && (
                <span className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs tracking-wide ${product.badge === "Sale" ? "bg-destructive/10 text-destructive" : product.badge === "New" ? "bg-primary/10 text-primary" : "bg-accent text-accent-foreground"}`}>{product.badge}</span>
              )}
              {/* Quick actions */}
              <div className="absolute top-4 right-4 flex flex-col gap-2">
                <button onClick={(e) => { e.preventDefault(); toggleWishlist(product.id) }} className={`w-9 h-9 rounded-full backdrop-blur flex items-center justify-center boty-transition ${wishlist.includes(product.id) ? "bg-primary text-primary-foreground" : "bg-background/90 text-foreground opacity-0 group-hover:opacity-100"}`} aria-label="Wishlist">
                  <Heart className={`w-4 h-4 ${wishlist.includes(product.id) ? "fill-current" : ""}`} />
                </button>
                <button onClick={(e) => { e.preventDefault(); toggleCompare(product.id) }} className={`w-9 h-9 rounded-full backdrop-blur flex items-center justify-center boty-transition ${compare.includes(product.id) ? "bg-primary text-primary-foreground" : "bg-background/90 text-foreground opacity-0 group-hover:opacity-100"}`} aria-label="Compare">
                  <GitCompare className="w-4 h-4" />
                </button>
              </div>
              <button onClick={(e) => { e.preventDefault(); addItem({ id: product.id, name: product.name, description: product.description, price: product.price, image: product.image }) }} className="absolute bottom-4 right-4 w-12 h-12 rounded-full bg-background/90 backdrop-blur flex items-center justify-center opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 boty-transition boty-shadow" aria-label="Add to cart">
                <ShoppingBag className="w-5 h-5 text-foreground" />
              </button>
            </Link>
            <div className="p-5">
              <div className="flex items-center justify-between mb-1">
                <p className="text-[10px] uppercase tracking-[0.18em] text-primary capitalize">{product.category}</p>
                {product.rating && (
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Star className="w-3 h-3 fill-primary text-primary" />
                    <span>{product.rating}</span>
                  </div>
                )}
              </div>
              <Link href={`/product/${product.id}`}><h3 className="font-serif text-lg text-foreground hover:text-primary boty-transition mb-1">{product.name}</h3></Link>
              <p className="text-sm text-muted-foreground mb-3">{product.description}</p>
              <div className="flex items-center gap-2">
                <span className="font-medium text-foreground">${product.price}</span>
                {product.originalPrice && <span className="text-sm text-muted-foreground line-through">${product.originalPrice}</span>}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
