"use client"

import { useEffect, useState } from "react"
import { ArrowUp } from "lucide-react"

export function GoToTop() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const onScroll = () => {
      setVisible(window.scrollY > 500)
    }
    onScroll()
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  const scrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <button
      type="button"
      onClick={scrollTop}
      className={`lumina-gototop ${visible ? "is-visible" : ""}`}
      aria-label="Go to top"
      title="Back to top"
    >
      <ArrowUp className="w-5 h-5" />
    </button>
  )
}
