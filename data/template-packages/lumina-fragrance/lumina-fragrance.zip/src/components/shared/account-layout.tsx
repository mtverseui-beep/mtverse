"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Header } from "@/components/boty/header"
import { Footer } from "@/components/boty/footer"
import { LayoutDashboard, Package, MapPin, CreditCard, Heart, RefreshCw, Gift, Bell, User, Shield } from "lucide-react"

const nav = [
  { href: "/account", label: "Dashboard", icon: LayoutDashboard },
  { href: "/account/orders", label: "Orders", icon: Package },
  { href: "/account/addresses", label: "Addresses", icon: MapPin },
  { href: "/account/payment-methods", label: "Payment", icon: CreditCard },
  { href: "/account/wishlist", label: "Wishlist", icon: Heart },
  { href: "/account/subscriptions", label: "Subscriptions", icon: RefreshCw },
  { href: "/account/rewards", label: "Rewards", icon: Gift },
  { href: "/account/notifications", label: "Notifications", icon: Bell },
  { href: "/account/profile", label: "Profile", icon: User },
  { href: "/account/security", label: "Security", icon: Shield },
]

export function AccountLayout({ children, title }: { children: React.ReactNode; title: string }) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  return (
    <main className="min-h-screen lumina-page">
      <Header />
      <div className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="mb-8">
            <span className="text-sm tracking-[0.3em] uppercase text-primary block mb-1">My Account</span>
            <h1 className="font-serif text-3xl md:text-4xl text-foreground">{title}</h1>
          </div>

          <div className="grid lg:grid-cols-[240px_1fr] gap-8">
            {/* Sidebar */}
            <aside>
              <div className="bg-card rounded-3xl p-4 boty-shadow lg:sticky lg:top-24">
                <div className="flex items-center gap-3 p-3 mb-2 border-b border-border/50">
                  <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif text-lg">A</div>
                  <div>
                    <p className="font-medium text-foreground text-sm">Aurelia Brennan</p>
                    <p className="text-xs text-muted-foreground">Gold Member</p>
                  </div>
                </div>
                <button onClick={() => setOpen(!open)} className="lg:hidden w-full text-left px-3 py-2 text-sm text-foreground mb-2">{open ? "Hide menu" : "Show menu"}</button>
                <nav className={`space-y-1 ${open ? "block" : "hidden lg:block"}`}>
                  {nav.map((item) => {
                    const active = pathname === item.href
                    return (
                      <Link key={item.href} href={item.href} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm boty-transition ${active ? "bg-primary text-primary-foreground" : "text-foreground/70 hover:text-foreground hover:bg-background"}`}>
                        <item.icon className="w-4 h-4" /> {item.label}
                      </Link>
                    )
                  })}
                  <Link href="/sign-in" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-destructive hover:bg-destructive/5 boty-transition">Sign Out</Link>
                </nav>
              </div>
            </aside>

            {/* Content */}
            <div>{children}</div>
          </div>
        </div>
      </div>
      <Footer />
    </main>
  )
}
