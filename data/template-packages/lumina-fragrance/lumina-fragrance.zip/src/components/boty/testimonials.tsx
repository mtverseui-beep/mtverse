"use client"

import { useEffect, useRef, useState } from "react"

const testimonials = [
  {
    id: 1,
    name: "Sarah M.",
    location: "New York",
    rating: 5,
    text: "Cloud Veil has become my everyday signature. It wears so softly and the musk base lingers for hours without ever feeling loud.",
    product: "Cloud Veil Body Mist"
  },
  {
    id: 2,
    name: "Emma L.",
    location: "Los Angeles",
    rating: 5,
    text: "Finally, a hair perfume that doesn't dry my hair. Amber Bloom leaves the most beautiful trail whenever I move. Absolutely in love.",
    product: "Amber Bloom Hair Perfume"
  },
  {
    id: 3,
    name: "Jessica R.",
    location: "Chicago",
    rating: 5,
    text: "The Vanilla Hour mist is divine. Grown-up vanilla, never cloying. I layer it with the hair perfume for the long evenings.",
    product: "Vanilla Hour Fragrance Mist"
  },
  {
    id: 4,
    name: "Maria K.",
    location: "Miami",
    rating: 5,
    text: "I've tried countless body mists but nothing compares to the depth of Lumina. The layering duo changed my whole routine.",
    product: "Bloom Layering Duo"
  },
  {
    id: 5,
    name: "Sophie T.",
    location: "Seattle",
    rating: 5,
    text: "The packaging is beautiful and the bottles are refillable. I feel good choosing sustainable fragrance that also smells incredible.",
    product: "Soft Musk Travel Mini"
  },
  {
    id: 6,
    name: "Anna P.",
    location: "Boston",
    rating: 5,
    text: "The Calm Linen pillow mist has completely transformed my bedtime routine. I sleep so much better now. A small ritual I treasure.",
    product: "Calm Linen Pillow Mist"
  },
  {
    id: 7,
    name: "Claire B.",
    location: "Austin",
    rating: 5,
    text: "The Citrus Linen room spray is perfection. I spritz it before guests arrive and everyone asks what the scent is. So fresh and clean.",
    product: "Citrus Linen Room Spray"
  },
  {
    id: 8,
    name: "Lily W.",
    location: "Portland",
    rating: 5,
    text: "I love that Lumina is vegan and cruelty-free. Beautiful fragrances that align with my values. The discovery set was the perfect intro.",
    product: "Golden Fig Discovery Set"
  },
  {
    id: 9,
    name: "Rachel D.",
    location: "Denver",
    rating: 5,
    text: "The scent is so subtle and natural. No overpowering perfumes, just soft layered fragrance that feels like a second skin.",
    product: "Rose Milk Body Mist"
  }
]

const TestimonialCard = ({ testimonial }: { testimonial: typeof testimonials[0] }) => (
  <div className="rounded-3xl p-6 bg-background mb-4 flex-shrink-0 boty-shadow">
    {/* Quote */}
    <p className="text-foreground/80 leading-relaxed mb-4 text-pretty font-medium text-xl font-serif tracking-wide">
      &ldquo;{testimonial.text}&rdquo;
    </p>

    {/* Author */}
    <div className="flex items-start justify-between gap-2">
      <div>
        <p className="text-foreground text-sm font-bold">{testimonial.name}</p>
        <p className="text-xs text-muted-foreground">{testimonial.location}</p>
      </div>
      <span className="text-xs tracking-wide text-primary/70 bg-primary/5 px-2 py-1 rounded-full whitespace-nowrap">
        {testimonial.product}
      </span>
    </div>
  </div>
)

export function Testimonials() {
  const [headerVisible, setHeaderVisible] = useState(false)
  const headerRef = useRef<HTMLDivElement>(null)

  const column1 = [testimonials[0], testimonials[3], testimonials[6]]
  const column2 = [testimonials[1], testimonials[4], testimonials[7]]
  const column3 = [testimonials[2], testimonials[5], testimonials[8]]

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setHeaderVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (headerRef.current) {
      observer.observe(headerRef.current)
    }

    return () => {
      if (headerRef.current) {
        observer.unobserve(headerRef.current)
      }
    }
  }, [])

  return (
    <section className="py-24 bg-background overflow-hidden pb-24 pt-12">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16">
          <span className={`text-sm tracking-[0.3em] uppercase text-primary mb-4 block ${headerVisible ? 'animate-blur-in opacity-0' : 'opacity-0'}`} style={headerVisible ? { animationDelay: '0.2s', animationFillMode: 'forwards' } : {}}>
            Kind Words
          </span>
          <h2 className={`font-serif text-4xl leading-tight text-foreground text-balance md:text-7xl ${headerVisible ? 'animate-blur-in opacity-0' : 'opacity-0'}`} style={headerVisible ? { animationDelay: '0.4s', animationFillMode: 'forwards' } : {}}>
            Loved by thousands
          </h2>
        </div>

        {/* Scrolling Testimonials */}
        <div className="relative">
          {/* Gradient Overlays */}
          <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-background to-transparent z-10 pointer-events-none" />
          <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent z-10 pointer-events-none" />

          {/* Mobile - Single Column */}
          <div className="md:hidden h-[600px]">
            <div className="relative overflow-hidden h-full">
              <div className="animate-scroll-down hover:animate-scroll-down-slow">
                {[...testimonials, ...testimonials].map((testimonial, index) => (
                  <TestimonialCard key={`mobile-${testimonial.id}-${index}`} testimonial={testimonial} />
                ))}
              </div>
            </div>
          </div>

          {/* Desktop - Three Columns */}
          <div className="hidden md:grid md:grid-cols-3 gap-4 h-[600px]">
            {/* Column 1 - Scrolling Down */}
            <div className="relative overflow-hidden">
              <div className="animate-scroll-down hover:animate-scroll-down-slow">
                {[...column1, ...column1].map((testimonial, index) => (
                  <TestimonialCard key={`col1-${testimonial.id}-${index}`} testimonial={testimonial} />
                ))}
              </div>
            </div>

            {/* Column 2 - Scrolling Up */}
            <div className="relative overflow-hidden">
              <div className="animate-scroll-up hover:animate-scroll-up-slow">
                {[...column2, ...column2].map((testimonial, index) => (
                  <TestimonialCard key={`col2-${testimonial.id}-${index}`} testimonial={testimonial} />
                ))}
              </div>
            </div>

            {/* Column 3 - Scrolling Down */}
            <div className="relative overflow-hidden">
              <div className="animate-scroll-down hover:animate-scroll-down-slow">
                {[...column3, ...column3].map((testimonial, index) => (
                  <TestimonialCard key={`col3-${testimonial.id}-${index}`} testimonial={testimonial} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
