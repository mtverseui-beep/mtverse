"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { Recycle, Leaf, Flower2, Globe } from "lucide-react"
import { mediaConfig } from "@/lib/media"

const features = [
  {
    icon: Recycle,
    title: "Refillable Rituals",
    description: "Glass bottles designed to be refilled"
  },
  {
    icon: Leaf,
    title: "Vegan Formula",
    description: "No animal-derived ingredients"
  },
  {
    icon: Flower2,
    title: "Layerable Scents",
    description: "Mists, hair perfumes, room sprays"
  },
  {
    icon: Globe,
    title: "Ethical Sourcing",
    description: "Responsibly sourced fragrance oils"
  }
]

export function FeatureSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [isVideoVisible, setIsVideoVisible] = useState(false)
  const [headerVisible, setHeaderVisible] = useState(false)
  const bentoRef = useRef<HTMLDivElement>(null)
  const videoSectionRef = useRef<HTMLDivElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)

  const scentRitualVideo = mediaConfig.scentRitual.videoUrl
  const scentRitualPoster = mediaConfig.scentRitual.posterUrl
  const productCloseupVideo = mediaConfig.productCloseup.videoUrl
  const productCloseupPoster = mediaConfig.productCloseup.posterUrl
  const giftSetVideo = mediaConfig.giftSet.videoUrl
  const giftSetPoster = mediaConfig.giftSet.posterUrl

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    const videoObserver = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVideoVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    const headerObserver = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setHeaderVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (bentoRef.current) observer.observe(bentoRef.current)
    if (videoSectionRef.current) videoObserver.observe(videoSectionRef.current)
    if (headerRef.current) headerObserver.observe(headerRef.current)

    return () => {
      if (bentoRef.current) observer.unobserve(bentoRef.current)
      if (videoSectionRef.current) videoObserver.unobserve(videoSectionRef.current)
      if (headerRef.current) headerObserver.unobserve(headerRef.current)
    }
  }, [])

  return (
    <section className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Bento Grid */}
        <div
          ref={bentoRef}
          className="grid md:grid-cols-4 mb-20 md:grid-rows-[300px_300px] gap-6"
        >
          {/* Left Large Block - Video with Overlay Card */}
          <div
            className={`relative rounded-3xl overflow-hidden h-[500px] md:h-auto md:col-span-2 md:row-span-2 transition-all duration-700 ease-out ${
              isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
            }`}
            style={{ transitionDelay: '0ms' }}
          >
            {scentRitualVideo ? (
              <video
                autoPlay
                muted
                loop
                playsInline
                poster={scentRitualPoster}
                className="absolute inset-0 w-full h-full object-cover"
              >
                <source src={scentRitualVideo} type="video/mp4" />
              </video>
            ) : (
              <Image
                src={scentRitualPoster}
                alt="Fragrance ritual"
                fill
                className="object-cover"
              />
            )}
            {/* Overlay Card */}
            <div className="absolute bottom-8 left-8 right-8 bg-background p-6 shadow-lg rounded-xl boty-shadow">
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0">
                </div>
                <div>
                  <h3 className="text-xl text-foreground mb-2 font-medium">
                    Layered <span className="">Scent Rituals</span>
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Body mists, hair perfumes, and room sprays designed to be worn together for a deeper, more personal fragrance.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Top Right - Soft Luxury */}
          <div
            className={`rounded-3xl p-6 md:p-8 flex flex-col justify-center md:col-span-2 relative overflow-hidden transition-all duration-700 ease-out ${
              isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
            }`}
            style={{ transitionDelay: '100ms' }}
          >
            <Image
              src="https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1200&q=80"
              alt="Soft fragrance bottles"
              fill
              className="object-cover"
            />
            <div className="relative z-10">
              <h3 className="text-3xl md:text-4xl text-white mb-2">
                Soft Luxury
              </h3>
              <h3 className="text-2xl md:text-3xl text-white/70 mb-4">
                Everyday Wear
              </h3>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-white/90 text-sm">
                  <Leaf className="w-4 h-4 flex-shrink-0" />
                  <span>No Harsh Alcohols</span>
                </div>
                <div className="flex items-center gap-2 text-white/90 text-sm">
                  <Flower2 className="w-4 h-4 flex-shrink-0" />
                  <span>Layerable Fragrance</span>
                </div>
                <div className="flex items-center gap-2 text-white/90 text-sm">
                  <Globe className="w-4 h-4 flex-shrink-0" />
                  <span>Ethically Sourced</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Right - Refillable Packaging */}
          <div
            className={`rounded-3xl p-6 md:p-8 flex flex-col justify-center relative overflow-hidden md:col-span-2 transition-all duration-700 ease-out ${
              isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            {giftSetVideo ? (
              <video
                autoPlay
                muted
                loop
                playsInline
                poster={giftSetPoster}
                className="absolute inset-0 w-full h-full object-cover scale-[1.02]"
              >
                <source src={giftSetVideo} type="video/mp4" />
              </video>
            ) : (
              <Image
                src={giftSetPoster}
                alt="Gift set packaging"
                fill
                className="absolute inset-0 w-full h-full object-cover scale-[1.02]"
              />
            )}
            <div className="absolute inset-0 bg-transparent" />

            <div className="relative z-10 flex flex-col justify-center h-full text-left items-start">
              <div className="inline-flex items-center justify-center w-10 h-10 mb-3">
                <Recycle className="w-8 h-8 text-foreground" />
              </div>
              <h3 className="font-sans text-base mb-1 text-foreground">
                Refillable
              </h3>
              <h3 className="text-2xl md:text-3xl mb-2 text-foreground">
                Packaging
              </h3>
            </div>
          </div>
        </div>

        <div
          ref={videoSectionRef}
          className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center my-0 py-20"
        >
          {/* Video */}
          <div
            className={`relative aspect-[4/5] rounded-3xl overflow-hidden boty-shadow transition-all duration-700 ease-out ${
              isVideoVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
            }`}
          >
            {productCloseupVideo ? (
              <video
                autoPlay
                muted
                loop
                playsInline
                poster={productCloseupPoster}
                className="absolute inset-0 w-full h-full object-cover"
              >
                <source src={productCloseupVideo} type="video/mp4" />
              </video>
            ) : (
              <Image
                src={productCloseupPoster}
                alt="Fragrance close-up"
                fill
                className="object-cover"
              />
            )}
          </div>

          {/* Content */}
          <div
            ref={headerRef}
            className={`transition-all duration-700 ease-out ${
              isVideoVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '100ms' }}
          >
            <span className={`text-sm tracking-[0.3em] uppercase text-primary mb-4 block ${headerVisible ? 'animate-blur-in opacity-0' : 'opacity-0'}`} style={headerVisible ? { animationDelay: '0.2s', animationFillMode: 'forwards' } : {}}>
              Why Lumina
            </span>
            <h2 className={`font-serif text-4xl leading-tight text-foreground mb-6 text-balance md:text-7xl ${headerVisible ? 'animate-blur-in opacity-0' : 'opacity-0'}`} style={headerVisible ? { animationDelay: '0.4s', animationFillMode: 'forwards' } : {}}>
              Rituals that linger.
            </h2>
            <p className={`text-lg text-muted-foreground leading-relaxed mb-10 max-w-md ${headerVisible ? 'animate-blur-in opacity-0' : 'opacity-0'}`} style={headerVisible ? { animationDelay: '0.6s', animationFillMode: 'forwards' } : {}}>
              We believe fragrance should be a gentle ritual, not a loud statement.
              Every mist is crafted with intention and love for your everyday moments.
            </p>

            {/* Feature Cards */}
            <div className="grid sm:grid-cols-2 gap-4">
              {features.map((feature) => (
                <div
                  key={feature.title}
                  className="group p-5 boty-transition hover:scale-[1.02] rounded-md bg-background boty-shadow"
                >
                  <div className="inline-flex items-center justify-center w-10 h-10 rounded-full mb-3 group-hover:bg-primary/20 boty-transition bg-muted">
                    <feature.icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="font-medium text-foreground mb-1">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
