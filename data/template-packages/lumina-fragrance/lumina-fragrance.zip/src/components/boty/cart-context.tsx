"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface CartItem {
  id: string
  name: string
  description: string
  price: number
  quantity: number
  image: string
  size?: string
}

interface CartContextType {
  items: CartItem[]
  addItem: (item: Omit<CartItem, "quantity">) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  isOpen: boolean
  setIsOpen: (open: boolean) => void
  itemCount: number
  subtotal: number
  hydrated: boolean
}

const CartContext = createContext<CartContextType | undefined>(undefined)

// Use a versioned key so stale data from older schemas does not break the app.
const STORAGE_KEY = "lumina-cart-v1"

function isCartItems(value: unknown): value is CartItem[] {
  return Array.isArray(value) && value.every(
    (item) =>
      item &&
      typeof item === "object" &&
      typeof (item as CartItem).id === "string" &&
      typeof (item as CartItem).name === "string" &&
      typeof (item as CartItem).price === "number" &&
      typeof (item as CartItem).quantity === "number" &&
      typeof (item as CartItem).image === "string"
  )
}

function sanitizeItems(value: unknown): CartItem[] {
  if (!isCartItems(value)) return []
  return value
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [hydrated, setHydrated] = useState(false)

  // Load from localStorage on mount
  useEffect(() => {
    try {
      // Clean up stale keys from older cart schemas (zustand-based, etc.)
      const legacyKeys = ["lumina-cart", "lumina-wishlist", "lumina-compare", "lumina-recently-viewed"]
      legacyKeys.forEach((k) => {
        try { localStorage.removeItem(k) } catch { /* ignore */ }
      })

      const stored = localStorage.getItem(STORAGE_KEY)
      if (stored) {
        const parsed = JSON.parse(stored)
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setItems(sanitizeItems(parsed))
      }
    } catch {
      // ignore malformed JSON
    }
    setHydrated(true)
  }, [])

  // Persist to localStorage whenever items change
  useEffect(() => {
    if (hydrated) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
      } catch {
        // ignore quota errors
      }
    }
  }, [items, hydrated])

  const addItem = (newItem: Omit<CartItem, "quantity">) => {
    setItems(currentItems => {
      const existingItem = currentItems.find(item => item.id === newItem.id)
      if (existingItem) {
        return currentItems.map(item =>
          item.id === newItem.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...currentItems, { ...newItem, quantity: 1 }]
    })
    setIsOpen(true)
  }

  const removeItem = (id: string) => {
    setItems(currentItems => currentItems.filter(item => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity < 1) {
      removeItem(id)
      return
    }
    setItems(currentItems =>
      currentItems.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    )
  }

  const clearCart = () => {
    setItems([])
  }

  // Guard against any non-array state defensively
  const safeItems: CartItem[] = Array.isArray(items) ? items : []
  const itemCount = safeItems.reduce((sum, item) => sum + (item?.quantity ?? 0), 0)
  const subtotal = safeItems.reduce((sum, item) => sum + (item?.price ?? 0) * (item?.quantity ?? 0), 0)

  return (
    <CartContext.Provider
      value={{
        items: safeItems,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        isOpen,
        setIsOpen,
        itemCount,
        subtotal,
        hydrated,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
