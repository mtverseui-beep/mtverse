# Planna — Premium Task, Project & Team Productivity Dashboard

A production-ready Next.js 16 dashboard template for task management, project planning, team collaboration, time tracking, and productivity analytics. Built with TypeScript, Tailwind CSS 4, shadcn/ui, and Recharts.

> Rebranded and deeply upgraded from a small 8-page starter into a 150+ route premium SaaS dashboard template — preserving the original green/white visual identity, rounded card style, smooth animations, and calm productivity feel.

---

## Quick Start

```bash
bun install
bun run dev      # http://localhost:3000
bun run lint     # ESLint check
bun run build    # Production build
```

---

## Tech Stack

| Layer       | Choice                                            |
| ----------- | ------------------------------------------------- |
| Framework   | Next.js 16 (App Router, Turbopack)                |
| Language    | TypeScript 5 (strict)                             |
| Styling     | Tailwind CSS 4 + `tw-animate-css`                 |
| UI kit      | shadcn/ui (New York) + lucide-react icons         |
| Charts      | Recharts 2.15                                     |
| State       | Zustand (UI + tasks + timer, persisted)           |
| Forms       | React Hook Form + Zod                             |
| Drag-drop   | @dnd-kit/core + @dnd-kit/sortable                 |
| Tables      | @tanstack/react-table                             |
| Theme       | next-themes (light/dark)                          |
| Fonts       | Geist Sans + Geist Mono                           |

---

## Brand & Design System

- **Brand:** Planna
- **Tagline:** Plan, prioritize, accomplish.
- **Primary color:** Emerald green (`oklch(0.42 0.15 155)` in light, `oklch(0.55 0.18 155)` in dark)
- **Surface:** White cards on soft `oklch(0.98 0.005 120)` background
- **Radius:** 1rem (rounded-xl cards, rounded-lg controls)
- **Animations:** `slide-in-up`, `fade-in`, `scale-in`, `shimmer`, `card-lift` hover, `pulse-ring` for live indicators — all subtle, all matching the original Tasko feel

Tokens live in `src/app/globals.css` as CSS variables under `:root` and `.dark`, exposed to Tailwind via `@theme inline`. Charts use `--chart-1` through `--chart-5` (5-step emerald ramp).

---

## Project Structure

```
src/
├── app/
│   ├── (auth)/                # 10 auth pages (sign-in, sign-up, 2FA, onboarding, etc.)
│   ├── (dashboard)/           # 138 dashboard pages — the main app
│   │   ├── dashboard/         # 10 dashboard variants (overview, productivity, sprint, agency, executive…)
│   │   ├── tasks/             # 12 task pages (list, detail, my, overdue, recurring, calendar, timeline…)
│   │   ├── projects/          # 12 project pages (list, [id] with 8 tabs, templates, archived)
│   │   ├── kanban/            # Drag-and-drop board
│   │   ├── planning/          # 10 planning pages (sprint-board, backlog, roadmap, milestones, goals, OKRs…)
│   │   ├── calendar/          # 9 calendar pages (month, week, day, agenda, events, meetings, reminders…)
│   │   ├── team/              # 10 team pages (members, detail, departments, roles, permissions, workload…)
│   │   ├── time/              # 10 time pages (tracker, timesheets, entries, billable, focus, pomodoro…)
│   │   ├── analytics/         # 10 analytics pages (overview, tasks, projects, team, custom reports…)
│   │   ├── files/             # 6 file pages (manager, [id], shared, documents, attachments, templates)
│   │   ├── notes/             # 2 note pages (list, detail)
│   │   ├── knowledge/         # 2 knowledge pages (base, wiki)
│   │   ├── inbox/             # 2 inbox pages (list, [threadId])
│   │   ├── chat/, comments/, notifications/, mentions/, activity-log/, updates/, announcements/
│   │   ├── clients/           # 10 client/agency pages
│   │   ├── settings/          # 15 account/admin pages (profile, billing, api-keys, webhooks, audit-logs…)
│   │   └── help/              # 10 help pages (center, docs, faq, pricing, terms, privacy…)
│   ├── errors/                # 10 error/system pages (401, 403, 404, 408, 429, 500, 503, offline, maintenance, coming-soon)
│   ├── layout.tsx             # Root layout with ThemeProvider, CommandPalette, Toaster
│   ├── error.tsx              # Global runtime error boundary
│   ├── not-found.tsx          # Global 404
│   └── globals.css            # Design tokens + animations
│
├── components/
│   ├── layout/                # Sidebar, Header, CommandPalette, MobileNav, DashboardShell, BrandLogo
│   ├── common/                # StatCard, EmptyState, badges, skeletons
│   ├── charts/                # ChartCard, PlannaAreaChart, PlannaBarChart, PlannaLineChart, PlannaDonutChart, PlannaRadialChart, PlannaHeatmap, Sparkline
│   ├── task/                  # TasksTable (advanced data table with filters, sort, bulk actions, board view)
│   └── ui/                    # shadcn/ui components
│
├── lib/
│   ├── data/mock.ts           # All mock data (members, projects, tasks, sprints, time entries, clients, invoices, files, notes, goals, milestones, audit logs…)
│   ├── store/                 # Zustand stores: ui-store, task-store, timer-store (persisted)
│   ├── navigation.ts          # Central nav config (12 groups, 100+ destinations, quick actions)
│   ├── utils.ts               # cn, formatCurrency, formatDuration, timeAgo, relativeDay, pct, etc.
│   └── db.ts                  # Prisma client (optional, unused by mock data)
│
└── types/index.ts             # All TypeScript types (Task, Project, TeamMember, Sprint, CalendarEvent, TimeEntry, Notification, Client, Invoice, FileItem, Note, ApiKey, Webhook, Integration, AuditLog, Activity, Milestone, Goal, Announcement, ChatThread)
```

**Total: 158 routes** (138 dashboard + 10 auth + 10 error).

---

## Key Features

### Productivity
- **Command palette** (`Cmd+K` / `Ctrl+K`) — searches pages, tasks, projects, people, files, notes; supports recent pages, favorites, quick actions
- **Global breadcrumbs** — derived from the current path
- **Recently visited pages** — tracked in sidebar
- **Favorites** — star any page to pin it to the sidebar
- **Theme toggle** — light/dark, persisted
- **Mobile sidebar** — drawer pattern with overlay
- **Collapsible sidebar** — `72px` collapsed with tooltips

### Tasks
- Advanced table with: search, status/priority filters, sort by column, bulk select, bulk actions, pagination, list/board view toggle, export
- Task detail page with: subtasks (interactive checkboxes), comments (with composer), activity timeline, properties sidebar, attachments, blocked-by, quick actions
- 12 task variants: All, My, Assigned, Completed, Overdue, Recurring, Templates, Priorities, Labels, Calendar, Timeline, Detail

### Projects
- Grid + list views with filter tabs (All / Active / Planning / Completed)
- Project detail with 8 tabs: Overview, Tasks, Files, Timeline, Members, Discussions, Reports, Settings
- Project health badges (On Track / At Risk / Off Track)
- Budget tracking, progress, milestone tracking

### Kanban
- Full drag-and-drop using `@dnd-kit/core`
- 5 columns (Backlog → To Do → In Progress → Review → Done)
- Cards show: priority, labels, subtask progress, due date, comments count, attachments count, assignee avatar
- Drop indicators on hover

### Calendar
- Month, Week, Day, Agenda views
- Event detail page + create event form
- Color-coded by category (meeting, deadline, reminder, focus, personal, external)
- Meetings, Reminders, Deadlines as separate routes

### Team
- Member grid with online status, role, workload
- Member detail with tabs (Overview, Tasks, Activity, Files)
- Roles matrix, Permissions grid (interactive toggles)
- Workload heatmap, Availability calendar, Performance leaderboard

### Time Tracking
- Live timer (start/pause/reset) using persisted Zustand store
- Timesheets (weekly grid), manual entry, approval queue
- Billable vs non-billable analytics
- Pomodoro timer with circular SVG ring
- Focus mode with ambient sounds UI

### Analytics
- 10 dedicated analytics pages
- Reusable chart components with consistent green theme
- Date range selector, export buttons, fullscreen modals
- Custom report builder

### Clients / Agency
- Client cards, client detail with 5 tabs
- Projects, Tasks, Invoices, Portal (simulated client view)
- Proposals, Contracts, Approvals (interactive), Feedback (with NPS)

### Account / Settings
- 15 settings pages with shared sidebar
- Profile, Account, Workspace, Appearance (live theme preview)
- Notifications matrix (events × channels), Security (2FA UI), Sessions
- Billing, Subscription (plan comparison), Invoices
- API Keys (masked, scope chips, create dialog)
- Webhooks (CRUD + test), Integrations (8 connectors), Audit Logs

### Auth
- 10 auth pages with split-screen layout (brand panel + form)
- Sign in/up, forgot/reset password, verify email (OTP), 2FA, lock screen
- Invite accept, multi-step onboarding, workspace setup

### Error Pages
- 10 unique error pages — no reused layouts
- 401, 403, 404, 408, 429, 500, 503, Offline, Maintenance, Coming Soon

---

## How to Customize

### Change branding
1. Update `src/components/layout/brand-logo.tsx` (logo mark + wordmark)
2. Update `src/app/layout.tsx` metadata
3. Update `public/icon.svg` and `public/logo.svg`
4. Update `package.json` `name` field

### Change theme colors
All tokens live in `src/app/globals.css` under `:root` (light) and `.dark` (dark). Adjust the OKLCH values for `--primary`, `--accent`, `--chart-1` through `--chart-5` to retarget the palette. Everything else flows through Tailwind's `bg-primary`, `text-primary-foreground`, etc.

### Add a sidebar item
Add an entry to the relevant group in `src/lib/navigation.ts`. The sidebar, command palette, and breadcrumbs will all pick it up automatically.

```ts
// src/lib/navigation.ts
{
  title: "Tasks",
  items: [
    // ... existing items
    { label: "My New Page", href: "/tasks/new-page", icon: SomeIcon },
  ],
}
```

Then create `src/app/(dashboard)/tasks/new-page/page.tsx`:

```tsx
import { DashboardShell } from "@/components/layout/dashboard-shell"

export default function NewPage() {
  return (
    <DashboardShell title="My New Page" description="Page description.">
      {/* content */}
    </DashboardShell>
  )
}
```

### Add mock data
Extend `src/lib/data/mock.ts` with new typed entries. All pages already import from there.

### Add a Zustand store
Create `src/lib/store/<name>-store.ts` following the pattern in `ui-store.ts` (persisted) or `task-store.ts` (with actions).

---

## Build & Deploy

```bash
bun run lint     # Must pass — no errors
bun run build    # Production build to .next/
```

The project is configured for Vercel out of the box. No env vars required for the mock-data demo.

---

## License

MIT — use this template for any commercial project. Attribution appreciated but not required.

---

**Planna** — built with care for teams who want their tools to feel calm, premium, and fast.
