"use client"

import { useEffect } from "react"
import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import {
  ServerCrash,
  RefreshCw,
  ArrowRight,
  Activity,
  Bug,
} from "lucide-react"

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // In production this is where you'd ship the error to Sentry / Logflare.
    console.error(error)
  }, [error])

  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-2xl animate-fade-in">
          <div className="rounded-2xl overflow-hidden border border-border shadow-sm">
            {/* Terminal header */}
            <div className="flex items-center gap-2 px-4 py-2.5 bg-muted/60 border-b border-border">
              <span className="size-2.5 rounded-full bg-destructive/70" />
              <span className="size-2.5 rounded-full bg-warning/70" />
              <span className="size-2.5 rounded-full bg-success/70" />
              <span className="ml-2 text-xs text-muted-foreground font-mono">
                planna — runtime error
              </span>
            </div>

            <div className="bg-card p-6 sm:p-8 font-mono text-sm">
              <div className="flex items-start gap-3 mb-4">
                <div className="size-10 rounded-lg bg-destructive/10 text-destructive flex items-center justify-center shrink-0">
                  <ServerCrash className="size-5" strokeWidth={1.75} />
                </div>
                <div>
                  <div className="inline-flex items-center gap-1.5 text-[11px] font-medium text-destructive bg-destructive/10 px-2 py-0.5 rounded-full mb-1.5">
                    <span className="size-1.5 rounded-full bg-destructive" />
                    Unexpected error
                  </div>
                  <h1 className="text-xl font-semibold tracking-tight font-sans">
                    Something went wrong
                  </h1>
                </div>
              </div>

              <div className="rounded-lg bg-muted/40 p-3.5 text-xs space-y-1">
                <p>
                  <span className="text-muted-foreground">[error]</span>{" "}
                  <span className="text-destructive">
                    {error.name || "ApplicationError"}
                  </span>
                </p>
                <p className="break-words">
                  <span className="text-muted-foreground">[message]</span>{" "}
                  {error.message || "An unexpected error occurred while rendering this page."}
                </p>
                {error.digest && (
                  <p>
                    <span className="text-muted-foreground">[digest]</span>{" "}
                    <span className="text-primary">#{error.digest}</span>
                  </p>
                )}
              </div>

              <p className="mt-5 text-sm text-muted-foreground font-sans leading-relaxed">
                Our team has been notified. You can try again — your data is safe.
                If the problem persists, please reach out.
              </p>

              <div className="mt-6 flex flex-col sm:flex-row gap-3 font-sans">
                <Button size="lg" className="flex-1" onClick={reset}>
                  <RefreshCw className="size-4" />
                  Try again
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/dashboard">
                    <ArrowRight className="size-4" />
                    Go to dashboard
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <a
                    href="https://status.planna.app"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Activity className="size-4" />
                    Status
                  </a>
                </Button>
              </div>
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-4 flex items-center justify-center gap-1.5">
            <Bug className="size-3" />
            Reference this error as{" "}
            <code className="px-1.5 py-0.5 rounded bg-muted font-mono text-foreground">
              #{error.digest ?? "unknown"}
            </code>{" "}
            when contacting{" "}
            <a
              href="mailto:hello@planna.app"
              className="text-primary font-medium hover:underline"
            >
              hello@planna.app
            </a>
            .
          </p>
        </div>
      </section>
    </main>
  )
}
