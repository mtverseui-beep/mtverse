import NotFoundPage from "@/app/errors/404/page"

export default function NotFound() {
  return <NotFoundPage />
}
