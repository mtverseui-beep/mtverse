import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Toaster } from "@/components/ui/sonner"
import { ThemeProvider } from "@/components/theme-provider"
import { CommandPalette } from "@/components/layout/command-palette"
import { UiStoreHydration } from "@/components/layout/ui-store-hydration"
import "./globals.css"

const geist = Geist({
  subsets: ["latin"],
  variable: "--font-geist-sans",
  display: "swap",
})

const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
  display: "swap",
})

export const metadata: Metadata = {
  title: {
    default: "Planna — Task, Project & Team Productivity",
    template: "%s · Planna",
  },
  description:
    "Planna is a premium task management, project planning, and team collaboration dashboard for modern product teams.",
  applicationName: "Planna",
  authors: [{ name: "Planna Labs" }],
  keywords: [
    "task management",
    "project management",
    "team collaboration",
    "productivity dashboard",
    "kanban",
    "sprint planning",
    "time tracking",
  ],
  openGraph: {
    title: "Planna — Task, Project & Team Productivity",
    description:
      "Premium task management, project planning, and team collaboration dashboard for modern product teams.",
    type: "website",
    siteName: "Planna",
  },
  twitter: {
    card: "summary_large_image",
    title: "Planna — Task, Project & Team Productivity",
    description:
      "Premium task management, project planning, and team collaboration dashboard for modern product teams.",
  },
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
    ],
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#10b981" },
    { media: "(prefers-color-scheme: dark)", color: "#052e1d" },
  ],
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geist.variable} ${geistMono.variable} font-sans antialiased`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          storageKey="planna-theme"
          enableSystem={false}
          disableTransitionOnChange
        >
          <UiStoreHydration />
          {children}
          <CommandPalette />
          <Toaster richColors position="bottom-right" />
        </ThemeProvider>
      </body>
    </html>
  )
}
