"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  ArrowRight,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  LogOut,
} from "lucide-react"
import { toast } from "sonner"

export default function LockScreenPage() {
  const [show, setShow] = useState(false)
  const [loading, setLoading] = useState(false)
  const [password, setPassword] = useState("")

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!password) {
      toast.error("Please enter your password to unlock.")
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      toast.success("Welcome back! Your session is unlocked.")
    }, 1100)
  }

  return (
    <div className="space-y-6">
      <header className="text-center space-y-4">
        <div className="relative inline-block">
          <Avatar className="size-20 border-4 border-background shadow-md">
            <AvatarImage
              src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop"
              alt="Jessin Sam"
            />
            <AvatarFallback>JS</AvatarFallback>
          </Avatar>
          <span className="absolute bottom-1 right-1 size-3.5 rounded-full bg-success ring-2 ring-background" />
        </div>
        <div className="space-y-1">
          <h1 className="text-2xl font-semibold tracking-tight">Jessin Sam</h1>
          <p className="text-sm text-muted-foreground">jessin@planna.app</p>
        </div>
        <div className="inline-flex items-center gap-1.5 text-xs font-medium text-warning bg-warning/10 px-2.5 py-1 rounded-full">
          <Lock className="size-3.5" />
          Your session is locked
        </div>
      </header>

      <p className="text-center text-sm text-muted-foreground">
        Enter your password to pick up where you left off.
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="password" className="sr-only">
            Password
          </Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              id="password"
              type={show ? "text" : "password"}
              autoComplete="current-password"
              placeholder="Enter your password"
              className="pl-9 pr-9 h-10"
              autoFocus
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              aria-label={show ? "Hide password" : "Show password"}
            >
              {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </div>

        <Button type="submit" className="w-full h-10" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Unlocking…
            </>
          ) : (
            <>
              Unlock session
              <ArrowRight className="size-4" />
            </>
          )}
        </Button>
      </form>

      <div className="space-y-2">
        <Link
          href="/forgot-password"
          className="block text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          Forgot password?
        </Link>
        <Link
          href="/sign-in"
          className="inline-flex items-center justify-center gap-2 w-full text-sm font-medium text-primary hover:underline"
        >
          <LogOut className="size-4" />
          Sign in as a different user
        </Link>
      </div>
    </div>
  )
}
