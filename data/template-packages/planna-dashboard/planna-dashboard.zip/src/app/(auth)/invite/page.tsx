"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  ArrowRight,
  Building2,
  Check,
  Clock,
  Loader2,
  Sparkles,
  X,
} from "lucide-react"
import { toast } from "sonner"

export default function InvitePage() {
  const [accepting, setAccepting] = useState(false)
  const [declining, setDeclining] = useState(false)
  const [done, setDone] = useState<"accepted" | "declined" | null>(null)

  function accept() {
    setAccepting(true)
    setTimeout(() => {
      setAccepting(false)
      setDone("accepted")
      toast.success("Welcome to Northwind Labs!")
    }, 1100)
  }
  function decline() {
    setDeclining(true)
    setTimeout(() => {
      setDeclining(false)
      setDone("declined")
      toast("Invitation declined.")
    }, 800)
  }

  if (done === "accepted") {
    return (
      <div className="space-y-6 text-center">
        <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-primary/10 text-primary animate-scale-in">
          <Check className="size-7" />
        </div>
        <header className="space-y-1.5">
          <h1 className="text-2xl font-semibold tracking-tight">You&rsquo;re in!</h1>
          <p className="text-sm text-muted-foreground">
            You&rsquo;ve joined <strong className="text-foreground">Northwind Labs</strong> as a
            Product Designer. Let&rsquo;s get your workspace set up.
          </p>
        </header>
        <Button asChild className="w-full h-10">
          <Link href="/onboarding">
            Continue to onboarding
            <ArrowRight className="size-4" />
          </Link>
        </Button>
      </div>
    )
  }

  if (done === "declined") {
    return (
      <div className="space-y-6 text-center">
        <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-muted text-muted-foreground animate-scale-in">
          <X className="size-7" />
        </div>
        <header className="space-y-1.5">
          <h1 className="text-2xl font-semibold tracking-tight">Invitation declined</h1>
          <p className="text-sm text-muted-foreground">
            No worries — the invitation has been dismissed. You can request a new
            invite from your team admin at any time.
          </p>
        </header>
        <Button asChild variant="outline" className="w-full h-10">
          <Link href="/sign-in">Back to sign in</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1.5 text-center">
        <div className="inline-flex items-center gap-1.5 text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full mb-2">
          <Sparkles className="size-3.5" />
          You&rsquo;re invited
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">
          Join Northwind Labs on Planna
        </h1>
        <p className="text-sm text-muted-foreground">
          Accept this invitation to start collaborating with your team.
        </p>
      </header>

      {/* Inviter card */}
      <div className="rounded-xl border border-border bg-card p-4 space-y-4 shadow-sm">
        <div className="flex items-center gap-3">
          <Avatar className="size-11">
            <AvatarImage
              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&h=128&fit=crop"
              alt="Zara Marlowe"
            />
            <AvatarFallback>ZM</AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium truncate">Zara Marlowe</p>
            <p className="text-xs text-muted-foreground truncate">
              Head of Product · invited you
            </p>
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            2h ago
          </span>
        </div>

        <Separator />

        <dl className="grid grid-cols-2 gap-3 text-sm">
          <div className="space-y-0.5">
            <dt className="text-xs text-muted-foreground flex items-center gap-1">
              <Building2 className="size-3" />
              Workspace
            </dt>
            <dd className="font-medium">Northwind Labs</dd>
          </div>
          <div className="space-y-0.5">
            <dt className="text-xs text-muted-foreground flex items-center gap-1">
              <Sparkles className="size-3" />
              Role
            </dt>
            <dd className="font-medium">Product Designer</dd>
          </div>
          <div className="space-y-0.5">
            <dt className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="size-3" />
              Expires in
            </dt>
            <dd className="font-medium">6 days</dd>
          </div>
          <div className="space-y-0.5">
            <dt className="text-xs text-muted-foreground">Team size</dt>
            <dd className="font-medium">28 members</dd>
          </div>
        </dl>

        <div className="rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">
          &ldquo;Hi! I&rsquo;d love to have you on the design team — we&rsquo;re
          rebuilding our onboarding flow and your input would be invaluable.
          Looking forward to working with you!&rdquo;
        </div>
      </div>

      <div className="space-y-3">
        <Button
          type="button"
          className="w-full h-10"
          onClick={accept}
          disabled={accepting || declining}
        >
          {accepting ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Accepting…
            </>
          ) : (
            <>
              Accept invitation
              <ArrowRight className="size-4" />
            </>
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          className="w-full h-10"
          onClick={decline}
          disabled={accepting || declining}
        >
          Decline
        </Button>
      </div>

      <p className="text-center text-xs text-muted-foreground">
        By accepting, you agree to Planna&rsquo;s{" "}
        <a href="#" className="text-primary font-medium hover:underline">
          Terms
        </a>{" "}
        and acknowledge the workspace&rsquo;s data policies.
      </p>
    </div>
  )
}
