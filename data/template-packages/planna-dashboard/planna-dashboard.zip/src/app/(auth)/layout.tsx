import type { Metadata } from "next"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star } from "lucide-react"

export const metadata: Metadata = {
  title: "Authentication",
  description: "Sign in to Planna or create a new account.",
}

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen w-full grid lg:grid-cols-2">
      {/* ============================================================
          LEFT — BRAND PANEL (hidden on mobile, visible on lg+)
          ============================================================ */}
      <aside className="relative hidden lg:flex flex-col justify-between overflow-hidden bg-primary text-primary-foreground p-12">
        {/* Decorative background — soft layered radial glows, no purple/blue */}
        <div
          aria-hidden
          className="absolute inset-0 opacity-90"
          style={{
            background:
              "radial-gradient(circle at 20% 20%, color-mix(in oklch, var(--primary-foreground) 18%, transparent), transparent 45%), radial-gradient(circle at 80% 70%, color-mix(in oklch, var(--accent) 40%, transparent), transparent 50%)",
          }}
        />
        {/* Subtle grid lines */}
        <div
          aria-hidden
          className="absolute inset-0 opacity-[0.08]"
          style={{
            backgroundImage:
              "linear-gradient(to right, currentColor 1px, transparent 1px), linear-gradient(to bottom, currentColor 1px, transparent 1px)",
            backgroundSize: "48px 48px",
          }}
        />

        {/* Top — Logo + tagline */}
        <div className="relative z-10">
          <BrandLogo
            className="[&_span]:text-primary-foreground [&_div:first-child]:bg-primary-foreground [&_div:first-child>div]:bg-primary [&_div:first-child>div:last-child]:border-primary"
            size="lg"
          />
          <p className="mt-6 text-primary-foreground/80 text-lg max-w-sm leading-relaxed">
            Plan, prioritize, accomplish. The calm productivity workspace for
            modern product teams.
          </p>
        </div>

        {/* Middle — Product preview card (floating) */}
        <div className="relative z-10 my-12">
          <div className="relative animate-float">
            {/* Floating mini "task" cards */}
            <div className="absolute -top-6 -left-6 w-44 rounded-xl bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/15 p-3 shadow-xl rotate-[-6deg]">
              <div className="flex items-center gap-2">
                <span className="size-2 rounded-full bg-primary-foreground/70" />
                <span className="text-xs font-medium text-primary-foreground/90">
                  Sprint 24 · In progress
                </span>
              </div>
              <div className="mt-2 h-1.5 rounded-full bg-primary-foreground/15 overflow-hidden">
                <div className="h-full w-2/3 rounded-full bg-primary-foreground/80" />
              </div>
              <p className="mt-2 text-[11px] text-primary-foreground/70">
                12 of 18 tasks done
              </p>
            </div>

            <div className="ml-24 w-56 rounded-xl bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/15 p-3 shadow-xl rotate-[4deg]">
              <p className="text-xs font-medium text-primary-foreground/90">
                Today&rsquo;s focus
              </p>
              <ul className="mt-2 space-y-1.5">
                {[
                  "Ship onboarding v2",
                  "Review pull requests",
                  "Design system audit",
                ].map((t) => (
                  <li
                    key={t}
                    className="flex items-center gap-2 text-[11px] text-primary-foreground/80"
                  >
                    <span className="size-3 rounded-sm border border-primary-foreground/40" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom — Testimonial */}
        <figure className="relative z-10 max-w-md">
          <div className="flex gap-0.5 text-primary-foreground mb-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="size-4 fill-current" />
            ))}
          </div>
          <blockquote className="text-lg leading-relaxed text-primary-foreground font-medium">
            &ldquo;Planna replaced three tools for us. Sprints ship on time, the
            team stays focused, and I finally have a single source of truth
            across product and engineering.&rdquo;
          </blockquote>
          <figcaption className="mt-4 flex items-center gap-3">
            <Avatar className="size-9 border-2 border-primary-foreground/30">
              <AvatarImage src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=128&h=128&fit=crop" alt="Naomi Chen" />
              <AvatarFallback>NC</AvatarFallback>
            </Avatar>
            <div className="text-sm">
              <p className="font-semibold text-primary-foreground">Naomi Chen</p>
              <p className="text-primary-foreground/70 text-xs">
                VP Product, Northwind Labs
              </p>
            </div>
          </figcaption>
        </figure>
      </aside>

      {/* ============================================================
          RIGHT — FORM PANEL (always visible)
          ============================================================ */}
      <main className="relative flex flex-col min-h-screen">
        {/* Mobile brand header */}
        <div className="lg:hidden p-6 border-b border-border">
          <BrandLogo size="md" />
        </div>

        <div className="flex-1 flex items-center justify-center p-6 sm:p-10">
          <div className="w-full max-w-md animate-fade-in">{children}</div>
        </div>

        {/* Footer */}
        <footer className="px-6 sm:px-10 py-6 border-t border-border text-xs text-muted-foreground flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>&copy; {new Date().getFullYear()} Planna Labs. All rights reserved.</p>
          <p>
            Need help?{" "}
            <a
              href="mailto:hello@planna.app"
              className="text-primary font-medium hover:underline"
            >
              hello@planna.app
            </a>
          </p>
        </footer>
      </main>
    </div>
  )
}
