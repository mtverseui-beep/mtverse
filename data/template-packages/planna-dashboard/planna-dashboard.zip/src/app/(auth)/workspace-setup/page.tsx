"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import {
  ArrowRight,
  Check,
  Globe,
  Loader2,
  Sparkles,
  Users,
} from "lucide-react"
import { toast } from "sonner"

interface Size {
  id: string
  label: string
  hint: string
}

const SIZES: Size[] = [
  { id: "solo", label: "Just me", hint: "1 person" },
  { id: "small", label: "2–10", hint: "Small team" },
  { id: "medium", label: "11–50", hint: "Growing team" },
  { id: "large", label: "51+", hint: "Company-wide" },
]

export default function WorkspaceSetupPage() {
  const [name, setName] = useState("")
  const [size, setSize] = useState<string>("")
  const [loading, setLoading] = useState(false)

  const subdomain = useMemo(() => {
    const slug = name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 24)
    return slug || "your-team"
  }, [name])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!name.trim()) {
      toast.error("Please name your workspace.")
      return
    }
    if (!size) {
      toast.error("Please pick a team size.")
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      toast.success("Workspace created! Redirecting to your dashboard…")
    }, 1200)
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1.5">
        <div className="inline-flex items-center gap-1.5 text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full w-fit">
          <Sparkles className="size-3.5" />
          Step 1 of 1
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">Set up your workspace</h1>
        <p className="text-sm text-muted-foreground">
          A workspace is your team&rsquo;s shared home in Planna. You can rename it
          and invite members later.
        </p>
      </header>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="space-y-1.5">
          <Label htmlFor="name">Workspace name</Label>
          <Input
            id="name"
            placeholder="e.g. Northwind Labs"
            className="h-10"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoFocus
          />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="subdomain">Workspace URL</Label>
          <div className="flex items-stretch">
            <Input
              id="subdomain"
              readOnly
              value={subdomain}
              className="h-10 rounded-r-none font-mono text-sm bg-muted/40"
            />
            <div className="flex items-center px-3 rounded-r-md border border-l-0 border-input bg-muted text-sm text-muted-foreground">
              .planna.app
            </div>
          </div>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Globe className="size-3" />
            This is the address your team will use to sign in.
          </p>
        </div>

        <div className="space-y-2">
          <Label>Team size</Label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {SIZES.map((s) => {
              const selected = size === s.id
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSize(s.id)}
                  className={cn(
                    "rounded-lg border p-3 text-left transition-all hover:shadow-sm",
                    selected
                      ? "border-primary bg-primary/5 ring-1 ring-primary"
                      : "border-border hover:border-primary/40"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <Users
                      className={cn(
                        "size-4",
                        selected ? "text-primary" : "text-muted-foreground"
                      )}
                    />
                    {selected && <Check className="size-3.5 text-primary" />}
                  </div>
                  <p className="mt-1.5 text-sm font-medium">{s.label}</p>
                  <p className="text-[11px] text-muted-foreground">{s.hint}</p>
                </button>
              )
            })}
          </div>
        </div>

        <Button type="submit" className="w-full h-10" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Creating workspace…
            </>
          ) : (
            <>
              Create workspace
              <ArrowRight className="size-4" />
            </>
          )}
        </Button>
      </form>

      <p className="text-center text-xs text-muted-foreground">
        By creating a workspace you agree to Planna&rsquo;s{" "}
        <a href="#" className="text-primary font-medium hover:underline">
          Terms
        </a>{" "}
        and{" "}
        <a href="#" className="text-primary font-medium hover:underline">
          Privacy Policy
        </a>
        . You can delete your workspace at any time.
      </p>

      <Link
        href="/sign-in"
        className="block text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        Already part of a workspace? Sign in
      </Link>
    </div>
  )
}
