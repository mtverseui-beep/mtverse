"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from "@/components/ui/input-otp"
import {
  ArrowLeft,
  KeyRound,
  Loader2,
  RefreshCw,
  ShieldCheck,
  Smartphone,
} from "lucide-react"
import { toast } from "sonner"

export default function TwoFactorPage() {
  const [mode, setMode] = useState<"app" | "backup">("app")
  const [code, setCode] = useState("")
  const [backup, setBackup] = useState("")
  const [loading, setLoading] = useState(false)
  const [seconds, setSeconds] = useState(60)

  useEffect(() => {
    if (seconds <= 0) return
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000)
    return () => clearTimeout(t)
  }, [seconds])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (mode === "app" && code.length !== 6) {
      toast.error("Please enter the 6-digit code from your authenticator app.")
      return
    }
    if (mode === "backup" && backup.trim().length < 8) {
      toast.error("Please enter a valid backup code.")
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      toast.success("Verified! Taking you to your dashboard…")
    }, 1100)
  }

  function resend() {
    if (seconds > 0) return
    setSeconds(60)
    setCode("")
    toast.success("A new code has been generated.")
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1.5 text-center">
        <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-primary/10 text-primary animate-scale-in mb-2">
          <ShieldCheck className="size-7" />
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">Two-factor authentication</h1>
        <p className="text-sm text-muted-foreground">
          {mode === "app"
            ? "Enter the 6-digit code from your authenticator app to continue."
            : "Enter one of your single-use backup codes to continue."}
        </p>
      </header>

      {/* Mode switch */}
      <div className="grid grid-cols-2 gap-1 p-1 rounded-lg bg-muted/60 text-sm">
        <button
          type="button"
          onClick={() => setMode("app")}
          className={`flex items-center justify-center gap-1.5 h-9 rounded-md font-medium transition-all ${
            mode === "app"
              ? "bg-card text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Smartphone className="size-3.5" />
          Authenticator
        </button>
        <button
          type="button"
          onClick={() => setMode("backup")}
          className={`flex items-center justify-center gap-1.5 h-9 rounded-md font-medium transition-all ${
            mode === "backup"
              ? "bg-card text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <KeyRound className="size-3.5" />
          Backup code
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {mode === "app" ? (
          <div className="flex flex-col items-center gap-2">
            <InputOTP
              maxLength={6}
              value={code}
              onChange={(v) => setCode(v)}
              containerClassName="justify-center"
            >
              <InputOTPGroup>
                <InputOTPSlot index={0} className="size-12 text-base first:rounded-l-lg" />
                <InputOTPSlot index={1} className="size-12 text-base" />
                <InputOTPSlot index={2} className="size-12 text-base" />
              </InputOTPGroup>
              <InputOTPSeparator />
              <InputOTPGroup>
                <InputOTPSlot index={3} className="size-12 text-base" />
                <InputOTPSlot index={4} className="size-12 text-base" />
                <InputOTPSlot index={5} className="size-12 text-base last:rounded-r-lg" />
              </InputOTPGroup>
            </InputOTP>
          </div>
        ) : (
          <div className="space-y-1.5">
            <Label htmlFor="backup">Backup code</Label>
            <Input
              id="backup"
              autoComplete="one-time-code"
              placeholder="XXXX-XXXX"
              className="h-10 font-mono tracking-widest text-center uppercase"
              value={backup}
              onChange={(e) => setBackup(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Backup codes are 8 characters, dashes optional. Each code can only be
              used once.
            </p>
          </div>
        )}

        <Button type="submit" className="w-full h-10" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Verifying…
            </>
          ) : (
            <>
              <ShieldCheck className="size-4" />
              Verify & continue
            </>
          )}
        </Button>
      </form>

      <div className="text-center text-sm text-muted-foreground space-y-2">
        {mode === "app" && (
          <div>
            Didn&rsquo;t get the code?{" "}
            {seconds > 0 ? (
              <span className="font-medium text-foreground">
                Resend in {seconds}s
              </span>
            ) : (
              <button
                type="button"
                onClick={resend}
                className="inline-flex items-center gap-1 font-medium text-primary hover:underline"
              >
                <RefreshCw className="size-3.5" />
                Resend
              </button>
            )}
          </div>
        )}
        {mode === "app" && (
          <button
            type="button"
            onClick={() => setMode("backup")}
            className="block mx-auto font-medium text-primary hover:underline"
          >
            Use a backup code instead
          </button>
        )}
        {mode === "backup" && (
          <button
            type="button"
            onClick={() => setMode("app")}
            className="block mx-auto font-medium text-primary hover:underline"
          >
            Use authenticator app instead
          </button>
        )}
      </div>

      <Link
        href="/sign-in"
        className="inline-flex items-center justify-center gap-2 w-full text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="size-4" />
        Back to sign in
      </Link>
    </div>
  )
}
