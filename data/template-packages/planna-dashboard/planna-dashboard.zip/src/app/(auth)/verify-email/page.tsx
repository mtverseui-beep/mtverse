"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from "@/components/ui/input-otp"
import {
  ArrowLeft,
  Loader2,
  MailCheck,
  RefreshCw,
  ShieldCheck,
} from "lucide-react"
import { toast } from "sonner"

export default function VerifyEmailPage() {
  const [code, setCode] = useState("")
  const [loading, setLoading] = useState(false)
  const [seconds, setSeconds] = useState(60)

  useEffect(() => {
    if (seconds <= 0) return
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000)
    return () => clearTimeout(t)
  }, [seconds])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (code.length !== 6) {
      toast.error("Please enter the 6-digit code.")
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      toast.success("Email verified! Welcome to Planna.")
    }, 1100)
  }

  function resend() {
    if (seconds > 0) return
    setSeconds(60)
    setCode("")
    toast.success("A new code has been sent to your inbox.")
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1.5 text-center">
        <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-primary/10 text-primary animate-scale-in mb-2">
          <MailCheck className="size-7" />
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">Verify your email</h1>
        <p className="text-sm text-muted-foreground">
          We sent a 6-digit code to{" "}
          <span className="font-medium text-foreground">jessin@planna.app</span>.
          Enter it below to confirm your account.
        </p>
      </header>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex flex-col items-center gap-2">
          <InputOTP
            maxLength={6}
            value={code}
            onChange={(v) => setCode(v)}
            containerClassName="justify-center"
          >
            <InputOTPGroup>
              <InputOTPSlot index={0} className="size-12 text-base first:rounded-l-lg last:rounded-r-lg" />
              <InputOTPSlot index={1} className="size-12 text-base" />
              <InputOTPSlot index={2} className="size-12 text-base" />
            </InputOTPGroup>
            <InputOTPSeparator />
            <InputOTPGroup>
              <InputOTPSlot index={3} className="size-12 text-base" />
              <InputOTPSlot index={4} className="size-12 text-base" />
              <InputOTPSlot index={5} className="size-12 text-base first:rounded-l-none last:rounded-r-lg" />
            </InputOTPGroup>
          </InputOTP>
          <p className="text-xs text-muted-foreground">
            Tip: the code expires in 10 minutes.
          </p>
        </div>

        <Button type="submit" className="w-full h-10" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Verifying…
            </>
          ) : (
            <>
              <ShieldCheck className="size-4" />
              Verify email
            </>
          )}
        </Button>
      </form>

      <div className="text-center text-sm text-muted-foreground">
        Didn&rsquo;t get the code?{" "}
        {seconds > 0 ? (
          <span className="font-medium text-foreground">
            Resend in {seconds}s
          </span>
        ) : (
          <button
            type="button"
            onClick={resend}
            className="inline-flex items-center gap-1 font-medium text-primary hover:underline"
          >
            <RefreshCw className="size-3.5" />
            Resend code
          </button>
        )}
      </div>

      <Link
        href="/sign-up"
        className="inline-flex items-center justify-center gap-2 w-full text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="size-4" />
        Use a different email
      </Link>
    </div>
  )
}
