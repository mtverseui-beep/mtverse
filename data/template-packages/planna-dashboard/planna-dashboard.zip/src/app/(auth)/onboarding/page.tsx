"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import {
  ArrowLeft,
  ArrowRight,
  Check,
  FolderPlus,
  Loader2,
  Palette,
  Rocket,
  User,
} from "lucide-react"
import { toast } from "sonner"

interface Role {
  id: string
  label: string
  description: string
  icon: typeof User
}

const ROLES: Role[] = [
  {
    id: "pm",
    label: "Product Manager",
    description: "Plan roadmaps, sprints, and priorities",
    icon: Rocket,
  },
  {
    id: "engineer",
    label: "Engineer",
    description: "Pick up tasks, ship code, track time",
    icon: User,
  },
  {
    id: "designer",
    label: "Designer",
    description: "Design reviews, creative workflows",
    icon: Palette,
  },
  {
    id: "lead",
    label: "Team Lead",
    description: "Manage members and oversee delivery",
    icon: User,
  },
]

export default function OnboardingPage() {
  const [step, setStep] = useState(0)
  const [name, setName] = useState("Jessin")
  const [role, setRole] = useState<string>("")
  const [project, setProject] = useState("")
  const [loading, setLoading] = useState(false)

  const steps = ["Welcome", "Your role", "First project"]

  function next() {
    if (step === 0 && !name.trim()) {
      toast.error("Please enter your name.")
      return
    }
    if (step === 1 && !role) {
      toast.error("Please pick a role that fits you best.")
      return
    }
    if (step === 2 && !project.trim()) {
      toast.error("Give your first project a name.")
      return
    }
    if (step < 2) {
      setStep((s) => s + 1)
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      toast.success("All set! Taking you to your workspace…")
    }, 1200)
  }

  return (
    <div className="space-y-6">
      {/* Step indicator */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          {steps.map((label, i) => {
            const done = i < step
            const active = i === step
            return (
              <div key={label} className="flex-1 flex items-center gap-2">
                <div
                  className={cn(
                    "flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold transition-all",
                    done && "bg-primary text-primary-foreground",
                    active && "bg-primary text-primary-foreground ring-4 ring-primary/15",
                    !done && !active && "bg-muted text-muted-foreground"
                  )}
                >
                  {done ? <Check className="size-3.5" /> : i + 1}
                </div>
                <span
                  className={cn(
                    "text-xs font-medium hidden sm:block",
                    active ? "text-foreground" : "text-muted-foreground"
                  )}
                >
                  {label}
                </span>
                {i < steps.length - 1 && (
                  <div
                    className={cn(
                      "flex-1 h-px",
                      done ? "bg-primary" : "bg-border"
                    )}
                  />
                )}
              </div>
            )
          })}
        </div>
        <p className="text-xs text-muted-foreground">
          Step {step + 1} of {steps.length} · {steps[step]}
        </p>
      </div>

      {/* Step content */}
      <div className="min-h-[260px]">
        {step === 0 && (
          <div className="space-y-4 animate-fade-in">
            <header className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">
                Welcome to Planna{", "}
                <span className="text-primary">let&rsquo;s begin</span>
              </h1>
              <p className="text-sm text-muted-foreground">
                We&rsquo;ll personalize your workspace in 3 quick steps. First,
                what should we call you?
              </p>
            </header>
            <div className="space-y-1.5">
              <Label htmlFor="name">Your name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  id="name"
                  placeholder="e.g. Jessin Sam"
                  className="pl-9 h-10"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoFocus
                />
              </div>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4 animate-fade-in">
            <header className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">
                What brings you here?
              </h1>
              <p className="text-sm text-muted-foreground">
                Pick the role that fits best — we&rsquo;ll tailor your default views
                and shortcuts.
              </p>
            </header>
            <div className="grid sm:grid-cols-2 gap-3">
              {ROLES.map((r) => {
                const selected = role === r.id
                const Icon = r.icon
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setRole(r.id)}
                    className={cn(
                      "text-left rounded-xl border p-4 transition-all hover:shadow-sm",
                      selected
                        ? "border-primary bg-primary/5 ring-1 ring-primary"
                        : "border-border hover:border-primary/40"
                    )}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div
                        className={cn(
                          "flex size-9 items-center justify-center rounded-lg transition-colors",
                          selected
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground"
                        )}
                      >
                        <Icon className="size-4" />
                      </div>
                      {selected && (
                        <Check className="size-4 text-primary" />
                      )}
                    </div>
                    <p className="mt-2 font-medium text-sm">{r.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {r.description}
                    </p>
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4 animate-fade-in">
            <header className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">
                Create your first project
              </h1>
              <p className="text-sm text-muted-foreground">
                A project groups related tasks, milestones, and discussions. You
                can rename it anytime.
              </p>
            </header>
            <div className="space-y-1.5">
              <Label htmlFor="project">Project name</Label>
              <div className="relative">
                <FolderPlus className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  id="project"
                  placeholder="e.g. Mobile App Redesign"
                  className="pl-9 h-10"
                  value={project}
                  onChange={(e) => setProject(e.target.value)}
                  autoFocus
                />
              </div>
            </div>
            <div className="rounded-lg border border-dashed border-border bg-muted/30 p-4 text-sm">
              <p className="font-medium mb-1">We&rsquo;ll set you up with</p>
              <ul className="space-y-1 text-xs text-muted-foreground">
                <li className="flex items-center gap-1.5">
                  <Check className="size-3 text-primary" />
                  A Kanban board with To do, In progress, Review, Done columns
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="size-3 text-primary" />
                  A 2-week sprint starting today
                </li>
                <li className="flex items-center gap-1.5">
                  <Check className="size-3 text-primary" />
                  Starter labels and an inbox for notifications
                </li>
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Footer nav */}
      <div className="flex items-center justify-between gap-3 pt-2 border-t border-border">
        {step > 0 ? (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setStep((s) => s - 1)}
            disabled={loading}
          >
            <ArrowLeft className="size-4" />
            Back
          </Button>
        ) : (
          <Link
            href="/sign-in"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Skip for now
          </Link>
        )}

        <Button type="button" onClick={next} disabled={loading} className="min-w-32">
          {loading ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Finishing…
            </>
          ) : step === 2 ? (
            <>
              Finish setup
              <Check className="size-4" />
            </>
          ) : (
            <>
              Continue
              <ArrowRight className="size-4" />
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
