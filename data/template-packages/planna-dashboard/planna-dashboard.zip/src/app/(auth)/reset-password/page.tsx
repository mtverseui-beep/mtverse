"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import {
  ArrowRight,
  Check,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  ShieldCheck,
  X,
} from "lucide-react"
import { toast } from "sonner"

interface Rule {
  label: string
  test: (s: string) => boolean
}

const RULES: Rule[] = [
  { label: "At least 8 characters", test: (s) => s.length >= 8 },
  { label: "Upper & lowercase letters", test: (s) => /[a-z]/.test(s) && /[A-Z]/.test(s) },
  { label: "At least one number", test: (s) => /\d/.test(s) },
  { label: "A symbol (!@#$…)", test: (s) => /[^A-Za-z0-9]/.test(s) },
]

export default function ResetPasswordPage() {
  const [show, setShow] = useState(false)
  const [loading, setLoading] = useState(false)
  const [password, setPassword] = useState("")
  const [confirm, setConfirm] = useState("")

  const passed = useMemo(() => RULES.filter((r) => r.test(password)).length, [password])
  const scoreLabel = ["Too weak", "Weak", "Fair", "Good", "Strong"][passed]
  const scoreColor = [
    "bg-muted",
    "bg-destructive",
    "bg-warning",
    "bg-primary/70",
    "bg-primary",
  ][passed]
  const match = confirm.length > 0 && password === confirm
  const mismatch = confirm.length > 0 && password !== confirm

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (passed < 3) {
      toast.error("Please choose a stronger password.")
      return
    }
    if (password !== confirm) {
      toast.error("Passwords don't match.")
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      toast.success("Password reset! You can now sign in.")
    }, 1100)
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1.5">
        <div className="inline-flex items-center gap-1.5 text-xs font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full w-fit">
          <ShieldCheck className="size-3.5" />
          Secure reset
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">Set a new password</h1>
        <p className="text-sm text-muted-foreground">
          Choose a strong password you haven&rsquo;t used before. Your previous
          password will no longer work.
        </p>
      </header>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="password">New password</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              id="password"
              type={show ? "text" : "password"}
              autoComplete="new-password"
              placeholder="••••••••"
              className="pl-9 pr-9 h-10"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              aria-label={show ? "Hide password" : "Show password"}
            >
              {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>

          {password && (
            <div className="space-y-2 pt-1 animate-fade-in">
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden flex gap-1">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div
                      key={i}
                      className={cn(
                        "flex-1 rounded-full transition-colors",
                        i < passed ? scoreColor : "bg-transparent"
                      )}
                    />
                  ))}
                </div>
                <span className="text-xs font-medium text-muted-foreground w-14 text-right">
                  {scoreLabel}
                </span>
              </div>
              <ul className="grid grid-cols-2 gap-x-3 gap-y-1">
                {RULES.map((r) => {
                  const ok = r.test(password)
                  return (
                    <li
                      key={r.label}
                      className={cn(
                        "flex items-center gap-1.5 text-[11px] transition-colors",
                        ok ? "text-primary" : "text-muted-foreground"
                      )}
                    >
                      {ok ? <Check className="size-3" /> : <X className="size-3" />}
                      {r.label}
                    </li>
                  )
                })}
              </ul>
            </div>
          )}
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="confirm">Confirm new password</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              id="confirm"
              type={show ? "text" : "password"}
              autoComplete="new-password"
              placeholder="••••••••"
              className={cn(
                "pl-9 pr-9 h-10",
                mismatch && "border-destructive focus-visible:ring-destructive/30"
              )}
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
            {confirm && (
              <span className="absolute right-3 top-1/2 -translate-y-1/2">
                {match ? (
                  <Check className="size-4 text-primary" />
                ) : (
                  <X className="size-4 text-destructive" />
                )}
              </span>
            )}
          </div>
          {mismatch && (
            <p className="text-xs text-destructive">Passwords don&rsquo;t match.</p>
          )}
        </div>

        <Button type="submit" className="w-full h-10" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Resetting…
            </>
          ) : (
            <>
              Reset password
              <ArrowRight className="size-4" />
            </>
          )}
        </Button>
      </form>

      <Link
        href="/sign-in"
        className="block text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        Back to sign in
      </Link>
    </div>
  )
}
