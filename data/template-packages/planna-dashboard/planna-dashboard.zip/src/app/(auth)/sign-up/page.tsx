"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"
import {
  ArrowRight,
  Check,
  Eye,
  EyeOff,
  Github,
  Loader2,
  Lock,
  Mail,
  User,
  X,
} from "lucide-react"
import { toast } from "sonner"

interface Rule {
  label: string
  test: (s: string) => boolean
}

const RULES: Rule[] = [
  { label: "At least 8 characters", test: (s) => s.length >= 8 },
  { label: "Upper & lowercase letters", test: (s) => /[a-z]/.test(s) && /[A-Z]/.test(s) },
  { label: "At least one number", test: (s) => /\d/.test(s) },
  { label: "A symbol (!@#$…)", test: (s) => /[^A-Za-z0-9]/.test(s) },
]

export default function SignUpPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [terms, setTerms] = useState(false)

  const passed = useMemo(() => RULES.filter((r) => r.test(password)).length, [password])
  const scoreLabel = ["Too weak", "Weak", "Fair", "Good", "Strong"][passed]
  const scoreColor = [
    "bg-muted",
    "bg-destructive",
    "bg-warning",
    "bg-primary/70",
    "bg-primary",
  ][passed]

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!name || !email || !password) {
      toast.error("Please fill in all fields.")
      return
    }
    if (passed < 3) {
      toast.error("Please choose a stronger password.")
      return
    }
    if (!terms) {
      toast.error("Please accept the terms to continue.")
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      toast.success("Account created! Check your inbox to verify your email.")
    }, 1100)
  }

  return (
    <div className="space-y-6">
      <header className="space-y-1.5">
        <h1 className="text-2xl font-semibold tracking-tight">Create your account</h1>
        <p className="text-sm text-muted-foreground">
          Start your 14-day free trial. No credit card required.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3">
        <Button
          type="button"
          variant="outline"
          className="h-10"
          onClick={() => toast.info("Google sign-up is a UI demo.")}
        >
          <GoogleIcon className="size-4" />
          Google
        </Button>
        <Button
          type="button"
          variant="outline"
          className="h-10"
          onClick={() => toast.info("GitHub sign-up is a UI demo.")}
        >
          <Github className="size-4" />
          GitHub
        </Button>
      </div>

      <div className="relative">
        <Separator />
        <span className="absolute inset-0 -top-2.5 mx-auto w-fit bg-card px-3 text-xs text-muted-foreground">
          or sign up with email
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="name">Full name</Label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              id="name"
              autoComplete="name"
              placeholder="Jessin Sam"
              className="pl-9 h-10"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="email">Work email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              id="email"
              type="email"
              autoComplete="email"
              placeholder="you@company.com"
              className="pl-9 h-10"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="password">Password</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              autoComplete="new-password"
              placeholder="Create a strong password"
              className="pl-9 pr-9 h-10"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>

          {/* Strength meter */}
          {password && (
            <div className="space-y-2 pt-1 animate-fade-in">
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden flex gap-1">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div
                      key={i}
                      className={cn(
                        "flex-1 rounded-full transition-colors",
                        i < passed ? scoreColor : "bg-transparent"
                      )}
                    />
                  ))}
                </div>
                <span className="text-xs font-medium text-muted-foreground w-14 text-right">
                  {scoreLabel}
                </span>
              </div>
              <ul className="grid grid-cols-2 gap-x-3 gap-y-1">
                {RULES.map((r) => {
                  const ok = r.test(password)
                  return (
                    <li
                      key={r.label}
                      className={cn(
                        "flex items-center gap-1.5 text-[11px] transition-colors",
                        ok ? "text-primary" : "text-muted-foreground"
                      )}
                    >
                      {ok ? (
                        <Check className="size-3" />
                      ) : (
                        <X className="size-3" />
                      )}
                      {r.label}
                    </li>
                  )
                })}
              </ul>
            </div>
          )}
        </div>

        <label
          htmlFor="terms"
          className="flex items-start gap-2.5 cursor-pointer text-sm text-muted-foreground"
        >
          <Checkbox
            id="terms"
            checked={terms}
            onCheckedChange={(v) => setTerms(v === true)}
            className="mt-0.5"
          />
          <span>
            I agree to Planna&rsquo;s{" "}
            <a href="#" className="text-primary font-medium hover:underline">
              Terms of Service
            </a>{" "}
            and{" "}
            <a href="#" className="text-primary font-medium hover:underline">
              Privacy Policy
            </a>
            .
          </span>
        </label>

        <Button type="submit" className="w-full h-10" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              Creating account…
            </>
          ) : (
            <>
              Create account
              <ArrowRight className="size-4" />
            </>
          )}
        </Button>
      </form>

      <p className="text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link href="/sign-in" className="text-primary font-medium hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  )
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        fill="currentColor"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        opacity="0.9"
      />
      <path
        fill="currentColor"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        opacity="0.7"
      />
      <path
        fill="currentColor"
        d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.84z"
        opacity="0.8"
      />
      <path
        fill="currentColor"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"
        opacity="0.6"
      />
    </svg>
  )
}
