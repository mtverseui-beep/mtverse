"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { Clock, RefreshCw, ArrowRight, Activity } from "lucide-react"

export default function TimeoutPage() {
  const [elapsed, setElapsed] = useState(0)
  const [retrying, setRetrying] = useState(false)

  useEffect(() => {
    const t = setInterval(() => setElapsed((e) => e + 1), 1000)
    return () => clearInterval(t)
  }, [])

  function retry() {
    setRetrying(true)
    setTimeout(() => {
      setRetrying(false)
      setElapsed(0)
    }, 1200)
  }

  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-lg animate-fade-in">
          {/* Clock with ticking second hand visual */}
          <div className="relative mx-auto w-fit mb-8">
            <div className="absolute inset-0 -m-4 rounded-full bg-warning/10 animate-pulse" />
            <div className="relative size-24 rounded-full border-4 border-warning/30 bg-card flex items-center justify-center">
              <div className="absolute inset-3 rounded-full border border-warning/20" />
              <Clock className="size-10 text-warning" strokeWidth={1.5} />
              {/* Ticking mark */}
              <span className="absolute top-1 left-1/2 -translate-x-1/2 size-1.5 rounded-full bg-warning" />
            </div>
          </div>

          <div className="text-center">
            <div className="inline-flex items-center gap-1.5 text-xs font-medium text-warning bg-warning/10 px-2.5 py-1 rounded-full mb-3">
              <span className="size-1.5 rounded-full bg-warning" />
              HTTP 408
            </div>
            <h1 className="text-3xl font-semibold tracking-tight">Request timeout</h1>
            <p className="mt-3 text-muted-foreground max-w-sm mx-auto">
              The server took too long to respond. This usually happens when the
              network is slow or the request is unusually heavy.
            </p>
          </div>

          {/* Status row — distinctive horizontal info bar */}
          <div className="mt-8 grid grid-cols-3 gap-px rounded-xl overflow-hidden border border-border bg-border">
            <div className="bg-card p-4 text-center">
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Elapsed
              </p>
              <p className="text-lg font-semibold tabular-nums mt-0.5">
                {Math.floor(elapsed / 60)}:{String(elapsed % 60).padStart(2, "0")}
              </p>
            </div>
            <div className="bg-card p-4 text-center">
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Status
              </p>
              <p className="text-sm font-semibold mt-1 inline-flex items-center gap-1.5 text-warning">
                <span className="size-1.5 rounded-full bg-warning animate-pulse" />
                Timed out
              </p>
            </div>
            <div className="bg-card p-4 text-center">
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Retry
              </p>
              <p className="text-sm font-semibold mt-1 text-foreground">
                Recommended
              </p>
            </div>
          </div>

          <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
            <Button size="lg" onClick={retry} disabled={retrying}>
              {retrying ? (
                <>
                  <RefreshCw className="size-4 animate-spin" />
                  Retrying…
                </>
              ) : (
                <>
                  <RefreshCw className="size-4" />
                  Try again
                </>
              )}
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/dashboard">
                <ArrowRight className="size-4" />
                Go to dashboard
              </Link>
            </Button>
          </div>

          <p className="mt-6 text-center text-xs text-muted-foreground flex items-center justify-center gap-1.5">
            <Activity className="size-3" />
            Check our status page for live incident reports.
          </p>
        </div>
      </section>
    </main>
  )
}
