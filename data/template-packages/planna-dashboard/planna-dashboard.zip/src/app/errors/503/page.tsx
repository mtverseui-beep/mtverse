"use client"

import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Wrench,
  Clock,
  ArrowRight,
  CheckCircle2,
  Bell,
} from "lucide-react"

const SCHEDULE = [
  { time: "Today · 14:00 UTC", title: "Scheduled maintenance window begins", done: true },
  { time: "Today · 14:05 UTC", title: "API and real-time services paused", done: true },
  { time: "Today · 14:30 UTC", title: "Database upgrade in progress", done: false },
  { time: "Today · 15:00 UTC", title: "Services restored (ETA)", done: false },
]

export default function ServiceUnavailablePage() {
  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border flex items-center justify-between">
        <BrandLogo />
        <Badge variant="outline" className="hidden sm:inline-flex text-warning border-warning/40">
          <span className="size-1.5 rounded-full bg-warning animate-pulse" />
          Degraded service
        </Badge>
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-2xl animate-fade-in">
          {/* Hero */}
          <div className="text-center mb-8">
            <div className="relative mx-auto w-fit mb-5">
              <div className="absolute inset-0 -m-4 rounded-full bg-warning/10 animate-pulse" />
              <div className="relative size-20 rounded-2xl bg-warning/10 text-warning flex items-center justify-center">
                <Wrench className="size-9" strokeWidth={1.75} />
              </div>
            </div>

            <div className="inline-flex items-center gap-1.5 text-xs font-medium text-warning bg-warning/10 px-2.5 py-1 rounded-full mb-3">
              <span className="size-1.5 rounded-full bg-warning" />
              HTTP 503
            </div>
            <h1 className="text-3xl font-semibold tracking-tight">
              Service unavailable
            </h1>
            <p className="mt-3 text-muted-foreground max-w-md mx-auto">
              We&rsquo;re performing scheduled maintenance to make Planna better.
              The app will be back shortly — thanks for your patience.
            </p>
          </div>

          {/* Maintenance schedule */}
          <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold flex items-center gap-2">
                <Clock className="size-4 text-primary" />
                Maintenance schedule
              </h2>
              <span className="text-xs text-muted-foreground">
                Window: 14:00 – 15:00 UTC
              </span>
            </div>

            <ol className="space-y-3">
              {SCHEDULE.map((item, i) => (
                <li key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    {item.done ? (
                      <CheckCircle2 className="size-5 text-primary" />
                    ) : (
                      <span className="size-5 rounded-full border-2 border-muted-foreground/30 flex items-center justify-center">
                        {i === SCHEDULE.findIndex((s) => !s.done) && (
                          <span className="size-2 rounded-full bg-primary animate-pulse" />
                        )}
                      </span>
                    )}
                    {i < SCHEDULE.length - 1 && (
                      <span
                        className={`w-px flex-1 mt-1 ${
                          item.done ? "bg-primary/40" : "bg-border"
                        }`}
                      />
                    )}
                  </div>
                  <div className="pb-1 flex-1">
                    <p className="text-xs text-muted-foreground">{item.time}</p>
                    <p className={`text-sm ${item.done ? "" : "font-medium"}`}>
                      {item.title}
                    </p>
                  </div>
                </li>
              ))}
            </ol>
          </div>

          <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
            <Button asChild size="lg" variant="outline">
              <Link href="https://status.planna.app" target="_blank" rel="noreferrer">
                <Bell className="size-4" />
                Subscribe to updates
              </Link>
            </Button>
            <Button asChild size="lg">
              <Link href="/dashboard">
                <ArrowRight className="size-4" />
                Try dashboard again
              </Link>
            </Button>
          </div>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            Questions during maintenance? Reach us at{" "}
            <a
              href="mailto:hello@planna.app"
              className="text-primary font-medium hover:underline"
            >
              hello@planna.app
            </a>
            .
          </p>
        </div>
      </section>
    </main>
  )
}
