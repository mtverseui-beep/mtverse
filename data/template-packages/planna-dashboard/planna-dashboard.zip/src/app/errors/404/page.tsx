"use client"

import { useState } from "react"
import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Ghost,
  Search,
  ArrowRight,
  LayoutDashboard,
  CheckSquare,
  Users,
  Calendar,
  Clock,
} from "lucide-react"
import { toast } from "sonner"

const POPULAR = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "My tasks", href: "/dashboard/tasks", icon: CheckSquare },
  { label: "Team", href: "/dashboard/team", icon: Users },
  { label: "Calendar", href: "/dashboard/calendar", icon: Calendar },
]

export default function NotFoundPage() {
  const [query, setQuery] = useState("")

  function search(e: React.FormEvent) {
    e.preventDefault()
    if (!query.trim()) return
    toast.info(`Searching for "${query}"…`)
  }

  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-2xl text-center animate-fade-in">
          {/* Friendly ghost illustration */}
          <div className="relative mx-auto w-fit mb-6">
            <div
              aria-hidden
              className="absolute inset-0 -m-8 rounded-full bg-primary/5 blur-2xl"
            />
            <div className="relative animate-float">
              <div className="size-24 rounded-full bg-primary/10 flex items-center justify-center">
                <Ghost className="size-12 text-primary" strokeWidth={1.5} />
              </div>
              {/* Tiny dots around ghost */}
              <span className="absolute -top-1 -right-2 size-1.5 rounded-full bg-primary/40" />
              <span className="absolute -bottom-1 -left-3 size-1 rounded-full bg-primary/30" />
              <span className="absolute top-2 -left-4 size-1 rounded-full bg-primary/20" />
            </div>
          </div>

          {/* Big 404 with subtle treatment */}
          <div className="relative inline-block mb-2">
            <h1 className="text-7xl sm:text-8xl font-bold tracking-tighter text-primary/15 select-none">
              404
            </h1>
            <span className="absolute inset-0 flex items-center justify-center text-sm font-medium text-foreground">
              Page not found
            </span>
          </div>

          <p className="mt-4 text-muted-foreground max-w-md mx-auto">
            Oops — the page you&rsquo;re looking for has wandered off. It may have
            been moved, renamed, or never existed in the first place.
          </p>

          {/* Search box */}
          <form onSubmit={search} className="mt-6 max-w-md mx-auto">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search for a page, project, or task…"
                className="h-11 pl-10 pr-24 rounded-full"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <Button
                type="submit"
                size="sm"
                className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-full h-8"
              >
                Search
              </Button>
            </div>
          </form>

          {/* Popular pages */}
          <div className="mt-8">
            <p className="text-xs uppercase tracking-wide font-semibold text-muted-foreground mb-3 flex items-center justify-center gap-1.5">
              <Clock className="size-3.5" />
              Popular pages
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-w-lg mx-auto">
              {POPULAR.map((p) => {
                const Icon = p.icon
                return (
                  <Link
                    key={p.href}
                    href={p.href}
                    className="group rounded-xl border border-border bg-card p-3 text-left hover:border-primary/40 hover:shadow-sm transition-all"
                  >
                    <Icon className="size-4 text-primary mb-1.5" />
                    <p className="text-sm font-medium">{p.label}</p>
                  </Link>
                )
              })}
            </div>
          </div>

          <div className="mt-8">
            <Button asChild variant="outline">
              <Link href="/dashboard">
                <ArrowRight className="size-4" />
                Go to dashboard
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
