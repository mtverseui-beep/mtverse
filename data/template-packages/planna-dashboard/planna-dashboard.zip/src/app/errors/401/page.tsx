"use client"

import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { LockKeyhole, ArrowRight, Mail, LifeBuoy } from "lucide-react"

export default function UnauthorizedPage() {
  return (
    <main className="min-h-screen flex flex-col bg-background">
      {/* Top bar */}
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      {/* Body — centered lock motif */}
      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md text-center animate-fade-in">
          {/* Animated lock visual */}
          <div className="relative mx-auto w-fit mb-8">
            <div className="absolute inset-0 -m-6 rounded-full bg-primary/10 animate-pulse" />
            <div className="relative size-20 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/30">
              <LockKeyhole className="size-9" strokeWidth={1.75} />
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 text-xs font-medium text-destructive bg-destructive/10 px-2.5 py-1 rounded-full mb-3">
            <span className="size-1.5 rounded-full bg-destructive" />
            HTTP 401
          </div>
          <h1 className="text-3xl font-semibold tracking-tight">Unauthorized</h1>
          <p className="mt-3 text-muted-foreground max-w-sm mx-auto">
            This page requires authentication. Your session may have expired or
            you need to sign in to continue.
          </p>

          <div className="mt-8 space-y-3">
            <Button asChild size="lg" className="w-full">
              <Link href="/sign-in">
                Sign in to Planna
                <ArrowRight className="size-4" />
              </Link>
            </Button>
            <div className="grid grid-cols-2 gap-3">
              <Button asChild variant="outline" size="lg">
                <Link href="mailto:hello@planna.app">
                  <Mail className="size-4" />
                  Contact support
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/">
                  <LifeBuoy className="size-4" />
                  Help center
                </Link>
              </Button>
            </div>
          </div>

          <p className="mt-8 text-xs text-muted-foreground">
            Lost your password?{" "}
            <Link
              href="/forgot-password"
              className="text-primary font-medium hover:underline"
            >
              Reset it here
            </Link>
          </p>
        </div>
      </section>
    </main>
  )
}
