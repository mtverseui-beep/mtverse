"use client"

import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ShieldX, ArrowRight, Mail, KeySquare, FileText } from "lucide-react"

const ADMINS = [
  {
    name: "Zara Marlowe",
    role: "Head of Product · Workspace Admin",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&h=128&fit=crop",
  },
  {
    name: "Theo Nakamura",
    role: "Engineering Lead · Workspace Admin",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=128&h=128&fit=crop",
  },
  {
    name: "Jessin Sam",
    role: "Founder & CEO · Owner",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop",
  },
]

export default function ForbiddenPage() {
  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      {/* Two-column on desktop: left = explanation + CTA, right = admins list */}
      <section className="flex-1 grid lg:grid-cols-2">
        {/* Left */}
        <div className="flex items-center justify-center p-8 lg:p-12 border-b lg:border-b-0 lg:border-r border-border">
          <div className="w-full max-w-md animate-slide-in-up">
            <div className="relative w-fit mb-6">
              <div className="size-16 rounded-2xl bg-destructive/10 text-destructive flex items-center justify-center">
                <ShieldX className="size-8" strokeWidth={1.75} />
              </div>
            </div>

            <div className="inline-flex items-center gap-1.5 text-xs font-medium text-destructive bg-destructive/10 px-2.5 py-1 rounded-full mb-3">
              <span className="size-1.5 rounded-full bg-destructive" />
              HTTP 403
            </div>
            <h1 className="text-3xl font-semibold tracking-tight">Forbidden</h1>
            <p className="mt-3 text-muted-foreground">
              You don&rsquo;t have permission to access this page. If you believe
              this is a mistake, request access from one of your workspace
              administrators.
            </p>

            <div className="mt-6 space-y-3">
              <Button size="lg" className="w-full">
                <KeySquare className="size-4" />
                Request access
              </Button>
              <div className="grid grid-cols-2 gap-3">
                <Button asChild variant="outline" size="lg">
                  <Link href="/dashboard">
                    <ArrowRight className="size-4" />
                    Go to dashboard
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/dashboard/settings">
                    <FileText className="size-4" />
                    View permissions
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Right — who can grant access */}
        <div className="flex items-center justify-center p-8 lg:p-12 bg-muted/30">
          <div className="w-full max-w-md">
            <div className="flex items-center gap-2 mb-1">
              <Mail className="size-4 text-primary" />
              <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                Who can grant access
              </h2>
            </div>
            <p className="text-xs text-muted-foreground mb-5">
              These workspace admins can update your role and permissions.
            </p>

            <ul className="space-y-3">
              {ADMINS.map((admin, i) => (
                <li
                  key={admin.name}
                  className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 shadow-sm hover:shadow-md transition-shadow animate-slide-in-up"
                  style={{ animationDelay: `${i * 60}ms` }}
                >
                  <Avatar className="size-10">
                    <AvatarImage src={admin.avatar} alt={admin.name} />
                    <AvatarFallback>
                      {admin.name.split(" ").map((w) => w[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{admin.name}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {admin.role}
                    </p>
                  </div>
                  <Button asChild size="sm" variant="ghost">
                    <Link
                      href={`mailto:${admin.name.toLowerCase().split(" ")[0]}@planna.app`}
                    >
                      Message
                    </Link>
                  </Button>
                </li>
              ))}
            </ul>

            <p className="mt-6 text-xs text-muted-foreground text-center">
              Or email{" "}
              <a
                href="mailto:hello@planna.app"
                className="text-primary font-medium hover:underline"
              >
                hello@planna.app
              </a>{" "}
              and we&rsquo;ll help route your request.
            </p>
          </div>
        </div>
      </section>
    </main>
  )
}
