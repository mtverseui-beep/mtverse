"use client"

import { useState } from "react"
import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Construction,
  Clock,
  Bell,
  Check,
  ArrowRight,
  Hammer,
  Paintbrush,
  Database,
} from "lucide-react"
import { toast } from "sonner"

const TASKS = [
  { icon: Hammer, label: "Migrating task database to v3" },
  { icon: Paintbrush, label: "Polishing the new dashboard UI" },
  { icon: Database, label: "Optimizing query performance" },
]

export default function MaintenancePage() {
  const [email, setEmail] = useState("")
  const [subscribed, setSubscribed] = useState(false)

  function subscribe(e: React.FormEvent) {
    e.preventDefault()
    if (!email) {
      toast.error("Please enter your email to subscribe.")
      return
    }
    setSubscribed(true)
    toast.success("You're subscribed! We'll notify you when Planna is back.")
  }

  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-2xl animate-fade-in">
          {/* Top banner — like a "scheduled maintenance" status banner */}
          <div className="rounded-xl bg-primary text-primary-foreground p-4 mb-6 flex items-center gap-3 shadow-md shadow-primary/20">
            <span className="size-2.5 rounded-full bg-primary-foreground animate-pulse shrink-0" />
            <p className="text-sm font-medium">
              Scheduled maintenance in progress — Planna returns at{" "}
              <span className="font-semibold">16:00 UTC</span>.
            </p>
          </div>

          <div className="grid lg:grid-cols-[1fr_1.1fr] gap-6 items-start">
            {/* Left — heading + ETA + tasks */}
            <div>
              <div className="size-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-5">
                <Construction className="size-8" strokeWidth={1.75} />
              </div>

              <h1 className="text-3xl font-semibold tracking-tight">
                Under maintenance
              </h1>
              <p className="mt-3 text-muted-foreground text-sm leading-relaxed">
                We&rsquo;re rolling out improvements to make Planna faster and
                more reliable. The app is temporarily unavailable while we work.
              </p>

              {/* ETA card */}
              <div className="mt-5 rounded-xl border border-border bg-card p-4 flex items-center gap-3">
                <div className="size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <Clock className="size-5" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Estimated completion</p>
                  <p className="font-semibold">
                    ~52 minutes · 16:00 UTC
                  </p>
                </div>
              </div>

              {/* What we're working on */}
              <div className="mt-4 space-y-2">
                {TASKS.map((task, i) => {
                  const Icon = task.icon
                  return (
                    <div
                      key={task.label}
                      className="flex items-center gap-2.5 text-sm text-muted-foreground"
                    >
                      <Icon className="size-4 text-primary" />
                      {task.label}
                      <span className="ml-auto size-1.5 rounded-full bg-primary/40 animate-pulse" style={{ animationDelay: `${i * 200}ms` }} />
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Right — subscribe for updates */}
            <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
              {subscribed ? (
                <div className="text-center py-6 animate-scale-in">
                  <div className="mx-auto size-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-3">
                    <Check className="size-6" />
                  </div>
                  <p className="font-semibold">You&rsquo;re subscribed</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    We&rsquo;ll email{" "}
                    <span className="font-medium text-foreground">{email}</span>{" "}
                    when Planna is back online.
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-4"
                    onClick={() => {
                      setSubscribed(false)
                      setEmail("")
                    }}
                  >
                    Use a different email
                  </Button>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2 mb-1">
                    <Bell className="size-4 text-primary" />
                    <h2 className="font-semibold">Get notified</h2>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    We&rsquo;ll email you the moment Planna is back up — no spam,
                    just this one update.
                  </p>

                  <form onSubmit={subscribe} className="space-y-3">
                    <div className="space-y-1.5">
                      <Label htmlFor="email">Email address</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="you@company.com"
                        className="h-10"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    <Button type="submit" className="w-full h-10">
                      Notify me when it&rsquo;s back
                      <ArrowRight className="size-4" />
                    </Button>
                  </form>

                  <div className="mt-4 pt-4 border-t border-border text-xs text-muted-foreground space-y-1.5">
                    <p className="flex items-center gap-1.5">
                      <Check className="size-3 text-primary" />
                      Real-time updates at status.planna.app
                    </p>
                    <p className="flex items-center gap-1.5">
                      <Check className="size-3 text-primary" />
                      Follow @planna on Twitter for live announcements
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-6">
            Need urgent help?{" "}
            <a
              href="mailto:hello@planna.app"
              className="text-primary font-medium hover:underline"
            >
              hello@planna.app
            </a>
          </p>
        </div>
      </section>
    </main>
  )
}
