"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { Gauge, Coffee, ArrowRight, Info } from "lucide-react"

const INITIAL = 30

export default function RateLimitPage() {
  const [seconds, setSeconds] = useState(INITIAL)

  useEffect(() => {
    if (seconds <= 0) return
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000)
    return () => clearTimeout(t)
  }, [seconds])

  const pct = ((INITIAL - seconds) / INITIAL) * 100

  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-xl animate-fade-in">
          <div className="rounded-2xl border border-border bg-card shadow-sm overflow-hidden">
            {/* Gauge header bar */}
            <div className="relative bg-primary text-primary-foreground p-8 text-center overflow-hidden">
              <div
                aria-hidden
                className="absolute inset-0 opacity-10"
                style={{
                  backgroundImage:
                    "repeating-linear-gradient(45deg, currentColor 0, currentColor 1px, transparent 1px, transparent 12px)",
                }}
              />
              <div className="relative">
                <Gauge className="size-12 mx-auto mb-2" strokeWidth={1.5} />
                <div className="inline-flex items-center gap-1.5 text-[11px] font-medium bg-primary-foreground/15 px-2 py-0.5 rounded-full mb-2">
                  <span className="size-1.5 rounded-full bg-primary-foreground animate-pulse" />
                  HTTP 429
                </div>
                <h1 className="text-2xl font-semibold tracking-tight">
                  Too many requests
                </h1>
                <p className="text-primary-foreground/80 text-sm mt-1.5 max-w-sm mx-auto">
                  You&rsquo;ve hit our rate limit. We do this to keep Planna fast
                  and reliable for everyone.
                </p>
              </div>
            </div>

            {/* Countdown */}
            <div className="p-8 space-y-6">
              <div className="text-center">
                <p className="text-xs uppercase tracking-wide text-muted-foreground mb-2 flex items-center justify-center gap-1.5">
                  <Coffee className="size-3.5" />
                  Try again in
                </p>
                <p className="text-5xl font-semibold tabular-nums tracking-tighter">
                  {seconds}
                  <span className="text-xl text-muted-foreground ml-1">s</span>
                </p>
                {/* Progress bar */}
                <div className="mt-4 h-1.5 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-1000 ease-linear"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>

              <div className="rounded-lg bg-muted/50 p-3.5 text-xs text-muted-foreground flex gap-2.5">
                <Info className="size-4 shrink-0 text-primary mt-0.5" />
                <div>
                  <p className="font-medium text-foreground mb-0.5">
                    Why am I seeing this?
                  </p>
                  Each workspace is limited to{" "}
                  <span className="font-medium text-foreground">120 requests/minute</span>{" "}
                  on the free plan. Upgrade or wait for the limit to reset.
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  size="lg"
                  className="flex-1"
                  disabled={seconds > 0}
                >
                  <ArrowRight className="size-4" />
                  {seconds > 0 ? `Wait ${seconds}s` : "Continue to dashboard"}
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/dashboard/settings/billing">
                    View upgrade options
                  </Link>
                </Button>
              </div>
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-4">
            Need a higher limit now?{" "}
            <a
              href="mailto:hello@planna.app"
              className="text-primary font-medium hover:underline"
            >
              Contact our team
            </a>
          </p>
        </div>
      </section>
    </main>
  )
}
