"use client"

import { useState } from "react"
import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Sparkles,
  Check,
  ArrowRight,
  Bell,
  KanbanSquare,
  GitBranch,
  Bot,
  CalendarClock,
} from "lucide-react"
import { toast } from "sonner"

const FEATURES = [
  {
    icon: KanbanSquare,
    title: "Smart boards",
    desc: "AI-suggested column moves based on stale tasks.",
  },
  {
    icon: GitBranch,
    title: "Git-native sprints",
    desc: "Auto-link PRs to tasks and track cycle time per commit.",
  },
  {
    icon: Bot,
    title: "Planna Assistant",
    desc: "Summarize standups and draft your next sprint plan.",
  },
  {
    icon: CalendarClock,
    title: "Auto-scheduling",
    desc: "Plan work around your team's capacity and time off.",
  },
]

export default function ComingSoonPage() {
  const [email, setEmail] = useState("")
  const [subscribed, setSubscribed] = useState(false)

  function subscribe(e: React.FormEvent) {
    e.preventDefault()
    if (!email) {
      toast.error("Enter your email to join the waitlist.")
      return
    }
    setSubscribed(true)
    toast.success("You're on the list! We'll be in touch soon.")
  }

  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border flex items-center justify-between">
        <BrandLogo />
        <Badge variant="outline" className="text-primary border-primary/30">
          <Sparkles className="size-3" />
          Coming soon
        </Badge>
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-3xl animate-fade-in">
          {/* Hero */}
          <div className="text-center mb-10">
            <div className="relative mx-auto w-fit mb-5">
              <div className="absolute inset-0 -m-4 rounded-full bg-primary/10 blur-xl" />
              <div className="relative size-20 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/30 animate-float">
                <Sparkles className="size-9" strokeWidth={1.75} />
              </div>
            </div>

            <h1 className="text-4xl font-semibold tracking-tight">
              Planna <span className="text-primary">2.0</span> is on the way
            </h1>
            <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
              The next chapter of Planna brings AI-powered planning, native Git
              integrations, and a redesigned sprint experience. Join the waitlist
              to be first in line.
            </p>
          </div>

          {/* Feature preview grid */}
          <div className="grid sm:grid-cols-2 gap-3 mb-10">
            {FEATURES.map((f, i) => {
              const Icon = f.icon
              return (
                <div
                  key={f.title}
                  className="group rounded-xl border border-border bg-card p-4 hover:border-primary/40 hover:shadow-md transition-all animate-slide-in-up"
                  style={{ animationDelay: `${i * 60}ms` }}
                >
                  <div className="flex items-start gap-3">
                    <div className="size-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      <Icon className="size-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-sm">{f.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {f.desc}
                      </p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Notify-me form */}
          <div className="rounded-2xl border border-border bg-card shadow-sm overflow-hidden">
            <div className="grid sm:grid-cols-[1.2fr_1fr]">
              {/* Form */}
              <div className="p-6 sm:p-8">
                {subscribed ? (
                  <div className="text-center py-4 animate-scale-in">
                    <div className="mx-auto size-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-3">
                      <Check className="size-6" />
                    </div>
                    <p className="font-semibold">You&rsquo;re on the waitlist</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      We&rsquo;ll reach out to{" "}
                      <span className="font-medium text-foreground">{email}</span>{" "}
                      with early access when it&rsquo;s ready.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2 mb-1">
                      <Bell className="size-4 text-primary" />
                      <h2 className="font-semibold">Get early access</h2>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Be the first to know when Planna 2.0 launches. Waitlist
                      members get 3 months of Pro free.
                    </p>
                    <form onSubmit={subscribe} className="space-y-3">
                      <div className="space-y-1.5">
                        <Label htmlFor="email">Work email</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="you@company.com"
                          className="h-10"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                        />
                      </div>
                      <Button type="submit" className="w-full h-10">
                        Join the waitlist
                        <ArrowRight className="size-4" />
                      </Button>
                    </form>
                  </>
                )}
              </div>

              {/* Side perks */}
              <div className="bg-primary text-primary-foreground p-6 sm:p-8 flex flex-col justify-center">
                <p className="text-xs uppercase tracking-wide text-primary-foreground/70 font-semibold mb-3">
                  Waitlist perks
                </p>
                <ul className="space-y-2.5 text-sm">
                  {[
                    "3 months of Planna Pro free",
                    "Early access to new features",
                    "Direct line to the product team",
                    "Shape the roadmap with feedback",
                  ].map((perk) => (
                    <li key={perk} className="flex items-center gap-2">
                      <span className="size-5 rounded-full bg-primary-foreground/15 flex items-center justify-center shrink-0">
                        <Check className="size-3" />
                      </span>
                      {perk}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-6">
            In the meantime,{" "}
            <Link
              href="/dashboard"
              className="text-primary font-medium hover:underline"
            >
              continue using Planna 1.0
            </Link>
            .
          </p>
        </div>
      </section>
    </main>
  )
}
