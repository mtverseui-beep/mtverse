"use client"

import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import {
  ServerCrash,
  RefreshCw,
  ArrowRight,
  Activity,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react"

export default function ServerErrorPage() {
  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-2xl animate-fade-in">
          {/* Terminal/console style card */}
          <div className="rounded-2xl overflow-hidden border border-border shadow-sm">
            {/* Terminal header */}
            <div className="flex items-center gap-2 px-4 py-2.5 bg-muted/60 border-b border-border">
              <span className="size-2.5 rounded-full bg-destructive/70" />
              <span className="size-2.5 rounded-full bg-warning/70" />
              <span className="size-2.5 rounded-full bg-success/70" />
              <span className="ml-2 text-xs text-muted-foreground font-mono">
                planna-server — error.log
              </span>
            </div>

            {/* Console body */}
            <div className="bg-card p-6 sm:p-8 font-mono text-sm">
              <div className="flex items-start gap-3 mb-4">
                <div className="size-10 rounded-lg bg-destructive/10 text-destructive flex items-center justify-center shrink-0">
                  <ServerCrash className="size-5" strokeWidth={1.75} />
                </div>
                <div>
                  <div className="inline-flex items-center gap-1.5 text-[11px] font-medium text-destructive bg-destructive/10 px-2 py-0.5 rounded-full mb-1.5">
                    <span className="size-1.5 rounded-full bg-destructive" />
                    HTTP 500
                  </div>
                  <h1 className="text-xl font-semibold tracking-tight font-sans">
                    Something went wrong on our end
                  </h1>
                </div>
              </div>

              <div className="rounded-lg bg-muted/40 p-3.5 text-xs space-y-1">
                <p>
                  <span className="text-muted-foreground">[error]</span>{" "}
                  <span className="text-destructive">InternalServerError</span>: unhandled exception in /api/projects/route
                </p>
                <p>
                  <span className="text-muted-foreground">[stack]</span>{" "}
                  DatabaseConnection.timeout (8.2s)
                </p>
                <p>
                  <span className="text-muted-foreground">[info]</span>{" "}
                  Incident auto-reported · ID <span className="text-primary">#pl-4f3a92</span>
                </p>
              </div>

              <p className="mt-5 text-sm text-muted-foreground font-sans leading-relaxed">
                We&rsquo;ve been notified and our engineering team is on it. Your
                data is safe — no actions are needed from your side. Sorry for the
                disruption.
              </p>

              {/* Status indicators */}
              <div className="mt-5 space-y-1.5 font-sans text-xs">
                <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-muted/30">
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="size-3.5 text-success" />
                    Incident detected
                  </span>
                  <span className="text-muted-foreground">2 min ago</span>
                </div>
                <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-muted/30">
                  <span className="flex items-center gap-2">
                    <AlertTriangle className="size-3.5 text-warning" />
                    Engineering paged
                  </span>
                  <span className="text-muted-foreground">90s ago</span>
                </div>
                <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-muted/30">
                  <span className="flex items-center gap-2">
                    <span className="size-3.5 rounded-full border-2 border-muted-foreground/40 border-t-primary animate-spin" />
                    Fix in progress
                  </span>
                  <span className="text-muted-foreground">ETA ~15 min</span>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-6 flex flex-col sm:flex-row gap-3 font-sans">
                <Button size="lg" className="flex-1">
                  <RefreshCw className="size-4" />
                  Reload page
                </Button>
                <Button asChild variant="outline" size="lg">
                  <a
                    href="https://status.planna.app"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Activity className="size-4" />
                    Live status
                  </a>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/dashboard">
                    <ArrowRight className="size-4" />
                    Dashboard
                  </Link>
                </Button>
              </div>
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-4">
            Reference this incident as{" "}
            <code className="px-1.5 py-0.5 rounded bg-muted font-mono text-foreground">
              #pl-4f3a92
            </code>{" "}
            when contacting support at{" "}
            <a
              href="mailto:hello@planna.app"
              className="text-primary font-medium hover:underline"
            >
              hello@planna.app
            </a>
            .
          </p>
        </div>
      </section>
    </main>
  )
}
