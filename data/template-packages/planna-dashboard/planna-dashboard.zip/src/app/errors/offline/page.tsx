"use client"

import Link from "next/link"
import { BrandLogo } from "@/components/layout/brand-logo"
import { Button } from "@/components/ui/button"
import { WifiOff, RefreshCw, Download, CloudOff, Check } from "lucide-react"
import { toast } from "sonner"

export default function OfflinePage() {
  function refresh() {
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      toast.error("You're still offline. Reconnect to retry.")
      return
    }
    window.location.reload()
  }

  return (
    <main className="min-h-screen flex flex-col bg-background">
      <header className="px-6 py-5 border-b border-border">
        <BrandLogo />
      </header>

      <section className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-xl animate-fade-in">
          {/* Top banner — connection status */}
          <div className="rounded-t-2xl bg-muted/60 px-4 py-2 flex items-center justify-between border border-border border-b-0">
            <div className="flex items-center gap-2 text-xs">
              <span className="size-2 rounded-full bg-destructive animate-pulse" />
              <span className="font-mono text-muted-foreground">
                network.status = "offline"
              </span>
            </div>
            <span className="text-xs text-muted-foreground font-mono">
              Last sync: 2m ago
            </span>
          </div>

          <div className="rounded-b-2xl border border-border bg-card shadow-sm overflow-hidden">
            <div className="p-8 text-center">
              {/* Disconnected wifi visual */}
              <div className="relative mx-auto w-fit mb-6">
                <div className="absolute inset-0 -m-4 rounded-full bg-destructive/5" />
                <div className="relative size-20 rounded-2xl bg-destructive/10 text-destructive flex items-center justify-center">
                  <WifiOff className="size-9" strokeWidth={1.75} />
                </div>
              </div>

              <h1 className="text-3xl font-semibold tracking-tight">
                You&rsquo;re offline
              </h1>
              <p className="mt-3 text-muted-foreground max-w-md mx-auto">
                Planna can&rsquo;t reach the internet. Some features are
                unavailable, but you can still view content cached on this device.
              </p>

              <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
                <Button size="lg" onClick={refresh}>
                  <RefreshCw className="size-4" />
                  Try reconnecting
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/dashboard">
                    <Download className="size-4" />
                    View cached content
                  </Link>
                </Button>
              </div>
            </div>

            {/* Cached content availability list */}
            <div className="border-t border-border bg-muted/30 p-5">
              <p className="text-xs uppercase tracking-wide font-semibold text-muted-foreground mb-3 flex items-center gap-1.5">
                <CloudOff className="size-3.5" />
                Available while offline
              </p>
              <ul className="space-y-2 text-sm">
                {[
                  { label: "Recently viewed projects (read-only)", ok: true },
                  { label: "Drafts and unsaved notes", ok: true },
                  { label: "Commenting and editing tasks", ok: false },
                  { label: "Real-time presence & notifications", ok: false },
                ].map((item) => (
                  <li key={item.label} className="flex items-center gap-2.5">
                    <span
                      className={`size-5 rounded-full flex items-center justify-center ${
                        item.ok
                          ? "bg-success/15 text-success"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {item.ok ? (
                        <Check className="size-3" />
                      ) : (
                        <span className="text-[10px]">×</span>
                      )}
                    </span>
                    <span className={item.ok ? "" : "text-muted-foreground"}>
                      {item.label}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-4">
            Changes you make offline will sync automatically once you reconnect.
          </p>
        </div>
      </section>
    </main>
  )
}
