// Pass-through layout. Each page renders its own sidebar + main via DashboardShell
// or DashboardShellBare. This prevents double-sidebar nesting.
export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
