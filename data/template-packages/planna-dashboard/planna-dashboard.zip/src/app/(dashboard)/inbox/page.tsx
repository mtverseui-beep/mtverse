"use client"

import { InboxView } from "./_inbox-view"

export default function InboxPage() {
  return <InboxView />
}
