"use client"

import { useMemo, useRef, useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Search, Send, Paperclip, Phone, Video, MoreVertical, ArrowLeft,
  Users, FileText, Link2, Star, Trash2, Archive, SmilePlus,
  Sparkles, CheckCircle2, Hash, Info,
} from "lucide-react"
import { chatThreads, currentMember, members } from "@/lib/data/mock"
import { cn, timeAgo, formatDate, initials } from "@/lib/utils"
import { toast } from "sonner"
import type { ChatThread } from "@/types"

// ============================================================
// SYNTHETIC MESSAGES (chatThreads mock has no message list)
// ============================================================

interface InboxMessage {
  id: string
  threadId: string
  authorId: string
  authorName: string
  authorAvatar: string
  body: string
  createdAt: string
  mine: boolean
}

const threadParticipants: Record<string, { name: string; avatar: string; role?: string }[]> = {
  ct1: [{ name: "Zara Marlowe", avatar: members[1].avatar, role: "Head of Product" }, { name: currentMember.name, avatar: currentMember.avatar, role: currentMember.title }],
  ct2: members.slice(0, 5).map(m => ({ name: m.name, avatar: m.avatar, role: m.title })),
  ct3: [members[3], members[11], members[1]].map(m => ({ name: m.name, avatar: m.avatar, role: m.title })),
  ct4: [{ name: "Theo Nakamura", avatar: members[2].avatar, role: "Engineering Lead" }, { name: currentMember.name, avatar: currentMember.avatar, role: currentMember.title }],
  ct5: [members[1], members[4], members[8]].map(m => ({ name: m.name, avatar: m.avatar, role: m.title })),
  ct6: [{ name: "Amara Okafor", avatar: members[5].avatar, role: "Backend Engineer" }, { name: currentMember.name, avatar: currentMember.avatar, role: currentMember.title }],
}

const threadAttachments: Record<string, { name: string; size: string; type: string; owner: string }[]> = {
  ct1: [
    { name: "Onboarding PR #284.diff", size: "12 KB", type: "code", owner: "Zara Marlowe" },
    { name: "Onboarding flow v3.png", size: "1.2 MB", type: "image", owner: "Zara Marlowe" },
  ],
  ct2: [
    { name: "Command palette spec.pdf", size: "240 KB", type: "pdf", owner: "Felix Brandt" },
    { name: "Sprint 47 plan.md", size: "8 KB", type: "code", owner: "Theo Nakamura" },
  ],
  ct3: [
    { name: "Design tokens v3.json", size: "32 KB", type: "code", owner: "Mira Patel" },
  ],
  ct4: [
    { name: "WS reconnect diff.patch", size: "6 KB", type: "code", owner: "Theo Nakamura" },
  ],
  ct5: [],
  ct6: [],
}

const threadLinkedTask: Record<string, { key: string; title: string; project: string }> = {
  ct1: { key: "PLN-101", title: "Onboarding flow polish", project: "Planna Web App" },
  ct2: { key: "PLN-105", title: "Kanban drag-and-drop", project: "Planna Web App" },
  ct3: { key: "DSGN-401", title: "Button component variants", project: "Design System 2.0" },
  ct4: { key: "PLN-103", title: "WebSocket reconnect logic", project: "Planna Web App" },
  ct5: { key: "ARC-601", title: "Acme onboarding customization", project: "Acme Client Project" },
  ct6: { key: "API-301", title: "Rate limiting middleware", project: "Public API Platform" },
}

// Generate deterministic messages per thread based on lastMessage + extra context
const seedMessages: InboxMessage[] = [
  // ct1 — Zara DM
  { id: "m1-1", threadId: "ct1", authorId: "u2", authorName: "Zara Marlowe", authorAvatar: members[1].avatar, body: "Hey Jessin — quick one before EOD.", createdAt: "2026-01-28T15:32:00Z", mine: false },
  { id: "m1-2", threadId: "ct1", authorId: "u2", authorName: "Zara Marlowe", authorAvatar: members[1].avatar, body: "Can you review the new onboarding PR before EOD? It's #284, ~340 LOC.", createdAt: "2026-01-28T15:34:00Z", mine: false },
  { id: "m1-3", threadId: "ct1", authorId: "u1", authorName: currentMember.name, authorAvatar: currentMember.avatar, body: "On it. Will leave inline comments on Figma too.", createdAt: "2026-01-28T15:51:00Z", mine: true },
  { id: "m1-4", threadId: "ct1", authorId: "u2", authorName: "Zara Marlowe", authorAvatar: members[1].avatar, body: "Perfect — appreciated. Also flag if the 5-step variant looks off; that's the one Acme will get.", createdAt: "2026-01-28T15:55:00Z", mine: false },
  // ct2 — #planna-web channel
  { id: "m2-1", threadId: "ct2", authorId: "u4", authorName: "Felix Brandt", authorAvatar: members[4].avatar, body: "Command palette is ready for review", createdAt: "2026-01-28T09:14:00Z", mine: false },
  { id: "m2-2", threadId: "ct2", authorId: "u3", authorName: "Theo Nakamura", authorAvatar: members[2].avatar, body: "Nice. Are we keeping ⌘K as the only entry point, or also ⌘P?", createdAt: "2026-01-28T09:22:00Z", mine: false },
  { id: "m2-3", threadId: "ct2", authorId: "u4", authorName: "Felix Brandt", authorAvatar: members[4].avatar, body: "⌘K only for now — matches Linear/Notion. ⌘P would conflict with print.", createdAt: "2026-01-28T09:25:00Z", mine: false },
  { id: "m2-4", threadId: "ct2", authorId: "u1", authorName: currentMember.name, authorAvatar: currentMember.avatar, body: "+1 on ⌘K only. Ship it.", createdAt: "2026-01-28T09:31:00Z", mine: true },
  // ct3 — #design-system
  { id: "m3-1", threadId: "ct3", authorId: "u4", authorName: "Mira Patel", authorAvatar: members[3].avatar, body: "New tokens are in the Figma file — emerald family got a refresh for AA contrast.", createdAt: "2026-01-27T11:00:00Z", mine: false },
  { id: "m3-2", threadId: "ct3", authorId: "u12", authorName: "Sofia Vargas", authorAvatar: members[11].avatar, body: "Dark mode emerald-300 vs emerald-400 contrast ratio is now 4.7:1. Passes AA, fails AAA.", createdAt: "2026-01-27T11:18:00Z", mine: false },
  { id: "m3-3", threadId: "ct3", authorId: "u2", authorName: "Zara Marlowe", authorAvatar: members[1].avatar, body: "AA is fine for body, let's bump key CTAs to AAA.", createdAt: "2026-01-27T11:24:00Z", mine: false },
  // ct4 — Theo DM
  { id: "m4-1", threadId: "ct4", authorId: "u3", authorName: "Theo Nakamura", authorAvatar: members[2].avatar, body: "Pushed the WS reconnect fix to staging", createdAt: "2026-01-27T16:40:00Z", mine: false },
  { id: "m4-2", threadId: "ct4", authorId: "u1", authorName: currentMember.name, authorAvatar: currentMember.avatar, body: "Will smoke-test it tomorrow morning.", createdAt: "2026-01-27T17:02:00Z", mine: true },
  // ct5 — #acme-client
  { id: "m5-1", threadId: "ct5", authorId: "u9", authorName: "Hugo Lindqvist", authorAvatar: members[8].avatar, body: "SSO config doc shared — SAML metadata XML in the linked file.", createdAt: "2026-01-26T10:00:00Z", mine: false },
  { id: "m5-2", threadId: "ct5", authorId: "u5", authorName: "Felix Brandt", authorAvatar: members[4].avatar, body: "Thanks. I'll wire JIT provisioning on top of it.", createdAt: "2026-01-26T10:20:00Z", mine: false },
  // ct6 — Amara DM
  { id: "m6-1", threadId: "ct6", authorId: "u6", authorName: "Amara Okafor", authorAvatar: members[5].avatar, body: "Rate limit middleware deployed to prod. 1000 req/min per key, bursts up to 1500.", createdAt: "2026-01-25T13:00:00Z", mine: false },
  { id: "m6-2", threadId: "ct6", authorId: "u1", authorName: currentMember.name, authorAvatar: currentMember.avatar, body: "Excellent. Add a Slack alert on 429 spikes?", createdAt: "2026-01-25T13:12:00Z", mine: true },
]

// ============================================================
// MAIN INBOX VIEW (shared between /inbox and /inbox/[threadId])
// ============================================================

interface InboxViewProps {
  initialThreadId?: string
}

export function InboxView({ initialThreadId }: InboxViewProps) {
  const router = useRouter()
  const [threads, setThreads] = useState<ChatThread[]>(chatThreads)
  // On the thread-detail page (initialThreadId set), selectedId is driven by the URL.
  // On the inbox root, the user can pick a thread locally.
  const [internalSelectedId, setInternalSelectedId] = useState<string>(chatThreads[0].id)
  const selectedId = initialThreadId ?? internalSelectedId
  const [query, setQuery] = useState("")
  const [draft, setDraft] = useState("")
  // Mobile shows list by default on root; thread-detail always shows the conversation.
  const [internalShowList, setInternalShowList] = useState(true)
  const showMobileList = initialThreadId ? false : internalShowList
  // Message store in state so sending triggers a proper re-render.
  const [messageStore, setMessageStore] = useState<InboxMessage[]>(seedMessages)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const selectedThread = threads.find(t => t.id === selectedId) ?? threads[0]

  const messages = useMemo(() => {
    return messageStore
      .filter(m => m.threadId === selectedId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
  }, [messageStore, selectedId])

  const filteredThreads = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return threads
    return threads.filter(t =>
      t.name.toLowerCase().includes(q) ||
      t.lastMessage.toLowerCase().includes(q)
    )
  }, [threads, query])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages.length, selectedId])

  const totalUnread = threads.reduce((sum, t) => sum + t.unread, 0)

  const handleSelect = (id: string) => {
    setInternalSelectedId(id)
    setInternalShowList(false)
    setThreads(prev => prev.map(t => t.id === id ? { ...t, unread: 0 } : t))
    if (initialThreadId) {
      router.push(`/inbox/${id}`)
    }
  }

  const handleSend = () => {
    const text = draft.trim()
    if (!text) return
    const newMsg: InboxMessage = {
      id: `mine-${Date.now()}`,
      threadId: selectedId,
      authorId: "u1",
      authorName: currentMember.name,
      authorAvatar: currentMember.avatar,
      body: text,
      createdAt: new Date().toISOString(),
      mine: true,
    }
    setMessageStore(prev => [...prev, newMsg])
    setDraft("")
    setThreads(prev => prev.map(t => t.id === selectedId ? {
      ...t,
      lastMessage: `You: ${text}`,
      lastMessageAt: new Date().toISOString(),
    } : t))
    toast.success("Message sent", { description: `To ${selectedThread.name}` })
  }

  return (
    <DashboardShell
      title="Inbox"
      description="Direct messages and group threads with your team."
      actions={
        <>
          <Badge variant="secondary" className="h-9 px-3 gap-1.5 bg-primary/10 text-primary border-primary/20">
            <Sparkles className="w-3.5 h-3.5" />
            {totalUnread} unread
          </Badge>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Archive className="w-3.5 h-3.5" /> Archive
          </Button>
        </>
      }
    >
      <Card className="p-0 overflow-hidden border border-border rounded-xl">
        <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] xl:grid-cols-[300px_1fr_300px] h-[calc(100vh-220px)] min-h-[560px]">
          {/* LEFT — thread list */}
          <aside
            className={cn(
              "border-r border-border flex flex-col bg-card",
              showMobileList ? "block" : "hidden lg:flex"
            )}
          >
            <div className="p-3 border-b border-border">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input
                  value={query}
                  onChange={e => setQuery(e.target.value)}
                  placeholder="Search threads…"
                  className="h-8 pl-8 text-xs bg-secondary/50 border-transparent focus-visible:bg-card focus-visible:border-border"
                />
              </div>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-1.5">
                {filteredThreads.length === 0 ? (
                  <div className="p-8 text-center">
                    <p className="text-xs text-muted-foreground">No threads match &quot;{query}&quot;</p>
                  </div>
                ) : (
                  filteredThreads.map(thread => {
                    const isSel = thread.id === selectedId
                    return (
                      <button
                        key={thread.id}
                        onClick={() => handleSelect(thread.id)}
                        className={cn(
                          "w-full flex items-start gap-2.5 p-2.5 rounded-lg text-left transition-colors group",
                          isSel ? "bg-primary/10 ring-1 ring-primary/20" : "hover:bg-secondary/60"
                        )}
                      >
                        <div className="relative shrink-0">
                          {thread.isGroup ? (
                            <div className="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center text-primary font-semibold text-xs ring-2 ring-card">
                              {thread.name.replace("#", "").slice(0, 2).toUpperCase()}
                            </div>
                          ) : (
                            <Avatar className="w-10 h-10 ring-2 ring-card">
                              <AvatarImage src={thread.avatar} alt={thread.name} />
                              <AvatarFallback className="text-xs">{initials(thread.name)}</AvatarFallback>
                            </Avatar>
                          )}
                          {thread.unread > 0 && (
                            <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center ring-2 ring-card">
                              {thread.unread}
                            </span>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <p className={cn(
                              "text-xs truncate",
                              thread.unread > 0 ? "font-bold text-foreground" : "font-medium text-foreground"
                            )}>
                              {thread.name}
                            </p>
                            <span className="text-[10px] text-muted-foreground shrink-0">
                              {timeAgo(thread.lastMessageAt)}
                            </span>
                          </div>
                          <p className={cn(
                            "text-[11px] text-muted-foreground truncate mt-0.5",
                            thread.unread > 0 && "text-foreground/70"
                          )}>
                            {thread.lastMessage}
                          </p>
                        </div>
                      </button>
                    )
                  })
                )}
              </div>
            </ScrollArea>
          </aside>

          {/* MIDDLE — message stream + composer */}
          <section
            className={cn(
              "flex flex-col min-w-0",
              showMobileList ? "hidden lg:flex" : "flex"
            )}
          >
            {/* Thread header */}
            <div className="flex items-center gap-2 p-3 border-b border-border bg-card">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 lg:hidden"
                onClick={() => setInternalShowList(true)}
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              {selectedThread.isGroup ? (
                <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center text-primary font-semibold text-xs">
                  {selectedThread.name.replace("#", "").slice(0, 2).toUpperCase()}
                </div>
              ) : (
                <Avatar className="w-9 h-9">
                  <AvatarImage src={selectedThread.avatar} alt={selectedThread.name} />
                  <AvatarFallback className="text-xs">{initials(selectedThread.name)}</AvatarFallback>
                </Avatar>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  {selectedThread.isGroup && <Hash className="w-3.5 h-3.5 text-muted-foreground" />}
                  <p className="text-sm font-semibold text-foreground truncate">{selectedThread.name}</p>
                </div>
                <p className="text-[11px] text-muted-foreground truncate">
                  {selectedThread.isGroup
                    ? `${selectedThread.participants.length} members`
                    : "Direct message"}
                </p>
              </div>
              <div className="flex items-center gap-0.5">
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <Phone className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <Video className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <Star className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 bg-secondary/20">
              <div className="p-4 space-y-4">
                {/* Day separator */}
                <div className="flex items-center gap-3 my-2">
                  <div className="flex-1 h-px bg-border" />
                  <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    {formatDate(messages[0]?.createdAt ?? new Date().toISOString(), { month: "short", day: "numeric" })}
                  </span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                {messages.map((msg, idx) => {
                  const prev = messages[idx - 1]
                  const showAvatar = !prev || prev.authorId !== msg.authorId
                  return (
                    <div
                      key={msg.id}
                      className={cn(
                        "flex gap-2.5 animate-fade-in",
                        msg.mine ? "flex-row-reverse" : "flex-row"
                      )}
                    >
                      <div className="w-8 shrink-0">
                        {showAvatar && (
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={msg.authorAvatar} alt={msg.authorName} />
                            <AvatarFallback className="text-[10px]">{initials(msg.authorName)}</AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                      <div className={cn("max-w-[75%]", msg.mine && "items-end flex flex-col")}>
                        {showAvatar && (
                          <div className={cn("flex items-center gap-1.5 mb-0.5", msg.mine && "flex-row-reverse")}>
                            <span className="text-xs font-semibold text-foreground">{msg.mine ? "You" : msg.authorName}</span>
                            <span className="text-[10px] text-muted-foreground">
                              {new Date(msg.createdAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
                            </span>
                          </div>
                        )}
                        <div
                          className={cn(
                            "px-3 py-2 rounded-2xl text-xs leading-relaxed",
                            msg.mine
                              ? "bg-primary text-primary-foreground rounded-tr-sm"
                              : "bg-card border border-border rounded-tl-sm"
                          )}
                        >
                          {msg.body}
                        </div>
                      </div>
                    </div>
                  )
                })}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Composer */}
            <div className="p-3 border-t border-border bg-card">
              <div className="flex items-end gap-2">
                <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0 text-muted-foreground hover:text-foreground">
                  <Paperclip className="w-4 h-4" />
                </Button>
                <div className="flex-1 relative">
                  <Textarea
                    value={draft}
                    onChange={e => setDraft(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault()
                        handleSend()
                      }
                    }}
                    placeholder={`Message ${selectedThread.name}…`}
                    rows={1}
                    className="text-xs resize-none min-h-[36px] max-h-32 pr-9"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-1 bottom-1 h-7 w-7 text-muted-foreground hover:text-foreground"
                  >
                    <SmilePlus className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <Button
                  onClick={handleSend}
                  disabled={!draft.trim()}
                  size="icon"
                  className="h-9 w-9 shrink-0 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5 px-1">
                Press <kbd className="px-1 py-0.5 rounded bg-muted border border-border text-[9px] font-semibold">Enter</kbd> to send · <kbd className="px-1 py-0.5 rounded bg-muted border border-border text-[9px] font-semibold">Shift+Enter</kbd> for new line
              </p>
            </div>
          </section>

          {/* RIGHT — details */}
          <aside className="hidden xl:flex flex-col border-l border-border bg-card overflow-y-auto">
            <div className="p-4 border-b border-border">
              <div className="flex items-center gap-2 mb-1">
                <Info className="w-3.5 h-3.5 text-muted-foreground" />
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Thread details</p>
              </div>
            </div>

            {/* Participants */}
            <div className="p-4 border-b border-border">
              <div className="flex items-center gap-2 mb-3">
                <Users className="w-3.5 h-3.5 text-muted-foreground" />
                <p className="text-xs font-semibold text-foreground">Participants</p>
                <Badge variant="secondary" className="ml-auto text-[10px]">
                  {(threadParticipants[selectedThread.id] ?? selectedThread.participants).length}
                </Badge>
              </div>
              <div className="space-y-2">
                {(threadParticipants[selectedThread.id] ?? selectedThread.participants).map(p => (
                  <div key={p.name} className="flex items-center gap-2.5">
                    <Avatar className="w-7 h-7">
                      <AvatarImage src={p.avatar} alt={p.name} />
                      <AvatarFallback className="text-[10px]">{initials(p.name)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">
                        {p.name}{p.name === currentMember.name && " (you)"}
                      </p>
                      {"role" in p && p.role && (
                        <p className="text-[10px] text-muted-foreground truncate">{p.role}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Attachments */}
            <div className="p-4 border-b border-border">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                <p className="text-xs font-semibold text-foreground">Attachments</p>
                <Badge variant="secondary" className="ml-auto text-[10px]">
                  {(threadAttachments[selectedThread.id] ?? []).length}
                </Badge>
              </div>
              <div className="space-y-2">
                {(threadAttachments[selectedThread.id] ?? []).length === 0 ? (
                  <p className="text-[11px] text-muted-foreground italic">No attachments yet</p>
                ) : (
                  (threadAttachments[selectedThread.id] ?? []).map(att => (
                    <div
                      key={att.name}
                      className="flex items-center gap-2.5 p-2 rounded-lg border border-border hover:bg-secondary/50 transition-colors cursor-pointer group"
                    >
                      <div className="w-8 h-8 rounded-md bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <FileText className="w-3.5 h-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-foreground truncate">{att.name}</p>
                        <p className="text-[10px] text-muted-foreground">{att.size} · {att.owner}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Linked task */}
            <div className="p-4">
              <div className="flex items-center gap-2 mb-3">
                <Link2 className="w-3.5 h-3.5 text-muted-foreground" />
                <p className="text-xs font-semibold text-foreground">Linked task</p>
              </div>
              {threadLinkedTask[selectedThread.id] ? (
                <Link
                  href="#"
                  className="block p-3 rounded-lg border border-border hover:border-primary/40 hover:bg-primary/5 transition-colors group"
                >
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-mono font-semibold text-primary">{threadLinkedTask[selectedThread.id].key}</p>
                      <p className="text-xs font-medium text-foreground mt-0.5">{threadLinkedTask[selectedThread.id].title}</p>
                      <p className="text-[10px] text-muted-foreground mt-1">{threadLinkedTask[selectedThread.id].project}</p>
                    </div>
                  </div>
                </Link>
              ) : (
                <p className="text-[11px] text-muted-foreground italic">No linked task</p>
              )}

              <Button
                variant="outline"
                size="sm"
                className="w-full mt-4 h-8 text-xs gap-1.5 bg-transparent"
                onClick={() => toast.info("Archive action (demo only)")}
              >
                <Archive className="w-3.5 h-3.5" /> Archive thread
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full mt-1.5 h-8 text-xs gap-1.5 text-destructive hover:text-destructive hover:bg-destructive/10"
                onClick={() => toast.info("Delete action (demo only)")}
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete thread
              </Button>
            </div>
          </aside>
        </div>
      </Card>
    </DashboardShell>
  )
}
