"use client"

import { use } from "react"
import { notFound } from "next/navigation"
import { chatThreads } from "@/lib/data/mock"
import { InboxView } from "../_inbox-view"

export default function InboxThreadPage({ params }: { params: Promise<{ threadId: string }> }) {
  const { threadId } = use(params)
  const thread = chatThreads.find(t => t.id === threadId)
  if (!thread) notFound()
  return <InboxView initialThreadId={threadId} />
}
