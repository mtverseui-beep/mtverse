"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  Home, Search, BookOpen, ChevronRight, ChevronDown, FileText, Pencil, History,
  Eye, Clock, Hash, Plus, Library, ListTree,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn, formatDate, timeAgo, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

type WikiPage = {
  id: string
  title: string
  slug: string
  parent?: string
  content: { heading: string; body: string }[]
  author: string
  authorAvatar: string
  updatedAt: string
  views: number
}

const wikiPages: WikiPage[] = [
  {
    id: "w1", title: "Welcome to Planna Wiki", slug: "welcome", parent: undefined,
    content: [
      { heading: "What is Planna Wiki?", body: "Planna Wiki is the single source of truth for how we work. Every team — Engineering, Product, Design, Operations, HR, Finance — contributes here. If it's not in the wiki, it's not real." },
      { heading: "How to navigate", body: "Use the page tree on the left to browse by category. The table of contents on the right shows the structure of the current page. Use search at the top to find anything across all pages." },
      { heading: "Editing pages", body: "Anyone on the team can edit most pages — click the Edit button in the top right. Changes are versioned, so you can always roll back. For sensitive pages (security, finance), editing is restricted to owners." },
    ],
    author: "Jessin Sam", authorAvatar: members[0].avatar, updatedAt: new Date(Date.now() - 2 * 86400_000).toISOString(), views: 4287,
  },
  {
    id: "w2", title: "Engineering Handbook", slug: "engineering", parent: undefined,
    content: [
      { heading: "Overview", body: "Everything an engineer at Planna needs to know: setup, workflow, code review, deployment, on-call." },
      { heading: "Tech stack", body: "Frontend: Next.js 16, TypeScript, Tailwind CSS 4, shadcn/ui. Backend: Node.js, Prisma, SQLite (dev) / PostgreSQL (prod). Infra: Caddy gateway, Bun runtime." },
    ],
    author: "Theo Nakamura", authorAvatar: members[2].avatar, updatedAt: new Date(Date.now() - 1 * 86400_000).toISOString(), views: 3120,
  },
  {
    id: "w3", title: "Development Environment", slug: "engineering/dev-env", parent: "w2",
    content: [
      { heading: "Prerequisites", body: "Install Node.js 22+, Bun 1.2+, and Git. Clone the repo and run `bun install` from the project root." },
      { heading: "First run", body: "Run `bun run db:push` to set up your local SQLite database, then `bun run dev` to start the dev server on port 3000." },
      { heading: "Common issues", body: "If you see port conflicts, check that no other process is using 3000. If Prisma throws, delete the dev.db file and re-run db:push." },
    ],
    author: "Amara Okafor", authorAvatar: members[5].avatar, updatedAt: new Date(Date.now() - 3 * 86400_000).toISOString(), views: 1842,
  },
  {
    id: "w4", title: "Code Review Process", slug: "engineering/code-review", parent: "w2",
    content: [
      { heading: "Why we review", body: "Code review catches bugs, spreads knowledge, and keeps the codebase consistent. Every PR requires at least one approval before merge." },
      { heading: "Review SLA", body: "PRs should get a first review within 4 working hours. Use the #pr-review channel to ping reviewers if it's urgent." },
      { heading: "What to look for", body: "Correctness, tests, performance, security, and readability. Nitpicks go in a separate comment thread marked 'nit'." },
    ],
    author: "Theo Nakamura", authorAvatar: members[2].avatar, updatedAt: new Date(Date.now() - 0 * 86400_000).toISOString(), views: 1293,
  },
  {
    id: "w5", title: "Product Playbook", slug: "product", parent: undefined,
    content: [
      { heading: "Our process", body: "Discovery → Spec → Build → Launch → Learn. Each phase has clear exit criteria documented in this wiki." },
      { heading: "Roadmap planning", body: "Quarterly planning happens in the last 2 weeks of each quarter. PMs propose, eng leads estimate, and we lock themes." },
    ],
    author: "Zara Marlowe", authorAvatar: members[1].avatar, updatedAt: new Date(Date.now() - 5 * 86400_000).toISOString(), views: 2104,
  },
  {
    id: "w6", title: "Writing PRDs", slug: "product/prd", parent: "w5",
    content: [
      { heading: "PRD template", body: "Use the PRD template from the Templates library. The 6 sections are: Problem, Goals, User stories, Success metrics, Rollout plan, Open questions." },
      { heading: "Review flow", body: "Draft → Eng review → Design review → Leadership sign-off. Each stage takes ~2 days." },
    ],
    author: "Zara Marlowe", authorAvatar: members[1].avatar, updatedAt: new Date(Date.now() - 6 * 86400_000).toISOString(), views: 987,
  },
  {
    id: "w7", title: "Design System", slug: "design", parent: undefined,
    content: [
      { heading: "Foundations", body: "Our design system is built on tokens — color, type, spacing, motion. See the Tokens page for the full list." },
      { heading: "Components", body: "We use shadcn/ui as the base layer, customized with our green identity. New components go in `src/components/ui/`." },
    ],
    author: "Mira Patel", authorAvatar: members[3].avatar, updatedAt: new Date(Date.now() - 4 * 86400_000).toISOString(), views: 1654,
  },
  {
    id: "w8", title: "Design Tokens", slug: "design/tokens", parent: "w7",
    content: [
      { heading: "Color tokens", body: "Primary is emerald green (oklch 0.42 0.15 155). We have 5 chart colors derived from the primary. See globals.css for the full palette." },
      { heading: "Type scale", body: "Display: 2xl/3xl. Body: sm/base. Caption: xs. All sizes use rem so they scale with the root font." },
      { heading: "Adding a token", body: "Open a design system issue, propose the token in Figma, get review from the design team, then ship to globals.css." },
    ],
    author: "Mira Patel", authorAvatar: members[3].avatar, updatedAt: new Date(Date.now() - 2 * 86400_000).toISOString(), views: 1102,
  },
  {
    id: "w9", title: "Operations Runbooks", slug: "operations", parent: undefined,
    content: [
      { heading: "On-call rotation", body: "Weekly rotation across the engineering team. Handoff happens every Monday at 10am PT." },
      { heading: "Incident severity", body: "Sev1: user-facing outage. Sev2: degraded experience. Sev3: minor bug. Each has its own response SLA." },
    ],
    author: "Hugo Lindqvist", authorAvatar: members[8].avatar, updatedAt: new Date(Date.now() - 7 * 86400_000).toISOString(), views: 832,
  },
  {
    id: "w10", title: "HR Policies", slug: "hr", parent: undefined,
    content: [
      { heading: "Time off", body: "Unlimited PTO with a 2-week minimum. Anything over 2 weeks needs manager approval 30 days in advance." },
      { heading: "Remote work", body: "We're remote-first with optional office time. Quarterly offsites are mandatory for full-time staff." },
    ],
    author: "Jessin Sam", authorAvatar: members[0].avatar, updatedAt: new Date(Date.now() - 14 * 86400_000).toISOString(), views: 712,
  },
  {
    id: "w11", title: "Finance Processes", slug: "finance", parent: undefined,
    content: [
      { heading: "Expense reports", body: "Submit within 30 days via the finance portal. Receipts required for anything over $25." },
      { heading: "Vendor onboarding", body: "New vendors require a security review and a W-9 (US) or equivalent. Allow 2 weeks for processing." },
    ],
    author: "Naomi Chen", authorAvatar: members[7].avatar, updatedAt: new Date(Date.now() - 11 * 86400_000).toISOString(), views: 487,
  },
]

// Build the tree
function buildTree(pages: WikiPage[]) {
  const roots = pages.filter(p => !p.parent)
  const childrenOf = (id: string) => pages.filter(p => p.parent === id)
  return { roots, childrenOf }
}

export default function WikiPage() {
  const { toast } = useToast()
  const { roots, childrenOf } = buildTree(wikiPages)
  const [activeId, setActiveId] = useState<string>("w1")
  const [expanded, setExpanded] = useState<Set<string>>(new Set(["w2", "w5", "w7"]))
  const [query, setQuery] = useState("")

  const activePage = wikiPages.find(p => p.id === activeId) ?? wikiPages[0]

  const searchResults = useMemo(() => {
    if (!query.trim()) return []
    const q = query.toLowerCase()
    return wikiPages.filter(p => p.title.toLowerCase().includes(q) || p.content.some(c => c.heading.toLowerCase().includes(q) || c.body.toLowerCase().includes(q)))
  }, [query])

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const renderTree = (page: WikiPage, depth = 0) => {
    const children = childrenOf(page.id)
    const isExpanded = expanded.has(page.id)
    const isActive = activeId === page.id
    return (
      <div key={page.id}>
        <button
          onClick={() => setActiveId(page.id)}
          className={cn(
            "w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-xs transition-colors text-left",
            isActive ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-muted hover:text-foreground"
          )}
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
        >
          {children.length > 0 ? (
            <span
              onClick={(e) => { e.stopPropagation(); toggleExpand(page.id) }}
              className="shrink-0 cursor-pointer"
              role="button"
              aria-label={isExpanded ? "Collapse" : "Expand"}
            >
              {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            </span>
          ) : (
            <span className="w-3 shrink-0" />
          )}
          <FileText className={cn("w-3.5 h-3.5 shrink-0", isActive && "text-primary")} />
          <span className="truncate">{page.title}</span>
        </button>
        {isExpanded && children.length > 0 && (
          <div>{children.map(c => renderTree(c, depth + 1))}</div>
        )}
      </div>
    )
  }

  return (
    <DashboardShell
      title="Wiki"
      description="A living, versioned knowledge base. Browse the page tree, search, and edit any page."
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbLink asChild><Link href="/knowledge">Knowledge</Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Wiki</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent" onClick={() => toast({ title: "Edit mode", description: "Page editor would open." })}>
            <Pencil className="w-4 h-4" /> Edit
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast({ title: "New wiki page", description: "Page creator would open." })}>
            <Plus className="w-4 h-4" /> New page
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr_220px] gap-4">
        {/* Page tree sidebar */}
        <aside className="space-y-4">
          <Card className="p-3">
            <div className="relative mb-3">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                placeholder="Search wiki…"
                value={query}
                onChange={e => setQuery(e.target.value)}
                className="pl-8 h-8 text-xs"
              />
            </div>
            {searchResults.length > 0 ? (
              <div className="space-y-0.5">
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-1">{searchResults.length} results</p>
                {searchResults.map(p => (
                  <button
                    key={p.id}
                    onClick={() => { setActiveId(p.id); setQuery("") }}
                    className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs text-muted-foreground hover:bg-muted hover:text-foreground transition-colors text-left"
                  >
                    <FileText className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{p.title}</span>
                  </button>
                ))}
              </div>
            ) : (
              <div>
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-1 flex items-center gap-1.5">
                  <Library className="w-3 h-3" /> Page tree
                </p>
                <div className="max-h-[60vh] overflow-y-auto scroll-area-thin pr-1">
                  {roots.map(p => renderTree(p))}
                </div>
              </div>
            )}
          </Card>
        </aside>

        {/* Main content */}
        <div className="min-w-0">
          <Card className="p-5 md:p-6">
            {/* Page header */}
            <div className="flex items-start justify-between gap-3 mb-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1.5">
                  <BookOpen className="w-4 h-4 text-primary shrink-0" />
                  <Badge variant="outline" className="text-[10px]">{activePage.slug}</Badge>
                </div>
                <h1 className="text-xl md:text-2xl font-bold text-foreground leading-tight">{activePage.title}</h1>
              </div>
            </div>

            {/* Meta row */}
            <div className="flex items-center gap-3 flex-wrap mb-5 pb-4 border-b border-border">
              <div className="flex items-center gap-2">
                <Avatar className="w-6 h-6">
                  <AvatarImage src={activePage.authorAvatar} alt={activePage.author} />
                  <AvatarFallback className="text-[9px]">{initials(activePage.author)}</AvatarFallback>
                </Avatar>
                <span className="text-xs text-muted-foreground">by <span className="font-medium text-foreground">{activePage.author}</span></span>
              </div>
              <Separator orientation="vertical" className="h-4" />
              <span className="text-xs text-muted-foreground flex items-center gap-1.5"><Clock className="w-3 h-3" /> Updated {timeAgo(activePage.updatedAt)}</span>
              <Separator orientation="vertical" className="h-4" />
              <span className="text-xs text-muted-foreground flex items-center gap-1.5"><Eye className="w-3 h-3" /> {activePage.views.toLocaleString()} views</span>
              <Separator orientation="vertical" className="h-4" />
              <button className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5" onClick={() => toast({ title: "Version history", description: "Showing all page revisions." })}>
                <History className="w-3 h-3" /> History
              </button>
            </div>

            {/* Content */}
            <article className="space-y-6">
              {activePage.content.map((section, i) => (
                <section key={i} id={`section-${i}`} className="scroll-mt-20 animate-fade-in" style={{ animationDelay: `${i * 60}ms` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Hash className="w-3.5 h-3.5 text-primary" />
                    <h2 className="text-base font-semibold text-foreground">{section.heading}</h2>
                  </div>
                  <p className="text-sm text-foreground/80 leading-relaxed pl-5">{section.body}</p>
                </section>
              ))}
            </article>

            {/* Footer */}
            <div className="flex items-center justify-between mt-8 pt-4 border-t border-border">
              <p className="text-[10px] text-muted-foreground">Last edited by {activePage.author} on {formatDate(activePage.updatedAt)}</p>
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent" onClick={() => toast({ title: "Edit mode", description: "Page editor would open." })}>
                <Pencil className="w-3 h-3" /> Edit this page
              </Button>
            </div>
          </Card>
        </div>

        {/* TOC sidebar */}
        <aside className="space-y-4">
          <Card className="p-4 sticky top-4">
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <ListTree className="w-3 h-3" /> On this page
            </p>
            <nav className="space-y-1">
              {activePage.content.map((section, i) => (
                <a
                  key={i}
                  href={`#section-${i}`}
                  className="block text-xs text-muted-foreground hover:text-primary transition-colors py-1 pl-3 border-l border-border hover:border-primary"
                >
                  {section.heading}
                </a>
              ))}
            </nav>
            <Separator className="my-3" />
            <div className="space-y-2">
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Page info</p>
              <div className="text-[10px] text-muted-foreground space-y-1">
                <p>Slug: <code className="text-foreground font-mono">{activePage.slug}</code></p>
                <p>Sections: <span className="text-foreground font-medium">{activePage.content.length}</span></p>
                <p>Views: <span className="text-foreground font-medium">{activePage.views.toLocaleString()}</span></p>
              </div>
            </div>
          </Card>
        </aside>
      </div>
    </DashboardShell>
  )
}
