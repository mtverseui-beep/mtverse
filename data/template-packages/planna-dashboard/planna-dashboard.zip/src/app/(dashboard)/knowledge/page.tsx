"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  Home, Search, BookOpen, TrendingUp, Clock, Eye, ArrowRight, Plus,
  Code, Package, Palette, Settings, Users, DollarSign, FileText,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn, timeAgo, formatDate, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

type Article = {
  id: string
  title: string
  excerpt: string
  body: string
  category: string
  author: string
  authorAvatar: string
  updatedAt: string
  views: number
  tags: string[]
  popular?: boolean
}

const categoryConfig: Record<string, { label: string; icon: any; color: string }> = {
  Engineering: { label: "Engineering", icon: Code, color: "bg-emerald-500" },
  Product: { label: "Product", icon: Package, color: "bg-teal-500" },
  Design: { label: "Design", icon: Palette, color: "bg-lime-500" },
  Operations: { label: "Operations", icon: Settings, color: "bg-cyan-500" },
  HR: { label: "HR", icon: Users, color: "bg-amber-500" },
  Finance: { label: "Finance", icon: DollarSign, color: "bg-green-500" },
}

const articles: Article[] = [
  { id: "k1", title: "How we ship to production 12× per day", excerpt: "Our trunk-based development flow, feature flags, and progressive rollout strategy that lets the team ship confidently multiple times a day.", body: "", category: "Engineering", author: "Theo Nakamura", authorAvatar: members[2].avatar, updatedAt: new Date(Date.now() - 1 * 86400_000).toISOString(), views: 1242, tags: ["deploy", "ci-cd", "process"], popular: true },
  { id: "k2", title: "Writing a PRD that engineers actually love", excerpt: "The 6-section PRD template we use at Planna, plus the anti-patterns that kill alignment before kickoff.", body: "", category: "Product", author: "Zara Marlowe", authorAvatar: members[1].avatar, updatedAt: new Date(Date.now() - 3 * 86400_000).toISOString(), views: 987, tags: ["prd", "process", "spec"], popular: true },
  { id: "k3", title: "Design tokens: a complete guide", excerpt: "Everything you need to know about our token system — color, type, spacing, motion — and how to add a new one safely.", body: "", category: "Design", author: "Mira Patel", authorAvatar: members[3].avatar, updatedAt: new Date(Date.now() - 5 * 86400_000).toISOString(), views: 856, tags: ["design-system", "tokens"], popular: true },
  { id: "k4", title: "Onboarding a new engineer in week one", excerpt: "The buddy system, environment setup script, and first-PR checklist that gets new hires shipping by day 5.", body: "", category: "Engineering", author: "Amara Okafor", authorAvatar: members[5].avatar, updatedAt: new Date(Date.now() - 7 * 86400_000).toISOString(), views: 743, tags: ["onboarding", "process"] },
  { id: "k5", title: "Pricing experiments for H1 2026", excerpt: "Three pricing tests we ran, what we learned about conversion, and how we're rolling out the winning variant.", body: "", category: "Product", author: "Isla Reyes", authorAvatar: members[9].avatar, updatedAt: new Date(Date.now() - 4 * 86400_000).toISOString(), views: 612, tags: ["pricing", "growth"] },
  { id: "k6", title: "Accessibility checklist for new components", excerpt: "Before a component ships, it must pass this 14-point checklist — keyboard, screen reader, color contrast, focus management.", body: "", category: "Design", author: "Mira Patel", authorAvatar: members[3].avatar, updatedAt: new Date(Date.now() - 2 * 86400_000).toISOString(), views: 1102, tags: ["a11y", "design-system"], popular: true },
  { id: "k7", title: "Incident response: roles & runbooks", excerpt: "Who does what when the pager goes off. Commander, comms lead, ops lead — plus links to all live runbooks.", body: "", category: "Operations", author: "Hugo Lindqvist", authorAvatar: members[8].avatar, updatedAt: new Date(Date.now() - 6 * 86400_000).toISOString(), views: 489, tags: ["oncall", "incident", "runbook"] },
  { id: "k8", title: "Hiring loop for senior engineers", excerpt: "Our 5-stage interview loop, what each stage evaluates, and the calibration rubric we use for hiring decisions.", body: "", category: "HR", author: "Jessin Sam", authorAvatar: members[0].avatar, updatedAt: new Date(Date.now() - 9 * 86400_000).toISOString(), views: 312, tags: ["hiring", "process"] },
  { id: "k9", title: "Quarterly budget reconciliation", excerpt: "The finance team's step-by-step process for closing the books each quarter, including common reconciliation issues.", body: "", category: "Finance", author: "Naomi Chen", authorAvatar: members[7].avatar, updatedAt: new Date(Date.now() - 12 * 86400_000).toISOString(), views: 218, tags: ["finance", "process"] },
  { id: "k10", title: "Code review guidelines", excerpt: "What we look for in a review, how to write actionable comments, and the SLA for reviewing PRs across timezones.", body: "", category: "Engineering", author: "Theo Nakamura", authorAvatar: members[2].avatar, updatedAt: new Date(Date.now() - 0 * 86400_000).toISOString(), views: 932, tags: ["code-review", "process"] },
  { id: "k11", title: "Vendor security review process", excerpt: "Before signing with any vendor, we run a security review. Here's the questionnaire, scoring rubric, and approval flow.", body: "", category: "Operations", author: "Hugo Lindqvist", authorAvatar: members[8].avatar, updatedAt: new Date(Date.now() - 8 * 86400_000).toISOString(), views: 287, tags: ["security", "vendor"] },
  { id: "k12", title: "Performance review cycle 2026", excerpt: "Timeline, forms, calibration sessions, and how we translate reviews into compensation and promotions.", body: "", category: "HR", author: "Jessin Sam", authorAvatar: members[0].avatar, updatedAt: new Date(Date.now() - 14 * 86400_000).toISOString(), views: 405, tags: ["reviews", "people"] },
]

export default function KnowledgePage() {
  const { toast } = useToast()
  const [query, setQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState<string>("all")

  const filtered = useMemo(() => {
    let list = [...articles]
    if (activeCategory !== "all") list = list.filter(a => a.category === activeCategory)
    if (query.trim()) {
      const q = query.toLowerCase()
      list = list.filter(a => a.title.toLowerCase().includes(q) || a.excerpt.toLowerCase().includes(q) || a.tags.some(t => t.toLowerCase().includes(q)))
    }
    return list
  }, [query, activeCategory])

  const popular = articles.filter(a => a.popular).sort((a, b) => b.views - a.views)
  const recent = [...articles].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()).slice(0, 4)
  const grouped = useMemo(() => {
    const map = new Map<string, Article[]>()
    filtered.forEach(a => {
      if (!map.has(a.category)) map.set(a.category, [])
      map.get(a.category)!.push(a)
    })
    return Array.from(map.entries())
  }, [filtered])

  return (
    <DashboardShell
      title="Knowledge base"
      description="Internal articles, runbooks, and playbooks — searchable, browsable, and always up to date."
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Knowledge</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast({ title: "New article", description: "Article editor would open." })}>
          <Plus className="w-4 h-4" /> New article
        </Button>
      }
    >
      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search articles, tags, authors…"
          value={query}
          onChange={e => setQuery(e.target.value)}
          className="pl-9 h-10 text-sm"
        />
      </div>

      {/* Category chips */}
      <div className="flex items-center gap-1.5 flex-wrap mb-6">
        <button
          onClick={() => setActiveCategory("all")}
          className={cn(
            "text-xs px-3 py-1.5 rounded-full border transition-colors flex items-center gap-1.5",
            activeCategory === "all" ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground border-border hover:bg-muted hover:text-foreground"
          )}
        >
          <BookOpen className="w-3 h-3" /> All ({articles.length})
        </button>
        {Object.entries(categoryConfig).map(([key, c]) => {
          const count = articles.filter(a => a.category === key).length
          const Icon = c.icon
          return (
            <button
              key={key}
              onClick={() => setActiveCategory(key)}
              className={cn(
                "text-xs px-3 py-1.5 rounded-full border transition-colors flex items-center gap-1.5",
                activeCategory === key ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground border-border hover:bg-muted hover:text-foreground"
              )}
            >
              <Icon className="w-3 h-3" /> {c.label} ({count})
            </button>
          )
        })}
      </div>

      {/* Popular articles */}
      {!query && activeCategory === "all" && (
        <Card className="p-4 md:p-5 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Popular articles</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {popular.map((a, i) => (
              <ArticleRow key={a.id} article={a} index={i} highlight />
            ))}
          </div>
        </Card>
      )}

      {/* Recently updated */}
      {!query && activeCategory === "all" && (
        <Card className="p-4 md:p-5 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Recently updated</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {recent.map((a, i) => (
              <ArticleRow key={a.id} article={a} index={i} />
            ))}
          </div>
        </Card>
      )}

      {/* Articles grouped by category */}
      <div className="space-y-6">
        {grouped.map(([category, list]) => {
          const c = categoryConfig[category]
          const Icon = c?.icon ?? FileText
          return (
            <div key={category}>
              <div className="flex items-center gap-2 mb-3">
                <span className={cn("w-7 h-7 rounded-lg flex items-center justify-center", c?.color ?? "bg-muted")}>
                  <Icon className="w-3.5 h-3.5 text-white" />
                </span>
                <h3 className="text-sm font-semibold">{c?.label ?? category}</h3>
                <Badge variant="outline" className="text-[10px]">{list.length}</Badge>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {list.map((a, i) => (
                  <ArticleCard key={a.id} article={a} index={i} />
                ))}
              </div>
            </div>
          )
        })}
      </div>

      {filtered.length === 0 && (
        <Card className="p-8 flex flex-col items-center text-center border-dashed mt-3">
          <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-3">
            <BookOpen className="w-5 h-5 text-muted-foreground" />
          </div>
          <p className="text-sm font-semibold mb-1">No articles found</p>
          <p className="text-xs text-muted-foreground">Try a different category or search term.</p>
        </Card>
      )}
    </DashboardShell>
  )
}

function ArticleRow({ article, index, highlight }: { article: Article; index: number; highlight?: boolean }) {
  const c = categoryConfig[article.category]
  const Icon = c?.icon ?? FileText
  return (
    <Link
      href={`/knowledge/wiki`}
      className="block group animate-slide-in-up"
      style={{ animationDelay: `${Math.min(index * 40, 200)}ms` }}
    >
      <Card className={cn("p-3 card-lift flex items-start gap-3", highlight && "bg-primary/5")}>
        <span className={cn("w-9 h-9 rounded-lg flex items-center justify-center shrink-0", c?.color ?? "bg-muted")}>
          <Icon className="w-4 h-4 text-white" />
        </span>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-1">{article.title}</p>
          <p className="text-[10px] text-muted-foreground line-clamp-1 mt-0.5">{article.excerpt}</p>
          <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {article.views.toLocaleString()}</span>
            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {timeAgo(article.updatedAt)}</span>
          </div>
        </div>
        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0 mt-1" />
      </Card>
    </Link>
  )
}

function ArticleCard({ article, index }: { article: Article; index: number }) {
  const c = categoryConfig[article.category]
  const Icon = c?.icon ?? FileText
  return (
    <Link
      href={`/knowledge/wiki`}
      className="block group animate-slide-in-up"
      style={{ animationDelay: `${Math.min(index * 40, 280)}ms` }}
    >
      <Card className="p-4 card-lift h-full flex flex-col">
        <div className="flex items-start gap-2 mb-2">
          <span className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", c?.color ?? "bg-muted")}>
            <Icon className="w-4 h-4 text-white" />
          </span>
          <Badge variant="outline" className="text-[9px] h-4 px-1.5">{c?.label ?? article.category}</Badge>
        </div>
        <h4 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors leading-tight mb-1.5">{article.title}</h4>
        <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 mb-3 flex-1">{article.excerpt}</p>
        <div className="flex items-center justify-between pt-3 border-t border-border">
          <div className="flex items-center gap-1.5 min-w-0">
            <Avatar className="w-5 h-5 shrink-0">
              <AvatarImage src={article.authorAvatar} alt={article.author} />
              <AvatarFallback className="text-[9px]">{initials(article.author)}</AvatarFallback>
            </Avatar>
            <span className="text-[10px] text-muted-foreground truncate">{article.author.split(" ")[0]}</span>
          </div>
          <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-0.5"><Eye className="w-3 h-3" /> {article.views > 1000 ? `${(article.views / 1000).toFixed(1)}k` : article.views}</span>
            <span className="flex items-center gap-0.5"><Clock className="w-3 h-3" /> {formatDate(article.updatedAt, { month: "short", day: "numeric" })}</span>
          </div>
        </div>
      </Card>
    </Link>
  )
}
