"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard, ListTodo, FolderKanban, Users, Clock,
  TrendingUp, Scale, CheckCircle2, Gauge, SlidersHorizontal,
  Download,
} from "lucide-react"
import type { LucideIcon } from "lucide-react"

// ============================================================
// DATE RANGE TYPES & SELECTOR
// ============================================================

export type DateRange = "7d" | "30d" | "90d" | "1y"

export const DATE_RANGE_LABELS: Record<DateRange, string> = {
  "7d": "Last 7 days",
  "30d": "Last 30 days",
  "90d": "Last 90 days",
  "1y": "Last 12 months",
}

export const DATE_RANGE_DAYS: Record<DateRange, number> = {
  "7d": 7,
  "30d": 30,
  "90d": 90,
  "1y": 365,
}

/** Segmented date-range control — used in shell actions. */
export function DateRangeSelector({
  value,
  onChange,
  className,
}: {
  value: DateRange
  onChange: (r: DateRange) => void
  className?: string
}) {
  const ranges: DateRange[] = ["7d", "30d", "90d", "1y"]
  return (
    <div className={cn(
      "inline-flex items-center gap-0.5 rounded-lg bg-muted p-0.5 h-9",
      className,
    )}>
      {ranges.map(r => (
        <button
          key={r}
          onClick={() => onChange(r)}
          className={cn(
            "h-8 px-2.5 text-xs font-medium rounded-md transition-all",
            value === r
              ? "bg-background text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          {r === "1y" ? "1Y" : r.toUpperCase()}
        </button>
      ))}
    </div>
  )
}

/** Native date inputs for a custom range. */
export function CustomDateRange({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <input
        type="date"
        defaultValue={new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10)}
        className="h-9 rounded-lg border border-input bg-background px-2.5 text-xs text-foreground"
      />
      <span className="text-muted-foreground text-xs">to</span>
      <input
        type="date"
        defaultValue={new Date().toISOString().slice(0, 10)}
        className="h-9 rounded-lg border border-input bg-background px-2.5 text-xs text-foreground"
      />
    </div>
  )
}

// ============================================================
// EXPORT BUTTON (CSV stub)
// ============================================================

export function ExportButton({ label = "Export" }: { label?: string }) {
  return (
    <Button
      variant="outline"
      className="h-9 text-sm gap-1.5 bg-transparent"
      onClick={() => {
        if (typeof window !== "undefined") {
          import("sonner").then(({ toast }) => toast.success("Report exported", { description: `${label} downloaded as CSV` }))
        }
      }}
    >
      <Download className="w-4 h-4" /> {label}
    </Button>
  )
}

// ============================================================
// ANALYTICS SUB-NAVIGATION
// ============================================================

interface NavItem {
  href: string
  label: string
  icon: LucideIcon
}

const ANALYTICS_NAV: NavItem[] = [
  { href: "/analytics", label: "Overview", icon: LayoutDashboard },
  { href: "/analytics/tasks", label: "Tasks", icon: ListTodo },
  { href: "/analytics/projects", label: "Projects", icon: FolderKanban },
  { href: "/analytics/team", label: "Team", icon: Users },
  { href: "/analytics/time", label: "Time", icon: Clock },
  { href: "/analytics/productivity", label: "Productivity", icon: TrendingUp },
  { href: "/analytics/workload", label: "Workload", icon: Scale },
  { href: "/analytics/completion", label: "Completion", icon: CheckCircle2 },
  { href: "/analytics/performance", label: "Performance", icon: Gauge },
  { href: "/analytics/custom", label: "Custom", icon: SlidersHorizontal },
]

export function AnalyticsSubNav() {
  const pathname = usePathname()
  return (
    <nav className="mb-4 -mx-1 overflow-x-auto no-scrollbar">
      <div className="flex items-center gap-1 px-1 min-w-max">
        {ANALYTICS_NAV.map(item => {
          const active = item.href === "/analytics"
            ? pathname === "/analytics"
            : pathname.startsWith(item.href)
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium transition-all whitespace-nowrap",
                active
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-card border border-border text-muted-foreground hover:text-foreground hover:bg-secondary",
              )}
            >
              <Icon className="w-3.5 h-3.5" />
              {item.label}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

// ============================================================
// PROJECT SELECTOR (small)
// ============================================================

export function ProjectSelector({
  value,
  onChange,
  options,
}: {
  value: string
  onChange: (v: string) => void
  options: { value: string; label: string }[]
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="h-9 w-[180px] text-xs">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map(o => (
          <SelectItem key={o.value} value={o.value} className="text-xs">
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}

// ============================================================
// HELPERS — build a series of N day buckets ending today
// ============================================================

export function buildTimeSeries(days: number) {
  const out: { date: string; label: string }[] = []
  const today = new Date()
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today.getTime() - i * 86400000)
    out.push({
      date: d.toISOString().slice(0, 10),
      label: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    })
  }
  return out
}

// Deterministic pseudo-random for stable mock series
export function seeded(n: number, seed = 1) {
  const x = Math.sin(n * 9301 + seed * 49297) * 233280
  return x - Math.floor(x)
}
