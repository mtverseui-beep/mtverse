"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaAreaChart, PlannaBarChart, PlannaRadialChart,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle2, ListTodo, AlertTriangle, Timer,
  ArrowRight, Filter,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  buildTimeSeries, seeded,
  type DateRange,
} from "../_lib"
import { tasks } from "@/lib/data/mock"
import { cn } from "@/lib/utils"

export default function TaskAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("30d")

  // Completion rate (gauge)
  const doneCount = tasks.filter(t => t.status === "done").length + 78
  const totalScoped = 124
  const completionRate = Math.round((doneCount / totalScoped) * 100)

  // Tasks created vs completed — last 14 days (deterministic mock)
  const series14 = buildTimeSeries(14)
  const createdVsCompleted = series14.map((d, i) => {
    const base = 6 + seeded(i, 3) * 6
    return {
      date: d.label,
      created: Math.round(base + seeded(i, 7) * 4),
      completed: Math.round(base - 1 + seeded(i, 11) * 3),
    }
  })

  // Priority distribution
  const priorityCounts = { urgent: 0, high: 0, medium: 0, low: 0 }
  tasks.forEach(t => { (priorityCounts as any)[t.priority]++ })
  const priorityData = [
    { name: "Urgent", count: priorityCounts.urgent + 4, color: "var(--chart-1)" },
    { name: "High", count: priorityCounts.high + 12, color: "var(--chart-2)" },
    { name: "Medium", count: priorityCounts.medium + 38, color: "var(--chart-3)" },
    { name: "Low", count: priorityCounts.low + 22, color: "var(--chart-4)" },
  ]

  // Avg close time per priority (hours)
  const closeTimeData = [
    { name: "Urgent", hours: 6.2 },
    { name: "High", hours: 11.4 },
    { name: "Medium", hours: 28.7 },
    { name: "Low", hours: 52.3 },
  ]

  // Overdue trend — last 10 weeks
  const overdueTrend = Array.from({ length: 10 }).map((_, i) => ({
    week: `W${i + 1}`,
    overdue: Math.round(8 + seeded(i, 5) * 6 - i * 0.3),
  }))

  // Task funnel
  const funnel = [
    { stage: "Backlog", count: 42, color: "bg-muted-foreground" },
    { stage: "In Progress", count: 28, color: "bg-amber-500" },
    { stage: "Review", count: 12, color: "bg-violet-500" },
    { stage: "Done", count: 78, color: "bg-emerald-500" },
  ]
  const funnelMax = Math.max(...funnel.map(f => f.count))

  return (
    <DashboardShell
      title="Task Analytics"
      description="Throughput, cycle time, and funnel health across all tasks."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Completion Rate" value={`${completionRate}%`} hint={`${doneCount} of ${totalScoped} tasks`} icon={CheckCircle2} trend={{ value: 6, positive: true }} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Avg Cycle Time" value="2.4d" hint="created → done" icon={Timer} trend={{ value: 9, positive: false }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="In Progress" value={28} hint="9 in review" icon={ListTodo} trend={{ value: 3, positive: false }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Overdue" value={6} hint="2 blocked" icon={AlertTriangle} trend={{ value: 14, positive: false }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Gauge + created vs completed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Completion Rate" subtitle="Tasks done vs total in scope" fullscreen={false}>
          <div className="flex flex-col items-center gap-3 py-4">
            <PlannaRadialChart value={completionRate} label="Completed" size={180} />
            <div className="flex items-center gap-2 text-xs">
              <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">+6% vs last period</Badge>
            </div>
          </div>
        </ChartCard>

        <ChartCard
          title="Created vs Completed"
          subtitle="Daily task flow — last 14 days"
          className="lg:col-span-2"
        >
          <PlannaAreaChart
            data={createdVsCompleted}
            xKey="date"
            series={[
              { key: "created", name: "Created" },
              { key: "completed", name: "Completed", color: "var(--chart-2)" },
            ]}
            height={280}
          />
        </ChartCard>
      </div>

      {/* Priority dist + avg close time */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        <ChartCard title="Priority Distribution" subtitle="Open + done tasks by priority">
          <PlannaBarChart
            data={priorityData}
            xKey="name"
            series={[{ key: "count", name: "Tasks" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>

        <ChartCard title="Avg Close Time by Priority" subtitle="Hours from creation to done">
          <PlannaBarChart
            data={closeTimeData}
            xKey="name"
            series={[{ key: "hours", name: "Hours", color: "var(--chart-2)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>
      </div>

      {/* Overdue trend + funnel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <ChartCard title="Overdue Trend" subtitle="Overdue tasks per week — last 10 weeks">
          <PlannaAreaChart
            data={overdueTrend}
            xKey="week"
            series={[{ key: "overdue", name: "Overdue", color: "var(--chart-1)" }]}
            height={240}
            showLegend={false}
          />
        </ChartCard>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Task Funnel</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Backlog through done</p>
            </div>
            <Filter className="w-4 h-4 text-muted-foreground" />
          </div>
          <div className="space-y-3">
            {funnel.map((f, i) => (
              <div key={f.stage}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className={cn("w-2 h-2 rounded-full", f.color)} />
                    <span className="text-xs font-medium text-foreground">{f.stage}</span>
                  </div>
                  <span className="text-xs font-semibold text-foreground tabular-nums">{f.count}</span>
                </div>
                <div className="relative h-7 rounded-lg bg-secondary/60 overflow-hidden">
                  <div
                    className={cn("absolute inset-y-0 left-0 rounded-lg transition-all duration-500", f.color)}
                    style={{ width: `${(f.count / funnelMax) * 100}%` }}
                  />
                </div>
                {i < funnel.length - 1 && (
                  <div className="flex justify-end mt-1">
                    <ArrowRight className="w-3 h-3 text-muted-foreground/50" />
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-border">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Throughput (backlog → done)</span>
              <span className="font-semibold text-foreground">
                {Math.round((funnel[3].count / funnel[0].count) * 100)}%
              </span>
            </div>
            <Progress value={(funnel[3].count / funnel[0].count) * 100} className="h-1.5 mt-2" />
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
