"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaBarChart, PlannaLineChart, PlannaHeatmap, Sparkline,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Users, CheckCircle2, Gauge, TrendingUp, Trophy, Activity,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  seeded,
  type DateRange,
} from "../_lib"
import { members, sprintVelocityHistory } from "@/lib/data/mock"
import { cn } from "@/lib/utils"

export default function TeamAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("30d")

  // Workload distribution (utilized vs capacity remaining)
  const workloadData = members.slice(0, 8).map(m => ({
    name: m.name.split(" ")[0],
    utilized: m.utilized,
    remaining: Math.max(0, m.capacity - m.utilized),
  }))

  // Productivity per member (completed tasks this period — synthetic)
  const productivityData = members.slice(0, 8).map((m, i) => ({
    name: m.name.split(" ")[0],
    tasks: Math.round(m.completedTasks * 0.15 + seeded(i, 2) * 8),
    focus: Math.round(20 + seeded(i, 9) * 25),
  }))

  // Leaderboard
  const leaderboard = [...members]
    .sort((a, b) => b.completedTasks - a.completedTasks)
    .slice(0, 8)

  // Team velocity over sprints
  const velocityData = sprintVelocityHistory.map(s => ({
    sprint: s.sprint,
    completed: s.completed,
    planned: s.planned,
  }))

  // Member comparison — multi-metric bar (tasks, focus, on-time %)
  const comparisonData = members.slice(0, 6).map((m, i) => ({
    name: m.name.split(" ")[0],
    tasks: Math.round(80 + seeded(i, 4) * 40),
    focus: Math.round(60 + seeded(i, 8) * 35),
    quality: Math.round(70 + seeded(i, 12) * 28),
  }))

  // Contribution heatmap: member × day-of-week (7 cols)
  const contributionHeatmap = members.slice(0, 8).map((_, mi) =>
    Array.from({ length: 7 }).map((_, di) => {
      const base = mi < 5 ? 3 : 2
      return Math.round(seeded(mi * 7 + di, 13) * base)
    }),
  )

  const totalCompleted = members.reduce((s, m) => s + m.completedTasks, 0)
  const avgUtilization = Math.round(
    members.reduce((s, m) => s + (m.utilized / m.capacity) * 100, 0) / members.length,
  )

  return (
    <DashboardShell
      title="Team Analytics"
      description="Workload, productivity, and contribution patterns across the team."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Team Members" value={members.length} hint="across 6 departments" icon={Users} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Tasks Completed" value={totalCompleted} hint="all time" icon={CheckCircle2} trend={{ value: 11, positive: true }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Avg Utilization" value={`${avgUtilization}%`} hint="of 40h capacity" icon={Gauge} trend={{ value: 4, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Active Now" value={members.filter(m => m.online).length} hint="online this hour" icon={Activity} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Workload + productivity per member */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        <ChartCard title="Workload Distribution" subtitle="Utilized vs remaining capacity (hours/week)">
          <PlannaBarChart
            data={workloadData}
            xKey="name"
            series={[
              { key: "utilized", name: "Utilized", stackId: "a" },
              { key: "remaining", name: "Remaining", stackId: "a", color: "var(--chart-4)" },
            ]}
            height={260}
          />
        </ChartCard>

        <ChartCard title="Productivity per Member" subtitle="Completed tasks and focus hours">
          <PlannaBarChart
            data={productivityData}
            xKey="name"
            series={[
              { key: "tasks", name: "Tasks" },
              { key: "focus", name: "Focus hrs", color: "var(--chart-2)" },
            ]}
            height={260}
          />
        </ChartCard>
      </div>

      {/* Leaderboard + velocity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold text-foreground">Completed Tasks Leaderboard</h3>
          </div>
          <div className="space-y-1 max-h-[280px] overflow-y-auto scroll-area-thin pr-1">
            {leaderboard.map((m, i) => (
              <div key={m.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/60 transition-colors">
                <div className={cn(
                  "w-6 text-center text-xs font-bold shrink-0",
                  i === 0 ? "text-amber-500" : i === 1 ? "text-slate-400" : i === 2 ? "text-orange-700 dark:text-orange-400" : "text-muted-foreground",
                )}>
                  {i + 1}
                </div>
                <Avatar className="w-7 h-7 shrink-0">
                  <AvatarImage src={m.avatar} alt={m.name} />
                  <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{m.department}</p>
                </div>
                <span className="text-sm font-semibold text-foreground tabular-nums shrink-0">{m.completedTasks}</span>
              </div>
            ))}
          </div>
        </Card>

        <ChartCard
          title="Team Velocity"
          subtitle="Sprint-over-sprint throughput"
          className="lg:col-span-2"
        >
          <PlannaLineChart
            data={velocityData}
            xKey="sprint"
            series={[
              { key: "planned", name: "Planned", dashed: true, color: "var(--chart-3)" },
              { key: "completed", name: "Completed" },
            ]}
            height={280}
          />
        </ChartCard>
      </div>

      {/* Member comparison + contribution heatmap */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <ChartCard title="Member Comparison" subtitle="Tasks · Focus hrs · Quality score (normalized)">
          <PlannaBarChart
            data={comparisonData}
            xKey="name"
            series={[
              { key: "tasks", name: "Tasks" },
              { key: "focus", name: "Focus", color: "var(--chart-2)" },
              { key: "quality", name: "Quality", color: "var(--chart-3)" },
            ]}
            height={260}
          />
        </ChartCard>

        <ChartCard title="Contribution Heatmap" subtitle="Member × day of week — commits & completions" fullscreen={false}>
          <MemberWeekHeatmap data={contributionHeatmap} members={members.slice(0, 8).map(m => m.name.split(" ")[0])} />
        </ChartCard>
      </div>

      {/* Individual sparkline strip */}
      <Card className="p-4 md:p-5 card-lift mt-4">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Weekly Output Trend</h3>
          <Badge className="ml-auto bg-primary/10 text-primary text-[10px]">8-week sparkline</Badge>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {members.slice(0, 8).map((m, i) => {
            const spark = Array.from({ length: 8 }).map((_, w) =>
              Math.round(8 + seeded(i * 10 + w, 17) * 10),
            )
            return (
              <div key={m.id} className="rounded-lg border border-border p-3 bg-secondary/30">
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="w-6 h-6">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs font-medium text-foreground truncate">{m.name.split(" ")[0]}</span>
                </div>
                <Sparkline data={spark} height={36} />
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[10px] text-muted-foreground">avg {Math.round(spark.reduce((a, b) => a + b, 0) / spark.length)}/wk</span>
                  <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[9px]">+{Math.round(seeded(i, 21) * 12)}%</Badge>
                </div>
              </div>
            )
          })}
        </div>
      </Card>
    </DashboardShell>
  )
}

// Local member×week heatmap (reuse cell-color logic from PlannaHeatmap style)
function MemberWeekHeatmap({ data, members: names }: { data: number[][]; members: string[] }) {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
  const max = Math.max(...data.flat(), 1)
  const cellColor = (v: number) => {
    if (v === 0) return "var(--muted)"
    const ratio = v / max
    if (ratio < 0.25) return "color-mix(in oklch, var(--chart-1) 25%, var(--card))"
    if (ratio < 0.5) return "color-mix(in oklch, var(--chart-1) 50%, var(--card))"
    if (ratio < 0.75) return "color-mix(in oklch, var(--chart-1) 75%, var(--card))"
    return "var(--chart-1)"
  }
  return (
    <div className="w-full overflow-x-auto no-scrollbar">
      <div className="min-w-[420px]">
        <div className="flex">
          <div className="w-20 shrink-0" />
          <div className="flex-1 grid gap-0.5" style={{ gridTemplateColumns: "repeat(7, minmax(0, 1fr))" }}>
            {days.map(d => (
              <div key={d} className="text-[10px] text-muted-foreground text-center">{d}</div>
            ))}
          </div>
        </div>
        {data.map((row, mi) => (
          <div key={mi} className="flex items-center mt-0.5">
            <div className="w-20 shrink-0 text-[11px] text-foreground truncate pr-2">{names[mi]}</div>
            <div className="flex-1 grid gap-0.5" style={{ gridTemplateColumns: "repeat(7, minmax(0, 1fr))" }}>
              {row.map((v, di) => (
                <div
                  key={di}
                  className="aspect-square rounded-sm transition-all duration-200 hover:ring-2 hover:ring-primary/40 hover:scale-110 cursor-pointer"
                  style={{ background: cellColor(v) }}
                  title={`${names[mi]} ${days[di]} — ${v} contributions`}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
