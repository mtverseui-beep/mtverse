"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaAreaChart, PlannaDonutChart, PlannaBarChart,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  CheckCircle2, Clock, Timer, AlertTriangle, Calendar, Target,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  seeded,
  type DateRange,
} from "../_lib"
import { projects, members, tasks } from "@/lib/data/mock"
import { cn, pct } from "@/lib/utils"

export default function CompletionAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("90d")

  // Completion rate over time — last 12 weeks
  const completionOverTime = Array.from({ length: 12 }).map((_, i) => {
    const rate = Math.round(72 + seeded(i, 3) * 22)
    return { week: `W${i + 1}`, rate }
  })

  // On-time vs late
  const onTime = 64
  const late = 14
  const onTimePie = [
    { name: "On Time", value: onTime, color: "var(--chart-1)" },
    { name: "Late", value: late, color: "oklch(0.6 0.18 30)" },
  ]

  // Completion by project
  const completionByProject = projects.slice(0, 7).map(p => ({
    name: p.key,
    rate: pct(p.tasksDone, p.tasksTotal),
  }))

  // Completion by assignee
  const completionByAssignee = members.slice(0, 8).map((m, i) => ({
    name: m.name.split(" ")[0],
    completed: Math.round(8 + seeded(i, 2) * 14),
    total: Math.round(16 + seeded(i, 6) * 14),
  })).map(d => ({
    ...d,
    rate: pct(d.completed, d.total),
  })).sort((a, b) => b.rate - a.rate)

  // Estimated vs actual time (top tasks with logged hours)
  const estVsActual = tasks
    .filter(t => t.estimateHours && t.loggedHours)
    .slice(0, 8)
    .map(t => ({
      name: t.key,
      estimated: t.estimateHours,
      actual: t.loggedHours,
    }))

  // Cycle time distribution (buckets in days)
  const cycleTimeBuckets = [
    { name: "<1d", count: 18 },
    { name: "1–2d", count: 24 },
    { name: "2–4d", count: 19 },
    { name: "4–7d", count: 12 },
    { name: "7–14d", count: 7 },
    { name: "14d+", count: 4 },
  ]

  const avgCycle = 2.4
  const completionRate = 78
  const onTimeRate = pct(onTime, onTime + late)

  return (
    <DashboardShell
      title="Completion Reports"
      description="On-time delivery, cycle time, and estimate accuracy across tasks."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton label="Report" />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Completion Rate" value={`${completionRate}%`} hint="78 of 100 tasks" icon={CheckCircle2} trend={{ value: 6, positive: true }} iconColor="bg-primary/15 text-primary" />
        <StatCard label="On-time Rate" value={`${onTimeRate}%`} hint={`${late} tasks late`} icon={Clock} trend={{ value: 4, positive: true }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Avg Cycle Time" value={`${avgCycle}d`} hint="created → done" icon={Timer} trend={{ value: 9, positive: false }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Estimate Accuracy" value="92%" hint="within ±20% of actual" icon={Target} trend={{ value: 3, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Completion rate over time + on-time vs late */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Completion Rate Over Time" subtitle="Weekly % of planned tasks completed" className="lg:col-span-2">
          <PlannaAreaChart
            data={completionOverTime}
            xKey="week"
            series={[{ key: "rate", name: "Completion %", color: "var(--chart-1)" }]}
            height={280}
            showLegend={false}
          />
        </ChartCard>

        <ChartCard title="On-time vs Late" subtitle="This period" fullscreen={false}>
          <PlannaDonutChart
            data={onTimePie}
            height={260}
            centerValue={`${onTimeRate}%`}
            centerLabel="On time"
          />
        </ChartCard>
      </div>

      {/* Completion by project + by assignee */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        <ChartCard title="Completion by Project" subtitle="Done / total per project">
          <PlannaBarChart
            data={completionByProject}
            xKey="name"
            series={[{ key: "rate", name: "Completion %", color: "var(--chart-2)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Completion by Assignee</h3>
          </div>
          <div className="space-y-3 max-h-[260px] overflow-y-auto scroll-area-thin pr-1">
            {completionByAssignee.map((d, i) => {
              const m = members[i]
              return (
                <div key={d.name} className="flex items-center gap-3">
                  <Avatar className="w-7 h-7 shrink-0">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-medium text-foreground truncate">{m.name}</span>
                      <span className="text-[11px] font-semibold text-foreground tabular-nums">{d.completed}/{d.total}</span>
                    </div>
                    <Progress value={d.rate} className="h-1.5" />
                  </div>
                  <span className={cn(
                    "text-xs font-semibold tabular-nums w-10 text-right shrink-0",
                    d.rate >= 75 ? "text-emerald-600 dark:text-emerald-400" : d.rate >= 50 ? "text-amber-600 dark:text-amber-400" : "text-rose-600 dark:text-rose-400",
                  )}>
                    {d.rate}%
                  </span>
                </div>
              )
            })}
          </div>
        </Card>
      </div>

      {/* Estimated vs actual + cycle time distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <ChartCard title="Estimated vs Actual Time" subtitle="Hours per task — top 8 tasks with logged time">
          <PlannaBarChart
            data={estVsActual}
            xKey="name"
            series={[
              { key: "estimated", name: "Estimated", color: "var(--chart-4)" },
              { key: "actual", name: "Actual" },
            ]}
            height={260}
          />
        </ChartCard>

        <ChartCard title="Cycle Time Distribution" subtitle="How long tasks take from created to done">
          <PlannaBarChart
            data={cycleTimeBuckets}
            xKey="name"
            series={[{ key: "count", name: "Tasks", color: "var(--chart-2)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>
      </div>

      {/* Insight footer */}
      <Card className="p-4 card-lift mt-4 border-amber-500/20 bg-amber-500/5">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs text-foreground">
            <p className="font-semibold mb-1">Estimate drift detected on long tasks</p>
            <p className="text-muted-foreground leading-relaxed">
              Tasks estimated above 12h run an average of <span className="font-semibold text-foreground">+18% over</span>. Consider splitting large tasks into subtasks of 8h or less to improve estimate accuracy.
            </p>
          </div>
        </div>
      </Card>
    </DashboardShell>
  )
}
