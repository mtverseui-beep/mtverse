"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaAreaChart, PlannaDonutChart, PlannaLineChart,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle2, ListTodo, Clock, TrendingUp,
  Trophy, ArrowUpRight, ArrowDownRight, Sparkles,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  type DateRange,
} from "./_lib"
import {
  members, tasks, productivityTrend, sprintVelocityHistory, dashboardStats,
} from "@/lib/data/mock"
import { cn } from "@/lib/utils"

export default function AnalyticsOverviewPage() {
  const [range, setRange] = useState<DateRange>("30d")

  // Tally task statuses from real mock data
  const statusTally = { done: 0, in_progress: 0, todo: 0, backlog: 0, review: 0 }
  tasks.forEach(t => {
    if (t.status in statusTally) (statusTally as any)[t.status]++
  })
  const donutData = [
    { name: "Done", value: statusTally.done + dashboardStats.completedTasks, color: "var(--chart-1)" },
    { name: "In Progress", value: statusTally.in_progress + dashboardStats.inProgressTasks, color: "var(--chart-2)" },
    { name: "To Do", value: statusTally.todo + 14, color: "var(--chart-3)" },
    { name: "Backlog", value: statusTally.backlog + 8, color: "var(--chart-4)" },
    { name: "Review", value: statusTally.review + 5, color: "var(--chart-5)" },
  ]
  const totalTasks = donutData.reduce((s, d) => s + d.value, 0)

  // Top performers — sorted by completedTasks
  const topPerformers = [...members]
    .sort((a, b) => b.completedTasks - a.completedTasks)
    .slice(0, 6)

  // Velocity line chart from sprint history
  const velocityData = sprintVelocityHistory.map(s => ({
    sprint: s.sprint,
    planned: s.planned,
    completed: s.completed,
  }))

  return (
    <DashboardShell
      title="Analytics Overview"
      description="Cross-cutting metrics across tasks, projects, team, and time."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton label="Report" />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <div className="animate-slide-in-up">
          <StatCard
            label="Tasks Completed"
            value={dashboardStats.completedTasks}
            hint={`${dashboardStats.totalTasks} total in scope`}
            icon={CheckCircle2}
            trend={{ value: 12, positive: true }}
            iconColor="bg-primary/15 text-primary"
          />
        </div>
        <div className="animate-slide-in-up" style={{ animationDelay: "60ms" }}>
          <StatCard
            label="Active Tasks"
            value={dashboardStats.inProgressTasks}
            hint={`${dashboardStats.overdueTasks} overdue`}
            icon={ListTodo}
            trend={{ value: 4, positive: false }}
            iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400"
          />
        </div>
        <div className="animate-slide-in-up" style={{ animationDelay: "120ms" }}>
          <StatCard
            label="Hours This Week"
            value={`${dashboardStats.hoursThisWeek}h`}
            hint={`${dashboardStats.billableHours}h billable`}
            icon={Clock}
            trend={{ value: 8, positive: true }}
            iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400"
          />
        </div>
        <div className="animate-slide-in-up" style={{ animationDelay: "180ms" }}>
          <StatCard
            label="Productivity Score"
            value={dashboardStats.productivityScore}
            hint={`Velocity ${dashboardStats.sprintVelocity} pts/sprint`}
            icon={TrendingUp}
            trend={{ value: 5, positive: true }}
            iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400"
          />
        </div>
      </div>

      {/* Productivity trend (large) + task status donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard
          title="Productivity Trend"
          subtitle="Completed vs planned tasks and focus hours — last 12 weeks"
          className="lg:col-span-2"
        >
          <PlannaAreaChart
            data={productivityTrend}
            xKey="week"
            series={[
              { key: "completed", name: "Completed" },
              { key: "planned", name: "Planned", color: "var(--chart-3)" },
              { key: "focus", name: "Focus Hours", color: "var(--chart-2)" },
            ]}
            height={300}
          />
        </ChartCard>

        <ChartCard title="Task Status" subtitle="Current open work" fullscreen={false}>
          <PlannaDonutChart
            data={donutData}
            height={260}
            centerValue={`${totalTasks}`}
            centerLabel="Total tasks"
          />
        </ChartCard>
      </div>

      {/* Team velocity + top performers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard
          title="Team Velocity"
          subtitle="Story points planned vs completed — last 6 sprints"
          className="lg:col-span-2"
        >
          <PlannaLineChart
            data={velocityData}
            xKey="sprint"
            series={[
              { key: "planned", name: "Planned", dashed: true, color: "var(--chart-3)" },
              { key: "completed", name: "Completed" },
            ]}
            height={280}
          />
        </ChartCard>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold text-foreground">Top Performers</h3>
            <Badge className="ml-auto bg-primary/10 text-primary text-[10px]">All time</Badge>
          </div>
          <div className="space-y-1 max-h-[300px] overflow-y-auto scroll-area-thin pr-1">
            {topPerformers.map((m, i) => (
              <div
                key={m.id}
                className={cn(
                  "flex items-center gap-3 p-2 rounded-lg transition-colors hover:bg-secondary/60",
                )}
              >
                <div className={cn(
                  "w-6 text-center text-xs font-bold",
                  i === 0 ? "text-amber-500" : i === 1 ? "text-slate-400" : i === 2 ? "text-orange-700 dark:text-orange-400" : "text-muted-foreground",
                )}>
                  {i + 1}
                </div>
                <Avatar className="w-8 h-8">
                  <AvatarImage src={m.avatar} alt={m.name} />
                  <AvatarFallback>{m.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                  <p className="text-[11px] text-muted-foreground truncate">{m.title}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-foreground tabular-nums">{m.completedTasks}</p>
                  <p className="text-[10px] text-muted-foreground">tasks</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Insight strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4">
        <Card className="p-4 card-lift border-primary/20 bg-gradient-to-br from-primary/5 to-card">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary/15 text-primary flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground mb-1">Velocity is up 11%</p>
              <p className="text-[11px] text-muted-foreground leading-relaxed">Sprint 46 delivered 54 of 58 planned points — best ratio in 3 sprints.</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 card-lift">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <ArrowUpRight className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground mb-1">Focus hours trending up</p>
              <p className="text-[11px] text-muted-foreground leading-relaxed">Deep work is up 27% vs last quarter. Tuesday mornings are the peak window.</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 card-lift">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <ArrowDownRight className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground mb-1">Overdue tasks need attention</p>
              <p className="text-[11px] text-muted-foreground leading-relaxed">{dashboardStats.overdueTasks} tasks are overdue — concentrated in Infrastructure Migration.</p>
            </div>
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
