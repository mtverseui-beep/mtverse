"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaBarChart,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Scale, AlertTriangle, ArrowDownCircle, ArrowUpCircle,
  Users2, Lightbulb, ArrowRight, ShieldCheck,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  seeded,
  type DateRange,
} from "../_lib"
import { members } from "@/lib/data/mock"
import { cn } from "@/lib/utils"

export default function WorkloadAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("30d")

  // Capacity vs utilization per member
  const capacityData = members.slice(0, 10).map(m => ({
    name: m.name.split(" ")[0],
    capacity: m.capacity,
    utilized: m.utilized,
  }))

  // Over-utilized (>95%) and under-utilized (<60%)
  const enriched = members.map(m => ({
    ...m,
    utilization: Math.round((m.utilized / m.capacity) * 100),
  }))
  const overUtilized = enriched.filter(m => m.utilization > 95).sort((a, b) => b.utilization - a.utilization)
  const underUtilized = enriched.filter(m => m.utilization < 65).sort((a, b) => a.utilization - b.utilization)
  const balanced = enriched.filter(m => m.utilization >= 65 && m.utilization <= 95).length

  // Workload heatmap: member × day (7 days)
  const workloadHeatmap = members.slice(0, 8).map((m, mi) => {
    const base = m.utilized / m.capacity
    return Array.from({ length: 7 }).map((_, di) => {
      const weekend = di >= 5 ? 0.4 : 1
      return Math.round((base * (0.7 + seeded(mi * 7 + di, 5) * 0.6) * weekend) * 100) / 100
    })
  })

  // Rebalancing recommendations
  const recommendations = [
    {
      from: overUtilized[0]?.name ?? "—",
      to: underUtilized[0]?.name ?? "—",
      task: "2 design review tasks",
      reason: `${overUtilized[0]?.name ?? "Overloaded"} at ${overUtilized[0]?.utilization ?? 100}% — shift reviews to free 6h`,
    },
    {
      from: overUtilized[1]?.name ?? overUtilized[0]?.name ?? "—",
      to: underUtilized[1]?.name ?? underUtilized[0]?.name ?? "—",
      task: "QA automation pair",
      reason: `Pair-programming balances load and cross-trains ${underUtilized[1]?.name ?? underUtilized[0]?.name ?? "team"}`,
    },
    {
      from: "Sprint planning",
      to: underUtilized[2]?.name ?? underUtilized[0]?.name ?? "—",
      task: "Backlog grooming",
      reason: `Free up senior bandwidth — ${(underUtilized[2] ?? underUtilized[0])?.title ?? ""} can own grooming`,
    },
  ].filter(r => r.from !== "—")

  return (
    <DashboardShell
      title="Workload Analytics"
      description="Capacity, utilization, and rebalancing recommendations across the team."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Team Capacity" value={`${members.reduce((s, m) => s + m.capacity, 0)}h`} hint="per week" icon={Scale} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Over-utilized" value={overUtilized.length} hint="above 95% capacity" icon={AlertTriangle} trend={{ value: 1, positive: false }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Under-utilized" value={underUtilized.length} hint="below 65% capacity" icon={ArrowDownCircle} trend={{ value: 2, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Balanced" value={balanced} hint="65–95% sweet spot" icon={ShieldCheck} trend={{ value: 6, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      {/* Capacity vs utilization */}
      <ChartCard
        title="Capacity vs Utilization"
        subtitle="Weekly hours — capacity vs hours utilized per member"
        className="mb-4"
      >
        <PlannaBarChart
          data={capacityData}
          xKey="name"
          series={[
            { key: "capacity", name: "Capacity", color: "var(--chart-4)" },
            { key: "utilized", name: "Utilized" },
          ]}
          height={300}
        />
      </ChartCard>

      {/* Over-utilized + under-utilized lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        <Card className="p-4 md:p-5 card-lift border-rose-500/20">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg bg-rose-500/15 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <ArrowUpCircle className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-foreground">Over-utilized Members</h3>
            <Badge className="ml-auto bg-rose-500/15 text-rose-600 dark:text-rose-400 text-[10px]">{overUtilized.length} at risk</Badge>
          </div>
          <div className="space-y-2 max-h-[260px] overflow-y-auto scroll-area-thin pr-1">
            {overUtilized.length === 0 && (
              <p className="text-xs text-muted-foreground py-6 text-center">No over-utilized members — team is well balanced.</p>
            )}
            {overUtilized.map(m => (
              <div key={m.id} className="flex items-center gap-3 p-2 rounded-lg bg-rose-500/5 border border-rose-500/15">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={m.avatar} alt={m.name} />
                  <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{m.title}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-semibold text-rose-600 dark:text-rose-400 tabular-nums">{m.utilization}%</p>
                  <p className="text-[10px] text-muted-foreground">{m.utilized}h / {m.capacity}h</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-4 md:p-5 card-lift border-amber-500/20">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <ArrowDownCircle className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-foreground">Under-utilized Members</h3>
            <Badge className="ml-auto bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[10px]">{underUtilized.length} available</Badge>
          </div>
          <div className="space-y-2 max-h-[260px] overflow-y-auto scroll-area-thin pr-1">
            {underUtilized.length === 0 && (
              <p className="text-xs text-muted-foreground py-6 text-center">No under-utilized members.</p>
            )}
            {underUtilized.map(m => (
              <div key={m.id} className="flex items-center gap-3 p-2 rounded-lg bg-amber-500/5 border border-amber-500/15">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={m.avatar} alt={m.name} />
                  <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{m.title}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-semibold text-amber-600 dark:text-amber-400 tabular-nums">{m.utilization}%</p>
                  <p className="text-[10px] text-muted-foreground">{m.utilized}h / {m.capacity}h</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Workload heatmap + recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <ChartCard title="Workload Heatmap" subtitle="Member × day — utilization ratio" fullscreen={false}>
          <WorkloadHeatmap data={workloadHeatmap} names={members.slice(0, 8).map(m => m.name.split(" ")[0])} />
        </ChartCard>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-lg bg-primary/15 text-primary flex items-center justify-center">
              <Lightbulb className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-foreground">Recommended Rebalancing</h3>
            <Badge className="ml-auto bg-primary/10 text-primary text-[10px]">Auto-suggested</Badge>
          </div>
          <div className="space-y-3">
            {recommendations.map((r, i) => (
              <div key={i} className="rounded-lg border border-border p-3 bg-secondary/30">
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  <span className="text-xs font-medium text-rose-600 dark:text-rose-400">{r.from}</span>
                  <ArrowRight className="w-3 h-3 text-muted-foreground" />
                  <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">{r.to}</span>
                  <Badge className="bg-primary/10 text-primary text-[9px] ml-auto">{r.task}</Badge>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">{r.reason}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-border flex items-center gap-2 text-xs text-muted-foreground">
            <Users2 className="w-3.5 h-3.5" />
            Applying all suggestions would bring team utilization to ~82% avg.
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}

function WorkloadHeatmap({ data, names }: { data: number[][]; names: string[] }) {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
  const cellColor = (v: number) => {
    if (v === 0) return "var(--muted)"
    if (v < 0.4) return "color-mix(in oklch, var(--chart-1) 25%, var(--card))"
    if (v < 0.7) return "color-mix(in oklch, var(--chart-1) 50%, var(--card))"
    if (v < 0.95) return "color-mix(in oklch, var(--chart-1) 75%, var(--card))"
    if (v < 1.1) return "var(--chart-1)"
    return "color-mix(in oklch, var(--chart-1) 70%, oklch(0.5 0.2 25))"
  }
  return (
    <div className="w-full overflow-x-auto no-scrollbar">
      <div className="min-w-[420px]">
        <div className="flex">
          <div className="w-20 shrink-0" />
          <div className="flex-1 grid gap-0.5" style={{ gridTemplateColumns: "repeat(7, minmax(0, 1fr))" }}>
            {days.map(d => (
              <div key={d} className="text-[10px] text-muted-foreground text-center">{d}</div>
            ))}
          </div>
        </div>
        {data.map((row, mi) => (
          <div key={mi} className="flex items-center mt-0.5">
            <div className="w-20 shrink-0 text-[11px] text-foreground truncate pr-2">{names[mi]}</div>
            <div className="flex-1 grid gap-0.5" style={{ gridTemplateColumns: "repeat(7, minmax(0, 1fr))" }}>
              {row.map((v, di) => (
                <div
                  key={di}
                  className="aspect-square rounded-sm transition-all duration-200 hover:ring-2 hover:ring-primary/40 hover:scale-110 cursor-pointer"
                  style={{ background: cellColor(v) }}
                  title={`${names[mi]} ${days[di]} — ${Math.round(v * 100)}% utilized`}
                />
              ))}
            </div>
          </div>
        ))}
        <div className="flex items-center justify-end gap-1 mt-3">
          <span className="text-[10px] text-muted-foreground">Less</span>
          {[0.2, 0.5, 0.8, 1.0, 1.2].map(v => (
            <div key={v} className="w-3 h-3 rounded-sm" style={{ background: cellColor(v) }} />
          ))}
          <span className="text-[10px] text-muted-foreground">More</span>
        </div>
      </div>
    </div>
  )
}
