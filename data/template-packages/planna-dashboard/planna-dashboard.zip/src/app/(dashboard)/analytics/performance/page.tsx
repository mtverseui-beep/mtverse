"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaBarChart, PlannaLineChart, Sparkline,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Gauge, Trophy, Award, TrendingUp, Zap, Target, Users2, Star,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  seeded,
  type DateRange,
} from "../_lib"
import { members, sprintVelocityHistory } from "@/lib/data/mock"
import { cn } from "@/lib/utils"

interface PerfMember {
  id: string
  name: string
  avatar: string
  title: string
  score: number
  quality: number
  speed: number
  collaboration: number
  tasks: number
  trend: number[]
}

export default function PerformanceAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("90d")

  // Build performance data deterministically
  const perfMembers: PerfMember[] = members.slice(0, 10).map((m, i) => {
    const quality = Math.round(72 + seeded(i, 2) * 26)
    const speed = Math.round(68 + seeded(i, 5) * 28)
    const collaboration = Math.round(74 + seeded(i, 8) * 22)
    const score = Math.round((quality * 0.4 + speed * 0.35 + collaboration * 0.25))
    return {
      id: m.id,
      name: m.name,
      avatar: m.avatar,
      title: m.title,
      score,
      quality,
      speed,
      collaboration,
      tasks: Math.round(40 + seeded(i, 11) * 60),
      trend: Array.from({ length: 8 }).map((_, w) =>
        Math.round(60 + seeded(i * 10 + w, 17) * 35),
      ),
    }
  }).sort((a, b) => b.score - a.score)

  const top3 = perfMembers.slice(0, 3)
  const rest = perfMembers.slice(3)
  const avgScore = Math.round(perfMembers.reduce((s, m) => s + m.score, 0) / perfMembers.length)

  // Sprint-by-sprint performance
  const sprintPerf = sprintVelocityHistory.map(s => ({
    sprint: s.sprint,
    velocity: s.completed,
    quality: Math.round(70 + seeded(s.sprint.charCodeAt(1), 3) * 25),
  }))

  // Score breakdown for top member
  const topMember = perfMembers[0]
  const breakdown = [
    { label: "Quality", value: topMember.quality, color: "bg-primary", icon: Target },
    { label: "Speed", value: topMember.speed, color: "bg-teal-500", icon: Zap },
    { label: "Collaboration", value: topMember.collaboration, color: "bg-amber-500", icon: Users2 },
  ]

  return (
    <DashboardShell
      title="Performance Reports"
      description="Individual and team performance scoring across sprints and competencies."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton label="Report" />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Team Avg Score" value={avgScore} hint="out of 100" icon={Gauge} trend={{ value: 4, positive: true }} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Top Performer" value={perfMembers[0].name.split(" ")[0]} hint={`score ${perfMembers[0].score}`} icon={Trophy} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Sprint Velocity" value={54} hint="avg points/sprint" icon={TrendingUp} trend={{ value: 7, positive: true }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Active Members" value={perfMembers.length} hint="scored this period" icon={Users2} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Podium + score breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <Card className="p-4 md:p-5 card-lift lg:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold text-foreground">Performance Leaderboard</h3>
            <Badge className="ml-auto bg-primary/10 text-primary text-[10px]">Top 3</Badge>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {/* 2nd */}
            <PodiumCard member={top3[1]} rank={2} className="mt-6" />
            {/* 1st */}
            <PodiumCard member={top3[0]} rank={1} />
            {/* 3rd */}
            <PodiumCard member={top3[2]} rank={3} className="mt-10" />
          </div>
        </Card>

        {/* Score breakdown for top performer */}
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <Star className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Score Breakdown</h3>
          </div>
          <div className="flex items-center gap-3 mb-4">
            <Avatar className="w-10 h-10">
              <AvatarImage src={topMember.avatar} alt={topMember.name} />
              <AvatarFallback>{topMember.name[0]}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{topMember.name}</p>
              <p className="text-[11px] text-muted-foreground truncate">{topMember.title}</p>
            </div>
            <div className="ml-auto text-right">
              <p className="text-2xl font-bold text-primary tabular-nums">{topMember.score}</p>
              <p className="text-[10px] text-muted-foreground">score</p>
            </div>
          </div>
          <div className="space-y-3">
            {breakdown.map(b => {
              const Icon = b.icon
              return (
                <div key={b.label}>
                  <div className="flex items-center gap-2 mb-1.5">
                    <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-xs font-medium text-foreground">{b.label}</span>
                    <span className="ml-auto text-xs font-semibold text-foreground tabular-nums">{b.value}</span>
                  </div>
                  <Progress value={b.value} className="h-1.5" />
                </div>
              )
            })}
          </div>
          <div className="mt-4 pt-3 border-t border-border text-[11px] text-muted-foreground leading-relaxed">
            Weighted: Quality 40% · Speed 35% · Collaboration 25%
          </div>
        </Card>
      </div>

      {/* Individual performance cards with sparklines */}
      <Card className="p-4 md:p-5 card-lift mb-4">
        <div className="flex items-center gap-2 mb-4">
          <Award className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Individual Performance</h3>
          <Badge className="ml-auto bg-primary/10 text-primary text-[10px]">8-week trend</Badge>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {rest.map((m, i) => (
            <div key={m.id} className="rounded-lg border border-border p-3 bg-secondary/30 card-lift">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-5 text-center text-xs font-bold text-muted-foreground">#{i + 4}</span>
                <Avatar className="w-7 h-7">
                  <AvatarImage src={m.avatar} alt={m.name} />
                  <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{m.title}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-foreground tabular-nums">{m.score}</p>
                </div>
              </div>
              <Sparkline data={m.trend} height={36} />
              <div className="grid grid-cols-3 gap-2 mt-2">
                <MetricChip label="Q" value={m.quality} />
                <MetricChip label="S" value={m.speed} />
                <MetricChip label="C" value={m.collaboration} />
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Sprint-by-sprint performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <ChartCard title="Sprint-by-Sprint Performance" subtitle="Velocity (completed points) per sprint">
          <PlannaBarChart
            data={sprintPerf}
            xKey="sprint"
            series={[{ key: "velocity", name: "Velocity", color: "var(--chart-1)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>

        <ChartCard title="Sprint Quality Trend" subtitle="Defect-free delivery rate per sprint">
          <PlannaLineChart
            data={sprintPerf}
            xKey="sprint"
            series={[{ key: "quality", name: "Quality Score", color: "var(--chart-2)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>
      </div>
    </DashboardShell>
  )
}

function PodiumCard({ member, rank, className }: { member: PerfMember; rank: number; className?: string }) {
  const medal = rank === 1
    ? { color: "text-amber-500", bg: "bg-amber-500/10", border: "border-amber-500/30", label: "1st" }
    : rank === 2
    ? { color: "text-slate-400", bg: "bg-slate-400/10", border: "border-slate-400/30", label: "2nd" }
    : { color: "text-orange-700 dark:text-orange-400", bg: "bg-orange-500/10", border: "border-orange-500/30", label: "3rd" }
  return (
    <div className={cn(
      "rounded-xl border p-4 text-center card-lift",
      medal.border, medal.bg,
      rank === 1 && "scale-105 shadow-lg shadow-primary/10",
      className,
    )}>
      <div className={cn("inline-flex items-center justify-center w-6 h-6 rounded-full mb-2", medal.bg, medal.color)}>
        <Trophy className="w-3.5 h-3.5" />
      </div>
      <Avatar className="w-14 h-14 mx-auto mb-2 ring-2 ring-offset-2 ring-offset-background"
        style={{ "--tw-ring-color": rank === 1 ? "var(--primary)" : "var(--border)" } as any}
      >
        <AvatarImage src={member.avatar} alt={member.name} />
        <AvatarFallback>{member.name[0]}</AvatarFallback>
      </Avatar>
      <p className="text-xs font-semibold text-foreground truncate">{member.name.split(" ")[0]}</p>
      <p className="text-[10px] text-muted-foreground truncate mb-2">{member.title.split(" ")[0]}</p>
      <p className={cn("text-2xl font-bold tabular-nums", medal.color)}>{member.score}</p>
      <p className="text-[10px] text-muted-foreground mt-1">{member.tasks} tasks · 8wk</p>
    </div>
  )
}

function MetricChip({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md bg-background/60 border border-border px-1.5 py-1 text-center">
      <p className="text-[9px] text-muted-foreground uppercase">{label}</p>
      <p className="text-xs font-semibold text-foreground tabular-nums">{value}</p>
    </div>
  )
}
