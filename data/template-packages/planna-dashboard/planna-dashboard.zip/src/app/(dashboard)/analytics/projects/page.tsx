"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaBarChart, PlannaDonutChart,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { HealthBadge } from "@/components/common/badges"
import {
  FolderKanban, DollarSign, Target, Activity, Users2, TrendingUp,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  type DateRange,
} from "../_lib"
import { projects, members, getMemberById } from "@/lib/data/mock"
import { cn, formatCurrency, pct } from "@/lib/utils"

export default function ProjectAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("90d")

  // Health distribution
  const healthTally = { on_track: 0, at_risk: 0, off_track: 0 }
  projects.forEach(p => { (healthTally as any)[p.health]++ })
  const healthData = [
    { name: "On Track", value: healthTally.on_track, color: "var(--chart-1)" },
    { name: "At Risk", value: healthTally.at_risk, color: "var(--chart-4)" },
    { name: "Off Track", value: healthTally.off_track, color: "var(--chart-1)" },
  ]

  // Budget vs actual — top 6 projects by budget
  const budgetData = projects
    .slice(0, 6)
    .map(p => ({
      name: p.key,
      budget: p.budget,
      spent: p.spent,
    }))

  // Progress comparison
  const progressData = projects.slice(0, 8).map(p => ({
    name: p.key,
    progress: p.progress,
  }))

  // Total budget / spent
  const totalBudget = projects.reduce((s, p) => s + p.budget, 0)
  const totalSpent = projects.reduce((s, p) => s + p.spent, 0)
  const totalTasksDone = projects.reduce((s, p) => s + p.tasksDone, 0)
  const totalTasksAll = projects.reduce((s, p) => s + p.tasksTotal, 0)
  const avgProgress = Math.round(projects.reduce((s, p) => s + p.progress, 0) / projects.length)

  // Top contributors per project (top 4 active projects)
  const topProjects = projects.filter(p => p.status === "active").slice(0, 4)

  return (
    <DashboardShell
      title="Project Analytics"
      description="Health, budget, progress, and contributor mix across the portfolio."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Projects" value={projects.filter(p => p.status === "active").length} hint={`${projects.length} total`} icon={FolderKanban} trend={{ value: 8, positive: true }} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Budget Utilized" value={pct(totalSpent, totalBudget) + "%"} hint={`${formatCurrency(totalSpent)} of ${formatCurrency(totalBudget)}`} icon={DollarSign} trend={{ value: 4, positive: false }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Avg Progress" value={`${avgProgress}%`} hint={`${totalTasksDone} of ${totalTasksAll} tasks done`} icon={Target} trend={{ value: 7, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="At-Risk Projects" value={healthTally.at_risk + healthTally.off_track} hint="need attention" icon={Activity} trend={{ value: 2, positive: false }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Health donut + budget vs actual */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Project Health" subtitle="Distribution by health status" fullscreen={false}>
          <PlannaDonutChart
            data={healthData}
            height={260}
            centerValue={`${projects.length}`}
            centerLabel="Projects"
          />
        </ChartCard>

        <ChartCard
          title="Budget vs Actual"
          subtitle="Top 6 projects by budget"
          className="lg:col-span-2"
        >
          <PlannaBarChart
            data={budgetData}
            xKey="name"
            series={[
              { key: "budget", name: "Budget" },
              { key: "spent", name: "Spent", color: "var(--chart-2)" },
            ]}
            height={280}
          />
        </ChartCard>
      </div>

      {/* Progress comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        <ChartCard title="Project Progress" subtitle="% complete — top 8 projects">
          <PlannaBarChart
            data={progressData}
            xKey="name"
            series={[{ key: "progress", name: "Progress %", color: "var(--chart-1)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>

        {/* Project completion timeline */}
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Completion Timeline</h3>
          </div>
          <div className="space-y-3 max-h-[280px] overflow-y-auto scroll-area-thin pr-1">
            {projects.slice(0, 8).map(p => {
              const start = new Date(p.startDate).getTime()
              const end = new Date(p.dueDate).getTime()
              const now = Date.now()
              const total = end - start
              const elapsed = Math.min(Math.max(now - start, 0), total)
              const timePct = Math.round((elapsed / total) * 100)
              const isOverdue = now > end && p.progress < 100
              return (
                <div key={p.id} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={cn("w-2 h-2 rounded-full shrink-0", p.color)} />
                      <span className="text-xs font-medium text-foreground truncate">{p.name}</span>
                      <HealthBadge health={p.health} />
                    </div>
                    <span className="text-[10px] text-muted-foreground tabular-nums shrink-0">{p.progress}%</span>
                  </div>
                  <div className="relative h-2 rounded-full bg-secondary/60 overflow-hidden">
                    {/* time elapsed track */}
                    <div
                      className="absolute inset-y-0 left-0 bg-muted-foreground/20"
                      style={{ width: `${timePct}%` }}
                    />
                    {/* actual progress */}
                    <div
                      className={cn(
                        "absolute inset-y-0 left-0 rounded-full transition-all duration-500",
                        isOverdue ? "bg-rose-500" : "bg-primary",
                      )}
                      style={{ width: `${p.progress}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>{new Date(p.startDate).toLocaleDateString("en-US", { month: "short", year: "2-digit" })}</span>
                    <span className={isOverdue ? "text-rose-500 font-medium" : ""}>
                      {isOverdue ? "Overdue" : new Date(p.dueDate).toLocaleDateString("en-US", { month: "short", year: "2-digit" })}
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>
      </div>

      {/* Top contributors per project */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center gap-2 mb-4">
          <Users2 className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Top Contributors per Project</h3>
          <Badge className="ml-auto bg-primary/10 text-primary text-[10px]">Active projects</Badge>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
          {topProjects.map(p => {
            const contributors = p.members
              .map(id => getMemberById(id))
              .filter(Boolean)
              .slice(0, 5)
            return (
              <div key={p.id} className="rounded-lg border border-border p-3 bg-secondary/30">
                <div className="flex items-center gap-2 mb-3">
                  <span className={cn("w-2.5 h-2.5 rounded-full", p.color)} />
                  <p className="text-xs font-semibold text-foreground truncate">{p.key} · {p.name}</p>
                </div>
                <div className="space-y-2">
                  {contributors.map(m => m && (
                    <div key={m.id} className="flex items-center gap-2">
                      <Avatar className="w-6 h-6">
                        <AvatarImage src={m.avatar} alt={m.name} />
                        <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-[11px] text-foreground truncate flex-1">{m.name}</span>
                      <span className="text-[10px] text-muted-foreground">{m.title.split(" ")[0]}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-2 border-t border-border flex items-center justify-between text-[10px]">
                  <span className="text-muted-foreground">{p.tasksDone}/{p.tasksTotal} tasks</span>
                  <Progress value={p.progress} className="h-1 w-16" />
                </div>
              </div>
            )
          })}
        </div>
      </Card>
    </DashboardShell>
  )
}
