"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaAreaChart, PlannaBarChart, PlannaDonutChart, PlannaHeatmap,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Clock, DollarSign, Timer, Zap, Sun, Sunrise, Moon,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  buildTimeSeries, seeded,
  type DateRange,
} from "../_lib"
import { timeByProject, focusHeatmap, dashboardStats } from "@/lib/data/mock"
import { cn } from "@/lib/utils"

export default function TimeAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("30d")

  // Billable vs non-billable
  const billableHours = dashboardStats.billableHours
  const nonBillableHours = dashboardStats.hoursThisWeek - billableHours
  const billableData = [
    { name: "Billable", value: billableHours, color: "var(--chart-1)" },
    { name: "Non-billable", value: nonBillableHours, color: "var(--chart-4)" },
  ]

  // Daily hours trend — last 14 days
  const series14 = buildTimeSeries(14)
  const dailyHours = series14.map((d, i) => ({
    date: d.label,
    hours: Math.round((6 + seeded(i, 3) * 4) * 10) / 10,
    billable: Math.round((4 + seeded(i, 7) * 3) * 10) / 10,
  }))

  // Time by project (from mock)
  const timeByProjectData = timeByProject.map(p => ({
    name: p.name,
    hours: p.hours,
  }))

  // Avg daily hours by weekday (synthetic but stable)
  const weekdayData = [
    { name: "Mon", hours: 7.8 },
    { name: "Tue", hours: 8.4 },
    { name: "Wed", hours: 8.1 },
    { name: "Thu", hours: 7.6 },
    { name: "Fri", hours: 6.9 },
    { name: "Sat", hours: 2.1 },
    { name: "Sun", hours: 1.2 },
  ]

  // Peak productivity hours — synthesize an hourly distribution
  const peakHours = [
    { name: "9a", score: 72 }, { name: "10a", score: 88 }, { name: "11a", score: 91 },
    { name: "12p", score: 64 }, { name: "1p", score: 58 }, { name: "2p", score: 79 },
    { name: "3p", score: 86 }, { name: "4p", score: 74 }, { name: "5p", score: 52 },
    { name: "6p", score: 38 }, { name: "7p", score: 28 }, { name: "8p", score: 22 },
  ]
  const peakHour = peakHours.reduce((max, h) => (h.score > max.score ? h : max), peakHours[0])

  return (
    <DashboardShell
      title="Time Analytics"
      description="Where hours go, when focus peaks, and how billable time stacks up."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Hours This Week" value={`${dashboardStats.hoursThisWeek}h`} hint="38h last week" icon={Clock} trend={{ value: 8, positive: true }} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Billable Hours" value={`${billableHours}h`} hint={`${Math.round((billableHours / dashboardStats.hoursThisWeek) * 100)}% of total`} icon={DollarSign} trend={{ value: 5, positive: true }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Avg Session" value="42m" hint="across 96 sessions" icon={Timer} trend={{ value: 6, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Focus Today" value={`${dashboardStats.focusHoursToday}h`} hint="3.1h avg this week" icon={Zap} trend={{ value: 12, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Billable donut + daily hours */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Billable vs Non-billable" subtitle="This week" fullscreen={false}>
          <PlannaDonutChart
            data={billableData}
            height={260}
            centerValue={`${Math.round((billableHours / dashboardStats.hoursThisWeek) * 100)}%`}
            centerLabel="Billable"
          />
        </ChartCard>

        <ChartCard
          title="Daily Hours Trend"
          subtitle="Total vs billable hours — last 14 days"
          className="lg:col-span-2"
        >
          <PlannaAreaChart
            data={dailyHours}
            xKey="date"
            series={[
              { key: "hours", name: "Total Hours" },
              { key: "billable", name: "Billable", color: "var(--chart-2)" },
            ]}
            height={280}
          />
        </ChartCard>
      </div>

      {/* Time by project + weekday */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        <ChartCard title="Time by Project" subtitle="Hours logged per project this period">
          <PlannaBarChart
            data={timeByProjectData}
            xKey="name"
            series={[{ key: "hours", name: "Hours" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>

        <ChartCard title="Avg Daily Hours by Weekday" subtitle="Patterns across the week">
          <PlannaBarChart
            data={weekdayData}
            xKey="name"
            series={[{ key: "hours", name: "Hours", color: "var(--chart-2)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>
      </div>

      {/* Focus heatmap + peak productivity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        <ChartCard title="Focus Session Heatmap" subtitle="7 days × 24 hours — when deep work happens" className="lg:col-span-2" fullscreen={false}>
          <PlannaHeatmap data={focusHeatmap} />
        </ChartCard>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <Sun className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold text-foreground">Peak Productivity</h3>
          </div>
          <div className="text-center py-3">
            <div className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-primary/10 mb-2">
              <Sunrise className="w-5 h-5 text-primary" />
              <span className="text-2xl font-bold text-foreground">{peakHour.name}</span>
            </div>
            <p className="text-xs text-muted-foreground">Most productive hour — score {peakHour.score}/100</p>
          </div>
          <div className="space-y-1.5 mt-4">
            {peakHours.map(h => (
              <div key={h.name} className="flex items-center gap-2">
                <span className="text-[10px] text-muted-foreground w-8 shrink-0">{h.name}</span>
                <div className="flex-1 h-2 rounded-full bg-secondary/60 overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-500",
                      h.score > 80 ? "bg-primary" : h.score > 60 ? "bg-primary/70" : "bg-muted-foreground/40",
                    )}
                    style={{ width: `${h.score}%` }}
                  />
                </div>
                <span className="text-[10px] font-semibold text-foreground w-6 text-right tabular-nums">{h.score}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-border grid grid-cols-3 gap-2 text-center">
            <div>
              <Sunrise className="w-3.5 h-3.5 text-amber-500 mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Morning</p>
              <p className="text-xs font-semibold text-foreground">84</p>
            </div>
            <div>
              <Sun className="w-3.5 h-3.5 text-orange-500 mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Afternoon</p>
              <p className="text-xs font-semibold text-foreground">79</p>
            </div>
            <div>
              <Moon className="w-3.5 h-3.5 text-violet-500 mx-auto mb-1" />
              <p className="text-[10px] text-muted-foreground">Evening</p>
              <p className="text-xs font-semibold text-foreground">28</p>
            </div>
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
