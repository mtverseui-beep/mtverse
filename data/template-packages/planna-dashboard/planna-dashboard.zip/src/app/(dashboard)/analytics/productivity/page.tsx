"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaAreaChart, PlannaBarChart, PlannaRadialChart,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  TrendingUp, Brain, Zap, Target, ArrowUpRight, ArrowDownRight,
  AlertCircle, Smartphone, MessageSquare, Mail, Bell, Coffee,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  seeded,
  type DateRange,
} from "../_lib"
import { productivityTrend, dashboardStats } from "@/lib/data/mock"
import { cn } from "@/lib/utils"

export default function ProductivityAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("90d")

  // 12-week trend (from mock)
  const trendData = productivityTrend

  // Productivity score radial
  const score = dashboardStats.productivityScore

  // Focus hours trend — derive from productivityTrend
  const focusTrend = productivityTrend.map(w => ({
    week: w.week,
    focus: w.focus,
    target: 30,
  }))

  // Deep work distribution by day of week
  const deepWorkData = [
    { name: "Mon", hours: 5.2 },
    { name: "Tue", hours: 6.8 },
    { name: "Wed", hours: 6.1 },
    { name: "Thu", hours: 5.4 },
    { name: "Fri", hours: 4.1 },
    { name: "Sat", hours: 1.4 },
    { name: "Sun", hours: 0.6 },
  ]

  // Comparison vs last quarter
  const quarterCompare = [
    { metric: "Tasks Completed", current: 412, previous: 358, positive: true },
    { metric: "Focus Hours", current: 286, previous: 224, positive: true },
    { metric: "Avg Cycle Time", current: 2.4, previous: 3.1, positive: true, lowerBetter: true },
    { metric: "Overdue Rate", current: 4.8, previous: 6.2, positive: true, lowerBetter: true },
    { metric: "Meetings", current: 48, previous: 62, positive: true, lowerBetter: true },
    { metric: "Context Switches", current: 14, previous: 11, positive: false, lowerBetter: true },
  ]

  // Top distractions
  const distractions = [
    { name: "Slack notifications", minutes: 86, icon: MessageSquare, color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
    { name: "Email checking", minutes: 64, icon: Mail, color: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
    { name: "Phone / social", minutes: 52, icon: Smartphone, color: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
    { name: "Meeting interrupts", minutes: 41, icon: Bell, color: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
    { name: "Breaks (over)", minutes: 28, icon: Coffee, color: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
  ]
  const maxDistraction = Math.max(...distractions.map(d => d.minutes))

  return (
    <DashboardShell
      title="Productivity Trends"
      description="12-week momentum, deep work distribution, and quarter-over-quarter comparison."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Productivity Score" value={score} hint="out of 100" icon={TrendingUp} trend={{ value: 5, positive: true }} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Deep Work Hours" value="28h" hint="this week" icon={Brain} trend={{ value: 14, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Focus Sessions" value={42} hint="avg 40 min" icon={Zap} trend={{ value: 8, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Tasks Shipped" value={58} hint="vs 52 planned" icon={Target} trend={{ value: 12, positive: true }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
      </div>

      {/* 12-week trend + score radial */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="12-Week Productivity Trend" subtitle="Completed vs planned tasks" className="lg:col-span-2">
          <PlannaAreaChart
            data={trendData}
            xKey="week"
            series={[
              { key: "completed", name: "Completed" },
              { key: "planned", name: "Planned", color: "var(--chart-3)" },
            ]}
            height={280}
          />
        </ChartCard>

        <ChartCard title="Productivity Score" subtitle="Weighted: output × focus × quality" fullscreen={false}>
          <div className="flex flex-col items-center gap-3 py-4">
            <PlannaRadialChart value={score} label="Excellent" size={180} />
            <div className="flex items-center gap-2">
              <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
                <ArrowUpRight className="w-3 h-3" /> +5 vs last week
              </Badge>
              <Badge className="bg-primary/10 text-primary gap-1">
                <TrendingUp className="w-3 h-3" /> Top 15%
              </Badge>
            </div>
          </div>
        </ChartCard>
      </div>

      {/* Focus hours trend + deep work distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        <ChartCard title="Focus Hours Trend" subtitle="Weekly focus hours vs 30h target">
          <PlannaAreaChart
            data={focusTrend}
            xKey="week"
            series={[
              { key: "focus", name: "Focus Hours", color: "var(--chart-2)" },
              { key: "target", name: "Target", color: "var(--chart-4)" },
            ]}
            height={260}
          />
        </ChartCard>

        <ChartCard title="Deep Work by Day of Week" subtitle="Hours of uninterrupted focus">
          <PlannaBarChart
            data={deepWorkData}
            xKey="name"
            series={[{ key: "hours", name: "Deep Work hrs", color: "var(--chart-2)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>
      </div>

      {/* Quarter comparison + top distractions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">vs Last Quarter</h3>
            <Badge className="ml-auto bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px]">QoQ</Badge>
          </div>
          <div className="space-y-3">
            {quarterCompare.map(q => {
              const delta = q.lowerBetter
                ? q.previous - q.current
                : q.current - q.previous
              const deltaPct = Math.round((Math.abs(delta) / q.previous) * 100)
              const isWin = q.positive
              return (
                <div key={q.metric} className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{q.metric}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-sm font-semibold text-foreground tabular-nums">{q.current}</span>
                      <span className="text-[10px] text-muted-foreground">was {q.previous}</span>
                    </div>
                  </div>
                  <div className={cn(
                    "inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md shrink-0",
                    isWin ? "text-emerald-600 bg-emerald-500/10 dark:text-emerald-400" : "text-rose-600 bg-rose-500/10 dark:text-rose-400",
                  )}>
                    {isWin ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {deltaPct}%
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold text-foreground">Top Distractions</h3>
            <Badge className="ml-auto bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[10px]">This week</Badge>
          </div>
          <div className="space-y-3">
            {distractions.map(d => {
              const Icon = d.icon
              return (
                <div key={d.name}>
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className={cn("w-6 h-6 rounded-md flex items-center justify-center shrink-0", d.color)}>
                      <Icon className="w-3 h-3" />
                    </div>
                    <span className="text-xs font-medium text-foreground flex-1 truncate">{d.name}</span>
                    <span className="text-[11px] font-semibold text-foreground tabular-nums">{d.minutes}m</span>
                  </div>
                  <Progress value={(d.minutes / maxDistraction) * 100} className="h-1.5" />
                </div>
              )
            })}
          </div>
          <div className="mt-4 pt-3 border-t border-border flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Total distraction time</span>
            <span className="font-semibold text-rose-600 dark:text-rose-400">4h 31m / week</span>
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
