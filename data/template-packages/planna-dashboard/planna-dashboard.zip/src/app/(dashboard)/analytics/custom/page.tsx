"use client"

import { useState, useMemo } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import {
  ChartCard, PlannaBarChart, PlannaAreaChart, PlannaLineChart, PlannaDonutChart,
} from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  SlidersHorizontal, Save, Play, BarChart3, LineChart as LineIcon,
  AreaChart as AreaIcon, PieChart as PieIcon, Trash2, FileText,
  Calendar, Layers, Hash, Sigma, Calculator,
} from "lucide-react"
import {
  AnalyticsSubNav, DateRangeSelector, ExportButton,
  seeded,
  type DateRange,
} from "../_lib"
import { projects, members, tasks } from "@/lib/data/mock"
import { cn } from "@/lib/utils"

type Dimension = "time" | "project" | "member" | "priority" | "status"
type Metric = "count" | "sum" | "avg"
type AggregationField = "tasks" | "hours" | "estimate" | "logged" | "budget" | "spent"
type ChartType = "bar" | "area" | "line" | "donut"

interface SavedReport {
  id: string
  name: string
  dimension: Dimension
  metric: Metric
  field: AggregationField
  chartType: ChartType
  range: DateRange
  createdAt: string
}

const DIMENSIONS: { value: Dimension; label: string; icon: typeof Calendar }[] = [
  { value: "time", label: "Time", icon: Calendar },
  { value: "project", label: "Project", icon: Layers },
  { value: "member", label: "Member", icon: Hash },
  { value: "priority", label: "Priority", icon: Hash },
  { value: "status", label: "Status", icon: Hash },
]

const METRICS: { value: Metric; label: string; icon: typeof Hash }[] = [
  { value: "count", label: "Count", icon: Hash },
  { value: "sum", label: "Sum", icon: Sigma },
  { value: "avg", label: "Average", icon: Calculator },
]

const FIELDS: { value: AggregationField; label: string }[] = [
  { value: "tasks", label: "Tasks" },
  { value: "hours", label: "Hours" },
  { value: "estimate", label: "Estimate (h)" },
  { value: "logged", label: "Logged (h)" },
  { value: "budget", label: "Budget ($)" },
  { value: "spent", label: "Spent ($)" },
]

const CHART_TYPES: { value: ChartType; label: string; icon: typeof BarChart3 }[] = [
  { value: "bar", label: "Bar", icon: BarChart3 },
  { value: "area", label: "Area", icon: AreaIcon },
  { value: "line", label: "Line", icon: LineIcon },
  { value: "donut", label: "Donut", icon: PieIcon },
]

// Seed saved reports
const INITIAL_SAVED: SavedReport[] = [
  { id: "r1", name: "Weekly Task Throughput", dimension: "time", metric: "count", field: "tasks", chartType: "area", range: "30d", createdAt: "2d ago" },
  { id: "r2", name: "Budget by Project", dimension: "project", metric: "sum", field: "budget", chartType: "bar", range: "90d", createdAt: "5d ago" },
  { id: "r3", name: "Hours per Member", dimension: "member", metric: "sum", field: "hours", chartType: "bar", range: "30d", createdAt: "1w ago" },
  { id: "r4", name: "Priority Distribution", dimension: "priority", metric: "count", field: "tasks", chartType: "donut", range: "90d", createdAt: "2w ago" },
]

export default function CustomReportsPage() {
  const [range, setRange] = useState<DateRange>("30d")
  const [reportName, setReportName] = useState("")
  const [dimension, setDimension] = useState<Dimension>("project")
  const [metric, setMetric] = useState<Metric>("sum")
  const [field, setField] = useState<AggregationField>("budget")
  const [chartType, setChartType] = useState<ChartType>("bar")
  const [saved, setSaved] = useState<SavedReport[]>(INITIAL_SAVED)
  const [previewed, setPreviewed] = useState(false)

  // Build the preview dataset based on selections
  const previewData = useMemo(() => {
    let buckets: { key: string; label: string; value: number }[] = []
    if (dimension === "time") {
      buckets = Array.from({ length: 8 }).map((_, i) => ({
        key: `w${i}`,
        label: `W${i + 1}`,
        value: 0,
      }))
    } else if (dimension === "project") {
      buckets = projects.slice(0, 6).map(p => ({ key: p.id, label: p.key, value: 0 }))
    } else if (dimension === "member") {
      buckets = members.slice(0, 6).map(m => ({ key: m.id, label: m.name.split(" ")[0], value: 0 }))
    } else if (dimension === "priority") {
      buckets = ["urgent", "high", "medium", "low"].map(p => ({ key: p, label: p[0].toUpperCase() + p.slice(1), value: 0 }))
    } else if (dimension === "status") {
      buckets = ["backlog", "todo", "in_progress", "review", "done"].map(s => ({ key: s, label: s.replace("_", " ").replace(/\b\w/g, c => c.toUpperCase()), value: 0 }))
    }

    // Populate values
    buckets = buckets.map((b, i) => {
      let val = 0
      if (dimension === "project") {
        const p = projects.find(pp => pp.id === b.key)
        if (p) {
          if (field === "budget") val = p.budget
          else if (field === "spent") val = p.spent
          else if (field === "tasks") val = p.tasksTotal
        }
      } else if (dimension === "member") {
        const m = members.find(mm => mm.id === b.key)
        if (m) {
          if (field === "tasks") val = m.completedTasks
          else if (field === "hours") val = m.utilized * 4
        }
      } else if (dimension === "priority") {
        val = tasks.filter(t => t.priority === b.key).length
        if (field !== "tasks") val = val * (field === "hours" ? 8 : field === "estimate" ? 9 : 6)
      } else if (dimension === "status") {
        val = tasks.filter(t => t.status === b.key).length + (b.key === "done" ? 78 : 0)
      } else if (dimension === "time") {
        val = Math.round(40 + seeded(i, 7) * 30)
        if (field === "budget") val = val * 1000
        else if (field === "hours") val = val * 2
      }
      // apply metric
      if (metric === "avg") val = Math.round(val / 4)
      return { ...b, value: val }
    })
    return buckets
  }, [dimension, metric, field])

  const previewSeries = [{ key: "value", name: `${metric === "count" ? "Count of" : metric} ${field}` }]

  function saveReport() {
    const name = reportName.trim() || `Report ${saved.length + 1}`
    const r: SavedReport = {
      id: `r${Date.now()}`,
      name,
      dimension, metric, field, chartType, range,
      createdAt: "just now",
    }
    setSaved([r, ...saved])
    setReportName("")
    if (typeof window !== "undefined") {
      import("sonner").then(({ toast }) => toast.success("Report saved", { description: `"${name}" added to your reports` }))
    }
  }

  function deleteReport(id: string) {
    setSaved(saved.filter(r => r.id !== id))
  }

  function loadReport(r: SavedReport) {
    setDimension(r.dimension)
    setMetric(r.metric)
    setField(r.field)
    setChartType(r.chartType)
    setRange(r.range)
    setReportName(r.name)
    setPreviewed(true)
    if (typeof window !== "undefined") {
      import("sonner").then(({ toast }) => toast.info("Report loaded", { description: `"${r.name}" configuration applied` }))
    }
  }

  return (
    <DashboardShell
      title="Custom Reports Builder"
      description="Compose dimensions, metrics, and chart types — preview, save, and reuse."
      actions={
        <>
          <DateRangeSelector value={range} onChange={setRange} />
          <ExportButton />
        </>
      }
    >
      <AnalyticsSubNav />

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Saved Reports" value={saved.length} hint="in your library" icon={FileText} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Dimensions" value={DIMENSIONS.length} hint="X-axis options" icon={Layers} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Metrics" value={METRICS.length} hint="aggregation types" icon={Sigma} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Chart Types" value={CHART_TYPES.length} hint="visualization options" icon={BarChart3} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Builder panel */}
        <Card className="p-4 md:p-5 card-lift lg:col-span-1">
          <div className="flex items-center gap-2 mb-4">
            <SlidersHorizontal className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Report Builder</h3>
          </div>

          <div className="space-y-4">
            {/* Name */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1.5 block">Report name</Label>
              <Input
                value={reportName}
                onChange={e => setReportName(e.target.value)}
                placeholder="e.g. Monthly budget burn"
                className="h-9 text-sm"
              />
            </div>

            {/* Dimension */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1.5 block">Dimension (X axis)</Label>
              <div className="grid grid-cols-2 gap-1.5">
                {DIMENSIONS.map(d => {
                  const Icon = d.icon
                  const active = dimension === d.value
                  return (
                    <button
                      key={d.value}
                      onClick={() => setDimension(d.value)}
                      className={cn(
                        "flex items-center gap-1.5 h-9 px-2 rounded-lg border text-xs font-medium transition-all",
                        active
                          ? "bg-primary text-primary-foreground border-primary shadow-sm"
                          : "bg-card border-border text-muted-foreground hover:text-foreground hover:bg-secondary",
                      )}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {d.label}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Metric + Field */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-muted-foreground mb-1.5 block">Metric</Label>
                <Select value={metric} onValueChange={(v) => setMetric(v as Metric)}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {METRICS.map(m => <SelectItem key={m.value} value={m.value} className="text-xs">{m.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground mb-1.5 block">Field</Label>
                <Select value={field} onValueChange={(v) => setField(v as AggregationField)}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {FIELDS.map(f => <SelectItem key={f.value} value={f.value} className="text-xs">{f.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Chart type */}
            <div>
              <Label className="text-xs text-muted-foreground mb-1.5 block">Chart type</Label>
              <div className="grid grid-cols-4 gap-1.5">
                {CHART_TYPES.map(c => {
                  const Icon = c.icon
                  const active = chartType === c.value
                  return (
                    <button
                      key={c.value}
                      onClick={() => setChartType(c.value)}
                      className={cn(
                        "flex flex-col items-center justify-center gap-1 h-14 rounded-lg border text-[10px] font-medium transition-all",
                        active
                          ? "bg-primary text-primary-foreground border-primary shadow-sm"
                          : "bg-card border-border text-muted-foreground hover:text-foreground hover:bg-secondary",
                      )}
                    >
                      <Icon className="w-4 h-4" />
                      {c.label}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <Button
                onClick={() => setPreviewed(true)}
                className="flex-1 h-9 text-xs bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
              >
                <Play className="w-3.5 h-3.5" /> Preview
              </Button>
              <Button
                onClick={saveReport}
                variant="outline"
                className="flex-1 h-9 text-xs gap-1.5 bg-transparent"
              >
                <Save className="w-3.5 h-3.5" /> Save
              </Button>
            </div>
          </div>
        </Card>

        {/* Preview panel */}
        <Card className="p-4 md:p-5 card-lift lg:col-span-2">
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">Live Preview</h3>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <Badge className="bg-primary/10 text-primary text-[10px] capitalize">{dimension}</Badge>
              <Badge className="bg-secondary text-secondary-foreground text-[10px] capitalize">{metric} · {field}</Badge>
              <Badge className="bg-secondary text-secondary-foreground text-[10px] capitalize">{chartType}</Badge>
            </div>
          </div>

          {!previewed ? (
            <div className="flex flex-col items-center justify-center text-center py-16 border-2 border-dashed border-border rounded-lg">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-3">
                <BarChart3 className="w-7 h-7" />
              </div>
              <p className="text-sm font-semibold text-foreground mb-1">No preview yet</p>
              <p className="text-xs text-muted-foreground max-w-xs mb-4">Configure your report on the left and click Preview to render a live chart.</p>
              <Button onClick={() => setPreviewed(true)} size="sm" className="h-8 text-xs bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
                <Play className="w-3.5 h-3.5" /> Generate preview
              </Button>
            </div>
          ) : chartType === "donut" ? (
            <PlannaDonutChart
              data={previewData.map((d, i) => ({
                name: d.label,
                value: d.value,
                color: `var(--chart-${(i % 5) + 1})`,
              }))}
              height={300}
              centerValue={`${previewData.reduce((s, d) => s + d.value, 0)}`}
              centerLabel="Total"
            />
          ) : chartType === "area" ? (
            <PlannaAreaChart
              data={previewData}
              xKey="label"
              series={previewSeries}
              height={300}
              showLegend={false}
            />
          ) : chartType === "line" ? (
            <PlannaLineChart
              data={previewData}
              xKey="label"
              series={previewSeries}
              height={300}
              showLegend={false}
            />
          ) : (
            <PlannaBarChart
              data={previewData}
              xKey="label"
              series={previewSeries}
              height={300}
              showLegend={false}
            />
          )}
        </Card>
      </div>

      {/* Saved reports list */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center gap-2 mb-4">
          <FileText className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Saved Reports</h3>
          <Badge className="ml-auto bg-primary/10 text-primary text-[10px]">{saved.length}</Badge>
        </div>
        {saved.length === 0 ? (
          <div className="text-center py-10 text-xs text-muted-foreground">
            No saved reports yet. Build one above and hit Save.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {saved.map(r => {
              const dim = DIMENSIONS.find(d => d.value === r.dimension)!
              const ch = CHART_TYPES.find(c => c.value === r.chartType)!
              const ChIcon = ch.icon
              return (
                <div key={r.id} className="rounded-lg border border-border p-3 bg-secondary/30 card-lift">
                  <div className="flex items-start gap-2 mb-2">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <ChIcon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-foreground truncate">{r.name}</p>
                      <p className="text-[10px] text-muted-foreground">Saved {r.createdAt}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-3">
                    <Badge className="bg-primary/10 text-primary text-[9px] capitalize">{dim.label}</Badge>
                    <Badge className="bg-secondary text-secondary-foreground text-[9px] capitalize">{r.metric} {r.field}</Badge>
                    <Badge className="bg-secondary text-secondary-foreground text-[9px] uppercase">{r.range}</Badge>
                  </div>
                  <div className="flex gap-1.5">
                    <Button onClick={() => loadReport(r)} size="sm" className="h-7 text-[11px] flex-1 bg-primary text-primary-foreground hover:bg-primary/90 gap-1">
                      <Play className="w-3 h-3" /> Load
                    </Button>
                    <Button onClick={() => deleteReport(r.id)} size="sm" variant="outline" className="h-7 w-7 p-0 bg-transparent text-muted-foreground hover:text-rose-600 hover:border-rose-500/30">
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </Card>
    </DashboardShell>
  )
}
