"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  MessageSquare, Reply, Filter, Search, Link2, AtSign, Sparkles,
  ChevronDown, MessageCircle, Send,
} from "lucide-react"
import { tasks, members, currentMember } from "@/lib/data/mock"
import { cn, timeAgo, initials, formatDate } from "@/lib/utils"
import { toast } from "sonner"

// ============================================================
// SYNTHETIC UNIFIED COMMENT FEED
// (tasks[].comments only has 2 entries — synthesize a richer set)
// ============================================================

interface FeedComment {
  id: string
  taskId: string
  taskKey: string
  taskTitle: string
  projectId: string
  projectName: string
  projectColor: string
  authorId: string
  authorName: string
  authorAvatar: string
  body: string
  createdAt: string
  mentions?: string[]
  replies?: number
}

const feedComments: FeedComment[] = [
  { id: "fc-1", taskId: "t1", taskKey: "PLN-101", taskTitle: "Implement command palette keyboard navigation", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", authorId: "u2", authorName: "Zara Marlowe", authorAvatar: members[1].avatar, body: "Loving the ⌘K shortcut. Can we add arrow-key navigation between sections? @jessin would love your eyes on the focus behavior.", createdAt: "2026-01-28T14:32:00Z", mentions: ["jessin"], replies: 2 },
  { id: "fc-2", taskId: "t1", taskKey: "PLN-101", taskTitle: "Implement command palette keyboard navigation", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", authorId: "u4", authorName: "Felix Brandt", authorAvatar: members[4].avatar, body: "Pushed arrow-key nav in #284. Wraps around at the top/bottom of each section.", createdAt: "2026-01-28T15:01:00Z" },
  { id: "fc-3", taskId: "t1", taskKey: "PLN-101", taskTitle: "Implement command palette keyboard navigation", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", authorId: "u1", authorName: currentMember.name, authorAvatar: currentMember.avatar, body: "Looks great. One nit: when the palette is open and the user hits Escape, the search query should clear. Right now it persists on next open.", createdAt: "2026-01-28T15:21:00Z" },
  { id: "fc-4", taskId: "t3", taskKey: "PLN-103", taskTitle: "WebSocket reconnect logic for live presence", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", authorId: "u6", authorName: "Amara Okafor", authorAvatar: members[5].avatar, body: "Backoff strategy is in: starts at 1s, doubles up to 30s, max 10 retries. Adds an offline pill in the top-right.", createdAt: "2026-01-28T10:14:00Z", mentions: [], replies: 1 },
  { id: "fc-5", taskId: "t3", taskKey: "PLN-103", taskTitle: "WebSocket reconnect logic for live presence", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", authorId: "u3", authorName: "Theo Nakamura", authorAvatar: members[2].avatar, body: "Nice. One concern — once we hit max retries, we need a manual reconnect button, not a silent failure.", createdAt: "2026-01-28T10:42:00Z" },
  { id: "fc-6", taskId: "t4", taskKey: "MOB-201", taskTitle: "iOS push notification payload parsing", projectId: "p2", projectName: "Mobile Companion", projectColor: "bg-teal-500", authorId: "u8", authorName: "Naomi Chen", authorAvatar: members[7].avatar, body: "Tested on iOS 17 and 18 — looks good. Rich media displays correctly in the notification center.", createdAt: "2026-01-27T11:00:00Z", replies: 3 },
  { id: "fc-7", taskId: "t4", taskKey: "MOB-201", taskTitle: "iOS push notification payload parsing", projectId: "p2", projectName: "Mobile Companion", projectColor: "bg-teal-500", authorId: "u7", authorName: "Leon Cruz", authorAvatar: members[6].avatar, body: "Pushed the deep-link routing fix. Make sure to test from a cold start — the route was getting eaten by the splash screen.", createdAt: "2026-01-27T11:45:00Z" },
  { id: "fc-8", taskId: "t10", taskKey: "INF-501", taskTitle: "Migrate auth service to Kubernetes", projectId: "p6", projectName: "Infrastructure Migration", projectColor: "bg-sky-500", authorId: "u9", authorName: "Hugo Lindqvist", authorAvatar: members[8].avatar, body: "Blocked on staging cluster quota increase. Submitted the ticket to platform — ETA is 48h.", createdAt: "2026-01-26T09:30:00Z" },
  { id: "fc-9", taskId: "t10", taskKey: "INF-501", taskTitle: "Migrate auth service to Kubernetes", projectId: "p6", projectName: "Infrastructure Migration", projectColor: "bg-sky-500", authorId: "u3", authorName: "Theo Nakamura", authorAvatar: members[2].avatar, body: "Marking the task as blocked. We'll keep the Helm chart ready and resume as soon as the quota is bumped.", createdAt: "2026-01-26T10:10:00Z" },
  { id: "fc-10", taskId: "t14", taskKey: "SEC-901", taskTitle: "Pen test remediation: IDOR in /api/v1/projects/{id}", projectId: "p12", projectName: "Security Audit", projectColor: "bg-rose-500", authorId: "u6", authorName: "Amara Okafor", authorAvatar: members[5].avatar, body: "Added ownership check before returning project data. Also hardened the bulk-list endpoint — was leaking IDs of projects the user shouldn't see.", createdAt: "2026-01-28T13:02:00Z", replies: 2 },
  { id: "fc-11", taskId: "t14", taskKey: "SEC-901", taskTitle: "Pen test remediation: IDOR in /api/v1/projects/{id}", projectId: "p12", projectName: "Security Audit", projectColor: "bg-rose-500", authorId: "u8", authorName: "Naomi Chen", authorAvatar: members[7].avatar, body: "Re-ran the IDOR test suite — 0 failures. Worth adding a regression test for the bulk-list endpoint too.", createdAt: "2026-01-28T13:38:00Z" },
  { id: "fc-12", taskId: "t11", taskKey: "ARC-601", taskTitle: "Custom onboarding flow for Acme", projectId: "p9", projectName: "Acme Client Project", projectColor: "bg-lime-600", authorId: "u5", authorName: "Felix Brandt", authorAvatar: members[4].avatar, body: "Custom steps UI is in. Acme's 5-step variant is feature-flagged behind `onboarding.variant=acme`.", createdAt: "2026-01-27T16:20:00Z" },
  { id: "fc-13", taskId: "t11", taskKey: "ARC-601", taskTitle: "Custom onboarding flow for Acme", projectId: "p9", projectName: "Acme Client Project", projectColor: "bg-lime-600", authorId: "u2", authorName: "Zara Marlowe", authorAvatar: members[1].avatar, body: "@felix the brand assets are in the shared folder. Logo is SVG, primary color is `#0E7C5A`. Let's preview together tomorrow.", createdAt: "2026-01-27T16:45:00Z", mentions: ["felix"] },
  { id: "fc-14", taskId: "t26", taskKey: "PLN-108", taskTitle: "Time tracker widget improvements", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", authorId: "u5", authorName: "Felix Brandt", authorAvatar: members[4].avatar, body: "Pause/resume is in. Manual entry modal opens with the last-used project pre-selected. UX win.", createdAt: "2026-01-28T08:50:00Z" },
  { id: "fc-15", taskId: "t26", taskKey: "PLN-108", taskTitle: "Time tracker widget improvements", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", authorId: "u1", authorName: currentMember.name, authorAvatar: currentMember.avatar, body: "Exactly what I wanted. Moving to review. @naomi can you give it a final QA pass?", createdAt: "2026-01-28T09:12:00Z", mentions: ["naomi"] },
  { id: "fc-16", taskId: "t20", taskKey: "ARC-602", taskTitle: "Acme SSO integration", projectId: "p9", projectName: "Acme Client Project", projectColor: "bg-lime-600", authorId: "u9", authorName: "Hugo Lindqvist", authorAvatar: members[8].avatar, body: "SAML metadata XML is in. Acme Okta tenant confirmed. JIT provisioning flows through to role mapping — Admin, Editor, Viewer.", createdAt: "2026-01-26T10:05:00Z" },
  { id: "fc-17", taskId: "t24", taskKey: "QA-702", taskTitle: "E2E test for invite member flow", projectId: "p7", projectName: "Test Automation Suite", projectColor: "bg-emerald-600", authorId: "u8", authorName: "Naomi Chen", authorAvatar: members[7].avatar, body: "Added a test for the role-removal path. Found a bug — removing the last admin doesn't block; will file separately.", createdAt: "2026-01-27T14:20:00Z" },
  { id: "fc-18", taskId: "t17", taskKey: "PLN-105", taskTitle: "Recurring task scheduler", projectId: "p1", projectName: "Planna Web App", projectColor: "bg-emerald-500", authorId: "u6", authorName: "Amara Okafor", authorAvatar: members[5].avatar, body: "Weekly recurrence is in. Skipping on holidays requires a calendar source — punting to a follow-up task.", createdAt: "2026-01-27T09:00:00Z" },
]

// ============================================================
// PAGE
// ============================================================

export default function CommentsPage() {
  const [search, setSearch] = useState("")
  const [projectFilter, setProjectFilter] = useState("all")
  const [taskFilter, setTaskFilter] = useState("all")
  const [authorFilter, setAuthorFilter] = useState("all")
  const [replyDraft, setReplyDraft] = useState<string | null>(null)
  const [replyText, setReplyText] = useState("")

  const projects = useMemo(() => {
    const map = new Map<string, { id: string; name: string; color: string }>()
    feedComments.forEach(c => map.set(c.projectId, { id: c.projectId, name: c.projectName, color: c.projectColor }))
    return Array.from(map.values())
  }, [])

  const tasksWithComments = useMemo(() => {
    const map = new Map<string, { id: string; key: string; title: string }>()
    feedComments.forEach(c => map.set(c.taskId, { id: c.taskId, key: c.taskKey, title: c.taskTitle }))
    return Array.from(map.values())
  }, [])

  const authors = useMemo(() => {
    const map = new Map<string, { id: string; name: string; avatar: string }>()
    feedComments.forEach(c => map.set(c.authorId, { id: c.authorId, name: c.authorName, avatar: c.authorAvatar }))
    return Array.from(map.values())
  }, [])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return feedComments
      .filter(c => projectFilter === "all" || c.projectId === projectFilter)
      .filter(c => taskFilter === "all" || c.taskId === taskFilter)
      .filter(c => authorFilter === "all" || c.authorId === authorFilter)
      .filter(c => !q || c.body.toLowerCase().includes(q) || c.taskTitle.toLowerCase().includes(q) || c.authorName.toLowerCase().includes(q))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }, [search, projectFilter, taskFilter, authorFilter])

  const handleSendReply = (commentId: string, taskKey: string) => {
    if (!replyText.trim()) return
    toast.success("Reply posted", { description: `On ${taskKey}` })
    setReplyText("")
    setReplyDraft(null)
  }

  const hasActiveFilters = projectFilter !== "all" || taskFilter !== "all" || authorFilter !== "all" || search !== ""

  return (
    <DashboardShell
      title="Comments"
      description="A unified feed of every comment posted across your tasks and projects."
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Filter className="w-3.5 h-3.5" /> Filters
          </Button>
          <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
            <MessageSquare className="w-4 h-4" /> New comment
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total comments" value={feedComments.length} hint="last 30 days" icon={MessageSquare} />
        <StatCard label="With @mentions" value={feedComments.filter(c => c.mentions && c.mentions.length > 0).length} hint="tagged teammates" icon={AtSign} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Active discussions" value={tasksWithComments.length} hint="tasks with replies" icon={MessageCircle} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Your replies" value={feedComments.filter(c => c.authorId === "u1").length} hint="across all tasks" icon={Reply} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      {/* Filters */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search comments…"
              className="h-9 pl-8 text-xs"
            />
          </div>
          <Select value={projectFilter} onValueChange={setProjectFilter}>
            <SelectTrigger className="h-9 text-xs">
              <SelectValue placeholder="All projects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All projects</SelectItem>
              {projects.map(p => (
                <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={taskFilter} onValueChange={setTaskFilter}>
            <SelectTrigger className="h-9 text-xs">
              <SelectValue placeholder="All tasks" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All tasks</SelectItem>
              {tasksWithComments.map(t => (
                <SelectItem key={t.id} value={t.id}>{t.key} — {t.title.slice(0, 28)}{t.title.length > 28 && "…"}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={authorFilter} onValueChange={setAuthorFilter}>
            <SelectTrigger className="h-9 text-xs">
              <SelectValue placeholder="All authors" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All authors</SelectItem>
              {authors.map(a => (
                <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {hasActiveFilters && (
          <div className="mt-2 flex items-center justify-between">
            <p className="text-[11px] text-muted-foreground">
              Showing {filtered.length} of {feedComments.length} comments
            </p>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs"
              onClick={() => { setSearch(""); setProjectFilter("all"); setTaskFilter("all"); setAuthorFilter("all") }}
            >
              Clear filters
            </Button>
          </div>
        )}
      </Card>

      {/* Comment feed */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={MessageSquare}
          title="No comments found"
          description="Try adjusting your filters or search query to find the comment you're looking for."
          action={{ label: "Clear filters", onClick: () => { setSearch(""); setProjectFilter("all"); setTaskFilter("all"); setAuthorFilter("all") } }}
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((c, idx) => (
            <Card
              key={c.id}
              className="p-4 md:p-5 card-lift animate-slide-in-up"
              style={{ animationDelay: `${idx * 30}ms` }}
            >
              <div className="flex items-start gap-3">
                <Avatar className="w-9 h-9 ring-2 ring-card">
                  <AvatarImage src={c.authorAvatar} alt={c.authorName} />
                  <AvatarFallback className="text-xs">{initials(c.authorName)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  {/* Header */}
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-sm font-semibold text-foreground">{c.authorName}</span>
                    {c.authorId === currentMember.id && (
                      <Badge variant="outline" className="text-[9px] h-4 px-1 py-0 bg-primary/10 text-primary border-primary/20">You</Badge>
                    )}
                    <span className="text-[11px] text-muted-foreground">commented on</span>
                    <Link
                      href={`/tasks/${c.taskId}`}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-primary hover:underline"
                    >
                      <Link2 className="w-3 h-3" />
                      <span className="font-mono">{c.taskKey}</span>
                      <span className="text-muted-foreground font-normal">— {c.taskTitle}</span>
                    </Link>
                  </div>

                  {/* Project chip */}
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className={cn("w-1.5 h-1.5 rounded-full", c.projectColor)} />
                    <span className="text-[10px] text-muted-foreground">{c.projectName}</span>
                    <span className="text-[10px] text-muted-foreground">·</span>
                    <span className="text-[10px] text-muted-foreground">{timeAgo(c.createdAt)}</span>
                  </div>

                  {/* Body */}
                  <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">
                    {highlightMentions(c.body)}
                  </p>

                  {/* Footer actions */}
                  <div className="flex items-center gap-1 mt-3 -ml-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground"
                      onClick={() => setReplyDraft(replyDraft === c.id ? null : c.id)}
                    >
                      <Reply className="w-3 h-3" /> Reply
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground">
                      <AtSign className="w-3 h-3" /> Mention
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground">
                      <Link2 className="w-3 h-3" /> Copy link
                    </Button>
                    {c.replies && c.replies > 0 && (
                      <Badge variant="secondary" className="text-[10px] h-5 px-1.5 ml-1">
                        <MessageCircle className="w-2.5 h-2.5 mr-1" /> {c.replies} {c.replies === 1 ? "reply" : "replies"}
                      </Badge>
                    )}
                    <span className="ml-auto text-[10px] text-muted-foreground hidden sm:block">
                      {formatDate(c.createdAt, { month: "short", day: "numeric", year: "numeric" })}
                    </span>
                  </div>

                  {/* Reply box */}
                  {replyDraft === c.id && (
                    <div className="mt-3 p-3 rounded-lg border border-border bg-secondary/30 animate-fade-in">
                      <div className="flex items-start gap-2">
                        <Avatar className="w-7 h-7">
                          <AvatarImage src={currentMember.avatar} alt={currentMember.name} />
                          <AvatarFallback className="text-[10px]">{initials(currentMember.name)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <Textarea
                            value={replyText}
                            onChange={e => setReplyText(e.target.value)}
                            placeholder={`Reply to ${c.authorName}…`}
                            rows={2}
                            autoFocus
                            className="text-xs resize-none bg-card"
                          />
                          <div className="flex items-center justify-between mt-2">
                            <p className="text-[10px] text-muted-foreground">Markdown supported · @mention teammates</p>
                            <div className="flex gap-1.5">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 text-xs"
                                onClick={() => { setReplyDraft(null); setReplyText("") }}
                              >
                                Cancel
                              </Button>
                              <Button
                                size="sm"
                                className="h-7 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
                                onClick={() => handleSendReply(c.id, c.taskKey)}
                                disabled={!replyText.trim()}
                              >
                                <Send className="w-3 h-3" /> Reply
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Load more */}
      {filtered.length > 0 && (
        <div className="mt-6 text-center">
          <Button variant="outline" size="sm" className="gap-1.5 bg-transparent">
            Load more comments <ChevronDown className="w-3.5 h-3.5" />
          </Button>
          <p className="text-[10px] text-muted-foreground mt-2 flex items-center justify-center gap-1">
            <Sparkles className="w-3 h-3" /> Showing {filtered.length} of {feedComments.length} comments
          </p>
        </div>
      )}
    </DashboardShell>
  )
}

// ============================================================
// HELPERS
// ============================================================

function highlightMentions(text: string): React.ReactNode {
  const parts = text.split(/(@\w+)/g)
  return parts.map((part, i) => {
    if (part.startsWith("@")) {
      return (
        <span key={i} className="inline-flex items-center gap-0.5 px-1 py-0 mx-0.5 rounded bg-primary/10 text-primary font-medium">
          <AtSign className="w-2.5 h-2.5 inline" />
          {part.slice(1)}
        </span>
      )
    }
    return <span key={i}>{part}</span>
  })
}
