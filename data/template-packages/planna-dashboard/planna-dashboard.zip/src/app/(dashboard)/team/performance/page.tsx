"use client"

import { useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaBarChart, Sparkline } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Trophy, Medal, Award, Crown, Clock, Target, TrendingUp, Star,
  Sparkles, ArrowUpRight,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn } from "@/lib/utils"
import { TeamViewNav, AvatarWithStatus } from "../_lib"

// Deterministic derived performance metrics per member.
function computePerf(m: (typeof members)[number]) {
  const completed = m.completedTasks
  // on-time %: higher for higher roles and lower load
  const load = m.utilized / m.capacity
  const baseOnTime = 100 - Math.round(load * 18) // overloaded → lower on-time
  const roleBoost = m.role === "owner" || m.role === "admin" ? 5 : m.role === "manager" ? 3 : 0
  const onTime = Math.max(60, Math.min(99, baseOnTime + roleBoost))
  // avg close time (days): lower for more experienced
  const avgClose = Math.max(0.8, 4.2 - (completed / 200) - (m.role === "manager" || m.role === "admin" ? 0.6 : 0)).toFixed(1)
  // sprint contribution (% of team's completed)
  const sprintContrib = Math.round((completed / members.reduce((s, x) => s + x.completedTasks, 0)) * 100)
  // sparkline trend (last 8 weeks, derived deterministically)
  const seed = m.id.charCodeAt(1) + m.id.charCodeAt(2)
  const trend = Array.from({ length: 8 }).map((_, i) => Math.max(2, Math.round((completed / 30) + Math.sin(i + seed) * 3 + i * 0.5)))
  return { completed, onTime, avgClose, sprintContrib, trend }
}

const medalConfig = [
  { icon: Crown,  color: "text-amber-500",   bg: "bg-amber-500/15",   ring: "ring-amber-500/40",   label: "1st" },
  { icon: Medal,  color: "text-zinc-400",    bg: "bg-zinc-400/15",    ring: "ring-zinc-400/40",    label: "2nd" },
  { icon: Award,  color: "text-orange-600",  bg: "bg-orange-500/15",  ring: "ring-orange-500/40",  label: "3rd" },
]

export default function PerformancePage() {
  const ranked = useMemo(() =>
    members
      .map(m => ({ member: m, perf: computePerf(m) }))
      .sort((a, b) => b.perf.completed - a.perf.completed)
  , [])

  const topPerformer = ranked[0]
  const podium = ranked.slice(0, 3)

  const totalCompleted = ranked.reduce((s, r) => s + r.perf.completed, 0)
  const avgOnTime = Math.round(ranked.reduce((s, r) => s + r.perf.onTime, 0) / ranked.length)
  const avgClose = (ranked.reduce((s, r) => s + parseFloat(r.perf.avgClose), 0) / ranked.length).toFixed(1)
  const topContrib = topPerformer.perf.sprintContrib

  const chartData = ranked.slice(0, 10).map(r => ({
    name: r.member.name.split(" ")[0],
    fullName: r.member.name,
    completed: r.perf.completed,
    onTime: r.perf.onTime,
  }))

  return (
    <DashboardShell
      title="Performance"
      description="Leaderboard, throughput, and quality metrics across the team."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
          <Link href="/team/workload">Workload <ArrowUpRight className="w-3.5 h-3.5" /></Link>
        </Button>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team/performance" />
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Completed" value={totalCompleted} hint="all time" icon={Trophy} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" trend={{ value: 12, positive: true }} />
        <StatCard label="Avg On-Time" value={`${avgOnTime}%`} hint="delivery rate" icon={Target} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" trend={{ value: 3, positive: true }} />
        <StatCard label="Avg Close Time" value={`${avgClose}d`} hint="per task" icon={Clock} iconColor="bg-sky-500/15 text-sky-600 dark:text-sky-400" trend={{ value: 8, positive: false }} />
        <StatCard label="Top Contributor" value={`${topContrib}%`} hint={topPerformer.member.name.split(" ")[0] + " of sprint"} icon={Sparkles} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Top performer highlight */}
      <Card className="relative overflow-hidden p-5 md:p-6 mb-4 card-lift">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 via-primary/5 to-transparent" />
        <div className="relative flex flex-col md:flex-row md:items-center gap-5">
          <div className="flex items-center gap-4">
            <div className="relative">
              <AvatarWithStatus member={topPerformer.member} size={72} />
              <div className={cn("absolute -top-2 -right-2 w-8 h-8 rounded-full flex items-center justify-center ring-4 ring-card", medalConfig[0].bg)}>
                <Crown className={cn("w-4 h-4", medalConfig[0].color)} />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 flex items-center gap-1">
                  <Trophy className="w-3 h-3" /> Top Performer
                </span>
              </div>
              <h2 className="text-xl font-bold text-foreground">{topPerformer.member.name}</h2>
              <p className="text-xs text-muted-foreground">{topPerformer.member.title} · {topPerformer.member.department}</p>
            </div>
          </div>
          <div className="flex-1 grid grid-cols-3 gap-3 md:gap-4">
            <div className="text-center p-3 rounded-lg bg-card/60 backdrop-blur border border-border">
              <p className="text-2xl font-bold text-foreground">{topPerformer.perf.completed}</p>
              <p className="text-[10px] text-muted-foreground">Tasks completed</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-card/60 backdrop-blur border border-border">
              <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{topPerformer.perf.onTime}%</p>
              <p className="text-[10px] text-muted-foreground">On-time delivery</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-card/60 backdrop-blur border border-border">
              <p className="text-2xl font-bold text-foreground">{topPerformer.perf.avgClose}d</p>
              <p className="text-[10px] text-muted-foreground">Avg close time</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Podium + chart */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-3 md:gap-4 mb-4">
        {/* Podium */}
        <Card className="p-4 md:p-5 card-lift lg:col-span-2">
          <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-500" /> Podium
          </h3>
          <div className="space-y-3">
            {podium.map((r, i) => {
              const medal = medalConfig[i]
              return (
                <Link
                  key={r.member.id}
                  href={`/team/${r.member.id}`}
                  className={cn(
                    "flex items-center gap-3 p-3 rounded-xl border transition-all duration-300 hover:-translate-y-0.5 hover:shadow-md group",
                    i === 0 ? "bg-amber-500/5 border-amber-500/30" : "bg-card border-border hover:border-primary/30"
                  )}
                >
                  <div className={cn("w-10 h-10 rounded-full flex items-center justify-center ring-2", medal.bg, medal.ring)}>
                    <medal.icon className={cn("w-5 h-5", medal.color)} />
                  </div>
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={r.member.avatar} alt={r.member.name} />
                    <AvatarFallback className="text-xs">{r.member.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors truncate">{r.member.name}</p>
                    <p className="text-[11px] text-muted-foreground truncate">{r.member.title}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-foreground">{r.perf.completed}</p>
                    <p className="text-[10px] text-muted-foreground">completed</p>
                  </div>
                </Link>
              )
            })}
          </div>
        </Card>

        {/* Chart */}
        <ChartCard
          title="Tasks completed by member"
          subtitle="Top 10 performers — all-time completed tasks"
          className="lg:col-span-3"
        >
          <PlannaBarChart
            data={chartData}
            xKey="name"
            series={[
              { key: "completed", name: "Completed", color: "var(--chart-1)" },
            ]}
            height={300}
            showLegend={false}
          />
        </ChartCard>
      </div>

      {/* Leaderboard table */}
      <Card className="p-2 md:p-3 card-lift overflow-hidden">
        <div className="px-2 py-2 mb-1 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold">Leaderboard</h3>
            <p className="text-[11px] text-muted-foreground">All members ranked by completed tasks</p>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground border-b border-border">
                <th className="px-3 py-2 font-medium text-center w-12">#</th>
                <th className="px-3 py-2 font-medium">Member</th>
                <th className="px-3 py-2 font-medium text-center">Completed</th>
                <th className="px-3 py-2 font-medium text-center hidden sm:table-cell">Active</th>
                <th className="px-3 py-2 font-medium text-center hidden md:table-cell">On-Time</th>
                <th className="px-3 py-2 font-medium text-center hidden lg:table-cell">Avg Close</th>
                <th className="px-3 py-2 font-medium text-center hidden md:table-cell">Sprint</th>
                <th className="px-3 py-2 font-medium hidden xl:table-cell min-w-[120px]">8-week trend</th>
              </tr>
            </thead>
            <tbody>
              {ranked.map((r, i) => {
                const medal = medalConfig[i]
                return (
                <tr
                  key={r.member.id}
                  className={cn(
                    "border-b border-border last:border-0 hover:bg-secondary/40 transition-colors animate-fade-in",
                    i < 3 && "bg-muted/20"
                  )}
                  style={{ animationDelay: `${Math.min(i, 12) * 25}ms` }}
                >
                  <td className="px-3 py-2.5 text-center">
                    {i < 3 ? (
                      <span className={cn("inline-flex w-7 h-7 rounded-full items-center justify-center", medal.bg)}>
                        <medal.icon className={cn("w-3.5 h-3.5", medal.color)} />
                      </span>
                    ) : (
                      <span className="text-xs font-mono text-muted-foreground">{i + 1}</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5">
                    <Link href={`/team/${r.member.id}`} className="flex items-center gap-2.5 group">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={r.member.avatar} alt={r.member.name} />
                        <AvatarFallback className="text-[10px]">{r.member.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors truncate flex items-center gap-1.5">
                          {r.member.name}
                          {i === 0 && <Star className="w-3 h-3 fill-amber-500 text-amber-500" />}
                        </p>
                        <p className="text-[11px] text-muted-foreground truncate">{r.member.department}</p>
                      </div>
                    </Link>
                  </td>
                  <td className="px-3 py-2.5 text-center">
                    <span className="text-sm font-bold text-foreground">{r.perf.completed}</span>
                  </td>
                  <td className="px-3 py-2.5 text-center hidden sm:table-cell">
                    <span className="text-xs text-muted-foreground">{r.member.activeTasks}</span>
                  </td>
                  <td className="px-3 py-2.5 text-center hidden md:table-cell">
                    <span className={cn(
                      "inline-flex items-center gap-1 text-xs font-semibold",
                      r.perf.onTime >= 90 ? "text-emerald-600 dark:text-emerald-400"
                        : r.perf.onTime >= 80 ? "text-amber-600 dark:text-amber-400"
                        : "text-rose-600 dark:text-rose-400"
                    )}>
                      {r.perf.onTime}%
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-center hidden lg:table-cell">
                    <span className="text-xs text-muted-foreground">{r.perf.avgClose}d</span>
                  </td>
                  <td className="px-3 py-2.5 text-center hidden md:table-cell">
                    <span className="text-xs font-semibold text-primary">{r.perf.sprintContrib}%</span>
                  </td>
                  <td className="px-3 py-2.5 hidden xl:table-cell">
                    <div className="w-full h-8">
                      <Sparkline data={r.perf.trend} color={i < 3 ? "var(--chart-1)" : "var(--chart-4)"} height={32} />
                    </div>
                  </td>
                </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </DashboardShell>
  )
}
