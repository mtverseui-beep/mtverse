"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Lock, ShieldCheck, Grid3x3, RotateCcw, Save, Info, ArrowRight,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn } from "@/lib/utils"
import {
  TeamViewNav, rolesList, roleMeta, permissionMeta, nextPerm,
  type Permission,
} from "../_lib"

// Resources (rows of the matrix)
const resources = [
  { key: "projects", label: "Projects", description: "Create, edit, archive projects" },
  { key: "tasks", label: "Tasks", description: "Create, assign, complete tasks" },
  { key: "files", label: "Files", description: "Upload, share, delete files" },
  { key: "team", label: "Team", description: "Invite, remove, change roles" },
  { key: "billing", label: "Billing", description: "Plan, invoices, payment methods" },
  { key: "settings", label: "Settings", description: "Workspace configuration" },
] as const

// Default permission matrix (resource × role). UI-only — editable via click cycle.
const defaultMatrix: Record<string, Record<string, Permission>> = {
  projects: { owner: 3, admin: 3, manager: 2, member: 2, viewer: 1, guest: 0 },
  tasks: { owner: 3, admin: 3, manager: 3, member: 2, viewer: 1, guest: 1 },
  files: { owner: 3, admin: 3, manager: 2, member: 2, viewer: 1, guest: 0 },
  team: { owner: 3, admin: 3, manager: 1, member: 0, viewer: 0, guest: 0 },
  billing: { owner: 3, admin: 3, manager: 0, member: 0, viewer: 0, guest: 0 },
  settings: { owner: 3, admin: 3, manager: 1, member: 0, viewer: 0, guest: 0 },
}

export default function PermissionsPage() {
  const [matrix, setMatrix] = useState(() =>
    JSON.parse(JSON.stringify(defaultMatrix)) as typeof defaultMatrix
  )

  const cycle = (resource: string, role: string) => {
    setMatrix(prev => {
      const next = { ...prev }
      next[resource] = { ...next[resource], [role]: nextPerm(next[resource][role]) }
      return next
    })
  }

  const reset = () => setMatrix(JSON.parse(JSON.stringify(defaultMatrix)))

  // Counts for stat cards
  const allCells = resources.flatMap(r => rolesList.map(role => matrix[r.key][role]))
  const adminCount = allCells.filter(p => p === 3).length
  const editCount = allCells.filter(p => p === 2).length
  const viewCount = allCells.filter(p => p === 1).length
  const noneCount = allCells.filter(p => p === 0).length
  const totalCells = allCells.length

  return (
    <DashboardShell
      title="Permissions"
      description="Fine-grained access control matrix — what each role can do with each resource."
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent" onClick={reset}>
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Save className="w-4 h-4" /> Save changes
          </Button>
        </>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team/permissions" />
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Admin Grants" value={adminCount} hint={`of ${totalCells} cells`} icon={ShieldCheck} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Edit Grants" value={editCount} hint={`of ${totalCells} cells`} icon={Grid3x3} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="View Grants" value={viewCount} hint={`of ${totalCells} cells`} icon={Grid3x3} iconColor="bg-sky-500/15 text-sky-600 dark:text-sky-400" />
        <StatCard label="No Access" value={noneCount} hint={`of ${totalCells} cells`} icon={Lock} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Legend */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground shrink-0">
            <Info className="w-3.5 h-3.5" />
            Click any cell to cycle through:
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {([0, 1, 2, 3] as Permission[]).map(p => {
              const m = permissionMeta[p]
              return (
                <span key={p} className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium border", m.bg, m.border, m.color)}>
                  <span className="w-4 h-4 rounded-sm bg-current opacity-80 flex items-center justify-center text-[9px] font-bold text-card">
                    {m.short}
                  </span>
                  {m.label}
                </span>
              )
            })}
          </div>
        </div>
      </Card>

      {/* Permission matrix */}
      <Card className="p-2 md:p-3 card-lift overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left text-[11px] uppercase tracking-wide text-muted-foreground px-3 py-3 font-medium min-w-[200px]">
                  Resource
                </th>
                {rolesList.map(role => {
                  const meta = roleMeta[role]
                  return (
                    <th key={role} className="px-2 py-3 text-center min-w-[90px]">
                      <div className="flex flex-col items-center gap-1">
                        <span className={cn("w-8 h-8 rounded-lg flex items-center justify-center mx-auto", meta.color)}>
                          <meta.icon className="w-4 h-4" />
                        </span>
                        <span className="text-[11px] font-medium text-foreground">{meta.label}</span>
                        <span className="text-[9px] font-mono text-muted-foreground">L{meta.level}</span>
                      </div>
                    </th>
                  )
                })}
              </tr>
            </thead>
            <tbody>
              {resources.map((r, rowIdx) => (
                <tr
                  key={r.key}
                  className={cn("border-b border-border last:border-0 hover:bg-secondary/30 transition-colors", rowIdx % 2 === 1 && "bg-muted/20")}
                >
                  <td className="px-3 py-3">
                    <div>
                      <p className="text-sm font-medium text-foreground">{r.label}</p>
                      <p className="text-[11px] text-muted-foreground">{r.description}</p>
                    </div>
                  </td>
                  {rolesList.map(role => {
                    const p = matrix[r.key][role]
                    const m = permissionMeta[p]
                    const rMeta = roleMeta[role]
                    return (
                      <td key={role} className="px-2 py-3 text-center">
                        <button
                          onClick={() => cycle(r.key, role)}
                          className={cn(
                            "inline-flex flex-col items-center justify-center w-14 h-14 rounded-lg border-2 transition-all duration-200 hover:scale-105 hover:shadow-md cursor-pointer group",
                            m.bg, m.border, m.color
                          )}
                          title={`${r.label} · ${rMeta.label} · ${m.label}`}
                          aria-label={`${r.label} for ${rMeta.label}: ${m.label}. Click to change.`}
                        >
                          <span className="text-base font-bold leading-none">{m.short}</span>
                          <span className="text-[9px] font-medium mt-0.5 opacity-80">{m.label}</span>
                        </button>
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Footer note */}
      <Card className="p-4 md:p-5 mt-4 border-dashed">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
            <Info className="w-4 h-4" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground mb-1">About workspace permissions</p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              This matrix controls what each role can do with each resource type. Owners always have full access and cannot be restricted.
              Changes are previewed here only — click <span className="font-medium text-foreground">Save changes</span> to apply them across the workspace.
              Permission changes are logged in the audit trail and visible to all admins.
            </p>
            <div className="flex items-center gap-2 mt-3">
              <Button asChild variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent">
                <Link href="/team/roles">View roles <ArrowRight className="w-3 h-3" /></Link>
              </Button>
              <Button asChild variant="ghost" size="sm" className="h-8 text-xs">
                <Link href="/team">Back to team</Link>
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </DashboardShell>
  )
}
