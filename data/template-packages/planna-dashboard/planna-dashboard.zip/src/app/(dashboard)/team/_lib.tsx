"use client"

import Link from "next/link"
import { cn } from "@/lib/utils"
import {
  Cpu, Palette, Package, Megaphone, ShieldCheck, Headphones, Crown, Users,
  User, Eye, UserCheck,
} from "lucide-react"
import type { LucideIcon } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { TeamMember } from "@/types"

// ============================================================
// DEPARTMENT CONFIG
// ============================================================

export const departmentConfig: Record<string, { icon: LucideIcon; color: string; chip: string; ring: string; gradient: string }> = {
  Engineering: { icon: Cpu, color: "bg-emerald-500", chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", ring: "ring-emerald-500/30", gradient: "from-emerald-500/10 to-transparent" },
  Design: { icon: Palette, color: "bg-lime-500", chip: "bg-lime-500/15 text-lime-600 dark:text-lime-400", ring: "ring-lime-500/30", gradient: "from-lime-500/10 to-transparent" },
  Product: { icon: Package, color: "bg-teal-500", chip: "bg-teal-500/15 text-teal-600 dark:text-teal-400", ring: "ring-teal-500/30", gradient: "from-teal-500/10 to-transparent" },
  Marketing: { icon: Megaphone, color: "bg-cyan-500", chip: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400", ring: "ring-cyan-500/30", gradient: "from-cyan-500/10 to-transparent" },
  Quality: { icon: ShieldCheck, color: "bg-amber-500", chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400", ring: "ring-amber-500/30", gradient: "from-amber-500/10 to-transparent" },
  Support: { icon: Headphones, color: "bg-rose-500", chip: "bg-rose-500/15 text-rose-600 dark:text-rose-400", ring: "ring-rose-500/30", gradient: "from-rose-500/10 to-transparent" },
  Leadership: { icon: Crown, color: "bg-violet-500", chip: "bg-violet-500/15 text-violet-600 dark:text-violet-400", ring: "ring-violet-500/30", gradient: "from-violet-500/10 to-transparent" },
}

export function getDepartmentConfig(dept: string) {
  return departmentConfig[dept] ?? {
    icon: Users,
    color: "bg-muted-foreground",
    chip: "bg-muted text-muted-foreground",
    ring: "ring-border",
    gradient: "from-muted/10 to-transparent",
  }
}

// ============================================================
// ROLE CONFIG
// ============================================================

export const rolesList = ["owner", "admin", "manager", "member", "viewer", "guest"] as const

export const roleMeta: Record<string, { label: string; description: string; color: string; level: number; icon: LucideIcon }> = {
  owner: { label: "Owner", description: "Full control including billing and workspace deletion.", color: "bg-violet-500/15 text-violet-600 dark:text-violet-400", level: 5, icon: Crown },
  admin: { label: "Admin", description: "Manage members, projects, and workspace settings.", color: "bg-rose-500/15 text-rose-600 dark:text-rose-400", level: 4, icon: ShieldCheck },
  manager: { label: "Manager", description: "Manage projects, assign tasks, and view reports.", color: "bg-amber-500/15 text-amber-600 dark:text-amber-400", level: 3, icon: Users },
  member: { label: "Member", description: "Create and complete tasks, collaborate with the team.", color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", level: 2, icon: User },
  viewer: { label: "Viewer", description: "Read-only access to projects and dashboards.", color: "bg-sky-500/15 text-sky-600 dark:text-sky-400", level: 1, icon: Eye },
  guest: { label: "Guest", description: "Limited, time-boxed access to specific items.", color: "bg-muted text-muted-foreground", level: 0, icon: UserCheck },
}

// ============================================================
// PERMISSION MODEL (UI only)
// ============================================================

export type Permission = 0 | 1 | 2 | 3 // none | view | edit | admin

export const permissionMeta: Record<Permission, { label: string; short: string; color: string; bg: string; border: string }> = {
  0: { label: "No access", short: "—", color: "text-muted-foreground", bg: "bg-muted/50 hover:bg-muted", border: "border-border" },
  1: { label: "View", short: "V", color: "text-sky-600 dark:text-sky-400", bg: "bg-sky-500/15 hover:bg-sky-500/25", border: "border-sky-500/30" },
  2: { label: "Edit", short: "E", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-500/15 hover:bg-amber-500/25", border: "border-amber-500/30" },
  3: { label: "Admin", short: "A", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-500/15 hover:bg-emerald-500/25", border: "border-emerald-500/30" },
}

export function nextPerm(p: Permission): Permission {
  return (((p + 1) % 4) as Permission)
}

// ============================================================
// UTILIZATION HELPERS
// ============================================================

export function utilizationMeta(utilPct: number): { label: string; color: string; track: string; chip: string; dot: string } {
  if (utilPct >= 95) return { label: "Overloaded", color: "bg-rose-500", track: "bg-rose-500/15", chip: "bg-rose-500/15 text-rose-600 dark:text-rose-400", dot: "bg-rose-500" }
  if (utilPct >= 80) return { label: "High", color: "bg-amber-500", track: "bg-amber-500/15", chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400", dot: "bg-amber-500" }
  if (utilPct >= 60) return { label: "Optimal", color: "bg-emerald-500", track: "bg-emerald-500/15", chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" }
  if (utilPct >= 40) return { label: "Balanced", color: "bg-teal-500", track: "bg-teal-500/15", chip: "bg-teal-500/15 text-teal-600 dark:text-teal-400", dot: "bg-teal-500" }
  return { label: "Under", color: "bg-zinc-400", track: "bg-muted", chip: "bg-muted text-muted-foreground", dot: "bg-zinc-400" }
}

export function workloadBucket(utilPct: number): "over" | "balanced" | "under" {
  if (utilPct >= 95) return "over"
  if (utilPct >= 60) return "balanced"
  return "under"
}

// ============================================================
// TIMEZONE / DATE HELPERS
// ============================================================

export function formatTzOffset(tz: string): string {
  try {
    const now = new Date()
    const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, timeZoneName: "shortOffset" })
    const parts = fmt.formatToParts(now)
    const tzPart = parts.find(p => p.type === "timeZoneName")
    return tzPart?.value ?? tz
  } catch {
    return tz
  }
}

export function formatTzLocalTime(tz: string): string {
  try {
    return new Intl.DateTimeFormat("en-US", {
      timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false,
    }).format(new Date())
  } catch {
    return "--:--"
  }
}

export function relativeDateGroup(dateStr: string): string {
  const d = new Date(dateStr)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const target = new Date(d)
  target.setHours(0, 0, 0, 0)
  const diff = Math.floor((today.getTime() - target.getTime()) / 86400000)
  if (diff === 0) return "Today"
  if (diff === 1) return "Yesterday"
  if (diff > 1 && diff < 7) return d.toLocaleDateString("en-US", { weekday: "long" })
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
}

// ============================================================
// AVATAR WITH STATUS
// ============================================================

export function AvatarWithStatus({ member, size = 40, className }: { member: TeamMember; size?: number; className?: string }) {
  return (
    <div className={cn("relative inline-block shrink-0", className)} style={{ width: size, height: size }}>
      <Avatar className="ring-2 ring-card" style={{ width: size, height: size }}>
        <AvatarImage src={member.avatar} alt={member.name} />
        <AvatarFallback className="text-xs">{member.name.split(" ").map(w => w[0]).slice(0, 2).join("")}</AvatarFallback>
      </Avatar>
      <span
        className={cn(
          "absolute -bottom-0.5 -right-0.5 rounded-full ring-2 ring-card",
          member.online ? "bg-emerald-500" : "bg-zinc-300 dark:bg-zinc-600"
        )}
        style={{ width: Math.max(8, size * 0.28), height: Math.max(8, size * 0.28) }}
      />
    </div>
  )
}

// ============================================================
// TEAM VIEW NAV (shared segmented control)
// ============================================================

const teamNavItems = [
  { href: "/team", label: "Members" },
  { href: "/team/departments", label: "Departments" },
  { href: "/team/roles", label: "Roles" },
  { href: "/team/permissions", label: "Permissions" },
  { href: "/team/workload", label: "Workload" },
  { href: "/team/availability", label: "Availability" },
  { href: "/team/activity", label: "Activity" },
  { href: "/team/performance", label: "Performance" },
  { href: "/team/invite", label: "Invite" },
]

export function TeamViewNav({ active }: { active: string }) {
  return (
    <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-1 -mx-1 px-1">
      {teamNavItems.map(item => {
        const isActive = item.href === active
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap",
              isActive
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary"
            )}
          >
            {item.label}
          </Link>
        )
      })}
    </div>
  )
}
