"use client"

import { use, useState } from "react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { RoleBadge, PriorityBadge, TaskStatusBadge } from "@/components/common/badges"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft, Mail, MessageSquare, MoreHorizontal, MapPin, Clock, CalendarDays,
  CheckCircle2, Zap, Gauge, Briefcase, FileText, Paperclip, Star, Pencil,
  Activity as ActivityIcon, ListTodo, Download,
} from "lucide-react"
import { members, tasks, activities, files } from "@/lib/data/mock"
import { cn, timeAgo, formatDate, relativeDay } from "@/lib/utils"
import {
  TeamViewNav, getDepartmentConfig, utilizationMeta, formatTzOffset, formatTzLocalTime,
  AvatarWithStatus, relativeDateGroup,
} from "../_lib"
import type { FileItem } from "@/types"

// Skill matrix — derived from member role + department (deterministic, no persistence)
const skillMatrixByDept: Record<string, { skill: string; level: number }[]> = {
  Engineering: [
    { skill: "System Design", level: 88 }, { skill: "Code Quality", level: 92 },
    { skill: "Code Review", level: 80 }, { skill: "Testing", level: 75 },
    { skill: "DevOps", level: 70 }, { skill: "Mentoring", level: 65 },
  ],
  Design: [
    { skill: "Visual Design", level: 92 }, { skill: "UX Research", level: 78 },
    { skill: "Prototyping", level: 85 }, { skill: "Design Systems", level: 88 },
    { skill: "Accessibility", level: 80 }, { skill: "Motion", level: 70 },
  ],
  Product: [
    { skill: "Discovery", level: 88 }, { skill: "Roadmapping", level: 90 },
    { skill: "Stakeholder Mgmt", level: 85 }, { skill: "Analytics", level: 75 },
    { skill: "Spec Writing", level: 82 }, { skill: "User Interviews", level: 80 },
  ],
  Marketing: [
    { skill: "Copywriting", level: 85 }, { skill: "SEO", level: 72 },
    { skill: "Campaigns", level: 80 }, { skill: "Analytics", level: 78 },
    { skill: "Brand", level: 82 }, { skill: "Social", level: 75 },
  ],
  Quality: [
    { skill: "Test Automation", level: 90 }, { skill: "Manual QA", level: 85 },
    { skill: "Bug Triage", level: 88 }, { skill: "Performance", level: 72 },
    { skill: "Security", level: 70 }, { skill: "Process", level: 80 },
  ],
  Support: [
    { skill: "Customer Empathy", level: 92 }, { skill: "Troubleshooting", level: 85 },
    { skill: "Product Knowledge", level: 88 }, { skill: "Writing", level: 80 },
    { skill: "Onboarding", level: 82 }, { skill: "Escalations", level: 78 },
  ],
  Leadership: [
    { skill: "Strategy", level: 95 }, { skill: "Hiring", level: 88 },
    { skill: "Fundraising", level: 80 }, { skill: "Communication", level: 92 },
    { skill: "Vision", level: 90 }, { skill: "Operations", level: 82 },
  ],
}

function fileIcon(type: FileItem["type"]) {
  switch (type) {
    case "pdf": return { icon: FileText, color: "bg-rose-500/15 text-rose-600 dark:text-rose-400" }
    case "document": return { icon: FileText, color: "bg-sky-500/15 text-sky-600 dark:text-sky-400" }
    case "spreadsheet": return { icon: FileText, color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" }
    case "presentation": return { icon: FileText, color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" }
    case "image": return { icon: FileText, color: "bg-violet-500/15 text-violet-600 dark:text-violet-400" }
    case "video": return { icon: FileText, color: "bg-pink-500/15 text-pink-600 dark:text-pink-400" }
    case "code": return { icon: FileText, color: "bg-teal-500/15 text-teal-600 dark:text-teal-400" }
    default: return { icon: FileText, color: "bg-muted text-muted-foreground" }
  }
}

export default function MemberDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const member = members.find(m => m.id === id)
  const [activeTab, setActiveTab] = useState("overview")

  if (!member) notFound()

  const utilPct = Math.round((member.utilized / member.capacity) * 100)
  const utilMeta = utilizationMeta(utilPct)
  const deptCfg = getDepartmentConfig(member.department)

  // Member-specific data
  const memberTasks = tasks.filter(t => t.assignee === member.name)
  const memberActivities = activities.filter(a => a.actor === member.name)
  const memberFiles = files.filter(f => f.owner === member.name)
  const skills = skillMatrixByDept[member.department] ?? skillMatrixByDept.Engineering
  const avgSkill = Math.round(skills.reduce((s, k) => s + k.level, 0) / skills.length)

  const tenureDays = Math.floor((Date.now() - new Date(member.joinedAt).getTime()) / 86400000)
  const tenureLabel = tenureDays > 365 ? `${Math.floor(tenureDays / 365)}y ${Math.floor((tenureDays % 365) / 30)}m` : `${Math.floor(tenureDays / 30)}m`

  return (
    <DashboardShell
      title={member.name}
      description={`${member.title} · ${member.department}`}
      breadcrumbs={[{ label: "Team", href: "/team" }, { label: member.name }]}
      actions={
        <>
          <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Link href="/team"><ArrowLeft className="w-4 h-4" /> Back</Link>
          </Button>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Mail className="w-4 h-4" /> Email
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <MessageSquare className="w-4 h-4" /> Message
          </Button>
        </>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team" />
      </Card>

      {/* Profile header */}
      <Card className={cn("relative overflow-hidden p-4 md:p-6 mb-4 card-lift")}>
        <div className={cn("absolute inset-0 bg-gradient-to-br opacity-60", deptCfg.gradient)} />
        <div className="relative flex flex-col md:flex-row md:items-start gap-4 md:gap-6">
          <AvatarWithStatus member={member} size={84} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h1 className="text-xl md:text-2xl font-bold text-foreground">{member.name}</h1>
              <RoleBadge role={member.role} />
              <span className={cn("inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full", utilMeta.chip)}>
                <span className={cn("w-1.5 h-1.5 rounded-full", utilMeta.dot)} />
                {member.online ? "Online" : "Offline"}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-3">{member.title}</p>
            <div className="flex items-center gap-x-4 gap-y-1.5 flex-wrap text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" />{member.email}</span>
              <span className="inline-flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" />{member.location}</span>
              <span className="inline-flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />{formatTzOffset(member.timezone)} · {formatTzLocalTime(member.timezone)} local</span>
              <span className="inline-flex items-center gap-1.5"><CalendarDays className="w-3.5 h-3.5" />Joined {formatDate(member.joinedAt)}</span>
            </div>
          </div>
          <div className="flex md:flex-col gap-2">
            <Button variant="outline" size="sm" className="gap-1.5 bg-transparent">
              <Pencil className="w-3.5 h-3.5" /> Edit profile
            </Button>
            <Button variant="ghost" size="icon" className="h-9 w-9">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Tasks" value={member.activeTasks} hint="in progress" icon={Zap} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Completed" value={member.completedTasks} hint="all time" icon={CheckCircle2} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Utilization" value={`${utilPct}%`} hint={`${member.utilized}/${member.capacity}h this week`} icon={Gauge} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Tenure" value={tenureLabel} hint={`since ${formatDate(member.joinedAt, { month: "short", year: "numeric" })}`} icon={Briefcase} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
          <TabsTrigger value="tasks" className="text-xs">Tasks</TabsTrigger>
          <TabsTrigger value="activity" className="text-xs">Activity</TabsTrigger>
          <TabsTrigger value="files" className="text-xs">Files</TabsTrigger>
        </TabsList>

        {/* ===================== OVERVIEW ===================== */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
            {/* Recent activity */}
            <Card className="p-4 md:p-5 card-lift">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <ActivityIcon className="w-4 h-4 text-muted-foreground" /> Recent activity
                </h3>
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setActiveTab("activity")}>
                  View all
                </Button>
              </div>
              {memberActivities.length === 0 ? (
                <p className="text-xs text-muted-foreground py-6 text-center">No recent activity.</p>
              ) : (
                <div className="space-y-3">
                  {memberActivities.slice(0, 5).map(a => (
                    <div key={a.id} className="flex items-start gap-2.5">
                      <span className="mt-1 w-1.5 h-1.5 rounded-full bg-primary/60 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] text-foreground">
                          <span className="text-muted-foreground">{a.action}</span>{" "}
                          <span className="font-medium">{a.target}</span>
                        </p>
                        <p className="text-[10px] text-muted-foreground">{timeAgo(a.createdAt)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            {/* Current tasks */}
            <Card className="p-4 md:p-5 card-lift">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <ListTodo className="w-4 h-4 text-muted-foreground" /> Current tasks
                </h3>
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setActiveTab("tasks")}>
                  View all
                </Button>
              </div>
              {memberTasks.length === 0 ? (
                <p className="text-xs text-muted-foreground py-6 text-center">No assigned tasks.</p>
              ) : (
                <div className="space-y-2.5">
                  {memberTasks.slice(0, 5).map(t => (
                    <Link
                      key={t.id}
                      href={`/tasks/${t.id}`}
                      className="block p-2.5 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/40 transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
                        <TaskStatusBadge status={t.status} />
                      </div>
                      <p className="text-xs font-medium text-foreground line-clamp-1">{t.title}</p>
                      {t.dueDate && (
                        <p className="text-[10px] text-muted-foreground mt-1">Due {relativeDay(t.dueDate)}</p>
                      )}
                    </Link>
                  ))}
                </div>
              )}
            </Card>

            {/* Skill matrix */}
            <Card className="p-4 md:p-5 card-lift">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <Star className="w-4 h-4 text-muted-foreground" /> Skill matrix
                </h3>
                <span className="text-[11px] font-semibold text-primary">{avgSkill}% avg</span>
              </div>
              <div className="space-y-2.5">
                {skills.map(s => (
                  <div key={s.skill}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] text-foreground">{s.skill}</span>
                      <span className="text-[11px] font-medium text-muted-foreground">{s.level}</span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all duration-500",
                          s.level >= 85 ? "bg-emerald-500" : s.level >= 70 ? "bg-teal-500" : "bg-amber-500"
                        )}
                        style={{ width: `${s.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Utilization + workload summary */}
          <Card className="p-4 md:p-5 card-lift">
            <h3 className="text-sm font-semibold mb-4">Weekly workload</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">Capacity vs utilized</span>
                  <span className={cn("text-xs font-semibold", utilMeta.chip.split(" ").slice(1).join(" "))}>{utilMeta.label}</span>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span className="text-muted-foreground">Utilized</span>
                      <span className="font-medium text-foreground">{member.utilized}h / {member.capacity}h</span>
                    </div>
                    <div className={cn("h-2.5 w-full rounded-full overflow-hidden", utilMeta.track)}>
                      <div className={cn("h-full rounded-full transition-all duration-700", utilMeta.color)} style={{ width: `${utilPct}%` }} />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-2">
                    <div className="rounded-lg bg-secondary/50 p-2.5 text-center">
                      <p className="text-base font-bold text-foreground">{member.activeTasks}</p>
                      <p className="text-[10px] text-muted-foreground">Active tasks</p>
                    </div>
                    <div className="rounded-lg bg-secondary/50 p-2.5 text-center">
                      <p className="text-base font-bold text-foreground">{member.completedTasks}</p>
                      <p className="text-[10px] text-muted-foreground">Completed</p>
                    </div>
                    <div className="rounded-lg bg-secondary/50 p-2.5 text-center">
                      <p className="text-base font-bold text-foreground">{Math.max(0, member.capacity - member.utilized)}h</p>
                      <p className="text-[10px] text-muted-foreground">Available</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="border-t md:border-t-0 md:border-l border-border pt-4 md:pt-0 md:pl-4">
                <p className="text-xs text-muted-foreground mb-3">Quick actions</p>
                <div className="space-y-2">
                  <Button variant="outline" size="sm" className="w-full justify-start gap-2 bg-transparent text-xs h-8">
                    <MessageSquare className="w-3.5 h-3.5" /> Send message
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start gap-2 bg-transparent text-xs h-8">
                    <ListTodo className="w-3.5 h-3.5" /> Assign task
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start gap-2 bg-transparent text-xs h-8">
                    <CalendarDays className="w-3.5 h-3.5" /> Schedule 1:1
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start gap-2 bg-transparent text-xs h-8">
                    <Pencil className="w-3.5 h-3.5" /> Edit role
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* ===================== TASKS ===================== */}
        <TabsContent value="tasks">
          <Card className="p-2 md:p-3 card-lift overflow-hidden">
            <div className="flex items-center justify-between px-2 py-2 mb-1">
              <h3 className="text-sm font-semibold">Assigned tasks ({memberTasks.length})</h3>
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent">
                <Download className="w-3.5 h-3.5" /> Export
              </Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground border-b border-border">
                    <th className="px-3 py-2 font-medium">Key</th>
                    <th className="px-3 py-2 font-medium">Title</th>
                    <th className="px-3 py-2 font-medium hidden sm:table-cell">Project</th>
                    <th className="px-3 py-2 font-medium">Status</th>
                    <th className="px-3 py-2 font-medium hidden md:table-cell">Priority</th>
                    <th className="px-3 py-2 font-medium hidden lg:table-cell">Due</th>
                  </tr>
                </thead>
                <tbody>
                  {memberTasks.length === 0 ? (
                    <tr><td colSpan={6} className="px-3 py-10 text-center text-xs text-muted-foreground">No tasks assigned.</td></tr>
                  ) : memberTasks.map(t => (
                    <tr key={t.id} className="border-b border-border last:border-0 hover:bg-secondary/40 transition-colors">
                      <td className="px-3 py-2.5">
                        <span className="text-[11px] font-mono text-muted-foreground">{t.key}</span>
                      </td>
                      <td className="px-3 py-2.5">
                        <Link href={`/tasks/${t.id}`} className="text-sm font-medium text-foreground hover:text-primary transition-colors line-clamp-1">
                          {t.title}
                        </Link>
                      </td>
                      <td className="px-3 py-2.5 hidden sm:table-cell">
                        <span className="text-xs text-muted-foreground">{t.projectName}</span>
                      </td>
                      <td className="px-3 py-2.5"><TaskStatusBadge status={t.status} /></td>
                      <td className="px-3 py-2.5 hidden md:table-cell"><PriorityBadge priority={t.priority} /></td>
                      <td className="px-3 py-2.5 hidden lg:table-cell">
                        {t.dueDate ? <span className="text-xs text-muted-foreground">{relativeDay(t.dueDate)}</span> : <span className="text-xs text-muted-foreground">—</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {/* ===================== ACTIVITY ===================== */}
        <TabsContent value="activity">
          <Card className="p-4 md:p-5 card-lift">
            <h3 className="text-sm font-semibold mb-4">Activity timeline</h3>
            {memberActivities.length === 0 ? (
              <p className="text-xs text-muted-foreground py-10 text-center">No recent activity for this member.</p>
            ) : (
              <div className="space-y-5">
                {memberActivities.reduce<{ group: string; items: typeof memberActivities }[]>((acc, a) => {
                  const g = relativeDateGroup(a.createdAt)
                  const last = acc[acc.length - 1]
                  if (last && last.group === g) last.items.push(a)
                  else acc.push({ group: g, items: [a] })
                  return acc
                }, []).map(group => (
                  <div key={group.group}>
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">{group.group}</p>
                    <div className="space-y-3">
                      {group.items.map(a => (
                        <div key={a.id} className="flex items-start gap-3">
                          <Avatar className="w-7 h-7 shrink-0">
                            <AvatarImage src={a.actorAvatar} alt={a.actor} />
                            <AvatarFallback className="text-[10px]">{a.actor[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs text-foreground">
                              <span className="font-semibold">{a.actor.split(" ")[0]}</span>{" "}
                              <span className="text-muted-foreground">{a.action}</span>{" "}
                              <span className="font-medium">{a.target}</span>
                            </p>
                            <p className="text-[10px] text-muted-foreground">{timeAgo(a.createdAt)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        {/* ===================== FILES ===================== */}
        <TabsContent value="files">
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold">Files shared by {member.name.split(" ")[0]} ({memberFiles.length})</h3>
            </div>
            {memberFiles.length === 0 ? (
              <p className="text-xs text-muted-foreground py-10 text-center">No files shared by this member.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {memberFiles.map(f => {
                  const ic = fileIcon(f.type)
                  return (
                    <div key={f.id} className="p-3 rounded-xl border border-border hover:border-primary/30 hover:shadow-md transition-all duration-300 group cursor-pointer">
                      <div className="flex items-start gap-3">
                        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0", ic.color)}>
                          <ic.icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors truncate">{f.name}</p>
                          <p className="text-[10px] text-muted-foreground mt-0.5">
                            {f.project ?? "No project"} · {formatDate(f.modifiedAt)}
                          </p>
                          <div className="flex items-center gap-2 mt-1.5">
                            {f.starred && <Star className="w-3 h-3 fill-amber-500 text-amber-500" />}
                            {f.shared && <span className="text-[9px] px-1.5 py-0.5 rounded bg-secondary text-muted-foreground">Shared</span>}
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}
