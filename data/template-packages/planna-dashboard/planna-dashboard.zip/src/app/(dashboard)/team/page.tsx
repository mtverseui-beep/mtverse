"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { RoleBadge } from "@/components/common/badges"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import {
  Users, UserPlus, Search, LayoutGrid, List, MapPin, Mail,
  CheckCircle2, Zap, Clock, MoreHorizontal, ArrowUpRight,
} from "lucide-react"
import { members, activities } from "@/lib/data/mock"
import { cn, timeAgo } from "@/lib/utils"
import { TeamViewNav, getDepartmentConfig, utilizationMeta, AvatarWithStatus } from "./_lib"

export default function TeamMembersPage() {
  const [query, setQuery] = useState("")
  const [dept, setDept] = useState<string>("all")
  const [view, setView] = useState<"grid" | "list">("grid")

  const departments = useMemo(() => {
    const set = new Set(members.map(m => m.department))
    return ["all", ...Array.from(set).sort()]
  }, [])

  const filtered = useMemo(() => {
    return members.filter(m => {
      const matchDept = dept === "all" || m.department === dept
      const q = query.trim().toLowerCase()
      const matchQuery =
        !q ||
        m.name.toLowerCase().includes(q) ||
        m.email.toLowerCase().includes(q) ||
        m.title.toLowerCase().includes(q) ||
        m.department.toLowerCase().includes(q)
      return matchDept && matchQuery
    })
  }, [query, dept])

  const onlineCount = members.filter(m => m.online).length
  const totalActive = members.reduce((s, m) => s + m.activeTasks, 0)
  const avgUtil = Math.round(
    members.reduce((s, m) => s + (m.utilized / m.capacity) * 100, 0) / members.length
  )

  return (
    <DashboardShell
      title="Team"
      description="Everyone in your workspace — their roles, workload, and what they're shipping."
      actions={
        <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Link href="/team/invite"><UserPlus className="w-4 h-4" /> Invite member</Link>
        </Button>
      }
    >
      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Team Members" value={members.length} hint={`${onlineCount} online now`} icon={Users} trend={{ value: 8, positive: true }} />
        <StatCard label="Active Tasks" value={totalActive} hint="across the team" icon={Zap} trend={{ value: 4, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Utilization" value={`${avgUtil}%`} hint="this week" icon={Clock} trend={{ value: 6, positive: true }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Online Now" value={onlineCount} hint={`of ${members.length} members`} icon={CheckCircle2} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team" />
      </Card>

      {/* Toolbar */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="relative flex-1 min-w-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, title, or department…"
              value={query}
              onChange={e => setQuery(e.target.value)}
              className="pl-9 h-10 text-sm"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar -mx-1 px-1">
            {departments.map(d => {
              const isActive = dept === d
              const cfg = d === "all" ? null : getDepartmentConfig(d)
              return (
                <button
                  key={d}
                  onClick={() => setDept(d)}
                  className={cn(
                    "shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-card text-muted-foreground border-border hover:bg-secondary hover:text-foreground"
                  )}
                >
                  {cfg && <span className={cn("w-1.5 h-1.5 rounded-full", cfg.color)} />}
                  {d === "all" ? "All departments" : d}
                </button>
              )
            })}
          </div>
          <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary/60 shrink-0">
            <button
              onClick={() => setView("grid")}
              className={cn(
                "p-1.5 rounded-md transition-colors",
                view === "grid" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
              aria-label="Grid view"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setView("list")}
              className={cn(
                "p-1.5 rounded-md transition-colors",
                view === "list" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
              aria-label="List view"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <Card className="p-12 text-center border-dashed">
          <Users className="w-10 h-10 mx-auto text-muted-foreground/50 mb-3" />
          <p className="text-sm font-medium text-foreground">No members found</p>
          <p className="text-xs text-muted-foreground mt-1">Try a different search or department filter.</p>
        </Card>
      ) : view === "grid" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-4">
          {filtered.map((m, i) => {
            const utilPct = Math.round((m.utilized / m.capacity) * 100)
            const meta = utilizationMeta(utilPct)
            const deptCfg = getDepartmentConfig(m.department)
            return (
              <Link
                key={m.id}
                href={`/team/${m.id}`}
                className="block animate-slide-in-up"
                style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
              >
                <Card className="p-4 md:p-5 card-lift h-full group">
                  <div className="flex items-start justify-between mb-3">
                    <AvatarWithStatus member={m} size={48} />
                    <RoleBadge role={m.role} />
                  </div>
                  <div className="mb-3">
                    <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors truncate">{m.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{m.title}</p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap mb-3">
                    <span className={cn("inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded", deptCfg.chip)}>
                      <deptCfg.icon className="w-3 h-3" />
                      {m.department}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
                      <MapPin className="w-3 h-3" />{m.location.split(",")[0]}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-3 py-3 border-y border-border">
                    <div className="text-center">
                      <p className="text-sm font-bold text-foreground">{m.activeTasks}</p>
                      <p className="text-[10px] text-muted-foreground">Active</p>
                    </div>
                    <div className="text-center border-x border-border">
                      <p className="text-sm font-bold text-foreground">{m.completedTasks}</p>
                      <p className="text-[10px] text-muted-foreground">Done</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-bold text-foreground">{utilPct}%</p>
                      <p className="text-[10px] text-muted-foreground">Load</p>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] text-muted-foreground">Utilization</span>
                      <span className={cn("text-[10px] font-semibold", meta.chip.split(" ").slice(1).join(" "))}>{meta.label}</span>
                    </div>
                    <div className={cn("h-1.5 w-full rounded-full overflow-hidden", meta.track)}>
                      <div
                        className={cn("h-full rounded-full transition-all duration-500", meta.color)}
                        style={{ width: `${Math.min(100, utilPct)}%` }}
                      />
                    </div>
                  </div>
                </Card>
              </Link>
            )
          })}
        </div>
      ) : (
        <Card className="p-2 md:p-3 card-lift overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground border-b border-border">
                  <th className="px-3 py-2 font-medium">Member</th>
                  <th className="px-3 py-2 font-medium hidden md:table-cell">Department</th>
                  <th className="px-3 py-2 font-medium hidden sm:table-cell">Role</th>
                  <th className="px-3 py-2 font-medium text-center">Active</th>
                  <th className="px-3 py-2 font-medium text-center hidden sm:table-cell">Done</th>
                  <th className="px-3 py-2 font-medium hidden lg:table-cell min-w-[140px]">Utilization</th>
                  <th className="px-3 py-2 font-medium hidden md:table-cell">Location</th>
                  <th className="px-3 py-2 font-medium text-right"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((m, i) => {
                  const utilPct = Math.round((m.utilized / m.capacity) * 100)
                  const meta = utilizationMeta(utilPct)
                  return (
                    <tr
                      key={m.id}
                      className="border-b border-border last:border-0 hover:bg-secondary/40 transition-colors animate-fade-in"
                      style={{ animationDelay: `${Math.min(i, 10) * 30}ms` }}
                    >
                      <td className="px-3 py-2.5">
                        <Link href={`/team/${m.id}`} className="flex items-center gap-2.5 group">
                          <AvatarWithStatus member={m} size={36} />
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors truncate">{m.name}</p>
                            <p className="text-[11px] text-muted-foreground truncate">{m.title}</p>
                          </div>
                        </Link>
                      </td>
                      <td className="px-3 py-2.5 hidden md:table-cell">
                        <span className="text-xs text-muted-foreground">{m.department}</span>
                      </td>
                      <td className="px-3 py-2.5 hidden sm:table-cell">
                        <RoleBadge role={m.role} />
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <span className="text-sm font-semibold text-foreground">{m.activeTasks}</span>
                      </td>
                      <td className="px-3 py-2.5 text-center hidden sm:table-cell">
                        <span className="text-sm font-semibold text-foreground">{m.completedTasks}</span>
                      </td>
                      <td className="px-3 py-2.5 hidden lg:table-cell">
                        <div className="flex items-center gap-2">
                          <div className={cn("h-1.5 flex-1 rounded-full overflow-hidden", meta.track)}>
                            <div className={cn("h-full rounded-full", meta.color)} style={{ width: `${Math.min(100, utilPct)}%` }} />
                          </div>
                          <span className="text-[11px] font-medium text-muted-foreground w-9 text-right">{utilPct}%</span>
                        </div>
                      </td>
                      <td className="px-3 py-2.5 hidden md:table-cell">
                        <span className="text-xs text-muted-foreground">{m.location}</span>
                      </td>
                      <td className="px-3 py-2.5 text-right">
                        <Button asChild variant="ghost" size="icon" className="h-7 w-7">
                          <Link href={`/team/${m.id}`}><ArrowUpRight className="w-3.5 h-3.5" /></Link>
                        </Button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </DashboardShell>
  )
}
