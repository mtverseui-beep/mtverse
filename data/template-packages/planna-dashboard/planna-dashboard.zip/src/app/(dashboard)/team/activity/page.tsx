"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Activity as ActivityIcon, ListTodo, MessageSquare, FileText, FolderPlus,
  UserPlus, Filter, ChevronDown,
} from "lucide-react"
import { activities, members } from "@/lib/data/mock"
import { cn, timeAgo } from "@/lib/utils"
import { TeamViewNav, relativeDateGroup } from "../_lib"
import type { Activity } from "@/types"

const typeConfig: Record<Activity["type"], { label: string; icon: typeof ActivityIcon; chip: string; verb: string }> = {
  task:    { label: "Tasks",    icon: ListTodo,       chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", verb: "task" },
  comment: { label: "Comments", icon: MessageSquare,  chip: "bg-sky-500/15 text-sky-600 dark:text-sky-400",            verb: "comment" },
  file:    { label: "Files",    icon: FileText,       chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400",      verb: "file" },
  project: { label: "Projects", icon: FolderPlus,     chip: "bg-violet-500/15 text-violet-600 dark:text-violet-400",   verb: "project" },
  team:    { label: "Team",     icon: UserPlus,       chip: "bg-rose-500/15 text-rose-600 dark:text-rose-400",         verb: "team" },
}

const filterTabs = [
  { key: "all", label: "All", icon: ActivityIcon },
  ...Object.entries(typeConfig).map(([key, c]) => ({ key, label: c.label, icon: c.icon })),
] as const

export default function ActivityPage() {
  const [filter, setFilter] = useState<string>("all")
  const [limit, setLimit] = useState(15)

  const filtered = useMemo(() => {
    const sorted = [...activities].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    if (filter === "all") return sorted
    return sorted.filter(a => a.type === filter)
  }, [filter])

  // Build extra activities from tasks (so the feed is richer)
  const enriched = useMemo(() => {
    const taskEvents: Activity[] = []
    const today = new Date()
    members.forEach((m, i) => {
      if (m.completedTasks > 0 && i < 6) {
        taskEvents.push({
          id: `ta-${m.id}`,
          actor: m.name,
          actorAvatar: m.avatar,
          action: "completed",
          target: `${m.completedTasks > 100 ? "a batch of" : ""} ${Math.min(m.completedTasks, 12)} task${Math.min(m.completedTasks, 12) !== 1 ? "s" : ""} this week`,
          createdAt: new Date(today.getTime() - (i + 1) * 3600000 * 4).toISOString(),
          type: "task",
        })
      }
    })
    return [...filtered, ...taskEvents].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }, [filtered])

  const visible = enriched.slice(0, limit)

  // Group by day
  const grouped = useMemo(() => {
    const groups: { group: string; items: Activity[] }[] = []
    visible.forEach(a => {
      const g = relativeDateGroup(a.createdAt)
      const last = groups[groups.length - 1]
      if (last && last.group === g) last.items.push(a)
      else groups.push({ group: g, items: [a] })
    })
    return groups
  }, [visible])

  // Counts per filter
  const counts = useMemo(() => {
    const c: Record<string, number> = { all: activities.length }
    Object.keys(typeConfig).forEach(k => { c[k] = activities.filter(a => a.type === k).length })
    return c
  }, [])

  return (
    <DashboardShell
      title="Activity"
      description="A unified stream of everything happening across your team."
      actions={
        <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
          <Filter className="w-3.5 h-3.5" /> Filters
        </Button>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team/activity" />
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Events" value={activities.length} hint="last 7 days" icon={ActivityIcon} />
        <StatCard label="Tasks" value={counts.task} hint="task activity" icon={ListTodo} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Comments" value={counts.comment} hint="discussions" icon={MessageSquare} iconColor="bg-sky-500/15 text-sky-600 dark:text-sky-400" />
        <StatCard label="Files" value={counts.file} hint="uploads & shares" icon={FileText} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Filter pills */}
      <Card className="p-2 md:p-3 mb-4">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar -mx-1 px-1">
          {filterTabs.map(tab => {
            const isActive = filter === tab.key
            const count = counts[tab.key] ?? 0
            return (
              <button
                key={tab.key}
                onClick={() => { setFilter(tab.key); setLimit(15) }}
                className={cn(
                  "shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-muted-foreground border-border hover:bg-secondary hover:text-foreground"
                )}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
                <span className={cn(
                  "ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold",
                  isActive ? "bg-primary-foreground/20 text-primary-foreground" : "bg-secondary text-muted-foreground"
                )}>
                  {count}
                </span>
              </button>
            )
          })}
        </div>
      </Card>

      {/* Activity feed grouped by day */}
      <Card className="p-4 md:p-5 card-lift">
        {grouped.length === 0 ? (
          <div className="py-12 text-center">
            <ActivityIcon className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
            <p className="text-sm font-medium text-foreground">No activity yet</p>
            <p className="text-xs text-muted-foreground mt-1">Team activity will show up here as it happens.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {grouped.map(group => (
              <div key={group.group}>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{group.group}</span>
                  <span className="text-[10px] text-muted-foreground">· {group.items.length} event{group.items.length !== 1 ? "s" : ""}</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <div className="space-y-1">
                  {group.items.map((a, idx) => {
                    const cfg = typeConfig[a.type] ?? typeConfig.task
                    const actorMember = members.find(m => m.name === a.actor)
                    return (
                      <div
                        key={a.id}
                        className="flex items-start gap-3 p-2 rounded-lg hover:bg-secondary/40 transition-colors animate-fade-in"
                        style={{ animationDelay: `${idx * 25}ms` }}
                      >
                        {/* Vertical timeline line */}
                        <div className="relative flex flex-col items-center">
                          <Avatar className="w-8 h-8 shrink-0 ring-2 ring-card">
                            <AvatarImage src={a.actorAvatar} alt={a.actor} />
                            <AvatarFallback className="text-[10px]">{a.actor[0]}</AvatarFallback>
                          </Avatar>
                          {idx < group.items.length - 1 && (
                            <div className="w-px flex-1 bg-border mt-1 min-h-[20px]" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0 pt-0.5">
                          <p className="text-xs text-foreground leading-relaxed">
                            {actorMember ? (
                              <Link href={`/team/${actorMember.id}`} className="font-semibold hover:text-primary transition-colors">
                                {a.actor}
                              </Link>
                            ) : (
                              <span className="font-semibold">{a.actor}</span>
                            )}{" "}
                            <span className="text-muted-foreground">{a.action}</span>{" "}
                            <span className="font-medium text-foreground">{a.target}</span>
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={cn("inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded", cfg.chip)}>
                              <cfg.icon className="w-2.5 h-2.5" />
                              {cfg.label.slice(0, -1)}
                            </span>
                            <span className="text-[10px] text-muted-foreground">{timeAgo(a.createdAt)}</span>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {enriched.length > visible.length && (
          <div className="mt-4 pt-4 border-t border-border text-center">
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 bg-transparent"
              onClick={() => setLimit(l => l + 15)}
            >
              Load more <ChevronDown className="w-3.5 h-3.5" />
            </Button>
            <p className="text-[10px] text-muted-foreground mt-2">
              Showing {visible.length} of {enriched.length} events
            </p>
          </div>
        )}
      </Card>
    </DashboardShell>
  )
}
