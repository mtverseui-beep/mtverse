"use client"

import Link from "next/link"
import { useMemo } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Crown, ShieldCheck, Users, UserPlus, Check, X, ArrowRight,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn } from "@/lib/utils"
import { TeamViewNav, rolesList, roleMeta } from "../_lib"

// Capability matrix per role: can_edit, can_delete, can_invite, can_billing
const capabilitiesByRole: Record<string, {
  can_edit: boolean; can_delete: boolean; can_invite: boolean; can_billing: boolean
}> = {
  owner:   { can_edit: true,  can_delete: true,  can_invite: true,  can_billing: true  },
  admin:   { can_edit: true,  can_delete: true,  can_invite: true,  can_billing: true  },
  manager: { can_edit: true,  can_delete: false, can_invite: true,  can_billing: false },
  member:  { can_edit: true,  can_delete: false, can_invite: false, can_billing: false },
  viewer:  { can_edit: false, can_delete: false, can_invite: false, can_billing: false },
  guest:   { can_edit: false, can_delete: false, can_invite: false, can_billing: false },
}

const capabilityLabels: { key: keyof typeof capabilitiesByRole["owner"]; label: string; description: string }[] = [
  { key: "can_edit", label: "Edit", description: "Edit tasks, projects, and content" },
  { key: "can_delete", label: "Delete", description: "Delete tasks, projects, files" },
  { key: "can_invite", label: "Invite", description: "Invite new members to workspace" },
  { key: "can_billing", label: "Billing", description: "Manage subscription and invoices" },
]

export default function RolesPage() {
  const roleCounts = useMemo(() => {
    const counts: Record<string, number> = {}
    members.forEach(m => { counts[m.role] = (counts[m.role] ?? 0) + 1 })
    return counts
  }, [])

  const totalRoles = rolesList.length
  const adminCount = (roleCounts["owner"] ?? 0) + (roleCounts["admin"] ?? 0)
  const managerCount = roleCounts["manager"] ?? 0

  return (
    <DashboardShell
      title="Roles"
      description="Workspace roles, their capabilities, and who holds them."
      actions={
        <>
          <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Link href="/team/permissions">Permissions <ArrowRight className="w-3.5 h-3.5" /></Link>
          </Button>
          <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Link href="/team/invite"><UserPlus className="w-4 h-4" /> Invite member</Link>
          </Button>
        </>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team/roles" />
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Roles Defined" value={totalRoles} hint="workspace roles" icon={Crown} />
        <StatCard label="Total Members" value={members.length} hint="across all roles" icon={Users} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Admins & Owners" value={adminCount} hint="full access" icon={ShieldCheck} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Managers" value={managerCount} hint="project leads" icon={Users} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Roles grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        {rolesList.map((role, i) => {
          const meta = roleMeta[role]
          const caps = capabilitiesByRole[role]
          const roleMembers = members.filter(m => m.role === role)
          return (
            <Card
              key={role}
              className="p-4 md:p-5 card-lift animate-slide-in-up"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center", meta.color)}>
                    <meta.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-foreground">{meta.label}</h3>
                      <span className="text-[10px] font-mono text-muted-foreground">L{meta.level}</span>
                    </div>
                    <p className="text-[11px] text-muted-foreground">{roleMembers.length} member{roleMembers.length !== 1 ? "s" : ""}</p>
                  </div>
                </div>
                <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
                  <Link href="/team/permissions">Permissions <ArrowRight className="w-3 h-3" /></Link>
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mb-4 leading-relaxed">{meta.description}</p>

              {/* Capability badges */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                {capabilityLabels.map(c => {
                  const allowed = caps[c.key]
                  return (
                    <div
                      key={c.key}
                      className={cn(
                        "flex items-center gap-2 p-2 rounded-lg border text-xs",
                        allowed
                          ? "border-emerald-500/30 bg-emerald-500/5 text-foreground"
                          : "border-border bg-muted/30 text-muted-foreground"
                      )}
                    >
                      <span className={cn(
                        "w-5 h-5 rounded-full flex items-center justify-center shrink-0",
                        allowed ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-muted text-muted-foreground"
                      )}>
                        {allowed ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                      </span>
                      <div className="min-w-0">
                        <p className="font-medium leading-tight">{c.label}</p>
                        <p className="text-[10px] text-muted-foreground truncate">{c.description}</p>
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Members with this role */}
              <div className="border-t border-border pt-3">
                <p className="text-[11px] font-medium text-muted-foreground mb-2">Members with this role</p>
                {roleMembers.length === 0 ? (
                  <p className="text-[11px] text-muted-foreground italic">No members currently hold this role.</p>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {roleMembers.map(m => (
                      <Link
                        key={m.id}
                        href={`/team/${m.id}`}
                        className="flex items-center gap-1.5 pl-1 pr-2 py-1 rounded-full bg-secondary/60 hover:bg-secondary transition-colors group"
                      >
                        <Avatar className="w-5 h-5">
                          <AvatarImage src={m.avatar} alt={m.name} />
                          <AvatarFallback className="text-[9px]">{m.name[0]}</AvatarFallback>
                        </Avatar>
                        <span className="text-[11px] font-medium text-foreground group-hover:text-primary transition-colors">{m.name.split(" ")[0]}</span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </Card>
          )
        })}
      </div>

      {/* Capabilities summary table */}
      <Card className="p-2 md:p-3 card-lift overflow-hidden">
        <div className="px-2 py-2 mb-1">
          <h3 className="text-sm font-semibold">Capability matrix</h3>
          <p className="text-[11px] text-muted-foreground">What each role can do across the workspace.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground border-b border-border">
                <th className="px-3 py-2 font-medium">Role</th>
                <th className="px-3 py-2 font-medium text-center">Members</th>
                <th className="px-3 py-2 font-medium text-center">Edit</th>
                <th className="px-3 py-2 font-medium text-center">Delete</th>
                <th className="px-3 py-2 font-medium text-center">Invite</th>
                <th className="px-3 py-2 font-medium text-center">Billing</th>
                <th className="px-3 py-2 font-medium text-right">Access Level</th>
              </tr>
            </thead>
            <tbody>
              {rolesList.map(role => {
                const meta = roleMeta[role]
                const caps = capabilitiesByRole[role]
                const count = roleCounts[role] ?? 0
                return (
                  <tr key={role} className="border-b border-border last:border-0 hover:bg-secondary/40 transition-colors">
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className={cn("w-7 h-7 rounded-lg flex items-center justify-center", meta.color)}>
                          <meta.icon className="w-3.5 h-3.5" />
                        </span>
                        <span className="text-sm font-medium text-foreground">{meta.label}</span>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      <span className="text-xs font-semibold text-foreground">{count}</span>
                    </td>
                    {(["can_edit", "can_delete", "can_invite", "can_billing"] as const).map(cap => (
                      <td key={cap} className="px-3 py-2.5 text-center">
                        {caps[cap] ? (
                          <span className="inline-flex w-6 h-6 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 items-center justify-center">
                            <Check className="w-3.5 h-3.5" />
                          </span>
                        ) : (
                          <span className="inline-flex w-6 h-6 rounded-full bg-muted text-muted-foreground items-center justify-center">
                            <X className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </td>
                    ))}
                    <td className="px-3 py-2.5 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <div className="w-16 h-1.5 rounded-full bg-muted overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: `${(meta.level / 5) * 100}%` }} />
                        </div>
                        <span className="text-[11px] font-mono text-muted-foreground">L{meta.level}</span>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </DashboardShell>
  )
}
