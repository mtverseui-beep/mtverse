"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaBarChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertTriangle, CheckCircle2, Gauge, ArrowRightCircle, MoreHorizontal,
  ArrowUpRight, ChevronRight,
} from "lucide-react"
import { members, tasks } from "@/lib/data/mock"
import { cn } from "@/lib/utils"
import {
  TeamViewNav, utilizationMeta, workloadBucket, AvatarWithStatus,
} from "../_lib"

export default function WorkloadPage() {
  const [reassignOpenFor, setReassignOpenFor] = useState<string | null>(null)

  const enriched = useMemo(() =>
    members.map(m => {
      const utilPct = Math.round((m.utilized / m.capacity) * 100)
      return {
        ...m,
        utilPct,
        meta: utilizationMeta(utilPct),
        bucket: workloadBucket(utilPct),
        available: Math.max(0, m.capacity - m.utilized),
        memberTasks: tasks.filter(t => t.assignee === m.name),
      }
    }).sort((a, b) => b.utilPct - a.utilPct)
  , [])

  const over = enriched.filter(m => m.bucket === "over")
  const balanced = enriched.filter(m => m.bucket === "balanced")
  const under = enriched.filter(m => m.bucket === "under")
  const avgUtil = Math.round(enriched.reduce((s, m) => s + m.utilPct, 0) / enriched.length)

  // Chart data: capacity vs utilized
  const chartData = enriched.map(m => ({
    name: m.name.split(" ")[0],
    fullName: m.name,
    utilized: m.utilized,
    capacity: m.capacity,
  }))

  // Members available to reassign to (utilization < 80%)
  const reassignTargets = (excludeId: string) =>
    enriched.filter(m => m.id !== excludeId && m.utilPct < 80).slice(0, 5)

  return (
    <DashboardShell
      title="Workload"
      description="Who's overloaded, who has capacity, and where to rebalance work."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
          <Link href="/team/availability">Availability <ChevronRight className="w-3.5 h-3.5" /></Link>
        </Button>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team/workload" />
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Overloaded" value={over.length} hint="above 95% capacity" icon={AlertTriangle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Balanced" value={balanced.length} hint="60–95% capacity" icon={CheckCircle2} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Under-utilized" value={under.length} hint="below 60% capacity" icon={Gauge} iconColor="bg-zinc-500/15 text-zinc-600 dark:text-zinc-400" />
        <StatCard label="Avg Utilization" value={`${avgUtil}%`} hint="this week" icon={Gauge} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
      </div>

      {/* Top summary strips */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Overloaded */}
        <Card className={cn("p-4 md:p-5 border-l-4 border-l-rose-500 card-lift")}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-500" /> Overloaded
            </h3>
            <span className="text-[11px] font-semibold text-rose-600 dark:text-rose-400">{over.length}</span>
          </div>
          {over.length === 0 ? (
            <p className="text-xs text-muted-foreground py-4 text-center">No one is overloaded. Great!</p>
          ) : (
            <div className="space-y-2">
              {over.map(m => (
                <Link key={m.id} href={`/team/${m.id}`} className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-secondary/50 transition-colors">
                  <Avatar className="w-7 h-7 ring-1 ring-rose-500/30">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                    <p className="text-[10px] text-muted-foreground">{m.activeTasks} active · {m.utilized}/{m.capacity}h</p>
                  </div>
                  <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400">{m.utilPct}%</span>
                </Link>
              ))}
            </div>
          )}
        </Card>

        {/* Balanced */}
        <Card className="p-4 md:p-5 border-l-4 border-l-emerald-500 card-lift">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Balanced
            </h3>
            <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">{balanced.length}</span>
          </div>
          {balanced.length === 0 ? (
            <p className="text-xs text-muted-foreground py-4 text-center">No one in the balanced range.</p>
          ) : (
            <div className="space-y-2">
              {balanced.map(m => (
                <Link key={m.id} href={`/team/${m.id}`} className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-secondary/50 transition-colors">
                  <Avatar className="w-7 h-7 ring-1 ring-emerald-500/30">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                    <p className="text-[10px] text-muted-foreground">{m.activeTasks} active · {m.utilized}/{m.capacity}h</p>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">{m.utilPct}%</span>
                </Link>
              ))}
            </div>
          )}
        </Card>

        {/* Under-utilized */}
        <Card className="p-4 md:p-5 border-l-4 border-l-zinc-400 card-lift">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Gauge className="w-4 h-4 text-zinc-400" /> Under-utilized
            </h3>
            <span className="text-[11px] font-semibold text-zinc-600 dark:text-zinc-400">{under.length}</span>
          </div>
          {under.length === 0 ? (
            <p className="text-xs text-muted-foreground py-4 text-center">Everyone is well-utilized.</p>
          ) : (
            <div className="space-y-2">
              {under.map(m => (
                <Link key={m.id} href={`/team/${m.id}`} className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-secondary/50 transition-colors">
                  <Avatar className="w-7 h-7 ring-1 ring-zinc-400/30">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                    <p className="text-[10px] text-muted-foreground">{m.activeTasks} active · {m.utilized}/{m.capacity}h</p>
                  </div>
                  <span className="text-[11px] font-bold text-zinc-600 dark:text-zinc-400">{m.utilPct}%</span>
                </Link>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Workload chart */}
      <ChartCard
        title="Capacity vs Utilized"
        subtitle="Weekly hours per member — sorted by utilization"
        className="mb-4"
      >
        <PlannaBarChart
          data={chartData}
          xKey="name"
          series={[
            { key: "utilized", name: "Utilized", color: "var(--chart-1)" },
            { key: "capacity", name: "Capacity", color: "var(--chart-4)" },
          ]}
          height={300}
        />
      </ChartCard>

      {/* Member-by-member list with reassign */}
      <Card className="p-2 md:p-3 card-lift overflow-hidden">
        <div className="px-2 py-2 mb-1 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold">Rebalance workload</h3>
            <p className="text-[11px] text-muted-foreground">Reassign tasks from overloaded members to those with capacity.</p>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground border-b border-border">
                <th className="px-3 py-2 font-medium">Member</th>
                <th className="px-3 py-2 font-medium hidden sm:table-cell">Capacity</th>
                <th className="px-3 py-2 font-medium hidden md:table-cell">Utilized</th>
                <th className="px-3 py-2 font-medium min-w-[160px]">Utilization</th>
                <th className="px-3 py-2 font-medium text-center hidden sm:table-cell">Active</th>
                <th className="px-3 py-2 font-medium">Status</th>
                <th className="px-3 py-2 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {enriched.map(m => (
                <tr key={m.id} className="border-b border-border last:border-0 hover:bg-secondary/40 transition-colors">
                  <td className="px-3 py-2.5">
                    <Link href={`/team/${m.id}`} className="flex items-center gap-2.5 group">
                      <AvatarWithStatus member={m} size={32} />
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors truncate">{m.name}</p>
                        <p className="text-[11px] text-muted-foreground truncate">{m.title}</p>
                      </div>
                    </Link>
                  </td>
                  <td className="px-3 py-2.5 hidden sm:table-cell">
                    <span className="text-xs text-muted-foreground">{m.capacity}h</span>
                  </td>
                  <td className="px-3 py-2.5 hidden md:table-cell">
                    <span className="text-xs text-muted-foreground">{m.utilized}h</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className={cn("h-1.5 flex-1 rounded-full overflow-hidden", m.meta.track)}>
                        <div className={cn("h-full rounded-full transition-all duration-500", m.meta.color)} style={{ width: `${Math.min(100, m.utilPct)}%` }} />
                      </div>
                      <span className="text-[11px] font-semibold text-foreground w-9 text-right">{m.utilPct}%</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-center hidden sm:table-cell">
                    <span className="text-xs font-semibold text-foreground">{m.activeTasks}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full", m.meta.chip)}>
                      <span className={cn("w-1.5 h-1.5 rounded-full", m.meta.dot)} />
                      {m.meta.label}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    {m.bucket === "over" && m.memberTasks.length > 0 ? (
                      <DropdownMenu open={reassignOpenFor === m.id} onOpenChange={o => setReassignOpenFor(o ? m.id : null)}>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent">
                            <ArrowRightCircle className="w-3.5 h-3.5" /> Reassign
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-72">
                          <DropdownMenuLabel className="text-xs">
                            Reassign from {m.name.split(" ")[0]}
                          </DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuLabel className="text-[10px] uppercase tracking-wide text-muted-foreground">
                            {m.memberTasks.length} assignable task{m.memberTasks.length !== 1 ? "s" : ""}
                          </DropdownMenuLabel>
                          {m.memberTasks.slice(0, 4).map(t => (
                            <DropdownMenuItem key={t.id} className="flex flex-col items-start gap-1 py-2">
                              <div className="flex items-center gap-2 w-full">
                                <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
                                <span className="text-[11px] font-medium text-foreground truncate flex-1">{t.title}</span>
                              </div>
                              <div className="flex items-center gap-1 w-full mt-1">
                                <span className="text-[9px] text-muted-foreground">to:</span>
                                {reassignTargets(m.id).map(tgt => (
                                  <span key={tgt.id} className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-secondary text-[10px] text-foreground hover:bg-primary/10 hover:text-primary cursor-pointer">
                                    <Avatar className="w-3.5 h-3.5"><AvatarImage src={tgt.avatar} alt={tgt.name} /><AvatarFallback className="text-[7px]">{tgt.name[0]}</AvatarFallback></Avatar>
                                    {tgt.name.split(" ")[0]}
                                  </span>
                                ))}
                              </div>
                            </DropdownMenuItem>
                          ))}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-xs gap-1.5">
                            <ArrowUpRight className="w-3 h-3" /> Open task board
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    ) : m.bucket === "under" ? (
                      <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent">
                        <ArrowRightCircle className="w-3.5 h-3.5" /> Assign
                      </Button>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </DashboardShell>
  )
}
