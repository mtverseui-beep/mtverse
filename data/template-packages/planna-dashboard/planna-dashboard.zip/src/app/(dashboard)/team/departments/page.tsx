"use client"

import Link from "next/link"
import { useMemo } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  Building2, Users, Zap, Gauge, ArrowUpRight, ChevronRight,
} from "lucide-react"
import { members, tasks } from "@/lib/data/mock"
import { cn } from "@/lib/utils"
import { TeamViewNav, getDepartmentConfig, utilizationMeta } from "../_lib"

export default function DepartmentsPage() {
  const departments = useMemo(() => {
    const map = new Map<string, typeof members>()
    members.forEach(m => {
      const arr = map.get(m.department) ?? []
      arr.push(m)
      map.set(m.department, arr)
    })
    return Array.from(map.entries()).map(([name, mems]) => {
      // Lead = highest role level (owner > admin > manager > member)
      const roleRank: Record<string, number> = { owner: 5, admin: 4, manager: 3, member: 2, viewer: 1, guest: 0 }
      const lead = [...mems].sort((a, b) => (roleRank[b.role] ?? 0) - (roleRank[a.role] ?? 0))[0]
      const activeTasks = mems.reduce((s, m) => s + m.activeTasks, 0)
      const completedTasks = mems.reduce((s, m) => s + m.completedTasks, 0)
      const totalCap = mems.reduce((s, m) => s + m.capacity, 0)
      const totalUtil = mems.reduce((s, m) => s + m.utilized, 0)
      const avgUtil = Math.round((totalUtil / totalCap) * 100)
      const onlineCount = mems.filter(m => m.online).length
      // Tasks whose assignee is in this department
      const deptNames = new Set(mems.map(m => m.name))
      const deptTasks = tasks.filter(t => t.assignee && deptNames.has(t.assignee)).length
      return { name, members: mems, lead, activeTasks, completedTasks, avgUtil, onlineCount, totalTasks: deptTasks }
    }).sort((a, b) => b.members.length - a.members.length)
  }, [])

  const totalDepts = departments.length
  const totalMembers = members.length
  const overallUtil = Math.round(members.reduce((s, m) => s + (m.utilized / m.capacity) * 100, 0) / members.length)
  const totalActive = members.reduce((s, m) => s + m.activeTasks, 0)

  return (
    <DashboardShell
      title="Departments"
      description="Team structure by department — leads, headcount, workload, and active work."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
          <Link href="/team"><Users className="w-4 h-4" /> All members</Link>
        </Button>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team/departments" />
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Departments" value={totalDepts} hint="across workspace" icon={Building2} />
        <StatCard label="Total Members" value={totalMembers} hint="all departments" icon={Users} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Avg Utilization" value={`${overallUtil}%`} hint="this week" icon={Gauge} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Active Tasks" value={totalActive} hint="in progress" icon={Zap} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        {departments.map((dept, i) => {
          const cfg = getDepartmentConfig(dept.name)
          const utilMeta = utilizationMeta(dept.avgUtil)
          return (
            <Card
              key={dept.name}
              className="relative overflow-hidden p-4 md:p-5 card-lift group animate-slide-in-up"
              style={{ animationDelay: `${Math.min(i, 8) * 50}ms` }}
            >
              <div className={cn("absolute top-0 left-0 right-0 h-1", cfg.color)} />
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center", cfg.chip)}>
                    <cfg.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-foreground">{dept.name}</h3>
                    <p className="text-[11px] text-muted-foreground">{dept.members.length} member{dept.members.length !== 1 ? "s" : ""} · {dept.onlineCount} online</p>
                  </div>
                </div>
                <Button asChild variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Link href="/team"><ArrowUpRight className="w-4 h-4" /></Link>
                </Button>
              </div>

              {/* Lead */}
              <div className="flex items-center gap-2.5 p-2.5 rounded-lg bg-secondary/40 mb-4">
                <Avatar className="w-8 h-8 ring-2 ring-card">
                  <AvatarImage src={dept.lead.avatar} alt={dept.lead.name} />
                  <AvatarFallback className="text-[10px]">{dept.lead.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-muted-foreground">Department lead</p>
                  <p className="text-xs font-medium text-foreground truncate">{dept.lead.name}</p>
                </div>
                <span className="text-[9px] font-semibold uppercase tracking-wide px-1.5 py-0.5 rounded bg-primary/10 text-primary capitalize">{dept.lead.role}</span>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="text-center">
                  <p className="text-base font-bold text-foreground">{dept.activeTasks}</p>
                  <p className="text-[10px] text-muted-foreground">Active</p>
                </div>
                <div className="text-center border-x border-border">
                  <p className="text-base font-bold text-foreground">{dept.completedTasks}</p>
                  <p className="text-[10px] text-muted-foreground">Done</p>
                </div>
                <div className="text-center">
                  <p className="text-base font-bold text-foreground">{dept.totalTasks}</p>
                  <p className="text-[10px] text-muted-foreground">Tasks</p>
                </div>
              </div>

              {/* Utilization */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] text-muted-foreground">Avg utilization</span>
                  <span className={cn("text-[11px] font-semibold", utilMeta.chip.split(" ").slice(1).join(" "))}>{dept.avgUtil}%</span>
                </div>
                <div className={cn("h-1.5 w-full rounded-full overflow-hidden", utilMeta.track)}>
                  <div className={cn("h-full rounded-full transition-all duration-500", utilMeta.color)} style={{ width: `${Math.min(100, dept.avgUtil)}%` }} />
                </div>
              </div>

              {/* Member avatars */}
              <div className="flex items-center justify-between">
                <div className="flex -space-x-2">
                  {dept.members.slice(0, 5).map(m => (
                    <Avatar key={m.id} className="w-7 h-7 ring-2 ring-card">
                      <AvatarImage src={m.avatar} alt={m.name} />
                      <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                    </Avatar>
                  ))}
                  {dept.members.length > 5 && (
                    <div className="w-7 h-7 rounded-full ring-2 ring-card bg-secondary flex items-center justify-center text-[10px] font-medium text-muted-foreground">
                      +{dept.members.length - 5}
                    </div>
                  )}
                </div>
                <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
                  <Link href="/team">View <ChevronRight className="w-3 h-3" /></Link>
                </Button>
              </div>
            </Card>
          )
        })}
      </div>
    </DashboardShell>
  )
}
