"use client"

import Link from "next/link"
import { useMemo } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Wifi, CalendarOff, Users, UserCheck, Clock, Globe2, ChevronRight,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn } from "@/lib/utils"
import {
  TeamViewNav, formatTzOffset, formatTzLocalTime,
} from "../_lib"

// Availability states for weekly grid
type AvailState = "online" | "meeting" | "off" | "pto" | "focus"
const stateMeta: Record<AvailState, { label: string; short: string; cell: string; dot: string; chip: string }> = {
  online:  { label: "Online",      short: "On",  cell: "bg-emerald-500/80 hover:bg-emerald-500",                  dot: "bg-emerald-500", chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  meeting: { label: "In meeting",  short: "Mtg", cell: "bg-amber-500/80 hover:bg-amber-500",                     dot: "bg-amber-500",   chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  focus:   { label: "Focus time",  short: "Foc", cell: "bg-sky-500/80 hover:bg-sky-500",                          dot: "bg-sky-500",     chip: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
  pto:     { label: "On PTO",      short: "PTO", cell: "bg-violet-500/80 hover:bg-violet-500",                    dot: "bg-violet-500",  chip: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
  off:     { label: "Off",         short: "Off", cell: "bg-zinc-300/70 dark:bg-zinc-700/70 hover:bg-zinc-400",     dot: "bg-zinc-400",    chip: "bg-muted text-muted-foreground" },
}

const weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri"]
const weekdaysFull = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

// Deterministic availability schedule per member for 5 weekdays (Mon–Fri).
// Generated from member id hash so it's stable across renders.
function memberSchedule(memberId: string): AvailState[] {
  let seed = 0
  for (let i = 0; i < memberId.length; i++) seed = (seed * 31 + memberId.charCodeAt(i)) >>> 0
  const rng = (n: number) => {
    seed = (seed * 1103515245 + 12345 + n) & 0x7fffffff
    return seed / 0x7fffffff
  }
  const row: AvailState[] = []
  // ~18% of members are on PTO all week
  const allPto = rng(0) < 0.18
  if (allPto) return ["pto", "pto", "pto", "pto", "pto"]
  for (let d = 0; d < 5; d++) {
    const r = rng(d + 1)
    // ~15% chance of an off day
    if (r < 0.15) { row.push("off"); continue }
    const x = rng(d * 13 + 7)
    if (x < 0.5) row.push("online")
    else if (x < 0.75) row.push("meeting")
    else if (x < 0.88) row.push("focus")
    else row.push("off")
  }
  return row
}

// current weekday index (Mon=0 .. Sun=6), -1 if weekend
function currentWeekdayIndex(): number {
  const d = new Date().getDay() // 0=Sun..6=Sat
  return d === 0 ? -1 : d - 1 // Mon=0..Fri=4, Sat/Sun=-1
}

export default function AvailabilityPage() {
  const todayIdx = currentWeekdayIndex()

  // Group members by timezone offset for the strip
  const tzGroups = useMemo(() => {
    const map = new Map<string, typeof members>()
    members.forEach(m => {
      const off = formatTzOffset(m.timezone)
      const arr = map.get(off) ?? []
      arr.push(m)
      map.set(off, arr)
    })
    return Array.from(map.entries()).sort((a, b) => {
      // sort by numeric offset
      const pa = parseFloat(a[0].replace("GMT", "").replace(":",".")) || 0
      const pb = parseFloat(b[0].replace("GMT", "").replace(":",".")) || 0
      return pa - pb
    })
  }, [])

  const schedules = useMemo(() =>
    members.map(m => ({ member: m, schedule: memberSchedule(m.id) }))
  , [])

  // Counts (based on today, or Monday if weekend)
  const dayIdx = todayIdx >= 0 && todayIdx < 5 ? todayIdx : 0
  const todayStates = schedules.map(s => s.schedule[dayIdx])
  const onlineCount = todayStates.filter(s => s === "online").length
  const meetingCount = todayStates.filter(s => s === "meeting").length
  const ptoCount = todayStates.filter(s => s === "pto").length
  const availableCount = todayStates.filter(s => s === "online" || s === "focus").length

  return (
    <DashboardShell
      title="Availability"
      description="See who's online, in meetings, on PTO, or off — across time zones."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
          <Link href="/team/workload">Workload <ChevronRight className="w-3.5 h-3.5" /></Link>
        </Button>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team/availability" />
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Online Now" value={onlineCount} hint="available for work" icon={Wifi} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="In Meetings" value={meetingCount} hint="busy right now" icon={Users} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="On PTO" value={ptoCount} hint="out today" icon={CalendarOff} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Available" value={availableCount} hint="online or focused" icon={UserCheck} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
      </div>

      {/* Time zone strip */}
      <Card className="p-4 md:p-5 mb-4 card-lift">
        <div className="flex items-center gap-2 mb-3">
          <Globe2 className="w-4 h-4 text-muted-foreground" />
          <h3 className="text-sm font-semibold">Time zones</h3>
          <span className="text-[11px] text-muted-foreground">· {tzGroups.length} zones · {members.length} members</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2">
          {tzGroups.map(([offset, mems]) => (
            <div key={offset} className="p-2.5 rounded-lg border border-border bg-secondary/30">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-semibold text-foreground">{offset}</span>
                <span className="text-[10px] text-muted-foreground">{formatTzLocalTime(mems[0].timezone)}</span>
              </div>
              <div className="flex -space-x-1.5">
                {mems.slice(0, 4).map(m => (
                  <Avatar key={m.id} className="w-6 h-6 ring-2 ring-card">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback className="text-[9px]">{m.name[0]}</AvatarFallback>
                  </Avatar>
                ))}
                {mems.length > 4 && (
                  <div className="w-6 h-6 rounded-full ring-2 ring-card bg-secondary flex items-center justify-center text-[9px] font-medium text-muted-foreground">
                    +{mems.length - 4}
                  </div>
                )}
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5 truncate">
                {mems[0].timezone.split("/")[1]?.replace("_", " ") ?? mems[0].timezone}
              </p>
            </div>
          ))}
        </div>
      </Card>

      {/* Legend */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] text-muted-foreground mr-1">Legend:</span>
          {(Object.keys(stateMeta) as AvailState[]).map(s => {
            const m = stateMeta[s]
            return (
              <span key={s} className={cn("inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-[11px] font-medium", m.chip)}>
                <span className={cn("w-2 h-2 rounded-full", m.dot)} />
                {m.label}
              </span>
            )
          })}
          <span className="text-[11px] text-muted-foreground ml-auto">
            <Clock className="w-3 h-3 inline mr-1" />
            Highlighted column = today
          </span>
        </div>
      </Card>

      {/* Weekly availability grid */}
      <Card className="p-2 md:p-3 card-lift overflow-hidden">
        <div className="px-2 py-2 mb-1">
          <h3 className="text-sm font-semibold">Weekly availability</h3>
          <p className="text-[11px] text-muted-foreground">Mon–Fri · click a cell to see member detail</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left text-[11px] uppercase tracking-wide text-muted-foreground px-3 py-2 font-medium min-w-[200px]">
                  Member
                </th>
                {weekdays.map((d, i) => (
                  <th key={d} className="px-2 py-2 text-center min-w-[80px]">
                    <div className="flex flex-col items-center">
                      <span className={cn(
                        "text-[11px] font-medium",
                        i === todayIdx ? "text-primary" : "text-foreground"
                      )}>{weekdaysFull[i]}</span>
                      <span className="text-[9px] text-muted-foreground">{d}</span>
                      {i === todayIdx && (
                        <span className="text-[8px] font-bold text-primary uppercase tracking-wide mt-0.5">Today</span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {schedules.map(({ member, schedule }) => (
                <tr key={member.id} className="border-b border-border last:border-0 hover:bg-secondary/30 transition-colors">
                  <td className="px-3 py-2.5">
                    <Link href={`/team/${member.id}`} className="flex items-center gap-2.5 group">
                      <div className="relative">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={member.avatar} alt={member.name} />
                          <AvatarFallback className="text-[10px]">{member.name[0]}</AvatarFallback>
                        </Avatar>
                        <span className={cn(
                          "absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full ring-2 ring-card",
                          member.online ? "bg-emerald-500" : "bg-zinc-400"
                        )} />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors truncate">{member.name}</p>
                        <p className="text-[10px] text-muted-foreground truncate">
                          {formatTzOffset(member.timezone)} · {member.location.split(",")[0]}
                        </p>
                      </div>
                    </Link>
                  </td>
                  {schedule.map((state, i) => {
                    const m = stateMeta[state]
                    const isToday = i === todayIdx
                    return (
                      <td key={i} className="px-2 py-2.5 text-center">
                        <div
                          className={cn(
                            "relative mx-auto h-9 rounded-md flex items-center justify-center transition-all duration-200 hover:scale-105 cursor-default",
                            m.cell,
                            isToday && "ring-2 ring-primary ring-offset-1 ring-offset-card"
                          )}
                          title={`${member.name} — ${weekdaysFull[i]}: ${m.label}`}
                        >
                          <span className="text-[10px] font-bold text-white drop-shadow-sm">{m.short}</span>
                        </div>
                      </td>
                    )
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Summary footer */}
      <Card className="p-4 md:p-5 mt-4 border-dashed">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {(Object.keys(stateMeta) as AvailState[]).map(s => {
            const m = stateMeta[s]
            const count = todayStates.filter(x => x === s).length
            return (
              <div key={s} className="flex items-center gap-3">
                <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", m.chip)}>
                  <span className={cn("w-2.5 h-2.5 rounded-full", m.dot)} />
                </div>
                <div>
                  <p className="text-base font-bold text-foreground">{count}</p>
                  <p className="text-[11px] text-muted-foreground">{m.label} today</p>
                </div>
              </div>
            )
          })}
        </div>
      </Card>
    </DashboardShell>
  )
}
