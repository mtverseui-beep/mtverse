"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  UserPlus, Mail, Send, Clock, MoreHorizontal, RotateCw, X, CheckCircle2,
  Users, ShieldCheck, Crown, Sparkles,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn, formatDate, timeAgo } from "@/lib/utils"
import { TeamViewNav, rolesList, roleMeta } from "../_lib"

// Pending invites (inline mock)
const initialPending = [
  { id: "inv1", email: "kai.nakamura@example.com", role: "member" as const, sentAt: new Date(Date.now() - 2 * 86400000).toISOString(), inviter: "Jessin Sam" },
  { id: "inv2", email: "priya.shah@example.com", role: "viewer" as const, sentAt: new Date(Date.now() - 5 * 86400000).toISOString(), inviter: "Zara Marlowe" },
  { id: "inv3", email: "marcus.lee@example.com", role: "manager" as const, sentAt: new Date(Date.now() - 86400000).toISOString(), inviter: "Jessin Sam" },
]

const SEAT_LIMIT = 20

export default function InvitePage() {
  const [email, setEmail] = useState("")
  const [role, setRole] = useState<string>("member")
  const [message, setMessage] = useState("")
  const [pending, setPending] = useState(initialPending)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState("")

  const seatsUsed = members.length + pending.length
  const seatsAvailable = SEAT_LIMIT - seatsUsed
  const thisMonthInvited = 4 // mock

  const validEmail = useMemo(() => {
    if (!email) return false
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  }, [email])

  const sendInvite = () => {
    setError("")
    if (!validEmail) {
      setError("Please enter a valid email address.")
      return
    }
    if (pending.some(p => p.email.toLowerCase() === email.toLowerCase())) {
      setError("An invite is already pending for this email.")
      return
    }
    if (seatsAvailable <= 0) {
      setError("No seats available. Upgrade your plan to invite more members.")
      return
    }
    setPending(prev => [
      { id: `inv-${Date.now()}`, email, role: role as "member" | "viewer" | "manager", sentAt: new Date().toISOString(), inviter: "Jessin Sam" },
      ...prev,
    ])
    setSent(true)
    setEmail("")
    setMessage("")
    setTimeout(() => setSent(false), 4000)
  }

  const resend = (id: string) => {
    setPending(prev => prev.map(p => p.id === id ? { ...p, sentAt: new Date().toISOString() } : p))
  }

  const revoke = (id: string) => {
    setPending(prev => prev.filter(p => p.id !== id))
  }

  return (
    <DashboardShell
      title="Invite Members"
      description="Bring new teammates into your workspace and manage pending invitations."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
          <a href="/team"><Users className="w-4 h-4" /> All members</a>
        </Button>
      }
    >
      <Card className="p-3 md:p-4 mb-4">
        <TeamViewNav active="/team/invite" />
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Pending Invites" value={pending.length} hint="awaiting acceptance" icon={Clock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Seats Used" value={`${seatsUsed} / ${SEAT_LIMIT}`} hint="workspace members + invites" icon={Users} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Seats Available" value={seatsAvailable} hint="upgrade for more" icon={ShieldCheck} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Invited This Month" value={thisMonthInvited} hint="last 30 days" icon={UserPlus} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Invite form */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <UserPlus className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold">Invite a new member</h3>
                <p className="text-[11px] text-muted-foreground">They'll receive an email with a join link.</p>
              </div>
            </div>

            {sent && (
              <div className="mb-4 p-3 rounded-lg border border-emerald-500/30 bg-emerald-500/5 flex items-center gap-2 animate-scale-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <p className="text-xs text-foreground">
                  <span className="font-semibold">Invitation sent.</span>{" "}
                  <span className="text-muted-foreground">The recipient will get an email shortly.</span>
                </p>
              </div>
            )}

            <div className="space-y-4">
              {/* Email */}
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs">Email address <span className="text-rose-500">*</span></Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="teammate@company.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className={cn("pl-9 h-10", error && !validEmail && "border-rose-500/50 focus-visible:ring-rose-500/30")}
                  />
                </div>
                {error && <p className="text-[11px] text-rose-600 dark:text-rose-400">{error}</p>}
              </div>

              {/* Role selector */}
              <div className="space-y-1.5">
                <Label className="text-xs">Role</Label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {rolesList.map(r => {
                    const meta = roleMeta[r]
                    const isActive = role === r
                    return (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRole(r)}
                        className={cn(
                          "p-2.5 rounded-lg border text-left transition-all",
                          isActive
                            ? "border-primary bg-primary/5 ring-1 ring-primary/30"
                            : "border-border bg-card hover:border-primary/30 hover:bg-secondary/40"
                        )}
                      >
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className={cn("w-6 h-6 rounded-md flex items-center justify-center", meta.color)}>
                            <meta.icon className="w-3.5 h-3.5" />
                          </span>
                          <span className="text-xs font-semibold text-foreground">{meta.label}</span>
                          {isActive && <CheckCircle2 className="w-3.5 h-3.5 text-primary ml-auto" />}
                        </div>
                        <p className="text-[10px] text-muted-foreground line-clamp-2 leading-tight">{meta.description}</p>
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* Personal message */}
              <div className="space-y-1.5">
                <Label htmlFor="message" className="text-xs">Personal message <span className="text-muted-foreground font-normal">(optional)</span></Label>
                <Textarea
                  id="message"
                  placeholder="Welcome to the team! Looking forward to working with you…"
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  rows={3}
                  className="text-sm resize-none"
                />
                <p className="text-[10px] text-muted-foreground">{message.length}/500 characters</p>
              </div>

              <Separator />

              <div className="flex items-center justify-between gap-2">
                <p className="text-[11px] text-muted-foreground">
                  {seatsAvailable} seat{seatsAvailable !== 1 ? "s" : ""} remaining on your plan.
                </p>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="h-9 bg-transparent" onClick={() => { setEmail(""); setMessage(""); setRole("member"); setError("") }}>
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
                    onClick={sendInvite}
                    disabled={!validEmail}
                  >
                    <Send className="w-3.5 h-3.5" /> Send invite
                  </Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Pending invites list */}
          <Card className="p-2 md:p-3 card-lift overflow-hidden">
            <div className="px-2 py-2 mb-1 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold">Pending invitations</h3>
                <p className="text-[11px] text-muted-foreground">{pending.length} invite{pending.length !== 1 ? "s" : ""} awaiting acceptance</p>
              </div>
            </div>
            {pending.length === 0 ? (
              <div className="p-8 text-center">
                <CheckCircle2 className="w-10 h-10 mx-auto text-muted-foreground/40 mb-3" />
                <p className="text-sm font-medium text-foreground">No pending invites</p>
                <p className="text-xs text-muted-foreground mt-1">New invitations will appear here.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground border-b border-border">
                      <th className="px-3 py-2 font-medium">Email</th>
                      <th className="px-3 py-2 font-medium hidden sm:table-cell">Role</th>
                      <th className="px-3 py-2 font-medium hidden md:table-cell">Invited by</th>
                      <th className="px-3 py-2 font-medium">Sent</th>
                      <th className="px-3 py-2 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pending.map(p => {
                      const meta = roleMeta[p.role]
                      return (
                        <tr key={p.id} className="border-b border-border last:border-0 hover:bg-secondary/40 transition-colors animate-fade-in">
                          <td className="px-3 py-2.5">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0">
                                <Mail className="w-3.5 h-3.5 text-muted-foreground" />
                              </div>
                              <div className="min-w-0">
                                <p className="text-xs font-medium text-foreground truncate">{p.email}</p>
                                <p className="text-[10px] text-muted-foreground sm:hidden">{meta.label} · {timeAgo(p.sentAt)}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-3 py-2.5 hidden sm:table-cell">
                            <span className={cn("inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full", meta.color)}>
                              <meta.icon className="w-3 h-3" />
                              {meta.label}
                            </span>
                          </td>
                          <td className="px-3 py-2.5 hidden md:table-cell">
                            <span className="text-xs text-muted-foreground">{p.inviter}</span>
                          </td>
                          <td className="px-3 py-2.5">
                            <div>
                              <p className="text-xs text-foreground">{timeAgo(p.sentAt)}</p>
                              <p className="text-[10px] text-muted-foreground hidden sm:block">{formatDate(p.sentAt, { month: "short", day: "numeric" })}</p>
                            </div>
                          </td>
                          <td className="px-3 py-2.5 text-right">
                            <div className="inline-flex items-center gap-1">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 text-xs gap-1.5 bg-transparent hidden sm:inline-flex"
                                onClick={() => resend(p.id)}
                              >
                                <RotateCw className="w-3 h-3" /> Resend
                              </Button>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <MoreHorizontal className="w-4 h-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem className="text-xs gap-1.5 sm:hidden" onClick={() => resend(p.id)}>
                                    <RotateCw className="w-3.5 h-3.5" /> Resend invite
                                  </DropdownMenuItem>
                                  <DropdownMenuItem className="text-xs gap-1.5 sm:hidden" onClick={() => resend(p.id)}>
                                    <Mail className="w-3.5 h-3.5" /> Copy invite link
                                  </DropdownMenuItem>
                                  <DropdownMenuItem className="text-xs gap-1.5 text-rose-600 dark:text-rose-400 focus:text-rose-600" onClick={() => revoke(p.id)}>
                                    <X className="w-3.5 h-3.5" /> Revoke invite
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>

        {/* Side panel */}
        <div className="space-y-4">
          <Card className="p-4 md:p-5 card-lift">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" /> Tips for inviting
            </h3>
            <div className="space-y-3">
              {[
                { icon: Crown,       title: "Choose the right role", body: "Owners and admins have full access. Members can collaborate. Viewers are read-only." },
                { icon: Mail,        title: "Personalize the message", body: "A short note increases acceptance rates by up to 40%." },
                { icon: ShieldCheck, title: "Review permissions", body: "Fine-tune what each role can do in the permissions matrix." },
              ].map((t, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <t.icon className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-foreground">{t.title}</p>
                    <p className="text-[11px] text-muted-foreground leading-relaxed mt-0.5">{t.body}</p>
                  </div>
                </div>
              ))}
            </div>
            <Separator className="my-4" />
            <Button asChild variant="outline" size="sm" className="w-full bg-transparent text-xs h-8">
              <a href="/team/permissions">Manage permissions</a>
            </Button>
          </Card>

          <Card className="p-4 md:p-5 card-lift border-dashed">
            <div className="text-center">
              <div className="w-12 h-12 rounded-xl bg-violet-500/10 text-violet-600 dark:text-violet-400 flex items-center justify-center mx-auto mb-3">
                <Crown className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-foreground">Need more seats?</p>
              <p className="text-[11px] text-muted-foreground mt-1 mb-3">
                You've used {seatsUsed} of {SEAT_LIMIT} seats on the Scale plan.
              </p>
              <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs h-8">
                Upgrade plan
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
