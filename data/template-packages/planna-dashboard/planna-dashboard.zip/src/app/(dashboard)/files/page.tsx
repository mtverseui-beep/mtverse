"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Upload, Search, LayoutGrid, List as ListIcon, Star, MoreHorizontal, Download, Share2,
  Pencil, Trash2, Home, Folder, FileText, Image as ImageIcon, FileBox, Video, Music,
  Archive, Code, File as FileIcon, Clock, Users, Star as StarIcon, Trash, Files as FilesIcon,
} from "lucide-react"
import { files } from "@/lib/data/mock"
import { cn, formatFileSize, timeAgo, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import type { FileItem } from "@/types"

const fileIcons: Record<string, any> = {
  pdf: FileText, document: FileText, spreadsheet: FileBox, presentation: FileText,
  image: ImageIcon, video: Video, audio: Music, archive: Archive, code: Code,
}

const fileTypeLabels: Record<string, string> = {
  pdf: "PDF", document: "Document", spreadsheet: "Spreadsheet", presentation: "Presentation",
  image: "Image", video: "Video", audio: "Audio", archive: "Archive", code: "Code",
}

const fileTypeColors: Record<string, string> = {
  pdf: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  document: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  spreadsheet: "bg-teal-500/15 text-teal-600 dark:text-teal-400",
  presentation: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  image: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400",
  video: "bg-orange-500/15 text-orange-600 dark:text-orange-400",
  audio: "bg-pink-500/15 text-pink-600 dark:text-pink-400",
  archive: "bg-lime-500/15 text-lime-600 dark:text-lime-400",
  code: "bg-green-500/15 text-green-600 dark:text-green-400",
}

type FilterKey = "all" | "recent" | "shared" | "starred" | "trash"

const sidebarFilters: { key: FilterKey; label: string; icon: any; count: number }[] = [
  { key: "all", label: "All files", icon: FilesIcon, count: files.length },
  { key: "recent", label: "Recent", icon: Clock, count: 5 },
  { key: "shared", label: "Shared", icon: Users, count: files.filter(f => f.shared).length },
  { key: "starred", label: "Starred", icon: StarIcon, count: files.filter(f => f.starred).length },
  { key: "trash", label: "Trash", icon: Trash, count: 0 },
]

const folders = [
  { id: "fld1", name: "Planna Web App", files: 18, color: "bg-emerald-500" },
  { id: "fld2", name: "Design System 2.0", files: 12, color: "bg-teal-500" },
  { id: "fld3", name: "Public API Platform", files: 9, color: "bg-lime-500" },
  { id: "fld4", name: "Acme Client Project", files: 7, color: "bg-cyan-500" },
  { id: "fld5", name: "Mobile Companion", files: 5, color: "bg-green-500" },
]

const typeFilters = [
  { key: "all", label: "All types" },
  { key: "pdf", label: "PDF" },
  { key: "document", label: "Documents" },
  { key: "spreadsheet", label: "Spreadsheets" },
  { key: "presentation", label: "Presentations" },
  { key: "image", label: "Images" },
  { key: "video", label: "Videos" },
  { key: "code", label: "Code" },
  { key: "archive", label: "Archives" },
]

type SortKey = "name" | "size" | "modified"

export default function FilesPage() {
  const { toast } = useToast()
  const [activeFilter, setActiveFilter] = useState<FilterKey>("all")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [sort, setSort] = useState<SortKey>("modified")
  const [view, setView] = useState<"grid" | "list">("grid")
  const [query, setQuery] = useState("")
  const [starred, setStarred] = useState<Record<string, boolean>>(
    Object.fromEntries(files.map(f => [f.id, f.starred]))
  )

  const filtered = useMemo(() => {
    let list = [...files]
    if (activeFilter === "shared") list = list.filter(f => f.shared)
    if (activeFilter === "starred") list = list.filter(f => starred[f.id])
    if (activeFilter === "recent") list = list.slice().sort((a, b) => new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime()).slice(0, 5)
    if (typeFilter !== "all") list = list.filter(f => f.type === typeFilter)
    if (query.trim()) {
      const q = query.toLowerCase()
      list = list.filter(f => f.name.toLowerCase().includes(q) || f.owner.toLowerCase().includes(q) || (f.project?.toLowerCase().includes(q)))
    }
    list.sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name)
      if (sort === "size") return b.size - a.size
      return new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime()
    })
    return list
  }, [activeFilter, typeFilter, sort, query, starred])

  const toggleStar = (id: string) => {
    setStarred(s => ({ ...s, [id]: !s[id] }))
    toast({ title: starred[id] ? "Removed from starred" : "Added to starred" })
  }

  const totalSize = files.reduce((sum, f) => sum + f.size, 0)
  const sharedCount = files.filter(f => f.shared).length
  const starredCount = Object.values(starred).filter(Boolean).length

  return (
    <DashboardShell
      title="Files"
      description="Store, organize, and share your team's documents and assets."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast({ title: "Upload started", description: "Drag files into the dropzone below." })}>
          <Upload className="w-4 h-4" /> Upload
        </Button>
      }
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Files</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4">
        {/* Sidebar */}
        <aside className="space-y-4">
          <Card className="p-3">
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-2">Library</p>
            <nav className="space-y-0.5">
              {sidebarFilters.map(f => {
                const Icon = f.icon
                const active = activeFilter === f.key
                return (
                  <button
                    key={f.key}
                    onClick={() => setActiveFilter(f.key)}
                    className={cn(
                      "w-full flex items-center justify-between gap-2 px-2.5 py-2 rounded-lg text-sm transition-colors",
                      active ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-muted hover:text-foreground"
                    )}
                  >
                    <span className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4" /> {f.label}
                    </span>
                    <span className="text-[10px] text-muted-foreground">{f.count}</span>
                  </button>
                )
              })}
            </nav>
          </Card>

          <Card className="p-3">
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-2">Folders</p>
            <nav className="space-y-0.5 max-h-72 overflow-y-auto scroll-area-thin">
              {folders.map(fld => (
                <button key={fld.id} className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
                  <span className={cn("w-5 h-5 rounded-md flex items-center justify-center shrink-0", fld.color)}>
                    <Folder className="w-3 h-3 text-white" />
                  </span>
                  <span className="flex-1 text-left truncate">{fld.name}</span>
                  <span className="text-[10px] text-muted-foreground">{fld.files}</span>
                </button>
              ))}
            </nav>
          </Card>

          <Card className="p-4">
            <p className="text-xs font-semibold mb-3">Storage</p>
            <div className="h-2 rounded-full bg-muted overflow-hidden mb-2">
              <div className="h-full bg-primary rounded-full" style={{ width: "42%" }} />
            </div>
            <p className="text-[11px] text-muted-foreground">{formatFileSize(totalSize)} of 1 TB used</p>
            <p className="text-[10px] text-muted-foreground mt-2">{files.length} files · {sharedCount} shared · {starredCount} starred</p>
          </Card>
        </aside>

        {/* Main */}
        <div className="space-y-4 min-w-0">
          {/* Upload dropzone */}
          <Card className="p-4 md:p-5 border-dashed border-2 bg-secondary/20">
            <div className="flex flex-col items-center justify-center text-center py-6">
              <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center mb-3">
                <Upload className="w-5 h-5 text-primary" />
              </div>
              <p className="text-sm font-semibold text-foreground">Drop files here to upload</p>
              <p className="text-xs text-muted-foreground mb-3">or click to browse — up to 50MB per file</p>
              <Button size="sm" variant="outline" className="h-8 text-xs gap-1.5 bg-transparent" onClick={() => toast({ title: "File picker", description: "Browse dialog would open here." })}>
                <Upload className="w-3.5 h-3.5" /> Browse files
              </Button>
            </div>
          </Card>

          {/* Toolbar */}
          <div className="flex flex-col md:flex-row md:items-center gap-3 md:gap-2">
            <div className="relative flex-1 min-w-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search files, owners, projects…"
                value={query}
                onChange={e => setQuery(e.target.value)}
                className="pl-9 h-9 text-sm"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* Type filter */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent">
                    <FileBox className="w-3.5 h-3.5" />
                    {typeFilters.find(t => t.key === typeFilter)?.label}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-44">
                  {typeFilters.map(t => (
                    <DropdownMenuItem key={t.key} onClick={() => setTypeFilter(t.key)} className={cn("text-xs", typeFilter === t.key && "bg-primary/10")}>
                      {t.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Sort */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent capitalize">
                    Sort: {sort}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-40">
                  <DropdownMenuItem onClick={() => setSort("name")} className={cn("text-xs", sort === "name" && "bg-primary/10")}>Name (A–Z)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSort("size")} className={cn("text-xs", sort === "size" && "bg-primary/10")}>Size (large first)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSort("modified")} className={cn("text-xs", sort === "modified" && "bg-primary/10")}>Modified (recent)</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* View toggle */}
              <div className="flex items-center rounded-lg border border-border p-0.5 bg-card">
                <button
                  onClick={() => setView("grid")}
                  className={cn("h-8 w-8 rounded-md flex items-center justify-center transition-colors", view === "grid" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}
                  aria-label="Grid view"
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setView("list")}
                  className={cn("h-8 w-8 rounded-md flex items-center justify-center transition-colors", view === "list" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}
                  aria-label="List view"
                >
                  <ListIcon className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Folder row (only on All files) */}
          {activeFilter === "all" && view === "grid" && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2.5">Folders</p>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                {folders.map(fld => (
                  <Card key={fld.id} className="p-3 card-lift group cursor-pointer">
                    <div className="flex items-center gap-2.5">
                      <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center shrink-0", fld.color)}>
                        <Folder className="w-4 h-4 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-foreground truncate group-hover:text-primary transition-colors">{fld.name}</p>
                        <p className="text-[10px] text-muted-foreground">{fld.files} files</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Files */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{filtered.length} files</p>
            </div>

            {filtered.length === 0 ? (
              <Card className="p-8 flex flex-col items-center text-center border-dashed">
                <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-3">
                  <FileIcon className="w-5 h-5 text-muted-foreground" />
                </div>
                <p className="text-sm font-semibold mb-1">No files found</p>
                <p className="text-xs text-muted-foreground">Try a different filter or search term.</p>
              </Card>
            ) : view === "grid" ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                {filtered.map((f, i) => (
                  <FileGridCard key={f.id} file={f} starred={!!starred[f.id]} onStar={toggleStar} index={i} toast={toast} />
                ))}
              </div>
            ) : (
              <Card className="overflow-hidden">
                <div className="grid grid-cols-[1.5fr_1fr_1fr_0.8fr_auto] gap-3 px-4 py-2.5 border-b border-border text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
                  <span>Name</span><span className="hidden md:block">Owner</span><span className="hidden sm:block">Size</span><span>Modified</span><span className="sr-only">Actions</span>
                </div>
                <div className="divide-y divide-border">
                  {filtered.map((f, i) => (
                    <FileListRow key={f.id} file={f} starred={!!starred[f.id]} onStar={toggleStar} index={i} toast={toast} />
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}

// ---------- Grid card ----------
function FileGridCard({ file, starred, onStar, index, toast }: { file: FileItem; starred: boolean; onStar: (id: string) => void; index: number; toast: any }) {
  const Icon = fileIcons[file.type] ?? FileIcon
  return (
    <Card
      className="p-3 card-lift group cursor-pointer animate-slide-in-up"
      style={{ animationDelay: `${Math.min(index * 40, 320)}ms` }}
    >
      <div className="flex items-start gap-3">
        <Link href={`/files/${file.id}`} className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0", fileTypeColors[file.type] ?? "bg-muted text-muted-foreground")}>
          <Icon className="w-4 h-4" />
        </Link>
        <div className="flex-1 min-w-0">
          <Link href={`/files/${file.id}`}>
            <p className="text-xs font-semibold text-foreground truncate group-hover:text-primary transition-colors">{file.name}</p>
          </Link>
          <p className="text-[10px] text-muted-foreground mt-0.5">{formatFileSize(file.size)} · {timeAgo(file.modifiedAt)}</p>
          <div className="flex items-center gap-1.5 mt-2">
            <Avatar className="w-4 h-4">
              <AvatarImage src={file.ownerAvatar} alt={file.owner} />
              <AvatarFallback className="text-[8px]">{initials(file.owner)}</AvatarFallback>
            </Avatar>
            <span className="text-[10px] text-muted-foreground truncate">{file.owner.split(" ")[0]}</span>
            {file.shared && <Badge variant="outline" className="text-[9px] h-4 px-1">Shared</Badge>}
          </div>
        </div>
        <button
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); onStar(file.id) }}
          className="text-muted-foreground hover:text-amber-500 transition-colors"
          aria-label="Star file"
        >
          <Star className={cn("w-3.5 h-3.5", starred && "fill-amber-500 text-amber-500")} />
        </button>
      </div>
      <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-border">
        <Badge variant="outline" className="text-[9px] h-4 px-1.5">{fileTypeLabels[file.type]}</Badge>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="text-muted-foreground hover:text-foreground transition-colors p-1 -m-1" aria-label="More actions">
              <MoreHorizontal className="w-3.5 h-3.5" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40">
            <DropdownMenuItem onClick={() => toast({ title: "Downloading", description: file.name })} className="text-xs gap-2"><Download className="w-3.5 h-3.5" /> Download</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast({ title: "Share link copied", description: file.name })} className="text-xs gap-2"><Share2 className="w-3.5 h-3.5" /> Share</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast({ title: "Rename", description: "Rename dialog would open" })} className="text-xs gap-2"><Pencil className="w-3.5 h-3.5" /> Rename</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => toast({ title: "Moved to trash", description: file.name, variant: "destructive" })} className="text-xs gap-2 text-destructive"><Trash2 className="w-3.5 h-3.5" /> Delete</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </Card>
  )
}

// ---------- List row ----------
function FileListRow({ file, starred, onStar, index, toast }: { file: FileItem; starred: boolean; onStar: (id: string) => void; index: number; toast: any }) {
  const Icon = fileIcons[file.type] ?? FileIcon
  return (
    <div
      className="grid grid-cols-[1.5fr_1fr_1fr_0.8fr_auto] gap-3 px-4 py-2.5 hover:bg-muted/50 transition-colors items-center group animate-fade-in"
      style={{ animationDelay: `${Math.min(index * 30, 280)}ms` }}
    >
      <div className="flex items-center gap-2.5 min-w-0">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", fileTypeColors[file.type] ?? "bg-muted text-muted-foreground")}>
          <Icon className="w-4 h-4" />
        </div>
        <Link href={`/files/${file.id}`} className="min-w-0">
          <p className="text-xs font-semibold text-foreground truncate group-hover:text-primary transition-colors">{file.name}</p>
          <p className="text-[10px] text-muted-foreground md:hidden">{file.owner.split(" ")[0]} · {formatFileSize(file.size)}</p>
        </Link>
      </div>
      <div className="hidden md:flex items-center gap-2 min-w-0">
        <Avatar className="w-5 h-5">
          <AvatarImage src={file.ownerAvatar} alt={file.owner} />
          <AvatarFallback className="text-[9px]">{initials(file.owner)}</AvatarFallback>
        </Avatar>
        <span className="text-xs text-muted-foreground truncate">{file.owner}</span>
      </div>
      <div className="hidden sm:block text-xs text-muted-foreground">{formatFileSize(file.size)}</div>
      <div className="text-xs text-muted-foreground">{timeAgo(file.modifiedAt)}</div>
      <div className="flex items-center justify-end gap-0.5">
        <button
          onClick={() => onStar(file.id)}
          className="text-muted-foreground hover:text-amber-500 transition-colors p-1.5 rounded-md hover:bg-muted"
          aria-label="Star file"
        >
          <Star className={cn("w-3.5 h-3.5", starred && "fill-amber-500 text-amber-500")} />
        </button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="text-muted-foreground hover:text-foreground transition-colors p-1.5 rounded-md hover:bg-muted" aria-label="More actions">
              <MoreHorizontal className="w-3.5 h-3.5" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40">
            <DropdownMenuItem onClick={() => toast({ title: "Downloading", description: file.name })} className="text-xs gap-2"><Download className="w-3.5 h-3.5" /> Download</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast({ title: "Share link copied", description: file.name })} className="text-xs gap-2"><Share2 className="w-3.5 h-3.5" /> Share</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast({ title: "Rename", description: "Rename dialog would open" })} className="text-xs gap-2"><Pencil className="w-3.5 h-3.5" /> Rename</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => toast({ title: "Moved to trash", description: file.name, variant: "destructive" })} className="text-xs gap-2 text-destructive"><Trash2 className="w-3.5 h-3.5" /> Delete</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}
