"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  Home, Search, FileText, Calendar, RefreshCw, Users, FileBarChart, MessageSquare,
  ClipboardList, Star, Clock, Plus, FileBox, Sparkles,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn, timeAgo, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

type Template = {
  id: string
  name: string
  description: string
  icon: any
  color: string
  category: string
  lastUsed: string
  uses: number
  recentlyUsed?: boolean
}

const templates: Template[] = [
  { id: "t1", name: "Meeting notes", description: "Attendees, agenda, decisions, action items. Auto-tags by date and project.", icon: MessageSquare, color: "bg-emerald-500", category: "Meetings", lastUsed: "2026-02-12", uses: 142, recentlyUsed: true },
  { id: "t2", name: "PRD", description: "Problem, goals, user stories, success metrics, rollout plan, open questions.", icon: FileText, color: "bg-teal-500", category: "Product", lastUsed: "2026-02-10", uses: 38, recentlyUsed: true },
  { id: "t3", name: "Sprint retro", description: "What went well, what didn't, action items with owners and due dates.", icon: RefreshCw, color: "bg-lime-500", category: "Meetings", lastUsed: "2026-02-09", uses: 64, recentlyUsed: true },
  { id: "t4", name: "Daily standup", description: "Yesterday, today, blockers. One-line-per-item format with assignee chips.", icon: Calendar, color: "bg-cyan-500", category: "Meetings", lastUsed: "2026-02-12", uses: 218, recentlyUsed: true },
  { id: "t5", name: "1:1 meeting", description: "Topics, discussion notes, commitments, follow-ups. Tracks long-term goals.", icon: Users, color: "bg-green-500", category: "People", lastUsed: "2026-02-08", uses: 91 },
  { id: "t6", name: "Performance review", description: "Quarterly self-assessment, manager feedback, growth plan, calibration notes.", icon: FileBarChart, color: "bg-amber-500", category: "People", lastUsed: "2026-01-29", uses: 24 },
  { id: "t7", name: "Project brief", description: "Background, scope, milestones, risks, stakeholders, RACI matrix.", icon: FileBox, color: "bg-orange-500", category: "Product", lastUsed: "2026-02-01", uses: 47 },
  { id: "t8", name: "Launch checklist", description: "Pre-launch, launch day, post-launch tasks with owners and status.", icon: ClipboardList, color: "bg-pink-500", category: "Operations", lastUsed: "2026-01-22", uses: 18 },
  { id: "t9", name: "Incident postmortem", description: "Timeline, impact, root cause, contributing factors, action items.", icon: FileText, color: "bg-rose-500", category: "Engineering", lastUsed: "2026-01-15", uses: 9 },
  { id: "t10", name: "Design review", description: "Context, explorations, recommendation, open questions, next steps.", icon: Sparkles, color: "bg-violet-500", category: "Design", lastUsed: "2026-02-05", uses: 31 },
]

const categories = [
  { key: "all", label: "All templates", icon: FileBox },
  { key: "Meetings", label: "Meetings", icon: Calendar },
  { key: "Product", label: "Product", icon: FileText },
  { key: "People", label: "People", icon: Users },
  { key: "Operations", label: "Operations", icon: ClipboardList },
  { key: "Engineering", label: "Engineering", icon: FileBox },
  { key: "Design", label: "Design", icon: Sparkles },
]

export default function TemplatesPage() {
  const { toast } = useToast()
  const [category, setCategory] = useState<string>("all")
  const [query, setQuery] = useState("")

  const filtered = useMemo(() => {
    let list = [...templates]
    if (category !== "all") list = list.filter(t => t.category === category)
    if (query.trim()) {
      const q = query.toLowerCase()
      list = list.filter(t => t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q) || t.category.toLowerCase().includes(q))
    }
    return list
  }, [category, query])

  const recent = templates.filter(t => t.recentlyUsed)
  const totalUses = templates.reduce((s, t) => s + t.uses, 0)

  return (
    <DashboardShell
      title="Templates library"
      description="Start from a proven document template. Customizable, shareable, and tracked."
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbLink asChild><Link href="/files">Files</Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Templates</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast({ title: "New template", description: "Template builder would open." })}>
          <Plus className="w-4 h-4" /> New template
        </Button>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4">
        {/* Sidebar */}
        <aside className="space-y-4">
          <Card className="p-3">
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-2">Categories</p>
            <nav className="space-y-0.5">
              {categories.map(c => {
                const Icon = c.icon
                const active = category === c.key
                const count = c.key === "all" ? templates.length : templates.filter(t => t.category === c.key).length
                return (
                  <button
                    key={c.key}
                    onClick={() => setCategory(c.key)}
                    className={cn(
                      "w-full flex items-center justify-between gap-2 px-2.5 py-2 rounded-lg text-sm transition-colors",
                      active ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-muted hover:text-foreground"
                    )}
                  >
                    <span className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4" /> {c.label}
                    </span>
                    <span className="text-[10px] text-muted-foreground">{count}</span>
                  </button>
                )
              })}
            </nav>
          </Card>

          <Card className="p-4">
            <p className="text-xs font-semibold mb-3">Library stats</p>
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-muted-foreground">Templates</span>
                <span className="text-xs font-semibold">{templates.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-muted-foreground">Total uses</span>
                <span className="text-xs font-semibold">{totalUses}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-muted-foreground">Categories</span>
                <span className="text-xs font-semibold">{categories.length - 1}</span>
              </div>
            </div>
          </Card>
        </aside>

        {/* Main */}
        <div className="space-y-6 min-w-0">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search templates…"
              value={query}
              onChange={e => setQuery(e.target.value)}
              className="pl-9 h-9 text-sm"
            />
          </div>

          {/* Recently used */}
          {category === "all" && !query && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Clock className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Recently used</h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {recent.map((t, i) => (
                  <TemplateCard key={t.id} t={t} index={i} toast={toast} highlight />
                ))}
              </div>
            </div>
          )}

          {/* All templates */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <FileBox className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">{category === "all" ? "All templates" : category}</h3>
                <Badge variant="outline" className="text-[10px]">{filtered.length}</Badge>
              </div>
            </div>
            {filtered.length === 0 ? (
              <Card className="p-8 flex flex-col items-center text-center border-dashed">
                <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-3">
                  <FileText className="w-5 h-5 text-muted-foreground" />
                </div>
                <p className="text-sm font-semibold mb-1">No templates found</p>
                <p className="text-xs text-muted-foreground">Try a different category or search term.</p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {filtered.map((t, i) => (
                  <TemplateCard key={t.id} t={t} index={i} toast={toast} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}

function TemplateCard({ t, index, toast, highlight }: { t: Template; index: number; toast: any; highlight?: boolean }) {
  const Icon = t.icon
  return (
    <Card
      className={cn("p-4 card-lift group cursor-pointer animate-slide-in-up", highlight && "ring-1 ring-primary/30")}
      style={{ animationDelay: `${Math.min(index * 40, 320)}ms` }}
    >
      <div className="flex items-start gap-3 mb-3">
        <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110", t.color)}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{t.name}</p>
          <Badge variant="outline" className="text-[10px] mt-0.5">{t.category}</Badge>
        </div>
        <button
          className="text-muted-foreground hover:text-amber-500 transition-colors p-1 -m-1"
          aria-label="Favorite"
          onClick={(e) => { e.stopPropagation(); toast({ title: "Added to favorites" }) }}
        >
          <Star className="w-3.5 h-3.5" />
        </button>
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed mb-3 line-clamp-2">{t.description}</p>
      <div className="flex items-center justify-between pt-3 border-t border-border">
        <div className="flex items-center gap-2">
          <Avatar className="w-5 h-5">
            <AvatarImage src={members[0].avatar} alt="You" />
            <AvatarFallback className="text-[9px]">JS</AvatarFallback>
          </Avatar>
          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
            <Clock className="w-3 h-3" /> {timeAgo(t.lastUsed)}
          </div>
        </div>
        <Button
          size="sm"
          className="h-7 text-xs gap-1 bg-primary text-primary-foreground hover:bg-primary/90"
          onClick={() => toast({ title: "Creating from template", description: t.name })}
        >
          <Plus className="w-3 h-3" /> Use
        </Button>
      </div>
    </Card>
  )
}
