"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Home, Download, FileText, Image as ImageIcon, FileBox, Video, Music,
  Archive, Code, File as FileIcon, Link2, Filter, ChevronDown,
} from "lucide-react"
import { files, projects } from "@/lib/data/mock"
import { cn, formatFileSize, timeAgo, formatDate, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import type { FileItem } from "@/types"

const fileIcons: Record<string, any> = {
  pdf: FileText, document: FileText, spreadsheet: FileBox, presentation: FileText,
  image: ImageIcon, video: Video, audio: Music, archive: Archive, code: Code,
}

const fileTypeColors: Record<string, string> = {
  pdf: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  document: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  spreadsheet: "bg-teal-500/15 text-teal-600 dark:text-teal-400",
  presentation: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  image: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400",
  video: "bg-orange-500/15 text-orange-600 dark:text-orange-400",
  audio: "bg-pink-500/15 text-pink-600 dark:text-pink-400",
  archive: "bg-lime-500/15 text-lime-600 dark:text-lime-400",
  code: "bg-green-500/15 text-green-600 dark:text-green-400",
}

// Mock task link data — build synthetic attachments by reusing files and assigning a task + project
const taskAttachments = files.map((f, i) => {
  const tasks = [
    { id: "PLN-101", title: "Implement command palette keyboard navigation", projectId: "p1", projectName: "Planna Web App" },
    { id: "PLN-103", title: "Design system tokens documentation", projectId: "p4", projectName: "Design System 2.0" },
    { id: "API-302", title: "v2 endpoint deprecation notice", projectId: "p3", projectName: "Public API Platform" },
    { id: "ACME-12", title: "Acme SSO integration kickoff", projectId: "p5", projectName: "Acme Client Project" },
    { id: "MOB-44", title: "Mobile onboarding video walkthrough", projectId: "p2", projectName: "Mobile Companion" },
    { id: "SEC-7", title: "Pen test remediation tracker", projectId: "p12", projectName: "Security Audit" },
    { id: "PLN-110", title: "Sprint 47 review prep", projectId: "p1", projectName: "Planna Web App" },
    { id: "QA-22", title: "Burndown chart automation", projectId: "p7", projectName: "Test Automation Suite" },
    { id: "DOC-3", title: "Documentation portal launch", projectId: "p11", projectName: "Documentation Portal" },
    { id: "PLN-115", title: "Team photo for about page", projectId: "p1", projectName: "Planna Web App" },
  ]
  return { ...f, task: tasks[i % tasks.length] }
})

const projectOptions = [
  { value: "all", label: "All projects" },
  ...Array.from(new Set(taskAttachments.map(a => a.task.projectName))).map(name => ({ value: name, label: name })),
]

export default function AttachmentsPage() {
  const { toast } = useToast()
  const [projectFilter, setProjectFilter] = useState<string>("all")
  const [selected, setSelected] = useState<Set<string>>(new Set())

  const filtered = useMemo(() => {
    if (projectFilter === "all") return taskAttachments
    return taskAttachments.filter(a => a.task.projectName === projectFilter)
  }, [projectFilter])

  const toggleSelect = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const toggleSelectAll = () => {
    setSelected(prev => prev.size === filtered.length ? new Set() : new Set(filtered.map(a => a.id)))
  }

  return (
    <DashboardShell
      title="Task attachments"
      description="Every file attached to a task, in one place. Filter, select, and bulk download."
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbLink asChild><Link href="/files">Files</Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Attachments</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
      actions={
        <Button
          className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
          disabled={selected.size === 0}
          onClick={() => toast({ title: "Bulk download started", description: `${selected.size} files queued` })}
        >
          <Download className="w-4 h-4" /> Download {selected.size > 0 ? `(${selected.size})` : "all"}
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <Card className="p-4 card-lift">
          <div className="w-9 h-9 rounded-lg bg-primary/15 text-primary flex items-center justify-center mb-2"><FileBox className="w-4 h-4" /></div>
          <p className="text-2xl font-bold text-foreground">{taskAttachments.length}</p>
          <p className="text-xs text-muted-foreground">Total attachments</p>
        </Card>
        <Card className="p-4 card-lift">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-2"><Link2 className="w-4 h-4" /></div>
          <p className="text-2xl font-bold text-foreground">{new Set(taskAttachments.map(a => a.task.id)).size}</p>
          <p className="text-xs text-muted-foreground">Linked tasks</p>
        </Card>
        <Card className="p-4 card-lift">
          <div className="w-9 h-9 rounded-lg bg-teal-500/15 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-2"><FileBox className="w-4 h-4" /></div>
          <p className="text-2xl font-bold text-foreground">{new Set(taskAttachments.map(a => a.task.projectName)).size}</p>
          <p className="text-xs text-muted-foreground">Projects</p>
        </Card>
        <Card className="p-4 card-lift">
          <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-2"><Download className="w-4 h-4" /></div>
          <p className="text-2xl font-bold text-foreground">{formatFileSize(taskAttachments.reduce((s, a) => s + a.size, 0))}</p>
          <p className="text-xs text-muted-foreground">Total size</p>
        </Card>
      </div>

      {/* Toolbar */}
      <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <Checkbox
            checked={filtered.length > 0 && selected.size === filtered.length}
            onCheckedChange={toggleSelectAll}
            aria-label="Select all"
          />
          <span className="text-xs text-muted-foreground">
            {selected.size > 0 ? `${selected.size} selected` : `${filtered.length} attachments`}
          </span>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent">
              <Filter className="w-3.5 h-3.5" /> {projectOptions.find(p => p.value === projectFilter)?.label}
              <ChevronDown className="w-3 h-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 max-h-72 overflow-y-auto scroll-area-thin">
            {projectOptions.map(p => (
              <DropdownMenuItem key={p.value} onClick={() => setProjectFilter(p.value)} className={cn("text-xs", projectFilter === p.value && "bg-primary/10")}>
                {p.label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* List */}
      <Card className="overflow-hidden">
        <div className="hidden md:grid grid-cols-[28px_2fr_1.5fr_1fr_0.8fr_auto] gap-3 px-4 py-2.5 border-b border-border text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
          <span />
          <span>File</span>
          <span>Task</span>
          <span>Owner</span>
          <span>Size</span>
          <span>Date</span>
        </div>
        <div className="divide-y divide-border">
          {filtered.map((a, i) => {
            const Icon = fileIcons[a.type] ?? FileIcon
            const isSelected = selected.has(a.id)
            return (
              <div
                key={a.id}
                className={cn(
                  "grid grid-cols-[28px_1fr_auto] md:grid-cols-[28px_2fr_1.5fr_1fr_0.8fr_auto] gap-3 px-4 py-3 items-center hover:bg-muted/50 transition-colors group animate-fade-in",
                  isSelected && "bg-primary/5"
                )}
                style={{ animationDelay: `${Math.min(i * 25, 250)}ms` }}
              >
                <Checkbox checked={isSelected} onCheckedChange={() => toggleSelect(a.id)} aria-label={`Select ${a.name}`} />

                <div className="flex items-center gap-2.5 min-w-0">
                  <Link href={`/files/${a.id}`} className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", fileTypeColors[a.type] ?? "bg-muted text-muted-foreground")}>
                    <Icon className="w-4 h-4" />
                  </Link>
                  <div className="min-w-0">
                    <Link href={`/files/${a.id}`}>
                      <p className="text-xs font-semibold text-foreground truncate group-hover:text-primary transition-colors">{a.name}</p>
                    </Link>
                    <p className="text-[10px] text-muted-foreground md:hidden">{a.task.projectName} · {formatFileSize(a.size)}</p>
                  </div>
                </div>

                <div className="hidden md:flex items-center gap-2 min-w-0">
                  <Link2 className="w-3.5 h-3.5 text-primary shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-foreground truncate group-hover:text-primary transition-colors">{a.task.title}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{a.task.projectName}</p>
                  </div>
                </div>

                <div className="hidden md:flex items-center gap-2 min-w-0">
                  <Avatar className="w-5 h-5 shrink-0">
                    <AvatarImage src={a.ownerAvatar} alt={a.owner} />
                    <AvatarFallback className="text-[9px]">{initials(a.owner)}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground truncate">{a.owner}</span>
                </div>

                <div className="hidden md:block text-xs text-muted-foreground">{formatFileSize(a.size)}</div>

                <div className="flex items-center justify-end gap-1">
                  <span className="text-[10px] text-muted-foreground mr-1 hidden md:inline">{formatDate(a.modifiedAt, { month: "short", day: "numeric" })}</span>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="text-muted-foreground hover:text-foreground transition-colors p-1.5 rounded-md hover:bg-muted" aria-label="More actions">
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40">
                      <DropdownMenuItem onClick={() => toast({ title: "Downloading", description: a.name })} className="text-xs gap-2"><Download className="w-3.5 h-3.5" /> Download</DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-xs gap-2">
                        <Link href={`/files/${a.id}`}><FileText className="w-3.5 h-3.5" /> Open file</Link>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      {filtered.length === 0 && (
        <Card className="p-8 flex flex-col items-center text-center border-dashed mt-3">
          <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-3">
            <FileIcon className="w-5 h-5 text-muted-foreground" />
          </div>
          <p className="text-sm font-semibold mb-1">No attachments in this project</p>
          <p className="text-xs text-muted-foreground">Try a different project filter.</p>
        </Card>
      )}
    </DashboardShell>
  )
}
