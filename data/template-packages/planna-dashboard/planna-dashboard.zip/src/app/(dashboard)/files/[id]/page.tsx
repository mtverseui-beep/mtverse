"use client"

import { use, useState } from "react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  ArrowLeft, Download, Share2, Pencil, Trash2, Star, Home, FileText, Image as ImageIcon,
  FileBox, Video, Music, Archive, Code, File as FileIcon, History, MessageSquare, Send,
  Clock, Folder, Globe, Lock, CheckCircle2,
} from "lucide-react"
import { files, members } from "@/lib/data/mock"
import { cn, formatFileSize, timeAgo, formatDate, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

const fileIcons: Record<string, any> = {
  pdf: FileText, document: FileText, spreadsheet: FileBox, presentation: FileText,
  image: ImageIcon, video: Video, audio: Music, archive: Archive, code: Code,
}

const fileTypeColors: Record<string, string> = {
  pdf: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  document: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  spreadsheet: "bg-teal-500/15 text-teal-600 dark:text-teal-400",
  presentation: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  image: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400",
  video: "bg-orange-500/15 text-orange-600 dark:text-orange-400",
  audio: "bg-pink-500/15 text-pink-600 dark:text-pink-400",
  archive: "bg-lime-500/15 text-lime-600 dark:text-lime-400",
  code: "bg-green-500/15 text-green-600 dark:text-green-400",
}

// Mock version history + comments
const versionHistory = [
  { id: "v3", version: "v3", author: "Zara Marlowe", authorAvatar: "", note: "Updated Q1 milestones", at: new Date(Date.now() - 1 * 86400_000).toISOString(), size: 2_400_000, current: true },
  { id: "v2", version: "v2", author: "Theo Nakamura", authorAvatar: "", note: "Added API section", at: new Date(Date.now() - 4 * 86400_000).toISOString(), size: 2_180_000, current: false },
  { id: "v1", version: "v1", author: "Zara Marlowe", authorAvatar: "", note: "Initial upload", at: new Date(Date.now() - 9 * 86400_000).toISOString(), size: 1_940_000, current: false },
]

const initialComments = [
  { id: "c1", author: "Theo Nakamura", authorAvatar: members[2].avatar, body: "Can we add the API release date to page 4? Need to align with the migration plan.", at: new Date(Date.now() - 5 * 3600_000).toISOString() },
  { id: "c2", author: "Zara Marlowe", authorAvatar: members[1].avatar, body: "Good catch — pushed in v3. Also added a Gantt chart on page 6.", at: new Date(Date.now() - 3 * 3600_000).toISOString() },
  { id: "c3", author: "Naomi Chen", authorAvatar: members[7].avatar, body: "Reviewed. Looks good to ship to the client.", at: new Date(Date.now() - 1 * 3600_000).toISOString() },
]

const sharedWith = members.slice(1, 5)

export default function FileDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const file = files.find(f => f.id === id)
  if (!file) notFound()

  const { toast } = useToast()
  const [starred, setStarred] = useState(file.starred)
  const [comments, setComments] = useState(initialComments)
  const [comment, setComment] = useState("")

  const Icon = fileIcons[file.type] ?? FileIcon

  const submitComment = () => {
    if (!comment.trim()) return
    setComments(c => [...c, {
      id: `c${c.length + 1}`,
      author: "You",
      authorAvatar: members[0].avatar,
      body: comment.trim(),
      at: new Date().toISOString(),
    }])
    setComment("")
    toast({ title: "Comment posted" })
  }

  return (
    <DashboardShell
      title={file.name}
      description={`${file.type.toUpperCase()} · ${formatFileSize(file.size)} · ${timeAgo(file.modifiedAt)}`}
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbLink asChild><Link href="/files">Files</Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage className="max-w-[200px] truncate">{file.name}</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
      actions={
        <>
          <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Link href="/files"><ArrowLeft className="w-4 h-4" /> Back</Link>
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast({ title: "Downloading", description: file.name })}>
            <Download className="w-4 h-4" /> Download
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-4">
        {/* Main column */}
        <div className="space-y-4 min-w-0">
          {/* Preview area */}
          <Card className="overflow-hidden card-lift">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-2">
                <span className={cn("w-7 h-7 rounded-md flex items-center justify-center", fileTypeColors[file.type] ?? "bg-muted text-muted-foreground")}>
                  <Icon className="w-3.5 h-3.5" />
                </span>
                <div>
                  <p className="text-xs font-semibold text-foreground truncate max-w-[280px]">{file.name}</p>
                  <p className="text-[10px] text-muted-foreground">{file.mimeType}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast({ title: "Share link copied" })}>
                  <Share2 className="w-3.5 h-3.5" /> Share
                </Button>
                <Button variant="ghost" size="sm" className="h-8 text-xs gap-1.5" onClick={() => toast({ title: "Rename dialog would open" })}>
                  <Pencil className="w-3.5 h-3.5" /> Rename
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setStarred(s => !s); toast({ title: starred ? "Removed from starred" : "Added to starred" }) }}>
                  <Star className={cn("w-4 h-4", starred && "fill-amber-500 text-amber-500")} />
                </Button>
              </div>
            </div>

            {/* Preview body */}
            <div className="bg-muted/30 flex items-center justify-center min-h-[420px] md:min-h-[520px] p-6 md:p-10">
              {file.type === "image" && file.url !== "#" ? (
                <img src={file.url} alt={file.name} className="max-h-[460px] md:max-h-[560px] max-w-full object-contain rounded-lg shadow-lg animate-scale-in" />
              ) : (
                <div className="flex flex-col items-center text-center max-w-sm">
                  <div className={cn("w-24 h-24 rounded-2xl flex items-center justify-center mb-4 animate-scale-in", fileTypeColors[file.type] ?? "bg-muted text-muted-foreground")}>
                    <Icon className="w-12 h-12" />
                  </div>
                  <p className="text-sm font-semibold text-foreground mb-1">{file.name}</p>
                  <p className="text-xs text-muted-foreground mb-4">Preview not available for this file type.</p>
                  <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast({ title: "Downloading", description: file.name })}>
                    <Download className="w-3.5 h-3.5" /> Download to view
                  </Button>
                </div>
              )}
            </div>
          </Card>

          {/* Version history */}
          <Card className="p-4 md:p-5">
            <div className="flex items-center gap-2 mb-4">
              <History className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Version history</h3>
              <Badge variant="outline" className="text-[10px]">{versionHistory.length} versions</Badge>
            </div>
            <div className="space-y-2.5">
              {versionHistory.map(v => (
                <div key={v.id} className={cn(
                  "flex items-start gap-3 p-3 rounded-lg border transition-colors",
                  v.current ? "border-primary/40 bg-primary/5" : "border-border hover:bg-muted/50"
                )}>
                  <Avatar className="w-8 h-8 mt-0.5">
                    <AvatarImage src={members.find(m => m.name === v.author)?.avatar} alt={v.author} />
                    <AvatarFallback className="text-[10px]">{initials(v.author)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-mono font-semibold text-foreground">{v.version}</span>
                      {v.current && <Badge className="text-[9px] h-4 px-1.5 bg-primary/15 text-primary">Current</Badge>}
                      <span className="text-[10px] text-muted-foreground">{formatFileSize(v.size)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{v.note}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">{v.author} · {formatDate(v.at, { month: "short", day: "numeric", year: "numeric" })}</p>
                  </div>
                  {!v.current && (
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => toast({ title: `Restoring ${v.version}`, description: "File would be restored to this version." })}>
                      Restore
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </Card>

          {/* Comments */}
          <Card className="p-4 md:p-5">
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Comments</h3>
              <Badge variant="outline" className="text-[10px]">{comments.length}</Badge>
            </div>

            <div className="space-y-4 mb-4 max-h-96 overflow-y-auto scroll-area-thin pr-1">
              {comments.map(c => (
                <div key={c.id} className="flex gap-3 animate-fade-in">
                  <Avatar className="w-8 h-8 shrink-0">
                    <AvatarImage src={c.authorAvatar} alt={c.author} />
                    <AvatarFallback className="text-[10px]">{initials(c.author)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline gap-2">
                      <span className="text-xs font-semibold text-foreground">{c.author}</span>
                      <span className="text-[10px] text-muted-foreground">{timeAgo(c.at)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed mt-0.5 bg-muted/50 rounded-lg px-3 py-2">{c.body}</p>
                  </div>
                </div>
              ))}
            </div>

            <Separator className="my-3" />

            <div className="flex gap-2 items-end">
              <Avatar className="w-8 h-8 shrink-0">
                <AvatarImage src={members[0].avatar} alt="You" />
                <AvatarFallback className="text-[10px]">JS</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <Textarea
                  placeholder="Add a comment…"
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  className="min-h-[60px] text-xs resize-none"
                  onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submitComment() }}
                />
                <p className="text-[10px] text-muted-foreground mt-1">Press Cmd/Ctrl + Enter to post</p>
              </div>
              <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5 h-9" onClick={submitComment} disabled={!comment.trim()}>
                <Send className="w-3.5 h-3.5" /> Post
              </Button>
            </div>
          </Card>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          <Card className="p-4">
            <p className="text-xs font-semibold mb-3">File details</p>
            <dl className="space-y-3">
              <div className="flex items-center justify-between">
                <dt className="text-[11px] text-muted-foreground flex items-center gap-1.5"><Folder className="w-3 h-3" /> Project</dt>
                <dd className="text-xs font-medium text-right truncate max-w-[180px]">{file.project ?? "Unfiled"}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-[11px] text-muted-foreground flex items-center gap-1.5"><FileIcon className="w-3 h-3" /> Type</dt>
                <dd className="text-xs font-medium uppercase">{file.type}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-[11px] text-muted-foreground flex items-center gap-1.5"><FileBox className="w-3 h-3" /> Size</dt>
                <dd className="text-xs font-medium">{formatFileSize(file.size)}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-[11px] text-muted-foreground flex items-center gap-1.5"><Clock className="w-3 h-3" /> Modified</dt>
                <dd className="text-xs font-medium">{timeAgo(file.modifiedAt)}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-[11px] text-muted-foreground flex items-center gap-1.5">{file.shared ? <Globe className="w-3 h-3" /> : <Lock className="w-3 h-3" />} Access</dt>
                <dd className="text-xs font-medium">{file.shared ? "Shared" : "Private"}</dd>
              </div>
            </dl>
          </Card>

          <Card className="p-4">
            <p className="text-xs font-semibold mb-3">Owner</p>
            <div className="flex items-center gap-3">
              <Avatar className="w-9 h-9">
                <AvatarImage src={file.ownerAvatar} alt={file.owner} />
                <AvatarFallback className="text-xs">{initials(file.owner)}</AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-foreground truncate">{file.owner}</p>
                <p className="text-[10px] text-muted-foreground">File owner</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold">Shared with</p>
              <Badge variant="outline" className="text-[10px]">{file.shared ? sharedWith.length : 0}</Badge>
            </div>
            {file.shared ? (
              <div className="space-y-2.5">
                {sharedWith.map(m => (
                  <div key={m.id} className="flex items-center gap-2.5">
                    <Avatar className="w-7 h-7">
                      <AvatarImage src={m.avatar} alt={m.name} />
                      <AvatarFallback className="text-[10px]">{initials(m.name)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                      <p className="text-[10px] text-muted-foreground">{m.title}</p>
                    </div>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4">
                <Lock className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
                <p className="text-[11px] text-muted-foreground">Only the owner can access this file.</p>
                <Button size="sm" variant="outline" className="h-7 text-xs mt-2 gap-1.5 bg-transparent" onClick={() => toast({ title: "Share link copied" })}>
                  <Share2 className="w-3 h-3" /> Share
                </Button>
              </div>
            )}
          </Card>

          <Card className="p-4">
            <p className="text-xs font-semibold mb-3">Actions</p>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent" onClick={() => toast({ title: "Downloading", description: file.name })}>
                <Download className="w-3.5 h-3.5" /> Download
              </Button>
              <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent" onClick={() => toast({ title: "Share link copied" })}>
                <Share2 className="w-3.5 h-3.5" /> Share
              </Button>
              <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent" onClick={() => toast({ title: "Rename dialog" })}>
                <Pencil className="w-3.5 h-3.5" /> Rename
              </Button>
              <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent text-destructive hover:text-destructive" onClick={() => toast({ title: "Moved to trash", description: file.name, variant: "destructive" })}>
                <Trash2 className="w-3.5 h-3.5" /> Delete
              </Button>
            </div>
          </Card>
        </aside>
      </div>
    </DashboardShell>
  )
}
