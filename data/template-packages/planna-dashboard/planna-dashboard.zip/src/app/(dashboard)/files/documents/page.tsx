"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  Home, Star, Clock, Download, MoreHorizontal,
  FileText, FileBox, Pencil, ChevronRight,
} from "lucide-react"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { files } from "@/lib/data/mock"
import { cn, formatFileSize, timeAgo, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import type { FileItem } from "@/types"

const docIcons: Record<string, any> = {
  pdf: FileText, document: FileText, spreadsheet: FileBox, presentation: FileText,
}

const docTypeColors: Record<string, string> = {
  pdf: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  document: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  spreadsheet: "bg-teal-500/15 text-teal-600 dark:text-teal-400",
  presentation: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
}

const docTypeLabels: Record<string, string> = {
  pdf: "PDF", document: "DOC", spreadsheet: "XLS", presentation: "PPT",
}

const docTypes = ["pdf", "document", "spreadsheet", "presentation"]

export default function DocumentsPage() {
  const { toast } = useToast()

  const docFiles = useMemo(() => files.filter(f => docTypes.includes(f.type)), [])

  const recent = useMemo(() =>
    [...docFiles].sort((a, b) => new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime()).slice(0, 4)
  , [docFiles])

  // Group by project
  const grouped = useMemo(() => {
    const map = new Map<string, FileItem[]>()
    docFiles.forEach(f => {
      const key = f.project ?? "Unfiled"
      if (!map.has(key)) map.set(key, [])
      map.get(key)!.push(f)
    })
    return Array.from(map.entries())
  }, [docFiles])

  return (
    <DashboardShell
      title="Documents"
      description="All your documents — PDFs, spreadsheets, presentations, and word docs."
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbLink asChild><Link href="/files">Files</Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Documents</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
      actions={
        <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent" onClick={() => toast({ title: "Bulk download started", description: `${docFiles.length} documents queued` })}>
          <Download className="w-4 h-4" /> Download all
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        {[
          { label: "PDFs", value: docFiles.filter(f => f.type === "pdf").length, color: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
          { label: "Spreadsheets", value: docFiles.filter(f => f.type === "spreadsheet").length, color: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
          { label: "Presentations", value: docFiles.filter(f => f.type === "presentation").length, color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
          { label: "Word docs", value: docFiles.filter(f => f.type === "document").length, color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
        ].map(s => (
          <Card key={s.label} className="p-4 card-lift">
            <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center mb-2", s.color)}>
              <FileText className="w-4 h-4" />
            </div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </Card>
        ))}
      </div>

      {/* Recently edited */}
      <Card className="p-4 md:p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <Clock className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold">Recently edited</h3>
        </div>
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
          {recent.map((f, i) => {
            const Icon = docIcons[f.type] ?? FileText
            return (
              <Link
                key={f.id}
                href={`/files/${f.id}`}
                className="min-w-[180px] max-w-[180px] shrink-0 group animate-slide-in-up"
                style={{ animationDelay: `${i * 50}ms` }}
              >
                <Card className="p-3 card-lift cursor-pointer h-full">
                  {/* Thumbnail */}
                  <div className={cn("aspect-[4/3] rounded-lg flex items-center justify-center mb-3 relative overflow-hidden", docTypeColors[f.type])}>
                    <Icon className="w-8 h-8" />
                    <Badge className="absolute top-1.5 right-1.5 text-[9px] h-4 px-1.5 bg-card/90 text-foreground">{docTypeLabels[f.type]}</Badge>
                  </div>
                  <p className="text-xs font-semibold text-foreground truncate group-hover:text-primary transition-colors">{f.name}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{timeAgo(f.modifiedAt)}</p>
                </Card>
              </Link>
            )
          })}
        </div>
      </Card>

      {/* Grouped by project */}
      <div className="space-y-6">
        {grouped.map(([project, fileList]) => (
          <div key={project}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <FileBox className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold text-foreground">{project}</h3>
                <Badge variant="outline" className="text-[10px]">{fileList.length}</Badge>
              </div>
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-0.5">
                View all <ChevronRight className="w-3 h-3" />
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {fileList.map((f, i) => (
                <DocumentCard key={f.id} file={f} index={i} toast={toast} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </DashboardShell>
  )
}

function DocumentCard({ file, index, toast }: { file: FileItem; index: number; toast: any }) {
  const Icon = docIcons[file.type] ?? FileText
  return (
    <Card
      className="overflow-hidden card-lift group cursor-pointer animate-slide-in-up"
      style={{ animationDelay: `${Math.min(index * 40, 320)}ms` }}
    >
      <Link href={`/files/${file.id}`}>
        {/* Thumbnail */}
        <div className={cn("aspect-[4/3] flex items-center justify-center relative", docTypeColors[file.type])}>
          <Icon className="w-10 h-10" />
          <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-black/10 to-transparent" />
          <Badge className="absolute top-2 left-2 text-[9px] h-4 px-1.5 bg-card/90 text-foreground">{docTypeLabels[file.type]}</Badge>
          {file.starred && <Star className="absolute top-2 right-2 w-3.5 h-3.5 fill-amber-500 text-amber-500" />}
        </div>
      </Link>
      <div className="p-3">
        <Link href={`/files/${file.id}`}>
          <p className="text-xs font-semibold text-foreground truncate group-hover:text-primary transition-colors">{file.name}</p>
        </Link>
        <p className="text-[10px] text-muted-foreground mt-0.5">{formatFileSize(file.size)} · {timeAgo(file.modifiedAt)}</p>
        <div className="flex items-center justify-between mt-2.5">
          <div className="flex items-center gap-1.5 min-w-0">
            <Avatar className="w-5 h-5">
              <AvatarImage src={file.ownerAvatar} alt={file.owner} />
              <AvatarFallback className="text-[9px]">{initials(file.owner)}</AvatarFallback>
            </Avatar>
            <span className="text-[10px] text-muted-foreground truncate">{file.owner.split(" ")[0]}</span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="text-muted-foreground hover:text-foreground transition-colors p-1 -m-1 opacity-0 group-hover:opacity-100" aria-label="More actions">
                <MoreHorizontal className="w-3.5 h-3.5" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuItem onClick={() => toast({ title: "Downloading", description: file.name })} className="text-xs gap-2"><Download className="w-3.5 h-3.5" /> Download</DropdownMenuItem>
              <DropdownMenuItem onClick={() => toast({ title: "Opening editor" })} className="text-xs gap-2"><Pencil className="w-3.5 h-3.5" /> Edit</DropdownMenuItem>
              <DropdownMenuItem asChild className="text-xs gap-2">
                <Link href={`/files/${file.id}`}>Open preview</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </Card>
  )
}
