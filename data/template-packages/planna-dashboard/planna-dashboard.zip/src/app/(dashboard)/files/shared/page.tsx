"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  Home, Star, MoreHorizontal, Download, Share2, Users, User, Globe, Clock,
  FileText, Image as ImageIcon, FileBox, Video, Music, Archive, Code, File as FileIcon,
  ChevronDown,
} from "lucide-react"
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { files, members } from "@/lib/data/mock"
import { cn, formatFileSize, timeAgo, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import type { FileItem } from "@/types"

const fileIcons: Record<string, any> = {
  pdf: FileText, document: FileText, spreadsheet: FileBox, presentation: FileText,
  image: ImageIcon, video: Video, audio: Music, archive: Archive, code: Code,
}

const fileTypeLabels: Record<string, string> = {
  pdf: "PDF", document: "Document", spreadsheet: "Spreadsheet", presentation: "Presentation",
  image: "Image", video: "Video", audio: "Audio", archive: "Archive", code: "Code",
}

const fileTypeColors: Record<string, string> = {
  pdf: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
  document: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  spreadsheet: "bg-teal-500/15 text-teal-600 dark:text-teal-400",
  presentation: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  image: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400",
  video: "bg-orange-500/15 text-orange-600 dark:text-orange-400",
  audio: "bg-pink-500/15 text-pink-600 dark:text-pink-400",
  archive: "bg-lime-500/15 text-lime-600 dark:text-lime-400",
  code: "bg-green-500/15 text-green-600 dark:text-green-400",
}

type ShareFilter = "all" | "you" | "team" | "external"

const shareFilters: { key: ShareFilter; label: string; icon: any }[] = [
  { key: "all", label: "All shared", icon: Users },
  { key: "you", label: "Shared by you", icon: User },
  { key: "team", label: "Shared with team", icon: Users },
  { key: "external", label: "External", icon: Globe },
]

export default function SharedFilesPage() {
  const { toast } = useToast()
  const [shareFilter, setShareFilter] = useState<ShareFilter>("all")
  const [sort, setSort] = useState<"recent" | "name" | "size">("recent")

  const shared = useMemo(() => {
    let list = files.filter(f => f.shared)
    // mock — owner determines share source
    if (shareFilter === "you") list = list.filter(f => f.owner === "Jessin Sam" || f.owner === "Zara Marlowe")
    if (shareFilter === "team") list = list.filter(f => f.owner !== "Felix Brandt")
    if (shareFilter === "external") list = list.filter(f => f.owner === "Felix Brandt")
    list.sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name)
      if (sort === "size") return b.size - a.size
      return new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime()
    })
    return list
  }, [shareFilter, sort])

  return (
    <DashboardShell
      title="Shared files"
      description="Files shared with you, your team, and external collaborators."
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbLink asChild><Link href="/files">Files</Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Shared</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
    >
      {/* Stat row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        {shareFilters.map(f => {
          const Icon = f.icon
          const count = f.key === "all"
            ? files.filter(x => x.shared).length
            : f.key === "you" ? files.filter(x => x.shared && (x.owner === "Jessin Sam" || x.owner === "Zara Marlowe")).length
            : f.key === "team" ? files.filter(x => x.shared && x.owner !== "Felix Brandt").length
            : files.filter(x => x.shared && x.owner === "Felix Brandt").length
          return (
            <button
              key={f.key}
              onClick={() => setShareFilter(f.key)}
              className={cn(
                "text-left transition-all",
                shareFilter === f.key ? "scale-[1.02]" : "hover:scale-[1.01]"
              )}
            >
              <Card className={cn("p-4 card-lift", shareFilter === f.key && "ring-2 ring-primary/40 border-primary/30")}>
                <div className="flex items-center gap-2 mb-2">
                  <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", shareFilter === f.key ? "bg-primary text-primary-foreground" : "bg-primary/15 text-primary")}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-2xl font-bold text-foreground">{count}</span>
                </div>
                <p className="text-xs text-muted-foreground">{f.label}</p>
              </Card>
            </button>
          )
        })}
      </div>

      {/* Toolbar */}
      <div className="flex items-center justify-between mb-4">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{shared.length} files shared</p>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 text-xs gap-1.5 bg-transparent capitalize">
                <Clock className="w-3.5 h-3.5" /> Sort: {sort} <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuItem onClick={() => setSort("recent")} className={cn("text-xs", sort === "recent" && "bg-primary/10")}>Share date (recent)</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSort("name")} className={cn("text-xs", sort === "name" && "bg-primary/10")}>Name (A–Z)</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSort("size")} className={cn("text-xs", sort === "size" && "bg-primary/10")}>Size (large first)</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Grid */}
      {shared.length === 0 ? (
        <Card className="p-8 flex flex-col items-center text-center border-dashed">
          <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-3">
            <Users className="w-5 h-5 text-muted-foreground" />
          </div>
          <p className="text-sm font-semibold mb-1">No shared files in this view</p>
          <p className="text-xs text-muted-foreground">Try a different filter above.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {shared.map((f, i) => (
            <SharedFileCard key={f.id} file={f} index={i} toast={toast} />
          ))}
        </div>
      )}
    </DashboardShell>
  )
}

function SharedFileCard({ file, index, toast }: { file: FileItem; index: number; toast: any }) {
  const Icon = fileIcons[file.type] ?? FileIcon
  // Build a fake "shared with" list from members (excluding the owner)
  const sharedWith = members.filter(m => m.name !== file.owner).slice(0, 4)
  const external = file.owner === "Felix Brandt"

  return (
    <Card
      className="p-4 card-lift group cursor-pointer animate-slide-in-up"
      style={{ animationDelay: `${Math.min(index * 40, 320)}ms` }}
    >
      <div className="flex items-start gap-3 mb-3">
        <Link href={`/files/${file.id}`} className={cn("w-12 h-12 rounded-xl flex items-center justify-center shrink-0", fileTypeColors[file.type] ?? "bg-muted text-muted-foreground")}>
          <Icon className="w-5 h-5" />
        </Link>
        <div className="flex-1 min-w-0">
          <Link href={`/files/${file.id}`}>
            <p className="text-sm font-semibold text-foreground truncate group-hover:text-primary transition-colors">{file.name}</p>
          </Link>
          <p className="text-[11px] text-muted-foreground mt-0.5">{formatFileSize(file.size)} · {timeAgo(file.modifiedAt)}</p>
          <Badge variant="outline" className="text-[9px] h-4 px-1.5 mt-1.5">{fileTypeLabels[file.type]}</Badge>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="text-muted-foreground hover:text-foreground transition-colors p-1 -m-1 opacity-0 group-hover:opacity-100" aria-label="More actions">
              <MoreHorizontal className="w-4 h-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40">
            <DropdownMenuItem onClick={() => toast({ title: "Downloading", description: file.name })} className="text-xs gap-2"><Download className="w-3.5 h-3.5" /> Download</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast({ title: "Share link copied" })} className="text-xs gap-2"><Share2 className="w-3.5 h-3.5" /> Copy link</DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast({ title: "Removed from shared" })} className="text-xs gap-2">Remove access</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Owner row */}
      <div className="flex items-center gap-2 mb-3 pb-3 border-b border-border">
        <Avatar className="w-5 h-5">
          <AvatarImage src={file.ownerAvatar} alt={file.owner} />
          <AvatarFallback className="text-[9px]">{initials(file.owner)}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] text-muted-foreground">Shared by</p>
          <p className="text-xs font-medium text-foreground truncate">{file.owner}</p>
        </div>
        {external && <Badge className="text-[9px] h-4 px-1.5 bg-amber-500/15 text-amber-600 dark:text-amber-400">External</Badge>}
      </div>

      {/* Shared with avatars */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-muted-foreground">Shared with</span>
          <div className="flex -space-x-1.5">
            {sharedWith.slice(0, 3).map(m => (
              <Avatar key={m.id} className="w-6 h-6 border-2 border-card">
                <AvatarImage src={m.avatar} alt={m.name} />
                <AvatarFallback className="text-[8px]">{initials(m.name)}</AvatarFallback>
              </Avatar>
            ))}
            {sharedWith.length > 3 && (
              <div className="w-6 h-6 rounded-full bg-muted border-2 border-card flex items-center justify-center text-[9px] font-semibold text-muted-foreground">
                +{sharedWith.length - 3}
              </div>
            )}
          </div>
        </div>
        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => toast({ title: "Downloading", description: file.name })}>
          <Download className="w-3 h-3" />
        </Button>
      </div>
    </Card>
  )
}
