"use client"

import { useState, useMemo } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  Home, Search, Plus, Pin, Tag, Users, Lock, StickyNote, X,
} from "lucide-react"
import { notes } from "@/lib/data/mock"
import { cn, timeAgo, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import type { Note } from "@/types"

export default function NotesPage() {
  const { toast } = useToast()
  const [query, setQuery] = useState("")
  const [activeTag, setActiveTag] = useState<string | null>(null)
  const [pinned, setPinned] = useState<Record<string, boolean>>(
    Object.fromEntries(notes.map(n => [n.id, n.pinned]))
  )

  const allTags = useMemo(() => {
    const set = new Set<string>()
    notes.forEach(n => n.tags.forEach(t => set.add(t)))
    return Array.from(set).sort()
  }, [])

  const filtered = useMemo(() => {
    let list = [...notes]
    if (activeTag) list = list.filter(n => n.tags.includes(activeTag))
    if (query.trim()) {
      const q = query.toLowerCase()
      list = list.filter(n => n.title.toLowerCase().includes(q) || n.body.toLowerCase().includes(q) || n.author.toLowerCase().includes(q) || n.tags.some(t => t.toLowerCase().includes(q)))
    }
    // pinned first
    return list.sort((a, b) => Number(pinned[b.id] ?? false) - Number(pinned[a.id] ?? false))
  }, [activeTag, query, pinned])

  const pinnedCount = Object.values(pinned).filter(Boolean).length
  const sharedCount = notes.filter(n => n.shared).length

  const togglePin = (id: string) => {
    setPinned(s => ({ ...s, [id]: !s[id] }))
    toast({ title: pinned[id] ? "Unpinned" : "Pinned to top" })
  }

  return (
    <DashboardShell
      title="Notes"
      description="Quick thoughts, decisions, and shared context — pinned and tagged for easy retrieval."
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage>Notes</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast({ title: "New note", description: "Blank note editor would open." })}>
          <Plus className="w-4 h-4" /> New note
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <Card className="p-4 card-lift">
          <div className="w-9 h-9 rounded-lg bg-primary/15 text-primary flex items-center justify-center mb-2"><StickyNote className="w-4 h-4" /></div>
          <p className="text-2xl font-bold text-foreground">{notes.length}</p>
          <p className="text-xs text-muted-foreground">Total notes</p>
        </Card>
        <Card className="p-4 card-lift">
          <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-2"><Pin className="w-4 h-4" /></div>
          <p className="text-2xl font-bold text-foreground">{pinnedCount}</p>
          <p className="text-xs text-muted-foreground">Pinned</p>
        </Card>
        <Card className="p-4 card-lift">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-2"><Users className="w-4 h-4" /></div>
          <p className="text-2xl font-bold text-foreground">{sharedCount}</p>
          <p className="text-xs text-muted-foreground">Shared</p>
        </Card>
        <Card className="p-4 card-lift">
          <div className="w-9 h-9 rounded-lg bg-teal-500/15 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-2"><Tag className="w-4 h-4" /></div>
          <p className="text-2xl font-bold text-foreground">{allTags.length}</p>
          <p className="text-xs text-muted-foreground">Tags</p>
        </Card>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center gap-3 mb-4">
        <div className="relative flex-1 min-w-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search notes by title, body, or author…"
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="pl-9 h-9 text-sm"
          />
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {allTags.map(t => (
            <button
              key={t}
              onClick={() => setActiveTag(activeTag === t ? null : t)}
              className={cn(
                "text-xs px-2.5 py-1 rounded-full border transition-colors",
                activeTag === t ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground border-border hover:bg-muted hover:text-foreground"
              )}
            >
              #{t}
            </button>
          ))}
          {activeTag && (
            <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={() => setActiveTag(null)}>
              <X className="w-3 h-3" /> Clear
            </Button>
          )}
        </div>
      </div>

      {/* Masonry grid using CSS columns */}
      {filtered.length === 0 ? (
        <Card className="p-8 flex flex-col items-center text-center border-dashed">
          <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mb-3">
            <StickyNote className="w-5 h-5 text-muted-foreground" />
          </div>
          <p className="text-sm font-semibold mb-1">No notes found</p>
          <p className="text-xs text-muted-foreground mb-4">Try a different search or tag.</p>
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast({ title: "New note" })}>
            <Plus className="w-3.5 h-3.5" /> Create a note
          </Button>
        </Card>
      ) : (
        <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-3 [column-fill:_balance]">
          {filtered.map((n, i) => (
            <NoteCard key={n.id} note={n} index={i} isPinned={!!pinned[n.id]} onPin={togglePin} />
          ))}
        </div>
      )}
    </DashboardShell>
  )
}

function NoteCard({ note, index, isPinned, onPin }: { note: Note; index: number; isPinned: boolean; onPin: (id: string) => void }) {
  return (
    <Card
      className={cn(
        "p-4 mb-3 break-inside-avoid card-lift group cursor-pointer animate-slide-in-up border",
        note.color
      )}
      style={{ animationDelay: `${Math.min(index * 40, 320)}ms` }}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <Link href={`/notes/${note.id}`} className="flex-1 min-w-0">
          <h3 className="text-sm font-semibold text-foreground leading-tight group-hover:text-primary transition-colors">
            {note.title}
          </h3>
        </Link>
        <button
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); onPin(note.id) }}
          className="text-muted-foreground hover:text-foreground transition-colors p-0.5 -m-0.5 shrink-0"
          aria-label="Pin note"
        >
          <Pin className={cn("w-3.5 h-3.5", isPinned && "fill-primary text-primary")} />
        </button>
      </div>

      <Link href={`/notes/${note.id}`}>
        <p className="text-xs text-foreground/80 leading-relaxed whitespace-pre-line line-clamp-3 mb-3">
          {note.body}
        </p>
      </Link>

      <div className="flex items-center gap-1.5 flex-wrap mb-3">
        {note.tags.map(t => (
          <Badge key={t} variant="outline" className="text-[9px] h-4 px-1.5 bg-card/60">#{t}</Badge>
        ))}
      </div>

      <div className="flex items-center justify-between pt-2.5 border-t border-border/60">
        <div className="flex items-center gap-1.5 min-w-0">
          <Avatar className="w-5 h-5 shrink-0">
            <AvatarImage src={note.authorAvatar} alt={note.author} />
            <AvatarFallback className="text-[9px]">{initials(note.author)}</AvatarFallback>
          </Avatar>
          <span className="text-[10px] text-muted-foreground truncate">{note.author.split(" ")[0]}</span>
        </div>
        <div className="flex items-center gap-1.5">
          {note.shared ? <Users className="w-3 h-3 text-muted-foreground" /> : <Lock className="w-3 h-3 text-muted-foreground" />}
          <span className="text-[10px] text-muted-foreground">{timeAgo(note.updatedAt)}</span>
        </div>
      </div>
    </Card>
  )
}
