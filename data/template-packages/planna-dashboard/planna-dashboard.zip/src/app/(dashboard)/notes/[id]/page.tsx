"use client"

import { use, useState } from "react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import {
  Home, ArrowLeft, Pin, Users, Lock, Trash2, Save, Tag, X, Plus, Clock, Calendar, Globe, Hash,
} from "lucide-react"
import { notes, members } from "@/lib/data/mock"
import { cn, timeAgo, formatDate, initials } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

const colorOptions = [
  { value: "bg-emerald-500/10 border-emerald-500/30", label: "Emerald", dot: "bg-emerald-500" },
  { value: "bg-teal-500/10 border-teal-500/30", label: "Teal", dot: "bg-teal-500" },
  { value: "bg-lime-500/10 border-lime-500/30", label: "Lime", dot: "bg-lime-500" },
  { value: "bg-cyan-500/10 border-cyan-500/30", label: "Cyan", dot: "bg-cyan-500" },
  { value: "bg-amber-500/10 border-amber-500/30", label: "Amber", dot: "bg-amber-500" },
  { value: "bg-rose-500/10 border-rose-500/30", label: "Rose", dot: "bg-rose-500" },
  { value: "bg-pink-500/10 border-pink-500/30", label: "Pink", dot: "bg-pink-500" },
  { value: "bg-violet-500/10 border-violet-500/30", label: "Violet", dot: "bg-violet-500" },
]

export default function NoteDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const note = notes.find(n => n.id === id)
  if (!note) notFound()

  const { toast } = useToast()
  const [title, setTitle] = useState(note.title)
  const [body, setBody] = useState(note.body)
  const [tags, setTags] = useState<string[]>(note.tags)
  const [newTag, setNewTag] = useState("")
  const [pinned, setPinned] = useState(note.pinned)
  const [shared, setShared] = useState(note.shared)
  const [color, setColor] = useState(note.color)

  const addTag = () => {
    const t = newTag.trim().toLowerCase().replace(/^#/, "")
    if (t && !tags.includes(t)) {
      setTags([...tags, t])
      setNewTag("")
    }
  }

  const removeTag = (t: string) => setTags(tags.filter(x => x !== t))

  const save = () => toast({ title: "Note saved", description: "Changes persisted." })

  const remove = () => toast({ title: "Note deleted", description: note.title, variant: "destructive" })

  return (
    <DashboardShell
      title={title || "Untitled note"}
      description={`Last edited ${timeAgo(note.updatedAt)}`}
      breadcrumbs={
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem><BreadcrumbLink asChild><Link href="/"><Home className="w-3.5 h-3.5" /></Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbLink asChild><Link href="/notes">Notes</Link></BreadcrumbLink></BreadcrumbItem>
            <BreadcrumbSeparator /><BreadcrumbItem><BreadcrumbPage className="max-w-[200px] truncate">{note.title}</BreadcrumbPage></BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      }
      actions={
        <>
          <Button asChild variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Link href="/notes"><ArrowLeft className="w-4 h-4" /> Back</Link>
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={save}>
            <Save className="w-4 h-4" /> Save
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-4">
        {/* Editor */}
        <div className="min-w-0">
          <Card className={cn("p-5 md:p-6 border-2", color)}>
            {/* Title */}
            <input
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Note title…"
              className="w-full text-lg md:text-xl font-bold text-foreground bg-transparent border-none outline-none focus:ring-0 placeholder:text-muted-foreground/50 mb-3"
            />

            <div className="flex items-center gap-1.5 flex-wrap mb-4">
              {tags.map(t => (
                <Badge key={t} variant="outline" className="text-[10px] h-5 px-1.5 gap-1 bg-card/60">
                  <Hash className="w-2.5 h-2.5" />{t}
                  <button onClick={() => removeTag(t)} className="ml-0.5 hover:text-destructive" aria-label="Remove tag">
                    <X className="w-2.5 h-2.5" />
                  </button>
                </Badge>
              ))}
            </div>

            {/* Body */}
            <Textarea
              value={body}
              onChange={e => setBody(e.target.value)}
              placeholder="Start writing — markdown is supported. Use # for headings, - for lists, **bold**, _italic_, `code`."
              className="min-h-[420px] md:min-h-[560px] text-sm leading-relaxed bg-card/40 border-border/50 resize-none font-mono"
            />

            {/* Tag input */}
            <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/50">
              <Tag className="w-3.5 h-3.5 text-muted-foreground" />
              <Input
                value={newTag}
                onChange={e => setNewTag(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addTag() } }}
                placeholder="Add a tag and press Enter"
                className="h-8 text-xs flex-1 bg-card/60 border-border/50"
              />
              <Button size="sm" variant="outline" className="h-8 text-xs gap-1 bg-transparent" onClick={addTag}>
                <Plus className="w-3 h-3" /> Add
              </Button>
            </div>
          </Card>

          {/* Markdown preview */}
          <Card className="p-4 md:p-5 mt-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">Preview</h3>
              <Badge variant="outline" className="text-[10px]">Markdown</Badge>
            </div>
            <div className="prose prose-sm max-w-none text-sm text-foreground/90 leading-relaxed whitespace-pre-line">
              {body || <span className="text-muted-foreground italic">Nothing to preview yet.</span>}
            </div>
          </Card>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          <Card className="p-4">
            <p className="text-xs font-semibold mb-3">Metadata</p>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={note.authorAvatar} alt={note.author} />
                  <AvatarFallback className="text-[10px]">{initials(note.author)}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{note.author}</p>
                  <p className="text-[10px] text-muted-foreground">Author</p>
                </div>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground flex items-center gap-1.5"><Calendar className="w-3 h-3" /> Created</span>
                <span className="font-medium">{formatDate(note.updatedAt)}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground flex items-center gap-1.5"><Clock className="w-3 h-3" /> Last edit</span>
                <span className="font-medium">{timeAgo(note.updatedAt)}</span>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <p className="text-xs font-semibold mb-3">Quick actions</p>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Pin className={cn("w-3.5 h-3.5", pinned && "fill-primary text-primary")} />
                  <span className="text-xs">Pinned</span>
                </div>
                <Switch checked={pinned} onCheckedChange={v => { setPinned(v); toast({ title: v ? "Pinned to top" : "Unpinned" }) }} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {shared ? <Users className="w-3.5 h-3.5 text-primary" /> : <Lock className="w-3.5 h-3.5" />}
                  <span className="text-xs">{shared ? "Shared with team" : "Private"}</span>
                </div>
                <Switch checked={shared} onCheckedChange={v => { setShared(v); toast({ title: v ? "Note shared with team" : "Note set to private" }) }} />
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <p className="text-xs font-semibold mb-3">Color</p>
            <div className="grid grid-cols-4 gap-2">
              {colorOptions.map(c => (
                <button
                  key={c.value}
                  onClick={() => setColor(c.value)}
                  className={cn(
                    "aspect-square rounded-lg border-2 flex items-center justify-center transition-all",
                    color === c.value ? "border-primary scale-105" : "border-transparent hover:scale-105"
                  )}
                  aria-label={c.label}
                  title={c.label}
                >
                  <span className={cn("w-6 h-6 rounded-full", c.dot)} />
                </button>
              ))}
            </div>
          </Card>

          {shared && (
            <Card className="p-4">
              <p className="text-xs font-semibold mb-3">Shared with</p>
              <div className="space-y-2.5 max-h-60 overflow-y-auto scroll-area-thin">
                {members.slice(1, 5).map(m => (
                  <div key={m.id} className="flex items-center gap-2.5">
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={m.avatar} alt={m.name} />
                      <AvatarFallback className="text-[9px]">{initials(m.name)}</AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-foreground truncate">{m.name}</span>
                    <Globe className="w-3 h-3 text-muted-foreground ml-auto" />
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card className="p-4 border-destructive/30">
            <p className="text-xs font-semibold mb-3 text-destructive">Danger zone</p>
            <Button variant="outline" size="sm" className="w-full h-9 text-xs gap-1.5 bg-transparent text-destructive hover:text-destructive hover:bg-destructive/5" onClick={remove}>
              <Trash2 className="w-3.5 h-3.5" /> Delete note
            </Button>
          </Card>
        </aside>
      </div>
    </DashboardShell>
  )
}
