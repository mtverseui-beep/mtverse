"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  ArrowLeft, Bell, AtSign, MessageSquare, CalendarClock, UserCog,
  Sparkles, Mail, Smartphone, Monitor, Save, Moon, Clock, Globe,
  Volume2, Check, type LucideIcon,
} from "lucide-react"
import { toast } from "sonner"
import { cn } from "@/lib/utils"

// ============================================================
// CONFIG
// ============================================================

const channels: { key: string; label: string; icon: LucideIcon; description: string }[] = [
  { key: "email",   label: "Email",        icon: Mail,      description: "Daily-digest style, sent to your inbox" },
  { key: "in_app",  label: "In-app",       icon: Bell,      description: "Real-time toast + bell dropdown" },
  { key: "mobile",  label: "Mobile push",  icon: Smartphone, description: "Push notifications on iOS & Android" },
  { key: "desktop", label: "Desktop",      icon: Monitor,   description: "Browser notification (opt-in required)" },
]

const events: { key: string; label: string; icon: LucideIcon; description: string }[] = [
  { key: "mentions",     label: "Mentions",       icon: AtSign,        description: "When someone tags you with @" },
  { key: "comments",     label: "Comments",       icon: MessageSquare, description: "Replies to tasks you watch or own" },
  { key: "deadlines",    label: "Deadlines",      icon: CalendarClock, description: "Tasks due soon or overdue reminders" },
  { key: "assignments",  label: "Assignments",    icon: UserCog,       description: "When a task is assigned to you" },
  { key: "weekly_digest", label: "Weekly digest", icon: Sparkles,      description: "Summary of last week's activity" },
]

const digestOptions = [
  { value: "off", label: "Off", description: "No digest" },
  { value: "daily", label: "Daily", description: "Every morning at 8:00 AM" },
  { value: "weekly", label: "Weekly", description: "Mondays at 8:00 AM" },
  { value: "monthly", label: "Monthly", description: "First of each month" },
]

// Default preference matrix
const defaultMatrix: Record<string, Record<string, boolean>> = {
  mentions:     { email: true,  in_app: true,  mobile: true,  desktop: true  },
  comments:     { email: false, in_app: true,  mobile: true,  desktop: false },
  deadlines:    { email: true,  in_app: true,  mobile: true,  desktop: true  },
  assignments:  { email: true,  in_app: true,  mobile: false, desktop: false },
  weekly_digest:{ email: true,  in_app: false, mobile: false, desktop: false },
}

// ============================================================
// PAGE
// ============================================================

export default function NotificationSettingsPage() {
  const [matrix, setMatrix] = useState(defaultMatrix)
  const [quietHoursEnabled, setQuietHoursEnabled] = useState(true)
  const [quietStart, setQuietStart] = useState("22:00")
  const [quietEnd, setQuietEnd] = useState("08:00")
  const [timezone, setTimezone] = useState("America/Los_Angeles")
  const [digest, setDigest] = useState("weekly")
  const [sound, setSound] = useState("gentle")
  const [doNotDisturbFocus, setDoNotDisturbFocus] = useState(true)

  const toggle = (event: string, channel: string) => {
    setMatrix(prev => ({
      ...prev,
      [event]: { ...prev[event], [channel]: !prev[event][channel] },
    }))
  }

  const handleSave = () => {
    toast.success("Notification preferences saved", {
      description: `${Object.values(matrix).flat().filter(Boolean).length} channels active across ${events.length} event types`,
    })
  }

  const activeCount = Object.values(matrix).flat().filter(Boolean).length
  const totalCells = events.length * channels.length

  return (
    <DashboardShell
      title="Notification preferences"
      description="Choose how and when Planna reaches you. Changes apply across all your devices."
      actions={
        <>
          <Button variant="ghost" size="sm" className="h-9 gap-1.5" asChild>
            <Link href="/notifications">
              <ArrowLeft className="w-3.5 h-3.5" /> Back to notifications
            </Link>
          </Button>
          <Button
            size="sm"
            className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={handleSave}
          >
            <Save className="w-4 h-4" /> Save changes
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* MAIN — channel × event matrix */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-foreground">Channels by event type</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Toggle which channels receive each kind of event.</p>
              </div>
              <Badge variant="secondary" className="text-[10px] gap-1">
                <Check className="w-3 h-3" />
                {activeCount}/{totalCells} active
              </Badge>
            </div>

            {/* Matrix */}
            <div className="overflow-x-auto -mx-4 md:mx-0">
              <table className="w-full border-collapse min-w-[560px]">
                <thead>
                  <tr>
                    <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-4 md:px-3 pb-3 w-[40%]">
                      Event
                    </th>
                    {channels.map(ch => (
                      <th key={ch.key} className="px-2 pb-3">
                        <div className="flex flex-col items-center gap-1">
                          <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground">
                            <ch.icon className="w-4 h-4" />
                          </div>
                          <span className="text-[10px] font-medium text-foreground whitespace-nowrap">{ch.label}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {events.map(ev => (
                    <tr key={ev.key} className="border-t border-border">
                      <td className="px-4 md:px-3 py-3">
                        <div className="flex items-start gap-2.5">
                          <div className="w-7 h-7 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0 mt-0.5">
                            <ev.icon className="w-3.5 h-3.5" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-foreground">{ev.label}</p>
                            <p className="text-[10px] text-muted-foreground mt-0.5 leading-snug">{ev.description}</p>
                          </div>
                        </div>
                      </td>
                      {channels.map(ch => (
                        <td key={ch.key} className="px-2 py-3 text-center">
                          <div className="flex items-center justify-center">
                            <Switch
                              checked={matrix[ev.key][ch.key]}
                              onCheckedChange={() => toggle(ev.key, ch.key)}
                              aria-label={`${ev.label} via ${ch.label}`}
                            />
                          </div>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* Quiet hours */}
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-start justify-between gap-3 mb-4">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-violet-500/15 text-violet-600 dark:text-violet-400 flex items-center justify-center shrink-0">
                  <Moon className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-foreground">Quiet hours</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Mute non-urgent notifications during your focus or rest hours.
                  </p>
                </div>
              </div>
              <Switch checked={quietHoursEnabled} onCheckedChange={setQuietHoursEnabled} />
            </div>

            <div className={cn("grid grid-cols-1 sm:grid-cols-3 gap-3 transition-opacity", !quietHoursEnabled && "opacity-50 pointer-events-none")}>
              <div className="space-y-1.5">
                <Label htmlFor="quiet-start" className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Starts at
                </Label>
                <Input
                  id="quiet-start"
                  type="time"
                  value={quietStart}
                  onChange={e => setQuietStart(e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="quiet-end" className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Ends at
                </Label>
                <Input
                  id="quiet-end"
                  type="time"
                  value={quietEnd}
                  onChange={e => setQuietEnd(e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                  <Globe className="w-3 h-3" /> Timezone
                </Label>
                <Select value={timezone} onValueChange={setTimezone}>
                  <SelectTrigger className="h-9 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="America/Los_Angeles">America / Los Angeles (PT)</SelectItem>
                    <SelectItem value="America/New_York">America / New York (ET)</SelectItem>
                    <SelectItem value="Europe/London">Europe / London (GMT)</SelectItem>
                    <SelectItem value="Europe/Berlin">Europe / Berlin (CET)</SelectItem>
                    <SelectItem value="Asia/Tokyo">Asia / Tokyo (JST)</SelectItem>
                    <SelectItem value="Asia/Singapore">Asia / Singapore (SGT)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="mt-3 p-3 rounded-lg bg-secondary/40 border border-border flex items-start gap-2">
              <Sparkles className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
              <p className="text-[11px] text-muted-foreground">
                During quiet hours (<span className="font-medium text-foreground">{quietStart}–{quietEnd}</span>), only <span className="font-medium text-foreground">urgent deadlines</span> and <span className="font-medium text-foreground">security alerts</span> will be delivered. Everything else queues for the end of quiet hours.
              </p>
            </div>
          </Card>

          {/* Do not disturb during focus */}
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                  <Volume2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-foreground">Do not disturb during Focus sessions</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Automatically mute notifications while a Focus timer is running. Critical alerts still come through.
                  </p>
                </div>
              </div>
              <Switch checked={doNotDisturbFocus} onCheckedChange={setDoNotDisturbFocus} />
            </div>
          </Card>
        </div>

        {/* SIDEBAR — digest + sound + summary */}
        <div className="space-y-4">
          {/* Digest frequency */}
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">Digest frequency</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              How often Planna bundles your activity into a single summary email.
            </p>
            <RadioGroup value={digest} onValueChange={setDigest} className="space-y-1.5">
              {digestOptions.map(opt => (
                <label
                  key={opt.value}
                  htmlFor={`digest-${opt.value}`}
                  className={cn(
                    "flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-colors",
                    digest === opt.value
                      ? "border-primary/40 bg-primary/5"
                      : "border-border hover:bg-secondary/40"
                  )}
                >
                  <RadioGroupItem value={opt.value} id={`digest-${opt.value}`} className="mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-foreground">{opt.label}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{opt.description}</p>
                  </div>
                </label>
              ))}
            </RadioGroup>
          </Card>

          {/* Notification sound */}
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center gap-2 mb-1">
              <Volume2 className="w-3.5 h-3.5 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">Notification sound</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              Played for in-app notifications on desktop.
            </p>
            <Select value={sound} onValueChange={setSound}>
              <SelectTrigger className="h-9 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="off">Silent</SelectItem>
                <SelectItem value="gentle">Gentle chime (default)</SelectItem>
                <SelectItem value="pop">Soft pop</SelectItem>
                <SelectItem value="ding">Ding</SelectItem>
                <SelectItem value="chord">Ascending chord</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" className="w-full mt-2 h-8 text-xs bg-transparent gap-1.5">
              <Volume2 className="w-3.5 h-3.5" /> Preview sound
            </Button>
          </Card>

          {/* Summary card */}
          <Card className="p-4 md:p-5 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-7 h-7 rounded-md bg-primary text-primary-foreground flex items-center justify-center">
                <Bell className="w-3.5 h-3.5" />
              </div>
              <h3 className="text-sm font-semibold text-foreground">Your summary</h3>
            </div>
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Active channels</span>
                <span className="font-semibold text-foreground">{activeCount} / {totalCells}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Quiet hours</span>
                <span className="font-semibold text-foreground">
                  {quietHoursEnabled ? `${quietStart}–${quietEnd}` : "Off"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Digest</span>
                <span className="font-semibold text-foreground capitalize">{digest}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Focus DND</span>
                <span className="font-semibold text-foreground">{doNotDisturbFocus ? "On" : "Off"}</span>
              </div>
            </div>
            <Button
              size="sm"
              className="w-full mt-4 h-8 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={handleSave}
            >
              <Save className="w-3.5 h-3.5" /> Save preferences
            </Button>
          </Card>

          {/* Mobile push setup hint */}
          <Card className="p-4 md:p-5 border-dashed">
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Enable mobile push</p>
                <p className="text-[10px] text-muted-foreground mt-1 leading-snug">
                  Install the Planna mobile companion and sign in to receive push notifications on your phone.
                </p>
                <Button variant="link" size="sm" className="h-7 text-xs px-0 mt-1 text-primary">
                  Get the mobile app →
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
