"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { cn, timeAgo, initials } from "@/lib/utils"
import { toast } from "sonner"
import {
  Bell, AtSign, MessageSquare, CalendarClock, UserPlus, Settings,
  CheckCheck, ChevronRight, Filter, Sparkles, ListTodo, FolderKanban,
  Server, BellOff, type LucideIcon,
} from "lucide-react"
import { notifications as seedNotifications, members, currentMember } from "@/lib/data/mock"
import type { Notification } from "@/types"

// ============================================================
// ENRICH NOTIFICATIONS (add a few more so the feed is rich)
// ============================================================

const extraNotifications: Notification[] = [
  { id: "n9", type: "mention", title: "Felix mentioned you", body: "@jessin the command palette focus behavior needs your eyes — see PLN-101.", createdAt: "2026-01-28T15:21:00Z", read: false, actor: { name: members[4].name, avatar: members[4].avatar }, href: "/tasks/t1" },
  { id: "n10", type: "comment", title: "Theo commented on PLN-103", body: "We need a manual reconnect button after max retries — silent failure is bad UX.", createdAt: "2026-01-28T10:42:00Z", read: false, actor: { name: members[2].name, avatar: members[2].avatar }, href: "/tasks/t3" },
  { id: "n11", type: "task", title: "Task moved to Review", body: "PLN-108 — Time tracker widget improvements", createdAt: "2026-01-28T09:12:00Z", read: false, actor: { name: currentMember.name, avatar: currentMember.avatar }, href: "/tasks/t26" },
  { id: "n12", type: "deadline", title: "Sprint 47 ends in 5 days", body: "9 tasks still in progress. Plan accordingly.", createdAt: "2026-01-27T08:00:00Z", read: true, actor: { name: "Planna", avatar: "" }, href: "/planning/sprint-planning" },
  { id: "n13", type: "invite", title: "You've been invited", body: "Join the #leadership private channel.", createdAt: "2026-01-26T11:00:00Z", read: true, actor: { name: members[0].name, avatar: members[0].avatar }, href: "/chat" },
  { id: "n14", type: "system", title: "Workspace maintenance scheduled", body: "Sun Feb 2, 02:00–03:00 UTC. Brief read-only mode.", createdAt: "2026-01-24T12:00:00Z", read: true, actor: { name: "Planna", avatar: "" }, href: "/announcements" },
  { id: "n15", type: "mention", title: "Zara mentioned you", body: "@jessin let's preview the Acme onboarding variant tomorrow.", createdAt: "2026-01-23T16:45:00Z", read: true, actor: { name: members[1].name, avatar: members[1].avatar }, href: "/tasks/t11" },
  { id: "n16", type: "project", title: "Project milestone reached", body: "API v2 launch milestone completed in Public API Platform.", createdAt: "2026-01-21T10:00:00Z", read: true, actor: { name: members[5].name, avatar: members[5].avatar }, href: "/projects/p3" },
  { id: "n17", type: "comment", title: "Naomi commented on SEC-901", body: "Re-ran the IDOR test suite — 0 failures. Worth adding a regression test.", createdAt: "2026-01-20T13:38:00Z", read: true, actor: { name: members[7].name, avatar: members[7].avatar }, href: "/tasks/t14" },
  { id: "n18", type: "system", title: "API key revoked", body: "pk_live_77de was revoked by Theo Nakamura after 45 days of inactivity.", createdAt: "2026-01-15T14:30:00Z", read: true, actor: { name: members[2].name, avatar: members[2].avatar }, href: "/settings/security" },
  { id: "n19", type: "deadline", title: "Overdue: INF-501", body: "Migrate auth service to Kubernetes — due 1 day ago, still blocked.", createdAt: "2026-01-12T09:00:00Z", read: true, actor: { name: "Planna", avatar: "" }, href: "/tasks/t10" },
  { id: "n20", type: "project", title: "New project created", body: "Sprint 48 — Polishing was created by Theo Nakamura.", createdAt: "2026-01-10T11:00:00Z", read: true, actor: { name: members[2].name, avatar: members[2].avatar }, href: "/planning/sprint-planning" },
]

const allNotifications = [...extraNotifications, ...seedNotifications].sort(
  (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
)

// ============================================================
// TYPE CONFIG
// ============================================================

const typeConfig: Record<Notification["type"], { label: string; icon: LucideIcon; chip: string; dot: string }> = {
  mention:   { label: "Mentions",   icon: AtSign,        chip: "bg-primary/15 text-primary",                                dot: "bg-primary" },
  comment:   { label: "Comments",   icon: MessageSquare, chip: "bg-sky-500/15 text-sky-600 dark:text-sky-400",              dot: "bg-sky-500" },
  deadline:  { label: "Deadlines",  icon: CalendarClock, chip: "bg-rose-500/15 text-rose-600 dark:text-rose-400",          dot: "bg-rose-500" },
  invite:    { label: "Invites",    icon: UserPlus,      chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400",        dot: "bg-amber-500" },
  system:    { label: "System",     icon: Server,        chip: "bg-zinc-500/15 text-zinc-600 dark:text-zinc-400",           dot: "bg-zinc-500" },
  project:   { label: "Projects",   icon: FolderKanban,  chip: "bg-teal-500/15 text-teal-600 dark:text-teal-400",           dot: "bg-teal-500" },
  task:      { label: "Tasks",      icon: ListTodo,      chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",  dot: "bg-emerald-500" },
}

const filterTabs = [
  { key: "all", label: "All", icon: Bell },
  { key: "mention", label: "Mentions", icon: AtSign },
  { key: "comment", label: "Comments", icon: MessageSquare },
  { key: "deadline", label: "Deadlines", icon: CalendarClock },
  { key: "invite", label: "Invites", icon: UserPlus },
  { key: "system", label: "System", icon: Server },
  { key: "project", label: "Projects", icon: FolderKanban },
  { key: "task", label: "Tasks", icon: ListTodo },
] as const

// ============================================================
// DATE GROUPING
// ============================================================

function getDateGroup(dateStr: string): string {
  const d = new Date(dateStr)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const target = new Date(d)
  target.setHours(0, 0, 0, 0)
  const diff = Math.floor((today.getTime() - target.getTime()) / 86400000)
  if (diff === 0) return "Today"
  if (diff === 1) return "Yesterday"
  if (diff > 1 && diff < 7) return "This week"
  return "Earlier"
}

const groupOrder = ["Today", "Yesterday", "This week", "Earlier"]

// ============================================================
// PAGE
// ============================================================

export default function NotificationsPage() {
  const [items, setItems] = useState<Notification[]>(allNotifications)
  const [filter, setFilter] = useState<string>("all")

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: items.length }
    Object.keys(typeConfig).forEach(k => { c[k] = items.filter(n => n.type === k).length })
    return c
  }, [items])

  const unreadCount = items.filter(n => !n.read).length

  const filtered = useMemo(() => {
    const sorted = [...items].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    if (filter === "all") return sorted
    return sorted.filter(n => n.type === filter)
  }, [items, filter])

  const grouped = useMemo(() => {
    const groups: { group: string; items: Notification[] }[] = []
    filtered.forEach(n => {
      const g = getDateGroup(n.createdAt)
      const last = groups[groups.length - 1]
      if (last && last.group === g) last.items.push(n)
      else groups.push({ group: g, items: [n] })
    })
    return groups.sort((a, b) => groupOrder.indexOf(a.group) - groupOrder.indexOf(b.group))
  }, [filtered])

  const markAllRead = () => {
    setItems(prev => prev.map(n => ({ ...n, read: true })))
    toast.success("All notifications marked as read")
  }

  const markRead = (id: string) => {
    setItems(prev => prev.map(n => n.id === id ? { ...n, read: true } : n))
  }

  return (
    <DashboardShell
      title="Notifications"
      description="Stay on top of mentions, deadlines, and team activity in one place."
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent" asChild>
            <Link href="/notifications/settings">
              <Settings className="w-3.5 h-3.5" /> Settings
            </Link>
          </Button>
          <Button
            size="sm"
            className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={markAllRead}
            disabled={unreadCount === 0}
          >
            <CheckCheck className="w-4 h-4" /> Mark all read
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Unread" value={unreadCount} hint="needs your attention" icon={Bell} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Mentions" value={counts.mention ?? 0} hint="tagged you directly" icon={AtSign} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Deadlines" value={counts.deadline ?? 0} hint="due soon or overdue" icon={CalendarClock} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Invites" value={counts.invite ?? 0} hint="awaiting your response" icon={UserPlus} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Filter pills */}
      <Card className="p-2 md:p-3 mb-4">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar -mx-1 px-1">
          {filterTabs.map(tab => {
            const isActive = filter === tab.key
            const count = counts[tab.key] ?? 0
            return (
              <button
                key={tab.key}
                onClick={() => setFilter(tab.key)}
                className={cn(
                  "shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-muted-foreground border-border hover:bg-secondary hover:text-foreground"
                )}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
                <span className={cn(
                  "ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold",
                  isActive ? "bg-primary-foreground/20 text-primary-foreground" : "bg-secondary text-muted-foreground"
                )}>
                  {count}
                </span>
              </button>
            )
          })}
        </div>
      </Card>

      {/* Notifications list grouped by date */}
      {grouped.length === 0 || filtered.length === 0 ? (
        <EmptyState
          icon={BellOff}
          title="No notifications here"
          description="You're all caught up. New mentions, comments, and deadlines will appear here as they happen."
          action={{ label: "View all notifications", onClick: () => setFilter("all") }}
        />
      ) : (
        <div className="space-y-4">
          {grouped.map(group => (
            <div key={group.group} className="animate-fade-in">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{group.group}</span>
                <span className="text-[10px] text-muted-foreground">· {group.items.length} item{group.items.length !== 1 ? "s" : ""}</span>
                <div className="flex-1 h-px bg-border" />
                {group.group === "Today" && unreadCount > 0 && (
                  <Badge className="text-[10px] h-5 px-1.5 bg-primary/15 text-primary border-primary/20">{group.items.filter(n => !n.read).length} unread</Badge>
                )}
              </div>
              <Card className="divide-y divide-border overflow-hidden border border-border rounded-xl">
                {group.items.map((n, idx) => {
                  const cfg = typeConfig[n.type] ?? typeConfig.system
                  const isSystem = !n.actor?.avatar
                  return (
                    <Link
                      key={n.id}
                      href={n.href ?? "#"}
                      onClick={() => markRead(n.id)}
                      className={cn(
                        "flex items-start gap-3 p-3 md:p-4 transition-colors hover:bg-secondary/40 group relative",
                        !n.read && "bg-primary/5"
                      )}
                    >
                      {/* Avatar / icon */}
                      <div className="relative shrink-0">
                        {isSystem ? (
                          <div className={cn("w-9 h-9 rounded-full flex items-center justify-center", cfg.chip)}>
                            <cfg.icon className="w-4 h-4" />
                          </div>
                        ) : (
                          <Avatar className="w-9 h-9 ring-2 ring-card">
                            <AvatarImage src={n.actor!.avatar} alt={n.actor!.name} />
                            <AvatarFallback className="text-xs">{initials(n.actor!.name)}</AvatarFallback>
                          </Avatar>
                        )}
                        <span className={cn(
                          "absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-card",
                          cfg.chip
                        )}>
                          <cfg.icon className="w-2.5 h-2.5" />
                        </span>
                      </div>

                      {/* Body */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-0.5">
                          <p className={cn(
                            "text-sm leading-snug",
                            n.read ? "text-foreground font-medium" : "text-foreground font-semibold"
                          )}>
                            {n.title}
                          </p>
                          <span className="text-[10px] text-muted-foreground shrink-0 mt-0.5">
                            {timeAgo(n.createdAt)}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">{n.body}</p>
                        <div className="flex items-center gap-1.5 mt-2">
                          <span className={cn("inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded", cfg.chip)}>
                            <cfg.icon className="w-2.5 h-2.5" />
                            {cfg.label.slice(0, -1)}
                          </span>
                          {n.href && (
                            <span className="text-[10px] text-muted-foreground hidden sm:flex items-center gap-0.5 group-hover:text-primary transition-colors">
                              View <ChevronRight className="w-2.5 h-2.5" />
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Unread dot */}
                      {!n.read && (
                        <span className="absolute right-3 top-3 w-2 h-2 rounded-full bg-primary animate-pulse" />
                      )}
                    </Link>
                  )
                })}
              </Card>
            </div>
          ))}
        </div>
      )}

      {/* Footer summary */}
      {filtered.length > 0 && (
        <div className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
          <Sparkles className="w-3 h-3" />
          Showing {filtered.length} notification{filtered.length !== 1 ? "s" : ""} ·
          <Link href="/notifications/settings" className="text-primary hover:underline">
            Manage notification preferences
          </Link>
        </div>
      )}
    </DashboardShell>
  )
}
