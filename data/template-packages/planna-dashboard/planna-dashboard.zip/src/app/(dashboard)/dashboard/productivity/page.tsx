"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaAreaChart, PlannaBarChart, PlannaHeatmap, PlannaRadialChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Sparkles, Clock, Target, TrendingUp, Zap, Flame, Coffee, Brain, Timer, Calendar, ArrowUpRight, Award } from "lucide-react"
import { productivityTrend, focusHeatmap, members, currentMember } from "@/lib/data/mock"
import Link from "next/link"
import { cn } from "@/lib/utils"

export default function ProductivityDashboard() {
  return (
    <DashboardShell
      title="Productivity Dashboard"
      description="Track focus, deep work, and your personal velocity."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Calendar className="w-4 h-4" /> This week
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Zap className="w-4 h-4" /> Start focus session
          </Button>
        </>
      }
    >
      {/* Personal greeting + score */}
      <Card className="p-5 mb-4 bg-gradient-to-r from-primary/10 via-card to-card border-primary/20 card-lift">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 ring-2 ring-primary/20">
              <AvatarImage src={currentMember.avatar} alt={currentMember.name} />
              <AvatarFallback>{currentMember.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-xs text-muted-foreground">Good afternoon,</p>
              <p className="text-lg font-bold text-foreground">{currentMember.name.split(" ")[0]} 👋</p>
              <p className="text-xs text-muted-foreground mt-1">You're on a <span className="font-semibold text-amber-600 dark:text-amber-400">5-day focus streak</span> — keep it going!</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground tabular-nums">87</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Score</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground tabular-nums">4.2h</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Focus today</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground tabular-nums">12</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Done this week</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Top stats — productivity themed */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Deep Work Hours" value="28h" hint="this week" icon={Brain} trend={{ value: 14, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Focus Sessions" value="42" hint="avg 40 min" icon={Zap} trend={{ value: 8, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Tasks Shipped" value="12" hint="3 ahead of plan" icon={Target} trend={{ value: 20, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Streak" value="5 days" hint="best: 14 days" icon={Flame} trend={{ value: 25, positive: true }} iconColor="bg-orange-500/15 text-orange-600 dark:text-orange-400" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Weekly Output" subtitle="Completed tasks vs focus hours" className="lg:col-span-2">
          <PlannaAreaChart
            data={productivityTrend}
            xKey="week"
            series={[
              { key: "completed", name: "Tasks Completed" },
              { key: "focus", name: "Focus Hours", color: "var(--chart-2)" },
            ]}
            height={260}
          />
        </ChartCard>

        <ChartCard title="Productivity Score" subtitle="Last 7 days avg" fullscreen={false}>
          <div className="flex flex-col items-center gap-3 py-4">
            <PlannaRadialChart value={87} label="Excellent" size={180} />
            <div className="flex items-center gap-2 text-xs">
              <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
                <TrendingUp className="w-3 h-3" /> +5 vs last week
              </Badge>
            </div>
          </div>
        </ChartCard>
      </div>

      {/* Focus heatmap + breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4 mb-4">
        <ChartCard title="Focus Heatmap" subtitle="When you do your best work" fullscreen={false}>
          <PlannaHeatmap data={focusHeatmap} />
        </ChartCard>

        <ChartCard title="Time by Activity" subtitle="This week, in hours" fullscreen={false}>
          <PlannaBarChart
            data={[
              { name: "Deep Work", hours: 18 },
              { name: "Meetings", hours: 6 },
              { name: "Reviews", hours: 4 },
              { name: "Planning", hours: 3 },
              { name: "Admin", hours: 2 },
            ]}
            xKey="name"
            series={[{ key: "hours", name: "Hours", color: "var(--chart-1)" }]}
            height={240}
            showLegend={false}
          />
        </ChartCard>
      </div>

      {/* Goals + Awards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Weekly Goals</h3>
            </div>
            <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
              <Link href="/planning/goals">All goals</Link>
            </Button>
          </div>
          <div className="space-y-4">
            {[
              { label: "Ship 15 tasks", value: 12, max: 15, color: "bg-primary" },
              { label: "Log 30 focus hours", value: 28, max: 30, color: "bg-violet-500" },
              { label: "Review 8 PRs", value: 6, max: 8, color: "bg-amber-500" },
              { label: "Reduce WIP to 3", value: 4, max: 3, color: "bg-rose-500" },
            ].map(g => (
              <div key={g.label}>
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-xs font-medium text-foreground">{g.label}</p>
                  <span className="text-[11px] font-semibold text-muted-foreground">{g.value}/{g.max}</span>
                </div>
                <Progress value={Math.min(100, (g.value / g.max) * 100)} className="h-1.5" />
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold">Recent Achievements</h3>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {[
              { icon: Flame, title: "5-day streak", color: "bg-orange-500/15 text-orange-600 dark:text-orange-400" },
              { icon: Brain, title: "100h deep work", color: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
              { icon: Zap, title: "42 sessions", color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
              { icon: Coffee, title: "Early riser", color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
              { icon: Target, title: "Goal crusher", color: "bg-lime-500/15 text-lime-600 dark:text-lime-400" },
              { icon: Timer, title: "Sprint hero", color: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
            ].map((a, i) => {
              const Icon = a.icon
              return (
                <div key={i} className="flex items-center gap-2 p-2.5 rounded-lg bg-secondary/50 border border-border">
                  <div className={cn("w-7 h-7 rounded-md flex items-center justify-center", a.color)}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <p className="text-[11px] font-medium text-foreground truncate">{a.title}</p>
                </div>
              )
            })}
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
