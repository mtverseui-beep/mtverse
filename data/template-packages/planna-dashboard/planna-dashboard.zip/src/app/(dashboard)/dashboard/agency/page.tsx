"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaBarChart, PlannaAreaChart, PlannaDonutChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Building2, Users, DollarSign, Briefcase, Plus, TrendingUp, Clock, FileText, ArrowUpRight } from "lucide-react"
import { clients, projects, members, invoices } from "@/lib/data/mock"
import Link from "next/link"
import { cn, formatCurrency, relativeDay, pct } from "@/lib/utils"

export default function AgencyDashboard() {
  const clientProjects = projects.filter(p => p.client)
  const totalRevenue = clients.reduce((s, c) => s + c.totalRevenue, 0)
  const totalOutstanding = clients.reduce((s, c) => s + c.outstanding, 0)
  const avgUtilization = Math.round(members.reduce((s, m) => s + (m.utilized / m.capacity), 0) / members.length * 100)

  return (
    <DashboardShell
      title="Agency Dashboard"
      description="Operations overview across clients, projects, and team utilization."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <FileText className="w-4 h-4" /> New proposal
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> Add engagement
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Engagements" value={clientProjects.length} hint="across clients" icon={Briefcase} trend={{ value: 15, positive: true }} />
        <StatCard label="Team Utilization" value={`${avgUtilization}%`} hint="billable utilization" icon={Users} trend={{ value: 6, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="MRR" value={formatCurrency(48000)} hint="monthly recurring" icon={DollarSign} trend={{ value: 22, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Outstanding" value={formatCurrency(totalOutstanding)} hint="across clients" icon={Clock} trend={{ value: 4, positive: false }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Revenue trend */}
      <ChartCard title="Revenue Trend" subtitle="Monthly revenue, last 12 months" className="mb-4">
        <PlannaAreaChart
          data={[
            { month: "Feb", revenue: 32, target: 35 },
            { month: "Mar", revenue: 35, target: 36 },
            { month: "Apr", revenue: 38, target: 38 },
            { month: "May", revenue: 41, target: 40 },
            { month: "Jun", revenue: 39, target: 42 },
            { month: "Jul", revenue: 43, target: 44 },
            { month: "Aug", revenue: 45, target: 46 },
            { month: "Sep", revenue: 44, target: 48 },
            { month: "Oct", revenue: 47, target: 50 },
            { month: "Nov", revenue: 50, target: 52 },
            { month: "Dec", revenue: 48, target: 54 },
            { month: "Jan", revenue: 52, target: 56 },
          ]}
          xKey="month"
          series={[
            { key: "revenue", name: "Revenue ($K)" },
            { key: "target", name: "Target ($K)", color: "var(--chart-4)" },
          ]}
          height={260}
        />
      </ChartCard>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Client projects */}
        <Card className="p-4 md:p-5 lg:col-span-2 card-lift">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold">Active Client Engagements</h3>
            <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
              <Link href="/clients">All <ArrowUpRight className="w-3 h-3" /></Link>
            </Button>
          </div>
          <div className="space-y-3">
            {clientProjects.map(p => (
              <Link key={p.id} href={`/projects/${p.id}`} className="block p-3 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/30 transition-colors group">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", p.color)}>
                      <Briefcase className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-foreground group-hover:text-primary transition-colors">{p.name}</p>
                      <p className="text-[10px] text-muted-foreground">{p.client} · due {relativeDay(p.dueDate)}</p>
                    </div>
                  </div>
                  <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px]">{p.status}</Badge>
                </div>
                <div className="flex items-center gap-3">
                  <Progress value={p.progress} className="h-1.5 flex-1" />
                  <span className="text-[11px] font-semibold text-muted-foreground w-8">{p.progress}%</span>
                </div>
                <div className="flex items-center justify-between mt-2 text-[10px] text-muted-foreground">
                  <span>{p.tasksDone}/{p.tasksTotal} tasks</span>
                  <span>{formatCurrency(p.spent)} of {formatCurrency(p.budget)}</span>
                </div>
              </Link>
            ))}
          </div>
        </Card>

        {/* Team utilization */}
        <Card className="p-4 md:p-5 card-lift">
          <h3 className="text-sm font-semibold mb-4">Team Utilization</h3>
          <div className="space-y-3">
            {members.slice(0, 6).map(m => {
              const utilization = Math.round((m.utilized / m.capacity) * 100)
              return (
                <Link key={m.id} href={`/team/${m.id}`} className="block">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-5 h-5"><AvatarImage src={m.avatar} alt={m.name} /><AvatarFallback className="text-[9px]">{m.name[0]}</AvatarFallback></Avatar>
                      <span className="text-xs text-foreground">{m.name.split(" ")[0]}</span>
                    </div>
                    <span className={cn("text-[11px] font-semibold",
                      utilization >= 90 ? "text-rose-600 dark:text-rose-400" :
                      utilization >= 70 ? "text-emerald-600 dark:text-emerald-400" :
                      "text-muted-foreground"
                    )}>{utilization}%</span>
                  </div>
                  <Progress value={utilization} className="h-1.5" />
                </Link>
              )
            })}
          </div>
        </Card>
      </div>

      {/* Invoices summary */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Recent Invoices</h3>
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
            <Link href="/clients/invoices">All</Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
            <p className="text-xs text-muted-foreground mb-1">Paid (30d)</p>
            <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(invoices.filter(i => i.status === "paid").reduce((s, i) => s + i.total, 0))}</p>
          </div>
          <div className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
            <p className="text-xs text-muted-foreground mb-1">Outstanding</p>
            <p className="text-xl font-bold text-amber-600 dark:text-amber-400">{formatCurrency(invoices.filter(i => i.status === "sent").reduce((s, i) => s + i.total, 0))}</p>
          </div>
          <div className="p-3 rounded-lg bg-rose-500/5 border border-rose-500/20">
            <p className="text-xs text-muted-foreground mb-1">Overdue</p>
            <p className="text-xl font-bold text-rose-600 dark:text-rose-400">{formatCurrency(invoices.filter(i => i.status === "overdue").reduce((s, i) => s + i.total, 0))}</p>
          </div>
        </div>
      </Card>
    </DashboardShell>
  )
}
