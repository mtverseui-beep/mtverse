"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaBarChart, PlannaDonutChart, PlannaAreaChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Briefcase, DollarSign, Clock, AlertTriangle, Plus, FileText, TrendingUp, ArrowUpRight, Star } from "lucide-react"
import { clients, invoices, projects } from "@/lib/data/mock"
import Link from "next/link"
import { cn, formatCurrency, timeAgo, relativeDay } from "@/lib/utils"

export default function ClientWorkDashboard() {
  const activeClients = clients.filter(c => c.status === "active")
  const totalRevenue = clients.reduce((s, c) => s + c.totalRevenue, 0)
  const outstanding = clients.reduce((s, c) => s + c.outstanding, 0)
  const overdueInv = invoices.filter(i => i.status === "overdue")

  return (
    <DashboardShell
      title="Client Work Dashboard"
      description="Revenue, deliverables, and outstanding items across all clients."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <FileText className="w-4 h-4" /> Proposals
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> Add client
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Clients" value={activeClients.length} hint={`of ${clients.length} total`} icon={Briefcase} trend={{ value: 12, positive: true }} />
        <StatCard label="Total Revenue" value={formatCurrency(totalRevenue)} hint="all-time" icon={DollarSign} trend={{ value: 18, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Outstanding" value={formatCurrency(outstanding)} hint={`${overdueInv.length} overdue invoices`} icon={AlertTriangle} trend={{ value: 5, positive: false }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Project Value" value={formatCurrency(75000)} hint="per engagement" icon={TrendingUp} trend={{ value: 8, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Revenue by Client" subtitle="Last 12 months" className="lg:col-span-2">
          <PlannaBarChart
            data={clients.filter(c => c.totalRevenue > 0).map(c => ({ name: c.name.split(" ")[0], revenue: c.totalRevenue / 1000 }))}
            xKey="name"
            series={[{ key: "revenue", name: "Revenue ($K)", color: "var(--chart-1)" }]}
            height={260}
            showLegend={false}
          />
        </ChartCard>
        <ChartCard title="Invoice Status" subtitle="Outstanding by status" fullscreen={false}>
          <PlannaDonutChart
            data={[
              { name: "Paid", value: invoices.filter(i => i.status === "paid").length, color: "var(--chart-1)" },
              { name: "Sent", value: invoices.filter(i => i.status === "sent").length, color: "var(--chart-3)" },
              { name: "Overdue", value: invoices.filter(i => i.status === "overdue").length, color: "var(--chart-5)" },
              { name: "Draft", value: invoices.filter(i => i.status === "draft").length, color: "var(--chart-4)" },
            ]}
            centerValue={String(invoices.length)}
            centerLabel="invoices"
            height={240}
          />
        </ChartCard>
      </div>

      {/* Client cards */}
      <Card className="p-4 md:p-5 mb-4 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Top Clients</h3>
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
            <Link href="/clients">All clients <ArrowUpRight className="w-3 h-3" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {activeClients.map(c => (
            <Link
              key={c.id}
              href={`/clients/${c.id}`}
              className="p-4 rounded-xl border border-border bg-card hover:shadow-md hover:border-primary/30 transition-all duration-300 hover:-translate-y-0.5 group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <Avatar className="w-10 h-10 rounded-lg"><AvatarImage src={c.logo} alt={c.name} /><AvatarFallback className="rounded-lg">{c.name[0]}</AvatarFallback></Avatar>
                  <div>
                    <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{c.name}</p>
                    <p className="text-[11px] text-muted-foreground">{c.industry}</p>
                  </div>
                </div>
                <Badge className={cn("text-[10px]", c.status === "active" ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-muted text-muted-foreground")}>
                  {c.status}
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-3 border-t border-border">
                <div>
                  <p className="text-xs font-bold text-foreground">{formatCurrency(c.totalRevenue)}</p>
                  <p className="text-[10px] text-muted-foreground">Revenue</p>
                </div>
                <div>
                  <p className="text-xs font-bold text-foreground">{c.projectsCount}</p>
                  <p className="text-[10px] text-muted-foreground">Projects</p>
                </div>
              </div>
              {c.outstanding > 0 && (
                <div className="mt-3 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20">
                  <p className="text-[10px] text-amber-700 dark:text-amber-400">
                    {formatCurrency(c.outstanding)} outstanding
                  </p>
                </div>
              )}
            </Link>
          ))}
        </div>
      </Card>

      {/* Recent invoices */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Recent Invoices</h3>
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
            <Link href="/clients/invoices">All invoices</Link>
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="py-2 pr-3 font-medium">Invoice</th>
                <th className="py-2 px-3 font-medium">Client</th>
                <th className="py-2 px-3 font-medium">Status</th>
                <th className="py-2 px-3 font-medium">Due</th>
                <th className="py-2 pl-3 font-medium text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {invoices.slice(0, 6).map(inv => (
                <tr key={inv.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="py-2.5 pr-3 font-mono text-xs">{inv.number}</td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-5 h-5 rounded"><AvatarImage src={inv.clientLogo} alt={inv.clientName} /><AvatarFallback className="rounded text-[9px]">{inv.clientName[0]}</AvatarFallback></Avatar>
                      <span className="text-xs">{inv.clientName}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    <Badge className={cn("text-[10px]",
                      inv.status === "paid" ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" :
                      inv.status === "overdue" ? "bg-rose-500/15 text-rose-600 dark:text-rose-400" :
                      inv.status === "sent" ? "bg-sky-500/15 text-sky-600 dark:text-sky-400" :
                      "bg-muted text-muted-foreground"
                    )}>{inv.status}</Badge>
                  </td>
                  <td className="py-2.5 px-3 text-xs text-muted-foreground">{relativeDay(inv.dueDate)}</td>
                  <td className="py-2.5 pl-3 text-right text-xs font-semibold">{formatCurrency(inv.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </DashboardShell>
  )
}
