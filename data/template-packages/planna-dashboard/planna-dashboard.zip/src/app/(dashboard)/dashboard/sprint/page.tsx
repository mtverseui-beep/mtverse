"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaLineChart, PlannaBarChart, PlannaRadialChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Rocket, Target, CheckCircle2, AlertTriangle, Plus, Flag, GitBranch, TrendingUp, Clock } from "lucide-react"
import { sprints, sprintVelocityHistory, burndownData, tasks, members } from "@/lib/data/mock"
import { PriorityBadge, TaskStatusBadge } from "@/components/common/badges"
import Link from "next/link"
import { cn, relativeDay, pct } from "@/lib/utils"

export default function SprintDashboard() {
  const active = sprints.find(s => s.status === "active")!
  const remaining = active.storyPointsCommitted - active.storyPointsCompleted
  return (
    <DashboardShell
      title="Sprint Dashboard"
      description={`Sprint 47 — ${active.goal}`}
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <GitBranch className="w-4 h-4" /> Backlog
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New sprint
          </Button>
        </>
      }
    >
      {/* Active sprint banner */}
      <Card className="p-5 mb-4 bg-gradient-to-r from-primary/10 via-card to-card border-primary/20 card-lift">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Rocket className="w-4 h-4 text-primary" />
              <p className="text-xs font-semibold text-primary uppercase tracking-wider">Active sprint</p>
            </div>
            <h2 className="text-xl font-bold text-foreground">{active.name}</h2>
            <p className="text-xs text-muted-foreground mt-1">{active.goal}</p>
            <div className="flex items-center gap-3 mt-3 text-xs">
              <span className="text-muted-foreground">Ends in <span className="font-semibold text-foreground">7 days</span></span>
              <span className="text-muted-foreground">·</span>
              <span className="text-muted-foreground">{active.tasksDone}/{active.tasksTotal} tasks done</span>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground tabular-nums">{active.storyPointsCompleted}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Completed</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-muted-foreground tabular-nums">{remaining}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Remaining</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground tabular-nums">{pct(active.storyPointsCompleted, active.storyPointsCommitted)}%</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Done</p>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Sprint Goal" value="68%" hint="of plan completed" icon={Target} trend={{ value: 8, positive: true }} />
        <StatCard label="Velocity" value="54 pts" hint="3-sprint avg" icon={TrendingUp} trend={{ value: 12, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="In Progress" value={tasks.filter(t => t.status === "in_progress").length} hint="tasks active" icon={Clock} trend={{ value: 0, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Blocked" value={tasks.filter(t => t.status === "blocked").length} hint="needs attention" icon={AlertTriangle} trend={{ value: 1, positive: false }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Burndown */}
        <ChartCard title="Sprint Burndown" subtitle="Ideal vs actual progress" className="lg:col-span-2">
          <PlannaLineChart
            data={burndownData}
            xKey="day"
            series={[
              { key: "ideal", name: "Ideal", color: "var(--chart-4)", dashed: true },
              { key: "actual", name: "Actual", color: "var(--chart-1)" },
            ]}
            height={260}
          />
        </ChartCard>

        {/* Sprint progress radial */}
        <ChartCard title="Sprint Progress" subtitle="Story points completion" fullscreen={false}>
          <div className="flex flex-col items-center gap-3 py-4">
            <PlannaRadialChart value={pct(active.storyPointsCompleted, active.storyPointsCommitted)} label="complete" size={180} />
            <p className="text-xs text-muted-foreground text-center">
              {active.storyPointsCompleted} of {active.storyPointsCommitted} pts
            </p>
          </div>
        </ChartCard>
      </div>

      {/* Velocity + in-progress tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <ChartCard title="Velocity History" subtitle="Last 6 sprints" fullscreen={false}>
          <PlannaBarChart
            data={sprintVelocityHistory}
            xKey="sprint"
            series={[
              { key: "planned", name: "Planned", color: "var(--chart-4)" },
              { key: "completed", name: "Completed", color: "var(--chart-1)" },
            ]}
            height={240}
          />
        </ChartCard>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold">In Progress</h3>
            <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
              <Link href="/tasks">All tasks</Link>
            </Button>
          </div>
          <div className="space-y-2 max-h-80 overflow-y-auto scroll-area-thin">
            {tasks.filter(t => t.status === "in_progress").slice(0, 6).map(t => (
              <Link key={t.id} href={`/tasks/${t.id}`} className="block p-2.5 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/30 transition-colors group">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
                  <PriorityBadge priority={t.priority} />
                  <span className="ml-auto text-[10px] text-muted-foreground">{relativeDay(t.dueDate ?? "")}</span>
                </div>
                <p className="text-xs font-medium text-foreground line-clamp-1 group-hover:text-primary transition-colors">{t.title}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] text-muted-foreground">{t.projectName}</span>
                  {t.assigneeAvatar && <Avatar className="w-5 h-5"><AvatarImage src={t.assigneeAvatar} alt={t.assignee ?? ""} /><AvatarFallback className="text-[9px]">{t.assignee?.[0]}</AvatarFallback></Avatar>}
                </div>
              </Link>
            ))}
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
