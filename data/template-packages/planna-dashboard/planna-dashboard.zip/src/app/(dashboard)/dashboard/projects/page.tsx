"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaBarChart, PlannaDonutChart, PlannaRadialChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { FolderKanban, CheckCircle2, Clock, AlertTriangle, Plus, Filter, Download, DollarSign, TrendingUp, ArrowUpRight } from "lucide-react"
import { projects, timeByProject } from "@/lib/data/mock"
import { HealthBadge, ProjectStatusBadge } from "@/components/common/badges"
import Link from "next/link"
import { cn, relativeDay, formatCurrency, pct } from "@/lib/utils"

export default function ProjectDashboard() {
  const active = projects.filter(p => p.status === "active")
  const totalBudget = projects.reduce((s, p) => s + p.budget, 0)
  const totalSpent = projects.reduce((s, p) => s + p.spent, 0)
  const totalTasks = projects.reduce((s, p) => s + p.tasksTotal, 0)
  const doneTasks = projects.reduce((s, p) => s + p.tasksDone, 0)

  return (
    <DashboardShell
      title="Project Dashboard"
      description="Portfolio health, budgets, and progress at a glance."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Filters
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New project
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Projects" value={active.length} hint={`of ${projects.length} total`} icon={FolderKanban} trend={{ value: 8, positive: true }} />
        <StatCard label="Tasks Progress" value={`${pct(doneTasks, totalTasks)}%`} hint={`${doneTasks}/${totalTasks} done`} icon={CheckCircle2} trend={{ value: 4, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Budget Used" value={pct(totalSpent, totalBudget) + "%"} hint={`${formatCurrency(totalSpent)} of ${formatCurrency(totalBudget)}`} icon={DollarSign} trend={{ value: 12, positive: false }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="At Risk" value={projects.filter(p => p.health === "at_risk").length} hint="needs attention" icon={AlertTriangle} trend={{ value: 2, positive: false }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Project portfolio table */}
      <Card className="p-4 md:p-5 mb-4 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Project Portfolio</h3>
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
            <Link href="/projects">View all <ArrowUpRight className="w-3 h-3" /></Link>
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="py-2 pr-3 font-medium">Project</th>
                <th className="py-2 px-3 font-medium">Status</th>
                <th className="py-2 px-3 font-medium">Health</th>
                <th className="py-2 px-3 font-medium">Progress</th>
                <th className="py-2 px-3 font-medium">Lead</th>
                <th className="py-2 px-3 font-medium">Due</th>
                <th className="py-2 pl-3 font-medium text-right">Budget</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {projects.slice(0, 8).map(p => (
                <tr key={p.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="py-2.5 pr-3">
                    <Link href={`/projects/${p.id}`} className="flex items-center gap-2.5">
                      <div className={cn("w-7 h-7 rounded-md flex items-center justify-center shrink-0", p.color)}>
                        <FolderKanban className="w-3.5 h-3.5 text-white" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-foreground truncate group-hover:text-primary">{p.name}</p>
                        <p className="text-[10px] text-muted-foreground">{p.key}</p>
                      </div>
                    </Link>
                  </td>
                  <td className="py-2.5 px-3"><ProjectStatusBadge status={p.status} /></td>
                  <td className="py-2.5 px-3"><HealthBadge health={p.health} /></td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-2 min-w-[120px]">
                      <Progress value={p.progress} className="h-1.5 flex-1" />
                      <span className="text-[11px] font-semibold text-muted-foreground w-8 text-right">{p.progress}%</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-1.5">
                      <Avatar className="w-5 h-5"><AvatarImage src={p.leadAvatar} alt={p.lead} /><AvatarFallback className="text-[9px]">{p.lead[0]}</AvatarFallback></Avatar>
                      <span className="text-xs text-muted-foreground truncate max-w-[80px]">{p.lead.split(" ")[0]}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-xs text-muted-foreground">{relativeDay(p.dueDate)}</td>
                  <td className="py-2.5 pl-3 text-right">
                    <p className="text-xs font-semibold">{formatCurrency(p.spent)}</p>
                    <p className="text-[10px] text-muted-foreground">of {formatCurrency(p.budget)}</p>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        <ChartCard title="Hours by Project" subtitle="Last 30 days" className="lg:col-span-2">
          <PlannaBarChart
            data={timeByProject}
            xKey="name"
            series={[{ key: "hours", name: "Hours", color: "var(--chart-1)" }]}
            height={240}
            showLegend={false}
          />
        </ChartCard>
        <ChartCard title="Status Mix" subtitle="Distribution of project states" fullscreen={false}>
          <PlannaDonutChart
            data={[
              { name: "Active", value: projects.filter(p => p.status === "active").length, color: "var(--chart-1)" },
              { name: "Planning", value: projects.filter(p => p.status === "planning").length, color: "var(--chart-3)" },
              { name: "On Hold", value: projects.filter(p => p.status === "on_hold").length, color: "var(--chart-4)" },
              { name: "Completed", value: projects.filter(p => p.status === "completed").length, color: "var(--chart-2)" },
            ]}
            centerValue={String(projects.length)}
            centerLabel="projects"
            height={240}
          />
        </ChartCard>
      </div>
    </DashboardShell>
  )
}
