"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaAreaChart, PlannaBarChart, PlannaDonutChart, PlannaRadialChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, DollarSign, Users, FolderKanban, Download, ArrowUpRight, Target, AlertTriangle } from "lucide-react"
import { projects, members, clients, productivityTrend } from "@/lib/data/mock"
import { HealthBadge } from "@/components/common/badges"
import Link from "next/link"
import { cn, formatCurrency, pct } from "@/lib/utils"

export default function ExecutiveDashboard() {
  return (
    <DashboardShell
      title="Executive Overview"
      description="Company-wide KPIs, growth, and operational health."
      actions={
        <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
          <Download className="w-4 h-4" /> Export report
        </Button>
      }
    >
      {/* Hero KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="MRR" value="$48K" hint="+22% vs last month" icon={DollarSign} trend={{ value: 22, positive: true }} />
        <StatCard label="Active Users" value="2,847" hint="weekly active" icon={Users} trend={{ value: 18, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Projects" value={projects.filter(p => p.status === "active").length} hint="active across org" icon={FolderKanban} trend={{ value: 8, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="On-Time Delivery" value="94%" hint="last 30 days" icon={Target} trend={{ value: 4, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Big trend */}
      <ChartCard
        title="Revenue & Growth"
        subtitle="MRR and active workspaces, last 12 months"
        className="mb-4"
        action={
          <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] gap-1">
            <TrendingUp className="w-3 h-3" /> Trending up
          </Badge>
        }
      >
        <PlannaAreaChart
          data={[
            { month: "Feb", mrr: 32, users: 1800 },
            { month: "Mar", mrr: 35, users: 1950 },
            { month: "Apr", mrr: 38, users: 2100 },
            { month: "May", mrr: 41, users: 2250 },
            { month: "Jun", mrr: 39, users: 2380 },
            { month: "Jul", mrr: 43, users: 2490 },
            { month: "Aug", mrr: 45, users: 2560 },
            { month: "Sep", mrr: 44, users: 2620 },
            { month: "Oct", mrr: 47, users: 2700 },
            { month: "Nov", mrr: 50, users: 2780 },
            { month: "Dec", mrr: 48, users: 2810 },
            { month: "Jan", mrr: 52, users: 2847 },
          ]}
          xKey="month"
          series={[
            { key: "mrr", name: "MRR ($K)" },
            { key: "users", name: "Active Users", color: "var(--chart-2)" },
          ]}
          height={280}
        />
      </ChartCard>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Org health */}
        <Card className="p-4 md:p-5 card-lift">
          <h3 className="text-sm font-semibold mb-4">Org Health</h3>
          <div className="space-y-3">
            {[
              { label: "On Track", count: projects.filter(p => p.health === "on_track").length, color: "bg-emerald-500" },
              { label: "At Risk", count: projects.filter(p => p.health === "at_risk").length, color: "bg-amber-500" },
              { label: "Off Track", count: projects.filter(p => p.health === "off_track").length, color: "bg-rose-500" },
            ].map(h => (
              <div key={h.label} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={cn("w-2 h-2 rounded-full", h.color)} />
                  <span className="text-xs text-foreground">{h.label}</span>
                </div>
                <span className="text-sm font-bold text-foreground">{h.count}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-[10px] text-muted-foreground mb-2 uppercase tracking-wider">Overall Score</p>
            <div className="flex items-center justify-center py-2">
              <PlannaRadialChart value={84} label="Healthy" size={120} />
            </div>
          </div>
        </Card>

        {/* Department spend */}
        <ChartCard title="Spend by Department" subtitle="Q1 2026 actuals" fullscreen={false}>
          <PlannaBarChart
            data={[
              { name: "Eng", spend: 280 },
              { name: "Design", spend: 95 },
              { name: "Product", spend: 120 },
              { name: "Marketing", spend: 75 },
              { name: "Ops", spend: 60 },
              { name: "Support", spend: 45 },
            ]}
            xKey="name"
            series={[{ key: "spend", name: "Spend ($K)", color: "var(--chart-1)" }]}
            height={220}
            showLegend={false}
          />
        </ChartCard>

        {/* Revenue by client tier */}
        <ChartCard title="Revenue Mix" subtitle="By client tier" fullscreen={false}>
          <PlannaDonutChart
            data={[
              { name: "Enterprise", value: 280, color: "var(--chart-1)" },
              { name: "Mid-Market", value: 180, color: "var(--chart-2)" },
              { name: "SMB", value: 95, color: "var(--chart-3)" },
              { name: "Self-serve", value: 45, color: "var(--chart-4)" },
            ]}
            centerValue="$600K"
            centerLabel="ARR"
            height={220}
          />
        </ChartCard>
      </div>

      {/* At-risk projects */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold">Projects Requiring Attention</h3>
          </div>
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
            <Link href="/projects">All projects <ArrowUpRight className="w-3 h-3" /></Link>
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
                <th className="py-2 pr-3 font-medium">Project</th>
                <th className="py-2 px-3 font-medium">Health</th>
                <th className="py-2 px-3 font-medium">Budget Used</th>
                <th className="py-2 px-3 font-medium">Progress</th>
                <th className="py-2 pl-3 font-medium">Owner</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {projects.filter(p => p.health !== "on_track").map(p => (
                <tr key={p.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="py-2.5 pr-3">
                    <Link href={`/projects/${p.id}`} className="text-xs font-medium hover:text-primary transition-colors">{p.name}</Link>
                  </td>
                  <td className="py-2.5 px-3"><HealthBadge health={p.health} /></td>
                  <td className="py-2.5 px-3">
                    <span className={cn("text-xs font-semibold",
                      pct(p.spent, p.budget) > 80 ? "text-rose-600 dark:text-rose-400" : "text-foreground"
                    )}>
                      {pct(p.spent, p.budget)}%
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-xs">{p.progress}%</td>
                  <td className="py-2.5 pl-3 text-xs text-muted-foreground">{p.lead}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </DashboardShell>
  )
}
