"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaRadialChart, PlannaBarChart, PlannaHeatmap } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { User, CheckSquare, Clock, Target, Plus, Sparkles, Coffee, Flame, Brain, Zap, Heart, Moon } from "lucide-react"
import { currentMember, focusHeatmap, tasks } from "@/lib/data/mock"
import { PriorityBadge, TaskStatusBadge } from "@/components/common/badges"
import Link from "next/link"
import { cn, relativeDay, timeAgo } from "@/lib/utils"

export default function PersonalDashboard() {
  return (
    <DashboardShell
      title="My Dashboard"
      description="Your tasks, focus, and personal productivity at a glance."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Coffee className="w-4 h-4" /> Take a break
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> Quick add
          </Button>
        </>
      }
    >
      {/* Personal hero card */}
      <Card className="p-5 mb-4 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20 card-lift">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <Avatar className="w-14 h-14 ring-2 ring-primary/20">
              <AvatarImage src={currentMember.avatar} alt={currentMember.name} />
              <AvatarFallback>{currentMember.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-xs text-muted-foreground">Welcome back,</p>
              <h2 className="text-lg font-bold text-foreground">{currentMember.name}</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                You have <span className="font-semibold text-foreground">8 tasks</span> due this week. Let's make it count.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-foreground tabular-nums">5</p>
              <p className="text-[10px] text-muted-foreground uppercase">Day streak</p>
            </div>
            <div className="w-px h-10 bg-border" />
            <div className="text-center">
              <p className="text-2xl font-bold text-foreground tabular-nums">87</p>
              <p className="text-[10px] text-muted-foreground uppercase">Score</p>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="My Tasks" value="8" hint="due this week" icon={CheckSquare} trend={{ value: 12, positive: true }} />
        <StatCard label="Focus Today" value="4.2h" hint="of 6h goal" icon={Brain} trend={{ value: 14, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Completed" value="42" hint="this month" icon={Target} trend={{ value: 20, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Wellbeing" value="Good" hint="balanced load" icon={Heart} trend={{ value: 4, positive: true }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Today's tasks */}
        <Card className="p-4 md:p-5 lg:col-span-2 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold">Today's Focus</h3>
              <p className="text-[11px] text-muted-foreground">3 deep work blocks scheduled</p>
            </div>
            <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
              <Link href="/tasks/my">All my tasks</Link>
            </Button>
          </div>
          <div className="space-y-2">
            {tasks.filter(t => t.assignee === currentMember.name).slice(0, 5).map(t => (
              <Link
                key={t.id}
                href={`/tasks/${t.id}`}
                className="block p-3 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/30 transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    className="w-4 h-4 rounded border-border accent-primary shrink-0"
                    checked={t.status === "done"}
                    onChange={(e) => e.preventDefault()}
                  />
                  <div className="flex-1 min-w-0">
                    <p className={cn(
                      "text-xs font-medium line-clamp-1 group-hover:text-primary transition-colors",
                      t.status === "done" && "line-through text-muted-foreground"
                    )}>
                      {t.title}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
                      <PriorityBadge priority={t.priority} />
                      {t.dueDate && <span className="text-[10px] text-muted-foreground">{relativeDay(t.dueDate)}</span>}
                    </div>
                  </div>
                  <TaskStatusBadge status={t.status} />
                </div>
              </Link>
            ))}
          </div>
        </Card>

        {/* Wellbeing radial */}
        <ChartCard title="Daily Balance" subtitle="How your day is shaping up" fullscreen={false}>
          <div className="flex flex-col items-center gap-4 py-4">
            <PlannaRadialChart value={72} label="Balanced" size={160} />
            <div className="grid grid-cols-2 gap-3 w-full">
              <div className="text-center p-2 rounded-lg bg-violet-500/10">
                <Brain className="w-4 h-4 text-violet-500 mx-auto mb-1" />
                <p className="text-xs font-bold">4.2h</p>
                <p className="text-[10px] text-muted-foreground">Focus</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-amber-500/10">
                <Coffee className="w-4 h-4 text-amber-500 mx-auto mb-1" />
                <p className="text-xs font-bold">3</p>
                <p className="text-[10px] text-muted-foreground">Breaks</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-emerald-500/10">
                <Moon className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
                <p className="text-xs font-bold">7.5h</p>
                <p className="text-[10px] text-muted-foreground">Sleep</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-rose-500/10">
                <Heart className="w-4 h-4 text-rose-500 mx-auto mb-1" />
                <p className="text-xs font-bold">Good</p>
                <p className="text-[10px] text-muted-foreground">Mood</p>
              </div>
            </div>
          </div>
        </ChartCard>
      </div>

      {/* Weekly focus + habits */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        <ChartCard title="Focus Pattern" subtitle="When you focus best" fullscreen={false}>
          <PlannaHeatmap data={focusHeatmap} />
        </ChartCard>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <Flame className="w-4 h-4 text-orange-500" />
            <h3 className="text-sm font-semibold">Habit Streaks</h3>
          </div>
          <div className="space-y-3">
            {[
              { name: "Deep work block (90 min)", streak: 12, max: 14, color: "bg-violet-500" },
              { name: "Daily planning", streak: 28, max: 30, color: "bg-emerald-500" },
              { name: "No meetings before 10am", streak: 5, max: 5, color: "bg-amber-500" },
              { name: "Walk after lunch", streak: 8, max: 14, color: "bg-rose-500" },
              { name: "Inbox zero by EOD", streak: 3, max: 7, color: "bg-teal-500" },
            ].map(h => (
              <div key={h.name}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className={cn("w-2 h-2 rounded-full", h.color)} />
                    <p className="text-xs font-medium text-foreground">{h.name}</p>
                  </div>
                  <span className="text-[11px] font-bold text-foreground">
                    {h.streak} <span className="text-muted-foreground font-normal">/ {h.max}d</span>
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className={cn("h-full rounded-full transition-all duration-500", h.color)} style={{ width: `${(h.streak / h.max) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
