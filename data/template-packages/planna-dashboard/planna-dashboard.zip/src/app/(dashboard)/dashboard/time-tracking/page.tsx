"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaAreaChart, PlannaBarChart, PlannaDonutChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Clock, DollarSign, Timer, Play, Pause, Square, Plus, TrendingUp, CheckCircle2, Coffee } from "lucide-react"
import { timeEntries, members, projects } from "@/lib/data/mock"
import { useTimerStore, formatTimer, getElapsed } from "@/lib/store/timer-store"
import { useEffect, useState } from "react"
import { cn, formatDuration, timeAgo, formatCurrency } from "@/lib/utils"
import Link from "next/link"

export default function TimeTrackingDashboard() {
  const timer = useTimerStore()
  const [, force] = useState(0)
  useEffect(() => {
    if (!timer.running) return
    const i = setInterval(() => force(x => x + 1), 1000)
    return () => clearInterval(i)
  }, [timer.running])

  const elapsed = getElapsed()
  const totalHours = timeEntries.reduce((s, e) => s + e.duration, 0) / 3600
  const billableHours = timeEntries.filter(e => e.billable).reduce((s, e) => s + e.duration, 0) / 3600
  const billablePct = Math.round((billableHours / totalHours) * 100)

  return (
    <DashboardShell
      title="Time Tracking Dashboard"
      description="Hours logged, billable utilization, and live sessions."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Plus className="w-4 h-4" /> Manual entry
          </Button>
          <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Link href="/time/timesheets">View timesheets</Link>
          </Button>
        </>
      }
    >
      {/* Live timer + weekly summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Big timer card */}
        <Card className="p-5 lg:col-span-2 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Timer className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Live Tracker</h3>
              {timer.running && (
                <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Running
                </Badge>
              )}
            </div>
            <Badge variant="outline" className="text-[10px]">{timer.billable ? "Billable" : "Non-billable"}</Badge>
          </div>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <p className="text-5xl font-bold text-foreground tabular-nums tracking-tight">
                {formatTimer(elapsed)}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                {timer.projectName} {timer.taskId && `· Task ${timer.taskId}`}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {!timer.running ? (
                <Button size="lg" className="h-12 px-6 gap-2 bg-primary hover:bg-primary/90" onClick={() => timer.start()}>
                  <Play className="w-4 h-4" /> Start
                </Button>
              ) : (
                <Button size="lg" variant="outline" className="h-12 px-6 gap-2" onClick={() => timer.pause()}>
                  <Pause className="w-4 h-4" /> Pause
                </Button>
              )}
              <Button size="lg" variant="ghost" className="h-12 px-4" onClick={() => timer.reset()} disabled={elapsed === 0 && !timer.running}>
                <Square className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>

        {/* Today summary */}
        <Card className="p-5 card-lift">
          <h3 className="text-sm font-semibold mb-4">Today</h3>
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-muted-foreground">Tracked</span>
                <span className="text-xs font-semibold">5h 23m</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: "67%" }} />
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">of 8h goal</p>
            </div>
            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-border">
              <div>
                <p className="text-lg font-bold text-foreground">3h 45m</p>
                <p className="text-[10px] text-muted-foreground">Billable</p>
              </div>
              <div>
                <p className="text-lg font-bold text-foreground">1h 38m</p>
                <p className="text-[10px] text-muted-foreground">Non-billable</p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Hours This Week" value={`${Math.round(totalHours)}h`} hint="across team" icon={Clock} trend={{ value: 8, positive: true }} />
        <StatCard label="Billable %" value={`${billablePct}%`} hint={`${Math.round(billableHours)}h billable`} icon={DollarSign} trend={{ value: 4, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Pending Approval" value={timeEntries.filter(e => e.status === "submitted").length} hint="entries awaiting" icon={CheckCircle2} trend={{ value: 0, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Session" value="42m" hint="per focus block" icon={Coffee} trend={{ value: 6, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Daily Hours" subtitle="Last 14 days" className="lg:col-span-2">
          <PlannaAreaChart
            data={Array.from({ length: 14 }).map((_, i) => ({
              day: `D${i + 1}`,
              hours: 4 + Math.round(Math.random() * 5),
              billable: 2 + Math.round(Math.random() * 4),
            }))}
            xKey="day"
            series={[
              { key: "hours", name: "Total" },
              { key: "billable", name: "Billable", color: "var(--chart-2)" },
            ]}
            height={260}
          />
        </ChartCard>
        <ChartCard title="Time Split" subtitle="Billable vs non-billable" fullscreen={false}>
          <PlannaDonutChart
            data={[
              { name: "Billable", value: billableHours, color: "var(--chart-1)" },
              { name: "Non-billable", value: totalHours - billableHours, color: "var(--chart-4)" },
            ]}
            centerValue={`${billablePct}%`}
            centerLabel="billable"
            height={240}
          />
        </ChartCard>
      </div>

      {/* Recent entries */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Recent Time Entries</h3>
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
            <Link href="/time/entries">All entries</Link>
          </Button>
        </div>
        <div className="space-y-1.5">
          {timeEntries.slice(0, 6).map(e => (
            <div key={e.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-secondary/30 transition-colors">
              <Avatar className="w-8 h-8"><AvatarImage src={e.memberAvatar} alt={e.memberName} /><AvatarFallback>{e.memberName[0]}</AvatarFallback></Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground truncate">{e.description}</p>
                <p className="text-[10px] text-muted-foreground">{e.projectName} · {timeAgo(e.start)}</p>
              </div>
              <div className="text-right">
                <p className="text-xs font-semibold text-foreground tabular-nums">{formatDuration(e.duration)}</p>
                <Badge variant="outline" className={cn("text-[9px] mt-0.5", e.billable ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground")}>
                  {e.billable ? "Billable" : "Non-bill"}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </DashboardShell>
  )
}
