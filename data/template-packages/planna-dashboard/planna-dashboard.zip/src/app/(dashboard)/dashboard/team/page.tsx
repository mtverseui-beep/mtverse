"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaBarChart, PlannaDonutChart, PlannaRadialChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Users, UserPlus, Clock, CheckCircle2, Activity, TrendingUp, MessageSquare, Star, ArrowUpRight, Zap } from "lucide-react"
import { members, activities, workloadByMember } from "@/lib/data/mock"
import { RoleBadge } from "@/components/common/badges"
import Link from "next/link"
import { cn, timeAgo } from "@/lib/utils"

export default function TeamDashboard() {
  const online = members.filter(m => m.online).length
  const totalTasks = members.reduce((s, m) => s + m.activeTasks, 0)
  const totalCompleted = members.reduce((s, m) => s + m.completedTasks, 0)

  return (
    <DashboardShell
      title="Team Dashboard"
      description="Who's online, what they're shipping, and where they need help."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Activity className="w-4 h-4" /> Activity feed
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <UserPlus className="w-4 h-4" /> Invite member
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Team Members" value={members.length} hint={`${online} online now`} icon={Users} trend={{ value: 8, positive: true }} />
        <StatCard label="Active Tasks" value={totalTasks} hint="across team" icon={Zap} trend={{ value: 4, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Completed (30d)" value={totalCompleted} hint="tasks shipped" icon={CheckCircle2} trend={{ value: 18, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Avg Utilization" value="74%" hint="this week" icon={Clock} trend={{ value: 6, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Online members strip */}
      <Card className="p-4 md:p-5 mb-4 card-lift">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">Online now</h3>
          <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> {online} active
          </Badge>
        </div>
        <div className="flex flex-wrap gap-3">
          {members.filter(m => m.online).map(m => (
            <Link
              key={m.id}
              href={`/team/${m.id}`}
              className="flex items-center gap-2 p-2 pr-3 rounded-full bg-secondary/50 hover:bg-secondary transition-colors group"
            >
              <div className="relative">
                <Avatar className="w-7 h-7"><AvatarImage src={m.avatar} alt={m.name} /><AvatarFallback className="text-xs">{m.name[0]}</AvatarFallback></Avatar>
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-card" />
              </div>
              <div>
                <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors">{m.name.split(" ")[0]}</p>
                <p className="text-[10px] text-muted-foreground">{m.title}</p>
              </div>
            </Link>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Workload chart */}
        <ChartCard title="Workload Distribution" subtitle="Hours per member this week" className="lg:col-span-2">
          <PlannaBarChart
            data={workloadByMember}
            xKey="name"
            series={[
              { key: "utilized", name: "Utilized", color: "var(--chart-1)" },
              { key: "capacity", name: "Capacity", color: "var(--chart-4)" },
            ]}
            height={260}
          />
        </ChartCard>

        {/* Activity stream */}
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold">Recent Activity</h3>
            <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
              <Link href="/team/activity">All</Link>
            </Button>
          </div>
          <div className="space-y-3 max-h-80 overflow-y-auto scroll-area-thin">
            {activities.slice(0, 7).map(a => (
              <div key={a.id} className="flex items-start gap-2.5">
                <Avatar className="w-6 h-6 shrink-0"><AvatarImage src={a.actorAvatar} alt={a.actor} /><AvatarFallback className="text-[10px]">{a.actor[0]}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] text-foreground">
                    <span className="font-semibold">{a.actor.split(" ")[0]}</span>{" "}
                    <span className="text-muted-foreground">{a.action}</span>{" "}
                    <span className="font-medium">{a.target}</span>
                  </p>
                  <p className="text-[10px] text-muted-foreground">{timeAgo(a.createdAt)}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Team table */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Team Members</h3>
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs gap-1">
            <Link href="/team">All members <ArrowUpRight className="w-3 h-3" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {members.slice(0, 6).map(m => (
            <Link
              key={m.id}
              href={`/team/${m.id}`}
              className="p-3 rounded-xl border border-border bg-card hover:shadow-md hover:border-primary/30 transition-all duration-300 hover:-translate-y-0.5 group"
            >
              <div className="flex items-center gap-3 mb-3">
                <Avatar className="w-10 h-10"><AvatarImage src={m.avatar} alt={m.name} /><AvatarFallback>{m.name[0]}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors truncate">{m.name}</p>
                  <p className="text-[11px] text-muted-foreground truncate">{m.title}</p>
                </div>
                <RoleBadge role={m.role} />
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <p className="text-xs font-bold text-foreground">{m.activeTasks}</p>
                  <p className="text-[10px] text-muted-foreground">Active</p>
                </div>
                <div>
                  <p className="text-xs font-bold text-foreground">{m.completedTasks}</p>
                  <p className="text-[10px] text-muted-foreground">Done</p>
                </div>
                <div>
                  <p className="text-xs font-bold text-foreground">{Math.round((m.utilized / m.capacity) * 100)}%</p>
                  <p className="text-[10px] text-muted-foreground">Load</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </Card>
    </DashboardShell>
  )
}
