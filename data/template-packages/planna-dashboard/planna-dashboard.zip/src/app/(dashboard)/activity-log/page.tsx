"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Activity as ActivityIcon, ListTodo, MessageSquare, FileText, FolderPlus,
  UserPlus, Search, Download, Filter, ChevronDown, ChevronRight,
  Calendar, User, Sparkles, Clock,
} from "lucide-react"
import { activities as seedActivities, members, currentMember } from "@/lib/data/mock"
import { cn, timeAgo, formatDate, initials } from "@/lib/utils"
import { toast } from "sonner"
import type { Activity } from "@/types"

// ============================================================
// ENRICH ACTIVITIES — synthesize extra for richer timeline
// ============================================================

const extraActivities: Activity[] = [
  { id: "ax-1", actor: "Zara Marlowe", actorAvatar: members[1].avatar, action: "created", target: "PLN-110 — Push notification settings UI", createdAt: "2026-01-28T13:00:00Z", type: "task" },
  { id: "ax-2", actor: "Amara Okafor", actorAvatar: members[5].avatar, action: "commented on", target: "PLN-103 — WebSocket reconnect logic", createdAt: "2026-01-28T11:20:00Z", type: "comment" },
  { id: "ax-3", actor: "Felix Brandt", actorAvatar: members[4].avatar, action: "uploaded", target: "Onboarding flow v3.png", createdAt: "2026-01-28T09:40:00Z", type: "file" },
  { id: "ax-4", actor: "Theo Nakamura", actorAvatar: members[2].avatar, action: "started", target: "Focus session — Architecture review (45m)", createdAt: "2026-01-28T08:30:00Z", type: "task" },
  { id: "ax-5", actor: "Mira Patel", actorAvatar: members[3].avatar, action: "shared", target: "Design tokens v3.json with #design-system", createdAt: "2026-01-27T15:00:00Z", type: "file" },
  { id: "ax-6", actor: "Sofia Vargas", actorAvatar: members[11].avatar, action: "completed", target: "DSGN-402 — Accessibility audit of color tokens", createdAt: "2026-01-27T12:00:00Z", type: "task" },
  { id: "ax-7", actor: "Jessin Sam", actorAvatar: currentMember.avatar, action: "approved", target: "PLN-108 for review", createdAt: "2026-01-27T10:15:00Z", type: "task" },
  { id: "ax-8", actor: "Isla Reyes", actorAvatar: members[9].avatar, action: "joined", target: "Launch Campaign Q1", createdAt: "2026-01-26T09:00:00Z", type: "team" },
  { id: "ax-9", actor: "Hugo Lindqvist", actorAvatar: members[8].avatar, action: "blocked", target: "INF-501 — pending staging quota", createdAt: "2026-01-26T07:30:00Z", type: "task" },
  { id: "ax-10", actor: "Zara Marlowe", actorAvatar: members[1].avatar, action: "updated", target: "Sprint 47 — Velocity goal", createdAt: "2026-01-25T16:45:00Z", type: "project" },
  { id: "ax-11", actor: "Leon Cruz", actorAvatar: members[6].avatar, action: "moved", target: "MOB-201 → Review", createdAt: "2026-01-25T11:20:00Z", type: "task" },
  { id: "ax-12", actor: "Naomi Chen", actorAvatar: members[7].avatar, action: "uploaded", target: "QA-702 test report.pdf", createdAt: "2026-01-24T14:00:00Z", type: "file" },
  { id: "ax-13", actor: "Amara Okafor", actorAvatar: members[5].avatar, action: "completed", target: "API-301 — Rate limiting middleware", createdAt: "2026-01-24T09:30:00Z", type: "task" },
  { id: "ax-14", actor: "Theo Nakamura", actorAvatar: members[2].avatar, action: "created", target: "Sprint 48 — Polishing", createdAt: "2026-01-23T13:00:00Z", type: "project" },
  { id: "ax-15", actor: "Ravi Kapoor", actorAvatar: members[10].avatar, action: "invited", target: "sofia@planna.app to Design team", createdAt: "2026-01-22T10:00:00Z", type: "team" },
  { id: "ax-16", actor: "Felix Brandt", actorAvatar: members[4].avatar, action: "commented on", target: "ARC-601 — Custom onboarding for Acme", createdAt: "2026-01-22T08:30:00Z", type: "comment" },
  { id: "ax-17", actor: "Mira Patel", actorAvatar: members[3].avatar, action: "starred", target: "Q1 2026 Roadmap.pdf", createdAt: "2026-01-21T14:30:00Z", type: "file" },
  { id: "ax-18", actor: "Jessin Sam", actorAvatar: currentMember.avatar, action: "updated", target: "Workspace → Appearance theme", createdAt: "2026-01-21T09:00:00Z", type: "project" },
  { id: "ax-19", actor: "Hugo Lindqvist", actorAvatar: members[8].avatar, action: "deployed", target: "v2.4.1 hotfix to production", createdAt: "2026-01-20T18:00:00Z", type: "project" },
  { id: "ax-20", actor: "Zara Marlowe", actorAvatar: members[1].avatar, action: "completed", target: "Milestone: API v2 launch", createdAt: "2026-01-20T10:00:00Z", type: "project" },
]

const allActivities = [...extraActivities, ...seedActivities].sort(
  (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
)

// ============================================================
// TYPE CONFIG
// ============================================================

const typeConfig: Record<Activity["type"], { label: string; icon: typeof ListTodo; chip: string; verb: string }> = {
  task:    { label: "Tasks",    icon: ListTodo,      chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", verb: "task" },
  comment: { label: "Comments", icon: MessageSquare, chip: "bg-sky-500/15 text-sky-600 dark:text-sky-400",            verb: "comment" },
  file:    { label: "Files",    icon: FileText,      chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400",      verb: "file" },
  project: { label: "Projects", icon: FolderPlus,    chip: "bg-teal-500/15 text-teal-600 dark:text-teal-400",         verb: "project" },
  team:    { label: "Team",     icon: UserPlus,      chip: "bg-rose-500/15 text-rose-600 dark:text-rose-400",         verb: "team" },
}

const filterTabs = [
  { key: "all", label: "All", icon: ActivityIcon },
  ...Object.entries(typeConfig).map(([key, c]) => ({ key, label: c.label, icon: c.icon })),
] as const

// ============================================================
// DATE GROUPING
// ============================================================

function getDateGroup(dateStr: string): string {
  const d = new Date(dateStr)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const target = new Date(d)
  target.setHours(0, 0, 0, 0)
  const diff = Math.floor((today.getTime() - target.getTime()) / 86400000)
  if (diff === 0) return "Today"
  if (diff === 1) return "Yesterday"
  if (diff > 1 && diff < 7) return "This week"
  if (diff >= 7 && diff < 14) return "Last week"
  return "Earlier"
}

const groupOrder = ["Today", "Yesterday", "This week", "Last week", "Earlier"]

// ============================================================
// CSV EXPORT
// ============================================================

function exportCsv(rows: Activity[]) {
  const headers = ["ID", "Actor", "Action", "Target", "Type", "Timestamp", "ISO Date"]
  const csv = [
    headers.join(","),
    ...rows.map(r => [
      r.id,
      `"${r.actor.replace(/"/g, '""')}"`,
      `"${r.action.replace(/"/g, '""')}"`,
      `"${r.target.replace(/"/g, '""')}"`,
      r.type,
      `"${timeAgo(r.createdAt)}"`,
      new Date(r.createdAt).toISOString(),
    ].join(",")),
  ].join("\n")

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = `planna-activity-log-${new Date().toISOString().slice(0, 10)}.csv`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
  toast.success("CSV exported", { description: `${rows.length} activities → ${a.download}` })
}

// ============================================================
// PAGE
// ============================================================

export default function ActivityLogPage() {
  const [filter, setFilter] = useState<string>("all")
  const [actorFilter, setActorFilter] = useState<string>("all")
  const [search, setSearch] = useState("")
  const [limit, setLimit] = useState(20)

  const actors = useMemo(() => {
    const map = new Map<string, { id: string; name: string; avatar: string }>()
    allActivities.forEach(a => map.set(a.actor, { id: a.actor, name: a.actor, avatar: a.actorAvatar }))
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name))
  }, [])

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: allActivities.length }
    Object.keys(typeConfig).forEach(k => { c[k] = allActivities.filter(a => a.type === k).length })
    return c
  }, [])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return allActivities
      .filter(a => filter === "all" || a.type === filter)
      .filter(a => actorFilter === "all" || a.actor === actorFilter)
      .filter(a => !q || a.target.toLowerCase().includes(q) || a.action.toLowerCase().includes(q) || a.actor.toLowerCase().includes(q))
  }, [filter, actorFilter, search])

  const visible = filtered.slice(0, limit)

  const grouped = useMemo(() => {
    const groups: { group: string; items: Activity[] }[] = []
    visible.forEach(a => {
      const g = getDateGroup(a.createdAt)
      const last = groups[groups.length - 1]
      if (last && last.group === g) last.items.push(a)
      else groups.push({ group: g, items: [a] })
    })
    return groups.sort((a, b) => groupOrder.indexOf(a.group) - groupOrder.indexOf(b.group))
  }, [visible])

  const handleExport = () => {
    if (filtered.length === 0) {
      toast.error("Nothing to export", { description: "Adjust your filters to include at least one activity." })
      return
    }
    exportCsv(filtered)
  }

  return (
    <DashboardShell
      title="Activity log"
      description="A complete audit trail of every action across your workspace. Filter, search, and export."
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent" onClick={handleExport}>
            <Download className="w-3.5 h-3.5" /> Export CSV
          </Button>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent">
            <Filter className="w-3.5 h-3.5" /> Advanced
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total events" value={allActivities.length} hint="last 14 days" icon={ActivityIcon} />
        <StatCard label="Tasks" value={counts.task ?? 0} hint="task activity" icon={ListTodo} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Comments" value={counts.comment ?? 0} hint="discussions" icon={MessageSquare} iconColor="bg-sky-500/15 text-sky-600 dark:text-sky-400" />
        <StatCard label="Files" value={counts.file ?? 0} hint="uploads & shares" icon={FileText} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Filters — search + actor + filter pills */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="flex flex-col md:flex-row gap-2 mb-3">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by action, target, or actor…"
              className="h-9 pl-8 text-xs"
            />
          </div>
          <Select value={actorFilter} onValueChange={setActorFilter}>
            <SelectTrigger className="h-9 text-xs w-full md:w-[200px]">
              <User className="w-3.5 h-3.5 mr-1 text-muted-foreground" />
              <SelectValue placeholder="All actors" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All actors</SelectItem>
              {actors.map(a => (
                <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar -mx-1 px-1">
          {filterTabs.map(tab => {
            const isActive = filter === tab.key
            const count = counts[tab.key] ?? 0
            return (
              <button
                key={tab.key}
                onClick={() => { setFilter(tab.key); setLimit(20) }}
                className={cn(
                  "shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-muted-foreground border-border hover:bg-secondary hover:text-foreground"
                )}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
                <span className={cn(
                  "ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-semibold",
                  isActive ? "bg-primary-foreground/20 text-primary-foreground" : "bg-secondary text-muted-foreground"
                )}>
                  {count}
                </span>
              </button>
            )
          })}
        </div>
      </Card>

      {/* Timeline */}
      {grouped.length === 0 ? (
        <EmptyState
          icon={ActivityIcon}
          title="No activity matches your filters"
          description="Try clearing filters or broadening your search to see team activity."
          action={{ label: "Clear filters", onClick: () => { setSearch(""); setFilter("all"); setActorFilter("all") } }}
        />
      ) : (
        <Card className="p-4 md:p-5 card-lift">
          <div className="space-y-6">
            {grouped.map(group => (
              <div key={group.group}>
                {/* Day header */}
                <div className="flex items-center gap-2 mb-3 sticky top-0 bg-card z-10 py-1">
                  <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground">{group.group}</span>
                  <span className="text-[10px] text-muted-foreground">· {group.items.length} event{group.items.length !== 1 ? "s" : ""}</span>
                  <div className="flex-1 h-px bg-border" />
                  <span className="text-[10px] text-muted-foreground hidden sm:block">
                    {formatDate(group.items[0].createdAt, { month: "short", day: "numeric", year: "numeric" })}
                  </span>
                </div>

                {/* Timeline entries */}
                <div className="space-y-1">
                  {group.items.map((a, idx) => {
                    const cfg = typeConfig[a.type] ?? typeConfig.task
                    const actorMember = members.find(m => m.name === a.actor) ?? (a.actor === currentMember.name ? { id: "u1" } : null)
                    const isLast = idx === group.items.length - 1
                    return (
                      <div
                        key={a.id}
                        className="flex items-start gap-3 p-2 rounded-lg hover:bg-secondary/40 transition-colors group animate-fade-in"
                      >
                        {/* Timeline rail */}
                        <div className="relative flex flex-col items-center">
                          <Avatar className="w-8 h-8 ring-2 ring-card">
                            <AvatarImage src={a.actorAvatar} alt={a.actor} />
                            <AvatarFallback className="text-[10px]">{initials(a.actor)}</AvatarFallback>
                          </Avatar>
                          {!isLast && (
                            <div className="w-px flex-1 bg-border mt-1 min-h-[24px]" />
                          )}
                        </div>

                        {/* Body */}
                        <div className="flex-1 min-w-0 pt-0.5">
                          <p className="text-xs text-foreground leading-relaxed">
                            {actorMember?.id ? (
                              <Link
                                href={actorMember.id === "u1" ? "/team" : `/team/${actorMember.id}`}
                                className="font-semibold text-foreground hover:text-primary transition-colors"
                              >
                                {a.actor}
                              </Link>
                            ) : (
                              <span className="font-semibold">{a.actor}</span>
                            )}{" "}
                            <span className="text-muted-foreground">{a.action}</span>{" "}
                            <span className="font-medium text-foreground">{a.target}</span>
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={cn("inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded", cfg.chip)}>
                              <cfg.icon className="w-2.5 h-2.5" />
                              {cfg.verb}
                            </span>
                            <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                              <Clock className="w-2.5 h-2.5" />
                              {timeAgo(a.createdAt)}
                            </span>
                            <Link
                              href="#"
                              className="text-[10px] text-muted-foreground hover:text-primary transition-colors opacity-0 group-hover:opacity-100 flex items-center gap-0.5"
                            >
                              View context <ChevronRight className="w-2.5 h-2.5" />
                            </Link>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Load more */}
          {filtered.length > visible.length && (
            <div className="mt-4 pt-4 border-t border-border text-center">
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 bg-transparent"
                onClick={() => setLimit(l => l + 20)}
              >
                Load more <ChevronDown className="w-3.5 h-3.5" />
              </Button>
              <p className="text-[10px] text-muted-foreground mt-2">
                Showing {visible.length} of {filtered.length} events
              </p>
            </div>
          )}
        </Card>
      )}

      {/* Footer */}
      {filtered.length > 0 && (
        <div className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
          <Sparkles className="w-3 h-3" />
          {filtered.length} event{filtered.length !== 1 ? "s" : ""} matched ·{" "}
          <button onClick={handleExport} className="text-primary hover:underline">
            Export to CSV
          </button>
        </div>
      )}
    </DashboardShell>
  )
}
