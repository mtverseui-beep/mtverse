"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Avatar, AvatarFallback, AvatarImage,
} from "@/components/ui/avatar"
import {
  Plus, Tag, Rocket, CheckCircle2, Clock, Package, Calendar,
  CheckCircle, Circle, CircleDot, FileText, Download, GitCommit,
  AlertCircle,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn, formatDate, relativeDay } from "@/lib/utils"

type ReleaseStatus = "released" | "planned" | "beta" | "at_risk"

interface ReleaseFeature {
  title: string
  status: "done" | "in_progress" | "planned"
  project: string
}

interface Release {
  id: string
  version: string
  codename: string
  status: ReleaseStatus
  releaseDate: string
  releaseLead: string
  releaseLeadAvatar: string
  description: string
  completion: number
  features: ReleaseFeature[]
  commits: number
  contributors: string[]
  notes: string
}

const releases: Release[] = [
  {
    id: "r1",
    version: "v2.0",
    codename: "Velocity",
    status: "planned",
    releaseDate: "2026-05-30",
    releaseLead: "Zara Marlowe",
    releaseLeadAvatar: members[1].avatar,
    description: "Major release: command palette, recurring tasks, real-time collaboration, and refreshed design system.",
    completion: 42,
    commits: 184,
    contributors: [members[1].avatar, members[2].avatar, members[4].avatar, members[5].avatar, members[3].avatar],
    notes: "Includes breaking changes to webhooks API. Migration guide will be published two weeks before release.",
    features: [
      { title: "Command palette (Cmd+K)", status: "done", project: "PLN" },
      { title: "Recurring tasks scheduler", status: "in_progress", project: "PLN" },
      { title: "WebSocket live presence", status: "in_progress", project: "PLN" },
      { title: "Design System 2.0 tokens", status: "in_progress", project: "DSGN" },
      { title: "Notification preferences UI", status: "planned", project: "PLN" },
      { title: "Calendar month view", status: "planned", project: "PLN" },
    ],
  },
  {
    id: "r2",
    version: "v2.0-beta",
    codename: "Aurora",
    status: "beta",
    releaseDate: "2026-04-15",
    releaseLead: "Theo Nakamura",
    releaseLeadAvatar: members[2].avatar,
    description: "Public beta for early access customers. Focus on stability and performance under load.",
    completion: 68,
    commits: 142,
    contributors: [members[2].avatar, members[4].avatar, members[5].avatar, members[8].avatar],
    notes: "Beta channel opt-in via Settings → Labs. Bug reports tagged with 'v2.0-beta' label.",
    features: [
      { title: "Kanban drag-and-drop", status: "done", project: "PLN" },
      { title: "Time tracker widget", status: "done", project: "PLN" },
      { title: "WebSocket reconnect logic", status: "in_progress", project: "PLN" },
      { title: "Accessibility audit", status: "in_progress", project: "DSGN" },
      { title: "API rate limiting", status: "done", project: "API" },
    ],
  },
  {
    id: "r3",
    version: "v1.2",
    codename: "Horizon",
    status: "at_risk",
    releaseDate: "2026-03-20",
    releaseLead: "Leon Cruz",
    releaseLeadAvatar: members[6].avatar,
    description: "Mobile companion beta for iOS TestFlight and Android internal track.",
    completion: 55,
    commits: 96,
    contributors: [members[6].avatar, members[3].avatar, members[7].avatar],
    notes: "iOS push notifications blocked on APNs cert renewal. Android widget delayed to v1.2.1.",
    features: [
      { title: "iOS push notifications", status: "in_progress", project: "MOB" },
      { title: "Android widget", status: "planned", project: "MOB" },
      { title: "Offline mode", status: "planned", project: "MOB" },
      { title: "Acme SSO integration", status: "in_progress", project: "ARC" },
      { title: "Acme onboarding flow", status: "in_progress", project: "ARC" },
    ],
  },
  {
    id: "r4",
    version: "v1.1",
    codename: "Pioneer",
    status: "released",
    releaseDate: "2026-02-12",
    releaseLead: "Amara Okafor",
    releaseLeadAvatar: members[5].avatar,
    description: "QoL improvements: webhook retries, audit logs, and SOC2 readiness features.",
    completion: 100,
    commits: 211,
    contributors: [members[5].avatar, members[8].avatar, members[2].avatar, members[7].avatar],
    notes: "Released on schedule. Post-mortem: API rate-limit rollout caused 4 brief throttling events on day 1.",
    features: [
      { title: "Webhook delivery retries", status: "done", project: "API" },
      { title: "Audit log retention", status: "done", project: "API" },
      { title: "Pen test remediation", status: "done", project: "SEC" },
      { title: "API v2 endpoints", status: "done", project: "API" },
    ],
  },
  {
    id: "r5",
    version: "v1.0",
    codename: "Genesis",
    status: "released",
    releaseDate: "2026-01-05",
    releaseLead: "Jessin Sam",
    releaseLeadAvatar: members[0].avatar,
    description: "Initial public launch of Planna. Core dashboard, tasks, projects, and team collaboration.",
    completion: 100,
    commits: 428,
    contributors: [members[0].avatar, members[1].avatar, members[2].avatar, members[3].avatar, members[4].avatar, members[5].avatar],
    notes: "Launch-day metrics: 312 signups, 14 paid conversions, 0 critical incidents.",
    features: [
      { title: "Dashboard with widgets", status: "done", project: "PLN" },
      { title: "Task list and detail view", status: "done", project: "PLN" },
      { title: "Projects with members", status: "done", project: "PLN" },
      { title: "Team roles and permissions", status: "done", project: "PLN" },
      { title: "Time tracking", status: "done", project: "PLN" },
    ],
  },
]

type Filter = "all" | ReleaseStatus

const statusConfig: Record<ReleaseStatus, { label: string; className: string; dot: string; icon: typeof Rocket }> = {
  released: { label: "Released",  className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500", icon: Rocket },
  beta:     { label: "In Beta",   className: "bg-violet-500/15 text-violet-600 dark:text-violet-400",   dot: "bg-violet-500", icon: CircleDot },
  planned:  { label: "Planned",   className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",            dot: "bg-sky-500",    icon: Clock },
  at_risk:  { label: "At Risk",   className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",         dot: "bg-rose-500",   icon: AlertCircle },
}

const featureIcon = { done: CheckCircle, in_progress: CircleDot, planned: Circle }
const featureColor = {
  done: "text-emerald-500",
  in_progress: "text-amber-500",
  planned: "text-muted-foreground/50",
}

export default function ReleasesPage() {
  const [filter, setFilter] = useState<Filter>("all")

  const counts = {
    all: releases.length,
    released: releases.filter(r => r.status === "released").length,
    beta: releases.filter(r => r.status === "beta").length,
    planned: releases.filter(r => r.status === "planned").length,
    at_risk: releases.filter(r => r.status === "at_risk").length,
  }

  const filtered = filter === "all" ? releases : releases.filter(r => r.status === filter)

  // Sort: at_risk, beta, planned, released (reverse chronological within same status)
  const sortOrder: ReleaseStatus[] = ["at_risk", "beta", "planned", "released"]
  const sorted = useMemo(() =>
    [...filtered].sort((a, b) => {
      const sa = sortOrder.indexOf(a.status)
      const sb = sortOrder.indexOf(b.status)
      if (sa !== sb) return sa - sb
      return new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime()
    }),
  [filtered])

  const nextRelease = sorted.find(r => r.status !== "released")

  return (
    <DashboardShell
      title="Releases"
      description="Plan, track, and ship versioned product releases"
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <FileText className="w-4 h-4" /> Changelog
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New release
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Releases" value={counts.all} hint="all time" icon={Package} />
        <StatCard label="Shipped" value={counts.released} hint="released to GA" icon={Rocket} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="In Beta" value={counts.beta} hint="early access" icon={CircleDot} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Up Next" value={nextRelease?.version ?? "—"} hint={nextRelease ? relativeDay(nextRelease.releaseDate) : "no planned"} icon={Tag} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Filter tabs */}
      <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)} className="mb-4">
        <TabsList className="h-9 flex-wrap">
          <TabsTrigger value="all" className="text-xs gap-1.5">All <span className="text-[10px] text-muted-foreground">{counts.all}</span></TabsTrigger>
          <TabsTrigger value="released" className="text-xs gap-1.5">Released <span className="text-[10px] text-muted-foreground">{counts.released}</span></TabsTrigger>
          <TabsTrigger value="beta" className="text-xs gap-1.5">Beta <span className="text-[10px] text-muted-foreground">{counts.beta}</span></TabsTrigger>
          <TabsTrigger value="planned" className="text-xs gap-1.5">Planned <span className="text-[10px] text-muted-foreground">{counts.planned}</span></TabsTrigger>
          <TabsTrigger value="at_risk" className="text-xs gap-1.5">At Risk <span className="text-[10px] text-muted-foreground">{counts.at_risk}</span></TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Release cards */}
      <div className="space-y-4">
        {sorted.map((r, idx) => {
          const sc = statusConfig[r.status]
          const StatusIcon = sc.icon
          const doneFeatures = r.features.filter(f => f.status === "done").length
          const isReleased = r.status === "released"

          return (
            <Card
              key={r.id}
              className={cn(
                "p-4 md:p-5 card-lift animate-slide-in-up overflow-hidden",
                isReleased && "opacity-90",
              )}
              style={{ animationDelay: `${idx * 60}ms` }}
            >
              <div className="flex flex-col lg:flex-row lg:items-start gap-4">
                {/* Left: version identity */}
                <div className="lg:w-56 shrink-0 flex lg:flex-col items-center lg:items-start gap-3 lg:gap-2 lg:border-r lg:border-border lg:pr-4">
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
                    sc.className
                  )}>
                    <StatusIcon className="w-6 h-6" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-lg font-bold text-foreground tabular-nums leading-none">{r.version}</p>
                    <p className="text-xs text-muted-foreground italic mt-1">"{r.codename}"</p>
                    <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full inline-flex items-center gap-1.5 mt-2", sc.className)}>
                      <span className={cn("w-1.5 h-1.5 rounded-full", sc.dot)} />
                      {sc.label}
                    </span>
                  </div>
                </div>

                {/* Middle: description + features */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <p className="text-sm text-muted-foreground">{r.description}</p>
                  </div>

                  {/* Meta */}
                  <div className="flex items-center gap-4 flex-wrap text-xs text-muted-foreground mb-3">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {formatDate(r.releaseDate)}
                      <span className="text-muted-foreground/70">· {relativeDay(r.releaseDate)}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <GitCommit className="w-3 h-3" />
                      {r.commits} commits
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Avatar className="w-5 h-5 ring-1 ring-border">
                        <AvatarImage src={r.releaseLeadAvatar} alt={r.releaseLead} />
                        <AvatarFallback className="text-[9px]">{r.releaseLead[0]}</AvatarFallback>
                      </Avatar>
                      {r.releaseLead}
                    </span>
                    <span className="flex items-center -space-x-1.5">
                      {r.contributors.slice(0, 4).map((a, i) => (
                        <Avatar key={i} className="w-5 h-5 ring-2 ring-card">
                          <AvatarImage src={a} alt="" />
                          <AvatarFallback className="text-[8px]">?</AvatarFallback>
                        </Avatar>
                      ))}
                      {r.contributors.length > 4 && (
                        <span className="w-5 h-5 rounded-full bg-muted ring-2 ring-card text-[9px] font-semibold text-muted-foreground flex items-center justify-center">
                          +{r.contributors.length - 4}
                        </span>
                      )}
                    </span>
                  </div>

                  {/* Completion bar */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-muted-foreground">Completion</span>
                      <span className="font-semibold text-foreground tabular-nums">{r.completion}%</span>
                    </div>
                    <Progress value={r.completion} className={cn("h-1.5", r.status === "at_risk" && "[&>div]:bg-rose-500")} />
                  </div>

                  {/* Features */}
                  <div className="rounded-lg border border-border bg-secondary/20 p-3">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs font-semibold text-foreground">Included Features</p>
                      <span className="text-[10px] text-muted-foreground">
                        {doneFeatures}/{r.features.length} done
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                      {r.features.map((f, i) => {
                        const Icon = featureIcon[f.status]
                        return (
                          <div key={i} className="flex items-center gap-2 text-xs">
                            <Icon className={cn("w-3.5 h-3.5 shrink-0", featureColor[f.status])} />
                            <span className={cn(
                              "line-clamp-1",
                              f.status === "done" ? "text-muted-foreground line-through" : "text-foreground"
                            )}>
                              {f.title}
                            </span>
                            <Badge variant="outline" className="text-[9px] font-mono ml-auto shrink-0">
                              {f.project}
                            </Badge>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  {/* Release notes */}
                  <div className="mt-3 flex items-start gap-2 text-xs text-muted-foreground">
                    <FileText className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">{r.notes}</p>
                  </div>
                </div>

                {/* Right: actions */}
                <div className="lg:w-32 shrink-0 flex lg:flex-col gap-2">
                  {isReleased ? (
                    <>
                      <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent flex-1 lg:flex-none">
                        <Download className="w-3.5 h-3.5" /> Notes
                      </Button>
                      <Button variant="ghost" size="sm" className="h-8 text-xs gap-1.5 flex-1 lg:flex-none">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Shipped
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button size="sm" className="h-8 text-xs bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5 flex-1 lg:flex-none">
                        <Rocket className="w-3.5 h-3.5" /> Track
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent flex-1 lg:flex-none">
                        <FileText className="w-3.5 h-3.5" /> Notes
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </Card>
          )
        })}

        {sorted.length === 0 && (
          <Card className="p-12 text-center border-dashed">
            <Package className="w-10 h-10 mx-auto text-muted-foreground/60 mb-3" />
            <p className="text-sm font-medium text-foreground">No releases in this view</p>
            <p className="text-xs text-muted-foreground mt-1">Try a different filter tab.</p>
          </Card>
        )}
      </div>
    </DashboardShell>
  )
}
