"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Plus, Layers, Boxes, Clock, AlertCircle,
  Calendar, ChevronRight, GitBranch, TrendingUp, Filter, Search,
} from "lucide-react"
import { tasks, projects, members } from "@/lib/data/mock"
import { ProjectStatusBadge } from "@/components/common/badges"
import { cn, relativeDay, isOverdue } from "@/lib/utils"
import type { Task, TaskStatus } from "@/types"

const storyPoints = (t: Task) => Math.max(1, Math.round((t.estimateHours ?? 4) / 2))

interface Epic {
  id: string
  key: string
  title: string
  description: string
  projectId: string
  owner: string
  ownerAvatar: string
  startDate: string
  dueDate: string
  status: "in_progress" | "planned" | "done" | "at_risk"
  // Child task keys (matched against mock tasks by key)
  taskKeys: string[]
}

const epics: Epic[] = [
  {
    id: "e1",
    key: "PLN-EPIC-1",
    title: "Command Palette & Quick Actions",
    description: "Universal Cmd+K surface for navigation, search, and quick task actions across the app.",
    projectId: "p1",
    owner: "Felix Brandt",
    ownerAvatar: members[4].avatar,
    startDate: "2026-01-15",
    dueDate: "2026-02-28",
    status: "in_progress",
    taskKeys: ["PLN-101", "PLN-104", "PLN-105", "PLN-106", "PLN-107"],
  },
  {
    id: "e2",
    key: "PLN-EPIC-2",
    title: "Real-time Collaboration",
    description: "WebSocket-based presence, live cursors, and instant task updates across team members.",
    projectId: "p1",
    owner: "Amara Okafor",
    ownerAvatar: members[5].avatar,
    startDate: "2026-01-20",
    dueDate: "2026-03-15",
    status: "in_progress",
    taskKeys: ["PLN-103", "PLN-104", "PLN-108"],
  },
  {
    id: "e3",
    key: "MOB-EPIC-1",
    title: "Mobile Offline Mode",
    description: "Full offline parity for tasks, projects, and comments with conflict resolution on sync.",
    projectId: "p2",
    owner: "Leon Cruz",
    ownerAvatar: members[6].avatar,
    startDate: "2026-02-01",
    dueDate: "2026-04-30",
    status: "at_risk",
    taskKeys: ["MOB-201", "MOB-202", "MOB-203"],
  },
  {
    id: "e4",
    key: "API-EPIC-1",
    title: "API Platform Hardening",
    description: "Rate limiting, webhook retries, dead-letter queues, and audit log retention for GA readiness.",
    projectId: "p3",
    owner: "Amara Okafor",
    ownerAvatar: members[5].avatar,
    startDate: "2025-12-10",
    dueDate: "2026-01-20",
    status: "done",
    taskKeys: ["API-301", "API-302"],
  },
  {
    id: "e5",
    key: "DSGN-EPIC-1",
    title: "Design System 2.0",
    description: "Refreshed component library, color tokens, and accessibility audit across all surfaces.",
    projectId: "p4",
    owner: "Mira Patel",
    ownerAvatar: members[3].avatar,
    startDate: "2026-01-05",
    dueDate: "2026-02-28",
    status: "in_progress",
    taskKeys: ["DSGN-401", "DSGN-402", "DSGN-403", "PLN-102"],
  },
  {
    id: "e6",
    key: "INF-EPIC-1",
    title: "Infrastructure Migration",
    description: "Migrate monolith services to Kubernetes with blue-green deploys and full observability stack.",
    projectId: "p6",
    owner: "Hugo Lindqvist",
    ownerAvatar: members[8].avatar,
    startDate: "2025-11-01",
    dueDate: "2026-04-15",
    status: "at_risk",
    taskKeys: ["INF-501", "INF-502"],
  },
  {
    id: "e7",
    key: "ARC-EPIC-1",
    title: "Acme Custom Onboarding",
    description: "Branded onboarding flow with SSO and custom steps for Acme Corp's enterprise deployment.",
    projectId: "p9",
    owner: "Felix Brandt",
    ownerAvatar: members[4].avatar,
    startDate: "2026-01-10",
    dueDate: "2026-04-30",
    status: "in_progress",
    taskKeys: ["ARC-601", "ARC-602"],
  },
  {
    id: "e8",
    key: "SEC-EPIC-1",
    title: "Security & Compliance",
    description: "Pen test remediation, access control hardening, and SOC2 Type 1 audit readiness.",
    projectId: "p12",
    owner: "Amara Okafor",
    ownerAvatar: members[5].avatar,
    startDate: "2026-01-08",
    dueDate: "2026-03-31",
    status: "in_progress",
    taskKeys: ["SEC-901", "ARC-602", "API-301"],
  },
]

const epicStatusConfig: Record<Epic["status"], { label: string; className: string; dot: string }> = {
  in_progress: { label: "In Progress", className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",       dot: "bg-amber-500" },
  planned:     { label: "Planned",     className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",            dot: "bg-sky-500" },
  done:        { label: "Done",        className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  at_risk:     { label: "At Risk",     className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",         dot: "bg-rose-500" },
}

type GroupKey = "project" | "owner" | "status"

interface EnrichedEpic extends Epic {
  childTasks: Task[]
  byStatus: Record<TaskStatus, number>
  totalPoints: number
  donePoints: number
  progress: number
  project: typeof projects[0]
}

export default function EpicsPage() {
  const [search, setSearch] = useState("")
  const [groupBy, setGroupBy] = useState<GroupKey>("project")
  const [statusFilter, setStatusFilter] = useState<Epic["status"] | "all">("all")

  // Enrich epics with child task data
  const enrichedEpics = useMemo(() => epics.map(epic => {
    const childTasks = tasks.filter(t => epic.taskKeys.includes(t.key))
    const byStatus: Record<TaskStatus, number> = {
      backlog: 0, todo: 0, in_progress: 0, review: 0, done: 0, blocked: 0,
    }
    for (const t of childTasks) byStatus[t.status]++
    const totalPoints = childTasks.reduce((s, t) => s + storyPoints(t), 0)
    const donePoints = childTasks.filter(t => t.status === "done").reduce((s, t) => s + storyPoints(t), 0)
    const progress = totalPoints === 0 ? 0 : Math.round((donePoints / totalPoints) * 100)
    const project = projects.find(p => p.id === epic.projectId)!
    return { ...epic, childTasks, byStatus, totalPoints, donePoints, progress, project }
  }), [])

  // Filter
  const filtered = useMemo(() => {
    let result = enrichedEpics
    if (statusFilter !== "all") result = result.filter(e => e.status === statusFilter)
    if (search) {
      const q = search.toLowerCase()
      result = result.filter(e =>
        e.title.toLowerCase().includes(q) ||
        e.key.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q) ||
        e.owner.toLowerCase().includes(q)
      )
    }
    return result
  }, [enrichedEpics, statusFilter, search])

  // Group
  const groups = useMemo(() => {
    if (groupBy === "project") {
      const map = new Map<string, { name: string; color: string; items: typeof enrichedEpics }>()
      for (const e of filtered) {
        if (!map.has(e.project.id)) map.set(e.project.id, { name: e.project.name, color: e.project.color, items: [] })
        map.get(e.project.id)!.items.push(e)
      }
      return Array.from(map.entries()).map(([id, v]) => ({ id, ...v }))
    }
    if (groupBy === "owner") {
      const map = new Map<string, { name: string; color: string; items: typeof enrichedEpics }>()
      for (const e of filtered) {
        if (!map.has(e.owner)) map.set(e.owner, { name: e.owner, color: "bg-muted", items: [] })
        map.get(e.owner)!.items.push(e)
      }
      return Array.from(map.entries()).map(([id, v]) => ({ id, ...v }))
    }
    // group by status
    const order: Epic["status"][] = ["at_risk", "in_progress", "planned", "done"]
    return order
      .map(s => ({ id: s, name: epicStatusConfig[s].label, color: "bg-muted", items: filtered.filter(e => e.status === s) }))
      .filter(g => g.items.length > 0)
  }, [filtered, groupBy])

  const totalPoints = enrichedEpics.reduce((s, e) => s + e.totalPoints, 0)
  const donePoints = enrichedEpics.reduce((s, e) => s + e.donePoints, 0)
  const atRiskCount = enrichedEpics.filter(e => e.status === "at_risk").length
  const doneCount = enrichedEpics.filter(e => e.status === "done").length

  return (
    <DashboardShell
      title="Epics"
      description="Large features broken down into trackable workstreams"
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Filters
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New epic
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Epics" value={enrichedEpics.length} hint="across all projects" icon={Boxes} />
        <StatCard label="In Progress" value={enrichedEpics.filter(e => e.status === "in_progress").length} hint="actively being worked on" icon={Clock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Story Points" value={`${donePoints}/${totalPoints}`} hint={`${Math.round((donePoints / Math.max(1, totalPoints)) * 100)}% delivered`} icon={Layers} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="At Risk" value={atRiskCount} hint="need attention" icon={AlertCircle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Toolbar */}
      <Card className="p-3 md:p-4 mb-4 flex flex-col md:flex-row md:items-center gap-3">
        <div className="relative flex-1 min-w-0">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search epics by title, key, owner…"
            className="w-full pl-9 pr-3 h-9 text-sm rounded-md border border-input bg-background outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <div className="flex items-center gap-2">
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as Epic["status"] | "all")}>
            <SelectTrigger className="h-9 w-[140px] text-sm">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="planned">Planned</SelectItem>
              <SelectItem value="at_risk">At Risk</SelectItem>
              <SelectItem value="done">Done</SelectItem>
            </SelectContent>
          </Select>
          <Select value={groupBy} onValueChange={(v) => setGroupBy(v as GroupKey)}>
            <SelectTrigger className="h-9 w-[140px] text-sm">
              <SelectValue placeholder="Group by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="project">Group: Project</SelectItem>
              <SelectItem value="owner">Group: Owner</SelectItem>
              <SelectItem value="status">Group: Status</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Grouped epics */}
      <div className="space-y-4">
        {groups.map((g, gIdx) => (
          <div key={g.id} className="animate-slide-in-up" style={{ animationDelay: `${gIdx * 50}ms` }}>
            {/* Group header */}
            <div className="flex items-center gap-2 mb-3 px-1">
              <span className={cn("w-2.5 h-2.5 rounded-full", g.color)} />
              <h3 className="text-sm font-semibold text-foreground">{g.name}</h3>
              <Badge variant="secondary" className="text-[10px]">{g.items.length} epic{g.items.length > 1 ? "s" : ""}</Badge>
            </div>

            {/* Epic cards */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
              {g.items.map((epic, idx) => <EpicCard key={epic.id} epic={epic} delay={idx * 40} />)}
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <Card className="p-12 text-center border-dashed">
            <Boxes className="w-10 h-10 mx-auto text-muted-foreground/60 mb-3" />
            <p className="text-sm font-medium text-foreground">No epics match your filters</p>
            <p className="text-xs text-muted-foreground mt-1">Try clearing the search or status filter.</p>
          </Card>
        )}
      </div>

      {/* Footer summary */}
      <Card className="p-4 md:p-5 mt-4 card-lift">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="w-12 h-12 rounded-xl bg-primary/15 text-primary flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground">
              {doneCount} of {enrichedEpics.length} epics shipped · {Math.round((donePoints / Math.max(1, totalPoints)) * 100)}% of story points delivered
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {atRiskCount} epic{atRiskCount === 1 ? "" : "s"} at risk — review owners and due dates in the next planning session.
            </p>
          </div>
          <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent gap-1.5">
            <GitBranch className="w-3.5 h-3.5" /> Sync with backlog
          </Button>
        </div>
      </Card>
    </DashboardShell>
  )
}

// ----------------------------------------------------------------
function EpicCard({
  epic, delay,
}: {
  epic: EnrichedEpic
  delay: number
}) {
  const sc = epicStatusConfig[epic.status]
  const overdue = epic.status !== "done" && isOverdue(epic.dueDate)
  const childCount = epic.childTasks.length

  const statusBreakdown = [
    { status: "done" as TaskStatus,        label: "Done",        color: "bg-emerald-500", count: epic.byStatus.done },
    { status: "in_progress" as TaskStatus, label: "Active",      color: "bg-amber-500",   count: epic.byStatus.in_progress + epic.byStatus.review },
    { status: "todo" as TaskStatus,        label: "To Do",       color: "bg-sky-500",     count: epic.byStatus.todo + epic.byStatus.backlog },
    { status: "blocked" as TaskStatus,     label: "Blocked",     color: "bg-rose-500",    count: epic.byStatus.blocked },
  ].filter(s => s.count > 0)

  return (
    <Card
      className="p-4 md:p-5 card-lift animate-slide-in-up group"
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className={cn("w-2.5 h-2.5 rounded-full shrink-0", epic.project.color)} />
          <span className="text-[10px] font-mono text-muted-foreground">{epic.key}</span>
        </div>
        <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full inline-flex items-center gap-1.5 shrink-0", sc.className)}>
          <span className={cn("w-1.5 h-1.5 rounded-full", sc.dot)} />
          {sc.label}
        </span>
      </div>

      {/* Title */}
      <h3 className="text-base font-semibold text-foreground leading-snug group-hover:text-primary transition-colors">
        {epic.title}
      </h3>
      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{epic.description}</p>

      {/* Owner + dates */}
      <div className="flex items-center gap-3 mt-3 flex-wrap text-[11px] text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <Avatar className="w-5 h-5 ring-1 ring-border">
            <AvatarImage src={epic.ownerAvatar} alt={epic.owner} />
            <AvatarFallback className="text-[9px]">{epic.owner[0]}</AvatarFallback>
          </Avatar>
          <span>{epic.owner}</span>
        </div>
        <span className="flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          <span className={overdue ? "text-rose-600 dark:text-rose-400 font-medium" : ""}>
            {relativeDay(epic.dueDate)}
          </span>
        </span>
      </div>

      {/* Progress */}
      <div className="mt-4">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="text-muted-foreground">Progress</span>
          <span className="font-semibold text-foreground tabular-nums">
            {epic.donePoints}/{epic.totalPoints} pts · {epic.progress}%
          </span>
        </div>
        <Progress value={epic.progress} className={cn("h-2", epic.status === "at_risk" && "[&>div]:bg-rose-500")} />
      </div>

      {/* Child task breakdown */}
      <div className="mt-4 pt-3 border-t border-border">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-medium text-muted-foreground flex items-center gap-1">
            <Layers className="w-3 h-3" /> Child tasks
          </span>
          <span className="text-[10px] text-muted-foreground">{childCount} total</span>
        </div>
        {/* Stacked status bar */}
        <div className="flex h-2 rounded-full overflow-hidden bg-muted">
          {statusBreakdown.map(s => (
            <div
              key={s.status}
              className={cn("h-full transition-all", s.color)}
              style={{ width: `${(s.count / childCount) * 100}%` }}
              title={`${s.label}: ${s.count}`}
            />
          ))}
        </div>
        {/* Legend */}
        <div className="flex items-center gap-3 mt-2 flex-wrap">
          {statusBreakdown.map(s => (
            <span key={s.status} className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <span className={cn("w-1.5 h-1.5 rounded-full", s.color)} />
              {s.label} <span className="font-semibold text-foreground">{s.count}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Footer actions */}
      <div className="mt-4 flex items-center justify-between">
        <ProjectStatusBadge status={epic.project.status} />
        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
          Open epic <ChevronRight className="w-3 h-3" />
        </Button>
      </div>
    </Card>
  )
}
