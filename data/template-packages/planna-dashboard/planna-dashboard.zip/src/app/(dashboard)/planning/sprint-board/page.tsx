"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Plus, Rocket, Layers, CheckCircle2, AlertTriangle, Flag,
  Calendar, MoreHorizontal, MessageSquare, Paperclip, GripVertical,
} from "lucide-react"
import { sprints, tasks } from "@/lib/data/mock"
import { PriorityBadge } from "@/components/common/badges"
import { cn, relativeDay, isOverdue, pct } from "@/lib/utils"
import type { Task, TaskStatus, Sprint } from "@/types"

// Derive story points from estimate hours (1 SP ≈ 2 hours of work, min 1)
const storyPoints = (t: Task) => Math.max(1, Math.round((t.estimateHours ?? 4) / 2))

// Column config — order matters for visual flow
const columns: { id: TaskStatus; title: string; dot: string; accent: string }[] = [
  { id: "todo",        title: "To Do",       dot: "bg-sky-500",     accent: "border-t-sky-500" },
  { id: "in_progress", title: "In Progress", dot: "bg-amber-500",   accent: "border-t-amber-500" },
  { id: "review",      title: "Review",      dot: "bg-violet-500",  accent: "border-t-violet-500" },
  { id: "done",        title: "Done",        dot: "bg-emerald-500", accent: "border-t-emerald-500" },
]

export default function SprintBoardPage() {
  const [sprintId, setSprintId] = useState<string>(sprints.find(s => s.status === "active")?.id ?? sprints[0].id)
  const sprint = sprints.find(s => s.id === sprintId) as Sprint

  // For the active/planning sprint we surface the actual task board;
  // for completed sprints we still show the same task set (canned demo data).
  const boardTasks = useMemo(() => tasks.filter(t => t.status !== "backlog" && t.status !== "blocked"), [])

  const byColumn = (status: TaskStatus) => boardTasks.filter(t => t.status === status)
  const totalPoints = boardTasks.reduce((sum, t) => sum + storyPoints(t), 0)
  const donePoints = boardTasks.filter(t => t.status === "done").reduce((sum, t) => sum + storyPoints(t), 0)

  const remaining = sprint.storyPointsCommitted - sprint.storyPointsCompleted
  const sprintProgress = pct(sprint.storyPointsCompleted, sprint.storyPointsCommitted)

  return (
    <DashboardShell
      title="Sprint Board"
      description="Drag cards across columns to update status"
      actions={
        <>
          <Select value={sprintId} onValueChange={setSprintId}>
            <SelectTrigger className="h-9 w-[180px] text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {sprints.map(s => (
                <SelectItem key={s.id} value={s.id}>
                  <span className="flex items-center gap-2">
                    <span className={cn("w-1.5 h-1.5 rounded-full",
                      s.status === "active" ? "bg-emerald-500" :
                      s.status === "planning" ? "bg-amber-500" : "bg-muted-foreground")} />
                    {s.name}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New task
          </Button>
        </>
      }
    >
      {/* Active sprint banner */}
      <Card className="p-5 mb-4 bg-gradient-to-r from-primary/10 via-card to-card border-primary/20 card-lift animate-fade-in">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-1.5">
              <Rocket className="w-4 h-4 text-primary" />
              <p className="text-xs font-semibold text-primary uppercase tracking-wider">
                {sprint.status === "active" ? "Active sprint" : sprint.status === "planning" ? "Planning sprint" : "Completed sprint"}
              </p>
            </div>
            <h2 className="text-xl font-bold text-foreground">{sprint.name}</h2>
            <p className="text-xs text-muted-foreground mt-1">{sprint.goal}</p>
            <div className="flex items-center gap-3 mt-3 text-xs">
              <span className="flex items-center gap-1 text-muted-foreground">
                <Calendar className="w-3 h-3" />
                Ends <span className="font-semibold text-foreground">{relativeDay(sprint.endDate)}</span>
              </span>
              <span className="text-muted-foreground">·</span>
              <span className="text-muted-foreground">{sprint.tasksDone}/{sprint.tasksTotal} tasks done</span>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground tabular-nums">{sprint.storyPointsCompleted}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Completed</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-muted-foreground tabular-nums">{remaining}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Remaining</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground tabular-nums">{sprintProgress}%</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Done</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Sprint Progress" value={`${sprintProgress}%`} hint="of committed points" icon={Rocket} trend={{ value: 8, positive: true }} />
        <StatCard label="Board Story Points" value={totalPoints} hint="across active cards" icon={Layers} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Done This Sprint" value={donePoints} hint="points completed" icon={CheckCircle2} trend={{ value: 12, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="At Risk" value={boardTasks.filter(t => t.status !== "done" && isOverdue(t.dueDate)).length} hint="cards overdue" icon={AlertTriangle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Kanban board */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 md:gap-4">
        {columns.map((col, idx) => {
          const colTasks = byColumn(col.id)
          const colPoints = colTasks.reduce((sum, t) => sum + storyPoints(t), 0)
          return (
            <div
              key={col.id}
              className={cn(
                "flex flex-col rounded-xl border border-border bg-card/60 border-t-4 animate-slide-in-up",
                col.accent
              )}
              style={{ animationDelay: `${idx * 60}ms` }}
            >
              {/* Column header */}
              <div className="p-3 md:p-4 border-b border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={cn("w-2 h-2 rounded-full", col.dot)} />
                    <h3 className="text-sm font-semibold text-foreground">{col.title}</h3>
                    <span className="text-[10px] font-medium text-muted-foreground bg-muted rounded-full px-1.5 py-0.5">
                      {colTasks.length}
                    </span>
                  </div>
                  <Button variant="ghost" size="icon" className="h-6 w-6">
                    <Plus className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1.5 flex items-center gap-1">
                  <Flag className="w-3 h-3" />
                  {colPoints} story points
                </p>
              </div>

              {/* Cards */}
              <div className="p-2 md:p-2.5 space-y-2 flex-1 min-h-[120px] max-h-[640px] overflow-y-auto scroll-area-thin">
                {colTasks.length === 0 ? (
                  <div className="text-center py-10 text-xs text-muted-foreground">
                    No cards
                  </div>
                ) : (
                  colTasks.map(task => <BoardCard key={task.id} task={task} />)
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Sprint completion footer */}
      <Card className="p-4 md:p-5 mt-4 card-lift">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-foreground">Sprint Completion</h3>
          <span className="text-xs text-muted-foreground tabular-nums">
            {sprint.storyPointsCompleted} / {sprint.storyPointsCommitted} pts
          </span>
        </div>
        <Progress value={sprintProgress} className="h-2.5" />
        <p className="text-[11px] text-muted-foreground mt-2">
          On pace to deliver {sprintProgress}% of committed story points by {relativeDay(sprint.endDate)}.
        </p>
      </Card>
    </DashboardShell>
  )
}

// ----------------------------------------------------------------
// Board card
// ----------------------------------------------------------------
function BoardCard({ task }: { task: Task }) {
  const overdue = task.status !== "done" && isOverdue(task.dueDate)
  return (
    <div
      className="group rounded-lg border border-border bg-card p-3 hover:border-primary/40 hover:shadow-md hover:shadow-primary/5 transition-all duration-200 cursor-grab active:cursor-grabbing animate-fade-in"
      draggable
    >
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <span className="text-[10px] font-mono text-muted-foreground">{task.key}</span>
        <div className="flex items-center gap-0.5">
          <GripVertical className="w-3 h-3 text-muted-foreground/40 opacity-0 group-hover:opacity-100 transition-opacity" />
          <Button variant="ghost" size="icon" className="h-5 w-5">
            <MoreHorizontal className="w-3 h-3" />
          </Button>
        </div>
      </div>
      <p className="text-xs font-medium text-foreground line-clamp-2 mb-2 group-hover:text-primary transition-colors">
        {task.title}
      </p>

      {/* Labels */}
      {task.labels.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-2">
          {task.labels.slice(0, 2).map(l => (
            <span key={l.id} className={cn("text-[9px] font-medium px-1.5 py-0.5 rounded", l.color)}>
              {l.name}
            </span>
          ))}
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between pt-2 border-t border-border/60">
        <div className="flex items-center gap-1.5">
          <PriorityBadge priority={task.priority} />
          <span className={cn(
            "text-[10px] font-semibold px-1.5 py-0.5 rounded",
            "bg-primary/10 text-primary"
          )}>
            {storyPoints(task)} SP
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          {task.comments.length > 0 && (
            <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground">
              <MessageSquare className="w-3 h-3" />
              {task.comments.length}
            </span>
          )}
          {task.attachments > 0 && (
            <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground">
              <Paperclip className="w-3 h-3" />
              {task.attachments}
            </span>
          )}
          {task.assigneeAvatar ? (
            <Avatar className="w-5 h-5 ring-1 ring-border">
              <AvatarImage src={task.assigneeAvatar} alt={task.assignee ?? ""} />
              <AvatarFallback className="text-[9px]">{task.assignee?.[0]}</AvatarFallback>
            </Avatar>
          ) : null}
        </div>
      </div>

      {overdue && (
        <div className="mt-2 flex items-center gap-1 text-[10px] text-rose-600 dark:text-rose-400">
          <AlertTriangle className="w-3 h-3" />
          Overdue · {relativeDay(task.dueDate ?? "")}
        </div>
      )}
    </div>
  )
}
