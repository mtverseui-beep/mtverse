"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaBarChart, PlannaRadialChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  FileDown, CheckCircle2, Target, TrendingUp, TrendingDown,
  ThumbsUp, MessageSquare, Star, Play, AlertCircle, Quote, Award,
  ArrowUpRight, Users,
} from "lucide-react"
import { sprints, members, sprintVelocityHistory } from "@/lib/data/mock"
import { cn, formatDate, relativeDay, pct } from "@/lib/utils"

// Demo items (inline)
const demoItems = [
  {
    id: "d1",
    title: "Command palette (Cmd+K) with recents",
    presenter: "Felix Brandt",
    presenterAvatar: members[4].avatar,
    project: "PLN",
    status: "demoed" as const,
    notes: "Arrow navigation, recents-first, focus trap tested. Ship-ready.",
    duration: "8 min",
  },
  {
    id: "d2",
    title: "Recurring task scheduler — weekly digest",
    presenter: "Amara Okafor",
    presenterAvatar: members[5].avatar,
    project: "PLN",
    status: "demoed" as const,
    notes: "Skip-on-holiday works for 12 supported locales. Needs UX review for empty state.",
    duration: "6 min",
  },
  {
    id: "d3",
    title: "WebSocket reconnect with offline indicator",
    presenter: "Amara Okafor",
    presenterAvatar: members[5].avatar,
    project: "PLN",
    status: "demoed" as const,
    notes: "Exponential backoff 1s→32s, max 5 retries, toast on reconnect. Solid.",
    duration: "5 min",
  },
  {
    id: "d4",
    title: "Acme SSO integration (SAML 2.0)",
    presenter: "Hugo Lindqvist",
    presenterAvatar: members[8].avatar,
    project: "ARC",
    status: "partial" as const,
    notes: "JIT provisioning working. Pending: IdP metadata signing cert from Acme.",
    duration: "10 min",
  },
  {
    id: "d5",
    title: "Acme custom onboarding flow",
    presenter: "Felix Brandt",
    presenterAvatar: members[4].avatar,
    project: "ARC",
    status: "blocked" as const,
    notes: "Blocked on brand asset delivery from Acme marketing team. ETA next sprint.",
    duration: "—",
  },
]

// Stakeholder feedback
const feedback = [
  {
    id: "f1",
    stakeholder: "Jessin Sam",
    role: "Founder & CEO",
    avatar: members[0].avatar,
    sentiment: "positive" as const,
    body: "Command palette feels magical — this is the kind of polish that converts trials. Ship it ASAP.",
    rating: 5,
  },
  {
    id: "f2",
    stakeholder: "Zara Marlowe",
    role: "Head of Product",
    avatar: members[1].avatar,
    sentiment: "positive" as const,
    body: "Love the reconnect UX. Can we add a 'last synced' timestamp next to the indicator so users know freshness?",
    rating: 5,
  },
  {
    id: "f3",
    stakeholder: "Isla Reyes",
    role: "Marketing Lead",
    avatar: members[9].avatar,
    sentiment: "neutral" as const,
    body: "Recurring tasks look good. Will the digest email include CTA buttons or just plain links? Need this for the launch announcement.",
    rating: 4,
  },
  {
    id: "f4",
    stakeholder: "Ravi Kapoor",
    role: "Customer Success",
    avatar: members[10].avatar,
    sentiment: "negative" as const,
    body: "Acme SSO slipping is risky — they're our flagship reference account. Can we get a firm ETA in writing before the next check-in?",
    rating: 3,
  },
]

const demoStatusConfig = {
  demoed:  { label: "Demoed",      className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", icon: CheckCircle2 },
  partial: { label: "Partial",     className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",       icon: AlertCircle },
  blocked: { label: "Blocked",     className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",         icon: AlertCircle },
}

const sentimentConfig = {
  positive: { label: "Positive", className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", icon: ThumbsUp },
  neutral:  { label: "Neutral",  className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",              icon: MessageSquare },
  negative: { label: "Concern",  className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",          icon: AlertCircle },
}

export default function SprintReviewPage() {
  // Default to the most recently completed sprint
  const completedSprints = sprints.filter(s => s.status === "completed")
  const [sprintId, setSprintId] = useState(completedSprints[0]?.id ?? sprints[0].id)
  const sprint = sprints.find(s => s.id === sprintId)!

  const plannedPts = sprint.storyPointsCommitted
  const completedPts = sprint.storyPointsCompleted
  const achievementPct = pct(completedPts, plannedPts)
  const plannedTasks = sprint.tasksTotal
  const doneTasks = sprint.tasksDone
  const taskAchievementPct = pct(doneTasks, plannedTasks)

  const positiveCount = feedback.filter(f => f.sentiment === "positive").length
  const avgRating = (feedback.reduce((s, f) => s + f.rating, 0) / feedback.length).toFixed(1)

  return (
    <DashboardShell
      title="Sprint Review"
      description="Demo what we shipped and gather stakeholder feedback"
      actions={
        <>
          <Select value={sprintId} onValueChange={setSprintId}>
            <SelectTrigger className="h-9 w-[200px] text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {sprints.filter(s => s.status === "completed").map(s => (
                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <FileDown className="w-4 h-4" /> Export PDF
          </Button>
        </>
      }
    >
      {/* Sprint summary banner */}
      <Card className="p-5 mb-4 bg-gradient-to-r from-primary/10 via-card to-card border-primary/20 card-lift animate-fade-in">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-1.5">
              <Award className="w-4 h-4 text-primary" />
              <p className="text-xs font-semibold text-primary uppercase tracking-wider">
                Reviewing · {formatDate(sprint.startDate)} → {formatDate(sprint.endDate)}
              </p>
            </div>
            <h2 className="text-xl font-bold text-foreground">{sprint.name}</h2>
            <p className="text-xs text-muted-foreground mt-1">Goal: {sprint.goal}</p>
          </div>
          <div className="grid grid-cols-3 gap-6 shrink-0">
            <div className="text-center">
              <p className="text-3xl font-bold text-foreground tabular-nums">{completedPts}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Delivered</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-muted-foreground tabular-nums">{plannedPts - completedPts}</p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Slipped</p>
            </div>
            <div className="text-center">
              <p className={cn(
                "text-3xl font-bold tabular-nums",
                achievementPct >= 90 ? "text-emerald-600 dark:text-emerald-400" :
                achievementPct >= 70 ? "text-amber-600 dark:text-amber-400" :
                "text-rose-600 dark:text-rose-400"
              )}>
                {achievementPct}%
              </p>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Achieved</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Sprint Goal" value={`${achievementPct}%`} hint="story points delivered" icon={Target} trend={{ value: achievementPct - 85, positive: achievementPct >= 85 }} />
        <StatCard label="Tasks Completed" value={`${doneTasks}/${plannedTasks}`} hint={`${taskAchievementPct}% of plan`} icon={CheckCircle2} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Demos Delivered" value={`${demoItems.filter(d => d.status === "demoed").length}/${demoItems.length}`} hint="this sprint" icon={Play} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Stakeholder Rating" value={`${avgRating}/5`} hint={`${positiveCount}/${feedback.length} positive`} icon={Star} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Planned vs delivered chart + radial */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Planned vs Delivered" subtitle="Story points across recent sprints" className="lg:col-span-2">
          <PlannaBarChart
            data={sprintVelocityHistory}
            xKey="sprint"
            series={[
              { key: "planned", name: "Planned", color: "var(--chart-4)" },
              { key: "completed", name: "Completed", color: "var(--chart-1)" },
            ]}
            height={260}
          />
        </ChartCard>

        <ChartCard title="Goal Achievement" subtitle="This sprint" fullscreen={false}>
          <div className="flex flex-col items-center gap-3 py-4">
            <PlannaRadialChart
              value={achievementPct}
              label="of plan"
              size={180}
              color={achievementPct >= 90 ? "var(--success)" : achievementPct >= 70 ? "var(--warning)" : "var(--destructive)"}
            />
            <div className="text-center">
              <p className="text-xs text-muted-foreground">
                {completedPts} of {plannedPts} pts · {doneTasks} of {plannedTasks} tasks
              </p>
              <p className={cn(
                "text-xs font-semibold mt-1 flex items-center justify-center gap-1",
                achievementPct >= 85 ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400"
              )}>
                {achievementPct >= 85 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {achievementPct >= 85 ? "Above team avg" : "Below team avg"}
              </p>
            </div>
          </div>
        </ChartCard>
      </div>

      {/* Demo items */}
      <Card className="p-4 md:p-5 mb-4 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
            <Play className="w-4 h-4 text-primary" /> Sprint Demo Items
          </h3>
          <Badge variant="secondary" className="text-[10px]">{demoItems.length} presentations</Badge>
        </div>
        <div className="space-y-2">
          {demoItems.map((item, idx) => {
            const sc = demoStatusConfig[item.status]
            const StatusIcon = sc.icon
            return (
              <div
                key={item.id}
                className="flex items-start gap-3 p-3 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/30 transition-colors animate-slide-in-up"
                style={{ animationDelay: `${idx * 40}ms` }}
              >
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", sc.className)}>
                  <StatusIcon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-[10px] font-mono text-muted-foreground">{item.project}</span>
                    <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded-full", sc.className)}>
                      {sc.label}
                    </span>
                    <span className="text-[10px] text-muted-foreground ml-auto flex items-center gap-1">
                      <Play className="w-3 h-3" /> {item.duration}
                    </span>
                  </div>
                  <p className="text-sm font-medium text-foreground line-clamp-1">{item.title}</p>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{item.notes}</p>
                  <div className="flex items-center gap-1.5 mt-2">
                    <Avatar className="w-5 h-5 ring-1 ring-border">
                      <AvatarImage src={item.presenterAvatar} alt={item.presenter} />
                      <AvatarFallback className="text-[9px]">{item.presenter[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-[10px] text-muted-foreground">{item.presenter}</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      {/* Stakeholder feedback */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
            <MessageSquare className="w-4 h-4 text-primary" /> Stakeholder Feedback
          </h3>
          <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <ThumbsUp className="w-3 h-3 text-emerald-500" /> {positiveCount} positive
            </span>
            <span className="flex items-center gap-1">
              <Star className="w-3 h-3 text-amber-500" /> {avgRating} avg
            </span>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {feedback.map((f, idx) => {
            const sc = sentimentConfig[f.sentiment]
            return (
              <div
                key={f.id}
                className="rounded-lg border border-border p-3 hover:border-primary/30 transition-colors animate-slide-in-up"
                style={{ animationDelay: `${idx * 50}ms` }}
              >
                <div className="flex items-start gap-2.5 mb-2">
                  <Avatar className="w-8 h-8 ring-1 ring-border shrink-0">
                    <AvatarImage src={f.avatar} alt={f.stakeholder} />
                    <AvatarFallback className="text-[10px]">{f.stakeholder[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-semibold text-foreground truncate">{f.stakeholder}</p>
                      <span className={cn("text-[9px] font-semibold px-1.5 py-0.5 rounded-full shrink-0", sc.className)}>
                        {sc.label}
                      </span>
                    </div>
                    <p className="text-[10px] text-muted-foreground">{f.role}</p>
                    <div className="flex items-center gap-0.5 mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={cn(
                            "w-3 h-3",
                            i < f.rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"
                          )}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-1.5">
                  <Quote className="w-3 h-3 text-muted-foreground/50 shrink-0 mt-0.5" />
                  <p className="text-xs text-foreground leading-relaxed">{f.body}</p>
                </div>
              </div>
            )
          })}
        </div>

        <div className="mt-4 pt-4 border-t border-border flex items-center justify-between text-xs">
          <span className="text-muted-foreground flex items-center gap-1.5">
            <Users className="w-3 h-3" />
            Feedback collected from {feedback.length} stakeholders via in-app review form
          </span>
          <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
            View all feedback <ArrowUpRight className="w-3 h-3" />
          </Button>
        </div>
      </Card>
    </DashboardShell>
  )
}
