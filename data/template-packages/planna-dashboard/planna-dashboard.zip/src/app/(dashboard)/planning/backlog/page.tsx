"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Plus, Search, Layers, Inbox, ArrowRight, ChevronDown, ChevronRight,
  Filter, Calendar, Flag, GitBranch, AlertTriangle, CheckCircle2,
} from "lucide-react"
import { tasks, projects, sprints } from "@/lib/data/mock"
import { PriorityBadge, LabelBadge } from "@/components/common/badges"
import { cn, relativeDay, isOverdue } from "@/lib/utils"
import type { Task, Priority } from "@/types"

const storyPoints = (t: Task) => Math.max(1, Math.round((t.estimateHours ?? 4) / 2))

type GroupKey = "project" | "priority" | "none"

export default function BacklogPage() {
  const [search, setSearch] = useState("")
  const [group, setGroup] = useState<GroupKey>("project")
  const [priorityFilter, setPriorityFilter] = useState<Priority | "all">("all")
  const [expanded, setExpanded] = useState<Set<string>>(new Set(["p1", "p2"]))
  const [selected, setSelected] = useState<Set<string>>(new Set())

  const planningSprint = sprints.find(s => s.status === "planning")!

  const backlogTasks = useMemo(() => {
    let result = tasks.filter(t => t.status === "backlog" || t.status === "todo")
    if (priorityFilter !== "all") result = result.filter(t => t.priority === priorityFilter)
    if (search) {
      const q = search.toLowerCase()
      result = result.filter(t =>
        t.title.toLowerCase().includes(q) ||
        t.key.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.projectName.toLowerCase().includes(q)
      )
    }
    return result
  }, [search, priorityFilter])

  const groups = useMemo(() => {
    if (group === "project") {
      const map = new Map<string, { name: string; color: string; tasks: Task[] }>()
      for (const t of backlogTasks) {
        if (!map.has(t.projectId)) {
          map.set(t.projectId, { name: t.projectName, color: t.projectColor, tasks: [] })
        }
        map.get(t.projectId)!.tasks.push(t)
      }
      return Array.from(map.entries()).map(([id, v]) => ({ id, ...v }))
    }
    if (group === "priority") {
      const order: Priority[] = ["urgent", "high", "medium", "low"]
      return order
        .map(p => ({
          id: p,
          name: p.charAt(0).toUpperCase() + p.slice(1),
          color: "bg-muted",
          tasks: backlogTasks.filter(t => t.priority === p),
        }))
        .filter(g => g.tasks.length > 0)
    }
    return [{ id: "all", name: "All backlog items", color: "bg-muted", tasks: backlogTasks }]
  }, [backlogTasks, group])

  const totalPoints = backlogTasks.reduce((s, t) => s + storyPoints(t), 0)
  const readyForSprint = backlogTasks.filter(t => t.status === "todo" && !isOverdue(t.dueDate)).length

  const toggleExpand = (id: string) =>
    setExpanded(prev => {
      const n = new Set(prev)
      if (n.has(id)) n.delete(id); else n.add(id)
      return n
    })

  const toggleSelect = (id: string) =>
    setSelected(prev => {
      const n = new Set(prev)
      if (n.has(id)) n.delete(id); else n.add(id)
      return n
    })

  return (
    <DashboardShell
      title="Backlog"
      description="Triage and prioritize upcoming work"
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Filters
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New item
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Backlog Items" value={backlogTasks.length} hint="awaiting sprint" icon={Inbox} />
        <StatCard label="Story Points" value={totalPoints} hint="total queued" icon={Layers} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Ready for Sprint" value={readyForSprint} hint="estimate ready" icon={CheckCircle2} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Planning Sprint" value={planningSprint.name.split(" — ")[0]} hint={`targets ${planningSprint.storyPointsCommitted} pts`} icon={GitBranch} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Toolbar */}
      <Card className="p-3 md:p-4 mb-4 flex flex-col md:flex-row md:items-center gap-3">
        <div className="relative flex-1 min-w-0">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search backlog by title, key, project…"
            className="pl-9 h-9 text-sm"
          />
        </div>
        <div className="flex items-center gap-2">
          <Select value={priorityFilter} onValueChange={(v) => setPriorityFilter(v as Priority | "all")}>
            <SelectTrigger className="h-9 w-[130px] text-sm">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All priorities</SelectItem>
              <SelectItem value="urgent">Urgent</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
          <Select value={group} onValueChange={(v) => setGroup(v as GroupKey)}>
            <SelectTrigger className="h-9 w-[140px] text-sm">
              <SelectValue placeholder="Group by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="project">Group: Project</SelectItem>
              <SelectItem value="priority">Group: Priority</SelectItem>
              <SelectItem value="none">No grouping</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Backlog list — grouped */}
      <div className="space-y-4">
        {groups.map((g, idx) => {
          const groupPoints = g.tasks.reduce((s, t) => s + storyPoints(t), 0)
          const isOpen = group === "none" || expanded.has(g.id)
          return (
            <Card key={g.id} className="overflow-hidden card-lift animate-slide-in-up" style={{ animationDelay: `${idx * 50}ms` }}>
              {/* Group header */}
              <button
                onClick={() => group !== "none" && toggleExpand(g.id)}
                className="w-full flex items-center justify-between p-3 md:p-4 hover:bg-secondary/40 transition-colors text-left"
              >
                <div className="flex items-center gap-2 min-w-0">
                  {group !== "none" && (
                    isOpen ? <ChevronDown className="w-4 h-4 text-muted-foreground" />
                          : <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  )}
                  <span className={cn("w-2.5 h-2.5 rounded-full shrink-0", g.color)} />
                  <h3 className="text-sm font-semibold text-foreground truncate">{g.name}</h3>
                  <Badge variant="secondary" className="text-[10px] font-medium">
                    {g.tasks.length} items
                  </Badge>
                  <span className="text-[10px] text-muted-foreground hidden sm:inline">· {groupPoints} pts</span>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                    <ArrowRight className="w-3 h-3" /> Plan all
                  </Button>
                </div>
              </button>

              {/* Group items */}
              {isOpen && (
                <div className="divide-y divide-border border-t border-border">
                  {g.tasks.map(task => (
                    <BacklogRow
                      key={task.id}
                      task={task}
                      selected={selected.has(task.id)}
                      onToggle={() => toggleSelect(task.id)}
                    />
                  ))}
                </div>
              )}
            </Card>
          )
        })}

        {backlogTasks.length === 0 && (
          <Card className="p-12 text-center border-dashed">
            <Inbox className="w-10 h-10 mx-auto text-muted-foreground/60 mb-3" />
            <p className="text-sm font-medium text-foreground">No backlog items match your filters</p>
            <p className="text-xs text-muted-foreground mt-1">Try clearing the search or priority filter.</p>
          </Card>
        )}
      </div>

      {/* Floating plan-to-sprint bar */}
      {selected.size > 0 && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 animate-slide-in-up">
          <Card className="p-3 px-4 flex items-center gap-3 shadow-xl shadow-primary/10 border-primary/30 bg-card">
            <span className="text-sm font-medium text-foreground">
              {selected.size} item{selected.size > 1 ? "s" : ""} selected
            </span>
            <span className="text-xs text-muted-foreground">·</span>
            <span className="text-xs text-muted-foreground">
              {backlogTasks.filter(t => selected.has(t.id)).reduce((s, t) => s + storyPoints(t), 0)} pts
            </span>
            <Button size="sm" className="h-8 bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
              <ArrowRight className="w-3.5 h-3.5" /> Plan to {planningSprint.name.split(" — ")[0]}
            </Button>
            <Button size="sm" variant="ghost" className="h-8" onClick={() => setSelected(new Set())}>
              Clear
            </Button>
          </Card>
        </div>
      )}
    </DashboardShell>
  )
}

// ----------------------------------------------------------------
// Backlog row
// ----------------------------------------------------------------
function BacklogRow({
  task, selected, onToggle,
}: {
  task: Task
  selected: boolean
  onToggle: () => void
}) {
  const overdue = task.status !== "done" && isOverdue(task.dueDate)
  return (
    <div
      className={cn(
        "flex items-center gap-3 p-3 md:p-4 hover:bg-secondary/30 transition-colors group",
        selected && "bg-primary/5"
      )}
    >
      <Checkbox checked={selected} onCheckedChange={onToggle} className="shrink-0" />

      {/* Drag handle */}
      <Grip className="w-4 h-4 text-muted-foreground/40 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />

      {/* Main content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1 flex-wrap">
          <span className="text-[10px] font-mono text-muted-foreground">{task.key}</span>
          <PriorityBadge priority={task.priority} />
          {task.labels.slice(0, 2).map(l => <LabelBadge key={l.id} label={l} />)}
        </div>
        <p className="text-sm font-medium text-foreground line-clamp-1 group-hover:text-primary transition-colors">
          {task.title}
        </p>
        <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5 hidden md:block">
          {task.description}
        </p>
      </div>

      {/* Meta */}
      <div className="hidden lg:flex items-center gap-4 shrink-0">
        <div className="text-center min-w-[48px]">
          <p className="text-sm font-semibold text-foreground tabular-nums">{storyPoints(task)}</p>
          <p className="text-[9px] text-muted-foreground uppercase tracking-wider">pts</p>
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground min-w-[100px]">
          <Calendar className="w-3 h-3" />
          <span className={overdue ? "text-rose-600 dark:text-rose-400 font-medium" : ""}>
            {task.dueDate ? relativeDay(task.dueDate) : "—"}
          </span>
        </div>
      </div>

      {/* Avatar */}
      {task.assigneeAvatar && (
        <Avatar className="w-7 h-7 ring-1 ring-border shrink-0">
          <AvatarImage src={task.assigneeAvatar} alt={task.assignee ?? ""} />
          <AvatarFallback className="text-[10px]">{task.assignee?.[0]}</AvatarFallback>
        </Avatar>
      )}

      {/* Action */}
      <Button
        variant="ghost"
        size="sm"
        className="h-8 text-xs gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
      >
        <ArrowRight className="w-3.5 h-3.5" /> Plan
      </Button>
    </div>
  )
}

function Grip(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" {...props}>
      <circle cx="9" cy="6" r="1.4" /><circle cx="9" cy="12" r="1.4" /><circle cx="9" cy="18" r="1.4" />
      <circle cx="15" cy="6" r="1.4" /><circle cx="15" cy="12" r="1.4" /><circle cx="15" cy="18" r="1.4" />
    </svg>
  )
}
