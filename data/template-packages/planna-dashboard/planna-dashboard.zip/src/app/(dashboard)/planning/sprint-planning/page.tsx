"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  Plus, Search, ArrowRight, ArrowLeft, Rocket, Layers, Users,
  Gauge, AlertTriangle, CheckCircle2, X, ChevronRight, Sparkles,
  Calendar, Zap, TrendingUp,
} from "lucide-react"
import { tasks, sprints, members } from "@/lib/data/mock"
import { PriorityBadge } from "@/components/common/badges"
import { cn, relativeDay, pct } from "@/lib/utils"
import type { Task } from "@/types"

const storyPoints = (t: Task) => Math.max(1, Math.round((t.estimateHours ?? 4) / 2))

export default function SprintPlanningPage() {
  const planningSprint = sprints.find(s => s.status === "planning")!
  const [search, setSearch] = useState("")
  const [committed, setCommitted] = useState<Set<string>>(new Set([
    "t1", "t3", "t8", "t11", "t17", "t20", "t24", // pre-selected realistic commitment
  ]))

  // Backlog candidates — backlog and todo tasks not yet committed
  const candidates = useMemo(() => {
    let result = tasks.filter(t =>
      (t.status === "backlog" || t.status === "todo") &&
      !committed.has(t.id)
    )
    if (search) {
      const q = search.toLowerCase()
      result = result.filter(t =>
        t.title.toLowerCase().includes(q) ||
        t.key.toLowerCase().includes(q) ||
        t.projectName.toLowerCase().includes(q)
      )
    }
    return result
  }, [search, committed])

  const committedTasks = tasks.filter(t => committed.has(t.id))
  const committedPoints = committedTasks.reduce((s, t) => s + storyPoints(t), 0)

  const capacity = planningSprint.storyPointsCommitted
  const capacityPct = pct(committedPoints, capacity)
  const isOver = committedPoints > capacity
  const remaining = capacity - committedPoints

  // Per-member load (depends on the stable `committed` Set, not the derived array)
  const memberLoad = useMemo(() => {
    const committedList = tasks.filter(t => committed.has(t.id))
    const map = new Map<string, { member: typeof members[0]; points: number; tasks: number }>()
    for (const t of committedList) {
      const m = members.find(mm => mm.name === t.assignee)
      if (!m) continue
      const existing = map.get(m.id)
      if (existing) {
        map.set(m.id, { ...existing, points: existing.points + storyPoints(t), tasks: existing.tasks + 1 })
      } else {
        map.set(m.id, { member: m, points: storyPoints(t), tasks: 1 })
      }
    }
    return Array.from(map.values()).sort((a, b) => b.points - a.points)
  }, [committed])

  const commit = (id: string) => setCommitted(p => new Set(p).add(id))
  const uncommit = (id: string) => setCommitted(p => {
    const n = new Set(p); n.delete(id); return n
  })

  return (
    <DashboardShell
      title="Sprint Planning"
      description={`${planningSprint.name} · ${relativeDay(planningSprint.startDate)} → ${relativeDay(planningSprint.endDate)}`}
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm bg-transparent">
            Save draft
          </Button>
          <Button
            className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
            disabled={committedTasks.length === 0}
          >
            <Rocket className="w-4 h-4" /> Start sprint
          </Button>
        </>
      }
    >
      {/* Capacity banner */}
      <Card className={cn(
        "p-4 md:p-5 mb-4 card-lift border-l-4",
        isOver ? "border-l-rose-500 bg-rose-500/5" : "border-l-primary"
      )}>
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="flex items-center gap-3 shrink-0">
            <div className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center",
              isOver ? "bg-rose-500/15 text-rose-600 dark:text-rose-400" : "bg-primary/15 text-primary"
            )}>
              <Gauge className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Capacity vs. Committed</p>
              <p className="text-2xl font-bold text-foreground tabular-nums">
                {committedPoints} <span className="text-muted-foreground text-base font-normal">/ {capacity} pts</span>
              </p>
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className={cn(
                "font-medium",
                isOver ? "text-rose-600 dark:text-rose-400" : "text-muted-foreground"
              )}>
                {isOver
                  ? `Over by ${committedPoints - capacity} pts — consider reducing scope`
                  : `${remaining} pts remaining capacity`}
              </span>
              <span className={cn(
                "font-semibold tabular-nums",
                isOver ? "text-rose-600 dark:text-rose-400" : "text-foreground"
              )}>
                {capacityPct}%
              </span>
            </div>
            <Progress
              value={Math.min(100, capacityPct)}
              className={cn("h-2.5", isOver && "[&>div]:bg-rose-500")}
            />
            <div className="flex items-center gap-4 mt-2 text-[11px] text-muted-foreground">
              <span className="flex items-center gap-1"><Layers className="w-3 h-3" /> {committedTasks.length} tasks</span>
              <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {memberLoad.length} assignees</span>
              <span className="flex items-center gap-1"><TrendingUp className="w-3 h-3" /> Last sprint: 54 pts delivered</span>
            </div>
          </div>

          {/* Quick stat tiles */}
          <div className="grid grid-cols-3 gap-2 md:gap-3 shrink-0">
            <div className="rounded-lg bg-secondary/60 p-2.5 text-center min-w-[64px]">
              <p className="text-lg font-bold text-foreground tabular-nums">{committedTasks.length}</p>
              <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Tasks</p>
            </div>
            <div className="rounded-lg bg-secondary/60 p-2.5 text-center min-w-[64px]">
              <p className="text-lg font-bold text-foreground tabular-nums">{committedPoints}</p>
              <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Points</p>
            </div>
            <div className={cn(
              "rounded-lg p-2.5 text-center min-w-[64px]",
              isOver ? "bg-rose-500/10" : "bg-secondary/60"
            )}>
              <p className={cn("text-lg font-bold tabular-nums", isOver ? "text-rose-600 dark:text-rose-400" : "text-foreground")}>
                {Math.max(0, remaining)}
              </p>
              <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Free</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Two columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 md:gap-4">
        {/* Left: Backlog candidates */}
        <Card className="flex flex-col max-h-[760px] card-lift">
          <div className="p-4 border-b border-border flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">Backlog Candidates</h3>
              <Badge variant="secondary" className="text-[10px]">{candidates.length}</Badge>
            </div>
            <div className="relative w-40 sm:w-56">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search…"
                className="h-8 pl-8 text-xs"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto scroll-area-thin p-2 space-y-1.5">
            {candidates.length === 0 ? (
              <div className="text-center py-12 text-xs text-muted-foreground">
                <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
                All backlog items committed
              </div>
            ) : (
              candidates.map(t => <CandidateRow key={t.id} task={t} onCommit={() => commit(t.id)} />)
            )}
          </div>
        </Card>

        {/* Right: Sprint commitment */}
        <Card className="flex flex-col max-h-[760px] card-lift border-primary/30">
          <div className="p-4 border-b border-border flex items-center justify-between gap-2 bg-primary/5">
            <div className="flex items-center gap-2">
              <Rocket className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">Sprint Commitment</h3>
              <Badge className="text-[10px] bg-primary text-primary-foreground">
                {committedPoints} pts
              </Badge>
            </div>
            <span className="text-[10px] text-muted-foreground hidden sm:inline">
              Goal: {planningSprint.goal}
            </span>
          </div>
          <div className="flex-1 overflow-y-auto scroll-area-thin p-2 space-y-1.5">
            {committedTasks.length === 0 ? (
              <div className="text-center py-12 text-xs text-muted-foreground">
                <Sparkles className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
                Commit tasks from the backlog to plan your sprint
              </div>
            ) : (
              committedTasks.map(t => <CommittedRow key={t.id} task={t} onRemove={() => uncommit(t.id)} />)
            )}
          </div>
        </Card>
      </div>

      {/* Per-member load breakdown */}
      <Card className="p-4 md:p-5 mt-4 card-lift">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
            <Users className="w-4 h-4 text-primary" /> Team Capacity Load
          </h3>
          <span className="text-xs text-muted-foreground">
            Per-assignee committed story points
          </span>
        </div>
        {memberLoad.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-6">
            No tasks committed yet — pick from the backlog to see team load.
          </p>
        ) : (
          <div className="space-y-3">
            {memberLoad.map(({ member, points, tasks: taskCount }) => {
              // Recommended max load = 13 pts per person per sprint (industry heuristic)
              const maxLoad = 13
              const loadPct = pct(points, maxLoad)
              const overLoad = points > maxLoad
              return (
                <div key={member.id} className="flex items-center gap-3">
                  <Avatar className="w-8 h-8 ring-1 ring-border shrink-0">
                    <AvatarImage src={member.avatar} alt={member.name} />
                    <AvatarFallback className="text-[10px]">{member.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="w-28 sm:w-40 shrink-0 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{member.name}</p>
                    <p className="text-[10px] text-muted-foreground">{member.title}</p>
                  </div>
                  <div className="flex-1 min-w-0">
                    <Progress
                      value={Math.min(100, loadPct)}
                      className={cn("h-2", overLoad && "[&>div]:bg-rose-500")}
                    />
                  </div>
                  <div className="flex items-center gap-2 shrink-0 w-24 justify-end">
                    {overLoad && <AlertTriangle className="w-3 h-3 text-rose-500" />}
                    <span className={cn(
                      "text-xs font-semibold tabular-nums",
                      overLoad ? "text-rose-600 dark:text-rose-400" : "text-foreground"
                    )}>
                      {points} pts
                    </span>
                    <span className="text-[10px] text-muted-foreground">/ {taskCount}t</span>
                  </div>
                </div>
              )
            })}
          </div>
        )}
        <div className="mt-4 pt-3 border-t border-border flex items-center justify-between text-xs">
          <span className="text-muted-foreground flex items-center gap-1.5">
            <Zap className="w-3 h-3 text-amber-500" />
            Recommended max: 13 pts per person per 2-week sprint
          </span>
          <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
            <Calendar className="w-3 h-3" /> View past velocity <ChevronRight className="w-3 h-3" />
          </Button>
        </div>
      </Card>
    </DashboardShell>
  )
}

// ----------------------------------------------------------------
function CandidateRow({ task, onCommit }: { task: Task; onCommit: () => void }) {
  return (
    <div className="group flex items-center gap-2 p-2.5 rounded-lg border border-border bg-card hover:border-primary/40 hover:bg-secondary/30 transition-colors">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5 flex-wrap">
          <span className="text-[10px] font-mono text-muted-foreground">{task.key}</span>
          <PriorityBadge priority={task.priority} />
          <span className="text-[9px] text-muted-foreground bg-muted px-1 py-0.5 rounded">{task.projectName}</span>
        </div>
        <p className="text-xs font-medium text-foreground line-clamp-1">{task.title}</p>
      </div>
      <span className="text-[10px] font-semibold text-primary bg-primary/10 px-1.5 py-0.5 rounded shrink-0">
        {storyPoints(task)} SP
      </span>
      <Button
        size="icon"
        variant="ghost"
        className="h-7 w-7 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={onCommit}
        title="Commit to sprint"
      >
        <ArrowRight className="w-3.5 h-3.5" />
      </Button>
    </div>
  )
}

function CommittedRow({ task, onRemove }: { task: Task; onRemove: () => void }) {
  return (
    <div className="group flex items-center gap-2 p-2.5 rounded-lg border border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors">
      <Button
        size="icon"
        variant="ghost"
        className="h-7 w-7 shrink-0 hover:bg-rose-500/10 hover:text-rose-600"
        onClick={onRemove}
        title="Remove from sprint"
      >
        <X className="w-3.5 h-3.5" />
      </Button>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5 flex-wrap">
          <span className="text-[10px] font-mono text-muted-foreground">{task.key}</span>
          <PriorityBadge priority={task.priority} />
        </div>
        <p className="text-xs font-medium text-foreground line-clamp-1">{task.title}</p>
      </div>
      <span className="text-[10px] font-semibold text-primary bg-primary/10 px-1.5 py-0.5 rounded shrink-0">
        {storyPoints(task)} SP
      </span>
      {task.assigneeAvatar && (
        <Avatar className="w-6 h-6 ring-1 ring-border shrink-0">
          <AvatarImage src={task.assigneeAvatar} alt={task.assignee ?? ""} />
          <AvatarFallback className="text-[9px]">{task.assignee?.[0]}</AvatarFallback>
        </Avatar>
      )}
    </div>
  )
}
