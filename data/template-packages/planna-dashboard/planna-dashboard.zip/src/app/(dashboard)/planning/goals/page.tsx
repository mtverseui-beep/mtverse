"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { PlannaRadialChart } from "@/components/charts"
import {
  Plus, Target, TrendingUp, AlertTriangle, CircleCheck, Calendar,
  ChevronDown, ChevronRight, Flag, Sparkles,
} from "lucide-react"
import { goals } from "@/lib/data/mock"
import { cn, relativeDay, formatDate } from "@/lib/utils"
import type { Goal } from "@/types"

const statusConfig: Record<Goal["status"], { label: string; className: string; dot: string }> = {
  on_track: { label: "On Track", className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  at_risk:  { label: "At Risk",  className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",       dot: "bg-amber-500" },
  behind:   { label: "Behind",   className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",         dot: "bg-rose-500" },
  done:     { label: "Completed",className: "bg-violet-500/15 text-violet-600 dark:text-violet-400",   dot: "bg-violet-500" },
}

const quarters = ["Q1 2026", "Q4 2025", "Q3 2025"]

export default function GoalsPage() {
  const [quarter, setQuarter] = useState("Q1 2026")
  const [expanded, setExpanded] = useState<Set<string>>(new Set([goals[0].id]))

  const counts = {
    total: goals.length,
    on_track: goals.filter(g => g.status === "on_track").length,
    at_risk: goals.filter(g => g.status === "at_risk").length,
    behind: goals.filter(g => g.status === "behind").length,
  }
  const avgProgress = Math.round(goals.reduce((s, g) => s + g.progress, 0) / goals.length)

  const toggleExpand = (id: string) =>
    setExpanded(prev => {
      const n = new Set(prev)
      if (n.has(id)) n.delete(id); else n.add(id)
      return n
    })

  return (
    <DashboardShell
      title="Goals & OKRs"
      description="Quarterly objectives and key results"
      actions={
        <>
          <Select value={quarter} onValueChange={setQuarter}>
            <SelectTrigger className="h-9 w-[120px] text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {quarters.map(q => <SelectItem key={q} value={q}>{q}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New goal
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Goals" value={counts.total} hint={`${quarter} cycle`} icon={Target} />
        <StatCard label="On Track" value={counts.on_track} hint="healthy progress" icon={CircleCheck} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="At Risk" value={counts.at_risk} hint="falling behind" icon={AlertTriangle} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Progress" value={`${avgProgress}%`} hint="across all OKRs" icon={TrendingUp} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
      </div>

      {/* Goal cards grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 md:gap-4">
        {goals.map((goal, idx) => (
          <GoalCard
            key={goal.id}
            goal={goal}
            expanded={expanded.has(goal.id)}
            onToggle={() => toggleExpand(goal.id)}
            delay={idx * 60}
          />
        ))}
      </div>

      {/* Footer summary */}
      <Card className="p-4 md:p-5 mt-4 card-lift bg-gradient-to-r from-primary/5 via-card to-card border-primary/20">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="w-12 h-12 rounded-xl bg-primary/15 text-primary flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground">Quarter on track to deliver {avgProgress}% of objectives</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {counts.on_track} of {counts.total} goals on track · {counts.at_risk} at risk · {counts.behind} behind
            </p>
          </div>
          <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent">
            Export report
          </Button>
        </div>
      </Card>
    </DashboardShell>
  )
}

// ----------------------------------------------------------------
// Goal card
// ----------------------------------------------------------------
function GoalCard({
  goal, expanded, onToggle, delay,
}: {
  goal: Goal
  expanded: boolean
  onToggle: () => void
  delay: number
}) {
  const sc = statusConfig[goal.status]
  const completedKRs = goal.keyResults.filter(kr => kr.progress >= 100).length

  return (
    <Card
      className="p-4 md:p-5 card-lift animate-slide-in-up overflow-hidden"
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Header */}
      <div className="flex items-start gap-4">
        {/* Radial progress */}
        <div className="shrink-0 hidden sm:block">
          <PlannaRadialChart value={goal.progress} label="complete" size={104} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1.5">
            <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full inline-flex items-center gap-1.5", sc.className)}>
              <span className={cn("w-1.5 h-1.5 rounded-full", sc.dot)} />
              {sc.label}
            </span>
            <span className="text-[10px] text-muted-foreground flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {relativeDay(goal.dueDate)}
            </span>
          </div>
          <h3 className="text-base font-semibold text-foreground leading-snug">
            {goal.title}
          </h3>
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{goal.description}</p>

          {/* Owner */}
          <div className="flex items-center gap-2 mt-3">
            <Avatar className="w-6 h-6 ring-1 ring-border">
              <AvatarImage src={goal.ownerAvatar} alt={goal.owner} />
              <AvatarFallback className="text-[10px]">{goal.owner[0]}</AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground">{goal.owner}</span>
            <span className="text-[10px] text-muted-foreground ml-auto sm:hidden font-semibold">
              {goal.progress}%
            </span>
          </div>
        </div>
      </div>

      {/* KR summary - always visible */}
      <div className="mt-4 grid grid-cols-3 gap-2 sm:hidden">
        <div className="rounded-lg bg-secondary/60 p-2 text-center">
          <p className="text-lg font-bold text-foreground tabular-nums">{goal.progress}%</p>
          <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Progress</p>
        </div>
        <div className="rounded-lg bg-secondary/60 p-2 text-center">
          <p className="text-lg font-bold text-foreground tabular-nums">{completedKRs}/{goal.keyResults.length}</p>
          <p className="text-[9px] text-muted-foreground uppercase tracking-wider">KRs done</p>
        </div>
        <div className="rounded-lg bg-secondary/60 p-2 text-center">
          <p className="text-lg font-bold text-foreground tabular-nums">{goal.keyResults.length}</p>
          <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Key results</p>
        </div>
      </div>

      {/* KR list - expandable */}
      <button
        onClick={onToggle}
        className="mt-4 w-full flex items-center justify-between text-left text-xs font-medium text-foreground hover:text-primary transition-colors"
      >
        <span className="flex items-center gap-1.5">
          <Flag className="w-3.5 h-3.5" />
          Key Results ({goal.keyResults.length})
        </span>
        <span className="flex items-center gap-1 text-muted-foreground">
          {expanded ? "Hide" : "Show"}
          {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
        </span>
      </button>

      {expanded && (
        <div className="mt-3 space-y-3 animate-fade-in">
          {goal.keyResults.map((kr, i) => (
            <div key={kr.id}>
              <div className="flex items-center justify-between mb-1.5 gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="w-5 h-5 rounded-full bg-primary/10 text-primary text-[10px] font-bold flex items-center justify-center shrink-0">
                    {i + 1}
                  </span>
                  <p className="text-xs font-medium text-foreground line-clamp-1">{kr.title}</p>
                </div>
                <span className={cn(
                  "text-[10px] font-semibold tabular-nums shrink-0",
                  kr.progress >= 100 ? "text-emerald-600 dark:text-emerald-400" :
                  kr.progress >= 50 ? "text-foreground" :
                  "text-muted-foreground"
                )}>
                  {kr.progress}%
                </span>
              </div>
              <Progress
                value={kr.progress}
                className={cn(
                  "h-1.5",
                  kr.progress >= 100 && "[&>div]:bg-emerald-500",
                  kr.progress < 50 && goal.status === "behind" && "[&>div]:bg-rose-500",
                )}
              />
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
