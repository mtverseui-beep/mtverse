"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Plus, Smile, Frown, Lightbulb, CheckSquare, MoreHorizontal,
  X, ThumbsUp, Save, Calendar, Users, Sparkles,
} from "lucide-react"
import { sprints, members } from "@/lib/data/mock"
import { cn, formatDate, relativeDay } from "@/lib/utils"

type ColumnId = "went_well" | "didnt_go_well" | "improve" | "actions"

interface StickyNote {
  id: string
  column: ColumnId
  body: string
  author: string
  authorAvatar: string
  createdAt: string
  likes?: number
  color?: string
  // Action item fields
  assignee?: string
  assigneeAvatar?: string
  dueDate?: string
  done?: boolean
}

const columnConfig: Record<ColumnId, {
  title: string
  icon: typeof Smile
  color: string
  headerBg: string
  accent: string
  noteColor: string
}> = {
  went_well:     { title: "Went Well",       icon: Smile,        color: "text-emerald-600 dark:text-emerald-400", headerBg: "bg-emerald-500/10", accent: "border-t-emerald-500",  noteColor: "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900" },
  didnt_go_well: { title: "Didn't Go Well",  icon: Frown,        color: "text-rose-600 dark:text-rose-400",       headerBg: "bg-rose-500/10",    accent: "border-t-rose-500",     noteColor: "bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900" },
  improve:       { title: "Improve",         icon: Lightbulb,    color: "text-amber-600 dark:text-amber-400",     headerBg: "bg-amber-500/10",   accent: "border-t-amber-500",    noteColor: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900" },
  actions:       { title: "Action Items",    icon: CheckSquare,  color: "text-sky-600 dark:text-sky-400",         headerBg: "bg-sky-500/10",     accent: "border-t-sky-500",      noteColor: "bg-sky-50 dark:bg-sky-950/30 border-sky-200 dark:border-sky-900" },
}

const initialNotes: StickyNote[] = [
  // Went well
  { id: "n1", column: "went_well", body: "Command palette shipped with no critical bugs — focus trap and keyboard nav all worked first try.", author: "Felix Brandt", authorAvatar: members[4].avatar, createdAt: "2026-02-12T15:00:00Z", likes: 8 },
  { id: "n2", column: "went_well", body: "Pair-programming on the WS reconnect logic caught the backoff edge case early. Worth doing more often.", author: "Amara Okafor", authorAvatar: members[5].avatar, createdAt: "2026-02-12T15:05:00Z", likes: 5 },
  { id: "n3", column: "went_well", body: "Stakeholder demo had 4/5 demos land cleanly. Marketing loved the recurring-tasks digest preview.", author: "Zara Marlowe", authorAvatar: members[1].avatar, createdAt: "2026-02-12T15:10:00Z", likes: 12 },

  // Didn't go well
  { id: "n4", column: "didnt_go_well", body: "Acme SSO slipped because we waited too long to chase the IdP metadata cert. Should have escalated at day 3, not day 7.", author: "Hugo Lindqvist", authorAvatar: members[8].avatar, createdAt: "2026-02-12T15:15:00Z", likes: 9 },
  { id: "n5", column: "didnt_go_well", body: "Sprint scope grew mid-flight when onboarding redesign was added. We need a stronger sprint commitment boundary.", author: "Theo Nakamura", authorAvatar: members[2].avatar, createdAt: "2026-02-12T15:18:00Z", likes: 7 },
  { id: "n6", column: "didnt_go_well", body: "QA found a regression in the time-tracker widget the day before demo. Earlier E2E coverage would have caught it.", author: "Naomi Chen", authorAvatar: members[7].avatar, createdAt: "2026-02-12T15:22:00Z", likes: 4 },

  // Improve
  { id: "n7", column: "improve", body: "Adopt a 'definition of ready' checklist so backlog items can't be committed without estimates and acceptance criteria.", author: "Zara Marlowe", authorAvatar: members[1].avatar, createdAt: "2026-02-12T15:25:00Z", likes: 11 },
  { id: "n8", column: "improve", body: "Run mid-sprint check-in on day 7 to surface blockers earlier — async Slack poll would be enough.", author: "Felix Brandt", authorAvatar: members[4].avatar, createdAt: "2026-02-12T15:28:00Z", likes: 6 },
  { id: "n9", column: "improve", body: "Add visual regression snapshots for all widget states before demo day, not after.", author: "Naomi Chen", authorAvatar: members[7].avatar, createdAt: "2026-02-12T15:32:00Z", likes: 5 },

  // Actions
  { id: "n10", column: "actions", body: "Draft 'Definition of Ready' checklist and circulate for team sign-off.", author: "Zara Marlowe", authorAvatar: members[1].avatar, createdAt: "2026-02-12T15:35:00Z", assignee: "Zara Marlowe", assigneeAvatar: members[1].avatar, dueDate: "2026-02-19", done: false, likes: 3 },
  { id: "n11", column: "actions", body: "Set up async mid-sprint Slack poll workflow (#engineering channel).", author: "Felix Brandt", authorAvatar: members[4].avatar, createdAt: "2026-02-12T15:37:00Z", assignee: "Felix Brandt", assigneeAvatar: members[4].avatar, dueDate: "2026-02-17", done: false, likes: 2 },
  { id: "n12", column: "actions", body: "Add Percy snapshots for time-tracker widget states.", author: "Naomi Chen", authorAvatar: members[7].avatar, createdAt: "2026-02-12T15:39:00Z", assignee: "Naomi Chen", assigneeAvatar: members[7].avatar, dueDate: "2026-02-21", done: true, likes: 4 },
  { id: "n13", column: "actions", body: "Escalate Acme cert issue in writing with firm ETA.", author: "Hugo Lindqvist", authorAvatar: members[8].avatar, createdAt: "2026-02-12T15:41:00Z", assignee: "Hugo Lindqvist", assigneeAvatar: members[8].avatar, dueDate: "2026-02-14", done: false, likes: 5 },
]

const columnsOrder: ColumnId[] = ["went_well", "didnt_go_well", "improve", "actions"]

export default function RetrospectivePage() {
  const completedSprints = sprints.filter(s => s.status === "completed")
  const [sprintId, setSprintId] = useState(completedSprints[0]?.id ?? sprints[0].id)
  const sprint = sprints.find(s => s.id === sprintId)!
  const [notes, setNotes] = useState<StickyNote[]>(initialNotes)
  const [editing, setEditing] = useState<ColumnId | null>(null)
  const [draft, setDraft] = useState("")

  // Participants — for the avatar stack at top
  const participants = members.slice(0, 8)

  const addNote = (column: ColumnId) => {
    if (!draft.trim()) return
    const newNote: StickyNote = {
      id: `n${Date.now()}`,
      column,
      body: draft.trim(),
      author: members[0].name,
      authorAvatar: members[0].avatar,
      createdAt: new Date().toISOString(),
      likes: 0,
    }
    setNotes(prev => [...prev, newNote])
    setDraft("")
    setEditing(null)
  }

  const toggleActionDone = (id: string) => {
    setNotes(prev => prev.map(n => n.id === id ? { ...n, done: !n.done } : n))
  }

  const removeNote = (id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id))
  }

  const likeNote = (id: string) => {
    setNotes(prev => prev.map(n => n.id === id ? { ...n, likes: (n.likes ?? 0) + 1 } : n))
  }

  const actionStats = {
    total: notes.filter(n => n.column === "actions").length,
    done: notes.filter(n => n.column === "actions" && n.done).length,
  }

  return (
    <DashboardShell
      title="Retrospective"
      description="Reflect on the sprint and define action items"
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Calendar className="w-4 h-4" />
            {sprint.name}
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Save className="w-4 h-4" /> Save & close
          </Button>
        </>
      }
    >
      {/* Sprint context + participants */}
      <Card className="p-4 md:p-5 mb-4 card-lift bg-gradient-to-r from-primary/5 via-card to-card border-primary/20">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-1">
              Reflecting on
            </p>
            <h2 className="text-base font-bold text-foreground">{sprint.name}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {sprint.goal} · Completed {formatDate(sprint.endDate)}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-center">
              <p className="text-xl font-bold text-foreground tabular-nums">{actionStats.done}/{actionStats.total}</p>
              <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Actions Done</p>
            </div>
            <div className="h-10 w-px bg-border" />
            <div className="flex flex-col">
              <p className="text-[10px] text-muted-foreground mb-1.5 flex items-center gap-1">
                <Users className="w-3 h-3" /> {participants.length} participants
              </p>
              <div className="flex items-center -space-x-2">
                {participants.slice(0, 6).map(m => (
                  <Avatar key={m.id} className="w-7 h-7 ring-2 ring-card">
                    <AvatarImage src={m.avatar} alt={m.name} />
                    <AvatarFallback className="text-[10px]">{m.name[0]}</AvatarFallback>
                  </Avatar>
                ))}
                {participants.length > 6 && (
                  <span className="w-7 h-7 rounded-full bg-muted ring-2 ring-card text-[10px] font-semibold text-muted-foreground flex items-center justify-center">
                    +{participants.length - 6}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Retrospective board */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 md:gap-4">
        {columnsOrder.map((colId, idx) => {
          const cfg = columnConfig[colId]
          const Icon = cfg.icon
          const colNotes = notes.filter(n => n.column === colId)
          return (
            <div
              key={colId}
              className={cn(
                "flex flex-col rounded-xl border border-border bg-card/60 border-t-4 animate-slide-in-up",
                cfg.accent
              )}
              style={{ animationDelay: `${idx * 60}ms` }}
            >
              {/* Column header */}
              <div className={cn("p-3 md:p-4 rounded-t-xl", cfg.headerBg)}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className={cn("w-4 h-4", cfg.color)} />
                    <h3 className="text-sm font-semibold text-foreground">{cfg.title}</h3>
                    <span className="text-[10px] font-medium text-muted-foreground bg-card rounded-full px-1.5 py-0.5">
                      {colNotes.length}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    onClick={() => setEditing(editing === colId ? null : colId)}
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>

              {/* Notes */}
              <div className="p-2 md:p-2.5 space-y-2 flex-1 min-h-[200px] max-h-[640px] overflow-y-auto scroll-area-thin">
                {colNotes.length === 0 && editing !== colId && (
                  <div className="text-center py-8 text-xs text-muted-foreground">
                    No notes yet
                  </div>
                )}

                {colNotes.map(note => (
                  <div
                    key={note.id}
                    className={cn(
                      "group rounded-lg border p-3 transition-all duration-200 hover:shadow-sm animate-fade-in",
                      cfg.noteColor,
                      note.column === "actions" && note.done && "opacity-60"
                    )}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <Avatar className="w-5 h-5 ring-1 ring-border shrink-0">
                        <AvatarImage src={note.authorAvatar} alt={note.author} />
                        <AvatarFallback className="text-[9px]">{note.author[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex items-center gap-0.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity">
                        {note.column === "actions" && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className={cn(
                              "h-6 w-6",
                              note.done ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"
                            )}
                            onClick={() => toggleActionDone(note.id)}
                            title={note.done ? "Mark as not done" : "Mark as done"}
                          >
                            <CheckSquare className="w-3.5 h-3.5" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-muted-foreground hover:text-rose-600"
                          onClick={() => removeNote(note.id)}
                        >
                          <X className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>

                    <p className={cn(
                      "text-xs text-foreground leading-relaxed",
                      note.column === "actions" && note.done && "line-through"
                    )}>
                      {note.body}
                    </p>

                    {/* Footer */}
                    <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-border/40">
                      <div className="flex items-center gap-2">
                        {note.column === "actions" && note.assignee ? (
                          <div className="flex items-center gap-1">
                            <Avatar className="w-4 h-4 ring-1 ring-border">
                              <AvatarImage src={note.assigneeAvatar} alt={note.assignee} />
                              <AvatarFallback className="text-[8px]">{note.assignee[0]}</AvatarFallback>
                            </Avatar>
                            <span className="text-[9px] text-muted-foreground">{note.assignee.split(" ")[0]}</span>
                            {note.dueDate && (
                              <span className="text-[9px] text-muted-foreground flex items-center gap-0.5">
                                · <Calendar className="w-2.5 h-2.5" /> {relativeDay(note.dueDate)}
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-[9px] text-muted-foreground">
                            {note.author.split(" ")[0]} · {relativeDay(note.createdAt)}
                          </span>
                        )}
                      </div>
                      {(note.likes ?? 0) > 0 && (
                        <button
                          onClick={() => likeNote(note.id)}
                          className="flex items-center gap-1 text-[9px] text-muted-foreground hover:text-primary transition-colors"
                        >
                          <ThumbsUp className="w-2.5 h-2.5" />
                          {note.likes}
                        </button>
                      )}
                    </div>
                  </div>
                ))}

                {/* Add note textarea */}
                {editing === colId && (
                  <div className="rounded-lg border border-dashed border-primary/40 bg-card p-3 animate-scale-in">
                    <textarea
                      autoFocus
                      value={draft}
                      onChange={e => setDraft(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) addNote(colId)
                        if (e.key === "Escape") { setEditing(null); setDraft("") }
                      }}
                      placeholder={`Add a note to "${cfg.title}"…`}
                      className="w-full text-xs text-foreground bg-transparent resize-none outline-none placeholder:text-muted-foreground/60 min-h-[60px]"
                    />
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
                      <span className="text-[9px] text-muted-foreground">⌘+Enter to save · Esc to cancel</span>
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="ghost" className="h-6 text-[10px]" onClick={() => { setEditing(null); setDraft("") }}>
                          Cancel
                        </Button>
                        <Button
                          size="sm"
                          className="h-6 text-[10px] bg-primary text-primary-foreground hover:bg-primary/90 gap-1"
                          onClick={() => addNote(colId)}
                          disabled={!draft.trim()}
                        >
                          <Plus className="w-3 h-3" /> Add
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Add button */}
              {editing !== colId && (
                <button
                  onClick={() => setEditing(colId)}
                  className="m-2 mt-0 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-dashed border-border text-xs text-muted-foreground hover:border-primary/40 hover:text-primary transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" /> Add card
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* Footer summary */}
      <Card className="p-4 md:p-5 mt-4 card-lift">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-foreground">
              {actionStats.done} of {actionStats.total} action items completed
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Carry incomplete actions into the next sprint planning session.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-[10px] gap-1">
              <Smile className="w-3 h-3 text-emerald-500" /> {notes.filter(n => n.column === "went_well").length} wins
            </Badge>
            <Badge variant="outline" className="text-[10px] gap-1">
              <Frown className="w-3 h-3 text-rose-500" /> {notes.filter(n => n.column === "didnt_go_well").length} misses
            </Badge>
            <Badge variant="outline" className="text-[10px] gap-1">
              <Lightbulb className="w-3 h-3 text-amber-500" /> {notes.filter(n => n.column === "improve").length} ideas
            </Badge>
          </div>
        </div>
      </Card>
    </DashboardShell>
  )
}
