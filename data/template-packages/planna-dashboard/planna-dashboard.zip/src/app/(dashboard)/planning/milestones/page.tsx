"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus, Flag, Calendar, CheckCircle2, Clock, AlertCircle,
  CircleDashed, ChevronRight, CalendarDays, Filter,
} from "lucide-react"
import { milestones, projects } from "@/lib/data/mock"
import { cn, relativeDay, formatDate, isOverdue } from "@/lib/utils"
import type { Milestone } from "@/types"

type Filter = "all" | "planned" | "in_progress" | "done" | "overdue"

const statusConfig: Record<Milestone["status"], { label: string; icon: typeof Flag; className: string; dot: string }> = {
  planned:     { label: "Planned",     icon: CircleDashed,   className: "bg-sky-500/15 text-sky-600 dark:text-sky-400",             dot: "bg-sky-500" },
  in_progress: { label: "In Progress", icon: Clock,          className: "bg-amber-500/15 text-amber-600 dark:text-amber-400",       dot: "bg-amber-500" },
  done:        { label: "Done",        icon: CheckCircle2,   className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  overdue:     { label: "Overdue",     icon: AlertCircle,    className: "bg-rose-500/15 text-rose-600 dark:text-rose-400",         dot: "bg-rose-500" },
}

export default function MilestonesPage() {
  const [filter, setFilter] = useState<Filter>("all")

  // Compute actual status (override mock overdue based on dueDate)
  const computed = useMemo(() => milestones.map(m => {
    if (m.status === "done") return m
    if (isOverdue(m.dueDate)) return { ...m, status: "overdue" as const }
    return m
  }), [])

  const counts = useMemo(() => ({
    all: computed.length,
    planned: computed.filter(m => m.status === "planned").length,
    in_progress: computed.filter(m => m.status === "in_progress").length,
    done: computed.filter(m => m.status === "done").length,
    overdue: computed.filter(m => m.status === "overdue").length,
  }), [computed])

  const filtered = filter === "all" ? computed : computed.filter(m => m.status === filter)

  // Group by project
  const grouped = useMemo(() => {
    const map = new Map<string, { project: typeof projects[0]; items: Milestone[] }>()
    for (const m of filtered) {
      const proj = projects.find(p => p.id === m.projectId)!
      if (!map.has(m.projectId)) map.set(m.projectId, { project: proj, items: [] })
      map.get(m.projectId)!.items.push(m)
    }
    // Sort items within group by due date
    for (const g of map.values()) {
      g.items.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    }
    return Array.from(map.values())
  }, [filtered])

  const avgProgress = Math.round(computed.reduce((s, m) => s + m.progress, 0) / computed.length)

  return (
    <DashboardShell
      title="Milestones"
      description="Track key project checkpoints and deliverables"
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <CalendarDays className="w-4 h-4" /> Calendar view
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New milestone
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Milestones" value={counts.all} hint="across all projects" icon={Flag} />
        <StatCard label="In Progress" value={counts.in_progress} hint="actively being worked on" icon={Clock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Completed" value={counts.done} hint="shipped" icon={CheckCircle2} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Overdue" value={counts.overdue} hint="past due date" icon={AlertCircle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Filter tabs */}
      <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)} className="mb-4">
        <TabsList className="h-9 flex-wrap">
          <TabsTrigger value="all" className="text-xs gap-1.5">
            All <span className="text-[10px] text-muted-foreground">{counts.all}</span>
          </TabsTrigger>
          <TabsTrigger value="planned" className="text-xs gap-1.5">
            Planned <span className="text-[10px] text-muted-foreground">{counts.planned}</span>
          </TabsTrigger>
          <TabsTrigger value="in_progress" className="text-xs gap-1.5">
            In Progress <span className="text-[10px] text-muted-foreground">{counts.in_progress}</span>
          </TabsTrigger>
          <TabsTrigger value="done" className="text-xs gap-1.5">
            Done <span className="text-[10px] text-muted-foreground">{counts.done}</span>
          </TabsTrigger>
          <TabsTrigger value="overdue" className="text-xs gap-1.5">
            Overdue <span className="text-[10px] text-muted-foreground">{counts.overdue}</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Grouped milestone lists */}
      <div className="space-y-4">
        {grouped.length === 0 && (
          <Card className="p-12 text-center border-dashed">
            <Filter className="w-10 h-10 mx-auto text-muted-foreground/60 mb-3" />
            <p className="text-sm font-medium text-foreground">No milestones in this view</p>
            <p className="text-xs text-muted-foreground mt-1">Try a different filter tab.</p>
          </Card>
        )}

        {grouped.map((g, gIdx) => (
          <Card key={g.project.id} className="overflow-hidden card-lift animate-slide-in-up" style={{ animationDelay: `${gIdx * 60}ms` }}>
            {/* Project header */}
            <div className="p-3 md:p-4 bg-secondary/40 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className={cn("w-3 h-3 rounded-md shrink-0", g.project.color)} />
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{g.project.name}</p>
                  <p className="text-[10px] text-muted-foreground">{g.project.key} · {g.items.length} milestone{g.items.length > 1 ? "s" : ""}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[10px] text-muted-foreground hidden sm:inline">
                  {g.project.tasksDone}/{g.project.tasksTotal} tasks
                </span>
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                  Open <ChevronRight className="w-3 h-3" />
                </Button>
              </div>
            </div>

            {/* Milestone rows */}
            <div className="divide-y divide-border">
              {g.items.map((m, idx) => {
                const sc = statusConfig[m.status]
                const StatusIcon = sc.icon
                const isDone = m.status === "done"
                const isOver = m.status === "overdue"
                return (
                  <div key={m.id} className="p-3 md:p-4 hover:bg-secondary/30 transition-colors group">
                    <div className="flex items-start gap-3">
                      {/* Status icon */}
                      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5", sc.className)}>
                        <StatusIcon className="w-4 h-4" />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-1 flex-wrap">
                          <h4 className={cn(
                            "text-sm font-medium line-clamp-1",
                            isDone ? "text-muted-foreground line-through" : "text-foreground"
                          )}>
                            {m.title}
                          </h4>
                          <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0", sc.className)}>
                            {sc.label}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-1 mb-2">{m.description}</p>

                        {/* Progress bar */}
                        <div className="flex items-center gap-3">
                          <Progress
                            value={m.progress}
                            className={cn("h-1.5 flex-1", isOver && "[&>div]:bg-rose-500")}
                          />
                          <span className="text-[10px] font-semibold text-muted-foreground tabular-nums w-9 text-right">
                            {m.progress}%
                          </span>
                        </div>

                        {/* Meta */}
                        <div className="flex items-center gap-3 mt-2 text-[11px] text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            <span className={isOver ? "text-rose-600 dark:text-rose-400 font-medium" : ""}>
                              {formatDate(m.dueDate)}
                            </span>
                          </span>
                          <span>·</span>
                          <span className={isOver ? "text-rose-600 dark:text-rose-400 font-medium" : ""}>
                            {relativeDay(m.dueDate)}
                          </span>
                          {!isDone && !isOver && (
                            <>
                              <span>·</span>
                              <span>{100 - m.progress}% to go</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </Card>
        ))}
      </div>

      {/* Average progress footer */}
      <Card className="p-4 md:p-5 mt-4 card-lift">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-foreground">Average Milestone Progress</h3>
          <span className="text-xs text-muted-foreground tabular-nums">{avgProgress}%</span>
        </div>
        <Progress value={avgProgress} className="h-2.5" />
        <p className="text-[11px] text-muted-foreground mt-2">
          Across {computed.length} milestones in {grouped.length} projects.
        </p>
      </Card>
    </DashboardShell>
  )
}
