"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus, Flag, CalendarRange, GitBranch, Target, ZoomIn,
  Diamond, Info,
} from "lucide-react"
import { projects, milestones } from "@/lib/data/mock"
import { ProjectStatusBadge, HealthBadge } from "@/components/common/badges"
import { cn, formatDate } from "@/lib/utils"

// H1 2026 window (Jan 1 – Jun 30, inclusive)
const WINDOW_START = new Date("2026-01-01")
const WINDOW_END = new Date("2026-06-30")
const TOTAL_DAYS = Math.round((WINDOW_END.getTime() - WINDOW_START.getTime()) / 86_400_000) + 1

const MONTHS = [
  { label: "Jan", short: "J", days: 31 },
  { label: "Feb", short: "F", days: 28 },
  { label: "Mar", short: "M", days: 31 },
  { label: "Apr", short: "A", days: 30 },
  { label: "May", short: "M", days: 31 },
  { label: "Jun", short: "J", days: 30 },
]

type RangeKey = "h1" | "q1" | "q2"

function clampToWindow(date: Date) {
  return new Date(Math.max(WINDOW_START.getTime(), Math.min(WINDOW_END.getTime(), date.getTime())))
}

function dayOffset(dateStr: string) {
  const d = clampToWindow(new Date(dateStr))
  return Math.round((d.getTime() - WINDOW_START.getTime()) / 86_400_000)
}

// Precompute month boundaries as static const (no mutation during render)
let _cumulative = 0
const monthBoundaries = MONTHS.map(m => {
  const start = _cumulative
  _cumulative += m.days
  return {
    ...m,
    startPct: (start / TOTAL_DAYS) * 100,
    endPct: (_cumulative / TOTAL_DAYS) * 100,
    widthPct: (m.days / TOTAL_DAYS) * 100,
  }
})

export default function RoadmapPage() {
  const [range, setRange] = useState<RangeKey>("h1")
  const [selectedProject, setSelectedProject] = useState<string | null>(null)

  // Projects active in H1 2026
  const roadmapProjects = useMemo(() =>
    projects.filter(p => {
      const start = new Date(p.startDate)
      const end = new Date(p.dueDate)
      return end >= WINDOW_START && start <= WINDOW_END && p.status !== "archived"
    }),
  [])

  // Milestones for these projects, clipped to window
  const roadmapMilestones = useMemo(() =>
    milestones.filter(m => {
      const d = new Date(m.dueDate)
      return d >= WINDOW_START && d <= WINDOW_END
    }),
  [])

  // Quarter filter — affects only highlight, not data.
  // The visible range is determined inside the month header render below.

  // Precompute month boundary percentages within full H1 window (module-level const above)

  return (
    <DashboardShell
      title="Roadmap"
      description="H1 2026 project timeline and milestones"
      actions={
        <>
          <Tabs value={range} onValueChange={(v) => setRange(v as RangeKey)}>
            <TabsList className="h-9">
              <TabsTrigger value="q1" className="text-xs">Q1</TabsTrigger>
              <TabsTrigger value="q2" className="text-xs">Q2</TabsTrigger>
              <TabsTrigger value="h1" className="text-xs">H1</TabsTrigger>
            </TabsList>
          </Tabs>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <ZoomIn className="w-4 h-4" /> Zoom
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New project
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Projects" value={roadmapProjects.length} hint="in H1 2026" icon={GitBranch} />
        <StatCard label="Milestones" value={roadmapMilestones.length} hint="scheduled" icon={Flag} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="On Track" value={roadmapProjects.filter(p => p.health === "on_track").length} hint="healthy projects" icon={Target} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="At Risk" value={roadmapProjects.filter(p => p.health !== "on_track").length} hint="need attention" icon={CalendarRange} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Legend */}
      <Card className="p-3 md:p-4 mb-4 flex flex-wrap items-center gap-3 text-xs">
        <span className="font-semibold text-foreground">Legend:</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm bg-primary/70" /> Planned duration</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm bg-primary" /> Completed</span>
        <span className="flex items-center gap-1.5"><Diamond className="w-3 h-3 fill-amber-500 text-amber-500" /> Milestone</span>
        <span className="flex items-center gap-1.5"><span className="w-0.5 h-3 bg-rose-500" /> Today</span>
        <span className="ml-auto text-muted-foreground hidden md:flex items-center gap-1">
          <Info className="w-3 h-3" /> Bars are clipped to the visible window
        </span>
      </Card>

      {/* Gantt timeline */}
      <Card className="p-3 md:p-5 card-lift overflow-hidden">
        <div className="overflow-x-auto no-scrollbar">
          <div className="min-w-[900px]">
            {/* Month header */}
            <div className="flex border-b border-border">
              <div className="w-56 shrink-0 p-2 text-xs font-semibold text-muted-foreground">
                Project
              </div>
              <div className="flex-1 relative h-9">
                {monthBoundaries.map((m, i) => {
                  const isOutsideVisibleRange =
                    (range === "q1" && i >= 3) || (range === "q2" && i < 3)
                  return (
                    <div
                      key={m.label}
                      className={cn(
                        "absolute top-0 bottom-0 flex items-center justify-center text-xs font-semibold border-l border-border",
                        isOutsideVisibleRange ? "text-muted-foreground/40 bg-muted/30" : "text-foreground"
                      )}
                      style={{ left: `${m.startPct}%`, width: `${m.widthPct}%` }}
                    >
                      <span className="hidden sm:inline">{m.label}</span>
                      <span className="sm:hidden">{m.short}</span>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Today marker position (Dec 30, 2025 today-ish based on mock data — but show as "now") */}
            {(() => {
              // Show "today" at a fixed position in early Jan to demonstrate (since mock dates are futuristic)
              const todayPct = 1.5
              return (
                <div
                  className="absolute top-9 bottom-0 w-0.5 bg-rose-500/70 z-10 pointer-events-none"
                  style={{ left: `calc(14rem + ${todayPct}% * (100% - 14rem) / 100)` }}
                  aria-hidden
                />
              )
            })()}

            {/* Project rows */}
            <div className="relative">
              {roadmapProjects.map((p, idx) => {
                const startOffset = dayOffset(p.startDate)
                const endOffset = dayOffset(p.dueDate)
                const leftPct = (startOffset / TOTAL_DAYS) * 100
                const widthPct = ((endOffset - startOffset) / TOTAL_DAYS) * 100
                const completedWidthPct = (widthPct * p.progress) / 100
                const isSel = selectedProject === p.id

                // Milestones on this row
                const rowMilestones = roadmapMilestones.filter(m => m.projectId === p.id)

                return (
                  <div
                    key={p.id}
                    className={cn(
                      "flex border-b border-border hover:bg-secondary/30 transition-colors cursor-pointer",
                      isSel && "bg-primary/5"
                    )}
                    onClick={() => setSelectedProject(isSel ? null : p.id)}
                    style={{ minHeight: 56 }}
                  >
                    {/* Project label */}
                    <div className="w-56 shrink-0 p-2.5 flex flex-col justify-center">
                      <div className="flex items-center gap-1.5">
                        <span className={cn("w-2 h-2 rounded-full shrink-0", p.color)} />
                        <span className="text-[10px] font-mono text-muted-foreground">{p.key}</span>
                      </div>
                      <p className="text-xs font-medium text-foreground line-clamp-1 mt-0.5">{p.name}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <ProjectStatusBadge status={p.status} />
                      </div>
                    </div>

                    {/* Timeline track */}
                    <div className="flex-1 relative py-3">
                      {/* Month gridlines */}
                      {monthBoundaries.map((m, i) => (
                        <div
                          key={i}
                          className="absolute top-0 bottom-0 w-px bg-border/60"
                          style={{ left: `${m.endPct}%` }}
                        />
                      ))}

                      {/* Project bar */}
                      <div
                        className="absolute top-1/2 -translate-y-1/2 h-7 rounded-md overflow-hidden group"
                        style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                      >
                        {/* Planned (background) */}
                        <div className={cn("absolute inset-0 opacity-40", p.color)} />
                        {/* Completed (foreground) */}
                        <div
                          className={cn("absolute inset-y-0 left-0 transition-all duration-700", p.color)}
                          style={{ width: `${p.progress}%` }}
                        />
                        {/* Label */}
                        <div className="absolute inset-0 flex items-center px-2 z-10">
                          <span className="text-[10px] font-semibold text-white truncate drop-shadow-sm">
                            {p.progress}%
                          </span>
                        </div>
                      </div>

                      {/* Milestone diamonds */}
                      {rowMilestones.map(m => {
                        const mPct = (dayOffset(m.dueDate) / TOTAL_DAYS) * 100
                        return (
                          <div
                            key={m.id}
                            className="absolute top-1/2 -translate-y-1/2 z-20 group/ms"
                            style={{ left: `${mPct}%`, transform: "translate(-50%, -50%)" }}
                            title={`${m.title} · ${formatDate(m.dueDate)}`}
                          >
                            <Diamond className={cn(
                              "w-4 h-4 fill-amber-400 text-amber-500 drop-shadow-sm",
                              "transition-transform group-hover/ms:scale-125"
                            )} />
                            <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 hidden group-hover/ms:block z-30 whitespace-nowrap">
                              <div className="bg-popover border border-border rounded-lg shadow-lg p-2 text-[10px]">
                                <p className="font-semibold text-foreground">{m.title}</p>
                                <p className="text-muted-foreground">{formatDate(m.dueDate)}</p>
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </Card>

      {/* Selected project detail + upcoming milestones */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mt-4">
        <Card className="p-4 md:p-5 lg:col-span-1 card-lift">
          <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-1.5">
            <Flag className="w-4 h-4 text-primary" /> Upcoming Milestones
          </h3>
          <div className="space-y-3 max-h-80 overflow-y-auto scroll-area-thin">
            {roadmapMilestones
              .slice()
              .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
              .map(m => (
                <div key={m.id} className="flex items-start gap-2.5">
                  <div className="relative flex flex-col items-center pt-1">
                    <Diamond className="w-3.5 h-3.5 fill-amber-400 text-amber-500 shrink-0" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium text-foreground line-clamp-1">{m.title}</p>
                    <p className="text-[10px] text-muted-foreground">{m.projectName}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{formatDate(m.dueDate)}</p>
                  </div>
                  <span className={cn(
                    "text-[10px] font-semibold px-1.5 py-0.5 rounded-full shrink-0",
                    m.status === "done" ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" :
                    m.status === "in_progress" ? "bg-amber-500/15 text-amber-600 dark:text-amber-400" :
                    m.status === "overdue" ? "bg-rose-500/15 text-rose-600 dark:text-rose-400" :
                    "bg-muted text-muted-foreground"
                  )}>
                    {m.status.replace("_", " ")}
                  </span>
                </div>
              ))}
          </div>
        </Card>

        <Card className="p-4 md:p-5 lg:col-span-2 card-lift">
          <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-1.5">
            <GitBranch className="w-4 h-4 text-primary" /> Project Health
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {roadmapProjects.slice(0, 6).map(p => (
              <div key={p.id} className="rounded-lg border border-border p-3 hover:border-primary/30 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className={cn("w-2 h-2 rounded-full shrink-0", p.color)} />
                      <span className="text-[10px] font-mono text-muted-foreground">{p.key}</span>
                    </div>
                    <p className="text-xs font-medium text-foreground line-clamp-1 mt-0.5">{p.name}</p>
                  </div>
                  <HealthBadge health={p.health} />
                </div>
                <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                  <Avatar className="w-5 h-5 ring-1 ring-border">
                    <AvatarImage src={p.leadAvatar} alt={p.lead} />
                    <AvatarFallback className="text-[9px]">{p.lead[0]}</AvatarFallback>
                  </Avatar>
                  <span>{p.lead}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
