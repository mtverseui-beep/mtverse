"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Table, TableHeader, TableBody, TableHead, TableRow, TableCell,
} from "@/components/ui/table"
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Search, ListChecks, Trash2, MoreHorizontal, Pencil, Copy, Download,
  ChevronLeft, ChevronRight, Clock, DollarSign, Calendar, Filter, X,
} from "lucide-react"
import { timeEntries, projects, members } from "@/lib/data/mock"
import { useMemo, useState } from "react"
import { cn, formatDuration, formatDate } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import {
  TimeViewNav, EntryStatusBadge, formatHours, MemberAvatar, formatClock, downloadCSV, type EntryStatus,
} from "../_lib"

type BillableFilter = "all" | "billable" | "non_billable"
type StatusFilter = "all" | EntryStatus

const PAGE_SIZE = 8

export default function EntriesPage() {
  const { toast } = useToast()
  const [search, setSearch] = useState("")
  const [projectId, setProjectId] = useState<string>("all")
  const [memberFilter, setMemberFilter] = useState<string>("all")
  const [billable, setBillable] = useState<BillableFilter>("all")
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all")
  const [fromDate, setFromDate] = useState<string>("")
  const [toDate, setToDate] = useState<string>("")
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [page, setPage] = useState(0)
  const [localEntries, setLocalEntries] = useState(() => timeEntries.map(e => ({ ...e })))

  const filtered = useMemo(() => {
    return localEntries.filter(e => {
      if (search && !e.description.toLowerCase().includes(search.toLowerCase()) && !e.projectName.toLowerCase().includes(search.toLowerCase())) return false
      if (projectId !== "all" && e.projectId !== projectId) return false
      if (memberFilter !== "all" && e.memberId !== memberFilter) return false
      if (billable === "billable" && !e.billable) return false
      if (billable === "non_billable" && e.billable) return false
      if (statusFilter !== "all" && e.status !== statusFilter) return false
      const ed = e.start.slice(0, 10)
      if (fromDate && ed < fromDate) return false
      if (toDate && ed > toDate) return false
      return true
    })
  }, [localEntries, search, projectId, memberFilter, billable, statusFilter, fromDate, toDate])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages - 1)
  const paged = filtered.slice(currentPage * PAGE_SIZE, currentPage * PAGE_SIZE + PAGE_SIZE)

  const allOnPageSelected = paged.length > 0 && paged.every(e => selected.has(e.id))
  const someOnPageSelected = paged.some(e => selected.has(e.id))

  function toggleAll() {
    const next = new Set(selected)
    if (allOnPageSelected) {
      paged.forEach(e => next.delete(e.id))
    } else {
      paged.forEach(e => next.add(e.id))
    }
    setSelected(next)
  }
  function toggleOne(id: string) {
    const next = new Set(selected)
    if (next.has(id)) next.delete(id)
    else next.add(id)
    setSelected(next)
  }

  function bulkDelete() {
    if (selected.size === 0) return
    setLocalEntries(prev => prev.filter(e => !selected.has(e.id)))
    toast({ title: `${selected.size} entries deleted`, description: "Removed from your time log." })
    setSelected(new Set())
  }

  function deleteOne(id: string) {
    setLocalEntries(prev => prev.filter(e => e.id !== id))
    toast({ title: "Entry deleted", description: "1 entry removed." })
  }

  function duplicateEntry(id: string) {
    const orig = localEntries.find(e => e.id === id)
    if (!orig) return
    const copy = { ...orig, id: `${orig.id}-copy-${Date.now()}`, start: orig.start, end: orig.end, status: "running" as EntryStatus }
    setLocalEntries(prev => [copy, ...prev])
    toast({ title: "Entry duplicated", description: `Copied "${orig.description.slice(0, 40)}..."` })
  }

  function clearFilters() {
    setSearch(""); setProjectId("all"); setMemberFilter("all")
    setBillable("all"); setStatusFilter("all"); setFromDate(""); setToDate("")
  }

  const hasFilters = search || projectId !== "all" || memberFilter !== "all" || billable !== "all" || statusFilter !== "all" || fromDate || toDate
  const totalHours = filtered.reduce((s, e) => s + e.duration, 0)
  const billableHours = filtered.filter(e => e.billable).reduce((s, e) => s + e.duration, 0)
  const avgDuration = filtered.length > 0 ? Math.round(totalHours / filtered.length) : 0

  return (
    <DashboardShell
      title="Time Entries"
      description="All tracked time across projects, members, and dates — with bulk actions."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent" onClick={clearFilters} disabled={!hasFilters}>
            <Filter className="w-4 h-4" /> Clear
          </Button>
          <Button
            variant="outline"
            className="h-9 text-sm gap-1.5 bg-transparent"
            onClick={() => {
              const rows: (string | number)[][] = [
                ["Date", "Member", "Project", "Description", "Start", "End", "Duration (h)", "Billable", "Status"],
                ...filtered.map(e => [
                  e.start.slice(0, 10), e.memberName, e.projectName, e.description,
                  formatClock(e.start), formatClock(e.end),
                  (e.duration / 3600).toFixed(2),
                  e.billable ? "Yes" : "No", e.status,
                ]),
              ]
              downloadCSV("time-entries.csv", rows)
              toast({ title: "Exported", description: `${filtered.length} entries → time-entries.csv` })
            }}
          >
            <Download className="w-4 h-4" /> Export
          </Button>
        </>
      }
    >
      <TimeViewNav active="/time/entries" />

      {/* Filters bar */}
      <Card className="p-3 md:p-4 mb-4 card-lift">
        <div className="flex flex-col lg:flex-row gap-3 lg:items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search description or project…"
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(0) }}
              className="pl-9 h-9 text-sm"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={projectId} onValueChange={v => { setProjectId(v); setPage(0) }}>
              <SelectTrigger className="h-9 w-[170px] text-sm"><SelectValue placeholder="Project" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All projects</SelectItem>
                {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={memberFilter} onValueChange={v => { setMemberFilter(v); setPage(0) }}>
              <SelectTrigger className="h-9 w-[150px] text-sm"><SelectValue placeholder="Member" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All members</SelectItem>
                {members.map(m => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={billable} onValueChange={(v: BillableFilter) => { setBillable(v); setPage(0) }}>
              <SelectTrigger className="h-9 w-[130px] text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="billable">Billable</SelectItem>
                <SelectItem value="non_billable">Non-billable</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={(v: StatusFilter) => { setStatusFilter(v); setPage(0) }}>
              <SelectTrigger className="h-9 w-[140px] text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All status</SelectItem>
                <SelectItem value="running">Running</SelectItem>
                <SelectItem value="submitted">Submitted</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 mt-3 pt-3 border-t border-border">
          <div className="flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-[11px] text-muted-foreground">From</span>
            <Input type="date" value={fromDate} onChange={e => { setFromDate(e.target.value); setPage(0) }} className="h-8 w-[140px] text-xs" />
            <span className="text-[11px] text-muted-foreground">To</span>
            <Input type="date" value={toDate} onChange={e => { setToDate(e.target.value); setPage(0) }} className="h-8 w-[140px] text-xs" />
          </div>
          <div className="flex-1" />
          {hasFilters && (
            <Button variant="ghost" size="sm" className="h-8 text-xs gap-1" onClick={clearFilters}>
              <X className="w-3 h-3" /> Reset filters
            </Button>
          )}
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Entries" value={filtered.length} hint="matching filters" icon={ListChecks} />
        <StatCard label="Total Hours" value={formatHours(totalHours)} hint={`${Math.round(totalHours / 3600)}h ${Math.round((totalHours % 3600) / 60)}m`} icon={Clock} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Billable Hours" value={formatHours(billableHours)} hint={`${totalHours > 0 ? Math.round((billableHours / totalHours) * 100) : 0}% billable`} icon={DollarSign} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Avg Duration" value={formatDuration(avgDuration)} hint="per entry" icon={Calendar} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Bulk action bar */}
      {selected.size > 0 && (
        <div className="mb-3 flex items-center justify-between bg-primary/10 border border-primary/20 rounded-lg px-4 py-2.5 animate-fade-in">
          <span className="text-xs font-medium text-foreground">{selected.size} selected</span>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => setSelected(new Set())}>
              Clear
            </Button>
            <Button size="sm" variant="destructive" className="h-7 text-xs gap-1" onClick={bulkDelete}>
              <Trash2 className="w-3.5 h-3.5" /> Delete selected
            </Button>
          </div>
        </div>
      )}

      {/* Table */}
      <Card className="card-lift overflow-hidden">
        {paged.length === 0 ? (
          <EmptyState
            icon={ListChecks}
            title="No entries match"
            description="Try adjusting your filters or clearing the search."
            action={{ label: "Clear filters", onClick: clearFilters }}
            className="m-4"
          />
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden md:block overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-secondary/40 hover:bg-secondary/40">
                    <TableHead className="w-[40px] pl-4">
                      <Checkbox checked={allOnPageSelected} onCheckedChange={toggleAll} aria-label="Select all" />
                    </TableHead>
                    <TableHead className="text-[11px]">Member</TableHead>
                    <TableHead className="text-[11px]">Description</TableHead>
                    <TableHead className="text-[11px]">Project</TableHead>
                    <TableHead className="text-[11px]">Date</TableHead>
                    <TableHead className="text-[11px]">Time</TableHead>
                    <TableHead className="text-[11px] text-right">Duration</TableHead>
                    <TableHead className="text-[11px]">Billable</TableHead>
                    <TableHead className="text-[11px]">Status</TableHead>
                    <TableHead className="w-[40px] pr-4"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paged.map(e => (
                    <TableRow key={e.id} className={cn("hover:bg-secondary/30", selected.has(e.id) && "bg-primary/5")}>
                      <TableCell className="pl-4">
                        <Checkbox checked={selected.has(e.id)} onCheckedChange={() => toggleOne(e.id)} aria-label={`Select ${e.id}`} />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <MemberAvatar name={e.memberName} avatar={e.memberAvatar} size={26} />
                          <span className="text-xs font-medium truncate max-w-[120px]">{e.memberName}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <p className="text-xs font-medium text-foreground truncate max-w-[200px]">{e.description}</p>
                        {e.taskKey && <p className="text-[10px] text-muted-foreground">{e.taskKey}</p>}
                      </TableCell>
                      <TableCell>
                        <span className="inline-flex items-center gap-1.5 text-[11px]">
                          <span className={cn("w-1.5 h-1.5 rounded-full", (projects.find(p => p.id === e.projectId)?.color) ?? "bg-emerald-500")} />
                          {e.projectName}
                        </span>
                      </TableCell>
                      <TableCell className="text-[11px] text-muted-foreground">{formatDate(e.start, { month: "short", day: "numeric" })}</TableCell>
                      <TableCell className="text-[11px] text-muted-foreground tabular-nums">{formatClock(e.start)}–{formatClock(e.end)}</TableCell>
                      <TableCell className="text-right">
                        <span className="text-xs font-semibold tabular-nums">{formatDuration(e.duration)}</span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn("text-[9px]", e.billable ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground")}>
                          {e.billable ? "Billable" : "Non-bill"}
                        </Badge>
                      </TableCell>
                      <TableCell><EntryStatusBadge status={e.status as EntryStatus} /></TableCell>
                      <TableCell className="pr-4">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7">
                              <MoreHorizontal className="w-3.5 h-3.5" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => toast({ title: "Edit entry", description: "Opening editor (demo)…" })}>
                              <Pencil className="w-3.5 h-3.5 mr-2" /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => duplicateEntry(e.id)}>
                              <Copy className="w-3.5 h-3.5 mr-2" /> Duplicate
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-rose-600 dark:text-rose-400" onClick={() => deleteOne(e.id)}>
                              <Trash2 className="w-3.5 h-3.5 mr-2" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Mobile cards */}
            <div className="md:hidden divide-y divide-border">
              {paged.map(e => (
                <div key={e.id} className={cn("p-3 flex gap-2", selected.has(e.id) && "bg-primary/5")}>
                  <Checkbox checked={selected.has(e.id)} onCheckedChange={() => toggleOne(e.id)} aria-label={`Select ${e.id}`} className="mt-1" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-medium truncate">{e.description}</p>
                      <span className="text-xs font-semibold shrink-0">{formatDuration(e.duration)}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1.5">
                      <MemberAvatar name={e.memberName} avatar={e.memberAvatar} size={20} />
                      <span className="text-[10px] text-muted-foreground">{e.memberName}</span>
                      <span className="text-[10px] text-muted-foreground">·</span>
                      <span className="text-[10px] text-muted-foreground">{e.projectName}</span>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-[10px] text-muted-foreground">{formatDate(e.start, { month: "short", day: "numeric" })} · {formatClock(e.start)}</span>
                      <div className="flex items-center gap-1.5">
                        <EntryStatusBadge status={e.status as EntryStatus} />
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <MoreHorizontal className="w-3.5 h-3.5" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => toast({ title: "Edit entry", description: "Opening editor (demo)…" })}>
                              <Pencil className="w-3.5 h-3.5 mr-2" /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => duplicateEntry(e.id)}>
                              <Copy className="w-3.5 h-3.5 mr-2" /> Duplicate
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-rose-600 dark:text-rose-400" onClick={() => deleteOne(e.id)}>
                              <Trash2 className="w-3.5 h-3.5 mr-2" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-border">
              <span className="text-[11px] text-muted-foreground">
                Showing {currentPage * PAGE_SIZE + 1}–{Math.min(filtered.length, (currentPage + 1) * PAGE_SIZE)} of {filtered.length}
              </span>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => setPage(p => Math.max(0, p - 1))}
                  disabled={currentPage === 0}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-xs text-muted-foreground">{currentPage + 1} / {totalPages}</span>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                  disabled={currentPage >= totalPages - 1}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        )}
      </Card>
    </DashboardShell>
  )
}
