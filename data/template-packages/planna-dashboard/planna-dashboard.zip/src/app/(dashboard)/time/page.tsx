"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaAreaChart, PlannaDonutChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import {
  Clock, DollarSign, Timer, Play, Pause, Square, Plus, CheckCircle2,
  Coffee, Target, ListChecks, Link as LinkIcon,
} from "lucide-react"
import { timeEntries, projects, currentMember } from "@/lib/data/mock"
import { useTimerStore, formatTimer, getElapsed } from "@/lib/store/timer-store"
import { useEffect, useMemo, useState } from "react"
import { cn, formatDuration, timeAgo } from "@/lib/utils"
import Link from "next/link"
import {
  TimeViewNav, EntryStatusBadge, formatHours, hoursFromSeconds, MemberAvatar,
} from "./_lib"

const HOURLY_RATE = 95 // $/hr
const DAILY_GOAL_SECONDS = 8 * 3600

export default function TimeTrackerPage() {
  const timer = useTimerStore()
  const [, force] = useState(0)
  useEffect(() => {
    if (!timer.running) return
    const i = setInterval(() => force(x => x + 1), 1000)
    return () => clearInterval(i)
  }, [timer.running])

  const elapsed = getElapsed()

  // Today's entries (currentMember)
  const todayEntries = useMemo(() => {
    const today = new Date()
    return timeEntries.filter(e => {
      const d = new Date(e.start)
      return (
        e.memberId === currentMember.id &&
        d.getFullYear() === today.getFullYear() &&
        d.getMonth() === today.getMonth() &&
        d.getDate() === today.getDate()
      )
    })
  }, [])

  // If no entries for today, fall back to latest 5 for the current member
  const recentEntries = useMemo(() => {
    if (todayEntries.length > 0) return todayEntries.slice(0, 5)
    return timeEntries.filter(e => e.memberId === currentMember.id).slice(0, 5)
  }, [todayEntries])

  const todayTrackedSeconds = todayEntries.reduce((s, e) => s + e.duration, 0) + elapsed
  const todayBillableSeconds =
    todayEntries.filter(e => e.billable).reduce((s, e) => s + e.duration, 0) +
    (timer.billable ? elapsed : 0)
  const todayNonBillableSeconds = todayTrackedSeconds - todayBillableSeconds
  const goalPct = Math.min(100, Math.round((todayTrackedSeconds / DAILY_GOAL_SECONDS) * 100))

  // Weekly hours (last 7 days, currentMember)
  const weeklyData = useMemo(() => {
    const today = new Date()
    return Array.from({ length: 7 }).map((_, i) => {
      const d = new Date(today)
      d.setDate(d.getDate() - (6 - i))
      const dayEntries = timeEntries.filter(e => {
        const ed = new Date(e.start)
        return (
          e.memberId === currentMember.id &&
          ed.getFullYear() === d.getFullYear() &&
          ed.getMonth() === d.getMonth() &&
          ed.getDate() === d.getDate()
        )
      })
      const total = dayEntries.reduce((s, e) => s + e.duration, 0)
      const bill = dayEntries.filter(e => e.billable).reduce((s, e) => s + e.duration, 0)
      return {
        day: d.toLocaleDateString("en-US", { weekday: "short" }),
        hours: +(total / 3600).toFixed(2),
        billable: +(bill / 3600).toFixed(2),
      }
    })
  }, [])

  const totalHours = timeEntries.reduce((s, e) => s + e.duration, 0) / 3600
  const billableHours = timeEntries.filter(e => e.billable).reduce((s, e) => s + e.duration, 0) / 3600
  const billablePct = Math.round((billableHours / totalHours) * 100)
  const pendingCount = timeEntries.filter(e => e.status === "submitted").length

  return (
    <DashboardShell
      title="Time Tracker"
      description="Track live time, hit your daily goal, and review recent activity."
      actions={
        <>
          <Button asChild variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Link href="/time/manual"><Plus className="w-4 h-4" /> Manual entry</Link>
          </Button>
          <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Link href="/time/timesheets">Timesheets</Link>
          </Button>
        </>
      }
    >
      <TimeViewNav active="/time" />

      {/* Live timer + Today summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        {/* Big timer card */}
        <Card className="p-5 lg:col-span-2 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20 card-lift animate-slide-in-up">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <Timer className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Live Tracker</h3>
              {timer.running ? (
                <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Running
                </Badge>
              ) : (
                <Badge variant="outline" className="text-[10px]">Idle</Badge>
              )}
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <span className="text-[11px] text-muted-foreground">Billable</span>
              <Switch checked={timer.billable} onCheckedChange={timer.toggleBillable} />
            </label>
          </div>

          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
            <div className="min-w-0">
              <p className="text-6xl md:text-7xl font-bold text-foreground tabular-nums tracking-tight leading-none">
                {formatTimer(elapsed)}
              </p>
              <div className="mt-3 flex items-center gap-2 flex-wrap">
                <Select
                  value={timer.projectName}
                  onValueChange={(v) => {
                    if (!timer.running) {
                      useTimerStore.setState({ projectName: v })
                    } else {
                      useTimerStore.setState({ projectName: v })
                    }
                  }}
                >
                  <SelectTrigger className="h-8 w-[200px] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map(p => (
                      <SelectItem key={p.id} value={p.name}>
                        <span className="flex items-center gap-1.5">
                          <span className={cn("w-1.5 h-1.5 rounded-full", p.color)} />
                          {p.name}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Badge variant="outline" className="text-[10px]">
                  {timer.billable ? "Billable" : "Non-billable"}
                </Badge>
                <Badge variant="outline" className="text-[10px] gap-1">
                  <LinkIcon className="w-3 h-3" /> Task {timer.taskId ?? "—"}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Rate: <span className="font-semibold text-foreground">${HOURLY_RATE}/hr</span> · Potential{" "}
                <span className="font-semibold text-foreground">
                  ${((elapsed / 3600) * HOURLY_RATE).toFixed(2)}
                </span>
              </p>
            </div>

            <div className="flex items-center gap-2">
              {!timer.running ? (
                <Button
                  size="lg"
                  className="h-14 px-7 gap-2 bg-primary hover:bg-primary/90 text-base"
                  onClick={() => timer.start()}
                >
                  <Play className="w-5 h-5" /> Start
                </Button>
              ) : (
                <Button
                  size="lg"
                  variant="outline"
                  className="h-14 px-7 gap-2 text-base"
                  onClick={() => timer.pause()}
                >
                  <Pause className="w-5 h-5" /> Pause
                </Button>
              )}
              <Button
                size="lg"
                variant="ghost"
                className="h-14 px-5"
                onClick={() => timer.reset()}
                disabled={elapsed === 0 && !timer.running}
                title="Reset"
              >
                <Square className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </Card>

        {/* Today summary card with goal progress */}
        <Card className="p-5 card-lift animate-slide-in-up stagger-1">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Today</h3>
            </div>
            <span className="text-[11px] text-muted-foreground">{goalPct}% of goal</span>
          </div>

          <div className="flex items-baseline gap-2 mb-3">
            <p className="text-3xl font-bold text-foreground tabular-nums">{formatHours(todayTrackedSeconds)}</p>
            <p className="text-xs text-muted-foreground">/ {formatHours(DAILY_GOAL_SECONDS)}</p>
          </div>

          <Progress value={goalPct} className="h-2.5 mb-3" />

          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-border">
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <p className="text-[10px] text-muted-foreground">Billable</p>
              </div>
              <p className="text-base font-bold text-foreground">{formatHours(todayBillableSeconds)}</p>
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground" />
                <p className="text-[10px] text-muted-foreground">Non-billable</p>
              </div>
              <p className="text-base font-bold text-foreground">{formatHours(todayNonBillableSeconds)}</p>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
            <span className="text-[11px] text-muted-foreground">Today's revenue</span>
            <span className="text-sm font-semibold text-foreground">
              ${((todayBillableSeconds / 3600) * HOURLY_RATE).toFixed(0)}
            </span>
          </div>
        </Card>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Hours This Week" value={`${Math.round(totalHours)}h`} hint="across team" icon={Clock} trend={{ value: 8, positive: true }} />
        <StatCard label="Billable %" value={`${billablePct}%`} hint={`${Math.round(billableHours)}h billable`} icon={DollarSign} trend={{ value: 4, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Pending Approval" value={pendingCount} hint="entries awaiting" icon={CheckCircle2} trend={{ value: 0, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Session" value="42m" hint="per focus block" icon={Coffee} trend={{ value: 6, positive: true }} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Weekly Hours" subtitle="Your last 7 days" className="lg:col-span-2">
          <PlannaAreaChart
            data={weeklyData}
            xKey="day"
            series={[
              { key: "hours", name: "Total" },
              { key: "billable", name: "Billable", color: "var(--chart-2)" },
            ]}
            height={260}
          />
        </ChartCard>
        <ChartCard title="Time Split" subtitle="Billable vs non-billable" fullscreen={false}>
          <PlannaDonutChart
            data={[
              { name: "Billable", value: +billableHours.toFixed(2), color: "var(--chart-1)" },
              { name: "Non-billable", value: +(totalHours - billableHours).toFixed(2), color: "var(--chart-4)" },
            ]}
            centerValue={`${billablePct}%`}
            centerLabel="billable"
            height={240}
          />
        </ChartCard>
      </div>

      {/* Recent entries */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ListChecks className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Recent Entries</h3>
          </div>
          <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
            <Link href="/time/entries">All entries</Link>
          </Button>
        </div>

        {recentEntries.length === 0 ? (
          <div className="text-center py-10">
            <Clock className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No entries yet today. Start the timer!</p>
          </div>
        ) : (
          <div className="space-y-1.5 max-h-96 overflow-y-auto scroll-area-thin pr-1">
            {recentEntries.map(e => (
              <div
                key={e.id}
                className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-secondary/40 transition-colors group"
              >
                <MemberAvatar name={e.memberName} avatar={e.memberAvatar} size={32} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{e.description}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] text-muted-foreground">{e.projectName}</span>
                    <span className="text-[10px] text-muted-foreground">·</span>
                    <span className="text-[10px] text-muted-foreground">{timeAgo(e.start)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <EntryStatusBadge status={e.status as any} />
                  <div className="text-right min-w-[60px]">
                    <p className="text-xs font-semibold text-foreground tabular-nums">{formatDuration(e.duration)}</p>
                    <Badge variant="outline" className={cn("text-[9px] mt-0.5", e.billable ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground")}>
                      {e.billable ? "Billable" : "Non-bill"}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </DashboardShell>
  )
}
