"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Play, Pause, RotateCcw, SkipForward, Coffee, Brain, Flame,
  Clock3, Target, Settings, CheckCircle2,
} from "lucide-react"
import { useEffect, useMemo, useState, useCallback } from "react"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { TimeViewNav, formatHours } from "../_lib"

type Phase = "work" | "short_break" | "long_break"

const DEFAULT_WORK = 25 // minutes
const DEFAULT_SHORT = 5
const DEFAULT_LONG = 15
const DEFAULT_LONG_EVERY = 4

function phaseMeta(phase: Phase) {
  switch (phase) {
    case "work": return { label: "Focus", icon: Brain, color: "var(--chart-1)", chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" }
    case "short_break": return { label: "Short break", icon: Coffee, color: "var(--chart-2)", chip: "bg-teal-500/15 text-teal-600 dark:text-teal-400" }
    case "long_break": return { label: "Long break", icon: Coffee, color: "var(--chart-3)", chip: "bg-lime-500/15 text-lime-600 dark:text-lime-400" }
  }
}

export default function PomodoroPage() {
  const { toast } = useToast()
  const [workMin, setWorkMin] = useState(DEFAULT_WORK)
  const [shortMin, setShortMin] = useState(DEFAULT_SHORT)
  const [longMin, setLongMin] = useState(DEFAULT_LONG)
  const [longEvery, setLongEvery] = useState(DEFAULT_LONG_EVERY)
  const [autoStartBreaks, setAutoStartBreaks] = useState(false)

  const [phase, setPhase] = useState<Phase>("work")
  const [secondsLeft, setSecondsLeft] = useState(workMin * 60)
  const [running, setRunning] = useState(false)
  const [sessionsToday, setSessionsToday] = useState(3)
  const [totalSecondsToday, setTotalSecondsToday] = useState(75 * 60)
  const [streak, setStreak] = useState(5)
  const [showSettings, setShowSettings] = useState(false)

  const phaseDuration = useCallback(() => {
    if (phase === "work") return workMin * 60
    if (phase === "short_break") return shortMin * 60
    return longMin * 60
  }, [phase, workMin, shortMin, longMin])

  // Reset timer when phase changes
  useEffect(() => {
    setSecondsLeft(phaseDuration())
  }, [phaseDuration])

  // Tick
  useEffect(() => {
    if (!running) return
    const i = setInterval(() => {
      setSecondsLeft(prev => {
        if (prev <= 1) {
          // Phase complete
          handlePhaseComplete()
          return 0
        }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(i)
  }, [running, phase])

  function handlePhaseComplete() {
    setRunning(false)
    if (phase === "work") {
      const newCount = sessionsToday + 1
      setSessionsToday(newCount)
      setTotalSecondsToday(prev => prev + workMin * 60)
      toast({ title: "Pomodoro complete!", description: `${workMin} min focus logged. Time for a break.` })
      // Long break?
      const nextPhase: Phase = newCount % longEvery === 0 ? "long_break" : "short_break"
      setPhase(nextPhase)
      if (autoStartBreaks) setRunning(true)
    } else {
      toast({ title: "Break over", description: "Ready for another focus session?" })
      setPhase("work")
      if (autoStartBreaks) setRunning(true)
    }
  }

  function skipPhase() {
    if (phase === "work") {
      setPhase(prev => prev === "work" ? (sessionsToday + 1) % longEvery === 0 ? "long_break" : "short_break" : prev)
    } else {
      setPhase("work")
    }
    setRunning(false)
  }

  function resetAll() {
    setRunning(false)
    setPhase("work")
    setSecondsLeft(workMin * 60)
  }

  function resetDayStats() {
    setSessionsToday(0)
    setTotalSecondsToday(0)
    setStreak(0)
    toast({ title: "Today's stats reset" })
  }

  const meta = phaseMeta(phase)
  const Icon = meta.icon
  const totalForPhase = phaseDuration()
  const progressPct = totalForPhase > 0 ? ((totalForPhase - secondsLeft) / totalForPhase) * 100 : 0

  // Circular SVG progress
  const radius = 130
  const circumference = 2 * Math.PI * radius
  const strokeOffset = circumference - (progressPct / 100) * circumference

  const mm = Math.floor(secondsLeft / 60).toString().padStart(2, "0")
  const ss = (secondsLeft % 60).toString().padStart(2, "0")

  const sessionDots = Array.from({ length: Math.max(longEvery, 4) }).map((_, i) => i < (sessionsToday % longEvery || (sessionsToday > 0 && sessionsToday % longEvery === 0 ? longEvery : 0)))

  return (
    <DashboardShell
      title="Pomodoro Timer"
      description="Classic 25/5 focus technique with long breaks and session tracking."
      actions={
        <Button
          variant="outline"
          className="h-9 text-sm gap-1.5 bg-transparent"
          onClick={() => setShowSettings(s => !s)}
        >
          <Settings className="w-4 h-4" /> Settings
        </Button>
      }
    >
      <TimeViewNav active="/time/pomodoro" />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard
          label="Sessions Today"
          value={sessionsToday}
          hint={`${Math.round(sessionsToday * workMin)} min focus`}
          icon={Clock3}
          trend={{ value: 25, positive: true }}
          iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
        />
        <StatCard
          label="Total Focus"
          value={formatHours(totalSecondsToday)}
          hint="today's deep work"
          icon={Brain}
          trend={{ value: 12, positive: true }}
          iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400"
        />
        <StatCard
          label="Streak"
          value={`${streak} days`}
          hint="consecutive focus"
          icon={Flame}
          trend={{ value: 2, positive: true }}
          iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400"
        />
        <StatCard
          label="Next Long Break"
          value={`${longEvery - (sessionsToday % longEvery || longEvery)} sessions`}
          hint={`every ${longEvery} sessions`}
          icon={Target}
          iconColor="bg-lime-500/15 text-lime-600 dark:text-lime-400"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Big circular timer */}
        <Card className="lg:col-span-2 p-6 md:p-8 card-lift bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Badge className={cn("text-[11px] gap-1.5", meta.chip)}>
                <Icon className="w-3 h-3" />
                {meta.label}
              </Badge>
              {running && (
                <Badge variant="outline" className="text-[10px] gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Running
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-1.5">
              {Array.from({ length: longEvery }).map((_, i) => {
                const completed = i < (sessionsToday % longEvery || (sessionsToday > 0 && sessionsToday % longEvery === 0 ? longEvery : 0))
                return (
                  <span
                    key={i}
                    className={cn(
                      "w-2 h-2 rounded-full transition-colors",
                      completed ? "bg-primary" : "bg-muted-foreground/20"
                    )}
                  />
                )
              })}
            </div>
          </div>

          {/* Circular SVG timer */}
          <div className="flex justify-center py-4">
            <div className="relative" style={{ width: 300, height: 300 }}>
              <svg width="300" height="300" className="-rotate-90">
                <circle
                  cx="150" cy="150" r={radius}
                  fill="none"
                  stroke="var(--muted)"
                  strokeWidth="14"
                />
                <circle
                  cx="150" cy="150" r={radius}
                  fill="none"
                  stroke={meta.color}
                  strokeWidth="14"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeOffset}
                  style={{ transition: "stroke-dashoffset 1s linear" }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className="text-6xl font-bold text-foreground tabular-nums tracking-tight">
                  {mm}:{ss}
                </p>
                <p className="text-[11px] text-muted-foreground mt-2">{meta.label} phase</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{Math.round(progressPct)}% complete</p>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-3 mt-6">
            <Button variant="ghost" size="icon" className="h-12 w-12" onClick={resetAll} title="Reset">
              <RotateCcw className="w-5 h-5" />
            </Button>
            <Button
              size="lg"
              className={cn(
                "h-16 px-10 gap-2 text-base",
                phase === "work" ? "bg-primary hover:bg-primary/90" : "bg-emerald-600 hover:bg-emerald-700",
                "text-primary-foreground"
              )}
              onClick={() => setRunning(r => !r)}
            >
              {!running ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
              {!running ? "Start" : "Pause"}
            </Button>
            <Button variant="ghost" size="icon" className="h-12 w-12" onClick={skipPhase} title="Skip phase">
              <SkipForward className="w-5 h-5" />
            </Button>
          </div>
        </Card>

        {/* Settings + session log */}
        <div className="space-y-3 md:space-y-4">
          {showSettings && (
            <Card className="p-4 md:p-5 card-lift animate-fade-in">
              <div className="flex items-center gap-2 mb-4">
                <Settings className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Timer Settings</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-xs">Focus duration</Label>
                    <span className="text-xs font-semibold text-primary">{workMin} min</span>
                  </div>
                  <Slider value={[workMin]} onValueChange={([v]) => setWorkMin(v)} min={5} max={60} step={5} />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-xs">Short break</Label>
                    <span className="text-xs font-semibold text-primary">{shortMin} min</span>
                  </div>
                  <Slider value={[shortMin]} onValueChange={([v]) => setShortMin(v)} min={1} max={15} step={1} />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-xs">Long break</Label>
                    <span className="text-xs font-semibold text-primary">{longMin} min</span>
                  </div>
                  <Slider value={[longMin]} onValueChange={([v]) => setLongMin(v)} min={10} max={30} step={5} />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-xs">Long break every</Label>
                    <span className="text-xs font-semibold text-primary">{longEvery} sessions</span>
                  </div>
                  <Slider value={[longEvery]} onValueChange={([v]) => setLongEvery(v)} min={2} max={8} step={1} />
                </div>
                <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-border">
                  <span className="text-xs">Auto-start breaks</span>
                  <Switch checked={autoStartBreaks} onCheckedChange={setAutoStartBreaks} />
                </label>
              </div>
            </Card>
          )}

          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Today's Progress</h3>
              </div>
              <Button variant="ghost" size="sm" className="h-7 text-[10px]" onClick={resetDayStats}>
                Reset
              </Button>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/40">
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 text-primary" />
                  <div>
                    <p className="text-xs font-medium">Sessions</p>
                    <p className="text-[10px] text-muted-foreground">{sessionsToday} completed</p>
                  </div>
                </div>
                <span className="text-lg font-bold tabular-nums">{sessionsToday}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/40">
                <div className="flex items-center gap-2">
                  <Clock3 className="w-4 h-4 text-teal-500" />
                  <div>
                    <p className="text-xs font-medium">Focus time</p>
                    <p className="text-[10px] text-muted-foreground">today</p>
                  </div>
                </div>
                <span className="text-lg font-bold tabular-nums">{formatHours(totalSecondsToday)}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/40">
                <div className="flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-500" />
                  <div>
                    <p className="text-xs font-medium">Streak</p>
                    <p className="text-[10px] text-muted-foreground">consecutive days</p>
                  </div>
                </div>
                <span className="text-lg font-bold tabular-nums">{streak}d</span>
              </div>
            </div>
          </Card>

          {/* Phase legend */}
          <Card className="p-4 md:p-5 card-lift">
            <h3 className="text-sm font-semibold mb-3">Phases</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs py-1.5">
                <span className="flex items-center gap-2"><Brain className="w-3.5 h-3.5 text-primary" /> Focus</span>
                <Badge variant="outline" className="text-[10px]">{workMin} min</Badge>
              </div>
              <div className="flex items-center justify-between text-xs py-1.5">
                <span className="flex items-center gap-2"><Coffee className="w-3.5 h-3.5 text-teal-500" /> Short break</span>
                <Badge variant="outline" className="text-[10px]">{shortMin} min</Badge>
              </div>
              <div className="flex items-center justify-between text-xs py-1.5">
                <span className="flex items-center gap-2"><Coffee className="w-3.5 h-3.5 text-lime-500" /> Long break</span>
                <Badge variant="outline" className="text-[10px]">{longMin} min</Badge>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
