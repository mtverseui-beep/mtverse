"use client"

import Link from "next/link"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { LucideIcon } from "lucide-react"
import {
  Timer, CalendarRange, ListChecks, DollarSign, BarChart3,
  Brain, Target, Clock3, FilePlus, CheckCircle2,
} from "lucide-react"

// ============================================================
// TIME ENTRY STATUS BADGE
// ============================================================

export type EntryStatus = "running" | "submitted" | "approved" | "rejected"

export const entryStatusMeta: Record<EntryStatus, { label: string; chip: string; dot: string }> = {
  running: { label: "Running", chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  submitted: { label: "Submitted", chip: "bg-amber-500/15 text-amber-600 dark:text-amber-400", dot: "bg-amber-500" },
  approved: { label: "Approved", chip: "bg-teal-500/15 text-teal-600 dark:text-teal-400", dot: "bg-teal-500" },
  rejected: { label: "Rejected", chip: "bg-rose-500/15 text-rose-600 dark:text-rose-400", dot: "bg-rose-500" },
}

export function EntryStatusBadge({ status, className }: { status: EntryStatus; className?: string }) {
  const c = entryStatusMeta[status]
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full", c.chip, className)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", c.dot, status === "running" && "animate-pulse")} />
      {c.label}
    </span>
  )
}

// ============================================================
// HOURS FORMATTING — from seconds
// ============================================================

export function hoursFromSeconds(seconds: number): number {
  return seconds / 3600
}

export function formatHours(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  if (h === 0) return `${m}m`
  if (m === 0) return `${h}h`
  return `${h}h ${m}m`
}

export function formatHoursDecimal(seconds: number, digits = 1): string {
  return (seconds / 3600).toFixed(digits)
}

export function formatClock(dateStr: string): string {
  return new Date(dateStr).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
}

// ============================================================
// WEEK HELPERS
// ============================================================

export const WEEKDAYS_SHORT = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const
export const WEEKDAYS_LONG = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"] as const

export function getStartOfWeek(date: Date): Date {
  const d = new Date(date)
  d.setHours(0, 0, 0, 0)
  const day = d.getDay() // 0=Sun, 1=Mon
  const diff = (day === 0 ? -6 : 1 - day)
  d.setDate(d.getDate() + diff)
  return d
}

export function addDays(date: Date, days: number): Date {
  const d = new Date(date)
  d.setDate(d.getDate() + days)
  return d
}

export function isSameDate(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
}

export function dayKey(date: Date): string {
  return date.toISOString().slice(0, 10)
}

export function shortDate(date: Date): string {
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
}

// ============================================================
// AVATAR + PROJECT CHIP
// ============================================================

export function MemberAvatar({ name, avatar, size = 28 }: { name: string; avatar: string; size?: number }) {
  return (
    <Avatar style={{ width: size, height: size }} className="ring-2 ring-card">
      <AvatarImage src={avatar} alt={name} />
      <AvatarFallback className="text-[10px]">{name.split(" ").map(w => w[0]).slice(0, 2).join("")}</AvatarFallback>
    </Avatar>
  )
}

export function ProjectChip({ name, color = "bg-emerald-500", className }: { name: string; color?: string; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-[11px] font-medium px-1.5 py-0.5 rounded-md bg-secondary text-secondary-foreground", className)}>
      <span className={cn("w-1.5 h-1.5 rounded-full", color)} />
      {name}
    </span>
  )
}

// ============================================================
// TIME NAV (shared segmented control across /time/* pages)
// ============================================================

export const timeNavMeta: { href: string; label: string; icon: LucideIcon }[] = [
  { href: "/time", label: "Tracker", icon: Timer },
  { href: "/time/timesheets", label: "Timesheets", icon: CalendarRange },
  { href: "/time/entries", label: "Entries", icon: ListChecks },
  { href: "/time/billable", label: "Billable", icon: DollarSign },
  { href: "/time/reports", label: "Reports", icon: BarChart3 },
  { href: "/time/sessions", label: "Sessions", icon: Brain },
  { href: "/time/focus", label: "Focus", icon: Target },
  { href: "/time/pomodoro", label: "Pomodoro", icon: Clock3 },
  { href: "/time/manual", label: "Manual", icon: FilePlus },
  { href: "/time/approvals", label: "Approvals", icon: CheckCircle2 },
]

export function TimeViewNav({ active }: { active: string }) {
  return (
    <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-1 -mx-1 px-1 mb-3">
      {timeNavMeta.map(item => {
        const isActive = item.href === active
        const Icon = item.icon
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap",
              isActive
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary"
            )}
          >
            <Icon className="w-3.5 h-3.5" />
            {item.label}
          </Link>
        )
      })}
    </div>
  )
}

// ============================================================
// CSV EXPORT HELPER
// ============================================================

export function downloadCSV(filename: string, rows: (string | number)[][]) {
  const escape = (v: string | number) => {
    const s = String(v ?? "")
    if (s.includes(",") || s.includes('"') || s.includes("\n")) {
      return `"${s.replace(/"/g, '""')}"`
    }
    return s
  }
  const csv = rows.map(r => r.map(escape).join(",")).join("\n")
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}
