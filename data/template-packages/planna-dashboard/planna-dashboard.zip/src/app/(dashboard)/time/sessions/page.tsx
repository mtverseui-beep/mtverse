"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaHeatmap } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Brain, Clock, Zap, Flame, Calendar, TrendingUp, Target, Award,
} from "lucide-react"
import { timeEntries, projects, currentMember } from "@/lib/data/mock"
import { useMemo } from "react"
import { cn, formatDuration } from "@/lib/utils"
import {
  TimeViewNav, MemberAvatar, ProjectChip, formatHours, formatClock,
} from "../_lib"

interface FocusSession {
  id: string
  start: string
  end: string
  duration: number // seconds
  taskKey?: string
  taskTitle: string
  projectId: string
  projectName: string
  productivity: number // 0-100
  dayLabel: string
  dateLabel: string
}

// Derive focus sessions from time entries (treat longest 8 entries as focus blocks)
function buildSessions(): FocusSession[] {
  const sorted = [...timeEntries]
    .filter(e => e.memberId === currentMember.id || true)
    .sort((a, b) => b.duration - a.duration)
    .slice(0, 12)
    .sort((a, b) => new Date(b.start).getTime() - new Date(a.start).getTime())

  return sorted.map((e, i) => {
    const d = new Date(e.start)
    return {
      id: `fs-${e.id}`,
      start: e.start,
      end: e.end,
      duration: e.duration,
      taskKey: e.taskKey,
      taskTitle: e.description,
      projectId: e.projectId,
      projectName: e.projectName,
      productivity: Math.min(98, 60 + ((i * 7) % 40)),
      dayLabel: d.toLocaleDateString("en-US", { weekday: "short" }),
      dateLabel: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    }
  })
}

// 7 days x 24 hours heatmap of session counts
function buildHeatmap(sessions: FocusSession[]): number[][] {
  const grid: number[][] = Array.from({ length: 7 }, () => Array.from({ length: 24 }, () => 0))
  for (const s of sessions) {
    const d = new Date(s.start)
    let dayIdx = d.getDay() - 1 // Mon=0
    if (dayIdx < 0) dayIdx = 6 // Sun
    const hour = d.getHours()
    grid[dayIdx][hour] = Math.min(4, grid[dayIdx][hour] + 1)
  }
  // Add some baseline noise for visualization
  for (let i = 0; i < 7; i++) {
    for (let h = 9; h < 19; h++) {
      grid[i][h] = Math.max(grid[i][h], Math.floor(Math.random() * 3))
    }
  }
  return grid
}

export default function SessionsPage() {
  const sessions = useMemo(() => buildSessions(), [])
  const heatmap = useMemo(() => buildHeatmap(sessions), [sessions])

  const totalSessions = sessions.length
  const totalSeconds = sessions.reduce((s, e) => s + e.duration, 0)
  const avgSeconds = totalSessions > 0 ? Math.round(totalSeconds / totalSessions) : 0
  const avgProductivity = totalSessions > 0 ? Math.round(sessions.reduce((s, e) => s + e.productivity, 0) / totalSessions) : 0

  // Longest streak (consecutive days with at least 1 session)
  const streak = useMemo(() => {
    const daysWithSessions = new Set(sessions.map(s => new Date(s.start).toDateString()))
    let max = 0, cur = 0
    const today = new Date()
    for (let i = 0; i < 30; i++) {
      const d = new Date(today)
      d.setDate(d.getDate() - i)
      if (daysWithSessions.has(d.toDateString())) {
        cur++
        max = Math.max(max, cur)
      } else {
        cur = 0
      }
    }
    return max
  }, [sessions])

  // Most productive day
  const byDay = useMemo(() => {
    const map = new Map<string, { count: number; seconds: number }>()
    for (const s of sessions) {
      const key = s.dayLabel
      if (!map.has(key)) map.set(key, { count: 0, seconds: 0 })
      const row = map.get(key)!
      row.count++
      row.seconds += s.duration
    }
    let best = { day: "—", count: 0, seconds: 0 }
    for (const [day, v] of map.entries()) {
      if (v.count > best.count) best = { day, ...v }
    }
    return best
  }, [sessions])

  return (
    <DashboardShell
      title="Focus Sessions"
      description="Deep-work blocks, productivity scores, and your most productive patterns."
    >
      <TimeViewNav active="/time/sessions" />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard
          label="Total Sessions"
          value={totalSessions}
          hint="last 14 days"
          icon={Brain}
          trend={{ value: 14, positive: true }}
          iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
        />
        <StatCard
          label="Avg Session"
          value={formatDuration(avgSeconds)}
          hint="per focus block"
          icon={Clock}
          trend={{ value: 6, positive: true }}
          iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400"
        />
        <StatCard
          label="Longest Streak"
          value={`${streak}d`}
          hint="consecutive days"
          icon={Flame}
          trend={{ value: 2, positive: true }}
          iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400"
        />
        <StatCard
          label="Avg Productivity"
          value={`${avgProductivity}%`}
          hint={`best: ${byDay.day}`}
          icon={Zap}
          trend={{ value: 8, positive: true }}
          iconColor="bg-lime-500/15 text-lime-600 dark:text-lime-400"
        />
      </div>

      {/* Heatmap + best day */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Session Heatmap" subtitle="When you focus — by day & hour" className="lg:col-span-2" fullscreen={false}>
          <PlannaHeatmap data={heatmap} />
          <div className="flex items-center justify-end gap-1.5 mt-3 text-[10px] text-muted-foreground">
            <span>Less</span>
            <div className="flex gap-0.5">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: "var(--muted)" }} />
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: "color-mix(in oklch, var(--chart-1) 25%, var(--card))" }} />
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: "color-mix(in oklch, var(--chart-1) 50%, var(--card))" }} />
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: "color-mix(in oklch, var(--chart-1) 75%, var(--card))" }} />
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: "var(--chart-1)" }} />
            </div>
            <span>More</span>
          </div>
        </ChartCard>

        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Most Productive Day</h3>
          </div>
          <div className="text-center py-4">
            <p className="text-5xl font-bold text-primary">{byDay.day}</p>
            <p className="text-xs text-muted-foreground mt-1">{byDay.count} sessions · {formatHours(byDay.seconds)}</p>
          </div>
          <div className="pt-4 border-t border-border space-y-3">
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-muted-foreground">Productivity</span>
                <span className="font-semibold">{avgProductivity}%</span>
              </div>
              <Progress value={avgProductivity} className="h-2" />
            </div>
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-muted-foreground">Streak</span>
                <span className="font-semibold">{streak} / 7 days</span>
              </div>
              <Progress value={(streak / 7) * 100} className="h-2" />
            </div>
          </div>
        </Card>
      </div>

      {/* Sessions list */}
      <Card className="p-4 md:p-5 card-lift">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Focus Blocks</h3>
          </div>
          <Badge variant="outline" className="text-[10px]">{sessions.length} sessions</Badge>
        </div>

        <div className="space-y-2 max-h-[520px] overflow-y-auto scroll-area-thin pr-1">
          {sessions.map(s => {
            const proj = projects.find(p => p.id === s.projectId)
            const productivityColor =
              s.productivity >= 80 ? "bg-emerald-500" :
              s.productivity >= 60 ? "bg-teal-500" :
              s.productivity >= 40 ? "bg-amber-500" : "bg-rose-500"
            return (
              <div key={s.id} className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary/30 transition-colors">
                <div className="flex flex-col items-center justify-center w-12 shrink-0">
                  <span className="text-[10px] font-medium text-muted-foreground">{s.dayLabel}</span>
                  <span className="text-lg font-bold text-foreground">{new Date(s.start).getDate()}</span>
                </div>
                <div className="w-px h-10 bg-border shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{s.taskTitle}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <ProjectChip name={s.projectName} color={proj?.color} />
                    <span className="text-[10px] text-muted-foreground">{formatClock(s.start)}–{formatClock(s.end)}</span>
                  </div>
                </div>
                <div className="hidden sm:flex flex-col items-end gap-1 shrink-0 w-[120px]">
                  <div className="flex items-center gap-1.5">
                    <Zap className="w-3 h-3 text-amber-500" />
                    <span className="text-[11px] font-semibold">{s.productivity}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className={cn("h-full rounded-full transition-all", productivityColor)} style={{ width: `${s.productivity}%` }} />
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-bold text-foreground tabular-nums">{formatDuration(s.duration)}</p>
                  <Badge variant="outline" className="text-[9px] mt-0.5">Focus</Badge>
                </div>
              </div>
            )
          })}
        </div>
      </Card>
    </DashboardShell>
  )
}
