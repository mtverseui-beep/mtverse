"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  ChevronLeft, ChevronRight, Send, CheckCircle2, Clock, CalendarDays, Layers, TrendingUp,
} from "lucide-react"
import { timeEntries, members, currentMember, projects } from "@/lib/data/mock"
import { useMemo, useState } from "react"
import { cn, formatDuration } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import {
  TimeViewNav, WEEKDAYS_SHORT, getStartOfWeek, addDays, dayKey, shortDate,
  formatHours, MemberAvatar, EntryStatusBadge, type EntryStatus,
} from "../_lib"

export default function TimesheetsPage() {
  const { toast } = useToast()
  const [memberId, setMemberId] = useState(currentMember.id)
  const [weekStart, setWeekStart] = useState<Date>(() => getStartOfWeek(new Date()))
  const [status, setStatus] = useState<EntryStatus>("running")

  const member = members.find(m => m.id === memberId) ?? currentMember

  const weekDays = useMemo(
    () => Array.from({ length: 7 }).map((_, i) => addDays(weekStart, i)),
    [weekStart]
  )

  // Filter entries for selected member within the week
  const memberEntries = useMemo(() => {
    const startKey = dayKey(weekStart)
    const endKey = dayKey(addDays(weekStart, 6))
    return timeEntries.filter(e => {
      if (e.memberId !== memberId) return false
      const ek = e.start.slice(0, 10)
      return ek >= startKey && ek <= endKey
    })
  }, [memberId, weekStart])

  // Build a project-keyed map of dayKey -> seconds
  const projectsWithData = useMemo(() => {
    const map = new Map<string, { project: typeof projects[number]; dayTotals: Record<string, number>; total: number }>()
    for (const e of memberEntries) {
      const proj = projects.find(p => p.id === e.projectId)
      if (!proj) continue
      if (!map.has(proj.id)) map.set(proj.id, { project: proj, dayTotals: {}, total: 0 })
      const row = map.get(proj.id)!
      const dk = e.start.slice(0, 10)
      row.dayTotals[dk] = (row.dayTotals[dk] ?? 0) + e.duration
      row.total += e.duration
    }
    return Array.from(map.values()).sort((a, b) => b.total - a.total)
  }, [memberEntries])

  // Per-day totals
  const dayTotals = useMemo(() => {
    const t: Record<string, number> = {}
    for (const p of projectsWithData) {
      for (const dk in p.dayTotals) t[dk] = (t[dk] ?? 0) + p.dayTotals[dk]
    }
    return t
  }, [projectsWithData])

  const weekTotal = Object.values(dayTotals).reduce((s, v) => s + v, 0)
  const weekBillable = memberEntries.filter(e => e.billable).reduce((s, e) => s + e.duration, 0)
  const billablePct = weekTotal > 0 ? Math.round((weekBillable / weekTotal) * 100) : 0
  const todayIdx = weekDays.findIndex(d => dayKey(d) === dayKey(new Date()))

  const isCurrentWeek = dayKey(weekStart) === dayKey(getStartOfWeek(new Date()))
  const submitted = status === "submitted" || status === "approved"

  function shiftWeek(delta: number) {
    setWeekStart(w => addDays(w, delta * 7))
  }

  function submitWeek() {
    setStatus("submitted")
    toast({
      title: "Week submitted",
      description: `${shortDate(weekDays[0])} – ${shortDate(weekDays[6])} (${formatHours(weekTotal)}) sent for approval.`,
    })
  }

  function approveWeek() {
    setStatus("approved")
    toast({
      title: "Week approved",
      description: `Timesheet for ${member.name} approved.`,
    })
  }

  return (
    <DashboardShell
      title="Timesheets"
      description="Review and submit weekly hours by project, organized by day."
      actions={
        <>
          <Select value={memberId} onValueChange={setMemberId}>
            <SelectTrigger className="h-9 w-[180px] text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {members.map(m => (
                <SelectItem key={m.id} value={m.id}>
                  <span className="flex items-center gap-2">
                    <Avatar className="w-5 h-5">
                      <AvatarImage src={m.avatar} alt={m.name} />
                      <AvatarFallback>{m.name[0]}</AvatarFallback>
                    </Avatar>
                    {m.name}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </>
      }
    >
      <TimeViewNav active="/time/timesheets" />

      {/* Week navigation */}
      <Card className="p-4 md:p-5 mb-4 card-lift">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => shiftWeek(-1)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <div className="text-center min-w-[180px]">
              <p className="text-sm font-semibold">
                {shortDate(weekDays[0])} – {shortDate(weekDays[6])}
              </p>
              <p className="text-[11px] text-muted-foreground">
                {isCurrentWeek ? "This week" : ""} · {weekDays[0].toLocaleDateString("en-US", { month: "long", year: "numeric" })}
              </p>
            </div>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => shiftWeek(1)}>
              <ChevronRight className="w-4 h-4" />
            </Button>
            {!isCurrentWeek && (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-xs"
                onClick={() => setWeekStart(getStartOfWeek(new Date()))}
              >
                Today
              </Button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <EntryStatusBadge status={status} />
            {status !== "approved" && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 gap-1.5"
                  onClick={submitWeek}
                  disabled={submitted || weekTotal === 0}
                >
                  <Send className="w-4 h-4" /> {submitted ? "Submitted" : "Submit week"}
                </Button>
                <Button
                  size="sm"
                  className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
                  onClick={approveWeek}
                  disabled={weekTotal === 0}
                >
                  <CheckCircle2 className="w-4 h-4" /> Approve
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Member + week summary strip */}
        <div className="flex items-center gap-3 mt-4 pt-4 border-t border-border">
          <MemberAvatar name={member.name} avatar={member.avatar} size={40} />
          <div className="flex-1">
            <p className="text-sm font-semibold">{member.name}</p>
            <p className="text-[11px] text-muted-foreground">{member.title} · {member.department}</p>
          </div>
          <div className="grid grid-cols-3 gap-4 md:gap-6 text-right">
            <div>
              <p className="text-[10px] text-muted-foreground">Total</p>
              <p className="text-sm font-bold text-foreground">{formatHours(weekTotal)}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground">Billable</p>
              <p className="text-sm font-bold text-foreground">{billablePct}%</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground">Goal</p>
              <p className="text-sm font-bold text-foreground">{Math.round((weekTotal / (40 * 3600)) * 100)}%</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Weekly grid */}
      <Card className="p-4 md:p-5 card-lift overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Weekly Grid</h3>
          </div>
          <span className="text-[11px] text-muted-foreground">{projectsWithData.length} projects · {memberEntries.length} entries</span>
        </div>

        {/* Desktop grid */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left text-[11px] font-medium text-muted-foreground py-2.5 px-2 sticky left-0 bg-card z-10 min-w-[180px]">Project</th>
                {weekDays.map((d, i) => {
                  const isToday = i === todayIdx
                  return (
                    <th key={i} className={cn("px-2 py-2.5 text-center min-w-[80px]", isToday && "text-primary")}>
                      <div className="text-[10px] font-medium uppercase text-muted-foreground">{WEEKDAYS_SHORT[i]}</div>
                      <div className={cn("text-xs font-semibold", isToday ? "text-primary" : "text-foreground")}>{d.getDate()}</div>
                    </th>
                  )
                })}
                <th className="px-2 py-2.5 text-right text-[11px] font-medium text-muted-foreground min-w-[80px]">Total</th>
              </tr>
            </thead>
            <tbody>
              {projectsWithData.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-10 text-sm text-muted-foreground">
                    No time logged for this week.
                  </td>
                </tr>
              ) : (
                projectsWithData.map(({ project, dayTotals: dt, total }) => (
                  <tr key={project.id} className="border-b border-border/60 hover:bg-secondary/30 transition-colors">
                    <td className="py-3 px-2 sticky left-0 bg-card z-10">
                      <div className="flex items-center gap-2">
                        <span className={cn("w-2 h-2 rounded-full shrink-0", project.color)} />
                        <div className="min-w-0">
                          <p className="text-xs font-medium text-foreground truncate">{project.name}</p>
                          <p className="text-[10px] text-muted-foreground">{project.key}</p>
                        </div>
                      </div>
                    </td>
                    {weekDays.map((d, i) => {
                      const v = dt[dayKey(d)] ?? 0
                      const isToday = i === todayIdx
                      return (
                        <td key={i} className="px-2 py-3 text-center">
                          <div
                            className={cn(
                              "inline-flex items-center justify-center min-w-[44px] h-8 rounded-md text-[11px] font-semibold transition-colors",
                              v > 0
                                ? "bg-primary/10 text-primary hover:bg-primary/20"
                                : "text-muted-foreground/40",
                              isToday && "ring-1 ring-primary/30"
                            )}
                          >
                            {v > 0 ? formatHours(v) : "—"}
                          </div>
                        </td>
                      )
                    })}
                    <td className="px-2 py-3 text-right">
                      <span className="text-xs font-bold text-foreground tabular-nums">{formatHours(total)}</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {projectsWithData.length > 0 && (
              <tfoot>
                <tr className="border-t-2 border-border">
                  <td className="py-3 px-2 sticky left-0 bg-card z-10">
                    <span className="text-xs font-bold text-foreground">Daily total</span>
                  </td>
                  {weekDays.map((d, i) => {
                    const v = dayTotals[dayKey(d)] ?? 0
                    const isToday = i === todayIdx
                    return (
                      <td key={i} className="px-2 py-3 text-center">
                        <span className={cn("text-xs font-bold tabular-nums", isToday ? "text-primary" : "text-foreground")}>
                          {v > 0 ? formatHours(v) : "—"}
                        </span>
                      </td>
                    )
                  })}
                  <td className="px-2 py-3 text-right">
                    <span className="text-sm font-bold text-primary tabular-nums">{formatHours(weekTotal)}</span>
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Mobile: stacked by project */}
        <div className="md:hidden space-y-3">
          {projectsWithData.length === 0 ? (
            <p className="text-center py-8 text-sm text-muted-foreground">No time logged for this week.</p>
          ) : (
            projectsWithData.map(({ project, dayTotals: dt, total }) => (
              <div key={project.id} className="border border-border rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={cn("w-2 h-2 rounded-full shrink-0", project.color)} />
                    <p className="text-xs font-medium text-foreground truncate">{project.name}</p>
                  </div>
                  <span className="text-xs font-bold text-foreground">{formatHours(total)}</span>
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {weekDays.map((d, i) => {
                    const v = dt[dayKey(d)] ?? 0
                    return (
                      <div key={i} className="text-center">
                        <p className="text-[9px] text-muted-foreground mb-0.5">{WEEKDAYS_SHORT[i][0]}</p>
                        <div className={cn(
                          "h-7 rounded flex items-center justify-center text-[9px] font-semibold",
                          v > 0 ? "bg-primary/10 text-primary" : "bg-muted/40 text-muted-foreground/40"
                        )}>
                          {v > 0 ? formatHours(v) : "·"}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mt-4">
        <StatCard label="Week Total" value={formatHours(weekTotal)} hint="across projects" icon={Clock} />
        <StatCard label="Billable %" value={`${billablePct}%`} hint={`${formatHours(weekBillable)} billable`} icon={TrendingUp} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Projects" value={projectsWithData.length} hint="distinct this week" icon={Layers} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
        <StatCard label="Entries" value={memberEntries.length} hint="logged this week" icon={CalendarDays} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>
    </DashboardShell>
  )
}
