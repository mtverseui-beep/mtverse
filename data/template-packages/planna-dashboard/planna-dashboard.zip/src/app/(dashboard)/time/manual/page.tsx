"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  FilePlus, Save, Clock, Calendar, Tag, Plus, CheckCircle2, Trash2,
} from "lucide-react"
import { timeEntries, projects, tasks, currentMember } from "@/lib/data/mock"
import { useMemo, useState } from "react"
import { cn, formatDuration } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import {
  TimeViewNav, EntryStatusBadge, MemberAvatar, formatHours, formatClock, type EntryStatus,
} from "../_lib"

interface ManualEntry {
  id: string
  projectName: string
  taskKey: string
  taskTitle: string
  date: string
  start: string
  end: string
  duration: number
  description: string
  billable: boolean
}

function todayStr() {
  return new Date().toISOString().slice(0, 10)
}

function timeStr(date: Date) {
  return date.toTimeString().slice(0, 5)
}

function parseDuration(start: string, end: string): number {
  if (!start || !end) return 0
  const [sh, sm] = start.split(":").map(Number)
  const [eh, em] = end.split(":").map(Number)
  let diff = (eh * 60 + em) - (sh * 60 + sm)
  if (diff < 0) diff += 24 * 60 // overnight
  return diff * 60
}

export default function ManualPage() {
  const { toast } = useToast()
  const [projectId, setProjectId] = useState(projects[0].id)
  const [taskId, setTaskId] = useState<string>("none")
  const [newTaskTitle, setNewTaskTitle] = useState("")
  const [createNewTask, setCreateNewTask] = useState(false)
  const [date, setDate] = useState(todayStr())
  const [start, setStart] = useState("09:00")
  const [end, setEnd] = useState("10:30")
  const [description, setDescription] = useState("")
  const [billable, setBillable] = useState(true)
  const [entries, setEntries] = useState<ManualEntry[]>(() =>
    timeEntries
      .filter(e => e.memberId === currentMember.id)
      .slice(0, 5)
      .map(e => ({
        id: e.id,
        projectName: e.projectName,
        taskKey: e.taskKey ?? "",
        taskTitle: e.taskTitle ?? e.description,
        date: e.start.slice(0, 10),
        start: formatClock(e.start),
        end: formatClock(e.end),
        duration: e.duration,
        description: e.description,
        billable: e.billable,
      }))
  )

  const project = projects.find(p => p.id === projectId) ?? projects[0]
  const projectTasks = useMemo(
    () => tasks.filter(t => t.projectId === projectId),
    [projectId]
  )

  const duration = parseDuration(start, end)
  const isValid = duration > 0 && (createNewTask ? newTaskTitle.trim().length > 0 : taskId !== "none")

  function handleSave() {
    if (!isValid) {
      toast({ title: "Check your inputs", description: "Pick a task and ensure end is after start." })
      return
    }
    const taskKey = createNewTask
      ? `${project.key}-${Math.floor(Math.random() * 900) + 100}`
      : (tasks.find(t => t.id === taskId)?.key ?? "")
    const taskTitle = createNewTask ? newTaskTitle : (tasks.find(t => t.id === taskId)?.title ?? "")
    const entry: ManualEntry = {
      id: `manual-${Date.now()}`,
      projectName: project.name,
      taskKey,
      taskTitle,
      date,
      start,
      end,
      duration,
      description: description || taskTitle,
      billable,
    }
    setEntries(prev => [entry, ...prev])
    toast({
      title: "Entry saved",
      description: `${formatHours(duration)} on ${project.name} for ${date}.`,
    })
    // Reset
    setDescription("")
    setCreateNewTask(false)
    setNewTaskTitle("")
    setTaskId("none")
  }

  function deleteEntry(id: string) {
    setEntries(prev => prev.filter(e => e.id !== id))
    toast({ title: "Entry deleted" })
  }

  return (
    <DashboardShell
      title="Manual Time Entry"
      description="Log time after the fact — pick project, task, and time window."
    >
      <TimeViewNav active="/time/manual" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Form */}
        <Card className="lg:col-span-2 p-4 md:p-6 card-lift">
          <div className="flex items-center gap-2 mb-5">
            <FilePlus className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">New Time Entry</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Project */}
            <div className="space-y-2">
              <Label className="text-xs flex items-center gap-1.5">
                <Tag className="w-3 h-3" /> Project
              </Label>
              <Select value={projectId} onValueChange={(v) => { setProjectId(v); setTaskId("none") }}>
                <SelectTrigger className="h-10 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {projects.map(p => (
                    <SelectItem key={p.id} value={p.id}>
                      <span className="flex items-center gap-1.5">
                        <span className={cn("w-1.5 h-1.5 rounded-full", p.color)} />
                        {p.name}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Task or create new */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Task</Label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <span className="text-[10px] text-muted-foreground">Create new</span>
                  <Switch checked={createNewTask} onCheckedChange={setCreateNewTask} />
                </label>
              </div>
              {createNewTask ? (
                <Input
                  placeholder="New task title…"
                  value={newTaskTitle}
                  onChange={e => setNewTaskTitle(e.target.value)}
                  className="h-10 text-sm"
                />
              ) : (
                <Select value={taskId} onValueChange={setTaskId}>
                  <SelectTrigger className="h-10 text-sm"><SelectValue placeholder="Select task…" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— Select task —</SelectItem>
                    {projectTasks.length === 0 ? (
                      <SelectItem value="none" disabled>No tasks in this project</SelectItem>
                    ) : (
                      projectTasks.map(t => (
                        <SelectItem key={t.id} value={t.id}>
                          {t.key} · {t.title.slice(0, 40)}{t.title.length > 40 ? "…" : ""}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              )}
            </div>

            {/* Date */}
            <div className="space-y-2">
              <Label className="text-xs flex items-center gap-1.5">
                <Calendar className="w-3 h-3" /> Date
              </Label>
              <Input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="h-10 text-sm"
              />
            </div>

            {/* Billable toggle */}
            <div className="space-y-2">
              <Label className="text-xs">Billable</Label>
              <div className="h-10 flex items-center justify-between px-3 rounded-md border border-input bg-transparent">
                <span className="text-xs text-muted-foreground">
                  {billable ? "Billable to client" : "Internal / non-billable"}
                </span>
                <Switch checked={billable} onCheckedChange={setBillable} />
              </div>
            </div>

            {/* Start time */}
            <div className="space-y-2">
              <Label className="text-xs flex items-center gap-1.5">
                <Clock className="w-3 h-3" /> Start time
              </Label>
              <Input
                type="time"
                value={start}
                onChange={e => setStart(e.target.value)}
                className="h-10 text-sm"
              />
            </div>

            {/* End time */}
            <div className="space-y-2">
              <Label className="text-xs flex items-center gap-1.5">
                <Clock className="w-3 h-3" /> End time
              </Label>
              <Input
                type="time"
                value={end}
                onChange={e => setEnd(e.target.value)}
                className="h-10 text-sm"
              />
            </div>
          </div>

          {/* Auto-calc duration banner */}
          <div className="mt-4 flex items-center justify-between p-3 rounded-lg bg-primary/10 border border-primary/20">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              <span className="text-xs font-medium">Duration</span>
            </div>
            <span className="text-sm font-bold text-primary tabular-nums">
              {duration > 0 ? formatHours(duration) : "—"}
            </span>
          </div>

          {/* Description */}
          <div className="mt-4 space-y-2">
            <Label className="text-xs">Description (optional)</Label>
            <Textarea
              placeholder="What did you work on?"
              value={description}
              onChange={e => setDescription(e.target.value)}
              rows={3}
              className="text-sm resize-none"
            />
          </div>

          <div className="mt-5 flex items-center justify-end gap-2">
            <Button
              variant="outline"
              className="h-10 text-sm bg-transparent"
              onClick={() => {
                setDescription("")
                setCreateNewTask(false)
                setNewTaskTitle("")
                setTaskId("none")
                setStart("09:00")
                setEnd("10:30")
              }}
            >
              Reset
            </Button>
            <Button
              className="h-10 text-sm gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={handleSave}
              disabled={!isValid}
            >
              <Save className="w-4 h-4" /> Save entry
            </Button>
          </div>
        </Card>

        {/* Summary side panel */}
        <Card className="p-4 md:p-5 card-lift">
          <h3 className="text-sm font-semibold mb-4">Preview</h3>
          <div className="space-y-3">
            <div className="p-3 rounded-lg bg-secondary/40">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] text-muted-foreground">Project</span>
                <span className={cn("w-2 h-2 rounded-full", project.color)} />
              </div>
              <p className="text-xs font-medium">{project.name}</p>
              <p className="text-[10px] text-muted-foreground">{project.key} · {project.lead}</p>
            </div>
            <div className="p-3 rounded-lg bg-secondary/40">
              <span className="text-[10px] text-muted-foreground">Task</span>
              <p className="text-xs font-medium mt-0.5">
                {createNewTask
                  ? (newTaskTitle || "New task")
                  : (tasks.find(t => t.id === taskId)?.title ?? "Select a task")}
              </p>
              {createNewTask && (
                <Badge variant="outline" className="text-[9px] mt-1 gap-1">
                  <Plus className="w-2.5 h-2.5" /> Will be created
                </Badge>
              )}
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2 rounded-lg bg-secondary/40">
                <p className="text-[9px] text-muted-foreground">Date</p>
                <p className="text-[11px] font-semibold">
                  {new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                </p>
              </div>
              <div className="p-2 rounded-lg bg-secondary/40">
                <p className="text-[9px] text-muted-foreground">Time</p>
                <p className="text-[11px] font-semibold">{start}–{end}</p>
              </div>
              <div className="p-2 rounded-lg bg-primary/10">
                <p className="text-[9px] text-muted-foreground">Hours</p>
                <p className="text-[11px] font-bold text-primary">{duration > 0 ? formatHours(duration) : "—"}</p>
              </div>
            </div>
            <div className="p-3 rounded-lg border border-border">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-muted-foreground">Billable</span>
                <Badge variant="outline" className={cn("text-[10px]", billable ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground")}>
                  {billable ? "Yes" : "No"}
                </Badge>
              </div>
              {billable && duration > 0 && (
                <p className="text-[10px] text-muted-foreground mt-1">
                  Revenue: <span className="font-semibold text-foreground">${Math.round((duration / 3600) * 95)}</span> @ $95/hr
                </p>
              )}
            </div>
          </div>
        </Card>
      </div>

      {/* Recent manual entries */}
      <Card className="p-4 md:p-5 card-lift mt-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Recent Manual Entries</h3>
          </div>
          <Badge variant="outline" className="text-[10px]">{entries.length}</Badge>
        </div>
        {entries.length === 0 ? (
          <div className="text-center py-10">
            <FilePlus className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No manual entries yet. Fill the form above.</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto scroll-area-thin pr-1">
            {entries.map(e => (
              <div key={e.id} className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary/30 transition-colors group">
                <MemberAvatar name={currentMember.name} avatar={currentMember.avatar} size={32} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{e.description || e.taskTitle}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] text-muted-foreground">{e.projectName}</span>
                    {e.taskKey && <span className="text-[10px] text-muted-foreground">· {e.taskKey}</span>}
                    <span className="text-[10px] text-muted-foreground">· {e.date}</span>
                    <span className="text-[10px] text-muted-foreground">· {e.start}–{e.end}</span>
                  </div>
                </div>
                <Badge variant="outline" className={cn("text-[9px]", e.billable ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground")}>
                  {e.billable ? "Billable" : "Non-bill"}
                </Badge>
                <span className="text-xs font-semibold tabular-nums w-16 text-right">{formatHours(e.duration)}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 opacity-0 group-hover:opacity-100 text-rose-600 hover:text-rose-700 hover:bg-rose-500/10"
                  onClick={() => deleteEntry(e.id)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </Card>
    </DashboardShell>
  )
}
