"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaDonutChart, PlannaBarChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  DollarSign, Clock, TrendingUp, Percent, Trophy, ArrowUpRight,
} from "lucide-react"
import { timeEntries, projects } from "@/lib/data/mock"
import { cn, formatDuration } from "@/lib/utils"
import {
  TimeViewNav, EntryStatusBadge, formatHours, MemberAvatar, type EntryStatus,
} from "../_lib"

const HOURLY_RATE = 95

export default function BillablePage() {
  const totalSeconds = timeEntries.reduce((s, e) => s + e.duration, 0)
  const billableSeconds = timeEntries.filter(e => e.billable).reduce((s, e) => s + e.duration, 0)
  const nonBillableSeconds = totalSeconds - billableSeconds
  const billablePct = totalSeconds > 0 ? Math.round((billableSeconds / totalSeconds) * 100) : 0
  const revenue = (billableSeconds / 3600) * HOURLY_RATE

  // Per-project billable (computed once — source data is constant)
  const perProject = (() => {
    const map = new Map<string, { name: string; color: string; billable: number; nonBillable: number; revenue: number }>()
    for (const e of timeEntries) {
      const proj = projects.find(p => p.id === e.projectId)
      if (!proj) continue
      if (!map.has(proj.id)) map.set(proj.id, { name: proj.name, color: proj.color, billable: 0, nonBillable: 0, revenue: 0 })
      const row = map.get(proj.id)!
      if (e.billable) {
        row.billable += e.duration
        row.revenue += (e.duration / 3600) * HOURLY_RATE
      } else {
        row.nonBillable += e.duration
      }
    }
    return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue)
  })()

  const chartData = perProject.slice(0, 6).map(p => ({
    name: p.name.length > 18 ? p.name.slice(0, 16) + "…" : p.name,
    billable: +(p.billable / 3600).toFixed(2),
    nonBillable: +(p.nonBillable / 3600).toFixed(2),
  }))

  const billableEntries = timeEntries.filter(e => e.billable).slice(0, 8)

  return (
    <DashboardShell
      title="Billable Hours"
      description="Revenue, utilization, and per-project billable breakdown."
    >
      <TimeViewNav active="/time/billable" />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard
          label="Total Billable"
          value={formatHours(billableSeconds)}
          hint={`of ${formatHours(totalSeconds)} logged`}
          icon={Clock}
          trend={{ value: 12, positive: true }}
          iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
        />
        <StatCard
          label="Billable %"
          value={`${billablePct}%`}
          hint="utilization rate"
          icon={Percent}
          trend={{ value: 4, positive: true }}
          iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400"
        />
        <StatCard
          label="Revenue"
          value={`$${revenue.toLocaleString("en-US", { maximumFractionDigits: 0 })}`}
          hint={`@ $${HOURLY_RATE}/hr`}
          icon={DollarSign}
          trend={{ value: 18, positive: true }}
          iconColor="bg-lime-500/15 text-lime-600 dark:text-lime-400"
        />
        <StatCard
          label="Avg $ / Entry"
          value={`$${billableEntries.length > 0 ? Math.round(revenue / timeEntries.filter(e => e.billable).length) : 0}`}
          hint="per billable session"
          icon={TrendingUp}
          trend={{ value: 6, positive: true }}
          iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Billable Split" subtitle="Hours distribution" fullscreen={false}>
          <PlannaDonutChart
            data={[
              { name: "Billable", value: +(billableSeconds / 3600).toFixed(2), color: "var(--chart-1)" },
              { name: "Non-billable", value: +(nonBillableSeconds / 3600).toFixed(2), color: "var(--chart-4)" },
            ]}
            centerValue={`${billablePct}%`}
            centerLabel="billable"
            height={240}
          />
        </ChartCard>

        <ChartCard title="Hours by Project" subtitle="Billable vs non-billable" className="lg:col-span-2">
          <PlannaBarChart
            data={chartData}
            xKey="name"
            series={[
              { key: "billable", name: "Billable", color: "var(--chart-1)", stackId: "a" },
              { key: "nonBillable", name: "Non-billable", color: "var(--chart-4)", stackId: "a" },
            ]}
            height={260}
          />
        </ChartCard>
      </div>

      {/* Top billable projects list */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        <Card className="p-4 md:p-5 card-lift lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Top Billable Projects</h3>
            </div>
            <span className="text-[11px] text-muted-foreground">{perProject.length} projects</span>
          </div>

          <div className="space-y-3 max-h-[420px] overflow-y-auto scroll-area-thin pr-1">
            {perProject.slice(0, 8).map((p, i) => {
              const total = p.billable + p.nonBillable
              const pct = total > 0 ? Math.round((p.billable / total) * 100) : 0
              return (
                <div key={p.name} className="p-3 rounded-lg border border-border hover:bg-secondary/30 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[11px] font-bold text-muted-foreground w-4 shrink-0">#{i + 1}</span>
                      <span className={cn("w-2 h-2 rounded-full shrink-0", p.color)} />
                      <p className="text-xs font-medium truncate">{p.name}</p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                        ${p.revenue.toLocaleString("en-US", { maximumFractionDigits: 0 })}
                      </span>
                      <ArrowUpRight className="w-3 h-3 text-emerald-500" />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[11px] mb-2">
                    <div>
                      <p className="text-muted-foreground">Billable</p>
                      <p className="font-semibold text-foreground">{formatHours(p.billable)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Non-bill</p>
                      <p className="font-semibold text-foreground">{formatHours(p.nonBillable)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Util</p>
                      <p className="font-semibold text-foreground">{pct}%</p>
                    </div>
                  </div>
                  <Progress value={pct} className="h-1.5" />
                </div>
              )
            })}
          </div>
        </Card>

        {/* Recent billable entries */}
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Recent Billable</h3>
            </div>
            <Badge variant="outline" className="text-[10px]">{billableEntries.length}</Badge>
          </div>
          <div className="space-y-2 max-h-[420px] overflow-y-auto scroll-area-thin pr-1">
            {billableEntries.map(e => (
              <div key={e.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-secondary/30 transition-colors">
                <MemberAvatar name={e.memberName} avatar={e.memberAvatar} size={28} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{e.description}</p>
                  <p className="text-[10px] text-muted-foreground">{e.projectName}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                    ${Math.round((e.duration / 3600) * HOURLY_RATE)}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{formatDuration(e.duration)}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
