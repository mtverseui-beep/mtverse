"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog"
import {
  Play, Pause, Square, Target, ShieldOff, Volume2, VolumeX,
  CloudRain, Trees, Coffee, Wind, CheckCircle2, Sparkles,
} from "lucide-react"
import { projects, currentMember } from "@/lib/data/mock"
import { useTimerStore, formatTimer, getElapsed } from "@/lib/store/timer-store"
import { useEffect, useMemo, useState } from "react"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { TimeViewNav, formatHours } from "../_lib"

const AMBIENT_SOUNDS = [
  { id: "rain", label: "Rain", icon: CloudRain, color: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
  { id: "forest", label: "Forest", icon: Trees, color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  { id: "cafe", label: "Cafe", icon: Coffee, color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  { id: "whitenoise", label: "White noise", icon: Wind, color: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
] as const

const SESSION_GOAL_SECONDS = 90 * 60 // 90 min

export default function FocusPage() {
  const timer = useTimerStore()
  const { toast } = useToast()
  const [, force] = useState(0)
  const [activeSound, setActiveSound] = useState<string | null>(null)
  const [muted, setMuted] = useState(false)
  const [showSummary, setShowSummary] = useState(false)
  const [sessionLog, setSessionLog] = useState<{ start: string; end: string; duration: number; projectName: string }[]>([])
  const [selectedProject, setSelectedProject] = useState(timer.projectName)

  useEffect(() => {
    if (!timer.running) return
    const i = setInterval(() => force(x => x + 1), 1000)
    return () => clearInterval(i)
  }, [timer.running])

  const elapsed = getElapsed()
  const goalPct = Math.min(100, Math.round((elapsed / SESSION_GOAL_SECONDS) * 100))
  const remaining = Math.max(0, SESSION_GOAL_SECONDS - elapsed)

  const todayTotal = useMemo(
    () => sessionLog.reduce((s, e) => s + e.duration, 0),
    [sessionLog]
  )

  function startSession() {
    useTimerStore.setState({ projectName: selectedProject, billable: true })
    timer.start()
    toast({ title: "Focus session started", description: `${selectedProject} · ${formatHours(SESSION_GOAL_SECONDS)} goal` })
  }

  function endSession() {
    const dur = elapsed
    if (dur < 60) {
      toast({ title: "Session too short", description: "Focus for at least 1 minute to log it." })
      timer.reset()
      return
    }
    setSessionLog(prev => [
      { start: new Date(Date.now() - dur * 1000).toISOString(), end: new Date().toISOString(), duration: dur, projectName: timer.projectName },
      ...prev,
    ])
    timer.reset()
    setShowSummary(true)
  }

  function pauseSession() {
    timer.pause()
    toast({ title: "Paused", description: "Take a breath. Your timer is on hold." })
  }

  return (
    <DashboardShell
      title="Focus Mode"
      description="Block distractions, pick ambient sound, and dive into deep work."
      actions={
        <Badge variant="outline" className="h-9 px-3 text-xs gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-primary" />
          {sessionLog.length} sessions today
        </Badge>
      }
    >
      <TimeViewNav active="/time/focus" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4">
        {/* Big focus timer */}
        <Card className="lg:col-span-2 p-6 md:p-8 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20 card-lift animate-slide-in-up">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Focus Session</h3>
              {timer.running ? (
                <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Active
                </Badge>
              ) : elapsed > 0 ? (
                <Badge variant="outline" className="text-[10px]">Paused</Badge>
              ) : (
                <Badge variant="outline" className="text-[10px]">Ready</Badge>
              )}
            </div>
            <Select value={selectedProject} onValueChange={setSelectedProject}>
              <SelectTrigger className="h-8 w-[200px] text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {projects.map(p => (
                  <SelectItem key={p.id} value={p.name}>
                    <span className="flex items-center gap-1.5">
                      <span className={cn("w-1.5 h-1.5 rounded-full", p.color)} />
                      {p.name}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="text-center py-4">
            <p className="text-7xl md:text-8xl font-bold text-foreground tabular-nums tracking-tighter leading-none">
              {formatTimer(elapsed)}
            </p>
            <p className="text-xs text-muted-foreground mt-3">
              Goal: {formatHours(SESSION_GOAL_SECONDS)} · {goalPct}% complete
              {timer.running && remaining > 0 && ` · ${formatHours(remaining)} left`}
            </p>
          </div>

          <div className="mt-6">
            <Progress value={goalPct} className="h-2.5" />
          </div>

          <div className="mt-8 flex items-center justify-center gap-3">
            {!timer.running ? (
              <Button
                size="lg"
                className="h-14 px-8 gap-2 bg-primary hover:bg-primary/90 text-base"
                onClick={startSession}
                disabled={elapsed > 0}
              >
                <Play className="w-5 h-5" /> Start focus
              </Button>
            ) : (
              <Button
                size="lg"
                variant="outline"
                className="h-14 px-8 gap-2 text-base"
                onClick={pauseSession}
              >
                <Pause className="w-5 h-5" /> Pause
              </Button>
            )}
            {elapsed > 0 && !timer.running && (
              <Button
                size="lg"
                className="h-14 px-8 gap-2 bg-primary hover:bg-primary/90 text-base"
                onClick={() => timer.start()}
              >
                <Play className="w-5 h-5" /> Resume
              </Button>
            )}
            <Button
              size="lg"
              variant="ghost"
              className="h-14 px-6 text-base text-rose-600 hover:text-rose-700 hover:bg-rose-500/10"
              onClick={endSession}
              disabled={elapsed === 0}
            >
              <Square className="w-5 h-5" /> End
            </Button>
          </div>
        </Card>

        {/* Right column: ambient + blocker */}
        <div className="space-y-3 md:space-y-4">
          {/* Ambient sounds */}
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Ambient Sound</h3>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => setMuted(m => !m)}
                title={muted ? "Unmute" : "Mute"}
              >
                {muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {AMBIENT_SOUNDS.map(s => {
                const Icon = s.icon
                const isActive = !muted && activeSound === s.id
                return (
                  <button
                    key={s.id}
                    onClick={() => setActiveSound(prev => prev === s.id ? null : s.id)}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 p-4 rounded-lg border text-xs font-medium transition-all",
                      isActive
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:bg-secondary/40 text-muted-foreground hover:text-foreground"
                    )}
                  >
                    <span className={cn("w-9 h-9 rounded-lg flex items-center justify-center", s.color)}>
                      <Icon className="w-4 h-4" />
                    </span>
                    {s.label}
                  </button>
                )
              })}
            </div>
            {activeSound && !muted && (
              <p className="text-[10px] text-muted-foreground mt-3 text-center animate-fade-in">
                Now playing: {AMBIENT_SOUNDS.find(s => s.id === activeSound)?.label}
              </p>
            )}
          </Card>

          {/* Distraction blocker */}
          <Card className="p-4 md:p-5 card-lift bg-gradient-to-br from-emerald-500/5 to-card border-emerald-500/20">
            <div className="flex items-center gap-2 mb-3">
              <ShieldOff className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <h3 className="text-sm font-semibold">Distraction Blocker</h3>
              <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-[10px] ml-auto">Active</Badge>
            </div>
            <p className="text-[11px] text-muted-foreground mb-3">
              Notifications muted · Slack paused · Email hidden
            </p>
            <div className="space-y-2">
              {["slack.com", "twitter.com", "youtube.com", "news.ycombinator.com"].map(site => (
                <div key={site} className="flex items-center justify-between text-[11px] py-1.5 px-2 rounded bg-secondary/40">
                  <span className="text-muted-foreground">{site}</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-medium">Blocked</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Today total */}
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle2 className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-semibold">Today's Focus</h3>
            </div>
            <div className="text-center py-2">
              <p className="text-3xl font-bold text-foreground">{formatHours(todayTotal)}</p>
              <p className="text-[11px] text-muted-foreground mt-1">{sessionLog.length} sessions completed</p>
            </div>
          </Card>
        </div>
      </div>

      {/* Session log */}
      <Card className="p-4 md:p-5 card-lift mt-4">
        <h3 className="text-sm font-semibold mb-4">Recent Focus Sessions</h3>
        {sessionLog.length === 0 ? (
          <div className="text-center py-10">
            <Target className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No sessions yet. Start your first focus block above.</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto scroll-area-thin pr-1">
            {sessionLog.map((s, i) => (
              <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-secondary/30 transition-colors">
                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center text-[10px] font-bold">
                  #{sessionLog.length - i}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{s.projectName}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {new Date(s.start).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })} –{" "}
                    {new Date(s.end).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
                <span className="text-xs font-semibold tabular-nums">{formatHours(s.duration)}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* End-session summary modal */}
      <Dialog open={showSummary} onOpenChange={setShowSummary}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              Session complete
            </DialogTitle>
            <DialogDescription>
              Nice work. Here's how your focus session went.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border border-border p-4 text-center">
                <p className="text-[10px] text-muted-foreground">Duration</p>
                <p className="text-2xl font-bold text-foreground">
                  {sessionLog[0] ? formatHours(sessionLog[0].duration) : "0m"}
                </p>
              </div>
              <div className="rounded-lg border border-border p-4 text-center">
                <p className="text-[10px] text-muted-foreground">Goal progress</p>
                <p className="text-2xl font-bold text-primary">
                  {sessionLog[0] ? Math.round((sessionLog[0].duration / SESSION_GOAL_SECONDS) * 100) : 0}%
                </p>
              </div>
            </div>
            <div className="rounded-lg border border-border p-3">
              <p className="text-[11px] text-muted-foreground mb-2">Project</p>
              <p className="text-sm font-medium">{sessionLog[0]?.projectName ?? "—"}</p>
            </div>
            <p className="text-xs text-muted-foreground text-center">
              Total focus today: <span className="font-semibold text-foreground">{formatHours(todayTotal)}</span> across {sessionLog.length} sessions.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setShowSummary(false)} className="bg-primary text-primary-foreground hover:bg-primary/90">
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardShell>
  )
}
