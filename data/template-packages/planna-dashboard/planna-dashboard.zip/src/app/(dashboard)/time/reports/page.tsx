"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { ChartCard, PlannaAreaChart, PlannaDonutChart, PlannaBarChart } from "@/components/charts"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Download, Calendar, Clock, DollarSign, TrendingUp, Filter, X,
  FileSpreadsheet,
} from "lucide-react"
import { timeEntries, projects, members, currentMember } from "@/lib/data/mock"
import { useMemo, useState } from "react"
import { cn, formatDuration } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import {
  TimeViewNav, formatHours, MemberAvatar, downloadCSV, getStartOfWeek, addDays, dayKey,
} from "../_lib"

const HOURLY_RATE = 95
const RANGES = [
  { value: "7", label: "Last 7 days" },
  { value: "14", label: "Last 14 days" },
  { value: "30", label: "Last 30 days" },
  { value: "90", label: "Last 90 days" },
]

export default function ReportsPage() {
  const { toast } = useToast()
  const [range, setRange] = useState("14")
  const [projectId, setProjectId] = useState("all")
  const [memberFilter, setMemberFilter] = useState("all")
  const [fromDate, setFromDate] = useState("")
  const [toDate, setToDate] = useState("")

  const filtered = useMemo(() => {
    const days = parseInt(range, 10)
    const cutoff = new Date()
    cutoff.setDate(cutoff.getDate() - days)
    cutoff.setHours(0, 0, 0, 0)
    return timeEntries.filter(e => {
      const d = new Date(e.start)
      if (d < cutoff) return false
      if (projectId !== "all" && e.projectId !== projectId) return false
      if (memberFilter !== "all" && e.memberId !== memberFilter) return false
      const ek = e.start.slice(0, 10)
      if (fromDate && ek < fromDate) return false
      if (toDate && ek > toDate) return false
      return true
    })
  }, [range, projectId, memberFilter, fromDate, toDate])

  const totalSeconds = filtered.reduce((s, e) => s + e.duration, 0)
  const billableSeconds = filtered.filter(e => e.billable).reduce((s, e) => s + e.duration, 0)
  const days = parseInt(range, 10)
  const avgDaily = days > 0 ? totalSeconds / days : 0
  const revenue = (billableSeconds / 3600) * HOURLY_RATE
  const billablePct = totalSeconds > 0 ? Math.round((billableSeconds / totalSeconds) * 100) : 0

  // Daily hours series
  const dailyData = useMemo(() => {
    const today = new Date()
    return Array.from({ length: days }).map((_, i) => {
      const d = new Date(today)
      d.setDate(d.getDate() - (days - 1 - i))
      const dayEntries = filtered.filter(e => {
        const ed = new Date(e.start)
        return ed.getFullYear() === d.getFullYear() && ed.getMonth() === d.getMonth() && ed.getDate() === d.getDate()
      })
      const total = dayEntries.reduce((s, e) => s + e.duration, 0)
      const bill = dayEntries.filter(e => e.billable).reduce((s, e) => s + e.duration, 0)
      return {
        day: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        hours: +(total / 3600).toFixed(2),
        billable: +(bill / 3600).toFixed(2),
      }
    })
  }, [filtered, days])

  // Project distribution
  const projectDist = useMemo(() => {
    const map = new Map<string, { name: string; color: string; seconds: number }>()
    for (const e of filtered) {
      const proj = projects.find(p => p.id === e.projectId)
      if (!proj) continue
      if (!map.has(proj.id)) map.set(proj.id, { name: proj.name, color: proj.color, seconds: 0 })
      map.get(proj.id)!.seconds += e.duration
    }
    return Array.from(map.values())
      .sort((a, b) => b.seconds - a.seconds)
      .slice(0, 6)
      .map(p => ({ name: p.name, value: +(p.seconds / 3600).toFixed(2), color: undefined }))
  }, [filtered])

  // Member comparison
  const memberComparison = useMemo(() => {
    const map = new Map<string, { name: string; total: number; billable: number }>()
    for (const e of filtered) {
      if (!map.has(e.memberId)) map.set(e.memberId, { name: e.memberName, total: 0, billable: 0 })
      const row = map.get(e.memberId)!
      row.total += e.duration
      if (e.billable) row.billable += e.duration
    }
    return Array.from(map.values())
      .sort((a, b) => b.total - a.total)
      .slice(0, 8)
      .map(m => ({
        name: m.name.split(" ")[0],
        total: +(m.total / 3600).toFixed(2),
        billable: +(m.billable / 3600).toFixed(2),
      }))
  }, [filtered])

  function exportCSV() {
    const rows: (string | number)[][] = [
      ["Date", "Member", "Project", "Description", "Start", "End", "Duration (h)", "Billable", "Status", "Revenue ($)"],
      ...filtered.map(e => [
        e.start.slice(0, 10), e.memberName, e.projectName, e.description,
        new Date(e.start).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false }),
        new Date(e.end).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false }),
        (e.duration / 3600).toFixed(2),
        e.billable ? "Yes" : "No",
        e.status,
        e.billable ? ((e.duration / 3600) * HOURLY_RATE).toFixed(2) : "0",
      ]),
    ]
    downloadCSV(`time-report-${range}d.csv`, rows)
    toast({ title: "Report exported", description: `${filtered.length} entries → CSV` })
  }

  const hasFilters = projectId !== "all" || memberFilter !== "all" || fromDate || toDate
  function clearFilters() {
    setProjectId("all"); setMemberFilter("all"); setFromDate(""); setToDate("")
  }

  return (
    <DashboardShell
      title="Time Reports"
      description="Analyze hours across dates, projects, and members. Export anytime."
      actions={
        <Button className="h-9 text-sm gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90" onClick={exportCSV}>
          <Download className="w-4 h-4" /> Export CSV
        </Button>
      }
    >
      <TimeViewNav active="/time/reports" />

      {/* Filter bar */}
      <Card className="p-3 md:p-4 mb-4 card-lift">
        <div className="flex flex-col lg:flex-row lg:items-center gap-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs font-medium">Filters</span>
          </div>
          <div className="flex flex-wrap gap-2 flex-1">
            <Select value={range} onValueChange={setRange}>
              <SelectTrigger className="h-9 w-[140px] text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                {RANGES.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={projectId} onValueChange={setProjectId}>
              <SelectTrigger className="h-9 w-[170px] text-sm"><SelectValue placeholder="Project" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All projects</SelectItem>
                {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={memberFilter} onValueChange={setMemberFilter}>
              <SelectTrigger className="h-9 w-[150px] text-sm"><SelectValue placeholder="Member" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All members</SelectItem>
                {members.map(m => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
              <Input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)} className="h-9 w-[140px] text-xs" />
              <span className="text-[11px] text-muted-foreground">→</span>
              <Input type="date" value={toDate} onChange={e => setToDate(e.target.value)} className="h-9 w-[140px] text-xs" />
            </div>
            {hasFilters && (
              <Button variant="ghost" size="sm" className="h-9 text-xs gap-1" onClick={clearFilters}>
                <X className="w-3 h-3" /> Clear
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard
          label="Total Hours"
          value={formatHours(totalSeconds)}
          hint={`${filtered.length} entries`}
          icon={Clock}
          trend={{ value: 8, positive: true }}
        />
        <StatCard
          label="Billable Hours"
          value={formatHours(billableSeconds)}
          hint={`${billablePct}% of total`}
          icon={DollarSign}
          trend={{ value: 4, positive: true }}
          iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
        />
        <StatCard
          label="Avg Daily"
          value={formatHours(avgDaily)}
          hint={`over ${days} days`}
          icon={TrendingUp}
          trend={{ value: 6, positive: true }}
          iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400"
        />
        <StatCard
          label="Revenue"
          value={`$${revenue.toLocaleString("en-US", { maximumFractionDigits: 0 })}`}
          hint={`@ $${HOURLY_RATE}/hr`}
          icon={FileSpreadsheet}
          trend={{ value: 18, positive: true }}
          iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-4 mb-4">
        <ChartCard title="Daily Hours" subtitle={`Last ${days} days`} className="lg:col-span-2" onExport={exportCSV}>
          <PlannaAreaChart
            data={dailyData}
            xKey="day"
            series={[
              { key: "hours", name: "Total hours" },
              { key: "billable", name: "Billable", color: "var(--chart-2)" },
            ]}
            height={260}
          />
        </ChartCard>
        <ChartCard title="Project Distribution" subtitle="Top 6 by hours" fullscreen={false}>
          {projectDist.length > 0 ? (
            <PlannaDonutChart
              data={projectDist}
              centerValue={`${projectDist.length}`}
              centerLabel="projects"
              height={260}
            />
          ) : (
            <div className="h-[260px] flex items-center justify-center text-xs text-muted-foreground">No data</div>
          )}
        </ChartCard>
      </div>

      <div className="grid grid-cols-1 gap-3 md:gap-4">
        <ChartCard title="Member Comparison" subtitle="Total vs billable hours" onExport={exportCSV}>
          <PlannaBarChart
            data={memberComparison}
            xKey="name"
            series={[
              { key: "total", name: "Total hours", color: "var(--chart-1)" },
              { key: "billable", name: "Billable", color: "var(--chart-2)" },
            ]}
            height={280}
          />
        </ChartCard>
      </div>

      {/* Top entries table */}
      <Card className="p-4 md:p-5 card-lift mt-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Top Entries by Duration</h3>
          <Badge variant="outline" className="text-[10px]">{filtered.length} total</Badge>
        </div>
        <div className="space-y-1.5 max-h-96 overflow-y-auto scroll-area-thin pr-1">
          {filtered
            .slice()
            .sort((a, b) => b.duration - a.duration)
            .slice(0, 10)
            .map(e => (
              <div key={e.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-secondary/30 transition-colors">
                <MemberAvatar name={e.memberName} avatar={e.memberAvatar} size={28} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{e.description}</p>
                  <p className="text-[10px] text-muted-foreground">{e.memberName} · {e.projectName}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs font-semibold tabular-nums">{formatDuration(e.duration)}</p>
                  <Badge variant="outline" className={cn("text-[9px]", e.billable ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground")}>
                    {e.billable ? "Billable" : "Non-bill"}
                  </Badge>
                </div>
              </div>
            ))}
        </div>
      </Card>
    </DashboardShell>
  )
}
