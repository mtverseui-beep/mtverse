"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog"
import {
  CheckCircle2, XCircle, Clock, MessageSquare, Inbox, Check, Filter,
  AlertCircle, CalendarClock, ThumbsUp,
} from "lucide-react"
import { timeEntries, projects, currentMember } from "@/lib/data/mock"
import { useMemo, useState } from "react"
import { cn, formatDate } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import {
  TimeViewNav, EntryStatusBadge, MemberAvatar, formatHours, formatClock, type EntryStatus,
} from "../_lib"

interface ApprovalItem {
  id: string
  memberId: string
  memberName: string
  memberAvatar: string
  projectName: string
  projectColor: string
  taskKey?: string
  description: string
  date: string
  start: string
  end: string
  duration: number
  billable: boolean
  status: EntryStatus
  submittedAt: string
  comment?: string
}

// Seed approvals from timeEntries — submitted + rejected entries
function buildApprovals(): ApprovalItem[] {
  return timeEntries
    .filter(e => e.status === "submitted" || e.status === "rejected")
    .map((e, i) => {
      const proj = projects.find(p => p.id === e.projectId)
      return {
        id: e.id,
        memberId: e.memberId,
        memberName: e.memberName,
        memberAvatar: e.memberAvatar,
        projectName: e.projectName,
        projectColor: proj?.color ?? "bg-emerald-500",
        taskKey: e.taskKey,
        description: e.description,
        date: e.start.slice(0, 10),
        start: e.start,
        end: e.end,
        duration: e.duration,
        billable: e.billable,
        status: e.status as EntryStatus,
        submittedAt: e.start,
      }
    })
}

export default function ApprovalsPage() {
  const { toast } = useToast()
  const [items, setItems] = useState<ApprovalItem[]>(buildApprovals)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [filter, setFilter] = useState<"all" | "submitted" | "rejected">("all")
  const [commenting, setCommenting] = useState<ApprovalItem | null>(null)
  const [comment, setComment] = useState("")
  const [action, setAction] = useState<"approve" | "reject" | null>(null)

  const filtered = useMemo(() => {
    if (filter === "all") return items
    return items.filter(i => i.status === filter)
  }, [items, filter])

  const pending = items.filter(i => i.status === "submitted")
  const approvedThisWeek = items.filter(i => i.status === "approved").length + 8 // seed historical
  const rejectedThisWeek = items.filter(i => i.status === "rejected").length

  function approve(id: string, withComment?: string) {
    setItems(prev => prev.filter(i => i.id !== id))
    setSelected(prev => { const n = new Set(prev); n.delete(id); return n })
    toast({
      title: "Entry approved",
      description: withComment ? `Approved with note: "${withComment.slice(0, 50)}…"` : "Time logged and locked.",
    })
  }

  function reject(id: string, withComment: string) {
    setItems(prev => prev.map(i => i.id === id ? { ...i, status: "rejected" as EntryStatus, comment: withComment } : i))
    setSelected(prev => { const n = new Set(prev); n.delete(id); return n })
    toast({
      title: "Entry rejected",
      description: withComment ? `Sent back with note: "${withComment.slice(0, 50)}…"` : "Returned to owner.",
      variant: "destructive",
    })
  }

  function bulkApprove() {
    const ids = Array.from(selected).filter(id => {
      const item = items.find(i => i.id === id)
      return item && item.status === "submitted"
    })
    if (ids.length === 0) {
      toast({ title: "Nothing to approve", description: "Select submitted entries first." })
      return
    }
    setItems(prev => prev.filter(i => !ids.includes(i.id)))
    toast({ title: `${ids.length} entries approved`, description: "Time logged and locked." })
    setSelected(new Set())
  }

  function openComment(item: ApprovalItem, act: "approve" | "reject") {
    setCommenting(item)
    setAction(act)
    setComment("")
  }

  function submitComment() {
    if (!commenting || !action) return
    if (action === "approve") {
      approve(commenting.id, comment || undefined)
    } else {
      if (!comment.trim()) {
        toast({ title: "Comment required", description: "Please explain why you're rejecting this entry.", variant: "destructive" })
        return
      }
      reject(commenting.id, comment)
    }
    setCommenting(null)
    setComment("")
    setAction(null)
  }

  function toggleOne(id: string) {
    const next = new Set(selected)
    if (next.has(id)) next.delete(id)
    else next.add(id)
    setSelected(next)
  }
  function toggleAll() {
    const eligible = filtered.filter(i => i.status === "submitted")
    const allSelected = eligible.every(i => selected.has(i.id))
    const next = new Set(selected)
    if (allSelected) {
      eligible.forEach(i => next.delete(i.id))
    } else {
      eligible.forEach(i => next.add(i.id))
    }
    setSelected(next)
  }

  const allSelected = filtered.filter(i => i.status === "submitted").every(i => selected.has(i.id)) && filtered.some(i => i.status === "submitted")

  return (
    <DashboardShell
      title="Approval Queue"
      description="Review submitted time entries, approve in bulk, or send back with notes."
      actions={
        <>
          <Button
            variant="outline"
            className="h-9 text-sm gap-1.5 bg-transparent"
            onClick={() => setFilter(f => f === "all" ? "submitted" : "all")}
          >
            <Filter className="w-4 h-4" /> {filter === "all" ? "All" : filter === "submitted" ? "Pending" : "Rejected"}
          </Button>
          <Button
            className="h-9 text-sm gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={bulkApprove}
            disabled={selected.size === 0}
          >
            <Check className="w-4 h-4" /> Approve {selected.size > 0 ? `(${selected.size})` : ""}
          </Button>
        </>
      }
    >
      <TimeViewNav active="/time/approvals" />

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard
          label="Pending Review"
          value={pending.length}
          hint="awaiting your call"
          icon={Inbox}
          iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400"
        />
        <StatCard
          label="Approved This Week"
          value={approvedThisWeek}
          hint="locked & logged"
          icon={ThumbsUp}
          trend={{ value: 12, positive: true }}
          iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
        />
        <StatCard
          label="Rejected This Week"
          value={rejectedThisWeek}
          hint="returned to owners"
          icon={AlertCircle}
          iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400"
        />
        <StatCard
          label="Avg Review Time"
          value="2.3h"
          hint="from submission to decision"
          icon={Clock}
          iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400"
        />
      </div>

      {/* Filter chips */}
      <div className="flex items-center gap-2 mb-3 overflow-x-auto no-scrollbar pb-1">
        {(["all", "submitted", "rejected"] as const).map(f => {
          const count = f === "all" ? items.length : items.filter(i => i.status === f).length
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors",
                filter === f
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-secondary"
              )}
            >
              {f === "all" ? "All" : f === "submitted" ? "Pending" : "Rejected"} ({count})
            </button>
          )
        })}
      </div>

      {/* Approval list */}
      <Card className="card-lift overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState
            icon={CheckCircle2}
            title="All caught up"
            description="No entries match this filter. New submissions will appear here."
            iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
            className="m-4"
          />
        ) : (
          <>
            {/* Header */}
            <div className="hidden md:flex items-center gap-3 px-4 py-3 border-b border-border bg-secondary/40">
              <Checkbox checked={allSelected} onCheckedChange={toggleAll} aria-label="Select all" />
              <span className="text-[11px] font-medium text-muted-foreground flex-1">Entry</span>
              <span className="text-[11px] font-medium text-muted-foreground w-32 text-center">Hours</span>
              <span className="text-[11px] font-medium text-muted-foreground w-24 text-center">Status</span>
              <span className="text-[11px] font-medium text-muted-foreground w-[200px] text-right">Actions</span>
            </div>

            <div className="divide-y divide-border">
              {filtered.map(item => (
                <div
                  key={item.id}
                  className={cn(
                    "flex flex-col md:flex-row md:items-center gap-3 px-4 py-3 transition-colors",
                    item.status === "rejected" ? "bg-rose-500/5" : "hover:bg-secondary/30",
                    selected.has(item.id) && "bg-primary/5"
                  )}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <Checkbox
                      checked={selected.has(item.id)}
                      onCheckedChange={() => toggleOne(item.id)}
                      aria-label={`Select ${item.id}`}
                      disabled={item.status === "rejected"}
                    />
                    <MemberAvatar name={item.memberName} avatar={item.memberAvatar} size={36} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground truncate">{item.description}</p>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
                          <span className={cn("w-1.5 h-1.5 rounded-full", item.projectColor)} />
                          {item.projectName}
                        </span>
                        {item.taskKey && <span className="text-[10px] text-muted-foreground">· {item.taskKey}</span>}
                        <span className="text-[10px] text-muted-foreground">· {item.memberName}</span>
                        <span className="text-[10px] text-muted-foreground">· {formatDate(item.date, { month: "short", day: "numeric" })} {formatClock(item.start)}</span>
                        {item.billable && (
                          <Badge variant="outline" className="text-[9px] text-emerald-600 dark:text-emerald-400">Billable</Badge>
                        )}
                      </div>
                      {item.comment && (
                        <p className="text-[10px] text-rose-600 dark:text-rose-400 mt-1 italic">"{item.comment}"</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between md:justify-center gap-3 md:w-32">
                    <span className="text-[10px] text-muted-foreground md:hidden">Hours</span>
                    <span className="text-sm font-bold tabular-nums">{formatHours(item.duration)}</span>
                  </div>

                  <div className="flex items-center md:justify-center md:w-24">
                    <EntryStatusBadge status={item.status} />
                  </div>

                  <div className="flex items-center gap-2 md:ml-auto md:w-[200px] md:justify-end">
                    {item.status === "submitted" ? (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 text-xs gap-1.5"
                          onClick={() => openComment(item, "reject")}
                        >
                          <XCircle className="w-3.5 h-3.5" /> Reject
                        </Button>
                        <Button
                          size="sm"
                          className="h-8 text-xs gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
                          onClick={() => openComment(item, "approve")}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                        </Button>
                      </>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 text-xs gap-1.5"
                        onClick={() => openComment(item, "approve")}
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> Re-review
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </Card>

      {/* Comment dialog */}
      <Dialog open={!!commenting} onOpenChange={(o) => !o && (setCommenting(null), setComment(""), setAction(null))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {action === "approve" ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              ) : (
                <XCircle className="w-5 h-5 text-rose-500" />
              )}
              {action === "approve" ? "Approve entry" : "Reject entry"}
            </DialogTitle>
            <DialogDescription>
              {commenting && (
                <>
                  <span className="font-medium text-foreground">{commenting.memberName}</span> ·{" "}
                  {commenting.projectName} · {formatHours(commenting.duration)} on{" "}
                  {formatDate(commenting.date, { month: "short", day: "numeric" })}
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 py-2">
            <div className="p-3 rounded-lg bg-secondary/40 text-xs">
              <p className="text-muted-foreground text-[10px] mb-1">Description</p>
              <p>{commenting?.description}</p>
            </div>
            <div>
              <label className="text-xs font-medium mb-1.5 block">
                {action === "approve" ? "Comment (optional)" : "Reason for rejection"}
              </label>
              <Textarea
                placeholder={action === "approve" ? "Add a note for the owner…" : "Explain what needs to change…"}
                value={comment}
                onChange={e => setComment(e.target.value)}
                rows={3}
                className="text-sm resize-none"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => { setCommenting(null); setComment(""); setAction(null) }}>
              Cancel
            </Button>
            <Button
              className={cn(
                action === "approve"
                  ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                  : "bg-rose-600 hover:bg-rose-700 text-white"
              )}
              onClick={submitComment}
            >
              {action === "approve" ? "Approve entry" : "Reject entry"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardShell>
  )
}
