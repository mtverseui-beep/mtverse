"use client"

import { use } from "react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  ChevronLeft, Pencil, Trash2, Calendar, Clock, MapPin, Users, Video, Link2,
  Briefcase, Lightbulb, ArrowRight, ExternalLink,
} from "lucide-react"
import { events, projects, members } from "@/lib/data/mock"
import { cn, formatDate, relativeDay, isSameDay } from "@/lib/utils"
import {
  categoryConfig, formatTime, formatDurationFromMin, eventDurationMinutes,
  attendeeAvatar, attendeeInitials,
} from "../../_lib"

export default function EventDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const event = events.find(e => e.id === id)
  if (!event) notFound()

  const cat = categoryConfig[event.category]
  const project = event.projectId ? projects.find(p => p.id === event.projectId) : undefined
  const dur = eventDurationMinutes(event.start, event.end)
  const start = new Date(event.start)
  const end = new Date(event.end)
  const isMultiDay = !isSameDay(event.start, event.end)

  // Related events: same category or shared attendees, excluding this one, upcoming
  const relatedEvents = events
    .filter(e => e.id !== event.id)
    .filter(e => e.category === event.category || e.attendees.some(a => event.attendees.includes(a)))
    .filter(e => e.start.slice(0, 10) >= new Date().toISOString().slice(0, 10))
    .sort((a, b) => a.start.localeCompare(b.start))
    .slice(0, 4)

  // Suggested times: 3 dummy slots
  const suggestedTimes = [
    { day: "Tomorrow", time: "9:00 AM", available: 4 },
    { day: start.toLocaleDateString("en-US", { weekday: "short" }) === "Fri" ? "Next Mon" : "In 2 days", time: "2:00 PM", available: 3 },
    { day: "Next week", time: "11:00 AM", available: 5 },
  ]

  return (
    <DashboardShell
      title="Event Details"
      description="View and manage this calendar event."
      breadcrumbs={[
        { label: "Calendar", href: "/calendar" },
        { label: event.title },
      ]}
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 text-sm gap-1.5 bg-transparent" asChild>
            <Link href="/calendar"><ChevronLeft className="w-4 h-4" /> Back</Link>
          </Button>
          <Button variant="outline" size="sm" className="h-9 text-sm gap-1.5">
            <Pencil className="w-4 h-4" /> Edit
          </Button>
          <Button variant="destructive" size="sm" className="h-9 text-sm gap-1.5">
            <Trash2 className="w-4 h-4" /> Delete
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-4">
        {/* Main */}
        <div className="space-y-4">
          {/* Title card */}
          <Card className="p-5 md:p-6 card-lift animate-fade-in">
            <div className="flex items-start gap-3 mb-4">
              <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center shrink-0", cat.chip)}>
                <cat.icon className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full", cat.chip)}>
                    {cat.label}
                  </span>
                  {event.allDay && (
                    <Badge variant="secondary" className="text-[10px]">All day</Badge>
                  )}
                  {project && (
                    <Badge variant="outline" className="text-[10px] gap-1">
                      <span className={cn("w-1.5 h-1.5 rounded-full", project.color)} />
                      {project.name}
                    </Badge>
                  )}
                </div>
                <h1 className="text-xl md:text-2xl font-bold text-foreground leading-tight">{event.title}</h1>
              </div>
            </div>

            {event.description && (
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                {event.description}
              </p>
            )}

            {/* Quick facts grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <FactRow icon={Calendar} label="When">
                <span className="font-medium text-foreground">
                  {start.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
                </span>
                <span className="text-xs text-muted-foreground block mt-0.5">{relativeDay(event.start)}</span>
              </FactRow>
              <FactRow icon={Clock} label="Time">
                {event.allDay ? (
                  <span className="font-medium text-foreground">All day</span>
                ) : (
                  <>
                    <span className="font-medium text-foreground tabular-nums">
                      {formatTime(event.start)} – {formatTime(event.end)}
                    </span>
                    <span className="text-xs text-muted-foreground block mt-0.5">{formatDurationFromMin(dur)}</span>
                  </>
                )}
              </FactRow>
              {event.location && (
                <FactRow icon={MapPin} label="Location">
                  <span className="font-medium text-foreground truncate">{event.location}</span>
                  <span className="text-xs text-muted-foreground block mt-0.5">
                    {event.location.toLowerCase().includes("zoom") || event.location.toLowerCase().includes("meet") ? (
                      <span className="inline-flex items-center gap-1 text-primary">
                        <Video className="w-3 h-3" /> Video call
                      </span>
                    ) : "In person"}
                  </span>
                </FactRow>
              )}
              {project && (
                <FactRow icon={Briefcase} label="Project">
                  <Link href={`/projects/${project.id}`} className="font-medium text-primary hover:underline truncate inline-flex items-center gap-1">
                    {project.name}
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                  <span className="text-xs text-muted-foreground block mt-0.5">{project.key} · {project.tasksDone}/{project.tasksTotal} tasks</span>
                </FactRow>
              )}
            </div>

            {/* Video call CTA */}
            {event.location && (event.location.toLowerCase().includes("zoom") || event.location.toLowerCase().includes("meet")) && (
              <div className="mt-4 p-3 rounded-lg bg-primary/5 border border-primary/20 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0">
                  <Video className="w-4 h-4 text-primary shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{event.location}</p>
                    <p className="text-[10px] text-muted-foreground">Join 5 min before start</p>
                  </div>
                </div>
                <Button size="sm" className="h-8 text-xs gap-1.5">
                  <Link2 className="w-3.5 h-3.5" /> Join
                </Button>
              </div>
            )}
          </Card>

          {/* Attendees */}
          <Card className="p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
                <Users className="w-4 h-4 text-primary" /> Attendees
                <span className="text-xs text-muted-foreground font-normal">({event.attendees.length})</span>
              </h3>
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">Add</Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {event.attendees.map(name => {
                const member = members.find(m => m.name === name)
                return (
                  <div key={name} className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-secondary/50 transition-colors">
                    <Avatar className="w-8 h-8">
                      {attendeeAvatar(name) ? (
                        <AvatarImage src={attendeeAvatar(name)} alt={name} />
                      ) : (
                        <AvatarFallback className="text-[10px]">{attendeeInitials(name)}</AvatarFallback>
                      )}
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground truncate">{name}</p>
                      <p className="text-[10px] text-muted-foreground truncate">
                        {member?.title ?? "Guest"}
                      </p>
                    </div>
                    {member?.online && (
                      <span className="w-2 h-2 rounded-full bg-emerald-500" title="Online" />
                    )}
                  </div>
                )
              })}
            </div>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Related events */}
          <Card className="p-4 card-lift">
            <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-1.5">
              <ArrowRight className="w-4 h-4 text-primary" /> Related events
            </h4>
            {relatedEvents.length === 0 ? (
              <p className="text-xs text-muted-foreground py-4 text-center">No related events.</p>
            ) : (
              <div className="space-y-2">
                {relatedEvents.map(e => {
                  const ec = categoryConfig[e.category]
                  return (
                    <Link
                      key={e.id}
                      href={`/calendar/events/${e.id}`}
                      className="flex items-start gap-2.5 p-2 rounded-lg hover:bg-secondary/60 transition-colors group"
                    >
                      <span className={cn("mt-1 w-2 h-2 rounded-full shrink-0", ec.dot)} />
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-foreground truncate group-hover:text-primary transition-colors">{e.title}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">
                          {relativeDay(e.start)} {!e.allDay && `· ${formatTime(e.start)}`}
                        </p>
                      </div>
                    </Link>
                  )
                })}
              </div>
            )}
          </Card>

          {/* Suggested times */}
          <Card className="p-4 card-lift">
            <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-1.5">
              <Lightbulb className="w-4 h-4 text-primary" /> Suggested times
            </h4>
            <div className="space-y-2">
              {suggestedTimes.map((s, i) => (
                <button
                  key={i}
                  className="w-full flex items-center justify-between gap-2 p-2 rounded-lg hover:bg-secondary/60 transition-colors text-left group"
                >
                  <div>
                    <p className="text-xs font-medium text-foreground">{s.day}</p>
                    <p className="text-[10px] text-muted-foreground">{s.time} · {s.available} attendees free</p>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                </button>
              ))}
            </div>
          </Card>

          {/* Timestamps */}
          <Card className="p-4 card-lift">
            <h4 className="text-sm font-semibold text-foreground mb-2">Details</h4>
            <dl className="space-y-1.5 text-xs">
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Starts</dt>
                <dd className="font-medium text-foreground text-right">{formatDate(event.start, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Ends</dt>
                <dd className="font-medium text-foreground text-right">{formatDate(event.end, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Duration</dt>
                <dd className="font-medium text-foreground">{event.allDay ? "All day" : formatDurationFromMin(dur)}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Multi-day</dt>
                <dd className="font-medium text-foreground">{isMultiDay ? "Yes" : "No"}</dd>
              </div>
            </dl>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}

function FactRow({ icon: Icon, label, children }: { icon: typeof Calendar; label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-secondary/40">
      <div className="w-8 h-8 rounded-md bg-card flex items-center justify-center shrink-0">
        <Icon className="w-4 h-4 text-muted-foreground" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-0.5">{label}</p>
        <div className="text-xs">{children}</div>
      </div>
    </div>
  )
}
