"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus, Bell, Clock, CheckCircle2, AlarmClock, Hourglass, X, BellOff, Calendar,
} from "lucide-react"
import { events, tasks } from "@/lib/data/mock"
import { cn, relativeDay } from "@/lib/utils"
import { categoryConfig, dateKey, formatTime } from "../_lib"

interface Reminder {
  id: string
  title: string
  dueAt: string
  source: "task" | "event" | "custom"
  sourceId?: string
  category: "meeting" | "deadline" | "reminder" | "focus" | "personal" | "external"
  snoozedUntil?: string
  dismissed?: boolean
  done?: boolean
}

const today = new Date()

function buildReminders(): Reminder[] {
  const out: Reminder[] = []
  // From events flagged as "reminder"
  for (const e of events) {
    if (e.category === "reminder" || e.category === "deadline") {
      out.push({
        id: `r-e-${e.id}`,
        title: e.title,
        dueAt: e.start,
        source: "event",
        sourceId: e.id,
        category: e.category,
      })
    }
  }
  // From tasks with due dates (today or overdue)
  for (const t of tasks) {
    if (t.dueDate && t.status !== "done") {
      const d = new Date(t.dueDate)
      const diffDays = Math.floor((d.getTime() - today.getTime()) / 86400000)
      if (diffDays <= 3) {
        out.push({
          id: `r-t-${t.id}`,
          title: `Task due: ${t.title}`,
          dueAt: `${t.dueDate}T17:00:00`,
          source: "task",
          sourceId: t.id,
          category: "deadline",
        })
      }
    }
  }
  // Custom reminders (inline seed)
  out.push(
    { id: "r-c-1", title: "Submit weekly timesheet", dueAt: `${dateKey(today)}T17:00:00`, source: "custom", category: "reminder" },
    { id: "r-c-2", title: "Reply to Acme onboarding email", dueAt: `${dateKey(new Date(today.getTime() + 86400000))}T10:00:00`, source: "custom", category: "reminder", snoozedUntil: new Date(today.getTime() + 3600000).toISOString() },
    { id: "r-c-3", title: "Book flights for Q1 offsite", dueAt: `${dateKey(new Date(today.getTime() + 2 * 86400000))}T09:00:00`, source: "custom", category: "personal" },
  )
  return out
}

type Filter = "due" | "upcoming" | "snoozed"

export default function RemindersPage() {
  const [reminders, setReminders] = useState<Reminder[]>(buildReminders)
  const [filter, setFilter] = useState<Filter>("due")
  const [newTitle, setNewTitle] = useState("")
  const [newTime, setNewTime] = useState("17:00")
  const [newWhen, setNewWhen] = useState(dateKey(today))

  const due = reminders.filter(r => !r.done && !r.dismissed && !(r.snoozedUntil && new Date(r.snoozedUntil).getTime() > Date.now()) && new Date(r.dueAt).getTime() <= Date.now() + 86400000)
  const upcoming = reminders.filter(r => !r.done && !r.dismissed && !(r.snoozedUntil && new Date(r.snoozedUntil).getTime() > Date.now()) && new Date(r.dueAt).getTime() > Date.now() + 86400000)
  const snoozed = reminders.filter(r => r.snoozedUntil && new Date(r.snoozedUntil).getTime() > Date.now() && !r.done && !r.dismissed)
  const dismissed = reminders.filter(r => r.dismissed)

  const filtered = filter === "due" ? due : filter === "upcoming" ? upcoming : snoozed

  const counts = { due: due.length, upcoming: upcoming.length, snoozed: snoozed.length }

  const addReminder = () => {
    if (!newTitle.trim()) return
    const r: Reminder = {
      id: `r-c-${Date.now()}`,
      title: newTitle.trim(),
      dueAt: `${newWhen}T${newTime}:00`,
      source: "custom",
      category: "reminder",
    }
    setReminders(prev => [r, ...prev])
    setNewTitle("")
  }

  const snooze1h = (id: string) => {
    setReminders(prev => prev.map(r => r.id === id ? { ...r, snoozedUntil: new Date(Date.now() + 3600000).toISOString() } : r))
  }
  const markDone = (id: string) => {
    setReminders(prev => prev.map(r => r.id === id ? { ...r, done: true } : r))
  }
  const dismiss = (id: string) => {
    setReminders(prev => prev.map(r => r.id === id ? { ...r, dismissed: true } : r))
  }

  return (
    <DashboardShell
      title="Reminders"
      description="Stay on top of what needs your attention — snooze, complete, or dismiss."
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Due Now" value={counts.due} hint="needs action" icon={Bell} iconColor={counts.due > 0 ? "bg-rose-500/15 text-rose-600 dark:text-rose-400" : "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"} />
        <StatCard label="Upcoming" value={counts.upcoming} hint="next 7 days" icon={Clock} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Snoozed" value={counts.snoozed} hint="will return" icon={AlarmClock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Completed" value={reminders.filter(r => r.done).length} hint="all time" icon={CheckCircle2} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Add reminder form */}
      <Card className="p-4 mb-4 card-lift">
        <div className="flex items-center gap-2 mb-3">
          <Plus className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Add a reminder</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_auto_auto] gap-2">
          <Input
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
            onKeyDown={e => e.key === "Enter" && addReminder()}
            placeholder="What do you need to remember?"
            className="h-9"
          />
          <Input type="date" value={newWhen} onChange={e => setNewWhen(e.target.value)} className="h-9 sm:w-40" />
          <Input type="time" value={newTime} onChange={e => setNewTime(e.target.value)} className="h-9 sm:w-32" />
          <Button onClick={addReminder} disabled={!newTitle.trim()} className="h-9 text-sm gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
            <Plus className="w-4 h-4" /> Add
          </Button>
        </div>
      </Card>

      {/* Filter tabs */}
      <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)} className="mb-4">
        <TabsList className="h-9 flex-wrap">
          <TabsTrigger value="due" className="text-xs gap-1.5">
            <Bell className="w-3.5 h-3.5" /> Due <span className="text-[10px] text-muted-foreground">{counts.due}</span>
          </TabsTrigger>
          <TabsTrigger value="upcoming" className="text-xs gap-1.5">
            <Clock className="w-3.5 h-3.5" /> Upcoming <span className="text-[10px] text-muted-foreground">{counts.upcoming}</span>
          </TabsTrigger>
          <TabsTrigger value="snoozed" className="text-xs gap-1.5">
            <AlarmClock className="w-3.5 h-3.5" /> Snoozed <span className="text-[10px] text-muted-foreground">{counts.snoozed}</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Reminders list */}
      <div className="space-y-2">
        {filtered.length === 0 && (
          <Card className="p-12 text-center border-dashed">
            {filter === "due" ? <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500/60 mb-3" /> : <BellOff className="w-10 h-10 mx-auto text-muted-foreground/60 mb-3" />}
            <p className="text-sm font-medium text-foreground">
              {filter === "due" ? "All caught up!" : `No ${filter} reminders`}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {filter === "due" ? "Nothing needs your attention right now." : filter === "snoozed" ? "Snoozed reminders will reappear later." : "No upcoming reminders scheduled."}
            </p>
          </Card>
        )}

        {filtered.map((r, idx) => {
          const cat = categoryConfig[r.category]
          const dueDate = new Date(r.dueAt)
          const overdue = new Date(r.dueAt).getTime() < Date.now()
          const snoozedActive = r.snoozedUntil && new Date(r.snoozedUntil).getTime() > Date.now()
          return (
            <Card
              key={r.id}
              className={cn(
                "p-3 md:p-4 card-lift animate-slide-in-up",
                overdue && !snoozedActive && "border-rose-500/30 bg-rose-500/5"
              )}
              style={{ animationDelay: `${idx * 30}ms` }}
            >
              <div className="flex items-start gap-3">
                {/* Icon */}
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center shrink-0", cat.chip)}>
                  {snoozedActive ? <AlarmClock className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <h4 className="text-sm font-medium text-foreground">{r.title}</h4>
                    <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded shrink-0",
                      snoozedActive ? "bg-amber-500/15 text-amber-700 dark:text-amber-400" :
                      overdue ? "bg-rose-500/15 text-rose-700 dark:text-rose-400" :
                      "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
                    )}>
                      {snoozedActive ? "Snoozed" : overdue ? "Overdue" : "Due"}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-1 text-[11px] text-muted-foreground flex-wrap">
                    <span className="inline-flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {dueDate.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </span>
                    <span>·</span>
                    <span className="inline-flex items-center gap-1 tabular-nums">
                      <Clock className="w-3 h-3" /> {formatTime(r.dueAt)}
                    </span>
                    <span>·</span>
                    <span>{relativeDay(r.dueAt)}</span>
                    {snoozedActive && (
                      <>
                        <span>·</span>
                        <span className="text-amber-700 dark:text-amber-400 font-medium">
                          Until {new Date(r.snoozedUntil!).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
                        </span>
                      </>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 shrink-0">
                  {!snoozedActive && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 text-xs gap-1 bg-transparent"
                      onClick={() => snooze1h(r.id)}
                    >
                      <Hourglass className="w-3 h-3" /> Snooze 1h
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs gap-1 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-500/10"
                    onClick={() => markDone(r.id)}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" /> Done
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-muted-foreground hover:text-destructive"
                    onClick={() => dismiss(r.id)}
                    aria-label="Dismiss"
                  >
                    <X className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            </Card>
          )
        })}
      </div>

      {/* Dismissed footer */}
      {dismissed.length > 0 && (
        <Card className="p-3 mt-4 bg-secondary/30">
          <p className="text-xs text-muted-foreground text-center">
            <BellOff className="w-3.5 h-3.5 inline mr-1.5" />
            {dismissed.length} dismissed reminder{dismissed.length !== 1 ? "s" : ""} hidden.
          </p>
        </Card>
      )}
    </DashboardShell>
  )
}
