"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { ChevronLeft, ChevronRight, Plus, Clock, MapPin, Users, ListChecks, Calendar as CalendarIcon } from "lucide-react"
import { events, tasks } from "@/lib/data/mock"
import { cn, isSameDay, isOverdue, relativeDay } from "@/lib/utils"
import { PriorityBadge } from "@/components/common/badges"
import {
  categoryConfig, dateKey, eventOnDate, formatHour, formatTime, formatDurationFromMin, eventDurationMinutes,
  CalendarViewNav, attendeeAvatar, attendeeInitials,
} from "../_lib"
import type { CalendarEvent } from "@/types"

const START_HOUR = 6
const END_HOUR = 22
const HOUR_HEIGHT = 64
const today = new Date()

export default function CalendarDayPage() {
  const [cursor, setCursor] = useState(new Date(today))
  const now = new Date()
  const nowMinutes = now.getHours() * 60 + now.getMinutes()
  const isToday = isSameDay(dateKey(cursor), dateKey(today))

  const dayEvents = events
    .filter(e => eventOnDate(e, cursor))
    .sort((a, b) => a.start.localeCompare(b.start))

  const timedEvents = dayEvents.filter(e => !e.allDay)
  const allDayEvents = dayEvents.filter(e => e.allDay)

  const tasksDueToday = tasks.filter(t =>
    t.dueDate && isSameDay(t.dueDate, dateKey(cursor)) && t.status !== "done"
  )

  const totalMeetingMinutes = timedEvents
    .filter(e => e.category === "meeting")
    .reduce((s, e) => s + eventDurationMinutes(e.start, e.end), 0)

  return (
    <DashboardShell
      title="Day View"
      description="Focus on a single day with timed events and tasks due."
      actions={
        <>
          <CalendarViewNav active="/calendar/day" />
          <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Link href="/calendar/create-event"><Plus className="w-4 h-4" /> New event</Link>
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Events Today" value={dayEvents.length} hint={relativeDay(dateKey(cursor))} icon={CalendarIcon} />
        <StatCard label="Meeting Time" value={formatDurationFromMin(totalMeetingMinutes)} hint="in meetings" icon={Clock} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Attendees" value={new Set(dayEvents.flatMap(e => e.attendees)).size} hint="unique people" icon={Users} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Tasks Due" value={tasksDueToday.length} hint="today" icon={ListChecks} iconColor={tasksDueToday.length > 0 ? "bg-amber-500/15 text-amber-600 dark:text-amber-400" : "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-4">
        {/* Day timeline */}
        <Card className="p-3 md:p-5 card-lift">
          {/* Header */}
          <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
            <div>
              <h3 className="text-base md:text-lg font-semibold text-foreground">
                {cursor.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {dayEvents.length} event{dayEvents.length !== 1 ? "s" : ""} · {relativeDay(dateKey(cursor))}
              </p>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setCursor(new Date(today))}>Today</Button>
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() - 1))} aria-label="Previous day">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() + 1))} aria-label="Next day">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* All-day strip */}
          {allDayEvents.length > 0 && (
            <div className="mb-3 space-y-1">
              {allDayEvents.map(e => {
                const cat = categoryConfig[e.category]
                return (
                  <Link
                    key={e.id}
                    href={`/calendar/events/${e.id}`}
                    className={cn("flex items-center gap-2 text-xs font-medium px-3 py-1.5 rounded-md", cat.chip)}
                  >
                    <cat.icon className="w-3.5 h-3.5" />
                    <span className="truncate">{e.title}</span>
                    <span className="ml-auto text-[10px] opacity-70">all day</span>
                  </Link>
                )
              })}
            </div>
          )}

          {/* Timeline */}
          <div className="relative" style={{ height: (END_HOUR - START_HOUR + 1) * HOUR_HEIGHT }}>
            {/* Hour grid */}
            {Array.from({ length: END_HOUR - START_HOUR + 1 }).map((_, i) => {
              const h = START_HOUR + i
              return (
                <div key={h} className="absolute left-0 right-0 flex" style={{ top: i * HOUR_HEIGHT, height: HOUR_HEIGHT }}>
                  <div className="w-14 shrink-0 pr-2 text-right">
                    <span className="text-[10px] font-medium text-muted-foreground tabular-nums">{formatHour(h)}</span>
                  </div>
                  <Link
                    href="/calendar/create-event"
                    className="flex-1 border-t border-border/60 hover:bg-primary/5 transition-colors"
                    aria-label={`Add event at ${formatHour(h)}`}
                  />
                </div>
              )
            })}

            {/* Now indicator */}
            {isToday && nowMinutes >= START_HOUR * 60 && nowMinutes <= (END_HOUR + 1) * 60 && (
              <div
                className="absolute left-14 right-0 z-20 pointer-events-none"
                style={{ top: ((nowMinutes - START_HOUR * 60) / 60) * HOUR_HEIGHT }}
              >
                <div className="flex items-center">
                  <span className="text-[9px] font-semibold text-rose-600 dark:text-rose-400 -ml-12 w-12 text-right tabular-nums">
                    {now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
                  </span>
                  <span className="w-2 h-2 rounded-full bg-rose-500 ml-1" />
                  <div className="flex-1 h-px bg-rose-500" />
                </div>
              </div>
            )}

            {/* Event blocks */}
            {timedEvents.map(e => (
              <DayEventBlock key={e.id} event={e} />
            ))}
          </div>
        </Card>

        {/* Side: agenda + tasks due */}
        <div className="space-y-4">
          <Card className="p-4 card-lift">
            <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-primary" /> Day&apos;s Agenda
            </h4>
            {dayEvents.length === 0 ? (
              <p className="text-xs text-muted-foreground py-6 text-center">No events scheduled.</p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {dayEvents.map(e => {
                  const cat = categoryConfig[e.category]
                  return (
                    <Link
                      key={e.id}
                      href={`/calendar/events/${e.id}`}
                      className="flex items-start gap-2.5 p-2 rounded-lg hover:bg-secondary/60 transition-colors group"
                    >
                      <span className={cn("mt-1 w-2 h-2 rounded-full shrink-0", cat.dot)} />
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-foreground truncate group-hover:text-primary transition-colors">{e.title}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">
                          {e.allDay ? "All day" : `${formatTime(e.start)} – ${formatTime(e.end)}`}
                        </p>
                      </div>
                    </Link>
                  )
                })}
              </div>
            )}
          </Card>

          <Card className="p-4 card-lift">
            <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-1.5">
              <ListChecks className="w-4 h-4 text-primary" /> Tasks Due
            </h4>
            {tasksDueToday.length === 0 ? (
              <p className="text-xs text-muted-foreground py-6 text-center">No tasks due today.</p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {tasksDueToday.map(t => (
                  <Link
                    key={t.id}
                    href={`/tasks/${t.id}`}
                    className="flex items-start gap-2.5 p-2 rounded-lg hover:bg-secondary/60 transition-colors"
                  >
                    <span className={cn("mt-0.5 w-2.5 h-2.5 rounded-sm shrink-0", t.projectColor)} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground truncate">{t.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] text-muted-foreground">{t.key}</span>
                        <PriorityBadge priority={t.priority} />
                        {isOverdue(t.dueDate) && (
                          <span className="text-[10px] text-rose-600 dark:text-rose-400 font-medium">overdue</span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}

// ============================================================
// DAY EVENT BLOCK
// ============================================================
function DayEventBlock({ event }: { event: CalendarEvent }) {
  const cat = categoryConfig[event.category]
  const start = new Date(event.start)
  const end = new Date(event.end)
  const startMins = start.getHours() * 60 + start.getMinutes()
  const endMins = end.getHours() * 60 + end.getMinutes()
  const clampStart = Math.max(startMins, START_HOUR * 60)
  const clampEnd = Math.min(endMins, (END_HOUR + 1) * 60)
  if (clampEnd <= clampStart) return null
  const top = ((clampStart - START_HOUR * 60) / 60) * HOUR_HEIGHT
  const height = Math.max(28, ((clampEnd - clampStart) / 60) * HOUR_HEIGHT - 2)
  return (
    <Link
      href={`/calendar/events/${event.id}`}
      className="absolute left-16 right-1 rounded-lg overflow-hidden z-5 group transition-all hover:z-10 hover:shadow-md bg-primary/5 hover:bg-primary/10"
      style={{ top, height }}
    >
      <div className={cn("absolute left-0 top-0 bottom-0 w-1.5", cat.dot)} />
      <div className="pl-3 pr-2 py-1.5 h-full">
        <div className="flex items-start justify-between gap-1">
          <p className="text-xs font-semibold text-foreground truncate leading-tight">{event.title}</p>
          <span className={cn("shrink-0 inline-flex items-center text-[9px] font-semibold px-1.5 py-0.5 rounded", cat.chip)}>
            {cat.label}
          </span>
        </div>
        {height > 44 && (
          <p className="text-[10px] text-muted-foreground mt-0.5 leading-tight">
            {formatTime(event.start)} – {formatTime(event.end)}
          </p>
        )}
        {height > 60 && event.location && (
          <p className="text-[10px] text-muted-foreground mt-0.5 truncate inline-flex items-center gap-0.5">
            <MapPin className="w-2.5 h-2.5" /> {event.location}
          </p>
        )}
        {height > 80 && event.attendees.length > 0 && (
          <div className="flex items-center mt-1">
            <div className="flex -space-x-1.5">
              {event.attendees.slice(0, 4).map((name, i) => (
                <Avatar key={i} className="w-5 h-5 border-2 border-card">
                  {attendeeAvatar(name) ? (
                    <AvatarImage src={attendeeAvatar(name)} alt={name} />
                  ) : (
                    <AvatarFallback className="text-[8px]">{attendeeInitials(name)}</AvatarFallback>
                  )}
                </Avatar>
              ))}
            </div>
            {event.attendees.length > 4 && (
              <span className="text-[9px] text-muted-foreground ml-1.5">+{event.attendees.length - 4}</span>
            )}
          </div>
        )}
      </div>
    </Link>
  )
}
