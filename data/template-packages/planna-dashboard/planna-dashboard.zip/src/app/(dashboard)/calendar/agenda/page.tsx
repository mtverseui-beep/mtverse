"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Plus, List, Clock, MapPin, Users, ChevronDown, CalendarClock, Filter } from "lucide-react"
import { events } from "@/lib/data/mock"
import { cn, isSameDay, relativeDay } from "@/lib/utils"
import {
  categoryConfig, dateKey, formatTime, formatDurationFromMin, eventDurationMinutes,
  CalendarViewNav, attendeeAvatar, attendeeInitials,
} from "../_lib"
import type { EventCategory } from "@/types"
import type { LucideIcon } from "lucide-react"

const today = new Date()
const PAGE_SIZE = 10

const filterTabs: { value: "all" | EventCategory; label: string; icon: LucideIcon }[] = [
  { value: "all", label: "All", icon: List },
  { value: "meeting", label: "Meetings", icon: Users },
  { value: "deadline", label: "Deadlines", icon: CalendarClock },
  { value: "focus", label: "Focus", icon: Clock },
  { value: "reminder", label: "Reminders", icon: Clock },
  { value: "personal", label: "Personal", icon: Users },
  { value: "external", label: "External", icon: Users },
]

export default function CalendarAgendaPage() {
  const [filter, setFilter] = useState<"all" | EventCategory>("all")
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE)

  const upcoming = useMemo(() => {
    const tKey = dateKey(today)
    return [...events]
      .filter(e => e.start.slice(0, 10) >= tKey)
      .filter(e => filter === "all" || e.category === filter)
      .sort((a, b) => a.start.localeCompare(b.start))
  }, [filter])

  // Group by date
  const grouped = useMemo(() => {
    const map = new Map<string, typeof upcoming>()
    for (const e of upcoming) {
      const k = e.start.slice(0, 10)
      if (!map.has(k)) map.set(k, [])
      map.get(k)!.push(e)
    }
    return Array.from(map.entries()).map(([key, items]) => ({ key, items }))
  }, [upcoming])

  const visible = grouped.slice(0, visibleCount)
  const totalEvents = upcoming.length

  // Stats
  const todayEvents = upcoming.filter(e => isSameDay(e.start, dateKey(today)))
  const weekAhead = upcoming.filter(e => {
    const d = new Date(e.start)
    const diff = (d.getTime() - today.getTime()) / 86400000
    return diff >= 0 && diff <= 7
  })
  const meetingCount = upcoming.filter(e => e.category === "meeting").length

  return (
    <DashboardShell
      title="Agenda"
      description="A chronological list of everything coming up."
      actions={
        <>
          <CalendarViewNav active="/calendar/agenda" />
          <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Link href="/calendar/create-event"><Plus className="w-4 h-4" /> New event</Link>
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Today" value={todayEvents.length} hint="scheduled" icon={CalendarClock} />
        <StatCard label="This Week" value={weekAhead.length} hint="next 7 days" icon={Clock} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Meetings" value={meetingCount} hint="upcoming" icon={Users} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Total Upcoming" value={totalEvents} hint="all categories" icon={List} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto no-scrollbar pb-1">
        {filterTabs.map(t => {
          const Icon = t.icon
          const isActive = filter === t.value
          const count = t.value === "all" ? totalEvents : upcoming.filter(e => e.category === t.value).length
          return (
            <button
              key={t.value}
              onClick={() => { setFilter(t.value); setVisibleCount(PAGE_SIZE) }}
              className={cn(
                "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors whitespace-nowrap",
                isActive
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-muted-foreground border-border hover:text-foreground hover:border-primary/30"
              )}
            >
              <Icon className="w-3.5 h-3.5" />
              {t.label}
              <span className={cn(
                "text-[10px] tabular-nums px-1.5 py-0.5 rounded-full",
                isActive ? "bg-primary-foreground/20" : "bg-secondary"
              )}>{count}</span>
            </button>
          )
        })}
      </div>

      {/* Grouped agenda */}
      <div className="space-y-4">
        {grouped.length === 0 && (
          <Card className="p-12 text-center border-dashed">
            <Filter className="w-10 h-10 mx-auto text-muted-foreground/60 mb-3" />
            <p className="text-sm font-medium text-foreground">Nothing scheduled</p>
            <p className="text-xs text-muted-foreground mt-1">No upcoming events match this filter.</p>
          </Card>
        )}

        {visible.map((group, gIdx) => (
          <div key={group.key} className="animate-slide-in-up" style={{ animationDelay: `${gIdx * 40}ms` }}>
            {/* Date header */}
            <div className="flex items-center gap-3 mb-2 px-1">
              <div className="flex items-baseline gap-2">
                <span className="text-lg font-bold text-foreground tabular-nums">
                  {new Date(group.key).getDate()}
                </span>
                <span className="text-xs text-muted-foreground">
                  {new Date(group.key).toLocaleDateString("en-US", { weekday: "long", month: "short" })}
                </span>
              </div>
              <div className="flex-1 border-t border-dashed border-border" />
              <span className="text-[10px] font-medium text-muted-foreground">
                {relativeDay(group.key)} · {group.items.length} event{group.items.length !== 1 ? "s" : ""}
              </span>
            </div>

            <Card className="overflow-hidden card-lift">
              <div className="divide-y divide-border">
                {group.items.map(e => {
                  const cat = categoryConfig[e.category]
                  const dur = eventDurationMinutes(e.start, e.end)
                  return (
                    <Link
                      key={e.id}
                      href={`/calendar/events/${e.id}`}
                      className="flex items-start gap-3 p-3 md:p-4 hover:bg-secondary/40 transition-colors group"
                    >
                      {/* Time column */}
                      <div className="w-16 shrink-0 text-right">
                        <p className="text-xs font-semibold text-foreground tabular-nums">
                          {e.allDay ? "All day" : formatTime(e.start)}
                        </p>
                        {!e.allDay && (
                          <p className="text-[10px] text-muted-foreground tabular-nums mt-0.5">
                            {formatTime(e.end)}
                          </p>
                        )}
                      </div>

                      {/* Color bar */}
                      <span className={cn("w-1 self-stretch rounded-full shrink-0", cat.dot)} />

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <h4 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                            {e.title}
                          </h4>
                          <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0", cat.chip)}>
                            <cat.icon className="w-3 h-3" />
                            {cat.label}
                          </span>
                        </div>
                        {e.description && (
                          <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{e.description}</p>
                        )}
                        <div className="flex items-center gap-3 mt-2 flex-wrap">
                          {!e.allDay && dur > 0 && (
                            <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
                              <Clock className="w-3 h-3" /> {formatDurationFromMin(dur)}
                            </span>
                          )}
                          {e.location && (
                            <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground truncate">
                              <MapPin className="w-3 h-3" /> <span className="truncate max-w-[140px]">{e.location}</span>
                            </span>
                          )}
                          {e.attendees.length > 0 && (
                            <div className="flex items-center gap-1">
                              <div className="flex -space-x-1.5">
                                {e.attendees.slice(0, 3).map((name, i) => (
                                  <Avatar key={i} className="w-5 h-5 border-2 border-card">
                                    {attendeeAvatar(name) ? (
                                      <AvatarImage src={attendeeAvatar(name)} alt={name} />
                                    ) : (
                                      <AvatarFallback className="text-[8px]">{attendeeInitials(name)}</AvatarFallback>
                                    )}
                                  </Avatar>
                                ))}
                              </div>
                              {e.attendees.length > 3 && (
                                <span className="text-[10px] text-muted-foreground">+{e.attendees.length - 3}</span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </Link>
                  )
                })}
              </div>
            </Card>
          </div>
        ))}
      </div>

      {/* Load more */}
      {visible.length < grouped.length && (
        <div className="mt-4 flex justify-center">
          <Button
            variant="outline"
            className="h-9 text-sm gap-1.5 bg-transparent"
            onClick={() => setVisibleCount(c => c + PAGE_SIZE)}
          >
            Load more
            <ChevronDown className="w-4 h-4" />
            <span className="text-[10px] text-muted-foreground">
              ({grouped.length - visible.length} day{grouped.length - visible.length !== 1 ? "s" : ""} left)
            </span>
          </Button>
        </div>
      )}
    </DashboardShell>
  )
}
