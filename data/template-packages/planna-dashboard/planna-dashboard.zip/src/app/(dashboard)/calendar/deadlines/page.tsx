"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Flag, CalendarClock, AlertTriangle, CheckCircle2, ListTodo, Milestone as MilestoneIcon,
  ArrowRight, Calendar, Filter,
} from "lucide-react"
import { tasks, milestones, projects } from "@/lib/data/mock"
import { cn, formatDate, relativeDay } from "@/lib/utils"
import { PriorityBadge } from "@/components/common/badges"
import type { Priority } from "@/types"

interface DeadlineRow {
  id: string
  title: string
  kind: "task" | "milestone"
  projectName: string
  projectColor: string
  projectId: string
  dueDate: string
  priority: Priority | "none"
  progress?: number
  status?: "planned" | "in_progress" | "done" | "overdue" | "todo" | "review" | "blocked" | "backlog"
  assignee?: string
  assigneeAvatar?: string
  taskKey?: string
}

const today = new Date()

function buildDeadlines(): DeadlineRow[] {
  const rows: DeadlineRow[] = []
  for (const t of tasks) {
    if (!t.dueDate) continue
    rows.push({
      id: t.id,
      title: t.title,
      kind: "task",
      projectName: t.projectName,
      projectColor: t.projectColor,
      projectId: t.projectId,
      dueDate: t.dueDate,
      priority: t.priority,
      assignee: t.assignee,
      assigneeAvatar: t.assigneeAvatar,
      taskKey: t.key,
      status: t.status,
    })
  }
  for (const m of milestones) {
    rows.push({
      id: m.id,
      title: m.title,
      kind: "milestone",
      projectName: m.projectName,
      projectColor: projects.find(p => p.id === m.projectId)?.color ?? "bg-primary",
      projectId: m.projectId,
      dueDate: m.dueDate,
      priority: "none",
      progress: m.progress,
      status: m.status,
    })
  }
  return rows
}

function daysRemaining(dueDate: string): number {
  const d = new Date(dueDate)
  d.setHours(0, 0, 0, 0)
  const t = new Date(today)
  t.setHours(0, 0, 0, 0)
  return Math.round((d.getTime() - t.getTime()) / 86400000)
}

function urgency(row: DeadlineRow): "overdue" | "critical" | "soon" | "upcoming" | "done" {
  if (row.status === "done") return "done"
  const days = daysRemaining(row.dueDate)
  if (days < 0) return "overdue"
  if (days <= 2) return "critical"
  if (days <= 7) return "soon"
  return "upcoming"
}

const urgencyConfig = {
  overdue:   { label: "Overdue",    className: "bg-rose-500/15 text-rose-700 dark:text-rose-400",       border: "border-l-rose-500",   dot: "bg-rose-500" },
  critical:  { label: "Critical",   className: "bg-orange-500/15 text-orange-700 dark:text-orange-400", border: "border-l-orange-500", dot: "bg-orange-500" },
  soon:      { label: "Soon",       className: "bg-amber-500/15 text-amber-700 dark:text-amber-400",    border: "border-l-amber-500",  dot: "bg-amber-500" },
  upcoming:  { label: "Upcoming",   className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400", border: "border-l-emerald-500", dot: "bg-emerald-500" },
  done:      { label: "Done",       className: "bg-violet-500/15 text-violet-700 dark:text-violet-400", border: "border-l-violet-500", dot: "bg-violet-500" },
} as const

type Filter = "all" | "overdue" | "critical" | "soon" | "upcoming"

export default function DeadlinesPage() {
  const [filter, setFilter] = useState<Filter>("all")
  const all = useMemo(() => buildDeadlines().sort((a, b) => a.dueDate.localeCompare(b.dueDate)), [])

  const enriched = useMemo(() => all.map(r => ({ ...r, _urgency: urgency(r) })), [all])

  const counts = useMemo(() => ({
    all: enriched.length,
    overdue: enriched.filter(r => r._urgency === "overdue").length,
    critical: enriched.filter(r => r._urgency === "critical").length,
    soon: enriched.filter(r => r._urgency === "soon").length,
    upcoming: enriched.filter(r => r._urgency === "upcoming").length,
    done: enriched.filter(r => r._urgency === "done").length,
    tasks: enriched.filter(r => r.kind === "task").length,
    milestones: enriched.filter(r => r.kind === "milestone").length,
  }), [enriched])

  const filtered = filter === "all"
    ? enriched.filter(r => r._urgency !== "done")
    : enriched.filter(r => r._urgency === filter)

  return (
    <DashboardShell
      title="Deadlines"
      description="Task due dates and project milestones in one unified timeline."
      actions={
        <Button asChild variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
          <Link href="/calendar/create-event"><CalendarClock className="w-4 h-4" /> Add deadline</Link>
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total Deadlines" value={counts.all - counts.done} hint={`${counts.tasks} tasks · ${counts.milestones} milestones`} icon={Flag} />
        <StatCard label="Overdue" value={counts.overdue} hint="past due" icon={AlertTriangle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Critical (≤2 days)" value={counts.critical} hint="needs action now" icon={CalendarClock} iconColor="bg-orange-500/15 text-orange-600 dark:text-orange-400" />
        <StatCard label="Completed" value={counts.done} hint="shipped" icon={CheckCircle2} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Filter tabs */}
      <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)} className="mb-4">
        <TabsList className="h-9 flex-wrap">
          <TabsTrigger value="all" className="text-xs gap-1.5">All <span className="text-[10px] text-muted-foreground">{counts.all - counts.done}</span></TabsTrigger>
          <TabsTrigger value="overdue" className="text-xs gap-1.5">Overdue <span className="text-[10px] text-muted-foreground">{counts.overdue}</span></TabsTrigger>
          <TabsTrigger value="critical" className="text-xs gap-1.5">Critical <span className="text-[10px] text-muted-foreground">{counts.critical}</span></TabsTrigger>
          <TabsTrigger value="soon" className="text-xs gap-1.5">Soon <span className="text-[10px] text-muted-foreground">{counts.soon}</span></TabsTrigger>
          <TabsTrigger value="upcoming" className="text-xs gap-1.5">Upcoming <span className="text-[10px] text-muted-foreground">{counts.upcoming}</span></TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Deadlines list */}
      <div className="space-y-2">
        {filtered.length === 0 && (
          <Card className="p-12 text-center border-dashed">
            <Filter className="w-10 h-10 mx-auto text-muted-foreground/60 mb-3" />
            <p className="text-sm font-medium text-foreground">No deadlines in this view</p>
            <p className="text-xs text-muted-foreground mt-1">Try a different filter tab.</p>
          </Card>
        )}

        {filtered.map((r, idx) => {
          const uc = urgencyConfig[r._urgency]
          const days = daysRemaining(r.dueDate)
          const isTask = r.kind === "task"
          const href = isTask ? `/tasks/${r.id}` : `/planning/milestones`
          return (
            <Card
              key={`${r.kind}-${r.id}`}
              className={cn("p-3 md:p-4 card-lift animate-slide-in-up border-l-4", uc.border)}
              style={{ animationDelay: `${idx * 25}ms` }}
            >
              <div className="flex items-start gap-3 flex-wrap sm:flex-nowrap">
                {/* Kind icon */}
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center shrink-0", uc.className)}>
                  {isTask ? <ListTodo className="w-4 h-4" /> : <MilestoneIcon className="w-4 h-4" />}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-semibold text-foreground truncate">{r.title}</h4>
                        {r.taskKey && <span className="text-[10px] font-mono text-muted-foreground">{r.taskKey}</span>}
                      </div>
                      <div className="flex items-center gap-2 mt-1 flex-wrap text-[11px] text-muted-foreground">
                        <Link href={`/projects/${r.projectId}`} className="inline-flex items-center gap-1 hover:text-primary transition-colors">
                          <span className={cn("w-2 h-2 rounded-full", r.projectColor)} />
                          {r.projectName}
                        </Link>
                        <span>·</span>
                        <span className="inline-flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> {formatDate(r.dueDate)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {r.priority !== "none" && <PriorityBadge priority={r.priority as Priority} />}
                      <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded", uc.className)}>
                        {uc.label}
                      </span>
                    </div>
                  </div>

                  {/* Bottom row: days remaining + progress / assignee */}
                  <div className="flex items-center gap-3 mt-2 flex-wrap">
                    <span className={cn(
                      "text-xs font-semibold tabular-nums",
                      r._urgency === "overdue" ? "text-rose-600 dark:text-rose-400" :
                      r._urgency === "critical" ? "text-orange-600 dark:text-orange-400" :
                      "text-muted-foreground"
                    )}>
                      {days < 0 ? `${-days} day${-days !== 1 ? "s" : ""} overdue` :
                       days === 0 ? "Due today" :
                       days === 1 ? "Due tomorrow" :
                       `${days} days left`}
                    </span>
                    <span className="text-[10px] text-muted-foreground">·</span>
                    <span className="text-[10px] text-muted-foreground">{relativeDay(r.dueDate)}</span>

                    {r.kind === "milestone" && typeof r.progress === "number" && (
                      <div className="flex items-center gap-2 flex-1 min-w-[120px]">
                        <Progress value={r.progress} className="h-1.5 flex-1" />
                        <span className="text-[10px] font-semibold text-muted-foreground tabular-nums w-9 text-right">{r.progress}%</span>
                      </div>
                    )}

                    {r.assignee && (
                      <div className="flex items-center gap-1.5 ml-auto">
                        <Avatar className="w-5 h-5">
                          {r.assigneeAvatar ? <AvatarImage src={r.assigneeAvatar} alt={r.assignee} /> : <AvatarFallback className="text-[8px]">{r.assignee.split(" ").map(w => w[0]).slice(0, 2).join("")}</AvatarFallback>}
                        </Avatar>
                        <span className="text-[10px] text-muted-foreground hidden sm:inline">{r.assignee}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Action */}
                <Button asChild variant="ghost" size="icon" className="h-8 w-8 shrink-0 text-muted-foreground hover:text-primary">
                  <Link href={href} aria-label={`Open ${r.title}`}><ArrowRight className="w-4 h-4" /></Link>
                </Button>
              </div>
            </Card>
          )
        })}
      </div>

      {/* Summary footer */}
      <Card className="p-4 mt-4 card-lift">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h3 className="text-sm font-semibold text-foreground">Deadline Summary</h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              {counts.overdue} overdue · {counts.critical} critical · {counts.soon} soon · {counts.upcoming} upcoming
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span className="text-muted-foreground">Overdue</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
              <span className="text-muted-foreground">Critical</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span className="text-muted-foreground">Soon</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-muted-foreground">Upcoming</span>
            </div>
          </div>
        </div>
      </Card>
    </DashboardShell>
  )
}
