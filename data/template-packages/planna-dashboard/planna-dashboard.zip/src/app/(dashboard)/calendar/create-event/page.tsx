"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  ChevronLeft, Calendar, Clock, MapPin, Users, Video, Tag, Repeat, X, Check,
  Plus, Briefcase, Bell,
} from "lucide-react"
import { members, projects } from "@/lib/data/mock"
import { cn } from "@/lib/utils"
import { categoryConfig, attendeeAvatar, attendeeInitials } from "../_lib"
import type { EventCategory } from "@/types"

const colorOptions = [
  { label: "Emerald", value: "bg-emerald-500" },
  { label: "Teal", value: "bg-teal-500" },
  { label: "Lime", value: "bg-lime-500" },
  { label: "Cyan", value: "bg-cyan-500" },
  { label: "Amber", value: "bg-amber-500" },
  { label: "Rose", value: "bg-rose-500" },
  { label: "Pink", value: "bg-pink-500" },
  { label: "Violet", value: "bg-violet-500" },
]

const recurrenceOptions = [
  { value: "none", label: "Does not repeat" },
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "biweekly", label: "Every 2 weeks" },
  { value: "monthly", label: "Monthly" },
]

const today = new Date()
const pad = (n: number) => String(n).padStart(2, "0")
const defaultDate = `${today.getFullYear()}-${pad(today.getMonth() + 1)}-${pad(today.getDate())}`

export default function CreateEventPage() {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [allDay, setAllDay] = useState(false)
  const [startDate, setStartDate] = useState(defaultDate)
  const [endDate, setEndDate] = useState(defaultDate)
  const [startTime, setStartTime] = useState("10:00")
  const [endTime, setEndTime] = useState("11:00")
  const [category, setCategory] = useState<EventCategory>("meeting")
  const [color, setColor] = useState("bg-emerald-500")
  const [location, setLocation] = useState("")
  const [projectId, setProjectId] = useState("none")
  const [recurrence, setRecurrence] = useState("none")
  const [attendees, setAttendees] = useState<string[]>([members[0].name, members[1].name])
  const [attendeeQuery, setAttendeeQuery] = useState("")
  const [reminder, setReminder] = useState("15")
  const [submitted, setSubmitted] = useState(false)

  const filteredMembers = members.filter(m =>
    !attendees.includes(m.name) &&
    (m.name.toLowerCase().includes(attendeeQuery.toLowerCase()) ||
     m.email.toLowerCase().includes(attendeeQuery.toLowerCase()))
  )

  const toggleAttendee = (name: string) => {
    setAttendees(prev => prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name])
  }

  const canSubmit = title.trim().length > 0

  const handleSubmit = () => {
    if (!canSubmit) return
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <DashboardShell
        title="Create Event"
        description="Add a new event to your calendar."
      >
        <Card className="p-8 md:p-12 text-center card-lift animate-scale-in max-w-md mx-auto">
          <div className="w-16 h-16 rounded-full bg-emerald-500/15 flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-emerald-600 dark:text-emerald-400" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-1">Event created</h3>
          <p className="text-sm text-muted-foreground mb-6">
            &ldquo;{title}&rdquo; has been added to your calendar.
          </p>
          <div className="flex gap-2 justify-center flex-wrap">
            <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link href="/calendar">View calendar</Link>
            </Button>
            <Button variant="outline" onClick={() => { setSubmitted(false); setTitle("") }}>
              Create another
            </Button>
          </div>
        </Card>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell
      title="Create Event"
      description="Add a new event to your calendar."
      actions={
        <Button variant="outline" size="sm" className="h-9 text-sm gap-1.5 bg-transparent" asChild>
          <Link href="/calendar"><ChevronLeft className="w-4 h-4" /> Back to calendar</Link>
        </Button>
      }
    >
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-4">
        {/* Form */}
        <div className="space-y-4">
          {/* Title + description */}
          <Card className="p-5 card-lift">
            <Label htmlFor="title" className="text-xs font-medium text-muted-foreground mb-1.5 block">
              Event title <span className="text-destructive">*</span>
            </Label>
            <Input
              id="title"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Sprint Planning"
              className="h-10 text-base font-medium"
              autoFocus
            />
            <Label htmlFor="description" className="text-xs font-medium text-muted-foreground mb-1.5 block mt-4">
              Description
            </Label>
            <Textarea
              id="description"
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Add agenda, notes, or context…"
              rows={3}
              className="resize-none"
            />
          </Card>

          {/* Date & time */}
          <Card className="p-5 card-lift">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-primary" /> Date &amp; time
              </h3>
              <label className="flex items-center gap-2 cursor-pointer">
                <span className="text-xs text-muted-foreground">All day</span>
                <Switch checked={allDay} onCheckedChange={setAllDay} />
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">Start date</Label>
                <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-9" />
              </div>
              <div>
                <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">End date</Label>
                <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="h-9" />
              </div>
              {!allDay && (
                <>
                  <div>
                    <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">Start time</Label>
                    <Input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} className="h-9" />
                  </div>
                  <div>
                    <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">End time</Label>
                    <Input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} className="h-9" />
                  </div>
                </>
              )}
            </div>

            {/* Recurrence */}
            <div className="mt-4">
              <Label className="text-xs font-medium text-muted-foreground mb-1.5 flex items-center gap-1.5">
                <Repeat className="w-3.5 h-3.5" /> Recurrence
              </Label>
              <Select value={recurrence} onValueChange={setRecurrence}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {recurrenceOptions.map(o => (
                    <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </Card>

          {/* Category & color */}
          <Card className="p-5 card-lift">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-1.5">
              <Tag className="w-4 h-4 text-primary" /> Category &amp; color
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
              {(Object.keys(categoryConfig) as EventCategory[]).map(k => {
                const c = categoryConfig[k]
                const isActive = category === k
                return (
                  <button
                    key={k}
                    type="button"
                    onClick={() => { setCategory(k); setColor(c.dot) }}
                    className={cn(
                      "flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-medium transition-all",
                      isActive
                        ? "border-primary bg-primary/5 text-foreground"
                        : "border-border text-muted-foreground hover:border-primary/30 hover:text-foreground"
                    )}
                  >
                    <span className={cn("w-2 h-2 rounded-full", c.dot)} />
                    <c.icon className="w-3.5 h-3.5" />
                    {c.label}
                  </button>
                )
              })}
            </div>
            <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">Color</Label>
            <div className="flex items-center gap-2 flex-wrap">
              {colorOptions.map(c => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setColor(c.value)}
                  className={cn(
                    "w-7 h-7 rounded-full transition-all hover:scale-110",
                    c.value,
                    color === c.value && "ring-2 ring-offset-2 ring-offset-card ring-foreground"
                  )}
                  aria-label={c.label}
                />
              ))}
            </div>
          </Card>

          {/* Location */}
          <Card className="p-5 card-lift">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-primary" /> Location
            </h3>
            <Input
              value={location}
              onChange={e => setLocation(e.target.value)}
              placeholder="Add a location or video call link…"
              className="h-9"
            />
            <div className="flex items-center gap-2 mt-3 flex-wrap">
              <Button type="button" variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => setLocation("Zoom — Main")}>
                <Video className="w-3.5 h-3.5" /> Zoom
              </Button>
              <Button type="button" variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => setLocation("Google Meet")}>
                <Video className="w-3.5 h-3.5" /> Google Meet
              </Button>
              <Button type="button" variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => setLocation("Conference room A")}>
                <MapPin className="w-3.5 h-3.5" /> In person
              </Button>
            </div>
          </Card>

          {/* Attendees */}
          <Card className="p-5 card-lift">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-primary" /> Attendees
              <span className="text-xs text-muted-foreground font-normal">({attendees.length})</span>
            </h3>

            {/* Selected attendees */}
            {attendees.length > 0 && (
              <div className="flex items-center gap-1.5 flex-wrap mb-3">
                {attendees.map(name => {
                  const m = members.find(x => x.name === name)
                  return (
                    <Badge key={name} variant="secondary" className="gap-1.5 pl-1 pr-1 py-1">
                      <Avatar className="w-4 h-4">
                        {attendeeAvatar(name) ? <AvatarImage src={attendeeAvatar(name)} alt={name} /> : <AvatarFallback className="text-[7px]">{attendeeInitials(name)}</AvatarFallback>}
                      </Avatar>
                      <span className="text-[10px]">{m?.name.split(" ")[0] ?? name}</span>
                      <button
                        type="button"
                        onClick={() => toggleAttendee(name)}
                        className="ml-0.5 hover:text-destructive"
                        aria-label={`Remove ${name}`}
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  )
                })}
              </div>
            )}

            {/* Search box */}
            <div className="relative">
              <Input
                value={attendeeQuery}
                onChange={e => setAttendeeQuery(e.target.value)}
                placeholder="Search team members…"
                className="h-9"
              />
              {attendeeQuery && filteredMembers.length > 0 && (
                <div className="absolute z-10 mt-1 w-full bg-card border border-border rounded-lg shadow-lg max-h-60 overflow-y-auto">
                  {filteredMembers.slice(0, 6).map(m => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => { toggleAttendee(m.name); setAttendeeQuery("") }}
                      className="w-full flex items-center gap-2.5 p-2 hover:bg-secondary/60 transition-colors text-left"
                    >
                      <Avatar className="w-7 h-7">
                        <AvatarImage src={m.avatar} alt={m.name} />
                        <AvatarFallback className="text-[10px]">{attendeeInitials(m.name)}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-foreground truncate">{m.name}</p>
                        <p className="text-[10px] text-muted-foreground truncate">{m.title}</p>
                      </div>
                      <Plus className="w-3.5 h-3.5 text-muted-foreground" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </Card>

          {/* Project + reminder */}
          <Card className="p-5 card-lift">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label className="text-xs font-medium text-muted-foreground mb-1.5 flex items-center gap-1.5">
                  <Briefcase className="w-3.5 h-3.5" /> Linked project
                </Label>
                <Select value={projectId} onValueChange={setProjectId}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No project</SelectItem>
                    {projects.map(p => (
                      <SelectItem key={p.id} value={p.id}>
                        <span className="inline-flex items-center gap-1.5">
                          <span className={cn("w-1.5 h-1.5 rounded-full", p.color)} />
                          {p.name}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-medium text-muted-foreground mb-1.5 flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5" /> Reminder
                </Label>
                <Select value={reminder} onValueChange={setReminder}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">At time of event</SelectItem>
                    <SelectItem value="5">5 minutes before</SelectItem>
                    <SelectItem value="15">15 minutes before</SelectItem>
                    <SelectItem value="30">30 minutes before</SelectItem>
                    <SelectItem value="60">1 hour before</SelectItem>
                    <SelectItem value="1440">1 day before</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>
        </div>

        {/* Live preview + actions */}
        <div className="space-y-4">
          <Card className="p-4 card-lift sticky top-4">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Preview</h4>
            <div className={cn("rounded-lg p-3 border-l-4", "bg-card border-border")} style={{ borderLeftColor: "var(--ring)" }}>
              <div className={cn("w-1 h-full")} />
              <p className="text-sm font-semibold text-foreground">{title || "Untitled event"}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {allDay ? "All day" : `${startTime} – ${endTime}`}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {startDate === endDate ? startDate : `${startDate} → ${endDate}`}
              </p>
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded", categoryConfig[category].chip)}>
                  {categoryConfig[category].label}
                </span>
                {recurrence !== "none" && (
                  <Badge variant="outline" className="text-[10px] gap-1"><Repeat className="w-2.5 h-2.5" /> {recurrence}</Badge>
                )}
                {location && (
                  <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
                    <MapPin className="w-2.5 h-2.5" /> {location}
                  </span>
                )}
              </div>
              {attendees.length > 0 && (
                <div className="flex items-center mt-2">
                  <div className="flex -space-x-1.5">
                    {attendees.slice(0, 4).map((name, i) => (
                      <Avatar key={i} className="w-5 h-5 border-2 border-card">
                        {attendeeAvatar(name) ? <AvatarImage src={attendeeAvatar(name)} alt={name} /> : <AvatarFallback className="text-[8px]">{attendeeInitials(name)}</AvatarFallback>}
                      </Avatar>
                    ))}
                  </div>
                  {attendees.length > 4 && <span className="text-[10px] text-muted-foreground ml-1.5">+{attendees.length - 4}</span>}
                </div>
              )}
            </div>

            <div className="mt-4 space-y-2">
              <Button
                className="w-full h-9 text-sm gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={!canSubmit}
                onClick={handleSubmit}
              >
                <Check className="w-4 h-4" /> Create event
              </Button>
              <Button asChild variant="outline" className="w-full h-9 text-sm bg-transparent">
                <Link href="/calendar">Cancel</Link>
              </Button>
            </div>

            <div className="mt-4 pt-3 border-t border-border space-y-1.5 text-[11px] text-muted-foreground">
              <p className="flex items-center gap-1.5"><Clock className="w-3 h-3" /> Duration: {allDay ? "All day" : calcDuration(startTime, endTime)}</p>
              <p className="flex items-center gap-1.5"><Users className="w-3 h-3" /> {attendees.length} attendee{attendees.length !== 1 ? "s" : ""}</p>
              {projectId !== "none" && (
                <p className="flex items-center gap-1.5"><Briefcase className="w-3 h-3" /> {projects.find(p => p.id === projectId)?.name}</p>
              )}
            </div>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}

function calcDuration(start: string, end: string): string {
  const [sh, sm] = start.split(":").map(Number)
  const [eh, em] = end.split(":").map(Number)
  let mins = (eh * 60 + em) - (sh * 60 + sm)
  if (mins < 0) mins += 24 * 60
  const h = Math.floor(mins / 60)
  const m = mins % 60
  if (h > 0 && m > 0) return `${h}h ${m}m`
  if (h > 0) return `${h}h`
  return `${m}m`
}
