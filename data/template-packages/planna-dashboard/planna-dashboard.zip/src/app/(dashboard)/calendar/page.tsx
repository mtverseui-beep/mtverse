"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  ChevronLeft, ChevronRight, Plus, CalendarDays, Users, Target, Flag, Clock, MapPin,
} from "lucide-react"
import { events } from "@/lib/data/mock"
import { cn, isSameDay, relativeDay } from "@/lib/utils"
import {
  categoryConfig, getMonthGrid, getWeekDays, WEEKDAY_LABELS, WEEKDAY_LABELS_SHORT,
  dateKey, eventOnDate, formatTime, CalendarViewNav,
} from "./_lib"

const today = new Date()

export default function CalendarMonthPage() {
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1))

  const year = cursor.getFullYear()
  const month = cursor.getMonth()
  const days = useMemo(() => getMonthGrid(year, month), [year, month])

  const eventsThisMonth = useMemo(() =>
    events.filter(e => {
      const s = new Date(e.start)
      const en = new Date(e.end)
      // event overlaps month if start <= last-of-month and end >= first-of-month
      const first = new Date(year, month, 1)
      const last = new Date(year, month + 1, 0, 23, 59, 59)
      return s <= last && en >= first
    })
  , [year, month])

  const stats = useMemo(() => ({
    total: eventsThisMonth.length,
    meetings: eventsThisMonth.filter(e => e.category === "meeting").length,
    focus: eventsThisMonth.filter(e => e.category === "focus").length,
    deadlines: eventsThisMonth.filter(e => e.category === "deadline").length,
  }), [eventsThisMonth])

  // Upcoming events (next 5 from today onward)
  const upcoming = useMemo(() => {
    const tKey = dateKey(today)
    return [...events]
      .filter(e => e.start.slice(0, 10) >= tKey)
      .sort((a, b) => a.start.localeCompare(b.start))
      .slice(0, 5)
  }, [])

  return (
    <DashboardShell
      title="Calendar"
      description="Plan and view your schedule across the month."
      actions={
        <>
          <CalendarViewNav active="/calendar" />
          <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Link href="/calendar/create-event">
              <Plus className="w-4 h-4" /> New event
            </Link>
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Events This Month" value={stats.total} hint={`${cursor.toLocaleDateString("en-US", { month: "long", year: "numeric" })}`} icon={CalendarDays} />
        <StatCard label="Meetings" value={stats.meetings} hint="scheduled syncs" icon={Users} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Focus Blocks" value={stats.focus} hint="deep work time" icon={Target} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Deadlines" value={stats.deadlines} hint="due this month" icon={Flag} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-4">
        {/* Month grid */}
        <Card className="p-3 md:p-5 card-lift">
          {/* Header */}
          <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
            <h3 className="text-base md:text-lg font-semibold text-foreground">
              {cursor.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
            </h3>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setCursor(new Date(today.getFullYear(), today.getMonth(), 1))}>
                Today
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(year, month - 1, 1))} aria-label="Previous month">
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(year, month + 1, 1))} aria-label="Next month">
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Weekday labels */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {WEEKDAY_LABELS.map((d, i) => (
              <div key={i} className="text-center">
                <span className="hidden sm:inline text-[10px] font-semibold text-muted-foreground uppercase tracking-wider py-1">{d}</span>
                <span className="sm:hidden text-[10px] font-semibold text-muted-foreground uppercase tracking-wider py-1">{WEEKDAY_LABELS_SHORT[i]}</span>
              </div>
            ))}
          </div>

          {/* Day cells */}
          <div className="grid grid-cols-7 gap-1">
            {days.map((d, i) => {
              const inMonth = d.getMonth() === month
              const isToday = isSameDay(dateKey(d), dateKey(today))
              const dayEvents = events.filter(e => eventOnDate(e, d))
              return (
                <div
                  key={i}
                  className={cn(
                    "group min-h-[78px] md:min-h-[110px] rounded-lg border p-1.5 transition-all hover:border-primary/30 hover:shadow-sm flex flex-col",
                    isToday ? "border-primary bg-primary/5" : "border-border",
                    !inMonth && "opacity-50",
                  )}
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className={cn(
                      "text-[11px] font-semibold tabular-nums inline-flex items-center justify-center",
                      isToday ? "bg-primary text-primary-foreground rounded-full w-5 h-5" : "text-muted-foreground px-1"
                    )}>
                      {d.getDate()}
                    </span>
                    <Link
                      href="/calendar/create-event"
                      className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-primary"
                      aria-label={`Add event on ${d.toDateString()}`}
                    >
                      <Plus className="w-3 h-3" />
                    </Link>
                  </div>
                  <div className="space-y-0.5 flex-1 overflow-hidden">
                    {dayEvents.slice(0, 3).map(e => {
                      const cat = categoryConfig[e.category]
                      return (
                        <Link
                          key={e.id}
                          href={`/calendar/events/${e.id}`}
                          className="block text-[10px] leading-tight px-1 py-0.5 rounded truncate hover:opacity-80 transition-opacity"
                          title={e.title}
                        >
                          <span className={cn("inline-block w-1.5 h-1.5 rounded-full mr-1 align-middle", cat.dot)} />
                          <span className={cn("align-middle", cat.text)}>{e.title}</span>
                        </Link>
                      )
                    })}
                    {dayEvents.length > 3 && (
                      <Link
                        href={`/calendar/day?d=${dateKey(d)}`}
                        className="block text-[10px] text-muted-foreground hover:text-primary px-1 font-medium"
                      >
                        +{dayEvents.length - 3} more
                      </Link>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Side panel */}
        <div className="space-y-4">
          {/* Mini calendar */}
          <MiniCalendar cursor={cursor} onSelect={(d) => setCursor(new Date(d.getFullYear(), d.getMonth(), 1))} />

          {/* Upcoming events */}
          <Card className="p-4 card-lift">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-primary" /> Upcoming
              </h4>
              <Link href="/calendar/agenda" className="text-[11px] text-primary hover:underline">View agenda</Link>
            </div>
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {upcoming.length === 0 && (
                <p className="text-xs text-muted-foreground py-6 text-center">No upcoming events.</p>
              )}
              {upcoming.map(e => {
                const cat = categoryConfig[e.category]
                return (
                  <Link
                    key={e.id}
                    href={`/calendar/events/${e.id}`}
                    className="flex items-start gap-2.5 p-2 rounded-lg hover:bg-secondary/60 transition-colors group"
                  >
                    <span className={cn("mt-1 w-2 h-2 rounded-full shrink-0", cat.dot)} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground truncate group-hover:text-primary transition-colors">{e.title}</p>
                      <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground mt-0.5">
                        <span>{relativeDay(e.start)}</span>
                        {!e.allDay && <span>· {formatTime(e.start)}</span>}
                        {e.location && (
                          <>
                            <span>·</span>
                            <span className="truncate inline-flex items-center gap-0.5"><MapPin className="w-2.5 h-2.5" />{e.location}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </Link>
                )
              })}
            </div>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}

// ============================================================
// MINI CALENDAR — small month picker for the sidebar
// ============================================================
function MiniCalendar({ cursor, onSelect }: { cursor: Date; onSelect: (d: Date) => void }) {
  const [view, setView] = useState(new Date(cursor.getFullYear(), cursor.getMonth(), 1))
  const year = view.getFullYear()
  const month = view.getMonth()
  const days = useMemo(() => getMonthGrid(year, month), [year, month])
  const weekDays = useMemo(() => getWeekDays(today), [])

  return (
    <Card className="p-4 card-lift">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-sm font-semibold text-foreground">
          {view.toLocaleDateString("en-US", { month: "short", year: "numeric" })}
        </h4>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setView(new Date(year, month - 1, 1))} aria-label="Previous month">
            <ChevronLeft className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setView(new Date(year, month + 1, 1))} aria-label="Next month">
            <ChevronRight className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
      <div className="grid grid-cols-7 gap-0.5 mb-1">
        {WEEKDAY_LABELS_SHORT.map((d, i) => (
          <div key={i} className="text-center text-[9px] font-semibold text-muted-foreground uppercase">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-0.5">
        {days.map((d, i) => {
          const inMonth = d.getMonth() === month
          const isToday = isSameDay(dateKey(d), dateKey(today))
          const hasEvent = events.some(e => eventOnDate(e, d))
          const inThisWeek = weekDays.some(w => isSameDay(dateKey(w), dateKey(d)))
          return (
            <button
              key={i}
              onClick={() => onSelect(d)}
              className={cn(
                "aspect-square rounded-md text-[10px] font-medium tabular-nums flex items-center justify-center transition-colors relative",
                isToday
                  ? "bg-primary text-primary-foreground"
                  : inThisWeek
                    ? "bg-primary/10 text-primary hover:bg-primary/20"
                    : inMonth
                      ? "text-foreground hover:bg-secondary"
                      : "text-muted-foreground/50 hover:bg-secondary",
              )}
            >
              {d.getDate()}
              {hasEvent && !isToday && (
                <span className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />
              )}
            </button>
          )
        })}
      </div>
    </Card>
  )
}
