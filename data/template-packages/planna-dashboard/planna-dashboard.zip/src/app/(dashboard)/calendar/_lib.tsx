"use client"

import Link from "next/link"
import { CalendarDays, CalendarRange, CalendarClock, List, Users, Bell, Flag, Target, Coffee, ExternalLink } from "lucide-react"
import { members } from "@/lib/data/mock"
import type { EventCategory } from "@/types"
import { cn } from "@/lib/utils"

// ============================================================
// CATEGORY CONFIG — every event category gets icon + colors
// ============================================================
export const categoryConfig: Record<EventCategory, {
  label: string
  icon: typeof Users
  // Tailwind classes for a soft chip
  chip: string
  dot: string
  text: string
}> = {
  meeting:  { label: "Meeting",  icon: Users,        chip: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400", dot: "bg-emerald-500", text: "text-emerald-700 dark:text-emerald-400" },
  deadline: { label: "Deadline", icon: Flag,         chip: "bg-rose-500/15 text-rose-700 dark:text-rose-400",         dot: "bg-rose-500",    text: "text-rose-700 dark:text-rose-400" },
  reminder: { label: "Reminder", icon: Bell,         chip: "bg-amber-500/15 text-amber-700 dark:text-amber-400",      dot: "bg-amber-500",   text: "text-amber-700 dark:text-amber-400" },
  focus:    { label: "Focus",    icon: Target,       chip: "bg-violet-500/15 text-violet-700 dark:text-violet-400",   dot: "bg-violet-500",  text: "text-violet-700 dark:text-violet-400" },
  personal: { label: "Personal", icon: Coffee,       chip: "bg-pink-500/15 text-pink-700 dark:text-pink-400",         dot: "bg-pink-500",    text: "text-pink-700 dark:text-pink-400" },
  external: { label: "External", icon: ExternalLink, chip: "bg-cyan-500/15 text-cyan-700 dark:text-cyan-400",         dot: "bg-cyan-500",    text: "text-cyan-700 dark:text-cyan-400" },
}

// ============================================================
// ATTENDEE LOOKUP — name → avatar URL (from mock members)
// ============================================================
const memberByName = new Map(members.map(m => [m.name, m]))

export function attendeeAvatar(name: string): string {
  return memberByName.get(name)?.avatar ?? ""
}

export function attendeeInitials(name: string): string {
  return name.split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase()
}

// ============================================================
// DATE HELPERS
// ============================================================
export const WEEKDAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const
export const WEEKDAY_LABELS_SHORT = ["M", "T", "W", "T", "F", "S", "S"] as const

/** Build the 6x7 (or 5x7) grid of Date cells for a given month. */
export function getMonthGrid(year: number, month: number): Date[] {
  const first = new Date(year, month, 1)
  const startWeekday = (first.getDay() + 6) % 7 // Mon = 0
  const gridStart = new Date(year, month, 1 - startWeekday)
  const cells: Date[] = []
  for (let i = 0; i < 42; i++) {
    cells.push(new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + i))
  }
  return cells
}

/** Return the 7 dates of the week containing `ref` (Mon-Sun). */
export function getWeekDays(ref: Date): Date[] {
  const weekday = (ref.getDay() + 6) % 7 // Mon = 0
  const monday = new Date(ref.getFullYear(), ref.getMonth(), ref.getDate() - weekday)
  const days: Date[] = []
  for (let i = 0; i < 7; i++) {
    days.push(new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + i))
  }
  return days
}

/** Format an hour integer (0-23) as e.g. "9 AM", "1 PM". */
export function formatHour(h: number): string {
  const period = h < 12 ? "AM" : "PM"
  const display = h % 12 === 0 ? 12 : h % 12
  return `${display} ${period}`
}

/** Format a time string like "2026-01-01T14:00:00" → "2:00 PM". */
export function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
}

/** Format event duration as "1h 30m" or "45m". */
export function eventDurationMinutes(startIso: string, endIso: string): number {
  return Math.max(0, Math.round((new Date(endIso).getTime() - new Date(startIso).getTime()) / 60000))
}

export function formatDurationFromMin(min: number): string {
  const h = Math.floor(min / 60)
  const m = min % 60
  if (h > 0 && m > 0) return `${h}h ${m}m`
  if (h > 0) return `${h}h`
  return `${m}m`
}

/** Date → "YYYY-MM-DD" key (local). */
export function dateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`
}

/** Does event fall on the given date? */
export function eventOnDate(event: { start: string; end: string; allDay?: boolean }, d: Date): boolean {
  const key = dateKey(d)
  const sKey = event.start.slice(0, 10)
  const eKey = event.end.slice(0, 10)
  return key >= sKey && key <= eKey
}

// ============================================================
// CALENDAR VIEW NAV — shared segmented control
// ============================================================
const viewLinks = [
  { href: "/calendar",          label: "Month",   icon: CalendarDays },
  { href: "/calendar/week",     label: "Week",    icon: CalendarRange },
  { href: "/calendar/day",      label: "Day",     icon: CalendarClock },
  { href: "/calendar/agenda",   label: "Agenda",  icon: List },
] as const

export function CalendarViewNav({ active }: { active: string }) {
  return (
    <div className="inline-flex items-center rounded-lg border border-border bg-card p-0.5 shadow-sm">
      {viewLinks.map(v => {
        const Icon = v.icon
        const isActive = v.href === active
        return (
          <Link
            key={v.href}
            href={v.href}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors",
              isActive
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary"
            )}
          >
            <Icon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{v.label}</span>
          </Link>
        )
      })}
    </div>
  )
}

// ============================================================
// QUICK CATEGORY ICON
// ============================================================
export function CategoryIcon({ category, className }: { category: EventCategory; className?: string }) {
  const Icon = categoryConfig[category].icon
  return <Icon className={className} />
}
