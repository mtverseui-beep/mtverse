"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Plus, Clock } from "lucide-react"
import { events } from "@/lib/data/mock"
import { cn, isSameDay } from "@/lib/utils"
import {
  categoryConfig, getWeekDays, dateKey, eventOnDate, formatHour, formatTime,
  CalendarViewNav,
} from "../_lib"
import type { CalendarEvent } from "@/types"

const START_HOUR = 7   // 7 AM
const END_HOUR = 20    // 8 PM
const HOUR_HEIGHT = 56 // px per hour
const today = new Date()

export default function CalendarWeekPage() {
  const [cursor, setCursor] = useState(new Date(today))
  const weekDays = useMemo(() => getWeekDays(cursor), [cursor])
  const now = new Date()
  const nowMinutes = now.getHours() * 60 + now.getMinutes()
  const showNowLine = weekDays.some(d => isSameDay(dateKey(d), dateKey(today)))

  const eventsThisWeek = useMemo(() =>
    events.filter(e => weekDays.some(d => eventOnDate(e, d)))
  , [weekDays])

  return (
    <DashboardShell
      title="Week View"
      description="See your week at a glance with timed event blocks."
      actions={
        <>
          <CalendarViewNav active="/calendar/week" />
          <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Link href="/calendar/create-event"><Plus className="w-4 h-4" /> New event</Link>
          </Button>
        </>
      }
    >
      <Card className="p-3 md:p-5 card-lift">
        {/* Header */}
        <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
          <div>
            <h3 className="text-base md:text-lg font-semibold text-foreground">
              {weekDays[0].toLocaleDateString("en-US", { month: "short", day: "numeric" })} – {weekDays[6].toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              {eventsThisWeek.length} event{eventsThisWeek.length !== 1 ? "s" : ""} this week
            </p>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setCursor(new Date(today))}>Today</Button>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() - 7))} aria-label="Previous week">
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() + 7))} aria-label="Next week">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Day headers */}
        <div className="grid grid-cols-[48px_repeat(7,minmax(0,1fr))] sticky top-0 z-20 bg-card pb-2 border-b border-border">
          <div />
          {weekDays.map((d, i) => {
            const isToday = isSameDay(dateKey(d), dateKey(today))
            return (
              <div key={i} className="text-center px-1">
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
                  {d.toLocaleDateString("en-US", { weekday: "short" })}
                </p>
                <p className={cn(
                  "inline-flex items-center justify-center w-7 h-7 rounded-full text-sm font-semibold tabular-nums mt-0.5",
                  isToday ? "bg-primary text-primary-foreground" : "text-foreground"
                )}>
                  {d.getDate()}
                </p>
              </div>
            )
          })}
        </div>

        {/* Scrollable time grid */}
        <div className="overflow-x-auto">
          <div className="min-w-[760px]">
            <div className="grid grid-cols-[48px_repeat(7,minmax(0,1fr))] relative">
              {/* Hour labels column */}
              <div className="relative">
                {Array.from({ length: END_HOUR - START_HOUR + 1 }).map((_, i) => {
                  const h = START_HOUR + i
                  return (
                    <div key={h} className="relative" style={{ height: HOUR_HEIGHT }}>
                      <span className="absolute -top-1.5 right-2 text-[9px] font-medium text-muted-foreground tabular-nums">
                        {formatHour(h)}
                      </span>
                    </div>
                  )
                })}
              </div>

              {/* Day columns */}
              {weekDays.map((d, dayIdx) => {
                const isToday = isSameDay(dateKey(d), dateKey(today))
                const dayEvents = events.filter(e => eventOnDate(e, d) && !e.allDay)
                return (
                  <div key={dayIdx} className="relative border-l border-border">
                    {/* Hour slot backgrounds */}
                    {Array.from({ length: END_HOUR - START_HOUR + 1 }).map((_, i) => {
                      const h = START_HOUR + i
                      return (
                        <Link
                          key={h}
                          href="/calendar/create-event"
                          className="absolute left-0 right-0 border-t border-border/60 hover:bg-primary/5 transition-colors"
                          style={{ top: i * HOUR_HEIGHT, height: HOUR_HEIGHT }}
                          aria-label={`Add event at ${formatHour(h)} on ${d.toLocaleDateString()}`}
                        />
                      )
                    })}

                    {/* Now indicator */}
                    {isToday && nowMinutes >= START_HOUR * 60 && nowMinutes <= (END_HOUR + 1) * 60 && (
                      <div
                        className="absolute left-0 right-0 z-10 pointer-events-none"
                        style={{ top: ((nowMinutes - START_HOUR * 60) / 60) * HOUR_HEIGHT }}
                      >
                        <div className="flex items-center">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 -ml-0.5" />
                          <div className="flex-1 h-px bg-rose-500" />
                        </div>
                      </div>
                    )}

                    {/* Event blocks */}
                    {dayEvents.map(e => (
                      <WeekEventBlock key={e.id} event={e} day={d} />
                    ))}
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* All-day events strip */}
        <div className="mt-4 grid grid-cols-[48px_repeat(7,minmax(0,1fr))] gap-0 border-t border-border pt-3">
          <div className="text-[9px] font-medium text-muted-foreground uppercase pt-1">All day</div>
          {weekDays.map((d, i) => {
            const allDayEvents = events.filter(e => e.allDay && eventOnDate(e, d))
            return (
              <div key={i} className="px-0.5 space-y-0.5 min-h-[24px]">
                {allDayEvents.map(e => {
                  const cat = categoryConfig[e.category]
                  return (
                    <Link
                      key={e.id}
                      href={`/calendar/events/${e.id}`}
                      className={cn("block text-[10px] font-medium px-1.5 py-0.5 rounded truncate", cat.chip)}
                      title={e.title}
                    >
                      {e.title}
                    </Link>
                  )
                })}
              </div>
            )
          })}
        </div>
      </Card>

      {/* Legend */}
      <Card className="p-3 mt-4 card-lift">
        <div className="flex items-center gap-4 flex-wrap text-xs">
          <span className="font-medium text-foreground flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-primary" />Legend:</span>
          {Object.entries(categoryConfig).map(([k, c]) => (
            <span key={k} className="inline-flex items-center gap-1.5 text-muted-foreground">
              <span className={cn("w-2 h-2 rounded-full", c.dot)} />
              {c.label}
            </span>
          ))}
        </div>
      </Card>
    </DashboardShell>
  )
}

// ============================================================
// WEEK EVENT BLOCK — positioned absolutely based on start/end
// ============================================================
function WeekEventBlock({ event, day }: { event: CalendarEvent; day: Date }) {
  const cat = categoryConfig[event.category]
  const start = new Date(event.start)
  const end = new Date(event.end)
  const startMins = start.getHours() * 60 + start.getMinutes()
  const endMins = end.getHours() * 60 + end.getMinutes()
  const clampStart = Math.max(startMins, START_HOUR * 60)
  const clampEnd = Math.min(endMins, (END_HOUR + 1) * 60)
  if (clampEnd <= clampStart) return null
  const top = ((clampStart - START_HOUR * 60) / 60) * HOUR_HEIGHT
  const height = Math.max(20, ((clampEnd - clampStart) / 60) * HOUR_HEIGHT - 2)
  return (
    <Link
      href={`/calendar/events/${event.id}`}
      className={cn(
        "absolute left-0.5 right-0.5 rounded-md px-1.5 py-1 overflow-hidden z-5 group transition-all hover:z-10 hover:shadow-md bg-primary/10 hover:bg-primary/15",
      )}
      style={{ top, height }}
      title={`${event.title} · ${formatTime(event.start)} – ${formatTime(event.end)}`}
    >
      <div className={cn("absolute left-0 top-0 bottom-0 w-1 rounded-l-md", cat.dot)} />
      <p className="text-[10px] font-semibold text-foreground truncate leading-tight ml-1">{event.title}</p>
      {height > 32 && (
        <p className="text-[9px] text-muted-foreground ml-1 leading-tight">
          {formatTime(event.start)} – {formatTime(event.end)}
        </p>
      )}
      {height > 48 && event.location && (
        <p className="text-[9px] text-muted-foreground ml-1 truncate leading-tight">{event.location}</p>
      )}
    </Link>
  )
}
