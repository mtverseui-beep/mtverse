"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus, Video, MapPin, Clock, Users, CalendarClock, CheckCircle2, XCircle, Link2, ArrowRight,
} from "lucide-react"
import { events } from "@/lib/data/mock"
import { cn, relativeDay } from "@/lib/utils"
import {
  categoryConfig, dateKey, formatTime, formatDurationFromMin, eventDurationMinutes,
  attendeeAvatar, attendeeInitials,
} from "../_lib"
import type { CalendarEvent } from "@/types"

type Filter = "upcoming" | "past" | "cancelled"

const today = new Date()
const tKey = dateKey(today)

// Derive a "virtual" cancelled list — events whose title contains "cancelled"
// (Since mock data doesn't have a cancelled flag, we just reuse a few.)
function getMeetings(): (CalendarEvent & { status: "upcoming" | "past" | "cancelled"; meetingLink?: string })[] {
  return events
    .filter(e => e.category === "meeting" || e.category === "external")
    .map((e, i) => {
      const isPast = e.end.slice(0, 10) < tKey
      const isCancelled = e.title.toLowerCase().includes("cancel") || (i === 2 && isPast)
      const status = isCancelled ? "cancelled" : isPast ? "past" : "upcoming"
      const linkKind = e.location && (e.location.toLowerCase().includes("zoom") || e.location.toLowerCase().includes("meet"))
        ? e.location
        : i % 2 === 0 ? "Zoom — Main" : undefined
      return { ...e, status, meetingLink: linkKind }
    })
}

export default function MeetingsPage() {
  const [filter, setFilter] = useState<Filter>("upcoming")
  const meetings = useMemo(() => getMeetings(), [])

  const filtered = useMemo(() => {
    const list = meetings.filter(m => m.status === filter)
    return list.sort((a, b) => {
      // upcoming: soonest first; past: most recent first; cancelled: soonest first
      if (filter === "past") return b.start.localeCompare(a.start)
      return a.start.localeCompare(b.start)
    })
  }, [meetings, filter])

  const counts = {
    upcoming: meetings.filter(m => m.status === "upcoming").length,
    past: meetings.filter(m => m.status === "past").length,
    cancelled: meetings.filter(m => m.status === "cancelled").length,
  }

  const upcomingMinutes = meetings
    .filter(m => m.status === "upcoming")
    .reduce((s, m) => s + eventDurationMinutes(m.start, m.end), 0)

  const nextMeeting = filtered[0]

  return (
    <DashboardShell
      title="Meetings"
      description="All your meetings in one place — upcoming, past, and cancelled."
      actions={
        <Button asChild className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Link href="/calendar/create-event"><Plus className="w-4 h-4" /> Schedule meeting</Link>
        </Button>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Upcoming" value={counts.upcoming} hint="scheduled" icon={CalendarClock} />
        <StatCard label="Time in Meetings" value={formatDurationFromMin(upcomingMinutes)} hint="upcoming" icon={Clock} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Past" value={counts.past} hint="this period" icon={CheckCircle2} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Cancelled" value={counts.cancelled} hint="won't happen" icon={XCircle} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      {/* Next meeting banner */}
      {filter === "upcoming" && nextMeeting && (
        <Card className="p-4 md:p-5 mb-4 border-primary/30 bg-primary/5 card-lift animate-fade-in">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div className="flex items-start gap-3 min-w-0">
              <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                <Video className="w-5 h-5 text-primary" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] font-semibold text-primary uppercase tracking-wider">Next meeting</p>
                <h3 className="text-base font-semibold text-foreground mt-0.5">{nextMeeting.title}</h3>
                <div className="flex items-center gap-3 mt-1.5 text-xs text-muted-foreground flex-wrap">
                  <span className="inline-flex items-center gap-1"><Clock className="w-3 h-3" /> {relativeDay(nextMeeting.start)} · {formatTime(nextMeeting.start)}</span>
                  <span className="inline-flex items-center gap-1"><Users className="w-3 h-3" /> {nextMeeting.attendees.length} attendee{nextMeeting.attendees.length !== 1 ? "s" : ""}</span>
                  {nextMeeting.location && <span className="inline-flex items-center gap-1"><MapPin className="w-3 h-3" /> {nextMeeting.location}</span>}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {nextMeeting.meetingLink && (
                <Button size="sm" className="h-8 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                  <Link2 className="w-3.5 h-3.5" /> Join
                </Button>
              )}
              <Button asChild size="sm" variant="outline" className="h-8 text-xs bg-transparent">
                <Link href={`/calendar/events/${nextMeeting.id}`}>Details <ArrowRight className="w-3.5 h-3.5" /></Link>
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Filter tabs */}
      <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)} className="mb-4">
        <TabsList className="h-9 flex-wrap">
          <TabsTrigger value="upcoming" className="text-xs gap-1.5">
            Upcoming <span className="text-[10px] text-muted-foreground">{counts.upcoming}</span>
          </TabsTrigger>
          <TabsTrigger value="past" className="text-xs gap-1.5">
            Past <span className="text-[10px] text-muted-foreground">{counts.past}</span>
          </TabsTrigger>
          <TabsTrigger value="cancelled" className="text-xs gap-1.5">
            Cancelled <span className="text-[10px] text-muted-foreground">{counts.cancelled}</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Meeting list */}
      <div className="space-y-3">
        {filtered.length === 0 && (
          <Card className="p-12 text-center border-dashed">
            <CalendarClock className="w-10 h-10 mx-auto text-muted-foreground/60 mb-3" />
            <p className="text-sm font-medium text-foreground">No {filter} meetings</p>
            <p className="text-xs text-muted-foreground mt-1">
              {filter === "upcoming" ? "Schedule a meeting to get started." : `No ${filter} meetings in this period.`}
            </p>
          </Card>
        )}

        {filtered.map((m, idx) => {
          const cat = categoryConfig[m.category]
          const dur = eventDurationMinutes(m.start, m.end)
          const isCancelled = m.status === "cancelled"
          const isPast = m.status === "past"
          return (
            <Card
              key={m.id}
              className={cn(
                "p-4 card-lift animate-slide-in-up",
                isCancelled && "opacity-70",
              )}
              style={{ animationDelay: `${idx * 40}ms` }}
            >
              <div className="flex items-start gap-3 flex-wrap sm:flex-nowrap">
                {/* Date/time block */}
                <div className="w-14 shrink-0 text-center">
                  <p className="text-[10px] font-semibold text-muted-foreground uppercase">
                    {new Date(m.start).toLocaleDateString("en-US", { weekday: "short" })}
                  </p>
                  <p className="text-xl font-bold text-foreground tabular-nums leading-none mt-0.5">
                    {new Date(m.start).getDate()}
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    {new Date(m.start).toLocaleDateString("en-US", { month: "short" })}
                  </p>
                </div>

                {/* Divider */}
                <div className={cn("w-1 self-stretch rounded-full shrink-0", cat.dot)} />

                {/* Main content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div className="min-w-0">
                      <h4 className={cn(
                        "text-sm font-semibold text-foreground flex items-center gap-2",
                        (isCancelled || isPast) && "line-through text-muted-foreground"
                      )}>
                        {m.title}
                        {isCancelled && <XCircle className="w-3.5 h-3.5 text-rose-500" />}
                      </h4>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                        {m.description ?? "No agenda provided."}
                      </p>
                    </div>
                    <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0", cat.chip)}>
                      <cat.icon className="w-3 h-3" /> {cat.label}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 mt-2 flex-wrap text-[11px] text-muted-foreground">
                    <span className="inline-flex items-center gap-1 tabular-nums">
                      <Clock className="w-3 h-3" /> {formatTime(m.start)} – {formatTime(m.end)} · {formatDurationFromMin(dur)}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Users className="w-3 h-3" /> {m.attendees.length}
                    </span>
                    {m.location && (
                      <span className="inline-flex items-center gap-1 truncate max-w-[160px]">
                        {m.meetingLink ? <Video className="w-3 h-3" /> : <MapPin className="w-3 h-3" />}
                        <span className="truncate">{m.location}</span>
                      </span>
                    )}
                    {!isCancelled && !isPast && (
                      <span className="text-primary font-medium">{relativeDay(m.start)}</span>
                    )}
                  </div>

                  {/* Attendees */}
                  {m.attendees.length > 0 && (
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex -space-x-1.5">
                        {m.attendees.slice(0, 5).map((name, i) => (
                          <Avatar key={i} className="w-6 h-6 border-2 border-card">
                            {attendeeAvatar(name) ? <AvatarImage src={attendeeAvatar(name)} alt={name} /> : <AvatarFallback className="text-[8px]">{attendeeInitials(name)}</AvatarFallback>}
                          </Avatar>
                        ))}
                      </div>
                      {m.attendees.length > 5 && (
                        <span className="text-[10px] text-muted-foreground">+{m.attendees.length - 5} more</span>
                      )}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex sm:flex-col items-end gap-1.5 shrink-0">
                  {isCancelled ? (
                    <Button asChild variant="outline" size="sm" className="h-7 text-xs bg-transparent">
                      <Link href={`/calendar/events/${m.id}`}>Reschedule</Link>
                    </Button>
                  ) : isPast ? (
                    <Button asChild variant="ghost" size="sm" className="h-7 text-xs">
                      <Link href={`/calendar/events/${m.id}`}>Notes</Link>
                    </Button>
                  ) : (
                    <>
                      {m.meetingLink && (
                        <Button size="sm" className="h-7 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                          <Link2 className="w-3 h-3" /> Join
                        </Button>
                      )}
                      <Button asChild variant="outline" size="sm" className="h-7 text-xs bg-transparent">
                        <Link href={`/calendar/events/${m.id}`}>Details</Link>
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </Card>
          )
        })}
      </div>
    </DashboardShell>
  )
}
