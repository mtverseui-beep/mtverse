"use client"

import { useMemo, useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { StatCard } from "@/components/common/stat-card"
import { EmptyState } from "@/components/common/empty-state"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Megaphone, Pin, CheckCircle2, Bell, Users, Globe, Shield, Lock,
  Plus, Filter, Search, ChevronDown, Sparkles, Eye, Send,
} from "lucide-react"
import { announcements as seedAnnouncements, members, currentMember } from "@/lib/data/mock"
import { cn, timeAgo, formatDate, initials } from "@/lib/utils"
import { toast } from "sonner"
import type { Announcement } from "@/types"

// ============================================================
// SYNTHETIC EXTRA ANNOUNCEMENTS
// (mock only has 3 — add a few more so the timeline reads well)
// ============================================================

const extraAnnouncements: Announcement[] = [
  { id: "an4", title: "Q1 2026 All-hands — agenda posted", body: "Join us Feb 20 at 10:00 AM PT for the Q1 all-hands. We'll cover: roadmap, customer wins, hiring plan, and the SOC2 Type 2 timeline. Agenda doc linked in the comments.", author: "Zara Marlowe", authorAvatar: members[1].avatar, createdAt: "2026-01-21T09:00:00Z", pinned: false, audience: "All members", read: true },
  { id: "an5", title: "New: Sprint 47 retro notes available", body: "Action items: reduce WIP to 3 per column, automate Slack status updates, pair-program on WebSocket reconnect. Full notes in the wiki.", author: "Theo Nakamura", authorAvatar: members[2].avatar, createdAt: "2026-01-18T16:00:00Z", pinned: false, audience: "Engineering", read: true },
  { id: "an6", title: "Acme Corp contract renewed for 2026", body: "Excited to share that Acme renewed for another year — $480k ARR. Thanks to the customer success and engineering teams for a smooth Q4.", author: "Jessin Sam", authorAvatar: members[0].avatar, createdAt: "2026-01-15T11:30:00Z", pinned: false, audience: "All members", read: true },
  { id: "an7", title: "Mobile beta program — sign-ups open", body: "We're opening 50 internal beta slots for the Mobile Companion app (iOS + Android). Sign-up form below; first come, first served.", author: "Leon Cruz", authorAvatar: members[6].avatar, createdAt: "2026-01-12T14:00:00Z", pinned: false, audience: "All members", read: true },
  { id: "an8", title: "Maintenance window: Sun Jan 26, 02:00–03:00 UTC", body: "Brief read-only mode (~5 min) while we upgrade the database. Workspaces will display a maintenance banner. No data loss expected.", author: "Hugo Lindqvist", authorAvatar: members[8].avatar, createdAt: "2026-01-10T10:00:00Z", pinned: false, audience: "All members", read: true },
]

const allAnnouncements = [...extraAnnouncements, ...seedAnnouncements].sort(
  (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
)

// ============================================================
// AUDIENCE BADGE CONFIG
// ============================================================

const audienceConfig: Record<string, { icon: typeof Users; chip: string }> = {
  "All members":  { icon: Globe,  chip: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  "Admins":       { icon: Shield, chip: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
  "Engineering":  { icon: Users,  chip: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
  "Leadership":   { icon: Lock,   chip: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
}

function audienceBadge(audience: string) {
  const cfg = audienceConfig[audience] ?? { icon: Users, chip: "bg-muted text-muted-foreground" }
  return (
    <span className={cn("inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded", cfg.chip)}>
      <cfg.icon className="w-2.5 h-2.5" />
      {audience}
    </span>
  )
}

// ============================================================
// PAGE
// ============================================================

export default function AnnouncementsPage() {
  const [items, setItems] = useState<Announcement[]>(allAnnouncements)
  const [search, setSearch] = useState("")
  const [audienceFilter, setAudienceFilter] = useState("all")
  const [showUnreadOnly, setShowUnreadOnly] = useState(false)
  const [composeOpen, setComposeOpen] = useState(false)
  const [draft, setDraft] = useState({ title: "", body: "", audience: "All members" })

  const audiences = useMemo(() => {
    const set = new Set(items.map(a => a.audience))
    return Array.from(set)
  }, [items])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return items
      .filter(a => audienceFilter === "all" || a.audience === audienceFilter)
      .filter(a => !showUnreadOnly || !a.read)
      .filter(a => !q || a.title.toLowerCase().includes(q) || a.body.toLowerCase().includes(q))
      .sort((a, b) => {
        // Pinned first, then by date desc
        if (a.pinned !== b.pinned) return a.pinned ? -1 : 1
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      })
  }, [items, search, audienceFilter, showUnreadOnly])

  const pinned = filtered.filter(a => a.pinned)
  const regular = filtered.filter(a => !a.pinned)

  const markRead = (id: string) => {
    setItems(prev => prev.map(a => a.id === id ? { ...a, read: true } : a))
  }

  const acknowledge = (id: string, title: string) => {
    setItems(prev => prev.map(a => a.id === id ? { ...a, read: true } : a))
    toast.success("Acknowledged", { description: title })
  }

  const markAllRead = () => {
    setItems(prev => prev.map(a => ({ ...a, read: true })))
    toast.success("All announcements marked as read")
  }

  const handlePublish = () => {
    if (!draft.title.trim() || !draft.body.trim()) {
      toast.error("Title and body are required")
      return
    }
    const newAnn: Announcement = {
      id: `an-${Date.now()}`,
      title: draft.title.trim(),
      body: draft.body.trim(),
      author: currentMember.name,
      authorAvatar: currentMember.avatar,
      createdAt: new Date().toISOString(),
      pinned: false,
      audience: draft.audience,
      read: false,
    }
    setItems(prev => [newAnn, ...prev])
    setDraft({ title: "", body: "", audience: "All members" })
    setComposeOpen(false)
    toast.success("Announcement published", { description: `To ${newAnn.audience}` })
  }

  const unreadCount = items.filter(a => !a.read).length
  const pinnedCount = items.filter(a => a.pinned).length

  return (
    <DashboardShell
      title="Announcements"
      description="Company-wide updates, policy changes, and team milestones — all in one place."
      actions={
        <>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent" onClick={markAllRead}>
            <CheckCircle2 className="w-3.5 h-3.5" /> Mark all read
          </Button>
          <Button
            size="sm"
            className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={() => setComposeOpen(true)}
          >
            <Plus className="w-4 h-4" /> Compose
          </Button>
        </>
      }
    >
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Total announcements" value={items.length} hint="last 90 days" icon={Megaphone} />
        <StatCard label="Unread" value={unreadCount} hint="needs your attention" icon={Bell} iconColor="bg-primary/15 text-primary" />
        <StatCard label="Pinned" value={pinnedCount} hint="stickied at top" icon={Pin} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Audiences" value={audiences.length} hint="distinct groups" icon={Users} iconColor="bg-teal-500/15 text-teal-600 dark:text-teal-400" />
      </div>

      {/* Filter bar */}
      <Card className="p-3 md:p-4 mb-4">
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_auto] gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search announcements…"
              className="h-9 pl-8 text-xs"
            />
          </div>
          <Select value={audienceFilter} onValueChange={setAudienceFilter}>
            <SelectTrigger className="h-9 text-xs w-full md:w-[160px]">
              <SelectValue placeholder="All audiences" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All audiences</SelectItem>
              {audiences.map(a => (
                <SelectItem key={a} value={a}>{a}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant={showUnreadOnly ? "default" : "outline"}
            size="sm"
            className={cn("h-9 gap-1.5", showUnreadOnly ? "bg-primary text-primary-foreground" : "bg-transparent")}
            onClick={() => setShowUnreadOnly(v => !v)}
          >
            <Filter className="w-3.5 h-3.5" /> Unread only
          </Button>
        </div>
      </Card>

      {/* Pinned section */}
      {pinned.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Pin className="w-3.5 h-3.5 text-amber-500" />
            <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Pinned</span>
            <div className="flex-1 h-px bg-border" />
          </div>
          <div className="space-y-3">
            {pinned.map(a => (
              <AnnouncementCard
                key={a.id}
                announcement={a}
                onAcknowledge={() => acknowledge(a.id, a.title)}
                onMarkRead={() => markRead(a.id)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Regular announcements */}
      {regular.length === 0 && pinned.length === 0 ? (
        <EmptyState
          icon={Megaphone}
          title="No announcements match"
          description="Try a different search or filter. New announcements from your team will appear here."
          action={{ label: "Clear filters", onClick: () => { setSearch(""); setAudienceFilter("all"); setShowUnreadOnly(false) } }}
        />
      ) : regular.length === 0 ? (
        <Card className="p-8 text-center border-dashed">
          <p className="text-xs text-muted-foreground">No non-pinned announcements match your filters.</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {pinned.length > 0 && (
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">All announcements</span>
              <div className="flex-1 h-px bg-border" />
            </div>
          )}
          {regular.map((a, idx) => (
            <AnnouncementCard
              key={a.id}
              announcement={a}
              onAcknowledge={() => acknowledge(a.id, a.title)}
              onMarkRead={() => markRead(a.id)}
              index={idx}
            />
          ))}
        </div>
      )}

      {/* Load more */}
      {filtered.length > 0 && (
        <div className="mt-6 text-center">
          <Button variant="outline" size="sm" className="gap-1.5 bg-transparent">
            Load more <ChevronDown className="w-3.5 h-3.5" />
          </Button>
          <p className="text-[10px] text-muted-foreground mt-2 flex items-center justify-center gap-1">
            <Sparkles className="w-3 h-3" /> Showing {filtered.length} of {items.length} announcements
          </p>
        </div>
      )}

      {/* Compose dialog */}
      <Dialog open={composeOpen} onOpenChange={setComposeOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-primary" /> Compose announcement
            </DialogTitle>
            <DialogDescription>
              Share news, updates, or policy changes with your team. Recipients will see this in their announcements feed.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="ann-title" className="text-xs font-medium">Title</Label>
              <Input
                id="ann-title"
                value={draft.title}
                onChange={e => setDraft(d => ({ ...d, title: e.target.value }))}
                placeholder="e.g. Planna 2.5 is live — Calendar 2.0"
                className="text-sm"
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ann-body" className="text-xs font-medium">Body</Label>
              <Textarea
                id="ann-body"
                value={draft.body}
                onChange={e => setDraft(d => ({ ...d, body: e.target.value }))}
                placeholder="Write your announcement… Markdown supported."
                rows={6}
                className="text-sm resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Audience</Label>
                <Select value={draft.audience} onValueChange={v => setDraft(d => ({ ...d, audience: v }))}>
                  <SelectTrigger className="h-9 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All members">All members</SelectItem>
                    <SelectItem value="Admins">Admins</SelectItem>
                    <SelectItem value="Engineering">Engineering</SelectItem>
                    <SelectItem value="Leadership">Leadership</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Pin to top?</Label>
                <Select defaultValue="no">
                  <SelectTrigger className="h-9 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="no">No — show in chronological order</SelectItem>
                    <SelectItem value="yes">Yes — pin to top</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" size="sm" onClick={() => setComposeOpen(false)}>Cancel</Button>
            <Button size="sm" className="gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90" onClick={handlePublish}>
              <Send className="w-3.5 h-3.5" /> Publish
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardShell>
  )
}

// ============================================================
// ANNOUNCEMENT CARD
// ============================================================

function AnnouncementCard({
  announcement: a,
  onAcknowledge,
  onMarkRead,
  index = 0,
}: {
  announcement: Announcement
  onAcknowledge: () => void
  onMarkRead: () => void
  index?: number
}) {
  return (
    <Card
      className={cn(
        "p-4 md:p-5 card-lift animate-slide-in-up",
        a.pinned && "border-l-4 border-l-amber-500",
        !a.read && "bg-primary/[0.03]"
      )}
      style={{ animationDelay: `${index * 30}ms` }}
    >
      <div className="flex items-start gap-3">
        <Avatar className="w-10 h-10 ring-2 ring-card shrink-0">
          <AvatarImage src={a.authorAvatar} alt={a.author} />
          <AvatarFallback className="text-xs">{initials(a.author)}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-start justify-between gap-2 mb-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-bold text-foreground">{a.title}</h3>
              {a.pinned && (
                <Badge variant="outline" className="text-[10px] h-5 px-1.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30 gap-1">
                  <Pin className="w-2.5 h-2.5" /> Pinned
                </Badge>
              )}
              {audienceBadge(a.audience)}
              {!a.read && (
                <Badge variant="outline" className="text-[10px] h-5 px-1.5 bg-primary/10 text-primary border-primary/20">
                  New
                </Badge>
              )}
            </div>
            <span className="text-[10px] text-muted-foreground shrink-0 mt-0.5">{timeAgo(a.createdAt)}</span>
          </div>

          {/* Meta */}
          <p className="text-[11px] text-muted-foreground mb-2">
            by <span className="font-medium text-foreground">{a.author}</span> · {formatDate(a.createdAt, { month: "short", day: "numeric", year: "numeric" })}
          </p>

          {/* Body */}
          <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">{a.body}</p>

          {/* Footer */}
          <div className="flex items-center gap-1.5 mt-4 -ml-2">
            {!a.read ? (
              <>
                <Button
                  size="sm"
                  className="h-7 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
                  onClick={onAcknowledge}
                >
                  <CheckCircle2 className="w-3 h-3" /> Acknowledge
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 text-xs gap-1.5 text-muted-foreground"
                  onClick={onMarkRead}
                >
                  <Eye className="w-3 h-3" /> Mark as read
                </Button>
              </>
            ) : (
              <Badge variant="secondary" className="text-[10px] h-5 px-1.5 gap-1 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-2.5 h-2.5" /> Acknowledged
              </Badge>
            )}
            <Button variant="ghost" size="sm" className="h-7 text-xs gap-1.5 text-muted-foreground ml-auto">
              <Sparkles className="w-3 h-3" /> Discuss
            </Button>
          </div>
        </div>
      </div>
    </Card>
  )
}
