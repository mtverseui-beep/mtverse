"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  AtSign, MessageSquare, CalendarClock, UserCog, Sparkles, ShieldAlert,
  Mail, Bell, Smartphone, Monitor, Moon, Clock, Globe, Save, Check,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

const channels = [
  { key: "email", label: "Email", icon: Mail },
  { key: "in_app", label: "In-app", icon: Bell },
  { key: "mobile", label: "Mobile", icon: Smartphone },
  { key: "desktop", label: "Desktop", icon: Monitor },
]

const events = [
  { key: "mentions", label: "Mentions", icon: AtSign, desc: "When someone tags you with @" },
  { key: "comments", label: "Comments", icon: MessageSquare, desc: "Replies to tasks you watch or own" },
  { key: "deadlines", label: "Deadlines", icon: CalendarClock, desc: "Tasks due soon or overdue reminders" },
  { key: "assignments", label: "Assignments", icon: UserCog, desc: "When a task is assigned to you" },
  { key: "weekly_digest", label: "Weekly digest", icon: Sparkles, desc: "Summary of last week's activity" },
  { key: "security_alerts", label: "Security alerts", icon: ShieldAlert, desc: "Sign-ins, 2FA changes, key revocations" },
]

const defaultMatrix: Record<string, Record<string, boolean>> = {
  mentions:        { email: true,  in_app: true,  mobile: true,  desktop: true  },
  comments:        { email: false, in_app: true,  mobile: true,  desktop: false },
  deadlines:       { email: true,  in_app: true,  mobile: true,  desktop: true  },
  assignments:     { email: true,  in_app: true,  mobile: false, desktop: false },
  weekly_digest:   { email: true,  in_app: false, mobile: false, desktop: false },
  security_alerts: { email: true,  in_app: true,  mobile: true,  desktop: true  },
}

export default function NotificationsSettingsPage() {
  const [matrix, setMatrix] = useState(defaultMatrix)
  const [quietEnabled, setQuietEnabled] = useState(true)
  const [quietStart, setQuietStart] = useState("22:00")
  const [quietEnd, setQuietEnd] = useState("08:00")
  const [digest, setDigest] = useState("weekly")

  const toggle = (event: string, channel: string) => {
    setMatrix(prev => ({ ...prev, [event]: { ...prev[event], [channel]: !prev[event][channel] } }))
  }
  const activeCount = Object.values(matrix).flat().filter(Boolean).length
  const totalCells = events.length * channels.length

  return (
    <DashboardShell
      title="Notifications"
      description="Choose how Planna reaches you across email, in-app, mobile and desktop channels."
      actions={
        <Button
          size="sm"
          className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
          onClick={() => toast.success("Preferences saved", { description: `${activeCount}/${totalCells} channels active.` })}
        >
          <Save className="w-4 h-4" /> Save preferences
        </Button>
      }
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Matrix */}
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Channels by event type</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Toggle which channels receive each kind of event.</p>
            </div>
            <Badge variant="secondary" className="text-[10px] gap-1">
              <Check className="w-3 h-3" /> {activeCount}/{totalCells} active
            </Badge>
          </div>

          <div className="overflow-x-auto -mx-4 md:mx-0">
            <table className="w-full border-collapse min-w-[640px]">
              <thead>
                <tr>
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 pb-3 w-[40%]">
                    Event
                  </th>
                  {channels.map(ch => (
                    <th key={ch.key} className="px-2 pb-3">
                      <div className="flex flex-col items-center gap-1">
                        <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground">
                          <ch.icon className="w-4 h-4" />
                        </div>
                        <span className="text-[10px] font-medium text-foreground whitespace-nowrap">{ch.label}</span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {events.map(ev => (
                  <tr key={ev.key} className="border-t border-border">
                    <td className="px-3 py-3">
                      <div className="flex items-start gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0 mt-0.5">
                          <ev.icon className="w-3.5 h-3.5" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-foreground">{ev.label}</p>
                          <p className="text-[10px] text-muted-foreground mt-0.5 leading-snug">{ev.desc}</p>
                        </div>
                      </div>
                    </td>
                    {channels.map(ch => (
                      <td key={ch.key} className="px-2 py-3 text-center">
                        <div className="flex items-center justify-center">
                          <Switch
                            checked={matrix[ev.key][ch.key]}
                            onCheckedChange={() => toggle(ev.key, ch.key)}
                            aria-label={`${ev.label} via ${ch.label}`}
                          />
                        </div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Quiet hours */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start justify-between gap-3 mb-4">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-violet-500/15 text-violet-600 dark:text-violet-400 flex items-center justify-center shrink-0">
                <Moon className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">Quiet hours</h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Mute non-urgent notifications during rest or focus hours. Security alerts still come through.
                </p>
              </div>
            </div>
            <Switch checked={quietEnabled} onCheckedChange={setQuietEnabled} />
          </div>
          <div className={cn("grid grid-cols-1 sm:grid-cols-2 gap-3 transition-opacity", !quietEnabled && "opacity-50 pointer-events-none")}>
            <div className="space-y-1.5">
              <Label htmlFor="quiet-start" className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" /> Starts at
              </Label>
              <Input id="quiet-start" type="time" value={quietStart} onChange={e => setQuietStart(e.target.value)} className="h-9 text-sm" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="quiet-end" className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" /> Ends at
              </Label>
              <Input id="quiet-end" type="time" value={quietEnd} onChange={e => setQuietEnd(e.target.value)} className="h-9 text-sm" />
            </div>
          </div>
        </Card>

        {/* Digest frequency */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Digest frequency</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            How often Planna bundles your activity into a single summary email.
          </p>
          <Select value={digest} onValueChange={setDigest}>
            <SelectTrigger className="h-9 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="off">Off — no digest</SelectItem>
              <SelectItem value="daily">Daily — every morning at 8:00 AM</SelectItem>
              <SelectItem value="weekly">Weekly — Mondays at 8:00 AM</SelectItem>
              <SelectItem value="monthly">Monthly — first of each month</SelectItem>
            </SelectContent>
          </Select>
        </Card>

        <Separator />

        {/* Summary */}
        <Card className="p-5 md:p-6 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20 card-lift">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 rounded-md bg-primary text-primary-foreground flex items-center justify-center">
              <Bell className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-sm font-semibold text-foreground">Your summary</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <SummaryStat label="Active channels" value={`${activeCount}/${totalCells}`} />
            <SummaryStat label="Quiet hours" value={quietEnabled ? `${quietStart}–${quietEnd}` : "Off"} />
            <SummaryStat label="Digest" value={digest} />
            <SummaryStat label="Timezone" value="PT" />
          </div>
          <Button
            size="sm"
            className="w-full mt-4 h-8 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={() => toast.success("Preferences saved", { description: `${activeCount}/${totalCells} channels active.` })}
          >
            <Save className="w-3.5 h-3.5" /> Save preferences
          </Button>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}

function SummaryStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-2.5 rounded-lg bg-background/60 border border-border">
      <p className="text-[10px] text-muted-foreground capitalize">{label}</p>
      <p className="text-sm font-semibold text-foreground capitalize mt-0.5">{value}</p>
    </div>
  )
}
