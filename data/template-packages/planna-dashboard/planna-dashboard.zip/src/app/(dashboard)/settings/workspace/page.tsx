"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Building2, Camera, Save, Globe, LayoutGrid, Calendar, Users, Plus,
} from "lucide-react"
import { toast } from "sonner"
import { members } from "@/lib/data/mock"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
const HOLIDAYS_2026 = [
  { name: "New Year's Day", date: "2026-01-01" },
  { name: "MLK Day", date: "2026-01-19" },
  { name: "Presidents' Day", date: "2026-02-16" },
  { name: "Memorial Day", date: "2026-05-25" },
  { name: "Independence Day", date: "2026-07-04" },
  { name: "Labor Day", date: "2026-09-07" },
  { name: "Thanksgiving", date: "2026-11-26" },
  { name: "Christmas", date: "2026-12-25" },
]

export default function WorkspaceSettingsPage() {
  const [name, setName] = useState("Planna HQ")
  const [subdomain, setSubdomain] = useState("planna")
  const [defaultProject, setDefaultProject] = useState("p1")
  const [defaultView, setDefaultView] = useState("kanban")
  const [workingDays, setWorkingDays] = useState<Record<string, boolean>>({
    Mon: true, Tue: true, Wed: true, Thu: true, Fri: true, Sat: false, Sun: false,
  })
  const [startHour, setStartHour] = useState("09:00")
  const [endHour, setEndHour] = useState("18:00")

  const seatUsed = members.length
  const seatCapacity = 25

  return (
    <DashboardShell
      title="Workspace"
      description="Configure how your team works inside Planna — defaults, hours and capacity."
      actions={
        <Button
          size="sm"
          className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
          onClick={() => toast.success("Workspace saved", { description: "Changes apply to all members immediately." })}
        >
          <Save className="w-4 h-4" /> Save changes
        </Button>
      }
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Identity */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">Workspace identity</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Shown across Planna, in invites and the sidebar.</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-start gap-4">
            <div className="shrink-0">
              <Label className="text-xs font-medium text-muted-foreground mb-2 block">Logo</Label>
              <div className="relative">
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground flex items-center justify-center font-bold text-xl">
                  P
                </div>
                <button
                  type="button"
                  onClick={() => toast.info("Logo upload", { description: "PNG or SVG, max 512×512." })}
                  className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-foreground text-background flex items-center justify-center shadow-md hover:scale-105 transition-transform"
                  aria-label="Upload logo"
                >
                  <Camera className="w-3 h-3" />
                </button>
              </div>
            </div>
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="ws-name" className="text-xs font-medium text-muted-foreground">Workspace name</Label>
                <Input id="ws-name" value={name} onChange={e => setName(e.target.value)} className="h-9 text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ws-sub" className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                  <Globe className="w-3 h-3" /> Subdomain
                </Label>
                <div className="flex">
                  <Input
                    id="ws-sub"
                    value={subdomain}
                    onChange={e => setSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))}
                    className="h-9 text-sm rounded-r-none"
                  />
                  <span className="inline-flex items-center px-2.5 h-9 text-xs text-muted-foreground bg-secondary border border-l-0 border-input rounded-r-md whitespace-nowrap">
                    .planna.app
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-3 p-3 rounded-lg bg-secondary/40 border border-border flex items-start gap-2">
            <Globe className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
            <p className="text-[11px] text-muted-foreground">
              Your workspace URL: <span className="font-mono text-foreground">https://{subdomain}.planna.app</span>
            </p>
          </div>
        </Card>

        {/* Defaults */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <LayoutGrid className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">Defaults</h3>
              <p className="text-xs text-muted-foreground mt-0.5">What members see when they sign in or create new projects.</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Default project</Label>
              <Select value={defaultProject} onValueChange={setDefaultProject}>
                <SelectTrigger className="h-9 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="p1">Planna Web App</SelectItem>
                  <SelectItem value="p2">Mobile Companion</SelectItem>
                  <SelectItem value="p3">Public API Platform</SelectItem>
                  <SelectItem value="p4">Design System 2.0</SelectItem>
                  <SelectItem value="p5">Acme Client Project</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Default task view</Label>
              <Select value={defaultView} onValueChange={setDefaultView}>
                <SelectTrigger className="h-9 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="kanban">Kanban board</SelectItem>
                  <SelectItem value="list">List view</SelectItem>
                  <SelectItem value="timeline">Timeline</SelectItem>
                  <SelectItem value="calendar">Calendar</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Working hours */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">Working hours</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Used for scheduling, deadlines and capacity planning.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            <div className="space-y-1.5">
              <Label htmlFor="ws-start" className="text-xs font-medium text-muted-foreground">Start of day</Label>
              <Input id="ws-start" type="time" value={startHour} onChange={e => setStartHour(e.target.value)} className="h-9 text-sm" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ws-end" className="text-xs font-medium text-muted-foreground">End of day</Label>
              <Input id="ws-end" type="time" value={endHour} onChange={e => setEndHour(e.target.value)} className="h-9 text-sm" />
            </div>
          </div>

          <Label className="text-xs font-medium text-muted-foreground mb-2 block">Working days</Label>
          <div className="flex flex-wrap gap-2">
            {DAYS.map(d => {
              const on = workingDays[d]
              return (
                <button
                  key={d}
                  type="button"
                  onClick={() => setWorkingDays(prev => ({ ...prev, [d]: !on }))}
                  className={`h-9 px-3 rounded-lg text-xs font-medium border transition-all ${
                    on
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-card text-muted-foreground border-border hover:bg-secondary"
                  }`}
                >
                  {d}
                </button>
              )
            })}
          </div>
        </Card>

        {/* Holidays */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start justify-between mb-3 gap-3">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Holidays (2026)</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Days Planna automatically marks as non-working.</p>
            </div>
            <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-transparent">
              <Plus className="w-3.5 h-3.5" /> Add holiday
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {HOLIDAYS_2026.map(h => (
              <div
                key={h.date}
                className="flex items-center justify-between px-3 py-2 rounded-lg border border-border bg-card text-xs"
              >
                <span className="font-medium text-foreground">{h.name}</span>
                <span className="text-muted-foreground">{new Date(h.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Members & seats */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-violet-500/15 text-violet-600 dark:text-violet-400 flex items-center justify-center shrink-0">
              <Users className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm font-semibold text-foreground">Seats</h3>
                <Badge variant="secondary" className="text-[10px]">{seatUsed} / {seatCapacity} used</Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">Members in your workspace. Add or remove from the Team page.</p>
            </div>
          </div>

          <Progress value={(seatUsed / seatCapacity) * 100} className="h-2 mb-2" />
          <p className="text-[11px] text-muted-foreground mb-3">
            {seatCapacity - seatUsed} seats remaining on your current plan.
          </p>

          <div className="flex items-center -space-x-2 mb-1">
            {members.slice(0, 10).map(m => (
              <Avatar key={m.id} className="w-7 h-7 border-2 border-background">
                <AvatarFallback className="bg-primary/20 text-primary text-[10px]">
                  {m.name.split(" ").map(w => w[0]).join("").slice(0, 2)}
                </AvatarFallback>
              </Avatar>
            ))}
            {members.length > 10 && (
              <div className="w-7 h-7 rounded-full border-2 border-background bg-secondary text-muted-foreground text-[10px] flex items-center justify-center font-medium">
                +{members.length - 10}
              </div>
            )}
          </div>
          <Button variant="link" size="sm" className="h-7 px-0 text-xs text-primary" asChild>
            <a href="/team">Manage team →</a>
          </Button>
        </Card>

        <Separator />

        <div className="flex justify-end pb-2">
          <Button
            size="sm"
            className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={() => toast.success("Workspace saved", { description: "Changes apply to all members immediately." })}
          >
            <Save className="w-4 h-4" /> Save changes
          </Button>
        </div>
      </SettingsLayout>
    </DashboardShell>
  )
}
