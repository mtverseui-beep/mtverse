"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Receipt, Download, Eye, FileText, Search, Filter, TrendingUp, CalendarClock,
} from "lucide-react"
import { cn, formatCurrency, formatDate } from "@/lib/utils"
import { toast } from "sonner"
import { invoices } from "@/lib/data/mock"
import { SettingsLayout, SettingsMobileNav, ExportCSVButton } from "../_lib"

const statusConfig: Record<string, { label: string; className: string; dot: string }> = {
  paid: { label: "Paid", className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400", dot: "bg-emerald-500" },
  sent: { label: "Sent", className: "bg-sky-500/15 text-sky-600 dark:text-sky-400", dot: "bg-sky-500" },
  overdue: { label: "Overdue", className: "bg-rose-500/15 text-rose-600 dark:text-rose-400", dot: "bg-rose-500" },
  draft: { label: "Draft", className: "bg-muted text-muted-foreground", dot: "bg-muted-foreground" },
  cancelled: { label: "Cancelled", className: "bg-muted text-muted-foreground", dot: "bg-muted-foreground" },
}

export default function InvoicesSettingsPage() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filtered = invoices.filter(inv => {
    if (statusFilter !== "all" && inv.status !== statusFilter) return false
    if (search && !inv.number.toLowerCase().includes(search.toLowerCase()) && !inv.clientName.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const ytdSpent = invoices
    .filter(i => i.status === "paid")
    .reduce((sum, i) => sum + i.total, 0)
  const avgMonthly = Math.round(ytdSpent / 6)
  const overdueTotal = invoices
    .filter(i => i.status === "overdue")
    .reduce((sum, i) => sum + i.total, 0)

  return (
    <DashboardShell
      title="Invoices"
      description="Past invoices, statements and payment history. Download PDFs or export to CSV for accounting."
      actions={<ExportCSVButton rows={invoices.length} />}
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Summary cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-2">
              <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">YTD</span>
            </div>
            <p className="text-[11px] text-muted-foreground">Total spent</p>
            <p className="text-2xl font-bold text-foreground mt-1">{formatCurrency(ytdSpent)}</p>
            <p className="text-[10px] text-muted-foreground mt-1">Across {invoices.filter(i => i.status === "paid").length} paid invoices</p>
          </Card>
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-2">
              <div className="w-9 h-9 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                <CalendarClock className="w-4 h-4" />
              </div>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">6 mo avg</span>
            </div>
            <p className="text-[11px] text-muted-foreground">Avg monthly</p>
            <p className="text-2xl font-bold text-foreground mt-1">{formatCurrency(avgMonthly)}</p>
            <p className="text-[10px] text-muted-foreground mt-1">Trending up 12% vs H2 2025</p>
          </Card>
          <Card className="p-4 md:p-5 card-lift">
            <div className="flex items-center justify-between mb-2">
              <div className={cn(
                "w-9 h-9 rounded-lg flex items-center justify-center",
                overdueTotal > 0
                  ? "bg-rose-500/15 text-rose-600 dark:text-rose-400"
                  : "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
              )}>
                <Receipt className="w-4 h-4" />
              </div>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Outstanding</span>
            </div>
            <p className="text-[11px] text-muted-foreground">Overdue balance</p>
            <p className={cn("text-2xl font-bold mt-1", overdueTotal > 0 ? "text-rose-600 dark:text-rose-400" : "text-foreground")}>
              {formatCurrency(overdueTotal)}
            </p>
            <p className="text-[10px] text-muted-foreground mt-1">
              {overdueTotal > 0 ? "Pay now to avoid service interruption" : "All caught up"}
            </p>
          </Card>
        </div>

        {/* Filters + table */}
        <Card className="p-0 card-lift overflow-hidden">
          {/* Toolbar */}
          <div className="p-4 border-b border-border flex flex-col sm:flex-row sm:items-center gap-2">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search by number or client…"
                className="w-full h-9 pl-8 pr-3 text-xs rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-muted-foreground" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="h-9 w-[140px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse min-w-[720px]">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-4 py-2.5">
                    Invoice
                  </th>
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    Client
                  </th>
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    Issue date
                  </th>
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    Due date
                  </th>
                  <th className="text-right text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    Amount
                  </th>
                  <th className="text-center text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    Status
                  </th>
                  <th className="text-right text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-xs text-muted-foreground">
                      No invoices match your filters.
                    </td>
                  </tr>
                ) : (
                  filtered.map(inv => {
                    const status = statusConfig[inv.status]
                    return (
                      <tr key={inv.id} className="border-b border-border last:border-b-0 hover:bg-secondary/30 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground shrink-0">
                              <FileText className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-xs font-mono font-semibold text-foreground">{inv.number}</span>
                          </div>
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-2">
                            <Avatar className="w-6 h-6 rounded-md">
                              <AvatarImage src={inv.clientLogo} alt={inv.clientName} />
                              <AvatarFallback className="text-[9px] rounded-md">{inv.clientName[0]}</AvatarFallback>
                            </Avatar>
                            <span className="text-xs text-foreground">{inv.clientName}</span>
                          </div>
                        </td>
                        <td className="px-3 py-3 text-xs text-muted-foreground">{formatDate(inv.issueDate)}</td>
                        <td className="px-3 py-3 text-xs text-muted-foreground">
                          {formatDate(inv.dueDate)}
                          {inv.paidDate && (
                            <span className="block text-[10px] text-emerald-600 dark:text-emerald-400">
                              Paid {formatDate(inv.paidDate)}
                            </span>
                          )}
                        </td>
                        <td className="px-3 py-3 text-right">
                          <span className="text-xs font-semibold text-foreground">{formatCurrency(inv.total)}</span>
                          <span className="block text-[10px] text-muted-foreground">{formatCurrency(inv.amount)} + tax</span>
                        </td>
                        <td className="px-3 py-3 text-center">
                          <span className={cn("inline-flex items-center gap-1.5 text-[10px] font-semibold px-2 py-0.5 rounded-full", status.className)}>
                            <span className={cn("w-1.5 h-1.5 rounded-full", status.dot)} />
                            {status.label}
                          </span>
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7"
                              onClick={() => toast.info("Preview invoice", { description: `${inv.number} PDF preview would open here.` })}
                              aria-label="View invoice"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7"
                              onClick={() => toast.success("Download started", { description: `${inv.number}.pdf downloading…` })}
                              aria-label="Download invoice"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Footer */}
          <div className="p-3 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
            <span>Showing {filtered.length} of {invoices.length} invoices</span>
            <span>Total: {formatCurrency(filtered.reduce((s, i) => s + i.total, 0))}</span>
          </div>
        </Card>

        {/* Statement info */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <div className="flex-1">
              <p className="text-xs font-semibold text-foreground">Need a full statement?</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                Export all invoices from the last 12 months as a single PDF or CSV for your accountant.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent gap-1.5" onClick={() => toast.success("Statement generated", { description: "PDF sent to your email." })}>
                <FileText className="w-3.5 h-3.5" /> Annual statement
              </Button>
              <ExportCSVButton rows={invoices.length} />
            </div>
          </div>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}
