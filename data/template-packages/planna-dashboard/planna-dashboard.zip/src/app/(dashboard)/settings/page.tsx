"use client"

import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowRight, Sparkles, ShieldCheck, Zap } from "lucide-react"
import { currentMember } from "@/lib/data/mock"
import { SETTINGS_NAV_GROUPS, SettingsMobileNav, SettingsSidebar } from "./_lib"
import { cn, initials } from "@/lib/utils"

export default function SettingsIndexPage() {
  return (
    <DashboardShell
      title="Settings"
      description="Manage your account, workspace, security, billing and developer tools — all in one place."
    >
      <SettingsMobileNav />
      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4 lg:gap-6 animate-fade-in">
        <aside className="hidden lg:block">
          <div className="sticky top-4">
            <SettingsSidebar />
          </div>
        </aside>

        <div className="min-w-0 space-y-6">
          {/* Hero — current member snapshot */}
          <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <Avatar className="w-16 h-16 ring-2 ring-primary/30">
                <AvatarImage src={currentMember.avatar} alt={currentMember.name} />
                <AvatarFallback>{initials(currentMember.name)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg font-semibold text-foreground">{currentMember.name}</h2>
                  <Badge className="bg-primary/15 text-primary capitalize">{currentMember.role}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {currentMember.title} · {currentMember.department} · {currentMember.location}
                </p>
                <p className="text-xs text-muted-foreground mt-1">{currentMember.email}</p>
              </div>
              <Button asChild size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 h-9 gap-1.5">
                <Link href="/settings/profile">
                  Edit profile <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </Button>
            </div>
          </Card>

          {/* Quick links — recommended actions */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Card className="p-4 card-lift">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-foreground">Enable 2FA</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                    Add a second layer of protection to your account.
                  </p>
                  <Button asChild variant="link" size="sm" className="h-6 px-0 mt-1 text-primary text-xs">
                    <Link href="/settings/security">Set up →</Link>
                  </Button>
                </div>
              </div>
            </Card>
            <Card className="p-4 card-lift">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-foreground">Upgrade to Scale</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                    Unlock unlimited projects, SSO and audit logs.
                  </p>
                  <Button asChild variant="link" size="sm" className="h-6 px-0 mt-1 text-primary text-xs">
                    <Link href="/settings/subscription">View plans →</Link>
                  </Button>
                </div>
              </div>
            </Card>
            <Card className="p-4 card-lift">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-violet-500/15 text-violet-600 dark:text-violet-400 flex items-center justify-center shrink-0">
                  <Zap className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-foreground">Create an API key</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                    Automate Planna from your scripts and CI pipelines.
                  </p>
                  <Button asChild variant="link" size="sm" className="h-6 px-0 mt-1 text-primary text-xs">
                    <Link href="/settings/api-keys">Get started →</Link>
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* All categories grid */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-foreground">All settings</h3>
              <span className="text-xs text-muted-foreground">
                {SETTINGS_NAV_GROUPS.reduce((n, g) => n + g.items.length, 0)} sections
              </span>
            </div>

            <div className="space-y-6">
              {SETTINGS_NAV_GROUPS.map(group => (
                <div key={group.title}>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2.5">
                    {group.title}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                    {group.items.map(item => {
                      const Icon = item.icon
                      return (
                        <Card
                          key={item.href}
                          className="p-4 card-lift group cursor-pointer"
                        >
                          <Link href={item.href} className="flex items-start gap-3">
                            <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0 transition-transform group-hover:scale-110">
                              <Icon className="w-4 h-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-2">
                                <p className="text-xs font-semibold text-foreground">{item.label}</p>
                                <ArrowRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
                              </div>
                              <p className="text-[11px] text-muted-foreground mt-1 leading-snug">
                                {item.description}
                              </p>
                            </div>
                          </Link>
                        </Card>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Help footer */}
          <Card className={cn(
            "p-4 md:p-5 border-dashed flex flex-col sm:flex-row sm:items-center gap-3",
          )}>
            <div className="flex-1">
              <p className="text-xs font-semibold text-foreground">Need help configuring your workspace?</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                Browse the docs or contact support — we typically reply in under 2 hours.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                <Link href="/help/docs">Documentation</Link>
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                <Link href="/help/contact">Contact support</Link>
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
