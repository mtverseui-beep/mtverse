"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Webhook, Plus, Send, Trash2, Pencil, Link2, Check, Clock, Zap, Loader2, AlertCircle,
} from "lucide-react"
import { cn, timeAgo, formatDate } from "@/lib/utils"
import { toast } from "sonner"
import { webhooks as initialWebhooks } from "@/lib/data/mock"
import { SettingsLayout, SettingsMobileNav } from "../_lib"
import type { Webhook as WH } from "@/types"

const ALL_EVENTS = [
  { key: "task.created", label: "Task created" },
  { key: "task.updated", label: "Task updated" },
  { key: "task.completed", label: "Task completed" },
  { key: "task.deleted", label: "Task deleted" },
  { key: "project.created", label: "Project created" },
  { key: "project.updated", label: "Project updated" },
  { key: "project.archived", label: "Project archived" },
  { key: "member.invited", label: "Member invited" },
  { key: "member.removed", label: "Member removed" },
  { key: "comment.posted", label: "Comment posted" },
]

export default function WebhooksSettingsPage() {
  const [hooks, setHooks] = useState<WH[]>(initialWebhooks)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<WH | null>(null)
  const [formUrl, setFormUrl] = useState("")
  const [formEvents, setFormEvents] = useState<string[]>(["task.created"])
  const [formActive, setFormActive] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testingId, setTestingId] = useState<string | null>(null)

  const openCreate = () => {
    setEditing(null)
    setFormUrl("")
    setFormEvents(["task.created"])
    setFormActive(true)
    setDialogOpen(true)
  }
  const openEdit = (h: WH) => {
    setEditing(h)
    setFormUrl(h.url)
    setFormEvents(h.events)
    setFormActive(h.active)
    setDialogOpen(true)
  }

  const save = () => {
    if (!formUrl.trim()) {
      toast.error("URL required")
      return
    }
    if (!/^https?:\/\/.+/.test(formUrl.trim())) {
      toast.error("Invalid URL", { description: "Must start with http:// or https://" })
      return
    }
    if (formEvents.length === 0) {
      toast.error("Select at least one event")
      return
    }
    setSaving(true)
    setTimeout(() => {
      if (editing) {
        setHooks(prev => prev.map(h => h.id === editing.id ? { ...h, url: formUrl, events: formEvents, active: formActive } : h))
        toast.success("Webhook updated")
      } else {
        const newHook: WH = {
          id: `wh${Date.now()}`,
          url: formUrl,
          events: formEvents,
          active: formActive,
          createdAt: new Date().toISOString(),
        }
        setHooks(prev => [newHook, ...prev])
        toast.success("Webhook added")
      }
      setSaving(false)
      setDialogOpen(false)
    }, 600)
  }

  const toggleActive = (id: string) => {
    setHooks(prev => prev.map(h => h.id === id ? { ...h, active: !h.active } : h))
  }

  const del = (id: string) => {
    setHooks(prev => prev.filter(h => h.id !== id))
    toast.success("Webhook deleted")
  }

  const test = (h: WH) => {
    setTestingId(h.id)
    setTimeout(() => {
      setTestingId(null)
      toast.success("Test event sent", { description: `POST → ${h.url}` })
    }, 900)
  }

  const toggleEvent = (ev: string) => {
    setFormEvents(prev => prev.includes(ev) ? prev.filter(e => e !== ev) : [...prev, ev])
  }

  const active = hooks.filter(h => h.active)
  const inactive = hooks.filter(h => !h.active)

  return (
    <DashboardShell
      title="Webhooks"
      description="Outbound event delivery to your services. Planna sends a signed POST request when subscribed events fire."
      actions={
        <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90" onClick={openCreate}>
          <Plus className="w-4 h-4" /> Add webhook
        </Button>
      }
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <StatMini label="Total" value={hooks.length} icon={Webhook} color="bg-primary/10 text-primary" />
          <StatMini label="Active" value={active.length} icon={Zap} color="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
          <StatMini label="Paused" value={inactive.length} icon={AlertCircle} color="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        </div>

        {/* Active */}
        <Card className="p-5 md:p-6 card-lift">
          <h3 className="text-sm font-semibold text-foreground mb-4">Webhooks</h3>

          {hooks.length === 0 ? (
            <div className="text-center py-10">
              <Webhook className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-xs font-medium text-foreground">No webhooks yet</p>
              <p className="text-[11px] text-muted-foreground mt-1">Add your first webhook to receive event notifications.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {hooks.map(h => (
                <div key={h.id} className="rounded-lg border border-border bg-card p-4 hover:shadow-sm transition-shadow">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <div className={cn(
                        "w-9 h-9 rounded-lg flex items-center justify-center shrink-0",
                        h.active ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-muted text-muted-foreground",
                      )}>
                        <Webhook className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <a href={h.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-xs font-mono text-foreground hover:text-primary">
                            <Link2 className="w-3 h-3" />
                            {h.url}
                          </a>
                          {h.active ? (
                            <Badge variant="secondary" className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Active
                            </Badge>
                          ) : (
                            <Badge variant="secondary" className="text-[10px] bg-amber-500/15 text-amber-600 dark:text-amber-400 gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Paused
                            </Badge>
                          )}
                        </div>

                        <div className="mt-2 flex flex-wrap gap-1">
                          {h.events.map(ev => (
                            <Badge key={ev} variant="secondary" className="text-[10px] font-mono bg-secondary text-foreground">
                              {ev}
                            </Badge>
                          ))}
                        </div>

                        <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-muted-foreground">
                          <span>Created {formatDate(h.createdAt)}</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" /> Last fired {h.lastFired ? timeAgo(h.lastFired) : "never"}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="flex items-center gap-1.5 px-2">
                        <Switch checked={h.active} onCheckedChange={() => toggleActive(h.id)} aria-label="Toggle active" />
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 text-xs gap-1 bg-transparent"
                        onClick={() => test(h)}
                        disabled={testingId === h.id}
                      >
                        {testingId === h.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                        Test
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(h)} aria-label="Edit webhook">
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10" aria-label="Delete webhook">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete webhook?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Planna will stop sending events to <span className="font-mono text-foreground">{h.url}</span>. This cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              onClick={() => del(h.id)}
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Separator />

        {/* Help */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground">How webhooks work</p>
              <ul className="mt-2 space-y-1.5 text-[11px] text-muted-foreground">
                <li className="flex items-start gap-2"><Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /> Planna POSTs JSON to your URL with an HMAC-SHA256 signature in the <code className="font-mono">X-Planna-Signature</code> header.</li>
                <li className="flex items-start gap-2"><Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /> Verify the signature with your webhook secret before processing the payload.</li>
                <li className="flex items-start gap-2"><Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /> Respond with a 2xx status within 10 seconds. Failed deliveries retry with exponential backoff for up to 24 hours.</li>
              </ul>
              <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent mt-3" asChild>
                <a href="/help/docs">Webhook guide →</a>
              </Button>
            </div>
          </div>
        </Card>
      </SettingsLayout>

      {/* Create / edit dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit webhook" : "Add webhook"}</DialogTitle>
            <DialogDescription>
              Planna will deliver subscribed events to the URL below.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="wh-url" className="text-xs font-medium text-muted-foreground">Endpoint URL</Label>
              <Input
                id="wh-url"
                value={formUrl}
                onChange={e => setFormUrl(e.target.value)}
                placeholder="https://example.com/webhooks/planna"
                className="h-9 text-sm font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">Events to subscribe</Label>
              <div className="space-y-1 max-h-44 overflow-y-auto scroll-area-thin rounded-lg border border-border p-2">
                {ALL_EVENTS.map(ev => (
                  <label key={ev.key} className="flex items-center gap-2 px-1 py-1 cursor-pointer hover:bg-secondary/40 rounded">
                    <Checkbox
                      checked={formEvents.includes(ev.key)}
                      onCheckedChange={() => toggleEvent(ev.key)}
                    />
                    <span className="text-xs text-foreground">{ev.label}</span>
                    <code className="ml-auto text-[10px] font-mono text-muted-foreground">{ev.key}</code>
                  </label>
                ))}
              </div>
              <p className="text-[10px] text-muted-foreground">{formEvents.length} event{formEvents.length === 1 ? "" : "s"} selected</p>
            </div>

            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <p className="text-xs font-semibold text-foreground">Active</p>
                <p className="text-[11px] text-muted-foreground">Paused webhooks receive no events.</p>
              </div>
              <Switch checked={formActive} onCheckedChange={setFormActive} />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" size="sm" className="h-9 bg-transparent" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
              onClick={save}
              disabled={saving}
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              {saving ? "Saving…" : editing ? "Save changes" : "Add webhook"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardShell>
  )
}

function StatMini({
  label, value, icon: Icon, color,
}: {
  label: string
  value: number
  icon: typeof Webhook
  color: string
}) {
  return (
    <Card className="p-3 md:p-4 card-lift">
      <div className="flex items-center gap-2">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", color)}>
          <Icon className="w-3.5 h-3.5" />
        </div>
        <div>
          <p className="text-lg font-bold text-foreground leading-none">{value}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">{label}</p>
        </div>
      </div>
    </Card>
  )
}
