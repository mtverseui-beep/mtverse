"use client"

import { useState, useEffect } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Check, Sun, Moon, Monitor, Sparkles, Zap, Type, Rows3, MoveRight, Wind } from "lucide-react"
import { cn } from "@/lib/utils"
import { useTheme } from "next-themes"
import { toast } from "sonner"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

const ACCENTS = [
  { key: "emerald", label: "Emerald", color: "bg-emerald-500" },
  { key: "teal", label: "Teal", color: "bg-teal-500" },
  { key: "lime", label: "Lime", color: "bg-lime-500" },
  { key: "green", label: "Forest", color: "bg-green-600" },
  { key: "cyan", label: "Cyan", color: "bg-cyan-500" },
  { key: "mint", label: "Mint", color: "bg-emerald-400" },
]

const FONT_SIZES = [
  { key: "sm", label: "Compact", desc: "13px", sample: "text-[13px]" },
  { key: "md", label: "Default", desc: "14px", sample: "text-sm" },
  { key: "lg", label: "Comfortable", desc: "15px", sample: "text-[15px]" },
]

const DENSITIES = [
  { key: "comfortable", label: "Comfortable", desc: "More padding, easier to scan" },
  { key: "compact", label: "Compact", desc: "Tighter spacing, more on screen" },
]

export default function AppearanceSettingsPage() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [accent, setAccent] = useState("emerald")
  const [fontSize, setFontSize] = useState("md")
  const [density, setDensity] = useState("comfortable")
  const [reduceMotion, setReduceMotion] = useState(false)

  // Track mount to avoid SSR/CSR theme mismatch (standard next-themes pattern)
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true)
  }, [])

  const themes = [
    { key: "light", label: "Light", icon: Sun, desc: "Bright and crisp" },
    { key: "dark", label: "Dark", icon: Moon, desc: "Easy on the eyes at night" },
    { key: "system", label: "System", icon: Monitor, desc: "Follow OS preference" },
  ]

  return (
    <DashboardShell
      title="Appearance"
      description="Customize how Planna looks across your devices — changes sync instantly to your other sessions."
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Theme picker */}
        <Card className="p-5 md:p-6 card-lift">
          <h3 className="text-sm font-semibold text-foreground mb-1">Theme</h3>
          <p className="text-xs text-muted-foreground mb-4">Choose your default appearance. System follows your OS setting.</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {themes.map(t => {
              const active = mounted && theme === t.key
              const Icon = t.icon
              return (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => setTheme(t.key)}
                  className={cn(
                    "relative text-left rounded-xl border p-3 transition-all",
                    active
                      ? "border-primary ring-2 ring-primary/20 bg-primary/5"
                      : "border-border hover:border-primary/40 hover:bg-secondary/40",
                  )}
                >
                  <ThemePreview themeKey={t.key} />
                  <div className="mt-3 flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                    <p className="text-xs font-semibold text-foreground">{t.label}</p>
                    {active && <Check className="w-3.5 h-3.5 text-primary ml-auto" />}
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{t.desc}</p>
                </button>
              )
            })}
          </div>
        </Card>

        {/* Accent color */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Accent color</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-4">Used for buttons, links, focus rings and highlights.</p>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {ACCENTS.map(a => {
              const active = accent === a.key
              return (
                <button
                  key={a.key}
                  type="button"
                  onClick={() => {
                    setAccent(a.key)
                    toast.success(`Accent: ${a.label}`, { description: "Preview only — your theme stays green for now." })
                  }}
                  className={cn(
                    "flex flex-col items-center gap-2 p-2 rounded-lg border transition-all",
                    active ? "border-primary ring-2 ring-primary/20" : "border-border hover:bg-secondary/40",
                  )}
                >
                  <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", a.color)}>
                    {active && <Check className="w-4 h-4 text-white" />}
                  </div>
                  <span className="text-[10px] font-medium text-foreground">{a.label}</span>
                </button>
              )
            })}
          </div>
        </Card>

        {/* Font size */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center gap-2 mb-1">
            <Type className="w-3.5 h-3.5 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Font size</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-4">Adjust base text size for readability.</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {FONT_SIZES.map(f => {
              const active = fontSize === f.key
              return (
                <button
                  key={f.key}
                  type="button"
                  onClick={() => setFontSize(f.key)}
                  className={cn(
                    "text-left rounded-lg border p-3 transition-all",
                    active ? "border-primary ring-2 ring-primary/20 bg-primary/5" : "border-border hover:bg-secondary/40",
                  )}
                >
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-semibold text-foreground">{f.label}</p>
                    {active && <Check className="w-3.5 h-3.5 text-primary" />}
                  </div>
                  <p className={cn("text-muted-foreground", f.sample)}>The quick brown fox</p>
                  <p className="text-[10px] text-muted-foreground mt-1">{f.desc}</p>
                </button>
              )
            })}
          </div>
        </Card>

        {/* Density */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center gap-2 mb-1">
            <Rows3 className="w-3.5 h-3.5 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Density</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-4">How tightly information is packed on list and table views.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {DENSITIES.map(d => {
              const active = density === d.key
              return (
                <button
                  key={d.key}
                  type="button"
                  onClick={() => setDensity(d.key)}
                  className={cn(
                    "text-left rounded-lg border p-3 transition-all",
                    active ? "border-primary ring-2 ring-primary/20 bg-primary/5" : "border-border hover:bg-secondary/40",
                  )}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-semibold text-foreground">{d.label}</p>
                    {active && <Check className="w-3.5 h-3.5 text-primary" />}
                  </div>
                  <p className="text-[10px] text-muted-foreground mb-2">{d.desc}</p>
                  {/* Mini preview rows */}
                  <div className={cn("space-y-1", d.key === "compact" && "space-y-0.5")}>
                    <div className="h-2 rounded-full bg-secondary" />
                    <div className="h-2 w-3/4 rounded-full bg-secondary" />
                    <div className={cn("h-2 w-1/2 rounded-full bg-secondary", d.key === "comfortable" && "mt-2")} />
                  </div>
                </button>
              )
            })}
          </div>
        </Card>

        {/* Reduce motion */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                <Wind className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">Reduce motion</h3>
                <p className="text-xs text-muted-foreground mt-0.5 max-w-md">
                  Minimize animations and transitions across Planna. Respects your OS-level reduce-motion preference.
                </p>
              </div>
            </div>
            <Switch checked={reduceMotion} onCheckedChange={setReduceMotion} />
          </div>
          {reduceMotion && (
            <div className="mt-3 p-3 rounded-lg bg-secondary/40 border border-border flex items-start gap-2">
              <MoveRight className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
              <p className="text-[11px] text-muted-foreground">
                Animations will be replaced with instant state changes. Useful on low-power devices or for vestibular comfort.
              </p>
            </div>
          )}
        </Card>

        {/* Live preview */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">Live preview</h3>
            </div>
            <Badge variant="secondary" className="text-[10px]">Sample</Badge>
          </div>
          <div className="rounded-xl border border-border overflow-hidden">
            <div className="bg-background p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-foreground">Sprint 48 — Polishing</p>
                  <p className="text-[11px] text-muted-foreground">12 tasks · 4 in review</p>
                </div>
                <Button size="sm" className="h-8 text-xs bg-primary text-primary-foreground hover:bg-primary/90 gap-1">
                  <Sparkles className="w-3 h-3" /> New
                </Button>
              </div>
              <div className="space-y-1.5">
                {["Implement command palette", "Ship dark mode toggle", "Refactor webhook retry logic"].map(t => (
                  <div key={t} className="flex items-center gap-2 p-2 rounded-lg border border-border bg-card">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    <span className={cn(
                      "text-foreground",
                      fontSize === "sm" && "text-[13px]",
                      fontSize === "md" && "text-sm",
                      fontSize === "lg" && "text-[15px]",
                    )}>{t}</span>
                    <span className="ml-auto text-[10px] text-muted-foreground">2h</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground mt-3">
            Theme: <span className="font-medium text-foreground capitalize">{mounted ? theme : "system"}</span> ·
            Accent: <span className="font-medium text-foreground capitalize">{accent}</span> ·
            Density: <span className="font-medium text-foreground capitalize">{density}</span>
          </p>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}

function ThemePreview({ themeKey }: { themeKey: string }) {
  const isDark = themeKey === "dark"
  const isSystem = themeKey === "system"
  return (
    <div
      className={cn(
        "rounded-lg border h-20 overflow-hidden relative",
        isDark ? "bg-zinc-900 border-zinc-700" : isSystem ? "bg-gradient-to-r from-white to-zinc-900 border-border" : "bg-white border-border",
      )}
    >
      <div className="flex h-full">
        <div className={cn("w-1/3 border-r", isDark ? "bg-zinc-800 border-zinc-700" : isSystem ? "bg-zinc-100" : "bg-zinc-50", "border-border")}>
          <div className="p-2 space-y-1">
            <div className={cn("h-1 w-6 rounded-full", isDark ? "bg-zinc-600" : "bg-zinc-300")} />
            <div className={cn("h-1 w-8 rounded-full", isDark ? "bg-zinc-700" : "bg-zinc-200")} />
            <div className="h-1 w-5 rounded-full bg-primary" />
          </div>
        </div>
        <div className="flex-1 p-2 space-y-1.5">
          <div className={cn("h-1.5 w-12 rounded-full", isDark ? "bg-zinc-600" : "bg-zinc-300")} />
          <div className="h-4 rounded bg-primary/20 border border-primary/40 flex items-center px-1">
            <div className="h-1 w-6 rounded-full bg-primary" />
          </div>
          <div className={cn("h-1.5 w-10 rounded-full", isDark ? "bg-zinc-700" : "bg-zinc-200")} />
          <div className={cn("h-1.5 w-8 rounded-full", isDark ? "bg-zinc-700" : "bg-zinc-200")} />
        </div>
      </div>
    </div>
  )
}
