"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  ShieldCheck, ShieldAlert, QrCode, Copy, RefreshCw, Key, Smartphone,
  Lock, Download, Check, AlertTriangle, Clock, Eye,
} from "lucide-react"
import { cn, initials, timeAgo } from "@/lib/utils"
import { toast } from "sonner"
import { currentMember } from "@/lib/data/mock"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

const SECURITY_EVENTS = [
  { id: "se1", type: "signin", title: "New sign-in from Chrome on macOS", ip: "203.0.113.42 · San Francisco, US", time: "2026-02-18T09:14:00Z", icon: Smartphone, level: "info" },
  { id: "se2", type: "twofa", title: "Two-factor authentication enabled", ip: "203.0.113.42 · San Francisco, US", time: "2026-02-15T18:02:00Z", icon: ShieldCheck, level: "success" },
  { id: "se3", type: "password", title: "Password changed", ip: "203.0.113.42 · San Francisco, US", time: "2026-01-12T11:48:00Z", icon: Key, level: "info" },
  { id: "se4", type: "key", title: "API key revoked: pk_live_77de", ip: "203.0.113.78 · Tokyo, JP", time: "2026-02-13T14:22:00Z", icon: ShieldAlert, level: "warning" },
  { id: "se5", type: "signin", title: "Failed sign-in attempt", ip: "198.51.100.7 · Unknown", time: "2026-02-10T03:11:00Z", icon: AlertTriangle, level: "warning" },
]

const BACKUP_CODES = [
  "7H3K-9P2Q", "MN4X-8B5C", "R2JW-6T9Y", "K8PL-3F7D",
  "V5QX-2H8N", "Z9MR-4C1L", "B6YT-7G3S", "W1FA-9E4D",
  "P8KJ-5N2R", "T3XC-6V9M",
]

export default function SecuritySettingsPage() {
  const [twofaEnabled, setTwofaEnabled] = useState(true)
  const [codesVisible, setCodesVisible] = useState(false)
  const [revealedCodes, setRevealedCodes] = useState(false)

  return (
    <DashboardShell
      title="Security"
      description="Manage two-factor authentication, backup codes and review recent security activity on your account."
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* 2FA */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start justify-between gap-3 mb-4">
            <div className="flex items-start gap-3">
              <div className={cn(
                "w-9 h-9 rounded-lg flex items-center justify-center shrink-0",
                twofaEnabled ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-amber-500/15 text-amber-600 dark:text-amber-400",
              )}>
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-foreground">Two-factor authentication</h3>
                  <Badge className={cn(
                    "gap-1",
                    twofaEnabled
                      ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
                      : "bg-amber-500/15 text-amber-600 dark:text-amber-400",
                  )}>
                    {twofaEnabled ? <><Check className="w-3 h-3" /> Enabled</> : "Disabled"}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {twofaEnabled
                    ? "Codes from your authenticator app are required at sign-in."
                    : "Add a second layer of protection to your account."}
                </p>
              </div>
            </div>
            <Switch checked={twofaEnabled} onCheckedChange={v => {
              setTwofaEnabled(v)
              toast.success(v ? "2FA enabled" : "2FA disabled", {
                description: v ? "Your account is now protected with 2FA." : "We strongly recommend re-enabling 2FA.",
              })
            }} />
          </div>

          {twofaEnabled ? (
            <div className="grid grid-cols-1 md:grid-cols-[200px_1fr] gap-5">
              {/* QR placeholder */}
              <div className="flex flex-col items-center text-center">
                <div className="w-40 h-40 rounded-xl border-2 border-dashed border-border bg-secondary/30 flex items-center justify-center relative">
                  <QrCode className="w-24 h-24 text-muted-foreground/60" />
                  <div className="absolute inset-0 grid grid-cols-8 grid-rows-8 gap-px p-2 opacity-30">
                    {Array.from({ length: 64 }).map((_, i) => (
                      <div key={i} className={cn("rounded-[1px]", (i * 7 + 3) % 3 === 0 && "bg-foreground")} />
                    ))}
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground mt-2">Scan with Google Authenticator, 1Password or Authy</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 mt-2 text-[11px] gap-1 bg-transparent"
                  onClick={() => toast.info("Setup key", { description: "Manual code copied to clipboard." })}
                >
                  <Copy className="w-3 h-3" /> Copy setup key
                </Button>
              </div>

              {/* Steps */}
              <div className="space-y-3">
                <Step n={1} title="Install an authenticator app" desc="Google Authenticator, 1Password, Authy or Bitwarden all work." />
                <Step n={2} title="Scan the QR code" desc="Or enter the setup key manually if your device has no camera." />
                <Step n={3} title="Enter the 6-digit code" desc="Verify the code from your app to complete setup." />
                <div className="flex flex-wrap gap-2 pt-1">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs gap-1.5 bg-transparent"
                    onClick={() => toast.success("New QR generated", { description: "Re-scan with your authenticator app." })}
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Regenerate QR
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs gap-1.5 bg-transparent"
                    onClick={() => toast.info("Disable 2FA", { description: "You'd be asked to enter your password first." })}
                  >
                    <Lock className="w-3.5 h-3.5" /> Disable 2FA
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setTwofaEnabled(true)}>
              <ShieldCheck className="w-4 h-4" /> Enable 2FA
            </Button>
          )}
        </Card>

        {/* Backup codes */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                <Key className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">Backup codes</h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  10 one-time codes — each works once when you can't access your authenticator.
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-8 text-xs gap-1 bg-transparent"
              onClick={() => toast.success("New backup codes generated", { description: "Old codes are now invalid." })}
            >
              <RefreshCw className="w-3.5 h-3.5" /> Regenerate
            </Button>
          </div>

          <div className="rounded-xl border border-border p-4 bg-secondary/20">
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {BACKUP_CODES.map((code, i) => (
                <div
                  key={i}
                  className="px-2 py-2 rounded-md bg-background border border-border text-center font-mono text-xs text-foreground tracking-wider"
                >
                  {revealedCodes ? code : "••••••••"}
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-2 mt-3">
              <Button
                variant="outline"
                size="sm"
                className="h-8 text-xs gap-1 bg-transparent"
                onClick={() => setRevealedCodes(r => !r)}
              >
                <Eye className="w-3.5 h-3.5" /> {revealedCodes ? "Hide codes" : "Reveal codes"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="h-8 text-xs gap-1 bg-transparent"
                onClick={() => toast.success("Backup codes downloaded", { description: "Saved as planna-backup-codes.txt" })}
              >
                <Download className="w-3.5 h-3.5" /> Download
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-xs gap-1"
                onClick={() => {
                  navigator.clipboard?.writeText(BACKUP_CODES.join("\n"))
                  toast.success("Copied to clipboard")
                }}
              >
                <Copy className="w-3.5 h-3.5" /> Copy all
              </Button>
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground mt-2 flex items-start gap-1">
            <AlertTriangle className="w-3 h-3 mt-0.5 shrink-0" />
            Store these somewhere safe. Anyone with a code can bypass 2FA on your account.
          </p>
        </Card>

        {/* Password last changed */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">Password</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Last changed 38 days ago.</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5" asChild>
              <a href="/settings/account">Change password</a>
            </Button>
          </div>
        </Card>

        {/* Recent security events */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Recent security events</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Last 30 days of account activity.</p>
            </div>
            <Button variant="link" size="sm" className="h-7 text-xs text-primary" asChild>
              <a href="/settings/sessions">View all sessions →</a>
            </Button>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto scroll-area-thin">
            {SECURITY_EVENTS.map(ev => {
              const Icon = ev.icon
              return (
                <div key={ev.id} className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card hover:bg-secondary/40 transition-colors">
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                    ev.level === "success" && "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
                    ev.level === "info" && "bg-sky-500/15 text-sky-600 dark:text-sky-400",
                    ev.level === "warning" && "bg-amber-500/15 text-amber-600 dark:text-amber-400",
                  )}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-foreground">{ev.title}</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{ev.ip}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground whitespace-nowrap">{timeAgo(ev.time)}</span>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Active sessions count */}
        <Card className="p-5 md:p-6 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20 card-lift">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Avatar className="w-12 h-12 ring-2 ring-primary/30">
                <AvatarImage src={currentMember.avatar} alt={currentMember.name} />
                <AvatarFallback>{initials(currentMember.name)}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-sm font-semibold text-foreground">3 active sessions</h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Across macOS, iOS and Chrome (Windows). 1 current, 2 others.
                </p>
              </div>
            </div>
            <Button size="sm" className="h-9 bg-primary text-primary-foreground hover:bg-primary/90" asChild>
              <a href="/settings/sessions">Manage sessions</a>
            </Button>
          </div>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}

function Step({ n, title, desc }: { n: number; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center shrink-0">
        {n}
      </div>
      <div>
        <p className="text-xs font-semibold text-foreground">{title}</p>
        <p className="text-[11px] text-muted-foreground mt-0.5">{desc}</p>
      </div>
    </div>
  )
}
