"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  MessageSquare, Github, Calendar, Figma, ArrowLeftRight, Zap,
  FileText, Video, Check, Settings2, Plug, Sparkles, Loader2,
} from "lucide-react"
import { cn, formatDate, timeAgo } from "@/lib/utils"
import { toast } from "sonner"
import { integrations as initialIntegrations } from "@/lib/data/mock"
import { SettingsLayout, SettingsMobileNav } from "../_lib"
import type { Integration } from "@/types"

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  MessageSquare,
  Github,
  Calendar,
  Figma,
  ArrowLeftRight,
  Zap,
  FileText,
  Video,
}

const ICON_COLORS: Record<string, string> = {
  Slack: "bg-violet-500/15 text-violet-600 dark:text-violet-400",
  GitHub: "bg-zinc-900 text-white dark:bg-zinc-700",
  "Google Calendar": "bg-sky-500/15 text-sky-600 dark:text-sky-400",
  Figma: "bg-pink-500/15 text-pink-600 dark:text-pink-400",
  Linear: "bg-indigo-500/15 text-indigo-600 dark:text-indigo-400",
  Zapier: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  Notion: "bg-zinc-700 text-white",
  Loom: "bg-rose-500/15 text-rose-600 dark:text-rose-400",
}

export default function IntegrationsSettingsPage() {
  const [integrations, setIntegrations] = useState<Integration[]>(initialIntegrations)
  const [category, setCategory] = useState("All")
  const [connecting, setConnecting] = useState<string | null>(null)

  const categories = ["All", ...Array.from(new Set(initialIntegrations.map(i => i.category)))]

  const filtered = category === "All"
    ? integrations
    : integrations.filter(i => i.category === category)

  const toggleConnect = (id: string) => {
    setConnecting(id)
    setTimeout(() => {
      setIntegrations(prev => prev.map(i => i.id === id ? {
        ...i,
        connected: !i.connected,
        installedAt: !i.connected ? new Date().toISOString() : i.installedAt,
      } : i))
      setConnecting(null)
      const integ = integrations.find(i => i.id === id)
      if (integ) {
        toast.success(
          integ.connected ? `${integ.name} disconnected` : `${integ.name} connected`,
          { description: integ.connected ? "You can reconnect anytime." : "Sync may take a few minutes." }
        )
      }
    }, 800)
  }

  const connectedCount = integrations.filter(i => i.connected).length

  return (
    <DashboardShell
      title="Integrations"
      description="Connect Planna to your favorite tools — Slack, GitHub, Google Calendar and many more."
      actions={
        <Badge variant="secondary" className="text-[10px] h-9 px-3 gap-1.5">
          <Plug className="w-3.5 h-3.5" /> {connectedCount} connected
        </Badge>
      }
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Hero */}
        <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">Connect your stack</h3>
              <p className="text-xs text-muted-foreground mt-1 max-w-md">
                Browse {integrations.length} integrations across {categories.length - 1} categories. New connections sync
                instantly and can be revoked from here at any time.
              </p>
            </div>
          </div>
        </Card>

        {/* Category filter */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {categories.map(c => {
            const active = category === c
            const count = c === "All" ? integrations.length : integrations.filter(i => i.category === c).length
            return (
              <button
                key={c}
                type="button"
                onClick={() => setCategory(c)}
                className={cn(
                  "h-8 px-3 rounded-lg text-xs font-medium border transition-all",
                  active
                    ? "bg-primary text-primary-foreground border-primary shadow-sm"
                    : "bg-card text-muted-foreground border-border hover:text-foreground hover:bg-secondary",
                )}
              >
                {c} <span className={cn("ml-1", active ? "opacity-80" : "opacity-60")}>({count})</span>
              </button>
            )
          })}
        </div>

        {/* Integrations grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
          {filtered.map(integ => {
            const Icon = ICONS[integ.icon] ?? Plug
            const colorClass = ICON_COLORS[integ.name] ?? "bg-primary/15 text-primary"
            const isConnecting = connecting === integ.id
            return (
              <Card key={integ.id} className="p-4 md:p-5 card-lift group flex flex-col">
                <div className="flex items-start gap-3 mb-3">
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", colorClass)}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-semibold text-foreground">{integ.name}</p>
                      {integ.connected && (
                        <Badge variant="secondary" className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
                          <Check className="w-3 h-3" /> Connected
                        </Badge>
                      )}
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{integ.category}</p>
                  </div>
                </div>

                <p className="text-[11px] text-muted-foreground leading-snug flex-1 mb-3">
                  {integ.description}
                </p>

                {integ.connected && integ.installedAt && (
                  <p className="text-[10px] text-muted-foreground mb-3 flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> Connected {timeAgo(integ.installedAt)}
                  </p>
                )}

                <div className="flex gap-2">
                  {integ.connected ? (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 text-xs gap-1.5 bg-transparent flex-1"
                        onClick={() => toast.info(`${integ.name} settings`, { description: "Per-integration settings panel would open here." })}
                      >
                        <Settings2 className="w-3.5 h-3.5" /> Configure
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 text-xs gap-1.5 bg-transparent text-destructive hover:text-destructive hover:bg-destructive/10"
                        onClick={() => toggleConnect(integ.id)}
                        disabled={isConnecting}
                      >
                        Disconnect
                      </Button>
                    </>
                  ) : (
                    <Button
                      size="sm"
                      className="h-8 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90 flex-1"
                      onClick={() => toggleConnect(integ.id)}
                      disabled={isConnecting}
                    >
                      {isConnecting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plug className="w-3.5 h-3.5" />}
                      {isConnecting ? "Connecting…" : "Connect"}
                    </Button>
                  )}
                </div>
              </Card>
            )
          })}
        </div>

        {/* Connected summary */}
        {connectedCount > 0 && (
          <Card className="p-5 md:p-6 card-lift">
            <h3 className="text-sm font-semibold text-foreground mb-3">Connected integrations</h3>
            <div className="space-y-2">
              {integrations.filter(i => i.connected).map(integ => {
                const Icon = ICONS[integ.icon] ?? Plug
                const colorClass = ICON_COLORS[integ.name] ?? "bg-primary/15 text-primary"
                return (
                  <div key={integ.id} className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card">
                    <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", colorClass)}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-foreground">{integ.name}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        Connected {integ.installedAt ? formatDate(integ.installedAt) : "—"}
                      </p>
                    </div>
                    <Button variant="link" size="sm" className="h-7 text-xs text-primary" onClick={() => toast.info(`${integ.name} settings`, { description: "Settings panel would open here." })}>
                      Manage
                    </Button>
                  </div>
                )
              })}
            </div>
          </Card>
        )}

        {/* Request integration */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex items-start gap-3">
            <Avatar className="w-9 h-9 rounded-lg bg-primary/15 text-primary">
              <AvatarFallback className="bg-transparent text-primary">
                <Sparkles className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="text-xs font-semibold text-foreground">Don't see your tool?</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                We add new integrations every month. Vote on the roadmap or build your own using our REST API and webhooks.
              </p>
              <div className="flex gap-2 mt-2">
                <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" onClick={() => toast.success("Vote submitted", { description: "Thanks! We'll prioritize popular requests." })}>
                  Vote on roadmap
                </Button>
                <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                  <a href="/settings/api-keys">Build with API →</a>
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}
