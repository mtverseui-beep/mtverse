"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard, User, Settings, Building2, Monitor, Bell, Shield,
  History, CreditCard, Sparkles, Receipt, KeyRound, Webhook, Blocks,
  ScrollText, Download,
} from "lucide-react"
import type { LucideIcon } from "lucide-react"

// ============================================================
// SETTINGS NAVIGATION — vertical sidebar grouped by section
// ============================================================

export interface SettingsNavItem {
  href: string
  label: string
  icon: LucideIcon
  description: string
}

export interface SettingsNavGroup {
  title: string
  items: SettingsNavItem[]
}

export const SETTINGS_NAV_GROUPS: SettingsNavGroup[] = [
  {
    title: "Personal",
    items: [
      { href: "/settings/profile", label: "Profile", icon: User, description: "Your name, avatar, bio and social links" },
      { href: "/settings/account", label: "Account", icon: Settings, description: "Email, password and connected accounts" },
      { href: "/settings/appearance", label: "Appearance", icon: Monitor, description: "Theme, accent color and density" },
      { href: "/settings/notifications", label: "Notifications", icon: Bell, description: "Channels, quiet hours and digest" },
    ],
  },
  {
    title: "Workspace",
    items: [
      { href: "/settings/workspace", label: "Workspace", icon: Building2, description: "Workspace name, logo and defaults" },
      { href: "/settings/integrations", label: "Integrations", icon: Blocks, description: "Connect Slack, GitHub and 5,000+ apps" },
      { href: "/settings/audit-logs", label: "Audit Logs", icon: ScrollText, description: "Track every workspace change" },
    ],
  },
  {
    title: "Security",
    items: [
      { href: "/settings/security", label: "Security", icon: Shield, description: "2FA, backup codes and recent events" },
      { href: "/settings/sessions", label: "Sessions", icon: History, description: "Active devices and sign-in history" },
    ],
  },
  {
    title: "Billing",
    items: [
      { href: "/settings/billing", label: "Billing", icon: CreditCard, description: "Plan, usage and payment method" },
      { href: "/settings/subscription", label: "Subscription", icon: Sparkles, description: "Compare and change plans" },
      { href: "/settings/invoices", label: "Invoices", icon: Receipt, description: "Past invoices and statements" },
    ],
  },
  {
    title: "Developer",
    items: [
      { href: "/settings/api-keys", label: "API Keys", icon: KeyRound, description: "Manage programmatic access tokens" },
      { href: "/settings/webhooks", label: "Webhooks", icon: Webhook, description: "Outbound event delivery endpoints" },
    ],
  },
]

// Flat list (used for the index landing grid)
export const ALL_SETTINGS_ITEMS: SettingsNavItem[] = SETTINGS_NAV_GROUPS.flatMap(g => g.items)

// ============================================================
// SETTINGS SIDEBAR NAV — left vertical nav, sticky on desktop
// ============================================================

export function SettingsSidebar({ className }: { className?: string }) {
  const pathname = usePathname()
  return (
    <nav className={cn("w-full", className)}>
      <ScrollArea className="h-full">
        <div className="space-y-5 pr-1">
          {/* Home link */}
          <Link
            href="/settings"
            className={cn(
              "flex items-center gap-2 px-3 h-9 rounded-lg text-xs font-medium transition-colors",
              pathname === "/settings"
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary",
            )}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            Overview
          </Link>

          {SETTINGS_NAV_GROUPS.map(group => (
            <div key={group.title}>
              <p className="px-3 mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                {group.title}
              </p>
              <div className="space-y-0.5">
                {group.items.map(item => {
                  const active = pathname === item.href
                  const Icon = item.icon
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        "flex items-center gap-2 px-3 h-9 rounded-lg text-xs font-medium transition-all",
                        active
                          ? "bg-primary text-primary-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                      )}
                    >
                      <Icon className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </Link>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </nav>
  )
}

// ============================================================
// SETTINGS PAGE LAYOUT — sticky sidebar + main content
// ============================================================

export function SettingsLayout({
  sidebar,
  children,
}: {
  sidebar?: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4 lg:gap-6 animate-fade-in">
      <aside className="hidden lg:block">
        <div className="sticky top-4 max-h-[calc(100vh-2rem)]">
          <SettingsSidebar />
          {sidebar}
        </div>
      </aside>
      <div className="min-w-0 space-y-4">{children}</div>
    </div>
  )
}

// ============================================================
// MOBILE SETTINGS NAV — horizontal pill nav, scrollable
// ============================================================

export function SettingsMobileNav() {
  const pathname = usePathname()
  return (
    <nav className="lg:hidden -mx-1 mb-3 overflow-x-auto no-scrollbar">
      <div className="flex items-center gap-1 px-1 min-w-max">
        <Link
          href="/settings"
          className={cn(
            "inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
            pathname === "/settings"
              ? "bg-primary text-primary-foreground"
              : "bg-card border border-border text-muted-foreground hover:text-foreground",
          )}
        >
          <LayoutDashboard className="w-3.5 h-3.5" />
          Overview
        </Link>
        {ALL_SETTINGS_ITEMS.map(item => {
          const active = pathname === item.href
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                active
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-card border border-border text-muted-foreground hover:text-foreground",
              )}
            >
              <Icon className="w-3.5 h-3.5" />
              {item.label}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

// ============================================================
// EXPORT CSV — stub that fires a toast
// ============================================================

export function ExportCSVButton({ label = "Export CSV", rows = 0 }: { label?: string; rows?: number }) {
  return (
    <Button
      variant="outline"
      className="h-9 text-sm gap-1.5 bg-transparent"
      onClick={() => {
        if (typeof window !== "undefined") {
          import("sonner").then(({ toast }) =>
            toast.success("Export started", {
              description: rows
                ? `${rows} rows downloading as CSV…`
                : "Your export is downloading as CSV…",
            }),
          )
        }
      }}
    >
      <Download className="w-4 h-4" /> {label}
    </Button>
  )
}
