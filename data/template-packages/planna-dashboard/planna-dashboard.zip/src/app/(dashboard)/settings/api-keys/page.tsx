"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  KeyRound, Plus, Copy, Eye, EyeOff, Trash2, ShieldAlert, Check, Clock, Loader2, Sparkles,
} from "lucide-react"
import { cn, timeAgo, formatDate } from "@/lib/utils"
import { toast } from "sonner"
import { apiKeys as initialKeys } from "@/lib/data/mock"
import { SettingsLayout, SettingsMobileNav } from "../_lib"
import type { ApiKey } from "@/types"

const SCOPE_LABELS: Record<string, string> = {
  "tasks:read": "Tasks: read",
  "tasks:write": "Tasks: write",
  "projects:read": "Projects: read",
  "projects:write": "Projects: write",
  "analytics:read": "Analytics: read",
  "webhooks:write": "Webhooks: write",
}
const ALL_SCOPES = Object.keys(SCOPE_LABELS)

export default function ApiKeysSettingsPage() {
  const [keys, setKeys] = useState<ApiKey[]>(initialKeys)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [newKeyName, setNewKeyName] = useState("")
  const [newKeyScopes, setNewKeyScopes] = useState<string[]>(["tasks:read"])
  const [creating, setCreating] = useState(false)
  const [revealed, setRevealed] = useState<Record<string, boolean>>({})
  const [justCreated, setJustCreated] = useState<string | null>(null)

  const activeKeys = keys.filter(k => !k.revoked)
  const revokedKeys = keys.filter(k => k.revoked)

  const createKey = () => {
    if (!newKeyName.trim()) {
      toast.error("Name required", { description: "Give your key a descriptive name." })
      return
    }
    if (newKeyScopes.length === 0) {
      toast.error("Select at least one scope")
      return
    }
    setCreating(true)
    setTimeout(() => {
      const prefix = `pk_live_${Math.random().toString(36).slice(2, 6)}`
      const fullKey = `pk_live_${Math.random().toString(36).slice(2, 12)}${Math.random().toString(36).slice(2, 12)}${Math.random().toString(36).slice(2, 12)}`
      const newKey: ApiKey = {
        id: `ak${Date.now()}`,
        name: newKeyName.trim(),
        prefix,
        created: new Date().toISOString(),
        lastUsed: undefined,
        scopes: newKeyScopes,
        revoked: false,
      }
      setKeys(prev => [newKey, ...prev])
      setJustCreated(fullKey)
      setCreating(false)
      setNewKeyName("")
      setNewKeyScopes(["tasks:read"])
    }, 700)
  }

  const revokeKey = (id: string) => {
    setKeys(prev => prev.map(k => k.id === id ? { ...k, revoked: true } : k))
    toast.success("API key revoked", { description: "Requests using this key will fail immediately." })
  }

  const toggleScope = (scope: string) => {
    setNewKeyScopes(prev => prev.includes(scope) ? prev.filter(s => s !== scope) : [...prev, scope])
  }

  return (
    <DashboardShell
      title="API Keys"
      description="Programmatic access tokens for the Planna REST API. Treat keys like passwords — they grant full access to the scopes they hold."
      actions={
        <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) setJustCreated(null) }}>
          <DialogTrigger asChild>
            <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="w-4 h-4" /> Create new key
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{justCreated ? "Key created" : "Create new API key"}</DialogTitle>
              <DialogDescription>
                {justCreated
                  ? "Copy your key now — you won't be able to see it again."
                  : "Generate a new key with the scopes you need. You can revoke it later."}
              </DialogDescription>
            </DialogHeader>

            {justCreated ? (
              <div className="space-y-3">
                <div className="rounded-lg border border-emerald-500/40 bg-emerald-500/10 p-3">
                  <p className="text-[10px] uppercase tracking-wider text-emerald-600 dark:text-emerald-400 font-semibold mb-1.5">
                    Your new API key
                  </p>
                  <code className="block text-xs font-mono text-foreground break-all">
                    {justCreated}
                  </code>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs gap-1 bg-transparent flex-1"
                    onClick={() => { navigator.clipboard?.writeText(justCreated); toast.success("API key copied to clipboard") }}
                  >
                    <Copy className="w-3.5 h-3.5" /> Copy key
                  </Button>
                  <Button
                    size="sm"
                    className="h-8 text-xs bg-primary text-primary-foreground hover:bg-primary/90"
                    onClick={() => { setDialogOpen(false); setJustCreated(null) }}
                  >
                    Done
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground flex items-start gap-1.5">
                  <ShieldAlert className="w-3 h-3 mt-0.5 shrink-0" />
                  Store this key in a secrets manager. Planna will never display it again.
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="new-key-name" className="text-xs font-medium text-muted-foreground">Key name</Label>
                    <Input
                      id="new-key-name"
                      value={newKeyName}
                      onChange={e => setNewKeyName(e.target.value)}
                      placeholder="e.g. Production Server"
                      className="h-9 text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-medium text-muted-foreground">Scopes</Label>
                    <div className="space-y-1.5 max-h-44 overflow-y-auto scroll-area-thin rounded-lg border border-border p-2">
                      {ALL_SCOPES.map(scope => (
                        <label key={scope} className="flex items-center gap-2 px-1 py-1 cursor-pointer hover:bg-secondary/40 rounded">
                          <Checkbox
                            checked={newKeyScopes.includes(scope)}
                            onCheckedChange={() => toggleScope(scope)}
                          />
                          <span className="text-xs text-foreground">{SCOPE_LABELS[scope]}</span>
                        </label>
                      ))}
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      {newKeyScopes.length} scope{newKeyScopes.length === 1 ? "" : "s"} selected
                    </p>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" size="sm" className="h-9 bg-transparent" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
                    onClick={createKey}
                    disabled={creating}
                  >
                    {creating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <KeyRound className="w-3.5 h-3.5" />}
                    {creating ? "Generating…" : "Generate key"}
                  </Button>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>
      }
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Active keys */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Active keys</h3>
              <p className="text-xs text-muted-foreground mt-0.5">{activeKeys.length} keys can authenticate API requests.</p>
            </div>
            <Badge variant="secondary" className="text-[10px]">{activeKeys.length} active</Badge>
          </div>

          <div className="space-y-2">
            {activeKeys.map(k => {
              const isRevealed = revealed[k.id]
              return (
                <div key={k.id} className="rounded-lg border border-border bg-card p-4 hover:shadow-sm transition-shadow">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <KeyRound className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-xs font-semibold text-foreground">{k.name}</p>
                          <code className="text-[10px] font-mono text-muted-foreground bg-secondary px-1.5 py-0.5 rounded">
                            {k.prefix}••••••••••••
                          </code>
                          <button
                            type="button"
                            onClick={() => setRevealed(prev => ({ ...prev, [k.id]: !prev[k.id] }))}
                            className="text-muted-foreground hover:text-foreground"
                            aria-label={isRevealed ? "Hide key" : "Show key"}
                          >
                            {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        {isRevealed && (
                          <div className="mt-2 p-2 rounded bg-secondary/60 border border-border">
                            <code className="text-[11px] font-mono text-foreground break-all">
                              {k.prefix}•••••••••••••••••••••••••••••••••••••••••
                            </code>
                            <p className="text-[10px] text-muted-foreground mt-1">
                              Full key hidden for security. Rotate this key if it leaks.
                            </p>
                          </div>
                        )}

                        <div className="mt-2 flex flex-wrap gap-1">
                          {k.scopes.map(s => (
                            <Badge key={s} variant="secondary" className="text-[10px] font-mono bg-primary/10 text-primary">
                              {s}
                            </Badge>
                          ))}
                        </div>

                        <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-muted-foreground">
                          <span>Created {formatDate(k.created)}</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" /> Last used {k.lastUsed ? timeAgo(k.lastUsed) : "never"}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => { navigator.clipboard?.writeText(`${k.prefix}••••`); toast.success("Key prefix copied") }}
                        aria-label="Copy key prefix"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10" aria-label="Revoke key">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Revoke "{k.name}"?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Any service using this key will immediately fail to authenticate. This cannot be undone — you'll need to generate a new key and update all consumers.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              onClick={() => revokeKey(k.id)}
                            >
                              Yes, revoke key
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Revoked keys */}
        {revokedKeys.length > 0 && (
          <Card className="p-5 md:p-6 card-lift opacity-70">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-foreground">Revoked keys</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Kept for audit history. No longer functional.</p>
              </div>
              <Badge variant="secondary" className="text-[10px] bg-muted text-muted-foreground">{revokedKeys.length} revoked</Badge>
            </div>
            <div className="space-y-2">
              {revokedKeys.map(k => (
                <div key={k.id} className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card">
                  <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground shrink-0">
                    <KeyRound className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-muted-foreground line-through">{k.name}</p>
                    <code className="text-[10px] font-mono text-muted-foreground">{k.prefix}••••</code>
                  </div>
                  <Badge variant="secondary" className="text-[10px] bg-rose-500/15 text-rose-600 dark:text-rose-400 gap-1">
                    <ShieldAlert className="w-3 h-3" /> Revoked
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        )}

        <Separator />

        {/* Safety / docs */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex items-start gap-3 mb-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground">API best practices</p>
              <ul className="mt-2 space-y-1.5 text-[11px] text-muted-foreground">
                <li className="flex items-start gap-2"><Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /> Use the narrowest scopes possible — never request write access you don't need.</li>
                <li className="flex items-start gap-2"><Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /> Rotate keys every 90 days, and immediately if a key leaks.</li>
                <li className="flex items-start gap-2"><Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /> Store keys in a secrets manager (Vault, AWS Secrets Manager, Doppler).</li>
                <li className="flex items-start gap-2"><Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /> Never commit keys to Git. Use environment variables.</li>
              </ul>
              <div className="flex gap-2 mt-3">
                <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                  <a href="/help/docs">API documentation</a>
                </Button>
                <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                  <a href="/settings/webhooks">Webhooks settings</a>
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}
