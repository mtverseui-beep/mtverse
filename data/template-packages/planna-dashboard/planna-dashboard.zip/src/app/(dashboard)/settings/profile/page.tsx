"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Save, RotateCcw, Camera, Globe, Linkedin, Twitter, Github, Link2, AtSign, MapPin,
} from "lucide-react"
import { toast } from "sonner"
import { currentMember } from "@/lib/data/mock"
import { initials } from "@/lib/utils"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

export default function ProfileSettingsPage() {
  const [name, setName] = useState(currentMember.name)
  const [email] = useState(currentMember.email)
  const [title, setTitle] = useState(currentMember.title)
  const [bio, setBio] = useState(
    "Building Planna — a calmer way to run projects. Previously @ Linear and Stripe. Coffee + climbing.",
  )
  const [location, setLocation] = useState(currentMember.location)
  const [timezone, setTimezone] = useState(currentMember.timezone)
  const [website, setWebsite] = useState("https://planna.app")
  const [twitter, setTwitter] = useState("jessinsam")
  const [linkedin, setLinkedin] = useState("jessinsam")
  const [github, setGithub] = useState("jessinsam")

  const handleSave = () => {
    toast.success("Profile saved", { description: "Your changes are now live across Planna." })
  }
  const handleReset = () => {
    setName(currentMember.name)
    setTitle(currentMember.title)
    setBio("")
    setLocation(currentMember.location)
    setTimezone(currentMember.timezone)
    setWebsite("https://planna.app")
    setTwitter("jessinsam")
    setLinkedin("jessinsam")
    setGithub("jessinsam")
    toast.info("Changes reverted", { description: "Form reset to last saved state." })
  }

  return (
    <DashboardShell
      title="Profile"
      description="Your public profile and personal information — visible to teammates and clients you collaborate with."
      actions={
        <>
          <Button variant="ghost" size="sm" className="h-9 gap-1.5" onClick={handleReset}>
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </Button>
          <Button
            size="sm"
            className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={handleSave}
          >
            <Save className="w-4 h-4" /> Save changes
          </Button>
        </>
      }
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Avatar + display name */}
        <Card className="p-5 md:p-6 card-lift">
          <h3 className="text-sm font-semibold text-foreground mb-1">Avatar & identity</h3>
          <p className="text-xs text-muted-foreground mb-4">
            Used across Planna, in mentions, comments and activity feeds.
          </p>
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="relative shrink-0">
              <Avatar className="w-20 h-20 ring-2 ring-primary/20">
                <AvatarImage src={currentMember.avatar} alt={name} />
                <AvatarFallback>{initials(name)}</AvatarFallback>
              </Avatar>
              <button
                type="button"
                onClick={() => toast.info("Avatar upload", { description: "Image picker would open here." })}
                className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-md hover:bg-primary/90 transition-colors"
                aria-label="Upload new avatar"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="profile-name" className="text-xs font-medium text-muted-foreground">Full name</Label>
                <Input id="profile-name" value={name} onChange={e => setName(e.target.value)} className="h-9 text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="profile-title" className="text-xs font-medium text-muted-foreground">Title</Label>
                <Input id="profile-title" value={title} onChange={e => setTitle(e.target.value)} className="h-9 text-sm" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="profile-email" className="text-xs font-medium text-muted-foreground">Email</Label>
                <Input id="profile-email" value={email} disabled className="h-9 text-sm text-muted-foreground" />
                <p className="text-[10px] text-muted-foreground">Manage your email address in Account settings.</p>
              </div>
            </div>
          </div>
        </Card>

        {/* About */}
        <Card className="p-5 md:p-6 card-lift">
          <h3 className="text-sm font-semibold text-foreground mb-1">About</h3>
          <p className="text-xs text-muted-foreground mb-4">A short bio shown on your profile card.</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-3 space-y-1.5">
              <Label htmlFor="profile-bio" className="text-xs font-medium text-muted-foreground">Bio</Label>
              <Textarea
                id="profile-bio"
                value={bio}
                onChange={e => setBio(e.target.value)}
                rows={3}
                maxLength={240}
                className="text-sm resize-none"
                placeholder="Tell your teammates a little about yourself…"
              />
              <p className="text-[10px] text-muted-foreground text-right">{bio.length} / 240</p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="profile-location" className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <MapPin className="w-3 h-3" /> Location
              </Label>
              <Input id="profile-location" value={location} onChange={e => setLocation(e.target.value)} className="h-9 text-sm" />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="profile-tz" className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                <Globe className="w-3 h-3" /> Timezone
              </Label>
              <Select value={timezone} onValueChange={setTimezone}>
                <SelectTrigger id="profile-tz" className="h-9 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="America/Los_Angeles">America / Los Angeles (PT)</SelectItem>
                  <SelectItem value="America/New_York">America / New York (ET)</SelectItem>
                  <SelectItem value="America/Chicago">America / Chicago (CT)</SelectItem>
                  <SelectItem value="America/Toronto">America / Toronto (ET)</SelectItem>
                  <SelectItem value="Europe/London">Europe / London (GMT)</SelectItem>
                  <SelectItem value="Europe/Berlin">Europe / Berlin (CET)</SelectItem>
                  <SelectItem value="Europe/Madrid">Europe / Madrid (CET)</SelectItem>
                  <SelectItem value="Europe/Stockholm">Europe / Stockholm (CET)</SelectItem>
                  <SelectItem value="Asia/Tokyo">Asia / Tokyo (JST)</SelectItem>
                  <SelectItem value="Asia/Singapore">Asia / Singapore (SGT)</SelectItem>
                  <SelectItem value="Asia/Kolkata">Asia / Kolkata (IST)</SelectItem>
                  <SelectItem value="Asia/Manila">Asia / Manila (PHT)</SelectItem>
                  <SelectItem value="Africa/Lagos">Africa / Lagos (WAT)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Social links */}
        <Card className="p-5 md:p-6 card-lift">
          <h3 className="text-sm font-semibold text-foreground mb-1">Social & web</h3>
          <p className="text-xs text-muted-foreground mb-4">External links shown on your profile.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <SocialField icon={Link2} label="Website" value={website} onChange={setWebsite} placeholder="https://…" prefix="URL" />
            <SocialField icon={AtSign} label="Twitter / X" value={twitter} onChange={setTwitter} placeholder="username" prefix="@" />
            <SocialField icon={Linkedin} label="LinkedIn" value={linkedin} onChange={setLinkedin} placeholder="username" prefix="in/" />
            <SocialField icon={Github} label="GitHub" value={github} onChange={setGithub} placeholder="username" prefix="@" />
          </div>
        </Card>

        <Separator />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2">
          <div>
            <p className="text-xs font-semibold text-foreground">Member since</p>
            <p className="text-[11px] text-muted-foreground">
              {new Date(currentMember.joinedAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" className="h-9 gap-1.5" onClick={handleReset}>
              <RotateCcw className="w-3.5 h-3.5" /> Reset
            </Button>
            <Button size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90" onClick={handleSave}>
              <Save className="w-4 h-4" /> Save changes
            </Button>
          </div>
        </div>
      </SettingsLayout>
    </DashboardShell>
  )
}

function SocialField({
  icon: Icon,
  label,
  value,
  onChange,
  placeholder,
  prefix,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
  onChange: (v: string) => void
  placeholder: string
  prefix: string
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium text-muted-foreground flex items-center gap-1">
        <Icon className="w-3 h-3" /> {label}
      </Label>
      <div className="flex">
        <span className="inline-flex items-center px-2.5 h-9 text-xs text-muted-foreground bg-secondary border border-r-0 border-input rounded-l-md">
          {prefix}
        </span>
        <Input
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className="h-9 text-sm rounded-l-none"
        />
      </div>
    </div>
  )
}
