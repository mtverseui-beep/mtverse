"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Check, Sparkles, Zap, Building2, Crown, ArrowRight } from "lucide-react"
import { cn, formatCurrency } from "@/lib/utils"
import { toast } from "sonner"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

type Cycle = "monthly" | "annual"

interface Plan {
  id: string
  name: string
  icon: typeof Sparkles
  tagline: string
  monthlyPrice: number // 0 means "Free"
  features: string[]
  cta: string
  highlight?: boolean
  disabled?: boolean
  color: string
  current?: boolean
}

const PLANS: Plan[] = [
  {
    id: "starter",
    name: "Starter",
    icon: Zap,
    tagline: "For solo builders and side projects.",
    monthlyPrice: 0,
    features: [
      "Up to 3 projects",
      "Up to 2 seats",
      "1 GB storage",
      "Kanban + list views",
      "Mobile apps",
      "Community support",
    ],
    cta: "Downgrade to Starter",
    color: "text-sky-600 dark:text-sky-400",
  },
  {
    id: "pro",
    name: "Pro",
    icon: Sparkles,
    tagline: "For small teams getting serious.",
    monthlyPrice: 49,
    features: [
      "Up to 20 projects",
      "Up to 10 seats",
      "50 GB storage",
      "All views (incl. timeline & calendar)",
      "Time tracking",
      "Priority support",
    ],
    cta: "Switch to Pro",
    color: "text-emerald-600 dark:text-emerald-400",
  },
  {
    id: "scale",
    name: "Scale",
    icon: Sparkles,
    tagline: "For growing agencies and studios.",
    monthlyPrice: 99,
    features: [
      "Up to 50 projects",
      "Up to 25 seats",
      "100 GB storage",
      "SSO & SCIM",
      "Audit logs",
      "API & webhooks",
    ],
    cta: "Current plan",
    color: "text-primary",
    current: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    icon: Building2,
    tagline: "For larger orgs with custom needs.",
    monthlyPrice: 299,
    features: [
      "Unlimited projects",
      "Unlimited seats",
      "1 TB storage",
      "Dedicated CSM",
      "Custom SLA (99.99%)",
      "On-prem option",
    ],
    cta: "Talk to sales",
    color: "text-violet-600 dark:text-violet-400",
  },
]

export default function SubscriptionSettingsPage() {
  const [cycle, setCycle] = useState<Cycle>("monthly")
  const annualDiscount = 0.2 // 20% off
  const priceFor = (plan: Plan) => {
    if (plan.monthlyPrice === 0) return 0
    if (cycle === "annual") return Math.round(plan.monthlyPrice * (1 - annualDiscount))
    return plan.monthlyPrice
  }

  return (
    <DashboardShell
      title="Subscription"
      description="Compare plans and billing cycles. Upgrade or downgrade anytime — changes prorate instantly."
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Cycle toggle */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Billing cycle</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {cycle === "annual"
                  ? "Pay annually and save 20% — about 2 months free."
                  : "Pay monthly. Switch to annual anytime to save 20%."}
              </p>
            </div>
            <div className="inline-flex items-center gap-2 rounded-lg bg-muted p-1 h-9">
              <button
                type="button"
                onClick={() => setCycle("monthly")}
                className={cn(
                  "h-7 px-3 text-xs font-medium rounded-md transition-all",
                  cycle === "monthly" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
                )}
              >
                Monthly
              </button>
              <button
                type="button"
                onClick={() => setCycle("annual")}
                className={cn(
                  "h-7 px-3 text-xs font-medium rounded-md transition-all inline-flex items-center gap-1.5",
                  cycle === "annual" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
                )}
              >
                Annual
                <Badge variant="secondary" className="text-[9px] px-1 py-0 h-4 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                  -20%
                </Badge>
              </button>
            </div>
          </div>
        </Card>

        {/* Plan comparison cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
          {PLANS.map(plan => {
            const Icon = plan.icon
            const isCurrent = plan.current
            const price = priceFor(plan)
            return (
              <Card
                key={plan.id}
                className={cn(
                  "p-5 card-lift relative flex flex-col",
                  isCurrent && "border-primary ring-2 ring-primary/20 bg-primary/5",
                )}
              >
                {isCurrent && (
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground gap-1 shadow-md">
                      <Crown className="w-3 h-3" /> Current
                    </Badge>
                  </div>
                )}
                <div className="flex items-center gap-2 mb-1">
                  <div className={cn("w-8 h-8 rounded-lg bg-secondary flex items-center justify-center", plan.color)}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-semibold text-foreground">{plan.name}</h3>
                </div>
                <p className="text-[11px] text-muted-foreground mb-3 min-h-[28px]">{plan.tagline}</p>

                <div className="mb-4">
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-bold text-foreground">
                      {price === 0 ? "Free" : formatCurrency(price)}
                    </span>
                    {price > 0 && (
                      <span className="text-[11px] text-muted-foreground">/mo</span>
                    )}
                  </div>
                  {cycle === "annual" && price > 0 && (
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 mt-0.5">
                      Billed {formatCurrency(price * 12)}/yr
                    </p>
                  )}
                </div>

                <Separator className="mb-3" />

                <ul className="space-y-1.5 mb-4 flex-1">
                  {plan.features.map(f => (
                    <li key={f} className="flex items-start gap-1.5 text-[11px] text-foreground">
                      <Check className="w-3 h-3 text-primary mt-0.5 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>

                <Button
                  size="sm"
                  variant={isCurrent ? "outline" : "default"}
                  disabled={isCurrent}
                  className={cn(
                    "h-9 text-xs gap-1.5 w-full",
                    !isCurrent && "bg-primary text-primary-foreground hover:bg-primary/90",
                    isCurrent && "bg-transparent",
                  )}
                  onClick={() => toast.success(`${plan.cta}`, {
                    description: cycle === "annual" ? "Annual billing selected." : "Monthly billing selected.",
                  })}
                >
                  {isCurrent ? <Check className="w-3.5 h-3.5" /> : null}
                  {plan.cta}
                </Button>
              </Card>
            )
          })}
        </div>

        {/* Feature comparison table */}
        <Card className="p-0 card-lift overflow-hidden">
          <div className="p-5 md:p-6 border-b border-border">
            <h3 className="text-sm font-semibold text-foreground">Full feature comparison</h3>
            <p className="text-xs text-muted-foreground mt-0.5">Everything included with each plan.</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse min-w-[720px]">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-5 py-3">
                    Feature
                  </th>
                  {PLANS.map(p => (
                    <th key={p.id} className="px-3 py-3 text-center">
                      <p className={cn("text-xs font-semibold text-foreground", p.current && "text-primary")}>{p.name}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {p.monthlyPrice === 0 ? "Free" : `${formatCurrency(priceFor(p))}/mo`}
                      </p>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <FeatureRow label="Projects" values={["3", "20", "50", "Unlimited"]} />
                <FeatureRow label="Seats" values={["2", "10", "25", "Unlimited"]} />
                <FeatureRow label="Storage" values={["1 GB", "50 GB", "100 GB", "1 TB"]} />
                <FeatureRow label="Views (Kanban, list, timeline, calendar)" values={[true, true, true, true]} />
                <FeatureRow label="Mobile apps (iOS + Android)" values={[true, true, true, true]} />
                <FeatureRow label="Time tracking" values={[false, true, true, true]} />
                <FeatureRow label="API & webhooks" values={[false, false, true, true]} />
                <FeatureRow label="SSO & SCIM" values={[false, false, true, true]} />
                <FeatureRow label="Audit logs" values={[false, false, true, true]} />
                <FeatureRow label="Custom SLA (99.99%)" values={[false, false, false, true]} />
                <FeatureRow label="Dedicated CSM" values={[false, false, false, true]} />
                <FeatureRow label="On-prem option" values={[false, false, false, true]} />
                <FeatureRow label="Support" values={["Community", "Priority", "Priority", "Dedicated"]} last />
              </tbody>
            </table>
          </div>
        </Card>

        {/* FAQ */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <h3 className="text-sm font-semibold text-foreground mb-3">Plan FAQs</h3>
          <div className="space-y-3">
            <FaqItem
              q="What happens when I upgrade mid-cycle?"
              a="You're immediately upgraded and we prorate the difference for the remaining days. Your next invoice reflects the new plan."
            />
            <FaqItem
              q="Can I downgrade later?"
              a="Yes — downgrades take effect at the end of your current billing cycle. You keep premium features until then."
            />
            <FaqItem
              q="Do you offer discounts for non-profits or education?"
              a="Yes, 50% off Pro and Scale for verified non-profits and educational institutions. Contact support to apply."
            />
            <FaqItem
              q="How is storage measured?"
              a="All files, attachments, avatar uploads and asset versions count toward your storage. Workspace exports are free."
            />
          </div>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}

function FeatureRow({
  label, values, last,
}: {
  label: string
  values: (boolean | string)[]
  last?: boolean
}) {
  return (
    <tr className={cn("border-b border-border", last && "border-b-0")}>
      <td className="px-5 py-2.5 text-xs text-foreground font-medium">{label}</td>
      {values.map((v, i) => (
        <td key={i} className="px-3 py-2.5 text-center text-xs">
          {typeof v === "boolean" ? (
            v ? <Check className="w-3.5 h-3.5 text-primary mx-auto" /> : <span className="text-muted-foreground">—</span>
          ) : (
            <span className={cn("text-foreground", i === 2 && "font-semibold text-primary")}>{v}</span>
          )}
        </td>
      ))}
    </tr>
  )
}

function FaqItem({ q, a }: { q: string; a: string }) {
  return (
    <div className="flex items-start gap-2">
      <ArrowRight className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
      <div>
        <p className="text-xs font-semibold text-foreground">{q}</p>
        <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{a}</p>
      </div>
    </div>
  )
}
