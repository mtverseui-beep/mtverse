"use client"

import { useState, useMemo } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  ScrollText, Search, Filter, Download, Calendar, Activity, User,
  Globe, ShieldAlert, Settings as SettingsIcon, KeyRound, UserCog,
  UserPlus, CreditCard, Webhook, FileText, History,
} from "lucide-react"
import { cn, formatDate, timeAgo, initials } from "@/lib/utils"
import { toast } from "sonner"
import { auditLogs } from "@/lib/data/mock"
import { SettingsLayout, SettingsMobileNav, ExportCSVButton } from "../_lib"

// Categorize actions for filtering
const ACTION_TYPES = [
  { key: "all", label: "All actions" },
  { key: "workspace", label: "Workspace", match: /workspace|appearance|settings/i },
  { key: "team", label: "Team & members", match: /invited|member|role/i },
  { key: "developer", label: "API & webhooks", match: /api key|webhook|secret/i },
  { key: "billing", label: "Billing", match: /billing|plan|invoice|subscription/i },
  { key: "security", label: "Security", match: /password|2fa|session|sign-in|revoke/i },
]

// Actors from logs (unique)
const ACTORS = Array.from(new Set(auditLogs.map(l => l.actor)))

const ACTION_ICONS: { match: RegExp; icon: typeof Activity; color: string }[] = [
  { match: /workspace|appearance|settings/i, icon: SettingsIcon, color: "bg-primary/10 text-primary" },
  { match: /invited|member/i, icon: UserPlus, color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  { match: /role/i, icon: UserCog, color: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
  { match: /api key|revoke/i, icon: KeyRound, color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  { match: /webhook/i, icon: Webhook, color: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
  { match: /billing|plan/i, icon: CreditCard, color: "bg-lime-500/15 text-lime-600 dark:text-lime-400" },
  { match: /export/i, icon: Download, color: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
]

function iconFor(action: string) {
  for (const cfg of ACTION_ICONS) {
    if (cfg.match.test(action)) return cfg
  }
  return { icon: Activity, color: "bg-secondary text-muted-foreground" }
}

export default function AuditLogsSettingsPage() {
  const [search, setSearch] = useState("")
  const [actor, setActor] = useState("all")
  const [actionType, setActionType] = useState("all")
  const [from, setFrom] = useState("")
  const [to, setTo] = useState("")

  const filtered = useMemo(() => {
    return auditLogs.filter(l => {
      if (search) {
        const q = search.toLowerCase()
        if (!l.action.toLowerCase().includes(q) && !l.target.toLowerCase().includes(q) && !l.ip.includes(q)) return false
      }
      if (actor !== "all" && l.actor !== actor) return false
      if (actionType !== "all") {
        const type = ACTION_TYPES.find(t => t.key === actionType)
        if (type?.match && !type.match.test(l.action)) return false
      }
      if (from && new Date(l.createdAt) < new Date(from)) return false
      if (to && new Date(l.createdAt) > new Date(to + "T23:59:59")) return false
      return true
    })
  }, [search, actor, actionType, from, to])

  return (
    <DashboardShell
      title="Audit Logs"
      description="A complete record of every change in your workspace — who did what, when and from where."
      actions={<ExportCSVButton rows={filtered.length} />}
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatMini label="Total events" value={auditLogs.length} icon={History} color="bg-primary/10 text-primary" />
          <StatMini label="Last 7 days" value={auditLogs.filter(l => Date.now() - new Date(l.createdAt).getTime() < 7 * 86400000).length} icon={Activity} color="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
          <StatMini label="Unique actors" value={ACTORS.length} icon={User} color="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
          <StatMini label="Showing" value={filtered.length} icon={Filter} color="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        </div>

        {/* Filters */}
        <Card className="p-4 card-lift">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2.5">
            <div className="lg:col-span-2 relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search action, target or IP…"
                className="w-full h-9 pl-8 pr-3 text-xs rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <Select value={actor} onValueChange={setActor}>
              <SelectTrigger className="h-9 text-xs">
                <SelectValue placeholder="Actor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All actors</SelectItem>
                {ACTORS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={actionType} onValueChange={setActionType}>
              <SelectTrigger className="h-9 text-xs">
                <SelectValue placeholder="Action type" />
              </SelectTrigger>
              <SelectContent>
                {ACTION_TYPES.map(t => <SelectItem key={t.key} value={t.key}>{t.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="mt-2.5 flex flex-col sm:flex-row sm:items-center gap-2.5">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-[11px] text-muted-foreground">From</span>
              <input
                type="date"
                value={from}
                onChange={e => setFrom(e.target.value)}
                className="h-8 px-2 text-xs rounded-md border border-input bg-background text-foreground"
              />
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-muted-foreground">To</span>
              <input
                type="date"
                value={to}
                onChange={e => setTo(e.target.value)}
                className="h-8 px-2 text-xs rounded-md border border-input bg-background text-foreground"
              />
            </div>
            {(search || actor !== "all" || actionType !== "all" || from || to) && (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-xs ml-auto"
                onClick={() => { setSearch(""); setActor("all"); setActionType("all"); setFrom(""); setTo("") }}
              >
                Clear filters
              </Button>
            )}
          </div>
        </Card>

        {/* Logs table */}
        <Card className="p-0 card-lift overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse min-w-[820px]">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-4 py-2.5 w-[28%]">
                    Actor
                  </th>
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    Action
                  </th>
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    Target
                  </th>
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-3 py-2.5">
                    IP address
                  </th>
                  <th className="text-right text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-4 py-2.5">
                    Timestamp
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="text-center py-12">
                      <ScrollText className="w-8 h-8 mx-auto text-muted-foreground/50 mb-2" />
                      <p className="text-xs font-medium text-foreground">No events match your filters</p>
                      <p className="text-[11px] text-muted-foreground mt-1">Try adjusting your search or date range.</p>
                    </td>
                  </tr>
                ) : (
                  filtered.map(log => {
                    const { icon: Icon, color } = iconFor(log.action)
                    return (
                      <tr key={log.id} className="border-b border-border last:border-b-0 hover:bg-secondary/30 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <Avatar className="w-7 h-7">
                              <AvatarImage src={log.actorAvatar} alt={log.actor} />
                              <AvatarFallback className="text-[10px]">{initials(log.actor)}</AvatarFallback>
                            </Avatar>
                            <div className="min-w-0">
                              <p className="text-xs font-semibold text-foreground truncate">{log.actor}</p>
                              <p className="text-[10px] text-muted-foreground">Member</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-2">
                            <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center shrink-0", color)}>
                              <Icon className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-xs text-foreground">{log.action}</span>
                          </div>
                          {log.metadata && (
                            <div className="mt-1.5 ml-9 flex flex-wrap gap-1">
                              {Object.entries(log.metadata).map(([k, v]) => (
                                <Badge key={k} variant="secondary" className="text-[9px] font-mono">
                                  {k}: {v}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-3">
                          <span className="text-xs text-muted-foreground font-mono">{log.target}</span>
                        </td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-1.5">
                            <Globe className="w-3 h-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground font-mono">{log.ip}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <p className="text-xs text-foreground">{timeAgo(log.createdAt)}</p>
                          <p className="text-[10px] text-muted-foreground">{formatDate(log.createdAt, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</p>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>
          <div className="p-3 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
            <span>Showing {filtered.length} of {auditLogs.length} events</span>
            <span className="flex items-center gap-1">
              <ShieldAlert className="w-3 h-3" /> Logs retained for 365 days
            </span>
          </div>
        </Card>

        {/* Retention / compliance */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-foreground">Compliance & retention</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                Audit logs are retained for 365 days on Scale and Enterprise plans. Export to CSV for long-term storage or SIEM ingestion.
              </p>
            </div>
            <div className="flex gap-2">
              <ExportCSVButton rows={auditLogs.length} label="Export all" />
              <Button
                variant="outline"
                size="sm"
                className="h-9 text-xs bg-transparent gap-1.5"
                onClick={() => toast.success("Stream configured", { description: "Logs now stream to your SIEM via webhook." })}
              >
                <Webhook className="w-3.5 h-3.5" /> Stream to SIEM
              </Button>
            </div>
          </div>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}

function StatMini({
  label, value, icon: Icon, color,
}: {
  label: string
  value: number
  icon: typeof Activity
  color: string
}) {
  return (
    <Card className="p-3 md:p-4 card-lift">
      <div className="flex items-center gap-2">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", color)}>
          <Icon className="w-3.5 h-3.5" />
        </div>
        <div>
          <p className="text-lg font-bold text-foreground leading-none">{value}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">{label}</p>
        </div>
      </div>
    </Card>
  )
}
