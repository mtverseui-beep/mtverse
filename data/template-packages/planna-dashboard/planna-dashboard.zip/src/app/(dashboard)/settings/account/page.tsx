"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Mail, ShieldCheck, Eye, EyeOff, Key, Trash2, AlertTriangle,
  Check, Github, Chrome, Loader2,
} from "lucide-react"
import { toast } from "sonner"
import { currentMember } from "@/lib/data/mock"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

export default function AccountSettingsPage() {
  const [showCurrent, setShowCurrent] = useState(false)
  const [showNew, setShowNew] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const [currentPw, setCurrentPw] = useState("")
  const [newPw, setNewPw] = useState("")
  const [confirmPw, setConfirmPw] = useState("")
  const [savingPw, setSavingPw] = useState(false)

  const handlePasswordSave = () => {
    if (!currentPw || !newPw || !confirmPw) {
      toast.error("Missing fields", { description: "All three fields are required." })
      return
    }
    if (newPw !== confirmPw) {
      toast.error("Passwords don't match", { description: "New password and confirmation must be identical." })
      return
    }
    if (newPw.length < 8) {
      toast.error("Password too short", { description: "Use at least 8 characters." })
      return
    }
    setSavingPw(true)
    setTimeout(() => {
      setSavingPw(false)
      setCurrentPw(""); setNewPw(""); setConfirmPw("")
      toast.success("Password updated", { description: "Use your new password next time you sign in." })
    }, 900)
  }

  return (
    <DashboardShell
      title="Account"
      description="Manage your sign-in credentials, connected accounts and account lifecycle."
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Email address */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Email address</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Used for sign-in, notifications and password recovery.</p>
            </div>
            <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
              <Check className="w-3 h-3" /> Verified
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex-1 relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={currentMember.email}
                readOnly
                className="h-10 text-sm pl-9 bg-secondary/40"
              />
            </div>
            <Button
              variant="outline"
              className="h-10 text-sm gap-1.5 bg-transparent"
              onClick={() => toast.info("Email change", { description: "We'd send a verification link to your new address." })}
            >
              Change email
            </Button>
          </div>
          <p className="text-[10px] text-muted-foreground mt-2">
            Last verified on Feb 14, 2026. <button className="text-primary hover:underline">Resend verification</button>
          </p>
        </Card>

        {/* Change password */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">Change password</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Last changed 38 days ago. We recommend rotating every 90 days.</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-3xl">
            <PasswordInput
              id="pw-current"
              label="Current password"
              value={currentPw}
              onChange={setCurrentPw}
              visible={showCurrent}
              onToggle={() => setShowCurrent(s => !s)}
            />
            <PasswordInput
              id="pw-new"
              label="New password"
              value={newPw}
              onChange={setNewPw}
              visible={showNew}
              onToggle={() => setShowNew(s => !s)}
            />
            <PasswordInput
              id="pw-confirm"
              label="Confirm new"
              value={confirmPw}
              onChange={setConfirmPw}
              visible={showConfirm}
              onToggle={() => setShowConfirm(s => !s)}
            />
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              size="sm"
              className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={handlePasswordSave}
              disabled={savingPw}
            >
              {savingPw ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              {savingPw ? "Updating…" : "Update password"}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-9"
              onClick={() => toast.info("Password reset", { description: "We'd email a reset link to your address." })}
            >
              Forgot password?
            </Button>
          </div>
        </Card>

        {/* Connected accounts */}
        <Card className="p-5 md:p-6 card-lift">
          <h3 className="text-sm font-semibold text-foreground mb-1">Connected accounts</h3>
          <p className="text-xs text-muted-foreground mb-4">Use these providers to sign in or import data.</p>
          <div className="space-y-3">
            <ConnectedRow
              icon={Chrome}
              name="Google"
              hint="jessin@planna.app"
              connected
              onDisconnect={() => toast.success("Google disconnected")}
            />
            <Separator />
            <ConnectedRow
              icon={Github}
              name="GitHub"
              hint="@jessinsam · 14 repos"
              connected
              onDisconnect={() => toast.success("GitHub disconnected")}
            />
            <Separator />
            <ConnectedRow
              icon={Mail}
              name="Apple ID"
              hint="Not connected"
              connected={false}
              onConnect={() => toast.success("Apple ID connected")}
            />
          </div>
        </Card>

        {/* Delete account — danger zone */}
        <Card className="p-5 md:p-6 border-destructive/30 bg-destructive/5 card-lift">
          <div className="flex items-start gap-3 mb-3">
            <div className="w-9 h-9 rounded-lg bg-destructive/15 text-destructive flex items-center justify-center shrink-0">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">Delete account</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Permanently remove your account, all projects and data. This action cannot be undone.
              </p>
            </div>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm" className="h-9 gap-1.5">
                <Trash2 className="w-4 h-4" /> Delete my account
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete your account and all associated projects, tasks, files, and history.
                  This action <span className="font-semibold text-foreground">cannot be undone</span>. To confirm,
                  type <span className="font-mono font-semibold text-foreground">DELETE</span> below.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <Input placeholder="Type DELETE to confirm" className="h-9 text-sm" />
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  onClick={() => toast.error("Account deletion blocked", { description: "This is a UI demo — no data was actually deleted." })}
                >
                  Yes, delete my account
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}

function PasswordInput({
  id, label, value, onChange, visible, onToggle,
}: {
  id: string
  label: string
  value: string
  onChange: (v: string) => void
  visible: boolean
  onToggle: () => void
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="text-xs font-medium text-muted-foreground">{label}</Label>
      <div className="relative">
        <Input
          id={id}
          type={visible ? "text" : "password"}
          value={value}
          onChange={e => onChange(e.target.value)}
          className="h-9 text-sm pr-9"
          placeholder="••••••••"
        />
        <button
          type="button"
          onClick={onToggle}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          aria-label={visible ? "Hide password" : "Show password"}
        >
          {visible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>
    </div>
  )
}

function ConnectedRow({
  icon: Icon, name, hint, connected, onConnect, onDisconnect,
}: {
  icon: React.ComponentType<{ className?: string }>
  name: string
  hint: string
  connected: boolean
  onConnect?: () => void
  onDisconnect?: () => void
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="w-9 h-9 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground shrink-0">
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="text-xs font-semibold text-foreground">{name}</p>
          {connected && (
            <Badge variant="secondary" className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
              <Check className="w-3 h-3" /> Connected
            </Badge>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground mt-0.5">{hint}</p>
      </div>
      {connected ? (
        <Button
          variant="outline"
          size="sm"
          className="h-8 text-xs bg-transparent"
          onClick={onDisconnect}
        >
          Disconnect
        </Button>
      ) : (
        <Button
          size="sm"
          className="h-8 text-xs bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
          onClick={onConnect}
        >
          Connect
        </Button>
      )}
    </div>
  )
}
