"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Sparkles, Users, FolderKanban, HardDrive, Code2, CreditCard,
  Calendar, TrendingUp, ArrowUpRight, ArrowDownRight, Check, Zap,
} from "lucide-react"
import { cn, formatCurrency } from "@/lib/utils"
import { toast } from "sonner"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

const USAGE_METRICS = [
  { label: "Seats", icon: Users, used: 12, total: 25, hint: "Members in your workspace", color: "text-emerald-600 dark:text-emerald-400" },
  { label: "Projects", icon: FolderKanban, used: 8, total: 50, hint: "Active projects", color: "text-teal-600 dark:text-teal-400" },
  { label: "Storage", icon: HardDrive, used: 4.2, total: 100, unit: "GB", hint: "Files, attachments and assets", color: "text-lime-600 dark:text-lime-400" },
  { label: "API calls", icon: Code2, used: 184_000, total: 500_000, unit: "", format: "compact", hint: "Last 30 days", color: "text-cyan-600 dark:text-cyan-400" },
]

export default function BillingSettingsPage() {
  return (
    <DashboardShell
      title="Billing"
      description="Plan details, usage meters and payment method on file. Upgrade or downgrade anytime."
      actions={
        <Button variant="outline" size="sm" className="h-9 bg-transparent" asChild>
          <a href="/settings/subscription">Change plan</a>
        </Button>
      }
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Current plan */}
        <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-semibold text-foreground">Planna Scale</h3>
                  <Badge className="bg-primary/15 text-primary">Current plan</Badge>
                </div>
                <p className="text-2xl font-bold text-foreground mt-1">
                  {formatCurrency(99)}
                  <span className="text-xs font-normal text-muted-foreground">/month</span>
                </p>
                <p className="text-[11px] text-muted-foreground mt-1">
                  Renews on <span className="font-medium text-foreground">Mar 18, 2026</span> · Billed monthly
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" className="h-9 bg-transparent gap-1.5" asChild>
                <a href="/settings/subscription">
                  <TrendingUp className="w-3.5 h-3.5" /> Compare plans
                </a>
              </Button>
              <Button size="sm" className="h-9 bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5" onClick={() => toast.info("Manage subscription", { description: "Stripe portal would open here." })}>
                <CreditCard className="w-3.5 h-3.5" /> Manage
              </Button>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
            {["Unlimited projects", "Up to 25 seats", "SSO & SCIM", "Audit logs"].map(f => (
              <div key={f} className="flex items-center gap-1.5 text-[11px] text-foreground">
                <Check className="w-3 h-3 text-primary shrink-0" />
                {f}
              </div>
            ))}
          </div>
        </Card>

        {/* Usage meters */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Usage this period</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Feb 18 – Mar 18, 2026. Resets on renewal.</p>
            </div>
            <Button variant="link" size="sm" className="h-7 text-xs text-primary">View detailed usage →</Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {USAGE_METRICS.map(m => {
              const pctVal = (m.used / m.total) * 100
              const formatVal = (v: number) => {
                if (m.format === "compact") {
                  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`
                  if (v >= 1_000) return `${(v / 1_000).toFixed(0)}K`
                  return v.toString()
                }
                if (m.unit) return `${v}${m.unit}`
                return v.toString()
              }
              const Icon = m.icon
              const isWarning = pctVal >= 80
              return (
                <div key={m.label} className="p-3 rounded-lg border border-border bg-card">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={cn("w-7 h-7 rounded-lg bg-secondary flex items-center justify-center", m.color)}>
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <p className="text-xs font-semibold text-foreground">{m.label}</p>
                    </div>
                    {isWarning && (
                      <Badge className="text-[10px] bg-amber-500/15 text-amber-600 dark:text-amber-400">Near limit</Badge>
                    )}
                  </div>
                  <div className="flex items-baseline justify-between mb-1.5">
                    <p className="text-sm font-semibold text-foreground">
                      {formatVal(m.used)}
                      <span className="text-[11px] text-muted-foreground font-normal"> / {formatVal(m.total)}</span>
                    </p>
                    <span className="text-[11px] text-muted-foreground">{Math.round(pctVal)}%</span>
                  </div>
                  <Progress value={pctVal} className="h-1.5" />
                  <p className="text-[10px] text-muted-foreground mt-1.5">{m.hint}</p>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Payment method */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start justify-between gap-3 mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Payment method</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Charged automatically on the 18th of each month.</p>
            </div>
            <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" onClick={() => toast.info("Update payment", { description: "Stripe would open here to update your card." })}>
              Update
            </Button>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card">
            <div className="w-12 h-8 rounded-md bg-gradient-to-br from-zinc-800 to-zinc-700 text-white flex items-center justify-center text-[10px] font-bold tracking-wider">
              VISA
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-foreground">Visa ending in 4242</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">Expires 09/2028 · Jessin Sam</p>
            </div>
            <Badge variant="secondary" className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
              <Check className="w-3 h-3" /> Primary
            </Badge>
          </div>
        </Card>

        {/* Next invoice */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-start gap-3 mb-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-foreground">Next invoice</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Mar 18, 2026 · {formatCurrency(99)} + tax</p>
            </div>
          </div>
          <div className="rounded-lg border border-border p-3 space-y-1.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Planna Scale (monthly)</span>
              <span className="font-medium text-foreground">{formatCurrency(99)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Tax (estimated)</span>
              <span className="font-medium text-foreground">{formatCurrency(8.32)}</span>
            </div>
            <Separator className="my-1" />
            <div className="flex items-center justify-between">
              <span className="font-semibold text-foreground">Total due</span>
              <span className="font-bold text-foreground">{formatCurrency(107.32)}</span>
            </div>
          </div>
        </Card>

        {/* Upgrade / downgrade CTA */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Card className="p-4 card-lift bg-gradient-to-br from-violet-500/10 to-transparent border-violet-500/20">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-violet-500/15 text-violet-600 dark:text-violet-400 flex items-center justify-center shrink-0">
                <ArrowUpRight className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <p className="text-xs font-semibold text-foreground">Need more power?</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                  Enterprise adds SSO, dedicated support and unlimited seats.
                </p>
                <Button variant="link" size="sm" className="h-6 px-0 mt-1 text-violet-600 dark:text-violet-400 text-xs" asChild>
                  <a href="/settings/subscription">Talk to sales →</a>
                </Button>
              </div>
            </div>
          </Card>
          <Card className="p-4 card-lift">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-secondary text-muted-foreground flex items-center justify-center shrink-0">
                <ArrowDownRight className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <p className="text-xs font-semibold text-foreground">Downgrade to Pro</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                  {formatCurrency(49)}/mo · up to 10 seats, 20 projects.
                </p>
                <Button variant="link" size="sm" className="h-6 px-0 mt-1 text-primary text-xs" asChild>
                  <a href="/settings/subscription">View plans →</a>
                </Button>
              </div>
            </div>
          </Card>
        </div>

        <Separator />

        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-foreground">Billing support</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                Questions about invoices, taxes or refunds? Our billing team replies within 4 hours on weekdays.
              </p>
              <div className="flex gap-2 mt-2">
                <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                  <a href="/help/contact">Email billing</a>
                </Button>
                <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                  <a href="/settings/invoices">Past invoices</a>
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}
