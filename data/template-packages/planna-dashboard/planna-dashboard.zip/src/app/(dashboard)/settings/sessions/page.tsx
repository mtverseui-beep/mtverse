"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Monitor, Smartphone, Tablet, Apple, Globe, Clock, MapPin, LogOut,
  ShieldCheck, Wifi, Trash2, Check,
} from "lucide-react"
import { cn, timeAgo } from "@/lib/utils"
import { toast } from "sonner"
import { SettingsLayout, SettingsMobileNav } from "../_lib"

interface Session {
  id: string
  device: string
  deviceType: "desktop" | "mobile" | "tablet"
  os: string
  browser: string
  location: string
  ip: string
  lastActive: string
  current: boolean
}

const SESSIONS: Session[] = [
  { id: "s1", device: "MacBook Pro 16\"", deviceType: "desktop", os: "macOS 15.3 Sequoia", browser: "Chrome 132", location: "San Francisco, CA, US", ip: "203.0.113.42", lastActive: new Date().toISOString(), current: true },
  { id: "s2", device: "iPhone 16 Pro", deviceType: "mobile", os: "iOS 18.3", browser: "Planna iOS 2.4", location: "San Francisco, CA, US", ip: "203.0.113.43", lastActive: new Date(Date.now() - 1000 * 60 * 32).toISOString(), current: false },
  { id: "s3", device: "Windows PC", deviceType: "desktop", os: "Windows 11 Pro", browser: "Firefox 134", location: "Austin, TX, US", ip: "192.0.2.88", lastActive: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(), current: false },
  { id: "s4", device: "iPad Pro 13\"", deviceType: "tablet", os: "iPadOS 18.3", browser: "Safari 18", location: "San Francisco, CA, US", ip: "203.0.113.51", lastActive: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(), current: false },
  { id: "s5", device: "MacBook Air", deviceType: "desktop", os: "macOS 14 Sonoma", browser: "Safari 18", location: "London, UK", ip: "198.51.100.7", lastActive: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(), current: false },
]

function DeviceIcon({ type }: { type: Session["deviceType"] }) {
  if (type === "mobile") return <Smartphone className="w-4 h-4" />
  if (type === "tablet") return <Tablet className="w-4 h-4" />
  return <Monitor className="w-4 h-4" />
}

export default function SessionsSettingsPage() {
  const [sessions, setSessions] = useState(SESSIONS)

  const revoke = (id: string) => {
    setSessions(prev => prev.filter(s => s.id !== id))
    toast.success("Session revoked", { description: "The device will be signed out on next request." })
  }
  const revokeAllOthers = () => {
    const others = sessions.filter(s => !s.current).length
    setSessions(prev => prev.filter(s => s.current))
    toast.success(`${others} sessions revoked`, { description: "All other devices were signed out." })
  }

  const current = sessions.find(s => s.current)
  const others = sessions.filter(s => !s.current)

  return (
    <DashboardShell
      title="Sessions"
      description="Active sign-ins across your devices. Revoke any session you don't recognize immediately."
      actions={
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline" size="sm" className="h-9 gap-1.5 bg-transparent" disabled={others.length === 0}>
              <LogOut className="w-3.5 h-3.5" /> Revoke all others ({others.length})
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Revoke all other sessions?</AlertDialogTitle>
              <AlertDialogDescription>
                You'll be signed out of <span className="font-semibold text-foreground">{others.length}</span> other device{others.length === 1 ? "" : "s"}. Your current session on this device will remain active.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={revokeAllOthers}
              >
                Yes, revoke {others.length} session{others.length === 1 ? "" : "s"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      }
    >
      <SettingsMobileNav />
      <SettingsLayout>
        {/* Current session */}
        {current && (
          <Card className="p-5 md:p-6 card-lift border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-md bg-primary text-primary-foreground flex items-center justify-center">
                  <ShieldCheck className="w-3.5 h-3.5" />
                </div>
                <h3 className="text-sm font-semibold text-foreground">Current session</h3>
                <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Active now
                </Badge>
              </div>
            </div>
            <SessionRow session={current} current onRevoke={() => toast.info("This is your current session", { description: "You can sign out from the sidebar instead." })} />
          </Card>
        )}

        {/* Other sessions */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Other sessions</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Devices currently signed in to your account.</p>
            </div>
            <Badge variant="secondary" className="text-[10px]">{others.length} active</Badge>
          </div>

          {others.length === 0 ? (
            <div className="text-center py-10">
              <Check className="w-8 h-8 mx-auto text-emerald-500 mb-2" />
              <p className="text-xs font-medium text-foreground">No other active sessions</p>
              <p className="text-[11px] text-muted-foreground mt-1">You're only signed in here.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[600px] overflow-y-auto scroll-area-thin">
              {others.map(s => (
                <SessionRow key={s.id} session={s} onRevoke={() => revoke(s.id)} />
              ))}
            </div>
          )}
        </Card>

        {/* Safety tips */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-foreground">Don't recognize a session?</p>
              <ul className="mt-2 space-y-1.5 text-[11px] text-muted-foreground">
                <li className="flex items-start gap-2">
                  <Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" />
                  Revoke the session immediately and change your password.
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" />
                  Enable two-factor authentication if you haven't already.
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" />
                  Review your audit log for any unauthorized changes.
                </li>
              </ul>
              <div className="flex gap-2 mt-3">
                <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                  <a href="/settings/security">Security settings</a>
                </Button>
                <Button variant="outline" size="sm" className="h-8 text-xs bg-transparent" asChild>
                  <a href="/settings/audit-logs">Audit logs</a>
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </SettingsLayout>
    </DashboardShell>
  )
}

function SessionRow({
  session, current, onRevoke,
}: {
  session: Session
  current?: boolean
  onRevoke: () => void
}) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card hover:bg-secondary/40 transition-colors">
      <div className={cn(
        "w-9 h-9 rounded-lg flex items-center justify-center shrink-0",
        current ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
      )}>
        <DeviceIcon type={session.deviceType} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-xs font-semibold text-foreground">{session.device}</p>
          {current && (
            <Badge variant="secondary" className="text-[10px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> This device
            </Badge>
          )}
        </div>
        <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Apple className="w-3 h-3" /> {session.os}
          </span>
          <span className="flex items-center gap-1">
            <Globe className="w-3 h-3" /> {session.browser}
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3" /> {session.location}
          </span>
          <span className="flex items-center gap-1">
            <Wifi className="w-3 h-3" /> {session.ip}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" /> {current ? "Active now" : timeAgo(session.lastActive)}
          </span>
        </div>
      </div>
      <Button
        variant={current ? "ghost" : "outline"}
        size="sm"
        className={cn("h-8 text-xs gap-1 shrink-0", !current && "bg-transparent text-destructive hover:text-destructive hover:bg-destructive/10")}
        onClick={onRevoke}
        disabled={current}
      >
        {current ? <Check className="w-3.5 h-3.5" /> : <Trash2 className="w-3.5 h-3.5" />}
        {current ? "Current" : "Revoke"}
      </Button>
    </div>
  )
}
