"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import {
  ShieldCheck, ChevronRight, ArrowRight, Lock, Cookie, Users,
  AlertTriangle, Mail, Download, Printer, Clock, Baby, FileText,
  Eye, Database, KeyRound,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// TOC
// ============================================================

interface TocItem {
  id: string
  number: string
  title: string
  icon: typeof Lock
}

const TOC: TocItem[] = [
  { id: "collect", number: "1", title: "Information We Collect", icon: Database },
  { id: "use", number: "2", title: "How We Use Your Information", icon: Eye },
  { id: "share", number: "3", title: "Sharing & Disclosure", icon: Users },
  { id: "security", number: "4", title: "Data Security", icon: Lock },
  { id: "rights", number: "5", title: "Your Privacy Rights", icon: KeyRound },
  { id: "cookies", number: "6", title: "Cookies & Tracking", icon: Cookie },
  { id: "third-party", number: "7", title: "Third-Party Services", icon: FileText },
  { id: "children", number: "8", title: "Children's Privacy", icon: Baby },
  { id: "changes", number: "9", title: "Changes to This Policy", icon: AlertTriangle },
  { id: "contact", number: "10", title: "Contact Us", icon: Mail },
]

// ============================================================
// SECTIONS
// ============================================================

interface Section {
  id: string
  title: string
  paragraphs: string[]
  paragraphs_post?: string[]
  bullets?: string[]
  tables?: { header: string[]; rows: string[][] }[]
}

const SECTIONS: Section[] = [
  {
    id: "collect",
    title: "1. Information We Collect",
    paragraphs: [
      "Planna is committed to transparency about the data we collect and how we use it. We collect only the information necessary to provide, secure, and improve our Service.",
      "We collect information in three ways: (1) information you provide directly, (2) information collected automatically when you use the Service, and (3) information from third-party sources when you integrate them with Planna.",
    ],
    bullets: [
      "Account information: name, email address, password (hashed), profile photo, role, and workspace affiliation.",
      "Workspace information: workspace name, logo, billing details (processed by Stripe — we never store full card numbers), and member roster.",
      "User Content: tasks, projects, comments, files, time entries, and any other data you create or upload through the Service.",
      "Usage data: pages viewed, features used, device type, browser, IP address, and timestamps — collected via first-party analytics.",
      "Communication data: support tickets, feedback submissions, and email correspondence with our team.",
      "Diagnostic data: crash reports, error logs, and performance metrics — used solely for debugging and improving the Service.",
    ],
  },
  {
    id: "use",
    title: "2. How We Use Your Information",
    paragraphs: [
      "We use the information we collect to provide, operate, secure, and improve the Service. We do not sell your personal information to third parties — never have, never will.",
      "Specifically, we use your information for the following purposes:",
    ],
    bullets: [
      "Provide the Service: create and manage your account, workspace, projects, and tasks; enable real-time collaboration.",
      "Process payments: bill you for paid Plans, manage subscriptions, and issue invoices (via Stripe).",
      "Communicate with you: send service announcements, security alerts, billing notices, and support responses.",
      "Improve the Service: analyze usage patterns, identify bugs, prioritize features, and conduct user research.",
      "Secure the Service: detect and prevent fraud, abuse, unauthorized access, and security incidents.",
      "Comply with legal obligations: respond to lawful requests from authorities and meet regulatory requirements.",
      "Aggregate analytics: compile anonymized, statistical data about Service usage to share with partners and the public.",
    ],
  },
  {
    id: "share",
    title: "3. Sharing & Disclosure",
    paragraphs: [
      "We share your information only in the limited circumstances described below. We never sell your data, and we never share it for cross-context advertising.",
    ],
    bullets: [
      "Within your workspace: content you create is visible to other members of your workspace based on their role and permissions.",
      "Service providers: we use trusted subprocessors (Stripe, AWS, Postmark, Sentry) to operate the Service. They process data on our behalf under written agreements and are bound by confidentiality obligations.",
      "Legal compliance: we may disclose information if required by law, court order, or government request, or to protect the rights, property, or safety of Planna, our users, or others.",
      "Business transfers: in connection with a merger, acquisition, or sale of assets, we may transfer user data — subject to the same privacy protections described here.",
      "Anonymized data: we may share aggregated, de-identified data that cannot reasonably be used to identify you.",
      "With your consent: we share information with third parties when you explicitly authorize it (e.g., connecting a Slack integration).",
    ],
  },
  {
    id: "security",
    title: "4. Data Security",
    paragraphs: [
      "We take security seriously. Planna is SOC 2 Type II certified and employs industry-standard safeguards to protect your data. However, no system is 100% secure, and we cannot guarantee absolute security.",
    ],
    bullets: [
      "Encryption in transit: all connections use TLS 1.3 with HSTS enabled.",
      "Encryption at rest: all data is encrypted with AES-256 in our primary database and backups.",
      "Access control: strict role-based access, multi-factor authentication for all employees, and quarterly access reviews.",
      "Network security: VPC segmentation, Web Application Firewall, DDoS protection, and continuous monitoring.",
      "Auditing: SOC 2 Type II annual audits, quarterly penetration tests by third parties, and a public bug bounty program.",
      "Incident response: 24/7 monitoring with a documented incident response plan. We notify affected users within 72 hours of a confirmed breach.",
      "Data residency: by default, data is stored in US-East. Enterprise customers can choose EU (Frankfurt) or APAC (Singapore) regions.",
      "Backup: encrypted backups are taken every 6 hours and retained for 30 days. Backups are stored in a separate region.",
    ],
  },
  {
    id: "rights",
    title: "5. Your Privacy Rights",
    paragraphs: [
      "Depending on your location, you may have certain rights regarding your personal information. We honor these rights for all users, regardless of jurisdiction.",
    ],
    bullets: [
      "Access: request a copy of the personal information we hold about you.",
      "Rectification: request correction of inaccurate or incomplete information.",
      "Erasure: request deletion of your personal information (subject to legal retention requirements).",
      "Portability: request an export of your data in a machine-readable format (JSON or CSV).",
      "Objection: object to certain processing activities, such as direct marketing.",
      "Restriction: request that we limit our processing of your data in certain circumstances.",
      "Withdraw consent: withdraw consent for processing based on consent at any time.",
      "Account deletion: delete your account at any time from Settings → Account — all data is permanently removed within 90 days.",
    ],
    paragraphs_post: [
      "To exercise any of these rights, email privacy@planna.app. We respond within 30 days. EU/UK users may also lodge a complaint with their local data protection authority.",
    ],
  },
  {
    id: "cookies",
    title: "6. Cookies & Tracking Technologies",
    paragraphs: [
      "We use cookies and similar tracking technologies (local storage, pixels) to operate, secure, and improve the Service. We do not use cookies for cross-site advertising or selling data to ad networks.",
    ],
    tables: [{
      header: ["Cookie", "Purpose", "Duration", "Category"],
      rows: [
        ["planna_session", "Authenticates your session", "30 days", "Strictly necessary"],
        ["planna_theme", "Remembers your theme preference", "1 year", "Functional"],
        ["planna_locale", "Remembers your language/region", "1 year", "Functional"],
        ["planna_csrf", "Prevents cross-site request forgery", "Session", "Strictly necessary"],
        ["_pk_id", "Anonymized usage analytics (Matomo)", "13 months", "Analytics (opt-out)"],
        ["_pk_ses", "Anonymized usage analytics session", "30 minutes", "Analytics (opt-out)"],
      ],
    }],
    paragraphs_post: [
      "You can manage cookies via your browser settings. Disabling strictly necessary cookies will prevent the Service from functioning. Analytics cookies can be opted out via the cookie banner on first visit.",
    ],
  },
  {
    id: "third-party",
    title: "7. Third-Party Services",
    paragraphs: [
      "Planna integrates with several third-party services. When you connect an integration, that service may access certain data from your Planna workspace, subject to your authorization. We do not control the privacy practices of third parties — please review their policies.",
    ],
    bullets: [
      "Stripe: payment processing — see Stripe's privacy policy. We never store full card numbers.",
      "AWS (Amazon Web Services): primary infrastructure and data storage — see AWS's privacy policy.",
      "Postmark: transactional email delivery — see Postmark's privacy policy.",
      "Sentry: error monitoring and crash reporting (sanitized) — see Sentry's privacy policy.",
      "Slack, GitHub, Google Calendar: optional integrations activated by you — see each provider's privacy policy.",
      "OpenAI: used only for AI-assisted features (smart suggestions) — content is not used to train models.",
    ],
  },
  {
    id: "children",
    title: "8. Children's Privacy",
    paragraphs: [
      "The Service is not directed to children under 16. We do not knowingly collect personal information from children under 16. If you believe we have collected information from a child, please contact privacy@planna.app and we will delete it promptly.",
      "Educational institutions may use Planna with students aged 13+ with parental consent. We offer FERPA-aligned data practices for verified educational customers — contact us for a DPA.",
    ],
  },
  {
    id: "changes",
    title: "9. Changes to This Policy",
    paragraphs: [
      "We may update this Privacy Policy from time to time. We will notify you of material changes by email and via an in-app banner at least 30 days before the changes take effect.",
      "The \"Last updated\" date at the top of this page reflects the most recent revision. We encourage you to review this page periodically. Continued use of the Service after changes take effect constitutes acceptance of the revised policy.",
    ],
    bullets: [
      "Material changes (e.g., new data uses, new subprocessors): 30-day email + in-app notice.",
      "Non-material changes (e.g., clarifications, formatting): updated without separate notice.",
      "A historical archive of past versions is available on request from privacy@planna.app.",
    ],
  },
  {
    id: "contact",
    title: "10. Contact Us",
    paragraphs: [
      "If you have any questions about this Privacy Policy, our data practices, or your rights, please contact us:",
    ],
    bullets: [
      "Email: privacy@planna.app (Data Protection Officer)",
      "Support: support@planna.app",
      "Postal mail: Planna Inc., Attn: Privacy, 535 Mission Street, San Francisco, CA 94105, USA",
      "EU representative: Planna EU GDPR Rep, Friedrichstraße 68, 10117 Berlin, Germany",
    ],
    paragraphs_post: [
      "We aim to respond to all privacy inquiries within 30 days. For urgent matters (e.g., a data breach affecting you), we respond within 72 hours.",
    ],
  },
]

// ============================================================
// PAGE
// ============================================================

export default function PrivacyPage() {
  const [activeSection, setActiveSection] = useState<string>("collect")
  const [analyticsOptOut, setAnalyticsOptOut] = useState(false)

  const lastUpdated = "January 28, 2026"
  const effectiveDate = "February 1, 2026"

  const handleDownload = () => {
    toast.success("Download started", { description: "Privacy Policy downloading as PDF…" })
  }
  const handlePrint = () => { if (typeof window !== "undefined") window.print() }

  return (
    <DashboardShell
      title="Privacy Policy"
      description="How Planna collects, uses, and protects your personal information. Your privacy matters to us."
      actions={
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5" onClick={handlePrint}>
            <Printer className="w-3.5 h-3.5" /> Print
          </Button>
          <Button variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5" onClick={handleDownload}>
            <Download className="w-3.5 h-3.5" /> Download PDF
          </Button>
        </div>
      }
    >
      <HelpMobileNav />
      <HelpLayout>
        {/* META BAR */}
        <Card className="p-4 card-lift">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Legal Document</p>
                <p className="text-[11px] text-muted-foreground">Planna Privacy Policy</p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <Clock className="w-3 h-3" /> Last updated: {lastUpdated}
              </span>
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5 bg-primary/10 text-primary">
                Effective {effectiveDate}
              </Badge>
            </div>
          </div>
        </Card>

        {/* PRIVACY AT A GLANCE */}
        <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex items-center gap-2 mb-4">
            <Lock className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Privacy at a glance</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Data sold", value: "Never", tint: "text-emerald-600 dark:text-emerald-400" },
              { label: "Encryption", value: "AES-256 + TLS 1.3", tint: "text-foreground" },
              { label: "Compliance", value: "GDPR · CCPA · SOC 2", tint: "text-foreground" },
              { label: "Data retention", value: "30 days after deletion", tint: "text-foreground" },
            ].map(s => (
              <div key={s.label} className="p-3 rounded-lg bg-background/60 border border-border">
                <p className="text-[10px] text-muted-foreground">{s.label}</p>
                <p className={cn("text-xs font-bold mt-0.5", s.tint)}>{s.value}</p>
              </div>
            ))}
          </div>
          {/* Opt-out toggle */}
          <div className="mt-4 pt-4 border-t border-border/60 flex items-center justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <Cookie className="w-4 h-4 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-xs font-semibold text-foreground">Opt out of analytics</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                  We use anonymized analytics to improve Planna. Toggle off to disable.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Label htmlFor="opt-out" className="text-[10px] text-muted-foreground">{analyticsOptOut ? "Off" : "On"}</Label>
              <Switch
                id="opt-out"
                checked={analyticsOptOut}
                onCheckedChange={(v) => {
                  setAnalyticsOptOut(v)
                  toast.success(v ? "Analytics opted out" : "Analytics opted in")
                }}
              />
            </div>
          </div>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-4 lg:gap-6">
          {/* LEFT — TABLE OF CONTENTS */}
          <aside>
            <Card className="p-4 card-lift lg:sticky lg:top-4">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-3 px-2">
                Table of contents
              </p>
              <nav className="space-y-0.5">
                {TOC.map(item => {
                  const TIcon = item.icon
                  const active = activeSection === item.id
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setActiveSection(item.id)
                        if (typeof document !== "undefined") {
                          document.getElementById(item.id)?.scrollIntoView({ behavior: "smooth", block: "start" })
                        }
                      }}
                      className={cn(
                        "w-full flex items-center gap-2 px-2 h-9 rounded-md text-xs font-medium text-left transition-colors",
                        active
                          ? "bg-primary text-primary-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                      )}
                    >
                      <span className={cn(
                        "w-5 h-5 rounded text-[10px] font-bold flex items-center justify-center shrink-0",
                        active ? "bg-primary-foreground/20 text-primary-foreground" : "bg-secondary text-muted-foreground",
                      )}>
                        {item.number}
                      </span>
                      <span className="truncate">{item.title}</span>
                    </button>
                  )
                })}
              </nav>

              <div className="mt-4 pt-4 border-t border-border space-y-1">
                <Button asChild variant="ghost" size="sm" className="w-full h-8 text-xs justify-start text-muted-foreground hover:text-foreground">
                  <Link href="/help/terms"><FileText className="w-3.5 h-3.5" /> Terms of Service</Link>
                </Button>
                <Button asChild variant="ghost" size="sm" className="w-full h-8 text-xs justify-start text-muted-foreground hover:text-foreground">
                  <Link href="/help/contact"><Mail className="w-3.5 h-3.5" /> Contact DPO</Link>
                </Button>
              </div>
            </Card>
          </aside>

          {/* RIGHT — CONTENT */}
          <div className="min-w-0 space-y-4">
            <Card className="p-5 md:p-7 card-lift">
              {/* Header */}
              <div className="mb-6 pb-5 border-b border-border">
                <h1 className="text-2xl font-bold text-foreground tracking-tight">Privacy Policy</h1>
                <p className="text-xs text-muted-foreground mt-1">
                  This Privacy Policy was last updated on {lastUpdated} and became effective on {effectiveDate}.
                </p>
              </div>

              {/* Intro */}
              <div className="mb-6 p-4 rounded-lg bg-secondary/40 border border-border">
                <p className="text-xs text-muted-foreground leading-relaxed">
                  This Privacy Policy explains how Planna collects, uses, discloses, and safeguards your information when you use our Service. We are committed to protecting your privacy and being transparent about our data practices. Please read this policy carefully to understand our practices regarding your information.
                </p>
              </div>

              {/* Sections */}
              <div className="space-y-8">
                {SECTIONS.map(section => (
                  <section
                    key={section.id}
                    id={section.id}
                    className="scroll-mt-24"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className={cn(
                        "w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold transition-colors",
                        activeSection === section.id ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary",
                      )}>
                        {section.id.match(/\d+/)?.[0]}
                      </div>
                      <h2 className="text-base font-semibold text-foreground">{section.title.replace(/^\d+\.\s/, "")}</h2>
                    </div>
                    <div className="pl-11 space-y-3">
                      {section.paragraphs.map((p, i) => (
                        <p key={i} className="text-sm text-muted-foreground leading-relaxed">{p}</p>
                      ))}
                      {section.bullets && (
                        <ul className="space-y-2 mt-3">
                          {section.bullets.map((b, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                              <span className="leading-relaxed">{b}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                      {section.tables && section.tables.map((t, ti) => (
                        <div key={ti} className="mt-3 rounded-lg border border-border overflow-hidden overflow-x-auto">
                          <table className="w-full border-collapse text-xs min-w-[480px]">
                            <thead>
                              <tr className="bg-secondary">
                                {t.header.map((h, i) => (
                                  <th key={i} className="text-left font-semibold text-foreground px-3 py-2">{h}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {t.rows.map((row, ri) => (
                                <tr key={ri} className="border-t border-border">
                                  {row.map((cell, ci) => (
                                    <td key={ci} className="px-3 py-2">
                                      {ci === 0 ? <span className="font-mono text-foreground">{cell}</span> : <span className="text-muted-foreground">{cell}</span>}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ))}
                      {section.paragraphs_post?.map((p, i) => (
                        <p key={`p-${i}`} className="text-sm text-muted-foreground leading-relaxed">{p}</p>
                      ))}
                    </div>
                  </section>
                ))}
              </div>

              {/* Footer */}
              <div className="mt-8 pt-6 border-t border-border">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-foreground">Have privacy questions?</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">Our Data Protection Officer is here to help.</p>
                  </div>
                  <div className="flex gap-2">
                    <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent">
                      <Link href="/help/contact">Contact DPO <ArrowRight className="w-3.5 h-3.5" /></Link>
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            {/* PREV / NEXT */}
            <div className="grid grid-cols-2 gap-3">
              <Card className="p-4 card-lift">
                <Link href="/help/terms" className="block">
                  <p className="text-[10px] text-muted-foreground">Previous</p>
                  <p className="text-xs font-semibold text-foreground mt-1">Terms of Service</p>
                </Link>
              </Card>
              <Card className="p-4 card-lift">
                <Link href="/help" className="block text-right">
                  <p className="text-[10px] text-muted-foreground">Next</p>
                  <p className="text-xs font-semibold text-foreground mt-1">Help Center <ChevronRight className="w-3 h-3 inline" /></p>
                </Link>
              </Card>
            </div>
          </div>
        </div>
      </HelpLayout>
    </DashboardShell>
  )
}
