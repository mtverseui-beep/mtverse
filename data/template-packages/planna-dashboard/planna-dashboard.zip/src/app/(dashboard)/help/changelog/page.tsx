"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Search, Sparkles, Zap, Wrench, Rocket, ChevronRight, Pin,
  Mail, Bell, ArrowRight, Calendar, Tag, GitBranch, type LucideIcon,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn, formatDate, initials } from "@/lib/utils"
import { toast } from "sonner"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// RELEASE DATA
// ============================================================

type ChangeType = "added" | "improved" | "fixed"

interface Change {
  type: ChangeType
  text: string
}

interface Release {
  id: string
  version: string
  date: string
  title: string
  summary: string
  author: string
  authorAvatar: string
  pinned?: boolean
  latest?: boolean
  status: "released" | "beta" | "planned"
  changes: Change[]
}

const RELEASES: Release[] = [
  {
    id: "rel-2-4",
    version: "v2.4.0",
    date: "2026-01-28",
    title: "Command Palette & Kanban 2.0",
    summary: "Press ⌘K anywhere to search pages, tasks, projects, and trigger quick actions. Plus a rebuilt Kanban with drag-and-drop, optimistic updates, and WIP limits.",
    author: members[0].name,
    authorAvatar: members[0].avatar,
    pinned: true,
    latest: true,
    status: "released",
    changes: [
      { type: "added", text: "Command palette (⌘K) with fuzzy search across pages, tasks, projects, and quick actions" },
      { type: "added", text: "Kanban drag-and-drop with optimistic updates and rollback on error" },
      { type: "added", text: "WIP limits per column with visual warning when exceeded" },
      { type: "added", text: "Recurring task scheduler — daily, weekly, monthly recurrence with skip-on-holiday" },
      { type: "improved", text: "Notification center with type filters and date grouping" },
      { type: "improved", text: "Sidebar now collapses to icon-only on smaller viewports" },
      { type: "fixed", text: "WebSocket reconnect no longer silently fails after 10 retries — added manual reconnect button" },
      { type: "fixed", text: "IDOR vulnerability in /api/v1/projects/{id} (SEC-901)" },
      { type: "fixed", text: "Theme toggle flash on first page load" },
    ],
  },
  {
    id: "rel-2-3",
    version: "v2.3.0",
    date: "2026-01-14",
    title: "Time tracking 2.0 & Focus mode",
    summary: "A rebuilt time tracking experience with pause/resume, manual entries, and a new Focus mode for distraction-free deep work.",
    author: members[2].name,
    authorAvatar: members[2].avatar,
    status: "released",
    changes: [
      { type: "added", text: "Focus mode with Pomodoro timer (25/5, 50/10, custom)" },
      { type: "added", text: "Pause / resume for running time entries" },
      { type: "added", text: "Manual time entry modal with last-used project pre-selected" },
      { type: "added", text: "Time approval workflow — submit, approve, reject" },
      { type: "improved", text: "Billable vs non-billable split is now visible on every time entry" },
      { type: "improved", text: "Weekly timesheet view prints cleanly to PDF" },
      { type: "fixed", text: "Time entries with midnight crossover no longer split into two entries" },
    ],
  },
  {
    id: "rel-2-2",
    version: "v2.2.0",
    date: "2025-12-22",
    title: "Analytics overhaul & Custom dashboards",
    summary: "Eight new analytics views, custom dashboard builder, and a productivity score that adapts to your team's working patterns.",
    author: members[5].name,
    authorAvatar: members[5].avatar,
    status: "released",
    changes: [
      { type: "added", text: "Custom dashboard builder — drag widgets onto a canvas, share with team" },
      { type: "added", text: "Productivity score with team-specific weighting" },
      { type: "added", text: "Velocity chart with rolling 6-sprint average" },
      { type: "added", text: "Workload heatmap by person × week" },
      { type: "improved", text: "All charts now print cleanly to PDF" },
      { type: "fixed", text: "Custom date range picker now respects workspace timezone" },
    ],
  },
  {
    id: "rel-2-1",
    version: "v2.1.0",
    date: "2025-12-08",
    title: "Team roles, SSO & Audit logs",
    summary: "Granular roles, SAML SSO for Enterprise, and a complete audit log so you always know who did what and when.",
    author: members[1].name,
    authorAvatar: members[1].avatar,
    status: "released",
    changes: [
      { type: "added", text: "Five-tier role system (Owner, Admin, Manager, Member, Viewer)" },
      { type: "added", text: "SAML 2.0 SSO with IdP-initiated and SP-initiated flows" },
      { type: "added", text: "SCIM 2.0 user provisioning for automated onboarding/offboarding" },
      { type: "added", text: "Audit log with 90-day retention (1-year on Enterprise)" },
      { type: "improved", text: "Invite links now expire after 7 days for security" },
      { type: "fixed", text: "Guest users could view internal-only labels — patched" },
    ],
  },
  {
    id: "rel-2-0",
    version: "v2.0.0",
    date: "2025-11-15",
    title: "Planna 2.0 — a complete rewrite",
    summary: "We rebuilt Planna from the ground up on a new event-sourced backend, cutting p95 latency by 8× and unlocking real-time everything.",
    author: members[0].name,
    authorAvatar: members[0].avatar,
    status: "released",
    changes: [
      { type: "added", text: "Real-time collaboration with conflict-free replicated data types (CRDTs)" },
      { type: "added", text: "Brand-new design system with light/dark themes and accent colors" },
      { type: "added", text: "Public REST API with OAuth 2.0 and personal access tokens" },
      { type: "added", text: "Webhooks for 30+ events with HMAC signatures and retries" },
      { type: "improved", text: "p95 API latency down from 480ms to 60ms" },
      { type: "improved", text: "Mobile apps rebuilt with offline-first sync" },
      { type: "fixed", text: "Dozens of long-standing paper cuts — see upgrade guide for the full list" },
    ],
  },
  {
    id: "rel-1-9",
    version: "v1.9.4",
    date: "2025-10-22",
    title: "Maintenance release",
    summary: "Quality-of-life fixes ahead of the 2.0 launch.",
    author: members[8].name,
    authorAvatar: members[8].avatar,
    status: "released",
    changes: [
      { type: "improved", text: "Email digest now includes task completion stats" },
      { type: "fixed", text: "Two-factor auth enrollment flow on Safari 17" },
      { type: "fixed", text: "Calendar sync occasionally duplicated recurring events" },
      { type: "fixed", text: "Search results pagination off-by-one on page 1" },
    ],
  },
]

const TYPE_CONFIG: Record<ChangeType, { label: string; icon: LucideIcon; className: string }> = {
  added: { label: "New", icon: Sparkles, className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  improved: { label: "Improved", icon: Zap, className: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  fixed: { label: "Fixed", icon: Wrench, className: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
}

// ============================================================
// CHANGE BULLET
// ============================================================

function ChangeBullet({ change }: { change: Change }) {
  const cfg = TYPE_CONFIG[change.type]
  const TIcon = cfg.icon
  return (
    <li className="flex items-start gap-2.5 text-sm">
      <span className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full shrink-0 mt-0.5", cfg.className)}>
        <TIcon className="w-2.5 h-2.5" />
        {cfg.label}
      </span>
      <span className="text-foreground leading-snug">{change.text}</span>
    </li>
  )
}

// ============================================================
// RELEASE CARD
// ============================================================

function ReleaseCard({ release }: { release: Release }) {
  const grouped = useMemo(() => {
    const m: Record<ChangeType, Change[]> = { added: [], improved: [], fixed: [] }
    release.changes.forEach(c => m[c.type].push(c))
    return m
  }, [release])

  return (
    <Card className={cn(
      "p-5 md:p-6 card-lift relative",
      release.latest && "border-primary ring-2 ring-primary/20 bg-primary/5",
    )}>
      {/* Left timeline dot */}
      <div className="absolute -left-[9px] top-7 w-3.5 h-3.5 rounded-full bg-primary ring-4 ring-background hidden lg:block" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-4">
        <div className="flex items-start gap-3 min-w-0">
          <div className={cn(
            "w-11 h-11 rounded-xl flex items-center justify-center shrink-0",
            release.latest ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground",
          )}>
            <GitBranch className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5 bg-primary/10 text-primary font-mono font-semibold">
                {release.version}
              </Badge>
              {release.pinned && (
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5 bg-amber-500/15 text-amber-600 dark:text-amber-400 gap-1">
                  <Pin className="w-2.5 h-2.5" /> Pinned
                </Badge>
              )}
              {release.latest && (
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 gap-1">
                  <span className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" /> Latest
                </Badge>
              )}
            </div>
            <h3 className="text-base font-bold text-foreground tracking-tight mt-1.5">{release.title}</h3>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{release.summary}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0 sm:text-right">
          <Avatar className="w-7 h-7">
            <AvatarImage src={release.authorAvatar} alt={release.author} />
            <AvatarFallback>{initials(release.author)}</AvatarFallback>
          </Avatar>
          <div className="text-[10px] text-muted-foreground">
            <p className="text-foreground font-medium">{release.author}</p>
            <p className="flex items-center gap-1 sm:justify-end"><Calendar className="w-2.5 h-2.5" /> {formatDate(release.date)}</p>
          </div>
        </div>
      </div>

      {/* Changes */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
        {(["added", "improved", "fixed"] as ChangeType[]).map(type => (
          grouped[type].length > 0 && (
            <div key={type} className="space-y-2">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                {type === "added" && <Sparkles className="w-3 h-3 text-emerald-500" />}
                {type === "improved" && <Zap className="w-3 h-3 text-amber-500" />}
                {type === "fixed" && <Wrench className="w-3 h-3 text-sky-500" />}
                {TYPE_CONFIG[type].label}
                <span className="text-muted-foreground/60">({grouped[type].length})</span>
              </p>
              <ul className="space-y-1.5">
                {grouped[type].map((c, i) => <ChangeBullet key={i} change={c} />)}
              </ul>
            </div>
          )
        ))}
      </div>
    </Card>
  )
}

// ============================================================
// PAGE
// ============================================================

export default function ChangelogPage() {
  const [query, setQuery] = useState("")
  const [subscribed, setSubscribed] = useState(false)
  const [email, setEmail] = useState("")

  const filtered = useMemo(() => {
    if (!query.trim()) return RELEASES
    const q = query.toLowerCase()
    return RELEASES.filter(r =>
      r.title.toLowerCase().includes(q) ||
      r.summary.toLowerCase().includes(q) ||
      r.version.toLowerCase().includes(q) ||
      r.changes.some(c => c.text.toLowerCase().includes(q)),
    )
  }, [query])

  const subscribe = () => {
    if (!email.trim() || !email.includes("@")) {
      toast.error("Enter a valid email address")
      return
    }
    setSubscribed(true)
    toast.success("Subscribed to changelog", { description: `We'll send future release notes to ${email}.` })
    setEmail("")
  }

  return (
    <DashboardShell
      title="Changelog"
      description="Every release, every improvement. See what's new in Planna — updated with each ship."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5">
          <a href="#subscribe"><Bell className="w-3.5 h-3.5" /> Subscribe</a>
        </Button>
      }
    >
      <HelpMobileNav />
      <HelpLayout>
        {/* SUBSCRIBE CTA */}
        <Card id="subscribe" className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <Rocket className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-foreground">Get release notes in your inbox</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {subscribed
                  ? "You're subscribed! We'll email you whenever we ship something new."
                  : "We ship every 2 weeks. Get an email whenever we release — no marketing, just changelog."}
              </p>
            </div>
            <div className="flex gap-2 shrink-0 w-full md:w-auto">
              <Input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="h-9 text-sm md:w-64"
                disabled={subscribed}
              />
              <Button
                onClick={subscribe}
                disabled={subscribed}
                className="h-9 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90 shrink-0"
              >
                {subscribed ? <><Sparkles className="w-3.5 h-3.5" /> Subscribed</> : <>Subscribe <ArrowRight className="w-3.5 h-3.5" /></>}
              </Button>
            </div>
          </div>
        </Card>

        {/* SEARCH */}
        <Card className="p-4 card-lift">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search releases, features, or fixes…"
              className="h-9 pl-9 text-sm"
            />
          </div>
        </Card>

        {/* TIMELINE */}
        {filtered.length === 0 ? (
          <Card className="p-12 border-dashed text-center">
            <GitBranch className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm font-semibold text-foreground">No releases found</p>
            <p className="text-xs text-muted-foreground mt-1">Try a different search term.</p>
          </Card>
        ) : (
          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-[2px] top-7 bottom-7 w-px bg-border hidden lg:block" />
            <div className="space-y-4">
              {filtered.map((r, i) => (
                <div key={r.id} className={cn("lg:pl-4", `stagger-${Math.min(i + 1, 6)}`)}>
                  <ReleaseCard release={r} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* FOOTER */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Mail className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-foreground">Want to request a feature?</h3>
              <p className="text-xs text-muted-foreground mt-0.5">We prioritize based on customer feedback. Send us your ideas.</p>
            </div>
            <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent shrink-0">
              <Link href="/help/contact">Submit feedback <ChevronRight className="w-3.5 h-3.5" /></Link>
            </Button>
          </div>
        </Card>
      </HelpLayout>
    </DashboardShell>
  )
}
