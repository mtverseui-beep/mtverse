"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Search, ArrowRight, LifeBuoy, BookOpen, Rocket, Keyboard, GitBranch,
  Mail, HelpCircle, CreditCard, ShieldCheck, Sparkles, CheckCircle2,
  Wrench, Zap, Users, Calendar, Clock, BarChart3, Code, Bell,
  FolderKanban, ListChecks, type LucideIcon,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn, initials, timeAgo } from "@/lib/utils"
import { toast } from "sonner"
import { HelpMobileNav } from "./_lib"

// ============================================================
// POPULAR ARTICLES DATA
// ============================================================

interface Article {
  id: string
  title: string
  category: string
  icon: LucideIcon
  views: string
}

const POPULAR_ARTICLES: Article[] = [
  { id: "a1", title: "Setting up your first project", category: "Getting Started", icon: Rocket, views: "12.4K" },
  { id: "a2", title: "Inviting teammates and managing roles", category: "Team", icon: Users, views: "9.8K" },
  { id: "a3", title: "Mastering the Kanban board", category: "Tasks", icon: FolderKanban, views: "8.6K" },
  { id: "a4", title: "Time tracking best practices", category: "Time", icon: Clock, views: "7.2K" },
  { id: "a5", title: "Working with the calendar view", category: "Calendar", icon: Calendar, views: "6.9K" },
  { id: "a6", title: "Custom analytics and dashboards", category: "Analytics", icon: BarChart3, views: "5.7K" },
  { id: "a7", title: "Securing your workspace with 2FA", category: "Security", icon: ShieldCheck, views: "5.1K" },
  { id: "a8", title: "Getting started with the Planna API", category: "API", icon: Code, views: "4.4K" },
]

// ============================================================
// CATEGORY TILES
// ============================================================

interface Category {
  id: string
  label: string
  description: string
  icon: LucideIcon
  articles: number
  href: string
  tint: string
}

const CATEGORIES: Category[] = [
  { id: "c1", label: "Getting Started", description: "Onboard your team in under 10 minutes.", icon: Rocket, articles: 18, href: "/help/getting-started", tint: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  { id: "c2", label: "Tasks", description: "Create, assign, prioritize, and ship work.", icon: ListChecks, articles: 42, href: "/help/docs", tint: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
  { id: "c3", label: "Projects", description: "Organize work, milestones, and timelines.", icon: FolderKanban, articles: 35, href: "/help/docs", tint: "bg-lime-500/15 text-lime-600 dark:text-lime-400" },
  { id: "c4", label: "Team", description: "Roles, permissions, and collaboration.", icon: Users, articles: 28, href: "/help/docs", tint: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-400" },
  { id: "c5", label: "Billing", description: "Plans, invoices, and payment methods.", icon: CreditCard, articles: 22, href: "/help/pricing", tint: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  { id: "c6", label: "Security", description: "2FA, SSO, audit logs, and data safety.", icon: ShieldCheck, articles: 19, href: "/help/docs", tint: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
  { id: "c7", label: "API", description: "Build on Planna with REST and webhooks.", icon: Code, articles: 31, href: "/help/docs", tint: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
]

// ============================================================
// WHAT'S NEW
// ============================================================

interface WhatsNew {
  id: string
  title: string
  type: "new" | "improved" | "fixed"
  date: string
}

const WHATS_NEW: WhatsNew[] = [
  { id: "w1", title: "Command palette (⌘K) with fuzzy search across everything", type: "new", date: "2026-01-28" },
  { id: "w2", title: "Kanban 2.0 with drag-and-drop and WIP limits", type: "new", date: "2026-01-28" },
  { id: "w3", title: "Rebuilt notification center with filters", type: "improved", date: "2026-01-28" },
  { id: "w4", title: "Sidebar collapses to icon-only on smaller viewports", type: "improved", date: "2026-01-28" },
  { id: "w5", title: "WebSocket reconnect no longer silently fails", type: "fixed", date: "2026-01-28" },
  { id: "w6", title: "Theme toggle flash on first page load", type: "fixed", date: "2026-01-28" },
]

const TYPE_CONFIG = {
  new: { label: "New", icon: Sparkles, className: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  improved: { label: "Improved", icon: Zap, className: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  fixed: { label: "Fixed", icon: Wrench, className: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
} as const

const QUICK_LINKS = [
  { href: "/help/docs", label: "Documentation", icon: BookOpen, description: "Complete guides" },
  { href: "/help/shortcuts", label: "Shortcuts", icon: Keyboard, description: "Work faster" },
  { href: "/help/changelog", label: "Changelog", icon: GitBranch, description: "What's new" },
  { href: "/help/faq", label: "FAQ", icon: HelpCircle, description: "Quick answers" },
] as const

// ============================================================
// PAGE
// ============================================================

export default function HelpCenterPage() {
  const [query, setQuery] = useState("")

  const filteredArticles = query.trim()
    ? POPULAR_ARTICLES.filter(a =>
        a.title.toLowerCase().includes(query.toLowerCase()) ||
        a.category.toLowerCase().includes(query.toLowerCase()),
      )
    : POPULAR_ARTICLES

  return (
    <DashboardShell
      title="Help Center"
      description="Find answers, browse docs, and get the most out of Planna."
      actions={
        <Button asChild size="sm" className="h-9 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
          <Link href="/help/contact"><Mail className="w-3.5 h-3.5" /> Contact support</Link>
        </Button>
      }
    >
      <HelpMobileNav />

      <div className="space-y-6">
        {/* HERO SEARCH */}
        <Card className="p-6 md:p-10 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20 relative overflow-hidden">
          <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-primary/10 blur-3xl pointer-events-none" />
          <div className="relative max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-primary/15 text-primary text-[10px] font-semibold mb-4">
              <LifeBuoy className="w-3 h-3" />
              We're here to help
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight mb-2">
              How can we help you?
            </h1>
            <p className="text-sm text-muted-foreground mb-5">
              Search our knowledge base, browse popular articles, or get in touch with our team.
            </p>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search for help…"
                className="h-12 pl-11 pr-4 text-sm bg-background border-border rounded-xl shadow-sm"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground"
                >
                  Clear
                </button>
              )}
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
              <span className="text-[11px] text-muted-foreground">Popular:</span>
              {["Kanban", "Time tracking", "API", "2FA"].map(term => (
                <button
                  key={term}
                  type="button"
                  onClick={() => setQuery(term)}
                  className="text-[11px] px-2 py-0.5 rounded-full bg-secondary text-foreground hover:bg-primary/10 hover:text-primary transition-colors"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* QUICK LINKS */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {QUICK_LINKS.map(q => {
            const Icon = q.icon
            return (
              <Card key={q.href} className="p-4 card-lift group cursor-pointer">
                <Link href={q.href} className="block">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-2.5 transition-transform group-hover:scale-110">
                    <Icon className="w-4 h-4" />
                  </div>
                  <p className="text-xs font-semibold text-foreground">{q.label}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">{q.description}</p>
                </Link>
              </Card>
            )
          })}
        </div>

        {/* POPULAR ARTICLES */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Popular articles</h3>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                Most-read guides this week
              </p>
            </div>
            <Button asChild variant="ghost" size="sm" className="h-8 text-xs">
              <Link href="/help/docs">View all docs <ArrowRight className="w-3.5 h-3.5" /></Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {filteredArticles.length === 0 ? (
              <Card className="p-6 col-span-full text-center border-dashed">
                <p className="text-xs text-muted-foreground">No articles match "{query}".</p>
              </Card>
            ) : filteredArticles.map((a, i) => {
              const Icon = a.icon
              return (
                <Card
                  key={a.id}
                  className={cn("p-4 card-lift group cursor-pointer", `stagger-${Math.min(i + 1, 6)}`)}
                >
                  <Link href="/help/docs" className="block">
                    <div className="flex items-start justify-between mb-2">
                      <div className="w-9 h-9 rounded-lg bg-secondary text-foreground flex items-center justify-center transition-transform group-hover:scale-110">
                        <Icon className="w-4 h-4" />
                      </div>
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4 bg-secondary text-muted-foreground">
                        {a.views} views
                      </Badge>
                    </div>
                    <p className="text-xs font-semibold text-foreground leading-snug mb-1">{a.title}</p>
                    <p className="text-[11px] text-muted-foreground">{a.category}</p>
                  </Link>
                </Card>
              )
            })}
          </div>
        </div>

        {/* CATEGORY TILES */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Browse by category</h3>
              <p className="text-[11px] text-muted-foreground mt-0.5">Find help by topic</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {CATEGORIES.map(c => {
              const Icon = c.icon
              return (
                <Card key={c.id} className="p-4 card-lift group cursor-pointer">
                  <Link href={c.href} className="flex items-start gap-3">
                    <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0 transition-transform group-hover:scale-110", c.tint)}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-semibold text-foreground">{c.label}</p>
                        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{c.description}</p>
                      <p className="text-[10px] text-muted-foreground mt-1.5">{c.articles} articles</p>
                    </div>
                  </Link>
                </Card>
              )
            })}
          </div>
        </div>

        {/* WHAT'S NEW */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">What's new</h3>
                <p className="text-[11px] text-muted-foreground">Latest release highlights — v2.4.0</p>
              </div>
            </div>
            <Button asChild variant="outline" size="sm" className="h-8 text-xs bg-transparent">
              <Link href="/help/changelog">Full changelog <ArrowRight className="w-3.5 h-3.5" /></Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2.5">
            {WHATS_NEW.map(w => {
              const cfg = TYPE_CONFIG[w.type]
              const TIcon = cfg.icon
              return (
                <div key={w.id} className="flex items-start gap-2.5 py-1">
                  <div className={cn("inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full shrink-0 mt-0.5", cfg.className)}>
                    <TIcon className="w-2.5 h-2.5" />
                    {cfg.label}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-foreground leading-snug">{w.title}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{timeAgo(w.date)}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* CONTACT SUPPORT CTA */}
        <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="flex -space-x-2">
              {[0, 1, 2].map(i => (
                <Avatar key={i} className="w-10 h-10 ring-2 ring-background">
                  <AvatarImage src={members[i].avatar} alt={members[i].name} />
                  <AvatarFallback>{initials(members[i].name)}</AvatarFallback>
                </Avatar>
              ))}
              <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground ring-2 ring-background flex items-center justify-center text-[10px] font-bold">
                +24
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-sm font-semibold text-foreground">Still need help?</h3>
                <Badge className="text-[10px] px-1.5 py-0 h-4 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                  <span className="w-1 h-1 rounded-full bg-emerald-500 mr-1 animate-pulse" />
                  Online now
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                Our support team typically replies in under 2 hours during business hours. Reach out any time — we've got you covered.
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent">
                <Link href="/help/faq">Read FAQ</Link>
              </Button>
              <Button asChild size="sm" className="h-9 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/help/contact"><Mail className="w-3.5 h-3.5" /> Contact support</Link>
              </Button>
            </div>
          </div>
        </Card>

        {/* FOOTER PROMISES */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { icon: CheckCircle2, title: "99.99% uptime", description: "Production-grade reliability SLA." },
            { icon: Clock, title: "< 2 hour response", description: "Average first reply on weekdays." },
            { icon: Users, title: "24/7 coverage", description: "Global team across 5 timezones." },
          ].map(item => {
            const Icon = item.icon
            return (
              <Card key={item.title} className="p-4 card-lift">
                <div className="flex items-start gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-foreground">{item.title}</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{item.description}</p>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      </div>
    </DashboardShell>
  )
}
