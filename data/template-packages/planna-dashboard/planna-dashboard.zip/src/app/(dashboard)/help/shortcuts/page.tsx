"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Search, Keyboard, Command, ArrowRight, type LucideIcon,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// TYPES & DATA
// ============================================================

type Platform = "mac" | "win"

interface Shortcut {
  id: string
  description: string
  keys: {
    mac: string[]
    win: string[]
  }
  category: string
}

const CATEGORIES = ["Global", "Navigation", "Tasks", "Editor", "Command Palette"] as const

const SHORTCUTS: Shortcut[] = [
  // Global
  { id: "g1", description: "Open command palette", keys: { mac: ["⌘", "K"], win: ["Ctrl", "K"] }, category: "Global" },
  { id: "g2", description: "Toggle dark / light theme", keys: { mac: ["⇧", "⌘", "L"], win: ["Shift", "Ctrl", "L"] }, category: "Global" },
  { id: "g3", description: "Open search everywhere", keys: { mac: ["⌘", "/"], win: ["Ctrl", "/"] }, category: "Global" },
  { id: "g4", description: "Show keyboard shortcuts help", keys: { mac: ["⇧", "?"], win: ["Shift", "?"] }, category: "Global" },
  { id: "g5", description: "Collapse / expand sidebar", keys: { mac: ["⌘", "B"], win: ["Ctrl", "B"] }, category: "Global" },
  { id: "g6", description: "Create new item (smart)", keys: { mac: ["C"], win: ["C"] }, category: "Global" },
  { id: "g7", description: "Go to notifications", keys: { mac: ["⌘", "I"], win: ["Ctrl", "I"] }, category: "Global" },
  { id: "g8", description: "Open settings", keys: { mac: ["⇧", "⌘", ","], win: ["Shift", "Ctrl", ","] }, category: "Global" },

  // Navigation
  { id: "n1", description: "Go to Dashboard", keys: { mac: ["G", "D"], win: ["G", "D"] }, category: "Navigation" },
  { id: "n2", description: "Go to Projects", keys: { mac: ["G", "P"], win: ["G", "P"] }, category: "Navigation" },
  { id: "n3", description: "Go to Tasks", keys: { mac: ["G", "T"], win: ["G", "T"] }, category: "Navigation" },
  { id: "n4", description: "Go to Kanban", keys: { mac: ["G", "K"], win: ["G", "K"] }, category: "Navigation" },
  { id: "n5", description: "Go to Calendar", keys: { mac: ["G", "C"], win: ["G", "C"] }, category: "Navigation" },
  { id: "n6", description: "Go to Team", keys: { mac: ["G", "M"], win: ["G", "M"] }, category: "Navigation" },
  { id: "n7", description: "Go to Time tracking", keys: { mac: ["G", "I"], win: ["G", "I"] }, category: "Navigation" },
  { id: "n8", description: "Go back / forward in history", keys: { mac: ["⌥", "←"], win: ["Alt", "←"] }, category: "Navigation" },

  // Tasks
  { id: "t1", description: "Create new task", keys: { mac: ["N"], win: ["N"] }, category: "Tasks" },
  { id: "t2", description: "Edit selected task", keys: { mac: ["E"], win: ["E"] }, category: "Tasks" },
  { id: "t3", description: "Mark task complete", keys: { mac: ["X"], win: ["X"] }, category: "Tasks" },
  { id: "t4", description: "Assign to me", keys: { mac: ["A"], win: ["A"] }, category: "Tasks" },
  { id: "t5", description: "Set due date", keys: { mac: ["D"], win: ["D"] }, category: "Tasks" },
  { id: "t6", description: "Change priority", keys: { mac: ["1"], win: ["1"] }, category: "Tasks" },
  { id: "t7", description: "Add label", keys: { mac: ["L"], win: ["L"] }, category: "Tasks" },
  { id: "t8", description: "Move to project", keys: { mac: ["⇧", "P"], win: ["Shift", "P"] }, category: "Tasks" },
  { id: "t9", description: "Archive task", keys: { mac: ["⇧", "⌫"], win: ["Shift", "Del"] }, category: "Tasks" },
  { id: "t10", description: "Start / stop time timer", keys: { mac: ["⇧", "T"], win: ["Shift", "T"] }, category: "Tasks" },

  // Editor
  { id: "e1", description: "Bold selected text", keys: { mac: ["⌘", "B"], win: ["Ctrl", "B"] }, category: "Editor" },
  { id: "e2", description: "Italic selected text", keys: { mac: ["⌘", "I"], win: ["Ctrl", "I"] }, category: "Editor" },
  { id: "e3", description: "Insert link", keys: { mac: ["⌘", "K"], win: ["Ctrl", "K"] }, category: "Editor" },
  { id: "e4", description: "Insert code block", keys: { mac: ["⇧", "⌘", "C"], win: ["Shift", "Ctrl", "C"] }, category: "Editor" },
  { id: "e5", description: "Insert @mention", keys: { mac: ["@"], win: ["@"] }, category: "Editor" },
  { id: "e6", description: "Insert task list", keys: { mac: ["⇧", "⌘", "X"], win: ["Shift", "Ctrl", "X"] }, category: "Editor" },
  { id: "e7", description: "Save draft", keys: { mac: ["⌘", "S"], win: ["Ctrl", "S"] }, category: "Editor" },
  { id: "e8", description: "Submit / send", keys: { mac: ["⌘", "↵"], win: ["Ctrl", "↵"] }, category: "Editor" },

  // Command Palette
  { id: "c1", description: "Open command palette", keys: { mac: ["⌘", "K"], win: ["Ctrl", "K"] }, category: "Command Palette" },
  { id: "c2", description: "Quick switch project", keys: { mac: ["⌘", "P"], win: ["Ctrl", "P"] }, category: "Command Palette" },
  { id: "c3", description: "Run any command", keys: { mac: [">"], win: [">"] }, category: "Command Palette" },
  { id: "c4", description: "Search settings", keys: { mac: ["⇧", ","], win: ["Shift", ","] }, category: "Command Palette" },
  { id: "c5", description: "Move selection up", keys: { mac: ["↑"], win: ["↑"] }, category: "Command Palette" },
  { id: "c6", description: "Move selection down", keys: { mac: ["↓"], win: ["↓"] }, category: "Command Palette" },
  { id: "c7", description: "Confirm selection", keys: { mac: ["↵"], win: ["↵"] }, category: "Command Palette" },
  { id: "c8", description: "Dismiss palette", keys: { mac: ["Esc"], win: ["Esc"] }, category: "Command Palette" },
]

// ============================================================
// KBD COMPONENT
// ============================================================

function Kbd({ label }: { label: string }) {
  const base = "inline-flex items-center justify-center min-w-[28px] h-7 px-2 rounded-md border border-border bg-secondary text-foreground text-[11px] font-semibold font-mono shadow-[0_2px_0_0_var(--border)]"
  return <span className={cn(base, label.length > 1 && "px-2.5")}>{label}</span>
}

function KeyCombo({ keys }: { keys: string[] }) {
  return (
    <div className="flex items-center gap-1">
      {keys.map((p, i) => (
        <span key={i} className="flex items-center gap-1">
          <Kbd label={p} />
          {i < keys.length - 1 && <span className="text-muted-foreground text-[10px]">+</span>}
        </span>
      ))}
    </div>
  )
}

// ============================================================
// PAGE
// ============================================================

export default function ShortcutsPage() {
  const [platform, setPlatform] = useState<Platform>("mac")
  const [query, setQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState<string>("All")

  const filtered = useMemo(() => {
    return SHORTCUTS.filter(s => {
      const matchCat = activeCategory === "All" || s.category === activeCategory
      const matchQuery = !query.trim() ||
        s.description.toLowerCase().includes(query.toLowerCase()) ||
        s.category.toLowerCase().includes(query.toLowerCase())
      return matchCat && matchQuery
    })
  }, [query, activeCategory])

  const grouped = useMemo(() => {
    const map: Record<string, Shortcut[]> = {}
    filtered.forEach(s => {
      if (!map[s.category]) map[s.category] = []
      map[s.category].push(s)
    })
    return map
  }, [filtered])

  return (
    <DashboardShell
      title="Keyboard Shortcuts"
      description="Work faster in Planna with these keyboard shortcuts. Press ⌘K anytime to open the command palette."
      actions={
        <div className="flex items-center gap-2">
          {/* Platform toggle */}
          <div className="inline-flex items-center gap-1 rounded-lg bg-muted p-1 h-9">
            <button
              type="button"
              onClick={() => setPlatform("mac")}
              className={cn(
                "h-7 px-3 text-xs font-medium rounded-md transition-all",
                platform === "mac" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
              )}
            >
              Mac
            </button>
            <button
              type="button"
              onClick={() => setPlatform("win")}
              className={cn(
                "h-7 px-3 text-xs font-medium rounded-md transition-all",
                platform === "win" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
              )}
            >
              Windows
            </button>
          </div>
        </div>
      }
    >
      <HelpMobileNav />
      <HelpLayout>
        {/* SEARCH + FILTERS */}
        <Card className="p-4 md:p-5 card-lift">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search shortcuts…"
                className="h-9 pl-9 text-sm"
              />
            </div>
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
              <button
                type="button"
                onClick={() => setActiveCategory("All")}
                className={cn(
                  "h-9 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                  activeCategory === "All"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground hover:text-foreground",
                )}
              >
                All ({SHORTCUTS.length})
              </button>
              {CATEGORIES.map(cat => {
                const count = SHORTCUTS.filter(s => s.category === cat).length
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setActiveCategory(cat)}
                    className={cn(
                      "h-9 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                      activeCategory === cat
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {cat} ({count})
                  </button>
                )
              })}
            </div>
          </div>
        </Card>

        {/* SHORTCUTS BY CATEGORY */}
        {Object.keys(grouped).length === 0 ? (
          <Card className="p-12 border-dashed text-center">
            <Keyboard className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm font-semibold text-foreground">No shortcuts found</p>
            <p className="text-xs text-muted-foreground mt-1">
              No shortcuts match "{query}". Try a different search term.
            </p>
          </Card>
        ) : (
          <div className="space-y-4">
            {CATEGORIES.filter(c => grouped[c]).map(cat => (
              <Card key={cat} className="p-5 md:p-6 card-lift">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                    <Keyboard className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-foreground">{cat}</h3>
                    <p className="text-[11px] text-muted-foreground">{grouped[cat].length} shortcuts</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
                  {grouped[cat].map(s => (
                    <div
                      key={s.id}
                      className="flex items-center justify-between gap-3 py-2 border-b border-border/60 last:border-b-0 group"
                    >
                      <p className="text-xs text-foreground group-hover:text-primary transition-colors">{s.description}</p>
                      <KeyCombo keys={platform === "mac" ? s.keys.mac : s.keys.win} />
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* COMMAND PALETTE HINT */}
        <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <Command className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-foreground">Pro tip: Master the command palette</h3>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                Press <span className="font-mono text-foreground">⌘K</span> (Mac) or <span className="font-mono text-foreground">Ctrl+K</span> (Windows) anywhere in Planna to search pages, tasks, projects, and trigger quick actions without ever touching the mouse.
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent">
                <Link href="/help/docs">Learn more</Link>
              </Button>
              <Button asChild size="sm" className="h-9 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/dashboard">Try it now <ArrowRight className="w-3.5 h-3.5" /></Link>
              </Button>
            </div>
          </div>
        </Card>

        {/* LEGEND */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <h3 className="text-sm font-semibold text-foreground mb-3">Modifier key legend</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { mac: "⌘", win: "Ctrl", label: "Command / Control", icon: Command },
              { mac: "⇧", win: "Shift", label: "Shift", icon: Keyboard },
              { mac: "⌥", win: "Alt", label: "Option / Alt", icon: Keyboard },
              { mac: "⌃", win: "Ctrl", label: "Control", icon: Keyboard },
            ].map(m => {
              const MIcon = m.icon as LucideIcon
              return (
                <div key={m.label} className="flex items-center gap-2 p-3 rounded-lg border border-border">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                    <MIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-foreground">{platform === "mac" ? m.mac : m.win}</p>
                    <p className="text-[10px] text-muted-foreground">{m.label}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>
      </HelpLayout>
    </DashboardShell>
  )
}
