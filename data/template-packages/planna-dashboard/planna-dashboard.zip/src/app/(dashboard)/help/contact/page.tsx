"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Mail, MessageSquare, Phone, Clock, Paperclip, X, Send,
  ChevronRight, HelpCircle, Zap, ShieldCheck, CheckCircle2, Upload,
} from "lucide-react"
import { members } from "@/lib/data/mock"
import { cn, formatFileSize, initials } from "@/lib/utils"
import { toast } from "sonner"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// CONTACT METHODS
// ============================================================

interface ContactMethod {
  id: string
  label: string
  icon: typeof Mail
  description: string
  availability: string
  responseTime: string
  cta: string
  badge?: string
  badgeColor?: string
  tint: string
}

const CONTACT_METHODS: ContactMethod[] = [
  {
    id: "email",
    label: "Email support",
    icon: Mail,
    description: "Best for detailed issues with screenshots. Open a ticket and we'll reply in writing.",
    availability: "24/7 — submit anytime",
    responseTime: "< 2 hours (business hours)",
    cta: "support@planna.app",
    badge: "All plans",
    badgeColor: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
    tint: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
  },
  {
    id: "chat",
    label: "Live chat",
    icon: MessageSquare,
    description: "Quick questions and real-time troubleshooting with our support engineers.",
    availability: "Mon–Fri, 8 AM – 8 PM UTC",
    responseTime: "< 5 minutes",
    cta: "Start a chat",
    badge: "Pro & Scale",
    badgeColor: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
    tint: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  },
  {
    id: "phone",
    label: "Phone support",
    icon: Phone,
    description: "Dedicated phone line for urgent issues. Skip the queue and talk to a human.",
    availability: "24/7 — follow-the-sun",
    responseTime: "Immediate",
    cta: "+1 (415) 555-0142",
    badge: "Enterprise",
    badgeColor: "bg-violet-500/15 text-violet-600 dark:text-violet-400",
    tint: "bg-violet-500/15 text-violet-600 dark:text-violet-400",
  },
]

// ============================================================
// FAQ LINKS
// ============================================================

const QUICK_FAQS = [
  { q: "How do I reset my password?", href: "/help/faq" },
  { q: "How do I invite team members?", href: "/help/faq" },
  { q: "How do I cancel my subscription?", href: "/help/faq" },
  { q: "Where can I download invoices?", href: "/help/faq" },
  { q: "How do I enable two-factor auth?", href: "/help/faq" },
  { q: "How do I export my data?", href: "/help/faq" },
]

// ============================================================
// PAGE
// ============================================================

const CATEGORIES = [
  { value: "account", label: "Account & Login" },
  { value: "billing", label: "Billing & Plans" },
  { value: "tasks", label: "Tasks & Projects" },
  { value: "integrations", label: "Integrations & API" },
  { value: "security", label: "Security & Privacy" },
  { value: "bug", label: "Bug Report" },
  { value: "feature", label: "Feature Request" },
  { value: "other", label: "Other" },
]

const PRIORITIES = [
  { value: "low", label: "Low — general question", color: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
  { value: "medium", label: "Medium — minor issue", color: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  { value: "high", label: "High — workflow blocked", color: "bg-orange-500/15 text-orange-600 dark:text-orange-400" },
  { value: "urgent", label: "Urgent — production down", color: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
]

interface Attachment {
  id: string
  name: string
  size: number
}

export default function ContactPage() {
  const [subject, setSubject] = useState("")
  const [category, setCategory] = useState<string>("")
  const [priority, setPriority] = useState<string>("")
  const [message, setMessage] = useState("")
  const [attachments, setAttachments] = useState<Attachment[]>([])
  const [includeLogs, setIncludeLogs] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [ticketId, setTicketId] = useState("")

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    if (!files.length) return
    const total = attachments.length + files.length
    if (total > 5) {
      toast.error("Max 5 attachments allowed")
      return
    }
    const next: Attachment[] = files.map((f, i) => ({
      id: `${Date.now()}-${i}`,
      name: f.name,
      size: f.size,
    }))
    setAttachments(prev => [...prev, ...next])
    toast.success(`${files.length} file(s) attached`)
  }

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id))
  }

  const submit = () => {
    if (!subject.trim() || !category || !priority || !message.trim()) {
      toast.error("Please fill in all required fields")
      return
    }
    if (message.trim().length < 20) {
      toast.error("Message must be at least 20 characters")
      return
    }
    setSubmitting(true)
    setTimeout(() => {
      setSubmitting(false)
      setSubmitted(true)
      setTicketId(`#PLN-${Math.floor(10000 + Math.random() * 90000)}`)
      toast.success("Ticket submitted", { description: "We'll reply within 2 hours during business hours." })
    }, 1200)
  }

  const reset = () => {
    setSubject("")
    setCategory("")
    setPriority("")
    setMessage("")
    setAttachments([])
    setSubmitted(false)
    setTicketId("")
  }

  return (
    <DashboardShell
      title="Contact Support"
      description="Reach out to our team — we typically reply in under 2 hours during business hours."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5">
          <Link href="/help/faq"><HelpCircle className="w-3.5 h-3.5" /> Read FAQ first</Link>
        </Button>
      }
    >
      <HelpMobileNav />
      <HelpLayout>
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-4">
          {/* LEFT — FORM */}
          <div className="space-y-4 min-w-0">
            {/* CONTACT METHODS */}
            <Card className="p-4 card-lift">
              <h3 className="text-sm font-semibold text-foreground mb-3">Ways to reach us</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {CONTACT_METHODS.map(m => {
                  const MIcon = m.icon
                  return (
                    <div key={m.id} className="p-3 rounded-lg border border-border hover:border-primary/40 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", m.tint)}>
                          <MIcon className="w-4 h-4" />
                        </div>
                        {m.badge && (
                          <Badge variant="secondary" className={cn("text-[9px] px-1.5 py-0 h-4", m.badgeColor)}>
                            {m.badge}
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs font-semibold text-foreground">{m.label}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug min-h-[32px]">{m.description}</p>
                      <div className="mt-2 pt-2 border-t border-border space-y-1">
                        <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5" /> {m.availability}
                        </p>
                        <p className="text-[10px] text-foreground font-medium">{m.responseTime}</p>
                      </div>
                      <p className="text-[11px] text-primary font-mono mt-2">{m.cta}</p>
                    </div>
                  )
                })}
              </div>
            </Card>

            {/* CONTACT FORM */}
            <Card className="p-5 md:p-6 card-lift">
              {submitted ? (
                /* SUCCESS STATE */
                <div className="text-center py-8">
                  <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4 animate-scale-in">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground">Ticket submitted</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Your ticket ID is <span className="font-mono font-semibold text-foreground">{ticketId}</span>
                  </p>
                  <p className="text-xs text-muted-foreground mt-3 max-w-md mx-auto leading-relaxed">
                    We've sent a confirmation email. Our team typically replies within 2 hours during business hours (8 AM – 8 PM UTC).
                  </p>
                  <div className="mt-5 p-3 rounded-lg bg-secondary/50 border border-border text-left max-w-md mx-auto">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">Summary</p>
                    <div className="space-y-1 text-xs">
                      <p className="flex justify-between"><span className="text-muted-foreground">Subject:</span><span className="text-foreground font-medium truncate ml-2">{subject}</span></p>
                      <p className="flex justify-between"><span className="text-muted-foreground">Category:</span><span className="text-foreground font-medium capitalize">{CATEGORIES.find(c => c.value === category)?.label}</span></p>
                      <p className="flex justify-between"><span className="text-muted-foreground">Priority:</span><span className="text-foreground font-medium capitalize">{priority}</span></p>
                      <p className="flex justify-between"><span className="text-muted-foreground">Attachments:</span><span className="text-foreground font-medium">{attachments.length}</span></p>
                    </div>
                  </div>
                  <div className="flex gap-2 justify-center mt-5">
                    <Button variant="outline" size="sm" className="h-9 text-xs bg-transparent" onClick={reset}>
                      Submit another
                    </Button>
                    <Button asChild size="sm" className="h-9 text-xs bg-primary text-primary-foreground hover:bg-primary/90">
                      <Link href="/help">Back to Help Center</Link>
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-foreground">Open a support ticket</h3>
                      <p className="text-[11px] text-muted-foreground">Fill in the form below — all fields marked with * are required.</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {/* Subject */}
                    <div className="space-y-1.5">
                      <Label htmlFor="subject" className="text-xs">Subject *</Label>
                      <Input
                        id="subject"
                        value={subject}
                        onChange={e => setSubject(e.target.value)}
                        placeholder="Brief summary of your issue"
                        className="h-9 text-sm"
                        maxLength={120}
                      />
                      <p className="text-[10px] text-muted-foreground text-right">{subject.length}/120</p>
                    </div>

                    {/* Category + Priority */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label className="text-xs">Category *</Label>
                        <Select value={category} onValueChange={setCategory}>
                          <SelectTrigger className="h-9 text-sm">
                            <SelectValue placeholder="Choose a category" />
                          </SelectTrigger>
                          <SelectContent>
                            {CATEGORIES.map(c => (
                              <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">Priority *</Label>
                        <Select value={priority} onValueChange={setPriority}>
                          <SelectTrigger className="h-9 text-sm">
                            <SelectValue placeholder="How urgent?" />
                          </SelectTrigger>
                          <SelectContent>
                            {PRIORITIES.map(p => (
                              <SelectItem key={p.value} value={p.value}>
                                <span className="flex items-center gap-2">
                                  <span className={cn("w-1.5 h-1.5 rounded-full", p.color.split(" ")[0].replace("/15", ""))} />
                                  {p.label}
                                </span>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Message */}
                    <div className="space-y-1.5">
                      <Label htmlFor="message" className="text-xs">Message *</Label>
                      <Textarea
                        id="message"
                        value={message}
                        onChange={e => setMessage(e.target.value)}
                        placeholder="Describe your issue in detail. Include steps to reproduce, expected vs actual behavior, and any error messages."
                        className="min-h-[160px] text-sm"
                        maxLength={4000}
                      />
                      <p className="text-[10px] text-muted-foreground text-right">{message.length}/4000</p>
                    </div>

                    {/* Attachments */}
                    <div className="space-y-2">
                      <Label className="text-xs">Attachments (optional)</Label>
                      <div className="rounded-lg border border-dashed border-border p-3">
                        {attachments.length > 0 && (
                          <div className="space-y-1.5 mb-2">
                            {attachments.map(a => (
                              <div key={a.id} className="flex items-center gap-2 p-2 rounded-md bg-secondary/50">
                                <div className="w-7 h-7 rounded bg-primary/10 text-primary flex items-center justify-center shrink-0">
                                  <Paperclip className="w-3 h-3" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-xs font-medium text-foreground truncate">{a.name}</p>
                                  <p className="text-[10px] text-muted-foreground">{formatFileSize(a.size)}</p>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => removeAttachment(a.id)}
                                  className="w-6 h-6 rounded hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                        <label className="flex items-center justify-center gap-2 cursor-pointer py-3 hover:bg-secondary/40 rounded-md transition-colors">
                          <Upload className="w-4 h-4 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">
                            {attachments.length ? "Add more files" : "Click to upload screenshots or logs"}
                          </span>
                          <input
                            type="file"
                            multiple
                            accept="image/*,.txt,.log,.pdf,.zip"
                            onChange={handleFile}
                            className="hidden"
                          />
                        </label>
                        <p className="text-[10px] text-muted-foreground text-center mt-1">
                          Max 5 files · 10 MB each · PNG, JPG, PDF, TXT, LOG, ZIP
                        </p>
                      </div>
                    </div>

                    {/* Include diagnostic logs */}
                    <label className="flex items-start gap-2.5 p-3 rounded-lg border border-border cursor-pointer hover:bg-secondary/40 transition-colors">
                      <Checkbox
                        checked={includeLogs}
                        onCheckedChange={(v) => setIncludeLogs(!!v)}
                      />
                      <div className="flex-1">
                        <p className="text-xs font-semibold text-foreground">Include diagnostic info</p>
                        <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                          Attaches your browser, OS, and Planna version so we can reproduce faster. No personal data is included.
                        </p>
                      </div>
                    </label>

                    {/* Submit */}
                    <div className="flex items-center justify-between gap-2 pt-2">
                      <p className="text-[11px] text-muted-foreground">
                        By submitting, you agree to our <Link href="/help/terms" className="text-primary hover:underline">Terms</Link> and <Link href="/help/privacy" className="text-primary hover:underline">Privacy Policy</Link>.
                      </p>
                      <Button
                        onClick={submit}
                        disabled={submitting}
                        className="h-9 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90"
                      >
                        {submitting ? (
                          <><span className="w-3 h-3 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" /> Submitting…</>
                        ) : (
                          <>Submit ticket <Send className="w-3.5 h-3.5" /></>
                        )}
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </Card>
          </div>

          {/* RIGHT — SIDEBAR */}
          <aside className="space-y-4">
            {/* Response time */}
            <Card className="p-4 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <p className="text-xs font-semibold text-foreground">Response times</p>
              </div>
              <div className="space-y-2 mt-3">
                <div className="flex items-center justify-between p-2 rounded-md bg-background/60">
                  <span className="text-[11px] text-muted-foreground">Email (Starter)</span>
                  <span className="text-xs font-semibold text-foreground">&lt; 24h</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-md bg-background/60">
                  <span className="text-[11px] text-muted-foreground">Email (Pro/Scale)</span>
                  <span className="text-xs font-semibold text-foreground">&lt; 2h</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-md bg-background/60">
                  <span className="text-[11px] text-muted-foreground">Live chat</span>
                  <span className="text-xs font-semibold text-foreground">&lt; 5m</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-md bg-background/60">
                  <span className="text-[11px] text-muted-foreground">Phone (Enterprise)</span>
                  <span className="text-xs font-semibold text-foreground">Immediate</span>
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-3 leading-snug">
                Business hours: Mon–Fri, 8 AM – 8 PM UTC. After hours, tickets are queued by priority.
              </p>
            </Card>

            {/* On-duty team */}
            <Card className="p-4 card-lift">
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-semibold text-foreground">On duty right now</p>
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                  <span className="w-1 h-1 rounded-full bg-emerald-500 mr-1 animate-pulse" /> Online
                </Badge>
              </div>
              <div className="space-y-2">
                {[2, 5, 8].map(i => (
                  <div key={i} className="flex items-center gap-2">
                    <Avatar className="w-7 h-7 ring-1 ring-emerald-500/30">
                      <AvatarImage src={members[i].avatar} alt={members[i].name} />
                      <AvatarFallback>{initials(members[i].name)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{members[i].name}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{members[i].title}</p>
                    </div>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-muted-foreground mt-3">3 of 12 support engineers available</p>
            </Card>

            {/* Quick FAQs */}
            <Card className="p-4 card-lift border-dashed">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-foreground">Quick answers</p>
                  <p className="text-[10px] text-muted-foreground">Common questions, instantly answered</p>
                </div>
              </div>
              <div className="space-y-1">
                {QUICK_FAQS.map(faq => (
                  <Link
                    key={faq.q}
                    href={faq.href}
                    className="flex items-center justify-between gap-2 p-2 rounded-md hover:bg-secondary/60 transition-colors group"
                  >
                    <span className="text-xs text-foreground group-hover:text-primary transition-colors">{faq.q}</span>
                    <ChevronRight className="w-3 h-3 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                  </Link>
                ))}
              </div>
              <Button asChild variant="link" size="sm" className="w-full h-7 mt-2 text-xs text-primary">
                <Link href="/help/faq">Browse all FAQs <ChevronRight className="w-3 h-3" /></Link>
              </Button>
            </Card>

            {/* SLA */}
            <Card className="p-4 card-lift">
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-foreground">Enterprise SLA</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">
                    99.99% uptime guarantee with 1-hour critical response time. Custom SLAs available.
                  </p>
                </div>
              </div>
            </Card>
          </aside>
        </div>
      </HelpLayout>
    </DashboardShell>
  )
}
