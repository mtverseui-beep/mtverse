"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion"
import {
  Search, HelpCircle, ThumbsUp, ThumbsDown, ChevronRight,
  Mail, MessageSquare, User, CreditCard, ListChecks, FolderKanban,
  ShieldCheck, Code, type LucideIcon,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// FAQ DATA
// ============================================================

interface FaqItem {
  id: string
  question: string
  answer: string
  category: string
}

const FAQ_CATEGORIES = [
  { id: "account", label: "Account", icon: User, tint: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" },
  { id: "billing", label: "Billing", icon: CreditCard, tint: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
  { id: "tasks", label: "Tasks", icon: ListChecks, tint: "bg-teal-500/15 text-teal-600 dark:text-teal-400" },
  { id: "projects", label: "Projects", icon: FolderKanban, tint: "bg-lime-500/15 text-lime-600 dark:text-lime-400" },
  { id: "security", label: "Security", icon: ShieldCheck, tint: "bg-rose-500/15 text-rose-600 dark:text-rose-400" },
  { id: "api", label: "API", icon: Code, tint: "bg-violet-500/15 text-violet-600 dark:text-violet-400" },
] as const

const FAQS: FaqItem[] = [
  // Account
  { id: "a1", category: "account", question: "How do I reset my password?", answer: "Click \"Forgot password\" on the sign-in page. We'll send a reset link to your email — it's valid for 30 minutes. If you don't see the email within 5 minutes, check your spam folder or contact support. Note: password reset links can only be used once." },
  { id: "a2", category: "account", question: "How do I change my email address?", answer: "Go to Settings → Account → Email. Enter your new email and we'll send a verification link to it. Your email won't change until you click the link. If you've lost access to your current email, contact support with proof of identity." },
  { id: "a3", category: "account", question: "Can I have multiple workspaces under one account?", answer: "Yes — you can create or join up to 10 workspaces with a single email address. Switch between them from the workspace switcher in the top-left corner. Each workspace has its own members, projects, and billing." },
  { id: "a4", category: "account", question: "How do I delete my account?", answer: "Go to Settings → Account → Delete account. You'll need to confirm with your password. Account deletion is permanent after a 30-day grace period. We'll email you a full data export before deletion completes." },
  { id: "a5", category: "account", question: "What happens to my data if I downgrade to free?", answer: "Your data is preserved — nothing is deleted. If you exceed the Starter plan's limits (3 projects, 2 seats), the extra items become read-only until you upgrade again or remove them." },

  // Billing
  { id: "b1", category: "billing", question: "How do I cancel my subscription?", answer: "Go to Settings → Subscription → Cancel. Cancellation takes effect at the end of your current billing cycle — you keep premium features until then. No partial refunds for monthly plans; annual plans get prorated refunds for unused months." },
  { id: "b2", category: "billing", question: "Where can I download my invoices?", answer: "All past invoices are under Settings → Invoices. Click any invoice to download a PDF. We also email a copy to your billing contact whenever a new invoice is generated. Add a VAT/tax ID under Settings → Billing to see it reflected on future invoices." },
  { id: "b3", category: "billing", question: "Do you offer refunds?", answer: "Annual plans are refundable on a prorated basis within the first 30 days. Monthly plans aren't refunded but you keep access until the end of the cycle. Non-profits and education get 50% off — contact support to apply." },
  { id: "b4", category: "billing", question: "What payment methods do you accept?", answer: "We accept Visa, Mastercard, AMEX, and Discover via Stripe. Enterprise customers can pay by ACH or wire transfer on annual contracts. We don't currently support PayPal or crypto." },
  { id: "b5", category: "billing", question: "Can I switch between monthly and annual?", answer: "Yes — go to Settings → Subscription and toggle the cycle. Switching to annual bills you immediately with a 20% discount. Switching to monthly takes effect at the next renewal date." },

  // Tasks
  { id: "t1", category: "tasks", question: "How do I assign a task to multiple people?", answer: "Planna tasks have one primary assignee for accountability, but you can add unlimited followers who get notifications. Use @mentions in comments to loop in additional people for context." },
  { id: "t2", category: "tasks", question: "Can I set up recurring tasks?", answer: "Yes — open any task, click the repeat icon, and choose daily, weekly, monthly, or custom recurrence. Recurring tasks create a new instance when the current one is completed. You can also skip recurrences on holidays." },
  { id: "t3", category: "tasks", question: "Is there a limit on subtasks?", answer: "Subtasks are unlimited on all paid plans. Starter (free) is capped at 10 subtasks per task. Subtasks inherit labels and the parent's project but can have their own assignee and due date." },
  { id: "t4", category: "tasks", question: "How do I bulk edit tasks?", answer: "In list view, shift-click or cmd/ctrl-click to select multiple tasks. A bulk-action bar appears at the bottom — change assignee, due date, priority, labels, or move to another project in one action." },
  { id: "t5", category: "tasks", question: "Can I export tasks to CSV or Excel?", answer: "Yes — open any project or filter, click the export icon at the top-right, and choose CSV or XLSX. Exports respect your current filters and visible columns. API access enables programmatic exports too." },

  // Projects
  { id: "p1", category: "projects", question: "How do I archive a project?", answer: "Open the project, click the ⋯ menu at the top, and choose Archive. Archived projects are read-only and hidden from the sidebar but searchable. Unarchive anytime — nothing is lost." },
  { id: "p2", category: "projects", question: "Can I share a project with external clients?", answer: "Yes — invite external collaborators as Guests. Guests can view and comment on a specific project but can't see other projects or workspace members. Pro plans include 5 guests; Scale includes 25; Enterprise includes unlimited." },
  { id: "p3", category: "projects", question: "How do project templates work?", answer: "Convert any existing project to a template from the project's ⋯ menu. Templates preserve task structure, labels, and default views. Spin up new projects from templates via the New Project dialog." },
  { id: "p4", category: "projects", question: "Is there a Gantt / timeline view?", answer: "Yes — Timeline view is available on Pro, Scale, and Enterprise plans. It shows tasks and milestones on a horizontal Gantt chart with dependency arrows. Drag to reschedule; right-click to add dependencies." },
  { id: "p5", category: "projects", question: "Can I import from Jira / Trello / Asana?", answer: "Yes — go to Settings → Integrations → Import. We support direct imports from Trello, Asana, Jira, and ClickUp, plus CSV import for any other tool. Imports preserve assignees, due dates, and labels where possible." },

  // Security
  { id: "s1", category: "security", question: "How do I enable two-factor authentication?", answer: "Go to Settings → Security → Enable 2FA. We support TOTP apps (Authy, 1Password, Google Authenticator) and SMS as a fallback. Save your backup codes in a safe place — they're the only way to recover if you lose access." },
  { id: "s2", category: "security", question: "Do you support SSO?", answer: "Yes — Scale and Enterprise plans include SAML 2.0 SSO with any IdP (Okta, Azure AD, Google Workspace, OneLogin). Enterprise also includes SCIM for automated user provisioning. See Settings → Security → SSO." },
  { id: "s3", category: "security", question: "Where is my data stored?", answer: "By default, all data is stored in our primary region (US-East). Enterprise customers can choose EU (Frankfurt) or APAC (Singapore) data residency. All data is encrypted at rest (AES-256) and in transit (TLS 1.3)." },
  { id: "s4", category: "security", question: "Are you SOC 2 / GDPR compliant?", answer: "Yes — Planna is SOC 2 Type II certified (annual audits), GDPR compliant, and CCPA compliant. Our DPA is available on request. Enterprise customers can request audit reports under NDA." },
  { id: "s5", category: "security", question: "How do I view my active sessions?", answer: "Go to Settings → Sessions to see every device currently signed in. You can revoke any session individually, or revoke all others in one click. Suspicious activity triggers an automatic email alert." },

  // API
  { id: "i1", category: "api", question: "How do I get an API key?", answer: "Go to Settings → API Keys → Create new key. Name it, select scopes (read-only, read-write, admin), and copy the key immediately — it's only shown once. Revoke anytime. Keys are rate-limited to 1000 req/min by default." },
  { id: "i2", category: "api", question: "Is there an API rate limit?", answer: "Yes — 1000 requests per minute per workspace on standard plans, 10,000/min on Enterprise. We use a sliding window with X-RateLimit headers. Burst above the limit returns 429 with a Retry-After header." },
  { id: "i3", category: "api", question: "What languages have SDKs?", answer: "We maintain official SDKs for JavaScript/TypeScript, Python, and Go. Community SDKs exist for Ruby, PHP, and Rust. See the API docs for installation and examples — all SDKs auto-generated from our OpenAPI spec." },
  { id: "i4", category: "api", question: "Do you have webhooks?", answer: "Yes — Settings → Webhooks. We fire webhooks for 30+ events (task.created, project.updated, etc.). Webhooks are signed with HMAC-SHA256 so you can verify authenticity. Failed deliveries retry with exponential backoff." },
  { id: "i5", category: "api", question: "Can I use the API on the free plan?", answer: "API access is available on Pro, Scale, and Enterprise plans. The Starter (free) plan does not include API or webhook access. You can explore the API docs without an active key — see Settings → API Keys." },
]

// ============================================================
// HELPFUL TRACKER
// ============================================================

function HelpfulTracker({ id }: { id: string }) {
  const [vote, setVote] = useState<"up" | "down" | null>(null)

  const cast = (v: "up" | "down") => {
    if (vote === v) return
    setVote(v)
    toast.success(v === "up" ? "Thanks for your feedback!" : "Thanks — we'll improve this answer.")
  }

  return (
    <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border">
      <span className="text-[11px] text-muted-foreground">Was this helpful?</span>
      <button
        type="button"
        onClick={() => cast("up")}
        className={cn(
          "inline-flex items-center gap-1 h-6 px-2 rounded-md text-[11px] font-medium transition-colors",
          vote === "up"
            ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
            : "bg-secondary text-muted-foreground hover:text-foreground",
        )}
      >
        <ThumbsUp className="w-3 h-3" /> Yes
      </button>
      <button
        type="button"
        onClick={() => cast("down")}
        className={cn(
          "inline-flex items-center gap-1 h-6 px-2 rounded-md text-[11px] font-medium transition-colors",
          vote === "down"
            ? "bg-rose-500/15 text-rose-600 dark:text-rose-400"
            : "bg-secondary text-muted-foreground hover:text-foreground",
        )}
      >
        <ThumbsDown className="w-3 h-3" /> No
      </button>
      {vote && (
        <span className="text-[10px] text-muted-foreground ml-auto">{id}</span>
      )}
    </div>
  )
}

// ============================================================
// FAQ ACCORDION ITEM
// ============================================================

function FaqAccordion({ items }: { items: FaqItem[] }) {
  if (items.length === 0) {
    return (
      <Card className="p-8 border-dashed text-center">
        <HelpCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
        <p className="text-sm font-semibold text-foreground">No FAQs match your search</p>
        <p className="text-xs text-muted-foreground mt-1">Try a different term or browse another category.</p>
      </Card>
    )
  }
  return (
    <Accordion type="single" collapsible className="space-y-2">
      {items.map(item => (
        <AccordionItem
          key={item.id}
          value={item.id}
          className="border border-border rounded-lg bg-card px-4 data-[state=open]:border-primary/40 transition-colors"
        >
          <AccordionTrigger className="text-sm font-semibold text-foreground hover:no-underline py-3.5 text-left">
            {item.question}
          </AccordionTrigger>
          <AccordionContent className="text-xs text-muted-foreground leading-relaxed pb-3.5 pt-1">
            <p>{item.answer}</p>
            <HelpfulTracker id={item.id} />
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  )
}

// ============================================================
// PAGE
// ============================================================

export default function FaqPage() {
  const [query, setQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState<string>("all")

  const filtered = useMemo(() => {
    return FAQS.filter(f => {
      const matchCat = activeCategory === "all" || f.category === activeCategory
      const matchQuery = !query.trim() ||
        f.question.toLowerCase().includes(query.toLowerCase()) ||
        f.answer.toLowerCase().includes(query.toLowerCase())
      return matchCat && matchQuery
    })
  }, [query, activeCategory])

  const grouped = useMemo(() => {
    const map: Record<string, FaqItem[]> = {}
    filtered.forEach(f => {
      if (!map[f.category]) map[f.category] = []
      map[f.category].push(f)
    })
    return map
  }, [filtered])

  return (
    <DashboardShell
      title="Frequently Asked Questions"
      description="Quick answers to the most common questions about Planna. Can't find what you're looking for? Contact support."
      actions={
        <Button asChild size="sm" className="h-9 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
          <Link href="/help/contact"><Mail className="w-3.5 h-3.5" /> Contact support</Link>
        </Button>
      }
    >
      <HelpMobileNav />
      <HelpLayout>
        {/* SEARCH */}
        <Card className="p-4 card-lift">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search FAQs… (e.g. password, billing, API)"
              className="h-10 pl-10 text-sm"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground"
              >
                Clear
              </button>
            )}
          </div>
          <div className="flex items-center gap-1.5 mt-3 overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={() => setActiveCategory("all")}
              className={cn(
                "h-8 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                activeCategory === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground",
              )}
            >
              All ({FAQS.length})
            </button>
            {FAQ_CATEGORIES.map(c => {
              const CIcon = c.icon
              const count = FAQS.filter(f => f.category === c.id).length
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setActiveCategory(c.id)}
                  className={cn(
                    "h-8 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors inline-flex items-center gap-1.5",
                    activeCategory === c.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-muted-foreground hover:text-foreground",
                  )}
                >
                  <CIcon className="w-3 h-3" />
                  {c.label} ({count})
                </button>
              )
            })}
          </div>
        </Card>

        {/* STATS */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Total FAQs", value: FAQS.length, hint: "Across all categories" },
            { label: "Categories", value: FAQ_CATEGORIES.length, hint: "Topic areas covered" },
            { label: "Avg helpful score", value: "94%", hint: "From user feedback" },
            { label: "Last updated", value: "2 days ago", hint: "New answers added" },
          ].map(s => (
            <Card key={s.label} className="p-4 card-lift">
              <p className="text-[10px] text-muted-foreground">{s.label}</p>
              <p className="text-xl font-bold text-foreground mt-1">{s.value}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{s.hint}</p>
            </Card>
          ))}
        </div>

        {/* FAQ GROUPS */}
        {activeCategory === "all" && !query.trim() ? (
          // Show grouped by category
          <div className="space-y-6">
            {FAQ_CATEGORIES.map(cat => {
              const items = grouped[cat.id] ?? []
              if (items.length === 0) return null
              const CIcon = cat.icon
              return (
                <div key={cat.id}>
                  <div className="flex items-center gap-2 mb-3">
                    <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", cat.tint)}>
                      <CIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-foreground">{cat.label}</h3>
                      <p className="text-[11px] text-muted-foreground">{items.length} questions</p>
                    </div>
                  </div>
                  <FaqAccordion items={items} />
                </div>
              )
            })}
          </div>
        ) : (
          // Show flat filtered list
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs text-muted-foreground">
                {filtered.length} {filtered.length === 1 ? "result" : "results"}
                {query && <> for "<span className="text-foreground font-medium">{query}</span>"</>}
              </p>
            </div>
            <FaqAccordion items={filtered} />
          </div>
        )}

        {/* STILL NEED HELP */}
        <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-foreground">Didn't find an answer?</h3>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                Our support team is online now and typically replies within 2 hours. We're happy to help with anything — even weird edge cases.
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent">
                <Link href="/help/docs">Browse docs</Link>
              </Button>
              <Button asChild size="sm" className="h-9 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/help/contact">Contact support <ChevronRight className="w-3.5 h-3.5" /></Link>
              </Button>
            </div>
          </div>
        </Card>
      </HelpLayout>
    </DashboardShell>
  )
}
