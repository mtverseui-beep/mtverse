"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  FileText, ChevronRight, ArrowRight, Scale, Gavel, ShieldCheck,
  AlertTriangle, Mail, Download, Printer, Clock, Hash,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// TOC
// ============================================================

interface TocItem {
  id: string
  number: string
  title: string
  icon: typeof Scale
}

const TOC: TocItem[] = [
  { id: "acceptance", number: "1", title: "Acceptance of Terms", icon: FileText },
  { id: "definitions", number: "2", title: "Definitions", icon: Hash },
  { id: "accounts", number: "3", title: "Accounts & User Responsibilities", icon: ShieldCheck },
  { id: "subscriptions", number: "4", title: "Subscriptions & Billing", icon: Scale },
  { id: "fees", number: "5", title: "Fees & Payment", icon: Scale },
  { id: "termination", number: "6", title: "Termination & Suspension", icon: Gavel },
  { id: "warranties", number: "7", title: "Warranties & Disclaimers", icon: AlertTriangle },
  { id: "liability", number: "8", title: "Limitation of Liability", icon: AlertTriangle },
  { id: "governing", number: "9", title: "Governing Law & Disputes", icon: Gavel },
]

// ============================================================
// SECTION CONTENT
// ============================================================

interface Section {
  id: string
  title: string
  paragraphs: string[]
  bullets?: string[]
}

const SECTIONS: Section[] = [
  {
    id: "acceptance",
    title: "1. Acceptance of Terms",
    paragraphs: [
      "Welcome to Planna. By creating an account, accessing, or using the Planna platform (the \"Service\"), you agree to be bound by these Terms of Service (\"Terms\"), our Privacy Policy, and any additional terms or conditions referenced herein.",
      "If you are entering into these Terms on behalf of a company or other legal entity, you represent that you have the authority to bind that entity to these Terms. In that case, \"you\" and \"your\" refer to that entity.",
      "If you do not agree to these Terms, you must not access or use the Service. We may update these Terms from time to time — continued use after changes take effect constitutes acceptance of the revised Terms.",
    ],
  },
  {
    id: "definitions",
    title: "2. Definitions",
    paragraphs: [
      "The following terms have the meanings set forth below when used in these Terms with initial capital letters:",
    ],
    bullets: [
      "\"Service\" refers to the Planna platform, including the web application, mobile apps, API, documentation, and any related services provided by Planna.",
      "\"Customer\" or \"you\" refers to the individual or entity that creates an account and uses the Service.",
      "\"Workspace\" refers to a logical grouping of users, projects, and data within the Service, isolated from other Workspaces.",
      "\"User Content\" refers to any data, information, or material that you or your team submit, upload, or transmit through the Service.",
      "\"Plan\" refers to the subscription tier you have selected, including any associated limits on usage, storage, or features.",
      "\"Effective Date\" refers to the date these Terms become effective, as shown at the top of this document.",
    ],
  },
  {
    id: "accounts",
    title: "3. Accounts & User Responsibilities",
    paragraphs: [
      "To access the Service, you must create an account and provide accurate, complete, and current information. You are solely responsible for maintaining the security of your account credentials and for all activities that occur under your account.",
      "You agree to notify Planna immediately of any unauthorized use of your account or any other security breach. Planna will not be liable for any loss or damage arising from your failure to comply with this obligation.",
    ],
    bullets: [
      "You must be at least 16 years old to create an account. Users under 18 require parental or legal guardian consent.",
      "You are responsible for all content posted under your account and for ensuring it complies with applicable laws and third-party rights.",
      "You may not use the Service to store or transmit unlawful, defamatory, infringing, or harmful content.",
      "You may not attempt to disrupt, reverse-engineer, or gain unauthorized access to the Service, its systems, or other customers' data.",
      "You are responsible for all usage fees incurred under your account, including fees from unauthorized use if you failed to secure your account.",
    ],
  },
  {
    id: "subscriptions",
    title: "4. Subscriptions & Billing",
    paragraphs: [
      "Planna offers multiple subscription Plans with different features, limits, and pricing. By selecting a paid Plan, you authorize Planna to charge the applicable fees on a recurring basis (monthly or annually, as you select) until you cancel.",
      "You may upgrade or downgrade your Plan at any time. Upgrades take effect immediately with prorated billing for the remainder of the current cycle. Downgrades take effect at the end of the current cycle.",
      "All Plan fees are stated in US Dollars (USD) and exclude applicable taxes, which are your responsibility unless Planna is required by law to collect them.",
    ],
    bullets: [
      "Free trials, where offered, last 14 days and do not require a credit card. Trials convert to paid subscriptions only if you actively select a paid Plan.",
      "Annual Plans are billed in full at the start of each annual cycle and are non-refundable except as expressly stated in these Terms.",
      "Planna reserves the right to change Plan pricing with at least 30 days' notice. Price changes take effect at your next renewal date.",
      "If you exceed the limits of your Plan, you will be prompted to upgrade. Continued overage may result in read-only access until you upgrade or remove excess data.",
    ],
  },
  {
    id: "fees",
    title: "5. Fees & Payment",
    paragraphs: [
      "Paid Plans require a valid payment method on file. We use Stripe as our payment processor — Planna does not store full card numbers on its servers. You authorize Planna to charge your payment method for all fees incurred under your account.",
      "Fees are billed in advance on the recurring billing date corresponding to your Plan (monthly or annual). If a charge fails, we will retry up to 3 times over 7 days. If payment is not completed, your account may be downgraded to the free Starter Plan or suspended.",
    ],
    bullets: [
      "Invoices are available under Settings → Invoices and emailed to the billing contact on file.",
      "You may add a tax ID (VAT, GST, etc.) under Settings → Billing; it will appear on future invoices.",
      "Refunds for annual Plans are available on a prorated basis within the first 30 days. Monthly Plans are non-refundable.",
      "If you believe you have been incorrectly billed, contact support within 60 days of the invoice date for a review.",
    ],
  },
  {
    id: "termination",
    title: "6. Termination & Suspension",
    paragraphs: [
      "You may cancel your subscription at any time from Settings → Subscription. Cancellation takes effect at the end of your current billing cycle. You retain access to premium features until then.",
      "Planna may suspend or terminate your account immediately, without notice, if: (a) you breach these Terms; (b) we are required to do so by law; or (c) your account has been inactive for 12+ consecutive months on a free Plan.",
      "Upon termination, your data will be retained for 30 days, during which you may export it. After 30 days, all data associated with your account will be permanently deleted from our production systems, with backups purged within 90 days.",
    ],
    bullets: [
      "Planna may discontinue or modify any feature of the Service with at least 30 days' notice.",
      "Sections that by their nature should survive termination (e.g., Fees, Warranties, Liability, Governing Law) will remain in effect.",
      "If your account is terminated for cause, no refunds are due. If terminated by Planna without cause, you will receive a prorated refund of any prepaid fees.",
    ],
  },
  {
    id: "warranties",
    title: "7. Warranties & Disclaimers",
    paragraphs: [
      "Planna provides the Service \"as is\" and \"as available,\" with all faults and without warranty of any kind. To the maximum extent permitted by law, Planna disclaims all warranties, whether express or implied, including implied warranties of merchantability, fitness for a particular purpose, title, and non-infringement.",
      "Planna does not warrant that the Service will be uninterrupted, error-free, secure, or that defects will be corrected. You use the Service at your own risk.",
      "No advice or information, whether oral or written, obtained from Planna or through the Service, creates any warranty not expressly stated in these Terms.",
    ],
    bullets: [
      "Planna's uptime commitment applies only to Enterprise Plans with a paid SLA; standard Plans have no uptime guarantee.",
      "You are responsible for backing up critical User Content; Planna's backup processes do not constitute a guarantee against data loss.",
      "Third-party integrations (Slack, GitHub, etc.) are governed by their respective terms and are not warranted by Planna.",
    ],
  },
  {
    id: "liability",
    title: "8. Limitation of Liability",
    paragraphs: [
      "To the maximum extent permitted by law, in no event shall Planna, its directors, employees, partners, or affiliates be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits, data, use, or goodwill, arising out of or related to your use of the Service.",
      "Planna's total aggregate liability for any claim arising out of or related to these Terms or the Service shall not exceed the amount you paid to Planna in the 12 months preceding the claim, or $100 USD, whichever is greater.",
      "The limitations in this section apply even if Planna has been advised of the possibility of such damages, and regardless of the legal theory (contract, tort, or otherwise) on which the claim is based.",
    ],
    bullets: [
      "Some jurisdictions do not allow the exclusion or limitation of certain damages, so some of the above limitations may not apply to you.",
      "Planna is not liable for any unauthorized access to your account resulting from your failure to maintain credential security.",
      "Planna is not liable for any data loss caused by you, your team, or third-party integrations.",
    ],
  },
  {
    id: "governing",
    title: "9. Governing Law & Disputes",
    paragraphs: [
      "These Terms shall be governed by and construed in accordance with the laws of the State of California, USA, without regard to its conflict of law provisions. You and Planna agree to submit to the exclusive jurisdiction of the state and federal courts located in San Francisco County, California, for any disputes arising out of or related to these Terms.",
      "Before filing a claim, you agree to attempt to resolve the dispute informally by contacting Planna's legal team at legal@planna.app with a 30-day notice. If the dispute is not resolved within 30 days, either party may proceed with formal proceedings.",
      "Any dispute arising out of or related to these Terms will be resolved on an individual basis — class actions and class arbitrations are not permitted. This section survives termination of these Terms.",
    ],
    bullets: [
      "The United Nations Convention on Contracts for the International Sale of Goods does not apply.",
      "If any provision of these Terms is found unenforceable, the remaining provisions remain in full force and effect.",
      "Planna's failure to enforce any right or provision is not a waiver of that right or provision.",
      "For EU/UK customers, additional statutory rights under your local consumer protection laws may apply and are not affected by these Terms.",
    ],
  },
]

// ============================================================
// PAGE
// ============================================================

export default function TermsPage() {
  const [activeSection, setActiveSection] = useState<string>("acceptance")

  const lastUpdated = "January 28, 2026"
  const effectiveDate = "February 1, 2026"

  const handleDownload = () => {
    toast.success("Download started", { description: "Terms of Service downloading as PDF…" })
  }

  const handlePrint = () => {
    if (typeof window !== "undefined") window.print()
  }

  return (
    <DashboardShell
      title="Terms of Service"
      description="The rules and terms for using Planna. Please read them carefully."
      actions={
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5" onClick={handlePrint}>
            <Printer className="w-3.5 h-3.5" /> Print
          </Button>
          <Button variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5" onClick={handleDownload}>
            <Download className="w-3.5 h-3.5" /> Download PDF
          </Button>
        </div>
      }
    >
      <HelpMobileNav />
      <HelpLayout>
        {/* META BAR */}
        <Card className="p-4 card-lift">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Legal Document</p>
                <p className="text-[11px] text-muted-foreground">Planna Terms of Service</p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <Clock className="w-3 h-3" /> Last updated: {lastUpdated}
              </span>
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5 bg-primary/10 text-primary">
                Effective {effectiveDate}
              </Badge>
            </div>
          </div>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-4 lg:gap-6">
          {/* LEFT — TABLE OF CONTENTS */}
          <aside>
            <Card className="p-4 card-lift lg:sticky lg:top-4">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-3 px-2">
                Table of contents
              </p>
              <nav className="space-y-0.5">
                {TOC.map(item => {
                  const TIcon = item.icon
                  const active = activeSection === item.id
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setActiveSection(item.id)
                        if (typeof document !== "undefined") {
                          document.getElementById(item.id)?.scrollIntoView({ behavior: "smooth", block: "start" })
                        }
                      }}
                      className={cn(
                        "w-full flex items-center gap-2 px-2 h-9 rounded-md text-xs font-medium text-left transition-colors",
                        active
                          ? "bg-primary text-primary-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                      )}
                    >
                      <span className={cn(
                        "w-5 h-5 rounded text-[10px] font-bold flex items-center justify-center shrink-0",
                        active ? "bg-primary-foreground/20 text-primary-foreground" : "bg-secondary text-muted-foreground",
                      )}>
                        {item.number}
                      </span>
                      <span className="truncate">{item.title}</span>
                    </button>
                  )
                })}
              </nav>

              <div className="mt-4 pt-4 border-t border-border space-y-1">
                <Button asChild variant="ghost" size="sm" className="w-full h-8 text-xs justify-start text-muted-foreground hover:text-foreground">
                  <Link href="/help/privacy"><ShieldCheck className="w-3.5 h-3.5" /> Privacy Policy</Link>
                </Button>
                <Button asChild variant="ghost" size="sm" className="w-full h-8 text-xs justify-start text-muted-foreground hover:text-foreground">
                  <Link href="/help/contact"><Mail className="w-3.5 h-3.5" /> Contact legal</Link>
                </Button>
              </div>
            </Card>
          </aside>

          {/* RIGHT — CONTENT */}
          <div className="min-w-0 space-y-4">
            <Card className="p-5 md:p-7 card-lift">
              {/* Header */}
              <div className="mb-6 pb-5 border-b border-border">
                <h1 className="text-2xl font-bold text-foreground tracking-tight">Terms of Service</h1>
                <p className="text-xs text-muted-foreground mt-1">
                  These Terms were last updated on {lastUpdated} and became effective on {effectiveDate}.
                </p>
              </div>

              {/* Intro */}
              <div className="mb-6 p-4 rounded-lg bg-secondary/40 border border-border">
                <p className="text-xs text-muted-foreground leading-relaxed">
                  These Terms of Service govern your access to and use of the Planna platform. By using Planna, you agree to these Terms in full. If you disagree with any part, you may not use the Service. Please read them carefully — they affect your legal rights.
                </p>
              </div>

              {/* Sections */}
              <div className="space-y-8">
                {SECTIONS.map(section => (
                  <section
                    key={section.id}
                    id={section.id}
                    className="scroll-mt-24"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className={cn(
                        "w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold transition-colors",
                        activeSection === section.id ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary",
                      )}>
                        {section.id.match(/\d+/)?.[0]}
                      </div>
                      <h2 className="text-base font-semibold text-foreground">{section.title.replace(/^\d+\.\s/, "")}</h2>
                    </div>
                    <div className="pl-11 space-y-3">
                      {section.paragraphs.map((p, i) => (
                        <p key={i} className="text-sm text-muted-foreground leading-relaxed">{p}</p>
                      ))}
                      {section.bullets && (
                        <ul className="space-y-2 mt-3">
                          {section.bullets.map((b, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                              <span className="leading-relaxed">{b}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </section>
                ))}
              </div>

              {/* Footer */}
              <div className="mt-8 pt-6 border-t border-border">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-foreground">Questions about these Terms?</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">Our legal team is happy to clarify any section.</p>
                  </div>
                  <div className="flex gap-2">
                    <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent">
                      <Link href="/help/contact">Contact legal <ArrowRight className="w-3.5 h-3.5" /></Link>
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            {/* PREV / NEXT */}
            <div className="grid grid-cols-2 gap-3">
              <Card className="p-4 card-lift">
                <Link href="/help" className="block">
                  <p className="text-[10px] text-muted-foreground">Previous</p>
                  <p className="text-xs font-semibold text-foreground mt-1">Help Center</p>
                </Link>
              </Card>
              <Card className="p-4 card-lift">
                <Link href="/help/privacy" className="block text-right">
                  <p className="text-[10px] text-muted-foreground">Next</p>
                  <p className="text-xs font-semibold text-foreground mt-1">Privacy Policy <ChevronRight className="w-3 h-3 inline" /></p>
                </Link>
              </Card>
            </div>
          </div>
        </div>
      </HelpLayout>
    </DashboardShell>
  )
}
