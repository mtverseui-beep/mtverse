"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LifeBuoy, BookOpen, Rocket, Keyboard, GitBranch, Mail,
  HelpCircle, CreditCard, FileText, ShieldCheck, LayoutDashboard,
  Download,
} from "lucide-react"
import type { LucideIcon } from "lucide-react"

// ============================================================
// HELP NAVIGATION
// ============================================================

export interface HelpNavItem {
  href: string
  label: string
  icon: LucideIcon
  description: string
}

export interface HelpNavGroup {
  title: string
  items: HelpNavItem[]
}

export const HELP_NAV_GROUPS: HelpNavGroup[] = [
  {
    title: "Support",
    items: [
      { href: "/help", label: "Help Center", icon: LifeBuoy, description: "Search articles and browse popular topics" },
      { href: "/help/docs", label: "Documentation", icon: BookOpen, description: "Complete guides and reference docs" },
      { href: "/help/getting-started", label: "Getting Started", icon: Rocket, description: "Five-step onboarding for new teams" },
      { href: "/help/shortcuts", label: "Keyboard Shortcuts", icon: Keyboard, description: "Speed up your workflow with hotkeys" },
      { href: "/help/changelog", label: "Changelog", icon: GitBranch, description: "What's new in every release" },
      { href: "/help/contact", label: "Contact Support", icon: Mail, description: "Email, chat and enterprise support" },
      { href: "/help/faq", label: "FAQ", icon: HelpCircle, description: "Answers to the most common questions" },
    ],
  },
  {
    title: "Plans & Legal",
    items: [
      { href: "/help/pricing", label: "Pricing", icon: CreditCard, description: "Compare plans and features" },
      { href: "/help/terms", label: "Terms of Service", icon: FileText, description: "The rules of using Planna" },
      { href: "/help/privacy", label: "Privacy Policy", icon: ShieldCheck, description: "How we handle your data" },
    ],
  },
]

// Flat list (used for the index landing grid + mobile nav)
export const ALL_HELP_ITEMS: HelpNavItem[] = HELP_NAV_GROUPS.flatMap(g => g.items)

// ============================================================
// HELP SIDEBAR — left vertical nav, sticky on desktop
// ============================================================

export function HelpSidebar({ className }: { className?: string }) {
  const pathname = usePathname()
  return (
    <nav className={cn("w-full", className)}>
      <ScrollArea className="h-full">
        <div className="space-y-5 pr-1">
          <Link
            href="/help"
            className={cn(
              "flex items-center gap-2 px-3 h-9 rounded-lg text-xs font-medium transition-colors",
              pathname === "/help"
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary",
            )}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            Overview
          </Link>

          {HELP_NAV_GROUPS.map(group => (
            <div key={group.title}>
              <p className="px-3 mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                {group.title}
              </p>
              <div className="space-y-0.5">
                {group.items.map(item => {
                  const active = pathname === item.href
                  const Icon = item.icon
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        "flex items-center gap-2 px-3 h-9 rounded-lg text-xs font-medium transition-all",
                        active
                          ? "bg-primary text-primary-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                      )}
                    >
                      <Icon className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </Link>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </nav>
  )
}

// ============================================================
// HELP LAYOUT — sticky sidebar + main content
// ============================================================

export function HelpLayout({
  sidebar,
  children,
}: {
  sidebar?: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4 lg:gap-6 animate-fade-in">
      <aside className="hidden lg:block">
        <div className="sticky top-4 max-h-[calc(100vh-2rem)]">
          <HelpSidebar />
          {sidebar}
        </div>
      </aside>
      <div className="min-w-0 space-y-4">{children}</div>
    </div>
  )
}

// ============================================================
// MOBILE HELP NAV — horizontal pill nav, scrollable
// ============================================================

export function HelpMobileNav() {
  const pathname = usePathname()
  return (
    <nav className="lg:hidden -mx-1 mb-3 overflow-x-auto no-scrollbar">
      <div className="flex items-center gap-1 px-1 min-w-max">
        <Link
          href="/help"
          className={cn(
            "inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
            pathname === "/help"
              ? "bg-primary text-primary-foreground"
              : "bg-card border border-border text-muted-foreground hover:text-foreground",
          )}
        >
          <LayoutDashboard className="w-3.5 h-3.5" />
          Overview
        </Link>
        {ALL_HELP_ITEMS.map(item => {
          const active = pathname === item.href
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium whitespace-nowrap transition-colors",
                active
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-card border border-border text-muted-foreground hover:text-foreground",
              )}
            >
              <Icon className="w-3.5 h-3.5" />
              {item.label}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

// ============================================================
// EXPORT CSV — stub that fires a toast
// ============================================================

export function ExportPDFButton({ label = "Download PDF", rows = 0 }: { label?: string; rows?: number }) {
  return (
    <Button
      variant="outline"
      className="h-9 text-sm gap-1.5 bg-transparent"
      onClick={() => {
        if (typeof window !== "undefined") {
          import("sonner").then(({ toast }) =>
            toast.success("Download started", {
              description: rows
                ? `${rows} pages downloading as PDF…`
                : "Your document is downloading as PDF…",
            }),
          )
        }
      }}
    >
      <Download className="w-4 h-4" /> {label}
    </Button>
  )
}
