"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import {
  ChevronLeft, ChevronRight, Building2, Users, FolderKanban,
  ListChecks, Clock, CheckCircle2, Sparkles, ArrowRight,
  Image as ImageIcon, RotateCcw, PartyPopper,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// ONBOARDING STEPS
// ============================================================

interface OnboardingStep {
  id: string
  number: number
  title: string
  description: string
  detail: string
  icon: typeof Building2
  cta: string
  href: string
  estimated: string
}

const STEPS: OnboardingStep[] = [
  {
    id: "s1",
    number: 1,
    title: "Create your workspace",
    description: "Set up your team's home base in Planna — name it, add a logo, and pick your timezone.",
    detail: "Your workspace is the top-level container for all projects, tasks, and team members. You can rename it anytime under Settings → Workspace. Workspaces are isolated — perfect for managing multiple clients or business units.",
    icon: Building2,
    cta: "Configure workspace",
    href: "/settings/workspace",
    estimated: "2 minutes",
  },
  {
    id: "s2",
    number: 2,
    title: "Invite your team",
    description: "Bring teammates in by email or share an invite link — assign roles as you go.",
    detail: "Planna supports five roles: Owner, Admin, Manager, Member, and Viewer. You can also invite external collaborators as Guests with limited permissions. New members receive an email with setup instructions.",
    icon: Users,
    cta: "Open team page",
    href: "/team",
    estimated: "3 minutes",
  },
  {
    id: "s3",
    number: 3,
    title: "Create your first project",
    description: "Spin up a project from scratch or use a template — Kanban, Sprint, or Marketing.",
    detail: "Projects group related tasks, milestones, and files. Choose a color, set a start/end date, and pick a default view. You can convert a project to a template later for reuse.",
    icon: FolderKanban,
    cta: "New project",
    href: "/projects",
    estimated: "3 minutes",
  },
  {
    id: "s4",
    number: 4,
    title: "Add your first tasks",
    description: "Add tasks, set due dates, assign owners, and attach files — get work flowing.",
    detail: "Tasks are the unit of work in Planna. Use priorities to signal urgency, labels to group across projects, and subtasks to break down larger items. Mention @teammate to loop someone in.",
    icon: ListChecks,
    cta: "Add a task",
    href: "/tasks",
    estimated: "4 minutes",
  },
  {
    id: "s5",
    number: 5,
    title: "Track your time",
    description: "Start a timer on any task with one click — see exactly where your hours go.",
    detail: "Time tracking helps with billing, capacity planning, and retrospectives. Mark entries as billable or non-billable, add notes, and export weekly timesheets. Run Focus mode for distraction-free deep work.",
    icon: Clock,
    cta: "Open time tracker",
    href: "/time",
    estimated: "2 minutes",
  },
]

// ============================================================
// SCREENSHOT PLACEHOLDER
// ============================================================

function ScreenshotPlaceholder({ step }: { step: OnboardingStep }) {
  const Icon = step.icon
  return (
    <div className="relative aspect-video rounded-lg border border-dashed border-border bg-gradient-to-br from-secondary/50 to-secondary/20 flex items-center justify-center overflow-hidden">
      {/* Window dots */}
      <div className="absolute top-3 left-3 flex gap-1.5">
        <div className="w-2 h-2 rounded-full bg-rose-400/70" />
        <div className="w-2 h-2 rounded-full bg-amber-400/70" />
        <div className="w-2 h-2 rounded-full bg-emerald-400/70" />
      </div>

      {/* Decorative grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(var(--foreground) 1px, transparent 1px), linear-gradient(90deg, var(--foreground) 1px, transparent 1px)",
          backgroundSize: "20px 20px",
        }}
      />

      <div className="relative text-center">
        <div className="w-12 h-12 mx-auto rounded-xl bg-primary/15 text-primary flex items-center justify-center mb-2 animate-float">
          <Icon className="w-6 h-6" />
        </div>
        <p className="text-[11px] font-semibold text-foreground">{step.title}</p>
        <p className="text-[10px] text-muted-foreground mt-0.5 inline-flex items-center gap-1">
          <ImageIcon className="w-2.5 h-2.5" /> Screenshot preview
        </p>
      </div>

      {/* Floating mini cards */}
      <div className="absolute bottom-3 right-3 w-16 h-10 rounded-md bg-background/80 backdrop-blur border border-border shadow-sm animate-float" style={{ animationDelay: "0.5s" }} />
      <div className="absolute bottom-3 left-3 w-12 h-8 rounded-md bg-background/80 backdrop-blur border border-border shadow-sm animate-float" style={{ animationDelay: "1s" }} />
    </div>
  )
}

// ============================================================
// PAGE
// ============================================================

export default function GettingStartedPage() {
  const [done, setDone] = useState<Record<string, boolean>>({
    s1: false, s2: false, s3: false, s4: false, s5: false,
  })
  const [activeStep, setActiveStep] = useState(0)

  const completedCount = Object.values(done).filter(Boolean).length
  const progress = Math.round((completedCount / STEPS.length) * 100)
  const allDone = completedCount === STEPS.length

  const toggle = (id: string) => {
    setDone(prev => {
      const next = { ...prev, [id]: !prev[id] }
      const newCount = Object.values(next).filter(Boolean).length
      if (newCount === STEPS.length && !prev[id]) {
        toast.success("Onboarding complete!", {
          description: "You're all set. Welcome to Planna — let's ship some work.",
        })
      } else if (!next[id]) {
        toast.info("Step marked as incomplete")
      } else {
        toast.success("Step marked as done")
      }
      return next
    })
  }

  const resetAll = () => {
    setDone({ s1: false, s2: false, s3: false, s4: false, s5: false })
    setActiveStep(0)
    toast.info("Progress reset")
  }

  return (
    <DashboardShell
      title="Getting Started"
      description="Five quick steps to set up Planna for your team. Most teams finish in under 15 minutes."
      actions={
        <Button variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5" onClick={resetAll}>
          <RotateCcw className="w-3.5 h-3.5" /> Reset progress
        </Button>
      }
    >
      <HelpMobileNav />
      <HelpLayout>
        {/* PROGRESS BAR */}
        <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                {allDone ? (
                  <><PartyPopper className="w-4 h-4 text-primary" /> Onboarding complete</>
                ) : (
                  <><Sparkles className="w-4 h-4 text-primary" /> Your onboarding progress</>
                )}
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {allDone
                  ? "You've completed every step — time to ship some work."
                  : `${completedCount} of ${STEPS.length} steps complete — about ${STEPS.length - completedCount} step(s) to go.`}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Badge className="text-xs px-2 py-0.5 h-6 bg-primary text-primary-foreground">
                {progress}%
              </Badge>
              <span className="text-[11px] text-muted-foreground">{completedCount} / {STEPS.length}</span>
            </div>
          </div>
          <Progress value={progress} className="h-2" />
          {/* Step pills */}
          <div className="flex flex-wrap gap-1.5 mt-4">
            {STEPS.map((s, i) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setActiveStep(i)}
                className={cn(
                  "inline-flex items-center gap-1.5 h-7 px-2.5 rounded-full text-[11px] font-medium transition-colors",
                  done[s.id]
                    ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
                    : activeStep === i
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-muted-foreground hover:text-foreground",
                )}
              >
                {done[s.id] ? <CheckCircle2 className="w-3 h-3" /> : <span className="w-3.5 h-3.5 rounded-full bg-foreground/10 flex items-center justify-center text-[9px]">{s.number}</span>}
                {s.title}
              </button>
            ))}
          </div>
        </Card>

        {/* ACTIVE STEP DETAIL */}
        {(() => {
          const step = STEPS[activeStep]
          const isDone = done[step.id]
          return (
            <Card className="p-5 md:p-7 card-lift" key={step.id}>
              <div className="flex items-start gap-4 mb-5">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-colors",
                  isDone ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-primary text-primary-foreground",
                )}>
                  {isDone ? <CheckCircle2 className="w-5 h-5" /> : <span className="text-base font-bold">{step.number}</span>}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-lg font-bold text-foreground tracking-tight">{step.title}</h2>
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4 bg-secondary text-muted-foreground">
                      Step {step.number} of {STEPS.length}
                    </Badge>
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-border text-muted-foreground">
                      <Clock className="w-2.5 h-2.5 mr-1" /> {step.estimated}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{step.description}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                {/* Left — detail */}
                <div>
                  <ScreenshotPlaceholder step={step} />
                  <div className="mt-4 p-4 rounded-lg bg-secondary/50 border border-border">
                    <p className="text-xs text-foreground leading-relaxed">{step.detail}</p>
                  </div>
                </div>

                {/* Right — action card */}
                <div className="flex flex-col">
                  <div className="flex-1 p-4 rounded-lg border border-dashed border-border bg-secondary/30">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                      Action required
                    </p>
                    <p className="text-sm font-semibold text-foreground mb-3">{step.title}</p>
                    <ul className="space-y-2 text-xs text-muted-foreground">
                      <li className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                        Click the action button below to open the relevant page.
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                        Complete the step in the new view — it takes about {step.estimated.toLowerCase()}.
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                        Come back here and tick the "Mark as done" checkbox.
                      </li>
                    </ul>
                  </div>

                  <div className="mt-4 space-y-3">
                    <Button asChild className="w-full h-10 gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                      <Link href={step.href}>
                        {step.cta} <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    </Button>

                    <label className="flex items-center gap-2.5 p-3 rounded-lg border border-border cursor-pointer hover:bg-secondary/40 transition-colors">
                      <Checkbox
                        checked={!!isDone}
                        onCheckedChange={() => toggle(step.id)}
                      />
                      <div className="flex-1">
                        <p className="text-xs font-semibold text-foreground">Mark as done</p>
                        <p className="text-[11px] text-muted-foreground">Check this box once you've finished the step</p>
                      </div>
                      {isDone && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                    </label>
                  </div>
                </div>
              </div>

              {/* Step navigation */}
              <div className="flex items-center justify-between mt-6 pt-5 border-t border-border">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 text-xs bg-transparent gap-1.5"
                  disabled={activeStep === 0}
                  onClick={() => setActiveStep(i => Math.max(0, i - 1))}
                >
                  <ChevronLeft className="w-3.5 h-3.5" /> Previous
                </Button>
                <div className="flex gap-1">
                  {STEPS.map((s, i) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setActiveStep(i)}
                      className={cn(
                        "w-1.5 h-1.5 rounded-full transition-colors",
                        i === activeStep ? "bg-primary w-4" : done[s.id] ? "bg-emerald-500" : "bg-border",
                      )}
                      aria-label={`Go to step ${i + 1}`}
                    />
                  ))}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 text-xs bg-transparent gap-1.5"
                  disabled={activeStep === STEPS.length - 1}
                  onClick={() => setActiveStep(i => Math.min(STEPS.length - 1, i + 1))}
                >
                  Next <ChevronRight className="w-3.5 h-3.5" />
                </Button>
              </div>
            </Card>
          )
        })()}

        {/* ALL STEPS LIST */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground">All onboarding steps</h3>
              <p className="text-[11px] text-muted-foreground mt-0.5">Tick each step as you complete it</p>
            </div>
            <Badge variant="secondary" className="text-[10px] px-2 py-0.5 h-5 bg-secondary text-muted-foreground">
              {completedCount} / {STEPS.length} done
            </Badge>
          </div>
          <div className="space-y-2">
            {STEPS.map(s => {
              const Icon = s.icon
              const isDone = done[s.id]
              return (
                <div
                  key={s.id}
                  className={cn(
                    "flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer",
                    isDone ? "border-emerald-500/30 bg-emerald-500/5" : "border-border hover:bg-secondary/40",
                  )}
                  onClick={() => toggle(s.id)}
                >
                  <Checkbox checked={!!isDone} onCheckedChange={() => toggle(s.id)} />
                  <div className={cn(
                    "w-9 h-9 rounded-lg flex items-center justify-center shrink-0 transition-colors",
                    isDone ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-primary/10 text-primary",
                  )}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={cn("text-xs font-semibold", isDone ? "text-muted-foreground line-through" : "text-foreground")}>
                      {s.title}
                    </p>
                    <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{s.description}</p>
                  </div>
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-border text-muted-foreground shrink-0">
                    <Clock className="w-2.5 h-2.5 mr-1" /> {s.estimated}
                  </Badge>
                </div>
              )
            })}
          </div>
        </Card>

        {/* NEXT STEPS */}
        <Card className="p-5 md:p-6 card-lift border-dashed">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-foreground">What's next?</h3>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                Once you've completed onboarding, explore the docs, learn keyboard shortcuts, and configure integrations to get the most out of Planna.
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent">
                <Link href="/help/docs">Docs</Link>
              </Button>
              <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent">
                <Link href="/help/shortcuts">Shortcuts</Link>
              </Button>
              <Button asChild size="sm" className="h-9 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/dashboard">Open dashboard <ArrowRight className="w-3.5 h-3.5" /></Link>
              </Button>
            </div>
          </div>
        </Card>
      </HelpLayout>
    </DashboardShell>
  )
}
