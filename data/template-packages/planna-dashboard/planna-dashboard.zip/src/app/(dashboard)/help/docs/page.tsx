"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Search, BookOpen, ChevronRight, ChevronLeft, Clock, Eye,
  ThumbsUp, Copy, Check, Hash, Lightbulb, AlertTriangle, Info,
  FileText, ArrowRight, type LucideIcon,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// DOC NAVIGATION — left sidebar categories
// ============================================================

interface DocPage {
  id: string
  title: string
  category: string
  description: string
  readTime: string
  lastUpdated: string
}

const DOC_CATEGORIES = [
  "Introduction",
  "Setup",
  "Tasks",
  "Projects",
  "Kanban",
  "Calendar",
  "Team",
  "Time",
  "Analytics",
  "API",
  "Webhooks",
  "Integrations",
] as const

const DOC_PAGES: DocPage[] = [
  { id: "intro", title: "Welcome to Planna", category: "Introduction", description: "An overview of what Planna can do for your team.", readTime: "3 min", lastUpdated: "2026-01-28" },
  { id: "concepts", title: "Core concepts", category: "Introduction", description: "Workspaces, projects, tasks, and how they relate.", readTime: "5 min", lastUpdated: "2026-01-26" },
  { id: "setup-account", title: "Create your account", category: "Setup", description: "Sign up and verify your email in 60 seconds.", readTime: "2 min", lastUpdated: "2026-01-22" },
  { id: "setup-workspace", title: "Set up your workspace", category: "Setup", description: "Choose a name, logo, and default preferences.", readTime: "4 min", lastUpdated: "2026-01-20" },
  { id: "setup-invite", title: "Invite your team", category: "Setup", description: "Bring teammates in and assign roles.", readTime: "3 min", lastUpdated: "2026-01-18" },
  { id: "tasks-create", title: "Create and edit tasks", category: "Tasks", description: "Add tasks, set due dates, and assign owners.", readTime: "4 min", lastUpdated: "2026-01-15" },
  { id: "tasks-priorities", title: "Priorities and labels", category: "Tasks", description: "Use priorities and labels to stay organized.", readTime: "3 min", lastUpdated: "2026-01-12" },
  { id: "tasks-subtasks", title: "Subtasks and checklists", category: "Tasks", description: "Break down larger work into smaller steps.", readTime: "4 min", lastUpdated: "2026-01-10" },
  { id: "projects-create", title: "Create a project", category: "Projects", description: "Spin up a new project with template and team.", readTime: "5 min", lastUpdated: "2026-01-08" },
  { id: "projects-milestones", title: "Milestones and timelines", category: "Projects", description: "Plan releases and track key dates.", readTime: "6 min", lastUpdated: "2026-01-05" },
  { id: "kanban-basics", title: "Kanban board basics", category: "Kanban", description: "Drag, drop, and customize your columns.", readTime: "4 min", lastUpdated: "2026-01-04" },
  { id: "kanban-wip", title: "WIP limits and column rules", category: "Kanban", description: "Prevent bottlenecks with WIP limits.", readTime: "5 min", lastUpdated: "2026-01-03" },
  { id: "cal-view", title: "Calendar view", category: "Calendar", description: "See tasks and deadlines on a calendar grid.", readTime: "3 min", lastUpdated: "2026-01-02" },
  { id: "cal-sync", title: "Two-way calendar sync", category: "Calendar", description: "Sync with Google, Outlook, and iCal.", readTime: "4 min", lastUpdated: "2025-12-30" },
  { id: "team-roles", title: "Roles and permissions", category: "Team", description: "Owner, admin, manager, member, viewer.", readTime: "5 min", lastUpdated: "2025-12-28" },
  { id: "team-guests", title: "Guests and external collaborators", category: "Team", description: "Invite clients and contractors with limits.", readTime: "3 min", lastUpdated: "2025-12-26" },
  { id: "time-track", title: "Time tracking", category: "Time", description: "Start, pause, and resume timers on tasks.", readTime: "4 min", lastUpdated: "2025-12-22" },
  { id: "time-reports", title: "Time reports and exports", category: "Time", description: "Build timesheets and billable summaries.", readTime: "5 min", lastUpdated: "2025-12-20" },
  { id: "analytics-overview", title: "Analytics overview", category: "Analytics", description: "Understand your team's productivity at a glance.", readTime: "5 min", lastUpdated: "2025-12-18" },
  { id: "analytics-custom", title: "Custom dashboards", category: "Analytics", description: "Compose widgets into your own views.", readTime: "6 min", lastUpdated: "2025-12-15" },
  { id: "api-quickstart", title: "API quickstart", category: "API", description: "Make your first request in under a minute.", readTime: "5 min", lastUpdated: "2025-12-12" },
  { id: "api-auth", title: "Authentication", category: "API", description: "API keys, scopes, and rate limits.", readTime: "4 min", lastUpdated: "2025-12-10" },
  { id: "api-tasks", title: "Tasks endpoint", category: "API", description: "CRUD for tasks with filtering and pagination.", readTime: "6 min", lastUpdated: "2025-12-08" },
  { id: "webhooks-intro", title: "Webhooks overview", category: "Webhooks", description: "Get notified when things change in Planna.", readTime: "4 min", lastUpdated: "2025-12-05" },
  { id: "webhooks-events", title: "Event reference", category: "Webhooks", description: "Complete list of supported webhook events.", readTime: "5 min", lastUpdated: "2025-12-03" },
  { id: "integ-slack", title: "Slack integration", category: "Integrations", description: "Get task updates in your Slack channels.", readTime: "3 min", lastUpdated: "2025-12-01" },
  { id: "integ-github", title: "GitHub integration", category: "Integrations", description: "Link commits and PRs to Planna tasks.", readTime: "4 min", lastUpdated: "2025-11-28" },
]

// ============================================================
// SAMPLE DOC CONTENT
// ============================================================

interface ContentBlock {
  type: "h2" | "p" | "ul" | "code" | "callout"
  text?: string
  items?: string[]
  language?: string
  variant?: "info" | "warning" | "tip"
}

const SAMPLE_CONTENT: Record<string, ContentBlock[]> = {
  intro: [
    { type: "p", text: "Planna is a project and task management platform designed for fast-moving teams. It brings tasks, projects, kanban boards, calendars, time tracking, and analytics into a single, fast workspace." },
    { type: "h2", text: "What you can do" },
    { type: "ul", items: [
      "Organize work across unlimited projects and milestones.",
      "Choose between list, Kanban, calendar, and timeline views.",
      "Track time with one-click timers and billable splits.",
      "Collaborate with comments, mentions, and file attachments.",
      "Automate workflows with webhooks, the API, and integrations.",
    ]},
    { type: "callout", variant: "tip", text: "New here? Start with the Getting Started guide — it walks you through your first project in under 10 minutes." },
    { type: "h2", text: "Where to go next" },
    { type: "ul", items: [
      "Read Core Concepts to understand workspaces vs projects.",
      "Set up your workspace and invite your team.",
      "Create your first project and add a few tasks.",
      "Install the desktop and mobile apps for offline access.",
    ]},
  ],
}

function defaultContentFor(page: DocPage): ContentBlock[] {
  return [
    { type: "p", text: page.description },
    { type: "h2", text: "Overview" },
    { type: "p", text: `This page covers everything you need to know about ${page.title.toLowerCase()} within the ${page.category} area of Planna. We'll walk through the key concepts, common workflows, and a few pro tips along the way.` },
    { type: "h2", text: "Getting started" },
    { type: "ul", items: [
      "Open the relevant area from the left sidebar.",
      "Use ⌘K to jump straight to the page or task you need.",
      "Configure your preferences under Settings.",
      "Invite teammates to collaborate in real time.",
    ]},
    { type: "callout", variant: "info", text: `This doc was last updated on ${page.lastUpdated}. If something looks out of date, let us know via the Contact support page.` },
    { type: "h2", text: "Pro tips" },
    { type: "ul", items: [
      "Use labels to group related tasks across projects.",
      "Set WIP limits on Kanban columns to prevent overload.",
      "Pin frequently-used views for quick access.",
      "Schedule a weekly digest so nobody misses updates.",
    ]},
    { type: "h2", text: "Next steps" },
    { type: "p", text: "Once you're comfortable, explore the integrations and webhooks to automate repetitive work. The API section has everything you need to build custom workflows." },
  ]
}

// ============================================================
// DOC SIDEBAR ITEM
// ============================================================

function DocSidebar({
  selectedId,
  onSelect,
  query,
}: {
  selectedId: string
  onSelect: (id: string) => void
  query: string
}) {
  return (
    <div className="space-y-4">
      {DOC_CATEGORIES.map(cat => {
        const pages = DOC_PAGES.filter(p => p.category === cat)
        if (pages.length === 0) return null
        const filtered = query.trim()
          ? pages.filter(p => p.title.toLowerCase().includes(query.toLowerCase()))
          : pages
        if (filtered.length === 0) return null
        return (
          <div key={cat}>
            <p className="px-2 mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {cat}
            </p>
            <div className="space-y-0.5">
              {filtered.map(p => {
                const active = p.id === selectedId
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => onSelect(p.id)}
                    className={cn(
                      "w-full flex items-center gap-2 px-2 h-8 rounded-md text-xs font-medium text-left transition-colors",
                      active
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary",
                    )}
                  >
                    <span className="truncate">{p.title}</span>
                  </button>
                )
              })}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ============================================================
// CONTENT RENDERER
// ============================================================

function ContentRenderer({ blocks }: { blocks: ContentBlock[] }) {
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null)

  const copyCode = (text: string, idx: number) => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        setCopiedIdx(idx)
        setTimeout(() => setCopiedIdx(null), 1500)
        toast.success("Copied to clipboard")
      })
    }
  }

  return (
    <div className="space-y-4">
      {blocks.map((b, i) => {
        if (b.type === "h2") {
          return (
            <h2 key={i} className="flex items-center gap-2 text-base font-semibold text-foreground mt-6 scroll-mt-24">
              <Hash className="w-3.5 h-3.5 text-primary" />
              {b.text}
            </h2>
          )
        }
        if (b.type === "p") {
          return <p key={i} className="text-sm text-muted-foreground leading-relaxed">{b.text}</p>
        }
        if (b.type === "ul") {
          return (
            <ul key={i} className="space-y-1.5">
              {b.items?.map((it, j) => (
                <li key={j} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                  <span>{it}</span>
                </li>
              ))}
            </ul>
          )
        }
        if (b.type === "code") {
          return (
            <div key={i} className="relative rounded-lg border border-border bg-secondary/50 overflow-hidden">
              <div className="flex items-center justify-between px-3 py-1.5 border-b border-border bg-secondary">
                <span className="text-[10px] font-mono text-muted-foreground">{b.language ?? "bash"}</span>
                <button
                  type="button"
                  onClick={() => copyCode(b.text ?? "", i)}
                  className="text-[10px] text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                >
                  {copiedIdx === i ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                  {copiedIdx === i ? "Copied" : "Copy"}
                </button>
              </div>
              <pre className="p-3 text-xs font-mono text-foreground overflow-x-auto"><code>{b.text}</code></pre>
            </div>
          )
        }
        if (b.type === "callout") {
          const variants = {
            info: { icon: Info, className: "border-sky-500/30 bg-sky-500/5 text-foreground", iconCls: "bg-sky-500/15 text-sky-600 dark:text-sky-400" },
            warning: { icon: AlertTriangle, className: "border-amber-500/30 bg-amber-500/5 text-foreground", iconCls: "bg-amber-500/15 text-amber-600 dark:text-amber-400" },
            tip: { icon: Lightbulb, className: "border-primary/30 bg-primary/5 text-foreground", iconCls: "bg-primary/15 text-primary" },
          } as const
          const v = variants[b.variant ?? "info"]
          const TIcon = v.icon
          return (
            <div key={i} className={cn("flex items-start gap-3 p-3 rounded-lg border", v.className)}>
              <div className={cn("w-7 h-7 rounded-md flex items-center justify-center shrink-0", v.iconCls)}>
                <TIcon className="w-3.5 h-3.5" />
              </div>
              <p className="text-xs text-foreground leading-relaxed">{b.text}</p>
            </div>
          )
        }
        return null
      })}
    </div>
  )
}

// ============================================================
// TABLE OF CONTENTS (right sidebar)
// ============================================================

function TableOfContents({ blocks }: { blocks: ContentBlock[] }) {
  const headings = blocks.filter(b => b.type === "h2") as { type: "h2"; text: string }[]
  if (headings.length === 0) return null
  return (
    <div className="space-y-2">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">On this page</p>
      <ul className="space-y-1 border-l border-border">
        {headings.map((h, i) => (
          <li key={i}>
            <a
              href="#"
              onClick={e => { e.preventDefault() }}
              className="block pl-3 -ml-px py-0.5 text-[11px] text-muted-foreground hover:text-primary border-l border-transparent hover:border-primary transition-colors leading-snug"
            >
              {h.text}
            </a>
          </li>
        ))}
      </ul>
    </div>
  )
}

// ============================================================
// PAGE
// ============================================================

export default function DocsPage() {
  const [selectedId, setSelectedId] = useState<string>("intro")
  const [query, setQuery] = useState("")
  const [helpful, setHelpful] = useState<"up" | "down" | null>(null)

  const selectedPage = useMemo(
    () => DOC_PAGES.find(p => p.id === selectedId) ?? DOC_PAGES[0],
    [selectedId],
  )

  const content = SAMPLE_CONTENT[selectedId] ?? defaultContentFor(selectedPage)
  const currentIndex = DOC_PAGES.findIndex(p => p.id === selectedId)
  const prevPage = currentIndex > 0 ? DOC_PAGES[currentIndex - 1] : null
  const nextPage = currentIndex < DOC_PAGES.length - 1 ? DOC_PAGES[currentIndex + 1] : null

  return (
    <DashboardShell
      title="Documentation"
      description="Complete guides, references, and tutorials for everything in Planna."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5">
          <Link href="/help"><ChevronLeft className="w-3.5 h-3.5" /> Back to Help</Link>
        </Button>
      }
    >
      <HelpMobileNav />

      <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr_220px] gap-4 lg:gap-6 animate-fade-in">
        {/* Left sidebar — doc navigation */}
        <aside className="hidden lg:block">
          <div className="sticky top-4 max-h-[calc(100vh-2rem)] overflow-y-auto pr-1 scroll-area-thin">
            {/* Search docs */}
            <div className="relative mb-4">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search docs…"
                className="h-8 pl-8 pr-2 text-xs"
              />
            </div>
            <DocSidebar selectedId={selectedId} onSelect={setSelectedId} query={query} />
          </div>
        </aside>

        {/* Mobile doc search */}
        <div className="lg:hidden">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search docs…"
              className="h-10 pl-10 text-sm"
            />
          </div>
        </div>

        {/* Main content */}
        <div className="min-w-0 space-y-4">
          <Card className="p-5 md:p-7 card-lift">
            {/* Breadcrumb */}
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mb-3">
              <Link href="/help" className="hover:text-foreground">Help</Link>
              <ChevronRight className="w-3 h-3" />
              <span>Docs</span>
              <ChevronRight className="w-3 h-3" />
              <span className="text-foreground">{selectedPage.category}</span>
            </div>

            {/* Title */}
            <div className="flex items-start justify-between gap-3 mb-1">
              <div className="flex items-start gap-3 min-w-0">
                <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <BookOpen className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h1 className="text-xl font-bold text-foreground tracking-tight">{selectedPage.title}</h1>
                  <p className="text-xs text-muted-foreground mt-0.5">{selectedPage.description}</p>
                </div>
              </div>
            </div>

            {/* Meta */}
            <div className="flex items-center gap-3 mt-4 pb-4 border-b border-border">
              <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                <Clock className="w-3 h-3" /> {selectedPage.readTime} read
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                <Eye className="w-3 h-3" /> {Math.floor(Math.random() * 10) + 1}.{Math.floor(Math.random() * 9)}K views
              </span>
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4 bg-primary/10 text-primary">
                {selectedPage.category}
              </Badge>
              <span className="ml-auto text-[10px] text-muted-foreground">
                Updated {selectedPage.lastUpdated}
              </span>
            </div>

            {/* Body */}
            <div className="mt-5">
              <ContentRenderer blocks={content} />
            </div>

            {/* Was this helpful */}
            <div className="mt-7 pt-5 border-t border-border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex items-center gap-3">
                <p className="text-xs text-muted-foreground">Was this helpful?</p>
                <div className="flex gap-1.5">
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "h-8 gap-1.5 text-xs bg-transparent",
                      helpful === "up" && "border-primary bg-primary/10 text-primary",
                    )}
                    onClick={() => { setHelpful("up"); toast.success("Thanks for the feedback!") }}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" /> Yes
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "h-8 gap-1.5 text-xs bg-transparent",
                      helpful === "down" && "border-primary bg-primary/10 text-primary",
                    )}
                    onClick={() => { setHelpful("down"); toast.success("Thanks — we'll improve this page.") }}
                  >
                    <ThumbsUp className="w-3.5 h-3.5 rotate-180" /> No
                  </Button>
                </div>
              </div>
              <Button asChild variant="link" size="sm" className="h-8 text-xs text-primary px-0">
                <Link href="/help/contact">Still have questions? <ArrowRight className="w-3 h-3" /></Link>
              </Button>
            </div>
          </Card>

          {/* Prev / next nav */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {prevPage ? (
              <Card className="p-4 card-lift group cursor-pointer" >
                <button type="button" onClick={() => { setSelectedId(prevPage.id); setHelpful(null); window.scrollTo({ top: 0, behavior: "smooth" }) }} className="text-left w-full">
                  <p className="text-[10px] text-muted-foreground flex items-center gap-1"><ChevronLeft className="w-3 h-3" /> Previous</p>
                  <p className="text-xs font-semibold text-foreground mt-1 group-hover:text-primary transition-colors">{prevPage.title}</p>
                </button>
              </Card>
            ) : <div />}
            {nextPage ? (
              <Card className="p-4 card-lift group cursor-pointer">
                <button type="button" onClick={() => { setSelectedId(nextPage.id); setHelpful(null); window.scrollTo({ top: 0, behavior: "smooth" }) }} className="text-right w-full">
                  <p className="text-[10px] text-muted-foreground flex items-center gap-1 justify-end">Next <ChevronRight className="w-3 h-3" /></p>
                  <p className="text-xs font-semibold text-foreground mt-1 group-hover:text-primary transition-colors">{nextPage.title}</p>
                </button>
              </Card>
            ) : <div />}
          </div>
        </div>

        {/* Right sidebar — TOC */}
        <aside className="hidden lg:block">
          <div className="sticky top-4 max-h-[calc(100vh-2rem)] overflow-y-auto pr-1 scroll-area-thin space-y-6">
            <TableOfContents blocks={content} />

            {/* Help card */}
            <Card className="p-4 border-dashed">
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <FileText className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-foreground">Need more help?</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">Browse all docs or contact our support team.</p>
                  <Button asChild variant="link" size="sm" className="h-6 px-0 mt-1 text-xs text-primary">
                    <Link href="/help/contact">Contact support <ArrowRight className="w-3 h-3" /></Link>
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </aside>
      </div>
    </DashboardShell>
  )
}
