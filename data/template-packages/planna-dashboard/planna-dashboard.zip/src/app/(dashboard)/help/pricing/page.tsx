"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import {
  Check, Sparkles, Zap, Building2, Crown, ArrowRight, Phone,
  HelpCircle, Minus,
} from "lucide-react"
import { cn, formatCurrency } from "@/lib/utils"
import { toast } from "sonner"
import { HelpLayout, HelpMobileNav } from "../_lib"

// ============================================================
// PLANS
// ============================================================

type Cycle = "monthly" | "annual"

interface Plan {
  id: string
  name: string
  icon: typeof Sparkles
  tagline: string
  monthlyPrice: number
  features: string[]
  cta: string
  highlight?: boolean
  color: string
  accent: string
}

const PLANS: Plan[] = [
  {
    id: "starter",
    name: "Starter",
    icon: Zap,
    tagline: "For solo builders and side projects.",
    monthlyPrice: 0,
    features: [
      "Up to 3 projects",
      "Up to 2 seats",
      "1 GB storage",
      "Kanban + list views",
      "Mobile apps (iOS + Android)",
      "Community support",
    ],
    cta: "Get started free",
    color: "text-sky-600 dark:text-sky-400",
    accent: "from-sky-500/10 to-transparent",
  },
  {
    id: "pro",
    name: "Pro",
    icon: Sparkles,
    tagline: "For small teams getting serious.",
    monthlyPrice: 49,
    features: [
      "Up to 20 projects",
      "Up to 10 seats",
      "50 GB storage",
      "All views (timeline, calendar, analytics)",
      "Time tracking + Focus mode",
      "Priority support (< 2h reply)",
      "5 guest collaborators",
    ],
    cta: "Start Pro trial",
    color: "text-emerald-600 dark:text-emerald-400",
    accent: "from-emerald-500/10 to-transparent",
    highlight: true,
  },
  {
    id: "scale",
    name: "Scale",
    icon: Sparkles,
    tagline: "For growing agencies and studios.",
    monthlyPrice: 99,
    features: [
      "Up to 50 projects",
      "Up to 25 seats",
      "100 GB storage",
      "SSO & SCIM provisioning",
      "Audit logs (1-year retention)",
      "API & webhooks",
      "25 guest collaborators",
      "Custom analytics dashboards",
    ],
    cta: "Start Scale trial",
    color: "text-teal-600 dark:text-teal-400",
    accent: "from-teal-500/10 to-transparent",
  },
  {
    id: "enterprise",
    name: "Enterprise",
    icon: Building2,
    tagline: "For larger orgs with custom needs.",
    monthlyPrice: 299,
    features: [
      "Unlimited projects",
      "Unlimited seats",
      "1 TB storage",
      "Dedicated CSM",
      "Custom SLA (99.99%)",
      "On-prem / VPC option",
      "Unlimited guests",
      "SAML SSO + SCIM + audit log export",
    ],
    cta: "Talk to sales",
    color: "text-violet-600 dark:text-violet-400",
    accent: "from-violet-500/10 to-transparent",
  },
]

// ============================================================
// COMPARISON TABLE
// ============================================================

interface FeatureRow {
  label: string
  values: (boolean | string)[]
  group?: string
  last?: boolean
}

const COMPARISON: FeatureRow[] = [
  { group: "Core", label: "Projects", values: ["3", "20", "50", "Unlimited"] },
  { label: "Seats", values: ["2", "10", "25", "Unlimited"] },
  { label: "Storage", values: ["1 GB", "50 GB", "100 GB", "1 TB"] },
  { label: "Guest collaborators", values: ["0", "5", "25", "Unlimited"] },
  { label: "Kanban, list, calendar views", values: [true, true, true, true] },
  { label: "Timeline / Gantt view", values: [false, true, true, true] },
  { label: "Mobile apps (iOS + Android)", values: [true, true, true, true] },

  { group: "Collaboration", label: "Real-time co-editing", values: [true, true, true, true] },
  { label: "Comments & @mentions", values: [true, true, true, true] },
  { label: "File attachments", values: [true, true, true, true] },
  { label: "Task templates", values: [false, true, true, true] },
  { label: "Recurring tasks", values: [false, true, true, true] },

  { group: "Time & Analytics", label: "Time tracking", values: [false, true, true, true] },
  { label: "Focus mode (Pomodoro)", values: [false, true, true, true] },
  { label: "Billable vs non-billable", values: [false, true, true, true] },
  { label: "Analytics dashboards", values: [false, true, true, true] },
  { label: "Custom dashboards", values: [false, false, true, true] },
  { label: "Productivity score", values: [false, true, true, true] },

  { group: "Security & Admin", label: "Two-factor auth (TOTP)", values: [true, true, true, true] },
  { label: "SSO (SAML 2.0)", values: [false, false, true, true] },
  { label: "SCIM provisioning", values: [false, false, true, true] },
  { label: "Audit logs", values: [false, false, "1 year", "Unlimited"] },
  { label: "Data residency (EU/APAC)", values: [false, false, false, true] },
  { label: "Custom SLA (99.99%)", values: [false, false, false, true] },

  { group: "Developer", label: "REST API", values: [false, true, true, true] },
  { label: "Webhooks", values: [false, true, true, true] },
  { label: "API rate limit", values: ["—", "1K/min", "1K/min", "10K/min"] },
  { label: "Official SDKs", values: [false, true, true, true] },

  { group: "Support", label: "Support channel", values: ["Community", "Email", "Email + Chat", "Phone + CSM"] },
  { label: "Response time SLA", values: ["—", "< 24h", "< 2h", "< 1h"], last: true },
]

// ============================================================
// FAQ
// ============================================================

const PRICING_FAQS = [
  { q: "Can I change plans at any time?", a: "Yes — upgrade instantly with prorated billing. Downgrades take effect at the end of your current cycle, so you keep premium features until then." },
  { q: "Is there a free trial?", a: "Yes — Pro and Scale each include a 14-day free trial. No credit card required. We'll email you 3 days before the trial ends." },
  { q: "Do you offer discounts?", a: "Annual billing saves 20%. Non-profits and educational institutions get 50% off Pro and Scale. Contact support with verification." },
  { q: "What payment methods do you accept?", a: "Visa, Mastercard, AMEX, Discover via Stripe. Enterprise customers can pay by ACH or wire transfer on annual contracts." },
  { q: "What happens if I exceed my limits?", a: "Nothing breaks. You'll see an in-app prompt to upgrade. Data is preserved — extra items become read-only until you upgrade or remove them." },
  { q: "Can I get a custom plan?", a: "Yes — Enterprise supports custom seat counts, storage, SLAs, and security requirements. Talk to our sales team for a tailored quote." },
]

// ============================================================
// COMPARISON ROW
// ============================================================

function FeatureRowItem({ row, last }: { row: FeatureRow; last?: boolean }) {
  return (
    <tr className={cn("border-b border-border", last && "border-b-0")}>
      <td className="px-4 md:px-5 py-2.5 text-xs text-foreground font-medium">
        {row.group && (
          <p className="text-[10px] font-semibold uppercase tracking-wider text-primary mb-0.5">{row.group}</p>
        )}
        {row.label}
      </td>
      {row.values.map((v, i) => (
        <td key={i} className="px-2 md:px-3 py-2.5 text-center text-xs">
          {typeof v === "boolean" ? (
            v ? <Check className="w-3.5 h-3.5 text-primary mx-auto" /> : <Minus className="w-3.5 h-3.5 text-muted-foreground/40 mx-auto" />
          ) : (
            <span className={cn("text-foreground", v === "—" && "text-muted-foreground/60")}>{v}</span>
          )}
        </td>
      ))}
    </tr>
  )
}

// ============================================================
// PAGE
// ============================================================

export default function PricingPage() {
  const [cycle, setCycle] = useState<Cycle>("monthly")
  const annualDiscount = 0.2

  const priceFor = (plan: Plan) => {
    if (plan.monthlyPrice === 0) return 0
    if (cycle === "annual") return Math.round(plan.monthlyPrice * (1 - annualDiscount))
    return plan.monthlyPrice
  }

  return (
    <DashboardShell
      title="Pricing"
      description="Simple, transparent pricing for teams of every size. Start free — upgrade when you're ready."
      actions={
        <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5">
          <Link href="/help/faq"><HelpCircle className="w-3.5 h-3.5" /> Pricing FAQ</Link>
        </Button>
      }
    >
      <HelpMobileNav />
      <HelpLayout>
        {/* CYCLE TOGGLE */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-foreground">Choose your billing cycle</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {cycle === "annual"
                  ? "Pay annually and save 20% — about 2 months free."
                  : "Pay monthly. Switch to annual anytime to save 20%."}
              </p>
            </div>
            <div className="inline-flex items-center gap-2 rounded-lg bg-muted p-1 h-9">
              <button
                type="button"
                onClick={() => setCycle("monthly")}
                className={cn(
                  "h-7 px-3 text-xs font-medium rounded-md transition-all",
                  cycle === "monthly" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
                )}
              >
                Monthly
              </button>
              <button
                type="button"
                onClick={() => setCycle("annual")}
                className={cn(
                  "h-7 px-3 text-xs font-medium rounded-md transition-all inline-flex items-center gap-1.5",
                  cycle === "annual" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground",
                )}
              >
                Annual
                <Badge variant="secondary" className="text-[9px] px-1 py-0 h-4 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                  -20%
                </Badge>
              </button>
            </div>
          </div>
        </Card>

        {/* PLAN CARDS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
          {PLANS.map(plan => {
            const Icon = plan.icon
            const price = priceFor(plan)
            const isHighlight = plan.highlight
            return (
              <Card
                key={plan.id}
                className={cn(
                  "p-5 card-lift relative flex flex-col",
                  isHighlight && "border-primary ring-2 ring-primary/20 bg-primary/5",
                )}
              >
                {isHighlight && (
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground gap-1 shadow-md">
                      <Crown className="w-3 h-3" /> Most popular
                    </Badge>
                  </div>
                )}

                <div className={cn(
                  "flex items-center gap-2 mb-1 p-2 rounded-lg bg-gradient-to-br",
                  plan.accent,
                )}>
                  <div className={cn("w-8 h-8 rounded-lg bg-background flex items-center justify-center shadow-sm", plan.color)}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-semibold text-foreground">{plan.name}</h3>
                </div>
                <p className="text-[11px] text-muted-foreground mb-3 min-h-[28px] mt-2">{plan.tagline}</p>

                <div className="mb-4">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold text-foreground tracking-tight">
                      {price === 0 ? "Free" : formatCurrency(price)}
                    </span>
                    {price > 0 && (
                      <span className="text-[11px] text-muted-foreground">/mo</span>
                    )}
                  </div>
                  {cycle === "annual" && price > 0 && (
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 mt-0.5">
                      Billed {formatCurrency(price * 12)}/yr
                    </p>
                  )}
                  {price === 0 && (
                    <p className="text-[10px] text-muted-foreground mt-0.5">Free forever</p>
                  )}
                </div>

                <Separator className="mb-3" />

                <ul className="space-y-1.5 mb-5 flex-1">
                  {plan.features.map(f => (
                    <li key={f} className="flex items-start gap-1.5 text-[11px] text-foreground">
                      <Check className="w-3 h-3 text-primary mt-0.5 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>

                <Button
                  size="sm"
                  variant={isHighlight ? "default" : "outline"}
                  className={cn(
                    "h-9 text-xs gap-1.5 w-full",
                    isHighlight ? "bg-primary text-primary-foreground hover:bg-primary/90" : "bg-transparent",
                  )}
                  onClick={() => {
                    toast.success(plan.id === "enterprise" ? "Sales will reach out" : `Starting ${plan.name} trial`, {
                      description: plan.id === "enterprise"
                        ? "Our team will email you within 1 business day."
                        : "14-day free trial — no credit card required.",
                    })
                  }}
                >
                  {plan.cta}
                  <ArrowRight className="w-3.5 h-3.5" />
                </Button>
              </Card>
            )
          })}
        </div>

        {/* FEATURE COMPARISON TABLE */}
        <Card className="p-0 card-lift overflow-hidden">
          <div className="p-5 md:p-6 border-b border-border">
            <h3 className="text-sm font-semibold text-foreground">Full feature comparison</h3>
            <p className="text-xs text-muted-foreground mt-0.5">Everything included with each plan, side by side.</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse min-w-[760px]">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground px-4 md:px-5 py-3">
                    Feature
                  </th>
                  {PLANS.map(p => (
                    <th key={p.id} className="px-2 md:px-3 py-3 text-center">
                      <p className={cn("text-xs font-semibold text-foreground", p.highlight && "text-primary")}>{p.name}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {p.monthlyPrice === 0 ? "Free" : `${formatCurrency(priceFor(p))}/mo`}
                      </p>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {COMPARISON.map((row, i) => (
                  <FeatureRowItem
                    key={i}
                    row={row}
                    last={i === COMPARISON.length - 1}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* ENTERPRISE CTA */}
        <Card className="p-5 md:p-6 card-lift bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/20">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-foreground">Need a custom plan?</h3>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                Enterprise supports custom seat counts, storage, security reviews, and SLAs. Our sales team can tailor a quote for teams of 100+.
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button asChild variant="outline" size="sm" className="h-9 text-xs bg-transparent gap-1.5">
                <Link href="/help/contact"><Phone className="w-3.5 h-3.5" /> Talk to sales</Link>
              </Button>
              <Button asChild size="sm" className="h-9 text-xs gap-1.5 bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/help/contact">Get a quote <ArrowRight className="w-3.5 h-3.5" /></Link>
              </Button>
            </div>
          </div>
        </Card>

        {/* FAQ */}
        <Card className="p-5 md:p-6 card-lift">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">Pricing FAQ</h3>
              <p className="text-[11px] text-muted-foreground">Common questions about plans and billing</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
            {PRICING_FAQS.map(f => (
              <div key={f.q} className="flex items-start gap-2">
                <ArrowRight className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-foreground">{f.q}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{f.a}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 pt-5 border-t border-border flex items-center justify-between">
            <p className="text-[11px] text-muted-foreground">Still have questions?</p>
            <Button asChild variant="link" size="sm" className="h-7 text-xs text-primary">
              <Link href="/help/contact">Contact support <ArrowRight className="w-3 h-3" /></Link>
            </Button>
          </div>
        </Card>

        {/* TRUST BADGES */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "SOC 2 Type II", description: "Annual independent audit" },
            { label: "GDPR & CCPA", description: "Full data protection compliance" },
            { label: "99.99% uptime", description: "Production-grade SLA" },
            { label: "Cancel anytime", description: "No lock-in, no hassle" },
          ].map(b => (
            <Card key={b.label} className="p-3 card-lift">
              <p className="text-xs font-semibold text-foreground">{b.label}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{b.description}</p>
            </Card>
          ))}
        </div>
      </HelpLayout>
    </DashboardShell>
  )
}
