"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  DndContext, DragOverlay, useDraggable, useDroppable,
  PointerSensor, useSensor, useSensors, closestCenter,
  type DragEndEvent, type DragStartEvent,
} from "@dnd-kit/core"
import { useState } from "react"
import {
  Plus, MoreHorizontal, Star, MessageSquare, Paperclip,
  CheckCircle2, Clock, Filter, Save, Layout as LayoutIcon,
} from "lucide-react"
import { useTaskStore } from "@/lib/store/task-store"
import { PriorityBadge, LabelBadge } from "@/components/common/badges"
import { cn, relativeDay, isOverdue } from "@/lib/utils"
import type { Task } from "@/types"
import Link from "next/link"

export default function KanbanPage() {
  const columns = useTaskStore(s => s.columns)
  const tasks = useTaskStore(s => s.tasks)
  const moveTask = useTaskStore(s => s.moveTaskToColumn)
  const toggleStar = useTaskStore(s => s.toggleTaskStar)
  const [activeId, setActiveId] = useState<string | null>(null)

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  )

  const handleDragStart = (e: DragStartEvent) => setActiveId(e.active.id as string)
  const handleDragEnd = (e: DragEndEvent) => {
    setActiveId(null)
    const { active, over } = e
    if (!over) return
    const taskId = active.id as string
    const task = tasks.find(t => t.id === taskId)
    if (!task) return
    // Find source column
    const fromCol = columns.find(c => c.taskIds.includes(taskId))
    if (!fromCol) return
    // Determine target column — could be column droppable or a task in another column
    const overId = over.id as string
    let toColId = overId
    let toIndex: number | undefined
    const overCol = columns.find(c => c.id === overId)
    if (overCol) {
      toColId = overId
      toIndex = overCol.taskIds.length
    } else {
      const targetCol = columns.find(c => c.taskIds.includes(overId))
      if (targetCol) {
        toColId = targetCol.id
        toIndex = targetCol.taskIds.indexOf(overId)
      }
    }
    if (fromCol.id === toColId && toIndex !== undefined) {
      // reorder within column
      const newIds = [...fromCol.taskIds]
      const fromIdx = newIds.indexOf(taskId)
      newIds.splice(fromIdx, 1)
      newIds.splice(toIndex, 0, taskId)
      // Just call moveTaskToColumn with explicit index
      moveTask(taskId, fromCol.id, toColId, toIndex)
    } else {
      moveTask(taskId, fromCol.id, toColId, toIndex)
    }
  }

  const activeTask = activeId ? tasks.find(t => t.id === activeId) : null

  return (
    <DashboardShell
      title="Kanban Board"
      description="Drag cards across columns. Click a card to open details."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Filter
          </Button>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Save className="w-4 h-4" /> Save view
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New task
          </Button>
        </>
      }
    >
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {columns.map(col => {
            const colTasks = col.taskIds.map(id => tasks.find(t => t.id === id)!).filter(Boolean)
            const done = colTasks.filter(t => t.status === "done").length
            return (
              <KanbanColumn key={col.id} col={col} tasks={colTasks} doneCount={done} onToggleStar={toggleStar} />
            )
          })}
        </div>
        <DragOverlay>
          {activeTask ? <KanbanCard task={activeTask} onToggleStar={() => {}} dragging /> : null}
        </DragOverlay>
      </DndContext>
    </DashboardShell>
  )
}

function KanbanColumn({ col, tasks, doneCount, onToggleStar }: {
  col: { id: string; title: string; color: string; taskIds: string[] }
  tasks: Task[]
  doneCount: number
  onToggleStar: (id: string) => void
}) {
  const { setNodeRef, isOver } = useDroppable({ id: col.id })
  return (
    <div
      ref={setNodeRef}
      className={cn(
        "rounded-xl border border-border bg-card/50 transition-colors flex flex-col",
        isOver && "border-primary/40 bg-primary/5"
      )}
    >
      <div className="p-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={cn("w-2 h-2 rounded-full", col.color.replace("/15", ""))} />
          <p className="text-xs font-semibold text-foreground">{col.title}</p>
          <Badge variant="outline" className="text-[10px]">{tasks.length}</Badge>
        </div>
        <Button variant="ghost" size="icon" className="h-6 w-6">
          <Plus className="w-3 h-3" />
        </Button>
      </div>
      <div className="p-2 space-y-2 min-h-[200px] flex-1 overflow-y-auto scroll-area-thin">
        {tasks.map(t => (
          <DraggableCard key={t.id} task={t} onToggleStar={onToggleStar} />
        ))}
        {tasks.length === 0 && (
          <div className="text-center py-8 text-[10px] text-muted-foreground">
            Drop tasks here
          </div>
        )}
      </div>
    </div>
  )
}

function DraggableCard({ task, onToggleStar }: { task: Task; onToggleStar: (id: string) => void }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({ id: task.id })
  return (
    <div ref={setNodeRef} {...attributes} {...listeners} className={cn(isDragging && "opacity-30")}>
      <KanbanCard task={task} onToggleStar={onToggleStar} />
    </div>
  )
}

function KanbanCard({ task, onToggleStar, dragging }: { task: Task; onToggleStar: (id: string) => void; dragging?: boolean }) {
  const subtaskDone = task.subtasks.filter(s => s.done).length
  return (
    <Link
      href={dragging ? "#" : `/tasks/${task.id}`}
      onClick={(e) => { if (dragging) e.preventDefault() }}
      className={cn(
        "block p-2.5 rounded-lg border border-border bg-card hover:border-primary/30 hover:shadow-md transition-all group cursor-grab active:cursor-grabbing",
        dragging && "shadow-xl rotate-2"
      )}
    >
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <span className="text-[10px] font-mono text-muted-foreground">{task.key}</span>
        <button
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); onToggleStar(task.id) }}
          className="text-muted-foreground hover:text-amber-500 transition-colors"
        >
          <Star className={cn("w-3 h-3", task.starred && "fill-amber-500 text-amber-500")} />
        </button>
      </div>
      <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors line-clamp-2 mb-2">
        {task.title}
      </p>

      <div className="flex items-center gap-1 flex-wrap mb-2">
        <PriorityBadge priority={task.priority} />
        {task.labels.slice(0, 2).map(l => <LabelBadge key={l.id} label={l} />)}
      </div>

      {task.subtasks.length > 0 && (
        <div className="mb-2">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[9px] text-muted-foreground flex items-center gap-1">
              <CheckCircle2 className="w-2.5 h-2.5" /> {subtaskDone}/{task.subtasks.length}
            </span>
            <span className="text-[9px] text-muted-foreground">{Math.round((subtaskDone / task.subtasks.length) * 100)}%</span>
          </div>
          <Progress value={(subtaskDone / task.subtasks.length) * 100} className="h-0.5" />
        </div>
      )}

      <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
          {task.dueDate && (
            <span className={cn("flex items-center gap-0.5",
              isOverdue(task.dueDate) && task.status !== "done" && "text-rose-600 dark:text-rose-400"
            )}>
              <Clock className="w-2.5 h-2.5" /> {relativeDay(task.dueDate)}
            </span>
          )}
          {task.comments.length > 0 && (
            <span className="flex items-center gap-0.5"><MessageSquare className="w-2.5 h-2.5" /> {task.comments.length}</span>
          )}
          {task.attachments > 0 && (
            <span className="flex items-center gap-0.5"><Paperclip className="w-2.5 h-2.5" /> {task.attachments}</span>
          )}
        </div>
        {task.assigneeAvatar && (
          <Avatar className="w-5 h-5"><AvatarImage src={task.assigneeAvatar} alt={task.assignee ?? ""} /><AvatarFallback className="text-[9px]">{task.assignee?.[0]}</AvatarFallback></Avatar>
        )}
      </div>
    </Link>
  )
}
