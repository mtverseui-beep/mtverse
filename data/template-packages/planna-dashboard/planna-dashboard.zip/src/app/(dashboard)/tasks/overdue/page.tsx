"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { TasksTable } from "@/components/task/tasks-table"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Clock, Bell, Filter } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useTaskStore } from "@/lib/store/task-store"
import { isOverdue, cn, relativeDay } from "@/lib/utils"
import { PriorityBadge } from "@/components/common/badges"
import Link from "next/link"

export default function OverdueTasksPage() {
  const tasks = useTaskStore(s => s.tasks)
  const overdue = tasks.filter(t => isOverdue(t.dueDate) && t.status !== "done")
  const urgentOverdue = overdue.filter(t => t.priority === "urgent")
  const blockedOverdue = overdue.filter(t => t.status === "blocked")

  return (
    <DashboardShell
      title="Overdue Tasks"
      description="Tasks past their due date — prioritize and unblock."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Filter
          </Button>
          <Button className="h-9 text-sm bg-rose-600 hover:bg-rose-700 text-white gap-1.5">
            <Bell className="w-4 h-4" /> Send reminders
          </Button>
        </>
      }
    >
      {/* Urgent warning banner */}
      <Card className="p-4 mb-4 bg-rose-500/5 border-rose-500/30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-rose-500/15 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-rose-700 dark:text-rose-400">
              {overdue.length} tasks are overdue
            </p>
            <p className="text-xs text-muted-foreground">
              {urgentOverdue.length} urgent · {blockedOverdue.length} blocked · consider re-prioritizing or extending deadlines.
            </p>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Overdue" value={overdue.length} hint="past due date" icon={AlertTriangle} trend={{ value: 2, positive: false }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Urgent" value={urgentOverdue.length} hint="highest priority" icon={Clock} trend={{ value: 1, positive: false }} iconColor="bg-orange-500/15 text-orange-600 dark:text-orange-400" />
        <StatCard label="Blocked" value={blockedOverdue.length} hint="need unblocking" icon={AlertTriangle} trend={{ value: 0, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Avg Days Late" value="3.2d" hint="past deadline" icon={Clock} trend={{ value: 8, positive: false }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>

      {/* Top overdue list */}
      <Card className="p-4 md:p-5 mb-4 card-lift">
        <h3 className="text-sm font-semibold mb-3">Most overdue</h3>
        <div className="space-y-2">
          {overdue.slice(0, 4).map(t => {
            const daysLate = Math.floor((Date.now() - new Date(t.dueDate!).getTime()) / 86400000)
            return (
              <Link
                key={t.id}
                href={`/tasks/${t.id}`}
                className="flex items-center gap-3 p-3 rounded-lg border border-rose-500/30 bg-rose-500/5 hover:bg-rose-500/10 transition-colors group"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors line-clamp-1">
                    {t.title}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] font-mono text-muted-foreground">{t.key}</span>
                    <PriorityBadge priority={t.priority} />
                    <span className="text-[10px] text-muted-foreground">{t.projectName}</span>
                  </div>
                </div>
                <div className="text-right">
                  <Badge className="bg-rose-500/15 text-rose-600 dark:text-rose-400 text-[10px]">
                    {daysLate}d late
                  </Badge>
                  {t.assigneeAvatar && <Avatar className="w-5 h-5 mt-1"><AvatarImage src={t.assigneeAvatar} alt={t.assignee ?? ""} /><AvatarFallback className="text-[9px]">{t.assignee?.[0]}</AvatarFallback></Avatar>}
                </div>
              </Link>
            )
          })}
        </div>
      </Card>

      <TasksTable filterPreset={{ overdue: true }} />
    </DashboardShell>
  )
}
