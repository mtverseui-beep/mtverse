"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { TasksTable } from "@/components/task/tasks-table"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Download, Filter } from "lucide-react"
import { useTaskStore } from "@/lib/store/task-store"
import { StatCard } from "@/components/common/stat-card"
import { CheckSquare, Clock, AlertTriangle, Timer } from "lucide-react"
import { tasks as seedTasks } from "@/lib/data/mock"

export default function TasksPage() {
  const tasks = useTaskStore(s => s.tasks)
  const active = tasks.filter(t => t.status !== "done").length
  const done = tasks.filter(t => t.status === "done").length
  const overdue = tasks.filter(t => t.dueDate && new Date(t.dueDate).getTime() < Date.now() && t.status !== "done").length
  const inProgress = tasks.filter(t => t.status === "in_progress").length

  return (
    <DashboardShell
      title="Tasks"
      description="Plan, prioritize, and accomplish your tasks with ease."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Filter className="w-4 h-4" /> Saved views
          </Button>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Download className="w-4 h-4" /> Export
          </Button>
          <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
            <Plus className="w-4 h-4" /> New task
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active" value={active} hint="in progress" icon={CheckSquare} trend={{ value: 8, positive: true }} />
        <StatCard label="In Progress" value={inProgress} hint="being worked on" icon={Timer} trend={{ value: 4, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
        <StatCard label="Completed" value={done} hint="this sprint" icon={Clock} trend={{ value: 18, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Overdue" value={overdue} hint="needs attention" icon={AlertTriangle} trend={{ value: 2, positive: false }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
      </div>

      <Tabs defaultValue="all">
        <TabsList className="mb-4">
          <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
          <TabsTrigger value="my" className="text-xs">My tasks</TabsTrigger>
          <TabsTrigger value="assigned" className="text-xs">Assigned</TabsTrigger>
          <TabsTrigger value="overdue" className="text-xs">Overdue</TabsTrigger>
          <TabsTrigger value="completed" className="text-xs">Completed</TabsTrigger>
        </TabsList>
      </Tabs>

      <TasksTable />
    </DashboardShell>
  )
}
