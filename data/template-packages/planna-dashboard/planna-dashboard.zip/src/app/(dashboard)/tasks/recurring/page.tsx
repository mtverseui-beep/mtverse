"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { TasksTable } from "@/components/task/tasks-table"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { RefreshCw, Plus, Calendar, Clock, Repeat } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { useTaskStore } from "@/lib/store/task-store"
import { cn } from "@/lib/utils"
import Link from "next/link"

export default function RecurringTasksPage() {
  const tasks = useTaskStore(s => s.tasks)
  const recurring = tasks.filter(t => t.recurring && t.recurring !== "none")

  return (
    <DashboardShell
      title="Recurring Tasks"
      description="Tasks that repeat on a schedule — set once, run forever."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New recurring task
        </Button>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Active Recurring" value={recurring.length} hint="scheduled tasks" icon={Repeat} trend={{ value: 4, positive: true }} />
        <StatCard label="Daily" value={recurring.filter(t => t.recurring === "daily").length} hint="run every day" icon={Calendar} iconColor="bg-sky-500/15 text-sky-600 dark:text-sky-400" />
        <StatCard label="Weekly" value={recurring.filter(t => t.recurring === "weekly").length} hint="run every week" icon={RefreshCw} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="Monthly" value={recurring.filter(t => t.recurring === "monthly").length} hint="run every month" icon={Clock} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      <Card className="p-4 md:p-5 mb-4 card-lift">
        <h3 className="text-sm font-semibold mb-3">Schedule overview</h3>
        <div className="space-y-2">
          {recurring.map(t => (
            <Link
              key={t.id}
              href={`/tasks/${t.id}`}
              className="flex items-center gap-3 p-3 rounded-lg border border-border hover:border-primary/30 hover:bg-secondary/30 transition-colors group"
            >
              <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center",
                t.recurring === "daily" ? "bg-sky-500/15 text-sky-600 dark:text-sky-400" :
                t.recurring === "weekly" ? "bg-violet-500/15 text-violet-600 dark:text-violet-400" :
                "bg-amber-500/15 text-amber-600 dark:text-amber-400"
              )}>
                <RefreshCw className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors line-clamp-1">{t.title}</p>
                <p className="text-[10px] text-muted-foreground">{t.key} · {t.projectName}</p>
              </div>
              <Badge className={cn("text-[10px] capitalize",
                t.recurring === "daily" ? "bg-sky-500/15 text-sky-600 dark:text-sky-400" :
                t.recurring === "weekly" ? "bg-violet-500/15 text-violet-600 dark:text-violet-400" :
                "bg-amber-500/15 text-amber-600 dark:text-amber-400"
              )}>
                {t.recurring}
              </Badge>
            </Link>
          ))}
        </div>
      </Card>

      <TasksTable filterPreset={{ recurring: true }} />
    </DashboardShell>
  )
}
