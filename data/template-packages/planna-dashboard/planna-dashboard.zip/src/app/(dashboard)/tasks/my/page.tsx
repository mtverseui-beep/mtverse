"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { TasksTable } from "@/components/task/tasks-table"
import { Button } from "@/components/ui/button"
import { Plus, ListChecks } from "lucide-react"
import { currentMember } from "@/lib/data/mock"
import { StatCard } from "@/components/common/stat-card"
import { CheckSquare, Clock, AlertTriangle, Target } from "lucide-react"
import { useTaskStore } from "@/lib/store/task-store"

export default function MyTasksPage() {
  const tasks = useTaskStore(s => s.tasks)
  const myTasks = tasks.filter(t => t.assignee === currentMember.name)
  const active = myTasks.filter(t => t.status !== "done").length
  const done = myTasks.filter(t => t.status === "done").length
  const overdue = myTasks.filter(t => t.dueDate && new Date(t.dueDate).getTime() < Date.now() && t.status !== "done").length

  return (
    <DashboardShell
      title="My Tasks"
      description="Everything assigned to you, all in one place."
      actions={
        <Button className="h-9 text-sm bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5">
          <Plus className="w-4 h-4" /> New task
        </Button>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="My Active" value={active} hint="in progress" icon={CheckSquare} trend={{ value: 8, positive: true }} />
        <StatCard label="Completed" value={done} hint="this sprint" icon={Target} trend={{ value: 18, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Overdue" value={overdue} hint="needs attention" icon={AlertTriangle} trend={{ value: 2, positive: false }} iconColor="bg-rose-500/15 text-rose-600 dark:text-rose-400" />
        <StatCard label="Avg Close Time" value="2.4d" hint="last 30 days" icon={Clock} trend={{ value: 12, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
      </div>
      <TasksTable filterPreset={{ assignee: currentMember.name }} />
    </DashboardShell>
  )
}
