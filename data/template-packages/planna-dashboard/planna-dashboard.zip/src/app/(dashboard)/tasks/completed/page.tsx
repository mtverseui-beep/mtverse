"use client"

import { DashboardShell } from "@/components/layout/dashboard-shell"
import { TasksTable } from "@/components/task/tasks-table"
import { Button } from "@/components/ui/button"
import { Download, RotateCcw } from "lucide-react"
import { StatCard } from "@/components/common/stat-card"
import { CheckCircle2, Clock, Target, TrendingUp } from "lucide-react"
import { ChartCard, PlannaBarChart } from "@/components/charts"
import { useTaskStore } from "@/lib/store/task-store"
import { productivityTrend } from "@/lib/data/mock"

export default function CompletedTasksPage() {
  const tasks = useTaskStore(s => s.tasks)
  const done = tasks.filter(t => t.status === "done")

  return (
    <DashboardShell
      title="Completed Tasks"
      description="Your done list — celebrate the wins and review velocity."
      actions={
        <>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <RotateCcw className="w-4 h-4" /> Reopen
          </Button>
          <Button variant="outline" className="h-9 text-sm gap-1.5 bg-transparent">
            <Download className="w-4 h-4" /> Export
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-4">
        <StatCard label="Completed (30d)" value={done.length} hint="tasks shipped" icon={CheckCircle2} trend={{ value: 18, positive: true }} />
        <StatCard label="Avg Close Time" value="2.4d" hint="from creation to done" icon={Clock} trend={{ value: 12, positive: true }} iconColor="bg-violet-500/15 text-violet-600 dark:text-violet-400" />
        <StatCard label="On-Time %" value="84%" hint="completed before due" icon={Target} trend={{ value: 4, positive: true }} iconColor="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" />
        <StatCard label="Velocity" value="+12%" hint="vs last month" icon={TrendingUp} trend={{ value: 12, positive: true }} iconColor="bg-amber-500/15 text-amber-600 dark:text-amber-400" />
      </div>

      <ChartCard title="Completion Trend" subtitle="Tasks completed per week, last 12 weeks" className="mb-4">
        <PlannaBarChart
          data={productivityTrend}
          xKey="week"
          series={[{ key: "completed", name: "Completed", color: "var(--chart-1)" }]}
          height={220}
          showLegend={false}
        />
      </ChartCard>

      <TasksTable filterPreset={{ completed: true }} />
    </DashboardShell>
  )
}
